"""Learn a help-screen theme from an artist's PSD (one-time per game).

usage: python theme_extract.py <reference.psd> <theme_dir> [bg.png]

bg.png: optional flattened frame/background (e.g. exported once from Photoshop);
otherwise the bg group is composited with psd-tools (needs scipy for adjustments).

Writes <theme_dir>/theme.json plus assets (background PNG, table row art, raw
layer-effect blocks). Which reference layer plays which role is given in ROLES;
in the real tool the user would pick these once in the UI.
"""
import collections, io, json, logging, os, sys, time

from psd_tools import PSDImage
from psd_tools.constants import Tag

logging.disable(logging.WARNING)  # psd-tools warns about engine data it doesn't model

ROLES = {
    "bg_group": "bg",
    "title": ("Game RUles 1 2 3 4", "GAME RULES"),
    "body": ("Game RUles 1 2 3 4", "Prizes displayed on"),
    "legal": ("Game RUles 1 2 3 4", "Malfunction voids"),
    "body_icon": ("Game RUles 1 2 3 4", "Layer 1841 copy"),
    "table_group": "Wheel Blast denom 1 2",
    "table_header": "WHEEL PRIZES",
    "table_first_cell": "Double Up",
    "table_cell": "4 or more",
    "table_icon": "Layer 1833 copy 13",
    "art_header_left": "Layer 958",
    "art_header_right": ("Layer 1846 copy", 519),   # name repeats; disambiguate by top
    "art_row_left": "Layer 1846 copy 8",
    "art_row_right": "Layer 1846 copy 2",
}
EFFECT_TAGS = (Tag.OBJECT_BASED_EFFECTS_LAYER_INFO, Tag.OBJECT_BASED_EFFECTS_LAYER_INFO_V0,
               Tag.OBJECT_BASED_EFFECTS_LAYER_INFO_V1, Tag.EFFECTS_LAYER)


def group(psd, name):
    return next(l for l in psd if l.name == name)


def find(parent, prefix, top=None):
    for l in parent.descendants():
        name = l.name if l.kind != "type" else (l.text.strip() or l.name)
        if (l.name.startswith(prefix) or name.startswith(prefix)) and (top is None or l.top == top):
            return l
    raise KeyError(prefix)


def group_opacity(root, layer):
    """Combined opacity of the groups between root and layer (e.g. table art at 69%)."""
    def path(node, target):
        for child in node:
            if child is target:
                return [node]
            if child.is_group():
                sub = path(child, target)
                if sub:
                    return [node] + sub
        return None
    op = 1.0
    for g in (path(root, layer) or [])[1:]:
        op *= g.opacity / 255.0
    return op * layer.opacity / 255.0


def runs(layer):
    fs = layer.resource_dict["FontSet"]
    sr = layer.engine_dict["StyleRun"]
    pos, out = 0, []
    for r, n in zip(sr["RunArray"], sr["RunLengthArray"]):
        sd = r["StyleSheet"]["StyleSheetData"]
        c = sd.get("FillColor", {}).get("Values")
        out.append(dict(font=str(fs[int(sd.get("Font", 0))]["Name"]).strip("'"),
                        size=float(sd.get("FontSize", 0)),
                        leading=float(sd["Leading"]) if "Leading" in sd else None,
                        color=[round(float(v) * 255) for v in c[1:]] if c else [0, 0, 0],
                        text=layer.text[pos:pos + int(n)]))
        pos += int(n)
    return out


def text_style(layer):
    """Dominant run style of a type layer (by character count)."""
    rs = [r for r in runs(layer) if r["text"].strip()]
    weight = collections.Counter()
    for r in rs:
        weight[(r["font"], round(r["size"], 2), tuple(r["color"]))] += len(r["text"])
    font, size, color = weight.most_common(1)[0][0]
    leads = collections.Counter(r["leading"] for r in rs if r["font"] == font and r["leading"])
    return dict(font=font, size=size, color=list(color),
                leading=leads.most_common(1)[0][0] if leads else round(size * 1.2, 1))


def raw_block(block):
    buf = io.BytesIO()
    block.write(buf)
    return buf.getvalue()


def main(ref, out, bg_png=None):
    t0 = time.perf_counter()
    os.makedirs(out, exist_ok=True)
    psd = PSDImage.open(ref)
    W, H = psd.size
    theme = {"source": os.path.basename(ref), "canvas": [W, H]}

    # Background: composite the artist's frame group into one layer.
    if bg_png:
        from PIL import Image
        Image.open(bg_png).convert("RGBA").save(os.path.join(out, "bg.png"))
    else:
        group(psd, ROLES["bg_group"]).composite(viewport=(0, 0, W, H)).save(os.path.join(out, "bg.png"))
    theme["background"] = {"file": "bg.png", "left": 0, "top": 0}

    # Title: font + transform + the full effect stack, copied byte for byte.
    g, name = ROLES["title"]
    title = find(group(psd, g), name)
    fx_files = []
    for tag in EFFECT_TAGS:
        blk = title._record.tagged_blocks.get(tag)
        if blk is not None:
            fname = f"title_fx_{tag.name}.bin"
            open(os.path.join(out, fname), "wb").write(raw_block(blk))
            fx_files.append(fname)
    st = text_style(title)
    xx, xy, yx, yy, tx, ty = [float(v) for v in title.transform]
    theme["title"] = dict(st, scale_x=xx, scale_y=yy, center_x=W / 2, baseline_y=ty,
                          bbox=list(title.bbox), effects=fx_files)

    # Body + legal paragraph styles and the area they occupy.
    g, name = ROLES["body"]
    body = find(group(psd, g), name)
    gr = group(psd, ROLES["title"][0])
    widest = max((l for l in gr if l.kind == "type" and l.visible and l is not title),
                 key=lambda l: l.width)
    theme["body"] = dict(text_style(body), left=widest.left, right=widest.right,
                         top=min(l.top for l in gr if l.kind == "type" and l.visible and l is not title))
    g, name = ROLES["legal"]
    legal = find(group(psd, g), name)
    lst = text_style(legal)
    lst["leading"] = round(legal.height / max(1, legal.text.strip().count("\r") + 1), 1) \
        if legal.text.count("\r") else lst["leading"]
    theme["legal"] = dict(lst, left=legal.left, right=legal.right, top=legal.top,
                          trigger="Malfunction voids")
    g, name = ROLES["body_icon"]
    icon = find(group(psd, g), name)
    theme["body"]["icon_height"] = icon.height

    # Table styles, geometry and row art.
    tg = group(psd, ROLES["table_group"])
    hdr, first, cell = (find(tg, ROLES[k]) for k in ("table_header", "table_first_cell", "table_cell"))
    art, art_layers = {}, {}
    for key in ("art_header_left", "art_header_right", "art_row_left", "art_row_right"):
        spec = ROLES[key]
        layer = find(tg, *spec) if isinstance(spec, tuple) else find(tg, spec)
        layer.topil().save(os.path.join(out, f"{key}.png"))
        art_layers[key] = layer
        art[key] = dict(file=f"{key}.png", bbox=list(layer.bbox))
    rows_right = sorted({l.top for l in tg.descendants()
                         if l.kind == "pixel" and l.visible and l.left == art["art_row_right"]["bbox"][0]})
    theme["table"] = dict(
        header=text_style(hdr), first_cell=text_style(first), cell=text_style(cell),
        art=art,
        columns=[[art["art_row_left"]["bbox"][0], art["art_row_left"]["bbox"][2]],
                 [art["art_row_right"]["bbox"][0], art["art_row_right"]["bbox"][2]]],
        row_height=art["art_row_right"]["bbox"][3] - art["art_row_right"]["bbox"][1],
        row_pitch=min(b - a for a, b in zip(rows_right, rows_right[1:])),
        icon_height=find(tg, ROLES["table_icon"]).height,
        art_opacity=round(group_opacity(tg, art_layers["art_row_right"]), 3),
    )
    theme["table"]["first_cell"]["color"] = None  # first column takes keyword colours
    # Lowest artist text on any page = how far content may run down (safe area).
    theme["content_bottom"] = max(l.bottom for g in psd if g.is_group() and g.name != ROLES["bg_group"]
                                  for l in g.descendants()
                                  if l.kind == "type" and l.visible and l.text.strip())

    # Keyword colours: any run whose colour differs from its layer's main colour.
    kw = collections.Counter()
    for l in psd.descendants():
        if l.kind != "type" or not l.visible:
            continue
        try:
            rs = runs(l)
        except Exception:
            continue
        if not any(r["text"] for r in rs):
            continue
        main = collections.Counter(tuple(r["color"]) for r in rs for _ in r["text"]).most_common(1)[0][0]
        for r in rs:
            word = r["text"].strip(" ,.\r")
            if word and tuple(r["color"]) != main and len(word) > 2 and not word.isdigit():
                kw[(word, tuple(r["color"]))] += 1
    best = {}
    for (word, col), n in kw.most_common():
        best.setdefault(word, list(col))
    theme["keywords"] = best

    json.dump(theme, open(os.path.join(out, "theme.json"), "w"), indent=1)
    print(f"theme extracted in {time.perf_counter() - t0:.1f}s -> {out}")
    print(json.dumps({k: v for k, v in theme.items() if k != "table"}, indent=1)[:2500])


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else None)
