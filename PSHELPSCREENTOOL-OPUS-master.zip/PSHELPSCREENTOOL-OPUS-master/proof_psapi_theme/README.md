# PSAPI + theme proof (2026-10-16)

Two pages of BZZF_Blast_AGR_NYL.xlsx built without Photoshop, styled from the
artist's PSDRef/BZZF_blastBlueHelps.psd. Proof code only; the engine is unchanged.

    # one-time per game (bg.png = the artist's bg group exported flat)
    python theme_extract.py ../PSDRef/BZZF_blastBlueHelps.psd theme theme/bg.png
    # build
    python build_pages.py theme ../ExcelFileForReference/BZZF_Blast_AGR_NYL.xlsx ../symbols out.psd "Game Rules (denom1,2,3&4)" "Wheel(denom 1&2)"

- proof.psd: generated PSD (29 editable text layers, icons, table art, title effects)
- cmp_*.png: artist (top) vs generated, as opened in Photoshop with no refresh
