"""Proof: build help-screen pages from Excel + learned theme + symbols, no Photoshop.

usage: python build_pages.py <theme_dir> <excel> <symbols_dir> <out.psd> <sheet> [<sheet> ...]

Pipeline:
  Excel sheet -> blocks (title, paragraphs, table rows, legal)
  -> layout with skia/HarfBuzz measurement (kerning like Photoshop)
  -> PSAPI: editable text layers (keyword colour runs, explicit line breaks,
     centred), icon layers over space gaps, table row art, background
  -> psd-tools pass: attach preview pixels to every text layer + copy the
     title's effect blocks, write file with a quick merged image.
"""
import io, json, logging, math, os, re, sys, time

import numpy as np
import openpyxl
import photoshopapi as psapi
import skia
from PIL import Image
from psd_tools import PSDImage
from psd_tools.api import layers as ptl
from psd_tools.constants import Compression
from psd_tools.psd.tagged_blocks import TaggedBlock

logging.disable(logging.WARNING)

# ── text measurement / rendering (skia textlayout = HarfBuzz shaping) ────────
TL = skia.textlayout
UNICODE = skia.Unicode.ICU_Make()
# Register font files directly: skia's system FontMgr can't resolve "Arial Black" by name.
_files = TL.TypefaceFontProvider()
for _family, _file in (("Arial", "arial.ttf"), ("Arial", "arialbd.ttf"), ("Arial Black", "ariblk.ttf")):
    _files.registerTypeface(skia.Typeface.MakeFromFile(os.path.join(r"C:\Windows\Fonts", _file)), _family)
FONTS = TL.FontCollection()
FONTS.setDefaultFontManager(_files)
FAMILY = {
    "ArialMT": ("Arial", skia.FontStyle.Normal()),
    "Arial-BoldMT": ("Arial", skia.FontStyle.Bold()),
    "Arial-Black": ("Arial Black", skia.FontStyle.Normal()),
}
CAP = 0.716  # Arial cap height / em, for vertically centring icons and cells


def paragraph(segs, size):
    """segs: [(text, postscript_font, rgb)] -> laid-out single-line skia Paragraph."""
    b = TL.ParagraphBuilder(TL.ParagraphStyle(), FONTS, UNICODE)
    for text, font, rgb in segs:
        ts = TL.TextStyle()
        fam, style = FAMILY[font]
        ts.setFontFamilies([fam]); ts.setFontStyle(style); ts.setFontSize(size)
        ts.setColor(skia.Color(*rgb))
        b.pushStyle(ts); b.addText(text); b.pop()
    p = b.Build()
    p.layout(100000)
    return p


_wcache = {}
def width(segs, size):
    key = (tuple(segs), size)
    if key not in _wcache:
        _wcache[key] = paragraph(list(segs), size).LongestLine
    return _wcache[key]


# ── Excel -> blocks ──────────────────────────────────────────────────────────
def advance(segs, upto, size):
    """Shaped x-advance of the first `upto` characters of a line (trailing spaces included)."""
    pre, n = [], upto
    for t, f, rgb in segs:
        if n <= 0:
            break
        pre.append((t[:n], f, rgb)); n -= len(t)
    if not pre:
        return 0.0
    probe = ("|", pre[-1][1], (0, 0, 0))
    return width(tuple(pre) + (probe,), size) - width((probe,), size)


ANNOTATION = re.compile(r"^\s*<\s*(added|modified|removed)\b", re.I)
TOKEN = re.compile(r"<([^<>]+)>")


def clean(text):
    text = str(text).replace("�", "™").replace("\r", "")
    text = re.sub(r" {5,}", "\n", text)            # long space runs were manual line breaks
    return [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]


def read_sheet(path, sheet):
    ws = openpyxl.load_workbook(path)[sheet]
    title, items = None, []
    for row in ws.iter_rows():
        cells = [(c.column, c.value) for c in row
                 if c.value not in (None, "") and str(c.value).strip() and not ANNOTATION.match(str(c.value))]
        if not cells:
            continue
        if title is None and row[0].row <= 4:
            title = clean(cells[0][1])[0]
            continue
        if len(cells) >= 2:
            items.append(("row", [clean(v)[0] if clean(v) else "" for _, v in cells]))
        else:
            for part in clean(cells[0][1]):
                items.append(("para", part))
    return title, items


# ── theme + symbols ─────────────────────────────────────────────────────────
def norm(s):
    return re.sub(r"[^a-z0-9]", "", s.lower())


class Ctx:
    def __init__(self, theme_dir, symbols_dir):
        self.dir = theme_dir
        self.t = json.load(open(os.path.join(theme_dir, "theme.json")))
        self.symbols = {norm(os.path.splitext(f)[0]): os.path.join(symbols_dir, f)
                        for f in os.listdir(symbols_dir) if f.lower().endswith(".png")}
        kw = self.t["keywords"]
        keep = {k: v for k, v in kw.items()
                if max(v) - min(v) > 60 and not any(k != o and o.endswith(k) for o in kw)}
        self.keywords = sorted(keep.items(), key=lambda kv: -len(kv[0]))
        self.kw_re = re.compile("|".join(re.escape(k) for k, _ in self.keywords)) if keep else None
        self.missing = []
        self._icons = {}

    def icon(self, token, height):
        path = self.symbols.get(norm(token))
        if not path:
            self.missing.append(token)
            return None
        key = (path, height)
        if key not in self._icons:
            im = Image.open(path).convert("RGBA")
            im = im.crop(im.getbbox())
            self._icons[key] = im.resize((max(1, round(im.width * height / im.height)), height), Image.LANCZOS)
        return self._icons[key]


# ── inline layout: atoms -> wrapped lines ───────────────────────────────────
def atoms(ctx, text, style, base_rgb, icon_h):
    """Split text into wrap atoms: words (keyword-coloured) and icons."""
    out = []
    for i, part in enumerate(TOKEN.split(text)):
        if i % 2:  # token
            im = ctx.icon(part, icon_h)
            if im is not None:
                out.append(("icon", im))
            continue
        pieces, pos = [], 0
        for m in (ctx.kw_re.finditer(part) if ctx.kw_re else []):
            pieces.append((part[pos:m.start()], base_rgb))
            pieces.append((m.group(0), tuple(dict(ctx.keywords)[m.group(0)])))
            pos = m.end()
        pieces.append((part[pos:], base_rgb))
        for chunk, rgb in pieces:
            for w in re.findall(r"\S+\s*|\s+", chunk):
                out.append(("text", w, rgb))
    return out


def gap_spaces(style, im):
    space = width((( " ", style["font"], (0, 0, 0)),), style["size"])
    return max(1, math.ceil((im.width + style["size"] * 0.5) / space))


def line_segs(line, style):
    """Atoms of one line -> merged (text, font, rgb) segments + icon char ranges."""
    segs, icons, text = [], [], ""
    for a in line:
        if a[0] == "icon":
            n = gap_spaces(style, a[1])
            icons.append((len(text), len(text) + n, a[1]))
            seg = (" " * n, style["font"], tuple(style["color"]))
        else:
            seg = (a[1], style["font"], a[2])
        text += seg[0]
        if segs and segs[-1][1:] == seg[1:]:
            segs[-1] = (segs[-1][0] + seg[0],) + seg[1:]
        else:
            segs.append(seg)
    if segs:  # drop trailing whitespace on the line
        t = segs[-1][0].rstrip()
        segs[-1] = (t,) + segs[-1][1:]
        if not t:
            segs.pop()
    return segs, icons


WRAP_TOLERANCE = 1.02  # theme widths come from the artist's widest line; allow equality


def sentences(parts):
    """Regroup word atoms into sentence atoms (legal text breaks at sentence ends)."""
    out, cur = [], []
    for a in parts:
        cur.append(a)
        if a[0] == "text" and re.search(r"[.!?]\s+$", a[1]):
            out.append(cur); cur = []
    if cur:
        out.append(cur)
    return out


def wrap(ctx, text, style, max_w, icon_h, unit="word"):
    max_w *= WRAP_TOLERANCE
    lines, cur = [], []
    fits = lambda line: width(tuple(line_segs(line, style)[0]), style["size"]) <= max_w
    if unit == "sentence":
        for hard in text.split("\n"):
            cur = []
            for sent in sentences(atoms(ctx, hard, style, tuple(style["color"]), icon_h)):
                if cur and not fits(cur + sent):
                    lines.append(cur); cur = []
                if fits(cur + sent):
                    cur += sent
                else:                       # one sentence wider than the line: word-wrap it
                    for a in sent:
                        if cur and not fits(cur + [a]):
                            lines.append(cur); cur = []
                        cur.append(a)
            lines.append(cur)
        return [line_segs(l, style) for l in lines if l]
    for hard in text.split("\n"):
        cur = []
        for a in atoms(ctx, hard, style, tuple(style["color"]), icon_h):
            trial = cur + [a]
            if cur and not fits(trial):
                lines.append(cur)
                cur = [a] if a[0] == "icon" or a[1].strip() else []
            else:
                cur = trial
        lines.append(cur)
    return [line_segs(l, style) for l in lines if l]


# ── text block = one PSAPI layer + its preview ──────────────────────────────
class TextBlock:
    def __init__(self, name, lines, style, cx, baseline, leading, scale=(1.0, 1.0)):
        self.name, self.lines, self.style = name, lines, style
        self.cx, self.baseline, self.leading, self.scale = cx, baseline, leading, scale
        self.icons = []          # (PIL image, left, top)
        self.preview = None      # (PIL image, left, top)

    def layout(self):
        """Render preview and place icons over the space gaps."""
        size = self.style["size"] * self.scale[1]
        sx = self.scale[0] / self.scale[1]
        rendered = []
        for i, (segs, gaps) in enumerate(self.lines):
            p = paragraph(segs, size)
            w = p.LongestLine * sx
            left = self.cx - w / 2
            base = self.baseline + i * self.leading
            rendered.append((p, left, base))
            for a, b, im in gaps:
                gx = left + (advance(segs, a, size) + advance(segs, b, size)) / 2 * sx
                gy = base - size * CAP / 2
                self.icons.append((im, round(gx - im.width / 2), round(gy - im.height / 2)))
        pad = int(size)
        x0 = int(min(l for _, l, _ in rendered)) - pad
        x1 = int(max(l + p.LongestLine * sx for p, l, _ in rendered)) + pad
        y0 = int(min(b for *_, b in rendered) - size * 1.2) - pad
        y1 = int(max(b for *_, b in rendered) + size * 0.4) + pad
        surf = skia.Surface(max(1, x1 - x0), max(1, y1 - y0))
        with surf as c:
            c.clear(skia.ColorTRANSPARENT)
            for p, left, base in rendered:
                c.save(); c.translate(left - x0, base - y0); c.scale(sx, 1)
                p.paint(c, 0, -p.AlphabeticBaseline); c.restore()
        arr = surf.makeImageSnapshot().toarray(colorType=skia.kRGBA_8888_ColorType,
                                               alphaType=skia.kUnpremul_AlphaType)
        im = Image.fromarray(arr)
        bb = im.getbbox()
        self.preview = (im.crop(bb), x0 + bb[0], y0 + bb[1]) if bb else None
        return self

    def text(self):
        return "\r".join("".join(s[0] for s in segs) for segs, _ in self.lines)

    def psapi_layer(self):
        st = self.style
        full = self.text()
        tl = psapi.TextLayer_8bit(layer_name=self.name, text=full, font=st["font"],
                                  font_size=float(st["size"]), fill_color=argb(st["color"]),
                                  position_x=float(self.cx), position_y=float(self.baseline))
        tl.fill = 1.0; tl.opacity = 1.0
        tl.convert_to_point_text()
        fonts = {f for segs, _ in self.lines for _, f, _ in segs} | {st["font"]}
        for f in fonts:
            tl.add_font(f)
        tl.set_font(st["font"])
        # style runs: one per (font, colour) change, across lines ("\r" counts as 1 char)
        spans, pos = [], 0
        for li, (segs, _) in enumerate(self.lines):
            for t, f, rgb in segs:
                spans.append((pos, len(t), f, rgb)); pos += len(t)
            pos += 1 if li < len(self.lines) - 1 else 0
        run, run_start = 0, 0
        for k, (start, n, f, rgb) in enumerate(spans):
            if k and start > run_start:
                tl.split_style_run(run, start - run_start)
                run += 1; run_start = start
            tl.set_style_run_fill_color(run, argb(rgb))
            tl.set_style_run_font(run, tl.find_font_index(f))
        for r in range(tl.style_run_count):
            tl.set_style_run_font_size(r, float(st["size"]))
            tl.set_style_run_auto_leading(r, False)
            tl.set_style_run_leading(r, float(self.leading / self.scale[1]))
        for r in range(tl.paragraph_run_count):
            tl.set_paragraph_run_justification(r, psapi.enum.Justification.Center)
        if self.scale != (1.0, 1.0):
            tl.set_transform([self.scale[0], 0.0, 0.0, self.scale[1], float(self.cx), float(self.baseline)])
        return tl


def argb(rgb):
    return [1.0, rgb[0] / 255.0, rgb[1] / 255.0, rgb[2] / 255.0]


# ── page layout ─────────────────────────────────────────────────────────────
def short(text, n=40):
    return re.sub(r"\s+", " ", text)[:n].strip() or "text"


def scaled(style, f):
    out = dict(style, size=round(style["size"] * f, 1), leading=round(style["leading"] * f, 1))
    if "icon_height" in style:
        out["icon_height"] = round(style["icon_height"] * f)
    return out


def fit_page(ctx, title, items):
    """Artist-style fitting: tighten paragraph gaps, then line spacing, then step the size down."""
    limit = ctx.t["content_bottom"]
    # (size, leading) steps shrink together, as the artist does (36pt/54 -> 34pt/45 on Wheel Blast)
    ladder = [(1.0, 1.0), (1.0, 0.9), (0.97, 0.9), (0.944, 0.9), (0.944, 0.84),
              (0.92, 0.84), (0.89, 0.84), (0.86, 0.84)]
    for size_f, lead_f in ladder:
        for gap_f in (0.85, 0.5, 0.2, 0.0):
            blocks, art, bottom = layout_page(ctx, title, items, gap_f, size_f, lead_f)
            if bottom <= limit:
                return blocks, art, dict(gap=gap_f, size=size_f, leading=lead_f, bottom=round(bottom))
    return blocks, art, dict(gap=gap_f, size=size_f, leading=lead_f, bottom=round(bottom), overflow=True)


def layout_page(ctx, title, items, gap_f=0.85, size_f=1.0, lead_f=1.0):
    """Place every block; returns (blocks, art, content bottom). Previews render later."""
    t = ctx.t
    W, H = t["canvas"]
    body, legal, tab = scaled(t["body"], size_f), t["legal"], t["table"]
    body["leading"] = max(round(body["size"] * 1.2, 1), round(body["leading"] * lead_f, 1))
    body["icon_height"] = min(body["icon_height"], round(body["leading"] * 1.4))  # icons never swallow neighbouring lines
    after_table = False
    blocks, art = [], []
    ts = t["title"]
    tb = TextBlock(title, [([(title, ts["font"], tuple(ts["color"]))], [])], ts, ts["center_x"],
                   ts["baseline_y"], ts["size"] * 1.2, scale=(ts["scale_x"], ts["scale_y"]))
    tb.is_title = True
    blocks.append(tb)

    y = body["top"]
    para_gap = body["leading"] * gap_f
    legal_parts, in_legal, table_rows, last_gap = [], False, [], 0.0
    for kind, val in items + [("end", None)]:
        if kind != "row" and table_rows:
            last_gap = max(para_gap * 0.6, body["leading"] * 0.3)
            y = layout_table(ctx, table_rows, y, blocks, art) + last_gap
            table_rows, after_table = [], True
        if kind == "row":
            table_rows.append(val)
            continue
        if kind == "end":
            break
        if val.startswith(legal["trigger"]):
            in_legal = True
        if in_legal:
            legal_parts.append(val)
            continue
        # Notes under a table run as wide as the table (artist does the same).
        span = (tab["columns"][-1][1] - tab["columns"][0][0]) if after_table else body["right"] - body["left"]
        lines = wrap(ctx, val, body, span, body["icon_height"])
        first = y + body["size"] * CAP + (body["leading"] - body["size"]) / 2
        blocks.append(TextBlock(short(val), lines, body, W / 2, first, body["leading"]))
        last_gap = para_gap
        y += len(lines) * body["leading"] + last_gap
    y -= last_gap  # no gap after the last body item
    if legal_parts:
        text = " ".join(legal_parts)
        lines = wrap(ctx, text, legal, legal["right"] - legal["left"], round(legal["size"] * 1.9),
                     unit="sentence")
        top = max(legal["top"], y + body["leading"])
        blocks.append(TextBlock(short(text), lines, legal, W / 2, top + legal["size"] * CAP + 8, legal["leading"]))
        y = top + len(lines) * legal["leading"]
    return blocks, art, y


def layout_table(ctx, rows, y, blocks, art):
    tab = ctx.t["table"]
    cols = tab["columns"]
    for i, cells in enumerate(rows):
        header = i == 0
        top = y + i * tab["row_pitch"]
        for c, (x0, x1) in enumerate(cols):
            key = f"art_{'header' if header else 'row'}_{'left' if c == 0 else 'right'}"
            im = Image.open(os.path.join(ctx.dir, tab["art"][key]["file"])).convert("RGBA")
            im = im.resize((x1 - x0, tab["row_height"]), Image.LANCZOS)
            art.append((f"{'Header' if header else 'Row'} {i} col {c + 1}", im, x0, top,
                        tab.get("art_opacity", 1.0)))
            if c >= len(cells) or not cells[c]:
                continue
            style = dict(tab["header"] if header else (tab["first_cell"] if c == 0 else tab["cell"]))
            if style.get("color") is None:
                style["color"] = [0, 0, 0]
            max_w = ((x1 - x0) - 30) / WRAP_TOLERANCE  # cells stay strictly inside their art
            lines = wrap(ctx, cells[c], style, max_w, tab["icon_height"])
            while len(lines) > 1 and style["size"] > 20:   # fit to the row: shrink, don't wrap
                style["size"] -= 1
                lines = wrap(ctx, cells[c], style, max_w, tab["icon_height"])
            base = top + tab["row_height"] / 2 + style["size"] * CAP / 2
            blocks.append(TextBlock(short(cells[c]), lines, style, (x0 + x1) / 2, base, style["size"] * 1.2))
    return y + len(rows) * tab["row_pitch"]


# ── write PSD ────────────────────────────────────────────────────────────────
def unique(name, seen):
    n, k = name, 2
    while n in seen:
        n = f"{name} {k}"; k += 1
    seen.add(n)
    return n


def rgba_layer(im, name, left, top, opacity=1.0):
    arr = np.ascontiguousarray(np.transpose(np.asarray(im, dtype=np.uint8), (2, 0, 1)))
    il = psapi.ImageLayer_8bit(arr, name, width=im.width, height=im.height,
                               pos_x=left + im.width // 2, pos_y=top + im.height // 2)
    il.fill = 1.0; il.opacity = float(opacity)
    return il


def write(ctx, pages, out):
    W, H = ctx.t["canvas"]
    lf = psapi.LayeredFile_8bit(psapi.enum.ColorMode.rgb, W, H)
    seen, previews, fx = set(), {}, {}
    for pi, (sheet, blocks, art) in enumerate(pages):
        g = psapi.GroupLayer_8bit(layer_name=sheet, is_visible=(pi == 0))
        g.fill = 1.0; g.opacity = 1.0
        lf.add_layer(g)
        # PSAPI stacks first-added on top: icons, then text, then table art.
        for b in blocks:
            for k, (im, l, t) in enumerate(b.icons):
                g.add_layer(lf, rgba_layer(im, unique(f"icon {k + 1} - {b.name[:20]}", seen), l, t))
        for b in blocks:
            b.name = unique(b.name, seen)
            g.add_layer(lf, b.psapi_layer())
            previews[b.name] = (b.preview, pi)
            if getattr(b, "is_title", False):
                fx[b.name] = ctx.t["title"]["effects"]
        for name, im, l, t, op in art:
            g.add_layer(lf, rgba_layer(im, unique(name, seen), l, t, op))
    bg = Image.open(os.path.join(ctx.dir, ctx.t["background"]["file"])).convert("RGBA")
    lf.add_layer(rgba_layer(bg, "Background (theme)", 0, 0))
    raw = out.replace(".psd", "_raw.psd")
    lf.write(raw)

    # psd-tools pass: previews + title effects + quick merged image of page 1
    psd = PSDImage.open(raw)
    comp = bg.copy()
    for layer in psd.descendants():
        name = layer.name.rstrip(chr(0))
        if layer.kind == "type" and name in previews:
            (im, left, top), page = previews[name]
            rec, chans = ptl.PixelLayer._build_layer_record_and_channels(
                im, name, left, top, Compression.RLE, version=psd._record.header.version)
            r = layer._record
            r.top, r.left, r.bottom, r.right = rec.top, rec.left, rec.bottom, rec.right
            r.channel_info = rec.channel_info
            layer._channels = chans
            for f in fx.get(name, []):
                blk = TaggedBlock.read(io.BytesIO(open(os.path.join(ctx.dir, f), "rb").read()))
                layer._record.tagged_blocks[blk.key] = blk
            if page == 0:
                comp.alpha_composite(im, (max(0, left), max(0, top)))
    psd._update_record()
    rgb = comp.convert(psd.pil_mode)
    psd._record.image_data.set_data([c.tobytes() for c in rgb.split()], psd._record.header)
    with open(out, "wb") as f:
        psd._record.write(f)
    os.remove(raw)


def main(theme_dir, excel, symbols, out, sheets):
    T = {}
    t0 = time.perf_counter()
    ctx = Ctx(theme_dir, symbols)
    pages = []
    for s in sheets:
        title, items = read_sheet(excel, s)
        blocks, art, fit = fit_page(ctx, title, items)
        for b in blocks:
            b.layout()
        print(f"  {s}: fit {fit}")
        pages.append((s, blocks, art))
    T["read+layout+previews"] = time.perf_counter() - t0
    t1 = time.perf_counter()
    write(ctx, pages, out)
    T["write psd"] = time.perf_counter() - t1
    T["total"] = time.perf_counter() - t0
    n_text = sum(len(b) for _, b, _ in pages)
    print(" ".join(f"{k}={v:.2f}s" for k, v in T.items()), f"text_layers={n_text}",
          f"missing_tokens={sorted(set(ctx.missing))}")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5:])
