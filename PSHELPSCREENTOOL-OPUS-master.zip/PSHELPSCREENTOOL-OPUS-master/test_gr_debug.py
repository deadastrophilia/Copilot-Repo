"""Test with game rules debug output."""
import sys, os, tempfile
sys.path.insert(0, r'E:\Work\OPEN CODE AFTER CODEX LIMIT 05072026\PsHelpScreenTool_v46_20_xlsm_support')
import openpyxl
wb = openpyxl.Workbook()
ws = wb.active
ws.title = 'Game Rules'
ws['B3'] = 'GAME RULES'
ws['B3'].font = openpyxl.styles.Font(bold=True, size=16)
ws['B5'] = 'All wins begin on adjacent reels from left to right.'
ws['B6'] = '<Wild> substitutes for all symbols except <Scatter>.'
ws['B7'] = 'Malfunction voids all pays and plays.'
ws['B8'] = 'See terms and conditions for full details.'
tmp = tempfile.NamedTemporaryFile(suffix='.xlsx', delete=False)
wb.save(tmp.name)
print(f'Excel: {tmp.name}')

from ps_autotypesetter.build_engine_psapi import execute_build_psapi
result = execute_build_psapi(excel_path=tmp.name, icon_folder=r'ps_autotypesetter',
    bg_path='', c_width=800, c_height=600, max_col_limit=18,
    h_font='Arial', h_size=36, h_icon_h=20, h_rgb=(255,200,50),
    b_font='Arial', b_size=14, b_icon_h=14, b_rgb=(0,0,0),
    margin_x=60, line_spacing=4, para_spacing=10, gap_px=2, icon_y_offset=0)
path = result['path']; sz = result['size']
print(f'Saved: {path} ({sz} bytes)')
os.unlink(tmp.name)
