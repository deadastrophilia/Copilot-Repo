"""Card / plate / tab boxes behind paytable slots — one drawing path for all.

A slot mapping with a "shape" dict gets a box behind its content:

    {"radius": 12 | "pill", "fill": "#3D0000", "fill_opacity": 100,
     "stroke": {"enabled": true, "width": 4, "color": "#E8B400", "align": "inside"},
     "fx": "<layer style name in the library>"}

PNG output and the web preview draw it with psd_writer.shapes.render (+ the
layer style through ps_fx_png); a PSD build records it as a live Photoshop
rounded rectangle (finalize turns the layer into a vector shape and attaches
the style), so artists can still resize it, change its corners, colour,
border and style in Photoshop. Slots without "shape" keep the old fill/stroke
drawing untouched.
"""


def spec_for(shape, x, y, w, h):
    """shapes.py spec for a box at (x, y, w, h), or None when it draws nothing."""
    if not isinstance(shape, dict):
        return None
    stroke = dict(shape.get("stroke") or {})
    has_stroke = bool(stroke.get("enabled")) and float(stroke.get("width") or 0) > 0
    fill = shape.get("fill")
    if fill in ("", None) and not has_stroke and not shape.get("fx"):
        return None
    if not has_stroke:
        stroke = {"enabled": False}
    spec = {"left": float(x), "top": float(y), "width": max(1.0, float(w)), "height": max(1.0, float(h)),
            "radius": shape.get("radius", 0), "fill": fill if fill not in ("", None) else None,
            # no fill: nothing for the Fill % to fade — at 0 it would hide the border too (Photoshop's layer
            # Fill hides the vector stroke), where the preview shows it
            "fill_opacity": 100.0 if fill in ("", None) else float(shape.get("fill_opacity", 100) if shape.get("fill_opacity") is not None else 100),
            "stroke": stroke}
    if isinstance(shape.get("radii"), (list, tuple)) and len(shape["radii"]) == 4:
        spec["radii"] = [float(v) for v in shape["radii"]]        # each corner its own (tl, tr, br, bl)
    if isinstance(shape.get("corners"), (list, tuple)) and len(shape["corners"]) == 4:
        spec["corners"] = [str(v) for v in shape["corners"]]      # round / cut / notch / step, each corner
    elif shape.get("corner"):
        spec["corner"] = str(shape["corner"])
    if shape.get("fill_to") and fill not in ("", None) and shape.get("gradient_dir") != "none":
        spec["fill_to"] = str(shape["fill_to"])
        spec["gradient_dir"] = str(shape.get("gradient_dir") or "vertical")
    return spec


def style_for(shape, settings):
    """The layer-style config named by shape["fx"] (from the library), or None."""
    name = (shape or {}).get("fx") if isinstance(shape, dict) else None
    if isinstance(name, dict):
        return name
    if not name:
        return None
    lib = (settings or {}).get("layer_style_library") or {}
    style = lib.get(name)
    return style if isinstance(style, dict) else None


_NAMES = {"title": "Title plate", "wildbox": "WILD box", "wildbox.tab": "WILD tab", "scatbox": "SCATTER box",
          "scatbox.tab": "SCATTER tab", "scatbox.label": "SCATTER label box", "wildbox.text": "WILD text box",
          "grseparator": "Game Rules separator"}


def layer_name(label):
    """'pic1.card' -> 'pic1 card', 'wildbox.tab' -> 'WILD tab': what artists see in the Layers panel."""
    label = str(label or "box")
    if label in _NAMES:
        return _NAMES[label]
    if label.endswith(".card"):
        return label[:-len(".card")] + " card"
    return label + " box"


def _composite(base, img, left, top):
    """alpha_composite that tolerates boxes partly off the image."""
    l, t = int(left), int(top)
    x0, y0 = max(0, -l), max(0, -t)
    x1, y1 = min(img.width, base.width - l), min(img.height, base.height - t)
    if x1 <= x0 or y1 <= y0:
        return
    base.alpha_composite(img.crop((x0, y0, x1, y1)), (l + x0, t + y0))


def draw(base, mapping, x, y, w, h, settings=None, label="box", group=None, name=None):
    """Draw the mapping's box. True when the mapping has a shape (drawn or empty). `name`: its PSD
    layer's name (else one made from `label`)."""
    shape = (mapping or {}).get("shape")
    if not isinstance(shape, dict):
        return False
    spec = spec_for(shape, x, y, w, h)
    if spec is None:
        return True
    from .psd_writer import recorder, shapes

    style = style_for(shape, settings)
    # the box's fill % is the layer's Fill opacity, exactly as on a Photoshop shape layer: it fades
    # the box's own colour and border but never its layer style (colour overlay, satin, strokes…
    # stay at full strength). Drawing the shape solid and handing the % to the style keeps the
    # preview / PNG identical to what Photoshop shows for the PSD.
    fill = _fill01(spec.get("fill_opacity")) * _fill01((style or {}).get("fill_opacity"))
    img, left, top = shapes.render(dict(spec, fill_opacity=100))
    page = recorder.page_for(base)
    styled = _styled(img, spec, style, fill) if style else None
    if page is not None:
        block = (style or {}).get("effects_block") if isinstance((style or {}).get("effects_block"), dict) else None
        rec = recorder.ImageRecord(img, left, top, name or layer_name(label), group=group, effects=block)
        rec.vector = spec
        rec.fill = fill
        rec.fx_config = style if (style and not block) else None
        # how it looks with its style: what the text above it is blended onto, and the PSD's merged image
        rec.preview = (styled[0], left - styled[1], top - styled[1]) if styled else None
        page.shapes.append(rec)
        return True
    if styled is not None:
        _composite(base, styled[0], left - styled[1], top - styled[1])
        return True
    if fill < 1.0:
        img = img.copy()
        img.putalpha(img.getchannel("A").point(lambda a: int(round(a * fill))))
    _composite(base, img, left, top)
    return True


_STYLED = {}


def _styled(img, spec, style, fill):
    """(styled image, pad) for the box with its layer style; same-sized boxes are worked out once."""
    import json

    try:
        key = json.dumps([spec.get("width"), spec.get("height"), spec.get("left") % 1, spec.get("top") % 1,
                          spec.get("radius"), spec.get("radii"), spec.get("corner"), spec.get("corners"), spec.get("fill"), spec.get("fill_to"), spec.get("gradient_dir"),
                          spec.get("stroke"), round(fill, 4), style],
                         sort_keys=True, default=str)
    except Exception:
        key = None
    if key is not None and key in _STYLED:
        return _STYLED[key]
    try:
        from .fx_descriptor import enrich_style
        from .ps_fx_png import render_layer_image

        out = render_layer_image(img, dict(enrich_style(style), fill_opacity=fill * 100.0))
    except Exception:
        out = None
    if out is not None and out[0] is None:
        out = None
    if key is not None:
        if len(_STYLED) > 64:
            _STYLED.clear()
        _STYLED[key] = out
    return out


def _fill01(value):
    try:
        return max(0.0, min(100.0, float(100 if value is None else value))) / 100.0
    except (TypeError, ValueError):
        return 1.0
