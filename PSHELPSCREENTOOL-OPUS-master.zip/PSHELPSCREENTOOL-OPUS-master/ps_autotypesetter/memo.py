"""Remember expensive read-only answers until their inputs change.

``Memo.get(key, compute)`` returns the remembered value for `key`, or runs
`compute()` once. Callers asking for the same key while it is being computed
wait for that one result instead of computing it again (on start-up the UI asks
for the same data several times at once, and every copy fought over the same
Python process). Keys must include everything the answer depends on, e.g.
a config hash plus ``file_stamp(excel_path)``.
"""
import copy
import os
import threading
from collections import OrderedDict


def file_stamp(path):
    """(path, size, mtime) of a file, or None: changes whenever the file is saved."""
    try:
        st = os.stat(str(path or ""))
    except (OSError, ValueError):
        return None
    return [os.path.normcase(os.path.abspath(str(path))), st.st_size, st.st_mtime_ns]


class Memo:
    def __init__(self, size=8):
        self._size = size
        self._values = OrderedDict()
        self._lock = threading.Lock()
        self._pending = {}                 # key -> Event while one caller computes it

    def get(self, key, compute):
        while True:
            with self._lock:
                if key in self._values:
                    self._values.move_to_end(key)
                    return copy.deepcopy(self._values[key])
                event = self._pending.get(key)
                if event is None:
                    event = self._pending[key] = threading.Event()
                    break                  # this caller computes
            event.wait()                   # another caller is computing: use its answer
            with self._lock:
                if key in self._values:
                    continue
            return compute()               # it failed: compute our own (and raise our own error)
        try:
            value = compute()
            with self._lock:
                self._values[key] = copy.deepcopy(value)
                while len(self._values) > self._size:
                    self._values.popitem(last=False)
            return value
        finally:
            with self._lock:
                self._pending.pop(key, None)
            event.set()

    def clear(self):
        with self._lock:
            self._values.clear()
