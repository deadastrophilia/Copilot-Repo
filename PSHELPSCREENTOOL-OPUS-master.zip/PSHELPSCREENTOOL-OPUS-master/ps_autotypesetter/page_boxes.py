"""Where a page's text sits, set by hand on the Canvas: the paragraph's box, the gaps around rows made
headings, and text split off into boxes of its own.

Stored in the session's ``dynamic_settings`` (page px, per sheet)::

    "body_boxes": {"<sheet>": {"left": 300, "right": 1620,     # the paragraph's sides
                               "top": 360,                     # where it starts on page 1 (optional)
                               "bottom": 980,                  # where it moves on to a Continued page
                               "cont": {"left": 300, "top": 260, ...}}},   # its Continued pages' own margins
    "row_gaps":   {"<sheet>": {"row:12": {"above": 40, "below": 40},     # a row made a heading
                               "row:15": {"line": 24,                  # line height: the gap above each line
                                          "lines": {"2": 60}}}},       # ... or above its 2nd drawn line only
    "text_boxes": {"<sheet>": [{"id": "b1", "parts": [{"row": 12, "text": "words split off"}],
                                "page": 0, "x": 300, "y": 600, "w": 600, "h": 120,
                                "font": "", "size": 0, "rgb": "", "bold": False, "italic": False,
                                "align": "", "tracking": 0, "style": "",
                                "line": 24}]}                  # its line height (optional: the paragraph's)
    "page_breaks": {"<sheet>": ["row:12"]}                    # these rows start a new (Continued) page
    "heading_plate": {"on": True, "color": "#1e3a8a", "opacity": 0.85,       # a plate behind every page's
                      "pad_x": 40, "pad_y": 12, "radius": 12, "border": {...}, "fx": ""}   # heading, fit to it
    "heading_plates": {"<sheet>": {...the same, its own (or "on": False)}}
    "hidden_parts": {"<sheet>": ["heading_main",              # the page heading on its first page,
                                 "heading_cont",              # ... on its Continued pages ("heading": both),
                                 "continued"]}                # "(Continued)" — deleted on
                                                              # that page (the text moves up into its place)

A text box keeps its words linked to their Excel row: they are taken out of the row (the rest closes
up) and drawn in the box. When the row no longer holds those words (a new AGR changed them), the box
is not drawn and the row keeps all its text. The canonical layout (layout_engine — the Canvas preview
and the PNG / PSD builds of text pages) reads everything here, so preview and build can't disagree.
"""
import re
import threading

_LOCK = threading.Lock()
_STATE = {"body": {}, "gaps": {}, "boxes": {}, "hidden": {}, "breaks": {}, "plate": None, "plates": {}}
HIDEABLE = ("heading", "heading_main", "heading_cont", "continued")   # "heading": on every page


def _num(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def set_all(dynamic_settings):
    """Use these settings from now on (the server and every build call this, like row_roles)."""
    ds = dynamic_settings if isinstance(dynamic_settings, dict) else {}
    body, gaps, boxes = {}, {}, {}
    for sheet, b in (ds.get("body_boxes") or {}).items() if isinstance(ds.get("body_boxes"), dict) else ():
        if isinstance(b, dict):
            clean = {k: _num(b.get(k)) for k in ("left", "right", "top", "bottom") if _num(b.get(k)) is not None}
            cont = b.get("cont") if isinstance(b.get("cont"), dict) else {}
            cont = {k: _num(cont.get(k)) for k in ("left", "right", "top", "bottom") if _num(cont.get(k)) is not None}
            if cont:
                clean["cont"] = cont
            if clean:
                body[str(sheet)] = clean
    for sheet, rows in (ds.get("row_gaps") or {}).items() if isinstance(ds.get("row_gaps"), dict) else ():
        if isinstance(rows, dict):
            clean = {}
            for k, v in rows.items():
                if not isinstance(v, dict):
                    continue
                g = {s: max(0.0, _num(v.get(s))) for s in ("above", "below", "line") if _num(v.get(s)) is not None}
                lines = {str(n): max(0.0, _num(px)) for n, px in (v.get("lines") or {}).items()
                         if str(n).isdigit() and _num(px) is not None} if isinstance(v.get("lines"), dict) else {}
                if lines:
                    g["lines"] = lines
                clean[str(k)] = g
            gaps[str(sheet)] = clean
    for sheet, items in (ds.get("text_boxes") or {}).items() if isinstance(ds.get("text_boxes"), dict) else ():
        good = []
        for b in items if isinstance(items, list) else ():
            parts = [{"row": int(p["row"]), "text": str(p.get("text") or "")}
                     for p in (b.get("parts") or []) if isinstance(p, dict) and str(p.get("row", "")).isdigit()
                     and str(p.get("text") or "").strip()] if isinstance(b, dict) else []
            if parts and all(_num(b.get(k)) is not None for k in ("x", "y", "w")):
                good.append(dict(b, parts=parts))
        if good:
            boxes[str(sheet)] = good
    hidden = {}
    for sheet, parts in (ds.get("hidden_parts") or {}).items() if isinstance(ds.get("hidden_parts"), dict) else ():
        keep = {str(p).lower() for p in (parts if isinstance(parts, (list, tuple)) else ()) if str(p).lower() in HIDEABLE}
        if keep:
            hidden[str(sheet)] = keep
    breaks = {}
    for sheet, keys in (ds.get("page_breaks") or {}).items() if isinstance(ds.get("page_breaks"), dict) else ():
        keep = {_key(k) for k in (keys if isinstance(keys, (list, tuple)) else ()) if re.fullmatch(r"row:\d+", str(k))}
        if keep:
            breaks[str(sheet)] = keep
    plate = dict(ds["heading_plate"]) if isinstance(ds.get("heading_plate"), dict) else None
    plates = {str(sh): dict(p) for sh, p in (ds.get("heading_plates") or {}).items()
              if isinstance(p, dict)} if isinstance(ds.get("heading_plates"), dict) else {}
    with _LOCK:
        _STATE.update(body=body, gaps=gaps, boxes=boxes, hidden=hidden, breaks=breaks, plate=plate, plates=plates)


def hidden(sheet):
    """What was deleted from this sheet's pages: "heading_main" / "heading_cont" (the heading on its first /
    its Continued pages; "heading" = both), "continued"."""
    return set(_STATE["hidden"].get(str(sheet)) or ())


def body_box(sheet):
    """{left, right, top, bottom} the artist set for this sheet's paragraph (any may be missing)."""
    b = dict(_STATE["body"].get(str(sheet)) or {})
    b.pop("cont", None)
    return b


def heading_plate(sheet):
    """The plate behind this sheet's heading — a strip rule fit to the heading (text_styles.strip_geometry,
    full_width False): this page's own when it has one, else every heading's; None when off."""
    own = _STATE["plates"].get(str(sheet))
    rule = own if own is not None else _STATE["plate"]
    if not rule or not rule.get("on"):
        return None
    out = {"color": "#1e3a8a", "opacity": 0.85, "pad_x": 40, "pad_y": 12, "radius": 12}
    out.update({k: v for k, v in rule.items() if k != "on" and v is not None})
    out["full_width"] = False
    return out


def cont_box(sheet):
    """{left, right, top, bottom} of this sheet's Continued pages, where the artist set them (else {})."""
    return dict((_STATE["body"].get(str(sheet)) or {}).get("cont") or {})


def page_break(sheet, row_idx):
    """True when the artist sent this row to a new (Continued) page."""
    return _key(row_idx) in (_STATE["breaks"].get(str(sheet)) or ())


def _key(row):
    return row if isinstance(row, str) else f"row:{int(row)}"      # a row number, or a text box's "box:<id>"


def row_gaps(sheet, row_idx, default):
    """(above, below) px around a row made a heading: the artist's, else `default` (the page
    heading's gap to its text)."""
    g = (_STATE["gaps"].get(str(sheet)) or {}).get(_key(row_idx)) or {}
    return float(g.get("above", default)), float(g.get("below", default))


def line_gap(sheet, row_idx, line_no):
    """(just this line's, the row's) line height the artist set above drawn line `line_no` (1-based)
    of this row — each None when not set (the paragraph's own)."""
    g = (_STATE["gaps"].get(str(sheet)) or {}).get(_key(row_idx)) or {}
    one = (g.get("lines") or {}).get(str(int(line_no)))
    return (float(one) if one is not None else None), (float(g["line"]) if "line" in g else None)


def text_boxes(sheet):
    return [dict(b) for b in _STATE["boxes"].get(str(sheet)) or []]


# ── the words of a box inside their row ─────────────────────────────────────
def _word_pattern(word):
    out = []
    for piece in re.split(r"(<[^<>]+>)", word):
        if piece.startswith("<") and piece.endswith(">"):
            name = re.sub(r"(?:~\d+(?:\.\d+)?)?(?:\^[\d.]+,[\d.]+)?\s*$", "", piece[1:-1])
            out.append("<" + re.escape(name) + r"(?:~\d+(?:\.\d+)?\s*)?(?:\^[\d.]+,[\d.]+\s*)?>")
        elif piece:
            out.append(re.escape(piece))
    return "".join(out)


def find(row_text, part):
    """(start, end) of `part` in `row_text`, spaces and line breaks counting as one gap and an icon's
    size tag (<WILD~140>) matching its plain token; None when the row doesn't hold it."""
    words = str(part or "").split()
    if not words:
        return None
    m = re.search(r"\s+".join(_word_pattern(w) for w in words), str(row_text or ""))
    return (m.start(), m.end()) if m else None


def take_out(row_text, spans):
    """The row's text without these (start, end) spans; the gap they leave closes up."""
    text = str(row_text or "")
    for a, b in sorted(spans, reverse=True):
        text = text[:a] + " " + text[b:]
    text = re.sub(r"[ \t]{2,}", " ", text)
    text = re.sub(r"[ \t]+\n", "\n", text)
    text = re.sub(r"\n[ \t]+", "\n", text)
    return text.strip()
