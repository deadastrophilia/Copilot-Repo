import os
import datetime
import re
import math
import json
import hashlib
import photoshop.api as ps
from openpyxl import load_workbook
from openpyxl.utils import column_index_from_string, get_column_letter, range_boundaries

from .config import TABLE_DEFAULTS
from .excel_utils import get_excel_color
from .photoshop_utils import collapse_all_layer_groups, set_layer_color
from .table_detector import detect_tables_in_sheet, manual_tables_from_ranges
from .table_mapping import (
    load_mapped_table_templates,
    mapped_record_consumed_rows,
    source_row_range_for_template,
    strip_table_markers,
    table_template_for_excel_table,
    table_templates_for_marker,
    template_matches_sheet,
    trigger_row_for_template,
    direct_range_bounds,
)
from .table_renderer import (
    _grid_table_metrics,
    draw_mapped_table_to_psd,
    draw_table_to_psd,
    estimate_mapped_table_height,
    estimate_table_height,
)
from .text_icon_renderer import _measure_text_cached, _measure_line_height_pil, _px_to_pt, premeasure_texts_batch, _render_text_with_keyword_overlays, flush_text_spec_batch
from .background import apply_background
from .build_profiler import BuildProfiler, GLOBAL as _PROFILER, timed as _timed
from .diff_engine import compare_workbooks
from .photoshop_fonts import resolve_photoshop_font
from .layer_styles import apply_style_to_group_text_layers, apply_dual_style_to_group, apply_group_styles_batched
from .dynamic_pages import should_handle_sheet, render_dynamic_sheet
from .icon_mapping import get_icon_size_override, resolve_icon_path, scan_excel_icon_tokens
from .project_manifest import load_manifest, save_manifest, compare_excel_to_manifest, manifest_path_for_psd


class BuildCancelled(Exception):
    """Raised internally when the user requests a build stop."""


if os.environ.get("PSH_DEBUG_REFLOW"):
    print("[Engine] GAME-RULES REFLOW v4 ACTIVE (measure-union-per-row + cross-paragraph push + Row spacing)", flush=True)


_MEGA_STATE = {}


def _mega_mode_active():
    return os.environ.get("PSH_MEGA_BATCH", "1") != "0"


def _mega_state_for(doc):
    return _MEGA_STATE.setdefault(id(doc), {"batch": [], "styles": []})


def _mega_pending_batch(app, doc, keyword_colors=None):
    """Shared pending text-spec batch for mega mode (one flush per sheet).

    Returns None when mega mode is off or keyword-colored rendering is active
    (those lines always go through the per-layer path, unchanged).
    """
    if isinstance(keyword_colors, dict) and keyword_colors:
        return None
    if not _mega_mode_active():
        return None
    return _mega_state_for(doc)["batch"]


def _mega_record_style(app, doc, layer_group, body_style, icon_style, text_only=False):
    """Defer a group style apply to the sheet-end mega flush."""
    try:
        group_id = int(layer_group.id)
    except Exception:
        group_id = None
    _mega_state_for(doc)["styles"].append({
        "group_id": group_id,
        "layer_group": layer_group,
        "body": body_style,
        "icon": icon_style,
        "text_only": bool(text_only),
    })


def _mega_sheet_finish(app, doc):
    """Flush all deferred text specs and apply all deferred styles for a sheet.

    Specs carry their target group ids, so layers are created inside the
    correct groups even when pages were added mid-render. Safe to call with an
    empty state (no-op), so it can run after every page and sheet render.
    """
    state = _MEGA_STATE.pop(id(doc), None)
    if not state:
        return
    if state.get("batch"):
        _PROFILER.inc("mega_batch_specs", len(state["batch"]))
        flush_text_spec_batch(state["batch"], app, doc)
    styles = [r for r in state.get("styles", []) if r.get("group_id") is not None]
    if styles:
        _PROFILER.inc("mega_style_requests", len(styles))
        apply_group_styles_batched(app, doc, styles)
    for r in state.get("styles", []):
        if r.get("group_id") is not None:
            continue
        try:
            if r.get("text_only"):
                apply_style_to_group_text_layers(app, doc, r["layer_group"], r["body"] or r["icon"], text_only=True)
            else:
                apply_dual_style_to_group(app, doc, r["layer_group"], r["body"], r["icon"])
        except Exception as e:
            print(f"[Mega] Orphan style fallback failed: {e}")


def _build_style_signature(**style_kwargs):
    """Stable hash of all style-relevant settings.

    The incremental diff only compares Excel content. Without this signature,
    changing typography (heading/body size, fonts, colors, spacing, margins,
    background, icon heights, etc.) in the UI would leave every sheet marked
    'unchanged' and the old layers would be kept. Any signature change must
    force a full rebuild.
    """
    def _freeze(value):
        if isinstance(value, dict):
            return {str(k): _freeze(v) for k, v in sorted(value.items(), key=lambda kv: str(kv[0]))}
        if isinstance(value, (list, tuple)):
            return [_freeze(v) for v in value]
        if isinstance(value, (str, int, float, bool)) or value is None:
            return value
        return str(value)

    frozen = {k: _freeze(v) for k, v in sorted(style_kwargs.items())}
    return hashlib.sha256(
        json.dumps(frozen, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()


def _bounds_to_floats(bounds):
    try:
        return [float(bounds[i]) for i in range(4)]
    except Exception:
        return None

def _collect_group_bounds(layer_group):
    """Return [left, top, right, bottom] for all visible layers inside a Photoshop group."""
    boxes = []
    try:
        for lyr in list(layer_group.artLayers):
            try:
                b = _bounds_to_floats(lyr.bounds)
                if b and (b[2] - b[0]) > 0 and (b[3] - b[1]) > 0:
                    boxes.append(b)
            except Exception:
                pass
        for subgroup in list(layer_group.layerSets):
            b = _collect_group_bounds(subgroup)
            if b:
                boxes.append(b)
    except Exception:
        pass
    if not boxes:
        return None
    return [min(b[0] for b in boxes), min(b[1] for b in boxes), max(b[2] for b in boxes), max(b[3] for b in boxes)]


_EXCEL_MARKER_CELL_RE = re.compile(
    r"^(?:mod(?:ified|ify)?|update?d?|del(?:et?e)?d?|add(?:ed)?|remov(?:e|ed)|edit(?:ed)?|fix(?:ed)?)(?![a-z])",
    re.I,
)


def _is_excel_marker_cell(value):
    """Workflow-annotation cells that must never render.

    Exact marker words (with or without <>), plus unclosed "<" annotations
    such as "<mod 3/10", "< Update" or "<del 1/4" (no closing '>'), which are
    editor notes, not content.
    """
    raw = str(value or "").strip()
    if not raw:
        return False
    low = raw.casefold()
    if low.rstrip(">") in {"<<modified", "<modified", "<removed", "<added", "<deleted"} or \
       low in {"modified", "removed", "added", "deleted"}:
        return True
    if raw.startswith("<") and ">" not in raw:
        return bool(_EXCEL_MARKER_CELL_RE.match(raw[1:].lstrip()))
    return False

def _baseline_from_top(top_y, font_size):
    # Photoshop textItem.position is baseline, not visual top. This gives a stable user-facing gap.
    return top_y + font_size


_JSX_GROUP_BOUNDS_FN = r"""
    function __grpById(id) {
        var stack = [doc];
        while (stack.length) {
            var node = stack.pop();
            if (node.id == id) return node;
            var sets = node.layerSets;
            for (var i = 0; i < sets.length; i++) stack.push(sets[i]);
        }
        return null;
    }
    function __grpBounds(grp) {
        var boxes = [];
        var i, j, b, l, t, r, bb;
        for (i = 0; i < grp.artLayers.length; i++) {
            try {
                b = grp.artLayers[i].bounds;
                l = b[0].value; t = b[1].value; r = b[2].value; bb = b[3].value;
                if ((r - l) > 0 && (bb - t) > 0) boxes.push([l, t, r, bb]);
            } catch (e) {}
        }
        for (i = 0; i < grp.layerSets.length; i++) {
            try {
                var sub = __grpBounds(grp.layerSets[i]);
                if (sub) boxes.push(sub);
            } catch (e) {}
        }
        if (!boxes.length) return null;
        l = boxes[0][0]; t = boxes[0][1]; r = boxes[0][2]; bb = boxes[0][3];
        for (j = 1; j < boxes.length; j++) {
            l = Math.min(l, boxes[j][0]); t = Math.min(t, boxes[j][1]);
            r = Math.max(r, boxes[j][2]); bb = Math.max(bb, boxes[j][3]);
        }
        return [l, t, r, bb];
    }
"""


def _jsx_measure_groups(app, doc, ids):
    """Return {id: [l, t, r, b]} union bounds for every group id in ONE JSX call.

    Mirrors the COM _collect_group_bounds semantics: only nonzero-size boxes
    contribute; hidden layers are still measured. Returns None on failure."""
    if not ids:
        return {}
    id_list = ",".join(str(int(i)) for i in ids)
    jsx = f"""
    (function() {{
        var doc = app.activeDocument;
        var ids = [{id_list}];
        var parts = [];
        {_JSX_GROUP_BOUNDS_FN}
        for (var k = 0; k < ids.length; k++) {{
            try {{
                var g = __grpById(ids[k]);
                var b = g ? __grpBounds(g) : null;
                parts.push(ids[k] + "=" + (b ? b.join(",") : "null"));
            }} catch (e) {{
                parts.push(ids[k] + "=null");
            }}
        }}
        return parts.join(";");
    }})();
    """
    try:
        raw = str(app.doJavaScript(jsx))
    except Exception:
        return None
    result = {}
    try:
        for chunk in raw.split(";"):
            if "=" not in chunk:
                continue
            key, value = chunk.split("=", 1)
            if value == "null":
                continue
            vals = [float(v) for v in value.split(",")]
            if len(vals) == 4:
                result[int(key)] = vals
    except Exception:
        return None
    return result


def _jsx_translate_groups(app, doc, moves):
    """Translate groups by (dx, dy) in ONE JSX call. moves: [(gid, dx, dy)]."""
    if not moves:
        return True
    move_list = ",".join(f"[{int(g)}, {float(dx)}, {float(dy)}]" for g, dx, dy in moves)
    jsx = f"""
    (function() {{
        var doc = app.activeDocument;
        var moves = [{move_list}];
        var errors = 0;
        {_JSX_GROUP_BOUNDS_FN}
        for (var k = 0; k < moves.length; k++) {{
            try {{
                var g = __grpById(moves[k][0]);
                if (!g) {{ errors++; continue; }}
                g.translate(moves[k][1], moves[k][2]);
            }} catch (e) {{ errors++; }}
        }}
        return errors;
    }})();
    """
    try:
        result = app.doJavaScript(jsx)
        return str(result) == "0"
    except Exception:
        return False


def _jsx_align_line_groups(app, doc, specs):
    """Horizontally center/align line groups by measured bounds in ONE JSX call.

    specs: [(gid, alignment, box_left, box_width)]. Mirrors
    _align_group_horizontally (same box math, same |dx| > 0.5 threshold,
    group-level translate). Returns {gid: [l, t, r, b]} with the measured
    bounds (same values as COM) on success, or None on failure."""
    if not specs:
        return {}
    spec_list = ",".join(
        f"[{int(g)}, {json.dumps(_normalize_alignment(a))}, {float(bl or 0)}, {max(1.0, float(bw or 1))}]"
        for g, a, bl, bw in specs
    )
    jsx = f"""
    (function() {{
        var doc = app.activeDocument;
        var specs = [{spec_list}];
        var errors = 0;
        var parts = [];
        {_JSX_GROUP_BOUNDS_FN}
        for (var k = 0; k < specs.length; k++) {{
            try {{
                var g = __grpById(specs[k][0]);
                if (!g) {{ errors++; continue; }}
                var b = __grpBounds(g);
                if (!b) {{ errors++; continue; }}
                parts.push(specs[k][0] + "=" + b.join(","));
                var gw = b[2] - b[0];
                var boxL = specs[k][2];
                var boxW = specs[k][3];
                var align = specs[k][1];
                var desiredLeft;
                if (align == "left") desiredLeft = boxL;
                else if (align == "right") desiredLeft = boxL + boxW - gw;
                else desiredLeft = boxL + (boxW - gw) / 2.0;
                var dx = desiredLeft - b[0];
                if (Math.abs(dx) > 0.5) g.translate(dx, 0);
            }} catch (e) {{ errors++; }}
        }}
        return "E" + errors + ";" + parts.join(";");
    }})();
    """
    try:
        raw = str(app.doJavaScript(jsx))
    except Exception:
        return None
    result = {}
    try:
        if not raw.startswith("E"):
            return None
        _, _, body = raw.partition(";")
        errors = int(raw[1:].split(";", 1)[0])
        if errors > 0:
            return None
        for chunk in body.split(";"):
            if "=" not in chunk:
                continue
            key, value = chunk.split("=", 1)
            vals = [float(v) for v in value.split(",")]
            if len(vals) == 4:
                result[int(key)] = vals
    except Exception:
        return None
    return result


def _batched_block_layout(app, doc, target_group, line_groups, prev_visual_bottom, current_y, margin_px, debug_tag,
                          premeasured=None):
    """One-shot batched vertical layout for a rendered block: reflow + push via JSX.

    Callers run _jsx_align_line_groups BEFORE applying styles (mirroring the COM
    flow where alignment happens pre-style), then apply styles, then call this.
    premeasured (optional) is the {gid: [l, t, r, b]} dict already returned by
    _jsx_align_line_groups, so the line groups are NOT measured a second time;
    only the target group (and siblings, when prev_visual_bottom is None) get a
    fresh JSX measure. The math mirrors _reflow_rows_by_measured_bounds and
    _push_block_below_previous / _previous_visual_bottom_above exactly, so the
    final positions are identical to the COM flow. Returns the new current_y on
    success, or None when any step failed (caller falls back to COM)."""
    if not line_groups:
        return None
    try:
        margin = max(0, int(round(float(margin_px if margin_px is not None else 0))))
    except Exception:
        margin = 0
    try:
        ids = [int(g.id) for g, _align, _bl, _bw in line_groups]
        target_id = int(target_group.id)
    except Exception:
        return None
    bounds = dict(premeasured or {})
    siblings = []
    if prev_visual_bottom is None:
        try:
            parent = target_group.parent
            siblings = [int(s.id) for s in list(parent.layerSets)]
        except Exception:
            siblings = []
    missing = [gid for gid in ids if gid not in bounds]
    to_measure = missing + [target_id] + siblings
    if to_measure:
        extra = _jsx_measure_groups(app, doc, to_measure)
        if extra is None:
            return None
        bounds.update(extra)
    moves = []
    cursor_top = None
    prev_bottom = None
    for gid in ids:
        b = bounds.get(gid)
        if not b:
            continue
        top_y = float(b[1])
        bottom_y = float(b[3])
        if top_y >= bottom_y:
            continue
        if cursor_top is None:
            cursor_top = top_y
            prev_bottom = bottom_y
        else:
            need_top = prev_bottom + margin
            if abs(top_y - need_top) > 0.01:
                delta = need_top - top_y
                moves.append((gid, 0.0, delta))
                top_y += delta
                bottom_y += delta
            prev_bottom = bottom_y
    block_b = bounds.get(target_id)
    if block_b:
        block_top = float(block_b[1])
        block_bottom = float(block_b[3])
        if prev_bottom is not None:
            block_bottom = float(prev_bottom)
        if prev_visual_bottom is None:
            best = None
            for sid in siblings:
                if sid == target_id:
                    continue
                sb = bounds.get(sid)
                if not sb:
                    continue
                bottom = float(sb[3])
                if bottom >= block_bottom - 0.5:
                    continue
                if best is None or bottom > best:
                    best = bottom
            prev_visual_bottom = best
        if prev_visual_bottom is not None:
            need_top = float(prev_visual_bottom) + margin
            if block_top < need_top - 0.01:
                delta = need_top - block_top
                moves.append((target_id, 0.0, delta))
                current_y = float(current_y) + delta
    if moves and not _jsx_translate_groups(app, doc, moves):
        return None
    if prev_bottom is not None:
        current_y = max(float(current_y), float(prev_bottom))
    if os.environ.get("PSH_DEBUG_REFLOW"):
        print(f"[Reflow:{debug_tag}] batched: lines={len(ids)} margin={margin} final_y={current_y:.1f}", flush=True)
    return current_y


def _is_game_rules_sheet_name(name):
    normalized = re.sub(r"[^a-z0-9]+", "", str(name or "").casefold())
    return normalized.startswith("gamerules")


def _is_bingo_rules_sheet_name(name):
    normalized = re.sub(r"[^a-z0-9]+", "", str(name or "").casefold())
    return normalized == "bingorules" or normalized.startswith("bingorules")


def _translate_group_items(layer_group, dx, dy=0):
    try:
        for lyr in list(layer_group.artLayers):
            try:
                lyr.translate(dx, dy)
            except Exception:
                pass
        for subgroup in list(layer_group.layerSets):
            _translate_group_items(subgroup, dx, dy)
    except Exception:
        pass


def _reflow_rows_by_measured_bounds(row_groups, row_gap_px):
    """Space per-row layer groups by their ACTUAL rendered bounds.

    rows are created top-down; every row lives in its own group. Old behaviour
    advanced an estimated row, and a large icon on a following row could
    still overlap the previous row because real glyph/icon bounds are taller
    than `font * 0.35`. Here each group is measured (text + icons combined) and
    positioned so the gap between consecutive group bottoms is EXACTLY
    `row_gap_px` - it is snapped in both directions (down when too tight, up
    when too loose), so the web-UI "Row spacing" value is applied after every
    row's bounding box, never just once. The actual bottom is handed back.

    Returns (next_top_y, bottom_y) or None if measurement is unavailable.
    """
    if row_gap_px is None:
        row_gap_px = 0
    try:
        row_gap_px = max(0, int(round(float(row_gap_px))))
    except Exception:
        row_gap_px = 0
    cursor_top = None
    prev_bottom = None
    measured_rows = 0
    row_debug = []
    for group in row_groups:
        try:
            bounds = _collect_group_bounds(group)
            if not bounds:
                continue
            top_y = float(bounds[1])
            bottom_y = float(bounds[3])
        except Exception:
            continue
        if top_y >= bottom_y:
            continue
        measured_rows += 1
        delta = 0.0
        if cursor_top is None:
            cursor_top = top_y
            prev_bottom = bottom_y
        else:
            need_top = prev_bottom + row_gap_px
            if abs(top_y - need_top) > 0.01:
                delta = need_top - top_y
                _translate_group_items(group, 0, delta)
                top_y += delta
                bottom_y += delta
            prev_bottom = bottom_y
        if os.environ.get("PSH_DEBUG_REFLOW"):
            row_debug.append({"top": round(top_y, 1), "bottom": round(bottom_y, 1), "delta": round(delta, 1)})
    if prev_bottom is None:
        return None
    if os.environ.get("PSH_DEBUG_REFLOW"):
        print(f"[Reflow] rows={len(row_groups)} measured={measured_rows} gap={row_gap_px} bottom={prev_bottom} rows={row_debug}", flush=True)
    return cursor_top, prev_bottom


def _reflow_centered_rows(line_groups, margin_px=None):
    """Measured-bound reflow for per-row centered line groups.

    line_groups is a list of (group, align, box_left, box_width) tuples or of
    raw group objects. Each group is one rendered centered line; positions are
    vertically nudged so consecutive group boundaries never overlap, using the
    user-facing line-spacing value as the minimum gap.

    Returns the new bottom (current_y) of the row stack, or None when rows could
    not be measured (in which case the estimated baseline stays in effect).
    """
    rows = []
    for entry in line_groups:
        if isinstance(entry, (tuple, list)) and len(entry) >= 1:
            rows.append(entry[0])
        else:
            rows.append(entry)
    result = _reflow_rows_by_measured_bounds(rows, margin_px)
    if not result:
        return None
    return result[1]


def _previous_visual_bottom_above(target_group, block_top, block_bottom=None):
    """Measure the content that was laid out immediately above `target_group`.

    Used as a fallback when no explicit previous bottom is threaded through the
    callers: the sibling block whose bottom sits closest below the current block
    is the reference the cross-paragraph push must not collide with. The search is
    purely geometric, so it does not depend on Photoshop's layer-stack ordering.
    """
    best = None
    try:
        parent = target_group.parent
        siblings = list(parent.layerSets)
    except Exception:
        return None
    block_top = float(block_top)
    block_bottom = float(block_bottom) if block_bottom is not None else block_top
    for sib in siblings:
        if sib == target_group:
            continue
        try:
            b = _collect_group_bounds(sib)
        except Exception:
            continue
        if not b:
            continue
        bottom = float(b[3])
        if bottom >= block_bottom - 0.5:
            # The sibling's own span reaches AT or below the current block's span:
            # it is not content strictly above this block.
            continue
        if best is None or bottom > best:
            best = bottom
    return best


def _push_block_below_previous(target_group, prev_visual_bottom, current_y, margin_px=None, app=None, debug_tag="Block"):
    """Prevent a block's first row (big icon) from poking into the block above.

    Paragraphs are rendered one `_render...block` call at a time, and the per-block
    reflow only knows about ITS OWN rows. A following paragraph's first line can
    therefore rise into the previous paragraph's last line when its first icons are
    tall. Here the whole block group is measured and pushed down so its top clears
    `prev_visual_bottom + margin_px`; `current_y` (the baseline for the NEXT block)
    is bumped by the same amount. Returns the new current_y.

    When no explicit previous bottom is passed, the closest sibling above the block
    is measured and used instead, so the cross-paragraph guard fires for every block
    renderer even when callers do not thread the value.
    """
    try:
        margin = max(0, int(round(float(margin_px if margin_px is not None else 0))))
    except Exception:
        margin = 0
    try:
        bounds = _collect_group_bounds(target_group)
    except Exception:
        bounds = None
    if not bounds:
        return current_y
    block_top = float(bounds[1])
    block_bottom = float(bounds[3])
    if prev_visual_bottom is None:
        prev_visual_bottom = _previous_visual_bottom_above(target_group, block_top, block_bottom=block_bottom)
    if prev_visual_bottom is None:
        return current_y
    need_top = float(prev_visual_bottom) + margin
    if block_top < need_top - 0.01:
        delta = need_top - block_top
        _translate_group_items(target_group, 0, delta)
        current_y = float(current_y) + delta
        if os.environ.get("PSH_DEBUG_REFLOW"):
            print(f"[Reflow:{debug_tag}] block top {block_top} < prev-bot+gap {need_top:.1f}; pushed +{delta:.1f} -> current_y {current_y:.1f}", flush=True)
    return current_y


DEFAULT_ROW_GAP = 30

_PIL_INK_CACHE = {}
_PIL_INK_CACHE_MAX = 2048


def _pil_ink_extents(font_px, font_name, text="Agjyp"):
    """(ink_top, ink_bottom, ascent) of the REAL rendered ink for a font, from
    a PIL probe of the given text.

    ink_top / ink_bottom are offsets from the PIL text top; ascent is the font
    ascent (getmetrics). Row stacking uses these so the visual gap between
    consecutive rows equals the configured Row Gap px exactly, matching the
    PNG renderer's _line_ink_extents probe (the font box ascent+descent is
    taller than the ink, so box-based steps rendered larger visual gaps). The
    probe uses the line's ACTUAL text so descender-free lines (uppercase,
    digits) get the same ink the PNG renderer measures."""
    try:
        fpx = max(1, int(round(float(font_px))))
    except Exception:
        fpx = 24
    key = (fpx, str(font_name or ""), str(text or "Agjyp"))
    got = _PIL_INK_CACHE.get(key)
    if got is not None:
        return got
    result = (0.0, float(fpx + 2), float(fpx))
    try:
        from PIL import Image as _PI
        from PIL import ImageDraw as _PID
        from PIL import ImageFont as _PIF
        from .text_icon_renderer import _get_font_path
        fpath = _get_font_path(font_name) if font_name else None
        font = _PIF.truetype(fpath, fpx) if fpath else _PIF.load_default()
        probe = _PI.new("RGBA", (64, 160), (0, 0, 0, 0))
        _PID.Draw(probe).text((2, 2), str(text or "Agjyp"), font=font, fill=(255, 255, 255, 255))
        bbox = probe.getbbox()
        ascent = float(font.getmetrics()[0])
        if bbox:
            result = (float(bbox[1] - 2), float(bbox[3] - 2), ascent)
    except Exception:
        pass
    if len(_PIL_INK_CACHE) < _PIL_INK_CACHE_MAX:
        _PIL_INK_CACHE[key] = result
    return result


def _row_gap_step_px(font_px, font_name, text, icon_h, gap_px, next_text="", next_icon_h=0.0, icon_y_offset=0.0):
    """PSD baseline step for the UI 'Row spacing' (line_gap) contract.

    Returns the advance from the current line's baseline to the NEXT line's
    baseline so the VISUAL gap between consecutive rows equals `gap_px`
    exactly, measured between each row's FULL content bound — the union of
    the tallest icon box and the glyph ink (whatever is higher and whatever
    is lower). The gap is: prev_row_content_bottom -> gap -> next_row_content_top.

    A text-box-only step would read `gap_px - icon_overhang` (e.g. with a
    44px icon in 14px text and Row Gap 90 the visible gap would be ~75);
    this function counts the icon extremes on BOTH sides, mirroring the PNG
    renderer's _line_ink_extents stacking pixel-for-pixel.
    """
    try:
        fpx = max(1, int(round(float(font_px))))
    except Exception:
        fpx = 24
    spacing = float(gap_px if gap_px is not None else DEFAULT_ROW_GAP)
    if spacing != spacing or spacing < 0:
        spacing = 0.0
    _it, _ib, _ascent = _pil_ink_extents(fpx, font_name, text)
    _yoff = max(0.0, float(icon_y_offset))
    # Content bottom of THIS row, offset from its top (text ink vs icons).
    prev_bottom_off = _ib
    _max_icon_h = float(icon_h or 0)
    if _max_icon_h > 0:
        prev_bottom_off = max(prev_bottom_off, _ascent - float(fpx) * 0.35 + _max_icon_h / 2.0 + _yoff)
    # Content top of the NEXT row (icons rise above the text top when tall).
    _nit = _pil_ink_extents(fpx, font_name, next_text)[0]
    next_top_off = _nit
    _next_icon_h = float(next_icon_h or 0)
    if _next_icon_h > 0:
        next_top_off = min(next_top_off, _ascent - float(fpx) * 0.35 - _next_icon_h / 2.0 + _yoff)
    return max(int(math.ceil(prev_bottom_off + spacing - next_top_off)), 1)


def _effective_row_gap(raw_gap):
    """UI 'Row spacing' (line_gap) is the SINGLE row-gap source in the PSD and
    PNG renderers: a px gap between row content boxes. When the field is empty
    (or invalid) the PSD-compatible default of 30px applies; 0 = rows touch.
    """
    if raw_gap is None or raw_gap == "":
        return DEFAULT_ROW_GAP
    try:
        return max(0, int(round(float(raw_gap))))
    except Exception:
        return DEFAULT_ROW_GAP


def _line_gap_margin_px(font_size, line_spacing, line_step_override=None):
    """Convert the user's line-height controls to a px minimum gap between measured rows.

    Priority:
      1. A configured px line-height (e.g. `game_rules_line_height`, the desktop
         'Icon-safe line height' input) is used directly as the gap.
      2. The Typography 'Line spacing' value, which is either:
         - the Web UI multiplier (0.5-3): extra = font * (multiplier - 1); or
         - the desktop/preset px value (e.g. 19/25): used directly as the gap.

    A zero return only disables extra spacing; the measured reflow still prevents
    any visible overlap.
    """
    try:
        step = int(round(float(line_step_override))) if line_step_override else 0
        if step > 0:
            return step
    except Exception:
        pass
    try:
        raw = float(line_spacing)
    except Exception:
        return 0
    if 0.0 <= raw <= 3.0:
        try:
            font = max(0.0, float(font_size))
        except Exception:
            font = 0.0
        return int(round(font * max(0.0, raw - 1.0)))
    return max(0, int(round(raw)))


def _center_group_horizontally(layer_group, canvas_width):
    return _align_group_horizontally(layer_group, 0, canvas_width, "center")


def _align_group_horizontally(layer_group, box_left, box_width, alignment="center"):
    bounds = _collect_group_bounds(layer_group)
    if not bounds:
        return None
    group_width = bounds[2] - bounds[0]
    box_left = float(box_left or 0)
    box_width = max(1.0, float(box_width or 1))
    alignment = _normalize_alignment(alignment)
    if alignment == "left":
        desired_left = box_left
    elif alignment == "right":
        desired_left = box_left + box_width - group_width
    else:
        desired_left = box_left + (box_width - group_width) / 2.0
    dx = desired_left - bounds[0]
    if abs(dx) > 0.5:
        _translate_group_items(layer_group, dx, 0)
        bounds = _collect_group_bounds(layer_group) or bounds
    return bounds


def _normalize_alignment(value, fallback="center"):
    value = str(value or "").strip().lower()
    if value == "justify":
        # Point-text lines cannot truly justify without paragraph text. Use left
        # alignment as the safe visual fallback.
        return "left"
    if value in ("left", "center", "right"):
        return value
    return fallback


_EXCEL_RANGE_RE = re.compile(r"\b([A-Za-z]{1,4})(\d+)\s*(?::\s*([A-Za-z]{1,4})(\d+))?\b")
_EXCEL_CELL_RE = re.compile(r"^[A-Za-z]{1,4}\d+$")


def _ranges_from_text(value):
    ranges = []
    for match in _EXCEL_RANGE_RE.finditer(str(value or "")):
        start_col, start_row, end_col, end_row = match.groups()
        start = f"{start_col.upper()}{start_row}"
        end = f"{(end_col or start_col).upper()}{end_row or start_row}"
        ranges.append(start if start == end else f"{start}:{end}")
    return ranges


def _looks_like_scoped_range_entry_start(value, allow_cell_value=False):
    fragment = str(value or "").lstrip()
    if not fragment:
        return False
    if allow_cell_value and re.match(
        r"^[A-Za-z]{1,4}\d+\s*(?::\s*[A-Za-z]{1,4}\d+)?\s*=",
        fragment,
    ):
        return True
    for separator in ("=", "|", "!"):
        idx = fragment.find(separator)
        if idx > 0 and _ranges_from_text(fragment[idx + 1:]):
            return True
    for match in re.finditer(r":", fragment):
        left = fragment[:match.start()].strip()
        right = fragment[match.end():].lstrip()
        if not left or _EXCEL_CELL_RE.fullmatch(left):
            continue
        if "=" in left or "|" in left or "!" in left:
            continue
        if re.match(r"^[A-Za-z]{1,4}\d+\s*(?::\s*[A-Za-z]{1,4}\d+)?", right):
            return True
    return False


def _split_scoped_range_entries(value, strip_comment=False, allow_cell_value=False):
    entries = []
    for raw_line in str(value or "").splitlines():
        line = raw_line
        if strip_comment:
            line = line.split("#", 1)[0]
        line = line.strip()
        if not line:
            continue
        start = 0
        depth = 0
        for idx, char in enumerate(line):
            if char == "(":
                depth += 1
            elif char == ")" and depth > 0:
                depth -= 1
            elif char in ",;" and depth == 0:
                if _looks_like_scoped_range_entry_start(
                    line[idx + 1:],
                    allow_cell_value=allow_cell_value,
                ):
                    chunk = line[start:idx].strip()
                    if chunk:
                        entries.append(chunk)
                    start = idx + 1
        chunk = line[start:].strip()
        if chunk:
            entries.append(chunk)
    return entries


def _sheet_name_matches(left, sheet_name):
    left = str(left or "").strip().strip("'\"")
    if not left or left in ("*", "all", "ALL"):
        return True
    return left.casefold() == str(sheet_name or "").strip().casefold()


def _manual_table_ranges_for_sheet(raw_ranges, sheet_name):
    """Return user-entered manual table ranges that apply to this worksheet.

    Accepted forms:
      B10:C33
      Sheet Name: B10:C33; E10:F20
      Sheet Name = B10:C33
      Sheet Name | B10:C33
      Sheet Name!B10:C33
    """
    if isinstance(raw_ranges, dict):
        chunks = []
        for key, value in raw_ranges.items():
            if _sheet_name_matches(key, sheet_name):
                chunks.append(value)
        raw_ranges = "\n".join(str(chunk or "") for chunk in chunks)
    elif isinstance(raw_ranges, (list, tuple, set)):
        raw_ranges = "\n".join(str(chunk or "") for chunk in raw_ranges)

    selected = []
    seen = set()
    for line in _split_scoped_range_entries(raw_ranges, strip_comment=True):
        scope = ""
        body = line
        for separator in ("=", "|"):
            if separator in line:
                left, right = line.split(separator, 1)
                if _ranges_from_text(right):
                    scope, body = left.strip(), right.strip()
                    break
        else:
            if "!" in line:
                left, right = line.rsplit("!", 1)
                if _ranges_from_text(right):
                    scope, body = left.strip(), right.strip()
            if not scope:
                match = re.match(r"^(.+?)\s*:\s*(.+)$", line)
                if match:
                    left, right = match.group(1).strip(), match.group(2).strip()
                    if not _EXCEL_CELL_RE.fullmatch(left) and _ranges_from_text(right):
                        scope, body = left, right

        if scope and not _sheet_name_matches(scope, sheet_name):
            continue
        for range_ref in _ranges_from_text(body):
            key = range_ref.casefold()
            if key in seen:
                continue
            seen.add(key)
            selected.append(range_ref)
    return selected


def _parse_hex_rgb(value):
    match = re.search(r"#?([0-9A-Fa-f]{6})", str(value or ""))
    if not match:
        return None
    hex_value = match.group(1)
    return (
        int(hex_value[0:2], 16),
        int(hex_value[2:4], 16),
        int(hex_value[4:6], 16),
    )


def _table_excel_fill_hex_overrides_for_sheet(raw_value, sheet_name):
    """Return per-cell fallback fill colors for Excel-fill auto tables.

    Accepted forms:
      B13=#4F81BD
      B13:B15=#92D050
      Sheet Name!B13=#4F81BD
      Sheet Name: B13=#4F81BD
      Sheet Name=B13:#4F81BD
    """
    if isinstance(raw_value, dict):
        chunks = []
        for key, value in raw_value.items():
            if _sheet_name_matches(key, sheet_name):
                chunks.append(value)
        raw_value = "\n".join(str(chunk or "") for chunk in chunks)
    elif isinstance(raw_value, (list, tuple, set)):
        raw_value = "\n".join(str(chunk or "") for chunk in raw_value)

    overrides = {}
    for line in _split_scoped_range_entries(raw_value, allow_cell_value=True):
        if not line or "=" not in line:
            continue
        left, right = line.split("=", 1)
        rgb = _parse_hex_rgb(right)
        if not rgb:
            continue

        scope = ""
        body = left.strip()
        right_body = re.sub(r"[:=]?\s*#?[0-9A-Fa-f]{6}.*$", "", right).strip()
        if right_body and _ranges_from_text(right_body) and not _ranges_from_text(body):
            scope, body = body, right_body
        elif "!" in body:
            maybe_scope, maybe_body = body.rsplit("!", 1)
            if _ranges_from_text(maybe_body):
                scope, body = maybe_scope.strip(), maybe_body.strip()
        if not scope:
            match = re.match(r"^(.+?)\s*:\s*(.+)$", body)
            if match:
                maybe_scope, maybe_body = match.group(1).strip(), match.group(2).strip()
                if _ranges_from_text(maybe_body) and not _ranges_from_text(maybe_scope):
                    scope, body = maybe_scope, maybe_body
        if scope and not _sheet_name_matches(scope, sheet_name):
            continue

        for range_ref in _ranges_from_text(body):
            try:
                min_c, min_r, max_c, max_r = range_boundaries(range_ref)
            except Exception:
                continue
            for row_idx in range(min(min_r, max_r), max(min_r, max_r) + 1):
                for col_idx in range(min(min_c, max_c), max(min_c, max_c) + 1):
                    coord = f"{get_column_letter(col_idx).upper()}{row_idx}"
                    overrides[coord] = rgb
                    overrides[f"{row_idx}:{col_idx}"] = rgb
    return overrides


def _table_excel_font_hex_overrides_for_sheet(raw_value, sheet_name):
    return _table_excel_fill_hex_overrides_for_sheet(raw_value, sheet_name)


def _override_lines(raw_value):
    if isinstance(raw_value, dict):
        return [f"{key}={value}" for key, value in raw_value.items()]
    if isinstance(raw_value, (list, tuple, set)):
        raw_value = "\n".join(str(item or "") for item in raw_value)
    raw_text = str(raw_value or "")
    # Split on ;, newlines, and top-level commas (commas not inside parentheses)
    # This handles sheet names like "Game Rules (denom1,2,3&4)" that contain commas
    lines = []
    for raw_line in re.split(r"[;\n]+", raw_text):
        parts = []
        depth = 0
        current = []
        for ch in raw_line:
            if ch == "(":
                depth += 1
                current.append(ch)
            elif ch == ")":
                depth -= 1
                current.append(ch)
            elif ch == "," and depth == 0:
                parts.append("".join(current))
                current = []
            else:
                current.append(ch)
        if current:
            parts.append("".join(current))
        for part in parts:
            line = part.split("#", 1)[0].strip().rstrip(",;")
            if line:
                lines.append(line)
    return lines


def _split_scoped_override(line):
    line = str(line or "").strip()
    if not line:
        return "", ""
    for separator in ("=", "|"):
        if separator in line:
            left, right = line.split(separator, 1)
            return left.strip(), right.strip()
    if "!" in line:
        left, right = line.rsplit("!", 1)
        return left.strip(), right.strip()
    match = re.match(r"^(.+?)\s*:\s*(.+)$", line)
    if match:
        left, right = match.group(1).strip(), match.group(2).strip()
        if re.fullmatch(r"[A-Za-z]{1,4}|\d+", left) and re.fullmatch(r"[A-Za-z]{1,4}|\d+", right):
            return "", line
        if not _EXCEL_CELL_RE.fullmatch(left):
            return left, right
    return "", line


def _scoped_override_values_for_sheet(raw_value, sheet_name):
    values = []
    for line in _override_lines(raw_value):
        scope, body = _split_scoped_override(line)
        if scope and not _sheet_name_matches(scope, sheet_name):
            continue
        if body:
            values.append(body)
    return values


def _parse_cell_coordinate(value):
    match = re.match(r"^\s*([A-Za-z]{1,4})(\d+)\s*$", str(value or ""))
    if not match:
        return None
    try:
        col_idx = column_index_from_string(match.group(1).upper())
        row_idx = int(match.group(2))
        return row_idx, col_idx, f"{match.group(1).upper()}{row_idx}"
    except Exception:
        return None


def _page_multi_heading_overrides(raw_value):
    result = {}
    raw_text = str(raw_value or "").strip()
    if not raw_text:
        return result
    for block in raw_text.split(";"):
        block = block.strip()
        if not block or "=" not in block:
            continue
        page_part, entries_part = block.split("=", 1)
        page_name = page_part.strip()
        if not page_name:
            continue
        entries = []
        for entry_part in entries_part.split(","):
            entry_part = entry_part.strip()
            if ":" not in entry_part:
                continue
            label, cell_ref = entry_part.split(":", 1)
            parsed = _parse_cell_coordinate(cell_ref.strip())
            if parsed:
                entries.append((label.strip(), (parsed[0], parsed[1])))
        if entries:
            result[page_name] = entries
    return result


def _game_rules_legal_split_for_sheet(raw_value, sheet_name):
    for body in reversed(_scoped_override_values_for_sheet(raw_value, sheet_name)):
        parsed = _parse_cell_coordinate(body)
        if parsed:
            return parsed
        try:
            row_idx = int(str(body).strip())
            if row_idx > 0:
                return row_idx, 1, str(row_idx)
        except Exception:
            pass
    return None


_XTRA_REELS_NAME_PATTERNS = ("xtrareels", "xtrareel", "xtraa", "xtrareels2x", "xtrareel2x", "xtraa2x")


def _resolve_xtra_reels_asset(asset_raw="", candidate_dirs=()):
    """Resolve the XTRAA REELS side-icon asset for the Game Rules page.

    An explicitly chosen path wins whenever it exists. Otherwise the tool
    auto-detects an image named like ``xtraa.png`` / ``xtrareel.png`` /
    ``xtrareels.png`` (any case, '.png' '.jpg' '.jpeg' '.webp' '.bmp') inside
    the candidate folders — the project root, the icon folder and the Excel
    workbook's folder — one level deep. The most specific name wins (exact
    stem match beats prefix match; longer pattern beats shorter). Returns an
    absolute path, or "" when nothing is found.
    """
    raw = str(asset_raw or "").strip().strip('"')
    if raw and os.path.exists(raw):
        return os.path.abspath(raw)

    def _slug(text):
        return re.sub(r"[^a-z0-9]+", "", str(text or "").lower())

    patterns = sorted({(s, len(s)) for s in _XTRA_REELS_NAME_PATTERNS}, key=lambda item: -item[1])
    seeds = [os.path.abspath(str(d)) for d in candidate_dirs if str(d).strip()]
    if raw:
        seeds.append(os.path.dirname(os.path.abspath(raw)))
    best = None
    seen = set()
    for seed in seeds:
        seed_nc = seed.lower()
        if seed_nc in seen or not os.path.isdir(seed):
            continue
        seen.add(seed_nc)
        for root, dirs, files in os.walk(seed):
            depth = root[len(seed):].count(os.sep)
            if depth > 1:
                dirs[:] = []
                continue
            for name in files:
                ext = os.path.splitext(name)[1].lower()
                if ext not in (".png", ".jpg", ".jpeg", ".webp", ".bmp"):
                    continue
                stem = _slug(os.path.splitext(name)[0])
                if not stem:
                    continue
                for pattern, plen in patterns:
                    if stem == pattern or stem.startswith(pattern):
                        score = (plen, 1 if stem == pattern else 0)
                        if best is None or score > best[0]:
                            best = (score, os.path.abspath(os.path.join(root, name)))
                        break
    return best[1] if best else ""


def _column_token_to_index(token):
    token = str(token or "").strip()
    if not token:
        return None
    if re.fullmatch(r"\d+", token):
        value = int(token)
        return value if value > 0 else None
    if re.fullmatch(r"[A-Za-z]{1,4}", token):
        try:
            return column_index_from_string(token.upper())
        except Exception:
            return None
    cell = _parse_cell_coordinate(token)
    if cell:
        return cell[1]
    return None


def _parse_column_window(value, default_max_col):
    text = str(value or "").strip()
    default_max_col = max(1, int(default_max_col or 1))
    if not text:
        return None
    if re.fullmatch(r"\d+", text):
        return 1, max(1, int(text))

    range_match = re.match(
        r"^\s*([A-Za-z]{1,4}|\d+)\s*(?:-|:|to)\s*([A-Za-z]{1,4}|\d+)\s*$",
        text,
        flags=re.IGNORECASE,
    )
    if range_match:
        first = _column_token_to_index(range_match.group(1))
        second = _column_token_to_index(range_match.group(2))
        if first and second:
            return min(first, second), max(first, second)

    try:
        min_c, _min_r, max_c, _max_r = range_boundaries(text)
        return min(min_c, max_c), max(min_c, max_c)
    except Exception:
        pass

    single_col = _column_token_to_index(text)
    if single_col:
        return 1, single_col
    return None


def _page_render_column_window_for_sheet(raw_value, sheet_name, default_max_col):
    selected = None
    for body in _scoped_override_values_for_sheet(raw_value, sheet_name):
        parsed = _parse_column_window(body, default_max_col)
        if parsed:
            selected = parsed
    if not selected:
        return 1, max(1, int(default_max_col or 1))
    min_col, max_col = selected
    min_col = max(1, int(min_col or 1))
    max_col = max(min_col, int(max_col or min_col))
    return min_col, max_col


# ---------------------------------------------------------------------------
# per-sheet render window (rows + columns)
# ---------------------------------------------------------------------------

def _border_side_style(side):
    if side is None:
        return None
    try:
        style = getattr(side, "style", None)
    except Exception:
        return None
    return style if style and str(style).lower() != "none" else None


def detect_master_border(ws, min_edge_coverage=0.85, min_span=2, min_cells=6):
    """Detect the outer 'master border' rectangle that encloses all renderable
    data on a sheet (text, icons, tables).

    Excel help-screen sheets draw a box around the whole page content. We scan
    every cell border and keep the bounding box of all bordered cells, then
    accept it only when at least 3 of the 4 outer edges are >= 85% covered by
    a border line (some sheets skip the top/left edge by design).
    Returns dict(min_row, max_row, min_col, max_col) or None.
    """
    try:
        max_row = int(ws.max_row or 0)
        max_col = int(ws.max_column or 0)
        if max_row < 1 or max_col < 1:
            return None
        cells = {}
        for row in ws.iter_rows(min_row=1, max_row=max_row, min_col=1, max_col=max_col):
            for cell in row:
                try:
                    b = cell.border
                except Exception:
                    b = None
                if b is None:
                    continue
                sides = set()
                for name, side in (("T", b.top), ("B", b.bottom), ("L", b.left), ("R", b.right)):
                    if _border_side_style(side):
                        sides.add(name)
                if not sides:
                    continue
                cells[(int(cell.row), int(cell.column))] = sides
        if len(cells) < min_cells:
            return None
        min_r = min(r for r, _c in cells)
        max_r = max(r for r, _c in cells)
        min_c = min(c for _r, c in cells)
        max_c = max(c for _r, c in cells)
        if max_r - min_r + 1 < min_span or max_c - min_c + 1 < min_span:
            return None

        def coverage(side, row_range, col_range):
            total = 0
            hit = 0
            for r in row_range:
                for c in col_range:
                    total += 1
                    s = cells.get((r, c))
                    if s and side in s:
                        hit += 1
            return hit, total

        edges = [
            coverage("T", (min_r,), range(min_c, max_c + 1)),
            coverage("B", (max_r,), range(min_c, max_c + 1)),
            coverage("L", range(min_r, max_r + 1), (min_c,)),
            coverage("R", range(min_r, max_r + 1), (max_c,)),
        ]
        solid = sum(1 for hit, total in edges if total and (float(hit) / total) >= min_edge_coverage)
        if solid < 3:
            return None
        return {"min_row": min_r, "max_row": max_r, "min_col": min_c, "max_col": max_c}
    except Exception:
        return None


def _parse_render_window(value):
    """Parse a per-sheet render window override. Accepts:
       - 'A:L' / '1-12'      -> columns only (rows unconstrained)
       - '2:30'              -> rows only (columns unconstrained)
       - 'B2:O40'            -> full row+column rectangle
       - '12'                -> legacy: columns 1..12
       - '*' or ''           -> whole used range
    Returns (min_row, max_row, min_col, max_col); None = unconstrained.
    """
    text = str(value or "").strip()
    if not text or text == "*":
        return None, None, None, None
    try:
        min_c, min_r, max_c, max_r = range_boundaries(text)
        if min_r and max_r and min_c and max_c:
            return int(min_r), int(max_r), int(min_c), int(max_c)
    except Exception:
        pass
    m = re.fullmatch(r"([A-Za-z]{1,4})\s*[:=-]\s*([A-Za-z]{1,4})", text, flags=re.IGNORECASE)
    if m:
        c1, c2 = _column_token_to_index(m.group(1)), _column_token_to_index(m.group(2))
        if c1 and c2:
            return None, None, min(c1, c2), max(c1, c2)
    m = re.fullmatch(r"(\d+)\s*[:=-]\s*(\d+)", text)
    if m:
        r1, r2 = int(m.group(1)), int(m.group(2))
        return min(r1, r2), max(r1, r2), None, None
    m = re.fullmatch(r"([A-Za-z]{1,4})", text, flags=re.IGNORECASE)
    if m:
        c = _column_token_to_index(m.group(1))
        if c:
            return None, None, 1, c
    m = re.fullmatch(r"(\d+)", text)
    if m:
        return None, None, 1, max(1, int(m.group(1)))
    return None


def _render_window_for_sheet(dynamic_settings, sheet_name, default_max_col, ws):
    """Resolve the data window a normal page should render.

    Precedence:
      1. explicit per-sheet override (dynamic_settings.page_render_window_overrides,
         e.g. "Features=B2:O40")
      2. auto-detected master border (solid outer rectangle around all data)
      3. fallback: rows 1..used bottom, columns 1..max_col_limit

    Returns (min_row, max_row, min_col, max_col) — always clamped to the
    worksheet's used extent.
    """
    default_max_col = max(1, int(default_max_col or 1))
    raw = ""
    if isinstance(dynamic_settings, dict):
        raw = str(dynamic_settings.get("page_render_window_overrides") or "")
    selected = None
    for body in _scoped_override_values_for_sheet(raw, sheet_name):
        parsed = _parse_render_window(body)
        if parsed is not None and any(v is not None for v in parsed):
            selected = parsed
    if selected is not None:
        min_row, max_row, min_col, max_col = selected
    else:
        border = detect_master_border(ws)
        if border:
            min_row, max_row, min_col, max_col = border["min_row"], border["max_row"], border["min_col"], border["max_col"]
        else:
            min_row, max_row, min_col, max_col = None, None, 1, default_max_col

    used_max_row = 0
    used_max_col = 0
    try:
        used_max_row = int(ws.max_row or 0)
        used_max_col = int(ws.max_column or 0)
    except Exception:
        pass
    min_row = max(1, int(min_row or 1))
    max_row = min(max(int(max_row or used_max_row), min_row), max(used_max_row, min_row))
    min_col = max(1, int(min_col or 1))
    max_col = min(max(int(max_col or default_max_col), min_col), max(used_max_col, min_col))
    return min_row, max_row, min_col, max_col


def _cell_ranges_for_sheet(raw_ranges, sheet_name):
    """Return user-entered cell/range refs that apply to this worksheet."""
    if isinstance(raw_ranges, dict):
        chunks = []
        for key, value in raw_ranges.items():
            if _sheet_name_matches(key, sheet_name):
                chunks.append(value)
        raw_ranges = "\n".join(str(chunk or "") for chunk in chunks)
    elif isinstance(raw_ranges, (list, tuple, set)):
        raw_ranges = "\n".join(str(chunk or "") for chunk in raw_ranges)

    selected = []
    seen = set()
    for line in _split_scoped_range_entries(raw_ranges, strip_comment=True):
        scope = ""
        body = line
        for separator in ("=", "|"):
            if separator in line:
                left, right = line.split(separator, 1)
                if _ranges_from_text(right):
                    scope, body = left.strip(), right.strip()
                    break
        else:
            if "!" in line:
                left, right = line.rsplit("!", 1)
                if _ranges_from_text(right):
                    scope, body = left.strip(), right.strip()
            if not scope:
                match = re.match(r"^(.+?)\s*:\s*(.+)$", line)
                if match:
                    left, right = match.group(1).strip(), match.group(2).strip()
                    if not _EXCEL_CELL_RE.fullmatch(left) and _ranges_from_text(right):
                        scope, body = left, right

        if scope and not _sheet_name_matches(scope, sheet_name):
            continue
        for range_ref in _ranges_from_text(body):
            key = range_ref.casefold()
            if key in seen:
                continue
            seen.add(key)
            selected.append(range_ref)
    return selected


def _cell_coords_for_sheet(raw_ranges, sheet_name):
    coords = []
    seen = set()
    for range_ref in _cell_ranges_for_sheet(raw_ranges, sheet_name):
        try:
            min_c, min_r, max_c, max_r = range_boundaries(range_ref)
        except Exception:
            continue
        for row_idx in range(min(min_r, max_r), max(min_r, max_r) + 1):
            for col_idx in range(min(min_c, max_c), max(min_c, max_c) + 1):
                key = (int(row_idx), int(col_idx))
                if key in seen:
                    continue
                seen.add(key)
                coords.append(key)
    return coords


def _bingo_alignment_overrides_for_sheet(raw_value, sheet_name):
    """Parse cell-specific Bingo alignment/margins.

    Accepted examples:
      Bingo Rules=F13:center
      Bingo Rules=F13:left:120:120
      Bingo Rules!F13:F15:right
    """
    overrides = {}
    if isinstance(raw_value, dict):
        chunks = []
        for key, value in raw_value.items():
            if _sheet_name_matches(key, sheet_name):
                chunks.append(value)
        raw_value = "\n".join(str(chunk or "") for chunk in chunks)
    elif isinstance(raw_value, (list, tuple, set)):
        raw_value = "\n".join(str(chunk or "") for chunk in raw_value)

    for line in _split_scoped_range_entries(raw_value, strip_comment=True):
        scope = ""
        body = line
        for separator in ("=", "|"):
            if separator in line:
                left, right = line.split(separator, 1)
                if _ranges_from_text(right):
                    scope, body = left.strip(), right.strip()
                    break
        else:
            if "!" in line:
                left, right = line.rsplit("!", 1)
                if _ranges_from_text(right):
                    scope, body = left.strip(), right.strip()
        if scope and not _sheet_name_matches(scope, sheet_name):
            continue

        match = _EXCEL_RANGE_RE.search(body)
        if not match:
            continue
        range_ref = _ranges_from_text(match.group(0))
        if not range_ref:
            continue
        suffix = body[match.end():].strip()
        suffix = suffix.lstrip(":,=| ").strip()
        parts = [part.strip() for part in re.split(r"[:,|]", suffix) if part.strip()]
        alignment = _normalize_alignment(parts[0], "center") if parts else "center"
        left_margin = None
        right_margin = None
        if len(parts) >= 2:
            try:
                left_margin = max(0, int(float(parts[1])))
            except Exception:
                left_margin = None
        if len(parts) >= 3:
            try:
                right_margin = max(0, int(float(parts[2])))
            except Exception:
                right_margin = None
        try:
            min_c, min_r, max_c, max_r = range_boundaries(range_ref[0])
        except Exception:
            continue
        for row_idx in range(min(min_r, max_r), max(min_r, max_r) + 1):
            for col_idx in range(min(min_c, max_c), max(min_c, max_c) + 1):
                overrides[(int(row_idx), int(col_idx))] = {
                    "alignment": alignment,
                    "left_margin": left_margin,
                    "right_margin": right_margin,
                }
    return overrides


def _bingo_alignment_cells_psd(raw_cells, alignment):
    """Parse a plain cell list like 'b27, b28' or 'B5:C8' into
    {(row, col): {'alignment': ..., 'left_margin': None, 'right_margin': None}}."""
    overrides = {}
    for part in re.split(r"[\s,;]+", str(raw_cells or "")):
        part = part.strip().upper()
        if not part:
            continue
        try:
            min_c, min_r, max_c, max_r = range_boundaries(part)
        except Exception:
            continue
        for row_idx in range(min(min_r, max_r), max(min_r, max_r) + 1):
            for col_idx in range(min(min_c, max_c), max(min_c, max_c) + 1):
                overrides[(int(row_idx), int(col_idx))] = {
                    "alignment": alignment,
                    "left_margin": None,
                    "right_margin": None,
                }
    return overrides


def _bingo_merged_alignments_psd(dynamic_settings, sheet_name):
    """Merge legacy override text, engine defaults (B27/B28 left, H27/H28
    right) and the simple left/right cell fields — newest wins."""
    dynamic_settings = dynamic_settings or {}
    merged = _bingo_alignment_overrides_for_sheet(
        dynamic_settings.get("bingo_rules_alignment_overrides", ""), sheet_name
    )
    for coord, entry in _bingo_alignment_cells_psd("B27, B28", "left").items():
        merged.setdefault(coord, entry)
    for coord, entry in _bingo_alignment_cells_psd("H27, H28", "right").items():
        merged.setdefault(coord, entry)
    for coord, entry in _bingo_alignment_cells_psd(
        dynamic_settings.get("bingo_rules_left_align_cells"), "left"
    ).items():
        merged[coord] = entry
    for coord, entry in _bingo_alignment_cells_psd(
        dynamic_settings.get("bingo_rules_right_align_cells"), "right"
    ).items():
        merged[coord] = entry
    return merged


def _table_matches_any_range(table, ranges):
    if not table or not ranges:
        return False
    try:
        table_rect = {
            "start_row": int(table.get("start_row") or 0),
            "end_row": int(table.get("end_row") or 0),
            "min_col": int(table.get("min_col") or 0),
            "max_col": int(table.get("max_col") or 0),
        }
    except Exception:
        return False
    for range_ref in ranges:
        try:
            min_c, min_r, max_c, max_r = range_boundaries(str(range_ref or "").strip())
        except Exception:
            continue
        range_rect = {
            "start_row": min(min_r, max_r),
            "end_row": max(min_r, max_r),
            "min_col": min(min_c, max_c),
            "max_col": max(min_c, max_c),
        }
        if _table_rectangles_overlap(table_rect, range_rect):
            return True
    return False


def _table_rectangles_overlap(a, b):
    if not a or not b:
        return False
    return not (
        int(a.get("end_row", 0)) < int(b.get("start_row", 0))
        or int(b.get("end_row", 0)) < int(a.get("start_row", 0))
        or int(a.get("max_col", 0)) < int(b.get("min_col", 0))
        or int(b.get("max_col", 0)) < int(a.get("min_col", 0))
    )


def _safe_output_basename(value):
    value = str(value or "").strip()
    if not value:
        value = "PsHelpScreenTool_Final_" + datetime.datetime.now().strftime("%H%M%S")
    value = re.sub(r'[<>:"/\\|?*]+', "_", value)
    value = value.strip(" .")
    lower = value.lower()
    if lower.endswith(".psd") or lower.endswith(".psb"):
        value = value[:-4].strip(" .")
    return value or ("PsHelpScreenTool_Final_" + datetime.datetime.now().strftime("%H%M%S"))


def _psd_reuse_previous(output_name, prev_psd_path):
    """Whether the COM PSD engine may reuse the previous PSD for this build.

    The user-given output name is authoritative. The previous PSD file is
    only reused (open the already-open tab or reopen from disk) when its
    file name matches the requested output name, or when the user did not
    type a name at all (legacy update mode writes back into the old PSD).
    Any OTHER document open in Photoshop must never be rendered into, so a
    name mismatch falls through to creating a separate new document.
    """
    if not prev_psd_path:
        return False
    if not str(output_name or "").strip():
        return True
    target = _safe_output_basename(output_name)
    try:
        prev_base = _safe_output_basename(os.path.basename(str(prev_psd_path)))
    except Exception:
        return False
    return bool(prev_base) and prev_base.casefold() == target.casefold()


def _page_base_name(group_name):
    return str(group_name or "").split(" (Page")[0]


def _page_sort_key(group_name):
    text = str(group_name or "")
    match = re.search(r"\(Page\s+(\d+)", text, flags=re.IGNORECASE)
    page = int(match.group(1)) if match else 1
    is_copy = 1 if " Copy " in text else 0
    return (page, is_copy, text.casefold())


def _safe_layer_name_part(value, fallback="Cell"):
    text = str(value or "").strip()
    if not text:
        text = fallback
    text = re.sub(r'[<>:"/\\|?*\r\n\t]+', "_", text)
    text = re.sub(r"\s+", " ", text).strip(" ._")
    return text or fallback


def _cell_ref_from_coord(row_idx, col_idx):
    try:
        return f"{get_column_letter(int(col_idx))}{int(row_idx)}"
    except Exception:
        return f"R{row_idx}C{col_idx}"


def _cell_render_group_name(cell_ref, role):
    cell_ref = _safe_layer_name_part(cell_ref, "Cell")
    role = _safe_layer_name_part(role, "BodyTextAndIcons")
    return f"{cell_ref}-{role}"


def _norm_render_value(value):
    if value is None:
        return ""
    return str(value).strip()


def _performance_heading_signature(ws, min_col, max_col):
    return _performance_normalize_heading(_performance_internal_heading_text(ws, min_col, max_col))


def _performance_sheet_value_map(ws, min_col, max_col):
    values = {}
    try:
        max_row = int(ws.max_row or 0)
    except Exception:
        max_row = 0
    for row in ws.iter_rows(min_row=1, max_row=max_row, min_col=min_col, max_col=max_col):
        for cell in row:
            text = _norm_render_value(cell.value)
            if text and not _performance_is_metadata_text(text):
                values[(int(cell.row), int(cell.column))] = text
    return values


def _performance_merged_signature(ws):
    try:
        return tuple(sorted(str(item) for item in ws.merged_cells.ranges))
    except Exception:
        return tuple()


def _performance_layout_signature(ws, min_col, max_col):
    values = _performance_sheet_value_map(ws, min_col, max_col)
    return (
        tuple(sorted(values.keys())),
        _performance_merged_signature(ws),
    )


def _performance_diff_cells(base_values, target_values):
    changed = []
    all_coords = set(base_values or {}) | set(target_values or {})
    for coord in sorted(all_coords):
        if (base_values or {}).get(coord, "") != (target_values or {}).get(coord, ""):
            changed.append(coord)
    return changed


def _performance_changed_limit(total_cells):
    try:
        total_cells = int(total_cells or 0)
    except Exception:
        total_cells = 0
    return max(5, min(25, int(math.ceil(max(1, total_cells) * 0.18))))


def _performance_is_metadata_text(value):
    text = re.sub(r"\s+", " ", str(value or "")).strip().casefold()
    if not text:
        return True
    compact = re.sub(r"[^a-z0-9]+", "", text)
    if compact in {"modified", "removed", "delete", "deleted", "update", "updated"}:
        return True
    return bool(re.match(r"^<\s*(mod|modified|removed|delete|deleted|update|updated)\b", text))


def _performance_normalize_heading(value):
    text = re.sub(r"\s+", " ", str(value or "")).strip()
    if not text:
        return ""
    return text.casefold()


def _performance_internal_heading_text(ws, min_col, max_col):
    try:
        max_row = int(ws.max_row or 0)
    except Exception:
        max_row = 0
    first_text = ""
    first_bold_text = ""
    for row in ws.iter_rows(min_row=1, max_row=max_row, min_col=min_col, max_col=max_col):
        for cell in row:
            text = _norm_render_value(cell.value)
            if not text or _performance_is_metadata_text(text):
                continue
            if not first_text:
                first_text = text
            try:
                is_bold = bool(getattr(cell.font, "bold", False))
            except Exception:
                is_bold = False
            if is_bold:
                first_bold_text = text
                break
        if first_bold_text:
            break
    return first_bold_text or first_text


def _performance_sheet_has_mapped_template(mapped_table_records, sheet_name):
    for record in mapped_table_records or []:
        try:
            if not record.get("error") and template_matches_sheet(record, sheet_name):
                return True
        except Exception:
            continue
    return False


def _performance_sheet_has_dynamic_template(sheet_name, dynamic_settings):
    try:
        return bool(should_handle_sheet(sheet_name, dynamic_settings or {}))
    except Exception:
        return False


def _performance_cells_label(coords):
    refs = [_cell_ref_from_coord(row_idx, col_idx) for row_idx, col_idx in (coords or [])]
    return ", ".join(refs) if refs else "none"


def _build_performance_similarity_analysis(
        wb_formatted,
        render_tab_order,
        max_col_limit,
        dynamic_settings,
        mapped_table_records):
    """Analyze safe same-layout copy/patch targets before Photoshop rendering starts.

    The comparison uses visible worksheet content and the first internal page
    heading, never the Excel tab name. That lets sheets named anything still
    share one rendered bundle when their actual page content is nearly the same.
    """
    plan = {}
    rows = []
    base_records = []
    dynamic_settings = dynamic_settings or {}
    mapped_table_records = mapped_table_records or []

    def add_row(sheet_name, status, reason="", base="", changed_coords=None, heading_signature=""):
        rows.append({
            "sheet": sheet_name,
            "status": status,
            "reason": reason,
            "base": base,
            "changed_coords": list(changed_coords or []),
            "changed_cells": [
                _cell_ref_from_coord(row_idx, col_idx)
                for row_idx, col_idx in (changed_coords or [])
            ],
            "heading_signature": heading_signature or "",
        })

    for sheet_name in render_tab_order or []:
        if sheet_name not in getattr(wb_formatted, "sheetnames", []):
            add_row(sheet_name, "skipped", "Sheet not found in current workbook.")
            continue
        if _is_game_rules_sheet_name(sheet_name) or _is_bingo_rules_sheet_name(sheet_name):
            add_row(sheet_name, "normal", "GameRules/BingoRules sheet uses its dedicated renderer.")
            continue
        if _performance_sheet_has_dynamic_template(sheet_name, dynamic_settings):
            add_row(sheet_name, "normal", "Dynamic/custom page JSON is assigned.")
            continue
        if _performance_sheet_has_mapped_template(mapped_table_records, sheet_name):
            add_row(sheet_name, "normal", "Mapped @table JSON is assigned.")
            continue

        ws = wb_formatted[sheet_name]
        page_min_col, page_max_col = _page_render_column_window_for_sheet(
            dynamic_settings.get("page_render_column_overrides", ""),
            sheet_name,
            max_col_limit,
        )
        values = _performance_sheet_value_map(ws, page_min_col, page_max_col)
        if len(values) < 4:
            add_row(sheet_name, "normal", "Too little renderable cell content for safe similarity matching.")
            continue

        heading_signature = _performance_heading_signature(ws, page_min_col, page_max_col)
        if not heading_signature:
            add_row(sheet_name, "normal", "No stable internal page heading found.")
            continue

        value_coords = set(values.keys())
        merged_signature = _performance_merged_signature(ws)
        record = {
            "sheet": sheet_name,
            "heading_signature": heading_signature,
            "values": values,
            "value_coords": value_coords,
            "merged_signature": merged_signature,
            "page_min_col": page_min_col,
            "page_max_col": page_max_col,
        }

        best = None
        rejected_reasons = []
        for base in base_records:
            if base.get("heading_signature") != heading_signature:
                rejected_reasons.append(f"{base.get('sheet')}: heading mismatch")
                continue
            if base.get("merged_signature") != merged_signature:
                rejected_reasons.append(f"{base.get('sheet')}: merged-cell layout mismatch")
                continue
            all_coords = set(base.get("value_coords") or set()) | value_coords
            if len(all_coords) < 4:
                rejected_reasons.append(f"{base.get('sheet')}: too little comparable content")
                continue
            changed_coords = _performance_diff_cells(base.get("values", {}), values)
            changed_limit = _performance_changed_limit(len(all_coords))
            if len(changed_coords) > changed_limit:
                rejected_reasons.append(
                    f"{base.get('sheet')}: {len(changed_coords)} changed cells exceeds limit {changed_limit}"
                )
                continue
            unchanged_count = max(0, len(all_coords) - len(changed_coords))
            if unchanged_count < max(3, int(math.ceil(len(all_coords) * 0.75))):
                rejected_reasons.append(f"{base.get('sheet')}: less than 75% unchanged content")
                continue
            candidate = {
                "base": base.get("sheet"),
                "changed_coords": changed_coords,
                "heading_signature": heading_signature,
            }
            if best is None or len(changed_coords) < len(best.get("changed_coords") or []):
                best = candidate
                if not changed_coords:
                    break

        if best:
            plan[sheet_name] = best
            add_row(
                sheet_name,
                "copy",
                f"Copy from {best.get('base')} and patch {_performance_cells_label(best.get('changed_coords'))}.",
                base=best.get("base"),
                changed_coords=best.get("changed_coords"),
                heading_signature=heading_signature,
            )
        else:
            base_records.append(record)
            if rejected_reasons:
                reason = "No earlier compatible base. Closest checks: " + "; ".join(rejected_reasons[:4])
                if len(rejected_reasons) > 4:
                    reason += f"; +{len(rejected_reasons) - 4} more"
            else:
                reason = "First eligible page for this heading/layout; render normally as a future copy source."
            add_row(
                sheet_name,
                "base",
                reason,
                heading_signature=heading_signature,
            )
    return {"plan": plan, "rows": rows}


def _build_performance_similarity_plan(
        wb_formatted,
        render_tab_order,
        max_col_limit,
        dynamic_settings,
        mapped_table_records):
    return _build_performance_similarity_analysis(
        wb_formatted,
        render_tab_order,
        max_col_limit,
        dynamic_settings,
        mapped_table_records,
    ).get("plan", {})


def build_performance_mode_report(
        excel_path,
        max_col_limit=15,
        dynamic_settings=None,
        table_style=None,
        selected_sheets=None):
    """Return a dry-run Performance Mode plan without opening Photoshop."""
    if not excel_path or not os.path.exists(excel_path):
        raise FileNotFoundError(f"Excel file not found:\n{excel_path}")
    table_style = table_style or {}
    dynamic_settings = dynamic_settings or {}
    from .workbook_cache import load_formatted

    wb_formatted = load_formatted(excel_path)          # formula cells hold their results, not their formulas
    try:
        selected_names = []
        for name in (selected_sheets or []):
            cleaned = str(name or "").strip()
            if cleaned and cleaned not in selected_names:
                selected_names.append(cleaned)
        missing_selected = [name for name in selected_names if name not in wb_formatted.sheetnames]
        if missing_selected:
            raise ValueError(f"Selected Excel tab(s) not found: {', '.join(missing_selected)}")
        wanted = set(selected_names) if selected_names else set(wb_formatted.sheetnames)
        render_tab_order = [name for name in wb_formatted.sheetnames if name in wanted]

        mapped_raw = (
            table_style.get("mapped_table_jsons")
            or table_style.get("mapped_table_json")
            or ""
        )
        mapped_table_records = load_mapped_table_templates(mapped_raw, sheet_overrides=table_style.get("json_sheet_overrides") or {}) if mapped_raw else []
        analysis = _build_performance_similarity_analysis(
            wb_formatted,
            render_tab_order,
            max_col_limit,
            dynamic_settings,
            mapped_table_records,
        )
        rows = analysis.get("rows", [])
        copy_count = sum(1 for row in rows if row.get("status") == "copy")
        base_count = sum(1 for row in rows if row.get("status") == "base")
        normal_count = sum(1 for row in rows if row.get("status") == "normal")
        skipped_count = sum(1 for row in rows if row.get("status") == "skipped")
        lines = [
            "Performance Mode Dry Run",
            f"Excel: {excel_path}",
            f"Sheets checked: {len(render_tab_order)}",
            f"Copy-patch planned: {copy_count}",
            f"Normal/base renders: {base_count + normal_count}",
            f"Skipped: {skipped_count}",
            "",
        ]
        for record in mapped_table_records:
            if record.get("error"):
                lines.append(f"Mapped JSON warning: {record.get('path')}: {record.get('error')}")
        if any(record.get("error") for record in mapped_table_records):
            lines.append("")
        for row in rows:
            status = str(row.get("status") or "normal").upper()
            sheet = row.get("sheet") or ""
            base = row.get("base") or ""
            changed = ", ".join(row.get("changed_cells") or [])
            reason = row.get("reason") or ""
            if row.get("status") == "copy":
                lines.append(f"[{status}] {sheet} <- {base} | changed: {changed or 'none'}")
            else:
                lines.append(f"[{status}] {sheet} | {reason}")
        if not rows:
            lines.append("No eligible sheets found in the current selection.")
        lines.append("")
        lines.append("Note: the actual build still performs final safety checks. It first patches a recorded or named cell group such as F13-BodyTextAndIcons, then tries one unique editable-text match in the copied page bundle. JSON tables and unsafe/ambiguous matches fall back to normal rendering.")
        return {
            "plan": analysis.get("plan", {}),
            "rows": rows,
            "lines": lines,
            "summary": {
                "checked": len(render_tab_order),
                "copy": copy_count,
                "base": base_count,
                "normal": normal_count,
                "skipped": skipped_count,
            },
        }
    finally:
        try:
            wb_formatted.close()
        except Exception:
            pass


def _active_doc_group_order(app):
    """Return the visible top-level layer group order exactly as Photoshop shows it."""
    jsx = r'''
    (function() {
        var doc = app.activeDocument;
        var names = [];
        for (var i = 0; i < doc.layers.length; i++) {
            var layer = doc.layers[i];
            if (layer.typename === "LayerSet" && layer.name !== "Asset_Cache_Hidden") {
                names.push(layer.name);
            }
        }
        return names.join("\n");
    })();
    '''
    try:
        result = app.doJavaScript(jsx)
        return [line.strip() for line in str(result or "").splitlines() if line.strip()]
    except Exception:
        return []


def _desired_group_order(doc, original_order, workbook_sheet_names):
    try:
        current = [
            ls.name for ls in list(doc.layerSets)
            if getattr(ls, "name", "") not in ("Asset_Cache_Hidden",)
        ]
    except Exception:
        return []

    groups_by_base = {}
    for name in current:
        groups_by_base.setdefault(_page_base_name(name), []).append(name)
    for base_name in list(groups_by_base.keys()):
        groups_by_base[base_name] = sorted(groups_by_base[base_name], key=_page_sort_key)

    desired = []
    used = set()

    def append_base(base_name):
        for name in groups_by_base.get(base_name, []):
            if name not in used:
                desired.append(name)
                used.add(name)

    # First keep the exact old layer-stack base order. This is what preserves
    # "1, updated 2, 3" instead of placing the rebuilt group at the top.
    seen_bases = set()
    for original_name in original_order or []:
        base_name = _page_base_name(original_name)
        if base_name in seen_bases:
            continue
        seen_bases.add(base_name)
        append_base(base_name)

    # Then add any new workbook sheets in Excel order.
    for sheet_name in workbook_sheet_names or []:
        append_base(sheet_name)

    # Finally keep any helper/custom groups that are not workbook pages.
    for name in current:
        if name not in used:
            desired.append(name)
            used.add(name)

    return desired


def _reorder_top_level_groups(app, desired_names):
    desired_names = [str(name) for name in desired_names or [] if str(name or "").strip()]
    if not desired_names:
        return False
    names_js = json.dumps(desired_names)
    jsx = f"""
    (function() {{
        var doc = app.activeDocument;
        var desired = {names_js};
        function findTopGroup(name) {{
            for (var i = 0; i < doc.layers.length; i++) {{
                var layer = doc.layers[i];
                if (layer.typename === "LayerSet" && layer.name === name) return layer;
            }}
            return null;
        }}
        function moveToTop(group) {{
            if (!group || doc.layers.length < 1) return;
            try {{
                if (doc.layers[0] === group) return;
            }} catch (sameErr) {{}}
            try {{
                group.move(doc.layers[0], ElementPlacement.PLACEBEFORE);
            }} catch (e1) {{
                try {{
                    group.move(doc, ElementPlacement.PLACEATBEGINNING);
                }} catch (e2) {{}}
            }}
        }}
        for (var idx = desired.length - 1; idx >= 0; idx--) {{
            var group = findTopGroup(desired[idx]);
            if (!group) continue;
            moveToTop(group);
        }}
        return "OK";
    }})();
    """
    try:
        app.doJavaScript(jsx)
        return True
    except Exception as exc:
        print(f"Could not reorder top-level groups: {exc}")
        return False


def _label_page_groups(doc, app, current_tab_names, updated_tab_names):
    updated = set(updated_tab_names or [])
    current = set(current_tab_names or [])
    try:
        groups = list(doc.layerSets)
    except Exception:
        groups = []
    for group in groups:
        try:
            name = group.name
        except Exception:
            continue
        if name in ("Asset_Cache_Hidden",):
            continue
        base_name = _page_base_name(name)
        if base_name not in current:
            continue
        set_layer_color(group, app, 1 if base_name in updated else 4)



def _normalize_fs_path(path_value):
    try:
        return os.path.normcase(os.path.abspath(str(path_value).replace("\\", os.sep)))
    except Exception:
        return str(path_value or "").strip().casefold()


def _find_open_document_by_path(app, target_path):
    """Return an already-open Photoshop document matching target_path, or None.

    Prevents Re-render from opening the same PSD/PSB in another tab.
    """
    if not target_path:
        return None
    target_norm = _normalize_fs_path(target_path)
    try:
        docs = list(app.documents)
    except Exception:
        docs = []
    for doc in docs:
        candidates = []
        try:
            candidates.append(str(doc.fullName))
        except Exception:
            pass
        try:
            candidates.append(str(doc.path) + os.sep + str(doc.name))
        except Exception:
            pass
        try:
            candidates.append(str(doc.name))
        except Exception:
            pass
        for c in candidates:
            if not c:
                continue
            c_norm = _normalize_fs_path(c)
            if c_norm == target_norm or os.path.basename(c_norm) == os.path.basename(target_norm):
                try:
                    app.activeDocument = doc
                except Exception:
                    pass
                return doc
    return None


def execute_build(excel_path, icon_folder, bg_path, c_width, c_height, max_col_limit,
                  h_font, h_size, h_icon_h, h_rgb,
                  b_font, b_size, b_icon_h, b_rgb,
                  margin_x, line_spacing, para_spacing, gap_px, icon_y_offset,
                  bg_mode="stretch", table_style=None, enable_tables=True,
                  prev_excel_path=None, prev_psd_path=None, keyword_colors=None,
                  heading_top_margin=150, continued_gap=15, heading_to_body_gap=40, heading_style=None,
                  dynamic_settings=None, output_dir=None, icon_mappings=None, icon_size_overrides=None, bottom_margin=50,
                  output_name=None, output_format="PSD", overwrite_existing=False,
                  selected_sheets=None, preserve_selected_existing=False,
                  body_icons_use_original_size=False,
                  report_collector=None, body_style=None, icon_style=None,
                  alignment_settings=None, progress_callback=None,
                  cancel_event=None, show_completion_dialogs=True,
                  performance_mode=False, render_backend=None, c_resolution=72, bg_color="#FFFFFF",
                  icon_gap_left=None, icon_gap_right=None, heading_icon_gap=None,
                  heading_icon_gap_left=None, heading_icon_gap_right=None,
                  page_overrides=None, inner_canvas_width=0):
    profiler = BuildProfiler()
    profiler.start("total_build")

    def _emit_progress(event, **payload):
        if not callable(progress_callback):
            return
        try:
            data = {"event": event}
            data.update(payload)
            progress_callback(data)
        except Exception:
            pass

    def _show_dialog(kind, title, message):
        # Native dialogs are opt-in (the legacy desktop UI passes
        # show_completion_dialogs=True). Imported lazily so the build engine
        # carries no hard dependency on tkinter for web / headless builds.
        try:
            from tkinter import messagebox
        except Exception:
            return
        getattr(messagebox, kind, messagebox.showinfo)(title, message)

    def _cancel_requested():
        try:
            return bool(cancel_event and cancel_event.is_set())
        except Exception:
            return False

    def _heading_gap_for(size):
        if heading_icon_gap_left is not None or heading_icon_gap_right is not None:
            return (
                max(0, int(heading_icon_gap_left if heading_icon_gap_left is not None else (heading_icon_gap or 0))),
                max(0, int(heading_icon_gap_right if heading_icon_gap_right is not None else (heading_icon_gap or 0))),
            )
        if heading_icon_gap is not None:
            return max(0, int(heading_icon_gap))
        return max(int(size * 0.12), int(gap_px), 6)

    try:
        profiler.start("photoshop_connection")
        app = ps.Application()
        app.displayDialogs = ps.DialogModes.DisplayNoDialogs
        profiler.stop("photoshop_connection")
    except Exception as e:
        profiler.stop("photoshop_connection")
        if show_completion_dialogs:
            _show_dialog("showerror", "Error", f"Could not connect to Photoshop. Is it open?\n{str(e)}")
            return
        raise RuntimeError(f"Could not connect to Photoshop. Is it open?\n{str(e)}")
        return

    # Tkinter gives font family names. Photoshop textItem.font needs PostScript names.
    h_font = resolve_photoshop_font(app, h_font)
    b_font = resolve_photoshop_font(app, b_font)
    _emit_progress("note", message=(
        f"Typography received by engine: h_size={h_size!r} b_size={b_size!r} "
        f"h_font={h_font!r} b_font={b_font!r} resolution={c_resolution!r}"
    ))
    try:
        style_signature = _build_style_signature(
            h_font=h_font, h_size=h_size, h_icon_h=h_icon_h, h_rgb=h_rgb,
            b_font=b_font, b_size=b_size, b_icon_h=b_icon_h, b_rgb=b_rgb,
            margin_x=margin_x, line_spacing=line_spacing, para_spacing=para_spacing,
            gap_px=gap_px, icon_y_offset=icon_y_offset,
            heading_top_margin=heading_top_margin, continued_gap=continued_gap,
            heading_to_body_gap=heading_to_body_gap, bottom_margin=bottom_margin,
            bg_mode=bg_mode, bg_color=bg_color, c_resolution=c_resolution,
            keyword_colors=keyword_colors, dynamic_settings=dynamic_settings,
            table_style=table_style, heading_style=heading_style, body_style=body_style,
            icon_style=icon_style, alignment_settings=alignment_settings,
            icon_mappings=icon_mappings, icon_size_overrides=icon_size_overrides,
            body_icons_use_original_size=body_icons_use_original_size,
        )
    except Exception as e:
        style_signature = ""
        print(f"[Style] Could not build style signature: {e}")
    if table_style:
        for font_key in ("table_header_font_name", "table_body_font_name", "text_rectangle_font_name"):
            if table_style.get(font_key):
                table_style[font_key] = resolve_photoshop_font(app, table_style.get(font_key))
    dynamic_settings = dict(dynamic_settings or {})
    heading_uppercase_enabled = bool(dynamic_settings.get("heading_uppercase_enabled", False))
    heading_game_name_text = str(dynamic_settings.get("heading_game_name_text") or "").strip()
    heading_keep_one_line = bool(dynamic_settings.get("heading_keep_one_line", False))
    try:
        heading_one_line_margin = max(0, int(float(dynamic_settings.get("heading_one_line_margin", 80))))
    except Exception:
        heading_one_line_margin = 80
    heading_size_overrides_raw = dynamic_settings.get("heading_size_overrides", "")
    alignment_settings = dict(alignment_settings or {})
    alignment_defaults = dict(alignment_settings.get("global") or {})
    alignment_overrides = dict(alignment_settings.get("overrides") or {})
    alignment_source = str(alignment_settings.get("source") or "page_override").strip().casefold()
    heading_image_folder = str(alignment_settings.get("heading_image_folder") or "").strip()
    try:
        heading_image_height = int(float(alignment_settings.get("heading_image_height") or 0))
    except Exception:
        heading_image_height = 0

    def _page_override_for(sheet_name):
        if sheet_name in alignment_overrides:
            return alignment_overrides.get(sheet_name) or {}
        sheet_key = str(sheet_name or "").casefold()
        for key, value in alignment_overrides.items():
            if str(key).casefold() == sheet_key:
                return value or {}
        return {}

    def _page_style_override_for(sheet_name):
        src = dict(page_overrides or {})
        if sheet_name in src:
            return src.get(sheet_name) or {}
        sheet_key = str(sheet_name or "").casefold()
        for key, value in src.items():
            if str(key).casefold() == sheet_key:
                return value or {}
        return {}

    def _page_alignment(sheet_name, role, fallback="center"):
        default = _normalize_alignment(alignment_defaults.get(role), fallback)
        if alignment_source == "excel":
            # Excel is still primarily the content source. Keep the rendered
            # default stable unless a later Excel-alignment parser is enabled.
            return default
        if alignment_source in ("page_override", "page override if available, else global", "override"):
            override = _page_override_for(sheet_name)
            if override and not bool(override.get("use_global", True)):
                return _normalize_alignment(override.get(role), default)
        return default

    def _page_heading_size(sheet_name, fallback):
        selected = None
        for body in _scoped_override_values_for_sheet(heading_size_overrides_raw, sheet_name):
            match = re.search(r"\d+(?:\.\d+)?", str(body or ""))
            if not match:
                continue
            try:
                value = int(float(match.group(0)))
                if value > 0:
                    selected = value
            except Exception:
                pass
        if selected:
            return selected
        try:
            return int(fallback)
        except Exception:
            return int(h_size)

    def _heading_image_candidates(sheet_name):
        raw = str(sheet_name or "").strip()
        cleaned = re.sub(r"[^A-Za-z0-9]+", "_", raw).strip("_")
        compact = re.sub(r"[^A-Za-z0-9]+", "", raw)
        candidates = []
        for value in (raw, cleaned, compact):
            if value and value not in candidates:
                candidates.append(value)
        return candidates

    def _page_heading_image_path(sheet_name):
        override = _page_override_for(sheet_name)
        override_path = str(override.get("heading_image_path") or "").strip()
        if override_path and os.path.isfile(override_path):
            return override_path
        if not heading_image_folder or not os.path.isdir(heading_image_folder):
            return ""
        extensions = (".png", ".jpg", ".jpeg")
        for base_name in _heading_image_candidates(sheet_name):
            for ext in extensions:
                for candidate in (
                    os.path.join(heading_image_folder, base_name + ext),
                    os.path.join(heading_image_folder, base_name.lower() + ext),
                ):
                    if os.path.isfile(candidate):
                        return candidate
        return ""

    def _page_metric(sheet_name, role, fallback=0):
        try:
            default = int(float(alignment_defaults.get(role, fallback)))
        except Exception:
            default = int(fallback or 0)
        if alignment_source == "excel":
            return default
        if alignment_source in ("page_override", "page override if available, else global", "override"):
            override = _page_override_for(sheet_name)
            if override and not bool(override.get("use_global", True)):
                try:
                    return int(float(override.get(role, default)))
                except Exception:
                    return default
        return default

    def _role_box_for_alignment(alignment, left_margin_value=0, right_margin_value=None):
        alignment = _normalize_alignment(alignment)
        if alignment != "left":
            return None, None
        try:
            left_value = int(float(left_margin_value))
        except Exception:
            left_value = int(margin_x)
        try:
            right_value = int(float(right_margin_value if right_margin_value is not None else margin_x))
        except Exception:
            right_value = int(margin_x)
        left_value = max(0, min(int(c_width) - 1, left_value))
        right_value = max(0, min(int(c_width) - 1, right_value))
        return float(left_value), max(1.0, float(c_width - left_value - right_value))

    def _line_alignment_box(alignment, box_left=None, box_width=None):
        alignment = _normalize_alignment(alignment)
        if box_left is not None and box_width is not None:
            return float(box_left), max(1.0, float(box_width))
        if alignment == "center":
            return 0.0, float(c_width)
        return float(margin_x), max(1.0, float(c_width - (margin_x * 2)))

    def _line_start_x(line_width, alignment="center", box_left=None, box_width=None):
        alignment = _normalize_alignment(alignment)
        left, width = _line_alignment_box(alignment, box_left, box_width)
        line_width = float(line_width or 0)
        if alignment == "left":
            return left
        if alignment == "right":
            return left + width - line_width
        return left + (width - line_width) / 2.0

    game_name_heading_token_re = re.compile(r"<\s*game[\s_-]*name\s*>", flags=re.IGNORECASE)

    def _prepare_heading_text(raw_text):
        text = str(raw_text or "")
        if heading_game_name_text:
            text = game_name_heading_token_re.sub(heading_game_name_text, text)
        if heading_uppercase_enabled:
            text = text.upper()
        return text

    for src_key, dst_key in (
        ("count_font_request", "count_font"),
        ("value_font_request", "value_font"),
        ("game_rules_bottom_font_request", "game_rules_bottom_font"),
        ("subheading_font_request", "subheading_font"),
    ):
        if dynamic_settings.get(src_key):
            dynamic_settings[dst_key] = resolve_photoshop_font(app, dynamic_settings.get(src_key))
    print(f"[Fonts] Heading: {h_font} | Body: {b_font}")

    # Determine incremental vs full build
    incremental = False
    changed_tabs = None
    edit_log = []
    document_name = _safe_output_basename(output_name)
    mapped_table_records = []
    if table_style:
        mapped_table_records = load_mapped_table_templates(
            table_style.get("mapped_table_jsons") or table_style.get("mapped_table_json") or "",
            sheet_overrides=table_style.get("json_sheet_overrides") or {},
        )
        for record in mapped_table_records:
            if record.get("error"):
                warning = f"Mapped table JSON skipped: {record.get('error')}"
                edit_log.append(warning)
                if isinstance(report_collector, dict):
                    report_collector.setdefault("warnings", []).append(warning)

    # Open or create document.
    #
    # The user-given output name is authoritative. The previous PSD is only
    # reused (open tab or file on disk) when its name matches the requested
    # output name. If the names differ — or some unrelated file is open in
    # Photoshop — a SEPARATE new document is created, so the build never
    # writes into whatever PSD happens to be open in Photoshop.
    reuse_prev = _psd_reuse_previous(output_name, prev_psd_path)
    if reuse_prev and prev_psd_path and os.path.exists(prev_psd_path):
        try:
            doc = _find_open_document_by_path(app, prev_psd_path)
            if doc is None:
                doc = app.open(prev_psd_path)
            incremental = True
            # Clean ALL old helper layers/groups (including multiple backgrounds)
            for layer in list(doc.artLayers):
                if layer.name in ("MeasureLayer",) or layer.name.startswith("Custom Background"):
                    try:
                        layer.delete()
                    except:
                        try:
                            layer.remove()
                        except:
                            pass
            for ls in list(doc.layerSets):
                if ls.name == "Asset_Cache_Hidden":
                    try:
                        ls.delete()
                    except:
                        try:
                            ls.remove()
                        except:
                            pass
        except Exception as e:
            if show_completion_dialogs:
                _show_dialog("showwarning", "Warning", f"Could not open previous PSD. Creating new.\n{e}")
            else:
                edit_log.append(f"Could not open previous PSD. Creating new: {e}")
            doc = app.documents.add(c_width, c_height, c_resolution, name=document_name)
            incremental = False
    else:
        if prev_psd_path and os.path.exists(prev_psd_path) and not reuse_prev:
            edit_log.append(
                f"Output name '{document_name}' does not match the previous PSD name — "
                "created a separate new document instead of writing into the open file."
            )
        doc = app.documents.add(c_width, c_height, c_resolution, name=document_name)
        incremental = False

    # Load current workbook. Keep the formatted workbook open once; XLSM reloads
    # inside every sheet loop are expensive.
    profiler.start("workbook_load")
    wb = load_workbook(excel_path, data_only=True)
    from .workbook_cache import load_formatted

    wb_formatted = load_formatted(excel_path)          # formula cells hold their results, not their formulas
    profiler.stop("workbook_load")
    current_tab_names = set(wb.sheetnames)
    selected_names = []
    for name in (selected_sheets or []):
        cleaned = str(name or "").strip()
        if cleaned and cleaned not in selected_names:
            selected_names.append(cleaned)
    missing_selected = [name for name in selected_names if name not in current_tab_names]
    if missing_selected:
        raise ValueError(f"Selected Excel tab(s) not found: {', '.join(missing_selected)}")
    selected_tab_names = set(selected_names)
    selected_filter_active = bool(selected_tab_names)
    target_render_tabs = selected_tab_names if selected_filter_active else current_tab_names
    preserve_selected_existing = bool(preserve_selected_existing and selected_filter_active and prev_psd_path and os.path.exists(prev_psd_path))
    selected_copy_stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S") if preserve_selected_existing else ""

    # Compare with previous sources if available
    diff_source = None
    style_changed = False
    if incremental:
        manifest = None
        try:
            manifest = load_manifest(prev_psd_path)
        except Exception as e:
            print(f"[Manifest] Could not load manifest: {e}")
            manifest = None

        if prev_excel_path and os.path.exists(prev_excel_path):
            try:
                wb_old = load_workbook(prev_excel_path, data_only=True)
                wb_new = load_workbook(excel_path, data_only=True)
                changed_tabs = compare_workbooks(wb_old, wb_new, max_col_limit)
                diff_source = f"previous Excel ({prev_excel_path})"
                print(f"[Diff] Changed tabs from previous Excel: {list(changed_tabs.keys())}")
            except Exception as e:
                print(f"[Diff] Could not compare workbooks: {e}")
                changed_tabs = None

        if changed_tabs is None and manifest:
            try:
                changed_tabs = compare_excel_to_manifest(excel_path, manifest, max_col_limit)
                diff_source = f"manifest ({manifest_path_for_psd(prev_psd_path)})"
                print(f"[Diff] Changed tabs from manifest: {list(changed_tabs.keys())}")
            except Exception as e:
                print(f"[Diff] Could not compare against manifest: {e}")
                changed_tabs = None

        # Style/config changes are NOT visible in the Excel diff. Compare the
        # stored style signature; if the user changed typography, colors,
        # spacing, background, etc., force a full rebuild of every sheet.
        prev_style_signature = (manifest or {}).get("style_signature") or ""
        style_changed = bool(
            style_signature and prev_style_signature and style_signature != prev_style_signature
        )
        if style_changed:
            print(
                f"[Style] Signature changed: {prev_style_signature[:12]}... -> {style_signature[:12]}..."
            )
            edit_log.append("Typography/style settings changed — rebuilding all sheets")
    # Determine which tabs to keep, remove, and rebuild
    tabs_to_rebuild = set()      # Tabs that changed — need red label + delete old + rebuild
    tabs_to_remove = set()       # Tabs removed from Excel or orphaned in PSD
    tabs_to_keep = set()         # Tabs unchanged — leave alone, no red label

    if selected_filter_active:
        tabs_to_rebuild = target_render_tabs.copy()
        tabs_to_keep = current_tab_names - tabs_to_rebuild
        if preserve_selected_existing:
            edit_log.append("Selected-tab re-render copy mode active: " + ", ".join(sorted(tabs_to_rebuild)))
        else:
            edit_log.append("Selected-tab render mode active: " + ", ".join(sorted(tabs_to_rebuild)))
    elif style_changed:
        # Style settings changed — rebuild everything so the new typography
        # (sizes, fonts, colors, spacing, margins, background) actually applies.
        tabs_to_rebuild = current_tab_names.copy()
        edit_log.append(
            "Style settings changed — full rebuild: " + ", ".join(sorted(tabs_to_rebuild))
        )
    elif incremental:
        if changed_tabs is not None:
            for tab_name, changes in changed_tabs.items():
                if tab_name in current_tab_names:
                    tabs_to_rebuild.add(tab_name)
                    edit_log.append(f"Tab '{tab_name}' changed: {changes[0] if changes else 'updated'}")
                else:
                    tabs_to_remove.add(tab_name)
                    edit_log.append(f"Tab '{tab_name}' removed from Excel")

            # Unchanged tabs = keep as-is
            for tab_name in current_tab_names:
                if tab_name not in changed_tabs:
                    tabs_to_keep.add(tab_name)
                    edit_log.append(f"Tab '{tab_name}' unchanged — keeping")
        else:
            # Could not compare — rebuild all as safety fallback
            tabs_to_rebuild = current_tab_names.copy()
            edit_log.append("Full rebuild in existing PSD (could not compare with previous Excel)")
    else:
        # New PSD — rebuild all
        tabs_to_rebuild = current_tab_names.copy()

    render_tab_order = [name for name in wb.sheetnames if name in tabs_to_rebuild and name not in tabs_to_keep]
    total_render_tabs = len(render_tab_order)
    completed_render_tabs = 0
    cancel_requested = False
    performance_mode = bool(performance_mode)
    performance_max_changed_cells = 5
    performance_bases = []
    render_manifest = {
        "render_manifest_version": 1,
        "performance_mode_enabled": performance_mode,
        "sheets": {},
    }
    performance_similarity_plan = {}
    if performance_mode:
        edit_log.append("Performance Mode enabled: similar normal pages may copy prior page bundles and patch safe changed cells.")
        try:
            performance_analysis = _build_performance_similarity_analysis(
                wb_formatted,
                render_tab_order,
                max_col_limit,
                dynamic_settings,
                mapped_table_records,
            )
            performance_similarity_plan = performance_analysis.get("plan", {})
            render_manifest["performance_analysis"] = performance_analysis.get("rows", [])
            if performance_similarity_plan:
                render_manifest["performance_plan"] = {
                    sheet_name: {
                        "base": details.get("base"),
                        "changed_cells": [
                            _cell_ref_from_coord(row_idx, col_idx)
                            for row_idx, col_idx in (details.get("changed_coords") or [])
                        ],
                    }
                    for sheet_name, details in performance_similarity_plan.items()
                }
                edit_log.append(
                    "Performance Mode planned copy-patch sheets: "
                    + ", ".join(
                        f"{sheet_name} <- {details.get('base')}"
                        for sheet_name, details in performance_similarity_plan.items()
                    )
                )
        except Exception as exc:
            performance_similarity_plan = {}
            edit_log.append(f"Performance Mode planner skipped: {exc}")
    _emit_progress("build_start", total=total_render_tabs, sheets=render_tab_order)

    original_group_order = _active_doc_group_order(app)
    if not original_group_order:
        try:
            original_group_order = [
                ls.name for ls in list(doc.layerSets)
                if getattr(ls, "name", "") not in ("Asset_Cache_Hidden",)
            ]
        except Exception:
            original_group_order = []

    # Get all existing group names in PSD
    existing_groups = set()
    for ls in doc.layerSets:
        existing_groups.add(ls.name)
        # Also track page variants
        base_name = ls.name.split(" (Page")[0]
        existing_groups.add(base_name)

    # Find orphaned groups (in PSD but not in latest Excel)
    orphaned_groups = set()
    if not selected_filter_active:
        for group_name in existing_groups:
            base_name = group_name.split(" (Page")[0]
            if base_name not in current_tab_names and base_name not in ("Asset_Cache_Hidden",):
                orphaned_groups.add(base_name)
                tabs_to_remove.add(base_name)

    # REMOVE old groups: changed tabs + removed tabs + orphaned groups
    target_tab_names = set(list(tabs_to_remove) + list(orphaned_groups))
    if not preserve_selected_existing:
        target_tab_names.update(tabs_to_rebuild)

    all_layer_sets = list(doc.layerSets)
    to_delete = []

    for ls in all_layer_sets:
        # Skip helper groups
        if ls.name in ("Asset_Cache_Hidden",):
            continue

        # Check if this group matches a tab we need to rebuild or remove
        for tab_name in target_tab_names:
            if ls.name == tab_name or ls.name.startswith(f"{tab_name} (Page"):
                to_delete.append(ls)
                break

    # Delete collected groups. Layer-set COM objects can go stale when
    # Photoshop re-created the document (failed attempts/retries), so the
    # name is captured ONCE up front and never read again after a failure —
    # a stale handle must not kill the whole build.
    for ls in to_delete:
        try:
            group_name = str(ls.name or "")
        except Exception:
            group_name = ""
        if not group_name:
            edit_log.append("Removed old group: <stale layer set>")
            continue
        edit_log.append(f"Removed old group: {group_name}")
        try:
            ls.delete()
            continue
        except Exception as e:
            try:
                name = group_name.replace('"', '\\"')
                jsx = f'''
                (function() {{
                    var doc = app.activeDocument;
                    var allSets = doc.layerSets;
                    for (var i = 0; i < allSets.length; i++) {{
                        if (allSets[i].name === "{name}") {{
                            allSets[i].remove();
                            return;
                        }}
                    }}
                }})();
                '''
                app.doJavaScript(jsx)
                edit_log.append(f"Removed old group via JS: {group_name}")
            except Exception as e2:
                edit_log.append(f"Failed to remove {group_name}: {e} / {e2}")

    # Background
    if bg_path or bg_mode == "color":
        with _timed("background"):
            apply_background(doc, app, bg_path, c_width, c_height, bg_mode, bg_color)

    max_line_width = c_width - (margin_x * 2)
    # Bottom-safe limit for normal text/table pages. UI controls this value.
    # Nothing should intentionally render below this Y limit.
    try:
        bottom_margin = int(bottom_margin)
    except Exception:
        bottom_margin = 50
    bottom_margin = max(0, min(bottom_margin, max(0, int(c_height) - 1)))
    max_y_limit = c_height - bottom_margin

    color_h = ps.SolidColor()
    color_h.rgb.red, color_h.rgb.green, color_h.rgb.blue = h_rgb
    color_b = ps.SolidColor()
    color_b.rgb.red, color_b.rgb.green, color_b.rgb.blue = b_rgb

    measure_layer = doc.artLayers.add()
    measure_layer.name = "MeasureLayer"
    measure_layer.kind = ps.LayerKind.TextLayer
    measure_layer.visible = False

    asset_group = doc.layerSets.add()
    asset_group.name = "Asset_Cache_Hidden"
    asset_group.visible = False

    font_cache = {}
    icon_cache = {}
    _parsed_lines_cache = {}
    missing_icons_log = set()
    body_icons_use_original_size = bool(body_icons_use_original_size)

    def measure_text(text_string, font_size, f_name):
        with _timed("classic_measure_text"):
            return _measure_text_cached(text_string, font_size, f_name, measure_layer, font_cache)

    _solid_color_cache = {}
    def _solid_color_from_rgb(rgb_tuple):
        key = tuple(int(v) for v in rgb_tuple) if rgb_tuple else (255, 255, 255)
        if key not in _solid_color_cache:
            c = ps.SolidColor()
            try:
                c.rgb.red, c.rgb.green, c.rgb.blue = key
            except Exception:
                c.rgb.red, c.rgb.green, c.rgb.blue = 255, 255, 255
            _solid_color_cache[key] = c
        return _solid_color_cache[key]

    def _keyword_segments(text_string):
        """Split text into normal/keyword color runs.

        Keyword matching is case-insensitive and longest-keyword-first so custom
        words from the Keywords panel can override the body/heading color without
        breaking the normal text flow.
        """
        text_string = str(text_string or "")
        if not keyword_colors:
            return [(text_string, None)]
        usable = []
        for key, rgb in (keyword_colors or {}).items():
            key_s = str(key or "")
            if key_s:
                usable.append((key_s, tuple(rgb)))
        if not usable:
            return [(text_string, None)]
        usable.sort(key=lambda item: len(item[0]), reverse=True)
        pattern = "|".join(re.escape(k) for k, _ in usable)
        color_by_key = {k.casefold(): rgb for k, rgb in usable}
        segments = []
        last = 0
        for match in re.finditer(pattern, text_string, flags=re.IGNORECASE):
            if match.start() > last:
                segments.append((text_string[last:match.start()], None))
            matched_text = text_string[match.start():match.end()]
            segments.append((matched_text, color_by_key.get(matched_text.casefold())))
            last = match.end()
        if last < len(text_string):
            segments.append((text_string[last:], None))
        return segments or [(text_string, None)]

    def _resolved_icon_height(icon_name, default_height, use_size_overrides=True, use_original_icon_size=False):
        override_height = get_icon_size_override(icon_name, icon_size_overrides) if use_size_overrides else None
        if override_height:
            return max(1, int(override_height))
        if use_original_icon_size and icon_name in icon_cache:
            try:
                return max(1, int(round(float(icon_cache[icon_name].get('orig_h', 0)))))
            except Exception:
                pass
        try:
            return max(1, int(default_height))
        except Exception:
            return 1

    def _build_parsed_lines(raw_string, font_size, f_name, target_icon_h, local_gap_px=None, local_max_width=None,
                            use_size_overrides=True, use_original_icon_size=False):
        with _timed("classic_build_parsed_lines"):
            return _build_parsed_lines_impl(raw_string, font_size, f_name, target_icon_h, local_gap_px,
                                            local_max_width, use_size_overrides, use_original_icon_size)

    def _build_parsed_lines_impl(raw_string, font_size, f_name, target_icon_h, local_gap_px=None, local_max_width=None,
                                 use_size_overrides=True, use_original_icon_size=False):
        _cache_key = (raw_string, font_size, f_name, target_icon_h, local_gap_px, local_max_width,
                      use_size_overrides, use_original_icon_size, icon_gap_left, icon_gap_right)
        _cached = _parsed_lines_cache.get(_cache_key)
        if _cached is not None:
            return _cached
        import re as _re
        if isinstance(local_gap_px, tuple):
            _gap_l = max(0, int(local_gap_px[0] or 0))
            _gap_r = max(0, int(local_gap_px[1] or 0))
        else:
            active_gap_px = gap_px if local_gap_px is None else max(0, int(local_gap_px))
            if local_gap_px is not None:
                _gap_l = _gap_r = active_gap_px
            else:
                _gap_l = active_gap_px if icon_gap_left is None else max(0, int(icon_gap_left))
                _gap_r = active_gap_px if icon_gap_right is None else max(0, int(icon_gap_right))
        active_max_width = max_line_width if local_max_width is None else max(50, int(local_max_width))
        parts = _re.split(r'(<[^>]+>)', str(raw_string or ""))
        for _pi in range(len(parts)):
            _pp = parts[_pi]
            if not _pp or (_pp.startswith('<') and _pp.endswith('>')):
                continue
            _prev_is_token = _pi > 0 and parts[_pi - 1].startswith('<') and parts[_pi - 1].endswith('>')
            _next_is_token = _pi + 1 < len(parts) and parts[_pi + 1].startswith('<') and parts[_pi + 1].endswith('>')
            if _prev_is_token:
                parts[_pi] = _pp.lstrip()
            if _next_is_token:
                parts[_pi] = parts[_pi].rstrip()
        try:
            _batch_texts, _batch_sizes, _batch_fonts = [], [], []
            for _bp in parts:
                if not _bp or (_bp.startswith('<') and _bp.endswith('>')):
                    continue
                _batch_texts.append(_bp)
                _batch_sizes.append(font_size)
                _batch_fonts.append(f_name)
                for _bw in _re.split(r'( )', _bp):
                    if _bw:
                        _batch_texts.append(_bw)
                        _batch_sizes.append(font_size)
                        _batch_fonts.append(f_name)
            if _batch_texts:
                premeasure_texts_batch(_batch_texts, _batch_sizes, _batch_fonts, measure_layer, font_cache)
        except Exception:
            pass
        lines, current_line, current_w = [], [], 0

        for part in parts:
            if not part:
                continue
            if part.startswith('<') and part.endswith('>'):
                icon_name = part[1:-1].strip(" .;,-!")
                if icon_name not in icon_cache:
                    icon_path = resolve_icon_path(icon_name, icon_folder, icon_mappings)
                    # resolve_icon_path returns None when no matching asset exists.
                    # os.path.exists(None) raises: path should be string/bytes/PathLike, not NoneType.
                    if not icon_path or not os.path.exists(icon_path):
                        missing_icons_log.add(icon_name)
                        fallback_txt = f"<{icon_name}>"
                        fallback_w = measure_text(fallback_txt, font_size, f_name)
                        if current_w + fallback_w <= active_max_width:
                            current_line.append({'type': 'text', 'val': fallback_txt, 'w': fallback_w})
                            current_w += fallback_w
                        else:
                            if current_line:
                                lines.append({'elements': current_line, 'width': current_w})
                            current_line, current_w = [{'type': 'text', 'val': fallback_txt, 'w': fallback_w}], fallback_w
                        continue

                    icon_path_safe = json.dumps(icon_path)
                    icon_name_safe = json.dumps(str(icon_name or ""))
                    _t_icon0 = __import__("time").perf_counter()
                    jsx = f"""
                    (function() {{
                    var __doc0 = app.activeDocument;
                    var idPlc = charIDToTypeID("Plc ");
                    var desc = new ActionDescriptor();
                    desc.putPath(charIDToTypeID("null"), new File({icon_path_safe}));
                    executeAction(idPlc, desc, DialogModes.NO);
                    var l = app.activeDocument.activeLayer;
                    l.name = {icon_name_safe};
                    var b = l.bounds;
                    return [(b[2].value - b[0].value), (b[3].value - b[1].value)].join("|");
                    }})();
                    """
                    try:
                        _icon_bounds_res = app.doJavaScript(jsx)
                        layer = doc.activeLayer
                        layer.move(asset_group, ps.ElementPlacement.PlaceInside)
                    except Exception:
                        _PROFILER.inc("app_open_calls")
                        icon_doc = app.open(icon_path)
                        icon_doc.activeLayer.duplicate(doc)
                        icon_doc.close(2)
                        app.activeDocument = doc
                        layer = doc.activeLayer
                        layer.name = icon_name
                        try:
                            app.executeAction(app.stringIDToTypeID("newPlacedLayer"))
                        except:
                            pass
                        layer.move(asset_group, ps.ElementPlacement.PlaceInside)
                    _PROFILER.inc("classic_icons_placed")
                    _PROFILER.inc("classic_icons_place_ms", int((__import__("time").perf_counter() - _t_icon0) * 1000))

                    try:
                        _iw, _ih = str(_icon_bounds_res).split("|")
                        icon_cache[icon_name] = {
                            'layer': layer,
                            'orig_h': float(_ih),
                            'orig_w': float(_iw),
                        }
                    except Exception:
                        b = layer.bounds
                        icon_cache[icon_name] = {
                            'layer': layer,
                            'orig_h': float(b[3]) - float(b[1]),
                            'orig_w': float(b[2]) - float(b[0])
                        }

                resolved_icon_h = _resolved_icon_height(
                    icon_name, target_icon_h,
                    use_size_overrides=use_size_overrides,
                    use_original_icon_size=use_original_icon_size,
                )
                ratio = icon_cache[icon_name]['orig_w'] / icon_cache[icon_name]['orig_h']
                icon_w = resolved_icon_h * ratio
                w = _gap_l + icon_w + _gap_r
                if current_w + w > active_max_width and current_line:
                    lines.append({'elements': current_line, 'width': current_w})
                    current_line, current_w = [], 0
                current_line.append({'type': 'icon', 'val': icon_name, 'w': w, 'icon_h': resolved_icon_h})
                current_w += w
            else:
                full_chunk_w = measure_text(part, font_size, f_name)
                if current_w + full_chunk_w <= active_max_width:
                    current_line.append({'type': 'text', 'val': part, 'w': full_chunk_w})
                    current_w += full_chunk_w
                else:
                    words = _re.split(r'( )', part)
                    for word in words:
                        if not word:
                            continue
                        word_w = measure_text(word, font_size, f_name)
                        if current_w + word_w > active_max_width:
                            if word == ' ':
                                continue
                            if current_line:
                                lines.append({'elements': current_line, 'width': current_w})
                            current_line, current_w = [], 0
                        current_line.append({'type': 'text', 'val': word, 'w': word_w})
                        current_w += word_w

        if current_line:
            lines.append({'elements': current_line, 'width': current_w})
        try:
            _line_texts = []
            for _ln in lines:
                for _el in _ln.get('elements', []):
                    if _el.get('type') == 'text' and str(_el.get('val') or '').strip():
                        _line_texts.append(str(_el['val']))
            if _line_texts:
                premeasure_texts_batch(
                    _line_texts, [font_size] * len(_line_texts), [f_name] * len(_line_texts),
                    measure_layer, font_cache,
                )
        except Exception:
            pass
        _parsed_lines_cache[_cache_key] = lines
        return lines

    def _line_icon_height(line):
        return max((float(item.get('icon_h', 0)) for item in line.get('elements', []) if item.get('type') == 'icon'), default=0.0)

    def _line_text(line):
        return ''.join(item.get('val', '') for item in line.get('elements', []) if item.get('type') == 'text')

    # Row Gap ('line_gap') state for the whole build: a mutable holder the
    # per-sheet loop sets from the UI 'Row spacing' field (empty -> default 30).
    # _line_step_self and the row_gap_margin reflow read it so the PSD rows
    # stack at exactly content_bottom + row_gap like the PNG renderer.
    _row_gap_state = {"px": None}

    def _line_step_for_line(line, font_size, next_icon_h=0.0, local_line_step=None, font_name=None, next_line=None):
        """Vertical advance to the next baseline after `line`.

        Row Gap ('line_gap') is set: the step makes the VISUAL gap between the
        FULL content bounds of consecutive rows exactly the configured px,
        measured union-to-union (glyph ink UNION the tallest icon box of each
        row; near wrapper _row_gap_step_px). This mirrors the PNG renderer's
        _line_ink_extents stacking pixel-for-pixel.
        Otherwise (legacy): only the *current* line's own height is considered;
        a following line with a tall icon could ride up over a text-only line
        above it, so when the next line carries a tall icon the step must leave
        room for it below `line`.
        """
        if _row_gap_state["px"] is None:
            base = _line_step_self(line, font_size, local_line_step=local_line_step, font_name=font_name)
            if next_icon_h and next_icon_h > 0:
                need = _line_bottom_offset(line, font_size) + float(font_size) * 0.35 + float(next_icon_h) / 2.0
                base = max(base, int(math.ceil(need)))
            return base
        try:
            font_px = max(1, int(round(float(font_size))))
        except Exception:
            font_px = 24
        if next_line is not None:
            next_icon_h = _line_icon_height(next_line)
        return _row_gap_step_px(
            font_px, font_name, _line_text(line), _line_icon_height(line),
            _row_gap_state["px"], icon_y_offset=icon_y_offset,
            next_text=_line_text(next_line) if next_line is not None else "",
            next_icon_h=float(next_icon_h or 0),
        )

    def _line_step_self(line, font_size, local_line_step=None, font_name=None):
        if _row_gap_state["px"] is None and local_line_step is not None:
            try:
                return max(int(local_line_step), int(font_size) + 2)
            except Exception:
                pass
        try:
            font_px = max(1, int(round(float(font_size))))
        except Exception:
            font_px = 24
        # Row Gap is the single row-spacing source: the explicit UI value or
        # the default 30px (empty field). The legacy line-spacing multiplier
        # no longer participates in row stacking.
        spacing_px = float(_row_gap_state["px"] if _row_gap_state["px"] is not None else DEFAULT_ROW_GAP)
        if spacing_px != spacing_px or spacing_px < 0:
            spacing_px = 0.0
        # EXACT-ink step: real text ink (PIL probe of the line's actual text)
        # plus the user's px gap, minus the text ink top of the following line,
        # so consecutive text rows sit exactly `gap` px apart visually (the font
        # box ascent+descent is taller than the ink and produced larger gaps).
        _it, _ib, _ascent = _pil_ink_extents(font_px, font_name, _line_text(line))
        _yoff = max(0.0, float(icon_y_offset))
        prev_bottom_off = _ib
        max_icon_h = _line_icon_height(line)
        if max_icon_h:
            prev_bottom_off = max(prev_bottom_off, _ascent - float(font_px) * 0.35 + max_icon_h / 2.0 + _yoff)
        step = prev_bottom_off + spacing_px - _it
        return max(int(math.ceil(step)), 1)

    def _line_bottom_offset(line, font_size):
        max_icon_h = _line_icon_height(line)
        return max(4.0, float(font_size) * 0.35, max_icon_h - (float(font_size) * 0.35) + abs(float(icon_y_offset)))

    def _line_fits_at(baseline_y, font_size, line=None, local_line_step=None):
        # Photoshop textItem.position is baseline. When icons are taller than the
        # font, use their rendered height too so single lines do not sneak below the
        # bottom-safe margin.
        if line is None:
            return (baseline_y + max(4, font_size * 0.35)) <= max_y_limit
        return (baseline_y + _line_bottom_offset(line, font_size)) <= max_y_limit

    def _block_height(lines, font_size, local_line_step=None, font_name=None):
        total = 0
        for i, line in enumerate(lines):
            next_icon_h = _line_icon_height(lines[i + 1]) if i + 1 < len(lines) else 0.0
            next_line = lines[i + 1] if i + 1 < len(lines) else None
            total += _line_step_for_line(line, font_size, next_icon_h=next_icon_h, local_line_step=local_line_step, font_name=font_name, next_line=next_line)
        return total

    _default_keyword_colors = object()

    # ── Backend-aware helpers (used when render_backend is provided) ──────
    def _b_group(parent, name):
        if render_backend is not None:
            return render_backend.create_group(parent, name)
        g = parent.layerSets.add()
        g.name = name
        return g

    def _b_text(parent, text, font_name, font_size, color_rgb, x, y, name="Text", line_height=None):
        if render_backend is not None:
            return render_backend.create_text_layer(parent, text, font_name, font_size, color_rgb, x, y, name, line_height)
        return None

    def _b_shape(parent, w, h, fill_rgb, x, y, name="Shape"):
        if render_backend is not None:
            return render_backend.create_shape_layer(parent, w, h, fill_rgb, x, y, name)
        return None

    # ── Rendering functions ──────────────────────────────────────────────

    def _render_prepared_lines(lines, font_size, f_name, target_icon_h, target_color, target_group, start_y,
                               local_gap_px=None, text_group=None, icon_group=None,
                               local_keyword_colors=_default_keyword_colors, local_line_step=None,
                               local_alignment="center", local_box_left=None, local_box_width=None,
                               text_batch=None, lookahead_icon_h=0.0):
        if isinstance(local_gap_px, tuple):
            _gap_l = max(0, int(local_gap_px[0] or 0))
            _gap_r = max(0, int(local_gap_px[1] or 0))
        else:
            active_gap_px = gap_px if local_gap_px is None else max(0, int(local_gap_px))
            if local_gap_px is not None:
                _gap_l = _gap_r = active_gap_px
            else:
                _gap_l = active_gap_px if icon_gap_left is None else max(0, int(icon_gap_left))
                _gap_r = active_gap_px if icon_gap_right is None else max(0, int(icon_gap_right))
        active_keyword_colors = keyword_colors if local_keyword_colors is _default_keyword_colors else local_keyword_colors
        current_y = start_y
        text_target = text_group or target_group
        icon_target = icon_group or target_group
        _row_leading = None
        for i, line in enumerate(lines):
            # Row Gap mode: set each text layer's PS leading (line box) to the
            # row's OVERALL ink height (glyph ink union with the tallest icon),
            # so each row's text box spans "the highest icon or text". The
            # baseline step already leaves exactly `gap` blank between
            # consecutive rows' CONTENT (union) boxes, so a PS row-box to
            # row-box measurement reads exactly the gap (auto-leading boxes
            # and text-only leading are shorter than the union and read wrong
            # when an icon is taller than the text).
            if _row_gap_state["px"] is not None:
                try:
                    _fpx = max(1, int(round(float(font_size))))
                    _rit, _rib, _rasc = _pil_ink_extents(_fpx, f_name, _line_text(line))
                    _r_yoff = max(0.0, float(icon_y_offset))
                    _r_top, _r_bot = _rit, _rib
                    _r_icon_h = _line_icon_height(line)
                    if _r_icon_h and float(_r_icon_h) > 0:
                        _r_center = _rasc - float(_fpx) * 0.35 + _r_yoff
                        _r_top = min(_r_top, _r_center - float(_r_icon_h) / 2.0)
                        _r_bot = max(_r_bot, _r_center + float(_r_icon_h) / 2.0)
                    _row_leading = max(1, int(math.ceil(_r_bot - _r_top)))
                except Exception:
                    _row_leading = None
            next_icon_h = _line_icon_height(lines[i + 1]) if i + 1 < len(lines) else lookahead_icon_h
            next_line = lines[i + 1] if i + 1 < len(lines) else None
            line_step = _line_step_for_line(line, font_size, next_icon_h=next_icon_h, local_line_step=local_line_step, font_name=f_name, next_line=next_line)
            start_x = _line_start_x(line['width'], local_alignment, local_box_left, local_box_width)
            current_x = start_x
            grouped, txt_block = [], ""
            for item in line['elements']:
                if item['type'] == 'text':
                    txt_block += item['val']
                else:
                    if txt_block:
                        grouped.append({'type': 'text', 'val': txt_block})
                        txt_block = ""
                    grouped.append(item)
            if txt_block:
                grouped.append({'type': 'text', 'val': txt_block})

            for item in grouped:
                if item['type'] == 'text':
                    val = item['val']
                    if val.strip() != "":
                        _render_text_with_keyword_overlays(
                            text_target, val, font_size, f_name, target_color,
                            current_x, current_y, measure_layer, font_cache, active_keyword_colors,
                            "Text", app=app, text_batch=text_batch, backend=render_backend,
                            line_height=_row_leading,
                        )
                    current_x += measure_text(val, font_size, f_name)
                elif item['type'] == 'icon':
                    current_x += _gap_l
                    resolved_icon_h = float(item.get('icon_h', target_icon_h))
                    if render_backend is not None:
                        pil_im = icon_cache[item['val']].get('pil_image')
                        if pil_im is None:
                            icon_path = resolve_icon_path(item['val'], icon_folder, icon_mappings)
                            if icon_path and os.path.exists(icon_path):
                                from PIL import Image as _PILImage
                                pil_im = _PILImage.open(icon_path).convert("RGBA")
                        if pil_im is not None:
                            orig_w, orig_h = pil_im.size
                            scale = resolved_icon_h / max(orig_h, 1)
                            new_w = max(1, int(orig_w * scale))
                            new_h = max(1, int(orig_h * scale))
                            resized = pil_im.resize((new_w, new_h), _PILImage.LANCZOS)
                            center_y = current_y - (font_size * 0.35)
                            target_y = center_y - (resolved_icon_h / 2) + icon_y_offset
                            render_backend.create_image_layer(icon_target, resized, item['val'],
                                                              int(current_x), int(target_y))
                        current_x += (item['w'] - (_gap_l + _gap_r)) + _gap_r
                        continue
                    new_icon = icon_cache[item['val']]['layer'].duplicate()
                    new_icon.move(icon_target, ps.ElementPlacement.PlaceInside)
                    new_icon.visible = True
                    scale_pct = (resolved_icon_h / icon_cache[item['val']]['orig_h']) * 100
                    new_icon.resize(scale_pct, scale_pct)
                    b = new_icon.bounds
                    delta_x = current_x - float(b[0])
                    center_y = current_y - (font_size * 0.35)
                    target_y = center_y - (resolved_icon_h / 2) + icon_y_offset
                    delta_y = target_y - float(b[1])
                    new_icon.translate(delta_x, delta_y)
                    current_x += (item['w'] - (_gap_l + _gap_r)) + _gap_r
            current_y += line_step
        return current_y

    def draw_parsed_block(raw_string, font_size, f_name, target_icon_h, target_color, target_group, start_y,
                          local_gap_px=None, text_group=None, icon_group=None,
                          local_keyword_colors=_default_keyword_colors, local_max_width=None, local_line_step=None,
                          use_size_overrides=True, use_original_icon_size=False,
                          local_alignment="center", local_box_left=None, local_box_width=None):
        lines = _build_parsed_lines(
            raw_string, font_size, f_name, target_icon_h,
            local_gap_px=local_gap_px, local_max_width=local_max_width,
            use_size_overrides=use_size_overrides,
            use_original_icon_size=use_original_icon_size,
        )
        return _render_prepared_lines(
            lines, font_size, f_name, target_icon_h, target_color, target_group, start_y,
            local_gap_px=local_gap_px, text_group=text_group, icon_group=icon_group,
            local_keyword_colors=local_keyword_colors, local_line_step=local_line_step,
            local_alignment=local_alignment, local_box_left=local_box_left, local_box_width=local_box_width
        )

    def _estimate_block_height(raw_string, font_size, f_name, target_icon_h, local_gap_px=None, local_max_width=None,
                               local_line_step=None, use_size_overrides=True, use_original_icon_size=False):
        lines = _build_parsed_lines(
            raw_string, font_size, f_name, target_icon_h,
            local_gap_px=local_gap_px, local_max_width=local_max_width,
            use_size_overrides=use_size_overrides,
            use_original_icon_size=use_original_icon_size,
        )
        return _block_height(lines, font_size, local_line_step=local_line_step, font_name=f_name)


    def draw_game_rules_block(raw_string, font_size, f_name, target_icon_h, target_color, target_group, start_y,
                              local_gap_px=None, local_keyword_colors=_default_keyword_colors,
                              local_max_width=None, local_line_step=None, use_size_overrides=True,
                              use_original_icon_size=False, local_alignment="center",
                              local_box_left=None, local_box_width=None, local_body_style=None,
                              local_icon_style=None, prev_visual_bottom=None, row_gap_margin=None):
        """Render game-rules text line by line and visually center each line.

        Every rendered line gets its own temporary line group, even when it is text-only.
        After Photoshop renders the actual glyph/icon bounds, that line group is centered to
        the canvas. This is more accurate than centering from measured text width, because
        real Photoshop bounds can differ because of font side bearings, glyph overhangs,
        stroke/shadow, and icon bounds.
        """
        lines = _build_parsed_lines(
            raw_string, font_size, f_name, target_icon_h,
            local_gap_px=local_gap_px, local_max_width=local_max_width,
            use_size_overrides=use_size_overrides,
            use_original_icon_size=use_original_icon_size,
        )
        line_groups = []
        _row_spacing_px = row_gap_margin if row_gap_margin is not None else _line_gap_margin_px(font_size, line_spacing, local_line_step)
        _batched = render_backend is None and os.environ.get("PSH_BATCHED_LAYOUT", "1") != "0"
        # Direct positioning is the default now (PSH_DIRECT_POSITION=0 opts out):
        # lines are created ONCE at measured-width x + estimated row stack, no
        # measure/align/reflow passes. The fit loop uses the same estimates, so
        # pages still fit the canvas; rows may drift a couple px vs real bounds.
        _direct = render_backend is None and os.environ.get("PSH_DIRECT_POSITION", "1") != "0"
        _mega = _direct and _mega_mode_active()
        if _mega:
            _text_batch = _mega_pending_batch(app, doc, local_keyword_colors)
        else:
            _text_batch = [] if (_batched or _direct) and not local_keyword_colors else None
        current_y = start_y
        for line_index, line in enumerate(lines, start=1):
            line_group = _b_group(target_group, f"Centered Line {line_index}")
            text_layers = _b_group(line_group, "Body Text")
            line_has_icons = any(elem.get('type') == 'icon' for elem in line.get('elements', []))
            icon_layers = _b_group(line_group, "Body Icons") if line_has_icons else None
            next_h = _line_icon_height(lines[line_index]) if line_index < len(lines) else 0.0
            current_y = _render_prepared_lines(
                [line], font_size, f_name, target_icon_h, target_color, line_group, current_y,
                local_gap_px=local_gap_px, local_keyword_colors=local_keyword_colors,
                local_line_step=local_line_step, text_group=text_layers,
                icon_group=icon_layers,
                local_alignment=local_alignment, local_box_left=local_box_left, local_box_width=local_box_width,
                text_batch=_text_batch,
                lookahead_icon_h=next_h,
            )
            line_groups.append((line_group, local_alignment, local_box_left, local_box_width))
            if _batched or _direct:
                # Batched: reflow later snaps every row to the measured bounds
                # with the exact same gap, so only the first row's top must be
                # exact; skipping the per-line bounds read keeps the layout
                # identical. Direct: lines were created at their estimated
                # final positions (measured-width x + estimated row stack), so
                # there is nothing left to correct.
                continue
            # Two-pass row layout: advance the next line from this row's actual
            # union bottom (text + icons), never from estimated text height.
            _row_bounds = _collect_group_bounds(line_group)
            if _row_bounds:
                _row_bottom = float(_row_bounds[3])
                current_y = _row_bottom + _row_spacing_px
            if os.environ.get("PSH_DEBUG_REFLOW"):
                print(f"[Reflow:Row] line {line_index} bounds={_row_bounds} next_y={current_y:.1f}", flush=True)
        if _text_batch is not None and not _mega:
            flush_text_spec_batch(_text_batch, app, doc)
        if _direct:
            _page_body_style = local_body_style if local_body_style is not None else body_style
            _page_icon_style = local_icon_style if local_icon_style is not None else icon_style
            if _mega:
                _mega_record_style(app, doc, target_group, _page_body_style, _page_icon_style)
            else:
                apply_dual_style_to_group(app, doc, target_group, _page_body_style, _page_icon_style)
            if _mega:
                _pending = _mega_pending_batch(app, doc, local_keyword_colors)
                if _pending is not None:
                    flush_text_spec_batch(_pending, app, doc)
            current_y = _push_block_below_previous(
                target_group, prev_visual_bottom, current_y,
                margin_px=_row_spacing_px, app=app, debug_tag="GameRules",
            )
            _PROFILER.inc("classic_direct_blocks")
            return current_y
        if _batched:
            _PROFILER.inc("classic_layout_batched")
            with _timed("classic_layout_batched_total"):
                _resolved_groups = []
                for line_group, align, box_left, box_width in line_groups:
                    _r_left, _r_width = _line_alignment_box(align, box_left, box_width)
                    _resolved_groups.append((line_group, align, _r_left, _r_width))
                _align_bounds = _jsx_align_line_groups(
                    app, doc,
                    [(int(g.id), align, bl, bw) for g, align, bl, bw in _resolved_groups],
                )
                if _align_bounds is not None:
                    # Pre-style measured advance (mirrors the per-line
                    # current_y = row_bottom + spacing reads of the COM flow).
                    for _g, _a, _bl, _bw in _resolved_groups:
                        _bb = _align_bounds.get(int(_g.id))
                        if _bb:
                            current_y = float(_bb[3]) + _row_spacing_px
                    _page_body_style = local_body_style if local_body_style is not None else body_style
                    _page_icon_style = local_icon_style if local_icon_style is not None else icon_style
                    apply_dual_style_to_group(app, doc, target_group, _page_body_style, _page_icon_style)
                    _batched_y = _batched_block_layout(
                        app, doc, target_group, _resolved_groups,
                        prev_visual_bottom, current_y, _row_spacing_px, "GameRules",
                        premeasured=_align_bounds,
                    )
                    if _batched_y is not None:
                        return _batched_y
            _PROFILER.inc("classic_layout_batched_fallback")
        for line_group, align, box_left, box_width in line_groups:
            box_left, box_width = _line_alignment_box(align, box_left, box_width)
            if render_backend is not None:
                render_backend.align_group(line_group, box_left, box_width, align)
            else:
                _align_group_horizontally(line_group, box_left, box_width, align)
        _page_body_style = local_body_style if local_body_style is not None else body_style
        _page_icon_style = local_icon_style if local_icon_style is not None else icon_style
        apply_dual_style_to_group(app, doc, target_group, _page_body_style, _page_icon_style)
        _gap_margin_px = _row_spacing_px
        _reflowed_bottom = _reflow_centered_rows(line_groups, margin_px=_row_spacing_px)
        if _reflowed_bottom is not None:
            current_y = max(float(current_y), float(_reflowed_bottom))
        current_y = _push_block_below_previous(
            target_group, prev_visual_bottom, current_y,
            margin_px=_row_spacing_px, app=app, debug_tag="GameRules",
        )
        return current_y

    def _render_centered_prepared_lines(lines, font_size, f_name, target_icon_h, target_color, target_group, start_y,
                                        local_gap_px=None, local_keyword_colors=_default_keyword_colors,
                                        local_line_step=None, local_alignment="center",
                                        local_box_left=None, local_box_width=None, local_body_style=None,
                                        local_icon_style=None, prev_visual_bottom=None, row_gap_margin=None,
                                        block_push=True):
        _mega = (
            render_backend is None
            and os.environ.get("PSH_DIRECT_POSITION", "1") != "0"
            and _mega_mode_active()
        )
        if _mega:
            text_batch = _mega_pending_batch(app, doc, local_keyword_colors)
        else:
            text_batch = []
        line_groups = []
        current_y = start_y
        for line_index, line in enumerate(lines, start=1):
            line_group = _b_group(target_group, f"Centered Line {line_index}")
            text_layers = _b_group(line_group, "Body Text")
            line_has_icons = any(elem.get('type') == 'icon' for elem in line.get('elements', []))
            icon_layers = _b_group(line_group, "Body Icons") if line_has_icons else None
            next_h = _line_icon_height(lines[line_index]) if line_index < len(lines) else 0.0
            current_y = _render_prepared_lines(
                [line], font_size, f_name, target_icon_h, target_color, line_group, current_y,
                local_gap_px=local_gap_px, local_keyword_colors=local_keyword_colors,
                local_line_step=local_line_step, text_group=text_layers,
                icon_group=icon_layers,
                local_alignment=local_alignment, local_box_left=local_box_left, local_box_width=local_box_width,
                text_batch=text_batch,
                lookahead_icon_h=next_h,
            )
            line_groups.append((line_group, local_alignment, local_box_left, local_box_width))
        if render_backend is None and not _mega:
            flush_text_spec_batch(text_batch, app, doc)
        if render_backend is None and os.environ.get("PSH_DIRECT_POSITION", "1") != "0":
            _page_body_style = local_body_style if local_body_style is not None else body_style
            _page_icon_style = local_icon_style if local_icon_style is not None else icon_style
            if _mega:
                _mega_record_style(app, doc, target_group, _page_body_style, _page_icon_style)
            else:
                apply_dual_style_to_group(app, doc, target_group, _page_body_style, _page_icon_style)
            _gap_margin_px = row_gap_margin if row_gap_margin is not None else                 (_row_gap_state["px"] if _row_gap_state["px"] is not None else _line_gap_margin_px(font_size, line_spacing, local_line_step))
            if _mega:
                _pending = _mega_pending_batch(app, doc, local_keyword_colors)
                if _pending is not None:
                    flush_text_spec_batch(_pending, app, doc)
            if block_push:
                current_y = _push_block_below_previous(
                    target_group, prev_visual_bottom, current_y,
                    margin_px=_gap_margin_px, app=app, debug_tag="BodyBlock",
                )
            _PROFILER.inc("classic_direct_blocks")
            return current_y
        for line_group, align, box_left, box_width in line_groups:
            box_left, box_width = _line_alignment_box(align, box_left, box_width)
            if render_backend is not None:
                render_backend.align_group(line_group, box_left, box_width, align)
            else:
                _align_group_horizontally(line_group, box_left, box_width, align)
        _page_body_style = local_body_style if local_body_style is not None else body_style
        _page_icon_style = local_icon_style if local_icon_style is not None else icon_style
        if render_backend is None:
            apply_dual_style_to_group(app, doc, target_group, _page_body_style, _page_icon_style)
        _gap_margin_px = row_gap_margin if row_gap_margin is not None else _line_gap_margin_px(font_size, line_spacing, local_line_step)
        if os.environ.get("PSH_DEBUG_REFLOW"):
            for i, lgrp in enumerate(lines, start=1):
                try:
                    rb = _collect_group_bounds(line_groups[i - 1][0])
                except Exception:
                    rb = None
                print(f"[Reflow:BodyRow] line {i} icons={'Y' if any(e.get('type')=='icon' for e in lgrp.get('elements', [])) else 'N'} bounds={rb} gap_resolved={_gap_margin_px} font={font_size} line_spacing={line_spacing}", flush=True)
        _reflowed_bottom = _reflow_centered_rows(line_groups, margin_px=_gap_margin_px)
        if _reflowed_bottom is not None:
            current_y = float(_reflowed_bottom) + float(_gap_margin_px)
        current_y = _push_block_below_previous(
            target_group, prev_visual_bottom, current_y,
            margin_px=_gap_margin_px, app=app, debug_tag="BodyBlock",
        )
        return current_y

    def _draw_horizontal_rule(parent_group, top_y, width_px, height_px, fill_color, layer_name="Separator",
                              alignment="center", placement_margin=0):
        try:
            width_px = max(1, int(width_px))
            height_px = max(1, int(height_px))
            try:
                placement_margin = max(0, int(float(placement_margin)))
            except Exception:
                placement_margin = 0
            alignment = _normalize_alignment(alignment)
            if alignment == "left":
                left_x = placement_margin
            elif alignment == "right":
                left_x = int(c_width) - width_px - placement_margin
            else:
                left_x = int((c_width - width_px) / 2)
            left_x = max(0, min(int(c_width) - width_px, int(left_x)))
            top_y = int(top_y)
            if render_backend is not None:
                render_backend.create_shape_layer(parent_group, width_px, height_px, fill_color, left_x, top_y, layer_name)
                return
            layer = doc.artLayers.add()
            layer.name = layer_name
            region = [[left_x, top_y], [left_x + width_px, top_y], [left_x + width_px, top_y + height_px], [left_x, top_y + height_px]]
            doc.selection.select(region)
            rule_color = fill_color
            if isinstance(fill_color, (list, tuple)):
                rule_color = ps.SolidColor()
                rule_color.rgb.red = int(fill_color[0])
                rule_color.rgb.green = int(fill_color[1])
                rule_color.rgb.blue = int(fill_color[2])
            doc.selection.fill(rule_color)
            doc.selection.deselect()
            layer.move(parent_group, ps.ElementPlacement.PlaceInside)
        except Exception as exc:
            print(f"[Game Rules] Could not draw separator: {exc}")

    def _place_game_rules_side_icons(parent_group, asset_path, icon_width, outer_margin, center_y, y_offset=0):
        if not asset_path or not os.path.isfile(asset_path):
            print(f"[Game Rules] XTRAA REELS icon was not found: {asset_path}")
            if isinstance(report_collector, dict):
                report_collector.setdefault("warnings", []).append(f"Game Rules XTRAA REELS icon missing: {asset_path}")
            return False
        icon_width = max(1.0, float(icon_width))
        outer_margin = max(0.0, float(outer_margin))
        icon_group = parent_group.layerSets.add()
        icon_group.name = "Game Rules XTRAA REELS Side Icons"
        normalized_path = os.path.abspath(asset_path).replace('\\', '/')
        jsx_path = json.dumps(normalized_path)
        try:
            app.doJavaScript(f'''
                var __docx = app.activeDocument;
                var idPlc = charIDToTypeID("Plc ");
                var desc = new ActionDescriptor();
                desc.putPath(charIDToTypeID("null"), new File({jsx_path}));
                executeAction(idPlc, desc, DialogModes.NO);
            ''')
            left_layer = doc.activeLayer
        except Exception:
            _PROFILER.inc("app_open_calls")
            icon_doc = app.open(asset_path)
            icon_doc.activeLayer.duplicate(doc)
            icon_doc.close(2)
            app.activeDocument = doc
            left_layer = doc.activeLayer
        left_layer.name = "XTRAA REELS Left"
        left_layer.move(icon_group, ps.ElementPlacement.PlaceInside)
        bounds = _bounds_to_floats(left_layer.bounds)
        if not bounds or bounds[2] <= bounds[0]:
            return False
        scale_pct = (icon_width / (bounds[2] - bounds[0])) * 100.0
        left_layer.resize(scale_pct, scale_pct)
        bounds = _bounds_to_floats(left_layer.bounds)
        rendered_height = max(1.0, bounds[3] - bounds[1])
        target_top = float(center_y) - rendered_height / 2.0 + float(y_offset)
        target_top = max(float(heading_top_margin), min(target_top, float(max_y_limit) - rendered_height))
        left_layer.translate(outer_margin - bounds[0], target_top - bounds[1])

        right_layer = left_layer.duplicate()
        right_layer.name = "XTRAA REELS Right"
        right_layer.move(icon_group, ps.ElementPlacement.PlaceInside)
        right_bounds = _bounds_to_floats(right_layer.bounds)
        target_right_x = float(c_width) - outer_margin - icon_width
        right_layer.translate(target_right_x - right_bounds[0], target_top - right_bounds[1])
        return True

    def _hide_main_sheet_groups(groups):
        for group in groups:
            try:
                group.visible = False
            except Exception:
                pass

    def _solid_color_to_rgb_tuple(color_obj, fallback=None):
        try:
            return (
                int(round(float(color_obj.rgb.red))),
                int(round(float(color_obj.rgb.green))),
                int(round(float(color_obj.rgb.blue))),
            )
        except Exception:
            return tuple(fallback or b_rgb)

    def _sheet_render_manifest(tab_name):
        sheet_payload = render_manifest.setdefault("sheets", {}).setdefault(tab_name, {})
        sheet_payload.setdefault("page_groups", [])
        sheet_payload.setdefault("cells", {})
        sheet_payload.setdefault("performance", {})
        return sheet_payload

    def _append_sheet_group_manifest(tab_name, group_name):
        payload = _sheet_render_manifest(tab_name)
        if group_name and group_name not in payload["page_groups"]:
            payload["page_groups"].append(group_name)

    def _record_cell_render(tab_name, cell_ref, role, source_text, page_group_name, render_group, start_y,
                            font_size, font_name, icon_height, text_color, alignment, max_width,
                            box_left, box_width, line_step, safe_patch=True,
                            patch_kind="text", patch_data=None):
        if not cell_ref:
            return
        bounds = _collect_group_bounds(render_group)
        payload = _sheet_render_manifest(tab_name)
        cell_entries = payload["cells"].setdefault(str(cell_ref), [])
        entry = {
            "cell": str(cell_ref),
            "role": str(role or "body"),
            "source_text": str(source_text or ""),
            "page_group": str(page_group_name or ""),
            "group_name": str(getattr(render_group, "name", "") or ""),
            "start_y": float(start_y or 0),
            "bounds": bounds,
            "font_size": int(font_size or 0),
            "font_name": str(font_name or ""),
            "icon_height": int(icon_height or 0),
            "text_rgb": _solid_color_to_rgb_tuple(text_color),
            "alignment": _normalize_alignment(alignment),
            "max_width": float(max_width or 0),
            "box_left": None if box_left is None else float(box_left),
            "box_width": None if box_width is None else float(box_width),
            "line_step": None if line_step is None else float(line_step),
            "safe_patch": bool(safe_patch),
            "patch_kind": str(patch_kind or "text"),
        }
        if isinstance(patch_data, dict):
            entry["patch_data"] = dict(patch_data)
        try:
            lines = _build_parsed_lines(
                source_text, font_size, font_name, icon_height,
                local_max_width=max_width,
                use_original_icon_size=body_icons_use_original_size,
            )
            entry["line_count"] = len(lines)
            entry["estimated_height"] = _block_height(lines, font_size, local_line_step=line_step)
        except Exception:
            entry["line_count"] = 0
            entry["estimated_height"] = 0
        cell_entries.append(entry)

    def _find_layer_set_recursive(parent_group, target_name):
        try:
            for subgroup in list(parent_group.layerSets):
                try:
                    if subgroup.name == target_name:
                        return subgroup
                except Exception:
                    pass
                found = _find_layer_set_recursive(subgroup, target_name)
                if found is not None:
                    return found
        except Exception:
            pass
        return None

    def _remove_layer_group(group):
        if group is None:
            return False
        for method_name in ("delete", "remove"):
            try:
                getattr(group, method_name)()
                return True
            except Exception:
                pass
        return False

    def _performance_bundle_name(old_name, base_sheet_name, target_sheet_name):
        old_name = str(old_name or "")
        base_sheet_name = str(base_sheet_name or "")
        target_sheet_name = str(target_sheet_name or "")
        if old_name == base_sheet_name:
            return target_sheet_name
        prefix = base_sheet_name + " "
        if old_name.startswith(prefix):
            return target_sheet_name + old_name[len(base_sheet_name):]
        return old_name.replace(base_sheet_name, target_sheet_name, 1) if base_sheet_name else target_sheet_name

    def _cell_in_table_rect(coord, tables):
        row_idx, col_idx = coord
        for table in tables or []:
            try:
                if (
                    int(table.get("start_row", 0)) <= int(row_idx) <= int(table.get("end_row", 0))
                    and int(table.get("min_col", 0)) <= int(col_idx) <= int(table.get("max_col", 0))
                ):
                    return True
            except Exception:
                continue
        return False

    def _text_layer_contents(layer):
        try:
            return str(layer.textItem.contents)
        except Exception:
            return None

    def _normalized_patch_text(value):
        return re.sub(r"\s+", " ", str(value or "")).strip()

    def _iter_text_layers_recursive(parent_group):
        try:
            for layer in list(parent_group.artLayers):
                contents = _text_layer_contents(layer)
                if contents is not None:
                    yield layer, contents
        except Exception:
            pass
        try:
            for subgroup in list(parent_group.layerSets):
                yield from _iter_text_layers_recursive(subgroup)
        except Exception:
            pass

    def _iter_layer_sets_recursive(parent_group):
        try:
            for subgroup in list(parent_group.layerSets):
                yield subgroup
                yield from _iter_layer_sets_recursive(subgroup)
        except Exception:
            return

    def _cell_group_name_matches(cell_ref, group_name):
        cell_part = _safe_layer_name_part(cell_ref, "Cell").casefold()
        name = str(group_name or "").casefold()
        if not cell_part or not name:
            return False
        if not name.startswith(cell_part + "-"):
            return False
        suffix = name[len(cell_part) + 1:]
        return bool(suffix) and not suffix.startswith("table")

    def _derive_patch_entry_from_group(cell_ref, page_group, found_group, target_cell=None):
        bounds = _collect_group_bounds(found_group) or []
        left = body_box_left
        width = body_box_width or max(50.0, c_width - margin_x * 2)
        start_y = 0.0
        if len(bounds) >= 4:
            try:
                left = float(bounds[0])
                width = max(20.0, float(bounds[2]) - float(bounds[0]))
                start_y = float(bounds[1]) + float(b_size)
            except Exception:
                pass
        group_name = str(getattr(found_group, "name", "") or _cell_render_group_name(cell_ref, "BodyTextAndIcons"))
        role = "TextRectangle" if "textrectangle" in group_name.casefold() else "BodyTextAndIcons"
        return {
            "cell": str(cell_ref),
            "role": role,
            "source_text": str(getattr(target_cell, "value", "") if target_cell is not None else ""),
            "page_group": str(getattr(page_group, "name", "") or ""),
            "group_name": group_name,
            "start_y": start_y,
            "bounds": bounds,
            "font_size": int(b_size or 0),
            "font_name": str(b_font or ""),
            "icon_height": int(b_icon_h or 0),
            "text_rgb": tuple(b_rgb),
            "alignment": body_alignment,
            "max_width": float(width),
            "box_left": float(left),
            "box_width": float(width),
            "line_step": None,
            "safe_patch": True,
            "patch_kind": "text",
        }

    def _find_named_cell_patch_target(duplicated_groups, group_map, cell_ref, entries, target_cell=None):
        matches = []
        entries = list(entries or [])
        for entry in entries:
            group_name = str(entry.get("group_name") or "").strip()
            if not group_name:
                continue
            page_group = group_map.get(entry.get("page_group"))
            found_group = _find_layer_set_recursive(page_group, group_name) if page_group is not None else None
            if found_group is None:
                for duplicated in duplicated_groups or []:
                    found_group = _find_layer_set_recursive(duplicated, group_name)
                    if found_group is not None:
                        page_group = duplicated
                        break
            if found_group is not None and page_group is not None:
                matches.append((page_group, entry, f"recorded group {group_name}"))

        if len(matches) == 1:
            return matches[0]
        if len(matches) > 1:
            return None, f"{cell_ref} matched {len(matches)} recorded cell groups"

        loose_matches = []
        for page_group in duplicated_groups or []:
            for subgroup in _iter_layer_sets_recursive(page_group):
                try:
                    group_name = str(subgroup.name or "")
                except Exception:
                    continue
                if _cell_group_name_matches(cell_ref, group_name):
                    loose_matches.append((page_group, subgroup))

        if len(loose_matches) != 1:
            return None, f"{cell_ref} named cell group match count was {len(loose_matches)}"

        page_group, found_group = loose_matches[0]
        usable_entry = entries[0] if len(entries) == 1 else _derive_patch_entry_from_group(
            cell_ref,
            page_group,
            found_group,
            target_cell=target_cell,
        )
        usable_entry = dict(usable_entry)
        usable_entry["page_group"] = str(getattr(page_group, "name", "") or usable_entry.get("page_group") or "")
        usable_entry["group_name"] = str(getattr(found_group, "name", "") or usable_entry.get("group_name") or "")
        return page_group, usable_entry, f"named group {usable_entry['group_name']}"

    def _patch_copied_text_layer_by_value(duplicated_groups, cell_ref, old_text, new_text):
        old_text = str(old_text or "").strip()
        new_text = str(new_text or "").strip()
        if not old_text:
            return False, f"{cell_ref} has no old text value to match"
        if old_text == new_text:
            return True, f"{cell_ref} unchanged"

        old_norm = _normalized_patch_text(old_text)
        exact_matches = []
        substring_matches = []
        for group in duplicated_groups or []:
            for layer, contents in _iter_text_layers_recursive(group):
                if contents == old_text or _normalized_patch_text(contents) == old_norm:
                    exact_matches.append((layer, contents))
                elif old_text in contents:
                    substring_matches.append((layer, contents))

        matches = exact_matches or substring_matches
        match_kind = "exact" if exact_matches else "substring"
        if len(matches) != 1:
            return False, f"{cell_ref} editable text match count was {len(matches)}"

        layer, contents = matches[0]
        old_bounds = _bounds_to_floats(layer.bounds)
        old_center_x = None
        old_width = 0.0
        if old_bounds:
            old_center_x = (float(old_bounds[0]) + float(old_bounds[2])) / 2.0
            old_width = max(0.0, float(old_bounds[2]) - float(old_bounds[0]))

        replacement = contents.replace(old_text, new_text, 1) if match_kind == "substring" and old_text in contents else new_text

        try:
            layer.textItem.contents = replacement
            new_bounds = _bounds_to_floats(layer.bounds)
            if old_bounds and new_bounds:
                new_width = max(0.0, float(new_bounds[2]) - float(new_bounds[0]))
                max_safe_width = max(old_width + 120.0, old_width * 1.45)
                if old_width > 0 and new_width > max_safe_width:
                    layer.textItem.contents = contents
                    return False, f"{cell_ref} replacement text grew too wide"
                if old_center_x is not None:
                    new_center_x = (float(new_bounds[0]) + float(new_bounds[2])) / 2.0
                    layer.translate(old_center_x - new_center_x, 0)
            try:
                layer.name = f"{layer.name} [patched {cell_ref}]"
            except Exception:
                pass
            return True, f"{cell_ref} patched by editable text match"
        except Exception as exc:
            return False, f"{cell_ref} editable text patch failed: {exc}"

    def _render_performance_patch_cell(page_group, entry, new_text, target_cell):
        group_name = entry.get("group_name") or _cell_render_group_name(entry.get("cell"), "BodyTextAndIcons")
        old_group = _find_layer_set_recursive(page_group, group_name)
        if old_group is None:
            return False, f"cell group not found: {group_name}"

        role_key = str(entry.get("role") or "").lower()
        if "heading" in role_key:
            new_text = _prepare_heading_text(new_text)
            patch_text_style = heading_style
        elif "subheading" in role_key:
            patch_text_style = subheading_style
        else:
            patch_text_style = body_style
        font_size = int(entry.get("font_size") or b_size)
        font_name = str(entry.get("font_name") or b_font)
        icon_h = int(entry.get("icon_height") or b_icon_h)
        if "heading" in role_key:
            font_size, icon_h = _fit_heading_size_one_line(new_text, font_size, icon_h)
        max_width = float(entry.get("max_width") or body_box_width or (c_width - margin_x * 2))
        line_step = entry.get("line_step")
        try:
            line_step = None if line_step is None else float(line_step)
        except Exception:
            line_step = None
        try:
            probe_lines = _build_parsed_lines(
                new_text,
                font_size,
                font_name,
                icon_h,
                local_max_width=max_width,
                use_original_icon_size=body_icons_use_original_size,
            )
            new_line_count = len(probe_lines)
            new_height = _block_height(probe_lines, font_size, local_line_step=line_step)
        except Exception as exc:
            return False, f"could not measure changed cell {entry.get('cell')}: {exc}"

        old_line_count = int(entry.get("line_count") or 0)
        old_height = float(entry.get("estimated_height") or 0)
        entry_bounds = entry.get("bounds") or []
        allowed_height = 0.0
        try:
            if len(entry_bounds) >= 4:
                allowed_height = max(0.0, float(entry_bounds[3]) - float(entry_bounds[1]))
        except Exception:
            allowed_height = 0.0
        patch_kind = str(entry.get("patch_kind") or "text").strip().casefold()
        patch_data = entry.get("patch_data") or {}
        if patch_kind == "text_rectangle" and isinstance(patch_data, dict):
            try:
                allowed_height = max(
                    allowed_height,
                    float(patch_data.get("bottom", 0)) - float(patch_data.get("top", 0)) - (float(patch_data.get("pad_y", 0)) * 2),
                )
            except Exception:
                pass
        tolerance = max(4.0, font_size * 0.25)
        if allowed_height > 0:
            if new_height > allowed_height + tolerance:
                return False, f"changed cell {entry.get('cell')} would not fit old box"
        else:
            if old_line_count and new_line_count != old_line_count:
                return False, f"changed cell {entry.get('cell')} would alter line count ({old_line_count} -> {new_line_count})"
            if old_height and new_height > old_height + tolerance:
                return False, f"changed cell {entry.get('cell')} would grow vertically"

        if not _remove_layer_group(old_group):
            return False, f"could not remove old cell group: {group_name}"

        try:
            new_group = page_group.layerSets.add()
            new_group.name = group_name
            rgb = (get_excel_color(target_cell) if target_cell is not None else None) or tuple(entry.get("text_rgb") or b_rgb)
            color = ps.SolidColor()
            color.rgb.red, color.rgb.green, color.rgb.blue = [int(v) for v in rgb]
            if patch_kind == "text_rectangle" and isinstance(patch_data, dict):
                left = float(patch_data.get("left", 0))
                top = float(patch_data.get("top", 0))
                right = float(patch_data.get("right", left + max_width))
                bottom = float(patch_data.get("bottom", top + max(new_height, font_size)))
                fill_rgb = tuple(patch_data.get("fill_rgb") or (20, 20, 30))
                stroke_rgb = tuple(patch_data.get("stroke_rgb") or (255, 255, 255))
                fill_opacity = max(0, min(100, int(patch_data.get("fill_opacity", 100) or 0)))
                stroke_width = max(0, int(patch_data.get("stroke_width", 0) or 0))
                safe_name = json.dumps(f"Text Rectangle Fill {entry.get('cell')}")
                jsx = f"""
                    var doc = app.activeDocument;
                    var layer = doc.artLayers.add();
                    layer.name = {safe_name};
                    var region = [[{int(round(left))},{int(round(top))}],[{int(round(right))},{int(round(top))}],[{int(round(right))},{int(round(bottom))}],[{int(round(left))},{int(round(bottom))}]];
                    doc.selection.select(region);
                    if ({fill_opacity} > 0) {{
                        var fillColor = new SolidColor();
                        fillColor.rgb.red = {int(fill_rgb[0])};
                        fillColor.rgb.green = {int(fill_rgb[1])};
                        fillColor.rgb.blue = {int(fill_rgb[2])};
                        doc.selection.fill(fillColor);
                        layer.opacity = {fill_opacity};
                    }}
                    if ({stroke_width} > 0) {{
                        var strokeColor = new SolidColor();
                        strokeColor.rgb.red = {int(stroke_rgb[0])};
                        strokeColor.rgb.green = {int(stroke_rgb[1])};
                        strokeColor.rgb.blue = {int(stroke_rgb[2])};
                        doc.selection.stroke(strokeColor, {stroke_width}, StrokeLocation.INSIDE);
                    }}
                    doc.selection.deselect();
                """
                app.doJavaScript(jsx)
                rect_layer = doc.activeLayer
                rect_layer.move(new_group, ps.ElementPlacement.PlaceInside)
                text_group = new_group.layerSets.add()
                text_group.name = "Text"
                icon_group = new_group.layerSets.add()
                icon_group.name = "Icons"
                _render_prepared_lines(
                    probe_lines,
                    font_size,
                    font_name,
                    icon_h,
                    color,
                    new_group,
                    float(entry.get("start_y") or 0),
                    text_group=text_group,
                    icon_group=icon_group,
                    local_alignment=entry.get("alignment") or "center",
                    local_box_left=entry.get("box_left"),
                    local_box_width=entry.get("box_width"),
                )
                apply_style_to_group_text_layers(app, doc, text_group, patch_text_style)
                apply_style_to_group_text_layers(app, doc, icon_group, icon_style, text_only=False)
            else:
                _render_centered_prepared_lines(
                    probe_lines,
                    font_size,
                    font_name,
                    icon_h,
                    color,
                    new_group,
                    float(entry.get("start_y") or 0),
                    local_gap_px=_heading_gap_for(font_size) if "heading" in role_key else None,
                    local_line_step=line_step,
                    local_alignment=entry.get("alignment") or "center",
                    local_box_left=entry.get("box_left"),
                    local_box_width=entry.get("box_width"),
                    local_body_style=patch_text_style,
                    local_icon_style=icon_style,
                    block_push=False,
                )
            return True, ""
        except Exception as exc:
            return False, f"could not render changed cell {entry.get('cell')}: {exc}"

    def _try_performance_copy_from_base(
            tab_name,
            sheet_fmt,
            page_min_col,
            page_max_col,
            tables,
            sheet_mapped_table_records,
            planned_base_name=None,
            planned_changed_coords=None):
        if not performance_mode or not performance_bases:
            return False, "performance mode unavailable"
        if sheet_mapped_table_records:
            return False, "mapped JSON table present"
        current_merged_sig = _performance_merged_signature(sheet_fmt)
        current_values = _performance_sheet_value_map(sheet_fmt, page_min_col, page_max_col)
        candidate = None
        if planned_base_name:
            for base_index, base in enumerate(reversed(performance_bases)):
                if str(base.get("sheet") or "") != str(planned_base_name or ""):
                    continue
                changed_coords = list(planned_changed_coords or [])
                all_coords = set(base.get("values", {}) or {}) | set(current_values or {})
                changed_limit = max(performance_max_changed_cells, _performance_changed_limit(len(all_coords)))
                if len(changed_coords) > changed_limit:
                    return False, "planned copy changed too many cells"
                candidate = {
                    "base": base,
                    "changed_coords": changed_coords,
                    "base_index": base_index,
                    "planned": True,
                }
                break
            if candidate is None:
                return False, "planned base sheet not rendered yet"
        else:
            for base_index, base in enumerate(reversed(performance_bases)):
                if base.get("merged_signature") != current_merged_sig:
                    continue
                if base.get("heading_signature") != _performance_heading_signature(sheet_fmt, page_min_col, page_max_col):
                    continue
                changed_coords = _performance_diff_cells(base.get("values", {}), current_values)
                all_coords = set(base.get("values", {}) or {}) | set(current_values or {})
                changed_limit = max(performance_max_changed_cells, _performance_changed_limit(len(all_coords)))
                if len(changed_coords) > changed_limit:
                    continue
                unchanged_count = max(0, len(all_coords) - len(changed_coords))
                if len(all_coords) > 3 and unchanged_count < max(3, int(math.ceil(len(all_coords) * 0.75))):
                    continue
                if candidate is None or len(changed_coords) < len(candidate["changed_coords"]):
                    candidate = {
                        "base": base,
                        "changed_coords": changed_coords,
                        "base_index": base_index,
                    }
                    if not changed_coords:
                        break

        if candidate is None:
            return False, "no similar low-diff base sheet found"

        base = candidate["base"]
        changed_coords = candidate["changed_coords"]
        if any(_cell_in_table_rect(coord, tables) or _cell_in_table_rect(coord, base.get("tables", [])) for coord in changed_coords):
            return False, "changed cell is inside an auto table"
        base_manifest = render_manifest.get("sheets", {}).get(base.get("sheet"), {}) or {}
        base_groups = list(base.get("groups") or [])
        if not base_groups:
            return False, "base page bundle has no Photoshop groups"

        duplicated_groups = []
        group_map = {}
        try:
            for group in base_groups:
                old_name = str(getattr(group, "name", "") or "")
                duplicated = group.duplicate()
                new_name = _performance_bundle_name(old_name, base.get("sheet"), tab_name)
                duplicated.name = new_name
                set_layer_color(duplicated, app, 1 if tab_name in tabs_to_rebuild else 0)
                duplicated_groups.append(duplicated)
                group_map[old_name] = duplicated
                _append_sheet_group_manifest(tab_name, new_name)
        except Exception as exc:
            for duplicated in duplicated_groups:
                _remove_layer_group(duplicated)
            return False, f"could not duplicate page bundle: {exc}"

        patched_refs = []
        for row_idx, col_idx in changed_coords:
            cell_ref = _cell_ref_from_coord(row_idx, col_idx)
            entries = (base_manifest.get("cells", {}) or {}).get(cell_ref, [])
            safe_entries = [entry for entry in entries if entry.get("safe_patch")]
            target_cell = sheet_fmt.cell(row=row_idx, column=col_idx)
            if len(safe_entries) != 1:
                named_target = _find_named_cell_patch_target(
                    duplicated_groups,
                    group_map,
                    cell_ref,
                    entries,
                    target_cell=target_cell,
                )
                if named_target and len(named_target) == 3 and named_target[0] is not None:
                    page_group, entry, target_reason = named_target
                    ok, reason = _render_performance_patch_cell(
                        page_group,
                        entry,
                        str(target_cell.value or "").strip(),
                        target_cell,
                    )
                    if ok:
                        patched_refs.append(cell_ref)
                        edit_log.append(f"Performance Mode named-cell patched {cell_ref} on {tab_name}: {target_reason}")
                        continue
                    for duplicated in duplicated_groups:
                        _remove_layer_group(duplicated)
                    return False, f"{cell_ref} named-cell patch failed: {reason}"

                named_reason = named_target[1] if named_target and len(named_target) == 2 else "no named cell group"
                old_text = (base.get("values", {}) or {}).get((row_idx, col_idx), "")
                ok, reason = _patch_copied_text_layer_by_value(
                    duplicated_groups,
                    cell_ref,
                    old_text,
                    str(target_cell.value or "").strip(),
                )
                if ok:
                    patched_refs.append(cell_ref)
                    edit_log.append(f"Performance Mode value-patched {cell_ref} on {tab_name}: {reason}")
                    continue
                for duplicated in duplicated_groups:
                    _remove_layer_group(duplicated)
                return False, (
                    f"changed cell {cell_ref} has {len(safe_entries)} safe patch target(s); "
                    f"{named_reason}; {reason}"
                )
            entry = safe_entries[0]
            page_group = group_map.get(entry.get("page_group"))
            if page_group is None:
                for duplicated in duplicated_groups:
                    _remove_layer_group(duplicated)
                return False, f"page group not found for changed cell {cell_ref}"
            ok, reason = _render_performance_patch_cell(page_group, entry, str(target_cell.value or "").strip(), target_cell)
            if not ok:
                for duplicated in duplicated_groups:
                    _remove_layer_group(duplicated)
                return False, reason
            patched_refs.append(cell_ref)

        pseudo_heading_ref = "__PAGE_HEADING__"
        if base.get("sheet") != tab_name:
            heading_entries = [
                entry for entry in ((base_manifest.get("cells", {}) or {}).get(pseudo_heading_ref, []))
                if entry.get("safe_patch")
            ]
            if heading_entries:
                if len(heading_entries) != 1:
                    for duplicated in duplicated_groups:
                        _remove_layer_group(duplicated)
                    return False, f"page heading has {len(heading_entries)} safe patch target(s)"
                heading_entry = heading_entries[0]
                heading_group = group_map.get(heading_entry.get("page_group"))
                if heading_group is None:
                    for duplicated in duplicated_groups:
                        _remove_layer_group(duplicated)
                    return False, "page group not found for copied page heading"
                ok, reason = _render_performance_patch_cell(heading_group, heading_entry, tab_name, None)
                if not ok:
                    for duplicated in duplicated_groups:
                        _remove_layer_group(duplicated)
                    return False, reason
                patched_refs.append(pseudo_heading_ref)

        sheet_payload = _sheet_render_manifest(tab_name)
        sheet_payload["performance"] = {
            "copied_from": base.get("sheet"),
            "patched_cells": patched_refs,
            "mode": "bundle_copy_cell_patch",
        }
        sheet_payload["cells"] = {}
        for cell_ref, entries in (base_manifest.get("cells", {}) or {}).items():
            copied_entries = []
            for entry in entries:
                clone = dict(entry)
                clone["page_group"] = _performance_bundle_name(clone.get("page_group"), base.get("sheet"), tab_name)
                if cell_ref == pseudo_heading_ref and cell_ref in patched_refs:
                    clone["source_text"] = tab_name
                elif cell_ref in patched_refs:
                    clone["source_text"] = current_values.get((
                        int(re.sub(r"[^0-9]", "", cell_ref) or 0),
                        column_index_from_string(re.sub(r"[^A-Za-z]", "", cell_ref) or "A"),
                    ), clone.get("source_text", ""))
                copied_entries.append(clone)
            sheet_payload["cells"][cell_ref] = copied_entries
        _hide_main_sheet_groups(duplicated_groups)
        patch_note = f"patched {', '.join(patched_refs)}" if patched_refs else "no cell patches needed"
        edit_log.append(f"Performance Mode copied {base.get('sheet')} bundle to {tab_name}; {patch_note}")
        return True, ""

    def _register_performance_base(tab_name, sheet_fmt, page_min_col, page_max_col, sheet_groups, tables, sheet_mapped_table_records):
        if not performance_mode or sheet_mapped_table_records:
            return
        try:
            payload = _sheet_render_manifest(tab_name)
            payload["performance"].update({
                "heading_signature": _performance_heading_signature(sheet_fmt, page_min_col, page_max_col),
                "layout_cell_count": len(_performance_sheet_value_map(sheet_fmt, page_min_col, page_max_col)),
            })
            performance_bases.append({
                "sheet": tab_name,
                "heading_signature": _performance_heading_signature(sheet_fmt, page_min_col, page_max_col),
                "layout_signature": _performance_layout_signature(sheet_fmt, page_min_col, page_max_col),
                "merged_signature": _performance_merged_signature(sheet_fmt),
                "values": _performance_sheet_value_map(sheet_fmt, page_min_col, page_max_col),
                "groups": list(sheet_groups or []),
                "tables": [dict(table) for table in (tables or [])],
            })
        except Exception as exc:
            edit_log.append(f"Performance Mode could not register base sheet {tab_name}: {exc}")

    def _preimport_icons():
        """Scan Excel for all icon tokens and batch-import them before rendering."""
        try:
            tokens = scan_excel_icon_tokens(excel_path)
            if not tokens:
                return
            pending = []
            seen_paths = set()
            for token in tokens:
                if token in icon_cache:
                    continue
                icon_path = resolve_icon_path(token, icon_folder, icon_mappings)
                if not icon_path or not os.path.exists(icon_path):
                    continue
                path_key = os.path.normcase(os.path.normpath(icon_path))
                if path_key in seen_paths:
                    continue
                seen_paths.add(path_key)
                pending.append((token, icon_path))
            if not pending:
                return
            _emit_progress("preimport_icons", total=len(pending))
            for batch_start in range(0, len(pending), 20):
                batch = pending[batch_start:batch_start + 20]
                jsx_parts = ['(function(){ var doc = app.activeDocument;']
                for icon_name, icon_path in batch:
                    safe_path = json.dumps(icon_path)
                    safe_name = json.dumps("__PII_" + icon_name)
                    jsx_parts.append(f'''
                        var d = new ActionDescriptor();
                        d.putPath(charIDToTypeID("null"), new File({safe_path}));
                        executeAction(charIDToTypeID("Plc "), d, DialogModes.NO);
                        doc.activeLayer.name = {safe_name};
                    ''')
                jsx_parts.append('})();')
                try:
                    app.doJavaScript('\n'.join(jsx_parts))
                except Exception as exc:
                    print(f"[Icon] Batch pre-import failed at {batch_start}: {exc}")
                    continue
                prefix = "__PII_"
                for l in list(doc.artLayers):
                    if l.name.startswith(prefix):
                        real_name = l.name[len(prefix):]
                        l.name = real_name
                        try:
                            l.move(asset_group, ps.ElementPlacement.PlaceInside)
                            b = l.bounds
                            icon_cache[real_name] = {
                                'layer': l,
                                'orig_h': float(b[3]) - float(b[1]),
                                'orig_w': float(b[2]) - float(b[0])
                            }
                        except Exception as exc2:
                            print(f"[Icon] Cache failed for {real_name}: {exc2}")
            print(f"[Icon] Pre-imported {len(icon_cache)} unique icons")
        except Exception as exc:
            print(f"[Icon] Pre-import failed: {exc}")

    # Pre-import all icons before the sheet loop to avoid on-demand imports
    # during rendering. Each batch uses one JSX call instead of one-per-icon.
    _preimport_icons()

    # --- MAIN LOOP PER SHEET ---
    for tab_name in wb.sheetnames:
        if _cancel_requested():
            cancel_requested = True
            edit_log.append("Build stopped by user before rendering next sheet.")
            break
        if tab_name in tabs_to_keep:
            print(f"[Skip] {tab_name} unchanged — keeping existing.")
            profiler.inc("sheets_skipped")
            continue
        if tab_name not in tabs_to_rebuild:
            print(f"[Skip] {tab_name} not in rebuild list.")
            profiler.inc("sheets_skipped")
            continue





        sheet = wb[tab_name]
        completed_render_tabs += 1
        sheet_groups = []
        _emit_progress(
            "sheet_start",
            sheet=tab_name,
            index=completed_render_tabs,
            total=total_render_tabs,
        )
        profiler.start(f"sheet:{tab_name}")
        sheet_fmt = wb_formatted[tab_name] if tab_name in wb_formatted.sheetnames else sheet
        is_game_rules_page = _is_game_rules_sheet_name(tab_name)

        page_min_row, page_max_row, page_min_col, page_max_col = _render_window_for_sheet(
            dynamic_settings, tab_name, max_col_limit, sheet,
        )
        if page_min_row > 1 or page_max_row < (sheet.max_row or 1):
            edit_log.append(
                f"Render window for {tab_name}: rows {page_min_row}-{page_max_row}, "
                f"cols {page_min_col}-{page_max_col}"
            )
        heading_alignment = _page_alignment(tab_name, "heading", "center")
        body_alignment = _page_alignment(tab_name, "body", "center")
        table_alignment = _page_alignment(tab_name, "table", "center")
        bottom_alignment = _page_alignment(tab_name, "bottom", "center")
        paytable_notes_alignment = _page_alignment(tab_name, "paytable_notes", "center")
        heading_left_margin = _page_metric(tab_name, "heading_left_margin", margin_x)
        body_left_margin = _page_metric(tab_name, "body_left_margin", margin_x)
        heading_box_left, heading_box_width = _role_box_for_alignment(heading_alignment, heading_left_margin)
        body_box_left, body_box_width = _role_box_for_alignment(body_alignment, body_left_margin)
        _loop_line_spacing = line_spacing
        _loop_para_spacing = para_spacing
        _loop_bottom_margin = bottom_margin
        _loop_max_y_limit = max_y_limit
        page_heading_size = _page_heading_size(tab_name, h_size)
        if page_heading_size != h_size:
            edit_log.append(f"Page heading size override for {tab_name}: {page_heading_size}px")
        _ps_ov = _page_style_override_for(tab_name)
        _p_h_font = str(_ps_ov.get("h_font") or h_font)
        if _p_h_font != h_font:
            try:
                _p_h_font = resolve_photoshop_font(app, _p_h_font)
            except Exception:
                pass
        try:
            _p_h_size = int(float(_ps_ov.get("h_size") or page_heading_size))
        except Exception:
            _p_h_size = page_heading_size
        _p_h_rgb = _ps_ov.get("h_rgb") or h_rgb
        if isinstance(_p_h_rgb, str):
            _hx = re.match(r"#?([0-9A-Fa-f]{6})", _p_h_rgb.strip())
            _p_h_rgb = tuple(int(_hx.group(1)[i:i + 2], 16) for i in (0, 2, 4)) if _hx else h_rgb
        else:
            try:
                _vals = list(_p_h_rgb)
                if len(_vals) >= 3:
                    _p_h_rgb = tuple(max(0, min(255, int(v))) for v in _vals[:3])
            except Exception:
                _p_h_rgb = h_rgb
        _p_b_font = str(_ps_ov.get("b_font") or b_font)
        if _p_b_font != b_font:
            try:
                _p_b_font = resolve_photoshop_font(app, _p_b_font)
            except Exception:
                pass
        try:
            _p_b_size = int(float(_ps_ov.get("b_size") or b_size))
        except Exception:
            _p_b_size = int(b_size)
        _p_b_rgb = _ps_ov.get("b_rgb") or b_rgb
        if isinstance(_p_b_rgb, str):
            _bx = re.match(r"#?([0-9A-Fa-f]{6})", _p_b_rgb.strip())
            _p_b_rgb = tuple(int(_bx.group(1)[i:i + 2], 16) for i in (0, 2, 4)) if _bx else b_rgb
        else:
            try:
                _vals = list(_p_b_rgb)
                if len(_vals) >= 3:
                    _p_b_rgb = tuple(max(0, min(255, int(v))) for v in _vals[:3])
            except Exception:
                _p_b_rgb = b_rgb
        if _ps_ov:
            edit_log.append(f"Page style override for {tab_name}: heading={_p_h_font} {_p_h_size}px "
                            f"body={_p_b_font} {_p_b_size}px")
            edit_log.append(f"Page heading size override for {tab_name}: {page_heading_size}px")
        game_rules_text_style = dynamic_settings.get("game_rules_text_style") or body_style
        game_rules_legal_style = dynamic_settings.get("game_rules_legal_style") or body_style
        section_heading_cells = set(_cell_coords_for_sheet(
            dynamic_settings.get("page_heading_cell_overrides", ""),
            tab_name,
        ))
        section_subheading_cells = set(_cell_coords_for_sheet(
            dynamic_settings.get("page_subheading_cell_overrides", ""),
            tab_name,
        ))
        multi_heading_map = _page_multi_heading_overrides(
            dynamic_settings.get("page_multi_heading_overrides", ""),
        )
        multi_heading_entries = multi_heading_map.get(tab_name, [])
        multi_heading_coords = {coord for _label, coord in multi_heading_entries}
        section_heading_cells.update(multi_heading_coords)
        text_rectangle_cells = set(_cell_coords_for_sheet(
            (table_style or {}).get("text_rectangle_cells", ""),
            tab_name,
        ))
        subheading_font_name = str(dynamic_settings.get("subheading_font") or _p_h_font)
        try:
            subheading_font_size = max(8, int(dynamic_settings.get("subheading_size") or max(8, int(page_heading_size * 0.65))))
        except Exception:
            subheading_font_size = max(8, int(page_heading_size * 0.65))
        subheading_color = _solid_color_from_rgb(dynamic_settings.get("subheading_rgb") or _p_h_rgb)
        subheading_style = dynamic_settings.get("subheading_style")
        bingo_page = _is_bingo_rules_sheet_name(tab_name)
        try:
            bingo_body_size = int(dynamic_settings.get("bingo_rules_body_size") or 0)
        except Exception:
            bingo_body_size = 0
        bingo_one_page = bool(dynamic_settings.get("bingo_rules_one_page", True))
        bingo_alignment_overrides = _bingo_merged_alignments_psd(
            dynamic_settings,
            tab_name,
        ) if bingo_page else {}
        bingo_body_range_coords = set(_cell_coords_for_sheet(
            dynamic_settings.get("bingo_rules_body_ranges", ""),
            tab_name,
        )) if bingo_page else set()
        try:
            bingo_left_margin = int(dynamic_settings.get("bingo_rules_left_margin") or 0)
        except Exception:
            bingo_left_margin = 0
        try:
            bingo_line_spacing = int(dynamic_settings.get("bingo_rules_line_spacing") or 0)
        except Exception:
            bingo_line_spacing = 0
        try:
            bingo_para_spacing = int(dynamic_settings.get("bingo_rules_para_spacing") or 0)
        except Exception:
            bingo_para_spacing = 0
        try:
            bingo_bottom_margin = int(dynamic_settings.get("bingo_rules_bottom_margin") or 0)
        except Exception:
            bingo_bottom_margin = 0
        if bingo_page:
            if bingo_left_margin > 0:
                body_left_margin = float(bingo_left_margin)
                body_box_left, body_box_width = _role_box_for_alignment(body_alignment, body_left_margin)
            if bingo_line_spacing > 0:
                line_spacing = bingo_line_spacing
            if bingo_para_spacing > 0:
                para_spacing = bingo_para_spacing
            if bingo_bottom_margin > 0:
                bottom_margin = bingo_bottom_margin
                max_y_limit = c_height - bottom_margin

        sheet_mapped_table_records = [
            record for record in mapped_table_records
            if not record.get("error") and template_matches_sheet(record, tab_name)
        ]

        planned_performance_copy = performance_similarity_plan.get(tab_name) or {}
        if performance_mode and planned_performance_copy and not is_game_rules_page and not bingo_page:
            edit_log.append(
                f"Performance plan for {tab_name}: copy {planned_performance_copy.get('base')} "
                f"and patch {_performance_cells_label(planned_performance_copy.get('changed_coords'))}"
            )
            copied, perf_reason = _try_performance_copy_from_base(
                tab_name,
                sheet_fmt,
                page_min_col,
                page_max_col,
                [],
                sheet_mapped_table_records,
                planned_base_name=planned_performance_copy.get("base"),
                planned_changed_coords=planned_performance_copy.get("changed_coords"),
            )
            if copied:
                profiler.inc("sheets_rendered")
                profiler.inc("performance_mode_copies")
                profiler.stop(f"sheet:{tab_name}")
                _emit_progress(
                    "sheet_done",
                    sheet=tab_name,
                    index=completed_render_tabs,
                    total=total_render_tabs,
                )
                continue
            edit_log.append(f"Performance fallback for {tab_name}: {perf_reason or 'unknown reason'}")

        # ------------------------------------------------------------
        # OPTIONAL DYNAMIC-PAGE ADDON
        # ------------------------------------------------------------
        # This is the only branch added to the proven normal renderer.
        # It uses an exact tab-name match. Every unmatched sheet continues
        # through the original text/icon/table code below without changes.
        dynamic_runtime = dict(dynamic_settings or {})
        # Row Gap ('line_gap') is the SINGLE row-spacing source for this sheet
        # (empty field -> the 30px PSD-compatible default). _line_step_self and
        # the row_gap_margin reflow below both read _row_gap_state.
        _row_gap_state["px"] = _effective_row_gap(dynamic_runtime.get("line_gap"))
        dynamic_runtime.update({
            'canvas_width': c_width,
            'canvas_height': c_height,
            'heading_font': _p_h_font,
            'body_font': _p_b_font,
            'heading_size': page_heading_size,
            'heading_icon_height': h_icon_h,
            'body_size': _p_b_size,
            'heading_rgb': tuple(_p_h_rgb),
            'body_rgb': tuple(_p_b_rgb),
            'asset_folder': icon_folder,
            'heading_style': heading_style,
            'body_style': body_style,
            'game_rules_text_style': game_rules_text_style,
            'game_rules_legal_style': game_rules_legal_style,
            'icon_style': icon_style,
            'icon_mappings': dict(icon_mappings or {}),
            'icon_size_overrides': dict(icon_size_overrides or {}),
            'bottom_margin': bottom_margin,
            'alignment_settings': alignment_settings,
            'page_alignment': {
                'heading': heading_alignment,
                'body': body_alignment,
                'table': table_alignment,
                'bottom': bottom_alignment,
                'paytable_notes': paytable_notes_alignment,
                'heading_left_margin': heading_left_margin,
                'body_left_margin': body_left_margin,
            },
            'paytable_notes_alignment': paytable_notes_alignment,
            '_report_collector': report_collector,
        })
        if (not is_game_rules_page) and should_handle_sheet(tab_name, dynamic_runtime):
            tab_group = doc.layerSets.add()
            sheet_groups.append(tab_group)
            tab_group.name = f"{tab_name} (Page 1 Copy {selected_copy_stamp})" if preserve_selected_existing else tab_name
            _append_sheet_group_manifest(tab_name, tab_group.name)
            set_layer_color(tab_group, app, 1 if tab_name in tabs_to_rebuild else 0)
            profiler.start("dynamic_page_render")
            render_dynamic_sheet(
                doc=doc,
                app=app,
                worksheet=sheet,
                sheet_name=tab_name,
                settings=dynamic_runtime,
                parent_group=tab_group,
            )
            profiler.stop("dynamic_page_render")
            line_spacing = _loop_line_spacing; para_spacing = _loop_para_spacing; bottom_margin = _loop_bottom_margin; max_y_limit = _loop_max_y_limit
            edit_log.append(f"Rendered dynamic addon for exact matched tab: {tab_name}")
            _mega_sheet_finish(app, doc)
            _hide_main_sheet_groups(sheet_groups)
            edit_log.append(f"Hid completed page group(s): {tab_name}")
            profiler.inc("sheets_rendered")
            profiler.stop(f"sheet:{tab_name}")
            _emit_progress(
                "sheet_done",
                sheet=tab_name,
                index=completed_render_tabs,
                total=total_render_tabs,
            )
            continue
        if is_game_rules_page and should_handle_sheet(tab_name, dynamic_runtime):
            edit_log.append(f"GameRules renderer took priority over dynamic addon for tab: {tab_name}")

        tables = []
        if enable_tables and not bingo_page:
            profiler.start("table_detection")
            manual_ranges = _manual_table_ranges_for_sheet(
                (table_style or {}).get("manual_table_ranges", ""),
                tab_name,
            )
            manual_tables = manual_tables_from_ranges(sheet_fmt, manual_ranges, page_max_col) if manual_ranges else []
            auto_tables = detect_tables_in_sheet(sheet_fmt, page_max_col, min_col_limit=page_min_col)
            if auto_tables and (page_min_row > 1 or page_max_row < (sheet.max_row or 1)):
                auto_tables = [
                    t for t in auto_tables
                    if int(t.get("start_row", 0)) <= page_max_row and int(t.get("end_row", 0)) >= page_min_row
                ]
            if manual_tables:
                auto_tables = [
                    table for table in auto_tables
                    if not any(_table_rectangles_overlap(table, manual_table) for manual_table in manual_tables)
                ]
            tables = sorted(manual_tables + auto_tables, key=lambda item: (item["start_row"], item.get("min_col", 0)))
            excel_fill_ranges = _manual_table_ranges_for_sheet(
                (table_style or {}).get("table_excel_fill_ranges", ""),
                tab_name,
            )
            excel_fill_hex_overrides = _table_excel_fill_hex_overrides_for_sheet(
                (table_style or {}).get("table_excel_fill_hex_overrides", ""),
                tab_name,
            )
            excel_font_color_ranges = _manual_table_ranges_for_sheet(
                (table_style or {}).get("table_excel_font_color_ranges", ""),
                tab_name,
            )
            excel_font_hex_overrides = _table_excel_font_hex_overrides_for_sheet(
                (table_style or {}).get("table_excel_font_hex_overrides", ""),
                tab_name,
            )
            if excel_fill_ranges:
                for table in tables:
                    if _table_matches_any_range(table, excel_fill_ranges):
                        table["use_excel_fill_colors"] = True
                        if excel_fill_hex_overrides:
                            table["excel_fill_hex_overrides"] = excel_fill_hex_overrides
                if any(table.get("use_excel_fill_colors") for table in tables):
                    edit_log.append(f"Excel fill colors enabled for selected table range(s) on {tab_name}")
            if excel_font_color_ranges:
                for table in tables:
                    if _table_matches_any_range(table, excel_font_color_ranges):
                        table["use_excel_font_colors"] = True
                        if excel_font_hex_overrides:
                            table["excel_font_hex_overrides"] = excel_font_hex_overrides
                if any(table.get("use_excel_font_colors") for table in tables):
                    edit_log.append(f"Excel font colors enabled for selected table range(s) on {tab_name}")
            profiler.stop("table_detection")

        mapped_table_by_trigger = {}
        if enable_tables:
            for record in sheet_mapped_table_records:
                trigger_row = trigger_row_for_template(record)
                if trigger_row > 0:
                    mapped_table_by_trigger.setdefault(trigger_row, []).append(record)

        rendered_mapped_table_ids = set()
        rendered_mapped_source_rows = set()
        rendered_mapped_claimed_rows = set()

        def _collect_mapped_source_rows(record, ws):
            """Fallback: collect source rows when source_row_range_for_template can't resolve named ranges."""
            rows = set()
            spec = record.get("spec") or {}
            template = record.get("template") or {}
            sources = []
            raw_sr = spec.get("source_range")
            if raw_sr:
                sources.append(str(raw_sr).strip())
            for mapping in (spec.get("mappings") or []):
                s = str((mapping or {}).get("source") or "").strip()
                if s:
                    sources.append(s)
            for slot_name, slot_def in (template.get("slots") or {}).items():
                s = str((slot_def or {}).get("source") or "").strip()
                if s:
                    sources.append(s)
            for table_name, table_spec in (template.get("table_templates") or {}).items():
                s = str((table_spec or {}).get("source_range") or "").strip()
                if s:
                    sources.append(s)
            for source in sources:
                bounds = direct_range_bounds(source)
                if bounds:
                    rows.add(bounds[1])
                    rows.add(bounds[3])
                    continue
                try:
                    key = str(source).strip()
                    defined_names = ws.parent.defined_names
                    if key not in defined_names:
                        continue
                    destinations = list(defined_names[key].destinations)
                    for _sheet_name, coordinate in destinations:
                        try:
                            _min_c, min_r, _max_c, max_r = range_boundaries(coordinate)
                            rows.update(range(min_r, max_r + 1))
                        except Exception:
                            pass
                except Exception:
                    pass
            if not rows:
                return None
            return (min(rows), max(rows))

        mapped_table_ranges = []
        mapped_table_claimed_ranges = []
        for record in sheet_mapped_table_records:
            source_rows = source_row_range_for_template(record)
            if not source_rows:
                try:
                    source_rows = _collect_mapped_source_rows(record, sheet_fmt)
                except Exception:
                    pass
            if source_rows:
                mapped_table_claimed_ranges.append(source_rows)
                consumed = mapped_record_consumed_rows(record)
                if consumed:
                    mapped_table_ranges.append((min(consumed), max(consumed)))
                edit_log.append(f"TRACE: mapped_table_range added: {source_rows} for {record.get('table_name', '?')}")
            else:
                edit_log.append(f"TRACE: No source_rows for mapped_table_ranges for {record.get('table_name', '?')}")

        def _row_ranges_overlap(a_start, a_end, b_start, b_end):
            try:
                return not (int(a_end) < int(b_start) or int(a_start) > int(b_end))
            except Exception:
                return False

        if enable_tables and mapped_table_claimed_ranges and tables:
            overlap_count = sum(
                1
                for table in tables
                if any(
                    _row_ranges_overlap(
                        table.get("start_row", 0),
                        table.get("end_row", 0),
                        mapped_start,
                        mapped_end,
                    )
                    for mapped_start, mapped_end in mapped_table_claimed_ranges
                )
            )
            if overlap_count:
                edit_log.append(f"JSON mapped table has priority over {overlap_count} overlapping auto table trigger(s) on {tab_name}")

        table_row_ranges = []
        for t in tables:
            table_row_ranges.append((t['start_row'], t['end_row']))

        def _row_is_inside_mapped_table(row_number):
            for r_start, r_end in mapped_table_ranges:
                if r_start <= row_number <= r_end:
                    return True
            return False


        page_num = 1
        tab_group = doc.layerSets.add()
        sheet_groups.append(tab_group)
        tab_group.name = f"{tab_name} (Page 1 Copy {selected_copy_stamp})" if preserve_selected_existing else tab_name
        _append_sheet_group_manifest(tab_name, tab_group.name)
        # Red label (1) for changed tabs, no color (0) for new/unchanged
        if tab_name in tabs_to_rebuild:
            set_layer_color(tab_group, app, 1)
            edit_log.append(f"Created new group [CHANGED]: {tab_group.name}")
        else:
            set_layer_color(tab_group, app, 0)
            edit_log.append(f"Created new group: {tab_group.name}")
        current_y = heading_top_margin
        current_y_is_visual_top = False
        current_heading_raw = ""
        heading_image_path = _page_heading_image_path(tab_name)

        def _place_heading_image(parent_group, image_path, top_y):
            if not image_path or not os.path.isfile(image_path):
                return None
            normalized_path = os.path.abspath(image_path).replace('\\', '/')
            jsx_path = json.dumps(normalized_path)
            try:
                app.doJavaScript(f'''
                    var __doch = app.activeDocument;
                    var idPlc = charIDToTypeID("Plc ");
                    var desc = new ActionDescriptor();
                    desc.putPath(charIDToTypeID("null"), new File({jsx_path}));
                    executeAction(idPlc, desc, DialogModes.NO);
                ''')
                layer = doc.activeLayer
            except Exception:
                try:
                    _PROFILER.inc("app_open_calls")
                    image_doc = app.open(image_path)
                    image_doc.activeLayer.duplicate(doc)
                    image_doc.close(2)
                    app.activeDocument = doc
                    layer = doc.activeLayer
                except Exception as exc:
                    print(f"[Heading Image] Could not place {image_path}: {exc}")
                    return None
            layer.name = "Heading Image"
            try:
                layer.move(parent_group, ps.ElementPlacement.PlaceInside)
            except Exception:
                pass
            bounds = _bounds_to_floats(layer.bounds)
            if not bounds:
                return None
            if heading_image_height > 0:
                current_h = max(1.0, bounds[3] - bounds[1])
                scale_pct = (float(heading_image_height) / current_h) * 100.0
                try:
                    layer.resize(scale_pct, scale_pct)
                    bounds = _bounds_to_floats(layer.bounds) or bounds
                except Exception:
                    pass
            width = max(1.0, bounds[2] - bounds[0])
            h_box_left, h_box_width = _line_alignment_box(heading_alignment, heading_box_left, heading_box_width)
            target_left = _line_start_x(width, heading_alignment, h_box_left, h_box_width)
            try:
                layer.translate(target_left - bounds[0], float(top_y) - bounds[1])
            except Exception:
                pass
            return _bounds_to_floats(layer.bounds)

        def _ensure_text_baseline(font_size):
            nonlocal current_y, current_y_is_visual_top
            if current_y_is_visual_top:
                current_y = _baseline_from_top(current_y, font_size)
                current_y_is_visual_top = False
            return current_y

        def _consume_visual_top_for_table():
            nonlocal current_y_is_visual_top
            was_visual_top = bool(current_y_is_visual_top)
            current_y_is_visual_top = False
            return was_visual_top

        def _heading_text_box():
            if heading_keep_one_line:
                side_margin = max(0, int(heading_one_line_margin))
                return float(side_margin), max(50.0, float(c_width) - (float(side_margin) * 2.0))
            return heading_box_left, heading_box_width

        def _fit_heading_size_one_line(heading_text, base_size, base_icon_h):
            try:
                base_size = max(8, int(base_size))
            except Exception:
                base_size = max(8, int(_p_h_size))
            try:
                base_icon_h = max(1, int(base_icon_h))
            except Exception:
                base_icon_h = max(1, int(h_icon_h))
            if not heading_keep_one_line:
                return base_size, base_icon_h
            _box_left, box_width = _heading_text_box()
            target_width = max(50, int(box_width))
            size = base_size
            while size > 8:
                ratio = float(size) / max(1.0, float(base_size))
                icon_h = max(1, int(round(float(base_icon_h) * ratio)))
                local_gap = _heading_gap_for(size)
                lines = _build_parsed_lines(
                    heading_text, size, _p_h_font, icon_h,
                    local_gap_px=local_gap,
                    local_max_width=target_width,
                    use_size_overrides=False,
                )
                widest = max((float(line.get("width", 0.0)) for line in lines), default=0.0)
                if len(lines) <= 1 and widest <= target_width:
                    return size, icon_h
                size -= 1
            ratio = float(size) / max(1.0, float(base_size))
            return size, max(1, int(round(float(base_icon_h) * ratio)))

        def _render_heading_block(raw_text, continued=False, add_body_gap=True, cell_ref=None, skip_image=False):
            nonlocal current_y, current_y_is_visual_top
            heading_text = _prepare_heading_text(raw_text)
            group_name = "Heading (Continued)" if continued else (_cell_render_group_name(cell_ref, "Heading") if cell_ref else "Heading")
            h_group = tab_group.layerSets.add()
            h_group.name = group_name
            heading_start_y = current_y
            render_heading_size = page_heading_size
            render_heading_icon_h = h_icon_h
            rendered_image = False
            if heading_image_path and not skip_image:
                image_bounds = _place_heading_image(h_group, heading_image_path, current_y)
                if image_bounds:
                    rendered_image = True
                    current_y = image_bounds[3] + (int(heading_to_body_gap) if add_body_gap else 0)
                    current_y_is_visual_top = bool(add_body_gap)
            if not rendered_image:
                h_text_group = h_group.layerSets.add()
                h_text_group.name = "Heading Text"
                h_symbol_group = h_group.layerSets.add()
                h_symbol_group.name = "Heading Symbols"
                render_heading_size, render_heading_icon_h = _fit_heading_size_one_line(
                    heading_text,
                    page_heading_size,
                    h_icon_h,
                )
                if render_heading_size != page_heading_size:
                    edit_log.append(f"Heading one-line fit for {tab_name}: {page_heading_size}px -> {render_heading_size}px")
                heading_symbol_gap = _heading_gap_for(render_heading_size)
                h_render_left, h_render_width = _heading_text_box()
                heading_baseline_y = _baseline_from_top(heading_start_y, render_heading_size)
                current_y = draw_parsed_block(
                    heading_text, render_heading_size, _p_h_font, render_heading_icon_h, color_h, h_group, heading_baseline_y,
local_gap_px=heading_symbol_gap,
                    text_group=h_text_group, icon_group=h_symbol_group,
                    local_keyword_colors={},
                    use_size_overrides=False,
                    local_max_width=h_render_width,
                    local_alignment=heading_alignment,
                    local_box_left=h_render_left,
                    local_box_width=h_render_width,
                )
                apply_style_to_group_text_layers(app, doc, h_text_group, heading_style)
                h_box_left, h_box_width = _line_alignment_box(heading_alignment, h_render_left, h_render_width)
                h_bounds = _align_group_horizontally(h_group, h_box_left, h_box_width, heading_alignment)
                if h_bounds:
                    current_y = h_bounds[3] + (int(heading_to_body_gap) if add_body_gap else 0)
                else:
                    current_y += int(heading_to_body_gap) if add_body_gap else 0
                current_y_is_visual_top = bool(add_body_gap)
            if cell_ref:
                _record_cell_render(
                    tab_name, cell_ref, "heading", heading_text, tab_group.name, h_group,
                    heading_start_y, render_heading_size, _p_h_font, render_heading_icon_h, color_h,
                    heading_alignment, _heading_text_box()[1], _heading_text_box()[0], _heading_text_box()[1],
                    None, safe_patch=(not rendered_image),
                )
            return h_group

        def _start_new_page():
            nonlocal page_num, tab_group, current_y, current_y_is_visual_top
            page_num += 1
            tab_group = doc.layerSets.add()
            sheet_groups.append(tab_group)
            tab_group.name = f"{tab_name} (Page {page_num} Copy {selected_copy_stamp})" if preserve_selected_existing else f"{tab_name} (Page {page_num})"
            _append_sheet_group_manifest(tab_name, tab_group.name)
            if tab_name in tabs_to_rebuild:
                set_layer_color(tab_group, app, 1)
            else:
                set_layer_color(tab_group, app, 0)
            edit_log.append(f"Created new group: {tab_group.name}")
            current_y = heading_top_margin
            current_y_is_visual_top = False

            if current_heading_raw or heading_image_path:
                h_group = _render_heading_block(current_heading_raw or tab_name, continued=True, add_body_gap=False)

                # Place (Continued) using real rendered heading bounds, not baseline math.
                # This fixes the label floating too far below styled or tall headings.
                continued_font_size = max(8, _p_b_size - 10)
                continued_text = "(Continued)"
                h_bounds = _collect_group_bounds(h_group)
                heading_bottom = h_bounds[3] if h_bounds else (current_y - line_spacing)
                continued_y = _baseline_from_top(heading_bottom + int(continued_gap), continued_font_size)
                c_layer = tab_group.artLayers.add()
                c_layer.kind = ps.LayerKind.TextLayer
                c_layer.name = "Continued Label"
                c_layer.textItem.contents = continued_text.replace(" ", "\xa0")
                c_layer.textItem.size = _px_to_pt(continued_font_size, c_layer)
                c_layer.textItem.color = color_b
                c_layer.textItem.font = _p_b_font
                c_layer.textItem.position = [
                    (c_width - measure_text(continued_text, continued_font_size, _p_b_font)) / 2, continued_y]
                try:
                    c_bounds = _bounds_to_floats(c_layer.bounds)
                    c_bottom = c_bounds[3] if c_bounds else continued_y
                except Exception:
                    c_bottom = continued_y
                current_y = c_bottom + int(heading_to_body_gap)
                current_y_is_visual_top = True

        def _clamp_block_never_overlaps(layer_group, baseline_y, keyword_colors, font_size):
            """Never-overlap guarantee between rendered blocks.

            Snaps the running baseline to the REAL bottom of the text group
            that was just rendered (Photoshop reports actual glyph bounds,
            which can exceed the 1.2x auto-leading estimate). Without this,
            the next Excel cell's first baseline could sit above the previous
            block's descenders. In mega-batch mode the text layers are only
            materialised at flush time, so flush the pending spec batch first.
            """
            try:
                if render_backend is not None:
                    return baseline_y
                pending_batch = _mega_pending_batch(app, doc, keyword_colors)
                if pending_batch is not None:
                    flush_text_spec_batch(pending_batch, app, doc)
                real_bounds = _collect_group_bounds(layer_group)
                if not real_bounds or real_bounds[3] is None:
                    return baseline_y
                try:
                    ascent_px = max(4.0, float(font_size) * 0.8)
                except Exception:
                    ascent_px = 20.0
                return max(float(baseline_y), float(real_bounds[3]) + ascent_px)
            except Exception:
                return baseline_y

        def draw_parsed_block_paged(raw_string, font_size, f_name, target_icon_h, target_color, start_y,
                                    local_max_width=None, local_line_step=None, local_alignment="center",
                                    local_box_left=None, local_box_width=None, local_text_style=None,
                                    local_icon_style=None, source_cell_ref=None, source_role="body",
                                    local_keyword_colors=_default_keyword_colors,
                                    prev_visual_bottom=None):
            """Render normal body text across pages without breaking the Excel order.

            If only one or two lines fit after a table, they are rendered on the
            same page. If the block is longer than the remaining safe area, only
            the overflow continues on the next page.
            """
            nonlocal current_y, tab_group
            lines = _build_parsed_lines(
                raw_string, font_size, f_name, target_icon_h,
                local_max_width=local_max_width,
                use_original_icon_size=body_icons_use_original_size,
            )
            if not lines:
                return start_y

            idx = 0
            current_y = start_y

            while idx < len(lines):
                if not _line_fits_at(current_y, font_size, line=lines[idx], local_line_step=local_line_step):
                    _start_new_page()

                page_start_y = current_y
                page_lines = []
                probe_y = current_y
                while idx < len(lines):
                    probe_line = lines[idx]
                    if page_lines and not _line_fits_at(probe_y, font_size, line=probe_line, local_line_step=local_line_step):
                        break
                    if not page_lines and not _line_fits_at(probe_y, font_size, line=probe_line, local_line_step=local_line_step):
                        break
                    page_lines.append(lines[idx])
                    idx += 1
                    probe_after = _line_icon_height(lines[idx]) if idx < len(lines) else 0.0
                    probe_next = lines[idx] if idx < len(lines) else None
                    probe_y += _line_step_for_line(probe_line, font_size, next_icon_h=probe_after, local_line_step=local_line_step, font_name=f_name, next_line=probe_next)

                # If nothing fits, move to a fresh page and force one line there
                # to avoid an infinite loop with huge fonts / very small canvases.
                if not page_lines:
                    _start_new_page()
                    page_start_y = current_y
                    page_lines = [lines[idx]]
                    idx += 1

                body_block = tab_group.layerSets.add()
                body_block_name = "Body Text Block"
                if source_cell_ref:
                    part_count = len(
                        _sheet_render_manifest(tab_name).get("cells", {}).get(str(source_cell_ref), [])
                    ) + 1
                    base_group_name = _cell_render_group_name(source_cell_ref, source_role)
                    body_block_name = base_group_name if part_count <= 1 else f"{base_group_name}-Part{part_count}"
                body_block.name = body_block_name
                active_keyword_colors = {} if str(source_role or "").casefold() == "heading" else local_keyword_colors
                effective_prev_bottom = prev_visual_bottom if page_start_y == start_y else None
                current_y = _render_centered_prepared_lines(
                    page_lines, font_size, f_name, target_icon_h, target_color, body_block, page_start_y,
                    local_line_step=local_line_step,
                    local_keyword_colors=active_keyword_colors,
                    local_alignment=local_alignment, local_box_left=local_box_left, local_box_width=local_box_width,
                    local_body_style=local_text_style if local_text_style is not None else body_style,
                    local_icon_style=local_icon_style if local_icon_style is not None else icon_style,
                    prev_visual_bottom=effective_prev_bottom,
                )
                current_y = _clamp_block_never_overlaps(body_block, current_y, active_keyword_colors, font_size)
                if source_cell_ref:
                    _record_cell_render(
                        tab_name, source_cell_ref, source_role, raw_string, body_block_name, body_block,
                        page_start_y, font_size, f_name, target_icon_h, target_color,
                        local_alignment, local_max_width, local_box_left, local_box_width,
                        local_line_step, safe_patch=(str(source_role).lower() in ("bodytextandicons", "body", "subheading"))
                    )

                if idx < len(lines):
                    _start_new_page()

            return current_y

        def _draw_text_rectangle_layer(parent_group, left, top, right, bottom, fill_rgb, fill_opacity, stroke_rgb, stroke_width, name):
            left = int(round(left))
            top = int(round(top))
            right = int(round(right))
            bottom = int(round(bottom))
            if right <= left or bottom <= top:
                return None
            fill_rgb = tuple(int(v) for v in (fill_rgb or (20, 20, 30)))
            stroke_rgb = tuple(int(v) for v in (stroke_rgb or (255, 255, 255)))
            fill_opacity = max(0, min(100, int(fill_opacity or 0)))
            stroke_width = max(0, int(stroke_width or 0))
            safe_name = json.dumps(str(name or "Text Rectangle"))
            jsx = f"""
                var doc = app.activeDocument;
                var layer = doc.artLayers.add();
                layer.name = {safe_name};
                var region = [[{left},{top}],[{right},{top}],[{right},{bottom}],[{left},{bottom}]];
                doc.selection.select(region);
                if ({fill_opacity} > 0) {{
                    var fillColor = new SolidColor();
                    fillColor.rgb.red = {fill_rgb[0]};
                    fillColor.rgb.green = {fill_rgb[1]};
                    fillColor.rgb.blue = {fill_rgb[2]};
                    doc.selection.fill(fillColor);
                    layer.opacity = {fill_opacity};
                }}
                if ({stroke_width} > 0) {{
                    var strokeColor = new SolidColor();
                    strokeColor.rgb.red = {stroke_rgb[0]};
                    strokeColor.rgb.green = {stroke_rgb[1]};
                    strokeColor.rgb.blue = {stroke_rgb[2]};
                    doc.selection.stroke(strokeColor, {stroke_width}, StrokeLocation.INSIDE);
                }}
                doc.selection.deselect();
            """
            try:
                app.doJavaScript(jsx)
                layer = doc.activeLayer
                layer.move(parent_group, ps.ElementPlacement.PlaceInside)
                return layer
            except Exception as exc:
                print(f"[Text Rectangle] Could not draw rectangle: {exc}")
                return None

        def _render_text_rectangle_cell(cell, raw_text):
            nonlocal current_y, current_y_is_visual_top
            if not raw_text:
                return False
            ts_rect = dict(table_style or {})
            try:
                rect_font_size = int(ts_rect.get("text_rectangle_font_size") or 0)
            except Exception:
                rect_font_size = 0
            rect_font_size = rect_font_size if rect_font_size > 0 else int(_p_b_size)
            rect_font_name = str(ts_rect.get("text_rectangle_font_name") or _p_b_font)
            rect_icon_h = b_icon_h
            rect_color = _solid_color_from_rgb(ts_rect.get("text_rectangle_text_rgb") or _p_b_rgb)
            rect_alignment = _normalize_alignment(ts_rect.get("text_rectangle_alignment", body_alignment), body_alignment)
            try:
                pad_x = max(0, int(ts_rect.get("text_rectangle_pad_x", 10)))
            except Exception:
                pad_x = 10
            try:
                pad_y = max(0, int(ts_rect.get("text_rectangle_pad_y", 5)))
            except Exception:
                pad_y = 5
            try:
                fill_opacity = max(0, min(100, int(ts_rect.get("text_rectangle_opacity", 100))))
            except Exception:
                fill_opacity = 100

            container_left = float(body_box_left if body_box_left is not None else margin_x)
            container_width = float(body_box_width if body_box_width is not None else max(1, c_width - (margin_x * 2)))
            max_inner_width = max(1.0, container_width - (pad_x * 2))
            lines = _build_parsed_lines(
                raw_text,
                rect_font_size,
                rect_font_name,
                rect_icon_h,
                local_max_width=max_inner_width,
                use_original_icon_size=body_icons_use_original_size,
            )
            if not lines:
                return False
            content_width = max(float(line.get("width", 0)) for line in lines)
            content_height = _block_height(lines, rect_font_size)
            rect_width = min(container_width, max(1.0, content_width + (pad_x * 2)))
            rect_height = max(1.0, content_height + (pad_y * 2))

            _ensure_text_baseline(rect_font_size)
            rect_top = max(0.0, current_y - rect_font_size - pad_y)
            if rect_top + rect_height > max_y_limit:
                _start_new_page()
                _ensure_text_baseline(rect_font_size)
                rect_top = max(0.0, current_y - rect_font_size - pad_y)
            rect_left = _line_start_x(rect_width, rect_alignment, container_left, container_width)
            rect_right = rect_left + rect_width
            rect_bottom = rect_top + rect_height

            coord = f"{get_column_letter(cell.column).upper()}{cell.row}"
            rect_group = tab_group.layerSets.add()
            rect_group.name = _cell_render_group_name(coord, "TextRectangle")
            _draw_text_rectangle_layer(
                rect_group,
                rect_left,
                rect_top,
                rect_right,
                rect_bottom,
                ts_rect.get("text_rectangle_fill_rgb") or (20, 20, 30),
                fill_opacity,
                ts_rect.get("text_rectangle_stroke_rgb") or (255, 255, 255),
                ts_rect.get("text_rectangle_stroke_width", 2),
                f"Text Rectangle Fill {coord}",
            )
            text_group = rect_group.layerSets.add()
            text_group.name = "Text"
            icon_group = rect_group.layerSets.add()
            icon_group.name = "Icons"
            text_vert_offset = max(0.0, (rect_height - pad_y * 2 - max(1, content_height - int(line_spacing))) / 2.0)
            _render_prepared_lines(
                lines,
                rect_font_size,
                rect_font_name,
                rect_icon_h,
                rect_color,
                rect_group,
                rect_top + pad_y + text_vert_offset + rect_font_size,
                text_group=text_group,
                icon_group=icon_group,
                local_alignment=rect_alignment,
                local_box_left=rect_left + pad_x,
                local_box_width=max(1.0, rect_width - (pad_x * 2)),
            )
            apply_style_to_group_text_layers(app, doc, text_group, body_style)
            apply_style_to_group_text_layers(app, doc, icon_group, icon_style, text_only=False)
            _record_cell_render(
                tab_name,
                coord,
                "TextRectangle",
                raw_text,
                tab_group.name,
                rect_group,
                rect_top + pad_y + rect_font_size,
                rect_font_size,
                rect_font_name,
                rect_icon_h,
                rect_color,
                rect_alignment,
                max(1.0, rect_width - (pad_x * 2)),
                rect_left + pad_x,
                max(1.0, rect_width - (pad_x * 2)),
                None,
                safe_patch=True,
                patch_kind="text_rectangle",
                patch_data={
                    "left": rect_left,
                    "top": rect_top,
                    "right": rect_right,
                    "bottom": rect_bottom,
                    "pad_x": pad_x,
                    "pad_y": pad_y,
                    "fill_rgb": tuple(ts_rect.get("text_rectangle_fill_rgb") or (20, 20, 30)),
                    "fill_opacity": fill_opacity,
                    "stroke_rgb": tuple(ts_rect.get("text_rectangle_stroke_rgb") or (255, 255, 255)),
                    "stroke_width": int(ts_rect.get("text_rectangle_stroke_width", 2) or 0),
                },
            )
            current_y = rect_bottom + int(para_spacing)
            current_y_is_visual_top = True
            return True

        # Render rows strictly in Excel order.
        # Previous behavior rendered all non-table text first and all tables at the end,
        # which broke hierarchy like: Text -> Table -> Text 2.
        tables = sorted(tables, key=lambda x: (x['start_row'], x.get('min_col', 0)))
        tables_by_start = {}
        for table_item in tables:
            tables_by_start.setdefault(table_item['start_row'], []).append(table_item)

        def _row_is_inside_table(row_number):
            for t_start, t_end in table_row_ranges:
                if t_start <= row_number <= t_end:
                    return True
            return False

        def _row_has_following_text(after_row_number):
            for probe_row in range(int(after_row_number) + 1, page_max_row + 1):
                if enable_tables and (_row_is_inside_table(probe_row) or _row_is_inside_mapped_table(probe_row)):
                    continue
                for probe_col in range(page_min_col, page_max_col + 1):
                    probe_value = sheet.cell(row=probe_row, column=probe_col).value
                    if probe_value is None or str(probe_value).strip() == "":
                        continue
                    probe_text = str(probe_value).strip()
                    probe_low = probe_text.lower()
                    if probe_low.rstrip('>') in ["<<modified", "<removed", "<added", "<deleted"]:
                        continue
                    if probe_low in ["modified", "removed", "added", "deleted"]:
                        continue
                    return True
            return False

        def _mapped_table_has_following_text(record):
            source_rows = source_row_range_for_template(record)
            end_row = source_rows[1] if source_rows else trigger_row_for_template(record)
            return _row_has_following_text(end_row)

        def _log_mapped_table_warnings(warnings):
            for warning in warnings or []:
                message = str(warning)
                edit_log.append(message)
                if isinstance(report_collector, dict):
                    report_collector.setdefault("warnings", []).append(message)

        def _render_mapped_table_here(record):
            nonlocal current_y
            record_id = id(record)
            if record_id in rendered_mapped_table_ids:
                return
            rendered_mapped_table_ids.add(record_id)
            spec = record.get("spec") or {}
            table_name = record.get("table_name") or "table"

            source_rows = source_row_range_for_template(record)
            if source_rows:
                edit_log.append(f"TRACE: source_row_range_for_template OK for {table_name}: {source_rows}")
            else:
                edit_log.append(f"TRACE: source_row_range_for_template returned None for {table_name}, trying fallback")
                source_rows = _collect_mapped_source_rows(record, sheet_fmt)
                if source_rows:
                    edit_log.append(f"TRACE: fallback _collect_mapped_source_rows returned {source_rows}")
                else:
                    edit_log.append(f"WARN: Could not determine source rows for mapped table {table_name} on {tab_name} (source_range={spec.get('source_range')})")
            if source_rows:
                r_start, r_end = source_rows
                if rendered_mapped_claimed_rows and rendered_mapped_claimed_rows.issuperset(range(r_start, r_end + 1)):
                    message = (
                        f"Mapped table {table_name} skipped on {tab_name}: source rows "
                        f"{r_start}-{r_end} were already rendered by another mapped table. "
                        f"Remove the duplicate entry from mapped_table_jsons if this is not intended."
                    )
                    edit_log.append(message)
                    if isinstance(report_collector, dict):
                        report_collector.setdefault("warnings", []).append(message)
                    return
                rendered_mapped_claimed_rows.update(range(r_start, r_end + 1))
                consumed_rows = mapped_record_consumed_rows(record)
                if not consumed_rows:
                    consumed_rows = set(range(r_start, r_end + 1))
                rendered_mapped_source_rows.update(consumed_rows)
                edit_log.append(f"TRACE: Added {len(consumed_rows)} consumed row(s) {min(consumed_rows)}-{max(consumed_rows)} to rendered_mapped_source_rows for {table_name}")

            try:
                margin_before = max(0, int(spec.get("margin_before", 30) or 0))
            except Exception:
                margin_before = 30
            try:
                margin_after = max(0, int(spec.get("margin_after", 30) or 0))
            except Exception:
                margin_after = 30
            fit_mode = str(spec.get("fit_mode") or "scale").strip().casefold()
            has_following_text = _mapped_table_has_following_text(record)
            starts_after_heading = _consume_visual_top_for_table()
            start_y = current_y + (0 if starts_after_heading else margin_before)
            try:
                table_h = estimate_mapped_table_height(record, c_width, c_height)
            except Exception:
                table_h = 300

            if fit_mode in ("next_page", "move_to_next_page") and start_y + table_h > max_y_limit:
                _start_new_page()
                starts_after_heading = _consume_visual_top_for_table()
                start_y = current_y + (0 if starts_after_heading else margin_before)
            elif fit_mode == "warn" and start_y + table_h > max_y_limit:
                _log_mapped_table_warnings([
                    f"Mapped table {table_name} may overflow the bottom safe margin on {tab_name}."
                ])

            table_bottom, _table_group, warnings = draw_mapped_table_to_psd(
                doc, app, record, sheet_fmt, icon_folder, start_y,
                c_width, c_height, max_y_limit,
                _p_b_font, _p_b_size, color_b, b_icon_h, icon_y_offset, gap_px,
                measure_layer=measure_layer, font_cache=font_cache, icon_cache=icon_cache,
                missing_icons_log=missing_icons_log, asset_group=asset_group, parent_group=tab_group,
                icon_mappings=icon_mappings, keyword_colors=keyword_colors,
                table_style=table_style or TABLE_DEFAULTS.copy(),
                icon_size_overrides=icon_size_overrides,
                layer_style_library=(dynamic_settings or {}).get("layer_style_library") or {},
            )
            _log_mapped_table_warnings(warnings)
            current_y = table_bottom
            next_text_top = table_bottom + margin_after
            if has_following_text and next_text_top > max_y_limit:
                _start_new_page()
            elif has_following_text:
                current_y = _baseline_from_top(next_text_top, _p_b_size)
            else:
                current_y = next_text_top
            edit_log.append(f"Rendered mapped table JSON component: {table_name}")

        game_rules_dynamic_line_marker = "__PSHST_GAME_RULES_DYNAMIC_LINE__"
        game_rules_dynamic_token_re = re.compile(r"<[^>]*dynamic[^>]*>", flags=re.IGNORECASE)

        def _game_rules_clean_inline_text(value):
            return re.sub(r"\s+", " ", str(value or "")).strip()

        def _is_game_rules_malfunction_line(value):
            text = _game_rules_clean_inline_text(value).casefold()
            if not text:
                return False
            return (
                "malfunction" in text
                or "voids all pays" in text
                or "all pays and plays" in text
            )

        def _split_prefix_before_dynamic(before_text):
            """Keep the current dynamic sentence separate from any previous sentence."""
            before_text = str(before_text or "")
            last_boundary = None
            for match in re.finditer(r"[.!?]\s+", before_text):
                last_boundary = match
            if not last_boundary:
                return "", before_text
            return before_text[:last_boundary.end()].strip(), before_text[last_boundary.end():]

        def _take_dynamic_sentence(after_text):
            """Return text up to the first sentence end after a dynamic token."""
            after_text = str(after_text or "")
            match = re.search(r"[.!?]", after_text)
            if not match:
                return after_text, ""
            return after_text[:match.end()], after_text[match.end():]

        def _game_rules_split_dynamic_placeholders(text):
            # Dynamic placeholders can live in the same Excel cell as normal copy.
            # Split the cell so surrounding sentences still render, while the
            # dynamic placeholder sentence owns its own PSD line.
            value = str(text or "").replace("\r", " ").replace("\n", " ")
            if not game_rules_dynamic_token_re.search(value):
                cleaned = _game_rules_clean_inline_text(value)
                return [cleaned] if cleaned else []

            pieces = []
            cursor = 0
            for match in game_rules_dynamic_token_re.finditer(value):
                before = value[cursor:match.start()]
                prefix, lead_in = _split_prefix_before_dynamic(before)
                prefix = _game_rules_clean_inline_text(prefix)
                if prefix:
                    pieces.append(prefix)

                raw_sentence_tail, _remainder_after_sentence = _take_dynamic_sentence(value[match.end():])
                # Keep a small blank reservation for the dynamic value without
                # importing huge Excel spacing into the rendered line.
                lead_in = _game_rules_clean_inline_text(lead_in)
                sentence_tail = _game_rules_clean_inline_text(raw_sentence_tail)
                dynamic_line = ((lead_in + " ") if lead_in else "") + (" " * 10) + ((" " + sentence_tail) if sentence_tail else "")
                if dynamic_line.strip():
                    pieces.append(dynamic_line)
                else:
                    pieces.append(game_rules_dynamic_line_marker)
                cursor = match.end() + len(raw_sentence_tail)

            trailing = _game_rules_clean_inline_text(value[cursor:])
            if trailing:
                pieces.append(trailing)
            return pieces

        def _render_game_rules_page():
            nonlocal current_y, current_heading_raw, tab_group
            heading_text = ""
            upper_lines = []
            lower_lines = []
            in_bottom_section = False
            text_rect_entries = {}  # coord -> (cell, raw_text)
            legal_split = _game_rules_legal_split_for_sheet(
                dynamic_runtime.get("game_rules_legal_split_overrides", ""),
                tab_name,
            )
            if legal_split:
                edit_log.append(f"GameRules legal split override for {tab_name}: {legal_split[2]}")

            cell_count = 0
            for row in sheet.iter_rows(min_row=page_min_row, max_row=page_max_row, min_col=page_min_col, max_col=page_max_col):
                for cell in row:
                    if cell.value is None or str(cell.value).strip() == "":
                        continue
                    cell_count += 1
                    raw_text = str(cell.value).strip()
                    raw_lower = raw_text.lower()
                    if raw_lower.rstrip('>') in ["<<modified", "<removed", "<added", "<deleted"] or \
                       raw_lower in ["modified", "removed", "added", "deleted"]:
                        continue
                    is_heading = bool(cell.font and cell.font.b)
                    if is_heading and not heading_text:
                        heading_text = raw_text
                        current_heading_raw = raw_text
                        continue
                    cell_coord = (cell.row, cell.column)
                    if cell_coord in text_rectangle_cells:
                        dict_key = f"R{int(cell_coord[0])}C{int(cell_coord[1])}"
                        text_rect_entries[dict_key] = (cell, raw_text)
                        marker = f"__PSHST_TEXTRECT__R{int(cell_coord[0])}C{int(cell_coord[1])}"
                        if in_bottom_section:
                            lower_lines.append(marker)
                        else:
                            upper_lines.append(marker)
                        continue
                    cleaned_items = _game_rules_split_dynamic_placeholders(raw_text)
                    if legal_split:
                        split_row, split_col, _coord = legal_split
                        if cell.row > split_row or (cell.row == split_row and cell.column >= split_col):
                            in_bottom_section = True
                    if _is_game_rules_malfunction_line(raw_text):
                        in_bottom_section = True
                    for cleaned in cleaned_items:
                        if in_bottom_section:
                            lower_lines.append(cleaned)
                        else:
                            upper_lines.append(cleaned)

            print(f"[GameRules Debug] {tab_name}: cells={cell_count}, heading={heading_text!r}, upper={len(upper_lines)}, lower={len(lower_lines)}, cols={page_min_col}-{page_max_col}")
            print(f"[GameRules] step1: heading_text={heading_text!r}, page_heading_size={page_heading_size!r}, gap_px={gap_px!r}")
            heading_text = heading_text or tab_name
            heading_icon_gap = _heading_gap_for(page_heading_size)
            print(f"[GameRules] step2: heading_icon_gap={heading_icon_gap}, _p_b_font={_p_b_font!r}, _p_b_size={_p_b_size!r}, max_y_limit={max_y_limit}")
            upper_font_name = _p_b_font
            upper_font_size = max(10, int(_p_b_size))
            lower_font_name = str(dynamic_runtime.get("game_rules_bottom_font") or _p_b_font)
            lower_font_size = max(8, int(dynamic_runtime.get("game_rules_bottom_font_size", max(8, _p_b_size - 12))))
            bottom_gap_local = max(0, int(dynamic_runtime.get("game_rules_bottom_gap", 26)))
            # Row Gap ('line_gap') is the SINGLE row-gap source: every row
            # stacks at content_bottom + gap (empty field -> default 30px).
            # The paragraph boundary is the same uniform gap, so no extra
            # paragraph spacing is added on top of the row reflow.
            _user_row_gap = _row_gap_state["px"]
            upper_row_gap_margin = _user_row_gap
            lower_row_gap_margin = _user_row_gap
            paragraph_gap_local = 0
            separator_width = max(1, int(dynamic_runtime.get("game_rules_separator_width", 1000)))
            separator_height = max(1, int(dynamic_runtime.get("game_rules_separator_height", 2)))
            separator_rgb_raw = dynamic_runtime.get("game_rules_separator_rgb")
            if separator_rgb_raw is None:
                separator_rgb_raw = _solid_color_to_rgb_tuple(color_b, (255, 255, 255))
            separator_color = tuple(separator_rgb_raw)
            separator_alignment = _normalize_alignment(dynamic_runtime.get("game_rules_separator_alignment", "center"), "center")
            separator_margin = max(0, int(dynamic_runtime.get("game_rules_separator_margin", margin_x)))
            bottom_lr_margin = max(0, int(dynamic_runtime.get("game_rules_bottom_lr_margin", 200)))
            malfunction_lr_margin = max(0, int(dynamic_runtime.get("game_rules_malfunction_lr_margin", bottom_lr_margin)))
            xtra_reels_enabled = bool(dynamic_runtime.get("game_rules_xtra_reels_enabled", False))
            xtra_reels_asset = str(dynamic_runtime.get("game_rules_xtra_reels_asset") or "").strip()
            xtra_reels_width = max(1, int(dynamic_runtime.get("game_rules_xtra_reels_width", 100)))
            xtra_reels_outer_margin = max(0, int(dynamic_runtime.get("game_rules_xtra_reels_outer_margin", 100)))
            xtra_reels_text_gap = max(0, int(dynamic_runtime.get("game_rules_xtra_reels_text_gap", 50)))
            xtra_reels_y_offset = int(dynamic_runtime.get("game_rules_xtra_reels_y_offset", 0))
            side_safe_margin = xtra_reels_outer_margin + xtra_reels_width + xtra_reels_text_gap if xtra_reels_enabled else 0
            active_lr_margin = max(bottom_lr_margin, side_safe_margin)
            upper_left_margin = max(active_lr_margin, body_left_margin) if _normalize_alignment(body_alignment) == "left" else active_lr_margin
            upper_right_margin = active_lr_margin
            malfunction_left_margin = malfunction_lr_margin
            malfunction_right_margin = malfunction_lr_margin
            bottom_text_width = max(100, int(c_width) - malfunction_left_margin - malfunction_right_margin)
            # Upper game-rules text should behave like a centered paragraph block.
            # XTRAA REELS pages reserve the icon width, outer margin, and text
            # clearance on both sides. Normal Game Rules pages remain unchanged.
            upper_text_width = max(100, int(c_width) - upper_left_margin - upper_right_margin)
            custom_line_height = int(dynamic_runtime.get("game_rules_line_height", 0) or 0)
            malfunction_line_height = int(dynamic_runtime.get("game_rules_malfunction_line_height", 0) or 0)
            dynamic_line_height = max(0, int(dynamic_runtime.get("game_rules_dynamic_line_height", 0) or 0))
            auto_upper_line_step = None if custom_line_height <= 0 else custom_line_height
            auto_lower_line_step = None if malfunction_line_height <= 0 else malfunction_line_height
            separator_after_gap = max(6, min(18, bottom_gap_local // 2 if bottom_gap_local else 8))

            def _dynamic_blank_line_step(font_size, configured_line_step=None):
                if dynamic_line_height > 0:
                    return dynamic_line_height
                if configured_line_step and int(configured_line_step) > 0:
                    return int(configured_line_step)
                return max(1, int(font_size) + max(0, int(line_spacing)))

            def _normal_paragraph_gap(lines_list, index):
                if index >= len(lines_list) - 1:
                    return 0
                current_value = lines_list[index]
                next_value = lines_list[index + 1]
                if current_value == game_rules_dynamic_line_marker or next_value == game_rules_dynamic_line_marker:
                    return 0
                if isinstance(current_value, str) and current_value.startswith("__PSHST_TEXTRECT__"):
                    return 0
                if isinstance(next_value, str) and next_value.startswith("__PSHST_TEXTRECT__"):
                    return 0
                return paragraph_gap_local

            def _lower_content_segments(lines_list):
                segments = []
                pending_text = []
                for text_value in lines_list:
                    if text_value == game_rules_dynamic_line_marker:
                        if pending_text:
                            segments.append(("text", " ".join(pending_text)))
                            pending_text = []
                        segments.append(("blank", ""))
                        continue
                    if text_value.startswith("__PSHST_TEXTRECT__"):
                        if pending_text:
                            segments.append(("text", " ".join(pending_text)))
                            pending_text = []
                        coord = text_value[len("__PSHST_TEXTRECT__"):]
                        segments.append(("textrect", coord))
                        continue
                    cleaned_value = str(text_value).strip()
                    if cleaned_value:
                        pending_text.append(cleaned_value)
                if pending_text:
                    segments.append(("text", " ".join(pending_text)))
                return segments

            lower_segments = _lower_content_segments(lower_lines)

            def _projected_bottom(body_size_local, bottom_size_local, paragraph_gap_value):
                if measure_layer is not None:
                    _fit_texts, _fit_sizes, _fit_fonts = [], [], []

                    def _collect_fit_tokens(text_value, fnt_size, fnt_name):
                        _parts = re.split(r"(<[^>]+>)", str(text_value or ""))
                        for _pi in range(len(_parts)):
                            _pp = _parts[_pi]
                            if not _pp or (_pp.startswith("<") and _pp.endswith(">")):
                                continue
                            _prev_tok = _pi > 0 and _parts[_pi - 1].startswith("<") and _parts[_pi - 1].endswith(">")
                            _next_tok = _pi + 1 < len(_parts) and _parts[_pi + 1].startswith("<") and _parts[_pi + 1].endswith(">")
                            if _prev_tok:
                                _parts[_pi] = _pp.lstrip()
                            if _next_tok:
                                _parts[_pi] = _parts[_pi].rstrip()
                        for _pi in range(len(_parts)):
                            _pp = _parts[_pi]
                            if not _pp or (_pp.startswith("<") and _pp.endswith(">")):
                                continue
                            _fit_texts.append(_pp)
                            _fit_sizes.append(fnt_size)
                            _fit_fonts.append(fnt_name)
                            for _bw in re.split(r"( )", _pp):
                                if _bw:
                                    _fit_texts.append(_bw)
                                    _fit_sizes.append(fnt_size)
                                    _fit_fonts.append(fnt_name)

                    if not (heading_image_path and heading_image_height > 0):
                        _collect_fit_tokens(heading_text, page_heading_size, _p_h_font)
                    for _uv in upper_lines:
                        if _uv == game_rules_dynamic_line_marker:
                            continue
                        if isinstance(_uv, str) and _uv.startswith("__PSHST_TEXTRECT__"):
                            _entry = text_rect_entries.get(_uv[len("__PSHST_TEXTRECT__"):])
                            if _entry:
                                _collect_fit_tokens(_entry[1], body_size_local, upper_font_name)
                            continue
                        _collect_fit_tokens(_uv, body_size_local, upper_font_name)
                    for _stype, _stext in lower_segments:
                        if _stype == "blank":
                            continue
                        if _stype == "textrect":
                            _entry = text_rect_entries.get(_stext)
                            if _entry:
                                _collect_fit_tokens(_entry[1], bottom_size_local, lower_font_name)
                            continue
                        _collect_fit_tokens(_stext, bottom_size_local, lower_font_name)
                    if _fit_texts:
                        _PROFILER.inc("classic_fit_prebatch_calls")
                        premeasure_texts_batch(_fit_texts, _fit_sizes, _fit_fonts, measure_layer, font_cache)
                if heading_image_path and heading_image_height > 0:
                    heading_height = heading_image_height
                else:
                    heading_height = _estimate_block_height(
                        heading_text, page_heading_size, _p_h_font, h_icon_h, local_gap_px=heading_icon_gap,
                        use_size_overrides=False
                    )
                total = heading_top_margin + heading_height + int(heading_to_body_gap)
                for idx, text_value in enumerate(upper_lines):
                    if text_value == game_rules_dynamic_line_marker:
                        total += _dynamic_blank_line_step(body_size_local, auto_upper_line_step)
                    elif isinstance(text_value, str) and text_value.startswith("__PSHST_TEXTRECT__"):
                        coord = text_value[len("__PSHST_TEXTRECT__"):]
                        entry = text_rect_entries.get(coord)
                        if entry:
                            total += _estimate_block_height(
                                entry[1], body_size_local, upper_font_name, b_icon_h,
                                local_max_width=upper_text_width,
                                local_line_step=auto_upper_line_step,
                                use_original_icon_size=body_icons_use_original_size,
                            ) + 10
                        else:
                            total += _estimate_block_height(
                                text_value, body_size_local, upper_font_name, b_icon_h,
                                local_max_width=upper_text_width,
                                local_line_step=auto_upper_line_step,
                                use_original_icon_size=body_icons_use_original_size,
                            )
                    else:
                        total += _estimate_block_height(
                            text_value, body_size_local, upper_font_name, b_icon_h,
                            local_max_width=upper_text_width,
                            local_line_step=auto_upper_line_step,
                            use_original_icon_size=body_icons_use_original_size,
                        )
                    if idx < len(upper_lines) - 1 and _normal_paragraph_gap(upper_lines, idx):
                        total += paragraph_gap_value
                if lower_segments:
                    total += bottom_gap_local + separator_height + separator_after_gap
                    for segment_type, segment_text in lower_segments:
                        if segment_type == "blank":
                            total += _dynamic_blank_line_step(bottom_size_local, auto_lower_line_step)
                        elif segment_type == "textrect":
                            entry = text_rect_entries.get(segment_text)
                            if entry:
                                total += _estimate_block_height(
                                    entry[1], bottom_size_local, lower_font_name, b_icon_h,
                                    local_max_width=bottom_text_width,
                                    local_line_step=auto_lower_line_step,
                                    use_original_icon_size=body_icons_use_original_size,
                                ) + 10
                        else:
                            total += _estimate_block_height(
                                segment_text, bottom_size_local, lower_font_name, b_icon_h,
                                local_max_width=bottom_text_width,
                                local_line_step=auto_lower_line_step,
                                use_original_icon_size=body_icons_use_original_size,
                            )
                return total

            loop_count = 0
            while _projected_bottom(upper_font_size, lower_font_size, paragraph_gap_local) > max_y_limit and (
                upper_font_size > 10 or lower_font_size > 8 or paragraph_gap_local > 4
            ):
                loop_count += 1
                if loop_count == 1:
                    print(f"[GameRules] while-loop starting fit: upper={upper_font_size}, lower={lower_font_size}, para_gap={paragraph_gap_local}, max_y={max_y_limit}")
                if upper_font_size > 10:
                    upper_font_size -= 1
                if lower_font_size > 8:
                    lower_font_size -= 1
                if paragraph_gap_local > 4:
                    paragraph_gap_local -= 1
            if loop_count > 0:
                print(f"[GameRules] while-loop done in {loop_count} iterations: upper={upper_font_size}, lower={lower_font_size}, para_gap={paragraph_gap_local}")

            current_y = heading_top_margin
            print(f"[GameRules] calling _render_heading_block with '{heading_text}'...")
            hg = _render_heading_block(heading_text)
            print(f"[GameRules] heading group created: {hg.name}, layers={len(list(hg.layerSets))}, text_groups={[g.name for g in hg.layerSets]}")
            _ensure_text_baseline(upper_font_size)

            upper_body_start_y = current_y
            prev_visual_bottom = current_y
            for idx, text_value in enumerate(upper_lines):
                if text_value == game_rules_dynamic_line_marker:
                    marker_group = tab_group.layerSets.add()
                    marker_group.name = f"Game Rules Dynamic Placeholder Line {idx + 1}"
                    current_y += _dynamic_blank_line_step(upper_font_size, auto_upper_line_step)
                    prev_visual_bottom = float(current_y)
                    continue
                if text_value.startswith("__PSHST_TEXTRECT__"):
                    coord = text_value[len("__PSHST_TEXTRECT__"):]
                    entry = text_rect_entries.get(coord)
                    if entry:
                        _render_text_rectangle_cell(entry[0], entry[1])
                    continue
                para_group = tab_group.layerSets.add()
                para_group.name = f"Game Rules Paragraph {idx + 1}"
                print(f"[GameRules] rendering para {idx+1}/{len(upper_lines)}: font={upper_font_size}, y={current_y}")
                current_y = draw_game_rules_block(
                    text_value, upper_font_size, upper_font_name, b_icon_h, color_b, para_group, current_y,
                    local_keyword_colors={}, local_max_width=upper_text_width, local_line_step=auto_upper_line_step,
                    use_original_icon_size=body_icons_use_original_size,
                    local_alignment=body_alignment, local_box_left=upper_left_margin, local_box_width=upper_text_width,
                    local_body_style=game_rules_text_style,
                    prev_visual_bottom=prev_visual_bottom,
                    row_gap_margin=upper_row_gap_margin,
                )
                print(f"[GameRules] para {idx+1} done: current_y={current_y}")
                prev_visual_bottom = float(current_y)
                if _normal_paragraph_gap(upper_lines, idx):
                    current_y += paragraph_gap_local

            if xtra_reels_enabled:
                _xtra_asset_entered = str(xtra_reels_asset or "").strip()
                xtra_reels_asset = _resolve_xtra_reels_asset(
                    xtra_reels_asset,
                    [output_dir, icon_folder, os.path.dirname(os.path.abspath(excel_path))],
                )
                if xtra_reels_asset and not _xtra_asset_entered:
                    print(f"[Game Rules] auto-detected XTRAA REELS icon: {xtra_reels_asset}")
                upper_body_top = upper_body_start_y - max(1, upper_font_size)
                upper_body_bottom = max(upper_body_top + 1, current_y)
                icon_center_y = (upper_body_top + upper_body_bottom) / 2.0
                _place_game_rules_side_icons(
                    tab_group,
                    xtra_reels_asset,
                    xtra_reels_width,
                    xtra_reels_outer_margin,
                    icon_center_y,
                    xtra_reels_y_offset,
                )

            if lower_segments:
                separator_top = current_y + bottom_gap_local
                _draw_horizontal_rule(
                    tab_group, separator_top, separator_width, separator_height, separator_color,
                    "Game Rules Separator", alignment=separator_alignment, placement_margin=separator_margin
                )
                current_y = _baseline_from_top(separator_top + separator_height + separator_after_gap, lower_font_size)
                paragraph_number = 0
                lower_prev_bottom = current_y
                for segment_type, segment_text in lower_segments:
                    if segment_type == "blank":
                        marker_group = tab_group.layerSets.add()
                        marker_group.name = "Game Rules Malfunction Dynamic Placeholder Line"
                        current_y += _dynamic_blank_line_step(lower_font_size, auto_lower_line_step)
                        lower_prev_bottom = float(current_y)
                        continue
                    if segment_type == "textrect":
                        entry = text_rect_entries.get(segment_text)
                        if entry:
                            _render_text_rectangle_cell(entry[0], entry[1])
                        continue
                    paragraph_number += 1
                    lower_para_group = tab_group.layerSets.add()
                    lower_para_group.name = "Game Rules Malfunction Paragraph" if paragraph_number == 1 else f"Game Rules Malfunction Paragraph {paragraph_number}"
                    current_y = draw_game_rules_block(
                        segment_text, lower_font_size, lower_font_name, b_icon_h, color_b, lower_para_group, current_y,
                        local_keyword_colors={}, local_max_width=bottom_text_width, local_line_step=auto_lower_line_step,
                        use_original_icon_size=body_icons_use_original_size,
                        local_alignment=bottom_alignment,
                        local_box_left=malfunction_left_margin, local_box_width=bottom_text_width,
                        local_body_style=game_rules_legal_style,
                        prev_visual_bottom=lower_prev_bottom,
                        row_gap_margin=lower_row_gap_margin,
                    )
                    lower_prev_bottom = float(current_y)

            _mega_sheet_finish(app, doc)

        def _render_bingo_rules_page():
            nonlocal current_y, current_heading_raw, current_y_is_visual_top

            def _is_noise_text(value):
                low = str(value or "").strip().lower()
                return low.rstrip('>') in ["<<modified", "<removed", "<added", "<deleted"] or low in ["modified", "removed", "added", "deleted"]

            def _clean_bingo_text(value):
                return re.sub(r"\s+", " ", str(value or "").strip())

            def _bingo_line_step(font_size):
                try:
                    configured = int(line_spacing)
                except Exception:
                    configured = 0
                return max(int(font_size) + max(4, configured), int(round(float(font_size) * 1.22)))

            wrap_cache = {}

            def _wrap_text_to_width(text_value, font_size, font_name, width_px):
                with _timed("classic_bingo_wrap"):
                    return _wrap_text_to_width_impl(text_value, font_size, font_name, width_px)

            def _wrap_text_to_width_impl(text_value, font_size, font_name, width_px):
                cache_key = (str(text_value or ""), int(font_size), str(font_name or ""), int(width_px or 0))
                if cache_key in wrap_cache:
                    return list(wrap_cache[cache_key])
                width_px = max(80, int(width_px or max_line_width))
                tokens = [token for token in re.split(r"(\s+)", str(text_value or "").strip()) if token]
                try:
                    _pre_texts, _pre_sizes, _pre_fonts = [], [], []
                    for _pt in tokens:
                        _ptn = " " if _pt.isspace() else _pt
                        _pre_texts.append(_ptn)
                        _pre_sizes.append(font_size)
                        _pre_fonts.append(font_name)
                        _lst = _ptn.lstrip()
                        if _lst != _ptn:
                            _pre_texts.append(_lst)
                            _pre_sizes.append(font_size)
                            _pre_fonts.append(font_name)
                    if _pre_texts:
                        premeasure_texts_batch(_pre_texts, _pre_sizes, _pre_fonts, measure_layer, font_cache)
                except Exception:
                    pass
                lines = []
                current_tokens = []
                current_width = 0.0
                for token in tokens:
                    token_text = " " if token.isspace() else token
                    token_width = measure_text(token_text, font_size, font_name)
                    if current_tokens and current_width + token_width > width_px:
                        lines.append("".join(current_tokens).strip())
                        if token.isspace():
                            current_tokens = []
                            current_width = 0.0
                        else:
                            token_text = token.lstrip()
                            current_tokens = [token_text]
                            current_width = measure_text(token_text, font_size, font_name)
                    else:
                        current_tokens.append(token)
                        current_width += token_width
                if current_tokens:
                    line_text = "".join(current_tokens).strip()
                    if line_text:
                        lines.append(line_text)
                lines = lines or [""]
                wrap_cache[cache_key] = tuple(lines)
                return list(lines)

            def _lines_for_paragraphs(paragraphs, font_size, font_name, width_px):
                lines = []
                for paragraph in paragraphs:
                    text_value = _clean_bingo_text(paragraph)
                    if not text_value:
                        continue
                    if lines:
                        lines.append("")
                    lines.extend(_wrap_text_to_width(text_value, font_size, font_name, width_px))
                return lines

            def _lines_height(lines, font_size):
                if not lines:
                    return 0
                return len(lines) * _bingo_line_step(font_size)

            def _draw_multiline_text_layer(parent_group, name, lines, font_size, font_name, color_value,
                                           left, top, width_px, alignment, style):
                lines = [str(line) for line in (lines or [])]
                if not any(line.strip() for line in lines):
                    return top
                alignment = _normalize_alignment(alignment, "center")
                font_size = int(font_size)
                line_step = int(_bingo_line_step(font_size))
                text_group = parent_group.layerSets.add()
                text_group.name = name
                text_batch = [] if not keyword_colors else None
                current_top = float(top)
                for line_index, line in enumerate(lines, start=1):
                    if not line.strip():
                        current_top += line_step
                        continue
                    line_width = measure_text(line, font_size, font_name)
                    x_pos = _line_start_x(line_width, alignment, float(left), float(width_px))
                    _render_text_with_keyword_overlays(
                        text_group,
                        line,
                        font_size,
                        font_name,
                        color_value,
                        x_pos,
                        _baseline_from_top(current_top, font_size),
                        measure_layer,
                        font_cache,
                        keyword_colors,
                        f"{name} Line {line_index}",
                        app=app,
                        line_height=line_step,
                        text_batch=text_batch,
                    )
                    current_top += line_step
                if text_batch is not None:
                    flush_text_spec_batch(text_batch, app, doc)
                apply_style_to_group_text_layers(app, doc, text_group, style if style is not None else body_style)
                expected_bottom = float(top) + _lines_height(lines, font_size)
                if os.environ.get("PSH_DIRECT_POSITION", "1") != "0":
                    return expected_bottom
                try:
                    bounds = _collect_group_bounds(text_group)
                    if bounds:
                        return max(expected_bottom, float(bounds[3]))
                except Exception:
                    pass
                return expected_bottom

            def _footer_box(alignment, records):
                alignment = _normalize_alignment(alignment, "center")
                explicit = None
                for record in records:
                    override = bingo_alignment_overrides.get(record["coord"])
                    if override and (override.get("left_margin") is not None or override.get("right_margin") is not None):
                        explicit = override
                        break
                if explicit:
                    left_margin = explicit.get("left_margin") if explicit.get("left_margin") is not None else body_left_margin
                    right_margin = explicit.get("right_margin") if explicit.get("right_margin") is not None else margin_x
                    return _role_box_for_alignment("left", left_margin, right_margin)
                if alignment == "left":
                    right_edge = (float(c_width) / 2.0) - 30
                    return float(body_left_margin), max(100.0, right_edge - float(body_left_margin))
                if alignment == "right":
                    left_edge = (float(c_width) / 2.0) + 30
                    return left_edge, max(100.0, float(c_width) - float(margin_x) - left_edge)
                return body_box_left, body_box_width

            rows = {}
            records = []
            heading_text = ""
            max_content_row = 0
            for row in sheet.iter_rows(min_row=page_min_row, max_row=page_max_row, min_col=page_min_col, max_col=page_max_col):
                for cell in row:
                    if cell.value is None or str(cell.value).strip() == "":
                        continue
                    raw_text = str(cell.value).strip()
                    if _is_noise_text(raw_text):
                        continue
                    if bool(cell.font and cell.font.b) and not heading_text:
                        heading_text = _clean_bingo_text(raw_text)
                        current_heading_raw = heading_text
                        continue
                    cleaned_text = _clean_bingo_text(raw_text)
                    if not cleaned_text:
                        continue
                    record = {"row": int(cell.row), "col": int(cell.column), "coord": (int(cell.row), int(cell.column)), "text": cleaned_text}
                    rows.setdefault(record["row"], []).append(record)
                    records.append(record)
                    max_content_row = max(max_content_row, record["row"])

            heading_text = heading_text or tab_name
            if not records:
                current_y = heading_top_margin
                _render_heading_block(heading_text)
                edit_log.append(f"Rendered Bingo Rules fast page with heading only: {tab_name}")
                return

            explicit_body = bool(bingo_body_range_coords)
            override_rows = {row for row, _col in bingo_alignment_overrides.keys()}

            def _infer_footer_rows(use_explicit_body):
                inferred = set()
                if override_rows:
                    footer_start = min(override_rows)
                    inferred = {row_idx for row_idx in rows if row_idx >= footer_start}
                elif not use_explicit_body:
                    mid_col = (page_min_col + page_max_col) / 2.0
                    bottom_right_rows = [
                        row_idx for row_idx, row_records in rows.items()
                        if row_idx >= max_content_row - 4 and any(record["col"] > mid_col for record in row_records)
                    ]
                    if bottom_right_rows:
                        footer_start = min(bottom_right_rows)
                        inferred = {row_idx for row_idx in rows if row_idx >= footer_start}
                return inferred

            def _collect_bingo_paragraphs(use_explicit_body, inferred_footer_rows):
                collected_body = []
                collected_footer = []
                for row_idx in sorted(rows):
                    row_records = sorted(rows[row_idx], key=lambda item: item["col"])
                    body_texts = []
                    for record in row_records:
                        coord = record["coord"]
                        if row_idx in inferred_footer_rows and (
                            not use_explicit_body
                            or coord not in bingo_body_range_coords
                            or coord in bingo_alignment_overrides
                        ):
                            collected_footer.append(record)
                            continue
                        if use_explicit_body and coord not in bingo_body_range_coords:
                            continue
                        body_texts.append(record["text"])
                    if body_texts:
                        collected_body.append(" ".join(body_texts))
                if use_explicit_body:
                    for record in records:
                        if record["coord"] in bingo_alignment_overrides and record not in collected_footer:
                            collected_footer.append(record)
                return collected_body, collected_footer

            footer_rows = _infer_footer_rows(explicit_body)
            body_paragraphs, footer_records = _collect_bingo_paragraphs(explicit_body, footer_rows)
            if explicit_body and not body_paragraphs:
                edit_log.append(f"Bingo Rules body range matched no cells for {tab_name}; using auto body content.")
                explicit_body = False
                footer_rows = _infer_footer_rows(explicit_body)
                body_paragraphs, footer_records = _collect_bingo_paragraphs(explicit_body, footer_rows)

            body_font_size = bingo_body_size if bingo_body_size > 0 else _p_b_size
            body_font_size = max(8, int(body_font_size))
            body_font_name = _p_b_font
            footer_font_size = body_font_size
            footer_font_name = _p_b_font
            footer_gap = max(10, int(para_spacing))

            def _footer_groups_for_size(font_size):
                grouped = {"left": [], "center": [], "right": []}
                mid_col = (page_min_col + page_max_col) / 2.0
                for record in sorted(footer_records, key=lambda item: (item["row"], item["col"])):
                    override = bingo_alignment_overrides.get(record["coord"])
                    alignment = _normalize_alignment((override or {}).get("alignment"), "left" if record["col"] <= mid_col else "right")
                    grouped.setdefault(alignment, []).append(record)
                groups = []
                for alignment in ("left", "center", "right"):
                    group_records = grouped.get(alignment) or []
                    if not group_records:
                        continue
                    box_left, box_width = _footer_box(alignment, group_records)
                    paragraphs = [record["text"] for record in group_records]
                    lines = _lines_for_paragraphs(paragraphs, font_size, footer_font_name, box_width)
                    groups.append({
                        "alignment": alignment,
                        "left": box_left,
                        "width": box_width,
                        "lines": lines,
                        "height": _lines_height(lines, font_size),
                    })
                return groups

            def _heading_estimate():
                if heading_image_path and heading_image_height > 0:
                    return float(heading_image_height)
                return _estimate_block_height(
                    heading_text, page_heading_size, _p_h_font, h_icon_h,
                    local_max_width=_heading_text_box()[1],
                    use_size_overrides=False,
                )

            def _layout_for_size(font_size):
                if measure_layer is not None:
                    _fit_texts, _fit_sizes, _fit_fonts = [], [], []

                    def _collect_wrap_tokens(text_value, fnt_size, fnt_name):
                        for _pt in [t for t in re.split(r"(\s+)", str(text_value or "").strip()) if t]:
                            _ptn = " " if _pt.isspace() else _pt
                            _fit_texts.append(_ptn)
                            _fit_sizes.append(fnt_size)
                            _fit_fonts.append(fnt_name)
                            _lst = _ptn.lstrip()
                            if _lst != _ptn:
                                _fit_texts.append(_lst)
                                _fit_sizes.append(fnt_size)
                                _fit_fonts.append(fnt_name)

                    for _paragraph in body_paragraphs:
                        _cv = _clean_bingo_text(_paragraph)
                        if _cv:
                            _collect_wrap_tokens(_cv, font_size, body_font_name)
                    for _record in footer_records:
                        _cv = _clean_bingo_text(_record["text"])
                        if _cv:
                            _collect_wrap_tokens(_cv, font_size, footer_font_name)
                    if _fit_texts:
                        _PROFILER.inc("classic_fit_prebatch_calls")
                        premeasure_texts_batch(_fit_texts, _fit_sizes, _fit_fonts, measure_layer, font_cache)
                body_lines = _lines_for_paragraphs(body_paragraphs, font_size, body_font_name, body_box_width)
                footer_groups = _footer_groups_for_size(font_size)
                body_height = _lines_height(body_lines, font_size)
                footer_height = max((group["height"] for group in footer_groups), default=0)
                total_height = (
                    float(heading_top_margin)
                    + _heading_estimate()
                    + int(heading_to_body_gap)
                    + body_height
                    + (footer_gap + footer_height if footer_height else 0)
                )
                if measure_layer is not None:
                    _fin_texts, _fin_sizes, _fin_fonts = [], [], []
                    for _line in body_lines:
                        if str(_line or "").strip():
                            _fin_texts.append(_line)
                            _fin_sizes.append(font_size)
                            _fin_fonts.append(body_font_name)
                    for _group in footer_groups:
                        for _line in _group["lines"]:
                            if str(_line or "").strip():
                                _fin_texts.append(_line)
                                _fin_sizes.append(font_size)
                                _fin_fonts.append(footer_font_name)
                    if _fin_texts:
                        _PROFILER.inc("classic_fit_prebatch_calls")
                        premeasure_texts_batch(_fin_texts, _fin_sizes, _fin_fonts, measure_layer, font_cache)
                return body_lines, footer_groups, body_height, footer_height, total_height

            original_body_size = body_font_size
            if bingo_one_page:
                _body_lines, _footer_groups, _body_height, _footer_height, projected = _layout_for_size(body_font_size)
                if projected > max_y_limit:
                    low, high = 8, max(8, body_font_size)
                    best = 8
                    while low <= high:
                        mid = (low + high) // 2
                        if _layout_for_size(mid)[4] <= max_y_limit:
                            best = mid
                            low = mid + 1
                        else:
                            high = mid - 1
                    body_font_size = best
                    footer_font_size = best
                    if body_font_size != original_body_size:
                        edit_log.append(f"Bingo Rules paragraph body size auto-fit for {tab_name}: {original_body_size} -> {body_font_size}")

            body_lines, footer_groups, body_height, footer_height, _projected = _layout_for_size(body_font_size)

            current_y = heading_top_margin
            _render_heading_block(heading_text)
            body_top = current_y if current_y_is_visual_top else max(heading_top_margin, current_y - body_font_size)
            footer_top = max_y_limit - footer_height if footer_height else None
            if footer_top is not None:
                body_bottom_limit = max(body_top, footer_top - footer_gap)
            else:
                body_bottom_limit = max_y_limit
            body_group = tab_group.layerSets.add()
            body_group.name = "Bingo Rules Paragraph Box"
            _draw_multiline_text_layer(
                body_group,
                "Bingo Rules Body Paragraph",
                body_lines,
                body_font_size,
                body_font_name,
                color_b,
                body_box_left,
                body_top,
                body_box_width,
                body_alignment,
                body_style,
            )

            if footer_groups and footer_top is not None:
                footer_group = tab_group.layerSets.add()
                footer_group.name = "Bingo Rules Footer"
                for group in footer_groups:
                    group_top = footer_top + ((footer_height - group["height"]) / 2.0)
                    _draw_multiline_text_layer(
                        footer_group,
                        f"Bingo Footer {group['alignment'].title()}",
                        group["lines"],
                        footer_font_size,
                        footer_font_name,
                        color_b,
                        group["left"],
                        group_top,
                        group["width"],
                        group["alignment"],
                        body_style,
                    )
                current_y = max_y_limit
            else:
                current_y = min(body_bottom_limit, body_top + body_height)
            current_y_is_visual_top = True
            edit_log.append(f"Rendered Bingo Rules fast paragraph page: {tab_name}")

        def _auto_table_style_base():
            ts_base = TABLE_DEFAULTS.copy()
            if table_style:
                ts_base.update(table_style)
            ts_base["table_header_alignment"] = table_alignment
            ts_base["table_body_alignment"] = table_alignment
            return ts_base

        def _auto_table_flow_margins(ts_base):
            try:
                after_table_margin = max(10, int(ts_base.get('after_table_margin', 30)))
            except Exception:
                after_table_margin = 30
            try:
                min_text_room = max(0, int(ts_base.get('after_table_min_text_room', 70)))
            except Exception:
                min_text_room = 70
            return after_table_margin, min_text_room

        def _draw_auto_table_direct(table_data, start_y, table_style_override):
            table_bottom, _ = draw_table_to_psd(
                doc, app, table_data, icon_folder, start_y, c_width, c_height,
                margin_x, _p_b_font, _p_b_size, color_b, b_icon_h, icon_y_offset, gap_px, line_spacing,
                table_style_override, measure_layer, font_cache, icon_cache, missing_icons_log, asset_group,
                tab_group, icon_mappings, keyword_colors, None
            )
            return table_bottom

        def _render_table_here(table_data):
            nonlocal current_y
            _consume_visual_top_for_table()
            ts_base = _auto_table_style_base()
            after_table_margin, min_text_room = _auto_table_flow_margins(ts_base)
            has_following_text = _row_has_following_text(table_data['end_row'])
            reserved_tail_room = (after_table_margin + min_text_room) if has_following_text else 0

            # Use the real table height before drawing. A fixed 300px guess let
            # large tables start too low, overflow the page, and create a full-page
            # colored overlay artifact in Photoshop.
            try:
                table_h = estimate_table_height(
                    table_data, c_width, _p_b_font, _p_b_size, b_icon_h,
                    ts_base, measure_layer, font_cache, gap_px=gap_px,
                    icon_folder=icon_folder, icon_mappings=icon_mappings
                )
            except Exception:
                table_h = 300

            # If the table cannot fit in the remaining safe area, move it to the
            # next page before rendering. If the table is taller than a fresh page,
            # render it at the top/continued position instead of clipping from the
            # previous page.
            if current_y + table_h > (max_y_limit - reserved_tail_room):
                _start_new_page()
                _consume_visual_top_for_table()

            ts = dict(ts_base)
            ts['max_table_height'] = max(1, int(max_y_limit - current_y - reserved_tail_room))
            try:
                table_h = estimate_table_height(
                    table_data, c_width, _p_b_font, _p_b_size, b_icon_h,
                    ts, measure_layer, font_cache, gap_px=gap_px,
                    icon_folder=icon_folder, icon_mappings=icon_mappings
                )
            except Exception:
                pass
            if current_y + table_h > max_y_limit and current_y > heading_top_margin:
                _start_new_page()
                _consume_visual_top_for_table()
                ts['max_table_height'] = max(1, int(max_y_limit - current_y - reserved_tail_room))

            current_y = _draw_auto_table_direct(table_data, current_y, ts)
            table_bottom = current_y
            next_text_top = table_bottom + after_table_margin
            if has_following_text and next_text_top + min_text_room > max_y_limit:
                _start_new_page()
            elif has_following_text:
                current_y = _baseline_from_top(next_text_top, _p_b_size)

        def _table_rows_consumed_by_mapped(table_data):
            try:
                start_row = int(table_data.get("start_row") or 0)
                end_row = int(table_data.get("end_row") or start_row)
            except Exception:
                return False
            if start_row <= 0 or not rendered_mapped_source_rows:
                return False
            return rendered_mapped_source_rows.issuperset(range(start_row, end_row + 1))

        def _render_table_group_here(table_group):
            nonlocal current_y
            if not table_group:
                return
            if len(table_group) == 1:
                table_data = table_group[0]
                if _table_rows_consumed_by_mapped(table_data):
                    edit_log.append(f"Auto table on {tab_name} rows {table_data.get('start_row')}-{table_data.get('end_row')} skipped: rows already rendered by a mapped JSON table.")
                    return
                mapped_record = table_template_for_excel_table(sheet_mapped_table_records, tab_name, table_data)
                if mapped_record:
                    rid = id(mapped_record)
                    if rid not in rendered_mapped_table_ids:
                        _render_mapped_table_here(mapped_record)
                    else:
                        edit_log.append(f"Auto table on {tab_name} rows {table_data.get('start_row')}-{table_data.get('end_row')} skipped: mapped JSON already rendered.")
                    return
                _render_table_here(table_data)
                return

            mapped_pairs = [
                (table_data, table_template_for_excel_table(sheet_mapped_table_records, tab_name, table_data))
                for table_data in table_group
            ]
            if any(mapped_record for _table_data, mapped_record in mapped_pairs):
                for table_data, mapped_record in mapped_pairs:
                    if mapped_record:
                        if id(mapped_record) not in rendered_mapped_table_ids:
                            _render_mapped_table_here(mapped_record)
                        else:
                            edit_log.append(f"Auto table on {tab_name} rows {table_data.get('start_row')}-{table_data.get('end_row')} skipped: mapped JSON already rendered.")
                    elif not _table_rows_consumed_by_mapped(table_data):
                        _render_table_here(table_data)
                    else:
                        edit_log.append(f"Auto table on {tab_name} rows {table_data.get('start_row')}-{table_data.get('end_row')} skipped: rows already rendered by a mapped JSON table.")
                return

            _consume_visual_top_for_table()
            ts_base = _auto_table_style_base()
            after_table_margin, min_text_room = _auto_table_flow_margins(ts_base)
            last_table_row = max(int(table_data.get("end_row") or table_data.get("start_row") or 0) for table_data in table_group)
            has_following_text = _row_has_following_text(last_table_row)
            reserved_tail_room = (after_table_margin + min_text_room) if has_following_text else 0

            metrics = []
            try:
                for table_data in table_group:
                    if not table_data.get("grid_mode"):
                        raise ValueError("Side-by-side auto tables require grid metrics.")
                    metric = _grid_table_metrics(
                        table_data, c_width, _p_b_font, _p_b_size, b_icon_h,
                        ts_base, measure_layer, font_cache, gap_px=gap_px,
                        icon_folder=icon_folder, icon_mappings=icon_mappings
                    )
                    metrics.append({"table": table_data, "width": metric["table_width"], "height": metric["total_row_h"]})
            except Exception:
                metrics = []

            if not metrics:
                for index, table_data in enumerate(table_group):
                    local_style = dict(ts_base)
                    if index < len(table_group) - 1:
                        local_style["after_table_margin"] = 0
                    _draw_auto_table_direct(table_data, current_y, local_style)
                    try:
                        current_y += estimate_table_height(
                            table_data, c_width, _p_b_font, _p_b_size, b_icon_h,
                            local_style, measure_layer, font_cache, gap_px=gap_px,
                            icon_folder=icon_folder, icon_mappings=icon_mappings
                        )
                    except Exception:
                        current_y += 300
                return

            try:
                same_row_gap = max(0, int(ts_base.get("same_row_table_gap", max(40, int(gap_px) * 2))))
            except Exception:
                same_row_gap = 40
            total_group_width = sum(item["width"] for item in metrics) + same_row_gap * (len(metrics) - 1)
            try:
                side_margin = max(0, int(ts_base.get("table_margin_x", margin_x)))
            except Exception:
                side_margin = max(0, int(margin_x))
            safe_width = max(1, int(c_width) - side_margin * 2)

            group_height = max(item["height"] for item in metrics)
            if current_y + group_height > (max_y_limit - reserved_tail_room):
                _start_new_page()
                _consume_visual_top_for_table()

            if total_group_width <= safe_width:
                start_x = max(0.0, (float(c_width) - float(total_group_width)) / 2.0)
                bottoms = []
                cursor_x = start_x
                for item in metrics:
                    local_style = dict(ts_base)
                    local_style["table_x"] = cursor_x
                    local_style["max_table_height"] = max(1, int(max_y_limit - current_y - reserved_tail_room))
                    bottoms.append(_draw_auto_table_direct(item["table"], current_y, local_style))
                    cursor_x += float(item["width"]) + same_row_gap
                current_y = max(bottoms) if bottoms else current_y
            else:
                for item in metrics:
                    local_style = dict(ts_base)
                    local_style["max_table_height"] = max(1, int(max_y_limit - current_y - reserved_tail_room))
                    current_y = _draw_auto_table_direct(item["table"], current_y, local_style)

            next_text_top = current_y + after_table_margin
            if has_following_text and next_text_top + min_text_room > max_y_limit:
                _start_new_page()
            elif has_following_text:
                current_y = _baseline_from_top(next_text_top, _p_b_size)

        def _first_normal_heading_coord():
            for scan_row in sheet.iter_rows(min_row=page_min_row, max_row=page_max_row, min_col=page_min_col, max_col=page_max_col):
                scan_row_idx = scan_row[0].row if scan_row else 0
                if enable_tables and _row_is_inside_table(scan_row_idx):
                    continue
                for scan_cell in scan_row:
                    if scan_cell.value is None or str(scan_cell.value).strip() == "":
                        continue
                    scan_text = str(scan_cell.value).strip()
                    if _is_excel_marker_cell(scan_text):
                        continue
                    if bool(scan_cell.font and scan_cell.font.b):
                        return scan_cell.row, scan_cell.column
            return None

        first_heading_coord = None if section_heading_cells else _first_normal_heading_coord()
        bingo_fit_body_size = bingo_body_size if (bingo_page and bingo_body_size > 0) else _p_b_size

        def _estimate_normal_sheet_flow_height(body_size_local):
            if measure_layer is not None:
                _fit_texts, _fit_sizes, _fit_fonts = [], [], []

                def _collect_sheet_tokens(text_value, fnt_size, fnt_name):
                    _parts = re.split(r"(<[^>]+>)", str(text_value or ""))
                    for _pi in range(len(_parts)):
                        _pp = _parts[_pi]
                        if not _pp or (_pp.startswith("<") and _pp.endswith(">")):
                            continue
                        _prev_tok = _pi > 0 and _parts[_pi - 1].startswith("<") and _parts[_pi - 1].endswith(">")
                        _next_tok = _pi + 1 < len(_parts) and _parts[_pi + 1].startswith("<") and _parts[_pi + 1].endswith(">")
                        if _prev_tok:
                            _parts[_pi] = _pp.lstrip()
                        if _next_tok:
                            _parts[_pi] = _parts[_pi].rstrip()
                    for _pi in range(len(_parts)):
                        _pp = _parts[_pi]
                        if not _pp or (_pp.startswith("<") and _pp.endswith(">")):
                            continue
                        _fit_texts.append(_pp)
                        _fit_sizes.append(fnt_size)
                        _fit_fonts.append(fnt_name)
                        for _bw in re.split(r"( )", _pp):
                            if _bw:
                                _fit_texts.append(_bw)
                                _fit_sizes.append(fnt_size)
                                _fit_fonts.append(fnt_name)

                _scan_primary_done = False
                if heading_image_path and first_heading_coord is None:
                    if heading_image_height <= 0:
                        _collect_sheet_tokens(_prepare_heading_text(tab_name), page_heading_size, _p_h_font)
                    _scan_primary_done = True
                for _scan_row in sheet.iter_rows(min_row=page_min_row, max_row=page_max_row, min_col=page_min_col, max_col=page_max_col):
                    _scan_row_idx = _scan_row[0].row if _scan_row else 0
                    if enable_tables and _scan_row_idx in tables_by_start:
                        continue
                    if enable_tables and (_row_is_inside_table(_scan_row_idx) or _row_is_inside_mapped_table(_scan_row_idx)):
                        continue
                    for _scan_cell in _scan_row:
                        if _scan_cell.value is None or str(_scan_cell.value).strip() == "":
                            continue
                        _scan_text = str(_scan_cell.value).strip()
                        if _is_excel_marker_cell(_scan_text):
                            continue
                        _scan_coord = (_scan_cell.row, _scan_cell.column)
                        if _scan_coord in text_rectangle_cells:
                            continue
                        _scan_heading = bool(_scan_coord in section_heading_cells) or bool(first_heading_coord and _scan_coord == first_heading_coord)
                        _scan_subheading = (not _scan_heading) and bool(_scan_coord in section_subheading_cells)
                        if _scan_heading and not _scan_primary_done:
                            _collect_sheet_tokens(_prepare_heading_text(_scan_text), page_heading_size, _p_h_font)
                            _scan_primary_done = True
                            continue
                        if _scan_heading:
                            _collect_sheet_tokens(_scan_text, page_heading_size, _p_h_font)
                        elif _scan_subheading:
                            _collect_sheet_tokens(_scan_text, subheading_font_size, subheading_font_name)
                        else:
                            _collect_sheet_tokens(_scan_text, body_size_local, _p_b_font)
                if _fit_texts:
                    _PROFILER.inc("classic_fit_prebatch_calls")
                    premeasure_texts_batch(_fit_texts, _fit_sizes, _fit_fonts, measure_layer, font_cache)
            total = float(heading_top_margin)
            rendered_primary = False
            if heading_image_path and first_heading_coord is None:
                if heading_image_height > 0:
                    total += float(heading_image_height) + int(heading_to_body_gap)
                else:
                    total += _estimate_block_height(
                        _prepare_heading_text(tab_name), page_heading_size, _p_h_font, h_icon_h,
                        local_max_width=_heading_text_box()[1],
                        use_size_overrides=False,
                    ) + int(heading_to_body_gap)
                rendered_primary = True
            for estimate_row in sheet.iter_rows(min_row=page_min_row, max_row=page_max_row, min_col=page_min_col, max_col=page_max_col):
                estimate_row_idx = estimate_row[0].row if estimate_row else 0
                if enable_tables and estimate_row_idx in tables_by_start:
                    for estimate_table in tables_by_start[estimate_row_idx]:
                        total += 300
                    continue
                if enable_tables and (_row_is_inside_table(estimate_row_idx) or _row_is_inside_mapped_table(estimate_row_idx)):
                    continue
                for estimate_cell in estimate_row:
                    if estimate_cell.value is None or str(estimate_cell.value).strip() == "":
                        continue
                    estimate_text = str(estimate_cell.value).strip()
                    if _is_excel_marker_cell(estimate_text):
                        continue
                    estimate_coord = (estimate_cell.row, estimate_cell.column)
                    if estimate_coord in text_rectangle_cells:
                        total += max(body_size_local, b_icon_h) + (2 * max(5, int((table_style or {}).get("text_rectangle_pad_y", 5)))) + int(para_spacing)
                        continue
                    estimate_heading = bool(estimate_coord in section_heading_cells) or bool(first_heading_coord and estimate_coord == first_heading_coord)
                    estimate_subheading = (not estimate_heading) and bool(estimate_coord in section_subheading_cells)
                    if estimate_heading and not rendered_primary:
                        total += _estimate_block_height(
                            _prepare_heading_text(estimate_text), page_heading_size, _p_h_font, h_icon_h,
                            local_max_width=_heading_text_box()[1],
                            use_size_overrides=False,
                        ) + int(heading_to_body_gap)
                        rendered_primary = True
                        continue
                    if estimate_heading:
                        estimate_font = _p_h_font
                        estimate_size = page_heading_size
                        estimate_icon_h = h_icon_h
                        estimate_width = _heading_text_box()[1]
                    elif estimate_subheading:
                        estimate_font = subheading_font_name
                        estimate_size = subheading_font_size
                        estimate_icon_h = max(b_icon_h, subheading_font_size)
                        estimate_width = body_box_width
                    else:
                        estimate_font = _p_b_font
                        estimate_size = body_size_local
                        estimate_icon_h = b_icon_h
                        estimate_width = body_box_width
                    estimate_cell_align = bingo_alignment_overrides.get(estimate_coord) if bingo_page else None
                    if estimate_cell_align and (estimate_cell_align.get("left_margin") is not None or estimate_cell_align.get("right_margin") is not None):
                        _left, estimate_width = _role_box_for_alignment(
                            "left",
                            estimate_cell_align.get("left_margin") if estimate_cell_align.get("left_margin") is not None else body_left_margin,
                            estimate_cell_align.get("right_margin") if estimate_cell_align.get("right_margin") is not None else margin_x,
                        )
                    total += _estimate_block_height(
                        estimate_text,
                        estimate_size,
                        estimate_font,
                        estimate_icon_h,
                        local_max_width=estimate_width,
                        use_original_icon_size=body_icons_use_original_size,
                    ) + int(para_spacing)
            return total

        if bingo_page and bingo_one_page:
            original_bingo_fit_size = bingo_fit_body_size
            while bingo_fit_body_size > 8 and _estimate_normal_sheet_flow_height(bingo_fit_body_size) > max_y_limit:
                bingo_fit_body_size -= 1
            if bingo_fit_body_size != original_bingo_fit_size:
                edit_log.append(f"Bingo Rules body size auto-fit for {tab_name}: {original_bingo_fit_size} -> {bingo_fit_body_size}")
        primary_heading_rendered = False

        if _is_game_rules_sheet_name(tab_name):
            profiler.start("game_rules_render")
            try:
                _render_game_rules_page()
            except Exception as e:
                import traceback
                print(f"[GameRules CRASH] {e}")
                traceback.print_exc()
                _mega_sheet_finish(app, doc)
                profiler.stop("game_rules_render")
                profiler.inc("sheets_rendered")
                profiler.stop(f"sheet:{tab_name}")
                continue
            profiler.stop("game_rules_render")
            _mega_sheet_finish(app, doc)
            _hide_main_sheet_groups(sheet_groups)
            edit_log.append(f"Hid completed page group(s): {tab_name}")
            profiler.inc("sheets_rendered")
            profiler.stop(f"sheet:{tab_name}")
            _emit_progress(
                "sheet_done",
                sheet=tab_name,
                index=completed_render_tabs,
                total=total_render_tabs,
            )
            continue

        if heading_image_path and first_heading_coord is None:
            current_heading_raw = tab_name
            _render_heading_block(tab_name, cell_ref="__PAGE_HEADING__")
            primary_heading_rendered = True

        def _bingo_footer_records():
            if not (bingo_page and bingo_alignment_overrides):
                return []
            footer_records = []
            for footer_row in sheet.iter_rows(min_row=page_min_row, max_row=page_max_row, min_col=page_min_col, max_col=page_max_col):
                for footer_cell in footer_row:
                    coord = (footer_cell.row, footer_cell.column)
                    if coord not in bingo_alignment_overrides:
                        continue
                    if footer_cell.value is None or str(footer_cell.value).strip() == "":
                        continue
                    raw_value = str(footer_cell.value).strip()
                    low_value = raw_value.lower()
                    if low_value.rstrip('>') in ["<<modified", "<removed", "<added", "<deleted"] or \
                       low_value in ["modified", "removed", "added", "deleted"]:
                        continue
                    text_color = color_b
                    cell_rgb = get_excel_color(footer_cell)
                    if cell_rgb is not None:
                        text_color = ps.SolidColor()
                        text_color.rgb.red, text_color.rgb.green, text_color.rgb.blue = cell_rgb
                    footer_records.append({
                        "coord": coord,
                        "row": int(footer_cell.row),
                        "col": int(footer_cell.column),
                        "text": raw_value,
                        "color": text_color,
                        "override": bingo_alignment_overrides.get(coord) or {},
                    })
            return sorted(footer_records, key=lambda item: (item["row"], item["col"]))

        def _bingo_footer_box(record):
            override = record.get("override") or {}
            alignment = _normalize_alignment(override.get("alignment"), body_alignment)
            local_left = body_box_left
            local_width = body_box_width
            if override and (override.get("left_margin") is not None or override.get("right_margin") is not None):
                local_left, local_width = _role_box_for_alignment(
                    "left",
                    override.get("left_margin") if override.get("left_margin") is not None else body_left_margin,
                    override.get("right_margin") if override.get("right_margin") is not None else margin_x,
                )
            return alignment, local_left, local_width

        def _render_bingo_footer_records(records):
            nonlocal current_y
            if not records:
                return
            font_size = max(8, int(bingo_fit_body_size if bingo_page else _p_b_size))
            grouped = {}
            for record in records:
                alignment, local_left, local_width = _bingo_footer_box(record)
                box_left, box_width = _line_alignment_box(alignment, local_left, local_width)
                key = (alignment, round(float(box_left), 3), round(float(box_width), 3))
                grouped.setdefault(key, {
                    "alignment": alignment,
                    "left": local_left,
                    "width": local_width,
                    "records": [],
                })["records"].append(record)

            group_infos = []
            for group in grouped.values():
                local_width = group["width"] or body_box_width
                height = 0
                for record in group["records"]:
                    height += _estimate_block_height(
                        record["text"],
                        font_size,
                        _p_b_font,
                        b_icon_h,
                        local_max_width=local_width,
                        use_original_icon_size=body_icons_use_original_size,
                    )
                    height += int(para_spacing)
                if height > 0:
                    height -= int(para_spacing)
                group["height"] = max(font_size, height)
                group_infos.append(group)

            if not group_infos:
                return

            max_group_height = max(group["height"] for group in group_infos)
            if current_y + max_group_height > max_y_limit:
                _start_new_page()

            footer_baseline = current_y
            for group in group_infos:
                group_y = footer_baseline + ((max_group_height - group["height"]) / 2.0)
                for record in group["records"]:
                    group_y = draw_parsed_block_paged(
                        record["text"],
                        font_size,
                        _p_b_font,
                        b_icon_h,
                        record["color"],
                        group_y,
                        local_alignment=group["alignment"],
                        local_max_width=group["width"] or body_box_width,
                        local_box_left=group["left"],
                        local_box_width=group["width"],
                        local_text_style=body_style,
                    )
                    group_y += int(para_spacing)
            current_y = footer_baseline + max_group_height + int(para_spacing)

        bingo_footer_records = _bingo_footer_records()
        bingo_footer_coords = {record["coord"] for record in bingo_footer_records}

        for row in sheet.iter_rows(min_row=page_min_row, max_row=page_max_row, min_col=page_min_col, max_col=page_max_col):
            row_idx = row[0].row if row else 0

            if enable_tables and row_idx in mapped_table_by_trigger:
                for mapped_record in mapped_table_by_trigger[row_idx]:
                    _render_mapped_table_here(mapped_record)
                rendered_mapped_source_rows.add(row_idx)
                continue

            # If this row starts a detected table, render the table right now,
            # at this exact point in the Excel flow.
            if enable_tables and row_idx in tables_by_start:
                _render_table_group_here(tables_by_start[row_idx])
                continue

            # Skip all rows that belong to a table after the table has been rendered.
            # Skip all rows that belong to ANY table (auto-detected or JSON mapped)
            if enable_tables and (_row_is_inside_table(row_idx) or _row_is_inside_mapped_table(row_idx) or row_idx in rendered_mapped_source_rows):
                continue

            if enable_tables and row_idx > 0 and any(cell.value is not None and str(cell.value).strip() != "" for cell in row):
                inside_table = _row_is_inside_table(row_idx)
                inside_mapped = _row_is_inside_mapped_table(row_idx)
                in_rendered = row_idx in rendered_mapped_source_rows
                if not (inside_table or inside_mapped or in_rendered):
                    edit_log.append(f"TRACE: row {row_idx} NOT in any skip set -- inside_table={inside_table} inside_mapped={inside_mapped} in_rendered={in_rendered} -- will render as body text")
            for cell in row:
                if cell.value is not None and str(cell.value).strip() != "":
                    raw_text = str(cell.value).strip()
                    if _is_excel_marker_cell(raw_text):
                        continue

                    cell_coord = (cell.row, cell.column)
                    if bingo_page and cell_coord in bingo_footer_coords:
                        continue
                    if cell_coord in text_rectangle_cells:
                        if _render_text_rectangle_cell(cell, raw_text):
                            continue

                    is_heading = bool(cell_coord in section_heading_cells) or bool(first_heading_coord and cell_coord == first_heading_coord)
                    is_subheading = (not is_heading) and bool(cell_coord in section_subheading_cells)
                    active_body_size = bingo_fit_body_size if bingo_page else _p_b_size
                    if is_heading:
                        c_font = _p_h_font
                        c_size = page_heading_size
                        c_icon_h = h_icon_h
                    elif is_subheading:
                        c_font = subheading_font_name
                        c_size = subheading_font_size
                        c_icon_h = max(b_icon_h, subheading_font_size)
                    else:
                        c_font = _p_b_font
                        c_size = active_body_size
                        c_icon_h = b_icon_h

                    # Use Excel cell color if explicitly set, otherwise use default heading/body color
                    cell_rgb = get_excel_color(cell)
                    if is_heading:
                        c_color = color_h
                    elif is_subheading:
                        c_color = subheading_color
                    else:
                        c_color = color_b
                    if cell_rgb is not None:
                        c_color = ps.SolidColor()
                        c_color.rgb.red, c_color.rgb.green, c_color.rgb.blue = cell_rgb

                    if is_heading and not primary_heading_rendered:
                        current_heading_raw = raw_text

                    if current_y > max_y_limit:
                        _start_new_page()

                    marker_records = table_templates_for_marker(sheet_mapped_table_records, tab_name, raw_text) if enable_tables else []
                    if marker_records:
                        raw_text_without_marker = strip_table_markers(raw_text)
                        if raw_text_without_marker:
                            if is_heading:
                                if not primary_heading_rendered or cell_coord in multi_heading_coords:
                                    _render_heading_block(raw_text_without_marker, cell_ref=_cell_ref_from_coord(cell.row, cell.column), skip_image=(cell_coord in multi_heading_coords))
                                    primary_heading_rendered = True
                                elif not heading_image_path:
                                    _ensure_text_baseline(c_size)
                                    current_y = draw_parsed_block_paged(
                                        raw_text_without_marker, c_size, c_font, c_icon_h, c_color, current_y,
                                        local_alignment=heading_alignment,
                                        local_max_width=_heading_text_box()[1],
                                        local_box_left=_heading_text_box()[0],
                                        local_box_width=_heading_text_box()[1],
                                        local_text_style=heading_style,
                                        source_cell_ref=_cell_ref_from_coord(cell.row, cell.column),
                                        source_role="Heading",
                                    )
                                    current_y += para_spacing
                            else:
                                _ensure_text_baseline(c_size)
                                cell_align = bingo_alignment_overrides.get(cell_coord) if bingo_page else None
                                local_alignment = (cell_align or {}).get("alignment", body_alignment)
                                local_left = body_box_left
                                local_width = body_box_width
                                if cell_align and (cell_align.get("left_margin") is not None or cell_align.get("right_margin") is not None):
                                    local_left, local_width = _role_box_for_alignment(
                                        "left",
                                        cell_align.get("left_margin") if cell_align.get("left_margin") is not None else body_left_margin,
                                        cell_align.get("right_margin") if cell_align.get("right_margin") is not None else margin_x,
                                    )
                                current_y = draw_parsed_block_paged(raw_text_without_marker, c_size, c_font, c_icon_h,
                                                                    c_color, current_y,
                                                                    local_alignment=local_alignment,
                                                                    local_max_width=local_width or body_box_width,
                                                                    local_box_left=local_left,
                                                                    local_box_width=local_width,
                                                                    local_text_style=subheading_style if is_subheading else None,
                                                                    source_cell_ref=_cell_ref_from_coord(cell.row, cell.column),
                                                                    source_role="Subheading" if is_subheading else "BodyTextAndIcons")
                                current_y += para_spacing
                        for mapped_record in marker_records:
                            _render_mapped_table_here(mapped_record)
                        continue

                    if is_heading:
                        if not primary_heading_rendered or cell_coord in multi_heading_coords:
                            _render_heading_block(raw_text, cell_ref=_cell_ref_from_coord(cell.row, cell.column), skip_image=(cell_coord in multi_heading_coords))
                            primary_heading_rendered = True
                        elif not heading_image_path:
                            _ensure_text_baseline(c_size)
                            current_y = draw_parsed_block_paged(
                                raw_text, c_size, c_font, c_icon_h, c_color, current_y,
                                local_alignment=heading_alignment,
                                local_max_width=_heading_text_box()[1],
                                local_box_left=_heading_text_box()[0],
                                local_box_width=_heading_text_box()[1],
                                local_text_style=heading_style,
                                source_cell_ref=_cell_ref_from_coord(cell.row, cell.column),
                                source_role="Heading",
                            )
                            current_y += para_spacing
                    else:
                        # Body text flows after any preceding table and paginates only
                        # the overflow. A short line after a table stays on that page
                        # as long as it fits above the bottom margin.
                        _ensure_text_baseline(c_size)
                        cell_align = bingo_alignment_overrides.get(cell_coord) if bingo_page else None
                        local_alignment = (cell_align or {}).get("alignment", body_alignment)
                        local_left = body_box_left
                        local_width = body_box_width
                        if cell_align and (cell_align.get("left_margin") is not None or cell_align.get("right_margin") is not None):
                            local_left, local_width = _role_box_for_alignment(
                                "left",
                                cell_align.get("left_margin") if cell_align.get("left_margin") is not None else body_left_margin,
                                cell_align.get("right_margin") if cell_align.get("right_margin") is not None else margin_x,
                            )
                        current_y = draw_parsed_block_paged(raw_text, c_size, c_font, c_icon_h,
                                                            c_color, current_y,
                                                            local_alignment=local_alignment,
                                                            local_max_width=local_width or body_box_width,
                                                            local_box_left=local_left,
                                                            local_box_width=local_width,
                                                            local_text_style=subheading_style if is_subheading else None,
                                                            source_cell_ref=_cell_ref_from_coord(cell.row, cell.column),
                                                            source_role="Subheading" if is_subheading else "BodyTextAndIcons")
                        current_y += para_spacing

        # Tables are rendered inline during the row loop above so that Excel hierarchy is preserved.
        _render_bingo_footer_records(bingo_footer_records)
        _register_performance_base(tab_name, sheet_fmt, page_min_col, page_max_col, sheet_groups, tables, sheet_mapped_table_records)
        _mega_sheet_finish(app, doc)
        _hide_main_sheet_groups(sheet_groups)
        edit_log.append(f"Hid completed page group(s): {tab_name}")
        profiler.inc("sheets_rendered")
        profiler.stop(f"sheet:{tab_name}")
        line_spacing = _loop_line_spacing; para_spacing = _loop_para_spacing; bottom_margin = _loop_bottom_margin; max_y_limit = _loop_max_y_limit
        _emit_progress(
            "sheet_done",
            sheet=tab_name,
            index=completed_render_tabs,
            total=total_render_tabs,
        )

    if _cancel_requested():
        cancel_requested = True
        edit_log.append("Build stopped by user before saving.")

    # Cleanup helper layers
    try:
        doc.artLayers.getByName("MeasureLayer").remove()
    except:
        pass
    try:
        doc.layerSets.getByName("Asset_Cache_Hidden").remove()
    except:
        pass

    try:
        app.activeDocument = doc
    except Exception:
        pass

    if cancel_requested:
        build_report_saved = None
        try:
            profiler.stop("total_build")
            save_folder = os.path.abspath(output_dir) if output_dir else os.path.dirname(excel_path)
            os.makedirs(save_folder, exist_ok=True)
            build_report_saved = profiler.save(save_folder)
            edit_log.append(f"Build timing report saved: {build_report_saved}")
        except Exception as profiler_error:
            edit_log.append(f"Could not save build timing report: {profiler_error}")
        for open_workbook in (wb_formatted, wb):
            try:
                open_workbook.close()
            except Exception:
                pass
        if isinstance(report_collector, dict):
            report_collector.update({
                "output_psd_path": "",
                "rendered_pages": [],
                "skipped_pages": sorted(tabs_to_keep),
                "updated_pages": [],
                "removed_pages": sorted(tabs_to_remove),
                "missing_icons": sorted(missing_icons_log),
                "build_report_path": build_report_saved,
                "warnings": list(report_collector.get("warnings", [])) + ["Build stopped by user before save."],
                "notes": list(report_collector.get("notes", [])) + edit_log,
            })
        _emit_progress("cancelled", total=total_render_tabs)
        if show_completion_dialogs:
            _show_dialog("showwarning", "Build Stopped", "Build stopped by user before saving the PSD/PSB.")
        return None

    try:
        desired_names = _desired_group_order(doc, original_group_order, wb.sheetnames)
        if _reorder_top_level_groups(app, desired_names):
            edit_log.append("Restored top-level page group order")
    except Exception as order_error:
        edit_log.append(f"Could not restore group order: {order_error}")

    try:
        updated_label_tabs = tabs_to_rebuild if (incremental or selected_filter_active) else set()
        _label_page_groups(doc, app, current_tab_names, updated_label_tabs)
        if updated_label_tabs:
            edit_log.append("Layer labels set: updated pages red, other pages green")
        else:
            edit_log.append("Layer labels set: page groups green")
    except Exception as label_error:
        edit_log.append(f"Could not update layer label colors: {label_error}")

    try:
        collapse_all_layer_groups(app)
        edit_log.append("Collapsed Photoshop layer groups")
    except Exception as collapse_error:
        edit_log.append(f"Could not collapse layer groups: {collapse_error}")

    save_folder = os.path.abspath(output_dir) if output_dir else os.path.dirname(excel_path)
    os.makedirs(save_folder, exist_ok=True)

    selected_format = str(output_format or "PSD").strip().upper()
    save_ext = ".psb" if selected_format == "PSB" else ".psd"
    if overwrite_existing and reuse_prev and prev_psd_path:
        save_path = os.path.abspath(prev_psd_path)
        existing_ext = os.path.splitext(save_path)[1].lower()
        if existing_ext in (".psd", ".psb"):
            save_ext = existing_ext
    else:
        save_path = os.path.join(save_folder, _safe_output_basename(output_name) + save_ext)

    if save_ext == ".psb":
        try:
            save_options = ps.LargeDocumentSaveOptions()
        except Exception:
            save_options = ps.PhotoshopSaveOptions()
    else:
        save_options = ps.PhotoshopSaveOptions()
    try:
        app.displayDialogs = ps.DialogModes.DisplayNoDialogs
    except Exception:
        pass
    profiler.start("psd_save")
    doc.saveAs(save_path, save_options, False)
    profiler.stop("psd_save")
    edit_log.append("Saved PSD/PSB without copy mode")

    manifest_saved = None
    try:
        manifest_saved = save_manifest(
            save_path,
            excel_path,
            max_col_limit,
            doc=doc,
            extra={"render_manifest": render_manifest},
        )
    except Exception as manifest_error:
        edit_log.append(f"Could not save PSD manifest: {manifest_error}")

    build_report_saved = None
    try:
        profiler.stop("total_build")
        build_report_saved = profiler.save(save_folder)
        edit_log.append(f"Build timing report saved: {build_report_saved}")
    except Exception as profiler_error:
        edit_log.append(f"Could not save build timing report: {profiler_error}")

    for open_workbook in (wb_formatted, wb):
        try:
            open_workbook.close()
        except Exception:
            pass

    success_msg = f"Build Complete!\nSaved to:\n{save_path}\n"
    if manifest_saved:
        success_msg += f"\nManifest saved:\n{manifest_saved}\n"
    if build_report_saved:
        success_msg += f"\nBuild report saved:\n{build_report_saved}\n"

    if incremental and changed_tabs:
        success_msg += "\nIncremental mode - Changes detected:\n"
        for tab_name, changes in changed_tabs.items():
            success_msg += f"\n[{tab_name}]\n"
            for ch in changes:
                success_msg += f"  • {ch}\n"

    if edit_log:
        success_msg += "\nLayer operations:\n"
        for entry in edit_log:
            success_msg += f"  • {entry}\n"

    if missing_icons_log:
        success_msg += "\nWARNING - MISSING ICONS:\n"
        for missing in sorted(missing_icons_log):
            success_msg += f"- <{missing}>\n"
        success_msg += "\n(These were safely rendered as standard text.)"
        if show_completion_dialogs:
            _show_dialog("showwarning", "Build Complete with Warnings", success_msg)
    else:
        if show_completion_dialogs:
            _show_dialog("showinfo", "Success", success_msg)

    if isinstance(report_collector, dict):
        report_collector.update({
            "output_psd_path": save_path,
            "rendered_pages": sorted(tabs_to_rebuild),
            "skipped_pages": sorted(tabs_to_keep),
            "updated_pages": sorted(tabs_to_rebuild if incremental else []),
            "removed_pages": sorted(tabs_to_remove),
            "missing_icons": sorted(missing_icons_log),
            "build_report_path": build_report_saved,
            "warnings": list(report_collector.get("warnings", [])) + ([f"Missing icon: <{name}>" for name in sorted(missing_icons_log)] if missing_icons_log else []),
            "notes": list(report_collector.get("notes", [])) + edit_log,
        })
    _emit_progress("build_done", total=total_render_tabs, output=save_path)

    return save_path