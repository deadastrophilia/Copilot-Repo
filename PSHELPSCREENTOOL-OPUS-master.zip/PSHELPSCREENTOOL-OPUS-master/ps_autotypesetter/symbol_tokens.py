"""Excel symbol tokens <-> symbol pictures, and the pre-build symbol check.

Tokens come from the game's Excel files (every market of the active game, or
the session's Excel) via icon_mapping.scan_excel_icon_tokens. A token is
linked to a picture by the existing ``icon_mappings`` config ({token: file
name in the symbols folder}), which every renderer already resolves through
icon_mapping.resolve_icon_path — so exported files keep their own names and
no renaming is needed. Mappings live in the game's style, i.e. per game.

Text placeholders such as <GAME NAME> or <dynamic Text> are not symbols.
"""
import os
import re

from .icon_mapping import normalize_token, resolve_icon_path, scan_excel_icon_tokens

IMAGE_EXT = (".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp")
PLACEHOLDERS = {"game name", "gamename"}


_PLACEHOLDER_RX = re.compile(r"^(dynamic\b|#|number of|no\.? of)|\b(game ?name|lines?|credits?|amount|value|bet|denom\w*)$", re.I)


def is_symbol_token(token):
    """A <token> that is a picture. Names may have spaces (<Red Bag>, <Feature MrMonopoly>);
    text placeholders are not pictures: <GAME NAME>, <dynamic text>, <DYNAMIC SY>, <# Lines>."""
    t = str(token or "").strip()
    if not t or normalize_token(t) in PLACEHOLDERS:
        return False
    return not _PLACEHOLDER_RX.search(t)


def game_excels(cfg):
    """The Excel files whose tokens matter: all markets of the active game, else the session's Excel."""
    paths = []
    if (cfg or {}).get("active_game"):
        try:
            from . import games

            game = games.get(cfg["active_game"])
            paths = [m.get("excel_path") for m in (game or {}).get("markets") or []]
        except Exception:
            paths = []
    if cfg.get("excel_path"):
        paths.insert(0, cfg["excel_path"])
    seen, out = set(), []
    for p in paths:
        key = os.path.normcase(os.path.abspath(p)) if p else ""
        if p and key not in seen and os.path.isfile(p):
            seen.add(key)
            out.append(p)
    return out


def symbol_tokens(excel_paths):
    """Unique symbol tokens across the Excel files (first spelling kept)."""
    seen, out = set(), []
    for path in excel_paths or []:
        try:
            tokens = scan_excel_icon_tokens(path)
        except Exception:
            continue
        for t in tokens:
            k = normalize_token(t)
            if is_symbol_token(t) and k not in seen:
                seen.add(k)
                out.append(t)
    return out


def symbol_files(folder):
    if not folder or not os.path.isdir(folder):
        return []
    try:
        return sorted(f for f in os.listdir(folder)
                      if f.lower().endswith(IMAGE_EXT) and os.path.isfile(os.path.join(folder, f)))
    except OSError:
        return []


def _mapped_file(token, mappings):
    k = normalize_token(token)
    for key, value in (mappings or {}).items():
        if normalize_token(key) == k and value:
            return str(value)
    return ""


def _compact(s):
    return re.sub(r"[^a-z0-9]+", "", os.path.splitext(str(s or ""))[0].lower())


def suggest(token, files):
    """A file that clearly is this token's picture ("wild" -> "WILD_symbol.png"), or ""."""
    t = _compact(token)
    if len(t) < 3:
        return ""
    hits = [f for f in files if t in _compact(f) or (len(_compact(f)) >= 3 and _compact(f) in t)]
    return hits[0] if len(hits) == 1 else ""


def state(cfg, excel_paths=None):
    """Everything the mapping screen needs.

    tokens: [{token, file, via}] — via "mapping" (user link), "name" (file name
    matches), "suggested" (a likely file, not saved yet) or "" (no picture).
    """
    folder = str(cfg.get("icon_folder") or "")
    files = symbol_files(folder)
    mappings = cfg.get("icon_mappings") or {}
    tokens = symbol_tokens(excel_paths if excel_paths is not None else game_excels(cfg))
    rows, used = [], set()
    for t in tokens:
        mapped = _mapped_file(t, mappings)
        resolved = resolve_icon_path(t, folder, mappings) if folder else None
        name = os.path.basename(resolved) if resolved else ""
        if resolved and mapped and os.path.basename(mapped).lower() == name.lower():
            via = "mapping"
        elif resolved:
            via = "name"
        else:
            via = ""
        if not resolved and files:
            sug = suggest(t, files)
            if sug:
                name, via = sug, "suggested"
        if name:
            used.add(name.lower())
        rows.append({"token": t, "file": name, "via": via})
    known = {normalize_token(t) for t in cfg.get("symbol_tokens_known") or []}
    return {
        "ok": True, "icon_folder": folder,
        # tokens that appeared since the mapping was last saved (Excel changed)
        "new_tokens": [r["token"] for r in rows if known and normalize_token(r["token"]) not in known], "folder_exists": bool(folder) and os.path.isdir(folder),
        "files": files, "tokens": rows,
        "unmapped": [r["token"] for r in rows if not r["file"] or r["via"] == "suggested"],
        "unused_files": [f for f in files if f.lower() not in used],
    }


def check(cfg):
    """Pre-build check for the build's own Excel.

    state: "no_folder" | "empty_folder" | "unreadable" | "unmapped" | "ok".
    """
    folder = str(cfg.get("icon_folder") or "")
    tokens = symbol_tokens([cfg["excel_path"]] if cfg.get("excel_path") and os.path.isfile(cfg["excel_path"]) else [])
    out = {"ok": True, "icon_folder": folder, "tokens": tokens, "unresolved": [], "usable": 0}
    if not tokens:
        out["state"] = "ok"                              # nothing in the Excel needs a symbol
        return out
    if not folder or not os.path.isdir(folder):
        out["state"] = "no_folder"
        out["unresolved"] = tokens
        return out
    files = symbol_files(folder)
    readable = []
    for f in files:
        try:
            with open(os.path.join(folder, f), "rb") as fh:
                fh.read(16)
            readable.append(f)
        except OSError:
            pass
    out["usable"] = len(readable)
    if not files:
        out["state"] = "empty_folder"
    elif not readable:
        out["state"] = "unreadable"
    else:
        mappings = cfg.get("icon_mappings") or {}
        out["unresolved"] = [t for t in tokens if not resolve_icon_path(t, folder, mappings)]
        out["state"] = "unmapped" if out["unresolved"] else "ok"
    if out["state"] in ("empty_folder", "unreadable"):
        out["unresolved"] = tokens
    return out


def apply(cfg, links, tokens=None):
    """Save {token: file name or ""} into cfg["icon_mappings"] (other entries kept).

    tokens: every token the screen showed, remembered so tokens added to the
    Excel later can be flagged as new."""
    mappings = dict(cfg.get("icon_mappings") or {})
    for token, file in (links or {}).items():
        k = normalize_token(token)
        for key in [key for key in mappings if normalize_token(key) == k]:
            mappings.pop(key)
        if file:
            mappings[str(token).strip().strip("<>")] = os.path.basename(str(file))
    cfg["icon_mappings"] = mappings
    if tokens is not None:
        known = list(cfg.get("symbol_tokens_known") or [])
        have = {normalize_token(t) for t in known}
        known += [str(t) for t in tokens if normalize_token(t) not in have]
        cfg["symbol_tokens_known"] = known
    return cfg
