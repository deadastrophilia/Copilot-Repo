import json


def _jsx_string(value):
    return json.dumps(str(value or ""))


def resolve_photoshop_font(app, requested_font):
    """Return a Photoshop PostScript font name for a UI-selected family/name.

    Tkinter returns family names like "Arial" or "Montserrat". Photoshop's
    textItem.font usually wants a PostScript name like "ArialMT". This helper
    asks Photoshop to match the selected value against postScriptName, name,
    and family, then falls back to the original value.

    Names may carry a style suffix like "ArialMT|bold|italic" (the web UI's
    font request format). The suffix is stripped for matching so the base
    family resolves; the style itself is applied by the renderer through the
    font file/JSX, not through the PostScript name.
    """
    requested = str(requested_font or "").strip()
    if not requested:
        return requested
    if "|" in requested:
        requested = requested.split("|")[0].strip()

    jsx = f'''
    (function() {{
        var q = {_jsx_string(requested)};
        var qLower = q.toLowerCase();
        try {{
            for (var i = 0; i < app.fonts.length; i++) {{
                var f = app.fonts[i];
                if ((f.postScriptName && f.postScriptName === q) ||
                    (f.name && f.name === q)) {{
                    return f.postScriptName;
                }}
            }}
            for (var j = 0; j < app.fonts.length; j++) {{
                var f2 = app.fonts[j];
                var fam = f2.family ? f2.family.toLowerCase() : "";
                var nm = f2.name ? f2.name.toLowerCase() : "";
                var psn = f2.postScriptName ? f2.postScriptName.toLowerCase() : "";
                if (fam === qLower || nm === qLower || psn === qLower) {{
                    return f2.postScriptName;
                }}
            }}
            for (var k = 0; k < app.fonts.length; k++) {{
                var f3 = app.fonts[k];
                var hay = ((f3.family || "") + " " + (f3.name || "") + " " + (f3.postScriptName || "")).toLowerCase();
                if (hay.indexOf(qLower) >= 0) {{
                    return f3.postScriptName;
                }}
            }}
        }} catch(e) {{}}
        return q;
    }})();
    '''
    try:
        resolved = app.doJavaScript(jsx)
        if resolved:
            return str(resolved)
    except Exception as e:
        print(f"[Font Resolver] Could not resolve '{requested}': {e}")
    return requested
