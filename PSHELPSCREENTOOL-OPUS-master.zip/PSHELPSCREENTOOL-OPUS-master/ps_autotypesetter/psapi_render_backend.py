"""RenderBackend that wraps PSAPIDocument — headless, no Photoshop needed."""
import os
from typing import Optional
from PIL import Image

from .render_backend import RenderBackend
from .psapi_backend import PSAPIDocument, resolve_font_psapi, rgb_to_psapi_fill
from .text_icon_renderer import _measure_text_cached


class PSAPIRenderBackend(RenderBackend):
    def __init__(self, record_ops: bool = False):
        self.doc = None
        self._font_cache = {}
        self._measure_layer = None  # not needed; uses Pillow measurement
        self.record_ops = bool(record_ops)
        self.op_log = []

    def _log_op(self, entry: dict):
        if self.record_ops:
            self.op_log.append(entry)

    # ── Document lifecycle ──────────────────────────────────────────────
    def create_document(self, width: int, height: int):
        self.doc = PSAPIDocument(width, height)
        return self.doc

    def open_document(self, path: str):
        raise NotImplementedError("PSAPI backend does not support opening existing PSDs")

    def save(self, path: str):
        return self.doc.save(path)

    def close(self):
        self.doc = None

    # ── Groups ──────────────────────────────────────────────────────────
    def create_group(self, parent, name: str):
        return self.doc.add_group(parent, name)

    def find_group(self, parent, name: str):
        # PSAPI doesn't support named lookup easily; return None
        return None

    def delete_group(self, group):
        # Not supported in current PSAPI wrapper
        pass

    def rename_group(self, group, new_name: str):
        group.name = new_name

    # ── Text layers ─────────────────────────────────────────────────────
    def create_text_layer(self, parent, text: str, font_name: str, font_size: int,
                          color_rgb, x: float, y: float, name: str = "Text",
                          line_height: Optional[float] = None):
        try:
            width = self.measure_text(str(text or ""), font_size, str(font_name or ""))
        except Exception:
            width = 0.0
        self._log_op({
            "op": "text", "name": name, "text": str(text or ""),
            "font": str(font_name or ""), "size": float(font_size or 0),
            "x": float(x or 0), "y": float(y or 0), "w": float(width or 0),
        })
        ps_font = resolve_font_psapi(font_name)
        layer = self.doc.add_text_layer(parent, text, ps_font, font_size,
                                        color_rgb, x, y, name, line_height)
        return layer

    def update_text_layer(self, layer, text: str):
        layer.text = text

    def text_layer_bounds(self, layer):
        return None  # PSAPI doesn't expose bounds per-layer easily

    # ── Image / icon layers ────────────────────────────────────────────
    def create_image_layer(self, parent, pil_image, name: str, x: float, y: float):
        layer = self.doc.add_image_layer(parent, pil_image, name, int(x), int(y))
        self._log_op({
            "op": "image", "name": name,
            "x": float(x or 0), "y": float(y or 0),
            "w": float(getattr(pil_image, "width", 0) or 0),
            "h": float(getattr(pil_image, "height", 0) or 0),
        })
        return layer

    def create_placed_layer(self, parent, file_path: str, name: str,
                            x: float, y: float):
        try:
            pil_img = Image.open(file_path).convert("RGBA")
        except Exception:
            return None
        return self.create_image_layer(parent, pil_img, name, x, y)

    # ── Shape layers ────────────────────────────────────────────────────
    def create_shape_layer(self, parent, width: int, height: int,
                           fill_color_rgb, x: int, y: int,
                           name: str = "Shape"):
        img = Image.new("RGBA", (width, height), tuple(fill_color_rgb) + (255,))
        return self.create_image_layer(parent, img, name, x, y)

    # ── Alignment ───────────────────────────────────────────────────────
    def align_group(self, group, box_left: float, box_width: float,
                    alignment: str):
        self.doc.align_group(group, int(box_left), int(box_width), alignment)

    def translate_layer(self, layer, dx: float, dy: float):
        pass  # position is baked on creation

    # ── Background ──────────────────────────────────────────────────────
    def apply_background(self, bg_path: str, width: int, height: int, mode: str, bg_color: str = "#FFFFFF"):
        if mode == "color":
            hexv = str(bg_color or "#FFFFFF").lstrip("#")
            try:
                rgb = tuple(int(hexv[i:i + 2], 16) for i in (0, 2, 4)) + (255,)
            except Exception:
                rgb = (255, 255, 255, 255)
            bg_img = Image.new("RGBA", (width, height), rgb)
            self.doc.add_image_layer(self.doc.doc, bg_img, "Background", 0, 0)
            return
        if not bg_path or not os.path.exists(bg_path):
            return
        try:                                   # placed exactly as the PNG build places it (bg_place)
            from . import png_builder

            bg_img = Image.new("RGBA", (width, height), (0, 0, 0, 0))
            png_builder._paint_background(bg_img, Image, bg_path, mode, bg_color)
            self.doc.add_image_layer(self.doc.doc, bg_img, "Background", 0, 0)
        except Exception:
            pass

    # ── Measurement ─────────────────────────────────────────────────────
    def measure_text(self, text: str, font_size: int, font_name: str) -> float:
        return _measure_text_cached(text, font_size, font_name,
                                     self._measure_layer, self._font_cache)

    def measure_layer_bounds(self, layer):
        return None

    # ── Misc ────────────────────────────────────────────────────────────
    def flatten(self):
        pass

    @property
    def document_size(self):
        if self.doc is None:
            return (0, 0)
        return (self.doc.width, self.doc.height)

