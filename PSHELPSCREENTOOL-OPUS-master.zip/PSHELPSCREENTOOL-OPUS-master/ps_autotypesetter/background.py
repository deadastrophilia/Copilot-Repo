import os
import photoshop.api as ps


def _apply_solid_color(doc, app, bg_color):
    hexv = str(bg_color or "#FFFFFF").lstrip("#")
    try:
        r = int(hexv[0:2], 16)
        g = int(hexv[2:4], 16)
        b = int(hexv[4:6], 16)
    except ValueError:
        r, g, b = 255, 255, 255
    js = f"""
    var __docb = app.activeDocument;
    var desc = new ActionDescriptor();
    var ref = new ActionReference();
    ref.putClass(charIDToTypeID("contentLayer"));
    desc.putReference(charIDToTypeID("null"), ref);
    var d2 = new ActionDescriptor();
    var d3 = new ActionDescriptor();
    d3.putDouble(charIDToTypeID("Rd  "), {r});
    d3.putDouble(charIDToTypeID("Grn "), {g});
    d3.putDouble(charIDToTypeID("Bl  "), {b});
    d2.putObject(charIDToTypeID("Clr "), charIDToTypeID("RGBC"), d3);
    desc.putObject(charIDToTypeID("Usng"), charIDToTypeID("solidColorLayer"), d2);
    executeAction(charIDToTypeID("Mk  "), desc, DialogModes.NO);
    """
    app.doJavaScript(js)
    layer = doc.activeLayer
    layer.name = "Solid Background"
    layer.move(doc.layers[doc.layers.length - 1], ps.ElementPlacement.PlaceBefore)
    return True


def apply_background(doc, app, bg_path, c_width, c_height, bg_mode="stretch", bg_color="#FFFFFF"):
    if bg_mode == "color":
        return _apply_solid_color(doc, app, bg_color)
    if not bg_path or not os.path.exists(bg_path):
        return False
    from . import bg_place

    placed = bg_place.parse(bg_mode)[0] in ("fit_width", "place")
    if placed and bg_place._rgba(bg_color):           # the colour behind a picture that doesn't fill the canvas
        _apply_solid_color(doc, app, bg_color)
    bg_js = f"""
    var __docbg = app.activeDocument;
    var idPlc = charIDToTypeID("Plc ");
    var desc = new ActionDescriptor();
    desc.putPath(charIDToTypeID("null"), new File("{bg_path.replace(os.sep, '/')}"));
    executeAction(idPlc, desc, DialogModes.NO);
    """
    try:
        app.doJavaScript(bg_js)
        bg_layer = doc.activeLayer
        bg_layer.name = "Custom Background"
        b = bg_layer.bounds
        bg_w = float(b[2]) - float(b[0])
        bg_h = float(b[3]) - float(b[1])
        if placed:
            # as wide as the canvas (top / middle / bottom) or the PSD's own rectangle — bg_place's rule
            x, y, w, h = bg_place.dest(bg_mode, c_width, c_height, bg_w, bg_h)
            bg_layer.resize(w / bg_w * 100, h / bg_h * 100)
            b_new = bg_layer.bounds
            bg_layer.translate(x - float(b_new[0]), y - float(b_new[1]))
        elif bg_mode == "stretch":
            # Exact fill: scale X and Y independently so the image becomes canvas-sized.
            scale_x = c_width / bg_w
            scale_y = c_height / bg_h
            bg_layer.resize(scale_x * 100, scale_y * 100)
            b_new = bg_layer.bounds
            bg_layer.translate(0 - float(b_new[0]), 0 - float(b_new[1]))
        elif bg_mode == "fit":
            # Contain: whole image visible, centered.
            scale = min(c_width / bg_w, c_height / bg_h)
            bg_layer.resize(scale * 100, scale * 100)
            b_new = bg_layer.bounds
            new_w = float(b_new[2]) - float(b_new[0])
            new_h = float(b_new[3]) - float(b_new[1])
            delta_x = ((c_width - new_w) / 2) - float(b_new[0])
            delta_y = ((c_height - new_h) / 2) - float(b_new[1])
            bg_layer.translate(delta_x, delta_y)
        elif bg_mode == "cover":
            # Cover: scale to fill, crop overflow, centered.
            scale = max(c_width / bg_w, c_height / bg_h)
            bg_layer.resize(scale * 100, scale * 100)
            b_new = bg_layer.bounds
            new_w = float(b_new[2]) - float(b_new[0])
            new_h = float(b_new[3]) - float(b_new[1])
            delta_x = ((c_width - new_w) / 2) - float(b_new[0])
            delta_y = ((c_height - new_h) / 2) - float(b_new[1])
            bg_layer.translate(delta_x, delta_y)
        elif bg_mode == "center":
            delta_x = ((c_width - bg_w) / 2) - float(b[0])
            delta_y = ((c_height - bg_h) / 2) - float(b[1])
            bg_layer.translate(delta_x, delta_y)
        bg_layer.move(doc.layers[doc.layers.length - 1], ps.ElementPlacement.PlaceBefore)
        return True
    except Exception as e:
        print(f"Background error: {e}")
        return False
