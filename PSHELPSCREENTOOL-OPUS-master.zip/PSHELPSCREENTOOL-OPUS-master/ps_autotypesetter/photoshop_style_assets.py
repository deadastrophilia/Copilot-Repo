"""photoshop_style_assets — optional Photoshop rendering of styled text.

Previews and PNG output render every layer style WITHOUT Photoshop
(ps_fx_png / ps_fx_canvas.js; descriptors decoded by fx_descriptor), so this
path is OFF by default (config.USE_PHOTOSHOT_STYLE_ASSETS). It stays for the
explicit opt-in (flag / PSH_USE_PHOTOSHOT_STYLE_ASSETS=1); the artist-facing
"Verify in Photoshop" check lives in fx_verify.py. When enabled, it gives any
styled text element the exact-Photoshop treatment the heading compositor gives
headings, generalized to every element of the canonical layout
(``page_layout.TextElement``):

  * Elements whose style is simple (plain stroke / drop shadow) stay on the
    historical PIL path unchanged ("pil").
  * Elements whose style needs real Photoshop (byte-exact captured effects,
    pasted styles, or effects PIL cannot reproduce faithfully — inner glow,
    color/gradient overlay, bevel/satin/pattern, combined) are rendered ONCE
    in an isolated temporary Photoshop document (one text layer per wrapped
    line, same font / size / colour / alignment / line stacking, same layer
    style via ``layer_styles.apply_heading_layer_style``) and exported as a
    transparent PNG ("photoshop").
  * The PNG renderer alpha-composites the asset at the exact logical box the
    layout engine already computed — layout math never changes, and the row /
    column union algorithm is untouched because the asset replaces only the
    per-line drawing of ONE element, inside the box that was already laid out.

Cache ("style_cache") keys on every rendering-affecting property (text, font,
size, bold, italic, colour, alignment, box width, line heights/spacing,
tracking, full style config hash), so:

  * any change to a rendering-affecting property invalidates the asset, and
  * 100 pages reusing the same 10 styled elements render 10 assets once.

Failure handling: every function degrades to None and callers fall back to
the existing PIL path, so nothing here can break a build. The final-export
caller can pass ``style_errors`` to ``render_layout_pages`` to get a clear
"Photoshop is required ..." message instead of a silent approximation.

Debug mode (PSH_STYLE_ASSETS_DEBUG=1) dumps the input style JSON, text, font,
logical box, render size, offset and composite coordinates per asset into
%LOCALAPPDATA%/PsHelpScreenTool/style_debug/.
"""

from __future__ import annotations

import hashlib
import json
import os
import tempfile

from .config import photoshop_style_assets_enabled

# ---------------------------------------------------------------------------
# Simple-vs-complex split
# ---------------------------------------------------------------------------

# Effects the PIL approximate renderer (ps_fx_png / png_builder) reproduces
# faithfully for preview purposes. Anything else in a style means the artist
# asked for Photoshop fidelity and the element must go through Photoshop.
_PIL_SIMPLE_EFFECTS = {"drop_shadow", "outer_glow", "inner_shadow", "stroke"}

_COMPLEX_EFFECT_KEYS = (
    "inner_glow", "color_overlay", "gradient_overlay",
    "bevel", "satin", "pattern_overlay",
)


def is_complex_style(style_config) -> bool:
    """True when the style goes beyond a plain stroke / drop shadow.

    Informational since the Photoshop-free engine renders every style: it
    only decides which elements the opt-in Photoshop asset path would send
    to Photoshop.

    Rules:
      * captured_effects_hex (byte-exact descriptor stream) or
        paste_copied_style -> Photoshop (PIL can only approximate these).
      * captured_params containing an effect outside the simple set
        (inner glow, color/gradient overlay, bevel, satin, pattern, ...) ->
        Photoshop.
      * captured_params combining MULTIPLE simple effects (stroke + shadow +
        glow together) -> Photoshop (combined effects are where PIL's
        approximation drifts most from Photoshop).
      * Legacy UI stroke_enabled / shadow_enabled only -> PIL (simple).
    """
    if not style_config or not isinstance(style_config, dict):
        return False
    if style_config.get("captured_effects_hex") or style_config.get("paste_copied_style"):
        return True
    captured = style_config.get("captured_params")
    if isinstance(captured, dict):
        simple_count = 0
        for key, value in captured.items():
            if key.startswith("$") or key in ("opacity", "fill_opacity",
                                              "is_fill_enabled", "source"):
                continue
            if key in _COMPLEX_EFFECT_KEYS:
                return True
            if key not in _PIL_SIMPLE_EFFECTS and bool(value):
                return True
            if key in _PIL_SIMPLE_EFFECTS and isinstance(value, dict):
                simple_count += 1
        if simple_count >= 2:
            return True
    return False


# ---------------------------------------------------------------------------
# Cache
# ---------------------------------------------------------------------------

_CACHE_DIR = None


def style_cache_dir():
    """%LOCALAPPDATA%/PsHelpScreenTool/style_cache/ (created on demand)."""
    global _CACHE_DIR
    if _CACHE_DIR is None:
        base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
        _CACHE_DIR = os.path.join(base, "PsHelpScreenTool", "style_cache")
        try:
            os.makedirs(_CACHE_DIR, exist_ok=True)
        except Exception:
            _CACHE_DIR = tempfile.gettempdir()
    return _CACHE_DIR


def _debug_dump_dir():
    base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    path = os.path.join(base, "PsHelpScreenTool", "style_debug")
    try:
        os.makedirs(path, exist_ok=True)
    except Exception:
        return None
    return path


def _debug_mode():
    raw = (os.environ.get("PSH_STYLE_ASSETS_DEBUG") or "").strip().casefold()
    return raw in ("1", "true", "on", "yes")


def _style_hash(style_config):
    try:
        raw = json.dumps(style_config or {}, sort_keys=True, default=str)
    except Exception:
        raw = str(style_config or "")
    return hashlib.sha256(raw.encode("utf-8", "replace")).hexdigest()[:24]


def _fnum(value, fallback=0.0):
    try:
        return float(value)
    except Exception:
        return float(fallback)


def _line_texts(element):
    lines = [ln for ln in getattr(element, "wrapped_lines", None) or [] if str(ln or "").strip() != ""]
    if not lines:
        text = str(getattr(element, "text", "") or "")
        if text.strip():
            lines = [text.split("\n")[0]]
    return [str(ln) for ln in lines if str(ln or "").strip() != ""]


def _has_icon_tokens(element):
    if getattr(element, "tokens", None):
        return True
    for line in getattr(element, "line_runs", None) or []:
        for run in line:
            if isinstance(run, dict) and run.get("kind") == "icon":
                return True
    import re

    token_re = re.compile(r"<([^<>]+)>")
    for line in _line_texts(element):
        if token_re.search(line):
            return True
    return False


def _tracking(element):
    meta = getattr(element, "meta", None) or {}
    try:
        value = float(meta.get("tracking") or 0)
    except Exception:
        value = 0.0
    return value if value else None


def asset_cache_key(element) -> str:
    """Deterministic SHA-256 over every rendering-affecting property."""
    color = tuple(int(c) for c in (getattr(element, "color", None) or (255, 255, 255))[:3])
    payload = "|".join([
        "\x1f".join(_line_texts(element)),
        str(getattr(element, "font", "") or ""),
        str(_fnum(getattr(element, "size", 0))),
        str(bool(getattr(element, "bold", False))),
        str(bool(getattr(element, "italic", False))),
        repr(color),
        str(getattr(element, "align", "center") or "center"),
        str(int(round(_fnum(getattr(element, "width", 0))))),
        repr([int(round(h)) for h in (getattr(element, "line_heights", None) or [])]),
        repr([int(round(w)) for w in (getattr(element, "line_widths", None) or [])]),
        str(int(round(_fnum(getattr(element, "line_spacing", 0))))),
        str(_tracking(element) or ""),
        _style_hash(getattr(element, "effects", None)),
    ])
    return hashlib.sha256(payload.encode("utf-8", "replace")).hexdigest()


def element_style_path(element):
    """'photoshop' | 'pil' — the render path for this element.

    Photoshop only when the feature is on, the element has a complex style
    and the element is pure text (icons cannot be isolated in Photoshop).
    """
    if not photoshop_style_assets_enabled():
        return "pil"
    effects = getattr(element, "effects", None)
    if not effects or not isinstance(effects, dict):
        return "pil"
    if not is_complex_style(effects):
        return "pil"
    if _has_icon_tokens(element):
        return "pil"
    return "photoshop"


# ---------------------------------------------------------------------------
# Photoshop isolated-element renderer
# ---------------------------------------------------------------------------

_PS_PROBE_UNSET = object()
_PS_PROBE = _PS_PROBE_UNSET


def photoshop_available():
    """Delegate to the retrying probe (see photoshop_heading_renderer).

    No local cache here: the underlying probe already retries transient
    COM 'busy' rejections and re-probes failures after a short TTL, so a
    permanently cached False would lock previews out of Photoshop until
    the server restarts."""
    try:
        from .photoshop_heading_renderer import _photoshop_available
    except Exception:
        return False
    try:
        return bool(_photoshop_available())
    except Exception:
        return False


def render_style_asset(element):
    """Render one element's styled text through Photoshop.

    Returns ``(png_path, meta)`` where meta = {
        ink_bounds:    [l, t, r, b] of visible ink inside the PNG,
        render_size:   [w, h] of the exported PNG,
        offset:        [l, t] — composite the PNG at (x - l, y - t),
        logical_size:  [w, h] of the layout box,
        resolved_font: PostScript font name used,
    } or ``(None, None)`` when Photoshop is unavailable or rendering failed.
    """
    lines = _line_texts(element)
    if not lines:
        return None, None

    key = asset_cache_key(element)
    cache_dir = style_cache_dir()
    png_path = os.path.join(cache_dir, key + ".png")
    meta_path = os.path.join(cache_dir, key + ".json")
    if os.path.isfile(png_path) and os.path.isfile(meta_path):
        try:
            with open(meta_path, "r", encoding="utf-8") as fh:
                return png_path, json.load(fh)
        except Exception:
            pass

    if not photoshop_available():
        return None, None

    try:
        meta = _render_style_asset_inner(png_path, meta_path, element, lines, key)
    except Exception as exc:
        print(f"[Style Asset] Photoshop element render failed; falling back to PIL: {exc}")
        try:
            if os.path.isfile(png_path):
                os.remove(png_path)
        except Exception:
            pass
        return None, None
    if meta is None:
        return None, None
    return png_path, meta


def _render_style_asset_inner(png_path, meta_path, element, lines, key):
    """Create the temp doc, text layers, styles, export; returns meta dict."""
    import photoshop.api as ps

    from .layer_styles import apply_heading_layer_style
    from .photoshop_fonts import resolve_photoshop_font
    from .photoshop_heading_renderer import _export_png, _png_ink_bounds, _rgb

    app = ps.Application()
    font_name = str(getattr(element, "font", "") or "")
    ps_font = resolve_photoshop_font(app, font_name) or font_name

    font_size = max(1.0, _fnum(getattr(element, "size", 24), 24.0))
    color = _rgb(getattr(element, "color", None), (255, 255, 255))
    align = str(getattr(element, "align", "center") or "center").strip().lower()
    box_width = max(16, int(round(_fnum(getattr(element, "width", 0)))))
    line_spacing = max(0, int(round(_fnum(getattr(element, "line_spacing", 0)))))
    line_heights = [max(1, int(round(_fnum(h)))) for h in (getattr(element, "line_heights", None) or [])]
    line_widths = [max(0.0, _fnum(w)) for w in (getattr(element, "line_widths", None) or [])]
    tracking = _tracking(element)
    bold = bool(getattr(element, "bold", False))
    italic = bool(getattr(element, "italic", False))
    style_config = getattr(element, "effects", None) or {}

    total_h = 0
    for i in range(len(lines)):
        lh = line_heights[i] if i < len(line_heights) else font_size * 1.2
        total_h += max(1, int(round(lh)))
        if i < len(lines) - 1:
            total_h += line_spacing
    pad = max(40, int(font_size) * 2)
    doc_w = max(16, box_width) + pad * 2
    doc_h = max(16, total_h) + pad * 2

    doc = app.documents.add(
        doc_w, doc_h, 72.0, "style_asset",
        ps.NewDocumentMode.NewRGB, ps.DocumentFill.Transparent,
    )
    try:
        y_cursor = pad
        for i, line in enumerate(lines):
            layer = doc.artLayers.add()
            layer.kind = ps.LayerKind.TextLayer
            layer.name = f"StyleAsset {i + 1}"
            layer.textItem.contents = str(line).replace(" ", "\xa0")
            layer.textItem.size = float(font_size)
            try:
                layer.textItem.font = ps_font
            except Exception as exc:
                print(f"[Style Asset] font '{ps_font}' failed: {exc}")
            if bold:
                try:
                    layer.textItem.syntheticBold = True
                except Exception:
                    pass
            if italic:
                try:
                    layer.textItem.syntheticItalic = True
                except Exception:
                    pass
            color_obj = ps.SolidColor()
            color_obj.rgb.red, color_obj.rgb.green, color_obj.rgb.blue = color
            layer.textItem.color = color_obj
            layer.textItem.justification = ps.Justification.Left
            if tracking:
                try:
                    layer.textItem.tracking = float(tracking)
                except Exception:
                    pass

            lw = line_widths[i] if i < len(line_widths) and line_widths[i] else font_size * 0.55 * len(line)
            if align == "left":
                x = pad
            elif align == "right":
                x = pad + max(0.0, float(box_width) - lw)
            else:
                x = pad + max(0.0, (float(box_width) - lw) / 2.0)
            layer.textItem.position = [x, y_cursor + float(font_size)]
            apply_heading_layer_style(app, doc, layer, style_config)

            lh = line_heights[i] if i < len(line_heights) else font_size * 1.2
            y_cursor += max(1, int(round(lh)))
            if i < len(lines) - 1:
                y_cursor += max(0, line_spacing)

        _export_png(doc, png_path)

        ink_bounds = tuple(_png_ink_bounds(png_path))
        render_size = [int(doc_w), int(doc_h)]
        meta = {
            "ink_bounds": list(ink_bounds),
            "render_size": render_size,
            "offset": [int(ink_bounds[0]), int(ink_bounds[1])],
            "logical_size": [box_width, total_h],
            "resolved_font": str(ps_font or ""),
        }
        try:
            with open(meta_path, "w", encoding="utf-8") as fh:
                json.dump(meta, fh)
        except Exception:
            pass
        if _debug_mode():
            _dump_debug(element, key, meta, lines, ps_font, png_path)
        return meta
    finally:
        try:
            doc.close(2)  # DoNotSaveChanges
        except Exception:
            pass


def _dump_debug(element, key, meta, lines, ps_font, png_path):
    from .page_layout import TextElement

    if not isinstance(element, TextElement):
        return
    directory = _debug_dump_dir()
    if not directory:
        return
    record = {
        "key": key,
        "text": str(element.text or ""),
        "lines": list(lines),
        "font_request": str(element.font or ""),
        "resolved_font": str(ps_font or ""),
        "size": _fnum(element.size, 24),
        "bold": bool(getattr(element, "bold", False)),
        "italic": bool(getattr(element, "italic", False)),
        "color": list(getattr(element, "color", None) or (255, 255, 255)),
        "align": str(element.align or "center"),
        "logical_box": [element.x, element.y, element.width, element.height],
        "line_spacing": _fnum(element.line_spacing),
        "style_config": element.effects or {},
        "render_size": meta.get("render_size"),
        "offset": meta.get("offset"),
        "ink_bounds": meta.get("ink_bounds"),
        "composite_position": [
            int(round(element.x - (meta.get("offset") or [0, 0])[0])),
            int(round(element.y - (meta.get("offset") or [0, 0])[1])),
        ],
        "png": str(png_path),
    }
    try:
        with open(os.path.join(directory, key + ".json"), "w", encoding="utf-8") as fh:
            json.dump(record, fh, indent=2, default=str)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Compositing
# ---------------------------------------------------------------------------


def composite_style_asset(page, png_path, element, meta=None):
    """Alpha-composite a rendered style asset onto the RGBA page.

    The asset is placed so the text origin (not the ink bounds) lands at the
    element's logical position, matching exactly where PIL would draw it.
    Stroke / glow / shadow extending beyond the text origin are preserved.
    Returns True on success.
    """
    if not png_path or not os.path.isfile(png_path):
        return False
    try:
        from PIL import Image

        img = Image.open(png_path).convert("RGBA")
        meta = meta or {}
        ink = meta.get("ink_bounds") or [0, 0, 0, 0]
        render_size = meta.get("render_size") or [0, 0]
        logical_size = meta.get("logical_size") or [0, 0]

        el_x = _fnum(getattr(element, "x", 0))
        el_y = _fnum(getattr(element, "y", 0))
        box_width = max(_fnum(getattr(element, "width", 0)), logical_size[0] if logical_size else 0)
        align = str(getattr(element, "align", "center") or "center").strip().lower()

        line_widths = getattr(element, "line_widths", None) or []
        max_line_w = max(line_widths) if line_widths else 0
        font_size = max(1.0, _fnum(getattr(element, "size", 24), 24.0))
        pad = max(40, int(font_size) * 2)

        if align == "left":
            text_origin_x = el_x
            doc_text_origin_x = pad
        elif align == "right":
            text_origin_x = el_x + max(0, box_width - max_line_w)
            doc_text_origin_x = pad + max(0, box_width - max_line_w)
        else:
            text_origin_x = el_x + max(0, (box_width - max_line_w) / 2.0)
            doc_text_origin_x = pad + max(0, (box_width - max_line_w) / 2.0)

        asset_x = int(round(text_origin_x - doc_text_origin_x))
        asset_y = int(round(el_y - ink[1]))
        page.alpha_composite(img, (asset_x, asset_y))
        return True
    except Exception as exc:
        print(f"[Style Asset] composite failed: {exc}")
        return False


# ---------------------------------------------------------------------------
# Inline heading helper — called from png_builder._draw_inline
# ---------------------------------------------------------------------------


def render_inline_heading(lines, line_widths, line_heights,
                          font_request, font_size, color_rgb,
                          box_width, align, line_spacing,
                          fx_config, bold=True, italic=False):
    """Render a multi-line heading through Photoshop as a single transparent PNG.

    Called from ``png_builder._draw_inline`` when the heading has a complex
    style that needs real Photoshop.  Returns ``(png_path, meta)`` where meta
    contains ``ink_bounds``, ``offset``, etc. — or ``(None, None)`` when
    Photoshop is unavailable / the render failed.
    """
    if not lines:
        return None, None
    if not photoshop_available():
        return None, None
    if not font_request or not font_size:
        return None, None

    from .page_layout import TextElement

    el = TextElement(
        element_id="_inline_heading",
        x=0.0, y=0.0,
        width=float(box_width),
        height=float(sum(line_heights) + line_spacing * max(0, len(lines) - 1)),
        text="\n".join(lines),
        font=str(font_request or ""),
        size=float(font_size),
        bold=bool(bold),
        italic=bool(italic),
        color=list(color_rgb[:3]) if color_rgb else [255, 255, 255],
        align=str(align or "center"),
        line_spacing=float(line_spacing),
        wrapped_lines=list(lines),
        line_heights=[float(h) for h in (line_heights or [])],
        line_widths=[float(w) for w in (line_widths or [])],
        effects=dict(fx_config or {}),
        style_role="Inline heading",
    )
    return render_style_asset(el)


def invalidate_asset_cache(element):
    """Remove a cached element render (edits to any member regenerate it)."""
    key = asset_cache_key(element)
    for ext in (".png", ".json"):
        try:
            path = os.path.join(style_cache_dir(), key + ext)
            if os.path.isfile(path):
                os.remove(path)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Validation test page (spec: 8 element types)
# ---------------------------------------------------------------------------


def validation_elements():
    """The 8 validation elements: plain text, stroke, drop shadow, outer glow,
    inner shadow, bevel, gradient overlay, combined — plus one byte-exact
    captured-style element. Each sits on its own line of a single page."""
    from .page_layout import TextElement

    def _el(n, text, effects, size=52, color=(255, 255, 255)):
        return TextElement(
            element_id="validate_" + str(n),
            x=120, y=90 + (n - 1) * 96,
            width=1680, height=66,
            text=text, font="Arial", size=size, bold=True,
            color=color, align="center",
            line_heights=[66], line_widths=[660], wrapped_lines=[text],
            effects=effects,
            style_role="Validation " + str(n),
        )

    return [
        _el(1, "01 Plain text", {}, color=(200, 220, 255)),
        _el(2, "02 Stroke + shadow", {
            "stroke_enabled": True, "stroke_size": 3, "stroke_rgb": [40, 40, 40],
            "stroke_opacity": 100, "shadow_enabled": True,
            "shadow_distance": 4, "shadow_size": 4, "shadow_opacity": 75,
        }),
        _el(3, "03 Drop shadow", {
            "captured_params": {
                "drop_shadow": {"enabled": True, "color": [0, 0, 0],
                                "opacity": 75, "angle": 120, "distance": 8,
                                "size": 12, "spread": 0, "blend": "multiply"},
            },
        }),
        _el(4, "04 Outer glow", {
            "captured_params": {
                "outer_glow": {"enabled": True, "color": [255, 255, 190],
                               "opacity": 66, "size": 18, "spread": 0,
                               "blend": "screen"},
            },
        }),
        _el(5, "05 Inner shadow", {
            "captured_params": {
                "inner_shadow": {"enabled": True, "color": [0, 0, 0],
                                 "opacity": 60, "angle": 120, "distance": 5,
                                 "size": 8, "spread": 0, "blend": "multiply"},
            },
        }),
        _el(6, "06 Bevel / inner glow", {
            "captured_params": {
                "inner_glow": {"enabled": True, "color": [255, 255, 255],
                               "opacity": 50, "size": 8, "blend": "screen"},
            },
        }),
        _el(7, "07 Gradient overlay", {
            "captured_params": {
                "gradient_overlay": {"enabled": True, "opacity": 100,
                                     "blend": "normal", "angle": 90,
                                     "type": "linear", "reverse": False,
                                     "colors": [[[255, 255, 255], 0],
                                                [[255, 200, 0], 100]]},
            },
        }),
        _el(8, "08 Combined (shadow + glow + stroke)", {
            "captured_params": {
                "drop_shadow": {"enabled": True, "color": [0, 0, 0],
                                "opacity": 70, "angle": 90, "distance": 6,
                                "size": 10, "spread": 0, "blend": "multiply"},
                "outer_glow": {"enabled": True, "color": [255, 128, 0],
                               "opacity": 90, "size": 25, "spread": 10,
                               "blend": "screen"},
                "stroke": {"enabled": True, "color": [255, 255, 255],
                           "opacity": 100, "size": 2, "position": "outside",
                           "blend": "normal"},
            },
        }),
        _el(9, "09 Byte-exact captured style", {
            "captured_effects_hex": "0000",
            "captured_params": {
                "stroke": {"enabled": True, "color": [255, 255, 255],
                           "opacity": 100, "size": 2, "position": "outside",
                           "blend": "normal"},
            },
        }, size=48, color=(255, 240, 200)),
    ]


def render_validation_page(out_path, style_errors=None):
    """Render the 9-element validation page (8 types + captured style) to PNG.

    Works with or without Photoshop: with Photoshop the complex elements go
    through real Photoshop; without it every element falls back to the PIL
    preview path and ``style_errors`` (when given) records the elements that
    requested Photoshop. Returns a dict with per-element path resolution.
    """
    from .canonical_png import render_layout_pages
    from .page_layout import PageLayout

    elements = validation_elements()
    errors_list = style_errors if style_errors is not None else []
    layout = PageLayout(
        source={"page_id": "style_validation"},
        canvas={"width": 1920, "height": 80 + len(elements) * 96,
                "margin_x": 0, "margin_y": 0},
        elements=elements,
    )
    pages = render_layout_pages(
        [layout], bg_color="#101820", style_errors=errors_list,
    )
    if not pages:
        return {"image_path": None, "elements": []}
    pages[0].convert("RGB").save(out_path)
    resolution = []
    for el in elements:
        resolution.append({
            "id": el.id,
            "role": el.style_role,
            "path": element_style_path(el),
            "complex": is_complex_style(el.effects),
        })
    return {"image_path": out_path, "elements": resolution}