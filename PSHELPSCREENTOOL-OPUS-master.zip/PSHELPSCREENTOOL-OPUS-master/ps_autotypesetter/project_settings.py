"""Per-PSD UI/settings sidecar helpers."""

import json
import os
import datetime

SETTINGS_SUFFIX = ".pshelpscreen.settings.json"
SETTINGS_VERSION = 1


def settings_path_for_psd(psd_path):
    if not psd_path:
        return None
    base, _ = os.path.splitext(psd_path)
    return base + SETTINGS_SUFFIX


def load_settings_for_psd(psd_path):
    path = settings_path_for_psd(psd_path)
    if not path or not os.path.exists(path):
        return None
    with open(path, "r", encoding="utf-8") as handle:
        payload = json.load(handle)
    return payload.get("settings", payload)


def save_settings_for_psd(psd_path, settings):
    path = settings_path_for_psd(psd_path)
    if not path:
        return None
    payload = {
        "settings_version": SETTINGS_VERSION,
        "updated_at": datetime.datetime.now().isoformat(timespec="seconds"),
        "psd_file": os.path.abspath(psd_path),
        "settings": dict(settings or {}),
    }
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
    return path
