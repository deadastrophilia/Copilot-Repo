"""
PSAPI-backed PSD builder v2.  Reuses measurement / icon‑resolution utilities
but renders entirely through PSAPIRenderBackend — no Photoshop needed.

Layout algorithm ported from the COM build_engine.py to produce identical
layer positioning, spacing, icon alignment, and page break behaviour.

Handles:
  - Normal sheets (heading + body text + icons)
  - Game Rules sheets (upper text, separator, lower/legal text, XTRAA REELS)
  - Multiple columns
  - Page breaks with "(Continued)" headings
  - Background images
"""
import os, re, math, functools
from PIL import Image as PILImage
from openpyxl import load_workbook

from .psapi_render_backend import PSAPIRenderBackend
from .text_icon_renderer import _measure_text_cached, _get_font_path
from .icon_mapping import resolve_icon_path, get_icon_size_override
from .psapi_backend import resolve_font_psapi
from .build_engine import _render_window_for_sheet


# ── helpers ─────────────────────────────────────────────────────────────────

def _is_game_rules_sheet_name(name):
    normalized = re.sub(r"[^a-z0-9]+", "", str(name or "").casefold())
    return normalized.startswith("gamerules")


def _is_bingo_rules_sheet_name(name):
    normalized = re.sub(r"[^a-z0-9]+", "", str(name or "").casefold())
    return normalized.startswith("bingo")


def _col_letter(col_idx):
    """1‑based → 'A', 'B', … 'Z', 'AA' …"""
    letters = []
    while col_idx > 0:
        col_idx, r = divmod(col_idx - 1, 26)
        letters.append(chr(65 + r))
    return "".join(reversed(letters))


DEFAULT_ROW_GAP = 30
_PIL_INK_CACHE = {}
_PIL_INK_CACHE_MAX = 2048


def _baseline_from_top(top_y, font_size):
    """Convert visual-top y to Photoshop baseline y."""
    return top_y + font_size


@functools.lru_cache(maxsize=2048)
def _pil_ink_extents(font_px, font_name, text="Agjyp"):
    """(ink_top, ink_bottom, ascent) of the REAL rendered ink for a font."""
    try:
        fpx = max(1, int(round(float(font_px))))
    except Exception:
        fpx = 24
    result = (0.0, float(fpx + 2), float(fpx))
    try:
        from PIL import Image as _PI, ImageDraw as _PID, ImageFont as _PIF
        fpath = _get_font_path(font_name) if font_name else None
        font = _PIF.truetype(fpath, fpx) if fpath else _PIF.load_default()
        probe = _PI.new("RGBA", (64, 160), (0, 0, 0, 0))
        _PID.Draw(probe).text((2, 2), str(text or "Agjyp"), font=font, fill=(255, 255, 255, 255))
        bbox = probe.getbbox()
        ascent = float(font.getmetrics()[0])
        if bbox:
            result = (float(bbox[1] - 2), float(bbox[3] - 2), ascent)
    except Exception:
        pass
    return result


def _row_gap_step_px(font_px, font_name, text, icon_h, gap_px,
                      next_text="", next_icon_h=0.0, icon_y_offset=0.0):
    """Baseline-to-baseline step so the VISUAL gap between rows equals gap_px."""
    try:
        fpx = max(1, int(round(float(font_px))))
    except Exception:
        fpx = 24
    spacing = float(gap_px if gap_px is not None else DEFAULT_ROW_GAP)
    if spacing != spacing or spacing < 0:
        spacing = 0.0
    _it, _ib, _ascent = _pil_ink_extents(fpx, font_name, text)
    _yoff = max(0.0, float(icon_y_offset))
    prev_bottom_off = _ib
    _max_icon_h = float(icon_h or 0)
    if _max_icon_h > 0:
        prev_bottom_off = max(prev_bottom_off,
                              _ascent - float(fpx) * 0.35 + _max_icon_h / 2.0 + _yoff)
    _nit = _pil_ink_extents(fpx, font_name, next_text)[0]
    next_top_off = _nit
    _next_icon_h = float(next_icon_h or 0)
    if _next_icon_h > 0:
        next_top_off = min(next_top_off,
                           _ascent - float(fpx) * 0.35 - _next_icon_h / 2.0 + _yoff)
    return max(int(math.ceil(prev_bottom_off + spacing - next_top_off)), 1)


def _line_bottom_offset(line, font_size):
    """Max visual extent below the baseline for a line (text + icons)."""
    f = float(font_size)
    max_icon_h = max((e.get('scaled_h', 0) for e in line.get('elements', [])
                      if e.get('type') == 'icon'), default=0.0)
    _, ink_bottom, ascent = _pil_ink_extents(font_size, None,
                                              _line_text_str(line))
    bottom = max(ink_bottom, ascent - f * 0.35 + max_icon_h / 2.0)
    return bottom


def _line_text_str(line):
    """Extract concatenated text from a line dict."""
    return "".join(e.get('val', '') for e in line.get('elements', [])
                   if e.get('type') == 'text')


def _line_bottom_offset_simple(line, font_size):
    """Simple bottom offset estimate for page-break checks."""
    f = float(font_size)
    max_icon_h = max((e.get('scaled_h', 0) for e in line.get('elements', [])
                      if e.get('type') == 'icon'), default=0.0)
    return max(4.0, f * 0.35, float(max_icon_h) - f * 0.35)


# ── main entry point ────────────────────────────────────────────────────────

def execute_build_psapi(
    excel_path, icon_folder, bg_path, c_width, c_height, max_col_limit,
    h_font, h_size, h_icon_h, h_rgb,
    b_font, b_size, b_icon_h, b_rgb,
    margin_x, line_spacing, para_spacing, gap_px, icon_y_offset, row_spacing=None,
    bg_mode="stretch", table_style=None, enable_tables=True, bg_color="#FFFFFF",
    prev_excel_path=None, prev_psd_path=None, keyword_colors=None,
    heading_top_margin=150, continued_gap=15, heading_to_body_gap=40,
    heading_style=None, dynamic_settings=None, output_dir=None,
    icon_mappings=None, icon_size_overrides=None, bottom_margin=50,
    output_name=None, output_format="PSD", overwrite_existing=False,
    selected_sheets=None, preserve_selected_existing=False,
    body_icons_use_original_size=False, report_collector=None,
    body_style=None, icon_style=None, alignment_settings=None,
    progress_callback=None, cancel_event=None, show_completion_dialogs=True,
    performance_mode=False,
    icon_gap_left=None, icon_gap_right=None,
    heading_icon_gap=None,
    render_backend=None,
):
    # ── setup ──────────────────────────────────────────────────────────────
    _emit = (lambda **kw: None) if not callable(progress_callback) else (
        lambda **kw: progress_callback(kw))
    _cancel = (lambda: False) if cancel_event is None else (
        lambda: cancel_event.is_set())

    h_size = max(8, int(h_size or 36))
    b_size = max(6, int(b_size or 14))
    h_icon_h = max(8, int(h_icon_h or 20))
    b_icon_h = max(6, int(b_icon_h or 14))
    gap_px = max(0, int(gap_px or 2))
    icon_y_offset = int(icon_y_offset or 0)
    margin_x = max(0, int(margin_x or 60))
    heading_top_margin = max(0, int(heading_top_margin or 150))
    bottom_margin = max(0, int(bottom_margin or 50))
    max_y_limit = c_height - bottom_margin
    # Row Spacing (UI 'line_gap') is the single row-gap source for the psapi
    # path too: it applies to EVERY row's union bounding box -- text-only rows
    # included. An explicit `row_spacing` wins; otherwise read dynamic_settings.
    if row_spacing is None:
        try:
            _rs_raw = (dynamic_settings or {}).get("line_gap") if dynamic_settings else None
        except Exception:
            _rs_raw = None
        if _rs_raw is None or _rs_raw == "":
            row_spacing = 30
        else:
            try:
                row_spacing = max(0, int(round(float(_rs_raw))))
            except Exception:
                row_spacing = 30
    else:
        try:
            row_spacing = max(0, int(round(float(row_spacing))))
        except Exception:
            row_spacing = 30

    h_font_ps = resolve_font_psapi(h_font)
    b_font_ps = resolve_font_psapi(b_font)
    h_rgb_t = tuple(h_rgb or (255, 200, 50))
    b_rgb_t = tuple(b_rgb or (200, 200, 200))

    edit_log = []

    # ── open workbooks ─────────────────────────────────────────────────────
    wb = load_workbook(excel_path, data_only=True)
    from .workbook_cache import load_formatted

    wb_fmt = load_formatted(excel_path)                # formula cells hold their results, not their formulas

    current_names = set(wb.sheetnames)
    target_names = set()
    if selected_sheets:
        for s in (selected_sheets if isinstance(selected_sheets, (list, tuple, set)) else [selected_sheets]):
            sn = str(s).strip()
            if sn in current_names:
                target_names.add(sn)
    if not target_names:
        target_names = current_names
    order = [n for n in wb.sheetnames if n in target_names]

    # ── document ───────────────────────────────────────────────────────────
    backend = render_backend if render_backend is not None else PSAPIRenderBackend()
    backend.create_document(c_width, c_height)

    # ── caches ─────────────────────────────────────────────────────────────
    font_cache = {}
    icon_cache = {}           # name → {'pil': PIL.Image, 'w': int, 'h': int}
    missing_icons = set()

    def measure_text(text, font_size, f_name):
        return _measure_text_cached(text, font_size, f_name, None, font_cache)

    def resolve_icon(name, target_h):
        """Return (PIL.Image, scaled_w, scaled_h) or None."""
        if name in icon_cache:
            info = icon_cache[name]
            ratio = info['w'] / max(info['h'], 1)
            scaled_h = max(1, target_h)
            scaled_w = max(1, int(scaled_h * ratio))
            return info['pil'], scaled_w, scaled_h
        path = resolve_icon_path(name, icon_folder, icon_mappings)
        if not path or not os.path.isfile(path):
            missing_icons.add(name)
            return None
        try:
            pil = PILImage.open(path).convert("RGBA")
            w, h = pil.size
            icon_cache[name] = {'pil': pil, 'w': w, 'h': h}
            ratio = w / max(h, 1)
            scaled_h = max(1, target_h)
            scaled_w = max(1, int(scaled_h * ratio))
            return pil, scaled_w, scaled_h
        except Exception:
            missing_icons.add(name)
            return None

    # ── layout helpers ─────────────────────────────────────────────────────
    max_line_w = max(50, c_width - margin_x * 2)

    def _line_start_x(lw, align="center", box_l=None, box_w=None):
        left = int(box_l or margin_x)
        width = int(box_w or (c_width - margin_x * 2))
        if align == "left":
            return float(left)
        if align == "right":
            return float(left + width - lw)
        return float(left + (width - lw) / 2)

    def _build_parsed_lines(raw, font_sz, f_name, icon_h, local_max=None):
        """Parse text + <icon> tokens into line dicts (same structure as original)."""
        _max_w = local_max or max_line_w
        parts = re.split(r'(<[^>]+>)', str(raw or ""))
        for _pi in range(len(parts)):
            _pp = parts[_pi]
            if not _pp or (_pp.startswith('<') and _pp.endswith('>')):
                continue
            _prev_is_token = _pi > 0 and parts[_pi - 1].startswith('<') and parts[_pi - 1].endswith('>')
            _next_is_token = _pi + 1 < len(parts) and parts[_pi + 1].startswith('<') and parts[_pi + 1].endswith('>')
            if _prev_is_token:
                parts[_pi] = _pp.lstrip()
            if _next_is_token:
                parts[_pi] = parts[_pi].rstrip()
        lines, cur_line, cur_w = [], [], 0.0
        for part in parts:
            if not part:
                continue
            if part.startswith('<') and part.endswith('>'):
                icon_name = part[1:-1].strip(" .;,-!")
                ri = resolve_icon(icon_name, icon_h)
                if ri is None:
                    fb = f"<{icon_name}>"
                    fb_w = measure_text(fb, font_sz, f_name)
                    if cur_w + fb_w > _max_w and cur_line:
                        lines.append({'elements': cur_line, 'width': cur_w})
                        cur_line, cur_w = [], 0
                    cur_line.append({'type': 'text', 'val': fb, 'w': fb_w})
                    cur_w += fb_w
                    continue
                pil_img, scaled_w, scaled_h = ri
                _gap_l = gap_px if icon_gap_left is None else max(0, int(icon_gap_left))
                _gap_r = gap_px if icon_gap_right is None else max(0, int(icon_gap_right))
                w = _gap_l + scaled_w + _gap_r
                if cur_w + w > _max_w and cur_line:
                    lines.append({'elements': cur_line, 'width': cur_w})
                    cur_line, cur_w = [], 0
                cur_line.append({
                    'type': 'icon', 'val': icon_name,
                    'w': w, 'icon_h': icon_h,
                    'pil': pil_img, 'scaled_w': scaled_w, 'scaled_h': scaled_h,
                })
                cur_w += w
            else:
                full_w = measure_text(part, font_sz, f_name)
                if cur_w + full_w <= _max_w:
                    cur_line.append({'type': 'text', 'val': part, 'w': full_w})
                    cur_w += full_w
                else:
                    for word in re.split(r'( )', part):
                        if not word:
                            continue
                        ww = measure_text(word, font_sz, f_name)
                        if cur_w + ww > _max_w:
                            if word == ' ':
                                continue
                            if cur_line:
                                lines.append({'elements': cur_line, 'width': cur_w})
                            cur_line, cur_w = [], 0
                        cur_line.append({'type': 'text', 'val': word, 'w': ww})
                        cur_w += ww
        if cur_line:
            lines.append({'elements': cur_line, 'width': cur_w})
        return lines

    def _line_step_for_line(line, font_sz, next_icon_h=0.0, local_line_step=None, font_name=None, next_line=None):
        """Baseline-to-baseline step using ink-extent measurement from COM."""
        line_text = _line_text_str(line)
        next_text = _line_text_str(next_line) if next_line else ""
        return _row_gap_step_px(
            font_sz, font_name, line_text,
            max((e.get('scaled_h', 0) for e in line.get('elements', []) if e.get('type') == 'icon'), default=0),
            row_spacing, icon_y_offset=icon_y_offset,
            next_text=next_text, next_icon_h=next_icon_h,
        )

    def _line_bottom_offset_for_line(line, font_sz):
        """Max visual extent below baseline for a line."""
        max_icon_h = max((e.get('scaled_h', 0) for e in line.get('elements', [])
                          if e.get('type') == 'icon'), default=0.0)
        return max(4.0, float(font_sz) * 0.35,
                   float(max_icon_h) - float(font_sz) * 0.35 + abs(float(icon_y_offset)))

    def _line_fits_at(baseline_y, font_sz, line=None, local_line_step=None):
        if line is None:
            return (baseline_y + max(4, font_sz * 0.35)) <= max_y_limit
        return (baseline_y + _line_bottom_offset_for_line(line, font_sz)) <= max_y_limit

    def _render_lines(lines, font_sz, f_name, icon_h, color_rgb, parent_group, start_y,
                      local_gap=None, local_step=None, alignment="center",
                      box_left=None, box_width=None, row_spacing=0):
        """Render parsed lines into per-line 'Centered Line N' groups with
        'Body Text' + 'Body Icons' sub-groups, matching COM engine structure.

        start_y is a **baseline** coordinate. Returns the next baseline y.
        """
        active_gap = gap_px if local_gap is None else max(0, int(local_gap))
        if local_gap is not None:
            _gap_l = _gap_r = active_gap
        else:
            _gap_l = active_gap if icon_gap_left is None else max(0, int(icon_gap_left))
            _gap_r = active_gap if icon_gap_right is None else max(0, int(icon_gap_right))
        cur_y = start_y
        for line_index, line in enumerate(lines, start=1):
            icons_in_line = [e.get('scaled_h', 0) for e in line['elements'] if e.get('type') == 'icon']
            next_line = lines[line_index] if line_index < len(lines) else None
            next_icons = [
                e.get('scaled_h', 0) for e in (next_line or {}).get('elements', [])
                if e.get('type') == 'icon'
            ] if next_line else []
            next_h = max(next_icons, default=0.0)
            step = _line_step_for_line(line, font_sz, next_icon_h=next_h,
                                       font_name=f_name, next_line=next_line)
            row_group = backend.create_group(parent_group, f"Centered Line {line_index}")
            text_group = backend.create_group(row_group, "Body Text")
            line_has_icons = any(e.get('type') == 'icon' for e in line['elements'])
            icon_group = backend.create_group(row_group, "Body Icons") if line_has_icons else None
            start_x = _line_start_x(line['width'], alignment, box_left, box_width)
            cx = start_x
            for item in line['elements']:
                if item['type'] == 'text':
                    txt = item['val']
                    if txt.strip():
                        try:
                            backend.create_text_layer(text_group, txt, f_name, font_sz,
                                                       color_rgb, cx, cur_y, "Text")
                        except Exception as _texc:
                            print(f"[WARN] create_text_layer failed: {_texc}")
                    cx += measure_text(txt, font_sz, f_name)
                elif item['type'] == 'icon':
                    cx += _gap_l
                    center_y = cur_y - (font_sz * 0.35)
                    target_y = center_y - (item['icon_h'] / 2) + icon_y_offset
                    pil_img = item.get('pil')
                    if pil_img:
                        target_group = icon_group or row_group
                        resized = pil_img.resize((item['scaled_w'], item['scaled_h']), PILImage.LANCZOS)
                        backend.create_image_layer(target_group, resized, item['val'],
                                                    int(cx), int(target_y))
                    cx += item['w'] - (_gap_l + _gap_r) + _gap_r
            cur_y += step
        return cur_y

    # ── background ──────────────────────────────────────────────────────────
    # Deferred: background will be added AFTER all content layers so it
    # sits at the bottom of the layer stack in Photoshop.
    _bg_info = None
    if bg_path and os.path.isfile(bg_path) or bg_mode == "color":
        _bg_info = (bg_path, c_width, c_height, bg_mode, bg_color)
    else:
        _bg_info = ("", c_width, c_height, "color", bg_color)

    # ── sheet loop ──────────────────────────────────────────────────────────
    for tab_name in order:
        if _cancel():
            break
        _emit(event="sheet_start", sheet=tab_name)

        sheet = wb[tab_name]
        sheet_fmt = wb_fmt[tab_name]
        is_game_rules = _is_game_rules_sheet_name(tab_name)
        _page_min_row, _page_max_row, _page_min_col, _page_max_col = _render_window_for_sheet(
            dynamic_settings or {}, tab_name, max_col_limit, sheet,
        )
        _col_max = _page_max_col
        page_num = 1

        tab_group = backend.create_group(backend.doc, f"{tab_name} (Page {page_num})")
        current_y = heading_top_margin

        def start_new_page(continued=True):
            nonlocal current_y, page_num, tab_group
            page_num += 1
            tab_group = backend.create_group(backend.doc, f"{tab_name} (Page {page_num})")
            current_y = heading_top_margin

            if continued and heading_text:
                h_group = backend.create_group(tab_group, "Heading (Continued)")
                h_text_group = backend.create_group(h_group, "Heading Text")
                h_symbol_group = backend.create_group(h_group, "Heading Symbols")
                _heading_w = measure_text(heading_text, h_size, h_font)
                _heading_x = max(0.0, (float(c_width) - float(_heading_w)) / 2.0)
                heading_baseline = _baseline_from_top(heading_top_margin, h_size)
                try:
                    backend.create_text_layer(h_text_group, heading_text, h_font_ps, h_size,
                                               h_rgb_t, _heading_x, heading_baseline, "Heading")
                except Exception:
                    pass
                continued_font_size = max(8, b_size - 10)
                continued_text = "(Continued)"
                _cont_w = measure_text(continued_text, continued_font_size, b_font)
                _cont_x = (c_width - _cont_w) / 2.0
                continued_y = _baseline_from_top(heading_top_margin + h_size + continued_gap, continued_font_size)
                try:
                    backend.create_text_layer(tab_group, continued_text, b_font_ps, continued_font_size,
                                               b_rgb_t, _cont_x, continued_y, "Continued Label")
                except Exception:
                    pass
                current_y = heading_top_margin + h_size + continued_gap + continued_font_size + heading_to_body_gap
            return tab_group

        # ── read cells ─────────────────────────────────────────────────────
        full_rows = []
        for row in sheet.iter_rows(min_row=_page_min_row, max_row=_page_max_row,
                                    min_col=_page_min_col, max_col=_col_max):
            cells = []
            for cell in row:
                val = str(cell.value or "").strip()
                if not val:
                    continue
                fmt_cell = sheet_fmt.cell(row=cell.row, column=cell.column)
                is_bold = bool(fmt_cell.font and fmt_cell.font.b) if fmt_cell and fmt_cell.font else False
                cells.append({
                    'row': cell.row, 'col': cell.column,
                    'text': val, 'bold': is_bold,
                })
            if cells:
                full_rows.append(cells)

        # ── determine heading and body ──────────────────────────────────────
        heading_text = ""
        body_contents = []

        if is_game_rules:
            # Game rules: first bold non-empty in first column range = heading
            # Rest split into upper (game rules) and lower (legal/malfunction)
            def _is_malfunction(value):
                t = re.sub(r"<[^>]+>", "", str(value or "")).strip().casefold()
                if not t:
                    return False
                return "malfunction" in t or "voids all pays" in t or "all pays and plays" in t
            found_lower = False
            for cells in full_rows:
                for c in cells:
                    low = c['text'].lower()
                    if not heading_text and c['bold']:
                        heading_text = c['text']
                        continue
                    if low.rstrip('>') in ("<<modified", "<removed", "<added", "<deleted") or \
                       low in ("modified", "removed", "added", "deleted"):
                        continue
                    if not found_lower and _is_malfunction(c['text']):
                        found_lower = True
                    body_contents.append({'text': c['text'], 'bottom': found_lower})
        else:
            # Normal sheet
            for cells in full_rows:
                for c in cells:
                    if c['bold'] and not heading_text:
                        heading_text = c['text']
                    else:
                        body_contents.append({'text': c['text'], 'bottom': False})

        # ── render heading ──────────────────────────────────────────────────
        if heading_text:
            _heading_w = measure_text(heading_text, h_size, h_font)
            _heading_x = max(0.0, (float(c_width) - float(_heading_w)) / 2.0)
            heading_baseline = _baseline_from_top(heading_top_margin, h_size)
            h_group = backend.create_group(tab_group, "Heading")
            h_text_group = backend.create_group(h_group, "Heading Text")
            h_symbol_group = backend.create_group(h_group, "Heading Symbols")
            try:
                backend.create_text_layer(h_text_group, heading_text, h_font_ps, h_size,
                                           h_rgb_t, _heading_x, heading_baseline, "Heading")
            except Exception as _h_exc:
                print(f"[WARN] Heading text layer failed: {_h_exc}")
            current_y = heading_top_margin + h_size + heading_to_body_gap

        # ── render body / game rules ─────────────────────────────────────────────────
        def _line_icons(line):
            return [e.get('scaled_h', 0) for e in line.get('elements', []) if e.get('type') == 'icon']

        def _render_paragraph_paged(lines, font_sz, icon_h, color_rgb, align,
                                    box_left=None, box_width=None):
            """Render one paragraph's rows with a PER-LINE page break.

            current_y tracks visual-top. We convert to baseline when calling
            _render_lines and when checking page-break fit.
            """
            nonlocal current_y, tab_group
            while lines:
                first_baseline = _baseline_from_top(current_y, font_sz)
                if not _line_fits_at(first_baseline, font_sz, line=lines[0]):
                    tab_group = start_new_page()
                    first_baseline = _baseline_from_top(current_y, font_sz)
                page_lines = []
                probe_y = current_y
                for li, line in enumerate(lines):
                    probe_baseline = _baseline_from_top(probe_y, font_sz)
                    if page_lines and not _line_fits_at(probe_baseline, font_sz, line=line):
                        break
                    page_lines.append(line)
                    next_line = lines[li + 1] if li + 1 < len(lines) else None
                    next_h = max((e.get('scaled_h', 0) for e in (next_line or {}).get('elements', [])
                                  if e.get('type') == 'icon'), default=0.0)
                    probe_y += _line_step_for_line(
                        line, font_sz, next_icon_h=next_h, font_name=b_font, next_line=next_line,
                    )
                if not page_lines:
                    page_lines = [lines[0]]
                first_baseline = _baseline_from_top(current_y, font_sz)
                current_y = _render_lines(page_lines, font_sz, b_font_ps, icon_h,
                                           color_rgb, tab_group, first_baseline,
                                           alignment=align,
                                           box_left=box_left, box_width=box_width,
                                           row_spacing=row_spacing)
                lines = lines[len(page_lines):]
                if lines:
                    tab_group = start_new_page()
                    current_y = _baseline_from_top(current_y, font_sz) - font_sz

        if is_game_rules:
            upper_texts = [e['text'] for e in body_contents if not e['bottom']]
            lower_texts = [e['text'] for e in body_contents if e['bottom']]
            print(f"[GR] tab={tab_name!r} heading={heading_text!r} upper={len(upper_texts)} lower={len(lower_texts)} y={current_y}")
            if upper_texts:
                for i, t in enumerate(upper_texts[:3]):
                    print(f"[GR]   upper[{i}]={t[:80]!r}")
            if lower_texts:
                for i, t in enumerate(lower_texts[:3]):
                    print(f"[GR]   lower[{i}]={t[:80]!r}")
            para_gap = max(6, int(para_spacing))

            for txt in upper_texts:
                if _cancel():
                    break
                lines = _build_parsed_lines(txt, b_size, b_font_ps, b_icon_h)
                _render_paragraph_paged(lines, b_size, b_icon_h, b_rgb_t, "center")
                current_y += para_gap

            if lower_texts:
                lower_baseline = _baseline_from_top(current_y, b_size)
                if not _line_fits_at(lower_baseline, b_size):
                    tab_group = start_new_page()
                current_y += 6
                sep_w = max(100, min(max_line_w, c_width - 40))
                sep_h = max(1, 2)
                sep_color = b_rgb_t
                sep_x = int((c_width - sep_w) / 2)
                backend.create_shape_layer(tab_group, int(sep_w), int(sep_h), sep_color,
                                            int(sep_x), int(current_y), "Separator")
                current_y += sep_h + 12

            lower_margin = int(dynamic_settings.get("game_rules_bottom_lr_margin", 200)) if dynamic_settings else 200
            lower_font_sz = max(8, b_size - 4)
            lower_icon_h = max(8, b_icon_h - 4)
            lower_box_w = max(100, c_width - lower_margin * 2)
            for txt in lower_texts:
                if _cancel():
                    break
                lines = _build_parsed_lines(txt, lower_font_sz, b_font_ps, lower_icon_h,
                                             local_max=lower_box_w)
                _render_paragraph_paged(lines, lower_font_sz, lower_icon_h, b_rgb_t, "left",
                                        box_left=lower_margin, box_width=lower_box_w)
                current_y += para_gap
        else:
            for entry in body_contents:
                if _cancel():
                    break
                txt = entry['text']
                lines = _build_parsed_lines(txt, b_size, b_font_ps, b_icon_h)
                _render_paragraph_paged(lines, b_size, b_icon_h, b_rgb_t, "center")
                current_y += int(para_spacing) if para_spacing else b_size


        _emit(event="sheet_done", sheet=tab_name)

    # ── deferred background (added last → renders at bottom) ────────────────
    if _bg_info:
        try:
            backend.apply_background(*_bg_info)
        except Exception as e:
            edit_log.append(f"Background skipped: {e}")

    # ── save ────────────────────────────────────────────────────────────────
    if not output_dir:
        output_dir = os.path.dirname(excel_path)
    if not output_name:
        base = os.path.splitext(os.path.basename(excel_path))[0]
        output_name = f"{base}_psapi.psd"
    if not os.path.splitext(output_name)[1].lower() in (".psd", ".psb"):
        output_name = output_name + ".psd"
    out_path = os.path.join(output_dir, output_name)
    if os.path.exists(out_path) and not overwrite_existing:
        base, ext = os.path.splitext(out_path)
        idx = 1
        while os.path.exists(f"{base}_{idx}{ext}"):
            idx += 1
        out_path = f"{base}_{idx}{ext}"

    backend.save(out_path)
    file_size = os.path.getsize(out_path)
    edit_log.append(f"Saved {out_path} ({file_size} bytes)")

    return {
        "path": out_path,
        "size": file_size,
        "sheets": len(order),
        "icons_missing": list(missing_icons),
        "log": edit_log,
    }
