"""fx_scale — a layer style's effects grow and shrink with the text it is on.

A style is made for text of one size: a 4 px stroke on a 120 px heading is far too thick on 40 px
body text. A style config remembers the text size it was copied at (``fx_base_size``, px) and how it
follows the text (``fx_scale_mode``):

  "proportional"  lengths × (text size ÷ fx_base_size) — the default for styles copied with a size;
  "original"      lengths exactly as copied — what every style without a size keeps (nothing changes);
  "custom"        lengths × ``fx_scale_pct`` / 100, whatever the text size.

Only lengths in px change: stroke size, shadow / inner shadow distance and size, glow size, bevel
size and soften, satin distance and size (and the old flat stroke_size / shadow_distance /
shadow_size). Opacity, colours, blend modes, angles, contours and every percentage (spread, range,
depth, gradient scale) stay. Each scaled value is worked out from the copied value — never from an
already scaled one — and rounded to whole px (half up), as Photoshop's Layer Style dialog keeps them;
a length that was above 0 never becomes 0.

``scaled(cfg, size)`` is the one entry point: the PNG text renderer (png_builder._draw_text_visual),
the editable PSD (psd_writer.recorder.TextRecord: the descriptor bytes themselves are rewritten) and
the Canvas (static/ps_fx_canvas.js PsFx.scaleFor, the 1:1 twin of this file) all call it with the
drawn font size, so all three draw the same numbers. The copy it returns is marked "original", so it
is never scaled twice.
"""
import functools
import io
import math

MODES = ("proportional", "original", "custom")

# captured_params effect -> its lengths (px)
LENGTHS = {
    "drop_shadow": ("distance", "size"), "inner_shadow": ("distance", "size"),
    "outer_glow": ("size",), "inner_glow": ("size",),
    "stroke": ("size",),
    "bevel": ("size", "soften"),
    "satin": ("distance", "size"),
}
FLAT = ("stroke_size", "shadow_distance", "shadow_size")

# the same lengths in a Photoshop effects descriptor (fx_descriptor reads them from these keys)
_DESC = {
    "DrSh": ("Dstn", "blur"), "dropShadowMulti": ("Dstn", "blur"),
    "IrSh": ("Dstn", "blur"), "innerShadowMulti": ("Dstn", "blur"),
    "OrGl": ("blur",), "IrGl": ("blur",),
    "FrFX": ("Sz  ",), "frameFXMulti": ("Sz  ",),
    "ebbl": ("blur", "Sftn"),
    "ChFX": ("Dstn", "blur"),
}


def _num(v):
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    return f if math.isfinite(f) else None


def base_size(cfg):
    """The text size (px) the style was copied at, or None."""
    b = _num((cfg or {}).get("fx_base_size")) if isinstance(cfg, dict) else None
    return b if b and b > 0 else None


def mode(cfg):
    """How the style follows the text size (see the module docstring)."""
    if not isinstance(cfg, dict):
        return "original"
    m = str(cfg.get("fx_scale_mode") or "").strip().lower()
    if m in MODES:
        return m
    return "proportional" if base_size(cfg) else "original"


def factor(cfg, size):
    """What the style's lengths are multiplied by for text of `size` px (1.0 = as copied)."""
    m = mode(cfg)
    if m == "custom":
        pct = _num(cfg.get("fx_scale_pct"))
        return pct / 100.0 if pct is not None and pct > 0 else 1.0
    if m == "proportional":
        b, s = base_size(cfg), _num(size)
        if b and s and s > 0:
            return s / b
    return 1.0


def length(value, f):
    """One scaled length: whole px, half up; above 0 stays at least 1."""
    v = _num(value)
    if v is None:
        return value
    out = math.floor(v * f + 0.5)
    if v > 0 and out < 1:
        out = 1
    return float(out)


def _scale_effect(eff, keys, f):
    if not isinstance(eff, dict):
        return eff
    out = dict(eff)
    for k in keys:
        if k in out:
            out[k] = length(out[k], f)
    return out


def scale_params(params, f):
    """captured_params with every length × f (a copy; the same dict when f is 1)."""
    if not isinstance(params, dict) or f == 1.0:
        return params
    out = dict(params)
    for kind, keys in LENGTHS.items():
        eff = out.get(kind)
        if isinstance(eff, list):
            out[kind] = [_scale_effect(e, keys, f) for e in eff]
        elif isinstance(eff, dict):
            out[kind] = _scale_effect(eff, keys, f)
    for k in FLAT:
        if k in out:
            out[k] = length(out[k], f)
    return out


# ── the descriptor bytes (what the PSD gets) ────────────────────────────────
def _set_lengths(item, keys, f):
    for k in keys:
        node = item.get(k.encode("latin-1")) if hasattr(item, "get") else None
        if node is not None and hasattr(node, "value") and _num(node.value) is not None:
            node.value = length(node.value, f)


@functools.lru_cache(maxsize=256)
def _scale_stream(data, f):
    from psd_tools.psd.descriptor import DescriptorBlock

    desc = DescriptorBlock.read(io.BytesIO(data))
    for key, value in list(desc.items()):
        name = key.decode("latin-1").rstrip("\x00") if isinstance(key, bytes) else str(key)
        keys = _DESC.get(name)
        if not keys:
            continue
        items = value if (hasattr(value, "__iter__") and not hasattr(value, "items")) else [value]
        for item in items:
            _set_lengths(item, keys, f)
    buf = io.BytesIO()
    desc.write(buf)
    out = buf.getvalue()
    # psd-tools pads the stream to an even length; Photoshop's own stream has no pad (the numbers
    # changed are fixed-size doubles, so everything else is byte for byte the copied stream)
    if len(out) > len(data) and not out[len(data):].strip(b"\x00"):
        out = out[:len(data)]
    return out


def scale_hex(raw_hex, f):
    """An effects hex (capture "00xx" per byte, or plain byte hex; with or without the 4-byte
    object-effects version) with its lengths × f, in the same form. None when it can't be read."""
    from . import fx_descriptor

    raw = fx_descriptor._HEX_RE.sub("", str(raw_hex or ""))
    data = fx_descriptor.descriptor_bytes(raw)
    if data is None:
        return None
    wide = len(raw) % 4 == 0 and all(raw[i:i + 2] == "00" for i in range(0, len(raw), 4))
    whole = bytes(int(raw[i:i + 4], 16) for i in range(0, len(raw), 4)) if wide else bytes.fromhex(raw[: len(raw) // 2 * 2])
    prefix = whole[:4] if whole[:8] == b"\x00\x00\x00\x00\x00\x00\x00\x10" else b""
    try:
        out = prefix + _scale_stream(data, f)
    except Exception as exc:  # a descriptor psd-tools can't write back: keep it as copied
        print(f"[fx_scale] could not scale the effects descriptor: {exc}")
        return None
    return "".join(f"{b:04x}" for b in out) if wide else out.hex()


def scaled(cfg, size):
    """The style config as drawn on text of `size` px: lengths scaled from the copied values in the
    descriptor bytes, captured_params and the old flat keys. The same config when nothing changes."""
    if not isinstance(cfg, dict):
        return cfg
    f = factor(cfg, size)
    if abs(f - 1.0) < 1e-9:
        return cfg
    out = dict(cfg)
    if out.get("captured_effects_hex"):
        h = scale_hex(out["captured_effects_hex"], f)
        if h is not None:
            out["captured_effects_hex"] = h
    block = out.get("effects_block")
    if isinstance(block, dict) and block.get("hex"):
        h = scale_hex(block["hex"], f)
        if h is not None:
            out["effects_block"] = dict(block, hex=h)
    if isinstance(out.get("captured_params"), dict):
        out["captured_params"] = scale_params(out["captured_params"], f)
    for k in FLAT:
        if k in out:
            out[k] = length(out[k], f)
    out["fx_scale_mode"] = "original"            # drawn values: never scaled again
    out["fx_applied_scale"] = f
    return out


def role_size(cfg, role):
    """The text size (px) a project gives a style role ("Heading text", ...), or None."""
    cfg = cfg if isinstance(cfg, dict) else {}
    ds = cfg.get("dynamic_settings") if isinstance(cfg.get("dynamic_settings"), dict) else {}
    value = {"Heading text": cfg.get("h_size"), "Body text": cfg.get("b_size"),
             "Subheading text": ds.get("subheading_size")}.get(str(role or ""))
    v = _num(value)
    return v if v and v > 0 else None


def remember_size(cfg, size, mode_=None):
    """A style config that remembers the text size it was copied at (proportional unless told)."""
    if not isinstance(cfg, dict):
        return cfg
    s = _num(size)
    if not s or s <= 0:
        return cfg
    out = dict(cfg)
    out["fx_base_size"] = round(s, 2)
    out["fx_scale_mode"] = mode_ if mode_ in MODES else (cfg.get("fx_scale_mode") if cfg.get("fx_scale_mode") in MODES
                                                         else "proportional")
    return out
