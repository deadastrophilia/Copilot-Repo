"""Run JSX in whatever Photoshop is available — any installed version.

COM ("Photoshop.Application") always means the ONE version registered for
automation; when the artist has a different version open, COM tries to start
the registered one and fails ("Server execution failed"). This bridge:

  1. finds a running Photoshop.exe (any version);
  2. if it is the registered one -> COM doJavaScript (fast, direct result);
  3. otherwise -> opens a wrapper .jsx with THAT Photoshop's own executable
     (every version runs a script it is asked to open) and reads the result
     the wrapper writes to a temp file;
  4. with no Photoshop running -> COM (starts the registered version).

run_jsx() returns what doJavaScript would: the script's last value as a string.
Building help screens never needs this (psd_writer is Photoshop-free); it is
for the interactive features that act on the artist's open document.
"""
import json
import os
import subprocess
import tempfile
import time
import uuid


class PhotoshopUnavailable(RuntimeError):
    pass


def _norm(path):
    return os.path.normcase(os.path.abspath(str(path or "").strip().strip('"')))


def registered_photoshop():
    """Executable registered for COM automation ("Photoshop.Application"), or ""."""
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, r"Photoshop.Application\CLSID") as k:
            clsid = winreg.QueryValue(k, None)
        with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, rf"CLSID\{clsid}\LocalServer32") as k:
            cmd = winreg.QueryValue(k, None)
    except Exception:
        return ""
    cmd = cmd.strip()
    if cmd.startswith('"'):
        return cmd[1:].split('"', 1)[0]
    return cmd.split(" /", 1)[0]


_PROGIDS = None


def version_progids():
    """{exe: ProgID} of every version-specific "Photoshop.Application.NNN" COM registration.

    Each Photoshop version installs its own ProgID next to the shared "Photoshop.Application" (here:
    ".170" -> Photoshop 2023 while the shared one -> 2026). Through it COM reaches THAT running version
    directly — no script file handed to Photoshop.exe, which makes Photoshop ask before running it."""
    global _PROGIDS
    if _PROGIDS is not None:
        return _PROGIDS
    found = {}
    try:
        import winreg

        i = 0
        while True:
            try:
                name = winreg.EnumKey(winreg.HKEY_CLASSES_ROOT, i)
            except OSError:
                break
            i += 1
            if not name.startswith("Photoshop.Application."):
                continue
            try:
                with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, rf"{name}\CLSID") as k:
                    clsid = winreg.QueryValue(k, None)
                with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, rf"CLSID\{clsid}\LocalServer32") as k:
                    cmd = winreg.QueryValue(k, None).strip()
            except OSError:
                continue
            exe = cmd[1:].split('"', 1)[0] if cmd.startswith('"') else cmd.split(" /", 1)[0]
            found.setdefault(_norm(exe), name)
    except Exception:
        pass
    _PROGIDS = found
    return found


def running_photoshops():
    """[(pid, exe)] of running Photoshop instances, any version."""
    out = []
    try:
        import psutil
        for p in psutil.process_iter(["pid", "name", "exe"]):
            if str(p.info.get("name") or "").casefold() == "photoshop.exe" and p.info.get("exe"):
                out.append((p.info["pid"], p.info["exe"]))
    except Exception:
        pass
    return out


def describe():
    """{'running': [exe...], 'registered': exe, 'route': 'com'|'file'|'none', 'progid': COM ProgID}."""
    running = [exe for _, exe in running_photoshops()]
    registered = registered_photoshop()
    progid = "Photoshop.Application"
    if not running:
        route = "com" if registered else "none"
    elif registered and any(_norm(e) == _norm(registered) for e in running):
        route = "com"
    else:
        own = version_progids().get(_norm(running[0]))
        route, progid = ("com", own) if own else ("file", "")
    return {"running": running, "registered": registered, "route": route, "progid": progid}


def _dispatch(progid):
    import pythoncom
    import win32com.client
    pythoncom.CoInitialize()
    return win32com.client.Dispatch(progid)


def _run_com(jsx, args, app=None):
    app = app if app is not None else _dispatch("Photoshop.Application")
    if args is not None:
        path = os.path.join(tempfile.gettempdir(), f"psh_bridge_{uuid.uuid4().hex}.jsx")
        with open(path, "w", encoding="utf-8") as f:
            f.write(jsx)
        try:
            return str(app.DoJavaScriptFile(path, list(args)) or "")
        finally:
            _remove(path)
    return str(app.DoJavaScript(jsx) or "")


def _js_path(path):
    return path.replace("\\", "/")


def _run_file(exe, jsx, args, timeout):
    work = tempfile.gettempdir()
    token = uuid.uuid4().hex
    script_path = os.path.join(work, f"psh_bridge_{token}.jsx")
    out_path = os.path.join(work, f"psh_bridge_{token}.out")
    # The wrapper evaluates the script at top level (like doJavaScript, the
    # last expression is the result), writes "OK\n<result>" or "ERR\n<msg>"
    # to a .part file and renames it so the reader never sees a partial file.
    wrapper = (
        "var arguments = " + json.dumps([str(a) for a in (args or [])]) + ";\n"
        "var __psh_out = new File(" + json.dumps(_js_path(out_path) + ".part") + ");\n"
        "var __psh_res;\n"
        # top-level eval: the script sees `arguments` above and its last value is the result
        "try { __psh_res = 'OK\\n' + String(eval(" + json.dumps(jsx) + ")); }\n"
        "catch (__psh_e) { __psh_res = 'ERR\\n' + String(__psh_e); }\n"
        "__psh_out.encoding = 'UTF-8'; __psh_out.open('w'); __psh_out.write(__psh_res); __psh_out.close();\n"
        "__psh_out.rename(" + json.dumps(os.path.basename(out_path)) + ");\n"
    )
    with open(script_path, "w", encoding="utf-8") as f:
        f.write(wrapper)
    try:
        subprocess.Popen([exe, script_path], close_fds=True)
        deadline = time.time() + float(timeout)
        while time.time() < deadline:
            if os.path.exists(out_path):
                with open(out_path, encoding="utf-8", errors="replace") as f:
                    status, _, body = f.read().partition("\n")
                if status == "OK":
                    return body
                raise RuntimeError(f"Photoshop script error: {body}")
            time.sleep(0.2)
        raise PhotoshopUnavailable(f"Photoshop ({exe}) did not run the script within {timeout:.0f}s "
                                   "— is a dialog open in Photoshop?")
    finally:
        _remove(script_path)
        _remove(out_path)


def _remove(path):
    try:
        os.remove(path)
    except OSError:
        pass


def run_jsx(jsx, args=None, timeout=300):
    """Run ExtendScript in the available Photoshop; returns its result string."""
    info = describe()
    if info["route"] == "none":
        raise PhotoshopUnavailable("Photoshop is not installed or not registered, and none is running.")
    if info["route"] == "com":
        if info["progid"] != "Photoshop.Application":
            try:
                app = _dispatch(info["progid"])
            except Exception as exc:   # that version's COM won't connect: the script-file route as before
                print(f"[photoshop_bridge] {info['progid']} did not connect ({exc}); running a script file")
                return _run_file(info["running"][0], jsx, args, timeout)
            return _run_com(jsx, args, app=app)
        return _run_com(jsx, args)
    return _run_file(info["running"][0], jsx, args, timeout)


def run_jsx_file(path, args=None, timeout=300):
    with open(path, encoding="utf-8") as f:
        return run_jsx(f.read(), args=args, timeout=timeout)


def photoshop_version(timeout=30):
    """Version string of the Photoshop run_jsx would use (starts none)."""
    if not running_photoshops():
        return ""
    return run_jsx("app.version", timeout=timeout)
