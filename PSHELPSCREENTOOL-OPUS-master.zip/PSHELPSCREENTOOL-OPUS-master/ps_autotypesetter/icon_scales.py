"""Icon sizes the artist set on a preview (Typography / Assets & Icons) — one icon, every copy in
a sheet, or every copy in the project.

Stored in the session as ``dynamic_settings.icon_scales``::

    {"<sheet>": {"WILD": 140,              # every <WILD> on this sheet at 140 %
                 "WILD@row:12#0": 80},     # only the first <WILD> of Excel row 12 at 80 %
     "*":       {"WILD": 120}}             # every <WILD> on every sheet of the project at 120 %

Heading icons have sizes of their own, apart from the body's: the same keys with "H:" in front
(``"H:WILD": 90`` for every heading <WILD> on the sheet, ``"H:WILD@row:1#0"`` for one), so sizing
a body icon never changes a heading icon and the other way round.

Keys use the compact token (upper case letters and digits, like the live window's ``normToken``).
The closest size wins: one icon over the sheet, the sheet over the project ("*" is never a sheet
name — Excel doesn't allow it). ``apply`` writes the size into the row's text as
``<WILD~140>``; every reader of page text (the builds, the live window, the thumbnails) gets
the same tag, and ``split`` turns it back into the token and its factor when the icon is drawn —
so the preview and the PSD can never size an icon differently.

Gaps beside an icon, set the same way (one icon, every copy in a sheet, or in the project), are kept
in ``dynamic_settings.icon_gaps`` with the same keys, each ``[left, right]`` px — written after the
size tag as ``<WILD~140^10,20>`` (or ``<WILD^10,20>``); ``gaps`` reads them back where an icon is
measured or drawn, the text's own gaps are used for the icons without one.
"""
import re
import threading

_LOCK = threading.Lock()
_SCALES = {}
_GAPS = {}
TOKEN_RE = re.compile(r"<([^<>]+)>")
_TAG_RE = re.compile(r"~(\d+(?:\.\d+)?)\s*$")
_GAP_RE = re.compile(r"\^(\d+(?:\.\d+)?),(\d+(?:\.\d+)?)\s*$")
PROJECT = "*"          # the sizes for every sheet


def compact(token):
    """'Wild 2x' -> 'WILD2X' (the scale tag dropped)."""
    return re.sub(r"[^A-Z0-9]+", "", strip(token).upper())


def strip(token):
    """The token without its size / gap tags: 'WILD~140^10,20' -> 'WILD'."""
    return _TAG_RE.sub("", _GAP_RE.sub("", str(token or ""))).strip()


def split(token):
    """('WILD', 1.4) for 'WILD~140'; (token, 1.0) when it has no tag (a gap tag is dropped)."""
    text = _GAP_RE.sub("", str(token or "")).strip()
    m = _TAG_RE.search(text)
    if not m:
        return text, 1.0
    try:
        pct = float(m.group(1))
    except ValueError:
        pct = 100.0
    return text[:m.start()].strip(), max(0.05, min(10.0, pct / 100.0))


def gaps(token, left, right):
    """(left, right) px beside this icon: its own gap tag ('WILD^10,20'), else the text's."""
    m = _GAP_RE.search(str(token or ""))
    if not m:
        return left, right
    return max(0.0, float(m.group(1))), max(0.0, float(m.group(2)))


def set_gaps(gaps_by_sheet):
    """Use these icon gaps from now on: {sheet | "*": {key: [left, right]}} (keys as for sizes)."""
    clean = {}
    for sheet, items in (gaps_by_sheet or {}).items() if isinstance(gaps_by_sheet, dict) else ():
        row = {}
        for k, v in (items or {}).items() if isinstance(items, dict) else ():
            try:
                lr = [max(0.0, float(v[0])), max(0.0, float(v[1]))]
            except (TypeError, ValueError, IndexError, KeyError):
                continue
            row[str(k)] = lr
        if row:
            clean[str(sheet)] = row
    with _LOCK:
        _GAPS.clear()
        _GAPS.update(clean)


def set_all(scales, gaps_by_sheet=None):
    """Use these sizes (and icon gaps) from now on (the server calls this whenever the settings change)."""
    set_gaps(gaps_by_sheet)
    clean = {}
    for sheet, items in (scales or {}).items() if isinstance(scales, dict) else ():
        if not isinstance(items, dict):
            continue
        row = {}
        for k, v in items.items():
            try:
                pct = float(v)
            except (TypeError, ValueError):
                continue
            if pct > 0 and abs(pct - 100.0) > 1e-6:
                row[str(k)] = pct
        if row:
            clean[str(sheet)] = row
    with _LOCK:
        _SCALES.clear()
        _SCALES.update(clean)


def _fmt(pct):
    return str(int(round(pct))) if abs(pct - round(pct)) < 0.05 else f"{pct:.1f}"


HEADING = "H:"        # the key prefix of heading icons


def apply(sheet, key, text, role="body"):
    """The row's text with each sized icon tagged: '<WILD>' -> '<WILD~140>'. `role` "heading": the
    page heading's icons, sized by the heading keys only."""
    table, everywhere = _SCALES.get(str(sheet)) or {}, _SCALES.get(PROJECT) or {}
    gtable, geverywhere = _GAPS.get(str(sheet)) or {}, _GAPS.get(PROJECT) or {}
    pre = HEADING if role == "heading" else ""
    if not (table or everywhere or gtable or geverywhere) or not text or "<" not in str(text):
        return text
    seen = {}

    def tag(m):
        raw = m.group(1)
        base = strip(raw)
        c = compact(base)
        k = seen.get(c, 0)
        seen[c] = k + 1
        pct = table.get(f"{pre}{c}@{key}#{k}", table.get(pre + c, everywhere.get(pre + c)))
        if pct is None and pre:                      # one heading icon sized before heading keys existed
            pct = table.get(f"{c}@{key}#{k}")
        gap = gtable.get(f"{pre}{c}@{key}#{k}", gtable.get(pre + c, geverywhere.get(pre + c)))
        if pct is None and gap is None:
            return m.group(0)
        size = f"~{_fmt(pct)}" if pct is not None else ""
        return f"<{base}{size}^{_fmt(gap[0])},{_fmt(gap[1])}>" if gap is not None else f"<{base}{size}>"

    return TOKEN_RE.sub(tag, str(text))
