import json
import re


def _num(value, fallback):
    try:
        return float(value)
    except Exception:
        return fallback


def _int(value, fallback):
    try:
        return int(float(value))
    except Exception:
        return fallback




def _blend_char_id(name, fallback="Mltp"):
    """Map user-facing Photoshop blend mode names to Action Manager charIDs."""
    mapping = {
        "normal": "Nrml",
        "multiply": "Mltp",
        "screen": "Scrn",
        "overlay": "Ovrl",
        "soft light": "SftL",
        "hard light": "HrdL",
        "color dodge": "CDdg",
        "color burn": "CBrn",
        "linear dodge": "LnrD",
        "linear burn": "LnrB",
        "difference": "Dfrn",
        "exclusion": "Xclu",
    }
    try:
        return mapping.get(str(name).strip().lower(), fallback)
    except Exception:
        return fallback

def _rgb(value, fallback=(0, 0, 0)):
    try:
        if value is None:
            return fallback
        return tuple(int(x) for x in value[:3])
    except Exception:
        return fallback


# ExtendScript (ES3) has no JSON, so the capture/extract JSX embeds this tiny
# serializer + an ActionManager descriptor dumper. It emits the readable
# layer-style params carried by the "captured_params" key of a captured style
# config — the form used by the LIVE visualiser preview and the PIL preview
# renderer. The byte-exact "hex" descriptor stream is emitted alongside for
# Photoshop-side applying.
#
# NOTE: the old DOM reader (layer.layerStyle...) is gone on purpose — on this
# Photoshop (2023+ AM API) it returns nothing for effects that were applied
# through ActionManager, which silently made every captured style empty.
# Reading the layerEffects descriptor back through executeActionGet works.
_CAPTURE_PARAMS_JS = r'''
        function fnum(v, fb) { v = Number(v); return isFinite(v) ? v : fb; }
        function clampv(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }
        function s2i(s) { try { return stringIDToTypeID(s); } catch (e) { return null; } }
        function t2s(id) {
            try { var s = app.typeIDToStringID(id); if (s) return s; } catch (e) {}
            try { return String(id); } catch (e2) { return "?"; }
        }
        function dumpList(list) {
            var out = [];
            var n = 0;
            try { n = list.count; } catch (e) {}
            for (var i = 0; i < n; i++) {
                try { out.push(valOfList(list, i)); } catch (e) { out.push(null); }
            }
            return { "$list": true, "$items": out };
        }
        function valOfList(list, i) {
            var t = null, ts = "?";
            try { t = list.getType(i); } catch (e) {}
            try { ts = t2s(t); } catch (e) {}
            if (ts.indexOf("OBJECT") >= 0) { try { return dumpDesc(list.getObjectValue(i)); } catch (e) { return null; } }
            if (ts.indexOf("LIST") >= 0) { try { return dumpList(list.getList(i)); } catch (e) { return null; } }
            if (ts.indexOf("DOUBLE") >= 0) { try { return { "$value": list.getDouble(i) }; } catch (e) { return null; } }
            if (ts.indexOf("INTEGER") >= 0 || ts.indexOf("LARGE") >= 0) { try { return { "$value": list.getInteger(i) }; } catch (e) { return null; } }
            if (ts.indexOf("BOOLEAN") >= 0) { try { return { "$value": list.getBoolean(i) }; } catch (e) { return null; } }
            if (ts.indexOf("STRING") >= 0) { try { return { "$value": list.getString(i) }; } catch (e) { return null; } }
            return null;
        }
        function valOf(desc, name) {
            var t = null, ts = "?";
            try { t = desc.getType(name); } catch (e) {}
            try { ts = t2s(t); } catch (e) {}
            if (ts.indexOf("OBJECT") >= 0) {
                var oc = "?";
                try { oc = t2s(desc.getObjectType(name)); } catch (e) {}
                try { return { "$class": oc, "$data": dumpDesc(desc.getObjectValue(name)) }; } catch (e) { return null; }
            }
            if (ts.indexOf("LIST") >= 0) { try { return dumpList(desc.getList(name)); } catch (e) { return null; } }
            if (ts.indexOf("DOUBLE") >= 0) { try { return { "$value": desc.getDouble(name) }; } catch (e) { return null; } }
            if (ts.indexOf("INTEGER") >= 0 || ts.indexOf("LARGE") >= 0) { try { return { "$value": desc.getInteger(name) }; } catch (e) { return null; } }
            if (ts.indexOf("BOOLEAN") >= 0) { try { return { "$value": desc.getBoolean(name) }; } catch (e) { return null; } }
            if (ts.indexOf("STRING") >= 0) { try { return { "$value": desc.getString(name) }; } catch (e) { return null; } }
            if (ts.indexOf("UNITDOUBLE") >= 0) {
                try {
                    var ut = null;
                    try { ut = desc.getUnitType(name); } catch (e) {}
                    return { "$unit": ut === null ? "?" : t2s(ut), "$value": desc.getUnitDouble(name, ut) };
                } catch (e2) {
                    try { return { "$unit": "?", "$value": desc.getUnitDouble(name) }; } catch (e3) { return null; }
                }
            }
            if (ts.indexOf("ENUM") >= 0) {
                var et = "?", ev = "?";
                try { et = t2s(desc.getEnumerationType(name)); } catch (e) {}
                try { ev = t2s(desc.getEnumerationValue(name)); } catch (e) {}
                return { "$enumType": et, "$enumValue": ev };
            }
            return null;
        }
        function dumpDesc(desc) {
            var out = {};
            var n = 0;
            try { n = desc.count; } catch (e) { return out; }
            for (var i = 0; i < n; i++) {
                var key = null;
                try { key = desc.getKey(i); } catch (e1) { continue; }
                var nm = t2s(key);
                out[nm] = valOf(desc, key);
            }
            return out;
        }
        function fxRawParams(layer) {
            var base = { opacity: 100, fill_opacity: 100, is_fill_enabled: true, source: "photoshop_am" };
            try { var o = fnum(layer.opacity, 100); if (o > 0 && o <= 1) o = o * 100; base.opacity = clampv(o, 0, 100); } catch (e) {}
            try { var fo = fnum(layer.fillOpacity, 100); if (fo > 0 && fo <= 1) fo = fo * 100; base.fill_opacity = clampv(fo, 0, 100); } catch (e) {}
            var tree = null;
            try {
                var ref = new ActionReference();
                ref.putProperty(s2i('property'), s2i('layerEffects'));
                ref.putEnumerated(s2i('layer'), s2i('ordinal'), s2i('targetEnum'));
                var res = executeActionGet(ref);
                if (res.hasKey(s2i('layerEffects'))) tree = dumpDesc(res.getObjectValue(s2i('layerEffects')));
            } catch (e) {}
            return { tree: tree, base: base };
        }
        function ser(v) {
            if (v === null || v === undefined) return "null";
            var t = typeof v;
            if (t === "number") return isFinite(v) ? String(v) : "null";
            if (t === "boolean") return v ? "true" : "false";
            if (t === "string") return '"' + v.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/\t/g, "\\t") + '"';
            if (v instanceof Array) {
                var parts = [];
                for (var i = 0; i < v.length; i++) parts.push(ser(v[i]));
                return "[" + parts.join(",") + "]";
            }
            var keys = [];
            for (var k in v) {
                try { if (v.hasOwnProperty(k)) keys.push(k); } catch (e4) {}
            }
            var kvs = [];
            for (var j = 0; j < keys.length; j++) {
                try { kvs.push(ser(keys[j]) + ":" + ser(v[keys[j]])); } catch (e5) {}
            }
            return "{" + kvs.join(",") + "}";
        }
'''

_PARAM_CHECK_RE = re.compile(r"^[0-9a-fA-F]+$")


def _parse_capture_result(result):
    """Parse JSX capture output: modern {"hex","params"} or legacy bare hex str."""
    result = str(result or "").strip()
    if result.startswith("{"):
        try:
            data = json.loads(result)
            if isinstance(data, dict) and data.get("error"):
                return {"error": str(data["error"])}
            if isinstance(data, dict) and data.get("hex"):
                params = data.get("params") or {}
                if isinstance(params, dict) and isinstance(params.get("tree"), dict):
                    params = fx_tree_to_params(params.get("tree"), params.get("base"))
                out = {
                    "hex": str(data["hex"]),
                    "captured_params": params,
                }
                try:
                    px = float(data.get("text_px"))
                    if px > 0:
                        out["text_px"] = round(px, 2)      # the copied text layer's size (fx_scale base)
                except (TypeError, ValueError):
                    pass
                if data.get("extra"):
                    out["extra"] = str(data["extra"])
                return out
        except Exception:
            pass
    return result


# --------------------------------------------------------------------------
# ActionManager descriptor tree -> readable flat captured_params schema.
# The JSX dump emits a JSON-ish tree {"$value"|"$class"+$data|"$list"+$items|
# "$enumType"+"$enumValue"} that maps 1:1 onto the flat effect dicts the LIVE
# visualiser (normalizeFx) and ps_fx_png consume.
# --------------------------------------------------------------------------


def _fx_scalar(node, fallback):
    if isinstance(node, dict) and "$value" in node:
        return node["$value"]
    return fallback


def _fx_num(node, fallback):
    value = _fx_scalar(node, fallback)
    try:
        return float(value)
    except Exception:
        return fallback


def _fx_bool(node, fallback=False):
    value = _fx_scalar(node, None)
    if value is None:
        return fallback
    return bool(value)


def _fx_enum(node):
    if isinstance(node, dict) and "$enumValue" in node:
        return str(node["$enumValue"])
    return None


def _fx_object_data(node):
    if not isinstance(node, dict):
        return None
    if isinstance(node.get("$data"), dict):
        return node["$data"]
    return None


def _fx_effect_data(node):
    """Top-level effect node: an object, or a list-of-objects (PS writes
    dropShadowMulti / frameFX etc. as lists). Picks the enabled/present item."""
    if not isinstance(node, dict):
        return None
    data = _fx_object_data(node)
    if data is not None:
        return data
    items = node.get("$items") if node.get("$list") else None
    if not items:
        return None
    best = None
    for item in items:
        d = _fx_object_data(item)
        if d is None:
            continue
        if _fx_bool(d.get("present")) or _fx_bool(d.get("enabled")):
            return d
        if best is None:
            best = d
    return best


def _fx_rgb(node, fallback=(0, 0, 0)):
    data = _fx_object_data(node)
    if not data:
        return fallback
    r = _fx_num(data.get("red"), fallback[0])
    g = _fx_num(data.get("grain", data.get("green")), fallback[1])
    b = _fx_num(data.get("blue"), fallback[2])
    return [int(max(0, min(255, round(r)))), int(max(0, min(255, round(g)))), int(max(0, min(255, round(b))))]


_FX_BLEND_NAMES = {
    "normal": "normal", "multiply": "multiply", "screen": "screen",
    "overlay": "overlay", "softlight": "soft light", "soft light": "soft light",
    "hardlight": "hard light", "hard light": "hard light",
    "colordodge": "color dodge", "color dodge": "color dodge",
    "colorburn": "color burn", "color burn": "color burn",
    "lineardodge": "linear dodge", "linear dodge": "linear dodge",
    "linearburn": "linear burn", "linear burn": "linear burn",
    "darken": "darken", "lighten": "lighten", "difference": "difference",
    "exclusion": "exclusion", "hue": "hue", "saturation": "saturation",
    "color": "color", "luminosity": "luminosity", "lighter": "linear dodge",
    "plus": "linear dodge", "hardlighte": "hard light",
}


def _fx_blend(node):
    raw = _fx_enum(node)
    if not raw:
        return "normal"
    return _FX_BLEND_NAMES.get(raw.strip().casefold(), "normal")


def _fx_gradient_stops(node):
    """[[rgb, location_0_100], ...] from the gradient descriptor."""
    grad = _fx_object_data(node)
    if not grad:
        return []
    colors = grad.get("colors")
    items = colors.get("$items") if isinstance(colors, dict) and colors.get("$list") else None
    stops = []
    for item in items or []:
        if not isinstance(item, dict):
            continue
        loc = _fx_num(item.get("location"), 0)
        if loc < 0 or loc > 4096:
            loc = 0
        rgb = _fx_rgb(item.get("color"), [255, 255, 255])
        stops.append([rgb, max(0.0, min(100.0, loc / 4096.0 * 100.0))])
    return stops


def _fx_shadow(data, angle_fb=120):
    return {
        "enabled": _fx_bool(data.get("enabled")),
        "color": _fx_rgb(data.get("color"), (0, 0, 0)),
        "opacity": max(0, min(100, _fx_num(data.get("opacity"), 75))),
        "angle": _fx_num(data.get("localLightingAngle"), angle_fb),
        "distance": _fx_num(data.get("distance"), 8),
        "size": _fx_num(data.get("blur"), 12),
        "spread": _fx_num(data.get("chokeMatte"), 0),
        "blend": _fx_blend(data.get("mode")),
    }


def _fx_outer_glow(data):
    return {
        "enabled": _fx_bool(data.get("enabled")),
        "color": _fx_rgb(data.get("color"), (255, 255, 190)),
        "opacity": max(0, min(100, _fx_num(data.get("opacity"), 66))),
        "size": _fx_num(data.get("blur"), 18),
        "spread": _fx_num(data.get("chokeMatte"), 0),
        "blend": _fx_blend(data.get("mode")),
    }


def _fx_inner_glow(data):
    return {
        "enabled": _fx_bool(data.get("enabled")),
        "color": _fx_rgb(data.get("color"), (255, 255, 255)),
        "opacity": max(0, min(100, _fx_num(data.get("opacity"), 50))),
        "size": _fx_num(data.get("blur"), 8),
        "blend": _fx_blend(data.get("mode")),
    }


def _fx_stroke(data):
    position = _fx_enum(data.get("style")) or ""
    if "inset" in position.casefold():
        pos = "inside"
    elif "center" in position.casefold():
        pos = "center"
    else:
        pos = "outside"
    return {
        "enabled": _fx_bool(data.get("enabled")),
        "color": _fx_rgb(data.get("color"), (255, 255, 255)),
        "opacity": max(0, min(100, _fx_num(data.get("opacity"), 100))),
        "size": _fx_num(data.get("size"), 3),
        "position": pos,
        "blend": _fx_blend(data.get("mode")),
    }


def _fx_color_overlay(data):
    return {
        "enabled": _fx_bool(data.get("enabled")),
        "color": _fx_rgb(data.get("color"), (255, 0, 0)),
        "opacity": max(0, min(100, _fx_num(data.get("opacity"), 100))),
        "blend": _fx_blend(data.get("mode")),
    }


def _fx_gradient_overlay(data):
    gtype = (_fx_enum(data.get("type")) or "linear").casefold()
    return {
        "enabled": _fx_bool(data.get("enabled")),
        "opacity": max(0, min(100, _fx_num(data.get("opacity"), 100))),
        "blend": _fx_blend(data.get("mode")),
        "angle": _fx_num(data.get("angle"), 90),
        "type": "radial" if gtype == "radial" else "linear",
        "reverse": _fx_bool(data.get("reverse")),
        "colors": _fx_gradient_stops(data.get("gradient")),
    }


_FX_EFFECT_SOURCES = (
    ("dropShadow", "drop_shadow"),
    ("dropShadowMulti", "drop_shadow"),
    ("innerShadow", "inner_shadow"),
    ("innerShadowMulti", "inner_shadow"),
    ("outerGlow", "outer_glow"),
    ("solidFill", "color_overlay"),
    ("solidFillMulti", "color_overlay"),
    ("gradientFill", "gradient_overlay"),
    ("gradientFillMulti", "gradient_overlay"),
    ("frameFX", "stroke"),
)

_FX_EFFECT_BUILDERS = {
    "drop_shadow": _fx_shadow,
    "inner_shadow": _fx_shadow,
    "outer_glow": _fx_outer_glow,
    "inner_glow": _fx_inner_glow,
    "stroke": _fx_stroke,
    "color_overlay": _fx_color_overlay,
    "gradient_overlay": _fx_gradient_overlay,
}


def fx_tree_to_params(tree, base=None):
    """Convert the ActionManager layerEffects tree to flat captured_params."""
    params = dict(base or {})
    params.pop("tree", None)
    if not isinstance(tree, dict):
        return params
    for src_key, target in _FX_EFFECT_SOURCES:
        node = tree.get(src_key)
        if node is None:
            continue
        data = _fx_effect_data(node)
        if not data:
            continue
        builder = _FX_EFFECT_BUILDERS[target]
        eff = builder(data)
        if not eff.get("enabled"):
            continue
        if eff.get("color") is None:
            continue
        params[target] = eff
    return params


def extract_params_from_effects_hex(effects_hex_list):
    """Upgrade stored legacy styles: ask Photoshop to re-deserialize each hex
    descriptor stream and read back readable captured_params (one JSX call).

    Returns {index: params_dict} for every entry that decoded successfully.
    Requires an open Photoshop document (like the other capture flows).
    """
    clean = []
    for fx_hex in effects_hex_list or []:
        h = re.sub(r"[^0-9a-fA-F]", "", str(fx_hex or ""))
        if h and len(h) % 4 == 0:
            clean.append(h)
    if not clean:
        return {}
    from . import photoshop_bridge  # works with whichever Photoshop version is open
    try:
        if photoshop_bridge.run_jsx("app.documents.length", timeout=60) in ("", "0"):
            return {}
    except Exception:
        return {}
    entries_js = json.dumps(clean)
    jsx = (
        "function hexToStream(hex){"
        " var stream=''; for (var i=0;i<hex.length;i+=4){"
        "   stream += String.fromCharCode(parseInt(hex.substr(i,4),16)); } return stream; }\n"
        "function applyFxTo(layer, hex){"
        " var effects = new ActionDescriptor(); effects.fromStream(hexToStream(hex));"
        " var setDesc = new ActionDescriptor();"
        " var ref = new ActionReference();"
        " ref.putProperty(stringIDToTypeID('property'), stringIDToTypeID('layerEffects'));"
        " ref.putEnumerated(stringIDToTypeID('layer'), stringIDToTypeID('ordinal'), stringIDToTypeID('targetEnum'));"
        " setDesc.putReference(stringIDToTypeID('null'), ref);"
        " setDesc.putObject(stringIDToTypeID('to'), stringIDToTypeID('layerEffects'), effects);"
        " executeAction(stringIDToTypeID('set'), setDesc, DialogModes.NO); }\n"
        + _CAPTURE_PARAMS_JS
        + "\n(function(){\n"
        " var doc = app.activeDocument;\n"
        " var list = " + entries_js + ";\n"
        " var out = {};\n"
        " for (var i = 0; i < list.length; i++){\n"
        "   var temp = null;\n"
        "   try {\n"
        "     temp = doc.artLayers.add();\n"
        "     temp.name = '__PsHelpScreenTool_ParamExtract__';\n"
        "     doc.activeLayer = temp;\n"
        "     applyFxTo(temp, list[i]);\n"
        "     out[i] = fxRawParams(temp);\n"
        "   } catch(e) {}\n"
        "   finally { try { if (temp) temp.remove(); } catch(ce) {} }\n"
        " }\n"
        " return ser(out);\n"
        "})();\n"
    )
    try:
        raw = str(photoshop_bridge.run_jsx(jsx) or "").strip()
    except Exception as exc:
        print(f"[Layer Style] Legacy param extraction failed: {exc}")
        return {}
    if not raw.startswith("{"):
        return {}
    try:
        data = json.loads(raw)
    except Exception:
        return {}
    if not isinstance(data, dict):
        return {}
    params_map = {}
    for key, value in data.items():
        try:
            if isinstance(value, dict) and isinstance(value.get("tree"), dict):
                params_map[int(key)] = fx_tree_to_params(value.get("tree"), value.get("base"))
            elif isinstance(value, dict):
                params_map[int(key)] = value
        except Exception:
            continue
    return params_map


def apply_copied_layer_style(app, doc, layer):
    """Paste the currently copied Photoshop layer style onto one layer."""
    try:
        doc.activeLayer = layer
        jsx = '''
        (function(){
            try { executeAction(stringIDToTypeID("pasteEffects"), undefined, DialogModes.NO); return true; } catch(e1) {}
            try { executeAction(charIDToTypeID("PaFX"), undefined, DialogModes.NO); return true; } catch(e2) {}
            return false;
        })();
        '''
        return bool(app.doJavaScript(jsx))
    except Exception as e:
        print(f"[Layer Style] Paste copied style failed on {getattr(layer, 'name', 'layer')}: {e}")
        return False


_CAPTURE_HEAD_JS = r'''
        // the active text layer's size in px, as the tool reads a PSD (FontSize × the layer's yy):
        // impliedFontSize already carries the layer's transform; a "pt" value is turned into px
        function pshTextPx() {
            try {
                var ref = new ActionReference();
                ref.putEnumerated(charIDToTypeID("Lyr "), charIDToTypeID("Ordn"), charIDToTypeID("Trgt"));
                var d = executeActionGet(ref), tk = stringIDToTypeID("textKey");
                if (!d.hasKey(tk)) return "";
                var t = d.getObjectValue(tk);
                var st = t.getList(stringIDToTypeID("textStyleRange")).getObjectValue(0)
                          .getObjectValue(stringIDToTypeID("textStyle"));
                var id = stringIDToTypeID("impliedFontSize"), implied = st.hasKey(id);
                if (!implied) id = stringIDToTypeID("size");
                if (!st.hasKey(id)) return "";
                var v = st.getUnitDoubleValue(id), unit = typeIDToStringID(st.getUnitDoubleType(id));
                if (!implied && t.hasKey(stringIDToTypeID("transform")))
                    v *= t.getObjectValue(stringIDToTypeID("transform")).getDouble(stringIDToTypeID("yy"));
                if (unit != "pixelsUnit") v = v * app.activeDocument.resolution / 72;
                return v;
            } catch (e) { return ""; }
        }
'''

_NO_DOCUMENT = '{"error": "Open a Photoshop document and select a styled layer first."}'


def _capture_result(raw, what):
    result = _parse_capture_result(raw or "")
    if isinstance(result, dict) and result.get("error"):
        raise RuntimeError(result["error"])
    if isinstance(result, dict):
        if not re.fullmatch(r"[0-9a-fA-F]+", str(result.get("hex") or "")):
            raise RuntimeError("Photoshop did not return a reusable layer-style descriptor.")
    elif not result or not _PARAM_CHECK_RE.fullmatch(result):
        raise RuntimeError("Photoshop did not return a reusable layer-style descriptor.")
    return result


def capture_copied_layer_style_from_photoshop(extra_js=None):
    """Capture Photoshop's copied Layer Style.

    ONE script (each script run through a Photoshop that isn't the COM-registered one is a file
    Photoshop asks about before running): no document → an error; else the style pasted on a temp
    layer and read, the active text layer's size (text_px: the style was most likely copied from it)
    and `extra_js` (an expression, e.g. the Global Light) → "extra".

    Returns {"hex": <descriptor stream>, "captured_params": {readable JSON}, "text_px", "extra"}
    (or the bare hex string if the readable-params emission fails)."""
    try:
        from . import photoshop_bridge  # works with whichever Photoshop version is open
        jsx = r'''
        (function(){
            if (!app.documents.length) return ''' + json.dumps(_NO_DOCUMENT) + r''';
        ''' + _CAPTURE_HEAD_JS + r'''
            var doc = app.activeDocument;
            var textPx = pshTextPx();
            var extra = "";
            try { extra = String(''' + (extra_js or '""') + r'''); } catch (ex) { extra = ""; }
            var temp = null;
            try {
                temp = doc.artLayers.add();
                temp.name = "__PsHelpScreenTool_StyleCapture__";
                doc.activeLayer = temp;
                try { executeAction(stringIDToTypeID("pasteEffects"), undefined, DialogModes.NO); }
                catch(e1) { executeAction(charIDToTypeID("PaFX"), undefined, DialogModes.NO); }
                var ref = new ActionReference();
                ref.putProperty(stringIDToTypeID("property"), stringIDToTypeID("layerEffects"));
                ref.putEnumerated(stringIDToTypeID("layer"), stringIDToTypeID("ordinal"), stringIDToTypeID("targetEnum"));
                var result = executeActionGet(ref);
                if (!result.hasKey(stringIDToTypeID("layerEffects"))) throw new Error("Copied style has no layer effects.");
                var effects = result.getObjectValue(stringIDToTypeID("layerEffects"));
                var stream = effects.toStream();
                var hex = "";
                for (var i = 0; i < stream.length; i++) {
                    var part = stream.charCodeAt(i).toString(16);
                    while (part.length < 4) part = "0" + part;
                    hex += part;
                }
        ''' + _CAPTURE_PARAMS_JS + r'''
                return ser({ hex: hex, params: fxRawParams(temp), text_px: textPx, extra: extra });
            } finally {
                try { if (temp) temp.remove(); } catch(cleanupError) {}
            }
        })();
        '''
        return _capture_result(photoshop_bridge.run_jsx(jsx), "copied")
    except Exception as exc:
        raise RuntimeError(f"Could not capture copied Photoshop layer style: {exc}") from exc


def capture_selected_layer_style_from_photoshop(extra_js=None):
    """Capture the active Photoshop layer's layer effects — one script, like the copied capture.

    Returns {"hex": <descriptor stream>, "captured_params": {readable JSON}, "text_px", "extra"}
    (or the bare hex string if the readable-params emission fails)."""
    try:
        from . import photoshop_bridge  # works with whichever Photoshop version is open
        jsx = r'''
        (function(){
            if (!app.documents.length) return ''' + json.dumps(_NO_DOCUMENT) + r''';
        ''' + _CAPTURE_HEAD_JS + r'''
            var doc = app.activeDocument;
            var textPx = pshTextPx();
            var extra = "";
            try { extra = String(''' + (extra_js or '""') + r'''); } catch (ex) { extra = ""; }
            var ref = new ActionReference();
            ref.putProperty(stringIDToTypeID("property"), stringIDToTypeID("layerEffects"));
            ref.putEnumerated(stringIDToTypeID("layer"), stringIDToTypeID("ordinal"), stringIDToTypeID("targetEnum"));
            var result = executeActionGet(ref);
            if (!result.hasKey(stringIDToTypeID("layerEffects"))) throw new Error("Selected layer has no layer effects.");
            var effects = result.getObjectValue(stringIDToTypeID("layerEffects"));
            var stream = effects.toStream();
            var hex = "";
            for (var i = 0; i < stream.length; i++) {
                var part = stream.charCodeAt(i).toString(16);
                while (part.length < 4) part = "0" + part;
                hex += part;
            }
        ''' + _CAPTURE_PARAMS_JS + r'''
            var paramsOut = {};
            try { paramsOut = fxRawParams(doc.activeLayer); } catch (fxErr) {}
            return ser({ hex: hex, params: paramsOut, text_px: textPx, extra: extra });
        })();
        '''
        return _capture_result(photoshop_bridge.run_jsx(jsx), "selected")
    except Exception as exc:
        raise RuntimeError(f"Could not capture selected Photoshop layer style: {exc}") from exc


def apply_serialized_layer_style(app, doc, layer, effects_hex):
    """Apply a descriptor stream previously captured from Photoshop."""
    effects_hex = re.sub(r"[^0-9a-fA-F]", "", str(effects_hex or ""))
    if not effects_hex or len(effects_hex) % 4:
        return False
    try:
        doc.activeLayer = layer
        jsx = f'''
        (function() {{
            var hex = "{effects_hex}";
            var stream = "";
            for (var i = 0; i < hex.length; i += 4) {{
                stream += String.fromCharCode(parseInt(hex.substr(i, 4), 16));
            }}
            var effects = new ActionDescriptor();
            effects.fromStream(stream);
            var setDesc = new ActionDescriptor();
            var ref = new ActionReference();
            ref.putProperty(stringIDToTypeID("property"), stringIDToTypeID("layerEffects"));
            ref.putEnumerated(stringIDToTypeID("layer"), stringIDToTypeID("ordinal"), stringIDToTypeID("targetEnum"));
            setDesc.putReference(stringIDToTypeID("null"), ref);
            setDesc.putObject(stringIDToTypeID("to"), stringIDToTypeID("layerEffects"), effects);
            executeAction(stringIDToTypeID("set"), setDesc, DialogModes.NO);
            return true;
        }})();
        '''
        return bool(app.doJavaScript(jsx))
    except Exception as exc:
        print(f"[Layer Style] Saved style failed on {getattr(layer, 'name', 'layer')}: {exc}")
        return False


def apply_heading_layer_style(app, doc, layer, style_config):
    """Apply UI-configured stroke/drop-shadow and/or copied style to a text layer."""
    if not style_config:
        return

    captured_effects = style_config.get('captured_effects_hex')
    if captured_effects:
        apply_serialized_layer_style(app, doc, layer, captured_effects)

    if style_config.get('paste_copied_style'):
        apply_copied_layer_style(app, doc, layer)

    stroke_enabled = bool(style_config.get('stroke_enabled'))
    shadow_enabled = bool(style_config.get('shadow_enabled'))
    if not stroke_enabled and not shadow_enabled:
        return

    stroke_rgb = _rgb(style_config.get('stroke_rgb'), (255, 255, 255))
    shadow_rgb = _rgb(style_config.get('shadow_rgb'), (0, 0, 0))
    shadow_blend = _blend_char_id(style_config.get('shadow_blend_mode'), "Mltp")
    stroke_size = _num(style_config.get('stroke_size'), 3)
    stroke_opacity = _num(style_config.get('stroke_opacity'), 100)
    shadow_opacity = _num(style_config.get('shadow_opacity'), 60)
    shadow_distance = _num(style_config.get('shadow_distance'), 8)
    shadow_size = _num(style_config.get('shadow_size'), 12)
    shadow_angle = _num(style_config.get('shadow_angle'), 120)
    shadow_spread = _num(style_config.get('shadow_spread'), 0)

    try:
        doc.activeLayer = layer
        jsx = f'''
        (function() {{
            var desc = new ActionDescriptor();
            var ref = new ActionReference();
            ref.putProperty(charIDToTypeID("Prpr"), charIDToTypeID("Lefx"));
            ref.putEnumerated(charIDToTypeID("Lyr "), charIDToTypeID("Ordn"), charIDToTypeID("Trgt"));
            desc.putReference(charIDToTypeID("null"), ref);
            var fx = new ActionDescriptor();
            fx.putUnitDouble(charIDToTypeID("Scl "), charIDToTypeID("#Prc"), 100.0);

            if ({str(stroke_enabled).lower()}) {{
                var stroke = new ActionDescriptor();
                stroke.putBoolean(charIDToTypeID("enab"), true);
                stroke.putEnumerated(charIDToTypeID("Styl"), charIDToTypeID("FStl"), charIDToTypeID("OutF"));
                stroke.putEnumerated(charIDToTypeID("PntT"), charIDToTypeID("FrFl"), charIDToTypeID("SClr"));
                stroke.putEnumerated(charIDToTypeID("Md  "), charIDToTypeID("BlnM"), charIDToTypeID("Nrml"));
                stroke.putUnitDouble(charIDToTypeID("Opct"), charIDToTypeID("#Prc"), {stroke_opacity});
                stroke.putUnitDouble(charIDToTypeID("Sz  "), charIDToTypeID("#Pxl"), {stroke_size});
                var strokeColor = new ActionDescriptor();
                strokeColor.putDouble(charIDToTypeID("Rd  "), {stroke_rgb[0]});
                strokeColor.putDouble(charIDToTypeID("Grn "), {stroke_rgb[1]});
                strokeColor.putDouble(charIDToTypeID("Bl  "), {stroke_rgb[2]});
                stroke.putObject(charIDToTypeID("Clr "), charIDToTypeID("RGBC"), strokeColor);
                fx.putObject(charIDToTypeID("FrFX"), charIDToTypeID("FrFX"), stroke);
            }}

            if ({str(shadow_enabled).lower()}) {{
                var sh = new ActionDescriptor();
                sh.putBoolean(charIDToTypeID("enab"), true);
                sh.putEnumerated(charIDToTypeID("Md  "), charIDToTypeID("BlnM"), charIDToTypeID("{shadow_blend}"));
                var shColor = new ActionDescriptor();
                shColor.putDouble(charIDToTypeID("Rd  "), {shadow_rgb[0]});
                shColor.putDouble(charIDToTypeID("Grn "), {shadow_rgb[1]});
                shColor.putDouble(charIDToTypeID("Bl  "), {shadow_rgb[2]});
                sh.putObject(charIDToTypeID("Clr "), charIDToTypeID("RGBC"), shColor);
                sh.putUnitDouble(charIDToTypeID("Opct"), charIDToTypeID("#Prc"), {shadow_opacity});
                sh.putBoolean(charIDToTypeID("uglg"), false);
                sh.putUnitDouble(charIDToTypeID("lagl"), charIDToTypeID("#Ang"), {shadow_angle});
                sh.putUnitDouble(charIDToTypeID("Dstn"), charIDToTypeID("#Pxl"), {shadow_distance});
                sh.putUnitDouble(charIDToTypeID("Ckmt"), charIDToTypeID("#Prc"), {shadow_spread});
                sh.putUnitDouble(charIDToTypeID("blur"), charIDToTypeID("#Pxl"), {shadow_size});
                fx.putObject(charIDToTypeID("DrSh"), charIDToTypeID("DrSh"), sh);
            }}

            desc.putObject(charIDToTypeID("T   "), charIDToTypeID("Lefx"), fx);
            executeAction(charIDToTypeID("setd"), desc, DialogModes.NO);
        }})();
        '''
        app.doJavaScript(jsx)
    except Exception as e:
        print(f"[Layer Style] Built-in style failed on {getattr(layer, 'name', 'layer')}: {e}")


def _is_text_layer(layer):
    import photoshop.api as ps
    try:
        return getattr(layer, "kind", None) == ps.LayerKind.TextLayer or bool(layer.textItem)
    except Exception:
        return False


def _apply_style_to_group_batched(app, doc, layer_group, style_config, text_only=True):
    """Apply stroke/shadow to all matching layers in a group using ONE JSX call.

    The JSX string is identical for every layer (only the active layer changes),
    so we move the layer iteration inside Photoshop JS to save N-1 round trips.
    Falls back to per-layer for captured/paste special styles.
    """
    if not style_config:
        return

    captured_effects = style_config.get('captured_effects_hex')
    if captured_effects or style_config.get('paste_copied_style'):
        _apply_text_layers_per_layer(app, doc, layer_group, style_config, text_only)
        return

    stroke_enabled = bool(style_config.get('stroke_enabled'))
    shadow_enabled = bool(style_config.get('shadow_enabled'))
    if not stroke_enabled and not shadow_enabled:
        return

    stroke_rgb = _rgb(style_config.get('stroke_rgb'), (255, 255, 255))
    shadow_rgb = _rgb(style_config.get('shadow_rgb'), (0, 0, 0))
    shadow_blend = _blend_char_id(style_config.get('shadow_blend_mode'), "Mltp")
    stroke_size = _num(style_config.get('stroke_size'), 3)
    stroke_opacity = _num(style_config.get('stroke_opacity'), 100)
    shadow_opacity = _num(style_config.get('shadow_opacity'), 60)
    shadow_distance = _num(style_config.get('shadow_distance'), 8)
    shadow_size = _num(style_config.get('shadow_size'), 12)
    shadow_angle = _num(style_config.get('shadow_angle'), 120)
    shadow_spread = _num(style_config.get('shadow_spread'), 0)

    group_id = int(layer_group.id)
    text_filter_js = ("true" if not text_only else
        "(function(l){try{return !!l.textItem}catch(e){return false}})(l)")

    jsx = f'''
    (function(){{
        var doc = app.activeDocument;
        var g = doc.layerSets.getByID({group_id});
        if (!g) return;
        var layers = [];
        (function collect(grp){{
            for (var i = 0; i < grp.artLayers.length; i++){{
                var l = grp.artLayers[i];
                if ({text_filter_js}) layers.push(l);
            }}
            for (var i = 0; i < grp.layerSets.length; i++){{
                collect(grp.layerSets[i]);
            }}
        }})(g);
        for (var j = 0; j < layers.length; j++){{
            try {{
                doc.activeLayer = layers[j];
                var desc = new ActionDescriptor();
                var ref = new ActionReference();
                ref.putProperty(charIDToTypeID("Prpr"), charIDToTypeID("Lefx"));
                ref.putEnumerated(charIDToTypeID("Lyr "), charIDToTypeID("Ordn"), charIDToTypeID("Trgt"));
                desc.putReference(charIDToTypeID("null"), ref);
                var fx = new ActionDescriptor();
                fx.putUnitDouble(charIDToTypeID("Scl "), charIDToTypeID("#Prc"), 100.0);
                if ({str(stroke_enabled).lower()}){{
                    var stroke = new ActionDescriptor();
                    stroke.putBoolean(charIDToTypeID("enab"), true);
                    stroke.putEnumerated(charIDToTypeID("Styl"), charIDToTypeID("FStl"), charIDToTypeID("OutF"));
                    stroke.putEnumerated(charIDToTypeID("PntT"), charIDToTypeID("FrFl"), charIDToTypeID("SClr"));
                    stroke.putEnumerated(charIDToTypeID("Md  "), charIDToTypeID("BlnM"), charIDToTypeID("Nrml"));
                    stroke.putUnitDouble(charIDToTypeID("Opct"), charIDToTypeID("#Prc"), {stroke_opacity});
                    stroke.putUnitDouble(charIDToTypeID("Sz  "), charIDToTypeID("#Pxl"), {stroke_size});
                    var strokeColor = new ActionDescriptor();
                    strokeColor.putDouble(charIDToTypeID("Rd  "), {stroke_rgb[0]});
                    strokeColor.putDouble(charIDToTypeID("Grn "), {stroke_rgb[1]});
                    strokeColor.putDouble(charIDToTypeID("Bl  "), {stroke_rgb[2]});
                    stroke.putObject(charIDToTypeID("Clr "), charIDToTypeID("RGBC"), strokeColor);
                    fx.putObject(charIDToTypeID("FrFX"), charIDToTypeID("FrFX"), stroke);
                }}
                if ({str(shadow_enabled).lower()}){{
                    var sh = new ActionDescriptor();
                    sh.putBoolean(charIDToTypeID("enab"), true);
                    sh.putEnumerated(charIDToTypeID("Md  "), charIDToTypeID("BlnM"), charIDToTypeID("{shadow_blend}"));
                    var shColor = new ActionDescriptor();
                    shColor.putDouble(charIDToTypeID("Rd  "), {shadow_rgb[0]});
                    shColor.putDouble(charIDToTypeID("Grn "), {shadow_rgb[1]});
                    shColor.putDouble(charIDToTypeID("Bl  "), {shadow_rgb[2]});
                    sh.putObject(charIDToTypeID("Clr "), charIDToTypeID("RGBC"), shColor);
                    sh.putUnitDouble(charIDToTypeID("Opct"), charIDToTypeID("#Prc"), {shadow_opacity});
                    sh.putBoolean(charIDToTypeID("uglg"), false);
                    sh.putUnitDouble(charIDToTypeID("lagl"), charIDToTypeID("#Ang"), {shadow_angle});
                    sh.putUnitDouble(charIDToTypeID("Dstn"), charIDToTypeID("#Pxl"), {shadow_distance});
                    sh.putUnitDouble(charIDToTypeID("Ckmt"), charIDToTypeID("#Prc"), {shadow_spread});
                    sh.putUnitDouble(charIDToTypeID("blur"), charIDToTypeID("#Pxl"), {shadow_size});
                    fx.putObject(charIDToTypeID("DrSh"), charIDToTypeID("DrSh"), sh);
                }}
                desc.putObject(charIDToTypeID("T   "), charIDToTypeID("Lefx"), fx);
                executeAction(charIDToTypeID("setd"), desc, DialogModes.NO);
            }} catch(e) {{}}
        }}
    }})();
    '''
    try:
        app.doJavaScript(jsx)
    except Exception as e:
        print(f"[Layer Style] Batch apply failed, falling back: {e}")
        _apply_text_layers_per_layer(app, doc, layer_group, style_config, text_only)


def _apply_text_layers_per_layer(app, doc, layer_group, style_config, text_only):
    """Fallback: apply style one layer at a time."""
    try:
        for lyr in list(layer_group.artLayers):
            if not text_only or _is_text_layer(lyr):
                apply_heading_layer_style(app, doc, lyr, style_config)
        for subgroup in list(layer_group.layerSets):
            _apply_text_layers_per_layer(app, doc, subgroup, style_config, text_only=text_only)
    except Exception as e:
        print(f"[Layer Style] Per-layer style apply failed: {e}")


def apply_style_to_group_text_layers(app, doc, layer_group, style_config, text_only=True):
    if not style_config:
        return
    try:
        _apply_style_to_group_batched(app, doc, layer_group, style_config, text_only)
    except Exception as e:
        print(f"[Layer Style] Could not apply style to group: {e}")


def _style_fx_params(style_config):
    """Extract stroke/shadow params from a style config into a JSON-safe dict."""
    if not style_config:
        return None
    params = {
        "stroke_enabled": bool(style_config.get('stroke_enabled')),
        "shadow_enabled": bool(style_config.get('shadow_enabled')),
        "stroke_rgb": list(_rgb(style_config.get('stroke_rgb'), (255, 255, 255))),
        "shadow_rgb": list(_rgb(style_config.get('shadow_rgb'), (0, 0, 0))),
        "shadow_blend": _blend_char_id(style_config.get('shadow_blend_mode'), "Mltp"),
        "stroke_size": _num(style_config.get('stroke_size'), 3),
        "stroke_opacity": _num(style_config.get('stroke_opacity'), 100),
        "shadow_opacity": _num(style_config.get('shadow_opacity'), 60),
        "shadow_distance": _num(style_config.get('shadow_distance'), 8),
        "shadow_size": _num(style_config.get('shadow_size'), 12),
        "shadow_angle": _num(style_config.get('shadow_angle'), 120),
        "shadow_spread": _num(style_config.get('shadow_spread'), 0),
    }
    if not params["stroke_enabled"] and not params["shadow_enabled"]:
        return None
    return params


def apply_dual_style_to_group(app, doc, layer_group, body_style, icon_style):
    """Apply body_style to text layers and icon_style to non-text layers in ONE JSX call.

    Merges what used to be two apply_style_to_group_text_layers calls (one
    text-only, one icon-only) into a single round trip: each layer is styled
    once, with the fx descriptor chosen by whether the layer is text. Falls
    back to per-layer COM for captured/paste styles."""
    if not body_style and not icon_style:
        return
    for _s in (body_style, icon_style):
        if not _s:
            continue
        if _s.get('captured_effects_hex') or _s.get('paste_copied_style'):
            try:
                for lyr in list(layer_group.artLayers):
                    try:
                        is_text = bool(getattr(lyr, "textItem", None))
                    except Exception:
                        is_text = True
                    apply_heading_layer_style(app, doc, lyr, body_style if is_text else icon_style)
                for subgroup in list(layer_group.layerSets):
                    apply_dual_style_to_group(app, doc, subgroup, body_style, icon_style)
            except Exception as e:
                print(f"[Layer Style] Dual style per-layer apply failed: {e}")
            return
    body = _style_fx_params(body_style)
    icon = _style_fx_params(icon_style)
    if not body and not icon:
        return
    try:
        group_id = int(layer_group.id)
    except Exception:
        return
    body_json = json.dumps(body if body else {"stroke_enabled": False, "shadow_enabled": False})
    icon_json = json.dumps(icon if icon else {"stroke_enabled": False, "shadow_enabled": False})
    jsx = f'''
    (function() {{
        var doc = app.activeDocument;
        var g = doc.layerSets.getByID({group_id});
        if (!g) return;
        var layers = [];
        (function collect(grp){{
            for (var i = 0; i < grp.artLayers.length; i++){{
                var l = grp.artLayers[i];
                var isText = (function(ll){{try{{return !!ll.textItem}}catch(e){{return false}}}})(l);
                layers.push([l, isText]);
            }}
            for (var i = 0; i < grp.layerSets.length; i++){{
                collect(grp.layerSets[i]);
            }}
        }})(g);
        function buildFx(s){{
            if (!s) return null;
            var strokeOn = s.stroke_enabled;
            var shadowOn = s.shadow_enabled;
            if (!strokeOn && !shadowOn) return null;
            var fx = new ActionDescriptor();
            fx.putUnitDouble(charIDToTypeID("Scl "), charIDToTypeID("#Prc"), 100.0);
            if (strokeOn){{
                var stroke = new ActionDescriptor();
                stroke.putBoolean(charIDToTypeID("enab"), true);
                stroke.putEnumerated(charIDToTypeID("Styl"), charIDToTypeID("FStl"), charIDToTypeID("OutF"));
                stroke.putEnumerated(charIDToTypeID("PntT"), charIDToTypeID("FrFl"), charIDToTypeID("SClr"));
                stroke.putEnumerated(charIDToTypeID("Md  "), charIDToTypeID("BlnM"), charIDToTypeID("Nrml"));
                stroke.putUnitDouble(charIDToTypeID("Opct"), charIDToTypeID("#Prc"), s.stroke_opacity);
                stroke.putUnitDouble(charIDToTypeID("Sz  "), charIDToTypeID("#Pxl"), s.stroke_size);
                var strokeColor = new ActionDescriptor();
                strokeColor.putDouble(charIDToTypeID("Rd  "), s.stroke_rgb[0]);
                strokeColor.putDouble(charIDToTypeID("Grn "), s.stroke_rgb[1]);
                strokeColor.putDouble(charIDToTypeID("Bl  "), s.stroke_rgb[2]);
                stroke.putObject(charIDToTypeID("Clr "), charIDToTypeID("RGBC"), strokeColor);
                fx.putObject(charIDToTypeID("FrFX"), charIDToTypeID("FrFX"), stroke);
            }}
            if (shadowOn){{
                var sh = new ActionDescriptor();
                sh.putBoolean(charIDToTypeID("enab"), true);
                sh.putEnumerated(charIDToTypeID("Md  "), charIDToTypeID("BlnM"), charIDToTypeID(s.shadow_blend));
                var shColor = new ActionDescriptor();
                shColor.putDouble(charIDToTypeID("Rd  "), s.shadow_rgb[0]);
                shColor.putDouble(charIDToTypeID("Grn "), s.shadow_rgb[1]);
                shColor.putDouble(charIDToTypeID("Bl  "), s.shadow_rgb[2]);
                sh.putObject(charIDToTypeID("Clr "), charIDToTypeID("RGBC"), shColor);
                sh.putUnitDouble(charIDToTypeID("Opct"), charIDToTypeID("#Prc"), s.shadow_opacity);
                sh.putBoolean(charIDToTypeID("uglg"), false);
                sh.putUnitDouble(charIDToTypeID("lagl"), charIDToTypeID("#Ang"), s.shadow_angle);
                sh.putUnitDouble(charIDToTypeID("Dstn"), charIDToTypeID("#Pxl"), s.shadow_distance);
                sh.putUnitDouble(charIDToTypeID("Ckmt"), charIDToTypeID("#Prc"), s.shadow_spread);
                sh.putUnitDouble(charIDToTypeID("blur"), charIDToTypeID("#Pxl"), s.shadow_size);
                fx.putObject(charIDToTypeID("DrSh"), charIDToTypeID("DrSh"), sh);
            }}
            return fx;
        }}
        var bodyFx = {body_json};
        var iconFx = {icon_json};
        for (var j = 0; j < layers.length; j++){{
            var l = layers[j][0];
            var fx = buildFx(layers[j][1] ? bodyFx : iconFx);
            if (!fx) continue;
            try {{
                doc.activeLayer = l;
                var desc = new ActionDescriptor();
                var ref = new ActionReference();
                ref.putProperty(charIDToTypeID("Prpr"), charIDToTypeID("Lefx"));
                ref.putEnumerated(charIDToTypeID("Lyr "), charIDToTypeID("Ordn"), charIDToTypeID("Trgt"));
                desc.putReference(charIDToTypeID("null"), ref);
                desc.putObject(charIDToTypeID("T   "), charIDToTypeID("Lefx"), fx);
                executeAction(charIDToTypeID("setd"), desc, DialogModes.NO);
            }} catch(e) {{}}
        }}
    }})();
    '''
    try:
        app.doJavaScript(jsx)
    except Exception as e:
        print(f"[Layer Style] Dual batch apply failed, falling back: {e}")
        try:
            for lyr in list(layer_group.artLayers):
                try:
                    is_text = bool(getattr(lyr, "textItem", None))
                except Exception:
                    is_text = True
                apply_heading_layer_style(app, doc, lyr, body_style if is_text else icon_style)
            for subgroup in list(layer_group.layerSets):
                apply_dual_style_to_group(app, doc, subgroup, body_style, icon_style)
        except Exception as e2:
            print(f"[Layer Style] Dual style per-layer fallback failed: {e2}")


def _has_captured_or_pasted_style(style_config):
    if not style_config:
        return False
    return bool(style_config.get('captured_effects_hex') or style_config.get('paste_copied_style'))


def apply_group_styles_batched(app, doc, requests):
    """Apply per-group styles in ONE JSX call.

    requests: list of dicts with keys:
        group_id (int), body (style config or None), icon (style config or None),
        text_only (bool, default False).
    text_only=True styles only text layers with body (bingo multi-line groups);
    text_only=False uses dual behavior (body on text, icon on non-text). Groups
    using captured/pasted effects fall back to per-group individual applies.
    """
    if not requests:
        return
    jsx_reqs = []
    normal = []
    for req in requests:
        if _has_captured_or_pasted_style(req.get("body")) or _has_captured_or_pasted_style(req.get("icon")):
            normal.append(req)
            continue
        body = _style_fx_params(req.get("body"))
        icon = _style_fx_params(req.get("icon"))
        if not body and not icon:
            continue
        try:
            group_id = int(req.get("group_id"))
        except Exception:
            normal.append(req)
            continue
        jsx_reqs.append({
            "id": group_id,
            "body": body if body else {"stroke_enabled": False, "shadow_enabled": False},
            "icon": icon if icon else {"stroke_enabled": False, "shadow_enabled": False},
            "textOnly": bool(req.get("text_only")),
        })
    for req in normal:
        try:
            if req.get("text_only"):
                apply_style_to_group_text_layers(app, doc, req.get("layer_group"), req.get("body") or req.get("icon"), text_only=True)
            else:
                apply_dual_style_to_group(app, doc, req.get("layer_group"), req.get("body"), req.get("icon"))
        except Exception as e:
            print(f"[Layer Style] Mega style per-group fallback failed: {e}")
    if not jsx_reqs:
        return
    requests_json = json.dumps(jsx_reqs)
    jsx = f'''
    (function() {{
        var doc = app.activeDocument;
        var requests = {requests_json};
        function buildFx(s){{
            if (!s) return null;
            var strokeOn = s.stroke_enabled;
            var shadowOn = s.shadow_enabled;
            if (!strokeOn && !shadowOn) return null;
            var fx = new ActionDescriptor();
            fx.putUnitDouble(charIDToTypeID("Scl "), charIDToTypeID("#Prc"), 100.0);
            if (strokeOn){{
                var stroke = new ActionDescriptor();
                stroke.putBoolean(charIDToTypeID("enab"), true);
                stroke.putEnumerated(charIDToTypeID("Styl"), charIDToTypeID("FStl"), charIDToTypeID("OutF"));
                stroke.putEnumerated(charIDToTypeID("PntT"), charIDToTypeID("FrFl"), charIDToTypeID("SClr"));
                stroke.putEnumerated(charIDToTypeID("Md  "), charIDToTypeID("BlnM"), charIDToTypeID("Nrml"));
                stroke.putUnitDouble(charIDToTypeID("Opct"), charIDToTypeID("#Prc"), s.stroke_opacity);
                stroke.putUnitDouble(charIDToTypeID("Sz  "), charIDToTypeID("#Pxl"), s.stroke_size);
                var strokeColor = new ActionDescriptor();
                strokeColor.putDouble(charIDToTypeID("Rd  "), s.stroke_rgb[0]);
                strokeColor.putDouble(charIDToTypeID("Grn "), s.stroke_rgb[1]);
                strokeColor.putDouble(charIDToTypeID("Bl  "), s.stroke_rgb[2]);
                stroke.putObject(charIDToTypeID("Clr "), charIDToTypeID("RGBC"), strokeColor);
                fx.putObject(charIDToTypeID("FrFX"), charIDToTypeID("FrFX"), stroke);
            }}
            if (shadowOn){{
                var sh = new ActionDescriptor();
                sh.putBoolean(charIDToTypeID("enab"), true);
                sh.putEnumerated(charIDToTypeID("Md  "), charIDToTypeID("BlnM"), charIDToTypeID(s.shadow_blend));
                var shColor = new ActionDescriptor();
                shColor.putDouble(charIDToTypeID("Rd  "), s.shadow_rgb[0]);
                shColor.putDouble(charIDToTypeID("Grn "), s.shadow_rgb[1]);
                shColor.putDouble(charIDToTypeID("Bl  "), s.shadow_rgb[2]);
                sh.putObject(charIDToTypeID("Clr "), charIDToTypeID("RGBC"), shColor);
                sh.putUnitDouble(charIDToTypeID("Opct"), charIDToTypeID("#Prc"), s.shadow_opacity);
                sh.putBoolean(charIDToTypeID("uglg"), false);
                sh.putUnitDouble(charIDToTypeID("lagl"), charIDToTypeID("#Ang"), s.shadow_angle);
                sh.putUnitDouble(charIDToTypeID("Dstn"), charIDToTypeID("#Pxl"), s.shadow_distance);
                sh.putUnitDouble(charIDToTypeID("Ckmt"), charIDToTypeID("#Prc"), s.shadow_spread);
                sh.putUnitDouble(charIDToTypeID("blur"), charIDToTypeID("#Pxl"), s.shadow_size);
                fx.putObject(charIDToTypeID("DrSh"), charIDToTypeID("DrSh"), sh);
            }}
            return fx;
        }}
        for (var k = 0; k < requests.length; k++) {{
            var req = requests[k];
            var g = doc.layerSets.getByID(req.id);
            if (!g) continue;
            var layers = [];
            (function collect(grp){{
                for (var i = 0; i < grp.artLayers.length; i++){{
                    var l = grp.artLayers[i];
                    var isText = (function(ll){{try{{return !!ll.textItem}}catch(e){{return false}}}})(l);
                    layers.push([l, isText]);
                }}
                for (var i = 0; i < grp.layerSets.length; i++){{
                    collect(grp.layerSets[i]);
                }}
            }})(g);
            for (var j = 0; j < layers.length; j++){{
                var l = layers[j][0];
                var fx = req.textOnly ? (layers[j][1] ? buildFx(req.body) : null) : buildFx(layers[j][1] ? req.body : req.icon);
                if (!fx) continue;
                try {{
                    doc.activeLayer = l;
                    var desc = new ActionDescriptor();
                    var ref = new ActionReference();
                    ref.putProperty(charIDToTypeID("Prpr"), charIDToTypeID("Lefx"));
                    ref.putEnumerated(charIDToTypeID("Lyr "), charIDToTypeID("Ordn"), charIDToTypeID("Trgt"));
                    desc.putReference(charIDToTypeID("null"), ref);
                    desc.putObject(charIDToTypeID("T   "), charIDToTypeID("Lefx"), fx);
                    executeAction(charIDToTypeID("setd"), desc, DialogModes.NO);
                }} catch(e) {{}}
            }}
        }}
    }})();
    '''
    try:
        app.doJavaScript(jsx)
    except Exception as e:
        print(f"[Layer Style] Mega batch apply failed, falling back: {e}")
        for req in requests:
            try:
                if req.get("text_only"):
                    apply_style_to_group_text_layers(app, doc, req.get("layer_group"), req.get("body") or req.get("icon"), text_only=True)
                else:
                    apply_dual_style_to_group(app, doc, req.get("layer_group"), req.get("body"), req.get("icon"))
            except Exception as e2:
                print(f"[Layer Style] Mega style per-group fallback failed: {e2}")
    print(f"[Layer Style] Mega style batch applied to {len(jsx_reqs)} group(s) in one JSX call")
