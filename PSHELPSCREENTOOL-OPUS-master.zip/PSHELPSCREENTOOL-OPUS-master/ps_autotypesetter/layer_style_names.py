"""layer_style_names — renaming a style of the project's layer-style library.

Styles are used by name, from many places of the settings: style_assignments (heading, body, ...),
word / selection rules and strips ("fx"), table looks, cells and lines ("fx", "lines_fx"), paytable
texts and shapes ("text_fx", "fx") and text boxes ("style", in dynamic_settings.text_boxes). A rename
moves the library entry (its position kept) and every one of those references, so nothing that used
the style loses it. Card templates saved outside the project are not touched.
"""
import copy

_NAME_KEYS = {"fx", "text_fx", "lines_fx"}


def _swap(node, old, new, box=False):
    n = 0
    if isinstance(node, dict):
        for k, v in node.items():
            if isinstance(v, str):
                if v == old and (k in _NAME_KEYS or (box and k == "style")):
                    node[k] = new
                    n += 1
            else:
                n += _swap(v, old, new, box)
    elif isinstance(node, list):
        for v in node:
            n += _swap(v, old, new, box)
    return n


def rename(cfg, old, new):
    """(settings copy with style `old` called `new`, number of references moved).

    ValueError when the name is empty, unknown, or already taken by another style."""
    old, new = str(old or "").strip(), str(new or "").strip()
    cfg = copy.deepcopy(cfg if isinstance(cfg, dict) else {})
    ds = cfg.get("dynamic_settings") if isinstance(cfg.get("dynamic_settings"), dict) else {}
    lib = ds.get("layer_style_library") if isinstance(ds.get("layer_style_library"), dict) else {}
    if not new:
        raise ValueError("Give the layer style a name.")
    if old not in lib:
        raise ValueError(f"There is no layer style “{old}”.")
    if new == old:
        return cfg, 0
    if new in lib:
        raise ValueError(f"A layer style called “{new}” already exists.")
    ds["layer_style_library"] = {(new if k == old else k): v for k, v in lib.items()}
    n = 0
    assign = ds.get("style_assignments")
    if isinstance(assign, dict):
        for role, name in list(assign.items()):
            if name == old:
                assign[role] = new
                n += 1
    for key, value in ds.items():
        if key not in ("layer_style_library", "style_assignments"):
            n += _swap(value, old, new, box=(key == "text_boxes"))
    for key, value in cfg.items():
        if key != "dynamic_settings":
            n += _swap(value, old, new)
    return cfg, n
