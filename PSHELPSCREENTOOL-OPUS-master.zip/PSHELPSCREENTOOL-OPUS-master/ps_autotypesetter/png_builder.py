import contextvars
import math
import os
import re
import threading
import time
from openpyxl.utils import range_boundaries
import json
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter, range_boundaries, column_index_from_string

from .config import TABLE_DEFAULTS, canonical_layout_enabled
from .excel_utils import get_excel_color, get_excel_fill_color
from .icon_mapping import get_icon_size_override, resolve_icon_path
from . import icon_scales                        # icon sizes and gaps set on a preview (tags in the text)
from .table_detector import detect_tables_in_sheet, manual_tables_from_ranges
from .build_engine import (
    DEFAULT_ROW_GAP,
    _effective_row_gap,
    _page_render_column_window_for_sheet,
    _render_window_for_sheet,
    _resolve_xtra_reels_asset,
    detect_master_border,
)
from .table_mapping import (
    load_mapped_table_templates,
    mapped_record_consumed_rows,
    resolve_table_source_text,
    resolve_table_token,
    source_row_range_for_template,
    template_matches_sheet,
    direct_range_bounds,
)

try:
    from .dynamic_pages.paytable.parser import parse_paytable_sheet
except Exception:
    parse_paytable_sheet = None
try:
    from .dynamic_pages.paytable.auto_extend import auto_extend_card_slots
except Exception:
    auto_extend_card_slots = None
try:
    from .dynamic_pages.template_loader import scale_template_slots
except Exception:
    scale_template_slots = None


def _untag_token(value):
    """A token as the artist wrote it (an Assets & Icons size tag dropped): 'WILD~140' -> 'WILD'."""
    from .icon_scales import strip

    return strip(value)


TOKEN_RE = re.compile(r"<([^<>]+)>")
CELL_RE = re.compile(r"^[A-Z]{1,3}\d+$", re.I)
RANGE_RE = re.compile(r"\$?[A-Z]{1,3}\$?\d+(?::\$?[A-Z]{1,3}\$?\d+)?", re.I)


class PngBuildCancelled(Exception):
    """Raised when the PNG-only worker receives a stop request."""


def _require_pillow():
    try:
        from PIL import Image, ImageDraw, ImageFont
    except Exception as exc:
        raise RuntimeError(
            "PNG-only build needs Pillow. Install Pillow in the Python used by this tool "
            "or run the normal PSD build path."
        ) from exc
    return Image, ImageDraw, ImageFont


def _text(value):
    if value is None:
        return ""
    text = str(value).replace("\r\n", "\n").replace("\r", "\n").strip()
    return text


def _rgb(value, fallback=(255, 255, 255)):
    if value is None:
        return tuple(fallback)
    if isinstance(value, str):
        match = re.search(r"#?([0-9A-Fa-f]{6})", value)
        if match:
            raw = match.group(1)
            return int(raw[0:2], 16), int(raw[2:4], 16), int(raw[4:6], 16)
    try:
        vals = list(value)
        if len(vals) >= 3:
            return tuple(max(0, min(255, int(v))) for v in vals[:3])
    except Exception:
        pass
    return tuple(fallback)


def _safe_int(value, fallback=0):
    try:
        return int(float(value))
    except Exception:
        return int(fallback)


def _row_gap_px(font_size, line_spacing, line_step_override=None, line_gap=None):
    """PNG-side twin of build_engine._line_gap_margin_px so PNG row stacking
    matches the PSD renderer exactly.

    Priority (mirrors the PSD engine):
      1. UI "Row spacing" (line_gap, px, 0 allowed) wins whenever it is
         provided -- 0 means rows touch their own bounds.
      2. A configured px line-height (e.g. `game_rules_line_height`) wins.
      3. The Typography 'Line spacing' value: the Web UI multiplier
         (0.5-3) becomes font * (multiplier - 1); a px value is used directly.
    """
    if line_gap is not None:
        try:
            return max(0, int(round(float(line_gap))))
        except Exception:
            return 0
    try:
        step = int(round(float(line_step_override))) if line_step_override else 0
        if step > 0:
            return step
    except Exception:
        pass
    try:
        raw = float(line_spacing)
    except Exception:
        return 0
    if 0.0 <= raw <= 3.0:
        try:
            font = max(0.0, float(font_size))
        except Exception:
            font = 0.0
        return int(round(font * max(0.0, raw - 1.0)))
    return max(0, int(round(raw)))


def _inner_safe_box(canvas_w, canvas_h, margin_x, inner_canvas_width=0):
    """Symmetric inner-canvas safe area for normal pages.

    The content box (heading/body/tables) is capped so it is never wider than
    the background height minus a 10 px breathing margin on each side, and is
    centered on the canvas (left == right margin). `inner_canvas_width` is an
    explicit override (0 = auto). The classic `margin_x` box is kept when the
    margins already make the box narrower than the cap.

    Returns (safe_left, safe_width) in page px.
    """
    default_w = max(100, canvas_w - max(0, _safe_int(margin_x, 0)) * 2)
    explicit = max(0, _safe_int(inner_canvas_width, 0))
    if explicit > 0:
        inner = min(max(100, explicit), canvas_w)
    elif canvas_w >= canvas_h:
        inner = min(default_w, max(100, canvas_h - 20))
    else:
        inner = default_w
    if inner >= default_w:
        return int(margin_x), default_w
    return int((canvas_w - inner) / 2.0), int(inner)


def _emit(progress_callback, event, **payload):
    if callable(progress_callback):
        data = {"event": event}
        data.update(payload)
        try:
            progress_callback(data)
        except Exception:
            pass


def _check_cancel(cancel_event):
    if cancel_event is not None and getattr(cancel_event, "is_set", lambda: False)():
        raise PngBuildCancelled("PNG build stopped by user.")


def _note(report, message):
    if isinstance(report, dict):
        report.setdefault("notes", []).append(str(message))


def _warn(report, message):
    if isinstance(report, dict):
        report.setdefault("warnings", []).append(str(message))


def _file_safe(name):
    clean = re.sub(r'[<>:"/\\|?*\x00-\x1F]+', "_", str(name or "").strip())
    clean = re.sub(r"\s+", " ", clean).strip(" .")
    return clean or "Page"


def _compact_font_name(value):
    return re.sub(r"[^a-z0-9]+", "", str(value or "").casefold())


def _font_candidates(font_name, bold=False, italic=False):
    base = str(font_name or "").strip()
    style_text = base.casefold()
    bold = bold or any(item in style_text for item in ("bold", "semibold", "semi bold", "demibold", "black", "heavy"))
    italic = italic or "italic" in style_text or "oblique" in style_text
    light = any(item in style_text for item in ("light", "extralight", "extra light"))
    condensed = "condensed" in style_text or "narrow" in style_text
    base_clean = base
    style_suffix = r"\s+(Regular|Medium|SemiBold|Semi Bold|DemiBold|Bold Italic|Bold|Italic|Oblique|Black|Heavy|ExtraLight|Extra Light|Light|Condensed|Narrow)$"
    while True:
        cleaned = re.sub(style_suffix, "", base_clean, flags=re.I).strip()
        if cleaned == base_clean:
            break
        base_clean = cleaned
    compact = _compact_font_name(base_clean)
    direct = []
    if "segoeprint" in compact:
        direct.append("segoeprb.ttf" if bold else "segoepr.ttf")
    elif "arial" in compact:
        direct.append("arialbi.ttf" if bold and italic else "arialbd.ttf" if bold else "ariali.ttf" if italic else "arial.ttf")
    if "segoe" in compact:
        if bold and italic:
            direct.extend(["seguisbi.ttf", "segoeuiz.ttf", "segoeuib.ttf"])
        elif bold:
            direct.extend(["seguisb.ttf", "segoeuib.ttf"])
        elif italic:
            direct.extend(["segoeuii.ttf"])
        elif light:
            direct.extend(["segoeuil.ttf", "seguili.ttf"])
        else:
            direct.append("segoeui.ttf")
    if "jhenghei" in compact:
        direct.append("msjhbd.ttc" if bold else "msjhl.ttc" if light else "msjh.ttc")
    if "calibri" in compact:
        direct.append("calibriz.ttf" if bold and italic else "calibrib.ttf" if bold else "calibrii.ttf" if italic else "calibril.ttf" if light else "calibri.ttf")
    if "timesnewroman" in compact:
        direct.append("timesbd.ttf" if bold else "timesi.ttf" if italic else "times.ttf")
    if "couriernew" in compact:
        direct.append("courbd.ttf" if bold else "couri.ttf" if italic else "cour.ttf")
    return base_clean, compact, direct, {"bold": bold, "italic": italic, "light": light, "condensed": condensed}


_FONT_CACHE = {}
_FONT_PATH_INDEX = None


def _font_file_index():
    global _FONT_PATH_INDEX
    if _FONT_PATH_INDEX is not None:
        return _FONT_PATH_INDEX
    seen = set()
    items = []
    font_dirs = [
        os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts"),
        r"C:\Windows\Fonts",
        os.path.join(os.environ.get("LOCALAPPDATA", ""), "Microsoft", "Windows", "Fonts"),
        os.path.join(os.getcwd(), "fonts"),
        os.path.join(os.getcwd(), "Fonts"),
        "/usr/share/fonts",
        "/usr/local/share/fonts",
    ]
    for folder in font_dirs:
        if not folder or not os.path.isdir(folder):
            continue
        try:
            for root, _dirs, files in os.walk(folder):
                for filename in files:
                    if not filename.lower().endswith((".ttf", ".ttc", ".otf")):
                        continue
                    path = os.path.join(root, filename)
                    key = os.path.normcase(path)
                    if key in seen or not os.path.isfile(path):
                        continue
                    seen.add(key)
                    items.append((path, _compact_font_name(os.path.splitext(filename)[0])))
        except Exception:
            pass
    _FONT_PATH_INDEX = items
    return items


def _best_font_path(base_clean, compact, style_flags):
    if not compact:
        return None
    words = [_compact_font_name(part) for part in re.split(r"\s+", str(base_clean or "")) if len(part.strip()) > 2]
    best = None
    best_score = 0
    for path, stem in _font_file_index():
        score = 0
        if stem == compact:
            score += 130
        elif compact in stem:
            score += 105
        elif words and all(word and word in stem for word in words):
            score += 85
        elif words and sum(1 for word in words if word and word in stem) >= max(1, len(words) - 1):
            score += 55
        else:
            continue
        stem_text = stem.casefold()
        has_bold = (
            any(token in stem_text for token in ("bold", "semibold", "black", "heavy"))
            or stem_text.endswith("bd")
        )
        has_italic = (
            "italic" in stem_text
            or "oblique" in stem_text
            or stem_text.endswith("it")
            or stem_text.endswith("i")
        )
        has_light = "light" in stem_text or stem_text.endswith("lt") or stem_text.endswith("l")
        has_condensed = "condensed" in stem_text or "narrow" in stem_text or stem_text.endswith("cn")
        score += 18 if style_flags.get("bold") and has_bold else -9 if style_flags.get("bold") else -7 if has_bold else 5
        score += 14 if style_flags.get("italic") and has_italic else -8 if style_flags.get("italic") else -5 if has_italic else 4
        if style_flags.get("light"):
            score += 10 if has_light else -3
        if style_flags.get("condensed"):
            score += 8 if has_condensed else -2
        if score > best_score:
            best_score = score
            best = path
    return best if best_score >= 50 else None


_HEAVY = ("bold", "black", "heavy", "semibold", "demibold", "extrabold", "ultrabold")
_LIGHT = ("light", "thin", "hairline", "extralight", "ultralight")


_WEIGHT_WORDS = ("extrabold", "ultrabold", "semibold", "demibold", "extralight", "ultralight",
                 "black", "heavy", "medium", "light", "thin", "hairline")


def _untag_text(text):
    """A line's text without the icon size tags: '<WILD~140>' -> '<WILD>' (the report shows plain text)."""
    return re.sub(r"<([^<>]*?)\s*(?:~\d+(?:\.\d+)?(?:\^[\d.]+,[\d.]+)?|\^[\d.]+,[\d.]+)\s*>", r"<\1>", str(text or ""))


def _row_gap_setting(settings, key):
    """A paragraph's own row gap in px (0 allowed), or None when the artist didn't set one."""
    raw = (settings or {}).get(key)
    if raw is None or (isinstance(raw, str) and not raw.strip()):
        return None
    try:
        return max(0, int(round(float(raw))))
    except (TypeError, ValueError):
        return None


def heading_shape(settings):
    """The heading's Character-panel look besides size / tracking (a Mimic PSD learns it from the artist's
    heading layer): {"hscale", "vscale"} (1.0 = 100 %) and "kerning" (True = Metrics, False = none)."""
    settings = settings or {}
    ds = settings.get("dynamic_settings") if isinstance(settings.get("dynamic_settings"), dict) else {}

    def pick(key, default):
        raw = settings.get(key, ds.get(key))
        return default if raw in (None, "") else raw

    def pct(key):
        try:
            return max(0.01, min(10.0, float(pick(key, 100)) / 100.0))
        except (TypeError, ValueError):
            return 1.0
    return {"hscale": pct("heading_hscale"), "vscale": pct("heading_vscale"),
            "kerning": str(pick("heading_kerning", "metrics")).lower() != "none"}


def _heading_font(ImageFont, font_name, size, settings):
    """The heading font with its width / height scale and kerning (heading_shape)."""
    from . import ps_text as _pst

    return _pst.shaped(_load_font(ImageFont, font_name, size, bold=True), **heading_shape(settings))


def _tracking_setting(settings, key):
    """Letter spacing from Typography (Photoshop tracking, 1/1000 em); 0 when unset."""
    try:
        return max(-200.0, min(1000.0, float((settings or {}).get(key) or 0)))
    except (TypeError, ValueError):
        return 0.0


def table_room(safe_bottom, heading_bottom, heading_to_body_gap, continued_gap, h_size):
    """The most height a table gets: the body room of a Continued page (heading, "(Continued)",
    gaps) — and never more than page 1's body room. The live window and the build both size
    tables with this, so a table looks the same in the preview, the PNG and the PSD."""
    cg = max(0, _safe_int(continued_gap, 15))
    from . import row_roles

    cbg = row_roles.continued_body_gap(20)                 # the artist's Continued–Body Gap, when set
    cont_top = float(heading_bottom) + max(8, cg) + math.ceil(_safe_int(h_size, 48) * 0.38) + (max(20, cg) if cbg is None else cbg)
    body_top = float(heading_bottom) + max(0, _safe_int(heading_to_body_gap, 40))
    return max(40.0, float(safe_bottom) - max(cont_top, body_top))


def _table_splits(table_style, table):
    """Where the artist cut this table (Visualiser ✂): body-row numbers a part starts at, sorted.
    [] = one table. (An old `True` from the automatic split counts as no cut.)"""
    raw = ((table_style or {}).get("split_tables") or {}).get(str((table or {}).get("design_key") or ""))
    if not isinstance(raw, (list, tuple)):
        return []
    out = set()
    for v in raw:
        try:
            if int(v) > 0:
                out.add(int(v))
        except (TypeError, ValueError):
            pass
    return sorted(out)


def _table_split_on(table_style, table):
    return bool(_table_splits(table_style, table))


TABLE_PART_SIDE_GAP = 40      # px between cut parts laid side by side


def _table_part_pages(table_style, table):
    """{part index: -1 | 1} — parts of a cut table the artist sent to the page before the table's
    (under the text above it) or the page after; the rest stay together on the table's page."""
    raw = ((table_style or {}).get("split_pages") or {}).get(str((table or {}).get("design_key") or ""))
    out = {}
    for k, v in (raw or {}).items() if isinstance(raw, dict) else ():
        try:
            k, v = int(k), int(v)
        except (TypeError, ValueError):
            continue
        if v in (-1, 1):
            out[k] = v
    return out


def _table_part_block(heights, table_w, table_x, safe_width, gap, align="center"):
    """Where the cut parts sharing one page go: [(dx, dy)] from the spot a whole table is drawn at,
    and the block's height. Side by side (TABLE_PART_SIDE_GAP apart; centred, or at the left / right
    of the area with `align` — the paragraph's) when they fit across the safe area, else one under
    the other. The live window places them with the same rule."""
    n = len(heights)
    total = n * table_w + (n - 1) * TABLE_PART_SIDE_GAP
    if n > 1 and table_w > 0 and total <= safe_width:
        start = 0.0 if align == "left" else (safe_width - total) if align == "right" else (safe_width - total) / 2.0
        spots = [(int(round(start + i * (table_w + TABLE_PART_SIDE_GAP) - table_x)), 0) for i in range(n)]
        return spots, max(heights)
    spots, y = [], 0
    for h in heights:
        spots.append((0, y))
        y += max(1, h) + gap
    return spots, max(1, y - gap)


def _table_offset(dynamic_settings, sheet_name, element_id):
    """(dx, dy) the artist moved a table (or a part of one) by in the Visualiser."""
    ov = (((dynamic_settings or {}).get("live_overrides") or {}).get(sheet_name) or {}).get(element_id) or {}
    try:
        return float(ov.get("x") or 0), float(ov.get("y") or 0)
    except (TypeError, ValueError):
        return 0.0, 0.0


def visible_sheet_names(wb):
    """The workbook's sheets that Excel shows (hidden and very-hidden sheets are never rendered)."""
    return [ws.title for ws in wb.worksheets if str(getattr(ws, "sheet_state", "visible") or "visible") == "visible"]


def _face_mismatch(filename, style_flags, font_name=""):
    """How far a font file's face (from its name) is from the requested one — smaller is closer.
    A weight the request names ("SemiBold", "Medium") decides first; then weight and slant;
    then a plain / Regular face; then the shortest name."""
    stem = re.sub(r"[^a-z0-9]+", "", os.path.splitext(filename)[0].casefold())
    asked = re.sub(r"[^a-z0-9]+", "", str(font_name or "").casefold())
    named = next((w for w in _WEIGHT_WORDS if w in asked), "")
    exact = int(bool(named) and named not in stem)
    heavy = any(w in stem for w in _HEAVY)
    light = any(w in stem for w in _LIGHT)
    slanted = "italic" in stem or "oblique" in stem
    medium = "medium" in stem
    flags = style_flags or {}
    return (exact, int(heavy != bool(flags.get("bold"))) + int(light != bool(flags.get("light"))),
            int(slanted != bool(flags.get("italic"))),
            int(medium and not flags.get("bold")),
            len(stem))


def _load_font(ImageFont, font_name, size, bold=False, italic=False):
    size = max(8, _safe_int(size, 24))
    key = (str(font_name or ""), size, bool(bold), bool(italic))
    if key in _FONT_CACHE:
        return _FONT_CACHE[key]
    # the installed face this request names, read from the font files (family + style like Photoshop's
    # menus) — the Canvas asks the same index, so it draws with this very file
    from . import fontfaces

    hit = fontfaces.pick(font_name, bold, italic)
    if hit:
        try:
            font = ImageFont.truetype(hit[0], size=size, index=hit[1])
            _FONT_CACHE[key] = font
            return font
        except Exception:
            pass
    base_clean, compact, direct, style_flags = _font_candidates(font_name, bold, italic)
    font_dirs = [
        os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts"),
        r"C:\Windows\Fonts",
        os.path.join(os.environ.get("LOCALAPPDATA", ""), "Microsoft", "Windows", "Fonts"),
        os.path.join(os.getcwd(), "fonts"),
        os.path.join(os.getcwd(), "Fonts"),
        "/usr/share/fonts",
        "/usr/local/share/fonts",
    ]
    for folder in font_dirs:
        for filename in direct:
            path = os.path.join(folder, filename)
            if os.path.isfile(path):
                try:
                    font = ImageFont.truetype(path, size=size)
                    _FONT_CACHE[key] = font
                    return font
                except Exception:
                    pass
        try:
            # every face of the family in this folder, the one whose weight / slant fit the request
            # first ("Poppins" = Poppins-Regular, not Poppins-Bold just because it sorts first)
            matches = [f for f in os.listdir(folder)
                       if compact and compact in re.sub(r"[^a-z0-9]+", "", os.path.splitext(f)[0].casefold())]
            for filename in sorted(matches, key=lambda f: _face_mismatch(f, style_flags, font_name)):
                path = os.path.join(folder, filename)
                try:
                    font = ImageFont.truetype(path, size=size)
                    _FONT_CACHE[key] = font
                    return font
                except Exception:
                    pass
        except Exception:
            pass
    path = _best_font_path(base_clean, compact, style_flags)
    if path:
        try:
            font = ImageFont.truetype(path, size=size)
            _FONT_CACHE[key] = font
            return font
        except Exception:
            pass
    # Final fallback must still be a scalable TrueType font; otherwise Pillow's
    # bitmap default ignores requested size and every UI font size looks tiny.
    fallback_fonts = [
        "arial.ttf",
        "Arial.ttf",
        "DejaVuSans.ttf",
        "DejaVuSans-Bold.ttf" if style_flags.get("bold") else "DejaVuSans.ttf",
        "LiberationSans-Bold.ttf" if style_flags.get("bold") else "LiberationSans-Regular.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if style_flags.get("bold") else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf" if style_flags.get("bold") else "/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf",
    ]
    for fallback_path in fallback_fonts:
        try:
            font = ImageFont.truetype(fallback_path, size=size)
            _FONT_CACHE[key] = font
            return font
        except Exception:
            pass
    font = ImageFont.load_default()
    _FONT_CACHE[key] = font
    return font


# Build-scoped caches: layout measures the same strings and loads the same
# icons thousands of times per build (~10s of a 28-sheet build). Cleared at
# the start of every build so changed icons/fonts are always picked up.
_MEASURE_CACHE = {}
_BBOX_CACHE = {}
_ICON_CACHE = {}


def _clear_build_caches():
    _MEASURE_CACHE.clear()
    _BBOX_CACHE.clear()
    _ICON_CACHE.clear()


def _font_key(draw, font):
    from . import ps_text as _pst

    return (getattr(font, "path", None) or id(font), getattr(font, "size", None),
            getattr(font, "index", 0), getattr(font, "layout_engine", None),
            getattr(draw, "fontmode", None)) + _pst.shape_of(font)


def _measure_text(draw, text, font):
    text = str(text or "")
    if not text:
        return 0, 0
    from . import ps_text as _pst

    key = (_font_key(draw, font), text, _pst.current_tracking())
    hit = _MEASURE_CACHE.get(key)
    if hit is None:
        hit = _MEASURE_CACHE[key] = _measure_text_uncached(draw, text, font)
    return hit


def _measure_text_uncached(draw, text, font):
    if "\n" not in text and getattr(font, "path", None):
        # width = Photoshop's layout width (exact advances); height = Pillow's ink box
        box = _text_bbox(draw, text, font)
        return max(0, box[2] - box[0]), max(0, box[3] - box[1])
    try:
        box = draw.multiline_textbbox((0, 0), text, font=font, spacing=0)
        return max(0, box[2] - box[0]), max(0, box[3] - box[1])
    except Exception:
        try:
            box = draw.textbbox((0, 0), text, font=font)
            return max(0, box[2] - box[0]), max(0, box[3] - box[1])
        except Exception:
            return len(text) * 8, 16


def _text_bbox(draw, text, font):
    text = str(text or "")
    if not text:
        return 0, 0, 0, 0
    from . import ps_text as _pst

    key = (_font_key(draw, font), text, _pst.current_tracking())
    hit = _BBOX_CACHE.get(key)
    if hit is None:
        hit = _BBOX_CACHE[key] = _text_bbox_uncached(draw, text, font)
    return hit


def _text_bbox_uncached(draw, text, font):
    try:
        box = draw.textbbox((0, 0), text, font=font)
        if getattr(font, "path", None):
            # Pillow's box spans the (hinted, whole-pixel) advance; use the exact
            # advance Photoshop lays the text out with (ps_text)
            from . import ps_text

            top, bottom = box[1], box[3]
            vs = ps_text.shape_of(font)[1]
            if vs != 1.0:
                # a height-scaled font (Photoshop's vertical scale) shrinks its ink toward the baseline
                asc = font.getmetrics()[0]
                top, bottom = asc + (top - asc) * vs, asc + (bottom - asc) * vs
            return (0, top, round(ps_text.advance(font, text), 3), bottom)
        return box
    except Exception:
        w, h = _measure_text(draw, text, font)
        return 0, 0, w, h


def fx_by_name(layer_style_library, name):
    """A layer style of the library by its name (or an inline fx dict), ready for the effects engine."""
    if isinstance(name, dict):
        from .fx_descriptor import enrich_style

        return enrich_style(name)
    config = (layer_style_library or {}).get(str(name or "")) if name else None
    if not config:
        return None
    from .fx_descriptor import enrich_style

    return enrich_style(config)


def _resolve_fx_config(layer_style_library, style_assignments, role_name):
    if not layer_style_library or not style_assignments:
        return None
    style_name = style_assignments.get(role_name)
    if not style_name:
        return None
    config = layer_style_library.get(style_name)
    if not config:
        return None
    # The live canvas and ps_fx_png need the readable params of every effect;
    # the byte-exact descriptor (kept for the PSD) is decoded once here.
    from .fx_descriptor import enrich_style

    return enrich_style(config)


def _render_text_with_fx(base, draw, x, y, text, font, fill, line_height, fx_config):
    from PIL import Image, ImageDraw  # PIL is optional at module import time

    box = _text_bbox(draw, text, font)
    text_h = max(0, box[3] - box[1])

    stroke_size = _safe_int(fx_config.get("stroke_size"), 0) if fx_config.get("stroke_enabled") else 0
    shadow_distance = _safe_int(fx_config.get("shadow_distance"), 0) if fx_config.get("shadow_enabled") else 0
    shadow_size = _safe_int(fx_config.get("shadow_size"), 0) if fx_config.get("shadow_enabled") else 0
    pad = max(stroke_size, shadow_distance + shadow_size, 2)

    text_w = max(1, box[2] - box[0])
    img_w = int(text_w + pad * 2)
    img_h = max(1, int(text_h + pad * 2))

    temp = Image.new("RGBA", (img_w, img_h), (0, 0, 0, 0))
    temp_draw = ImageDraw.Draw(temp)
    tx = pad - box[0]
    ty = pad - box[1]

    if fx_config.get("shadow_enabled"):
        import math
        shadow_rgb = _rgb(fx_config.get("shadow_rgb"), (0, 0, 0))
        shadow_opacity = max(0, min(255, int(_safe_int(fx_config.get("shadow_opacity"), 75) * 255 / 100)))
        angle = _safe_int(fx_config.get("shadow_angle"), 120)
        dist = _safe_int(fx_config.get("shadow_distance"), 5)
        sdx = dist * math.cos(math.radians(angle))
        sdy = dist * math.sin(math.radians(angle))
        blur_radius = max(0, _safe_int(fx_config.get("shadow_size"), 5))
        shadow_fill = (*shadow_rgb, shadow_opacity)
        shadow_img = Image.new("RGBA", (img_w, img_h), (0, 0, 0, 0))
        shadow_draw = ImageDraw.Draw(shadow_img)
        shadow_draw.text((tx + sdx, ty + sdy), str(text or ""), font=font, fill=shadow_fill)
        if blur_radius > 0:
            from PIL import ImageFilter
            shadow_img = shadow_img.filter(ImageFilter.GaussianBlur(radius=blur_radius))
        temp.alpha_composite(shadow_img)

    if fx_config.get("stroke_enabled"):
        stroke_rgb = _rgb(fx_config.get("stroke_rgb"), (0, 0, 0))
        stroke_opacity = max(0, min(255, int(_safe_int(fx_config.get("stroke_opacity"), 100) * 255 / 100)))
        sw = max(0, _safe_int(fx_config.get("stroke_size"), 2))
        stroke_fill = (*stroke_rgb, stroke_opacity)
        offsets = []
        for dx in range(-sw, sw + 1):
            for dy in range(-sw, sw + 1):
                if dx * dx + dy * dy <= sw * sw:
                    offsets.append((dx, dy))
        if offsets:
            stroke_img = Image.new("RGBA", (img_w, img_h), (0, 0, 0, 0))
            stroke_draw = ImageDraw.Draw(stroke_img)
            for sdx, sdy in offsets:
                stroke_draw.text((tx + sdx, ty + sdy), str(text or ""), font=font, fill=stroke_fill)
            temp.alpha_composite(stroke_img)

    main_alpha = fill if len(fill) == 4 else (*fill, 255)
    temp_draw.text((tx, ty), str(text or ""), font=font, fill=main_alpha)

    base.alpha_composite(temp, (int(x - pad + box[0]), int(y - pad + box[1])))


def _draw_text_visual(draw, x, y, text, font, fill, line_height, base=None, fx_config=None):
    box = _text_bbox(draw, text, font)
    text_h = max(0, box[3] - box[1])
    draw_x = x - box[0]
    draw_y = y + max(0, (line_height - text_h) / 2.0) - box[1]
    if fx_config:
        from . import fx_scale

        fx_config = fx_scale.scaled(fx_config, getattr(font, "size", None))   # effects follow the text size
    if fx_config and base is not None:
        from . import ps_fx_png

        # Every layer style (descriptor, captured params, flat stroke/shadow)
        # renders through the Photoshop-free effects engine.
        if ps_fx_png.render_captured_params_text(base, draw_x, draw_y, text, font, fill, fx_config):
            return
    if fx_config and base is not None and (fx_config.get("shadow_enabled") or fx_config.get("stroke_enabled")):
        _render_text_with_fx(base, draw, draw_x, draw_y, text, font, fill, line_height, fx_config)
        return
    _ps_draw(draw, base, draw_x, draw_y + font.getmetrics()[0], str(text or ""), font, fill)


def _ps_draw(draw, base, x, baseline, text, font, fill):
    """Draw text the way Photoshop renders it (ps_text); Pillow as a fallback."""
    target = getattr(draw, "_image", None)
    if target is None:
        target = base
    if target is not None and target.mode in ("RGBA", "RGB") and getattr(font, "path", None):
        from . import ps_text

        rgb = tuple(fill[:3]) if isinstance(fill, (tuple, list)) else (255, 255, 255)
        alpha = (fill[3] / 255.0) if isinstance(fill, (tuple, list)) and len(fill) > 3 else 1.0
        ps_text.draw(target, text, font, x, baseline, rgb, opacity=alpha)
        return
    draw.text((x, baseline), text, font=font, fill=fill, anchor="ls")


def _line_height(draw, font, fallback_size):
    """Line box height mirroring the LIVE canvas exactly:
    max("Ag" glyph bbox, 1.18 x font size) — the live renderer floors every
    line at 1.18em (visualiser_live.js lineHeight), and PSD auto-leading is
    ~1.2em, so rows stack identically in the live window, PSD art and PNG."""
    _, h = _measure_text(draw, "Ag", font)
    try:
        floor = float(fallback_size) * 1.18
    except Exception:
        floor = 0.0
    return max(h, floor)


def _glyph_box_h_px(font):
    """Real glyph box height (ascent + descent) for a PIL font, in px.

    Used by the PSD-style 'Row spacing' stacking: rows advance from the
    CONTENT bottom (glyph box / icon box union) plus the px gap, exactly like
    build_engine's measured-bounds reflow (next_row_top = prev_row_bottom +
    row_gap), instead of from the larger line box."""
    try:
        ascent, descent = font.getmetrics()
        h = float(ascent) + float(descent)
        return max(1, int(math.ceil(h)))
    except Exception:
        return None


def _split_inline(text):
    from . import text_styles as _ts

    parts = []
    starts = []                                       # where each part starts in `text`
    last = 0
    for match in TOKEN_RE.finditer(str(text or "")):
        if match.start() > last:
            parts.append(("text", str(text)[last:match.start()]))
            starts.append(last)
        parts.append(("token", match.group(1).strip()))
        starts.append(match.start())
        last = match.end()
    if last < len(str(text or "")):
        parts.append(("text", str(text)[last:]))
        starts.append(last)
    for _pi in range(len(parts)):
        _kind, _val = parts[_pi]
        if _kind != "text" or not _val:
            continue
        _prev_is_token = _pi > 0 and parts[_pi - 1][0] == "token"
        _next_is_token = _pi + 1 < len(parts) and parts[_pi + 1][0] == "token"
        _at = starts[_pi]
        if _prev_is_token:
            _at += len(_val) - len(_val.lstrip())
            _val = _val.lstrip()
        if _next_is_token:
            _val = _val.rstrip()
        # the piece remembers where it is in its line: " with one or more " is in a row three times
        parts[_pi] = (_kind, _ts.cut(text, _at, _val) if _val else _val)
    return [(kind, value) for kind, value in parts if str(value or "")]


def _load_icon(Image, token, icon_folder, icon_mappings, icon_height, icon_size_overrides=None):
    try:
        key = (str(token), str(icon_folder or ""), repr(sorted((icon_mappings or {}).items())),
               repr(icon_height), repr(sorted((icon_size_overrides or {}).items())))
    except Exception:
        key = None
    if key is not None and key in _ICON_CACHE:
        img, path = _ICON_CACHE[key]
        return (img.copy() if img is not None else None), path  # callers may mutate their icon
    img, path = _load_icon_uncached(Image, token, icon_folder, icon_mappings, icon_height, icon_size_overrides)
    if key is not None:
        _ICON_CACHE[key] = (img.copy() if img is not None else None, path)
    return img, path


def _load_icon_uncached(Image, token, icon_folder, icon_mappings, icon_height, icon_size_overrides=None):
    from . import icon_scales

    token, factor = icon_scales.split(token)        # '<WILD~140>': this icon at 140 % (Assets & Icons)
    path = resolve_icon_path(token, icon_folder, icon_mappings)
    if not path or not os.path.isfile(path):
        return None, None
    target_h = get_icon_size_override(token, icon_size_overrides) or _safe_int(icon_height, 0)
    try:
        img = Image.open(path).convert("RGBA")
    except Exception:
        return None, path
    if factor != 1.0:
        target_h = max(1, int(round((target_h if target_h > 0 else img.height) * factor)))
    if target_h > 0:
        scale = float(target_h) / max(1, img.height)
        img = img.resize((max(1, int(round(img.width * scale))), max(1, int(round(img.height * scale)))))
    return img, path


def _measure_inline(draw, Image, text, font, icon_folder, icon_mappings, icon_height, icon_size_overrides=None, icon_gap_left=0, icon_gap_right=0):
    width = 0
    # LIVE-window parity: floor every line at 1.18 x font size (live canvas
    # lineHeight = max("Ag" bbox, size * 1.18)). Without this floor the PNG
    # rows were a few px shorter than the live renderer and every row start,
    # row gap and page break drifted from the LIVE window / PSD art.
    height = _line_height(draw, font, getattr(font, "size", None) or 0)
    for kind, value in _split_inline(text):
        if kind == "token":
            icon, _path = _load_icon(Image, value, icon_folder, icon_mappings, icon_height, icon_size_overrides)
            if icon:
                _gl, _gr = icon_scales.gaps(value, max(0, _safe_int(icon_gap_left, 0)), max(0, _safe_int(icon_gap_right, 0)))
                width += _gl + icon.width + _gr
                height = max(height, icon.height)
            else:
                w, h = _measure_text(draw, f"<{_untag_token(value)}>", font)
                width += w
                height = max(height, h)
        else:
            w, h = _measure_text(draw, value, font)
            width += _styled_width(draw, value, font)
            height = max(height, h)
    return width, height


def _measure_inline_boxes(draw, Image, text, font, icon_folder, icon_mappings, icon_height, icon_size_overrides=None, icon_gap_left=0, icon_gap_right=0, icon_y_offset=0):
    """Measure one line like _measure_inline, plus the FINAL run geometry.

    Returns (width, height, runs) where `runs` mirrors the exact run walk of
    _draw_inline (same cursor math, gaps and icon compositing positions):
      {"kind": "text", "text": str,  "x": x_rel, "w": width}
      {"kind": "icon", "token": str, "x": x_rel, "y": y_rel (line top),
       "w": width, "h": height}   x/y are relative to the line top-left;
       y already includes the (line_h - icon_h) / 2 + icon_y_offset centering.

    The live canvas consumes these PIL-computed positions directly instead of
    re-measuring runs with browser metrics, so icon/text placement is
    pixel-identical to the PNG renderer without server-side changes to
    _draw_inline (which keeps drawing exactly these positions).
    """
    if not hasattr(Image, "open"):  # accept module / class / probe instance
        Image = _require_pillow()[0]
    width, height = _measure_inline(
        draw, Image, text, font, icon_folder, icon_mappings, icon_height,
        icon_size_overrides, icon_gap_left, icon_gap_right,
    )
    y_off = max(0, _safe_int(icon_y_offset, 0))
    cursor_x = 0
    runs = []
    for kind, value in _split_inline(text):
        if kind == "token":
            icon, _path = _load_icon(Image, value, icon_folder, icon_mappings, icon_height, icon_size_overrides)
            if icon:
                gl, gr = icon_scales.gaps(value, max(0, _safe_int(icon_gap_left, 0)), max(0, _safe_int(icon_gap_right, 0)))
                cursor_x += gl
                runs.append({
                    "kind": "icon",
                    "token": value,
                    "x": cursor_x,
                    "y": (height - icon.height) / 2.0 + y_off,
                    "w": icon.width,
                    "h": icon.height,
                })
                cursor_x += icon.width + gr
            else:
                w, _h = _measure_text(draw, f"<{_untag_token(value)}>", font)
                runs.append({"kind": "text", "text": f"<{_untag_token(value)}>", "x": cursor_x, "w": w})
                cursor_x += w
        else:
            # one run per word style, so the live canvas draws exactly what the PNG draws
            for seg, rgb, sfont, st in _style_runs(value, (255, 255, 255), font):
                if st:                                # its own face and spacing (never matched again on
                    with _run_tracking(st):           # its own: a lone "feature." can't tell which one it is)
                        w = _advance(sfont, seg)
                else:
                    w = _measure_text(draw, seg, font)[0]
                run = {"kind": "text", "text": seg, "x": cursor_x, "w": w}
                if st:
                    run["style"] = {"rgb": list(st["rgb"]) if st.get("rgb") else None,
                                    "bold": st.get("bold"), "italic": st.get("italic"), "font": st.get("font"),
                                    "size": st.get("size"), "fx": st.get("fx_config"),
                                    "tracking": st.get("tracking"), "bg": st.get("bg")}
                runs.append(run)
                cursor_x += w
    return width, height, runs


_LINE_INK_CACHE = {}
_LINE_INK_CACHE_MAX = 4000


def _text_styles_key():
    from . import text_styles

    cur = text_styles._ACTIVE.get()
    return (repr(cur) + "|" + text_styles._ROW.get()) if cur and cur[0] else ""


def _ts_place_key(text):
    from . import text_styles

    return text_styles.place_key(text)


def _line_ink_extents(draw, Image, text, font, icon_folder, icon_mappings, icon_height,
                      icon_size_overrides=None, icon_gap_left=0, icon_gap_right=0,
                      icon_y_offset=0):
    """Exact rendered ink extents of ONE inline line, as (ink_top, ink_bottom)
    offsets from the line's top y.

    The line is rendered into a probe image with the exact _draw_inline walk
    and the ink bounding box is read back, so the result is the REAL pixel ink
    (glyph ink + icon boxes), not the larger font box (ascent + descent).

    All row stacking uses these offsets so the VISUAL gap between consecutive
    rows equals the configured Row Gap px exactly:
        next_line_top = prev_ink_bottom + gap - ink_top
    (top/bottom are offsets from each line's own top y.)
    """
    if not hasattr(Image, "open"):  # accept module / class / probe instance
        Image = _require_pillow()[0]
    try:
        _bw, _bh = _measure_inline(
            draw, Image, text, font, icon_folder, icon_mappings, icon_height,
            icon_size_overrides, icon_gap_left, icon_gap_right,
        )
    except Exception:
        _bw = 1
        _bh = max(1, int(round(float(getattr(font, "size", 24)))))
    try:
        _fs = int(round(float(getattr(font, "size", 0) or 0)))
    except Exception:
        _fs = 0
    _ck = (
        _fs, str(getattr(font, "getname", lambda: ("", ""))()[0]),
        str(text or ""), int(round(float(_safe_int(icon_height, 0) or 0))),
        int(round(float(_safe_int(icon_gap_left, 0) or 0))),
        int(round(float(_safe_int(icon_gap_right, 0) or 0))),
        int(round(float(_safe_int(icon_y_offset, 0) or 0))),
        _text_styles_key(),
        _ts_place_key(text),                          # the same line twice in a row may be styled differently
    )
    _cached = _LINE_INK_CACHE.get(_ck)
    if _cached is not None:
        return _cached
    # ONE line, never wrapped in the probe: room to spare. Drawn a few px wider than it measured
    # (another request's tracking, a style), its last word / symbol fell to a second probe line and
    # the line's ink came out twice as tall (cached: the next row was drawn over it from then on)
    probe_w = max(64, int(_bw * 1.5) + 64)
    result = (0.0, max(1.0, float(_bh)))
    try:
        from PIL import ImageDraw as _PIDraw
        probe = Image.new("RGBA", (probe_w, 512), (0, 0, 0, 0))
        probe_draw = _PIDraw.Draw(probe)
        _draw_inline(
            probe, probe_draw, Image, text, 0, 0, font, (255, 255, 255, 255), probe_w,
            icon_folder, icon_mappings, icon_height, icon_size_overrides,
            align="left", line_spacing=0, fx_config=None,
            icon_gap_left=icon_gap_left, icon_gap_right=icon_gap_right,
            icon_y_offset=icon_y_offset,
        )
        bbox = probe.getbbox()
        if bbox:
            result = (float(bbox[1]), float(bbox[3]))
    except Exception:
        pass
    if len(_LINE_INK_CACHE) < _LINE_INK_CACHE_MAX:
        _LINE_INK_CACHE[_ck] = result
    return result


def _keep_tokens(words, is_icon):
    """The pieces of a line to wrap (words and the spaces between them), each mapped icon token whose
    name has a space ("<Feature Gem>") kept whole: the line never breaks inside it, where it would be
    drawn as two pieces of text. A token that is not mapped is text and may break like text."""
    out, i = [], 0
    while i < len(words):
        acc, j = words[i], i
        while acc.rfind("<") > acc.rfind(">") and j + 1 < len(words):
            j += 1
            acc += words[j]
        spaced = [t.strip() for t in TOKEN_RE.findall(acc) if re.search(r"\s", t)] if j > i else []
        if spaced and acc.rfind("<") < acc.rfind(">") and all(is_icon(t) for t in spaced):
            out.append(acc)
            i = j + 1
            continue
        out.append(words[i])
        i += 1
    return out


def _wrap_inline(draw, Image, text, font, max_width, icon_folder, icon_mappings, icon_height, icon_size_overrides=None, icon_gap_left=0, icon_gap_right=0):
    if max_width <= 0:
        return [str(text or "")]
    from . import text_styles as _ts

    raw = text if isinstance(text, str) else str(text or "")
    if "\n" in raw:
        lines = []
        at = 0
        for chunk in raw.splitlines():
            at = max(0, raw.find(chunk, at))
            lines.extend(_wrap_inline(draw, Image, _ts.cut(raw, at, chunk), font, max_width, icon_folder, icon_mappings, icon_height, icon_size_overrides, icon_gap_left, icon_gap_right))
            at += len(chunk)
        return lines
    words = _keep_tokens(re.split(r"(\s+)", raw), lambda t: _load_icon(
        Image, t, icon_folder, icon_mappings, icon_height, icon_size_overrides)[0] is not None)
    lines = []
    current = ""
    pos = start = 0                                   # where `current` starts in `raw` (word styles)

    def _line(s, at):
        return _ts.cut(raw, at + len(s) - len(s.lstrip()), s.strip())

    def _width(s, at):
        return _measure_inline(draw, Image, _ts.cut(raw, at, s), font, icon_folder, icon_mappings, icon_height, icon_size_overrides, icon_gap_left, icon_gap_right)[0]

    def _fit_word(word, at):
        """A word wider than the box starting a line: broken between letters like Photoshop's paragraph
        box (never inside an icon token), its full lines added; returns (what is left, where it starts)."""
        if not word or "<" in word or _width(word, at) <= max_width:
            return word, at
        i = 0
        while len(word) - i > 1 and _width(word[i:], at + i) > max_width:
            j = i + 1
            while j < len(word) and _width(word[i:j + 1], at + i) <= max_width:
                j += 1
            lines.append(_ts.cut(raw, at + i, word[i:j]))
            i = j
        return word[i:], at + i

    for word in words:
        if not current:
            start = pos
        trial = current + word
        w, _h = _measure_inline(draw, Image, _ts.cut(raw, start, trial), font, icon_folder, icon_mappings, icon_height, icon_size_overrides, icon_gap_left, icon_gap_right)
        if current.strip() and w > max_width:
            lines.append(_line(current, start))
            current, start = _fit_word(word.strip(), pos)
        elif not current.strip() and word.strip() and w > max_width:
            lead = len(trial) - len(trial.lstrip())
            current, start = _fit_word(trial.lstrip(), start + lead)
        else:
            current = trial
        pos += len(word)
    if current.strip():
        lines.append(_line(current, start))
    if not lines:
        lines.append("")
    return lines


def _wrapped_inline_size(draw, Image, text, font, box_width, icon_folder, icon_mappings, icon_height, icon_size_overrides=None, line_spacing=4, icon_gap_left=0, icon_gap_right=0):
    lines = _wrap_inline(draw, Image, text, font, max(1, int(box_width)), icon_folder, icon_mappings, icon_height, icon_size_overrides, icon_gap_left, icon_gap_right)
    max_w = 0
    total_h = 0
    for line in lines:
        line_w, line_h = _measure_inline(draw, Image, line, font, icon_folder, icon_mappings, icon_height, icon_size_overrides, icon_gap_left, icon_gap_right)
        max_w = max(max_w, line_w)
        total_h += line_h
    total_h += max(0, len(lines) - 1) * max(0, _safe_int(line_spacing, 0))
    return max_w, total_h


_ICON_SINK = threading.local()      # .list: (token, x, y, w, h) of every icon _draw_inline draws, while set
# .rec: {"lines": [...], "ctx": {...}, "skip": bool} — every line _draw_inline lays out, while set: the Game /
# Bingo Rules pages' Canvas layout (rules_layout.py). "skip": lay out only, draw no text (the page's
# picture without its text: separator, strips, XTRAA REELS)
_LINE_SINK = threading.local()


class line_sink:
    """with line_sink(skip_text) as rec: rec["lines"] gets one dict per line _draw_inline lays out."""

    def __init__(self, skip_text=False):
        self.rec = {"lines": [], "ctx": {}, "skip": bool(skip_text)}

    def __enter__(self):
        self.prev = getattr(_LINE_SINK, "rec", None)
        _LINE_SINK.rec = self.rec
        return self.rec

    def __exit__(self, *exc):
        _LINE_SINK.rec = self.prev
        return False


class _sink_ctx:
    """What the lines laid out inside this block are (kind, cell, part): recorded with each line."""

    def __init__(self, **ctx):
        self.ctx = ctx

    def __enter__(self):
        rec = getattr(_LINE_SINK, "rec", None)
        self.prev = rec["ctx"] if rec is not None else None
        if rec is not None:
            rec["ctx"] = self.ctx

    def __exit__(self, *exc):
        rec = getattr(_LINE_SINK, "rec", None)
        if rec is not None:
            rec["ctx"] = self.prev or {}
        return False


def _align_tracking(font, line):
    """Where Photoshop starts a tracked line: it centres / right-aligns a line two tracking steps narrower
    than it draws (measured in Photoshop 2023: "H", "HB", "GAME RULES" at tracking 50–200 — centred lines
    start one step right of the plain centring, right-aligned two). Left-aligned lines are unaffected."""
    from . import ps_text as _pst

    t = _pst.tracking_px(font)
    if not t or not any(k != "token" and str(v).strip() for k, v in _split_inline(line)):
        return 0.0
    return t


class _line_sink_paused:
    """Lines drawn inside are not recorded again (a line drawn twice: Blend If's second pass)."""

    def __enter__(self):
        self.prev = getattr(_LINE_SINK, "rec", None)
        _LINE_SINK.rec = None

    def __exit__(self, *exc):
        _LINE_SINK.rec = self.prev
        return False


def _sink_skips_text():
    rec = getattr(_LINE_SINK, "rec", None)
    return bool(rec and rec.get("skip"))


def _record_lines(rec, draw, Image, text, x, y, font, fill, box_width, icon_folder, icon_mappings, icon_height,
                  icon_size_overrides, align, line_spacing, fx_config, icon_gap_left, icon_gap_right, icon_y_offset,
                  font_request, font_size, bold):
    """_draw_inline's lines, where they land (its own cursor math), into the line sink. Returns (w, h)
    as _draw_inline would."""
    from . import ps_text as _pst

    lines = _wrap_inline(draw, Image, text, font, max(1, int(box_width)), icon_folder, icon_mappings, icon_height, icon_size_overrides, icon_gap_left, icon_gap_right)
    cursor_y, max_w, total_h = y, 0, 0
    for line_no, line in enumerate(lines):
        al = justify_line_align(align, line_no, len(lines))
        line_w, line_h, runs = _measure_inline_boxes(draw, Image, line, font, icon_folder, icon_mappings, icon_height,
                                                     icon_size_overrides, icon_gap_left, icon_gap_right, icon_y_offset)
        max_w = max(max_w, line_w)
        lx = x if al in ("left", "justify_all") else (
            x + max(0, box_width - line_w) + 2 * _align_tracking(font, line) if al == "right"
            else x + max(0, (box_width - line_w) / 2.0) + _align_tracking(font, line))
        rec["lines"].append({
            "text": line, "x": float(lx), "y": float(cursor_y), "w": float(line_w), "h": float(line_h),
            "box_x": float(x), "box_w": float(box_width), "align": al if al in ("left", "center", "right") else "left",
            "runs": runs, "font": str(font_request or ""), "size": float(font_size or getattr(font, "size", 24)),
            "font_path": str(getattr(font, "path", "") or ""),
            "bold": bool(bold), "color": [int(c) for c in tuple(fill)[:3]], "fx": fx_config or {},
            "icon_h": float(icon_height), "gap_l": float(icon_gap_left or 0), "gap_r": float(icon_gap_right or 0),
            "tracking": float(_pst.current_tracking() or 0), "spacing": float(line_spacing or 0),
            "index": line_no, "count": len(lines), "ctx": dict(rec.get("ctx") or {}),
        })
        cursor_y += line_h + line_spacing
        total_h += line_h + line_spacing
    return max_w, max(0, total_h - line_spacing)


def _draw_inline(
    base, draw, Image, text, x, y, font, fill, box_width,
    icon_folder, icon_mappings, icon_height, icon_size_overrides=None,
    align="center", line_spacing=4, fx_config=None,
    icon_gap_left=0, icon_gap_right=0, icon_y_offset=0,
    font_request=None, font_size=None, bold=False, keyword_colors=None, strips=True,
):
    from .psd_writer import recorder as _psd_recorder
    from . import text_styles as _ts
    psd_page = _psd_recorder.page_for(base)
    _strip = _ts.strip_for(text) if strips else None
    if _strip is not None:
        # a background strip behind this line / Excel row (drawn under the text, its own PSD layer)
        _strip_fill = _ts.strip_text_rgb(_strip)
        if _strip_fill:
            fill = tuple(_strip_fill) + (tuple(fill[3:4]) if len(fill) > 3 else ())
        _lines = _wrap_inline(draw, Image, text, font, max(1, int(box_width)), icon_folder, icon_mappings, icon_height, icon_size_overrides, icon_gap_left, icon_gap_right)
        _sizes = [_measure_inline(draw, Image, ln, font, icon_folder, icon_mappings, icon_height, icon_size_overrides, icon_gap_left, icon_gap_right) for ln in _lines]
        _block_h = sum(h for _w, h in _sizes) + max(0, len(_sizes) - 1) * max(0, _safe_int(line_spacing, 0))
        _max_w = max([w for w, _h in _sizes] or [0])
        _al = str(align).lower()
        _tl = x if _al == "left" else (x + box_width - _max_w if _al == "right" else x + (box_width - _max_w) / 2.0)
        _ts.draw_strip(base, _strip, _ts.strip_geometry(_strip, x, y, box_width, _block_h, _tl, _tl + _max_w))
    _lrec = getattr(_LINE_SINK, "rec", None)
    if _lrec is not None:
        _sunk = _record_lines(_lrec, draw, Image, text, x, y, font, fill, box_width, icon_folder, icon_mappings,
                              icon_height, icon_size_overrides, align, line_spacing, fx_config, icon_gap_left,
                              icon_gap_right, icon_y_offset, font_request, font_size, bold)
        if _lrec["skip"] and not (_lrec.get("ctx") or {}).get("draw"):
            return _sunk                          # (a block marked draw=True: recorded and drawn, e.g. payline numbers)
    from . import blend_if as _bif
    _under = _bif.of(fx_config)
    if _under and psd_page is None:
        # Blend If (the layer style's Blending Options): drawn, then hidden where the page under it is
        # outside the Underlying Layer range (the PSD keeps it as the layer's own setting)
        _before = base.copy()
        with _line_sink_paused():
            _res = _draw_inline(base, draw, Image, text, x, y, font, fill, box_width, icon_folder, icon_mappings,
                                icon_height, icon_size_overrides, align, line_spacing, _bif.without(fx_config),
                                icon_gap_left, icon_gap_right, icon_y_offset, font_request, font_size, bold,
                                keyword_colors, False)
        _bif.apply(base, _before, _under)
        return _res
    if fx_config and font_request and font_size and psd_page is None:
        from . import fx_scale

        ps_result = _draw_inline_ps_fastpath(
            base, draw, Image, text, x, y, font, fill, box_width,
            icon_folder, icon_mappings, icon_height, icon_size_overrides,
            align, line_spacing, fx_scale.scaled(fx_config, getattr(font, "size", None)), icon_gap_left, icon_gap_right,
            icon_y_offset, font_request, font_size, bold,
        )
        if ps_result is not None:
            return ps_result

    lines = _wrap_inline(draw, Image, text, font, max(1, int(box_width)), icon_folder, icon_mappings, icon_height, icon_size_overrides, icon_gap_left, icon_gap_right)
    record = None
    if psd_page is not None:
        # (justified lines fill the box: the layer's alignment is where the last line goes)
        _rec_al = JUSTIFY_LAST.get(str(align).lower(), align)
        record = _psd_recorder.TextRecord(font, fill, "left" if _rec_al == "justify_all" else _rec_al, fx_config)
        record.box = (float(x), float(box_width))
    cursor_y = y
    max_line_w = 0
    total_h = 0
    # justify: every line but the paragraph's last stretched to the full width, the last one where the
    # justify mode puts it (JUSTIFY_LAST); "justify_all": every line stretched
    for line_no, line in enumerate(lines):
        line_w, line_h = _measure_inline(draw, Image, line, font, icon_folder, icon_mappings, icon_height, icon_size_overrides, icon_gap_left, icon_gap_right)
        max_line_w = max(max_line_w, line_w)
        per_space = 0.0
        line_al = justify_line_align(align, line_no, len(lines))
        if line_al == "justify_all":
            spaces = sum(str(v).count(" ") for k, v in _split_inline(line) if k != "token")
            if spaces and box_width > line_w:
                per_space = (box_width - line_w) / float(spaces)
                max_line_w = max(max_line_w, box_width)
        if line_al in ("left", "justify_all"):
            cursor_x = x
        elif line_al == "right":
            cursor_x = x + max(0, box_width - line_w) + 2 * _align_tracking(font, line)
        else:
            cursor_x = x + max(0, (box_width - line_w) / 2.0) + _align_tracking(font, line)
        rec_line =_psd_recorder.TextLine(None) if record is not None else None
        # Every text piece of the line shares ONE baseline: pieces split by icons
        # are each centred by ink, so "2 or more" (no capitals) would sit lower
        # than ", Grand". Shift each piece to the whole line's centring.
        _pieces = [v if k != "token" else "" for k, v in _split_inline(line)]
        _joined = "".join(_pieces)
        _ref = None
        if sum(1 for p in _pieces if p.strip()) > 1 and _joined.strip():
            _rb = _text_bbox(draw, _joined, font)
            _ref = max(0, (line_h - max(0, _rb[3] - _rb[1])) / 2.0) - _rb[1]

        def _seg_y(text):
            if _ref is None or not str(text).strip():
                return cursor_y
            sb = _text_bbox(draw, text, font)
            return cursor_y + _ref - (max(0, (line_h - max(0, sb[3] - sb[1])) / 2.0) - sb[1])

        _line_parts = _split_inline(line)
        _bridges = _icon_bridges(_line_parts, fill, font, keyword_colors)
        for _pi, (kind, value) in enumerate(_line_parts):
            if kind == "token":
                icon, path = _load_icon(Image, value, icon_folder, icon_mappings, icon_height, icon_size_overrides)
                _gl, _gr = icon_scales.gaps(value, max(0, _safe_int(icon_gap_left, 0)), max(0, _safe_int(icon_gap_right, 0)))
                if icon and _pi in _bridges:
                    # a strip behind the words on both sides of this icon runs on behind it
                    _bst, _nxt = _bridges[_pi]
                    _nb = _text_bbox(draw, _nxt, font)
                    _base = _seg_y(_nxt) + max(0, (line_h - max(0, _nb[3] - _nb[1])) / 2.0) - _nb[1] + font.getmetrics()[0]
                    _draw_word_bg(base, _bst, cursor_x, _base,
                                  _gl + icon.width + _gr,
                                  _styled_font(font, _bst), value)
                if icon:
                    cursor_x += _gl
                    icon_pos = (int(round(cursor_x)), int(round(cursor_y + (line_h - icon.height) / 2.0 + max(0, _safe_int(icon_y_offset, 0)))))
                    _sink = getattr(_ICON_SINK, "list", None)
                    if _sink is not None:
                        _sink.append((value, icon_pos[0], icon_pos[1], icon.width, icon.height))
                    if rec_line is not None:
                        # PSD: the icon is its own layer over a gap in the text layer.
                        rec_line.gaps.append((cursor_x - _gl, cursor_x + icon.width + _gr))
                        psd_page.icons.append(_psd_recorder.ImageRecord(icon, icon_pos[0], icon_pos[1], value))
                    else:
                        base.alpha_composite(icon, icon_pos)
                    cursor_x += icon.width + _gr
                else:
                    token_text = f"<{_untag_token(value)}>"
                    _draw_text_segment(draw, cursor_x, cursor_y, token_text, font, fill, line_h, base, fx_config, None, rec_line)
                    cursor_x += _measure_text(draw, token_text, font)[0]
            elif per_space and " " in value:
                # justified: word by word, each space wider by the line's share
                words = value.split(" ")
                at = 0
                for wi, word in enumerate(words):
                    if word:
                        word = _ts.cut(value, at, word)   # which "feature." of the row this one is
                        _draw_text_segment(draw, cursor_x, _seg_y(word), word, font, fill, line_h, base, fx_config, keyword_colors, rec_line)
                        cursor_x += _styled_width(draw, word, font)
                    at += len(word) + 1
                    if wi < len(words) - 1:
                        cursor_x += _measure_text(draw, " ", font)[0] + per_space
            else:
                _draw_text_segment(draw, cursor_x, _seg_y(value), value, font, fill, line_h, base, fx_config, keyword_colors, rec_line)
                cursor_x += _styled_width(draw, value, font)
        if rec_line is not None and rec_line.runs:
            record.lines.append(rec_line)
        cursor_y += line_h + line_spacing
        total_h += line_h + line_spacing
    if record is not None and record.lines:
        record.name = " ".join(record.text.split())[:60] or "Text"
        psd_page.texts.append(record)
    return max_line_w, max(0, total_h - line_spacing)


_STYLED_FONT_CACHE = {}


def _styled_font(font, style):
    """The font for a word-style run: same size, bold/italic/other family as asked."""
    if not style or not (style.get("bold") or style.get("italic") or style.get("font") or style.get("size")):
        return font
    try:
        family = style.get("font") or font.getname()[0]
    except Exception:
        family = style.get("font") or ""
    size = getattr(font, "size", 24)
    if style.get("size"):                             # a word drawn bigger / smaller than its line
        size = max(4, int(round(size * float(style["size"]) / 100.0)))
    key = (str(getattr(font, "path", "")), family, size, bool(style.get("bold")), bool(style.get("italic")))
    hit = _STYLED_FONT_CACHE.get(key)
    if hit is None:
        try:
            from PIL import ImageFont as _IF

            if style.get("bold") or style.get("italic") or style.get("font"):
                hit = _load_font(_IF, family, size, bold=bool(style.get("bold")), italic=bool(style.get("italic")))
            else:                                     # same face, another size
                hit = font.font_variant(size=size) if hasattr(font, "font_variant") else font
        except Exception:
            hit = font
        _STYLED_FONT_CACHE[key] = hit
    return hit


def _style_runs(text, fill, font, keyword_colors=None):
    """[(segment, rgb(a), font, style)] — word-style rules first, then keyword colours."""
    from . import text_styles

    alpha = tuple(fill[3:4]) if len(fill) > 3 else ()
    out = []
    for seg, style in text_styles.word_runs(text):
        if not seg:
            continue
        if style:
            rgb = (tuple(style["rgb"]) + alpha) if style.get("rgb") else fill
            out.append((seg, rgb, _styled_font(font, style), style))
        else:
            for kseg, krgb in _keyword_runs(seg, fill, keyword_colors):
                if kseg:
                    out.append((kseg, krgb, font, None))
    return _split_missing(out or [(text, fill, font, None)])


def _split_missing(runs):
    """Characters a run's font has no glyph for (™ in a display heading font) get a run of their own in
    Arial at the same size — what the browser draws on the Canvas, so the PNG and PSD match it."""
    from .psd_writer import fontnames

    if not any(not fontnames.has_glyph(f, ch) for seg, _c, f, _s in runs for ch in seg if not ch.isspace()):
        return runs
    out = []
    for seg, rgb, f, st in runs:
        buf, ok_buf = "", True
        for ch in seg:
            ok = ch.isspace() or fontnames.has_glyph(f, ch)
            if buf and ok != ok_buf:
                out.append((buf, rgb, f if ok_buf else _fallback_font(f), st))
                buf = ""
            buf += ch
            ok_buf = ok
        if buf:
            out.append((buf, rgb, f if ok_buf else _fallback_font(f), st))
    return out


def _fallback_font(font):
    _image, _draw, image_font = _require_pillow()
    return _load_font(image_font, "Arial", getattr(font, "size", 24))


def _advance(font, text):
    """Layout width of a text run: Photoshop's exact advances (see ps_text)."""
    if getattr(font, "path", None):
        from . import ps_text

        return ps_text.advance(font, text)
    return font.getlength(text)


def _icon_bridges(parts, fill, font, keyword_colors=None):
    """{index of an icon part: (style, the text part after it)} for icons between two text parts that
    carry the same strip at that side (a strip behind a whole line runs on behind its icons).
    visualiser_live.js drawCanonicalRuns bridges the same icons."""
    from . import text_styles as _tsb

    if not _tsb.has_word_rules():
        return {}
    edge = {}                                         # text part index -> (first run style, last run style)
    for i, (kind, value) in enumerate(parts):
        if kind == "text" and str(value).strip():
            runs = [st for seg, _c, _f, st in _style_runs(value, fill, font, keyword_colors) if str(seg).strip()]
            if runs:
                edge[i] = (runs[0], runs[-1])
    out, i = {}, 0
    while i < len(parts):
        if parts[i][0] != "text" or i not in edge:
            i += 1
            continue
        j = i + 1
        while j < len(parts) and parts[j][0] == "token":
            j += 1
        left, right = edge[i][1], edge.get(j, (None,))[0]
        if j > i + 1 and left and right and left.get("bg") and left.get("bg") == right.get("bg"):
            for k in range(i + 1, j):
                out[k] = (right, parts[j][1])
        i = j
    return out


def _draw_word_bg(base, style, x, baseline, width, font, text=""):
    """The strip behind selected words (text_styles.bg_of): from just above the capitals to just
    below the baseline at this run's size, plus its padding — visualiser_live.js drawWordBg mirrors it."""
    bg = (style or {}).get("bg")
    if not bg or width <= 0:
        return
    from . import text_styles

    size = float(getattr(font, "size", 0) or 0)
    top, bottom = baseline - 0.85 * size - bg["pad_y"], baseline + 0.25 * size + bg["pad_y"]
    box = (x - bg["pad_x"], top, width + 2 * bg["pad_x"], max(0.0, bottom - top))
    rule = {"text": text, "color": "#%02x%02x%02x" % tuple(bg["rgba"][:3]), "opacity": bg["rgba"][3] / 255.0}
    rule.update((k, bg[k]) for k in ("radius", "radii", "border", "fx", "_fx") if k in bg)   # its corners, border, style
    text_styles.draw_strip(base, rule, box)


def _run_tracking(style):
    """A selection's own letter spacing around its run (else the text's own stays)."""
    import contextlib

    from . import ps_text

    if style and style.get("tracking") is not None:
        return ps_text.tracking(style["tracking"])
    return contextlib.nullcontext()


def _styled_width(draw, text, font):
    """Advance of a text segment; word-styled parts measured with their own font."""
    from . import text_styles

    if not text_styles.has_word_rules():
        return _measure_text(draw, text, font)[0]
    runs = text_styles.word_runs(text)
    if len(runs) == 1 and runs[0][1] is None:
        return _measure_text(draw, text, font)[0]
    total = 0.0
    for seg, st in runs:
        if seg:
            with _run_tracking(st):
                total += _advance(_styled_font(font, st) if st else font, seg)
    return total


def _keyword_runs(text, fill, keyword_colors):
    """[(text, rgb)] — the whole segment in `fill`, split where keywords match."""
    if not keyword_colors or not str(text or "").strip():
        return [(text, fill)]
    from .keyword_manager import get_colored_segments
    alpha = tuple(fill[3:4]) if len(fill) > 3 else ()
    return [(seg, (tuple(color[:3]) + alpha) if color else fill)
            for seg, color in get_colored_segments(text, keyword_colors) if seg]


def _draw_text_segment(draw, x, y, text, font, fill, line_height, base, fx_config, keyword_colors, rec_line):
    """Draw one inline text segment, or record it when building a PSD.

    Without keyword colours this is exactly _draw_text_visual. Keyword runs are
    drawn on the WHOLE segment's baseline (each run centred on its own ink
    would make the baseline jump between colours).
    """
    runs = _style_runs(text, fill, font, keyword_colors)
    styled = any(st or f is not font for _s, _c, f, st in runs)     # a fallback-font run is drawn on its own
    strips = any(st and st.get("bg") for _s, _c, _f, st in runs)
    if rec_line is None and not strips and (len(runs) <= 1 or (fx_config and not styled)):
        if runs and runs[0][3]:                       # the whole segment is one styled word
            seg, rgb, sfont, st = runs[0]
            with _run_tracking(st):
                _draw_text_visual(draw, x, y, seg, sfont, rgb, line_height, base=base,
                                  fx_config=st.get("fx_config") or fx_config)
        else:
            _draw_text_visual(draw, x, y, text, font, fill, line_height, base=base, fx_config=fx_config)
        return
    box = _text_bbox(draw, text, font)
    text_h = max(0, box[3] - box[1])
    pen_x = x - box[0]
    draw_y = y + max(0, (line_height - text_h) / 2.0) - box[1]
    baseline = draw_y + font.getmetrics()[0]
    advances = []
    for seg, _rgb, sfont, st in runs:
        with _run_tracking(st):                       # its own letter spacing (the PSD's tracking follows)
            advances.append(_advance(sfont, seg))
    if strips:                                        # strips behind selected words: under all the text
        at = pen_x
        for (seg, _rgb, sfont, st), adv in zip(runs, advances):
            _draw_word_bg(base, st, at, baseline, adv, sfont, seg)
            at += adv
    if rec_line is not None:
        from .psd_writer import recorder as _rec
        from .psd_writer.recorder import TextRun
        if rec_line.baseline is None:
            rec_line.baseline = baseline
        for (seg, rgb, sfont, _st), advance in zip(runs, advances):
            run = TextRun(seg, rgb, pen_x, advance)
            if sfont is not font:
                run.font = sfont                      # PSD: this run uses its own (bold/italic) face
            own_fx = (_st or {}).get("fx_config")
            page = _rec.page_for(base) if own_fx and own_fx != fx_config and seg.strip() else None
            if page is not None:
                # a layer style is one per text layer: these words are a text layer of their own, in
                # place, and the paragraph keeps their room (filled like an inline icon's)
                own = _rec.TextRecord(sfont, rgb, "left", own_fx)
                line = _rec.TextLine(baseline)
                line.runs.append(TextRun(seg, rgb, pen_x, advance))
                own.lines.append(line)
                own.box = (float(pen_x), float(advance))
                own.name = " ".join(seg.split())[:60] or "Text"
                own.word_style = True                 # its own layer: never joined into a paragraph's layer
                page.texts.append(own)
                rec_line.gaps.append((pen_x, pen_x + advance))
            else:
                rec_line.runs.append(run)
            pen_x += advance
        return
    for (seg, rgb, sfont, st), adv in zip(runs, advances):
        run_fx = (st or {}).get("fx_config") or fx_config
        with _run_tracking(st):
            if run_fx:
                # styled words keep the layer style (or have their own): run by run on the shared baseline
                sb = _text_bbox(draw, seg, sfont)
                _draw_text_visual(draw, pen_x + sb[0], baseline - sfont.getmetrics()[0] + sb[1] - max(0, (line_height - max(0, sb[3] - sb[1])) / 2.0),
                                  seg, sfont, rgb, line_height, base=base, fx_config=run_fx)
            else:
                _ps_draw(draw, base, pen_x, baseline, seg, sfont, rgb)
        pen_x += adv


def _draw_inline_ps_fastpath(base, draw, Image, text, x, y, font, fill, box_width,
                             icon_folder, icon_mappings, icon_height, icon_size_overrides,
                             align, line_spacing, fx_config, icon_gap_left, icon_gap_right,
                             icon_y_offset, font_request, font_size, bold=False):
    """Try to render the heading through Photoshop and composite it.

    Returns ``(width, height)`` on success, or ``None`` on fallback (caller
    must proceed with the normal PIL path).
    """
    from . import photoshop_style_assets as psa

    if not psa.photoshop_style_assets_enabled():
        return None
    try:
        if not psa.is_complex_style(fx_config):
            return None
    except Exception:
        return None
    if not font_request or not font_size:
        return None
    if not psa.photoshop_available():
        return None
    lines = _wrap_inline(draw, Image, text, font, max(1, int(box_width)),
                         icon_folder, icon_mappings, icon_height, icon_size_overrides,
                         icon_gap_left, icon_gap_right)
    if not lines:
        return None
    if any(TOKEN_RE.search(line) for line in lines):
        return None
    line_widths = []
    line_heights = []
    for line in lines:
        lw, lh = _measure_inline(draw, Image, line, font, icon_folder, icon_mappings,
                                 icon_height, icon_size_overrides, icon_gap_left, icon_gap_right)
        line_widths.append(lw)
        line_heights.append(lh)
    try:
        result = psa.render_inline_heading(
            lines, line_widths, line_heights,
            font_request, font_size, fill,
            box_width, align, line_spacing,
            fx_config, bold=bool(bold), italic=False,
        )
    except Exception:
        return None
    asset_path, asset_meta = result
    if not asset_path or not asset_meta:
        return None
    ink = asset_meta.get("ink_bounds") or [0, 0, 0, 0]
    offset_l, offset_t = ink[0], ink[1]
    img = Image.open(asset_path).convert("RGBA")
    max_line_w = max(line_widths) if line_widths else 0
    total_h = sum(line_heights) + line_spacing * max(0, len(lines) - 1)
    align_l = str(align or "center").strip().lower()
    if align_l == "left":
        text_origin_x = x
    elif align_l == "right":
        text_origin_x = x + max(0, box_width - max_line_w)
    else:
        text_origin_x = x + max(0, (box_width - max_line_w) / 2.0)
    ps_doc_w = asset_meta.get("render_size", [0, 0])[0] or 0
    pad = max(40, int(font_size) * 2) if font_size else 96
    if ps_doc_w > 0:
        doc_text_origin_x = pad + max(0.0, (box_width - max_line_w) / 2.0)
        if align_l == "left":
            doc_text_origin_x = pad
        elif align_l == "right":
            doc_text_origin_x = pad + max(0.0, box_width - max_line_w)
        asset_x = int(round(text_origin_x - doc_text_origin_x))
    else:
        asset_x = int(round(x - offset_l))
    base.alpha_composite(img, (asset_x, int(round(y - offset_t))))
    return max_line_w, max(0, total_h)


def _fit_png_inline_for_box(
    draw,
    Image,
    ImageFont,
    text,
    font_name,
    requested_size,
    minimum_size,
    box_width,
    box_height,
    icon_folder,
    icon_mappings,
    icon_height,
    icon_size_overrides=None,
    line_spacing=2,
    bold=False,
    italic=False,
):
    requested_size = max(6, _safe_int(requested_size, 24))
    minimum_size = max(4, min(requested_size, _safe_int(minimum_size, 6)))
    base_icon_height = max(1, _safe_int(icon_height, requested_size))
    best = None
    for size in range(requested_size, minimum_size - 1, -1):
        scaled_icon_height = max(1, int(round(base_icon_height * float(size) / max(1.0, float(requested_size)))))
        font = _load_font(ImageFont, font_name, size, bold=bold, italic=italic)
        measured_w, measured_h = _wrapped_inline_size(
            draw,
            Image,
            text,
            font,
            box_width,
            icon_folder,
            icon_mappings,
            scaled_icon_height,
            icon_size_overrides,
            line_spacing=line_spacing,
        )
        best = {
            "font": font,
            "size": size,
            "icon_height": scaled_icon_height,
            "width": measured_w,
            "height": measured_h,
            "fits": measured_h <= float(box_height) + 0.5 and measured_w <= float(box_width) + 0.5,
        }
        if best["fits"]:
            return best
    return best










#========================Added By me ======================================

def _read_excel_range(ws, range_str):
    """Read text from an Excel range like 'B6:B6' or 'A2'."""
    if not range_str:
        return ""
    try:
        min_c, min_r, max_c, max_r = range_boundaries(str(range_str).strip())
    except Exception:
        return ""
    texts = []
    for r in range(min_r, max_r + 1):
        row_texts = []
        for c in range(min_c, max_c + 1):
            val = ws.cell(row=r, column=c).value
            if val is not None:
                row_texts.append(str(val).strip())
        if row_texts:
            texts.append(" ".join(row_texts))
    return "\n".join(texts)


_PAYTABLE_NUMBER_WORDS = {
    "10": "ten", "9": "nine", "8": "eight", "7": "seven",
    "6": "six", "5": "five", "4": "four", "3": "three", "2": "two",
    "ten": "10", "nine": "9", "eight": "8", "seven": "7",
    "six": "6", "five": "5", "four": "4", "three": "3", "two": "2",
}


def _paytable_norm(value):
    value = re.sub(r"[^A-Za-z0-9]+", "", str(value or "").strip("<> ")).casefold()
    return _PAYTABLE_NUMBER_WORDS.get(value, value)


def _paytable_asset_candidates(label):
    label = str(label or "").strip("<> ")
    normalized = re.sub(r"\s+", "_", label)
    compact = re.sub(r"[^A-Za-z0-9]+", "", label)
    candidates = [label, normalized, compact, label.upper(), label.lower()]
    low_map = {
        "ace": ["ACE", "Ace", "A", "ace"],
        "king": ["KING", "King", "K", "king"],
        "queen": ["QUEEN", "Queen", "Q", "queen"],
        "jack": ["JACK", "Jack", "J", "jack"],
        "ten": ["10", "TEN", "Ten", "ten"],
    }
    candidates.extend(low_map.get(_paytable_norm(label), []))
    seen = set()
    out = []
    for item in candidates:
        item = str(item or "").strip()
        if not item:
            continue
        for candidate in (item, item + ".png", item + ".jpg", item + ".jpeg"):
            key = candidate.casefold()
            if key not in seen:
                out.append(candidate)
                seen.add(key)
    return out


def _paytable_slot(slots, *names, slot_prefix=""):
    lower_map = {str(key).casefold(): (key, value) for key, value in (slots or {}).items()}
    lookup_names = []
    for name in names:
        if name is None:
            continue
        value = str(name).strip()
        if value:
            lookup_names.append(value)
    prefix = str(slot_prefix or "").strip().rstrip(".")
    if prefix:
        lookup_names.extend([f"{prefix}.{name}" for name in list(lookup_names) if not str(name).startswith(prefix + ".")])
    for name in lookup_names:
        found = lower_map.get(str(name).casefold())
        if found:
            return found[1]
    return None


def _paytable_slot_name_set(slots):
    return {str(name).casefold() for name in (slots or {}).keys()}


def _paytable_card_aliases(card, index, card_type, top_count=0):
    key = card.get("slot_key") or _paytable_norm(card.get("label"))
    global_index = int(index) if card_type == "top" else int(top_count) + int(index)
    aliases = {
        str(key).casefold(),
        _paytable_norm(card.get("label")),
        f"pic{global_index}".casefold(),
        f"symbol.{global_index}".casefold(),
        f"symbol{global_index}".casefold(),
        f"{card_type}.{index}".casefold(),
    }
    if card_type != "top":
        aliases.update({
            f"low.{index}".casefold(),
            f"lower.{index}".casefold(),
            f"bottom.{index}".casefold(),
        })
    return {alias for alias in aliases if alias}


def _paytable_find_card_box(slots, card, index, card_type, top_count=0, slot_prefix=""):
    aliases = _paytable_card_aliases(card, index, card_type, top_count=top_count)
    return _paytable_slot(slots, *aliases, slot_prefix=slot_prefix)


def _paytable_find_icon_box(slots, card, index, card_type, top_count=0, slot_prefix=""):
    aliases = _paytable_card_aliases(card, index, card_type, top_count=top_count)
    names = []
    for alias in aliases:
        names.extend([f"{alias}.icon", f"{alias}.symbol_icon", f"{alias}.symbolicon"])
    return _paytable_slot(slots, *names, slot_prefix=slot_prefix)


def _paytable_card_part_box(card_box, part, is_top=True):
    if not card_box:
        return None
    x, y, w, h = card_box["x"], card_box["y"], card_box["w"], card_box["h"]
    if part == "icon":
        if is_top:
            return {"x": x + w * 0.07, "y": y + h * 0.04, "w": w * 0.86, "h": h * 0.50}
        return {"x": x + w * 0.06, "y": y + h * 0.04, "w": w * 0.88, "h": h * 0.46}
    if is_top:
        return {"x": x + w * 0.08, "y": y + h * 0.57, "w": w * 0.84, "h": h * 0.35}
    return {"x": x + w * 0.08, "y": y + h * 0.54, "w": w * 0.84, "h": h * 0.38}


def _paytable_rgba(rgb, opacity=100):
    r, g, b = _rgb(rgb, (0, 0, 0))
    return (r, g, b, max(0, min(255, int(round(255 * max(0, min(100, _safe_int(opacity, 100))) / 100.0)))))



def _present_setting(mapping, *names, fallback=None):
    """Return the first non-empty setting value from multiple UI/legacy keys."""
    if not isinstance(mapping, dict):
        return fallback
    for name in names:
        if name in mapping:
            value = mapping.get(name)
            if value is None:
                continue
            if isinstance(value, str) and not value.strip():
                continue
            return value
    return fallback



def _merge_template_style_settings(template):
    """Collect optional paytable style keys saved in mapper/template JSON.

    Some mapper exports/session JSONs store text controls at top level or under
    settings/styles/paytable_settings.  Merge all of those into a flat dict so
    PNG paytable can read count_size/value_size/wild_text_size/etc. too.
    """
    merged = {}
    if not isinstance(template, dict):
        return merged
    style_key_names = {
        "count_size", "count_rgb", "count_font", "count_font_request",
        "value_size", "value_rgb", "value_font", "value_font_request",
        "wild_text_size", "wild_text_rgb", "wild_title_size", "wild_title_rgb",
        "notes_text_size", "notes_text_rgb", "notes_last_text_size", "notes_last_text_rgb",
        "bottom_notes_size", "bottom_notes_rgb", "bottom_notes_last_size", "bottom_notes_last_rgb",
        "inline_icon_height", "inline_icon_gap", "inline_line_height",
    }
    def absorb(obj):
        if not isinstance(obj, dict):
            return
        for key, value in obj.items():
            key_s = str(key)
            if key_s in style_key_names or key_s.startswith(("dynamic_", "paytable_", "bottom_notes", "wild_icon", "count_", "value_")):
                if value not in (None, ""):
                    merged[key_s] = value

    # 1. Absorb from top level
    absorb(template)
    
    # 2. Absorb from standard containers
    for container_key in (
        "settings", "style_settings", "styles", "paytable_settings", "paytable_styles",
        "mapper_settings", "text_settings", "ui_settings", "png_settings",
    ):
        obj = template.get(container_key)
        if isinstance(obj, dict):
            absorb(obj)
            for nested_key in ("paytable", "text", "payout", "notes", "flow"):
                absorb(obj.get(nested_key) if isinstance(obj.get(nested_key), dict) else None)
                
    # 3. NEW: Absorb directly from slots and flow_regions so user inputs apply!
    for section in ("slots", "flow_regions"):
        section_data = template.get(section)
        if isinstance(section_data, dict):
            for _slot_name, slot_data in section_data.items():
                absorb(slot_data)
        elif isinstance(section_data, list):
            for slot_data in section_data:
                absorb(slot_data)
                
    return merged


def _with_font_style(font_name, style_name):
    font_name = str(font_name or "").strip()
    style_name = str(style_name or "").strip()
    if not font_name:
        return ""
    if not style_name or style_name.casefold() in {"regular", "normal"}:
        return font_name
    if style_name.casefold() in font_name.casefold():
        return font_name
    return f"{font_name} {style_name}"

def _normalize_png_paytable_settings(dynamic_settings, h_font, h_size, h_rgb, b_font, b_size, b_rgb):
    """Normalize PSD-builder Paytable UI keys for the PNG renderer."""
    settings = dict(dynamic_settings or {})
    settings["heading_font"] = _present_setting(settings, "heading_font", "heading_font_request", fallback=h_font)
    settings["body_font"] = _present_setting(settings, "body_font", "body_font_request", fallback=b_font)
    if not settings.get("count_font_request") and settings.get("dynamic_count_font"):
        settings["count_font_request"] = _with_font_style(settings.get("dynamic_count_font"), settings.get("dynamic_count_font_style"))
    if not settings.get("value_font_request") and settings.get("dynamic_value_font"):
        settings["value_font_request"] = _with_font_style(settings.get("dynamic_value_font"), settings.get("dynamic_value_font_style"))
    if not settings.get("count_font_request") and settings.get("count_font_weight"):
        settings["count_font_request"] = _with_font_style(
            settings.get("dynamic_count_font") or settings.get("count_font") or settings.get("body_font") or b_font,
            settings.get("count_font_weight"),
        )
    if not settings.get("value_font_request") and settings.get("value_font_weight"):
        settings["value_font_request"] = _with_font_style(
            settings.get("dynamic_value_font") or settings.get("value_font") or settings.get("body_font") or b_font,
            settings.get("value_font_weight"),
        )
    settings["title_size"] = _safe_int(_present_setting(settings, "title_size", "paytable_title_size", "dynamic_title_size", fallback=h_size), h_size)
    settings["title_rgb"] = _rgb(_present_setting(settings, "title_rgb", "heading_rgb", "paytable_title_rgb", fallback=h_rgb), _rgb(h_rgb, (255, 80, 80)))
    settings["heading_rgb"] = _rgb(_present_setting(settings, "heading_rgb", fallback=settings.get("title_rgb")), _rgb(h_rgb, (255, 80, 80)))
    settings["body_rgb"] = _rgb(_present_setting(settings, "body_rgb", fallback=b_rgb), _rgb(b_rgb, (255, 255, 255)))

    settings["count_font"] = _present_setting(settings, "count_font", "count_font_request", "paytable_count_font", "paytable_count_font_request", "dynamic_count_font", "dynamic_count_font_request", fallback=settings.get("body_font") or b_font)
    settings["value_font"] = _present_setting(settings, "value_font", "value_font_request", "paytable_value_font", "paytable_value_font_request", "dynamic_value_font", "dynamic_value_font_request", fallback=settings.get("body_font") or b_font)
    settings["count_size"] = _safe_int(_present_setting(settings, "count_size", "paytable_count_size", "dynamic_count_size", fallback=b_size), b_size)
    settings["value_size"] = _safe_int(_present_setting(settings, "value_size", "paytable_value_size", "dynamic_value_size", fallback=b_size), b_size)
    settings["count_rgb"] = _rgb(_present_setting(settings, "count_rgb", "paytable_count_rgb", "dynamic_count_rgb", "dynamic_count_hex", fallback=(255, 175, 55)), (255, 175, 55))
    settings["value_rgb"] = _rgb(_present_setting(settings, "value_rgb", "paytable_value_rgb", "dynamic_value_rgb", "dynamic_value_hex", fallback=settings.get("body_rgb")), settings.get("body_rgb", (255, 255, 255)))

    settings["wild_title_size"] = _safe_int(_present_setting(settings, "wild_title_size", "paytable_wild_title_size", "dynamic_wild_title_size", fallback=h_size), h_size)
    settings["wild_title_rgb"] = _rgb(_present_setting(settings, "wild_title_rgb", "paytable_wild_title_rgb", "dynamic_wild_title_rgb", fallback=settings.get("heading_rgb")), settings.get("heading_rgb", (255, 80, 80)))
    settings["wild_text_size"] = _safe_int(_present_setting(settings, "wild_text_size", "paytable_wild_text_size", "dynamic_wild_text_size", fallback=b_size), b_size)
    settings["wild_text_rgb"] = _rgb(_present_setting(settings, "wild_text_rgb", "paytable_wild_text_rgb", "dynamic_wild_text_rgb", fallback=settings.get("body_rgb")), settings.get("body_rgb", (255, 255, 255)))
    settings["notes_text_size"] = _safe_int(_present_setting(
        settings,
        "notes_text_size", "paytable_notes_size", "notes_size", "dynamic_notes_size",
        "bottom_notes_size", "bottom_notes_text_size", "paytable_bottom_notes_size",
        fallback=settings.get("wild_text_size", b_size),
    ), settings.get("wild_text_size", b_size))
    settings["notes_text_rgb"] = _rgb(_present_setting(
        settings,
        "notes_text_rgb", "paytable_notes_rgb", "notes_rgb", "dynamic_notes_rgb",
        "bottom_notes_rgb", "bottom_notes_text_rgb", "paytable_bottom_notes_rgb",
        fallback=settings.get("wild_text_rgb"),
    ), settings.get("wild_text_rgb", (255, 255, 255)))
    settings["notes_last_text_size"] = _safe_int(_present_setting(
        settings,
        "notes_last_text_size", "bottom_notes_last_size", "bottom_notes_last_text_size",
        "paytable_bottom_notes_last_size", fallback=settings.get("notes_text_size"),
    ), settings.get("notes_text_size", b_size))
    settings["notes_last_text_rgb"] = _rgb(_present_setting(
        settings,
        "notes_last_text_rgb", "bottom_notes_last_rgb", "bottom_notes_last_text_rgb",
        "paytable_bottom_notes_last_rgb", fallback=settings.get("notes_text_rgb"),
    ), settings.get("notes_text_rgb", (255, 255, 255)))

    settings["wild_icon_height"] = _present_setting(settings, "wild_icon_height", "paytable_wild_icon_height", "dynamic_wild_icon_height", fallback=None)
    settings["top_symbol_icon_height"] = _present_setting(settings, "top_symbol_icon_height", "paytable_top_symbol_icon_height", "dynamic_top_icon_height", fallback=None)
    settings["lower_symbol_icon_height"] = _present_setting(settings, "lower_symbol_icon_height", "paytable_lower_symbol_icon_height", "dynamic_lower_icon_height", fallback=None)
    return settings


def _has_present_setting(mapping, *names):
    sentinel = object()
    return _present_setting(mapping, *names, fallback=sentinel) is not sentinel


def _json_present(mapping, *names):
    sentinel = object()
    value = _present_setting(mapping, *names, fallback=sentinel)
    return None if value is sentinel else value


def _slot_style_key_variants(slot_name, region_id=""):
    """Return setting-key prefixes for a mapped flow slot.

    Example: wild.icon2.text => wild_icon2_text, wildicon2text.
    This lets PNG read both mapper JSON keys and future UI/session keys such as
    bottom_notes_last_size, bottom_notes_last_rgb, wild_icon2_text_size, etc.
    """
    raw_items = []
    for item in (slot_name, region_id):
        item = str(item or "").strip()
        if item:
            raw_items.append(item)
    variants = []
    for raw in raw_items:
        dotted = raw.casefold().replace(" ", "_").replace("-", "_")
        underscored = re.sub(r"[^a-z0-9]+", "_", dotted).strip("_")
        compact = re.sub(r"[^a-z0-9]+", "", dotted)
        for item in (dotted, underscored, compact):
            if item and item not in variants:
                variants.append(item)
    return variants


def _pick_mapped_flow_style(region, settings, category_size, category_rgb, category_font, prefer_category_style=False):
    """Pick the final text style for one mapped paytable flow slot."""
    region = dict(region or {})
    variants = _slot_style_key_variants(region.get("slot", ""), region.get("id", ""))
    size_keys = []
    rgb_keys = []
    font_keys = []
    min_keys = []
    icon_keys = []
    gap_keys = []
    for key in variants:
        size_keys.extend([f"{key}_size", f"{key}_font_size", f"{key}_text_size"])
        rgb_keys.extend([f"{key}_rgb", f"{key}_color", f"{key}_text_rgb", f"{key}_text_color"])
        font_keys.extend([f"{key}_font", f"{key}_font_request", f"{key}_font_name"])
        min_keys.extend([f"{key}_minimum_font_size", f"{key}_min_font_size", f"{key}_emergency_minimum_font_size"])
        icon_keys.extend([f"{key}_icon_height", f"{key}_inline_icon_height"])
        gap_keys.extend([f"{key}_gap", f"{key}_line_height", f"{key}_line_spacing"])

    slot_size = _json_present(settings, *size_keys)
    slot_rgb = _json_present(settings, *rgb_keys)
    slot_font = _json_present(settings, *font_keys)
    slot_min = _json_present(settings, *min_keys)
    slot_icon = _json_present(settings, *icon_keys)
    slot_gap = _json_present(settings, *gap_keys)

    json_size = _json_present(region, "font_size", "text_size", "size")
    json_rgb = _json_present(region, "color", "text_rgb", "rgb", "text_color")
    json_font = _json_present(region, "font", "font_name", "font_request", "font_family")
    json_min = _json_present(region, "minimum_font_size", "min_font_size", "emergency_minimum_font_size")
    json_icon = _json_present(region, "icon_height", "inline_icon_height")
    json_gap = _json_present(region, "gap", "line_height", "line_spacing", "block_gap")

    # FIX: Priority is now 1) Slot-specific UI setting, 2) JSON file explicitly, 3) Generic UI fallback
    if slot_size is not None:
        requested_size = slot_size
    elif json_size is not None:
        requested_size = json_size
    elif prefer_category_style and category_size is not None:
        requested_size = category_size
    else:
        requested_size = category_size

    if slot_rgb is not None:
        requested_rgb = slot_rgb
    elif json_rgb is not None:
        requested_rgb = json_rgb
    elif prefer_category_style and category_rgb is not None:
        requested_rgb = category_rgb
    else:
        requested_rgb = category_rgb

    if slot_font is not None:
        requested_font = slot_font
    elif json_font is not None:
        requested_font = json_font
    elif prefer_category_style and category_font:
        requested_font = category_font
    else:
        requested_font = category_font
        
    requested_min = slot_min if slot_min is not None else json_min
    requested_icon = slot_icon if slot_icon is not None else json_icon
    requested_gap = slot_gap if slot_gap is not None else json_gap

    final_size = max(4, _safe_int(requested_size, 30))
    region["font_size"] = final_size
    if requested_min is not None:
        region["minimum_font_size"] = min(final_size, max(4, _safe_int(requested_min, final_size)))
        region["emergency_minimum_font_size"] = region["minimum_font_size"]
    else:
        # Mapper-exported fixed text normally has minimum == font_size.
        existing_min = _safe_int(region.get("minimum_font_size", region.get("emergency_minimum_font_size", final_size)), final_size)
        region["minimum_font_size"] = min(final_size, max(4, existing_min))
        region["emergency_minimum_font_size"] = region["minimum_font_size"]
    region["color"] = requested_rgb
    if requested_font:
        region["font"] = requested_font
        region["font_name"] = requested_font
    if requested_icon is not None:
        region["icon_height"] = max(1, _safe_int(requested_icon, max(final_size, 36)))
    elif "icon_height" not in region or region.get("icon_height") in (None, ""):
        region["icon_height"] = max(final_size, _safe_int(settings.get("inline_icon_height"), 36))
    if requested_gap is not None:
        region["gap"] = max(0, _safe_int(requested_gap, 2))
    return region


def _png_flow_region_with_ui_defaults(region, settings):
    """Apply Paytable flow styles without wiping JSON mapper values."""
    region = dict(region or {})
    key = f"{region.get('slot', '')} {region.get('id', '')}".casefold()

    is_last_notes = any(token in key for token in ("bottom_notes_last", "bottomnoteslast", "notes_last", "last_notes"))
    is_notes = is_last_notes or any(token in key for token in ("bottom_notes", "bottomnotes", "note", "notes", "last"))
    is_title = "title" in key and not is_notes

    if is_title:
        category_size = settings.get("wild_title_size", settings.get("title_size", settings.get("wild_text_size", 30)))
        category_rgb = settings.get("wild_title_rgb", settings.get("heading_rgb", settings.get("wild_text_rgb", (255, 255, 255))))
        category_font = settings.get("heading_font") or settings.get("body_font")
        prefer_category_style = _has_present_setting(settings, "wild_title_size", "dynamic_wild_title_size", "paytable_wild_title_size")
    elif is_notes:
        if is_last_notes:
            category_size = settings.get("notes_last_text_size", settings.get("notes_text_size", settings.get("wild_text_size", settings.get("body_size", 30))))
            category_rgb = settings.get("notes_last_text_rgb", settings.get("notes_text_rgb", settings.get("wild_text_rgb", settings.get("body_rgb", (255, 255, 255)))))
            prefer_category_style = _has_present_setting(settings, "notes_last_text_size", "bottom_notes_last_size", "bottom_notes_last_text_size", "paytable_bottom_notes_last_size")
        else:
            category_size = settings.get("notes_text_size", settings.get("wild_text_size", settings.get("body_size", 30)))
            category_rgb = settings.get("notes_text_rgb", settings.get("wild_text_rgb", settings.get("body_rgb", (255, 255, 255))))
            prefer_category_style = _has_present_setting(settings, "notes_text_size", "dynamic_notes_size", "paytable_notes_size", "bottom_notes_size", "bottom_notes_text_size")
        category_font = settings.get("body_font")
    else:
        category_size = settings.get("wild_text_size", settings.get("body_size", 30))
        category_rgb = settings.get("wild_text_rgb", settings.get("body_rgb", (255, 255, 255)))
        category_font = settings.get("body_font")
        prefer_category_style = _has_present_setting(settings, "wild_text_size", "dynamic_wild_text_size", "paytable_wild_text_size")

    region = _pick_mapped_flow_style(region, settings, category_size, category_rgb, category_font, prefer_category_style=prefer_category_style)

    # Generic UI line/icon controls only fill missing mapper fields; they do not
    # overwrite per-region mapper values.
    if ("icon_height" not in region or region.get("icon_height") in (None, "")) and settings.get("inline_icon_height") not in (None, ""):
        region["icon_height"] = settings.get("inline_icon_height")
    if ("gap" not in region or region.get("gap") in (None, "")) and settings.get("inline_line_height") not in (None, ""):
        region["gap"] = settings.get("inline_line_height")
    if settings.get("inline_icon_gap") not in (None, "") and "icon_gap" not in region:
        region["icon_gap"] = settings.get("inline_icon_gap")
    return region

def _draw_alpha_rect(base, draw, Image, box, rgb, opacity=100, outline=None, stroke_width=0):
    if not box:
        return
    x, y, w, h = box["x"], box["y"], box["w"], box["h"]
    opacity = max(0, min(100, _safe_int(opacity, 100)))
    if opacity > 0:
        overlay = Image.new("RGBA", (max(1, int(round(w))), max(1, int(round(h)))), _paytable_rgba(rgb, opacity))
        base.alpha_composite(overlay, (int(round(x)), int(round(y))))
    stroke_width = max(0, _safe_int(stroke_width, 0))
    if outline and stroke_width:
        draw.rectangle([x, y, x + w, y + h], outline=_rgb(outline, (255, 255, 255)), width=max(1, int(round(stroke_width))))


def _fit_icon_to_box(Image, icon, box):
    if not icon or not box:
        return icon
    max_w = max(1, int(round(float(box["w"]))))
    max_h = max(1, int(round(float(box["h"]))))
    if icon.width <= max_w and icon.height <= max_h:
        return icon
    scale = min(max_w / max(1, icon.width), max_h / max(1, icon.height))
    return icon.resize((max(1, int(round(icon.width * scale))), max(1, int(round(icon.height * scale)))))


def _place_paytable_icon(base, draw, Image, ImageFont, label, box, icon_folder, icon_mappings, icon_size_overrides, max_height=None, fallback_font="", fallback_rgb=(255, 255, 255)):
    if not box:
        return False
    candidates = _paytable_asset_candidates(label)
    combined_map = dict(icon_mappings or {})
    path = resolve_icon_path(str(label or "").strip("<> "), icon_folder, combined_map, candidates)
    icon = None
    if path and os.path.isfile(path):
        try:
            icon = Image.open(path).convert("RGBA")
        except Exception:
            icon = None
    if icon:
        target_h = _safe_int(max_height, 0) or int(float(box["h"]))
        if target_h > 0 and icon.height > 0:
            scale = min(float(target_h) / max(1, icon.height), float(box["h"]) / max(1, icon.height))
            icon = icon.resize((max(1, int(round(icon.width * scale))), max(1, int(round(icon.height * scale)))))
        icon = _fit_icon_to_box(Image, icon, box)
        base.alpha_composite(icon, (int(round(float(box["x"]) + (float(box["w"]) - icon.width) / 2.0)), int(round(float(box["y"]) + (float(box["h"]) - icon.height) / 2.0))))
        return True

    # Match PSD fallback behaviour for low symbols.
    fallback = str(label or "").strip("<> ")
    key = _paytable_norm(fallback)
    fallback = {"queen": "Q", "king": "K", "jack": "J", "ace": "A", "ten": "10"}.get(key, fallback)
    font_size = max(8, int(min(float(box["w"]), float(box["h"])) * 0.45))
    font = _load_font(ImageFont, fallback_font, font_size, bold=True)
    _draw_inline(base, draw, Image, fallback, float(box["x"]), float(box["y"]) + float(box["h"]) * 0.18, font, _rgb(fallback_rgb), float(box["w"]), icon_folder, icon_mappings, font_size, icon_size_overrides, align="center", line_spacing=2)
    return False


def _draw_fitted_inline_in_box(base, draw, Image, ImageFont, text, box, font_name, font_size, rgb, icon_folder, icon_mappings, icon_height, icon_size_overrides, align="center", vertical_align="center", min_size=None, line_spacing=2, bold=False, italic=False):
    text = str(text or "").strip()
    if not text or not box:
        return 0
    x, y, w, h = float(box["x"]), float(box["y"]), float(box["w"]), float(box["h"])
    fit = _fit_png_inline_for_box(
        draw, Image, ImageFont, text, font_name, font_size,
        min_size if min_size is not None else max(6, int(float(font_size) * 0.55)),
        max(1, int(round(w))), max(1, int(round(h))), icon_folder,
        icon_mappings, icon_height, icon_size_overrides, line_spacing=line_spacing,
        bold=bold, italic=italic,
    )
    if not fit:
        return 0
    content_h = float(fit.get("height", 0))
    valign = str(vertical_align or "center").casefold()
    if valign == "top":
        text_y = y
    elif valign == "bottom":
        text_y = y + max(0, h - content_h)
    else:
        text_y = y + max(0, (h - content_h) / 2.0)
    _draw_inline(base, draw, Image, text, x, text_y, fit["font"], _rgb(rgb), w, icon_folder, icon_mappings, fit["icon_height"], icon_size_overrides, align=align, line_spacing=line_spacing)
    return content_h


def _draw_paytable_payout_lines(base, draw, Image, ImageFont, lines, box, font_name, font_size, rgb, icon_folder, icon_mappings, icon_size_overrides, bold=False, min_size=None):
    if not box or not lines:
        return False
    clean_lines = [str(line or "").strip() for line in lines if str(line or "").strip()]
    if not clean_lines:
        return False
    requested_size = max(6, _safe_int(font_size, 24))
    # Dedicated pay/value JSON slots should obey the Paytable UI size.  Do not
    # silently shrink to a tiny fallback unless a caller explicitly asks for it.
    requested_min = requested_size if min_size is None else max(4, _safe_int(min_size, requested_size))
    row_h = float(box["h"]) / max(1, len(clean_lines))
    for idx, line in enumerate(clean_lines):
        row_box = {
            "x": float(box["x"]),
            "y": float(box["y"]) + row_h * idx,
            "w": float(box["w"]),
            "h": row_h,
        }
        _draw_fitted_inline_in_box(
            base, draw, Image, ImageFont, line, row_box, font_name, requested_size, rgb,
            icon_folder, icon_mappings, max(1, int(requested_size)), icon_size_overrides,
            align="center", vertical_align="center", line_spacing=2, bold=bold,
            min_size=requested_min,
        )
    return True


def _render_png_payouts_in_json_slots(base, draw, Image, ImageFont, card, slots, settings, aliases, icon_folder, icon_mappings, icon_size_overrides, slot_prefix=""):
    payouts = list(card.get("payouts") or [])
    if not payouts:
        return False
    aliases = {str(a).casefold() for a in aliases if str(a).strip()}
    # Support both "ten" and "10" slot naming.
    expanded = set(aliases)
    for alias in list(aliases):
        expanded.add(_PAYTABLE_NUMBER_WORDS.get(alias, alias))
    aliases = expanded

    def lookup_suffixes(*suffixes):
        names = []
        for alias in aliases:
            for suffix in suffixes:
                names.append(f"{alias}.{suffix}")
        return _paytable_slot(slots, *names, slot_prefix=slot_prefix)

    bulk_pay = lookup_suffixes("pay", "pays", "PAY", "PAYS")
    bulk_value = lookup_suffixes("value", "values", "VALUE", "VALUES")
    numbered_pay = {}
    numbered_value = {}
    for row_idx in range(1, len(payouts) + 1):
        numbered_pay[row_idx] = lookup_suffixes(f"pay{row_idx}", f"pays{row_idx}")
        numbered_value[row_idx] = lookup_suffixes(f"value{row_idx}", f"values{row_idx}")
    numbered_pay = {k: v for k, v in numbered_pay.items() if v}
    numbered_value = {k: v for k, v in numbered_value.items() if v}

    count_size = _safe_int(settings.get("count_size"), 38)
    value_size = _safe_int(settings.get("value_size"), 42)
    count_rgb = settings.get("count_rgb", (255, 175, 55))
    value_rgb = settings.get("value_rgb", (255, 255, 255))
    count_font = settings.get("count_font") or settings.get("body_font") or ""
    value_font = settings.get("value_font") or settings.get("body_font") or ""
    used = False

    def count_text(payout):
        return str(payout.get("count", "")).strip()

    def value_text(payout):
        return str(payout.get("value", "")).strip()

    if numbered_pay and all(i in numbered_pay for i in range(1, len(payouts) + 1)):
        for i, payout in enumerate(payouts, start=1):
            _draw_paytable_payout_lines(base, draw, Image, ImageFont, [count_text(payout)], numbered_pay[i], count_font, count_size, count_rgb, icon_folder, icon_mappings, icon_size_overrides)
            used = True
    elif bulk_pay:
        _draw_paytable_payout_lines(base, draw, Image, ImageFont, [count_text(p) for p in payouts], bulk_pay, count_font, count_size, count_rgb, icon_folder, icon_mappings, icon_size_overrides)
        used = True
    elif numbered_pay:
        last_key = sorted(numbered_pay)[-1]
        grouped = {}
        for i, payout in enumerate(payouts, start=1):
            grouped.setdefault(i if i in numbered_pay else last_key, []).append(count_text(payout))
        for i, lines in grouped.items():
            _draw_paytable_payout_lines(base, draw, Image, ImageFont, lines, numbered_pay[i], count_font, count_size, count_rgb, icon_folder, icon_mappings, icon_size_overrides)
            used = True

    if numbered_value and all(i in numbered_value for i in range(1, len(payouts) + 1)):
        for i, payout in enumerate(payouts, start=1):
            _draw_paytable_payout_lines(base, draw, Image, ImageFont, [value_text(payout)], numbered_value[i], value_font, value_size, value_rgb, icon_folder, icon_mappings, icon_size_overrides)
            used = True
    elif bulk_value:
        _draw_paytable_payout_lines(base, draw, Image, ImageFont, [value_text(p) for p in payouts], bulk_value, value_font, value_size, value_rgb, icon_folder, icon_mappings, icon_size_overrides)
        used = True
    elif numbered_value:
        last_key = sorted(numbered_value)[-1]
        grouped = {}
        for i, payout in enumerate(payouts, start=1):
            grouped.setdefault(i if i in numbered_value else last_key, []).append(value_text(payout))
        for i, lines in grouped.items():
            _draw_paytable_payout_lines(base, draw, Image, ImageFont, lines, numbered_value[i], value_font, value_size, value_rgb, icon_folder, icon_mappings, icon_size_overrides)
            used = True
    return used


def _render_png_flow_region(base, draw, Image, ImageFont, region, slots, scale, icon_folder, icon_mappings, icon_size_overrides, b_font, b_size, b_rgb, report, slot_prefix=""):
    try:
        return _render_png_flow_region_impl(base, draw, Image, ImageFont, region, slots, scale, icon_folder, icon_mappings, icon_size_overrides, b_font, b_size, b_rgb, report, slot_prefix)
    except Exception as _exc:
        _warn(report, f"PNG paytable flow {region.get('id') or region.get('slot')} raised exception: {_exc}")
        return False

def _render_png_flow_region_impl(base, draw, Image, ImageFont, region, slots, scale, icon_folder, icon_mappings, icon_size_overrides, b_font, b_size, b_rgb, report, slot_prefix=""):
    box = _paytable_slot(slots, region.get("slot"), region.get("id"), slot_prefix=slot_prefix)
    if not box:
        _warn(report, f"PNG paytable flow skipped: missing slot {region.get('slot') or region.get('id')}")
        return False
    
    # style layer behind flow box
    fill_enabled = str(region.get("fill_enabled", "")).casefold() in {"1", "true", "yes", "on", "fill"} or bool(region.get("fill_enabled") is True)
    stroke_enabled = str(region.get("stroke_enabled", "")).casefold() in {"1", "true", "yes", "on", "stroke"} or bool(region.get("stroke_enabled") is True)
    if fill_enabled:
        _draw_alpha_rect(base, draw, Image, box, region.get("background_color", "#000000"), region.get("opacity", 100))
    if stroke_enabled and _safe_int(region.get("stroke_width"), 0) > 0:
        draw.rectangle([box["x"], box["y"], box["x"] + box["w"], box["y"] + box["h"]], outline=_rgb(region.get("stroke_color"), (255, 255, 255)), width=max(1, int(round(_safe_int(region.get("stroke_width"), 1)))))

    padding = region.get("padding") or [0, 0, 0, 0]
    if isinstance(padding, (int, float)):
        padding = [padding, padding, padding, padding]
    padding = list(padding) + [0, 0, 0, 0]
    
    # Match PSD paytable renderer: mapper text/padding values are absolute text settings,
    # not multiplied by the template coordinate scale.
    pad_t = max(0, float(padding[0]))
    pad_r = max(0, float(padding[1]))
    pad_b = max(0, float(padding[2]))
    pad_l = max(0, float(padding[3]))
    
    content_box = {
        "x": float(box["x"]) + pad_l,
        "y": float(box["y"]) + pad_t,
        "w": max(1.0, float(box["w"]) - pad_l - pad_r),
        "h": max(1.0, float(box["h"]) - pad_t - pad_b),
    }
    
    raw_blocks = region.get("blocks")
    if not raw_blocks:
        _warn(report, f"PNG paytable flow {region.get('id') or region.get('slot')}: no blocks found in region (key 'blocks' is {type(raw_blocks).__name__}: {raw_blocks!r}). Source cells may be empty or the worksheet may not contain data.")
        return False
    blocks = [b for b in (raw_blocks if isinstance(raw_blocks, (list, tuple)) else []) if isinstance(b, dict) and str(b.get("text", "")).strip()]
    if not blocks:
        _warn(report, f"PNG paytable flow {region.get('id') or region.get('slot')}: all {len(raw_blocks)} block(s) have empty text. Check cell content.")
        return False
        
    requested_size = max(6, int(_safe_int(region.get("font_size", b_size), b_size)))
    min_size = max(4, int(_safe_int(region.get("minimum_font_size", region.get("emergency_minimum_font_size", 6)), 6)))
    min_size = min(min_size, requested_size)
    icon_height = max(1, int(_safe_int(region.get("icon_height", b_size), b_size)))
    
    # FIX: Differentiate between paragraph/block spacing and inline text wrapping
    paragraph_gap = max(0, int(_safe_int(region.get("gap", region.get("block_gap", 2)), 2)))
    line_spacing_val = max(0, int(_safe_int(region.get("line_spacing", region.get("line_height", 2)), 2)))
    
    font_name = region.get("font") or region.get("font_name") or b_font
    style_text = str(region.get("font_style", region.get("style", "")) or "").casefold()
    bold = bool(region.get("bold")) or "bold" in style_text or "semibold" in style_text
    italic = bool(region.get("italic")) or "italic" in style_text or "oblique" in style_text
    color = _rgb(region.get("color"), _rgb(b_rgb, (255, 255, 255)))
    align = region.get("alignment") or "center"

    chosen = None
    for size in range(requested_size, min_size - 1, -1):
        font = _load_font(ImageFont, font_name, size, bold=bold, italic=italic)
        scaled_icon = max(1, int(round(icon_height * float(size) / max(1, requested_size))))
        total_h = 0
        block_plans = []
        for block in blocks:
            text = str(block.get("text", "")).strip()
            # Feed line_spacing_val instead of paragraph_gap here
            _mw, block_h = _wrapped_inline_size(draw, Image, text, font, content_box["w"], icon_folder, icon_mappings, scaled_icon, icon_size_overrides, line_spacing=line_spacing_val)
            block_plans.append((text, block_h))
            total_h += block_h
            
        total_h += paragraph_gap * max(0, len(block_plans) - 1)
        chosen = (font, size, scaled_icon, total_h, block_plans)
        if total_h <= content_box["h"] + 0.5:
            break
            
    if not chosen:
        return False
        
    font, used_size, used_icon_h, total_h, block_plans = chosen
    if total_h > content_box["h"] + 0.5:
        _warn(report, f"PNG paytable flow {region.get('id') or region.get('slot')} may clip; needs {round(total_h, 1)}px in {round(content_box['h'], 1)}px.")
        
    valign = str(region.get("vertical_align") or "top").casefold()
    if valign == "center":
        rel_y = max(0.0, (content_box["h"] - total_h) / 2.0)
    elif valign == "bottom":
        rel_y = max(0.0, content_box["h"] - total_h)
    else:
        rel_y = 0.0

# FIX: Render to a transparent clip buffer exactly the size of the content box
    # Fetch ImageDraw safely since it isn't passed as a parameter to this function
    _, ImageDraw, _ = _require_pillow()
    
    buffer = Image.new("RGBA", (int(math.ceil(content_box["w"])), int(math.ceil(content_box["h"]))), (0, 0, 0, 0))
    buffer_draw = ImageDraw.Draw(buffer)
    _psd_track_buffer(buffer, base, int(math.ceil(content_box["x"])), int(math.ceil(content_box["y"])))

    for text, block_h in block_plans:
        if rel_y >= content_box["h"]:
            break
        # Draw onto the buffer instead of base canvas, maintaining 0-indexed X and Y bounds
        _draw_inline(buffer, buffer_draw, Image, text, 0, rel_y, font, color, content_box["w"], icon_folder, icon_mappings, used_icon_h, icon_size_overrides, align=align, line_spacing=line_spacing_val)
        rel_y += block_h + paragraph_gap

    # Composite the hard-clipped buffer directly back onto the main page
    base.alpha_composite(buffer, (int(math.ceil(content_box["x"])), int(math.ceil(content_box["y"]))))
    return True


def _render_png_token_bindings(base, draw, Image, ImageFont, page_data, slots, settings, icon_folder, icon_mappings, icon_size_overrides, slot_prefix=""):
    used = False
    for index, binding in enumerate(page_data.get("token_bindings") or [], start=1):
        box = _paytable_slot(slots, binding.get("slot"), slot_prefix=slot_prefix)
        if not box:
            continue
        token = str(binding.get("token") or "").strip("<> ")
        max_height = _safe_int(binding.get("max_height"), 0) or int(float(box["h"]))
        _place_paytable_icon(base, draw, Image, ImageFont, token, box, icon_folder, icon_mappings, icon_size_overrides, max_height=max_height, fallback_font=settings.get("body_font", ""), fallback_rgb=settings.get("wild_text_rgb", (255, 255, 255)))
        used = True
    return used


def _paytable_wild_icon_boxes(slots, mapped_token_slots=None):
    mapped_token_slots = {str(s).casefold() for s in (mapped_token_slots or set())}
    matches = []
    for name, box in (slots or {}).items():
        key = str(name).casefold()
        is_icon = (
            "wild.icon" in key or "feature.icon" in key or "special.icon" in key or "feature.main_icon" in key
            or key in {"wild", "scatter", "feature", "special", "feature_icon", "wild_icon"}
        )
        if not is_icon or any(word in key for word in ("title", "text", "note", "exception", "inline")):
            continue
        if key in mapped_token_slots:
            continue
        matches.append((name, box))
    matches.sort(key=lambda pair: (float(pair[1]["y"]), float(pair[1]["x"])))
    seen = set()
    deduped = []
    for name, box in matches:
        sig = (round(float(box.get("x", 0))), round(float(box.get("y", 0))), round(float(box.get("w", 0))), round(float(box.get("h", 0))))
        if sig in seen:
            continue
        seen.add(sig)
        deduped.append((name, box))
    if not deduped:
        return []
    max_area = max(float(b.get("w", 0)) * float(b.get("h", 0)) for _, b in deduped)
    main = [box for _name, box in deduped if float(box.get("w", 0)) * float(box.get("h", 0)) >= max_area * 0.45]
    return main or [deduped[0][1]]


_BUILD_EXCEL = contextvars.ContextVar("png_build_excel", default="")   # workbook of the running build
_GAME_NAME_TOKEN_RE = re.compile(r"<\s*game[\s_-]*name\s*>", flags=re.I)
_GAME_NAME_FILES = ("GAME NAME", "Game Name", "GameName", "game_name", "gamename", "game name")


def game_name_heading(text, settings, icon_folder=None, icon_mappings=None):
    """Resolve <GAME NAME> in a heading: the game-name image when the icons
    folder has one (drawn inline like any icon), else the game name typed in
    the project (rendered as heading text with the heading layer style).
    Left as is when neither exists, so the UI can ask for the name."""
    text = str(text or "")
    if not _GAME_NAME_TOKEN_RE.search(text):
        return text
    settings = settings or {}
    folder = icon_folder if icon_folder is not None else settings.get("asset_folder") or settings.get("icon_folder")
    mappings = icon_mappings if icon_mappings is not None else settings.get("icon_mappings")
    path = None
    try:
        from .icon_mapping import resolve_icon_path

        path = resolve_icon_path("<GAME NAME>", folder or "", mappings or {}, _GAME_NAME_FILES)
    except Exception:
        path = None
    if path and os.path.isfile(path):
        token = "<" + os.path.splitext(os.path.basename(path))[0] + ">"
        return _GAME_NAME_TOKEN_RE.sub(lambda _m: token, text)
    name = str(settings.get("heading_game_name_text") or settings.get("game_name") or "").strip()
    if name:
        return _GAME_NAME_TOKEN_RE.sub(lambda _m: name, text)
    return text


def _prepare_png_heading_text(value, settings):
    text = game_name_heading(value, settings)
    if bool((settings or {}).get("heading_uppercase_enabled", False)):
        text = text.upper()
    return text


def _render_dynamic_json_page_png(
    base, draw, Image, ImageFont, ws, sheet_name, json_path,
    dynamic_settings, icon_folder, icon_mappings, icon_size_overrides,
    canvas_w, canvas_h, h_font, h_size, h_rgb, b_font, b_size, b_rgb,
    gap_px, line_spacing, report
):
    """Render a JSON-driven PNG page using the same Paytable parser as PSD builder."""
    try:
        with open(json_path, 'r', encoding='utf-8') as f:
            template = json.load(f)
    except Exception as e:
        _warn(report, f"Failed to load dynamic JSON {json_path}: {e}")
        return
    if _BUILD_EXCEL.get() and template.get("mappings"):
        # card images picked for another workbook give way to this sheet's own symbols
        try:
            from .ui_web.engine_api import drop_foreign_symbol_picks
            from .ui_web.ps_actions import _mapping_dict as _md

            _maps = {k: dict(v) for k, v in _md(template.get("mappings")).items()}
            if drop_foreign_symbol_picks(_maps, _BUILD_EXCEL.get()):
                template = dict(template, mappings=_maps)
        except Exception:
            pass
    # Layout learned from an artist PSD: fit it to THIS sheet (drop/clone cards).
    from .artist_design import fit_cards as _fit_cards
    if _fit_cards.is_artist_template(template):
        _fit_notes = []
        template = _fit_cards.prepare(template, ws, _fit_notes, target=(canvas_w, canvas_h))
        for _msg in _fit_notes:
            _warn(report, _msg)
    elif ws is not None:
        # Mapper design with fixed card boxes: one card per Excel card, top band
        # = cards before <ace>, bottom band = <ace> onward (card_grid).
        try:
            from .dynamic_pages.router import _is_mapper_design as _is_md
            from .dynamic_pages.paytable import card_grid as _card_grid

            _is_pt = str(template.get("page_type") or "").casefold() == "paytable" or str(sheet_name or "").casefold() == "paytable"
            if _is_pt and _is_md(template):
                _grid_notes = []
                template = _card_grid.adapt(template, ws, _grid_notes)
                for _msg in _grid_notes:
                    _note(report, _msg)
        except Exception as _exc:
            _warn(report, f"Card grid could not adapt the paytable to the sheet: {_exc}")

    # Auto-merge mapped JSON data (table_templates/flow_regions/token_bindings)
    # from mapped_table_jsons or sibling *_mapped.json into the loaded template.
    def _merge_mapped_into_template(_src, _label):
        _merged_keys = []
        for _key in ("table_templates", "flow_regions", "token_bindings", "mapper_meta", "flow_replaces_legacy_text"):
            if _key in _src and _key not in template:
                template[_key] = _src[_key]
                _merged_keys.append(_key)
        msg = f"Merged {', '.join(_merged_keys)} from {_label}" if _merged_keys else None
        if msg:
            _warn(report, msg)
            print(f"[PNG MERGE] {msg}")

    _sheet_overrides = dynamic_settings.pop("_json_sheet_overrides", None) or {}
    _did_merge = False
    print(f"[PNG MERGE] Checking mapped_records for sheet='{sheet_name}', json_path='{json_path}'")
    # Source 1: mapped_records from mapped_table_jsons (preferred — user-configured)
    for _idx, _mr in enumerate((dynamic_settings.pop("_mapped_records", None) or [])):
        if not isinstance(_mr, dict) or _mr.get("error"):
            print(f"[PNG MERGE]  record {_idx}: skipped (error or not dict)")
            continue
        if not template_matches_sheet(_mr, sheet_name, sheet_overrides=_sheet_overrides):
            print(f"[PNG MERGE]  record {_idx}: sheet mismatch (path={_mr.get('path')})")
            continue
        print(f"[PNG MERGE]  record {_idx}: matches sheet, attempting merge (path={_mr.get('path')})")
        if _merge_mapped_into_template(_mr.get("template") or {}, f"mapped JSON {os.path.basename(_mr.get('path', '?'))}"):
            _did_merge = True
    # Source 2: sibling *_mapped.json (fallback — only if no mapped_records matched)
    if not _did_merge:
        mapped_path = os.path.splitext(json_path)[0] + "_mapped.json"
        print(f"[PNG MERGE] No mapped_records matched, checking {mapped_path}")
        if os.path.isfile(mapped_path):
            try:
                with open(mapped_path, "r", encoding="utf-8") as _mf:
                    _mdata = json.load(_mf)
                _mr_check = {"path": mapped_path, "spec": {"source_sheet": ""}}
                if _mdata.get("table_templates"):
                    _first_key = next(iter(_mdata["table_templates"]), None)
                    if _first_key:
                        _mr_check["spec"]["source_sheet"] = _mdata["table_templates"][_first_key].get("source_sheet", "")
                if not _mr_check.get("spec", {}).get("source_sheet") or template_matches_sheet(_mr_check, sheet_name, sheet_overrides=_sheet_overrides):
                    _merge_mapped_into_template(_mdata, os.path.basename(mapped_path))
                else:
                    print(f"[PNG MERGE] Skipped {os.path.basename(mapped_path)} (sheet mismatch)")
            except Exception as _exc:
                print(f"[PNG MERGE] Could not merge {mapped_path}: {_exc}")
    print(f"[PNG MERGE] Final result: {'merged' if _did_merge else 'NOT merged'}")
    print(f"[PNG MERGE] template has table_templates={'table_templates' in template}, flow_regions={'flow_regions' in template}")

    slots_raw = template.get('slots', {}) or {}
    if scale_template_slots:
        try:
            slots, template_scale, _off_x, _off_y = scale_template_slots(template, canvas_w, canvas_h)
        except Exception:
            slots = {}
            template_scale = 1.0
    else:
        slots = {}
        template_scale = 1.0
    if not slots:
        template_canvas = template.get("canvas") or {}
        try:
            template_w = float(template_canvas.get("width") or canvas_w or 1)
            template_h = float(template_canvas.get("height") or canvas_h or 1)
        except Exception:
            template_w, template_h = float(canvas_w or 1), float(canvas_h or 1)
        sx = float(canvas_w) / max(1.0, template_w)
        sy = float(canvas_h) / max(1.0, template_h)
        template_scale = min(sx, sy)
        off_x = (float(canvas_w) - template_w * template_scale) / 2.0
        off_y = (float(canvas_h) - template_h * template_scale) / 2.0
        for name, box in slots_raw.items():
            try:
                slots[name] = {
                    "x": off_x + float(box.get('x', box.get("left", 0)) or 0) * template_scale,
                    "y": off_y + float(box.get('y', box.get("top", 0)) or 0) * template_scale,
                    "w": float(box.get('w', box.get("width", 0)) or 0) * template_scale,
                    "h": float(box.get('h', box.get("height", 0)) or 0) * template_scale,
                }
            except Exception:
                pass

    slot_prefix = str(template.get("slot_prefix") or "").strip()
    combined_icons = {}
    combined_icons.update(template.get("icon_mappings") or {})
    combined_icons.update(icon_mappings or {})

    # For paytable JSONs, use the exact PSD paytable parser instead of guessing row numbers.
    is_paytable = str(template.get("page_type") or "").casefold() == "paytable" or str(sheet_name or "").casefold() == "paytable"
    if not is_paytable:
        # "Paytable-100-50-25lines", "FG Paytable-5lines"…: a mapper design on a paytable-named sheet
        from ps_autotypesetter.dynamic_pages.router import _is_mapper_design as _mapper, _sheet_is_paytable
        is_paytable = _sheet_is_paytable(sheet_name) and _mapper(template)
    if is_paytable and parse_paytable_sheet is not None:
        template_style_settings = _merge_template_style_settings(template)
        merged_dynamic_settings = dict(template_style_settings)
        merged_dynamic_settings.update(dynamic_settings or {})
        settings = _normalize_png_paytable_settings(merged_dynamic_settings, h_font, h_size, h_rgb, b_font, b_size, b_rgb)
        settings["asset_folder"] = icon_folder
        settings["icon_mappings"] = combined_icons

        # Web-Paytable-Mapper authored JSON (canvas + slots + per-slot
        # mappings) renders through its OWN mappings -- exactly what the
        # Paytable Mapper studio preview shows (render_table_outline_preview
        # with annotations=False), no blueprints/no parser guess -- mirroring
        # the PSD router's _is_mapper_design() decision.
        from ps_autotypesetter.dynamic_pages.router import _is_mapper_design

        if _is_mapper_design(template):
            _render_mapped_paytable_png(
                base, draw, Image, ImageFont, template, ws, sheet_name,
                settings, icon_folder, combined_icons, icon_size_overrides,
                slots, line_spacing, report,
            )
            _note(report, "PNG paytable rendered from the Paytable Mapper design (per-slot mappings).")
            return
        _note(
            report,
            "PNG paytable styles: "
            f"count={settings.get('count_size')}px/{settings.get('count_rgb')} font={settings.get('count_font')}; "
            f"value={settings.get('value_size')}px/{settings.get('value_rgb')} font={settings.get('value_font')}; "
            f"wild_text={settings.get('wild_text_size')}px/{settings.get('wild_text_rgb')}; "
            f"notes={settings.get('notes_text_size')}px/{settings.get('notes_text_rgb')}."
        )

        # Check for a saved paytable data override file beside the template JSON.
        page_data = None
        override_path = os.path.splitext(json_path)[0] + ".paytable_override.json"
        if os.path.isfile(override_path):
            try:
                with open(override_path, "r", encoding="utf-8") as _f:
                    _override = json.load(_f)
                _pd = _override.get("page_data")
                if _pd:
                    page_data = _pd
                    _note(report, f"Using paytable data override from {os.path.basename(override_path)}")
            except Exception as _exc:
                _warn(report, f"Could not load paytable override {override_path}: {_exc}")
        if page_data is None:
            page_data = parse_paytable_sheet(ws, template)
        mapped_flow_slots = {str(region.get("slot") or region.get("id") or "").casefold() for region in page_data.get("flow_regions") or []}
        mapped_token_slots = {str(binding.get("slot") or "").casefold() for binding in page_data.get("token_bindings") or []}
        mapped_slots = {slot for slot in mapped_flow_slots | mapped_token_slots if slot}

        # Sheets can have fewer or more cards than the template's icon slots.
        # Fewer render only that many; extras clone the last matched card row
        # downward so every parsed card appears (e.g. 12 symbols / 10 slots).
        _pt_top_n = len(page_data.get("top_cards") or [])
        if auto_extend_card_slots is not None:
            auto_extend_card_slots(
                slots, page_data,
                lambda s, c, i, tc: _paytable_find_card_box(s, c, i, "top", top_count=tc, slot_prefix=slot_prefix),
                _paytable_card_aliases, card_type="top", settings=settings,
                canvas_height=base.height if base else None)
            auto_extend_card_slots(
                slots, page_data,
                lambda s, c, i, tc: _paytable_find_card_box(s, c, i, "lower", top_count=tc, slot_prefix=slot_prefix),
                _paytable_card_aliases, card_type="lower", settings=settings,
                canvas_height=base.height if base else None, top_count=_pt_top_n)

        # Main title.
        title_box = _paytable_slot(slots, "title", slot_prefix=slot_prefix)
        if title_box and "title" not in mapped_flow_slots:
            title_text = _prepare_png_heading_text(page_data.get("title") or sheet_name, settings)
            _draw_fitted_inline_in_box(
                base, draw, Image, ImageFont, title_text, title_box, settings.get("heading_font", h_font),
                settings.get("title_size", h_size), settings.get("title_rgb", h_rgb),
                icon_folder, combined_icons, max(1, int(settings.get("title_size", h_size))),
                icon_size_overrides, align="center", vertical_align="center", line_spacing=max(0, _safe_int(line_spacing, 2)), bold=True,
            )

        # Optional wild/feature title.
        side = page_data.get("side_panel", {}) or {}
        wild_title_box = _paytable_slot(slots, "feature.title", "wild.title", "special.title", slot_prefix=slot_prefix)
        if wild_title_box and "wild.title" not in mapped_flow_slots and "feature.title" not in mapped_flow_slots:
            title = settings.get("wild_title_slot_text") or settings.get("wild_title") or side.get("feature_title") or "WILD"
            _draw_fitted_inline_in_box(
                base, draw, Image, ImageFont, title, wild_title_box, settings.get("heading_font", h_font),
                settings.get("wild_title_size", h_size), settings.get("wild_title_rgb", settings.get("heading_rgb", h_rgb)),
                icon_folder, combined_icons, max(1, int(settings.get("wild_title_size", h_size))),
                icon_size_overrides, align="center", vertical_align="center", line_spacing=2, bold=True,
            )

        def card_bg_for(card_type):
            if card_type == "top":
                return settings.get("top_card_bg_rgb", (10, 10, 18)), settings.get("top_card_bg_opacity", 0)
            return settings.get("lower_card_bg_rgb", (18, 12, 28)), settings.get("lower_card_bg_opacity", 0)

        def render_card(card, index, card_type, top_count=0):
            aliases = _paytable_card_aliases(card, index, card_type, top_count=top_count)
            card_box = _paytable_find_card_box(slots, card, index, card_type, top_count=top_count, slot_prefix=slot_prefix)
            if card_box:
                bg_rgb, bg_opacity = card_bg_for(card_type)
                stroke_w = _safe_int(settings.get("card_stroke_width"), 0)
                if _safe_int(bg_opacity, 0) > 0 or stroke_w > 0:
                    _draw_alpha_rect(base, draw, Image, card_box, bg_rgb, bg_opacity, settings.get("card_stroke_rgb", (40, 40, 55)), stroke_w)

            icon_box = _paytable_find_icon_box(slots, card, index, card_type, top_count=top_count, slot_prefix=slot_prefix)
            if not icon_box:
                icon_box = _paytable_card_part_box(card_box, "icon", is_top=(card_type == "top"))
            icon_mapped = any(slot.startswith(alias + ".icon") or slot.startswith(alias + ".symbolicon") for alias in aliases for slot in mapped_slots)
            if icon_box and not icon_mapped:
                height_key = "top_symbol_icon_height" if card_type == "top" else "lower_symbol_icon_height"
                _place_paytable_icon(
                    base, draw, Image, ImageFont, card.get("label"), icon_box, icon_folder, combined_icons,
                    icon_size_overrides, max_height=settings.get(height_key), fallback_font=settings.get("heading_font", h_font),
                    fallback_rgb=settings.get("fallback_symbol_rgb", (255, 255, 255)),
                )

            payouts_mapped = any(
                slot.startswith(alias + ".pay") or slot.startswith(alias + ".pays") or slot.startswith(alias + ".value") or slot.startswith(alias + ".values")
                for alias in aliases for slot in mapped_slots
            )
            if not payouts_mapped:
                used_slots = _render_png_payouts_in_json_slots(
                    base, draw, Image, ImageFont, card, slots, settings, aliases,
                    icon_folder, combined_icons, icon_size_overrides, slot_prefix=slot_prefix,
                )
                if not used_slots and card_box:
                    payout_box = _paytable_card_part_box(card_box, "payouts", is_top=(card_type == "top"))
                    _draw_paytable_payout_lines(
                        base, draw, Image, ImageFont,
                        [f"{p.get('count', '')}     {p.get('value', '')}" for p in card.get("payouts") or []],
                        payout_box, b_font, settings.get("value_size", b_size), settings.get("value_rgb", b_rgb),
                        icon_folder, combined_icons, icon_size_overrides,
                    )

        top_cards = list(page_data.get("top_cards") or [])
        for idx, card in enumerate(top_cards, start=1):
            render_card(card, idx, "top")
        top_count = len(top_cards)
        for idx, card in enumerate(page_data.get("lower_cards") or [], start=1):
            render_card(card, idx, "lower", top_count=top_count)

        # With mapper-authoritative templates, PSD still auto-fills wild/feature icon slots.
        feature_tokens = list(side.get("feature_tokens") or []) or [side.get("wild_token") or "Wild"]
        wild_icon_boxes = _paytable_wild_icon_boxes(slots, mapped_token_slots=mapped_token_slots)
        for idx, icon_box in enumerate(wild_icon_boxes, start=1):
            token = feature_tokens[min(idx - 1, len(feature_tokens) - 1)] if feature_tokens else "Wild"
            _place_paytable_icon(
                base, draw, Image, ImageFont, token, icon_box, icon_folder, combined_icons,
                icon_size_overrides, max_height=settings.get("wild_icon_height"), fallback_font=b_font,
                fallback_rgb=settings.get("wild_text_rgb", b_rgb),
            )

        # If dedicated wild-icon slots exist, strip their tokens from flow text
        # so they don't render as inline icons inside text slots (double rendering).
        if wild_icon_boxes and feature_tokens:
            wild_keys = {str(t).strip("<> ").casefold() for t in feature_tokens}
            for region in page_data.get("flow_regions") or []:
                for block in region.get("blocks") or []:
                    text = str(block.get("text") or "")
                    new_parts = []
                    for part in re.split(r"(<[^>]+>)", text):
                        if part.startswith("<") and part.endswith(">"):
                            token_key = part.strip("<> ").casefold()
                            if token_key in wild_keys:
                                continue
                        new_parts.append(part)
                    cleaned = "".join(new_parts).strip()
                    cleaned = re.sub(r"\s+", " ", cleaned)
                    block["text"] = cleaned

        # Mapped flow text and mapped dedicated icon bindings from the JSON/template mapper.
        for _pf_region in page_data.get("flow_regions") or []:
            _pf_slot = str(_pf_region.get("slot", ""))
            _pf_blocks = _pf_region.get("blocks") or []
            _pf_texts = [str(b.get("text", "")) for b in _pf_blocks if isinstance(b, dict)]
            print(f"[PNG FLOW] slot={_pf_slot} blocks={len(_pf_blocks)} texts={_pf_texts}")
            _warn(report, f"PNG flow debug: slot={_pf_slot} blocks={len(_pf_blocks)} texts={_pf_texts}")
            _render_png_flow_region(
                base, draw, Image, ImageFont, _png_flow_region_with_ui_defaults(_pf_region, settings), slots, template_scale, icon_folder,
                combined_icons, icon_size_overrides, settings.get("body_font", b_font), settings.get("wild_text_size", b_size), settings.get("wild_text_rgb", b_rgb), report, slot_prefix=slot_prefix,
            )
        _render_png_token_bindings(base, draw, Image, ImageFont, page_data, slots, settings, icon_folder, combined_icons, icon_size_overrides, slot_prefix=slot_prefix)
        summary = page_data.get("parser_summary", {})
        _note(report, f"PNG paytable rendered with PSD parser: top={summary.get('top_cards', 0)}, lower={summary.get('lower_cards', 0)}, flow={summary.get('flow_regions', 0)}.")
        for warning in summary.get("flow_warnings", []) or []:
            _warn(report, f"PNG paytable mapper: {warning}")
        return

    # Generic non-paytable JSON fallback: render only explicitly mapped flow/text regions and title.
    flow_regions = template.get('flow_regions', {})
    if isinstance(flow_regions, dict):
        region_items = flow_regions.items()
    elif isinstance(flow_regions, list):
        region_items = [(region.get("id", f"region_{idx}"), region) for idx, region in enumerate(flow_regions, start=1) if isinstance(region, dict)]
    else:
        region_items = []
    flow_by_slot = {}
    for region_id, region in region_items:
        if not isinstance(region, dict):
            continue
        slot_name = region.get('slot', '') or region_id
        if slot_name:
            region = dict(region)
            region.setdefault("id", region_id)
            blocks = []
            for src in region.get("sources") or []:
                src_ref = src.get("source", "") if isinstance(src, dict) else src
                text = _read_excel_range(ws, src_ref)
                if text:
                    blocks.append({"text": text, "source": src_ref})
            region["blocks"] = blocks
            flow_by_slot[slot_name] = region
    for region in flow_by_slot.values():
        _render_png_flow_region(base, draw, Image, ImageFont, region, slots, template_scale, icon_folder, combined_icons, icon_size_overrides, b_font, b_size, b_rgb, report, slot_prefix=slot_prefix)
    title_box = _paytable_slot(slots, "title", slot_prefix=slot_prefix)
    if title_box:
        _draw_fitted_inline_in_box(base, draw, Image, ImageFont, sheet_name, title_box, h_font, h_size, h_rgb, icon_folder, combined_icons, h_size, icon_size_overrides, align="center", vertical_align="center", bold=True)
#======================== Added by me ======================================


def _render_mapped_paytable_png(
    base, draw, Image, ImageFont, template, ws, sheet_name, settings,
    icon_folder, icon_mappings, icon_size_overrides, slots, line_spacing, report
):
    """The mapped paytable reads its numbers from the sheet's VALUES, like the studio preview: a
    build holds the workbook with formulas (other pages need them), where a pay written as
    =H22 came out as the text "=H22" on the card."""
    path = _BUILD_EXCEL.get()
    if path and os.path.isfile(path) and ws is not None:
        from . import workbook_cache

        try:
            with workbook_cache.borrow(path, data_only=True) as values_wb:
                title = getattr(ws, "title", sheet_name)
                if title in values_wb.sheetnames:
                    return _render_mapped_paytable_png_ws(
                        base, draw, Image, ImageFont, template, values_wb[title], sheet_name, settings,
                        icon_folder, icon_mappings, icon_size_overrides, slots, line_spacing, report)
        except OSError:
            pass
    return _render_mapped_paytable_png_ws(
        base, draw, Image, ImageFont, template, ws, sheet_name, settings,
        icon_folder, icon_mappings, icon_size_overrides, slots, line_spacing, report)


def _render_mapped_paytable_png_ws(
    base, draw, Image, ImageFont, template, ws, sheet_name, settings,
    icon_folder, icon_mappings, icon_size_overrides, slots, line_spacing, report
):
    """Render a web-Paytable-Mapper authored JSON through its per-slot
    ``mappings`` -- the same layout the Paytable Mapper studio preview shows
    (``render_table_outline_preview`` with ``annotations=False``): slot fills
    and strokes, inline text/icons with per-slot font/color/alignment/padding,
    page-heading and hardcoded WILD defaults for unmapped slots. Drawn onto
    the existing canvas; no blueprint outlines or slot labels."""
    try:
        from ps_autotypesetter.ui_web import ps_actions as _pa
        from ps_autotypesetter.ui_web.engine_api import (
            _paytable_live_slot_data,
            paytable_slot_is_dead,
        )
    except Exception as _exc:
        _warn(report, f"Mapped paytable renderer unavailable: {_exc}")
        return
    try:
        mapped = _pa._mapping_dict(template.get("mappings") or {})
        _pa._sanitize_preview_mappings(mapped, ws, template)
        live_data = None
        # a learned artist layout was already fitted to this sheet (fit_cards):
        # the positional dead-card rules (pic5 > top-row count) do not apply
        from .artist_design.fit_cards import is_artist_template as _is_artist
        if ws is not None and not _is_artist(template):
            try:
                live_data = _paytable_live_slot_data(ws, template)
            except Exception:
                live_data = None
        if live_data is not None:
            _pa._filter_preview_dead_mappings(mapped, live_data, paytable_slot_is_dead)
    except Exception as _exc:
        _warn(report, f"Mapped paytable mapping prep failed: {_exc}")
        mapped = {}
        live_data = None
    _note(report, f"PNG mapped paytable: {len(mapped)} mapped slots on a {len(slots)}-slot design.")
    count_rgb = _pa._hex_to_rgb(settings.get("count_rgb"))

    for name, box in slots.items():
        if live_data is not None:
            m_spec = mapped.get(name) if isinstance(mapped, dict) else None
            if m_spec is None:
                m_spec = _pa._paytable_preview_default_mapping(name)
            try:
                if paytable_slot_is_dead(name, m_spec, live_data):
                    continue
            except Exception:
                pass
        try:
            if isinstance(box, dict) and all(key in box for key in ("x", "y", "w", "h")):
                x = int(float(box["x"]))
                y = int(float(box["y"]))
                w = int(float(box["w"]))
                h = int(float(box["h"]))
            elif isinstance(box, (list, tuple)) and len(box) >= 4:
                x = int(float(box[0]))
                y = int(float(box[1]))
                w = int(float(box[2]))
                h = int(float(box[3]))
            elif isinstance(box, dict) and box.get("bounds"):
                bbox = box["bounds"]
                x = int(float(bbox[0]))
                y = int(float(bbox[1]))
                w = int(float(bbox[2]))
                h = int(float(bbox[3]))
            else:
                continue
        except Exception:
            continue
        _psd_slot_label, _psd_slot_group = _psd_set_slot(base, name, slots)
        m = mapped.get(name) if isinstance(mapped, dict) else None
        if not (m and isinstance(m, dict)):
            m = _pa._paytable_preview_default_mapping(name)
            if m:
                if _pa._draw_mapped_slot_icon(
                    base, m, ws, icon_folder, icon_mappings, x, y, w, h, 1.0
                ):
                    pass
                else:
                    m = None
            if not m and _pa._preview_slot_is_wild_title(name):
                # Hardcoded: this slot always renders "WILD" with the heading
                # typography unless the user explicitly maps it.
                try:
                    wsize = int(float(settings.get("wild_title_size") or settings.get("title_size") or settings.get("heading_size") or 30))
                except Exception:
                    wsize = 30
                wcolor = _pa._rgb_to_hex(settings.get("wild_title_rgb") or settings.get("title_rgb") or settings.get("heading_rgb")) or "#FFCD32"
                m = {
                    "mode": "text", "source": "", "text": "WILD", "slot": name,
                    "font_size": wsize, "color": wcolor, "font_override": True,
                    "alignment": "center", "vertical_align": "center",
                    "padding": [0, 0, 0, 0],
                }
            if not m and _pa._preview_slot_is_title(name):
                # Hardcoded: the title slot always points to the page heading
                # (typography applied in the heading branch below) unless the
                # user explicitly maps it.
                m = {
                    "mode": "text", "source": "", "slot": name,
                    "font_size": 0, "color": "",
                    "alignment": "center", "vertical_align": "center",
                    "padding": [0, 0, 0, 0],
                }
            if not m:
                continue

        kind = str(m.get("kind") or "").casefold()
        # card templates: a live rounded box (PSD: vector shape + layer style)
        from . import paytable_box as _pbox
        # a plate that hugs its text (the paytable title): drawn once the text's width is known, as the
        # preview and the Canvas draw it
        _fit_plate = _pa.plate_is_late(m.get("shape"))
        _shaped = True if _fit_plate else _pbox.draw(base, m, x, y, w, h, settings, _psd_slot_label, _psd_slot_group)
        has_bg = bool(str(m.get("background_color") or m.get("fill_color") or "").strip())
        fill_ctl = m.get("fill_enabled")
        fill_off = fill_ctl is False or str(fill_ctl).casefold() in ("false", "off", "no", "0")
        fill_enabled = (not _shaped) and (not fill_off) and (
            has_bg or bool(fill_ctl) or kind == "background"
        )
        if fill_enabled:
            bg = m.get("background_color") or m.get("fill_color")
            if bg:
                try:
                    opacity = int(float(m.get("opacity") if m.get("opacity") is not None else 100) or 100)
                except Exception:
                    opacity = 100
                alpha = int(255 * (opacity / 100.0) * 0.85)
                try:
                    _fill_overlay = Image.new("RGBA", (w, h), _pa._hex_to_rgb(bg) + (alpha,))
                    if not _psd_shape(base, _fill_overlay, x, y, f"{_psd_slot_label} fill", _psd_slot_group):
                        base.alpha_composite(_fill_overlay, (x, y))
                except Exception:
                    draw.rectangle([x, y, x + w, y + h], fill=_pa._hex_to_rgb(bg) + (alpha,))
        try:
            stroke_w = int(m.get("stroke_width", 0) or 0)
        except Exception:
            stroke_w = 0
        stroke_ctl = m.get("stroke_enabled")
        stroke_off = _shaped or stroke_ctl is False or str(stroke_ctl).casefold() in ("false", "off", "no", "0")
        if (not stroke_off) and (bool(stroke_ctl) or stroke_w > 0):
            stroke = m.get("stroke_color")
            outline = _pa._hex_to_rgb(stroke) if stroke else (96, 140, 255)
            sw = max(1, int(stroke_w) or 1)  # target-canvas px, like the PSD
            from PIL import ImageDraw as _ImageDraw
            _stroke_img = Image.new("RGBA", (w + 1, h + 1), (0, 0, 0, 0))
            _ImageDraw.Draw(_stroke_img).rectangle([0, 0, w, h], outline=outline, width=sw)
            if not _psd_shape(base, _stroke_img, x, y, f"{_psd_slot_label} stroke", _psd_slot_group):
                draw.rectangle([x, y, x + w, y + h], outline=outline, width=sw)

        icon_drawn = False
        mode = str(m.get("mode") or "").casefold()
        icon_mode = kind in {"icon", "dedicated_icon"} or mode in {"icon", "symbol"}
        if icon_mode:
            icon_drawn = _pa._draw_mapped_slot_icon(
                base, m, ws, icon_folder, icon_mappings, x, y, w, h, 1.0
            )
            if not icon_drawn and isinstance(report, dict):
                report.setdefault("icon_issues", []).append(name)
        if icon_mode and not icon_drawn and str(m.get("token") or "").strip("<> "):
            # no picture for this symbol: show its <NAME> in the box rather than nothing
            icon_mode = False
            content = "<" + str(m.get("token")).strip("<> ").upper() + ">"
        elif icon_mode:
            content = ""
        else:
            content = _pa._mapping_preview_text(m, ws)
        if not icon_mode and _pa._preview_slot_is_title(name):
            # Page-heading slot: ALWAYS show the page heading with the
            # heading typography (font/size/color from the header settings)
            # unless the user mapped an explicit non-default text/source/font.
            if (mode == "literal" and _pa._cell_like_source(content)) or not content:
                content = _pa._preview_page_heading(ws, template)
                if not content:
                    content = str((template or {}).get("title")
                                  or ((template or {}).get("mapper_meta") or {}).get("title")
                                  or "").strip()
                if not content:
                    content = str((settings or {}).get("title_text") or "").strip()
            content = _pa._preview_heading_text(content, settings)
            if content:
                m = _pa.title_mapping(m, settings)
        if not icon_mode and _pa._preview_slot_is_wild_title(name) and not content:
            # Hardcoded: this slot renders "WILD" with the heading
            # typography unless the user provided explicit text/source.
            content = str(m.get("text") or settings.get("wild_title", "WILD")).strip() or "WILD"
            eff = dict(m)
            cur_size = int(float(m.get("font_size") or 0) or 0)
            try:
                wsize = int(float(settings.get("wild_title_size") or settings.get("title_size") or settings.get("heading_size") or 30))
            except Exception:
                wsize = 30
            eff["font_size"] = wsize if cur_size in (0, 30) else cur_size
            if not m.get("color") or str(m.get("color")).casefold() == "#ffffff":
                eff["color"] = _pa._rgb_to_hex(settings.get("wild_title_rgb") or settings.get("title_rgb") or settings.get("heading_rgb")) or "#FFCD32"
            if not (m.get("font_override") or (m.get("font_name") or m.get("font_family") or "").strip()):
                eff["font_name"] = str(settings.get("heading_font") or "").strip()
                eff["font_override"] = True
            eff["font_override"] = True
            m = eff
        if content:
            fcol = _pa._hex_to_rgb(m.get("color")) if m.get("color") else count_rgb
            _lay = _pa.slot_text_layout(name, m, content, x, y, w, h, icon_folder, icon_mappings, kind)
            flab, fh, lines, line_heights, block_h = _lay["font"], _lay["fh"], _lay["lines"], _lay["line_heights"], _lay["block_h"]
            ty, box_x, box_w, align = _lay["ty"], _lay["box_x"], _lay["box_w"], _lay["align"]
            _icon_h = _lay["icon_h"]
            if isinstance(report, dict) and not icon_mode and content and _lay["overflow"]:
                report.setdefault("overflow_issues", []).append(name)
            if _fit_plate:                       # the plate around the text: fit to it, or sized by hand
                _pbox.draw(base, m, *_pa.plate_rect(m["shape"], x, y, w, h, _lay), settings, _psd_slot_label, _psd_slot_group)
            _title_fx = None
            if (_pa._preview_slot_is_title(name) or _pa._preview_slot_is_wild_title(name)) and not m.get("effects_block"):
                # the page heading (and the WILD title) carry the "Heading text" layer style — or the
                # design's own title style (page.title.fx), as the preview and the Canvas draw it
                _own_fx = (m.get("title_own") or {}).get("fx")
                _title_fx = (fx_by_name(settings.get("layer_style_library") or {}, _own_fx) if _own_fx else
                             _resolve_fx_config(settings.get("layer_style_library") or {},
                                                settings.get("style_assignments") or {}, "Heading text"))
            if _title_fx:
                _draw_inline(
                    base, draw, Image, content, box_x + 3, ty, flab, fcol, max(1, box_w - 6),
                    icon_folder, icon_mappings, _icon_h, icon_size_overrides,
                    align=align, line_spacing=max(0, _safe_int(line_spacing, 2)), fx_config=_title_fx,
                    font_request=m.get("font_name") or m.get("font_family"), font_size=fh, bold=bool(m.get("bold", True)),
                )
                continue
            _text_fx = fx_by_name(settings.get("layer_style_library"), m.get("text_fx")) if m.get("text_fx") else None
            with _psd_text_block(base, _psd_slot_label, flab, fcol, align,
                                 (box_x + 3, max(1, box_w - 6)), _psd_slot_group,
                                 fx_config={"effects_block": m["effects_block"]} if m.get("effects_block") else _text_fx):
                for line_index, line in enumerate(lines):
                    _pa._draw_preview_inline_line(
                        draw, base, line, box_x + 3, ty, max(1, box_w - 6),
                        fcol, flab, line_heights[line_index], _icon_h, align, fx_config=_text_fx,
                    )
                    ty += line_heights[line_index]
    # Templates without any title slot still render the page heading the
    # normal way (every other page / the Visualiser preview): top with
    # heading_top_margin, inside the margin_x box, heading size/overrides,
    # h font/rgb and measured heading height -- same helpers, same result.
    _artist_meta = ((template.get("mapper_meta") or {}).get("artist_design") or {})
    if not any(_pa._preview_slot_is_title(name) for name in slots) and not _artist_meta.get("title_art"):
        heading = _pa._preview_page_heading(ws, template)
        if heading:
            try:
                target_width = max(1, int(getattr(base, "width", 0) or 1920))
                margin_x = int(float(settings.get("margin_x") or 80))
                heading_top = max(0, _safe_int(settings.get("heading_top_margin"), 120))
                safe_width = max(100, target_width - margin_x * 2)
                base_size = int(float(settings.get("title_size") or settings.get("heading_size") or 90))
                try:
                    current_size = max(8, int(float(_png_heading_size_for_sheet(sheet_name, settings, base_size))))
                except Exception:
                    current_size = base_size
                hfont_name = str(settings.get("heading_font") or settings.get("h_font") or "ArialMT")
                heading_font = _heading_font(ImageFont, hfont_name, current_size, settings)
                heading_color = _rgb(
                    settings.get("title_rgb") or settings.get("heading_rgb") or settings.get("h_rgb"),
                    (255, 80, 80))
                heading_icon_h = max(1, _safe_int(
                    current_size, _safe_int(settings.get("h_icon_h"), 48)))
                try:
                    heading_line_spacing = max(0, _safe_int(settings.get("line_spacing"), 4))
                except Exception:
                    heading_line_spacing = 4
                _draw_inline(
                    base, draw, Image, heading, margin_x, heading_top,
                    heading_font, heading_color, safe_width,
                    icon_folder, icon_mappings, heading_icon_h,
                    settings.get("icon_size_overrides") or {},
                    align="center", line_spacing=heading_line_spacing,
                )
            except Exception:
                pass
#========================Added By me ======================================



def _psd_track_buffer(buffer, base, dx, dy):
    """PSD record mode: text/icons drawn into `buffer` belong to `base` at +(dx, dy)."""
    from .psd_writer import recorder
    rec = recorder.active_recorder()
    if rec is not None:
        rec.register_buffer(buffer, base, dx, dy)


def _psd_set_slot(base, slot_name, slots):
    """Name + card group for a paytable slot's layers; also tells the recorder.

    `@slot.pic1.pay` -> ("pic1.pay", "pic1") when other slots share `pic1`, so
    each symbol card (icon, counts, pays) lands in one Photoshop group.
    """
    label = str(slot_name or "")
    for prefix in ("@slot.", "@table."):
        if label.startswith(prefix):
            label = label[len(prefix):]
    head = label.split(".")[0]
    siblings = 0
    for other in slots or ():
        other = str(other)
        for prefix in ("@slot.", "@table."):
            if other.startswith(prefix):
                other = other[len(prefix):]
        if other.split(".")[0] == head:
            siblings += 1
    group = head if siblings > 1 else None
    from .psd_writer import recorder
    rec = recorder.active_recorder()
    if rec is not None and recorder.page_for(base) is not None:
        rec.slot = (label, group)
    return label, group


def _psd_shape(target, image, x, y, name, group=None):
    """Record a slot fill/stroke as its own layer (below text). True when recorded."""
    from .psd_writer import recorder
    page = recorder.page_for(target)
    if page is None:
        return False
    page.shapes.append(recorder.ImageRecord(image, x, y, name, group=group))
    return True


def _psd_text_block(base, name, font, color, align, box, group=None, fx_config=None):
    from .psd_writer import recorder
    import contextlib
    rec = recorder.active_recorder()
    if rec is None:
        return contextlib.nullcontext()
    return rec.text_block(base, name, font, color, align, box, group=group, fx_config=fx_config)


def _psd_paste_icon(target, icon, x, y, name, group=None):
    """Composite an icon, or record it as its own layer when building a PSD."""
    from .psd_writer import recorder
    page = recorder.page_for(target)
    if page is None:
        target.alpha_composite(icon, (int(x), int(y)))
        return
    from . import icon_scales

    # the layer is named after the token, never its size tag ('Red Bag~130' -> 'Red Bag')
    page.icons.append(recorder.ImageRecord(icon.copy(), x, y, icon_scales.strip(name) or name, group=group))


def _draw_background(base, Image, bg_path, bg_mode, bg_color="#FFFFFF"):
    _paint_background(base, Image, bg_path, bg_mode, bg_color)
    # PSD record mode: every page passes through here right after creation, so
    # this is where it gets registered. The page is cleared so only graphics
    # accumulate on it; the background becomes its own layer.
    from .psd_writer import recorder
    rec = recorder.active_recorder()
    if rec is not None:
        background = base.copy()
        base.paste((0, 0, 0, 0), [0, 0, base.width, base.height])
        rec.register_page(base, background)


def _paint_background(base, Image, bg_path, bg_mode, bg_color="#FFFFFF"):
    draw = ImageDraw = None
    if str(bg_mode or "").casefold() == "color":
        hexv = str(bg_color or "#FFFFFF").lstrip("#")
        try:
            rgb = tuple(int(hexv[i:i + 2], 16) for i in (0, 2, 4)) + (255,)
        except Exception:
            rgb = (255, 255, 255, 255)
        base.paste(rgb, [0, 0, base.width, base.height])
        return
    if bg_path and os.path.isfile(bg_path):
        try:
            bg = Image.open(bg_path).convert("RGBA")
            from . import bg_place

            mode = bg_place.parse(bg_mode)[0]
            # what the picture leaves uncovered (around a fit / placed picture, its own transparent parts)
            # is transparent — or the "Colour behind" when the artist switched it on (bg_place.behind)
            base.paste(bg_place._rgba(bg_color) or (0, 0, 0, 0), [0, 0, base.width, base.height])
            if mode in ("fit_width", "place"):
                # the picture in its own rectangle (as wide as the canvas / where the PSD has it)
                x, y, w, h = bg_place.dest(bg_mode, base.width, base.height, bg.width, bg.height)
                bg = bg.resize((max(1, int(round(w))), max(1, int(round(h)))), Image.LANCZOS)
                layer = Image.new("RGBA", base.size, (0, 0, 0, 0))
                layer.paste(bg, (int(round(x)), int(round(y))))       # paste clips what reaches past the canvas
                base.alpha_composite(layer)
                return
            if mode == "center":
                x = int((base.width - bg.width) / 2)
                y = int((base.height - bg.height) / 2)
                base.alpha_composite(bg, (x, y))
                return
            if mode == "fit":
                scale = min(base.width / max(1, bg.width), base.height / max(1, bg.height))
                bg = bg.resize((max(1, int(bg.width * scale)), max(1, int(bg.height * scale))))
                x = int((base.width - bg.width) / 2)
                y = int((base.height - bg.height) / 2)
                base.alpha_composite(bg, (x, y))
                return
            if mode == "tile":
                for yy in range(0, base.height, bg.height):
                    for xx in range(0, base.width, bg.width):
                        base.alpha_composite(bg, (xx, yy))
                return
            if mode == "cover":
                # fill the whole canvas without stretching: scale up/down to cover, crop the overflow evenly
                scale = max(base.width / max(1, bg.width), base.height / max(1, bg.height))
                sw, sh = max(1, round(bg.width * scale)), max(1, round(bg.height * scale))
                bg = bg.resize((sw, sh), Image.LANCZOS)
                left, top = (sw - base.width) // 2, (sh - base.height) // 2
                base.alpha_composite(bg.crop((left, top, left + base.width, top + base.height)), (0, 0))
                return
            bg = bg.resize((base.width, base.height))
            base.alpha_composite(bg, (0, 0))
            return
        except Exception:
            pass
    # Transparent/blank backgrounds look surprising when opened directly, so use white.
    base.paste((255, 255, 255, 255), [0, 0, base.width, base.height])


def _sheet_matches(scope, sheet_name):
    scope = str(scope or "").strip().strip("'\"")
    if not scope or scope in ("*", "all", "ALL") or scope.casefold() == str(sheet_name or "").strip().casefold():
        return True
    stripped = re.sub(r"\s*\(\d+\)\s*", "", scope).strip()
    if stripped and stripped != scope and stripped.casefold() == str(sheet_name or "").strip().casefold():
        return True
    return False


def _ranges_from_text(value):
    ranges = []
    for match in RANGE_RE.finditer(str(value or "")):
        ref = match.group(0).replace("$", "").upper()
        if ":" not in ref and not CELL_RE.fullmatch(ref):
            continue
        if match.start() > 0:
            prev = str(value or "")[match.start() - 1]
            if prev.isalpha():
                continue
        ranges.append(ref)
    return ranges


def _split_scoped_entries(raw_value):
    if isinstance(raw_value, dict):
        return [f"{key}={value}" for key, value in raw_value.items()]
    if isinstance(raw_value, (list, tuple, set)):
        raw_value = "\n".join(str(v or "") for v in raw_value)
    entries = []
    for raw_line in re.split(r"[;\n]+", str(raw_value or "")):
        line = raw_line.strip()
        if line:
            entries.append(line)
    return entries


def _manual_ranges_for_sheet(raw_ranges, sheet_name):
    selected = []
    seen = set()
    for line in _split_scoped_entries(raw_ranges):
        scope = ""
        body = line
        for sep in ("=", "|"):
            if sep in line:
                left, right = line.split(sep, 1)
                if _ranges_from_text(right):
                    scope, body = left.strip(), right.strip()
                    break
        if not scope and "!" in line:
            left, right = line.rsplit("!", 1)
            if _ranges_from_text(right):
                scope, body = left.strip(), right.strip()
        if not scope:
            match = re.match(r"^(.+?)\s*:\s*(.+)$", line)
            if match and not _ranges_from_text(match.group(1)) and _ranges_from_text(match.group(2)):
                scope, body = match.group(1).strip(), match.group(2).strip()
        if scope and not _sheet_matches(scope, sheet_name):
            continue
        for range_ref in _ranges_from_text(body):
            key = range_ref.casefold()
            if key not in seen:
                selected.append(range_ref)
                seen.add(key)
    return selected


def _hex_overrides_for_sheet(raw_value, sheet_name):
    overrides = {}
    for line in _split_scoped_entries(raw_value):
        if "=" not in line:
            continue
        left, right = line.split("=", 1)
        hex_match = re.search(r"#?([0-9A-Fa-f]{6})", right)
        if not hex_match:
            continue
        rgb = _rgb("#" + hex_match.group(1))
        scope = ""
        body = left.strip()
        right_body = re.sub(r"[:=]?\s*#?[0-9A-Fa-f]{6}.*$", "", right).strip()
        if right_body and _ranges_from_text(right_body) and not _ranges_from_text(body):
            scope, body = body, right_body
        elif "!" in body:
            maybe_scope, maybe_body = body.rsplit("!", 1)
            if _ranges_from_text(maybe_body):
                scope, body = maybe_scope.strip(), maybe_body.strip()
        if not scope:
            match = re.match(r"^(.+?)\s*:\s*(.+)$", body)
            if match and _ranges_from_text(match.group(2)) and not _ranges_from_text(match.group(1)):
                scope, body = match.group(1).strip(), match.group(2).strip()
        if scope and not _sheet_matches(scope, sheet_name):
            continue
        for range_ref in _ranges_from_text(body):
            try:
                min_c, min_r, max_c, max_r = range_boundaries(range_ref)
            except Exception:
                continue
            for row_idx in range(min(min_r, max_r), max(min_r, max_r) + 1):
                for col_idx in range(min(min_c, max_c), max(min_c, max_c) + 1):
                    overrides[f"{get_column_letter(col_idx).upper()}{row_idx}"] = rgb
                    overrides[f"{row_idx}:{col_idx}"] = rgb
    return overrides


def _table_matches_range(table, range_ref):
    try:
        min_c, min_r, max_c, max_r = range_boundaries(range_ref)
    except Exception:
        return False
    return not (
        int(table.get("max_col", 0)) < min_c
        or int(table.get("min_col", 0)) > max_c
        or int(table.get("end_row", 0)) < min_r
        or int(table.get("start_row", 0)) > max_r
    )


def _prepare_tables(ws, table_style, max_col_limit, sheet_name, min_col_limit=1):
    manual_ranges = _manual_ranges_for_sheet((table_style or {}).get("manual_table_ranges", ""), sheet_name)
    manual_tables = manual_tables_from_ranges(ws, manual_ranges, max_col_limit) if manual_ranges else []
    auto_tables = detect_tables_in_sheet(ws, max_col_limit, min_col_limit=min_col_limit)
    if manual_tables:
        def overlaps(a, b):
            return not (
                int(a.get("max_col", 0)) < int(b.get("min_col", 0))
                or int(a.get("min_col", 0)) > int(b.get("max_col", 0))
                or int(a.get("end_row", 0)) < int(b.get("start_row", 0))
                or int(a.get("start_row", 0)) > int(b.get("end_row", 0))
            )
        auto_tables = [t for t in auto_tables if not any(overlaps(t, mt) for mt in manual_tables)]
    tables = sorted(manual_tables + auto_tables, key=lambda item: (item["start_row"], item.get("min_col", 0)))

    fill_ranges = _manual_ranges_for_sheet((table_style or {}).get("table_excel_fill_ranges", ""), sheet_name)
    font_ranges = _manual_ranges_for_sheet((table_style or {}).get("table_excel_font_color_ranges", ""), sheet_name)
    fill_overrides = _hex_overrides_for_sheet((table_style or {}).get("table_excel_fill_hex_overrides", ""), sheet_name)
    font_overrides = _hex_overrides_for_sheet((table_style or {}).get("table_excel_font_hex_overrides", ""), sheet_name)
    for table in tables:
        if any(_table_matches_range(table, rr) for rr in fill_ranges):
            table["use_excel_fill_colors"] = True
            table["excel_fill_hex_overrides"] = fill_overrides
        if any(_table_matches_range(table, rr) for rr in font_ranges):
            table["use_excel_font_colors"] = True
            table["excel_font_hex_overrides"] = font_overrides
        # its design (Tables → designs): by its header text, so it survives row moves in a revision
        from . import table_designs as _td

        table["design_key"] = _td.table_key(sheet_name, _table_header_text(ws, table))
        table["design"] = _td.design_for(table_style, table["design_key"])
        if _td.uses_excel_colours(table_style, table["design"]):
            table["use_excel_fill_colors"] = True
            table["use_excel_font_colors"] = True
            table["excel_blank_white"] = True          # cells without a fill are white, as Excel shows them
    # rows / columns the artist set on the Canvas (a row as normal text, a row or column as header / normal),
    # by the key of the table as detected — a lower piece of a split table keeps its table's design
    from . import table_rows as _tr
    from . import table_designs as _td

    out = []
    for table in tables:
        for piece in _tr.apply(table, _tr.spec_for(table_style, table["design_key"])):
            if piece.get("piece"):
                own = ((table_style or {}).get("designs") or {}).get(piece["design_key"])
                piece["design"] = _td.design_for(table_style, piece["design_key"]) if own else table["design"]
            out.append(piece)
    return out


def _table_header_text(ws, table):
    """The table's first row as text (how its design is remembered)."""
    try:
        row = int(table.get("header_row_idx") or table.get("start_row") or 0)
        lo, hi = int(table.get("min_col") or 1), int(table.get("max_col") or 1)
    except (TypeError, ValueError):
        return ""
    if row < 1:
        return ""
    vals = []
    for r in ws.iter_rows(min_row=row, max_row=row, min_col=lo, max_col=max(lo, hi), values_only=True):
        vals = [str(v).strip() for v in r if v is not None and str(v).strip()]
    return " | ".join(vals)


def _row_nonempty_cells(ws, row_idx, max_col_limit):
    cells = []
    for col_idx in range(1, max_col_limit + 1):
        value = _text(ws.cell(row=row_idx, column=col_idx).value)
        if value:
            cells.append((col_idx, value))
    return cells


def _find_heading_row(ws, max_col_limit, excluded_row_ranges=None, min_row=1, max_row=None):
    excluded_row_ranges = list(excluded_row_ranges or [])
    scan_col_limit = max(max_col_limit, min(_safe_int(getattr(ws, "max_column", max_col_limit), max_col_limit), 80))
    best = None
    lower = max(1, _safe_int(min_row, 1))
    upper = min(ws.max_row or 1, _safe_int(max_row, ws.max_row or 1), 20)
    for row_idx in range(lower, upper + 1):
        if _row_is_inside(row_idx, excluded_row_ranges):
            continue
        cells = _row_nonempty_cells(ws, row_idx, scan_col_limit)
        if not cells:
            continue
        text = " ".join(v for _c, v in cells)
        if not text or text.startswith("<mod"):
            continue
        bold_count = 0
        merged_span = 1
        for col_idx, _value in cells:
            try:
                if ws.cell(row=row_idx, column=col_idx).font.bold:
                    bold_count += 1
            except Exception:
                pass
            try:
                coord = ws.cell(row=row_idx, column=col_idx).coordinate
                for merged in ws.merged_cells.ranges:
                    if coord in merged:
                        merged_span = max(merged_span, merged.max_col - merged.min_col + 1)
                        break
            except Exception:
                pass
        upper_ratio = sum(1 for ch in text if ch.isupper()) / max(1, sum(1 for ch in text if ch.isalpha()))
        score = (
            90 - row_idx * 3
            + bold_count * 14
            + merged_span * 4
            + (10 if upper_ratio > 0.65 else 0)
            + (8 if len(text) <= 100 else 0)
            - len(cells) * 3
        )
        if best is None or score > best[0]:
            best = (score, row_idx, text)
    if not best:
        return 0, ""
    from . import icon_scales

    return best[1], icon_scales.apply(getattr(ws, "title", ""), f"row:{best[1]}", best[2], role="heading")


def _cell_keys(row_idx, col_idx):
    coord = f"{get_column_letter(col_idx).upper()}{row_idx}"
    return coord, f"{row_idx}:{col_idx}"


def _effective_render_mode(role, row_idx, table_style):
    if role == "header":
        ov = str((table_style or {}).get("header_render_mode", "") or "").casefold()
    elif row_idx % 2 == 0:
        ov = str((table_style or {}).get("row1_render_mode", "") or "").casefold()
    else:
        ov = str((table_style or {}).get("row2_render_mode", "") or "").casefold()
    return ov if ov else str((table_style or {}).get("render_mode", "both")).casefold()

def _cell_fill_for_table(ws, table, row_idx, col_idx, role, table_style):
    render_mode = _effective_render_mode(role, row_idx, table_style)
    if render_mode == "stroke":
        return None
    if table.get("use_excel_fill_colors"):
        coord, key2 = _cell_keys(row_idx, col_idx)
        override = (table.get("excel_fill_hex_overrides") or {}).get(coord) or (table.get("excel_fill_hex_overrides") or {}).get(key2)
        if override is not None:
            return _rgb(override)
        try:
            cell = ws.cell(row=row_idx, column=col_idx)
            from . import table_designs as _td

            # a colour rule in Excel (conditional formatting) paints over the cell's own fill
            fill = _td.conditional_fill(ws, cell) or get_excel_fill_color(cell)
            return fill if fill is not None or not table.get("excel_blank_white") else (255, 255, 255)
        except Exception:
            return None
    if role == "header":
        return _rgb((table_style or {}).get("header_bg_rgb"), (20, 20, 30))
    return _rgb((table_style or {}).get("row1_bg_rgb"), (35, 35, 50)) if (row_idx % 2 == 0) else _rgb((table_style or {}).get("row2_bg_rgb"), (28, 28, 42))


def _cell_font_color_for_table(ws, table, row_idx, col_idx, role, table_style):
    if table.get("use_excel_font_colors"):
        coord, key2 = _cell_keys(row_idx, col_idx)
        override = (table.get("excel_font_hex_overrides") or {}).get(coord) or (table.get("excel_font_hex_overrides") or {}).get(key2)
        if override is not None:
            return _rgb(override)
        try:
            color = get_excel_color(ws.cell(row=row_idx, column=col_idx))
            if color is not None:
                return color
        except Exception:
            pass
        return (0, 0, 0)
    if role == "header":
        return _rgb((table_style or {}).get("header_text_rgb"), (255, 255, 255))
    return _rgb((table_style or {}).get("table_body_text_rgb"), (255, 255, 255))


def _table_grid_values(table):
    grid_cells = list(table.get("grid_cells") or [])
    if grid_cells:
        return grid_cells
    cells = []
    header_idx = int(table.get("header_row_idx") or table.get("start_row") or 0)
    for col_idx, value in (table.get("header_row") or {}).items():
        cells.append({
            "row": header_idx,
            "col": int(col_idx),
            "row_pos": 0,
            "col_pos": int(col_idx) - int(table.get("min_col", 1)),
            "rowspan": 1,
            "colspan": 1,
            "value": value,
            "role": "header",
        })
    for row_dict, row_idx in zip(table.get("data_rows") or [], table.get("excel_row_map") or []):
        for col_idx, value in row_dict.items():
            cells.append({
                "row": int(row_idx),
                "col": int(col_idx),
                "row_pos": int(row_idx) - int(table.get("start_row", row_idx)),
                "col_pos": int(col_idx) - int(table.get("min_col", col_idx)),
                "rowspan": 1,
                "colspan": 1,
                "value": value,
                "role": "body",
            })
    return cells


TABLE_ICON_GAP_DEFAULT = 8


def ImageDraw_of(img):
    from PIL import ImageDraw as _ID

    return _ID.Draw(img)


def _safe_float(value, default=0.0):
    try:
        v = float(value)
    except (TypeError, ValueError):
        return default
    return v if v == v else default


def _side_strip(rect, side, w, bounds=None):
    """One side of a box's line, `w` px wide: on the table's outside edge it lies inside the box; between
    two boxes it is centred on their shared edge — the neighbour's line lands on the same pixels, so a
    1 px line is 1 px between boxes too (not two lines side by side)."""
    x0, y0, x1, y1 = rect
    w = max(1, int(w))
    a, b = w // 2, w - w // 2                     # px before / after the edge when centred
    tx0, ty0, tx1, ty1 = bounds or (x0, y0, x1, y1)
    edge = {"l": x0, "r": x1, "t": y0, "b": y1}[side]
    outer = (side == "l" and edge <= tx0 + 0.5) or (side == "r" and edge >= tx1 - 0.5) or \
            (side == "t" and edge <= ty0 + 0.5) or (side == "b" and edge >= ty1 - 0.5)
    if side in ("l", "r"):
        if outer:
            lo = x0 if side == "l" else x1 - w + 1
        else:
            lo = edge - a
        return [lo, y0 - (0 if y0 <= ty0 + 0.5 else a), lo + w - 1, y1 + (0 if y1 >= ty1 - 0.5 else b - 1)]
    if outer:
        lo = y0 if side == "t" else y1 - w + 1
    else:
        lo = edge - a
    return [x0 - (0 if x0 <= tx0 + 0.5 else a), lo, x1 + (0 if x1 >= tx1 - 0.5 else b - 1), lo + w - 1]


def _draw_excel_cell_borders(ldraw, ws, row_idx, col_idx, rowspan, colspan, rect, scale=1.0, bounds=None):
    """The lines Excel draws around this box (its own borders; a merged box: its outer cells')."""
    from .excel_utils import get_excel_border

    try:
        tl = get_excel_border(ws.cell(row=row_idx, column=col_idx))
        right = get_excel_border(ws.cell(row=row_idx, column=col_idx + colspan - 1)).get("right")
        bottom = get_excel_border(ws.cell(row=row_idx + rowspan - 1, column=col_idx)).get("bottom")
    except Exception:
        return
    x0, y0, x1, y1 = rect
    for side, spec in (("left", tl.get("left")), ("top", tl.get("top")), ("right", right), ("bottom", bottom)):
        if not spec:
            continue
        w = max(1, int(round(spec[0] * max(1.0, scale))))
        col = tuple(spec[1]) + (255,)
        ldraw.rectangle(_side_strip((x0, y0, x1, y1), side[0], w, bounds), fill=col)


def _composite_table_lines(base, lines, fx_name=None):
    """Put the table's lines layer on the page — with its own layer style when it has one."""
    box = lines.getbbox()
    if not box:
        return
    fx = fx_by_name(_tsx_lib(), fx_name) if fx_name else None
    if fx:
        try:
            from . import ps_fx_png

            styled, pad = ps_fx_png.render_layer_image(lines.crop(box), fx)
            if styled is not None:
                base.alpha_composite(styled.convert("RGBA"), (box[0] - pad, box[1] - pad))
                return
        except Exception:
            pass
    base.alpha_composite(lines)


def _tsx_lib():
    from . import text_styles as _tsx

    return _tsx.library()


def _table_layout(table_style, table):
    """This table's own sizes and text (Tables preview handles), by its design key:
    {scale, width, height, cols: [fractions], row_h: [px], icon_scale (%),
     header / body: {font, size, color, bold, italic, fx}}. Sizes are at scale 1."""
    from . import table_rows as _tr

    return _tr.piece_layout((table_style or {}).get("table_layouts") or {}, table.get("design_key") or "")


def table_geo_from(geo, left):
    """A table's geometry with x measured from `left` (the page's body edge the strip is cropped at) —
    its columns' start and the icons drawn in its boxes alike."""
    g = dict(geo, x=float(geo.get("x", left)) - left)
    if geo.get("icons"):
        g["icons"] = [dict(i, rect=[i["rect"][0] - left] + list(i["rect"][1:])) for i in geo["icons"]]
    return g


def _draw_auto_table(base, draw, Image, ImageFont, ws, table, x, y, safe_width, table_style, icon_folder, icon_mappings, icon_size_overrides, available_height=None, geo=None, row_slice=None):
    """Draw an Excel table; returns its height. `geo` (a dict) receives where its columns and
    rows landed (canvas px) — the Tables preview puts its handles there. `row_slice` (a, b): only
    the header rows and data rows a..b-1, sized exactly as in the whole table — one part of a
    table split across pages, each part with the same header row."""
    cells = _table_grid_values(table)
    if not cells:
        return 0
    if table.get("design") and table.get("design") != "current":
        from . import table_designs as _td

        table_style = _td.apply(table_style, table["design"])     # this table's own look
    lay = _table_layout(table_style, table)
    if isinstance(lay.get("style"), dict) and lay["style"]:
        from . import table_designs as _td2

        table_style = dict(table_style or {})
        table_style.update({k: v for k, v in lay["style"].items() if k in _td2.DESIGN_KEYS and v not in (None, "")})
    try:
        scale = max(0.2, min(5.0, float(lay.get("scale") or 1.0)))   # corner handles: everything together
    except (TypeError, ValueError):
        scale = 1.0
    hdr = lay.get("header") if isinstance(lay.get("header"), dict) else {}
    bdy = lay.get("body") if isinstance(lay.get("body"), dict) else {}
    pad_x = max(10, _safe_int((table_style or {}).get("cell_padding_x", 10), 10))
    pad_y = max(5, _safe_int((table_style or {}).get("cell_padding_y", 5), 5))
    header_size = _safe_int(hdr.get("size"), 0) or _safe_int((table_style or {}).get("table_header_font_size"), 0) or 28
    body_size = _safe_int(bdy.get("size"), 0) or _safe_int((table_style or {}).get("table_body_font_size"), 0) or 24
    header_font_name = hdr.get("font") or (table_style or {}).get("table_header_font_name") or ""
    body_font_name = bdy.get("font") or (table_style or {}).get("table_body_font_name") or ""
    header_bold = hdr.get("bold") is not False                    # headers are bold unless switched off
    table_icon_h = _safe_int((table_style or {}).get("table_icon_height"), 0) or body_size
    try:
        # every icon of this table (lay.icon_scale) × every icon of every table (table_icon_scale)
        table_icon_h = table_icon_h * max(0.2, min(5.0, float(lay.get("icon_scale") or 100) / 100.0)) \
            * max(0.2, min(5.0, float((table_style or {}).get("table_icon_scale") or 100) / 100.0))
    except (TypeError, ValueError):
        pass
    # space between an icon and the words beside it (Tables panel); icons never touch text
    gap_l = max(0, _safe_int((table_style or {}).get("table_icon_gap_left"), TABLE_ICON_GAP_DEFAULT))
    gap_r = max(0, _safe_int((table_style or {}).get("table_icon_gap_right"), TABLE_ICON_GAP_DEFAULT))
    if abs(scale - 1.0) > 0.001:
        pad_x, pad_y = max(2, int(round(pad_x * scale))), max(1, int(round(pad_y * scale)))
        header_size, body_size = max(6, int(round(header_size * scale))), max(6, int(round(body_size * scale)))
        gap_l, gap_r = int(round(gap_l * scale)), int(round(gap_r * scale))
        table_icon_h = table_icon_h * scale
    table_icon_h = max(4, int(round(table_icon_h)))
    header_font = _load_font(ImageFont, header_font_name, header_size, bold=header_bold, italic=bool(hdr.get("italic")))
    body_font = _load_font(ImageFont, body_font_name, body_size, bold=bool(bdy.get("bold")), italic=bool(bdy.get("italic")))
    base_sizes = {"header": header_size, "body": body_size}
    # boxes styled on the Canvas: "cells" one by one ("row index,column index" in the whole table), and
    # "boxes" for many at once — "all" (every box), "header" / "body" (every box of that role),
    # "row:N" / "col:N" (a whole row / column). A box takes them in that order, its own setting last.
    own_cells = lay.get("cells") if isinstance(lay.get("cells"), dict) else {}
    own_boxes = lay.get("boxes") if isinstance(lay.get("boxes"), dict) else {}
    # one icon's size: in this box (cells[r,c].icons), in this table (lay.icons), in every table
    # (table_style.table_icon_sizes) — the closest wins, written into the token as <WILD~140>
    from . import icon_scales as _isc

    _dict = lambda v: v if isinstance(v, dict) else {}     # noqa: E731
    _icons_all = _dict((table_style or {}).get("table_icon_sizes"))
    _icons_tab = _dict(lay.get("icons"))
    # the same in px — the icon's height as drawn (what the Icon bar shows and the handle sets):
    # one icon in a box / in this table / in every table, every icon of this table / of every table
    _px_all = _dict((table_style or {}).get("table_icon_sizes_px"))
    _px_tab = _dict(lay.get("icons_px"))
    _px_tab_all = _safe_float(lay.get("icon_px"), 0.0)
    _px_all_all = _safe_float((table_style or {}).get("table_icon_px"), 0.0)

    def sized_icons(text, cell):
        if "<" not in text or not (_icons_all or _icons_tab or own_cells or _px_all or _px_tab or _px_tab_all or _px_all_all):
            return text
        try:
            rc = f"{all_rows.index(int(cell.get('row')))},{columns.index(int(cell.get('col')))}"
        except ValueError:
            rc = ""
        own_c = own_cells.get(rc) if isinstance(own_cells.get(rc), dict) else {}
        mine, mine_px = _dict(own_c.get("icons")), _dict(own_c.get("icons_px"))

        def tag(m):
            tok = m.group(1)
            if "~" in tok:
                return m.group(0)
            k = _isc.compact(tok)
            # the closest wins: this box › this table › every table (px, else the older %), then every icon
            for d, px in ((mine_px, True), (mine, False), (_px_tab, True), (_icons_tab, False), (_px_all, True), (_icons_all, False)):
                v = d.get(k)
                if v in (None, "") or (not px and v == 100):
                    continue
                try:
                    pct = float(v) * 100.0 / max(1.0, float(table_icon_h)) if px else float(v)
                except (TypeError, ValueError):
                    continue
                return f"<{tok}~{pct:.1f}>"
            every = _px_tab_all or _px_all_all
            if every:
                return f"<{tok}~{every * 100.0 / max(1.0, float(table_icon_h)):.1f}>"
            return m.group(0)
        return re.sub(r"<([^<>\n]+)>", tag, text)

    def cell_spec(cell):
        if not own_cells and not own_boxes:
            return {}
        try:
            # by its row in the WHOLE table: a part of a split table (row_slice) keeps the same numbers
            r, c = all_rows.index(int(cell.get("row"))), columns.index(int(cell.get("col")))
        except ValueError:
            return {}
        spec = {}
        for part in (own_boxes.get("all"), own_boxes.get("header" if str(cell.get("role") or "") == "header" else "body"),
                     own_boxes.get(f"col:{c}"), own_boxes.get(f"row:{r}"), own_cells.get(f"{r},{c}")):
            if isinstance(part, dict):
                spec.update({k: v for k, v in part.items() if v not in (None, "")})
        return spec

    def cell_font(cell, role):
        """The box's own font (its size follows the table's scale and any fit-to-page shrink)."""
        spec = cell_spec(cell)
        role_font = header_font if role == "header" else body_font
        if not any(spec.get(k) not in (None, "") for k in ("font", "size", "bold", "italic")):
            return role_font
        role_spec = hdr if role == "header" else bdy
        now = header_size if role == "header" else body_size
        try:
            size = float(spec.get("size") or 0)       # a box's size as typed (a scaled table keeps it unrounded)
        except (TypeError, ValueError):
            size = 0.0
        size = max(6, int(round(size * scale * now / max(1, base_sizes[role])))) if size > 0 else now
        bold = spec["bold"] if spec.get("bold") is not None else (header_bold if role == "header" else bool(bdy.get("bold")))
        italic = spec["italic"] if spec.get("italic") is not None else bool(role_spec.get("italic"))
        name = spec.get("font") or (header_font_name if role == "header" else body_font_name)
        return _load_font(ImageFont, name, size, bold=bool(bold), italic=bool(italic))
    col_min = int(table.get("min_col", min(c["col"] for c in cells)))
    col_max = int(table.get("max_col", max(c["col"] for c in cells)))
    rows = sorted({int(c.get("row")) for c in cells})
    all_rows = list(rows)                          # every row of the table (rows becomes one part's when cut)
    columns = list(range(col_min, col_max + 1))
    col_widths = {col: 1 for col in columns}
    row_heights = {row: 1 for row in rows}
    for cell in cells:
        role = str(cell.get("role") or "body")
        font = cell_font(cell, role)
        text = "" if cell_spec(cell).get("clear") else sized_icons(_text(cell.get("value")), cell)     # a cell deleted / its icons sized
        content_w, content_h = _measure_inline(draw, Image, text, font, icon_folder, icon_mappings, table_icon_h, icon_size_overrides, gap_l, gap_r)
        colspan = max(1, _safe_int(cell.get("colspan"), 1))
        rowspan = max(1, _safe_int(cell.get("rowspan"), 1))
        per_col_w = int(math.ceil((content_w + pad_x * 2) / colspan))
        for col in range(int(cell.get("col")), int(cell.get("col")) + colspan):
            if col in col_widths:
                col_widths[col] = max(col_widths[col], per_col_w)
        # a merged cell's height is shared by the rows it spans that the table really has
        # (Excel merges can cover an empty row the table skips: it must not take half the height)
        spanned = [r for r in range(int(cell.get("row")), int(cell.get("row")) + rowspan) if r in row_heights] or [int(cell.get("row"))]
        per_row_h = int(math.ceil((content_h + pad_y * 2) / len(spanned)))
        for row in range(int(cell.get("row")), int(cell.get("row")) + rowspan):
            if row in row_heights:
                row_heights[row] = max(row_heights[row], per_row_h)

    row_gap = _safe_int((table_style or {}).get("row_gap"), 0)
    if abs(scale - 1.0) > 0.001:
        row_gap = max(0, int(round(row_gap * scale)))

    def recompute_row_heights():
        heights = {row: 1 for row in rows}
        for item in cells:
            role = str(item.get("role") or "body")
            font = cell_font(item, role)
            # as it is drawn: a deleted box is empty, sized icons at their own height (a row never shorter than its icon)
            text = "" if cell_spec(item).get("clear") else sized_icons(_text(item.get("value")), item)
            colspan = max(1, _safe_int(item.get("colspan"), 1))
            rowspan = max(1, _safe_int(item.get("rowspan"), 1))
            col_idx = int(item.get("col"))
            cell_width = sum(col_widths.get(col, 0) for col in range(col_idx, col_idx + colspan))
            content_width = max(1, cell_width - pad_x * 2)
            _content_w, content_h = _wrapped_inline_size(
                draw, Image, text, font, content_width, icon_folder, icon_mappings,
                table_icon_h, icon_size_overrides, line_spacing=2, icon_gap_left=gap_l, icon_gap_right=gap_r,
            )
            spanned = [r for r in range(int(item.get("row")), int(item.get("row")) + rowspan) if r in heights] or [int(item.get("row"))]
            per_row_h = int(math.ceil((content_h + pad_y * 2) / len(spanned)))
            for row in range(int(item.get("row")), int(item.get("row")) + rowspan):
                if row in heights:
                    heights[row] = max(heights[row], per_row_h)
        table_h = sum(heights.values()) + row_gap * max(0, len(rows) - 1)
        return heights, table_h

    total_width = sum(col_widths.values())
    # side handles / column dividers: the columns get wider or narrower, the content keeps its size
    own_w = _safe_int(lay.get("width"), 0) * scale
    fracs = [float(f) for f in (lay.get("cols") or []) if isinstance(f, (int, float)) and f > 0]
    if own_w > 0 or len(fracs) == len(columns):
        width_now = min(float(safe_width), own_w) if own_w > 0 else float(total_width)
        if len(fracs) == len(columns):
            tot = sum(fracs)
            for col, f in zip(columns, fracs):
                col_widths[col] = max(8, int(round(width_now * f / tot)))
        else:
            k = width_now / max(1, total_width)
            for col in col_widths:
                col_widths[col] = max(8, int(round(col_widths[col] * k)))
        total_width = sum(col_widths.values())
    target_width = 0 if (own_w > 0 or fracs) else _safe_int((table_style or {}).get("table_target_width"), 0)
    target_height = _safe_int((table_style or {}).get("table_target_height"), 0)
    height_limits = []
    if available_height:
        height_limits.append(max(20.0, float(available_height)))
    if target_height > 0:
        height_limits.append(float(target_height))
    height_limit = min(height_limits) if height_limits else None
    fit_scale = 1.0
    if target_width > 0:
        fit_scale = min(fit_scale, target_width / max(1, total_width))
    if total_width > safe_width + 0.5:
        fit_scale = min(fit_scale, safe_width / max(1, total_width))
    if fit_scale < 0.999:
        fit_scale = max(0.12, fit_scale)
        for col in col_widths:
            col_widths[col] = max(8, int(col_widths[col] * fit_scale))
        for row in row_heights:
            row_heights[row] = max(8, int(row_heights[row] * fit_scale))
        pad_x = max(2, int(pad_x * fit_scale))
        pad_y = max(1, int(pad_y * fit_scale))
        header_size = max(6, int(header_size * fit_scale))
        body_size = max(6, int(body_size * fit_scale))
        table_icon_h = max(4, int(table_icon_h * fit_scale))
        gap_l, gap_r = int(round(gap_l * fit_scale)), int(round(gap_r * fit_scale))
        header_font = _load_font(ImageFont, header_font_name, header_size, bold=header_bold, italic=bool(hdr.get("italic")))
        body_font = _load_font(ImageFont, body_font_name, body_size, bold=bool(bdy.get("bold")), italic=bool(bdy.get("italic")))
        row_gap = max(0, int(row_gap * fit_scale))
        total_width = sum(col_widths.values())
    for _attempt in range(4):
        row_heights, total_height = recompute_row_heights()
        if not height_limit or total_height <= height_limit:
            break
        height_scale = max(0.12, height_limit / max(1, total_height))
        if height_scale >= 0.995:
            break
        pad_x = max(2, int(pad_x * height_scale))
        pad_y = max(1, int(pad_y * height_scale))
        header_size = max(6, int(header_size * height_scale))
        body_size = max(6, int(body_size * height_scale))
        table_icon_h = max(4, int(table_icon_h * height_scale))
        gap_l, gap_r = int(round(gap_l * height_scale)), int(round(gap_r * height_scale))
        header_font = _load_font(ImageFont, header_font_name, header_size, bold=header_bold, italic=bool(hdr.get("italic")))
        body_font = _load_font(ImageFont, body_font_name, body_size, bold=bool(bdy.get("bold")), italic=bool(bdy.get("italic")))
        row_gap = max(0, int(row_gap * height_scale))
    else:
        row_heights, total_height = recompute_row_heights()
    # row lines / bottom handle: rows taller (never shorter than their content), content centred
    for i, h in enumerate(lay.get("row_h") or []):
        if i < len(rows) and isinstance(h, (int, float)) and h > 0:
            row_heights[rows[i]] = max(row_heights[rows[i]], int(round(h * scale)))
    own_h = _safe_int(lay.get("height"), 0) * scale
    total_height = sum(row_heights.values()) + row_gap * max(0, len(rows) - 1)
    if own_h > total_height and rows:
        extra = (own_h - total_height) / len(rows)
        for row in rows:
            row_heights[row] = int(round(row_heights[row] + extra))
        total_height = sum(row_heights.values()) + row_gap * max(0, len(rows) - 1)
    # the header rows (repeated on each ✂ part): the table's own when the artist set rows / columns
    # (a header column or a header row lower down only takes the header look), else its header cells' rows
    header_set = ({int(r) for r in table["head_rows"]} if isinstance(table.get("head_rows"), list)
                  else {int(c.get("row")) for c in cells if str(c.get("role") or "") == "header"})
    head_rows = [r for r in rows if r in header_set]
    if row_slice is not None:                      # one part of a split table: header + its rows
        body_rows = [r for r in rows if r not in header_set]
        a, b = row_slice
        rows = head_rows + body_rows[max(0, int(a)):max(0, int(b))]
    text_fx = {}
    for role, spec in (("header", hdr), ("body", bdy)):
        if spec.get("fx"):
            from . import text_styles as _tsx

            text_fx[role] = fx_by_name(_tsx.library(), spec.get("fx"))

    # boxes the artist deleted draw nothing; a column / row whose boxes are all deleted takes no room
    if own_cells or own_boxes:
        gone = [c for c in cells if cell_spec(c).get("clear")]
        if gone:
            plain = lambda c: max(1, _safe_int(c.get("colspan"), 1)) == 1 and max(1, _safe_int(c.get("rowspan"), 1)) == 1   # noqa: E731
            gone_set = {(int(c.get("row")), int(c.get("col"))) for c in gone}
            for col in columns:
                mine = [c for c in cells if int(c.get("col")) == col and int(c.get("row")) in row_heights]
                if mine and all((int(c.get("row")), col) in gone_set and plain(c) for c in mine):
                    col_widths[col] = 0
            for row in list(row_heights):
                mine = [c for c in cells if int(c.get("row")) == row]
                if mine and all((row, int(c.get("col"))) in gone_set and plain(c) for c in mine):
                    row_heights[row] = 0
            total_width = sum(col_widths.values())
            total_height = sum(row_heights.values()) + row_gap * max(0, len([r for r in rows if row_heights.get(r)]) - 1)
    align = str((table_style or {}).get("table_alignment") or "center").casefold()
    if align == "left":
        table_x = x
    elif align == "right":
        table_x = x + safe_width - total_width
    else:
        table_x = x + (safe_width - total_width) / 2.0
    row_tops = {}
    yy = y
    for row in rows:
        row_tops[row] = yy
        yy += row_heights[row] + (row_gap if row_heights[row] else 0)
    col_lefts = {}
    xx = table_x
    for col in columns:
        col_lefts[col] = xx
        xx += col_widths[col]
    # the table's outside edges: lines there lie inside it, lines between boxes are shared
    t_bounds = (table_x, y, table_x + sum(col_widths.values()),
                max((row_tops[r] + row_heights[r] for r in rows if r in row_tops), default=y))

    stroke_w = _safe_int((table_style or {}).get("stroke_width"), 1)
    stroke_color = _rgb((table_style or {}).get("stroke_rgb"), (255, 255, 255))
    # every line of the table goes on one layer (it can take a layer style):
    # "design" = the design's grid (Like Excel: Excel's own borders), "none", "all" = every box outlined
    lines_mode = str(lay.get("lines") or "design")
    excel_lines = lines_mode == "design" and bool(table.get("excel_blank_white"))
    if lines_mode == "all":
        stroke_w = max(1, _safe_int(lay.get("line_width"), stroke_w or 1))
        stroke_color = _rgb(lay.get("line_color"), stroke_color)
    stroke_w = int(round(stroke_w * scale)) if stroke_w > 0 else 0
    lines = Image.new("RGBA", base.size, (0, 0, 0, 0))
    ldraw = ImageDraw_of(lines)
    # each box's look as drawn ("row,col" in the whole table): what copying a box takes on the Canvas —
    # its fill and text from the Excel, the preset or the artist alike
    looks = {}
    icon_rects = []                                   # every icon drawn in the table's boxes (the Canvas picks them)

    def look_of(cell):
        return looks.setdefault(f"{all_rows.index(int(cell.get('row')))},{columns.index(int(cell.get('col')))}", {})

    def hex_of(rgb):
        return "#%02x%02x%02x" % tuple(int(v) for v in rgb[:3])

    for cell in cells:
        row_idx = int(cell.get("row"))
        if row_idx not in row_tops:
            continue                               # a row of another part of a split table
        col_idx = int(cell.get("col"))
        colspan = max(1, _safe_int(cell.get("colspan"), 1))
        rowspan = max(1, _safe_int(cell.get("rowspan"), 1))
        left = col_lefts.get(col_idx, table_x)
        top = row_tops.get(row_idx, y)
        width = sum(col_widths.get(col, 0) for col in range(col_idx, col_idx + colspan))
        spanned = [row for row in range(row_idx, row_idx + rowspan) if row in row_tops]
        height = sum(row_heights.get(row, 0) for row in spanned) + row_gap * max(0, len(spanned) - 1)
        role = str(cell.get("role") or "body")
        cell_rect = [left, top, left + width, top + height]
        cell_render_mode = _effective_render_mode(role, row_idx, table_style)
        own = cell_spec(cell)
        if own.get("clear") or width <= 0 or height <= 0:
            continue                               # deleted: no fill, no lines, no text
        if own.get("fill"):
            draw.rectangle(cell_rect, fill=_rgb(own["fill"]))
            look_of(cell)["fill"] = hex_of(_rgb(own["fill"]))
        elif cell_render_mode in {"fill", "both"}:
            fill = _cell_fill_for_table(ws, table, row_idx, col_idx, role, table_style)
            if fill is not None:
                draw.rectangle(cell_rect, fill=fill)
                look_of(cell)["fill"] = hex_of(fill)
        if excel_lines:
            _draw_excel_cell_borders(ldraw, ws, row_idx, col_idx, rowspan, colspan, cell_rect, scale, t_bounds)
        elif stroke_w > 0 and (lines_mode == "all" or (lines_mode == "design" and cell_render_mode in {"stroke", "both"})):
            for side in "tblr":                    # each line once, at its width (shared with the neighbour)
                ldraw.rectangle(_side_strip(cell_rect, side, stroke_w, t_bounds), fill=stroke_color)

    # a box's own border, over its neighbours' lines; a border around the whole table
    for cell in cells if (own_cells or own_boxes) else []:
        own = cell_spec(cell)
        bw = _safe_int(own.get("border_width"), 0)
        if own.get("clear") or not own.get("border") or bw <= 0 or int(cell.get("row")) not in row_tops:
            continue
        row_idx, col_idx = int(cell.get("row")), int(cell.get("col"))
        colspan, rowspan = max(1, _safe_int(cell.get("colspan"), 1)), max(1, _safe_int(cell.get("rowspan"), 1))
        left, top = col_lefts.get(col_idx, table_x), row_tops.get(row_idx, y)
        width = sum(col_widths.get(col, 0) for col in range(col_idx, col_idx + colspan))
        height = sum(row_heights.get(row, 0) for row in range(row_idx, row_idx + rowspan)) + row_gap * max(0, rowspan - 1)
        bpx, bcol = max(1, int(round(bw * scale))), _rgb(own["border"])
        sides = "".join(c for c in str(own.get("border_sides") or "tblr").lower() if c in "tblr") or "tblr"
        # its sides (all, or the Cell bar's ⊞ choice) over the shared lines, at their width — between two
        # boxes centred on the shared edge (over the neighbour's line, never beside it)
        for side in "tblr":
            if side in sides:
                ldraw.rectangle(_side_strip((left, top, left + width, top + height), side, bpx, t_bounds), fill=bcol)
    outer = lay.get("outer") if isinstance(lay.get("outer"), dict) else {}
    if outer.get("color") and _safe_int(outer.get("width"), 0) > 0 and rows:
        t_bottom = max(row_tops.values()) + row_heights[rows[-1]]
        ldraw.rectangle([table_x, y, table_x + sum(col_widths.values()), t_bottom], outline=_rgb(outer["color"]),
                        width=max(1, int(round(_safe_int(outer.get("width"), 1) * scale))))
    _composite_table_lines(base, lines, lay.get("lines_fx"))

    for cell in cells:
        row_idx = int(cell.get("row"))
        if row_idx not in row_tops:
            continue
        col_idx = int(cell.get("col"))
        colspan = max(1, _safe_int(cell.get("colspan"), 1))
        rowspan = max(1, _safe_int(cell.get("rowspan"), 1))
        left = col_lefts.get(col_idx, table_x)
        top = row_tops.get(row_idx, y)
        width = sum(col_widths.get(col, 0) for col in range(col_idx, col_idx + colspan))
        spanned = [row for row in range(row_idx, row_idx + rowspan) if row in row_tops]
        height = sum(row_heights.get(row, 0) for row in spanned) + row_gap * max(0, len(spanned) - 1)
        role = str(cell.get("role") or "body")
        font = cell_font(cell, role)
        own = cell_spec(cell)
        fill = _cell_font_color_for_table(ws, table, row_idx, col_idx, role, table_style)
        own_color = own.get("color") or (hdr if role == "header" else bdy).get("color")
        if own_color:
            fill = _rgb(own_color, fill)
        text = "" if own.get("clear") else sized_icons(_text(cell.get("value")), cell)   # a cell deleted / its icons sized
        _w, text_h = _wrapped_inline_size(
            draw, Image, text, font, max(1, width - pad_x * 2),
            icon_folder, icon_mappings, table_icon_h, icon_size_overrides, line_spacing=2,
            icon_gap_left=gap_l, icon_gap_right=gap_r,
        )
        content_y = top + max(pad_y, (height - text_h) / 2.0)
        cell_align = (table_style or {}).get("table_header_alignment") if role == "header" else (table_style or {}).get("table_body_alignment")
        if table.get("excel_blank_white"):            # Like Excel: the cell's own alignment
            try:
                xa = str(ws.cell(row=row_idx, column=col_idx).alignment.horizontal or "").lower()
                if xa in ("left", "center", "right"):
                    cell_align = xa
                elif xa in ("", "general") and not isinstance(cell.get("value"), (int, float)):
                    cell_align = "left" if not str(cell.get("value") or "").strip().replace(".", "").isdigit() else "right"
            except Exception:
                pass
        if own.get("align") in ("left", "center", "right"):
            cell_align = own["align"]
        role_spec = hdr if role == "header" else bdy
        look = look_of(cell)
        look.update(color=hex_of(fill), font=own.get("font") or (header_font_name if role == "header" else body_font_name) or "",
                    bold=bool(own["bold"] if own.get("bold") is not None else (header_bold if role == "header" else bdy.get("bold"))),
                    italic=bool(own["italic"] if own.get("italic") is not None else role_spec.get("italic")),
                    align=cell_align or "center")
        for k in ("size", "border", "border_width", "border_sides", "fx"):
            if own.get(k) not in (None, ""):
                look[k] = own[k]
        _ICON_SINK.list = [] if isinstance(geo, dict) and "<" in text else None
        try:
            _draw_inline(
                base, draw, Image, text, left + pad_x, content_y, font, fill,
                max(1, width - pad_x * 2), icon_folder, icon_mappings, table_icon_h,
                icon_size_overrides, align=cell_align or "center", line_spacing=2,
                icon_gap_left=gap_l, icon_gap_right=gap_r,
                fx_config=(fx_by_name(_tsx_lib(), own["fx"]) if own.get("fx") else text_fx.get(role)),
            )
            if _ICON_SINK.list:                           # where its icons landed: the Canvas picks one there
                try:
                    _rc = f"{all_rows.index(int(cell.get('row')))},{columns.index(int(cell.get('col')))}"
                except ValueError:
                    _rc = ""
                for _tok, _ix, _iy, _iw, _ih in _ICON_SINK.list:
                    icon_rects.append({"cell": _rc, "tok": _isc.compact(_isc.strip(_tok)), "name": _isc.strip(_tok),
                                       "rect": [int(_ix), int(_iy), int(_iw), int(_ih)]})
        finally:
            _ICON_SINK.list = None
    if isinstance(geo, dict):
        # a box's span in rows the table DRAWS: an Excel merge over an empty row the table skips (a header
        # merged with the blank row under it) is one row here — else the Canvas reads the next row as part
        # of that box (clicking it picks the box, the box's frame covers it)
        drawn = set(rows)
        geo["cells"] = [[rows.index(int(c.get("row"))), columns.index(int(c.get("col"))),
                         max(1, sum(1 for r in range(int(c.get("row")), int(c.get("row")) + max(1, _safe_int(c.get("rowspan"), 1))) if r in drawn)),
                         max(1, _safe_int(c.get("colspan"), 1))]
                        for c in cells if int(c.get("row")) in rows and int(c.get("col")) in columns]
        geo["looks"] = looks
        geo["icons"] = icon_rects
        geo.update({"x": float(table_x), "y": float(y), "cols": [int(col_widths[c]) for c in columns],
                    "rows": [int(row_heights[r]) for r in rows], "row_gap": int(row_gap), "scale": scale,
                    "header_rows": len([r for r in rows if r in header_set]),
                    # where the Canvas writes a row's / column's role (table_rows.py): every row of the
                    # whole table as its offset from the table's first row, and its rows drawn as text
                    "rows_key": table.get("rows_key") or table.get("design_key") or "",
                    "row_offs": [r - int(table.get("rows_start") or table.get("start_row") or 0) for r in all_rows],
                    "text_rows": list(table.get("text_rows") or []),
                    "header_size": header_size, "body_size": body_size, "icon_h": table_icon_h})
    return int(max(row_tops.values()) + row_heights[rows[-1]] - y) if rows else 0


def _slot_box(slot):
    if not isinstance(slot, dict):
        return None
    try:
        x = float(slot.get("x", slot.get("left", 0)) or 0)
        y = float(slot.get("y", slot.get("top", 0)) or 0)
        w = float(slot.get("w", slot.get("width", 0)) or 0)
        h = float(slot.get("h", slot.get("height", 0)) or 0)
    except Exception:
        return None
    if w <= 0 or h <= 0:
        return None
    return x, y, w, h



def _mapped_table_slot_boxes(record, mapped_only=True):
    """Return drawable mapped-table slot boxes.

    Important for PNG pagination: mapper JSON files can contain extra page/helper
    slots.  A mapped table should use only slots referenced by spec.mappings;
    otherwise natural_h becomes the height of the whole JSON/template and the
    table gets pushed to a Continued page even when its actual mapped slots fit.
    """
    slots = record.get("slots") or {}
    all_boxes = {name: _slot_box(slot) for name, slot in slots.items()}
    all_boxes = {name: box for name, box in all_boxes.items() if box}
    if not all_boxes or not mapped_only:
        return all_boxes

    mappings = list((record.get("spec") or {}).get("mappings") or [])
    used = {str(mapping.get("slot") or "").strip().casefold() for mapping in mappings if str(mapping.get("slot") or "").strip()}
    if not used:
        return all_boxes

    filtered = {name: box for name, box in all_boxes.items() if str(name).strip().casefold() in used}
    return filtered or all_boxes


def _truthy_json_flag(value):
    if isinstance(value, bool):
        return value
    return str(value or "").strip().casefold() in {"1", "true", "yes", "on", "enabled"}


def _mapped_table_flow_margin_before(spec):
    """Small flow gap before mapped JSON tables.

    Old PNG behavior respected mapper/template absolute_y, which left a large
    blank area between normal text and the mapped table.  For normal flowing
    pages, use a small y + margin flow gap instead.
    
    Override keys:
      png_margin_before / flow_margin_before: exact PNG flow gap
      margin_before: legacy value, capped to 8px for PNG flow
    """
    spec = spec or {}
    if spec.get("png_margin_before") not in (None, ""):
        return max(0, _safe_int(spec.get("png_margin_before"), 8))
    if spec.get("flow_margin_before") not in (None, ""):
        return max(0, _safe_int(spec.get("flow_margin_before"), 8))
    return max(0, min(_safe_int(spec.get("margin_before"), 20), 8))


def _mapped_table_respect_absolute_y(spec):
    """Return True only when JSON explicitly requests fixed vertical position."""
    spec = spec or {}
    if _truthy_json_flag(spec.get("png_respect_absolute_y")):
        return True
    if _truthy_json_flag(spec.get("respect_absolute_y")):
        return True
    if _truthy_json_flag(spec.get("use_absolute_y")):
        return True
    if str(spec.get("position_mode") or "").strip().casefold() in {"absolute", "fixed", "locked"}:
        return True
    return False


def _mapped_table_respect_absolute_x(spec):
    """Return True only when JSON explicitly requests fixed horizontal position.

    Mapper JSONs often save absolute_x from the design template. For normal PNG
    pages that should flow with body text, respecting absolute_x can make the
    table look shifted right/left. Default PNG behavior is therefore centered
    inside the normal safe content width unless this is explicitly enabled.
    """
    spec = spec or {}
    if _truthy_json_flag(spec.get("png_respect_absolute_x")):
        return True
    if _truthy_json_flag(spec.get("respect_absolute_x")):
        return True
    if _truthy_json_flag(spec.get("use_absolute_x")):
        return True
    if str(spec.get("position_mode") or "").strip().casefold() in {"absolute", "fixed", "locked"}:
        return True
    return False


def _mapped_table_flow_x(spec, x, safe_width, rendered_width):
    """Horizontal placement for flowing mapped JSON tables.

    Default: center in the page safe area.
    Optional JSON/spec keys: png_horizontal_align / horizontal_align / alignment.
    """
    spec = spec or {}
    if _mapped_table_respect_absolute_x(spec) and spec.get("absolute_x") not in (None, ""):
        try:
            return float(spec.get("absolute_x"))
        except Exception:
            pass

    align = str(
        spec.get("png_horizontal_align")
        or spec.get("horizontal_align")
        or spec.get("table_align")
        or spec.get("alignment")
        or "center"
    ).strip().casefold()

    x = float(x)
    safe_width = float(safe_width)
    rendered_width = float(rendered_width)

    if align == "left":
        return x
    if align == "right":
        return x + max(0.0, safe_width - rendered_width)
    return x + max(0.0, (safe_width - rendered_width) / 2.0)

def _draw_mapped_table(
    base, draw, Image, ImageFont, ws, record, x, y, safe_width, icon_folder,
    icon_mappings, icon_size_overrides, report, available_height=None, safe_bottom=None,
):
    """Draw one mapped JSON table as a clipped RGBA composition.

    Fixes two PNG-only mapper bugs:
    - Each JSON slot is rendered into its own transparent buffer, so text/icons
      cannot bleed outside the mapped slot bounds.
    - Text uses the slot/mapping font, size, color, padding, alignment and
      minimum-size values before falling back to defaults.
    """
    _, ImageDraw, _ = _require_pillow()

    slots = record.get("slots") or {}
    slot_boxes = _mapped_table_slot_boxes(record, mapped_only=True)
    if not slot_boxes:
        _warn(report, f"PNG mapped table skipped: no drawable mapped slots in {record.get('path')}")
        return 0

    min_x = min(box[0] for box in slot_boxes.values())
    min_y = min(box[1] for box in slot_boxes.values())
    max_x = max(box[0] + box[2] for box in slot_boxes.values())
    max_y = max(box[1] + box[3] for box in slot_boxes.values())
    natural_w = max(1.0, max_x - min_x)
    natural_h = max(1.0, max_y - min_y)

    spec = record.get("spec") or {}
    margin_before = _mapped_table_flow_margin_before(spec)
    margin_after = max(0, _safe_int(spec.get("margin_after"), 20))

    # Normal PNG pages should flow JSON tables directly after text.  Do not use
    # template absolute_y unless the JSON explicitly opts into fixed placement.
    scale = min(1.0, float(safe_width) / natural_w)
    if _mapped_table_respect_absolute_y(spec) and spec.get("absolute_y") not in (None, ""):
        try:
            table_y = float(spec.get("absolute_y"))
        except Exception:
            table_y = float(y) + margin_before
    else:
        table_y = float(y) + margin_before

    height_limits = []
    if available_height:
        height_limits.append(max(20.0, float(available_height) - margin_before - margin_after))
    if safe_bottom is not None:
        height_limits.append(max(20.0, float(safe_bottom) - table_y - margin_after))
    if height_limits:
        scale = min(scale, min(height_limits) / natural_h)
    scale = max(0.12, min(8.0, scale))

    # Center flowing PNG JSON tables in the normal safe area.  Do not use
    # mapper/template absolute_x unless the JSON explicitly opts into it.
    table_x = _mapped_table_flow_x(spec, x, safe_width, natural_w * scale)

    combined_icons = {}
    combined_icons.update(record.get("icon_mappings") or {})
    combined_icons.update(icon_mappings or {})

    mappings = list((record.get("spec") or {}).get("mappings") or [])
    by_slot = {}
    for mapping in mappings:
        by_slot.setdefault(str(mapping.get("slot") or ""), []).append(mapping)

    def _slot_meta(slot_name):
        data = slots.get(slot_name) or {}
        return data if isinstance(data, dict) else {}

    def _first_present(*values, fallback=None):
        for value in values:
            if value is None:
                continue
            if isinstance(value, str) and not value.strip():
                continue
            return value
        return fallback

    def _scaled_box(box):
        sx, sy, sw, sh = box
        return {
            "x": table_x + (sx - min_x) * scale,
            "y": table_y + (sy - min_y) * scale,
            "w": max(1.0, sw * scale),
            "h": max(1.0, sh * scale),
        }

    def _padding_for(mapping, meta):
        padding = _first_present(mapping.get("padding"), meta.get("padding"), fallback=[0, 0, 0, 0])
        if isinstance(padding, (int, float, str)):
            padding = [padding, padding, padding, padding]
        padding = list(padding or []) + [0, 0, 0, 0]
        pad_t, pad_r, pad_b, pad_l = [max(0, int(round(_safe_int(v, 0) * scale))) for v in padding[:4]]
        return pad_t, pad_r, pad_b, pad_l

    def _content_box(slot_box, mapping, meta):
        pad_t, pad_r, pad_b, pad_l = _padding_for(mapping, meta)
        return {
            "x": slot_box["x"] + pad_l,
            "y": slot_box["y"] + pad_t,
            "w": max(1.0, slot_box["w"] - pad_l - pad_r),
            "h": max(1.0, slot_box["h"] - pad_t - pad_b),
        }

    # Background fills and strokes are drawn once per slot.
    rects = []
    for slot_name, raw_box in slot_boxes.items():
        slot_box = _scaled_box(raw_box)
        meta = _slot_meta(slot_name)
        slot_maps = by_slot.get(slot_name) or []

        bg = _first_present(meta.get("background_color"), meta.get("fill"), fallback=None)
        stroke = _first_present(meta.get("stroke_color"), meta.get("outline"), fallback=None)
        stroke_w = _safe_int(_first_present(meta.get("stroke_width"), fallback=0), 0)
        fill_enabled = bool(meta.get("fill_enabled")) or bg not in (None, "")
        stroke_enabled = bool(meta.get("stroke_enabled")) or stroke_w > 0

        for mapping in slot_maps:
            mapping_bg = _first_present(mapping.get("background_color"), mapping.get("fill"), fallback=None)
            if mapping_bg is not None:
                bg = mapping_bg
            stroke = _first_present(mapping.get("stroke_color"), mapping.get("outline"), stroke, fallback=stroke)
            stroke_w = max(stroke_w, _safe_int(mapping.get("stroke_width"), 0))
            fill_enabled = fill_enabled or bool(mapping.get("fill_enabled")) or mapping_bg is not None
            stroke_enabled = stroke_enabled or bool(mapping.get("stroke_enabled"))
        if not stroke_enabled and stroke_w > 0:
            stroke_enabled = True

        if fill_enabled and bg not in (None, ""):
            draw.rectangle(
                [slot_box["x"], slot_box["y"], slot_box["x"] + slot_box["w"], slot_box["y"] + slot_box["h"]],
                fill=_rgb(bg, (0, 0, 0)),
            )
        rects.append((slot_box, stroke, stroke_w, stroke_enabled))

    for slot_box, stroke, stroke_w, stroke_enabled in rects:
        stroke_w = max(0, int(round(float(stroke_w) * scale)))
        if stroke_enabled and stroke_w > 0:
            draw.rectangle(
                [slot_box["x"], slot_box["y"], slot_box["x"] + slot_box["w"], slot_box["y"] + slot_box["h"]],
                outline=_rgb(stroke, (255, 255, 255)),
                width=max(1, stroke_w),
            )

    # Text/icons are rendered into isolated buffers and then composited back.
    for mapping in mappings:
        slot_name = str(mapping.get("slot") or "")
        raw_box = slot_boxes.get(slot_name)
        if not raw_box:
            continue

        meta = _slot_meta(slot_name)
        slot_box = _scaled_box(raw_box)
        content_box = _content_box(slot_box, mapping, meta)
        buffer_w = max(1, int(math.ceil(content_box["w"])))
        buffer_h = max(1, int(math.ceil(content_box["h"])))
        if buffer_w <= 0 or buffer_h <= 0:
            continue

        kind = str(mapping.get("kind") or meta.get("kind") or "flow").casefold()
        requested_size = _safe_int(
            _first_present(mapping.get("font_size"), mapping.get("text_size"), meta.get("font_size"), meta.get("text_size"), fallback=24),
            24,
        )
        requested_size = max(4, int(round(requested_size * scale)))
        min_size = _safe_int(
            _first_present(mapping.get("minimum_font_size"), mapping.get("min_font_size"), meta.get("minimum_font_size"), meta.get("min_font_size"), fallback=requested_size),
            requested_size,
        )
        min_size = max(4, min(requested_size, int(round(min_size * scale))))
        font_name = _first_present(mapping.get("font_name"), mapping.get("font_family"), mapping.get("font"), meta.get("font_name"), meta.get("font_family"), meta.get("font"), fallback="")
        color = _rgb(_first_present(mapping.get("color"), mapping.get("text_rgb"), mapping.get("rgb"), meta.get("color"), meta.get("text_rgb"), meta.get("rgb"), fallback=(255, 255, 255)), (255, 255, 255))
        style_text = str(_first_present(mapping.get("font_style"), mapping.get("style"), meta.get("font_style"), meta.get("style"), fallback="")).casefold()
        bold = bool(_first_present(mapping.get("bold"), meta.get("bold"), fallback=False)) or "bold" in style_text or str(mapping.get("role") or "").casefold() == "heading"
        italic = bool(_first_present(mapping.get("italic"), meta.get("italic"), fallback=False)) or "italic" in style_text or "oblique" in style_text
        align = str(_first_present(mapping.get("alignment"), meta.get("alignment"), fallback="center") or "center").casefold()
        vertical_align = str(_first_present(mapping.get("vertical_align"), meta.get("vertical_align"), fallback="center") or "center").casefold()
        line_spacing_value = max(0, _safe_int(_first_present(mapping.get("line_spacing"), mapping.get("gap"), meta.get("line_spacing"), meta.get("gap"), fallback=2), 2))
        icon_h = max(1, int(round(_safe_int(_first_present(mapping.get("icon_height"), meta.get("icon_height"), fallback=requested_size), requested_size) * scale)))

        clip = Image.new("RGBA", (buffer_w, buffer_h), (0, 0, 0, 0))
        clip_draw = ImageDraw.Draw(clip)
        _psd_track_buffer(clip, base, int(round(content_box["x"])), int(round(content_box["y"])))

        if kind in {"icon", "dedicated_icon", "symbol"}:
            token = _first_present(mapping.get("token"), meta.get("token"), fallback="")
            if not token:
                token = resolve_table_token(ws, mapping.get("source"), mapping.get("token_index", 0))
            icon, _path = _load_icon(Image, token, icon_folder, combined_icons, icon_h, icon_size_overrides)
            if icon:
                icon = _fit_icon_to_box(Image, icon, {"x": 0, "y": 0, "w": buffer_w, "h": buffer_h})
                ix = int(round((buffer_w - icon.width) / 2.0))
                iy = int(round((buffer_h - icon.height) / 2.0))
                _psd_paste_icon(clip, icon, ix, iy, str(token).strip("<> ") or "icon")
            elif token:
                fallback_text = f"<{str(token).strip('<> ')}>"
                _draw_fitted_inline_in_box(
                    clip, clip_draw, Image, ImageFont, fallback_text,
                    {"x": 0, "y": 0, "w": buffer_w, "h": buffer_h},
                    font_name, requested_size, color, icon_folder, combined_icons, icon_h,
                    icon_size_overrides, align=align, vertical_align=vertical_align,
                    min_size=min_size, line_spacing=line_spacing_value, bold=bold, italic=italic,
                )
            base.alpha_composite(clip, (int(round(content_box["x"])), int(round(content_box["y"]))))
            continue

        text = ""
        if mapping.get("source") not in (None, ""):
            text = resolve_table_source_text(ws, mapping.get("source"))
        if not str(text or "").strip():
            text = _first_present(mapping.get("text"), mapping.get("value"), meta.get("text"), meta.get("value"), fallback="")
        text = str(text or "").strip()
        if not text:
            continue

        fit = _fit_png_inline_for_box(
            clip_draw, Image, ImageFont, text, font_name, requested_size, min_size,
            buffer_w, buffer_h, icon_folder, combined_icons, icon_h, icon_size_overrides,
            line_spacing=line_spacing_value, bold=bold, italic=italic,
        )
        if not fit:
            continue

        content_h = float(fit.get("height", 0))
        if vertical_align == "top":
            local_y = 0.0
        elif vertical_align == "bottom":
            local_y = max(0.0, buffer_h - content_h)
        else:
            local_y = max(0.0, (buffer_h - content_h) / 2.0)

        _draw_inline(
            clip, clip_draw, Image, text, 0, local_y, fit["font"], color, buffer_w,
            icon_folder, combined_icons, fit["icon_height"], icon_size_overrides,
            align=align, line_spacing=line_spacing_value,
        )
        base.alpha_composite(clip, (int(round(content_box["x"])), int(round(content_box["y"]))))

    rendered_bottom = table_y + natural_h * scale + margin_after
    return max(1, int(math.ceil(rendered_bottom - float(y))))

def _row_is_inside(row_idx, ranges):
    for start, end in ranges:
        if start <= row_idx <= end:
            return True
    return False


def _row_page_text(ws, row_idx, max_col_limit, min_col=1):
    values = []
    for col_idx in range(max(1, int(min_col or 1)), max_col_limit + 1):
        value = _text(ws.cell(row=row_idx, column=col_idx).value)
        if value and not value.casefold().startswith("<mod"):
            values.append(value)
    from . import text_edits

    # the artist's line breaks / joined lines (made on a preview), while the Excel text is unchanged
    from . import icon_scales

    sheet = getattr(ws, "title", "")
    text = text_edits.apply(sheet, f"row:{row_idx}", " ".join(values).strip())
    return icon_scales.apply(sheet, f"row:{row_idx}", text)       # icons the artist sized (Assets & Icons)


def _normalized_sheet_kind(name):
    compact = re.sub(r"[^a-z0-9]+", "", str(name or "").casefold())
    if compact.startswith("gamerules"):
        return "game_rules"
    if compact.startswith("bingorules"):
        return "bingo_rules"
    return ""


def _scoped_bodies_for_sheet(raw_value, sheet_name):
    bodies = []
    for line in _split_scoped_entries(raw_value):
        scope = ""
        body = line
        for separator in ("=", "|"):
            if separator in line:
                left, right = line.split(separator, 1)
                scope, body = left.strip(), right.strip()
                break
        if not scope and "!" in line:
            left, right = line.rsplit("!", 1)
            scope, body = left.strip(), right.strip()
        if scope and not _sheet_matches(scope, sheet_name):
            continue
        if body:
            bodies.append(body)
    return bodies


def _cell_split_for_sheet(raw_value, sheet_name):
    for body in reversed(_scoped_bodies_for_sheet(raw_value, sheet_name)):
        body = str(body or "").strip()
        try:
            min_c, min_r, _max_c, _max_r = range_boundaries(body)
            return min_r, min_c, f"{get_column_letter(min_c).upper()}{min_r}"
        except Exception:
            pass
        try:
            row_idx = int(body)
            if row_idx > 0:
                return row_idx, 1, str(row_idx)
        except Exception:
            pass
    return None


def _iter_clean_cells(ws, max_col_limit, skip_rows=None, skip_coords=None, min_row=1, max_row=None):
    skip_rows = set(skip_rows or [])
    skip_coords = {str(c).upper() for c in (skip_coords or set())}
    lower = max(1, _safe_int(min_row, 1))
    upper = min(ws.max_row or 1, _safe_int(max_row, ws.max_row or 1))
    for row_idx in range(lower, upper + 1):
        if row_idx in skip_rows:
            continue
        row_items = []
        for col_idx in range(1, max_col_limit + 1):
            coord = f"{get_column_letter(col_idx).upper()}{row_idx}"
            if coord in skip_coords:
                continue
            value = _text(ws.cell(row=row_idx, column=col_idx).value)
            if not value or value.casefold().startswith("<mod"):
                continue
            row_items.append((row_idx, col_idx, coord, value))
        if row_items:
            yield row_idx, row_items


def _draw_horizontal_rule(draw, canvas_w, y, width, height, rgb, alignment="center", margin=80):
    width = max(1, int(width))
    height = max(1, int(height))
    margin = max(0, int(margin))
    alignment = str(alignment or "center").casefold()
    if alignment == "left":
        x = margin
    elif alignment == "right":
        x = canvas_w - margin - width
    else:
        x = (canvas_w - width) / 2.0
    draw.rectangle([x, y, x + width, y + height], fill=tuple(rgb or (255, 255, 255)))


def _paste_side_icons(base, Image, asset_path, icon_width, outer_margin, center_y, y_offset=0, candidate_dirs=()):
    asset_path = _resolve_xtra_reels_asset(asset_path, candidate_dirs)
    if not asset_path or not os.path.isfile(asset_path):
        return
    try:
        icon = Image.open(asset_path).convert("RGBA")
        scale = max(1, int(icon_width)) / max(1, icon.width)
        icon = icon.resize((max(1, int(round(icon.width * scale))), max(1, int(round(icon.height * scale)))))
        y = int(round(center_y - icon.height / 2.0 + _safe_int(y_offset, 0)))
        margin = max(0, _safe_int(outer_margin, 0))
        base.alpha_composite(icon, (margin, y))
        base.alpha_composite(icon, (max(0, base.width - margin - icon.width), y))
    except Exception:
        return


# Photoshop's four Justify buttons: every line but the paragraph's last stretched to the box, the last
# one left / centred / right — or stretched too ("justify_all"; also what a caller drawing line by line
# passes for the lines inside a paragraph)
JUSTIFY_LAST = {"justify": "left", "justify_center": "center", "justify_right": "right", "justify_all": "justify_all"}


def justify_line_align(align, line_index, n_lines):
    """How one line of a paragraph is drawn: "justify_all" (stretched), "left", "center" or "right"."""
    a = str(align or "").lower()
    if a not in JUSTIFY_LAST:
        return a
    return "justify_all" if line_index < n_lines - 1 else JUSTIFY_LAST[a]


def _text_alignment(alignment_settings, sheet_name, role, fallback="center"):
    """left | center | right | justify (+ justify_center / justify_right / justify_all) for a page's
    "heading" or "body" text: the page's own alignment (the Canvas › This page, per-page overrides)
    when it has one, else the global setting."""
    al = alignment_settings or {}
    valid = ("left", "center", "right") + tuple(JUSTIFY_LAST)

    def norm(v, fb):
        v = str(v or "").strip().casefold()
        return {"centre": "center", "middle": "center"}.get(v, v) if v in valid + ("centre", "middle") else fb

    default = norm((al.get("global") or {}).get(role), fallback)
    if role == "heading" and default in JUSTIFY_LAST:
        default = "center"
    source = str(al.get("source") or "page_override").strip().casefold()
    if source in ("page_override", "page override if available, else global", "override"):
        overrides = al.get("overrides") or {}
        if isinstance(overrides, str):
            try:
                import json as _json

                overrides = _json.loads(overrides) if overrides.strip() else {}
            except Exception:
                overrides = {}
        own = overrides.get(sheet_name) if isinstance(overrides, dict) else None
        if own is None and isinstance(overrides, dict):
            own = next((v for k, v in overrides.items() if str(k).casefold() == str(sheet_name or "").casefold()), None)
        if isinstance(own, dict) and not bool(own.get("use_global", True)):
            return norm(own.get(role), default)
    return default


def _justify_runs(draw, runs, font, line_w, box_w):
    """A justified line's runs (live canvas): every space wider by the same share, as _draw_inline draws it."""
    spaces = sum(str(r.get("text") or "").count(" ") for r in runs if r.get("kind") != "icon")
    if not spaces or box_w <= line_w:
        return runs
    per = (box_w - line_w) / float(spaces)
    space_w = _measure_text(draw, " ", font)[0]
    out, shift = [], 0.0
    for r in runs:
        if r.get("kind") == "icon":
            out.append(dict(r, x=float(r.get("x") or 0) + shift))
            continue
        x = float(r.get("x") or 0) + shift
        words = str(r.get("text") or "").split(" ")
        styled_font = _styled_font(font, r.get("style")) if r.get("style") else font
        for wi, word in enumerate(words):
            if word:
                w = _advance(styled_font, word)
                out.append(dict(r, text=word, x=x, w=w))
                x += w
            if wi < len(words) - 1:
                x += space_w + per
                shift += per
    return out


def _alignment_overrides_for_sheet(raw_value, sheet_name):
    overrides = {}
    for line in _split_scoped_entries(raw_value):
        scope = ""
        body = line
        if "=" in line:
            left, right = line.split("=", 1)
            if _ranges_from_text(right):
                scope, body = left.strip(), right.strip()
        if scope and not _sheet_matches(scope, sheet_name):
            continue
        for part in re.split(r",(?=\s*\$?[A-Za-z]{1,3}\$?\d)", body):
            match = re.match(
                r"\s*(?P<range>\$?[A-Za-z]{1,3}\$?\d+(?::\$?[A-Za-z]{1,3}\$?\d+)?)\s*[:|=|]\s*(?P<align>left|center|right)(?:\s*[:|,]\s*(?P<lm>\d+))?(?:\s*[:|,]\s*(?P<rm>\d+))?\s*$",
                part,
                flags=re.I,
            )
            if not match:
                continue
            range_ref = match.group("range").replace("$", "").upper()
            alignment = match.group("align").casefold()
            left_margin = int(match.group("lm")) if match.group("lm") else None
            right_margin = int(match.group("rm")) if match.group("rm") else None
            try:
                min_c, min_r, max_c, max_r = range_boundaries(range_ref)
            except Exception:
                continue
            for row_idx in range(min(min_r, max_r), max(min_r, max_r) + 1):
                for col_idx in range(min(min_c, max_c), max(min_c, max_c) + 1):
                    key = f"{get_column_letter(col_idx).upper()}{row_idx}"
                    overrides[key] = {
                        "alignment": alignment,
                        "left_margin": left_margin,
                        "right_margin": right_margin,
                    }
    return overrides


def _bingo_alignment_cells(raw_cells, alignment):
    """Parse a plain cell list like 'b27, b28' or 'B5:C8' into
    {coord: {'alignment': ..., 'left_margin': None, 'right_margin': None}}."""
    overrides = {}
    for part in re.split(r"[\s,;]+", str(raw_cells or "")):
        part = part.strip().upper()
        if not part:
            continue
        try:
            min_c, min_r, max_c, max_r = range_boundaries(part)
        except Exception:
            continue
        for row_idx in range(min(min_r, max_r), max(min_r, max_r) + 1):
            for col_idx in range(min(min_c, max_c), max(min_c, max_c) + 1):
                key = f"{get_column_letter(col_idx).upper()}{row_idx}"
                overrides[key] = {"alignment": alignment, "left_margin": None, "right_margin": None}
    return overrides


# Default Bingo footer alignment: last two footer cells right (H27/H28),
# the adjacent left cells left (B27/B28). Applied only when the cell exists
# on the sheet; explicit fields/legacy overrides always win.
_BINGO_DEFAULT_LEFT_CELLS = "B27, B28"
_BINGO_DEFAULT_RIGHT_CELLS = "H27, H28"


def _bingo_merged_alignments(dynamic_settings, sheet_name):
    """Merge legacy override text, engine defaults and the simple
    left/right cell fields into one per-cell alignment map (newest wins)."""
    dynamic_settings = dynamic_settings or {}
    merged = _alignment_overrides_for_sheet(
        dynamic_settings.get("bingo_rules_alignment_overrides", ""), sheet_name
    )
    for coord, entry in _bingo_alignment_cells(_BINGO_DEFAULT_LEFT_CELLS, "left").items():
        merged.setdefault(coord, entry)
    for coord, entry in _bingo_alignment_cells(_BINGO_DEFAULT_RIGHT_CELLS, "right").items():
        merged.setdefault(coord, entry)
    for coord, entry in _bingo_alignment_cells(
        dynamic_settings.get("bingo_rules_left_align_cells"), "left"
    ).items():
        merged[coord] = entry
    for coord, entry in _bingo_alignment_cells(
        dynamic_settings.get("bingo_rules_right_align_cells"), "right"
    ).items():
        merged[coord] = entry
    for coord, entry in _bingo_alignment_cells(
        dynamic_settings.get("bingo_rules_center_align_cells"), "center"
    ).items():
        merged[coord] = entry
    return merged



def _png_norm_page_key(value):
    return re.sub(r"\s+", " ", str(value or "").strip().casefold())


def _png_cell_coords_for_sheet(raw_value, sheet_name):
    """Parse scoped cell/range assignments like PSD builder.

    Supports UI strings such as:
      Feature=A7,A11; Bonus Page=A3:A5
      BBB(5)=Heading1:A3, Heading2:A7, Heading3:A11
    Labels before coordinates are ignored; only actual Excel refs are used.
    """
    coords = set()
    for range_ref in _manual_ranges_for_sheet(raw_value, sheet_name):
        try:
            min_c, min_r, max_c, max_r = range_boundaries(range_ref)
        except Exception:
            continue
        for row_idx in range(min(min_r, max_r), max(min_r, max_r) + 1):
            for col_idx in range(min(min_c, max_c), max(min_c, max_c) + 1):
                coords.add((int(row_idx), int(col_idx)))
    return coords


def _parse_page_heading_size_overrides(raw_value):
    """Parse per-page heading size text.

    Accepts common UI formats:
      Game Rules=50
      Some Other Page=60
      Game Rules:50; Bonus=42
    """
    result = {}
    raw = str(raw_value or "").strip()
    if not raw:
        return result

    # Preferred: one assignment per line/semicolon.
    chunks = []
    for chunk in re.split(r"[\n;]+", raw):
        chunk = str(chunk or "").strip()
        if chunk:
            chunks.append(chunk)

    # If everything was typed in one line, find all Name=Number pairs.
    if len(chunks) == 1 and len(re.findall(r"[:=]\s*\d+", chunks[0])) > 1:
        matches = re.finditer(r"([^:=]+?)\s*[:=]\s*(\d+)(?=\s+[^:=]+\s*[:=]\s*\d+|$)", chunks[0])
        chunks = [f"{m.group(1).strip()}={m.group(2)}" for m in matches]

    for item in chunks:
        if "=" in item:
            page_name, size_value = item.split("=", 1)
        elif ":" in item:
            page_name, size_value = item.rsplit(":", 1)
        else:
            continue
        page_key = _png_norm_page_key(page_name)
        size_int = _safe_int(size_value, 0)
        if page_key and size_int > 0:
            result[page_key] = max(1, int(size_int))
    return result


def _png_heading_size_for_sheet(sheet_name, dynamic_settings, default_size):
    raw_value = (
        (dynamic_settings or {}).get("per_page_heading_sizes")
        or (dynamic_settings or {}).get("page_heading_sizes")
        or (dynamic_settings or {}).get("heading_size_overrides")
        or (dynamic_settings or {}).get("per_page_heading_size_overrides")
        or ""
    )
    mapping = _parse_page_heading_size_overrides(raw_value)
    return int(mapping.get(_png_norm_page_key(sheet_name), _safe_int(default_size, 48) or 48))


def _png_page_style_override(sheet_name, page_overrides):
    page_overrides = dict(page_overrides or {})
    if sheet_name in page_overrides:
        return page_overrides.get(sheet_name) or {}
    sheet_key = str(sheet_name or "").casefold()
    for key, value in page_overrides.items():
        if str(key).casefold() == sheet_key:
            return value or {}
    return {}


_PNG_MARKER_CELL_RE = re.compile(
    r"^(?:mod(?:ified|ify)?|update?d?|del(?:et?e)?d?|add(?:ed)?|remov(?:e|ed)|edit(?:ed)?|fix(?:ed)?)(?![a-z])",
    re.I,
)


def _png_skip_helper_text(value):
    raw = str(value or "").strip()
    if not raw:
        return False
    low = raw.casefold()
    if low.rstrip(">") in {"<<modified", "<modified", "<removed", "<added", "<deleted"} or low in {"modified", "removed", "added", "deleted"}:
        return True
    if raw.startswith("<") and ">" not in raw:
        return bool(_PNG_MARKER_CELL_RE.match(raw[1:].lstrip()))
    return False

_GAME_RULES_DYNAMIC_TOKEN_RE = re.compile(r"<\s*dynamic(?:[\s_-]*text)?\s*>", re.I)

def _game_rules_clean_value(value):
    raw = _text(value)
    if not raw:
        return ""
    compact = re.sub(r"[^a-z0-9]+", "", raw.casefold())
    if compact in {"added", "modified", "dynamictext"}:
        return ""
    if raw.casefold().startswith("<added") or raw.casefold().startswith("<modified"):
        return ""
    cleaned = _GAME_RULES_DYNAMIC_TOKEN_RE.sub("", raw)
    cleaned = re.sub(r"\s{2,}", " ", cleaned).strip()
    return cleaned

_GR_BLANK = "\u2063"            # an empty line the artist typed (Enter twice): a row of its own, one text line high


def _game_rules_pieces(value):
    """A cell's rows: each line the artist broke (Enter) on its own, empty lines kept as _GR_BLANK;
    a cell without line breaks splits exactly as before (_game_rules_split_around_dynamic)."""
    raw = _text(value)
    if "\n" not in raw:
        return _game_rules_split_around_dynamic(value)
    out = []
    for part in raw.split("\n"):
        if part.strip():
            out.extend(_game_rules_split_around_dynamic(part))
        elif out:
            out.append(_GR_BLANK)
    while out and out[-1] == _GR_BLANK:
        out.pop()
    return out


def _game_rules_split_around_dynamic(value):
    """Split a cell value around <dynamic text> tokens into separate lines.

    - Cells without dynamic tokens return a single cleaned line.
    - Cells with dynamic tokens: content after each token becomes its own line,
      matching the PSD builder's _game_rules_split_dynamic_placeholders.
    """
    raw = _text(value)
    if not raw:
        return []
    compact = re.sub(r"[^a-z0-9]+", "", raw.casefold())
    if compact in {"added", "modified", "dynamictext"}:
        return []
    if raw.casefold().startswith("<added") or raw.casefold().startswith("<modified"):
        return []
    if not _GAME_RULES_DYNAMIC_TOKEN_RE.search(raw):
        cleaned = _GAME_RULES_DYNAMIC_TOKEN_RE.sub("", raw)
        cleaned = re.sub(r"\s{2,}", " ", cleaned).strip()
        return [cleaned] if cleaned else []

    pieces = []
    cursor = 0
    for match in _GAME_RULES_DYNAMIC_TOKEN_RE.finditer(raw):
        before = raw[cursor:match.start()].strip()
        if before:
            before = re.sub(r"\s{2,}", " ", before).strip()
            if before:
                pieces.append(before)
        after_raw = raw[match.end():]
        sentence_match = re.search(r"[.!?](?=\s|$)", after_raw)
        if sentence_match:
            sentence = after_raw[:sentence_match.end()].strip()
            sentence = re.sub(r"\s{2,}", " ", sentence).strip()
            if sentence:
                pieces.append(sentence)
            cursor = match.end() + sentence_match.end()
        else:
            cursor = match.end()
    trailing = raw[cursor:].strip()
    if trailing:
        trailing = re.sub(r"\s{2,}", " ", trailing).strip()
        if trailing:
            pieces.append(trailing)
    return pieces

def _resolve_heading_image_path(sheet_name, heading_image_folder, heading_index=0, alignment_settings=None):
    """Find heading image for a sheet. Checks per-page override first, then folder auto-match. Returns path or empty string."""
    if alignment_settings:
        overrides = (alignment_settings or {}).get("overrides") or {}
        page_cfg = overrides.get(str(sheet_name or "")) or {}
        override_path = str(page_cfg.get("heading_image_path") or "").strip()
        if override_path and os.path.isfile(override_path):
            return override_path
    if not heading_image_folder or not os.path.isdir(heading_image_folder):
        return ""
    raw = str(sheet_name or "").strip()
    cleaned = re.sub(r"[^A-Za-z0-9]+", "_", raw).strip("_")
    compact = re.sub(r"[^A-Za-z0-9]+", "", raw)
    candidates = []
    for value in (raw, cleaned, compact):
        if value and value not in candidates:
            candidates.append(value)
    if heading_index > 0:
        for base_name in candidates:
            numbered = f"{base_name}_heading{heading_index}"
            for ext in (".png", ".jpg", ".jpeg"):
                for path in (
                    os.path.join(heading_image_folder, numbered + ext),
                    os.path.join(heading_image_folder, numbered.lower() + ext),
                ):
                    if os.path.isfile(path):
                        return path
        return ""
    for base_name in candidates:
        for ext in (".png", ".jpg", ".jpeg"):
            for path in (
                os.path.join(heading_image_folder, base_name + ext),
                os.path.join(heading_image_folder, base_name.lower() + ext),
            ):
                if os.path.isfile(path):
                    return path
    return ""


def _place_heading_image_in_png(page, Image, image_path, margin_x, safe_width, y, target_height, alignment="center"):
    """Load heading image, resize proportionally if target_height>0, clamp to safe_width.
    alignment: 'left', 'center', 'right', or absolute 'x,y' string.
    Returns pasted height or 0 on error."""
    try:
        himg = Image.open(image_path).convert("RGBA")
        ow, oh = himg.size
        if ow < 1 or oh < 1:
            return 0
        if target_height > 0:
            scale = target_height / max(1, oh)
            nw = max(1, int(ow * scale))
            nh = target_height
        else:
            nw, nh = ow, oh
        if nw > safe_width:
            scale = safe_width / nw
            nw = max(1, int(nw * scale))
            nh = max(1, int(nh * scale))
        himg = himg.resize((nw, nh), Image.Resampling.LANCZOS)
        if alignment == "left":
            paste_x = margin_x
        elif alignment == "right":
            paste_x = margin_x + safe_width - nw
        elif alignment == "center":
            paste_x = margin_x + max(0, (safe_width - nw) // 2)
        elif alignment and "," in alignment:
            try:
                parts = alignment.split(",")
                paste_x = margin_x + int(parts[0].strip())
                y = y + int(parts[1].strip())
            except Exception:
                paste_x = margin_x + max(0, (safe_width - nw) // 2)
        else:
            paste_x = margin_x + max(0, (safe_width - nw) // 2)
        page.paste(himg, (paste_x, y), himg)
        return nh
    except Exception:
        return 0


def _render_game_rules_png_pages(
    Image, ImageDraw, ImageFont, ws, sheet_name, bg_path, bg_mode, bg_color, canvas_w, canvas_h,
    h_font, h_size, h_icon_h, h_rgb, b_font, b_size, b_icon_h, b_rgb, margin_x,
    heading_top_margin, heading_to_body_gap, bottom_margin, line_spacing, para_spacing,
    icon_folder, icon_mappings, icon_size_overrides, dynamic_settings, alignment_settings,
    page_min_col=1, page_max_col=None, page_min_row=1, page_max_row=None,
    xtra_candidate_dirs=(), report=None,
):
    """The Game Rules page (always one page). `report` (a dict) receives where everything landed —
    heading, each text line with its Excel cell, the separator, the XTRAA REELS spots, the margins
    and the fitted sizes — for the studio's click-to-edit preview."""
    page = Image.new("RGBA", (canvas_w, canvas_h), (0, 0, 0, 0) if _sink_skips_text() else (255, 255, 255, 255))
    if not _sink_skips_text():                     # the Canvas's picture of the page draws its own background
        _draw_background(page, Image, bg_path, bg_mode, bg_color)
    draw = ImageDraw.Draw(page)
    safe_bottom = max(heading_top_margin + 100, canvas_h - max(0, _safe_int(bottom_margin, 80)))
    effective_max_col = max(1, _safe_int(page_max_col, min(max(1, ws.max_column or 1), 100)))
    heading_row, heading_text = _find_heading_row(ws, effective_max_col, [], min_row=page_min_row, max_row=page_max_row)
    heading_text = game_name_heading(heading_text or sheet_name, dynamic_settings, icon_folder, icon_mappings)
    heading_font = _heading_font(ImageFont, h_font, h_size, dynamic_settings)
    heading_icon_h = max(1, _safe_int(h_icon_h, _safe_int(h_size, 48)))
    heading_color = _rgb(h_rgb, (255, 80, 80))
    dynamic_settings = dynamic_settings or {}
    alignment_settings = alignment_settings or {}
    # the legal text keeps the page's font / size / colour; only the rules paragraph has its own
    page_b_font, page_b_size, page_b_color = b_font, b_size, _rgb(b_rgb, (255, 255, 255))
    b_font = _styled_font_name(dynamic_settings.get("game_rules_body_font") or b_font, dynamic_settings.get("game_rules_body_font_style"))
    b_size = dynamic_settings.get("game_rules_body_size") or b_size
    body_color = _rgb(dynamic_settings.get("game_rules_body_rgb") or b_rgb, (255, 255, 255))
    _lsd = dynamic_settings.get("layer_style_library", {}) or {}
    _sas = dynamic_settings.get("style_assignments", {}) or {}
    _gr_heading_fx = _resolve_fx_config(_lsd, _sas, "Heading text")
    _gr_text_fx = _resolve_fx_config(_lsd, _sas, "Game Rules text")
    _gr_legal_fx = _resolve_fx_config(_lsd, _sas, "Malfunction/legal text")
    # the legal text's own colour (absent: the rules text's, as always)
    legal_color = _rgb(dynamic_settings.get("game_rules_bottom_rgb"), page_b_color)
    _gr_head_gap_l = max(0, _safe_int(dynamic_settings.get("heading_icon_gap_left", dynamic_settings.get("heading_icon_gap", 15)), 15))
    _gr_head_gap_r = max(0, _safe_int(dynamic_settings.get("heading_icon_gap_right", dynamic_settings.get("heading_icon_gap", 15)), 15))
    _gr_icon_gap_l = max(0, _safe_int(dynamic_settings.get("icon_gap_left", 15), 15))
    _gr_icon_gap_r = max(0, _safe_int(dynamic_settings.get("icon_gap_right", 15), 15))

    min_col = max(1, _safe_int(page_min_col, 1))
    # the legal text goes under the separator: from "Malfunction voids all pays and plays" on, or —
    # when the artist chose it in the studio ("Sheet=B25", "Sheet=none") — exactly from that cell
    legal_split, legal_off = _game_rules_legal_choice(dynamic_settings.get("game_rules_legal_split_overrides", ""), sheet_name)
    manual_split = bool(legal_split or legal_off)
    upper_lines = []                 # (text, source cell)
    lower_lines = []
    cell_texts = {}                  # cell -> its whole text (as shown, with the artist's edits)
    in_lower = False
    for _row_idx, row_items in _iter_clean_cells(ws, effective_max_col, skip_rows={heading_row}, min_row=page_min_row, max_row=page_max_row):
        for row_idx, col_idx, _coord, value in row_items:
            if col_idx < min_col:
                continue
            from . import text_edits as _text_edits

            from . import icon_scales as _icon_scales

            value = _text_edits.apply(sheet_name, _coord, value)       # the artist's line breaks / joins
            value = _icon_scales.apply(sheet_name, _coord, value)      # icons the artist sized (<WILD~140>)
            cell_texts[_coord] = _untag_text(value)
            pieces = _game_rules_pieces(value)
            if not pieces:
                continue
            if legal_split and (row_idx > legal_split[0] or (row_idx == legal_split[0] and col_idx >= legal_split[1])):
                in_lower = True
            for piece in pieces:
                lowered = piece.casefold()
                if not manual_split and ("malfunction" in lowered or "voids all pays" in lowered or "all pays and plays" in lowered):
                    in_lower = True
                (lower_lines if in_lower else upper_lines).append((piece, _coord))

    # XTRAA REELS side icons: only on this page, only when the icon is in the symbols folder and the
    # sheet talks about it — unless the artist ticked / unticked a side in the studio
    xr_asset = _resolve_xtra_reels_asset(
        dynamic_settings.get("game_rules_xtra_reels_asset"),
        [d for d in [icon_folder, *list(xtra_candidate_dirs or ())] if str(d or "").strip()],
    )
    xr_mentioned = _xtra_reels_mentioned([p for p, _c in upper_lines + lower_lines] + [heading_text or ""], xr_asset)
    xr_auto = bool(xr_asset) and (xr_mentioned or dynamic_settings.get("game_rules_xtra_reels_enabled") is True)
    xr_left = bool(xr_asset) and _choice(dynamic_settings.get("game_rules_xtra_reels_left"), xr_auto)
    xr_right = bool(xr_asset) and _choice(dynamic_settings.get("game_rules_xtra_reels_right"), xr_auto)

    max_width = max(100, canvas_w - margin_x * 2)
    heading_y = max(0, _safe_int(heading_top_margin, 120))
    heading_img_folder = (alignment_settings or {}).get("heading_image_folder", "") or ""
    heading_img_height = int((alignment_settings or {}).get("heading_image_height", 0) or 0)
    heading_img_path = _resolve_heading_image_path(sheet_name, heading_img_folder, alignment_settings=alignment_settings)
    heading_align = (alignment_settings or {}).get("global", {}).get("heading", "center")
    heading_h_from_img = _place_heading_image_in_png(page, Image, heading_img_path, margin_x, max_width, heading_y, heading_img_height, heading_align) if heading_img_path else 0
    if heading_h_from_img > 0:
        heading_w, heading_h = 0, heading_h_from_img
    else:
        from . import ps_text as _pst_h

        # the heading's own letter spacing (Typography / a Mimic PSD), as on normal pages
        with _sink_ctx(kind="heading"), _pst_h.tracking(_tracking_setting(dynamic_settings, "heading_tracking")):
          heading_w, heading_h = _draw_inline(
            page, draw, Image, heading_text, margin_x, heading_y,
            heading_font, heading_color, max_width, icon_folder, icon_mappings, heading_icon_h,
            icon_size_overrides, align="center", line_spacing=_row_gap_px(max(8, _safe_int(h_size, 48)), line_spacing),
            fx_config=_gr_heading_fx, icon_gap_left=_gr_head_gap_l, icon_gap_right=_gr_head_gap_r,
            font_request=h_font, font_size=h_size, bold=True,
        )

    # the legal text's own font (desktop UI: ..._request; web studio: game_rules_bottom_font)
    bottom_font_name = dynamic_settings.get("game_rules_bottom_font_request") or _styled_font_name(
        dynamic_settings.get("game_rules_bottom_font") or page_b_font, dynamic_settings.get("game_rules_bottom_font_style"))
    bottom_font_size = max(8, _safe_int(dynamic_settings.get("game_rules_bottom_font_size"), max(8, _safe_int(page_b_size, 24) - 8)))
    body_font_size = max(8, _safe_int(b_size, 24))
    body_font = _load_font(ImageFont, b_font, body_font_size)
    bottom_font = _load_font(ImageFont, bottom_font_name, bottom_font_size)
    bottom_gap = max(0, _safe_int(dynamic_settings.get("game_rules_bottom_gap"), 26))
    _gr_line_gap = dynamic_settings.get("line_gap") if "line_gap" in dynamic_settings else None
    _gr_upper_height_override = dynamic_settings.get("game_rules_line_height")
    _gr_lower_height_override = dynamic_settings.get("game_rules_malfunction_line_height")

    def _effective_line_gap(font_obj, size, height_override, ls, line_gap):
        """Per-row gap that makes the PNG row step match the PSD engine.

        The UI 'Row spacing' (line_gap) is a real gap between row boxes and is
        the SINGLE row-gap source (empty -> the 30px PSD-compatible default).
        A px Line-height override (game_rules_line_height / ..._malfunction_)
        is a full baseline STEP in Photoshop (build_engine._line_step_for_line
        = max(override, font + 2)), so the gap the inline renderer adds on top
        of its line box becomes max(0, step - line_box_h). The Typography
        'Line spacing' multiplier no longer affects row stacking."""
        if line_gap is not None:
            return _effective_row_gap(line_gap)
        try:
            step_px = max(0, int(round(float(height_override)))) if height_override else None
        except Exception:
            step_px = None
        if step_px:
            box_h = _line_height(draw, font_obj, size)
            return max(0, step_px - box_h)
        return _effective_row_gap(None)
    separator_h = max(1, _safe_int(dynamic_settings.get("game_rules_separator_height"), 2))
    separator_after_gap = max(
        0,
        _safe_int(
            dynamic_settings.get("game_rules_separator_after_gap"),
            bottom_gap // 2 if bottom_gap else 0,
        ),
    )
    sep_w = max(1, _safe_int(dynamic_settings.get("game_rules_separator_width"), max_width))
    sep_rgb = _rgb(dynamic_settings.get("game_rules_separator_rgb"), page_b_color)
    sep_align = dynamic_settings.get("game_rules_separator_alignment", "center")
    sep_margin = max(0, _safe_int(dynamic_settings.get("game_rules_separator_margin"), margin_x))
    bottom_lr = max(0, _safe_int(dynamic_settings.get("game_rules_bottom_lr_margin"), 200))
    malfunction_lr = max(0, _safe_int(dynamic_settings.get("game_rules_malfunction_lr_margin"), bottom_lr))
    # each paragraph's own alignment (the Canvas top bar), else the pages' as always
    body_align = _own_align(dynamic_settings.get("game_rules_body_align")) or (alignment_settings.get("body") or "center")
    bottom_align = _own_align(dynamic_settings.get("game_rules_legal_align")) or (alignment_settings.get("bottom") or "center")
    xr_width = max(1, _safe_int(dynamic_settings.get("game_rules_xtra_reels_width"), 100))
    xr_outer = max(0, _safe_int(dynamic_settings.get("game_rules_xtra_reels_outer_margin"), 100))
    xr_gap = max(0, _safe_int(dynamic_settings.get("game_rules_xtra_reels_text_gap"), 50))
    side_margin = xr_outer + xr_width + xr_gap if (xr_left or xr_right) else 0
    # Match PSD builder: Game Rules upper/body text also obeys the UI
    # "Upper/body L/R margin". XTRAA REELS side clearance still wins when enabled.
    upper_margin = max(margin_x, side_margin, bottom_lr)
    upper_width = max(100, canvas_w - upper_margin * 2)
    lower_width = max(100, canvas_w - malfunction_lr * 2)
    _gr_yoff = max(0, _safe_int(dynamic_settings.get("icon_y_offset"), 0))

    # One page: when the rules don't fit, text, row gaps and inline symbols shrink TOGETHER
    # (the page looks like the others, only smaller). Shrinking the text alone left the fixed
    # row gaps and full-size symbols eating the page, so the text ended up tiny.
    base_body, base_bottom = body_font_size, bottom_font_size
    base_icon_h = max(1, _safe_int(b_icon_h, 40))
    base_upper_gap = _effective_line_gap(body_font, base_body, _gr_upper_height_override, line_spacing, _gr_line_gap)
    base_lower_gap = _effective_line_gap(bottom_font, base_bottom, _gr_lower_height_override, line_spacing, _gr_line_gap)
    _own_upper_gap = _row_gap_setting(dynamic_settings, "game_rules_row_gap")           # px between rows: wins
    _own_lower_gap = _row_gap_setting(dynamic_settings, "game_rules_legal_row_gap")
    if _own_upper_gap is not None:
        base_upper_gap = _own_upper_gap
    if _own_lower_gap is not None:
        base_lower_gap = _own_lower_gap
    from . import ps_text as _ps_text

    _upper_trk = _tracking_setting(dynamic_settings, "game_rules_tracking")             # letter spacing, 1/1000 em
    _lower_trk = _tracking_setting(dynamic_settings, "game_rules_legal_tracking")

    def sized(f):
        body = max(8, int(round(base_body * f)))
        lower = max(8, int(round(base_bottom * f)))
        return (body, lower, max(4, int(round(base_icon_h * f))),
                max(0, int(round(base_upper_gap * f))), max(0, int(round(base_lower_gap * f))))

    # what decides a line's measured heights besides its text and size: the icons, the word styles
    _fit_ctx = repr((icon_folder, sorted((icon_mappings or {}).items()), sorted((icon_size_overrides or {}).items()),
                     _gr_icon_gap_l, _gr_icon_gap_r, _gr_yoff, _text_styles_state()))

    def ink_heights(line, font, width, icon_h, trk):
        """Each wrapped row's ink height for this line at this size — kept between renders (the Canvas
        lays the page out again at every keystroke; only the typed line is new)."""
        key = (line, str(getattr(font, "path", "")), getattr(font, "size", 0), width, icon_h, trk, _fit_ctx)
        hit = _GR_FIT_CACHE.get(key)
        if hit is None:
            with _ps_text.tracking(trk):
                _wrapped = _wrap_inline(draw, Image, line, font, width, icon_folder, icon_mappings, icon_h, icon_size_overrides, _gr_icon_gap_l, _gr_icon_gap_r)
            heights = []
            for ln in _wrapped:
                with _ps_text.tracking(trk):
                    _it, _ib = _line_ink_extents(
                        draw, Image, ln, font, icon_folder, icon_mappings, icon_h,
                        icon_size_overrides, _gr_icon_gap_l, _gr_icon_gap_r, _gr_yoff,
                    )
                heights.append(max(1.0, _ib - _it))
            hit = tuple(heights)
            if len(_GR_FIT_CACHE) > 20000:
                _GR_FIT_CACHE.clear()
            _GR_FIT_CACHE[key] = hit
        return hit

    def projected(f):
        body, lower, icon_h, upper_gap, lower_gap = sized(f)
        body_f = _load_font(ImageFont, b_font, body)
        lower_f = _load_font(ImageFont, bottom_font_name, lower)
        total = max(0, _safe_int(heading_top_margin, 120)) + heading_h + max(0, _safe_int(heading_to_body_gap, 40))
        for line, _cell in upper_lines:
            if line == _GR_BLANK:
                total += body + upper_gap
                continue
            for h in ink_heights(line, body_f, upper_width, icon_h, _upper_trk):
                total += h + upper_gap
        if lower_lines:
            total += bottom_gap + separator_h + separator_after_gap
            for line, _cell in lower_lines:
                if line == _GR_BLANK:
                    total += lower + lower_gap
                    continue
                if not line.strip():
                    continue
                for h in ink_heights(line.strip(), lower_f, lower_width, icon_h, _lower_trk):
                    total += h + lower_gap
        return total

    fit = 1.0
    while projected(fit) > safe_bottom and fit > 0.12 and sized(fit)[0] > 10:
        fit = round(fit - 0.02, 4)
    body_font_size, bottom_font_size, icon_h, upper_line_spacing, lower_line_spacing = sized(fit)
    body_font = _load_font(ImageFont, b_font, body_font_size)
    bottom_font = _load_font(ImageFont, bottom_font_name, bottom_font_size)

    if report is not None:
        report.update({
            "canvas": [canvas_w, canvas_h], "fit": fit,
            "sizes": {"body": body_font_size, "legal": bottom_font_size, "icon": icon_h,
                      "body_set": base_body, "legal_set": base_bottom,
                      "row_gap": upper_line_spacing, "legal_row_gap": lower_line_spacing},
            "heading": [margin_x, heading_y, max_width, heading_h],
            "guides": {"heading_top": heading_y, "heading_bottom": heading_y + heading_h,
                       "body_top": heading_y + heading_h + max(0, _safe_int(heading_to_body_gap, 40)),
                       "safe_bottom": safe_bottom, "margin_x": margin_x, "upper_margin": upper_margin,
                       "legal_margin": malfunction_lr, "text_margin_set": bottom_lr},
            "lines": [], "separator": None, "cells": cell_texts,
            "legal": {"manual": manual_split, "off": legal_off,
                      "split": legal_split[2] if legal_split else "", "first": lower_lines[0][1] if lower_lines else ""},
        })

    def _line_box(ln, font, x0, width, align, line_y, ink_top, ink_bottom, size):
        try:
            w = _measure_inline(draw, Image, ln, font, icon_folder, icon_mappings, icon_h, icon_size_overrides,
                                _gr_icon_gap_l, _gr_icon_gap_r)[0]
        except Exception:
            w = width
        w = min(width, max(1, w))
        x = x0 if align in ("left", "justify") else (x0 + width - w if align == "right" else x0 + (width - w) / 2.0)
        if align == "justify":
            w = width
        return [round(x, 1), round(line_y + ink_top, 1), round(w, 1), round(max(size * 0.6, ink_bottom - ink_top), 1)]

    def _layout(lines, font, x0, width, align, start_y, row_gap, size, strip_blank, trk=0.0):
        """Where each wrapped row lands: [(text, cell, line_y, ink_top, ink_bottom, rect)] and the y after the last."""
        with _ps_text.tracking(trk):
            return _layout_rows(lines, font, x0, width, align, start_y, row_gap, size, strip_blank)

    def _layout_rows(lines, font, x0, width, align, start_y, row_gap, size, strip_blank):
        rows, y = [], start_y
        for line, cell in lines:
            if line == _GR_BLANK:                      # an empty line: one text line high
                if report is not None:                 # where it is (the Canvas's caret goes there)
                    report.setdefault("blanks", []).append({"cell": cell, "top": round(y, 1), "h": size})
                y += size + row_gap
                continue
            if strip_blank:
                if not line.strip():
                    continue
                line = line.strip()
            for ln in _wrap_inline(draw, Image, line, font, width, icon_folder, icon_mappings, icon_h, icon_size_overrides, _gr_icon_gap_l, _gr_icon_gap_r):
                ink_top, ink_bottom = _line_ink_extents(
                    draw, Image, ln, font,
                    icon_folder, icon_mappings, icon_h, icon_size_overrides,
                    _gr_icon_gap_l, _gr_icon_gap_r, _gr_yoff,
                )
                # EXACT-ink stacking: each row's ink top lands on y (the previous row's ink bottom +
                # row gap), so the visual gap between ANY two consecutive rows (wrapped or paragraph
                # boundary) is exactly the row gap px.
                line_y = y - ink_top
                rows.append((ln, cell, line_y, ink_top, ink_bottom,
                             _line_box(ln, font, x0, width, align, line_y, ink_top, ink_bottom, size)))
                y = line_y + ink_bottom + row_gap
        return rows, y

    def _block(rows):
        """[x0, y0, x1, y1] around the rows' rects, or None."""
        if not rows:
            return None
        return [min(r[5][0] for r in rows), min(r[5][1] for r in rows),
                max(r[5][0] + r[5][2] for r in rows), max(r[5][1] + r[5][3] for r in rows)]

    def _strip(block, key, name):
        """The optional box behind a paragraph (game_rules_rules_bg / game_rules_legal_bg): [x, y, w, h] or None."""
        cfg = dynamic_settings.get(key)
        if not block or not isinstance(cfg, dict) or not cfg.get("on"):
            return None
        pad = max(0, _safe_int(cfg.get("pad"), 12))
        x, y = block[0] - pad, block[1] - pad
        w, h = block[2] - block[0] + pad * 2, block[3] - block[1] + pad * 2
        shape = {"radius": max(0, _safe_int(cfg.get("radius"), 12)), "fill": cfg.get("fill") or None,
                 "fill_opacity": cfg.get("fill_opacity"), "stroke": cfg.get("stroke") or None,
                 "fx": cfg.get("fx") or None}
        try:
            from . import paytable_box

            paytable_box.draw(page, {"shape": shape}, x, y, w, h, settings=dynamic_settings, label="grstrip", name=name)
        except Exception:
            return None
        return [round(x, 1), round(y, 1), round(w, 1), round(h, 1)]

    def _emit(rows, part, font, x0, width, align, spacing, color, fx, font_request, size, trk=0.0):
        for ln, cell, line_y, _it, _ib, rect in rows:
            from . import text_styles as _ts_row

            # the cell's own text styles (a selection styled on the Canvas: rules made for just this cell)
            with _ps_text.tracking(trk), _sink_ctx(kind="body", cell=cell, part=part), _ts_row.row(cell_texts.get(cell) or ln):
                _draw_inline(
                    page, draw, Image, ln, x0, line_y, font, color, width,
                    icon_folder, icon_mappings, icon_h, icon_size_overrides, align=align,
                    line_spacing=spacing, fx_config=fx,
                    icon_gap_left=_gr_icon_gap_l, icon_gap_right=_gr_icon_gap_r,
                    icon_y_offset=_gr_yoff,
                    font_request=font_request, font_size=size,
                )
            if report is not None:
                report["lines"].append({"text": _untag_text(ln), "cell": cell, "part": part, "rect": rect})

    current_y = max(0, _safe_int(heading_top_margin, 120)) + heading_h + max(0, _safe_int(heading_to_body_gap, 40))
    upper_top = current_y
    upper_rows, current_y = _layout(upper_lines, body_font, upper_margin, upper_width, body_align,
                                    current_y, upper_line_spacing, body_font_size, False, _upper_trk)
    upper_bottom = current_y
    rules_block = _block(upper_rows)
    rules_bg = _strip(rules_block, "game_rules_rules_bg", "Game Rules text strip")
    _emit(upper_rows, "rules", body_font, upper_margin, upper_width, body_align, upper_line_spacing,
          body_color, _gr_text_fx, b_font, body_font_size, _upper_trk)
    xr_rects = _paste_xtra_reels(page, Image, xr_asset, xr_width, xr_outer, (upper_top + upper_bottom) / 2.0,
                                 dynamic_settings.get("game_rules_xtra_reels_y_offset", 0), xr_left, xr_right)
    if report is not None:
        report["xtra"] = {"asset": xr_asset, "mentioned": xr_mentioned, "auto": xr_auto,
                          "left": xr_left, "right": xr_right, "width": xr_width, "outer": xr_outer, "gap": xr_gap,
                          # what the artist ticked (shown even before there is a picture for it)
                          "want_left": _choice(dynamic_settings.get("game_rules_xtra_reels_left"), xr_auto),
                          "want_right": _choice(dynamic_settings.get("game_rules_xtra_reels_right"), xr_auto),
                          "rects": xr_rects}
    legal_block = legal_bg = None
    if lower_lines:
        separator_y = current_y + bottom_gap
        sep_rect = _draw_game_rules_separator(page, draw, canvas_w, separator_y, sep_w, separator_h, sep_rgb,
                                              sep_align, sep_margin, dynamic_settings)
        if report is not None:
            report["separator"] = sep_rect
        current_y = separator_y + separator_h + separator_after_gap
        lower_rows, current_y = _layout(lower_lines, bottom_font, malfunction_lr, lower_width, bottom_align,
                                        current_y, lower_line_spacing, bottom_font_size, True, _lower_trk)
        legal_block = _block(lower_rows)
        legal_bg = _strip(legal_block, "game_rules_legal_bg", "Legal text strip")
        _emit(lower_rows, "legal", bottom_font, malfunction_lr, lower_width, bottom_align, lower_line_spacing,
              legal_color, _gr_legal_fx, bottom_font_name, bottom_font_size, _lower_trk)
    if report is not None:
        report["blocks"] = {"rules": [round(v, 1) for v in rules_block] if rules_block else None,
                            "legal": [round(v, 1) for v in legal_block] if legal_block else None}
        report["bg"] = {"rules": rules_bg, "legal": legal_bg}
    return [page]


def _styled_font_name(font, style):
    """A font with a paragraph's own style ("Arial" + "bold" -> "Arial Bold"), as the desktop app asks for one."""
    font, style = str(font or "").strip(), str(style or "").strip()
    if not font or not style or style.casefold() == "regular":
        return font
    return f"{font} {style.title()}"


def _own_align(value):
    """A paragraph's own alignment setting, or "" when it has none."""
    value = str(value or "").strip().casefold()
    return value if value in ("left", "center", "right", "justify") else ""


_GR_FIT_CACHE = {}          # Game Rules fit: a line's row ink heights at a size (see ink_heights)


def _text_styles_state():
    """The word styles in force now (they change how text measures)."""
    try:
        from . import text_styles

        return repr(text_styles._ACTIVE.get())
    except Exception:
        return ""


def _choice(value, default):
    """An artist's tick (True / False, also "true" / "off" ...) or the automatic default."""
    if value is None or value == "" or str(value).strip().casefold() == "auto":
        return bool(default)
    if isinstance(value, str):
        return value.strip().casefold() in ("1", "true", "yes", "on")
    return bool(value)


def _game_rules_legal_choice(raw_value, sheet_name):
    """((row, col, "B25") | None, off): the artist's choice for where the legal text starts on this
    sheet — the last "Sheet=Cell" line wins; "Sheet=none" keeps everything above the separator."""
    bodies = [str(b or "").strip() for b in _scoped_bodies_for_sheet(raw_value, sheet_name) if str(b or "").strip()]
    if not bodies:
        return None, False
    last = bodies[-1]
    if last.casefold() in ("none", "off", "no", "-"):
        return None, True
    return _cell_split_for_sheet(last, sheet_name), False


def _xtra_reels_mentioned(texts, asset_path=""):
    """True when the sheet's text names the XTRAA REELS feature (or the icon file's own name)."""
    blob = re.sub(r"[^a-z0-9]+", "", " ".join(str(t or "") for t in texts).casefold())
    names = {"xtrareel", "xtraa", "extrareel"}
    stem = re.sub(r"[^a-z0-9]+", "", os.path.splitext(os.path.basename(str(asset_path or "")))[0].casefold())
    if len(stem) >= 4:
        names.add(stem)
    return any(n in blob for n in names)


def _paste_xtra_reels(base, Image, asset_path, icon_width, outer_margin, center_y, y_offset=0, left=True, right=True):
    """The XTRAA REELS icon left and/or right of the rules text, each its own PSD layer.
    Returns {"left": [x, y, w, h] | None, "right": ...} (where each one goes, drawn or not)."""
    out = {"left": None, "right": None}
    margin = max(0, _safe_int(outer_margin, 0))
    if not asset_path or not os.path.isfile(asset_path):
        # no picture yet: the spots it would take (the studio shows them, with their ticks)
        w = max(1, int(icon_width))
        h = int(round(w * 1.6))
        y = int(round(center_y - h / 2.0 + _safe_int(y_offset, 0)))
        return {"left": [margin, y, w, h], "right": [max(0, base.width - margin - w), y, w, h]}
    try:
        icon = Image.open(asset_path).convert("RGBA")
    except Exception:
        return out
    scale = max(1, int(icon_width)) / max(1, icon.width)
    icon = icon.resize((max(1, int(round(icon.width * scale))), max(1, int(round(icon.height * scale)))))
    y = int(round(center_y - icon.height / 2.0 + _safe_int(y_offset, 0)))
    spots = {"left": margin, "right": max(0, base.width - margin - icon.width)}
    for side, x in spots.items():
        out[side] = [x, y, icon.width, icon.height]
        if (left if side == "left" else right):
            _psd_paste_icon(base, icon, x, y, f"XTRAA REELS {side.title()}")
    return out


def _draw_game_rules_separator(base, draw, canvas_w, y, width, height, rgb, alignment, margin, dynamic_settings):
    """The line between the rules and the legal text: a box in the separator colour (with the
    layer style picked for it), a live shape in PSD builds. Returns its [x, y, w, h]."""
    width, height, margin = max(1, int(width)), max(1, int(height)), max(0, int(margin))
    alignment = str(alignment or "center").casefold()
    x = margin if alignment == "left" else (canvas_w - margin - width if alignment == "right" else (canvas_w - width) / 2.0)
    shape = {"radius": 0, "fill": "#%02X%02X%02X" % tuple(int(c) for c in (rgb or (255, 255, 255))[:3]),
             "fx": dynamic_settings.get("game_rules_separator_fx") or None}
    try:
        from . import paytable_box

        paytable_box.draw(base, {"shape": shape}, x, y, width, height, settings=dynamic_settings, label="grseparator")
    except Exception:
        draw.rectangle([x, y, x + width, y + height], fill=tuple(rgb or (255, 255, 255)))
    return [round(x, 1), round(y, 1), width, height]


def _render_bingo_rules_png_pages(*args, **kwargs):
    """The Bingo Rules page; `bingo_rules_tracking` (letter spacing, 1/1000 em) applies to its text
    in measuring, drawing and the PSD."""
    from . import ps_text as _ps_text

    ds = kwargs["dynamic_settings"] if "dynamic_settings" in kwargs else (args[27] if len(args) > 27 else None)
    with _ps_text.tracking(_tracking_setting(ds, "bingo_rules_tracking")):
        return _render_bingo_rules_page_body(*args, **kwargs)


def _render_bingo_rules_page_body(
    Image, ImageDraw, ImageFont, ws, sheet_name, bg_path, bg_mode, bg_color, canvas_w, canvas_h,
    h_font, h_size, h_icon_h, h_rgb, b_font, b_size, b_icon_h, b_rgb, margin_x,
    heading_top_margin, heading_to_body_gap, bottom_margin, line_spacing, para_spacing,
    icon_folder, icon_mappings, icon_size_overrides, dynamic_settings, alignment_settings,
    page_min_col=1, page_max_col=None, page_min_row=1, page_max_row=None, report=None,
):
    """The Bingo Rules page (always one page: the text shrinks to fit). `report` (a dict)
    receives where each cell's text landed, its alignment and the fitted size — for the studio."""
    page = Image.new("RGBA", (canvas_w, canvas_h), (0, 0, 0, 0) if _sink_skips_text() else (255, 255, 255, 255))
    if not _sink_skips_text():                     # the Canvas's picture of the page draws its own background
        _draw_background(page, Image, bg_path, bg_mode, bg_color)
    draw = ImageDraw.Draw(page)
    safe_bottom = max(heading_top_margin + 100, canvas_h - max(0, _safe_int(bottom_margin, 80)))
    effective_max_col = max(1, _safe_int(page_max_col, min(max(1, ws.max_column or 1), 100)))
    min_col = max(1, _safe_int(page_min_col, 1))
    from . import text_edits as _text_edits

    # the page's own left / right margin (the studio's side guides), else every page's margin
    _own_margin = (dynamic_settings or {}).get("bingo_rules_side_margin")
    if _own_margin not in (None, ""):
        margin_x = max(0, min(int(canvas_w * 0.45), _safe_int(_own_margin, margin_x)))
    heading_row, heading_text = _find_heading_row(ws, effective_max_col, [], min_row=page_min_row, max_row=page_max_row)
    heading_text = game_name_heading(heading_text or sheet_name, dynamic_settings, icon_folder, icon_mappings)
    heading_font = _heading_font(ImageFont, h_font, h_size, dynamic_settings)
    heading_icon_h = max(1, _safe_int(h_icon_h, _safe_int(h_size, 48)))
    heading_color = _rgb(h_rgb, (255, 80, 80))
    max_width = max(100, canvas_w - margin_x * 2)
    dynamic_settings = dynamic_settings or {}
    # the paragraph's own font / colour (absent: the page body's, as always)
    b_font = _styled_font_name(dynamic_settings.get("bingo_rules_font") or b_font, dynamic_settings.get("bingo_rules_font_style"))
    body_color = _rgb(dynamic_settings.get("bingo_rules_rgb") or b_rgb, (255, 255, 255))
    _blsd = dynamic_settings.get("layer_style_library", {}) or {}
    _bsas = dynamic_settings.get("style_assignments", {}) or {}
    _br_heading_fx = _resolve_fx_config(_blsd, _bsas, "Heading text")
    _br_body_fx = _resolve_fx_config(_blsd, _bsas, "Bingo Rules text") or _resolve_fx_config(_blsd, _bsas, "Body text")
    _br_head_gap_l = max(0, _safe_int(dynamic_settings.get("heading_icon_gap_left", dynamic_settings.get("heading_icon_gap", 15)), 15))
    _br_head_gap_r = max(0, _safe_int(dynamic_settings.get("heading_icon_gap_right", dynamic_settings.get("heading_icon_gap", 15)), 15))
    _br_icon_gap_l = max(0, _safe_int(dynamic_settings.get("icon_gap_left", 15), 15))
    _br_icon_gap_r = max(0, _safe_int(dynamic_settings.get("icon_gap_right", 15), 15))
    heading_y = max(0, _safe_int(heading_top_margin, 120))
    heading_img_folder = (alignment_settings or {}).get("heading_image_folder", "") or ""
    heading_img_height = int((alignment_settings or {}).get("heading_image_height", 0) or 0)
    heading_img_path = _resolve_heading_image_path(sheet_name, heading_img_folder, alignment_settings=alignment_settings)
    heading_align = (alignment_settings or {}).get("global", {}).get("heading", "center")
    heading_h_from_img = _place_heading_image_in_png(page, Image, heading_img_path, margin_x, max_width, heading_y, heading_img_height, heading_align) if heading_img_path else 0
    if heading_h_from_img > 0:
        _heading_w, heading_h = 0, heading_h_from_img
    else:
        from . import ps_text as _ps_text_h

        with _ps_text_h.tracking(_tracking_setting(dynamic_settings, "heading_tracking")),                 _sink_ctx(kind="heading"):                                  # the heading keeps its own spacing
            _heading_w, heading_h = _draw_inline(
                page, draw, Image, heading_text, margin_x, heading_y,
                heading_font, heading_color, max_width, icon_folder, icon_mappings, heading_icon_h,
                icon_size_overrides, align="center", line_spacing=max(0, _safe_int(line_spacing, 4)),
                fx_config=_br_heading_fx, icon_gap_left=_br_head_gap_l, icon_gap_right=_br_head_gap_r,
                font_request=h_font, font_size=h_size, bold=True,
            )

    body_size = max(8, _safe_int(dynamic_settings.get("bingo_rules_body_size"), _safe_int(b_size, 24)) or _safe_int(b_size, 24))
    body_set = body_size
    body_font = _load_font(ImageFont, b_font, body_size)
    body_align = _own_align(dynamic_settings.get("bingo_rules_align")) or (alignment_settings or {}).get("body") or "center"
    override_alignments = _bingo_merged_alignments(dynamic_settings, sheet_name)
    body_ranges = _manual_ranges_for_sheet(dynamic_settings.get("bingo_rules_body_ranges", ""), sheet_name)
    # per-row looks: {"B27": {"size": px, "rgb": "#hex"}} — the row's own font size / colour
    _line_styles = dynamic_settings.get("bingo_rules_line_styles")
    _line_styles = {str(k).upper(): v for k, v in _line_styles.items() if isinstance(v, dict)} if isinstance(_line_styles, dict) else {}

    def _cell_look(cell, fit_size, base_size):
        """(font, size, colour) of a cell at the page's fit: its own size shrinks by the same factor as the page's."""
        st = _line_styles.get(str(cell).upper()) or {}
        size = fit_size
        if st.get("size") not in (None, ""):
            own = max(8, _safe_int(st.get("size"), base_size))
            size = max(8, int(round(own * fit_size / max(1, base_size))))
        color = _rgb(st.get("rgb"), body_color) if st.get("rgb") else body_color
        return _load_font(ImageFont, b_font, size), size, color

    def _override_box(coord_str, max_w):
        ov = override_alignments.get(coord_str) or {}
        align = ov.get("alignment") or body_align
        lm = ov.get("left_margin")
        rm = ov.get("right_margin")
        if lm is not None and rm is not None:
            return align, lm, max(1, canvas_w - lm - rm)
        if lm is not None:
            return align, lm, max(1, canvas_w - lm - margin_x)
        if rm is not None:
            return align, margin_x, max(1, canvas_w - margin_x - rm)
        return align, margin_x, max_w

    def cells_for_ranges(ranges):
        coords = []
        for range_ref in ranges:
            try:
                min_c, min_r, max_c, max_r = range_boundaries(range_ref)
            except Exception:
                continue
            for row_idx in range(min(min_r, max_r), max(min_r, max_r) + 1):
                for col_idx in range(min(min_c, max_c), max(min_c, max_c) + 1):
                    coords.append((row_idx, col_idx, f"{get_column_letter(col_idx).upper()}{row_idx}"))
        return coords

    current_y = max(0, _safe_int(heading_top_margin, 120)) + heading_h + max(0, _safe_int(heading_to_body_gap, 40))
    paragraph_gap = max(4, _safe_int(para_spacing, 12))
    _own_row_gap = _row_gap_setting(dynamic_settings, "bingo_rules_row_gap")      # px between a cell's wrapped lines
    cell_gap = _own_row_gap if _own_row_gap is not None else max(0, _safe_int(line_spacing, 4))
    _clean_spaces = dynamic_settings.get("bingo_rules_clean_spaces") is True or str(dynamic_settings.get("bingo_rules_clean_spaces")).strip().casefold() in ("1", "true", "yes", "on")
    from . import icon_scales as _icon_scales

    def _bingo_text(coord, value):
        value = _icon_scales.apply(sheet_name, coord, _text_edits.apply(sheet_name, coord, value))
        if _clean_spaces and value:
            value = "\n".join(re.sub(r"[ \t]{2,}", " ", ln) for ln in str(value).split("\n"))
        return value

    body_by_row = {}  # row_idx -> [(text, align, left, width, cell), ...]
    if body_ranges:
        for row_idx, col_idx, coord in cells_for_ranges(body_ranges):
            value = _bingo_text(coord, _text(ws.cell(row=row_idx, column=col_idx).value))
            if not value or value.casefold().startswith("<mod") or row_idx == heading_row:
                continue
            ov = override_alignments.get(coord)
            if ov:
                align, left, width = _override_box(coord, max_width)
                body_by_row.setdefault(row_idx, []).append((value, align, left, width, coord))
            else:
                body_by_row.setdefault(row_idx, []).append((value, body_align, margin_x, max_width, coord))
    else:
        for _row_idx, row_items in _iter_clean_cells(ws, effective_max_col, skip_rows={heading_row}, min_row=page_min_row, max_row=page_max_row):
            row_items_list = []
            for _r, _c, _coord, value in row_items:
                if _c < min_col:
                    continue
                value = _bingo_text(_coord, value)
                if not str(value or "").strip():
                    continue
                ov = override_alignments.get(_coord)
                if ov:
                    align, left, width = _override_box(_coord, max_width)
                    row_items_list.append((value, align, left, width, _coord))
                else:
                    row_items_list.append((value, body_align, margin_x, max_width, _coord))
            if row_items_list:
                body_by_row[_row_idx] = row_items_list

    available_bottom = safe_bottom
    sorted_rows = sorted(body_by_row)
    while sorted_rows and body_size > 8:
        height = 0
        for ri in sorted_rows:
            max_h = 0
            for text, _al, _lft, w, _cell in body_by_row[ri]:
                test_font = _cell_look(_cell, body_size, body_set)[0]
                _mh = _wrapped_inline_size(draw, Image, text, test_font, w, icon_folder, icon_mappings, b_icon_h, icon_size_overrides, line_spacing=cell_gap, icon_gap_left=_br_icon_gap_l, icon_gap_right=_br_icon_gap_r)[1]
                max_h = max(max_h, _mh)
            height += max_h + paragraph_gap
        if current_y + height <= available_bottom:
            break
        body_size -= 1
    body_font = _load_font(ImageFont, b_font, body_size)
    if report is not None:
        report.update({
            "canvas": [canvas_w, canvas_h], "cells": [], "default_align": body_align,
            "sizes": {"body": body_size, "row_gap": cell_gap, "body_set": max(8, _safe_int(dynamic_settings.get("bingo_rules_body_size"), _safe_int(b_size, 24)) or _safe_int(b_size, 24))},
            "heading": [margin_x, heading_y, max_width, heading_h],
            "guides": {"heading_top": heading_y, "heading_bottom": heading_y + heading_h, "body_top": current_y,
                       "safe_bottom": safe_bottom, "margin_x": margin_x},
        })
    for ri in sorted_rows:
        items = body_by_row[ri]
        max_h = 0
        size_data = []
        for text, _al, _lft, w, _cell in items:
            _mh = _wrapped_inline_size(draw, Image, text, _cell_look(_cell, body_size, body_set)[0], w, icon_folder, icon_mappings, b_icon_h, icon_size_overrides, line_spacing=cell_gap, icon_gap_left=_br_icon_gap_l, icon_gap_right=_br_icon_gap_r)[1]
            max_h = max(max_h, _mh)
            size_data.append(_mh)
        for (text, align, left, width, cell), item_h in zip(items, size_data):
            cell_font, cell_size, cell_color = _cell_look(cell, body_size, body_set)
            y_off = max(0, (max_h - item_h) / 2.0)
            if report is not None:
                tw = min(width, _wrapped_inline_size(draw, Image, text, cell_font, width, icon_folder, icon_mappings, b_icon_h, icon_size_overrides,
                                                     line_spacing=cell_gap, icon_gap_left=_br_icon_gap_l, icon_gap_right=_br_icon_gap_r)[0])
                tx = left if align in ("left", "justify") else (left + width - tw if align == "right" else left + (width - tw) / 2.0)
                report["cells"].append({"cell": cell, "row": ri, "text": _untag_text(text), "align": align,
                                        "rect": [round(tx, 1), round(current_y + y_off, 1), round(tw, 1), round(item_h, 1)],
                                        "size": cell_size, "rgb": "#%02X%02X%02X" % tuple(cell_color)})
            from . import text_styles as _ts_row

            with _sink_ctx(kind="body", cell=cell, part="bingo"), _ts_row.row(text):
              _draw_inline(
                page, draw, Image, text, left, current_y + y_off, cell_font, cell_color, width,
                icon_folder, icon_mappings, b_icon_h, icon_size_overrides, align=align,
                line_spacing=cell_gap,
                fx_config=_br_body_fx, icon_gap_left=_br_icon_gap_l, icon_gap_right=_br_icon_gap_r,
                font_request=b_font, font_size=cell_size,
            )
        current_y += max_h + paragraph_gap
    return [page]


def _render_paylines_png_pages(
    Image, ImageDraw, ImageFont, ws, sheet_name, bg_path, bg_mode, bg_color, canvas_w, canvas_h,
    h_font, h_size, h_icon_h, h_rgb, margin_x, heading_top_margin, line_spacing,
    icon_folder, icon_mappings, icon_size_overrides, dynamic_settings, alignment_settings, counts=None, meta=None,
    every=False,
):
    """Paylines / Win Lines: one page per denomination group, drawn from the
    Excel patterns (dynamic_pages/paylines.py). Returns ([(name, page)], warnings);
    raises paylines.PaylineError when the sheet's data is wrong."""
    from .dynamic_pages import paylines as _pl

    dynamic_settings = dynamic_settings or {}
    alignment_settings = alignment_settings or {}
    cfg = _pl.settings_for(dynamic_settings, canvas_w)
    heading_fx = _resolve_fx_config(dynamic_settings.get("layer_style_library", {}) or {},
                                    dynamic_settings.get("style_assignments", {}) or {}, "Heading text")
    heading_font = _heading_font(ImageFont, h_font, h_size, dynamic_settings)
    max_width = max(100, canvas_w - margin_x * 2)
    heading_y = max(0, _safe_int(heading_top_margin, 120))
    heading_align = (alignment_settings.get("global") or {}).get("heading", "center")
    heading_text = str(cfg.get("heading_text") or "").strip()

    def draw_page(name, count):
        page = Image.new("RGBA", (canvas_w, canvas_h), (0, 0, 0, 0) if _sink_skips_text() else (255, 255, 255, 255))
        if not _sink_skips_text():                 # the Canvas's picture of the page draws its own background
            _draw_background(page, Image, bg_path, bg_mode, bg_color)
        draw = ImageDraw.Draw(page)
        img_path = _resolve_heading_image_path(sheet_name, alignment_settings.get("heading_image_folder", "") or "",
                                               alignment_settings=alignment_settings)
        hh = 0
        if img_path:
            hh = _place_heading_image_in_png(page, Image, img_path, margin_x, max_width, heading_y,
                                             int(alignment_settings.get("heading_image_height", 0) or 0), heading_align)
        if not hh and heading_text:
            from . import ps_text as _pst_h

            with _pl.tagged_texts(page, "Heading"), _sink_ctx(kind="heading"),                     _pst_h.tracking(_tracking_setting(dynamic_settings, "heading_tracking")):
                _w, hh = _draw_inline(
                    page, draw, Image, heading_text, margin_x, heading_y, heading_font, _rgb(h_rgb, (255, 80, 80)),
                    max_width, icon_folder, icon_mappings, max(1, _safe_int(h_icon_h, _safe_int(h_size, 48))),
                    icon_size_overrides, align=heading_align,
                    line_spacing=_row_gap_px(max(8, _safe_int(h_size, 48)), line_spacing),
                    fx_config=heading_fx, font_request=h_font, font_size=h_size, bold=True,
                )
        return page, draw, heading_y + hh

    return _pl.render_pages(ws, dynamic_settings, canvas_w, canvas_h, draw_page, counts=counts, meta=meta, every=every)


def _png_merge_legacy_kwargs(dynamic_settings, legacy_kwargs):
    """Merge Paytable-style controls passed as top-level kwargs by older callers.

    Older builds swallowed these in **kwargs, so count_size/value_size/etc.
    never reached the Paytable renderer. Only Paytable-style keys are merged;
    normal pages/tables/GameRules stay untouched. Returns the same mapping,
    mutated via setdefault, plus the list of merged key names."""
    if not isinstance(legacy_kwargs, dict) or not legacy_kwargs:
        return dynamic_settings, []
    style_prefixes = (
        "count_", "value_", "wild_", "notes_", "bottom_notes",
        "dynamic_count_", "dynamic_value_", "dynamic_wild_", "dynamic_notes_",
        "paytable_count_", "paytable_value_", "paytable_wild_", "paytable_notes_",
        "inline_icon", "dynamic_inline_", "paytable_inline_",
        "subheading_", "game_rules_",
    )
    passthrough_keys = {
        "page_heading_cell_overrides", "page_subheading_cell_overrides",
        "per_page_heading_sizes", "page_heading_sizes",
        "heading_size_overrides", "per_page_heading_size_overrides",
        "png_page_name", "custom_png_page_name", "custom_png_name",
        "page_multi_heading_overrides",
        "icon_gap_left", "icon_gap_right",
        "heading_icon_gap", "heading_icon_gap_left", "heading_icon_gap_right",
    }
    merged_keys = []
    for key, value in legacy_kwargs.items():
        key_s = str(key or "")
        if not (key_s.startswith(style_prefixes) or key_s in passthrough_keys):
            continue
        if value is None or (isinstance(value, str) and not value.strip()):
            continue
        if key_s not in dynamic_settings:
            merged_keys.append(key_s)
        dynamic_settings.setdefault(key_s, value)
    return dynamic_settings, sorted(merged_keys)


def _png_existing_custom_png_indices(target_dir, custom_png_base):
    used = set()
    if not custom_png_base or not os.path.isdir(target_dir):
        return used
    pattern = re.compile(rf"^{re.escape(custom_png_base)}(\d+)\.png$", re.IGNORECASE)
    try:
        for filename in os.listdir(target_dir):
            match = pattern.match(filename)
            if match:
                used.add(int(match.group(1)))
    except Exception:
        pass
    return used


def _png_collect_mapped_source_rows(record, ws):
    rows = set()
    spec = record.get("spec") or {}
    template = record.get("template") or {}
    sources = []
    raw_sr = spec.get("source_range")
    if raw_sr:
        sources.append(str(raw_sr).strip())
    for mapping in (spec.get("mappings") or []):
        s = str((mapping or {}).get("source") or "").strip()
        if s:
            sources.append(s)
    for slot_name, slot_def in (template.get("slots") or {}).items():
        s = str((slot_def or {}).get("source") or "").strip()
        if s:
            sources.append(s)
    for table_name, table_spec in (template.get("table_templates") or {}).items():
        s = str((table_spec or {}).get("source_range") or "").strip()
        if s:
            sources.append(s)
    for source in sources:
        bounds = direct_range_bounds(source)
        if bounds:
            rows.add(bounds[1])
            rows.add(bounds[3])
            continue
        try:
            key = str(source).strip()
            defined_names = ws.parent.defined_names
            if key not in defined_names:
                continue
            destinations = list(defined_names[key].destinations)
            for _sheet_name, coordinate in destinations:
                try:
                    _min_c, min_r, _max_c, max_r = range_boundaries(coordinate)
                    rows.update(range(min_r, max_r + 1))
                except Exception:
                    pass
        except Exception:
            pass
    if not rows:
        return None
    return (min(rows), max(rows))


def _png_sheet_page_style(sheet_name, page_overrides, h_font, h_rgb, b_font, b_rgb, h_size, b_size, dynamic_settings):
    """Per-sheet font/color/size overrides plus the effective Row Gap setting."""
    ps_ov = _png_page_style_override(sheet_name, page_overrides)
    pg_h_font = str(ps_ov.get("h_font") or h_font)
    pg_h_rgb = ps_ov.get("h_rgb") or h_rgb
    pg_b_font = str(ps_ov.get("b_font") or b_font)
    pg_b_rgb = ps_ov.get("b_rgb") or b_rgb
    pg_h_size = h_size
    if ps_ov.get("h_size") is not None:
        try:
            pg_h_size = max(8, int(float(ps_ov.get("h_size") or h_size)))
        except Exception:
            pg_h_size = h_size
    pg_b_size = b_size
    if ps_ov.get("b_size") is not None:
        try:
            pg_b_size = max(8, int(float(ps_ov.get("b_size") or b_size)))
        except Exception:
            pg_b_size = b_size
    pg_line_gap = dynamic_settings.get("line_gap") if "line_gap" in dynamic_settings else None
    return {
        "override": ps_ov,
        "h_font": pg_h_font,
        "h_rgb": pg_h_rgb,
        "b_font": pg_b_font,
        "b_rgb": pg_b_rgb,
        "h_size": pg_h_size,
        "b_size": pg_b_size,
        "line_gap": pg_line_gap,
    }


def _png_multi_heading_rows(ws, sheet_name, raw):
    """Parse 'PageName=A1,B2' overrides into {row_index: heading_text}."""
    multi_heading_rows = {}
    if not raw:
        return multi_heading_rows
    sheet_key = re.sub(r"\s+", " ", str(sheet_name or "").strip()).casefold().strip()
    for part in re.split(r"[\n;]+", raw):
        item = str(part or "").strip()
        if not item or "=" not in item:
            continue
        page_part, rhs = item.split("=", 1)
        page_key = re.sub(r"\s+", " ", page_part.strip()).casefold().strip()
        if page_key != sheet_key:
            continue
        for token in rhs.split(","):
            token_s = str(token or "").strip()
            coord_match = None
            for m in re.finditer(r"([A-Za-z]{1,4})(\d+)", token_s):
                coord_match = m
            if coord_match:
                col_str, row_str = coord_match.group(1).upper(), coord_match.group(2)
                col_idx = column_index_from_string(col_str)
                row_num = int(row_str)
                try:
                    value = _text(ws.cell(row=row_num, column=col_idx).value)
                    if value:
                        multi_heading_rows[row_num] = value
                except Exception:
                    continue
    return multi_heading_rows


def _png_filter_tables_overlapping_mapped(tables, mapped_for_sheet):
    """Drop auto-detected tables whose rows are covered by a mapped JSON table."""
    if not mapped_for_sheet or not tables:
        return tables
    mapped_row_ranges = []
    for record in mapped_for_sheet:
        row_range = source_row_range_for_template(record)
        if row_range:
            mapped_row_ranges.append((int(row_range[0]), int(row_range[1])))
    if not mapped_row_ranges:
        return tables
    filtered_tables = []
    for table in tables:
        t_start = int(table.get("start_row", 0))
        t_end = int(table.get("end_row", 0))
        overlaps = False
        for m_start, m_end in mapped_row_ranges:
            if not (t_end < m_start or t_start > m_end):
                overlaps = True
                break
        if not overlaps:
            filtered_tables.append(table)
    return filtered_tables


def _settings_snapshot():
    """The shared settings the server keeps live (text edits, icon sizes, row roles, page boxes)."""
    import copy

    from . import global_light, icon_scales, page_boxes, row_roles, text_edits

    return [(d, copy.deepcopy(d)) for d in (text_edits._EDITS, icon_scales._SCALES, icon_scales._GAPS, row_roles._ROLES, row_roles._SUB,
                                           page_boxes._STATE, global_light._STATE)]


def _settings_restore(snapshot, built=None):
    """Put the server's settings back after a build — only those nobody changed while it ran: an edit
    saved meanwhile (the server loaded it over the build's) stays, never the build's older copy."""
    for i, (live, saved) in enumerate(snapshot):
        if built is not None and live != built[i][1]:
            continue
        live.clear()
        live.update(saved)


def build_pngs_only(
    excel_path, icon_folder, bg_path, c_width, c_height, max_col_limit,
    h_font, h_size, h_icon_h, h_rgb,
    b_font, b_size, b_icon_h, b_rgb,
    margin_x, line_spacing, para_spacing,
    gap_px, icon_y_offset,
    bg_mode="stretch", bg_color="#FFFFFF", table_style=None, enable_tables=True,
    prev_excel_path=None, prev_psd_path=None,
    keyword_colors=None, heading_top_margin=150, continued_gap=15,
    heading_to_body_gap=40, heading_style=None, body_style=None,
    icon_style=None, dynamic_settings=None, output_dir=None,
    icon_mappings=None, icon_size_overrides=None, bottom_margin=80,
    output_name=None, output_format="psd", overwrite_existing=False, png_output_dir=None,
    selected_sheets=None, body_icons_use_original_size=False,
    report_collector=None, alignment_settings=None, performance_mode=False,
    progress_callback=None, cancel_event=None, show_completion_dialogs=True,
    png_suffix=None, page_overrides=None, inner_canvas_width=0,
    use_canonical_layout=None, png_compress_level=6, **legacy_extra_kwargs,
):
    Image, ImageDraw, ImageFont = _require_pillow()
    if not excel_path or not os.path.isfile(excel_path):
        raise FileNotFoundError("Excel file not found for PNG build.")
    _clear_build_caches()
    table_style = dict(TABLE_DEFAULTS, **(table_style or {}))
    icon_mappings = dict(icon_mappings or {})
    icon_size_overrides = dict(icon_size_overrides or {})
    canvas_w = max(100, _safe_int(c_width, 1920))
    canvas_h = max(100, _safe_int(c_height, 1080))
    margin_x = max(0, _safe_int(margin_x, 100))
    bottom_margin = max(0, _safe_int(bottom_margin, 80))
    safe_left, safe_width = _inner_safe_box(canvas_w, canvas_h, margin_x, inner_canvas_width)
    safe_bottom = max(heading_top_margin + 100, canvas_h - bottom_margin)

    heading_image_folder = (alignment_settings or {}).get("heading_image_folder", "") or ""
    heading_image_height = int((alignment_settings or {}).get("heading_image_height", 0) or 0)
    heading_image_align = (alignment_settings or {}).get("global", {}).get("heading", "center")

    raw_output_name = str(output_name or "").strip()
    base_name = os.path.splitext(os.path.basename(raw_output_name or excel_path))[0]
    target_root = output_dir or os.path.dirname(os.path.abspath(excel_path))
    target_dir = os.path.join(target_root, f"{_file_safe(base_name)}_PNGs")
    if png_output_dir:
        target_dir = str(png_output_dir)          # e.g. the market's Help Screen/Static folder
    os.makedirs(target_dir, exist_ok=True)

    # Explicit PNG page name only.  Do NOT use output_name here because output_name
    # is often the PSD/group/build name. If no custom PNG name is supplied,
    # fallback naming must use Excel sheet names.
    custom_png_base = ""
    explicit_png_name = (
        str(png_suffix or "").strip()
        or str((dynamic_settings or {}).get("png_page_name") or "").strip()
        or str((dynamic_settings or {}).get("custom_png_page_name") or "").strip()
        or str((dynamic_settings or {}).get("custom_png_name") or "").strip()
    )
    if explicit_png_name:
        custom_png_base = _file_safe(os.path.splitext(os.path.basename(explicit_png_name))[0])

    from . import workbook_cache

    from . import text_edits as _text_edits

    # the build loads its own text edits / icon sizes / row roles / boxes into the shared settings;
    # what was there (the server's live settings) comes back when it is done — a page-picture build
    # from an older snapshot must never leave its settings behind for the live preview
    _live_settings = _settings_snapshot()
    _text_edits.set_all((dynamic_settings or {}).get("text_edits"))
    from . import icon_scales as _icon_scales

    _icon_scales.set_all((dynamic_settings or {}).get("icon_scales"), (dynamic_settings or {}).get("icon_gaps"))
    from . import row_roles as _row_roles_mod

    _row_roles_mod.set_all(dynamic_settings or {})
    from . import page_boxes as _page_boxes_mod

    _page_boxes_mod.set_all(dynamic_settings or {})
    from . import global_light as _global_light_mod

    _global_light_mod.set_all(dynamic_settings or {})
    _build_settings = _settings_snapshot()              # what this build put there (see _settings_restore)
    _wb_loan = workbook_cache.borrow(excel_path)       # parsed once per Excel version, reused
    wb = _wb_loan.__enter__()
    _excel_ctx = _BUILD_EXCEL.set(str(excel_path or ""))
    from . import text_styles as _text_styles
    _styles_ctx = _text_styles.begin((dynamic_settings or {}).get("text_style_rules") or [],
                                     (dynamic_settings or {}).get("layer_style_library"))
    try:
        # a sheet hidden in Excel is never a page (not even when it was picked before it was hidden)
        visible = visible_sheet_names(wb)
        wanted = [str(s) for s in (selected_sheets or []) if str(s) in visible]
        sheet_names = wanted or visible
        _emit(progress_callback, "build_start", total=len(sheet_names), sheet="")
        _note(report_collector, "PNG-only builder active. It uses a separate flat-image renderer and leaves the PSD renderer untouched.")

        mapped_records = load_mapped_table_templates(table_style.get("mapped_table_jsons", ""), sheet_overrides=table_style.get("json_sheet_overrides") or {})
        mapped_records = [r for r in mapped_records if not r.get("error")]
        dynamic_settings = dict(dynamic_settings or {})
        _layer_style_library = dynamic_settings.get("layer_style_library", {}) or {}
        _style_assignments = dynamic_settings.get("style_assignments", {}) or {}
        _heading_fx = _resolve_fx_config(_layer_style_library, _style_assignments, "Heading text")
        _body_fx = _resolve_fx_config(_layer_style_library, _style_assignments, "Body text")
        _subheading_fx = _resolve_fx_config(_layer_style_library, _style_assignments, "Subheading text")
        _game_rules_text_fx = _resolve_fx_config(_layer_style_library, _style_assignments, "Game Rules text")
        _game_rules_legal_fx = _resolve_fx_config(_layer_style_library, _style_assignments, "Malfunction/legal text")

        _icon_gap_l = max(0, _safe_int(dynamic_settings.get("icon_gap_left", 15), 15))
        _icon_gap_r = max(0, _safe_int(dynamic_settings.get("icon_gap_right", 15), 15))
        _head_gap_l = max(0, _safe_int(dynamic_settings.get("heading_icon_gap_left", dynamic_settings.get("heading_icon_gap", 15)), 15))
        _head_gap_r = max(0, _safe_int(dynamic_settings.get("heading_icon_gap_right", dynamic_settings.get("heading_icon_gap", 15)), 15))

        # Some PNG-only callers pass Paytable controls as top-level kwargs.
        # Older builds swallowed those in **kwargs, so count_size/value_size/
        # wild_text_size/etc. never reached the Paytable renderer.  Merge only
        # Paytable-style keys here; normal pages/tables/GameRules stay untouched.
        dynamic_settings, merged_legacy_keys = _png_merge_legacy_kwargs(dynamic_settings, legacy_extra_kwargs)
        if merged_legacy_keys:
            _note(report_collector, f"Legacy top-level kwargs merged into paytable settings: {', '.join(merged_legacy_keys)}")

        used_custom_png_indices = _png_existing_custom_png_indices(target_dir, custom_png_base)

        page_export_counter = 0

        def _next_custom_png_name():
            nonlocal page_export_counter
            while page_export_counter in used_custom_png_indices:
                page_export_counter += 1
            used_custom_png_indices.add(page_export_counter)
            out_name = f"{custom_png_base}{page_export_counter}.png"
            page_export_counter += 1
            return out_name

        def _save_pages_for_sheet(local_sheet_name, local_pages):
            from .psd_writer import recorder as _psd_recorder
            _rec = _psd_recorder.active_recorder()
            if _rec is not None:  # PSD build: hand the pages over, write no PNGs
                _rec.commit_sheet(local_sheet_name, local_pages)
                return
            for part_index, img in enumerate(local_pages, start=1):
                if custom_png_base:
                    out_name = _next_custom_png_name()
                else:
                    cont = "" if part_index == 1 else f"_Continued_{part_index - 1}"
                    out_name = f"{_file_safe(local_sheet_name)}{cont}.png"
                out_path = os.path.join(target_dir, out_name)
                # previews pass a low level: same pixels, ~5x faster encode, bigger file
                img.convert("RGB").save(out_path, "PNG", compress_level=int(png_compress_level))

        for index, sheet_name in enumerate(sheet_names, start=1):
            _text_styles.set_sheet(sheet_name)          # page-only word styles / strips
            _check_cancel(cancel_event)
            _emit(progress_callback, "sheet_start", sheet=sheet_name, index=index, total=len(sheet_names))
            ws = wb[sheet_name]
            _ps_ov_png = _png_sheet_page_style(
                sheet_name, page_overrides, h_font, h_rgb, b_font, b_rgb, h_size, b_size, dynamic_settings,
            )
            _pg_h_font = _ps_ov_png["h_font"]
            _pg_h_rgb = _ps_ov_png["h_rgb"]
            _pg_b_font = _ps_ov_png["b_font"]
            _pg_b_rgb = _ps_ov_png["b_rgb"]
            _pg_h_size = _ps_ov_png["h_size"]
            _pg_b_size = _ps_ov_png["b_size"]
            # UI 'Row spacing' (line_gap, px): PSD semantics -- a real gap
            # between row CONTENT boxes (union of text glyphs + icons). When
            # provided it overrides the line-spacing multiplier fallback.
            _pg_line_gap = _ps_ov_png["line_gap"]

            page_min_row, page_max_row, page_min_col, page_max_col = _render_window_for_sheet(
                dynamic_settings, sheet_name, max_col_limit, ws,
            )
            if page_min_row > 1 or page_max_row < (ws.max_row or 1):
                _note(
                    report_collector,
                    f"{sheet_name} renders rows {page_min_row}-{page_max_row}, "
                    f"cols {page_min_col}-{page_max_col} (row window)",
                )

            tables = _prepare_tables(ws, table_style, page_max_col, sheet_name, min_col_limit=page_min_col) if enable_tables else []
            if enable_tables and tables and (page_min_row > 1 or page_max_row < (ws.max_row or 1)):
                tables = [
                    t for t in tables
                    if int(t.get("start_row", 0)) <= page_max_row and int(t.get("end_row", 0)) >= page_min_row
                ]
            mapped_for_sheet = [r for r in mapped_records if template_matches_sheet(r, sheet_name)]

            if enable_tables:
                tables = _png_filter_tables_overlapping_mapped(tables, mapped_for_sheet)

            skip_ranges = []
            for table in tables:
                skip_ranges.append((int(table["start_row"]), int(table["end_row"])))
            for record in mapped_for_sheet:
                consumed = mapped_record_consumed_rows(record)
                if consumed:
                    skip_ranges.append((min(consumed), max(consumed)))
            heading_row, heading_text = _find_heading_row(ws, page_max_col, skip_ranges, min_row=page_min_row, max_row=page_max_row)
            heading_text = game_name_heading(heading_text or sheet_name, dynamic_settings, icon_folder, icon_mappings)

            current_sheet_heading_size = (_pg_h_size if _ps_ov_png.get("h_size") is not None
                                          else _png_heading_size_for_sheet(sheet_name, dynamic_settings, _pg_h_size))
            section_heading_cells = _png_cell_coords_for_sheet(dynamic_settings.get("page_heading_cell_overrides", ""), sheet_name)
            section_subheading_cells = _png_cell_coords_for_sheet(dynamic_settings.get("page_subheading_cell_overrides", ""), sheet_name)
            multi_heading_rows = _png_multi_heading_rows(
                ws, sheet_name, str(dynamic_settings.get("page_multi_heading_overrides") or "").strip(),
            )
            text_rectangle_cells = _png_cell_coords_for_sheet(
                (table_style or {}).get("text_rectangle_cells", ""), sheet_name,
            )
            section_heading_mode = bool(section_heading_cells or section_subheading_cells or multi_heading_rows)
            multi_heading_mode = bool(multi_heading_rows)






















            pages = []
            page = Image.new("RGBA", (canvas_w, canvas_h), (255, 255, 255, 255))
            _draw_background(page, Image, bg_path, bg_mode, bg_color)
            draw = ImageDraw.Draw(page)

            # --- PAYLINES / WIN LINES (drawn from the Excel patterns) ---
            from .dynamic_pages import paylines as _paylines
            if _paylines.is_payline_page(ws):
                try:
                    _pl_pages, _pl_warnings = _render_paylines_png_pages(
                        Image, ImageDraw, ImageFont, ws, sheet_name, bg_path, bg_mode, bg_color, canvas_w, canvas_h,
                        _pg_h_font, current_sheet_heading_size, h_icon_h, _pg_h_rgb, margin_x, heading_top_margin,
                        line_spacing, icon_folder, icon_mappings, icon_size_overrides, dynamic_settings,
                        alignment_settings,
                    )
                except _paylines.PaylineError as _pl_exc:
                    _warn(report_collector, f"Paylines page not built: {_pl_exc}")
                    _emit(progress_callback, "sheet_done", sheet=sheet_name, index=index, total=len(sheet_names))
                    continue
                for _pl_warning in _pl_warnings:
                    _warn(report_collector, _pl_warning)
                for _pl_name, _pl_page in _pl_pages:
                    _save_pages_for_sheet(_pl_name, [_pl_page])
                if _pl_pages:
                    _note(report_collector, f"Paylines pages saved for {sheet_name}: "
                          + ", ".join(n for n, _p in _pl_pages))
                _emit(progress_callback, "sheet_done", sheet=sheet_name, index=index, total=len(sheet_names))
                continue

            # --- DYNAMIC JSON PAGE INTERCEPTION ---
            # If a custom JSON layout is assigned to this sheet, render it 
            # instead of the normal row-by-row flow.
            dynamic_enabled = bool(dynamic_settings.get('enabled', False))
            template_json_map = dynamic_settings.get('template_json_map', {})
            default_template_json = dynamic_settings.get('template_json', '')
            
            json_path_for_sheet = None
            if dynamic_enabled:
                json_path_for_sheet = template_json_map.get(sheet_name)
                if not json_path_for_sheet and sheet_name.lower() == dynamic_settings.get('sheet_name', '').lower():
                    json_path_for_sheet = default_template_json
                    
            if json_path_for_sheet and os.path.isfile(json_path_for_sheet):
                # Pass mapped_records + sheet_overrides so _render_dynamic_json_page_png
                # can merge table_templates/flow_regions from the mapped JSON data.
                _render_ds = dict(dynamic_settings)
                _render_ds["_mapped_records"] = mapped_records
                _render_ds["_json_sheet_overrides"] = table_style.get("json_sheet_overrides") or {}
                _render_dynamic_json_page_png(
                    page, draw, Image, ImageFont, ws, sheet_name, json_path_for_sheet,
                    _render_ds, icon_folder, icon_mappings, icon_size_overrides,
                    canvas_w, canvas_h, _pg_h_font, _pg_h_size, _pg_h_rgb, _pg_b_font, _pg_b_size, _pg_b_rgb,
                    gap_px, line_spacing, report_collector
                )
                pages.append(page)
                _save_pages_for_sheet(sheet_name, pages)
                _note(report_collector, f"PNG page saved for {sheet_name} using dynamic JSON layout.")
                _emit(progress_callback, "sheet_done", sheet=sheet_name, index=index, total=len(sheet_names))
                continue # Skip normal heading and row rendering for this sheet
            # --------------------------------------

            special_kind = _normalized_sheet_kind(sheet_name)
            if special_kind == "game_rules":
                pages = _render_game_rules_png_pages(
                    Image, ImageDraw, ImageFont, ws, sheet_name, bg_path, bg_mode, bg_color, canvas_w, canvas_h,
                    _pg_h_font, current_sheet_heading_size, h_icon_h, _pg_h_rgb, _pg_b_font, _pg_b_size, b_icon_h, _pg_b_rgb, margin_x,
                    heading_top_margin, heading_to_body_gap, bottom_margin, line_spacing, para_spacing,
                    icon_folder, icon_mappings, icon_size_overrides, dynamic_settings, alignment_settings,
                    page_min_col=page_min_col, page_max_col=page_max_col,
                    page_min_row=page_min_row, page_max_row=page_max_row,
                )
                _save_pages_for_sheet(sheet_name, pages)
                _note(report_collector, f"PNG GameRules page saved for {sheet_name}: {len(pages)}")
                _emit(progress_callback, "sheet_done", sheet=sheet_name, index=index, total=len(sheet_names))
                continue
            if special_kind == "bingo_rules":
                pages = _render_bingo_rules_png_pages(
                    Image, ImageDraw, ImageFont, ws, sheet_name, bg_path, bg_mode, bg_color, canvas_w, canvas_h,
                    _pg_h_font, _pg_h_size, h_icon_h, _pg_h_rgb, _pg_b_font, _pg_b_size, b_icon_h, _pg_b_rgb, margin_x,
                    heading_top_margin, heading_to_body_gap, bottom_margin, line_spacing, para_spacing,
                    icon_folder, icon_mappings, icon_size_overrides, dynamic_settings, alignment_settings,
                    page_min_col=page_min_col, page_max_col=page_max_col,
                    page_min_row=page_min_row, page_max_row=page_max_row,
                )
                _save_pages_for_sheet(sheet_name, pages)
                _note(report_collector, f"PNG BingoRules page saved for {sheet_name}: {len(pages)}")
                _emit(progress_callback, "sheet_done", sheet=sheet_name, index=index, total=len(sheet_names))
                continue

            # --- CANONICAL LAYOUT PIPELINE (opt-in, feature-flagged) --------
            # When the canonical pipeline is enabled AND this sheet only uses
            # features the PageLayout model carries (plain text pages without
            # tables, section headings, text rectangles or heading images),
            # the page is laid out ONCE by layout_engine and rendered by the
            # canonical PNG adapter. Everything else keeps the historical
            # path below, so existing output/behaviour is preserved. The
            # layout engine itself returns None for anything it can't
            # guarantee, and the historical path then renders as before.
            _canonical_on = (
                use_canonical_layout if use_canonical_layout is not None else canonical_layout_enabled()
            )
            _canonical_supported = (
                _canonical_on
                and not section_heading_mode
                and not multi_heading_mode
                and not text_rectangle_cells
                and not mapped_for_sheet
                and not heading_image_folder
            )
            if _canonical_supported:
                _canonical_layouts = None
                try:
                    from .layout_engine import build_normal_page_layouts

                    _canonical_layouts = build_normal_page_layouts(
                        ws, sheet_name,
                        canvas_w=canvas_w, canvas_h=canvas_h, margin_x=margin_x,
                        inner_canvas_width=inner_canvas_width,
                        h_font=_pg_h_font, h_size=current_sheet_heading_size, h_icon_h=h_icon_h, h_rgb=_pg_h_rgb,
                        b_font=_pg_b_font, b_size=_pg_b_size, b_icon_h=b_icon_h, b_rgb=_pg_b_rgb,
                        line_spacing=line_spacing, para_spacing=para_spacing, line_gap=_pg_line_gap,
                        continued_gap=continued_gap,
                        heading_top_margin=heading_top_margin,
                        heading_to_body_gap=heading_to_body_gap,
                        bottom_margin=bottom_margin,
                        icon_folder=icon_folder, icon_mappings=icon_mappings,
                        icon_size_overrides=icon_size_overrides,
                        heading_fx=_heading_fx, body_fx=_body_fx,
                        page_min_row=page_min_row, page_max_row=page_max_row,
                        page_min_col=page_min_col, page_max_col=page_max_col,
                        heading_row=heading_row, heading_text=heading_text,
                        alignment_settings=alignment_settings,
                        heading_image_folder=heading_image_folder,
                        heading_image_height=heading_image_height,
                        icon_gap_left=_icon_gap_l, icon_gap_right=_icon_gap_r,
                        heading_icon_gap_left=_head_gap_l, heading_icon_gap_right=_head_gap_r,
                        letter_spacing={"heading": _tracking_setting(dynamic_settings, "heading_tracking"),
                                        "body": _tracking_setting(dynamic_settings, "body_tracking"),
                                        "heading_shape": heading_shape(dynamic_settings)},
                        tables=tables, table_style=table_style,
                        table_overrides=(((dynamic_settings or {}).get("live_overrides") or {}).get(sheet_name) or {}),
                    )
                except Exception as _canonical_exc:
                    _canonical_layouts = None
                    _note(report_collector, f"Canonical layout skipped on {sheet_name}: {_canonical_exc}")
                if _canonical_layouts:
                    from .canonical_png import render_layout_pages

                    _manifest_dir = str((dynamic_settings or {}).get("layout_manifest_dir") or "").strip()
                    if _manifest_dir:
                        try:
                            from .layout_manifest import manifest_from_layouts, write_manifest

                            write_manifest(
                                os.path.join(_manifest_dir, f"{_file_safe(sheet_name)}.layout.json"),
                                manifest_from_layouts(_canonical_layouts),
                            )
                        except Exception as _manifest_exc:
                            _note(report_collector, f"Manifest export failed on {sheet_name}: {_manifest_exc}")
                    def _draw_layout_table(page_img, page_draw, el, _ws=ws, _tables=tables):
                        m = el.meta or {}
                        try:
                            table = _tables[int(m.get("table"))]
                        except (TypeError, ValueError, IndexError):
                            return
                        sl = m.get("slice")
                        _draw_auto_table(
                            page_img, page_draw, Image, ImageFont, _ws, table,
                            float(el.x) + float(m.get("dx") or 0), float(el.y) + float(m.get("dy") or 0), float(el.width),
                            dict(table_style, table_alignment=m.get("align") or table_style.get("table_alignment")),
                            icon_folder, icon_mappings, icon_size_overrides,
                            available_height=m.get("cap"), row_slice=tuple(sl) if sl else None,
                        )

                    pages = render_layout_pages(
                        _canonical_layouts,
                        bg_path=bg_path, bg_mode=bg_mode, bg_color=bg_color,
                        icon_folder=icon_folder, icon_mappings=icon_mappings,
                        icon_size_overrides=icon_size_overrides,
                        table_drawer=_draw_layout_table,
                    )
                    _save_pages_for_sheet(sheet_name, pages)
                    _note(report_collector, f"PNG page(s) saved for {sheet_name} via canonical layout: {len(pages)}")
                    _emit(progress_callback, "sheet_done", sheet=sheet_name, index=index, total=len(sheet_names))
                    continue
            # ----------------------------------------------------------------

            heading_font = _heading_font(ImageFont, _pg_h_font, current_sheet_heading_size, dynamic_settings)
            body_font = _load_font(ImageFont, _pg_b_font, _pg_b_size)
            subheading_font_name = (
                dynamic_settings.get("subheading_font_request")
                or _with_font_style(dynamic_settings.get("subheading_font") or _pg_h_font, dynamic_settings.get("subheading_font_style") or "")
                or _pg_h_font
            )
            subheading_size = max(8, _safe_int(dynamic_settings.get("subheading_size"), max(8, int(current_sheet_heading_size * 0.65))))
            subheading_font = _load_font(ImageFont, subheading_font_name, subheading_size, bold=True)
            from . import row_roles as _rr_cont

            _cont_look = _rr_cont.continued_look(_pg_h_font, current_sheet_heading_size, _pg_b_rgb)   # Typography › Continued
            continued_font = _load_font(ImageFont, _cont_look["font"], _cont_look["size"],
                                        bold=_cont_look["bold"], italic=_cont_look["italic"])
            heading_icon_h = max(1, _safe_int(h_icon_h, _safe_int(current_sheet_heading_size, 48)))
            subheading_icon_h = max(1, max(_safe_int(b_icon_h, subheading_size), subheading_size))
            heading_color = _rgb(_pg_h_rgb, (255, 80, 80))
            subheading_color = _rgb(dynamic_settings.get("subheading_rgb"), heading_color)
            body_color = _rgb(_pg_b_rgb, (255, 255, 255))
            current_y = max(0, _safe_int(heading_top_margin, 120))
            from . import ps_text as _ps_text
            _h_trk = _tracking_setting(dynamic_settings, "heading_tracking")
            _b_trk = _tracking_setting(dynamic_settings, "body_tracking")
            current_section_heading_text = None
            _cont_row, _cont_first = None, False
            if not section_heading_mode or not multi_heading_rows:
                # the Excel's own "(Cont.)" / "CONTINUED" note after the heading: the tool's "(Continued)" instead
                heading_text, _cont_row, _cont_first = _rr_cont.continued_from_excel(
                    heading_text, lambda r: _row_page_text(ws, r, page_max_col, page_min_col), heading_row, page_max_row)
                current_section_heading_text = heading_text
                heading_img_path = _resolve_heading_image_path(sheet_name, heading_image_folder, alignment_settings=alignment_settings)
                heading_h_from_img = _place_heading_image_in_png(page, Image, heading_img_path, safe_left, safe_width, current_y, heading_image_height, heading_image_align) if heading_img_path else 0
                if heading_h_from_img > 0:
                    mh = heading_h_from_img
                else:
                    # rules made for just the heading's text apply to it (as layout_engine's heading)
                    with _text_styles.row(heading_text), _ps_text.tracking(_h_trk):
                        _mw, mh = _draw_inline(
                        page, draw, Image, heading_text, safe_left, current_y, heading_font, heading_color,
                        safe_width, icon_folder, icon_mappings, heading_icon_h, icon_size_overrides,
                        align=_text_alignment(alignment_settings, sheet_name, "heading"),
                        line_spacing=_row_gap_px(max(8, _safe_int(current_sheet_heading_size, 48)), line_spacing),
                        fx_config=_heading_fx, icon_gap_left=_head_gap_l, icon_gap_right=_head_gap_r,
                        icon_y_offset=icon_y_offset,
                        font_request=_pg_h_font, font_size=current_sheet_heading_size, bold=True,
                    )
                current_y += mh + max(0, _safe_int(heading_to_body_gap, 40))
                if _cont_first:                      # spaced like a Continued page's (new_page below)
                    cont_gap = max(2, _safe_int(continued_gap, 8), 8)
                    _cw, extra_h = _draw_inline(
                        page, draw, Image, "(Continued)", safe_left, current_y - max(0, _safe_int(heading_to_body_gap, 40)) + cont_gap,
                        continued_font, _cont_look["rgb"], safe_width, icon_folder, icon_mappings,
                        max(1, int(heading_icon_h * 0.38)), icon_size_overrides,
                        align=_rr_cont.continued_align(_text_alignment(alignment_settings, sheet_name, "heading")), line_spacing=_row_gap_px(max(8, _safe_int(current_sheet_heading_size, 48)), line_spacing),
                        icon_gap_left=_icon_gap_l, icon_gap_right=_icon_gap_r,
                        fx_config=_cont_look["fx"], font_request=_cont_look["font"], font_size=_cont_look["size"],
                        bold=_cont_look["bold"],
                    )
                    _cbg = _rr_cont.continued_body_gap(20)
                    if _cbg is not None:                 # the artist's Continued–Body Gap
                        current_y += cont_gap + extra_h + _cbg - max(0, _safe_int(heading_to_body_gap, 40))
                    else:
                        current_y = max(current_y, current_y + cont_gap + extra_h + max(0, _safe_int(continued_gap, 20), 20)
                                        - max(0, _safe_int(heading_to_body_gap, 40)))   # never above the Heading–Body Gap
            _table_cap = table_room(safe_bottom, current_y - max(0, _safe_int(heading_to_body_gap, 40)),
                                    heading_to_body_gap, continued_gap, _pg_h_size)

            rendered_mapped_source_rows = set()
            rendered_mapped_claimed_rows = set()

            table_by_row = {}
            for table in tables:
                table_by_row.setdefault(int(table["start_row"]), []).append(table)
            mapped_by_row = {}
            for record in mapped_for_sheet:
                rr = source_row_range_for_template(record)
                if not rr:
                    try:
                        rr = _png_collect_mapped_source_rows(record, ws)
                    except Exception:
                        pass
                if rr:
                    mapped_by_row.setdefault(int(rr[0]), []).append(record)

            precomputed_mapped_source_rows = set()
            for record in mapped_for_sheet:
                consumed = mapped_record_consumed_rows(record)
                if consumed:
                    precomputed_mapped_source_rows.update(consumed)

            _page_top = {"y": None}            # where the newest Continued page's body starts

            def new_page(suffix, continued_section_heading=None):
                img, d, y0 = _new_page_drawn(suffix, continued_section_heading)
                _page_top["y"] = y0
                return img, d, y0

            def _new_page_drawn(suffix, continued_section_heading=None):
                img = Image.new("RGBA", (canvas_w, canvas_h), (255, 255, 255, 255))
                _draw_background(img, Image, bg_path, bg_mode, bg_color)
                d = ImageDraw.Draw(img)
                top_y = max(0, _safe_int(heading_top_margin, 120))

                title_for_page = heading_text
                if section_heading_mode and continued_section_heading:
                    title_for_page = continued_section_heading
                elif section_heading_mode and not continued_section_heading:
                    return img, d, top_y

                with _text_styles.row(title_for_page), _ps_text.tracking(_h_trk):
                    _mw2, heading_h = _draw_inline(
                    img, d, Image, title_for_page, safe_left, top_y,
                    heading_font, heading_color, safe_width, icon_folder, icon_mappings,
                    heading_icon_h, icon_size_overrides, align=_text_alignment(alignment_settings, sheet_name, "heading"),
                    line_spacing=_row_gap_px(max(8, _safe_int(current_sheet_heading_size, 48)), line_spacing),
                    fx_config=_heading_fx, icon_gap_left=_head_gap_l, icon_gap_right=_head_gap_r,
                    icon_y_offset=icon_y_offset,
                    font_request=_pg_h_font, font_size=current_sheet_heading_size, bold=True,
                )
                extra_h = 0
                cont_gap = 0
                if suffix:
                    # same spacing as the live window's newPage(): heading, gap, "(Continued)", gap
                    cont_gap = max(2, _safe_int(continued_gap, 8), 8)
                    _cw, extra_h = _draw_inline(
                        img, d, Image, "(Continued)", safe_left,
                        top_y + heading_h + cont_gap,
                        continued_font, _cont_look["rgb"], safe_width, icon_folder, icon_mappings,
                        max(1, int(heading_icon_h * 0.38)), icon_size_overrides,
                        align=_rr_cont.continued_align(_text_alignment(alignment_settings, sheet_name, "heading")), line_spacing=_row_gap_px(max(8, _safe_int(current_sheet_heading_size, 48)), line_spacing),
                        icon_gap_left=_icon_gap_l, icon_gap_right=_icon_gap_r,
                        fx_config=_cont_look["fx"], font_request=_cont_look["font"], font_size=_cont_look["size"],
                        bold=_cont_look["bold"],
                    )
                next_y = top_y + heading_h + cont_gap + extra_h + (max(0, _safe_int(continued_gap, 20), 20) if suffix else max(0, _safe_int(continued_gap, 20)))
                _cbg = _rr_cont.continued_body_gap(20) if suffix else None
                if _cbg is not None:                      # the artist's Continued–Body Gap
                    next_y = top_y + heading_h + cont_gap + extra_h + _cbg
                elif suffix and not section_heading_mode:   # never above the Heading–Body Gap (as on page 1)
                    next_y = max(next_y, top_y + heading_h + max(0, _safe_int(heading_to_body_gap, 40)))
                if section_heading_mode:
                    next_y += max(0, _safe_int(heading_to_body_gap, 40))
                return img, d, next_y

            def _mapped_table_metrics_for_record(record, y_value):
                boxes = list(_mapped_table_slot_boxes(record, mapped_only=True).values())
                if not boxes:
                    return None
                min_x = min(box[0] for box in boxes)
                min_y = min(box[1] for box in boxes)
                max_x = max(box[0] + box[2] for box in boxes)
                max_y = max(box[1] + box[3] for box in boxes)
                natural_w = max(1.0, max_x - min_x)
                natural_h = max(1.0, max_y - min_y)
                spec = record.get("spec") or {}
                margin_before = _mapped_table_flow_margin_before(spec)
                margin_after = max(0, _safe_int(spec.get("margin_after"), 20))
                scale = min(1.0, float(safe_width) / natural_w)
                if _mapped_table_respect_absolute_y(spec) and spec.get("absolute_y") not in (None, ""):
                    try:
                        table_y_local = float(spec.get("absolute_y"))
                    except Exception:
                        table_y_local = float(y_value) + margin_before
                else:
                    table_y_local = float(y_value) + margin_before
                rendered_h = natural_h * scale
                needed = max(1, int(math.ceil((table_y_local + rendered_h + margin_after) - float(y_value))))
                return {
                    "spec": spec,
                    "natural_h": natural_h,
                    "scale": scale,
                    "table_y": table_y_local,
                    "margin_before": margin_before,
                    "margin_after": margin_after,
                    "needed": needed,
                }

            def _estimate_mapped_table_needed(record, y_value):
                metrics = _mapped_table_metrics_for_record(record, y_value)
                return int(metrics.get("needed", 0)) if metrics else 0

            def _mapped_table_can_stay_on_current_page(record, y_value):
                """Avoid unnecessary Continued pages for mapped JSON tables.

                The actual renderer can scale a mapped table to the remaining safe
                height.  Do not push it to a new page unless the current page has
                too little usable room or the JSON explicitly asks for next-page fit.
                """
                metrics = _mapped_table_metrics_for_record(record, y_value)
                if not metrics:
                    return True
                spec = metrics["spec"]
                fit_mode = str(spec.get("fit_mode") or "scale").strip().casefold()
                if fit_mode in {"next_page", "move_to_next_page"}:
                    return False
                available_for_table = float(safe_bottom) - float(metrics["table_y"]) - float(metrics["margin_after"])
                if available_for_table <= 0:
                    return False
                # Must have enough space to render at a readable scale.  This
                # mirrors _draw_mapped_table's scale-to-height behavior but avoids
                # accepting a tiny 12% table when the page is truly full.
                fitted_scale = min(float(metrics["scale"]), available_for_table / max(1.0, float(metrics["natural_h"])))
                return fitted_scale >= 0.60 and available_for_table >= 60


            def _render_inline_block_line_by_line(row_text, *args, **kwargs):
                # letter spacing (Typography): the heading's for heading text, the paragraph's otherwise
                trk = _h_trk if (args and args[0] is heading_font) else _b_trk
                with _text_styles.row(row_text), _ps_text.tracking(trk):   # rules made for just this row apply here
                    return _render_inline_block_line_by_line_in_row(row_text, *args, **kwargs)

            def _render_inline_block_line_by_line_in_row(row_text, local_font, local_color, local_icon_h, align="center", paragraph_gap_override=None, fx=None, icon_gaps=None, font_request=None, font_size=None, bold=False):
                nonlocal page, draw, current_y, page_index, current_section_heading_text
                ig_l, ig_r = icon_gaps or (_icon_gap_l, _icon_gap_r)
                is_body = paragraph_gap_override is None
                # Body rows: the UI 'Row spacing' (line_gap) is the SINGLE
                # row-gap source (empty -> default 30px). Rows stack on REAL
                # ink extents: each line is placed at current_y - ink_top so
                # its ink top lands on current_y (the previous row's ink
                # bottom + gap), then current_y advances by ink_bottom + gap.
                # The VISUAL gap between any two consecutive rows' ink is
                # therefore exactly the Row Gap px, in every renderer
                # (PNG / PSD / live). Heading / subheading blocks keep the
                # historical multiplier-derived gap plus their trailing gap
                # (heading_to_body_gap / para_spacing).
                if is_body:
                    line_spacing_value = _effective_row_gap(_pg_line_gap)
                else:
                    line_spacing_value = _row_gap_px(max(8, _safe_int(_pg_b_size, b_size)), line_spacing)
                lines = _wrap_inline(
                    draw, Image, row_text, local_font, safe_width,
                    icon_folder, icon_mappings, local_icon_h, icon_size_overrides, ig_l, ig_r,
                )
                lines = [line for line in lines if str(line or "").strip()]
                if not lines:
                    return

                for line_index, line_text in enumerate(lines):
                    if is_body:
                        ink_top, ink_bottom = _line_ink_extents(
                            draw, Image, line_text, local_font,
                            icon_folder, icon_mappings, local_icon_h, icon_size_overrides,
                            ig_l, ig_r, icon_y_offset,
                        )
                        line_y = current_y - ink_top
                        if line_y + ink_bottom > safe_bottom:
                            pages.append(page)
                            page_index += 1
                            page, draw, current_y = new_page(page_index, current_section_heading_text if section_heading_mode else None)
                            line_y = current_y - ink_top
                        # justified: the paragraph's last line where the justify mode puts it
                        line_align = justify_line_align(align, line_index, len(lines))
                        _draw_inline(
                            page, draw, Image, line_text, safe_left, line_y, local_font, local_color,
                            safe_width, icon_folder, icon_mappings, local_icon_h, icon_size_overrides,
                            align=line_align, line_spacing=line_spacing_value, fx_config=fx,
                            icon_gap_left=ig_l, icon_gap_right=ig_r,
                            icon_y_offset=icon_y_offset,
                            font_request=font_request, font_size=font_size, bold=bold,
                            keyword_colors=keyword_colors if is_body else None,
                        )
                        current_y = line_y + ink_bottom + line_spacing_value
                        continue

                    _line_w, line_h = _measure_inline(
                        draw, Image, line_text, local_font,
                        icon_folder, icon_mappings, local_icon_h, icon_size_overrides, ig_l, ig_r,
                    )
                    line_h = max(1, int(math.ceil(line_h)))
                    if current_y + line_h > safe_bottom:
                        pages.append(page)
                        page_index += 1
                        page, draw, current_y = new_page(page_index, current_section_heading_text if section_heading_mode else None)

                    _draw_inline(
                        page, draw, Image, line_text, safe_left, current_y, local_font, local_color,
                        safe_width, icon_folder, icon_mappings, local_icon_h, icon_size_overrides,
                        align=align, line_spacing=line_spacing_value, fx_config=fx,
                        icon_gap_left=ig_l, icon_gap_right=ig_r,
                        icon_y_offset=icon_y_offset,
                        font_request=font_request, font_size=font_size, bold=bold,
                        keyword_colors=keyword_colors if is_body else None,
                    )
                    current_y += line_h

                    # LIVE-window parity: the UI line spacing applies after
                    # EVERY line of a body row -- including the last one; the
                    # paragraph gap then follows. Heading/subheading blocks
                    # keep the historical spacing (gap between lines only).
                    if line_index < len(lines) - 1 or paragraph_gap_override is None:
                        current_y += line_spacing_value

                if paragraph_gap_override is not None:
                    current_y += max(0, _safe_int(paragraph_gap_override, 0))

            def _render_body_wrapped_line_by_line(row_text, fx=_body_fx):
                _render_inline_block_line_by_line(row_text, body_font, body_color, b_icon_h,
                                                  align=_text_alignment(alignment_settings, sheet_name, "body"), fx=fx,
                                                  font_request=_pg_b_font, font_size=_pg_b_size)

            def _render_section_heading(row_text, heading_index=0):
                nonlocal current_section_heading_text, page, draw, page_index, current_y
                current_section_heading_text = str(row_text or "").strip()
                heading_img_path = _resolve_heading_image_path(sheet_name, heading_image_folder, heading_index, alignment_settings)
                if heading_img_path:
                    gap = max(0, _safe_int(heading_to_body_gap, 40))
                    est_nh = 0
                    try:
                        himg = Image.open(heading_img_path).convert("RGBA")
                        oh, ow = himg.size
                        if oh < 1 or ow < 1:
                            est_nh = 0
                        else:
                            if heading_image_height > 0:
                                scale = heading_image_height / max(1, oh)
                                nw = max(1, int(ow * scale))
                                nh = heading_image_height
                            else:
                                nw, nh = ow, oh
                            if nw > safe_width:
                                scale = safe_width / nw
                                nw = max(1, int(nw * scale))
                                nh = max(1, int(nh * scale))
                            est_nh = nh
                    except Exception:
                        pass
                    if est_nh > 0 and current_y + est_nh > safe_bottom:
                        pages.append(page)
                        page_index += 1
                        page = Image.new("RGBA", (canvas_w, canvas_h), (255, 255, 255, 255))
                        _draw_background(page, Image, bg_path, bg_mode, bg_color)
                        draw = ImageDraw.Draw(page)
                        current_y = max(0, _safe_int(heading_top_margin, 120))
                    placed_nh = _place_heading_image_in_png(page, Image, heading_img_path, safe_left, safe_width, current_y, heading_image_height, heading_image_align)
                    if placed_nh > 0:
                        current_y += placed_nh + gap
                        return
                _render_inline_block_line_by_line(
                    current_section_heading_text, heading_font, heading_color, heading_icon_h,
                    align=_text_alignment(alignment_settings, sheet_name, "heading"), paragraph_gap_override=max(0, _safe_int(heading_to_body_gap, 40)),
                    fx=_heading_fx, icon_gaps=(_head_gap_l, _head_gap_r),
                    font_request=_pg_h_font, font_size=current_sheet_heading_size, bold=True,
                )

            def _render_section_subheading(row_text):
                _render_inline_block_line_by_line(
                    row_text, subheading_font, subheading_color, subheading_icon_h,
                    align=justify_line_align(_text_alignment(alignment_settings, sheet_name, "body"), 1, 1).replace("justify_all", "left"),
                    paragraph_gap_override=max(0, _safe_int(para_spacing, 12)),
                    fx=_subheading_fx,
                    font_request=subheading_font_name, font_size=subheading_size, bold=True,
                )

            def _render_text_rectangle_cell(cell_text):
                nonlocal current_y, page, draw, page_index
                if not cell_text:
                    return
                ts = table_style or {}
                rect_font_size = int(ts.get("text_rectangle_font_size") or 0) or int(_pg_b_size)
                rect_font = _load_font(ImageFont, str(ts.get("text_rectangle_font_name") or _pg_b_font), rect_font_size)
                rect_icon_h = b_icon_h
                rect_color = _rgb(ts.get("text_rectangle_text_rgb") or _pg_b_rgb)
                rect_alignment = str(ts.get("text_rectangle_alignment") or "center")
                pad_x = max(0, int(ts.get("text_rectangle_pad_x", 10)))
                pad_y = max(0, int(ts.get("text_rectangle_pad_y", 5)))
                fill_opacity = max(0, min(100, int(ts.get("text_rectangle_opacity", 100))))
                fill_rgb = tuple(ts.get("text_rectangle_fill_rgb") or (20, 20, 30))
                stroke_rgb = tuple(ts.get("text_rectangle_stroke_rgb") or (255, 255, 255))
                stroke_width = max(0, int(ts.get("text_rectangle_stroke_width", 2) or 0))
                ls = max(0, _safe_int(line_spacing, 4))

                max_inner_w = max(1, safe_width - pad_x * 2)
                lines = _wrap_inline(draw, Image, cell_text, rect_font, max_inner_w,
                                     icon_folder, icon_mappings, rect_icon_h, icon_size_overrides, _icon_gap_l, _icon_gap_r)
                lines = [ln for ln in lines if str(ln or "").strip()]
                if not lines:
                    return
                content_w = 0
                line_hs = []
                for ln in lines:
                    lw, lh = _measure_inline(draw, Image, ln, rect_font, icon_folder, icon_mappings, rect_icon_h, icon_size_overrides, _icon_gap_l, _icon_gap_r)
                    lh = max(1, int(math.ceil(lh)))
                    content_w = max(content_w, lw)
                    line_hs.append(lh)
                content_h = sum(line_hs) + (len(lines) - 1) * ls if len(lines) > 1 else sum(line_hs)
                rect_w = min(safe_width, max(1.0, content_w + pad_x * 2))
                rect_h = max(1.0, content_h + pad_y * 2)

                if current_y + rect_h > safe_bottom:
                    pages.append(page)
                    page_index += 1
                    page, draw, current_y = new_page(page_index, current_section_heading_text if section_heading_mode else None)

                if rect_alignment == "left":
                    rect_left = float(safe_left)
                elif rect_alignment == "right":
                    rect_left = float(safe_left + safe_width - rect_w)
                else:
                    rect_left = float(safe_left + (safe_width - rect_w) / 2.0)
                rect_top = float(current_y)
                rect_right = rect_left + rect_w
                rect_bottom = rect_top + rect_h

                if fill_opacity > 0:
                    ov = Image.new("RGBA", (canvas_w, canvas_h), (0, 0, 0, 0))
                    ov_d = ImageDraw.Draw(ov)
                    alpha = int(255 * fill_opacity / 100)
                    ov_d.rectangle([rect_left, rect_top, rect_right, rect_bottom],
                                   fill=(fill_rgb[0], fill_rgb[1], fill_rgb[2], alpha))
                    page.alpha_composite(ov)
                if stroke_width > 0:
                    draw.rectangle([rect_left, rect_top, rect_right, rect_bottom],
                                   outline=tuple(stroke_rgb), width=stroke_width)

                vert_off = max(0, (rect_h - pad_y * 2 - content_h) / 2.0)
                text_y = rect_top + pad_y + vert_off
                cy = text_y
                for i, ln in enumerate(lines):
                    _draw_inline(page, draw, Image, ln,
                                 rect_left + pad_x, cy, rect_font, rect_color,
                                 max(1, rect_w - pad_x * 2),
                                 icon_folder, icon_mappings, rect_icon_h, icon_size_overrides,
                                 align=rect_alignment, line_spacing=ls,
                                 icon_gap_left=_icon_gap_l, icon_gap_right=_icon_gap_r)
                    cy += line_hs[i] + (ls if i < len(lines) - 1 else 0)

                current_y = rect_bottom + max(0, _safe_int(para_spacing, 12))

            page_index = 0
            heading_index = 0
            rendered_mapped_record_ids = set()

            for row_idx in range(page_min_row, page_max_row + 1):
                _check_cancel(cancel_event)
                if row_idx in precomputed_mapped_source_rows and row_idx not in mapped_by_row:
                    continue
                if (not section_heading_mode or not multi_heading_rows) and (row_idx in (heading_row, _cont_row) or _row_is_inside(row_idx, skip_ranges) or row_idx in rendered_mapped_source_rows):
                    if row_idx not in table_by_row and row_idx not in mapped_by_row:
                        continue

                for record in mapped_by_row.get(row_idx, []):
                    record_key = (
                        str(record.get("path") or ""),
                        str((record.get("spec") or {}).get("table_name") or ""),
                        tuple(source_row_range_for_template(record) or (row_idx, row_idx)),
                        id(record),
                    )
                    if record_key in rendered_mapped_record_ids:
                        continue
                    rendered_mapped_record_ids.add(record_key)

                    rr_direct = source_row_range_for_template(record)
                    rr_fallback = None
                    try:
                        rr_fallback = _png_collect_mapped_source_rows(record, ws)
                    except Exception:
                        pass
                    any_rr = False
                    skip_duplicate = False
                    consumed = mapped_record_consumed_rows(record)
                    for rr in (rr_direct, rr_fallback):
                        if rr:
                            r0, r1 = int(rr[0]), int(rr[1])
                            if rendered_mapped_claimed_rows and rendered_mapped_claimed_rows.issuperset(range(r0, r1 + 1)):
                                skip_duplicate = True
                                any_rr = True
                                _note(
                                    report_collector,
                                    f"Mapped table {record.get('table_name')} skipped on {sheet_name}: "
                                    f"source rows {r0}-{r1} were already rendered by another mapped table.",
                                )
                                break
                            rendered_mapped_claimed_rows.update(range(r0, r1 + 1))
                            rendered_mapped_source_rows.update(consumed or set(range(r0, r1 + 1)))
                            any_rr = True
                    if not any_rr:
                        rendered_mapped_source_rows.add(row_idx)
                    if skip_duplicate:
                        continue

                    needed = _estimate_mapped_table_needed(record, current_y)
                    if current_y + needed > safe_bottom and not _mapped_table_can_stay_on_current_page(record, current_y):
                        pages.append(page)
                        page_index += 1
                        page, draw, current_y = new_page(page_index, current_section_heading_text if section_heading_mode else None)

                    height = _draw_mapped_table(
                        page, draw, Image, ImageFont, ws, record, safe_left, current_y, safe_width,
                        icon_folder, icon_mappings, icon_size_overrides, report_collector,
                        available_height=max(40, safe_bottom - current_y), safe_bottom=safe_bottom,
                    )
                    current_y += max(1, height)

                for table in table_by_row.get(row_idx, []):
                    # exactly like the live window: a table that doesn't fit under the text starts a
                    # Continued page (it is never squeezed into the space left) — or, where the artist
                    # cut it (✂ in the Visualiser), its parts go on consecutive pages, each under the same
                    # header row; a table / part the artist moved is drawn where they put it
                    after_gap = max(0, _safe_int(table_style.get("after_table_margin"), 30))

                    def measure(row_slice=None, geo=None, cap=None):
                        scratch = Image.new("RGBA", (canvas_w, max(canvas_h, 4000)), (0, 0, 0, 0))
                        return _draw_auto_table(
                            scratch, ImageDraw.Draw(scratch), Image, ImageFont, ws, table, safe_left, 0, safe_width,
                            table_style, icon_folder, icon_mappings, icon_size_overrides, available_height=cap,
                            geo=geo, row_slice=row_slice)

                    def turn_page():
                        nonlocal page, draw, current_y, page_index
                        pages.append(page)
                        page_index += 1
                        page, draw, current_y = new_page(page_index, current_section_heading_text if section_heading_mode else None)

                    splits = _table_splits(table_style, table)
                    cap = None if splits else _table_cap        # a cut table keeps its size in every part
                    full_geo = {}
                    natural = measure(geo=full_geo, cap=cap)
                    fresh = _page_top["y"] is not None and abs(current_y - _page_top["y"]) < 1
                    body_n = max(0, len(full_geo.get("rows") or []) - int(full_geo.get("header_rows") or 0))
                    base_id = f"table.{int(table.get('start_row') or 0)}"
                    cuts = [k for k in splits if 0 < k < body_n]
                    if cuts:
                        # cut by the artist (✂ in Tables): the parts stay together on the table's page —
                        # side by side when they fit across, else one under the other — except the ones
                        # sent to the page before (under the text above) or after. Each part has the same
                        # header row and size; a part the artist moved is drawn where they put it.
                        bounds = [0] + cuts + [body_n]
                        where = _table_part_pages(table_style, table)
                        tw = float(sum(full_geo.get("cols") or []))
                        gx = float(full_geo.get("x", safe_left)) - safe_left    # the table's left inside the strip
                        parts = [(pi, a, b, measure((a, b))) for pi, (a, b) in enumerate(zip(bounds, bounds[1:]))]
                        groups = {g: [pt for pt in parts if where.get(pt[0], 0) == g] for g in (-1, 0, 1)}

                        def place_parts(group):
                            nonlocal current_y
                            spots, block_h = _table_part_block([pt[3] for pt in group], tw, gx, safe_width, after_gap)
                            for (pi, a, b, _h), (ox, oy) in zip(group, spots):
                                dx, dy = _table_offset(dynamic_settings, sheet_name, base_id + (f".{pi}" if pi else ""))
                                _draw_auto_table(
                                    page, draw, Image, ImageFont, ws, table, safe_left + ox + dx, current_y + oy + dy,
                                    safe_width, table_style, icon_folder, icon_mappings, icon_size_overrides,
                                    available_height=None, row_slice=(a, b),
                                )
                            current_y += block_h + after_gap

                        if groups[-1]:
                            place_parts(groups[-1])
                            if groups[0] or groups[1]:
                                turn_page()
                            if groups[0]:
                                place_parts(groups[0])
                        elif groups[0]:
                            _spots, block_h = _table_part_block([pt[3] for pt in groups[0]], tw, gx, safe_width, after_gap)
                            if current_y + block_h > safe_bottom and not fresh:
                                turn_page()
                            place_parts(groups[0])
                        if groups[1]:
                            if not (_page_top["y"] is not None and abs(current_y - _page_top["y"]) < 1):
                                turn_page()
                            place_parts(groups[1])
                        continue
                    if _table_part_pages(table_style, table).get(0) == 1 and not fresh:
                        turn_page()                      # the artist sent the whole table to the next page
                    elif current_y + natural > safe_bottom and not fresh:
                        turn_page()
                    dx, dy = _table_offset(dynamic_settings, sheet_name, base_id)
                    height = _draw_auto_table(
                        page, draw, Image, ImageFont, ws, table, safe_left + dx, current_y + dy, safe_width,
                        table_style, icon_folder, icon_mappings, icon_size_overrides,
                        available_height=_table_cap,
                    )
                    current_y += max(1, height) + after_gap

                if row_idx in table_by_row or row_idx in mapped_by_row or _row_is_inside(row_idx, skip_ranges) or row_idx in rendered_mapped_source_rows:
                    continue

                if section_heading_mode:
                    body_values = []
                    if multi_heading_mode and row_idx in multi_heading_rows:
                        heading_text = game_name_heading(multi_heading_rows[row_idx], dynamic_settings, icon_folder, icon_mappings)
                        if body_values:
                            _render_body_wrapped_line_by_line(" ".join(body_values).strip())
                            body_values = []
                        heading_index += 1
                        _render_section_heading(heading_text, heading_index)
                        continue
                    for col_idx in range(page_min_col, page_max_col + 1):
                        value = _text(ws.cell(row=row_idx, column=col_idx).value)
                        if not value or value.casefold().startswith("<mod") or _png_skip_helper_text(value):
                            continue
                        coord = (row_idx, col_idx)
                        if text_rectangle_cells and coord in text_rectangle_cells:
                            if body_values:
                                _render_body_wrapped_line_by_line(" ".join(body_values).strip())
                                body_values = []
                            _render_text_rectangle_cell(value)
                            continue
                        if coord in section_heading_cells:
                            if body_values:
                                _render_body_wrapped_line_by_line(" ".join(body_values).strip())
                                body_values = []
                            _render_section_heading(value)
                        elif coord in section_subheading_cells:
                            if body_values:
                                _render_body_wrapped_line_by_line(" ".join(body_values).strip())
                                body_values = []
                            _render_section_subheading(value)
                        else:
                            body_values.append(value)
                    if body_values:
                        _render_body_wrapped_line_by_line(" ".join(body_values).strip())
                    continue

                if text_rectangle_cells and any(
                    (row_idx, ci) in text_rectangle_cells for ci in range(page_min_col, page_max_col + 1)
                ):
                    body_values = []
                    for ci in range(page_min_col, page_max_col + 1):
                        val = _text(ws.cell(row=row_idx, column=ci).value)
                        if not val or val.casefold().startswith("<mod") or _png_skip_helper_text(val):
                            continue
                        if (row_idx, ci) in text_rectangle_cells:
                            if body_values:
                                _render_body_wrapped_line_by_line(" ".join(body_values).strip())
                                body_values = []
                            _render_text_rectangle_cell(val)
                        else:
                            body_values.append(val)
                    if body_values:
                        _render_body_wrapped_line_by_line(" ".join(body_values).strip())
                else:
                    row_text = _row_page_text(ws, row_idx, page_max_col, page_min_col)
                    if not row_text:
                        continue
                    from . import row_roles as _row_roles

                    _role = _row_roles.role(sheet_name, row_idx)    # a row the artist made a heading / subheading
                    _body_align = _text_alignment(alignment_settings, sheet_name, "body")
                    if _role == "heading":
                        _render_inline_block_line_by_line(
                            row_text, heading_font, heading_color, heading_icon_h, align=_body_align, fx=_heading_fx,
                            icon_gaps=(_head_gap_l, _head_gap_r), font_request=_pg_h_font,
                            font_size=current_sheet_heading_size, bold=True)
                    elif _role == "subheading":
                        # Typography › Subheading (row_roles: one definition for the build and the live window)
                        _sn, _ss, _sc, _si = _row_roles.subheading_look(_pg_h_font, current_sheet_heading_size, _pg_h_rgb, b_icon_h)
                        _sb, _sit = _row_roles.subheading_style()
                        _render_inline_block_line_by_line(
                            row_text, _load_font(ImageFont, _sn, _ss, bold=_sb, italic=_sit), _sc, _si, align=_body_align,
                            fx=_subheading_fx, font_request=_sn, font_size=_ss, bold=_sb)
                    else:
                        _render_body_wrapped_line_by_line(row_text)

            pages.append(page)
            _save_pages_for_sheet(sheet_name, pages)
            _note(report_collector, f"PNG page(s) saved for {sheet_name}: {len(pages)}")
            _emit(progress_callback, "sheet_done", sheet=sheet_name, index=index, total=len(sheet_names))

        _emit(progress_callback, "build_done", total=len(sheet_names), sheet="")
        return target_dir
    finally:
        _text_styles.end(_styles_ctx)
        _BUILD_EXCEL.reset(_excel_ctx)
        _wb_loan.__exit__(None, None, None)
        _settings_restore(_live_settings, _build_settings)