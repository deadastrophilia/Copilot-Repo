"""layout_engine — canonical page layout computation (single source of truth).

Builds PageLayout objects from Excel sheet content + build settings. All
renderers (live preview, PNG renderer, Photoshop renderer) consume the SAME
PageLayout objects, so text wrapping, line breaks, box sizes, icon positions,
margins, spacing and alignment are computed exactly once.

Measurement adapters:
  * PillowMeasureAdapter        — exact same math as the historical PNG
    renderer (pixel parity with current output by construction).
  * PhotoshopMeasureAdapter     — real Photoshop measurement through the
    existing hidden MeasureLayer infrastructure (text_icon_renderer's
    _measure_text_cached). When Photoshop is unavailable, it falls back to
    cached measurements / Pillow / the historical estimate and behaviour.

Safety rules:
  * Public functions of the renderers are never touched.
  * When a page uses features that the canonical model does not carry yet,
    build_normal_page_layouts(...) returns None and the caller falls back to
    the historical rendering path.
"""

from __future__ import annotations

import math
import re

from typing import Any, Callable, List, Optional

from .config import canonical_layout_enabled  # noqa: F401  (re-export)
from .page_layout import RectElement, PageLayout, TextElement

# <token> pointer pattern — identical to png_builder.TOKEN_RE.
_TOKEN_RE = re.compile(r"<([^<>]+)>")

_PILLOW_GUARD = "Pillow is required to build a canonical page layout"


def _untag_token(value):
    """A token as the artist wrote it (an Assets & Icons size tag dropped): 'WILD~140' -> 'WILD'."""
    from .icon_scales import strip

    return strip(value)


def _require_pillow():
    from PIL import Image, ImageDraw, ImageFont  # noqa: F401

    return Image, ImageDraw, ImageFont


def _png() -> Any:
    """Lazy import of the PNG builder (avoids import cycles)."""
    from . import png_builder

    return png_builder


# ============================================================================
# Measurement adapters
# ============================================================================


class MeasureAdapter:
    """Interface used by the layout engine for all text/icon measurement.

    measure(text, font, size, font_name, icon_height, icon_gap_left,
            icon_gap_right) -> (width, height)  of ONE line (no wrapping).
    wrap(text, font, size, font_name, max_width, icon_height, gaps) -> lines.
    """

    def measure(self, text, font, size, font_name, icon_height, icon_gap_left, icon_gap_right):
        raise NotImplementedError

    def wrap(self, text, font, size, font_name, max_width, icon_height, icon_gap_left, icon_gap_right):
        if max_width <= 0:
            return [str(text or "")]
        raw = str(text or "")
        if "\n" in raw:
            lines = []
            for chunk in raw.splitlines():
                lines.extend(
                    self.wrap(chunk, font, size, font_name, max_width, icon_height, icon_gap_left, icon_gap_right)
                )
            return lines
        words = re.split(r"(\s+)", raw)
        lines = []
        current = ""
        for word in words:
            trial = current + word
            w, _h = self.measure(trial, font, size, font_name, icon_height, icon_gap_left, icon_gap_right)
            if current.strip() and w > max_width:
                lines.append(current.strip())
                current = word.strip()
            else:
                current = trial
        if current.strip():
            lines.append(current.strip())
        if not lines:
            lines.append("")
        return lines


class PillowMeasureAdapter(MeasureAdapter):
    """Identical math to the historical PNG renderer (pixel parity).

    Delegates directly to png_builder._measure_inline/_wrap_inline with the
    same font objects, icon gaps and overrides used by the legacy build.
    """

    def __init__(self, image, draw, icon_folder="", icon_mappings=None, icon_size_overrides=None):
        self._image = image
        self._draw = draw
        self._icon_folder = str(icon_folder or "")
        self._icon_mappings = dict(icon_mappings or {})
        self._icon_size_overrides = dict(icon_size_overrides or {})
        # _load_icon / _draw_inline need the PIL MODULE (Image.open is a module
        # function, not a class method) — a probe instance or its __class__
        # would silently drop every icon from measurement.
        self._Image = _png()._require_pillow()[0]

    def measure(self, text, font, size, font_name, icon_height, icon_gap_left, icon_gap_right):
        png = _png()
        w, h = png._measure_inline(
            self._draw, self._Image or self._image, text, font,
            self._icon_folder, self._icon_mappings, icon_height,
            self._icon_size_overrides, icon_gap_left, icon_gap_right,
        )
        return w, h

    def wrap(self, text, font, size, font_name, max_width, icon_height, icon_gap_left, icon_gap_right):
        png = _png()
        return png._wrap_inline(
            self._draw, self._Image or self._image, text, font, max_width,
            self._icon_folder, self._icon_mappings, icon_height,
            self._icon_size_overrides, icon_gap_left, icon_gap_right,
        )


def _font_pil_height(font, fallback_size):
    """Line height from a PIL font (matches png_builder._line_height base)."""
    try:
        bbox = font.getbbox("Ag")
        h = max(0, bbox[3] - bbox[1])
        if h > 0:
            return h
    except Exception:
        pass
    return max(0, int(float(fallback_size) * 1.18))


class PhotoshopMeasureAdapter(MeasureAdapter):
    """Real Photoshop measurement via the shared MeasureLayer infrastructure.

    Text widths come from text_icon_renderer._measure_text_cached (hidden
    MeasureLayer / JSX / COM / caches). Icon widths come from the existing
    png_builder icon loader. When Photoshop (or the measure layer) is not
    available the measurements silently fall back to cached values, the
    Pillow estimate or the historical estimate — never raising.
    """

    def __init__(
        self,
        measure_layer=None,
        font_cache=None,
        image=None,
        draw=None,
        icon_folder="",
        icon_mappings=None,
        icon_size_overrides=None,
        font_resolver: Optional[Callable[[str], str]] = None,
    ):
        self._measure_layer = measure_layer
        self._font_cache = font_cache if font_cache is not None else {}
        self._image = image
        self._draw = draw
        self._icon_folder = str(icon_folder or "")
        self._icon_mappings = dict(icon_mappings or {})
        self._icon_size_overrides = dict(icon_size_overrides or {})
        self._font_resolver = font_resolver

    # ------------------------------------------------------------------
    def _resolve_font(self, font_name):
        if self._font_resolver is not None:
            try:
                resolved = self._font_resolver(str(font_name or ""))
                if resolved:
                    return str(resolved)
            except Exception:
                pass
        return str(font_name or "")

    def _text_width(self, text, size, font_name):
        from .text_icon_renderer import _measure_text_cached

        try:
            return max(0.0, float(_measure_text_cached(str(text), max(1, int(size)), font_name, self._measure_layer, self._font_cache)))
        except Exception:
            # Photoshop or the measure layer unavailable -> historical estimate.
            return float(len(str(text)) * max(1, int(size)) * 0.55)

    # ------------------------------------------------------------------
    def measure(self, text, font, size, font_name, icon_height, icon_gap_left, icon_gap_right):
        font_name = self._resolve_font(font_name)
        line_h = _font_pil_height(font, size)
        width = 0.0
        height = float(line_h)
        png = _png()
        for kind, value in png._split_inline(str(text or "")):
            if kind == "token":
                icon, _path = png._load_icon(
                    self._image, value, self._icon_folder, self._icon_mappings,
                    icon_height, self._icon_size_overrides,
                )
                if icon is not None:
                    width += max(0, icon_gap_left) + icon.width + max(0, icon_gap_right)
                    height = max(height, icon.height)
                else:
                    width += self._text_width(f"<{_untag_token(value)}>", size, font_name)
            else:
                width += self._text_width(value, size, font_name)
        return width, height


def make_measure_layer(document):
    """Create (or reuse) the hidden MeasureLayer on a Photoshop document.

    Mirrors the existing pattern used by build_engine and the paytable
    renderer. Returns the COM layer or None when Photoshop is unavailable.
    Icons/estimates still work through the Pillow fallback then.
    """
    if document is None:
        return None
    try:
        import photoshop.api as ps
    except Exception:
        return None
    try:
        try:
            measure_layer = document.artLayers.getByName("MeasureLayer")
        except Exception:
            measure_layer = document.artLayers.add()
            measure_layer.name = "MeasureLayer"
            measure_layer.kind = ps.LayerKind.TextLayer
        measure_layer.visible = False
        return measure_layer
    except Exception:
        return None


# ============================================================================
# Normal page layout builder
# ============================================================================


def _find_measure_probe(canvas_w, canvas_h, adapter):
    """Return (image, draw) for measurement, reusing the adapter's probe
    when the adapter was built on one."""
    if adapter is not None and getattr(adapter, "_image", None) is not None and getattr(adapter, "_draw", None) is not None:
        return adapter._image, adapter._draw
    Image, ImageDraw, _F = _require_pillow()
    probe = Image.new("RGBA", (max(100, canvas_w), max(100, canvas_h)), (0, 0, 0, 0))
    return probe, ImageDraw.Draw(probe)


def _safe_int(value, fallback=0):
    try:
        return int(float(value))
    except Exception:
        return int(fallback)


def _row_page_text(ws, row_idx, max_col_limit, min_col=1):
    return _png()._row_page_text(ws, row_idx, max_col_limit, min_col)   # same text (and artist edits) as the build


def build_measure_context(canvas_w, canvas_h, *, measure_layer=None, font_cache=None,
                          icon_folder="", icon_mappings=None, icon_size_overrides=None,
                          font_resolver=None):
    """Create the default measurement context for the engine.

    Returns a PillowMeasureAdapter unless a Photoshop MeasureLayer was
    provided (then a PhotoshopMeasureAdapter is returned).
    """
    Image, ImageDraw, _F = _require_pillow()
    probe = Image.new("RGBA", (max(100, canvas_w), max(100, canvas_h)), (0, 0, 0, 0))
    draw = ImageDraw.Draw(probe)
    if measure_layer is not None:
        return PhotoshopMeasureAdapter(
            measure_layer=measure_layer, font_cache=font_cache,
            image=probe, draw=draw, icon_folder=icon_folder,
            icon_mappings=icon_mappings, icon_size_overrides=icon_size_overrides,
            font_resolver=font_resolver,
        )
    return PillowMeasureAdapter(
        probe, draw, icon_folder=icon_folder,
        icon_mappings=icon_mappings, icon_size_overrides=icon_size_overrides,
    )


def _heading_image_is_used(sheet_name, heading_image_folder, alignment_settings=None):
    """True when the historical renderer would place a heading IMAGE for this
    sheet — the canonical model does not carry heading images yet, so the
    caller must fall back to the historical path."""
    if not heading_image_folder:
        return False
    png = _png()
    try:
        return bool(png._resolve_heading_image_path(sheet_name, str(heading_image_folder), 0, alignment_settings))
    except Exception:
        return False


_ELEMENT_ID_COUNTER = {}


def _next_element_id(kind, key):
    counter = _ELEMENT_ID_COUNTER.setdefault(kind, {})
    index = counter.get(key, 0) + 1
    counter[key] = index
    return f"{kind}_{index}"


def build_normal_page_layouts(
    ws,
    sheet_name,
    *,
    canvas_w,
    canvas_h,
    margin_x,
    inner_canvas_width=0,
    h_font,
    h_size,
    h_icon_h,
    h_rgb,
    b_font,
    b_size,
    b_icon_h,
    b_rgb,
    line_spacing,
    para_spacing,
    line_gap=None,
    continued_gap,
    heading_top_margin,
    heading_to_body_gap,
    bottom_margin,
    icon_folder="",
    icon_mappings=None,
    icon_size_overrides=None,
    heading_fx=None,
    body_fx=None,
    page_min_row=1,
    page_max_row=None,
    page_min_col=1,
    page_max_col=12,
    heading_row=None,
    heading_text=None,
    alignment_settings=None,
    heading_image_folder="",
    heading_image_height=0,
    measure_adapter=None,
    icon_y_offset=0,
    icon_gap_left=15,
    icon_gap_right=15,
    heading_icon_gap_left=15,
    heading_icon_gap_right=15,
    letter_spacing=None,
    tables=None,
    table_style=None,
    table_overrides=None,
):
    """Compute the canonical PageLayout for a NORMAL (plain) page.

    `tables` (png_builder._prepare_tables of the sheet) are placed where their first Excel row is,
    between the rows of text — exactly png_builder's legacy placement: a table that doesn't fit starts
    a Continued page, a cut table's parts go side by side / on the pages the artist chose, each table
    or part where the artist moved it (`table_overrides`: the sheet's live_overrides). Tables follow
    the paragraph: its box (left / width) and its alignment (left, centre, right).

    The algorithm is a faithful, side-by-side replica of the historical PNG
    normal-page loop (heading + row-by-row wrapped paragraphs, page breaks
    with "(Continued)" labels). Returns None when the sheet uses features the
    canonical model does not support yet (heading images, tables, mapped
    tables, section headings, text rectangles) — the caller then renders with
    the historical path, so nothing ever breaks.

    All positions are FINAL page pixels. Renderers must not recalculate
    wrapping or geometry.
    """
    png = _png()
    if page_max_row is None:
        page_max_row = ws.max_row or 1

    # --- feature gate: only plain pages are canonicalized today -------------
    if _heading_image_is_used(sheet_name, heading_image_folder, alignment_settings):
        return None

    # --- heading row/text (identical detection to the legacy renderer) ------
    if heading_row is None or not heading_text:
        _detected_row, _detected_text = png._find_heading_row(
            ws, max(1, page_max_col or 1), [(int(t["start_row"]), int(t["end_row"])) for t in (tables or [])],
            min_row=max(1, page_min_row or 1), max_row=page_max_row,
        )
        if heading_row is None:
            heading_row = _detected_row
        if not heading_text:
            heading_text = _detected_text

    # --- geometry -----------------------------------------------------------
    canvas_w = max(100, _safe_int(canvas_w, 1920))
    canvas_h = max(100, _safe_int(canvas_h, 1080))
    margin_x = max(0, _safe_int(margin_x, 100))
    bottom_margin = max(0, _safe_int(bottom_margin, 80))
    safe_left, safe_width = png._inner_safe_box(canvas_w, canvas_h, margin_x, inner_canvas_width)
    safe_bottom = max(heading_top_margin + 100, canvas_h - bottom_margin)
    top_y = max(0, _safe_int(heading_top_margin, 120))
    # the paragraph's box, when the artist dragged its handles on the Canvas (page_boxes): the body
    # text wraps between its sides and moves on to a Continued page at its bottom; the heading keeps
    # the page's own box
    from . import page_boxes as _pbx

    _bb = _pbx.body_box(sheet_name)
    body_left, body_right = float(safe_left), float(safe_left + safe_width)
    if "left" in _bb or "right" in _bb:
        _l = max(0.0, min(float(canvas_w), _bb.get("left", body_left)))
        _r = max(0.0, min(float(canvas_w), _bb.get("right", body_right)))
        if _r - _l >= 40:
            body_left, body_right = _l, _r
    body_left = int(round(body_left))
    body_width = max(1, int(round(body_right)) - body_left)
    body_bottom = safe_bottom
    if "bottom" in _bb:
        body_bottom = max(top_y + 100, min(canvas_h, int(round(_bb["bottom"]))))
    body_top_1 = int(round(_bb["top"])) if "top" in _bb else None
    # the Continued pages' own margins (page_boxes cont): their sides, where their text starts and ends
    _cb = _pbx.cont_box(sheet_name)
    cont_left, cont_width, cont_bottom = body_left, body_width, body_bottom
    if "left" in _cb or "right" in _cb:
        _l = max(0.0, min(float(canvas_w), _cb.get("left", body_left)))
        _r = max(0.0, min(float(canvas_w), _cb.get("right", body_left + body_width)))
        if _r - _l >= 40:
            cont_left, cont_width = int(round(_l)), max(1, int(round(_r - _l)))
    if "bottom" in _cb:
        cont_bottom = max(top_y + 100, min(canvas_h, int(round(_cb["bottom"]))))
    cont_top = int(round(_cb["top"])) if "top" in _cb else None

    def _cont_margins(F):
        """A paragraph flow that just moved on to a Continued page: that page's own margins."""
        if not _cb or F.get("bottom") is None:            # a text box keeps its own place
            return
        F["left"], F["width"], F["bottom"] = cont_left, cont_width, cont_bottom
        if cont_top is not None:
            F["y"] = max(F["y"], float(cont_top))
        lay = F.get("layout")
        if lay is not None:                               # its frame on the Canvas: this page's own box
            lay.safe_area = dict(lay.safe_area, body={"left": cont_left, "width": cont_width, "bottom": cont_bottom,
                                                      "top": cont_top, "set": sorted(_cb), "cont": True})

    h_size = max(8, _safe_int(h_size, 48))
    b_size = max(8, _safe_int(b_size, 24))
    # Row Gap ('line_gap') is the SINGLE row-gap source in every renderer
    # (PSD, PNG, live): a px gap between row CONTENT boxes -- next_row_top =
    # prev_content_bottom + gap (build_engine's row_gap_margin reflow). The
    # Typography 'Line spacing' / 'Paragraph spacing' no longer affect body
    # row stacking; an empty field means the 30px PSD-compatible default.
    line_spacing_v = png._effective_row_gap(line_gap)
    # Headings re-derive their row gap from the heading font size -- same
    # values as the legacy heading _draw_inline call and the PSD engine.
    heading_line_spacing_v = png._row_gap_px(h_size, line_spacing)
    continued_gap_v = max(0, _safe_int(continued_gap, 15))

    Image, ImageDraw, ImageFont = _require_pillow()
    if measure_adapter is None:
        probe = Image.new("RGBA", (canvas_w, canvas_h), (0, 0, 0, 0))
        measure_adapter = PillowMeasureAdapter(
            probe, ImageDraw.Draw(probe), icon_folder=icon_folder,
            icon_mappings=icon_mappings, icon_size_overrides=icon_size_overrides,
        )
    # Dedicated probe for the PIL run-geometry pass (line widths + per-run icon
    # boxes the live canvas draws verbatim). Independent of the measurement
    # adapter so the viewer always matches the PNG renderer's PIL math.
    runs_probe = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    runs_draw = ImageDraw.Draw(runs_probe)

    def _line_geometry(line, font, icon_h, gap_l, gap_r):
        w, _h, runs = png._measure_inline_boxes(
            runs_draw, runs_probe, line, font, icon_folder, icon_mappings,
            icon_h, icon_size_overrides, gap_l, gap_r, icon_y_offset,
        )
        return w, runs

    # letter spacing (Typography, 1/1000 em): heading text and body text measure and draw with their own;
    # the heading also with its width / height scale and kerning (png_builder.heading_shape)
    from . import ps_text as _pst
    _ls = letter_spacing or {}
    heading_font = _pst.shaped(png._load_font(ImageFont, h_font, h_size, bold=True), **(_ls.get("heading_shape") or {}))
    body_font = png._load_font(ImageFont, b_font, b_size)
    h_trk, b_trk = float(_ls.get("heading") or 0), float(_ls.get("body") or 0)

    from . import row_roles as _rr

    # a subheading row (row_roles): the build's subheading look, measured with the paragraph's tracking
    _sub_name, _sub_size, _sub_rgb, _sub_icon_h = _rr.subheading_look(h_font, h_size, h_rgb, b_icon_h)
    _sub_bold, _sub_italic = _rr.subheading_style()
    sub_font = png._load_font(ImageFont, _sub_name, _sub_size, bold=_sub_bold, italic=_sub_italic)

    _font_trk = {}                                    # fonts with a letter spacing of their own (a text box's)

    def _trk(font):
        if id(font) in _font_trk:
            return _font_trk[id(font)]
        return h_trk if font is heading_font else (b_trk if font is body_font or font is sub_font else 0.0)

    class _Tracked:
        def __init__(self, inner):
            self.inner = inner

        def measure(self, text, font, *a):
            with _pst.tracking(_trk(font)):
                return self.inner.measure(text, font, *a)

        def wrap(self, text, font, *a):
            with _pst.tracking(_trk(font)):
                return self.inner.wrap(text, font, *a)

    measure_adapter = _Tracked(measure_adapter)
    _line_geometry_plain = _line_geometry

    def _line_geometry(line, font, icon_h, gap_l, gap_r):
        with _pst.tracking(_trk(font)):
            return _line_geometry_plain(line, font, icon_h, gap_l, gap_r)
    _cont = _rr.continued_look(h_font, h_size, b_rgb)          # Typography › Continued (row_roles)
    continued_font = png._load_font(ImageFont, _cont["font"], _cont["size"], bold=_cont["bold"], italic=_cont["italic"])

    heading_color = png._rgb(h_rgb, (255, 80, 80))
    body_color = png._rgb(b_rgb, (255, 255, 255))
    heading_icon_h = max(1, _safe_int(h_icon_h, _safe_int(h_size, 48)))
    body_icon_h = max(1, _safe_int(b_icon_h, 1))
    continued_icon_h = max(1, int(heading_icon_h * 0.38))
    # the Icon spacing settings (were hard-coded to 15 px, so the sliders did nothing here)
    heading_gap_l = max(0, _safe_int(heading_icon_gap_left, 15))
    heading_gap_r = max(0, _safe_int(heading_icon_gap_right, 15))
    body_gap_l = max(0, _safe_int(icon_gap_left, 15))
    body_gap_r = max(0, _safe_int(icon_gap_right, 15))

    heading_text = str(heading_text or "").strip() or str(sheet_name)
    heading_row = heading_row if heading_row is not None else 0
    # the Excel's own "(Cont.)" / "CONTINUED" note after the heading is not drawn: the page gets the
    # tool's "(Continued)" line instead (Typography › Continued), the same on every Continued page
    heading_text, cont_row, cont_first = _rr.continued_from_excel(
        heading_text, lambda r: _row_page_text(ws, r, page_max_col, page_min_col), heading_row, page_max_row)
    # Typography → alignment (the page's own, else the global one), as the PNG / PSD builders draw it
    heading_align = png._text_alignment(alignment_settings, sheet_name, "heading")
    body_align = png._text_alignment(alignment_settings, sheet_name, "body")

    _meta_canvas = {"width": canvas_w, "height": canvas_h}
    _meta_safe = {"left": safe_left, "top": top_y, "width": safe_width, "height": max(0, safe_bottom - top_y), "bottom": safe_bottom,
                  "body": {"left": body_left, "width": body_width, "bottom": body_bottom, "top": body_top_1,
                           "set": sorted(_bb)}}
    _meta_margins = {
        "margin_x": margin_x, "bottom_margin": bottom_margin,
        "heading_top_margin": top_y, "heading_to_body_gap": _safe_int(heading_to_body_gap, 40),
        "continued_gap": continued_gap_v, "line_spacing": line_spacing_v,
        "para_spacing": 0,
    }

    # --- heading measurement (identical to _draw_inline math) ---------------
    def _measure_text_block(text, font, size, font_name, icon_h, gap_l, gap_r):
        from . import text_styles as _tsh

        with _tsh.row(text):                         # rules made for just this text
            return _measure_text_block_in_row(text, font, size, font_name, icon_h, gap_l, gap_r)

    def _measure_text_block_in_row(text, font, size, font_name, icon_h, gap_l, gap_r):
        lines = measure_adapter.wrap(text, font, size, font_name, safe_width, icon_h, gap_l, gap_r)
        lines = [line for line in lines if str(line or "").strip()]
        if not lines:
            return [], [], [], []
        heights, widths, line_runs = [], [], []
        for line in lines:
            _w, h_raw = measure_adapter.measure(line, font, size, font_name, icon_h, gap_l, gap_r)
            heights.append(max(1, int(math.ceil(h_raw))))
            pil_w, runs = _line_geometry(line, font, icon_h, gap_l, gap_r)
            widths.append(pil_w)
            line_runs.append(runs)
        return lines, heights, widths, line_runs

    def _block_height(lines, heights, gap=None):
        if not lines:
            return 0
        return sum(heights) + max(0, len(lines) - 1) * (line_spacing_v if gap is None else gap)

    heading_lines, heading_heights, heading_widths, heading_runs = _measure_text_block(
        heading_text, heading_font, h_size, str(h_font), heading_icon_h, heading_gap_l, heading_gap_r,
    )
    # the page heading stays on one line (per line of its text): a heading too long for the page gets a
    # smaller size of its own — only this page's heading, every other heading (and rows made headings)
    # keeps the Typography size
    ph_size, ph_font, ph_icon_h, ph_spacing = h_size, heading_font, heading_icon_h, heading_line_spacing_v
    _h_want = max(1, len([ln for ln in str(heading_text or "").split("\n") if ln.strip()]))
    if len(heading_lines) > _h_want:
        _floor = max(8, int(h_size * 0.4))
        _s = h_size
        while _s > _floor:
            _s = max(_floor, int(_s * 0.97))
            _f = _pst.shaped(png._load_font(ImageFont, h_font, _s, bold=True), **(_ls.get("heading_shape") or {}))
            _icon = max(1, int(round(heading_icon_h * _s / float(h_size))))
            _m = _measure_text_block(heading_text, _f, _s, str(h_font), _icon, heading_gap_l, heading_gap_r)
            if len(_m[0]) <= _h_want or _s == _floor:
                ph_size, ph_font, ph_icon_h = _s, _f, _icon
                ph_spacing = png._row_gap_px(_s, line_spacing)
                heading_lines, heading_heights, heading_widths, heading_runs = _m
                break
    heading_h = _block_height(heading_lines, heading_heights, ph_spacing)
    # the heading / "(Continued)" deleted on this page (page_boxes.hidden_parts): not drawn, and no room
    # kept for them — the text (or a row made a heading) starts at the heading's top
    _gone = _pbx.hidden(sheet_name)
    no_heading = bool({"heading", "heading_main"} & _gone)                # on the first page
    no_heading_cont = bool({"heading", "heading_cont"} & _gone)          # on the Continued pages
    no_continued = "continued" in _gone
    heading_h_full = heading_h
    if no_heading:
        heading_h = 0

    continued_lines, continued_heights, continued_widths, continued_runs = _measure_text_block(
        "(Continued)", continued_font, max(12, int(h_size * 0.38)), str(h_font),
        continued_icon_h, body_gap_l, body_gap_r,
    )
    continued_h = _block_height(continued_lines, continued_heights, heading_line_spacing_v)

    # --- page assembly ------------------------------------------------------
    layouts: List[PageLayout] = []
    current_y = top_y  # not used for page-1 heading (always drawn first)

    def _new_page(next_y, page_index):
        # this page's heading: deleted on the first page / on the Continued pages (page_boxes.hidden_parts)
        gone_here = no_heading if page_index == 0 else no_heading_cont
        heading_h = 0 if gone_here else heading_h_full
        layout = PageLayout(
            source={
                "excel_path": str(getattr(ws, "parent", {}).path) if hasattr(ws, "parent") else "",
                "sheet_name": str(sheet_name),
                "page_index": page_index,
                "layout_mode": "normal",
            },
            canvas=dict(_meta_canvas),
            safe_area=dict(_meta_safe),
            margins=dict(_meta_margins),
        )
        heading_el = TextElement(
            element_id=f"heading_page_{page_index + 1}",
            x=float(safe_left), y=float(top_y),
            width=float(safe_width), height=float(heading_h),
            text=heading_text, font=str(h_font), size=float(ph_size),
            bold=True, color=list(heading_color), align=heading_align,
            line_spacing=float(ph_spacing), icon_height=float(ph_icon_h),
            icon_gap_left=float(heading_gap_l), icon_gap_right=float(heading_gap_r),
            wrapped_lines=list(heading_lines), line_heights=list(heading_heights),
            line_widths=list(heading_widths), line_runs=[list(r) for r in heading_runs],
            effects=dict(heading_fx or {}), style_role="Heading",
            meta={"kind": "heading", "page": page_index + 1, "tracking": h_trk},
        )
        if not gone_here:
            _plate = _pbx.heading_plate(sheet_name)
            if _plate and heading_lines:
                # the heading's plate (page_boxes.heading_plate): fit to its widest line, behind it
                from . import text_styles as _ts
                _al = str(heading_align or "center").lower()
                _lefts = [float(safe_left) + (0.0 if _al == "left" else (float(safe_width) - w) if _al == "right" else (float(safe_width) - w) / 2.0)
                          for w in heading_widths]
                _l, _r = min(_lefts), max(l + w for l, w in zip(_lefts, heading_widths))
                px, py, pw, ph = _ts.strip_geometry(_plate, float(safe_left), float(top_y), float(safe_width), float(heading_h), _l, _r)
                rgba = _ts.strip_rgba(_plate)
                layout.add(RectElement(
                    element_id=f"heading_plate_{page_index + 1}", x=px, y=py, width=pw, height=ph,
                    fill_rgb=list(rgba[:3]), fill_opacity=rgba[3] / 255.0, stroke_width=0.0, style_role="Strip",
                    meta={"kind": "strip", "strip": True, "plate": "heading", "page": page_index + 1,
                          "text_box": [_l, float(top_y), _r, float(top_y) + float(heading_h)],   # what its pads are from
                          "radius": float(_plate.get("radius", 12) or 0), "look": _ts.strip_look(_plate, radius=12)}))
            layout.add(heading_el)
        if (page_index >= 1 or cont_first) and not no_continued:
            continued_y = top_y + heading_h + (max(2, _safe_int(continued_gap, 8)) if heading_h else 0)
            layout.add(
                TextElement(
                    element_id=f"continued_page_{page_index + 1}",
                    x=float(safe_left), y=float(continued_y),
                    width=float(safe_width), height=float(continued_h),
                    text="(Continued)", font=str(_cont["font"]),
                    size=float(_cont["size"]), italic=bool(_cont["italic"]),
                    bold=bool(_cont["bold"]), color=list(_cont["rgb"]), align=_rr.continued_align(heading_align),
                    line_spacing=float(heading_line_spacing_v), icon_height=float(continued_icon_h),
                    icon_gap_left=float(body_gap_l), icon_gap_right=float(body_gap_r),
                    wrapped_lines=list(continued_lines), line_heights=list(continued_heights),
                    line_widths=list(continued_widths), line_runs=[list(r) for r in continued_runs],
                    effects=dict(_cont["fx"] or {}), style_role="Continued",
                    meta={"kind": "continued", "page": page_index + 1},
                )
            )
            # the text starts under "(Continued)" — its own gap (the Continued–Body Gap guide) when the artist
            # set one, else never above the Heading–Body Gap (as on page 1)
            _cbg = _rr.continued_body_gap(continued_gap_v)
            if _cbg is not None:
                return layout, continued_y + continued_h + _cbg
            return layout, max(continued_y + continued_h + continued_gap_v,
                               top_y + heading_h + max(0, _safe_int(heading_to_body_gap, 40)))
        # the Heading–Body Gap may be pulled above the heading's bottom (the text then overlaps it — the
        # artist's choice), never above the page's top; no heading: the text starts where it was
        if gone_here:
            return layout, top_y
        return layout, max(0, top_y + heading_h + _safe_int(heading_to_body_gap, 40))

    layout, current_y = _new_page(0, 0)
    if body_top_1 is not None:                     # the paragraph's own top: never over the heading / (Continued)
        cont_bottom = top_y + heading_h + max(2, _safe_int(continued_gap, 8)) + continued_h
        current_y = max(cont_bottom if cont_first and not no_continued else top_y + heading_h, body_top_1)
    layouts.append(layout)
    page_index = 0
    page_start_y = current_y                       # where this page's text starts (a heading row adds no gap there)
    heading_gap_v = max(0, _safe_int(heading_to_body_gap, 40))

    # text split off into boxes of their own (page_boxes): their words leave their rows; a box whose
    # words its rows no longer hold is not drawn (the rows keep all their text)
    cuts, boxes_ready, boxes_missing = {}, [], []
    for _box in _pbx.text_boxes(sheet_name):
        spans = []
        for _part in _box["parts"]:
            _r = int(_part["row"])
            if _r in (heading_row, cont_row) or _r < max(1, page_min_row) or _r > max(1, page_max_row):
                spans = None
                break
            _sp = _pbx.find(_row_page_text(ws, _r, page_max_col, page_min_col), _part["text"])
            if _sp is None:
                spans = None
                break
            spans.append((_r, _sp))
        if spans is None:
            boxes_missing.append(str(_box.get("id") or ""))
            continue
        for _r, _sp in spans:
            cuts.setdefault(_r, []).append(_sp)
        boxes_ready.append(_box)

    # --- one row: an Excel row of the paragraph, or a text box's words (laid out the same way) --------
    def _lay_row(F, row_idx, key, full_text, base_meta):
        """Lay one row into frame F: its parts by role (row_roles.segments), wrapped, the strip behind
        it, a heading row's gaps, the line heights set on it, justify. F holds the frame (left, width,
        align, the row gap, the normal-text look) and where it has got to (layout, y, start); with a
        bottom the text moves on to a Continued page there (the paragraph), without one it grows (a
        text box). Returns the elements made."""
        from . import text_styles as _tsr

        made = []
        _parts = _rr.segments(sheet_name, key, full_text)
        row_line = 0                                  # the row's drawn lines, counted over its parts
        for _seg_i, (row_text, _seg_role) in enumerate(_parts):
            # how this part looks: normal text, or a heading / subheading the artist made it (row_roles)
            _role = _seg_role
            if _role == "heading":
                r_font, r_name, r_size, r_color, r_icon_h = heading_font, str(h_font), h_size, heading_color, heading_icon_h
                r_gl, r_gr, r_fx, r_trk = heading_gap_l, heading_gap_r, heading_fx, h_trk
                r_bold, r_italic = True, False
            elif _role == "subheading":
                r_font, r_name, r_size, r_color, r_icon_h = sub_font, _sub_name, _sub_size, _sub_rgb, _sub_icon_h
                r_gl, r_gr, r_fx, r_trk = body_gap_l, body_gap_r, _rr.subheading_fx(), b_trk
                r_bold, r_italic = _sub_bold, _sub_italic
            else:
                r_font, r_name, r_size, r_color, r_icon_h, r_gl, r_gr, r_fx, r_trk, r_bold, r_italic = F["look"]

            with _tsr.row(full_text):                    # rules made for just this Excel row (or box)
                lines = measure_adapter.wrap(row_text, r_font, r_size, r_name, F["width"], r_icon_h, r_gl, r_gr)
                # an empty line (Enter pressed twice on the Canvas, like in Notepad) is space: a blank line
                # of this text's height before the next line — or after the row's last one
                blank_before, _run = [], 0
                for line in lines:
                    if str(line or "").strip():
                        blank_before.append(_run)
                        _run = 0
                    else:
                        _run += 1
                _tail = re.search(r"(?:\n[ \t]*)+$", str(row_text))
                blank_after = _tail.group(0).count("\n") if _tail else 0
                lines = [line for line in lines if str(line or "").strip()]
                blank_h = 0
                if any(blank_before) or blank_after:
                    blank_h = max(1, int(math.ceil(measure_adapter.measure("Hg", r_font, r_size, r_name, r_icon_h, r_gl, r_gr)[1])))
                line_heights = []
                line_widths = []
                line_runs = []
                for line in lines:
                    _w, h_raw = measure_adapter.measure(line, r_font, r_size, r_name, r_icon_h, r_gl, r_gr)
                    line_heights.append(max(1, int(math.ceil(h_raw))))
                    pil_w, runs = _line_geometry(line, r_font, r_icon_h, r_gl, r_gr)
                    line_widths.append(pil_w)
                    line_runs.append(runs)
            if not lines:
                continue

            # Line strip behind this row (text_styles): one rectangle under all of the row's lines on
            # each page it lands on; the strip may recolour the text.
            from . import text_styles as _ts

            row_strip = _ts.strip_for(full_text)
            row_color = list(_ts.strip_text_rgb(row_strip)) if row_strip and _ts.strip_text_rgb(row_strip) else list(r_color)
            strip_seg = None                                   # [layout, insert_index, top, bottom, left, right]

            def _flush_strip():
                if not (row_strip and strip_seg):
                    return
                seg_layout, at, top, bottom, left, right = strip_seg
                sx, sy, sw, sh = _ts.strip_geometry(row_strip, float(F["left"]), top, float(F["width"]), bottom - top, left, right)
                rgba = _ts.strip_rgba(row_strip)
                strip_meta = {"kind": "strip", "row": row_idx, "strip": True, "text": " ".join(str(full_text).split())[:60],
                              "radius": float(row_strip.get("radius", 6) or 0), "look": _ts.strip_look(row_strip)}
                if F.get("box") is not None:
                    strip_meta["box"] = F["box"]
                seg_layout.elements.insert(at, RectElement(
                    element_id=f"strip_{key.replace(':', '_')}_{at}", x=sx, y=sy, width=sw, height=sh,
                    fill_rgb=list(rgba[:3]), fill_opacity=rgba[3] / 255.0, stroke_width=0.0,
                    style_role="Strip", meta=strip_meta))

            # Row Gap stacking (PSD-style, always): rows advance from the REAL
            # ink bottom (glyph ink / icon boxes) plus the px row gap, so the
            # visual gap between consecutive rows equals the configured Row Gap
            # exactly (each row's ink top lands on y = prev_ink_bottom + gap).
            # Always per-line elements so the live canvas never re-stacks rows.
            gap_v = F["gap"]
            line_aligns = [F["align"]] * len(lines)
            # the paragraph box justified as ONE paragraph (the Canvas's Justify button): every line of its
            # text stretched, one-line rows too, and only the box's very last line centred (set after its
            # last row: P["box_last"]); a heading / subheading row keeps to the centre
            box_justify = F.get("box_justify") and _role not in ("heading", "subheading")
            unspread = list(line_runs), list(line_widths)
            if box_justify:
                for li in range(len(lines)):
                    line_aligns[li] = "justify_all"
                    with _pst.tracking(r_trk):
                        line_runs[li] = png._justify_runs(runs_draw, line_runs[li], r_font, line_widths[li], F["width"])
                    line_widths[li] = max(line_widths[li], float(F["width"]))
            elif F.get("box_justify"):
                line_aligns = ["center"] * len(lines)
            elif str(F["align"]).lower() in png.JUSTIFY_LAST:     # stretched lines; the last where the mode puts it
                for li in range(len(lines)):
                    line_aligns[li] = png.justify_line_align(F["align"], li, len(lines))
                    if line_aligns[li] == "justify_all":
                        with _pst.tracking(r_trk):
                            line_runs[li] = png._justify_runs(runs_draw, line_runs[li], r_font, line_widths[li], F["width"])
                        line_widths[li] = max(line_widths[li], float(F["width"]))
            gap_above = gap_below = None
            if _role == "heading":                       # the page heading's gap to its text, above and below (or the artist's)
                gap_above, gap_below = _pbx.row_gaps(sheet_name, key, heading_gap_v)
                if F["y"] > F["start"] + 0.5:
                    F["y"] += gap_above - gap_v
            for line_index, line in enumerate(lines):
                blanks = []
                for _b in range(blank_before[line_index]):
                    blanks.append({"top": float(F["y"]), "h": float(blank_h)})
                    F["y"] += blank_h + gap_v
                with _tsr.row(full_text), _pst.tracking(r_trk):
                    ink_top, ink_bottom = png._line_ink_extents(
                        runs_draw, runs_probe, line, r_font, icon_folder, icon_mappings,
                        r_icon_h, icon_size_overrides, r_gl, r_gr, icon_y_offset,
                    )
                row_line += 1
                # the line height set for this line / row (page_boxes.line_gap): the gap above it — not at
                # the top of a page, nor above a heading row's first line (its own gap, above)
                one_gap, row_gap_set = _pbx.line_gap(sheet_name, key, row_line)
                heading_top = line_index == 0 and gap_above is not None      # its gap above is already there
                gap_here = gap_above if heading_top else gap_v
                line_gap = one_gap if one_gap is not None else (None if heading_top else row_gap_set)
                if line_gap is not None and F["y"] > F["start"] + 0.5:
                    F["y"] += line_gap - gap_here
                    gap_here = line_gap
                elem_y = F["y"] - ink_top
                if F.get("bottom") is not None and elem_y + ink_bottom > F["bottom"]:
                    _flush_strip()
                    strip_seg = None
                    F["page"] += 1
                    F["layout"], F["y"] = _new_page(F["page"], F["page"])
                    _cont_margins(F)
                    layouts.append(F["layout"])
                    F["start"] = F["y"]
                    elem_y = F["y"] - ink_top
                if row_strip:
                    _free = max(0.0, float(F["width"]) - float(line_widths[line_index]))
                    _al = line_aligns[line_index]
                    line_left = float(F["left"]) + (0.0 if _al in ("left", "justify", "justify_all") else _free if _al == "right" else _free / 2.0)
                    line_right = line_left + float(line_widths[line_index])
                    top, bottom = elem_y + ink_top, elem_y + ink_bottom
                    if strip_seg is None:
                        strip_seg = [F["layout"], len(F["layout"].elements), top, bottom, line_left, line_right]
                    else:
                        strip_seg[3] = bottom
                        strip_seg[4] = min(strip_seg[4], line_left)
                        strip_seg[5] = max(strip_seg[5], line_right)
                _meta = dict(base_meta, line=line_index + 1, tracking=r_trk, role=_role, key=key,
                             ink_top=float(elem_y + ink_top), ink_bottom=float(elem_y + ink_bottom),
                             row_line=row_line, line_height=float(gap_here), line_height_set=line_gap is not None)
                if gap_above is not None:
                    _meta["gaps"] = {"above": gap_above, "below": gap_below, "default": heading_gap_v}
                if blanks:
                    _meta["blank_above"] = blanks         # the empty lines before it (the editor's caret goes there)
                if len(_parts) > 1:
                    _meta["part"] = row_text             # this part of the row (a line made a heading on its own)
                el_id = F["id"] + (f"_{line_index + 1}" if len(_parts) == 1 else f"_{_seg_i + 1}_{line_index + 1}")
                element = TextElement(
                    element_id=el_id,
                    x=float(F["left"]), y=float(elem_y),
                    width=float(F["width"]), height=float(line_heights[line_index]),
                    text=str(full_text), font=r_name, size=float(r_size),
                    bold=bool(r_bold), italic=bool(r_italic), color=list(row_color), align=line_aligns[line_index],
                    line_height=float(line_heights[line_index]), line_spacing=float(gap_v),
                    icon_height=float(r_icon_h),
                    icon_gap_left=float(r_gl), icon_gap_right=float(r_gr),
                    wrapped_lines=[line], line_heights=[float(line_heights[line_index])],
                    line_widths=[float(line_widths[line_index])],
                    line_runs=[list(line_runs[line_index])],
                    effects=dict(r_fx or {}), style_role={"heading": "Heading", "subheading": "Subheading"}.get(_role, "Body"),
                    meta=_meta,
                )
                F["layout"].add(element)
                made.append(element)
                if box_justify:                           # the box's last line so far, as it was before stretching
                    F["box_last"] = (element, list(unspread[0][line_index]), float(unspread[1][line_index]))
                F["y"] = elem_y + ink_bottom + gap_v
            if blank_after and made:
                made[-1].meta["blank_below"] = []
                for _b in range(blank_after):
                    made[-1].meta["blank_below"].append({"top": float(F["y"]), "h": float(blank_h)})
                    F["y"] += blank_h + gap_v
            if gap_below is not None:
                F["y"] += gap_below - gap_v
            _flush_strip()
        return made

    # --- tables: where their first Excel row is, between the rows of text (png_builder's placement) -----
    from .page_layout import TableElement

    tables = list(tables or [])
    tables_at = {}
    for _t in tables:
        tables_at.setdefault(int(_t.get("start_row") or 0), []).append(_t)
    table_rows = [(int(t["start_row"]), int(t["end_row"])) for t in tables]
    ts_base = dict(table_style or {})
    table_align = {"left": "left", "right": "right"}.get(str(body_align), "center")    # the paragraph's
    ts_aligned = dict(ts_base, table_alignment=table_align)
    after_gap = max(0, _safe_int(ts_base.get("after_table_margin"), 30))
    table_cap = png.table_room(body_bottom, top_y + heading_h, heading_to_body_gap, continued_gap, h_size)
    table_overrides = table_overrides if isinstance(table_overrides, dict) else {}

    def _measure_table(table, row_slice=None, cap=None):
        """(height, geo, picture) of a table or one part, drawn in the paragraph's box"""
        scratch = Image.new("RGBA", (canvas_w, max(canvas_h, 4000)), (0, 0, 0, 0))
        geo = {}
        h = png._draw_auto_table(
            scratch, ImageDraw.Draw(scratch), Image, ImageFont, ws, table, body_left, 0, body_width, ts_aligned,
            icon_folder, icon_mappings or {}, icon_size_overrides or {}, available_height=cap, geo=geo,
            row_slice=row_slice,
        )
        h = max(1, int(h or 0))
        pic = scratch.crop((int(body_left), 0, int(body_left) + int(body_width), min(scratch.height, h + 2)))
        return h, geo, pic

    def _cut_info(full_geo, a, b, pi, splits, pages):
        rows_h = [float(v) for v in full_geo.get("rows") or []]
        gap = float(full_geo.get("row_gap") or 0)
        n_head = min(len(rows_h), int(full_geo.get("header_rows") or 0))
        tops, acc = [], 0.0
        for i, rh in enumerate(rows_h):
            tops.append(acc)
            acc += rh + (gap if i < len(rows_h) - 1 else 0)
        tw = float(sum(full_geo.get("cols") or []))
        return {"a": a, "b": b, "pi": pi, "nBody": len(rows_h) - n_head, "nHead": n_head,
                "headH": (tops[n_head - 1] + rows_h[n_head - 1]) if n_head else 0, "gap": gap, "tops": tops,
                "rows": rows_h, "cuts": list(splits), "tx": float(full_geo.get("x", body_left)) - body_left if tw else 0,
                "tw": tw or float(body_width), "pages": {str(k): v for k, v in pages.items()}}

    def _add_table(table, h, geo, pic, x_off, y, full_geo, cap, pi=0, a=None, b=None):
        start = int(table.get("start_row") or 0)
        jsid = f"table.{start}" + (f".{pi}" if pi else "")
        ov = table_overrides.get(jsid) or {}
        try:
            dx, dy = float(ov.get("x") or 0), float(ov.get("y") or 0)
        except (TypeError, ValueError):
            dx = dy = 0.0
        splits, pages = png._table_splits(ts_base, table), png._table_part_pages(ts_base, table)
        n_head = int(full_geo.get("header_rows") or 0)
        n_body = max(0, len(full_geo.get("rows") or []) - n_head)
        g = png.table_geo_from(geo, body_left)       # x (and its icons) from the body's left edge
        if a is not None:
            g["rowMap"] = list(range(n_head)) + [n_head + i for i in range(a, b)]
        texts = sorted({png._text(c.get("value")) for c in png._table_grid_values(table) if png._text(c.get("value"))})[:80]
        meta = {"kind": "table", "table": tables.index(table), "jsid": jsid, "row_start": start,
                "design_key": table.get("design_key") or "", "design": table.get("design") or "current",
                "align": table_align, "cap": cap, "dx": dx, "dy": dy, "geo": g, "after": after_gap,
                "splits": splits, "part_pages": {str(k): v for k, v in pages.items()}, "texts": texts,
                "cut": _cut_info(full_geo, 0 if a is None else a, n_body if a is None else b, pi, splits, pages),
                "at_top": abs(y - P["start"]) < 1}
        if a is not None:
            meta.update(slice=[a, b], pi=pi)
        el = TableElement(element_id=f"tbl_{start}_{pi}", x=float(body_left) + x_off, y=float(y),
                          width=float(body_width), height=float(h), style_role="Table", meta=meta)
        el.image = pic
        P["layout"].add(el)

    def _turn():
        P["page"] += 1
        P["layout"], P["y"] = _new_page(P["page"], P["page"])
        _cont_margins(P)
        layouts.append(P["layout"])
        P["start"] = P["y"]

    def _place_tables(row_idx):
        for table in tables_at.get(row_idx, []):
            splits = png._table_splits(ts_base, table)
            cap = None if splits else table_cap          # a cut table keeps its size in every part
            h_full, full_geo, pic_full = _measure_table(table, cap=cap)
            fresh = abs(P["y"] - P["start"]) < 1
            n_head = int(full_geo.get("header_rows") or 0)
            body_n = max(0, len(full_geo.get("rows") or []) - n_head)
            cuts = [k for k in splits if 0 < k < body_n]
            where = png._table_part_pages(ts_base, table)
            if cuts:
                # cut by the artist: the parts stay together on the table's page — side by side when they
                # fit across, else one under the other — except the ones sent to the page before / after
                bounds = [0] + cuts + [body_n]
                tw = float(sum(full_geo.get("cols") or []))
                gx = float(full_geo.get("x", body_left)) - body_left
                parts = [(pi, a, b) + _measure_table(table, (a, b)) for pi, (a, b) in enumerate(zip(bounds, bounds[1:]))]
                groups = {gv: [pt for pt in parts if where.get(pt[0], 0) == gv] for gv in (-1, 0, 1)}

                def place(group):
                    spots, block_h = png._table_part_block([pt[3] for pt in group], tw, gx, body_width, after_gap, table_align)
                    for (pi, a, b, ph, pgeo, ppic), (ox, oy) in zip(group, spots):
                        _add_table(table, ph, pgeo, ppic, ox, P["y"] + oy, full_geo, None, pi, a, b)
                    P["y"] += block_h + after_gap

                if groups[-1]:
                    place(groups[-1])
                    if groups[0] or groups[1]:
                        _turn()
                    if groups[0]:
                        place(groups[0])
                elif groups[0]:
                    _sp, block_h = png._table_part_block([pt[3] for pt in groups[0]], tw, gx, body_width, after_gap, table_align)
                    if P["y"] + block_h > body_bottom and not fresh:
                        _turn()
                    place(groups[0])
                if groups[1]:
                    if abs(P["y"] - P["start"]) >= 1:
                        _turn()
                    place(groups[1])
                continue
            if where.get(0) == 1 and not fresh:
                _turn()                                  # the artist sent the whole table to the next page
            elif P["y"] + h_full > body_bottom and not fresh:
                _turn()
            _add_table(table, h_full, full_geo, pic_full, 0.0, P["y"], full_geo, cap)
            P["y"] += h_full + after_gap

    # --- the paragraph: row by row (identical pagination math to the legacy renderer) --------
    P = {"left": body_left, "width": body_width, "bottom": body_bottom, "align": body_align, "gap": line_spacing_v,
         "look": (body_font, str(b_font), b_size, body_color, body_icon_h, body_gap_l, body_gap_r, body_fx, b_trk, False, False),
         "layout": layout, "y": current_y, "start": page_start_y, "page": page_index,
         "box_justify": str(body_align).lower() == "justify_center"}
    for row_idx in range(max(1, page_min_row), max(1, page_max_row) + 1):
        if tables_at:
            _place_tables(row_idx)
        if row_idx in (heading_row, cont_row) or any(a <= row_idx <= b for a, b in table_rows):
            continue                                     # the page heading, the Excel's continued note / a table's own rows
        row_text = _row_page_text(ws, row_idx, page_max_col, page_min_col)
        if not row_text:
            continue
        if _pbx.page_break(sheet_name, row_idx) and abs(P["y"] - P["start"]) >= 1:
            _turn()                                      # the artist sent this row to a new (Continued) page
        if row_idx in cuts:
            # the row without the words in its text boxes — and the artist's edit of what it shows now
            from . import icon_scales as _isc
            from . import text_edits as _ted

            row_text = _pbx.take_out(row_text, cuts[row_idx])
            row_text = _isc.apply(sheet_name, f"row:{row_idx}", _ted.apply(sheet_name, f"row:{row_idx}", row_text))
            if not row_text.strip():
                continue
        meta0 = {"kind": "body", "row": row_idx}
        if row_idx in cuts:
            meta0["boxed"] = True                    # some of its words are in a text box
        P["id"] = f"body_{row_idx}"
        _lay_row(P, row_idx, f"row:{row_idx}", row_text, meta0)
    if P.get("box_last"):                                # the paragraph box's last line: centred, not stretched
        _el, _runs, _w = P["box_last"]
        _el.align, _el.line_runs, _el.line_widths = "center", [_runs], [_w]

    # --- the text boxes: each on its page, laid out like a row of the paragraph in its own frame -----------
    from . import text_edits as _ted
    from . import text_styles as _tsb

    for _box in boxes_ready:
        bid = str(_box.get("id") or "")
        # its words as the Excel has them, one line per row they came from — or as the artist edited them
        # on the Canvas (text_edits "box:<id>", like a row's edit: kept while those words are unchanged)
        text_all = _ted.apply(sheet_name, f"box:{bid}", "\n".join(str(p["text"]) for p in _box["parts"]))
        if not str(text_all or "").strip() or not layouts:
            continue
        font_name = str(_box.get("font") or b_font)
        size = _safe_int(_box.get("size"), 0) or int(b_size)
        bold, italic = bool(_box.get("bold")), bool(_box.get("italic"))
        font = png._load_font(ImageFont, font_name, size, bold=bold, italic=italic)
        color = png._rgb(_box.get("rgb"), tuple(body_color)) if _box.get("rgb") else tuple(body_color)
        icon_h = max(1, int(round(body_icon_h * size / float(max(1, b_size)))))
        trk = float(_box.get("tracking")) if _box.get("tracking") not in (None, "") else float(b_trk or 0)
        _font_trk[id(font)] = trk
        fx = body_fx
        if _box.get("style"):                        # a layer style of the game's library, by name
            try:
                fx = png.fx_by_name(_tsb.library(), _box.get("style")) or body_fx
            except Exception:
                fx = body_fx
        line_set = _box.get("line") not in (None, "")    # its own line height: the gap above each line
        width = max(20, int(round(float(_box.get("w") or 0))))
        x0, y0 = float(_box["x"]), float(_box["y"])
        page = layouts[max(0, min(len(layouts) - 1, int(_box.get("page") or 0)))]
        B = {"left": x0, "width": width, "bottom": None, "align": str(_box.get("align") or body_align or "center"),
             "gap": max(0.0, float(_box["line"])) if line_set else line_spacing_v, "box": bid,
             "look": (font, font_name, size, color, icon_h, body_gap_l, body_gap_r, fx, trk, bold, italic),
             "layout": page, "y": y0, "start": y0, "page": 0, "id": f"box_{bid}"}
        made = _lay_row(B, None, f"box:{bid}", text_all,
                        {"kind": "box", "box": bid, "rows": [int(p["row"]) for p in _box["parts"]],
                         "box_h": float(_box.get("h") or 0), "line_height_box": B["gap"], "line_height_box_set": line_set})
        if not made:
            continue
        bottom = max(e.y + e.height for e in made)
        frame = {"x": x0, "y": y0, "w": float(width), "h": max(float(_box.get("h") or 0), bottom - y0)}
        for e in made:
            e.meta["frame"] = frame
    if layouts and boxes_missing:
        layouts[0].source["missing_boxes"] = [b for b in boxes_missing if b]

    if not layouts:
        return None
    return layouts


def build_sheet_layouts(ws, sheet_name, **kwargs):
    """build_sheet_layouts with the project's word styles / line strips active
    (previews call this outside a build, so nothing has turned them on yet)."""
    from . import text_styles

    if text_styles._ACTIVE.get() is not None:
        return _build_sheet_layouts(ws, sheet_name, **kwargs)
    ds = kwargs.get("dynamic_settings") or {}
    with text_styles.active(ds.get("text_style_rules") or [], sheet_name, ds.get("layer_style_library")):
        return _build_sheet_layouts(ws, sheet_name, **kwargs)


def _legacy_only(png, ws, sheet_name, dynamic_settings, table_style):
    """True when a page with tables also has what only the legacy renderer draws (as build_pngs_only
    decides): mapped JSON tables, section / multi headings, text rectangles in cells."""
    try:
        mapped = png.load_mapped_table_templates(table_style.get("mapped_table_jsons", ""),
                                                 sheet_overrides=table_style.get("json_sheet_overrides") or {})
        if any(not r.get("error") and png.template_matches_sheet(r, sheet_name) for r in mapped):
            return True
    except Exception:
        return True
    if png._png_cell_coords_for_sheet(dynamic_settings.get("page_heading_cell_overrides", ""), sheet_name) \
            or png._png_cell_coords_for_sheet(dynamic_settings.get("page_subheading_cell_overrides", ""), sheet_name) \
            or png._png_multi_heading_rows(ws, sheet_name, str(dynamic_settings.get("page_multi_heading_overrides") or "").strip()) \
            or png._png_cell_coords_for_sheet(table_style.get("text_rectangle_cells", ""), sheet_name):
        return True
    return False


def _build_sheet_layouts(
    ws,
    sheet_name,
    *,
    canvas_w=1920,
    canvas_h=1080,
    margin_x=100,
    h_font="Arial",
    h_size=72,
    h_icon_h=48,
    h_rgb=(255, 80, 80),
    b_font="Arial",
    b_size=30,
    b_icon_h=24,
    b_rgb=(255, 255, 255),
    line_spacing=4,
    para_spacing=12,
    line_gap=None,
    heading_top_margin=120,
    heading_to_body_gap=40,
    bottom_margin=80,
    max_col_limit=12,
    icon_folder="",
    icon_mappings=None,
    icon_size_overrides=None,
    dynamic_settings=None,
    page_overrides=None,
    alignment_settings=None,
    heading_image_folder="",
    measure_layer=None,
    font_cache=None,
    inner_canvas_width=0,
    continued_gap=15,
    icon_y_offset=0,
    heading_fx=None,
    body_fx=None,
    table_style=None,
):
    """High-level per-sheet entry: compute the page window/heading like the
    historical builder, then build the canonical layouts.

    Returns a list of PageLayout or None (unsupported / feature-gated off —
    the caller must use the historical path).
    """
    png = _png()
    if not canonical_layout_enabled():
        return None
    dynamic_settings = dict(dynamic_settings or {})
    if heading_fx is None or body_fx is None:
        _lib = dynamic_settings.get("layer_style_library", {}) or {}
        _sas = dynamic_settings.get("style_assignments", {}) or {}
        if heading_fx is None:
            heading_fx = png._resolve_fx_config(_lib, _sas, "Heading text")
        if body_fx is None:
            body_fx = png._resolve_fx_config(_lib, _sas, "Body text")

    page_min_row, page_max_row, page_min_col, page_max_col = png._render_window_for_sheet(
        dynamic_settings, str(sheet_name), max_col_limit, ws,
    )
    table_style = dict(png.TABLE_DEFAULTS, **(table_style or {}))
    tables = (
        png._prepare_tables(ws, table_style, page_max_col, str(sheet_name), min_col_limit=page_min_col)
        if dynamic_settings.get("enable_tables", True) is not False
        else []
    )
    if tables and (page_min_row > 1 or page_max_row < (ws.max_row or 1)):
        tables = [t for t in tables if int(t.get("start_row", 0)) <= page_max_row and int(t.get("end_row", 0)) >= page_min_row]
    if tables and _legacy_only(png, ws, str(sheet_name), dynamic_settings, table_style):
        return None                                      # mapped tables, section headings, text boxes in cells

    heading_row, heading_text = png._find_heading_row(
        ws, page_max_col, [(int(t["start_row"]), int(t["end_row"])) for t in tables],
        min_row=page_min_row, max_row=page_max_row,
    )

    try:
        page_overrides = page_overrides or {}
        sheet_over = png._png_page_style_override(str(sheet_name), page_overrides)
        pg_h_size = h_size
        if sheet_over.get("h_size") is not None:
            try:
                pg_h_size = max(8, int(float(sheet_over.get("h_size") or h_size)))
            except Exception:
                pg_h_size = h_size
        pg_b_size = b_size
        if sheet_over.get("b_size") is not None:
            try:
                pg_b_size = max(8, int(float(sheet_over.get("b_size") or b_size)))
            except Exception:
                pg_b_size = b_size
        pg_h_font = str(sheet_over.get("h_font") or h_font)
        pg_b_font = str(sheet_over.get("b_font") or b_font)
        pg_h_rgb = sheet_over.get("h_rgb") or h_rgb
        pg_b_rgb = sheet_over.get("b_rgb") or b_rgb
    except Exception:
        pg_h_size, pg_b_size = h_size, b_size
        pg_h_font, pg_b_font = str(h_font), str(b_font)
        pg_h_rgb, pg_b_rgb = h_rgb, b_rgb

    return build_normal_page_layouts(
        ws,
        str(sheet_name),
        canvas_w=canvas_w, canvas_h=canvas_h, margin_x=margin_x,
        inner_canvas_width=inner_canvas_width,
        h_font=pg_h_font, h_size=pg_h_size, h_icon_h=h_icon_h, h_rgb=pg_h_rgb,
        b_font=pg_b_font, b_size=pg_b_size, b_icon_h=b_icon_h, b_rgb=pg_b_rgb,
        line_spacing=line_spacing, para_spacing=para_spacing, line_gap=line_gap,
        continued_gap=continued_gap, heading_top_margin=heading_top_margin,
        heading_to_body_gap=heading_to_body_gap, bottom_margin=bottom_margin,
        icon_folder=icon_folder, icon_mappings=icon_mappings,
        icon_size_overrides=icon_size_overrides,
        page_min_row=page_min_row, page_max_row=page_max_row,
        page_min_col=page_min_col, page_max_col=page_max_col,
        heading_row=heading_row, heading_text=heading_text,
        alignment_settings=alignment_settings,
        heading_image_folder=heading_image_folder,
        measure_adapter=None,  # high-level entry uses the Pillow math (parity)
        icon_y_offset=icon_y_offset,
        heading_fx=heading_fx, body_fx=body_fx,
        icon_gap_left=dynamic_settings.get("icon_gap_left", 15),
        icon_gap_right=dynamic_settings.get("icon_gap_right", 15),
        letter_spacing={"heading": png._tracking_setting(dynamic_settings, "heading_tracking"),
                        "body": png._tracking_setting(dynamic_settings, "body_tracking"),
                        "heading_shape": png.heading_shape(dynamic_settings)},
        heading_icon_gap_left=dynamic_settings.get("heading_icon_gap_left", dynamic_settings.get("heading_icon_gap", 15)),
        heading_icon_gap_right=dynamic_settings.get("heading_icon_gap_right", dynamic_settings.get("heading_icon_gap", 15)),
        tables=tables, table_style=table_style,
        table_overrides=((dynamic_settings.get("live_overrides") or {}).get(str(sheet_name)) or {}),
    )