"""Icon token scanning and per-token asset override helpers.

Mappings are optional. When an override is cleared, callers automatically fall
back to the normal Icons Folder lookup using the Excel token name.
"""
from __future__ import annotations

import os
import re
from typing import Dict, Iterable, List, Optional

from openpyxl import load_workbook

TOKEN_RE = re.compile(r"<([^<>]+)>")
SUPPORTED_EXTENSIONS = (".png", ".jpg", ".jpeg", ".psd")

_WORD_NUMBER_ALIASES = {
    "one": "1", "two": "2", "three": "3", "four": "4", "five": "5",
    "six": "6", "seven": "7", "eight": "8", "nine": "9", "ten": "10",
}


def _token_alias_keys(value: str) -> List[str]:
    """Compact token plus its number-word aliases ("TEN"/"ten" -> {"ten","10"})."""
    compact = _compact_token(value)
    out = [compact]
    if compact in _WORD_NUMBER_ALIASES and _WORD_NUMBER_ALIASES[compact] not in out:
        out.append(_WORD_NUMBER_ALIASES[compact])
    return out

_folder_file_cache: Dict[str, Dict[str, str]] = {}
"""folder -> {normalized name -> actual filename}"""


def _cache_folder_listing(folder: str) -> Dict[str, str]:
    """Scan folder once and return {lowercase_name: actual_name} for icon files."""
    if not folder or not os.path.isdir(folder):
        return {}
    if folder not in _folder_file_cache:
        _folder_file_cache[folder] = {
            name.casefold(): name
            for name in os.listdir(folder)
            if os.path.splitext(name)[1].casefold() in SUPPORTED_EXTENSIONS
        }
    return _folder_file_cache[folder]


def _clear_folder_cache(folder: Optional[str] = None):
    if folder:
        _folder_file_cache.pop(folder, None)
    else:
        _folder_file_cache.clear()


def _untag(token) -> str:
    """Drop an Assets & Icons size tag: 'WILD~140' -> 'WILD' (see icon_scales)."""
    return re.sub(r"(?:~\d+(?:\.\d+)?)?(?:\^[\d.]+,[\d.]+)?\s*$", "", str(token or "").strip().strip("<>")).strip()


def normalize_token(token: str) -> str:
    value = _untag(token).casefold()
    return re.sub(r"[\s_-]+", " ", value)


def _compact_token(token: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", _untag(token).casefold())


def scan_excel_icon_tokens(excel_path: str) -> List[str]:
    """Return unique <token> names from every worksheet, preserving first case/order."""
    if not excel_path or not os.path.isfile(excel_path):
        return []
    wb = load_workbook(excel_path, data_only=False, read_only=True)
    result: List[str] = []
    seen = set()
    try:
        for ws in wb.worksheets:
            for row in ws.iter_rows(values_only=True):
                for value in row:
                    if not isinstance(value, str):
                        continue
                    for match in TOKEN_RE.findall(value):
                        token = match.strip()
                        key = normalize_token(token)
                        if token and key not in seen:
                            seen.add(key)
                            result.append(token)
    finally:
        try:
            wb.close()
        except Exception:
            pass
    return result


def list_icon_files(icon_folder: str) -> List[str]:
    if not icon_folder or not os.path.isdir(icon_folder):
        return []
    folder_map = _cache_folder_listing(icon_folder)
    return sorted(folder_map.values(), key=str.casefold)


def _case_insensitive_file(folder: str, filename: str) -> Optional[str]:
    if not folder or not os.path.isdir(folder) or not filename:
        return None
    folder_map = _cache_folder_listing(folder)
    matched = folder_map.get(os.path.basename(filename).casefold())
    return os.path.join(folder, matched) if matched else None


def _name_variants(value: str) -> List[str]:
    value = re.sub(r"\s+", " ", str(value or "").strip().strip("<>").strip())
    if not value:
        return []
    variants = [
        value,
        re.sub(r"\s+", "_", value),
        re.sub(r"\s+", "-", value),
        re.sub(r"[\s_-]+", "", value),
        value.replace("_", " "),
        value.replace("-", " "),
    ]
    result = []
    seen = set()
    for variant in variants:
        key = variant.casefold()
        if variant and key not in seen:
            seen.add(key)
            result.append(variant)
    return result


def _canonical_file_match(folder: str, value: str) -> Optional[str]:
    if not folder or not os.path.isdir(folder):
        return None
    wanted = re.sub(r"[^a-z0-9]+", "", str(value or "").casefold())
    if not wanted:
        return None
    folder_map = _cache_folder_listing(folder)
    for actual_name in folder_map.values():
        stem, extension = os.path.splitext(actual_name)
        if re.sub(r"[^a-z0-9]+", "", stem.casefold()) == wanted:
            return os.path.join(folder, actual_name)
    return None


def get_mapping_override(token: str, mappings: Optional[Dict[str, str]]) -> Optional[str]:
    if not mappings:
        return None
    wanted = normalize_token(token)
    wanted_keys = _token_alias_keys(token)
    for key, value in mappings.items():
        if normalize_token(key) != wanted and _compact_token(key) not in wanted_keys:
            continue
        if isinstance(value, dict):
            path_value = str(value.get("path") or value.get("asset") or "").strip()
            if path_value:
                return path_value
        elif str(value or "").strip():
            return str(value).strip()
    return None


def get_icon_size_override(token: str, size_overrides: Optional[Dict[str, int]]) -> Optional[int]:
    if not size_overrides:
        return None
    wanted = normalize_token(token)
    wanted_keys = _token_alias_keys(token)
    for key, value in size_overrides.items():
        if normalize_token(key) != wanted and _compact_token(key) not in wanted_keys:
            continue
        try:
            size_value = int(value)
        except Exception:
            return None
        return size_value if size_value > 0 else None
    return None


def resolve_icon_path(
    token: str,
    icon_folder: str,
    mappings: Optional[Dict[str, str]] = None,
    candidates: Optional[Iterable[str]] = None,
) -> Optional[str]:
    """Resolve an icon override first, then fall back to normal folder lookup.

    Mapping values may be absolute paths or filenames relative to Icons Folder.
    A missing/broken override does not block the normal fallback.
    """
    token = _untag(token)
    override = get_mapping_override(token, mappings)
    if override:
        if os.path.isabs(override) and os.path.isfile(override):
            return override
        joined = os.path.join(icon_folder or "", override)
        if os.path.isfile(joined):
            return joined
        matched = _case_insensitive_file(icon_folder, override)
        if matched:
            return matched

    values: List[str] = []
    seen_values = set()

    def _add_value(v: str) -> None:
        v = str(v or "").strip()
        if not v:
            return
        key = v.casefold()
        if key in seen_values:
            return
        seen_values.add(key)
        values.append(v)

    for value in [token, *(list(candidates or []))]:
        value = str(value or "").strip().strip("<>").strip()
        _add_value(value)
        for alias in _token_alias_keys(value):
            _add_value(alias)

    names: List[str] = []
    for value in values:
        for variant in _name_variants(value):
            names.append(variant)
            root, extension = os.path.splitext(variant)
            if not extension:
                names.extend(variant + ext for ext in SUPPORTED_EXTENSIONS)

    seen = set()
    for name in names:
        key = name.casefold()
        if key in seen:
            continue
        seen.add(key)
        if os.path.isabs(name) and os.path.isfile(name):
            return name
        joined = os.path.join(icon_folder or "", name)
        if os.path.isfile(joined):
            return joined
        matched = _case_insensitive_file(icon_folder, name)
        if matched:
            return matched
    for value in values:
        matched = _canonical_file_match(icon_folder, value)
        if matched:
            return matched
    return None
