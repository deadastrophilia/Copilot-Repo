import os
import json
import re
import queue
import threading
import time
import tkinter as tk
from tkinter import ttk, filedialog, colorchooser, font, messagebox, simpledialog
from openpyxl import load_workbook

from .config import TABLE_DEFAULTS
from .session_manager import save_session, load_session
from .keyword_manager import KeywordManager
from .build_engine import execute_build, build_performance_mode_report
from .png_builder import build_pngs_only
from .icon_mapping import scan_excel_icon_tokens, list_icon_files, normalize_token, resolve_icon_path
from .custom_layout_exporter import export_paytable_json_from_active_psd, export_paytable_json_from_psd_group, list_psd_group_paths
from .template_mapper_ui import open_template_mapper
from .table_mapper_ui import open_table_mapper
from .layer_styles import (
    apply_serialized_layer_style,
    capture_copied_layer_style_from_photoshop,
    capture_selected_layer_style_from_photoshop,
)
from .project_settings import load_settings_for_psd, save_settings_for_psd
from .project_manifest import load_manifest, workbook_hashes
from .production_features import (
    batch_export_psd_groups,
    copy_psd_backup,
    excel_diff_summary,
    finish_render_report,
    format_render_report,
    list_psd_top_level_groups,
    preview_excel_tab,
    save_render_report,
    scan_icon_status,
    start_render_report,
)


def launch_ui():
    root = tk.Tk()
    root.title("PsHelpScreenTool V46.5")
    root.geometry("1260x800")
    root.minsize(980, 640)
    root.attributes('-topmost', False)
    root.resizable(True, True)

    sys_fonts = sorted(list(font.families()))
    ui_font_family = next((name for name in ["Segoe UI Variable", "Segoe UI", "Arial"] if name in sys_fonts), "Arial")
    ui_font = (ui_font_family, 11)
    ui_font_label = (ui_font_family, 13)
    ui_font_semibold = (ui_font_family, 11, "bold")
    ui_font_card = (ui_font_family, 16, "bold")
    ui_font_title = (ui_font_family, 23, "bold")
    ui_font_button = (ui_font_family, 14, "bold")

    style = ttk.Style()
    style.theme_use('clam')
    palette = {
        "app_bg": "#101114",
        "sidebar_bg": "#15161A",
        "panel_bg": "#1A1C20",
        "panel_soft": "#202329",
        "input_bg": "#24262B",
        "border": "#34363D",
        "text": "#F8F5EA",
        "muted": "#B8B2A3",
        "accent": "#F6C343",
        "accent_alt": "#E89B24",
        "accent_soft": "#2D2718",
        "success": "#4CAF50",
        "warning": "#E89B24",
        "error": "#E05252",
        "tab_idle": "#17191D",
        "tab_selected": "#2D2718",
        "button_text_on_accent": "#101114",
    }
    root.configure(bg=palette["app_bg"])
    root.option_add("*Font", ui_font)
    root.option_add("*TCombobox*Listbox.background", palette["input_bg"])
    root.option_add("*TCombobox*Listbox.foreground", palette["text"])
    root.option_add("*TCombobox*Listbox.selectBackground", palette["accent"])
    root.option_add("*TCombobox*Listbox.selectForeground", palette["button_text_on_accent"])
    root.option_add("*Listbox.selectBackground", palette["accent"])
    root.option_add("*Listbox.selectForeground", palette["button_text_on_accent"])
    try:
        style.configure(".", background=palette["app_bg"], foreground=palette["text"], font=ui_font)
        style.configure("TFrame", background=palette["app_bg"])
        style.configure("Card.TFrame", background=palette["panel_bg"], relief="flat", borderwidth=1)
        style.configure("Sidebar.TFrame", background=palette["sidebar_bg"])
        style.configure("Panel.TFrame", background=palette["panel_soft"])
        style.configure("TLabel", background=palette["app_bg"], foreground=palette["text"])
        style.configure("Muted.TLabel", background=palette["app_bg"], foreground=palette["muted"])
        style.configure("FieldLabel.TLabel", background=palette["app_bg"], foreground=palette["text"], font=ui_font_semibold)
        style.configure("SidebarSection.TLabel", background=palette["sidebar_bg"], foreground=palette["muted"], font=ui_font_semibold)
        style.configure("SidebarTitle.TLabel", background=palette["sidebar_bg"], foreground=palette["text"], font=ui_font_card)
        style.configure("SidebarCaption.TLabel", background=palette["sidebar_bg"], foreground=palette["muted"], font=ui_font)
        style.configure("Title.TLabel", background=palette["app_bg"], foreground=palette["text"], font=ui_font_title)
        style.configure("SectionTitle.TLabel", background=palette["app_bg"], foreground=palette["text"], font=ui_font_card)
        style.configure("SubTitle.TLabel", background=palette["app_bg"], foreground=palette["text"], font=(ui_font_family, 15, "bold"))
        style.configure("CardTitle.TLabel", background=palette["panel_bg"], foreground=palette["text"], font=ui_font_card)
        style.configure("CardMuted.TLabel", background=palette["panel_bg"], foreground=palette["muted"], font=ui_font)
        style.configure("Status.TLabel", background=palette["panel_bg"], foreground=palette["muted"], font=ui_font, anchor="w")
        style.configure("TNotebook", background=palette["app_bg"], borderwidth=0, tabmargins=(0, 0, 0, 0))
        style.configure("TNotebook.Tab", background=palette["tab_idle"], foreground=palette["muted"], padding=(16, 10), font=ui_font_semibold)
        style.map(
            "TNotebook.Tab",
            background=[("selected", palette["tab_selected"]), ("active", palette["panel_soft"])],
            foreground=[("selected", palette["accent"]), ("active", palette["text"])],
            padding=[("selected", (20, 14)), ("active", (17, 11))],
            expand=[("selected", (1, 1, 1, 0))],
        )
        style.layout("Content.TNotebook.Tab", [])
        style.configure("Content.TNotebook", background=palette["app_bg"], borderwidth=0, tabmargins=(0, 0, 0, 0))
        style.configure("TLabelframe", background=palette["panel_bg"], bordercolor=palette["border"], borderwidth=1, relief="solid", padding=10)
        style.configure("TLabelframe.Label", background=palette["panel_bg"], foreground=palette["text"], font=ui_font_semibold)
        style.configure("TButton", padding=(12, 10), font=ui_font_button, background=palette["panel_soft"], foreground=palette["text"], borderwidth=1, focusthickness=0)
        style.map("TButton", background=[("active", palette["border"]), ("pressed", palette["border"])], foreground=[("disabled", palette["muted"])])
        style.configure("Primary.TButton", background=palette["accent"], foreground=palette["button_text_on_accent"], bordercolor=palette["accent"])
        style.map("Primary.TButton", background=[("active", palette["accent_alt"]), ("pressed", palette["accent_alt"])])
        style.configure("Mapper.TButton", background=palette["error"], foreground=palette["text"], bordercolor=palette["error"])
        style.map("Mapper.TButton", background=[("active", "#EF6464"), ("pressed", "#C73F3F")])
        style.configure("Secondary.TButton", background=palette["panel_soft"], foreground=palette["text"], bordercolor=palette["border"])
        style.configure("Danger.TButton", background=palette["error"], foreground=palette["text"], bordercolor=palette["error"])
        style.map("Danger.TButton", background=[("active", "#DC2626"), ("pressed", "#DC2626")])
        style.configure("Warning.TButton", background=palette["warning"], foreground=palette["button_text_on_accent"], bordercolor=palette["warning"])
        style.map("Warning.TButton", background=[("active", palette["accent"]), ("pressed", palette["accent"])])
        style.configure("Launcher.TButton", font=ui_font_button, padding=(20, 14), background=palette["accent"], foreground=palette["button_text_on_accent"], bordercolor=palette["accent"])
        style.map("Launcher.TButton", background=[("active", palette["accent_alt"]), ("pressed", palette["accent_alt"])])
        style.configure("BigBuild.TButton", font=(ui_font_family, 15, "bold"), padding=(34, 18), background=palette["accent"], foreground=palette["button_text_on_accent"], bordercolor=palette["accent"])
        style.map("BigBuild.TButton", background=[("active", palette["accent_alt"]), ("pressed", palette["accent_alt"])])
        style.configure("BigWarning.TButton", font=(ui_font_family, 15, "bold"), padding=(34, 18), background=palette["warning"], foreground=palette["button_text_on_accent"], bordercolor=palette["warning"])
        style.map("BigWarning.TButton", background=[("active", palette["accent"]), ("pressed", palette["accent"])])
        style.configure("TEntry", fieldbackground=palette["input_bg"], foreground=palette["text"], bordercolor=palette["border"], insertcolor=palette["text"], lightcolor=palette["border"], darkcolor=palette["border"], padding=8)
        style.map("TEntry", fieldbackground=[("disabled", palette["input_bg"])], foreground=[("disabled", palette["muted"])])
        style.configure("TCombobox", fieldbackground=palette["input_bg"], background=palette["input_bg"], foreground=palette["text"], arrowcolor=palette["muted"], bordercolor=palette["border"], lightcolor=palette["border"], darkcolor=palette["border"], padding=8)
        style.map("TCombobox", fieldbackground=[("readonly", palette["input_bg"]), ("disabled", palette["input_bg"])], foreground=[("readonly", palette["text"]), ("disabled", palette["muted"])], selectforeground=[("readonly", palette["text"])], selectbackground=[("readonly", palette["input_bg"])], background=[("readonly", palette["input_bg"])])
        style.configure("TSpinbox", fieldbackground=palette["input_bg"], background=palette["input_bg"], foreground=palette["text"], arrowcolor=palette["muted"], bordercolor=palette["border"], lightcolor=palette["border"], darkcolor=palette["border"], padding=8)
        style.configure("TRadiobutton", background=palette["app_bg"], foreground=palette["text"])
        style.configure("TCheckbutton", background=palette["app_bg"], foreground=palette["text"])
        style.map("TCheckbutton", foreground=[("disabled", palette["muted"])])
        style.configure("Treeview", rowheight=28, fieldbackground=palette["panel_bg"], background=palette["panel_bg"], foreground=palette["text"], bordercolor=palette["border"])
        style.map("Treeview", background=[("selected", palette["accent"])], foreground=[("selected", palette["button_text_on_accent"])])
        style.configure("Treeview.Heading", font=ui_font_semibold, background=palette["panel_soft"], foreground=palette["text"], bordercolor=palette["border"])
    except Exception:
        pass

    excel_var = tk.StringVar()
    prev_excel_var = tk.StringVar()
    prev_psd_var = tk.StringVar()
    icon_var = tk.StringVar()
    bg_var = tk.StringVar()
    output_dir_var = tk.StringVar()
    output_name_var = tk.StringVar(value="")
    output_format_var = tk.StringVar(value="PSD")
    update_save_mode_var = tk.StringVar(value="new_copy")
    rerender_psd_var = tk.StringVar(value="")
    rerender_mode_var = tk.StringVar(value="replace")
    render_selected_pages_var = tk.BooleanVar(value=False)
    performance_mode_var = tk.BooleanVar(value=False)
    canvas_preset_var = tk.StringVar(value="FHD 1920x1080")
    custom_canvas_presets = {}
    bg_mode_var = tk.StringVar(value="stretch")
    h_color_var = tk.StringVar(value="#1e1e1e")
    b_color_var = tk.StringVar(value="#1e1e1e")
    h_font_style_var = tk.StringVar(value="Regular")
    b_font_style_var = tk.StringVar(value="Regular")
    h_rgb_val = [30, 30, 30]
    b_rgb_val = [30, 30, 30]
    body_icon_original_size_var = tk.BooleanVar(value=False)
    enable_tables_var = tk.BooleanVar(value=True)
    mapped_table_json_var = tk.StringVar(value="")
    json_sheet_overrides = {}  # {json_path: [sheet1, sheet2, ...]}

    header_fill_var = tk.StringVar(value="#14141E")
    row1_fill_var = tk.StringVar(value="#232332")
    row2_fill_var = tk.StringVar(value="#1C1C2A")
    stroke_color_var = tk.StringVar(value="#FFFFFF")
    table_header_rgb_val = [20, 20, 30]
    table_row1_rgb_val = [35, 35, 50]
    table_row2_rgb_val = [28, 28, 42]
    table_stroke_rgb_val = [255, 255, 255]
    table_header_text_rgb_val = [255, 255, 255]
    table_body_text_rgb_val = [255, 255, 255]
    table_inherit_font_var = tk.BooleanVar(value=True)
    table_merge_layers_var = tk.BooleanVar(value=False)
    table_header_font_style_var = tk.StringVar(value="Regular")
    table_body_font_style_var = tk.StringVar(value="Regular")
    table_header_text_color_var = tk.StringVar(value="#FFFFFF")
    table_body_text_color_var = tk.StringVar(value="#FFFFFF")
    subheading_font_style_var = tk.StringVar(value="SemiBold")
    subheading_text_color_var = tk.StringVar(value="#FFFFFF")
    subheading_rgb_val = [255, 255, 255]
    text_rect_fill_var = tk.StringVar(value="#14141E")
    text_rect_stroke_var = tk.StringVar(value="#FFFFFF")
    text_rect_text_color_var = tk.StringVar(value="#FFFFFF")
    text_rect_fill_rgb_val = [20, 20, 30]
    text_rect_stroke_rgb_val = [255, 255, 255]
    text_rect_text_rgb_val = [255, 255, 255]
    text_rect_font_style_var = tk.StringVar(value="Regular")
    text_rect_alignment_var = tk.StringVar(value="center")

    # Reusable layer-style vars. Captured Photoshop FX are serialized so they
    # survive sessions and can be shared by heading, body, or optional icons.
    paste_heading_style_var = tk.BooleanVar(value=False)
    copied_heading_style_name_var = tk.StringVar(value="Copied Photoshop layer style")
    heading_style_status_var = tk.StringVar(value="Copied Photoshop layer style is off.")
    h_stroke_enable_var = tk.BooleanVar(value=False)
    h_shadow_enable_var = tk.BooleanVar(value=False)
    h_stroke_color_var = tk.StringVar(value="#FFFFFF")
    h_shadow_color_var = tk.StringVar(value="#000000")
    h_shadow_blend_var = tk.StringVar(value="Multiply")
    h_stroke_rgb_val = [255, 255, 255]
    h_shadow_rgb_val = [0, 0, 0]
    paste_body_style_var = tk.BooleanVar(value=False)
    copied_body_style_name_var = tk.StringVar(value="Copied Photoshop layer style")
    body_style_status_var = tk.StringVar(value="Copied Photoshop layer style is off.")
    b_stroke_enable_var = tk.BooleanVar(value=False)
    b_shadow_enable_var = tk.BooleanVar(value=False)
    b_stroke_color_var = tk.StringVar(value="#FFFFFF")
    b_shadow_color_var = tk.StringVar(value="#000000")
    b_shadow_blend_var = tk.StringVar(value="Multiply")
    b_stroke_rgb_val = [255, 255, 255]
    b_shadow_rgb_val = [0, 0, 0]
    heading_captured_style = {"hex": "", "params": {}}
    body_captured_style = {"hex": "", "params": {}}
    layer_style_library = {}
    heading_saved_style_var = tk.StringVar(value="")
    body_saved_style_var = tk.StringVar(value="")
    icon_layer_style_enabled_var = tk.BooleanVar(value=False)
    icon_saved_style_var = tk.StringVar(value="")
    layer_style_assignments = {}
    style_sidecar_path_var = tk.StringVar(value="")
    style_global_folder_var = tk.StringVar(value=os.path.join(os.path.dirname(os.path.dirname(__file__)), "Layer Styles"))
    style_manager_name_var = tk.StringVar(value="")
    style_manager_choice_var = tk.StringVar(value="")
    style_manager_target_var = tk.StringVar(value="Heading text")
    style_manager_status_var = tk.StringVar(value="Capture or load a Photoshop layer style preset.")
    style_manager_apply_active_var = tk.BooleanVar(value=False)

    ALIGN_CHOICES = ["left", "center", "right"]
    BODY_ALIGN_CHOICES = ["left", "center", "right", "justify"]
    alignment_source_var = tk.StringVar(value="Use page override if available, else global")
    heading_alignment_var = tk.StringVar(value="center")
    body_alignment_var = tk.StringVar(value="center")
    table_alignment_var = tk.StringVar(value="center")
    bottom_alignment_var = tk.StringVar(value="center")
    paytable_notes_alignment_var = tk.StringVar(value="center")
    page_alignment_overrides = {}
    alignment_page_var = tk.StringVar(value="")
    alignment_use_global_var = tk.BooleanVar(value=True)
    alignment_override_heading_var = tk.StringVar(value="center")
    alignment_override_body_var = tk.StringVar(value="center")
    alignment_override_table_var = tk.StringVar(value="center")
    alignment_override_bottom_var = tk.StringVar(value="center")
    alignment_override_paytable_var = tk.StringVar(value="center")
    heading_image_folder_var = tk.StringVar(value="")
    alignment_override_heading_image_var = tk.StringVar(value="")
    heading_uppercase_var = tk.BooleanVar(value=False)
    heading_game_name_text_var = tk.StringVar(value="")
    heading_keep_one_line_var = tk.BooleanVar(value=False)

    # Dynamic-page addon settings. These are isolated from normal pages.
    default_template_json = os.path.join(os.path.dirname(__file__), "dynamic_pages", "templates", "Paytable.json")
    dynamic_enable_var = tk.BooleanVar(value=True)
    dynamic_sheet_var = tk.StringVar(value="Paytable")
    dynamic_template_json_var = tk.StringVar(value=default_template_json)
    dynamic_template_folder_var = tk.StringVar(value=os.path.dirname(default_template_json))
    dynamic_wild_asset_var = tk.StringVar(value="gold_scat.png")
    dynamic_wild_title_slot_enabled_var = tk.BooleanVar(value=False)
    dynamic_scatter_title_slot_enabled_var = tk.BooleanVar(value=False)
    dynamic_wild_title_slot_text_var = tk.StringVar(value="WILD")
    dynamic_scatter_title_slot_text_var = tk.StringVar(value="SCATTER")
    dynamic_count_font_style_var = tk.StringVar(value="Regular")
    dynamic_value_font_style_var = tk.StringVar(value="Regular")
    game_rules_bottom_font_style_var = tk.StringVar(value="Regular")
    bingo_rules_one_page_var = tk.BooleanVar(value=True)
    bingo_rules_body_ranges_var = tk.StringVar(value="")

    dynamic_count_rgb_val = [255, 175, 55]
    dynamic_value_rgb_val = [255, 255, 255]
    dynamic_top_bg_rgb_val = [8, 10, 18]
    dynamic_lower_bg_rgb_val = [16, 10, 28]
    dynamic_card_stroke_rgb_val = [35, 35, 50]
    dynamic_text_bg_rgb_val = [10, 10, 18]
    dynamic_wild_title_rgb_val = [255, 205, 50]
    dynamic_wild_text_rgb_val = [255, 255, 255]
    dynamic_notes_rgb_val = [255, 255, 255]
    dynamic_fallback_rgb_val = [255, 255, 255]

    dynamic_count_color_var = tk.StringVar(value="#FFAF37")
    dynamic_value_color_var = tk.StringVar(value="#FFFFFF")
    dynamic_top_bg_color_var = tk.StringVar(value="#080A12")
    dynamic_lower_bg_color_var = tk.StringVar(value="#100A1C")
    dynamic_card_stroke_color_var = tk.StringVar(value="#232332")
    dynamic_text_bg_color_var = tk.StringVar(value="#0A0A12")
    dynamic_wild_title_color_var = tk.StringVar(value="#FFCD32")
    dynamic_wild_text_color_var = tk.StringVar(value="#FFFFFF")
    dynamic_notes_color_var = tk.StringVar(value="#FFFFFF")
    dynamic_fallback_color_var = tk.StringVar(value="#FFFFFF")
    game_rules_separator_color_var = tk.StringVar(value="#FFFFFF")
    game_rules_separator_rgb_val = [255, 255, 255]
    game_rules_separator_alignment_var = tk.StringVar(value="center")
    game_rules_xtra_reels_enabled_var = tk.BooleanVar(value=False)
    game_rules_xtra_reels_asset_var = tk.StringVar(value="")

    keyword_mgr = KeywordManager()
    FONT_STYLE_CHOICES = ["Regular", "Medium", "SemiBold", "Bold", "Italic", "Bold Italic", "Black", "Light", "Condensed"]
    EXCEL_FILETYPES = [
        ("Excel workbooks", "*.xlsx;*.xlsm"),
        ("Excel workbook", "*.xlsx"),
        ("Excel macro-enabled workbook", "*.xlsm"),
        ("All files", "*.*"),
    ]

    def _filter_font_combo(combo):
        typed = combo.get().strip().casefold()
        if not typed:
            combo["values"] = sys_fonts
            return
        starts = [name for name in sys_fonts if name.casefold().startswith(typed)]
        contains = [name for name in sys_fonts if typed in name.casefold() and name not in starts]
        combo["values"] = starts + contains

    def _font_request(family, style_name):
        family = str(family or "").strip()
        style_name = str(style_name or "Regular").strip()
        if not family or style_name.casefold() == "regular":
            return family
        return f"{family} {style_name}"

    CANVAS_PRESETS = {
        "FHD 1920x1080": (1920, 1080),
        "2K QHD 2560x1440": (2560, 1440),
        "4K UHD 3840x2160": (3840, 2160),
        "Square 2048x2048": (2048, 2048),
        "Portrait 1080x1920": (1080, 1920),
    }

    # Per-token icon overrides. Keys are Excel token names without < >.
    # Empty/removed mappings always fall back to the normal Icons Folder lookup.
    icon_mappings = {}
    # Optional per-token body icon height overrides, e.g. {"gold_scat": 72}.
    # Heading/table/paytable icons keep their own dedicated size controls.
    icon_size_overrides = {}
    icon_tokens = []
    mapping_selected_token_var = tk.StringVar(value="No token selected")
    mapping_choice_var = tk.StringVar(value="")
    mapping_size_var = tk.StringVar(value="")
    sheet_listbox = None
    rerender_listbox = None
    missing_icon_tree = None
    missing_icon_preview_label = None
    missing_icon_preview_ref = {"image": None}
    render_report_text = None
    preview_text = None
    diff_preview_text = None
    preset_listbox = None
    export_group_listbox = None
    style_manager_cb = None

    preset_folder_var = tk.StringVar(value=os.path.join(os.path.dirname(__file__), "presets"))
    preset_name_var = tk.StringVar(value="")
    auto_fit_enabled_var = tk.BooleanVar(value=False)
    auto_fit_mode_var = tk.StringVar(value="Warn only")
    safe_backup_enabled_var = tk.BooleanVar(value=True)
    safe_backup_folder_var = tk.StringVar(value="")
    safe_duplicate_group_var = tk.BooleanVar(value=False)
    confirm_update_diff_var = tk.BooleanVar(value=True)
    batch_export_psd_var = tk.StringVar(value="")
    batch_export_folder_var = tk.StringVar(value="")
    batch_export_format_var = tk.StringVar(value="PNG")
    batch_export_quality_var = tk.StringVar(value="90")
    batch_export_suffix_var = tk.StringVar(value="MyExport")
    batch_export_transparent_var = tk.BooleanVar(value=True)
    batch_export_groups_var = tk.BooleanVar(value=True)
    batch_export_layers_var = tk.BooleanVar(value=False)
    batch_export_bottom_to_top_var = tk.BooleanVar(value=False)
    preview_sheet_var = tk.StringVar(value="")
    last_render_report = {}

    def _set_btn_color(btn, hex_value):
        try:
            btn.config(
                bg=hex_value,
                activebackground=hex_value,
                activeforeground=palette["text"],
                relief="flat",
                bd=0,
                highlightthickness=1,
                highlightbackground=palette["border"],
                highlightcolor=palette["accent_alt"],
                cursor="hand2",
                width=4,
            )
        except Exception:
            pass

    def _style_listbox(listbox):
        try:
            listbox.configure(
                bg=palette["input_bg"],
                fg=palette["text"],
                selectbackground=palette["accent"],
                selectforeground=palette["button_text_on_accent"],
                highlightbackground=palette["border"],
                highlightcolor=palette["accent_alt"],
                bd=0,
                relief="flat",
                activestyle="none",
                font=ui_font,
            )
        except Exception:
            pass

    def _make_toggle(parent, text, variable, command=None, width=34):
        btn = tk.Button(parent, relief="flat", bd=0, highlightthickness=1, cursor="hand2", anchor="w", width=width)

        def _refresh(*_args):
            enabled = bool(variable.get())
            btn.configure(
                text=("ON   " if enabled else "OFF  ") + text,
                bg=palette["accent"] if enabled else palette["panel_soft"],
                fg=palette["button_text_on_accent"] if enabled else palette["muted"],
                activebackground=palette["accent_alt"] if enabled else palette["input_bg"],
                activeforeground=palette["button_text_on_accent"] if enabled else palette["text"],
                highlightbackground=palette["accent"] if enabled else palette["border"],
                highlightcolor=palette["accent_alt"],
                padx=14,
                pady=8,
                font=ui_font_semibold,
            )

        def _toggle():
            variable.set(not bool(variable.get()))
            _refresh()
            if command:
                command()

        btn.configure(command=_toggle)
        variable.trace_add("write", _refresh)
        _refresh()
        return btn

    def _make_danger_toggle(parent, text, variable, command=None, width=34):
        btn = tk.Button(parent, relief="flat", bd=0, highlightthickness=1, cursor="hand2", anchor="w", width=width)

        def _refresh(*_args):
            enabled = bool(variable.get())
            btn.configure(
                text=("ON   " if enabled else "OFF  ") + text,
                bg=palette["error"] if enabled else palette["panel_soft"],
                fg=palette["text"] if enabled else palette["muted"],
                activebackground="#DC2626" if enabled else palette["input_bg"],
                activeforeground=palette["text"],
                highlightbackground=palette["error"] if enabled else palette["border"],
                highlightcolor=palette["error"],
                padx=18,
                pady=12,
                font=(ui_font_family, 13, "bold"),
            )

        def _toggle():
            variable.set(not bool(variable.get()))
            _refresh()
            if command:
                command()

        btn.configure(command=_toggle)
        variable.trace_add("write", _refresh)
        _refresh()
        return btn

    def _pick_rgb(title, rgb_list, var, btn):
        color = colorchooser.askcolor(title=title)
        if color[1]:
            var.set(color[1])
            rgb_list[:] = [int(c) for c in color[0]]
            _set_btn_color(btn, color[1])

    def _choose_excel_file():
        path = filedialog.askopenfilename(filetypes=EXCEL_FILETYPES)
        if path:
            excel_var.set(path)
            try:
                _refresh_sheet_list(show_message=False)
                _refresh_rerender_sheet_list(show_message=False)
                _scan_mapping_tokens(show_message=False)
            except Exception:
                pass

    def _choose_icon_folder():
        path = filedialog.askdirectory()
        if path:
            icon_var.set(path)
            try:
                _refresh_mapping_choices()
                _refresh_mapping_tree()
            except Exception:
                pass

    def _clear_path(var):
        var.set("")

    def _choose_bg_file():
        path = filedialog.askopenfilename(filetypes=[("Images", "*.png;*.jpg;*.jpeg")])
        if path:
            bg_var.set(path)

    def _choose_heading_image_folder():
        path = filedialog.askdirectory()
        if path:
            heading_image_folder_var.set(path)

    def _choose_heading_override_image():
        path = filedialog.askopenfilename(filetypes=[("Heading images", "*.png;*.jpg;*.jpeg"), ("All files", "*.*")])
        if path:
            alignment_override_heading_image_var.set(path)

    def _choose_output_dir():
        path = filedialog.askdirectory()
        if path:
            output_dir_var.set(path)

    def _choose_template_folder():
        path = filedialog.askdirectory()
        if path:
            dynamic_template_folder_var.set(path)
            root.after_idle(lambda: _refresh_paytable_json_library(select_active=True))

    def _choose_wild_asset_file():
        path = filedialog.askopenfilename(filetypes=[("Images / PSD", "*.png;*.jpg;*.jpeg;*.psd"), ("All files", "*.*")])
        if path:
            dynamic_wild_asset_var.set(path)

    def _choose_prev_excel_file():
        path = filedialog.askopenfilename(filetypes=EXCEL_FILETYPES)
        if path:
            prev_excel_var.set(path)

    def _refresh_after_psd_settings_load():
        try:
            _refresh_canvas_presets()
            _refresh_sheet_list(show_message=False)
            _refresh_rerender_sheet_list(show_message=False)
            _refresh_alignment_pages(show_message=False)
            _refresh_mapping_choices()
            _scan_mapping_tokens(show_message=False)
            _refresh_mapping_tree()
        except Exception:
            pass
        try:
            style_sidecar_path_var.set(_style_sidecar_default_path())
            if os.path.exists(style_sidecar_path_var.get()):
                _load_styles_sidecar()
        except Exception:
            pass

    def _load_settings_for_existing_psd(psd_path, keep_selected_new_excel=True):
        settings = load_settings_for_psd(psd_path)
        if not settings:
            prev_psd_var.set(psd_path)
            rerender_psd_var.set(psd_path)
            messagebox.showinfo("PSD Settings", "No settings JSON was found next to this PSD yet.")
            return

        selected_new_excel = excel_var.get().strip()
        saved_excel = str(settings.get('excel_path') or '').strip()
        saved_prev_excel = str(settings.get('prev_excel_path') or '').strip()

        _apply_loaded(settings)

        # The browsed PSD is always the update/re-render target, even if the
        # stored settings were saved when a different PSD path was active.
        prev_psd_var.set(psd_path)
        rerender_psd_var.set(psd_path)

        # For Update PSD, Old Excel should be the workbook that produced this
        # PSD. If this sidecar came from an older update, excel_path is still the
        # latest source workbook for the PSD and is safer than prev_excel_path.
        if saved_excel:
            prev_excel_var.set(saved_excel)
        elif saved_prev_excel:
            prev_excel_var.set(saved_prev_excel)

        # If the user already picked the new Excel before browsing the PSD, keep
        # it. Otherwise show the PSD's source Excel in Current Excel too, so the
        # full saved project context is visible and ready to edit.
        if keep_selected_new_excel and selected_new_excel and selected_new_excel != saved_excel:
            excel_var.set(selected_new_excel)
        elif saved_excel:
            excel_var.set(saved_excel)

        if not output_dir_var.get().strip():
            output_dir_var.set(os.path.dirname(os.path.abspath(psd_path)))

        _refresh_after_psd_settings_load()
        messagebox.showinfo(
            "PSD Settings",
            "Loaded the PSD settings JSON: Excel paths, icon/background paths, fonts, colors, sizes, layer styles, mappings, and custom layout JSON settings.",
        )

    def _choose_existing_psd():
        path = filedialog.askopenfilename(filetypes=[("Photoshop", "*.psd;*.psb")])
        if path:
            prev_psd_var.set(path)
            rerender_psd_var.set(path)
            _load_settings_for_existing_psd(path)

    def _canvas_preset_values():
        return list(CANVAS_PRESETS.keys()) + sorted(custom_canvas_presets.keys())

    def _refresh_canvas_presets():
        try:
            canvas_preset_cb['values'] = _canvas_preset_values()
        except Exception:
            pass

    def _apply_canvas_preset(event=None):
        name = canvas_preset_var.get()
        size = CANVAS_PRESETS.get(name) or custom_canvas_presets.get(name)
        if not size:
            return
        c_w_spin.set(int(size[0]))
        c_h_spin.set(int(size[1]))

    def _save_custom_canvas_preset():
        try:
            width = int(c_w_spin.get())
            height = int(c_h_spin.get())
        except Exception:
            messagebox.showerror("Canvas Preset", "Canvas width and height must be numbers.")
            return
        name = simpledialog.askstring("Custom Canvas Preset", "Preset name:")
        if not name:
            return
        name = name.strip()
        if not name:
            return
        custom_canvas_presets[name] = [width, height]
        canvas_preset_var.set(name)
        _refresh_canvas_presets()

    def _validate_update_source():
        manifest = load_manifest(prev_psd_var.get())
        if not manifest:
            return messagebox.askyesno(
                "No PSD Manifest",
                "No .pshelpscreen manifest was found next to the PSD. The tool can still compare Old Excel to New Excel, but it cannot fully prove the PSD came from the Old Excel. Continue?"
            )
        try:
            old_hashes = workbook_hashes(prev_excel_var.get(), int(max_col_spin.get()))
        except Exception as exc:
            messagebox.showerror("Update PSD", f"Could not read the Old Excel file:\n{exc}")
            return False
        manifest_sheets = manifest.get('sheets', {}) or {}
        def _norm_sheet_name(value):
            return " ".join(str(value or "").strip().split()).casefold()

        manifest_by_norm = {_norm_sheet_name(name): (name, info) for name, info in manifest_sheets.items()}
        common = []
        for old_name in old_hashes.keys():
            matched = manifest_by_norm.get(_norm_sheet_name(old_name))
            if matched:
                common.append((old_name, matched[0], matched[1]))
        if not common:
            old_tabs = ", ".join(list(old_hashes.keys())[:8])
            manifest_tabs = ", ".join(list(manifest_sheets.keys())[:8])
            return messagebox.askyesno(
                "Update PSD",
                "The Old Excel tab names do not exactly match the PSD manifest tab names after normalization.\n\n"
                f"Old Excel tabs: {old_tabs}\nPSD manifest tabs: {manifest_tabs}\n\n"
                "Continue anyway and compare Old Excel to New Excel?"
            )
        mismatched = [old_name for old_name, _manifest_name, info in common if (info or {}).get('hash') != old_hashes.get(old_name)]
        if mismatched:
            shown = ", ".join(mismatched[:8])
            if len(mismatched) > 8:
                shown += ", ..."
            return messagebox.askyesno(
                "Update PSD",
                f"The Old Excel content hash does not match the selected PSD manifest for:\n{shown}\n\n"
                "This can happen if the PSD was saved from another copy or the manifest was stale. "
                "Continue anyway and use Old Excel vs New Excel comparison?"
            )
        return True

    active_scroll_canvas = {"canvas": None}

    def _bind_scroll_canvas(canvas):
        active_scroll_canvas["canvas"] = canvas

    def _unbind_scroll_canvas(canvas):
        if active_scroll_canvas.get("canvas") is canvas:
            active_scroll_canvas["canvas"] = None

    def _on_global_mousewheel(event):
        canvas = active_scroll_canvas.get("canvas")
        if canvas is None:
            return
        try:
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        except Exception:
            pass

    root.bind_all("<MouseWheel>", _on_global_mousewheel)

    def _make_scrollable_host(parent, bg_color=None, show_scrollbar=True):
        bg_color = bg_color or palette["app_bg"]
        outer = ttk.Frame(parent, style="Panel.TFrame")
        canvas = tk.Canvas(outer, bg=bg_color, highlightthickness=0, bd=0, relief="flat")
        scroll = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=scroll.set if show_scrollbar else None)
        content = ttk.Frame(canvas)
        content_window = canvas.create_window((0, 0), window=content, anchor="nw")

        def _resize_content(event):
            canvas.itemconfigure(content_window, width=event.width)

        def _refresh_scroll(_event=None):
            try:
                canvas.configure(scrollregion=canvas.bbox("all"))
            except Exception:
                pass

        canvas.bind("<Configure>", _resize_content)
        content.bind("<Configure>", _refresh_scroll)
        for widget in (outer, canvas, content):
            widget.bind("<Enter>", lambda _event, c=canvas: _bind_scroll_canvas(c))
            widget.bind("<Leave>", lambda _event, c=canvas: _unbind_scroll_canvas(c))

        canvas.pack(side="left", fill="both", expand=True)
        if show_scrollbar:
            scroll.pack(side="right", fill="y")
        return outer, content


    launcher_frame = ttk.Frame(root)
    launcher_frame.pack(fill="both", expand=True, padx=24, pady=24)
    launcher_frame.columnconfigure(0, weight=1)
    launcher_card = ttk.Frame(launcher_frame, style="Card.TFrame", padding=32)
    launcher_card.grid(row=0, column=0, sticky="n", pady=(56, 0))
    launcher_card.columnconfigure(0, weight=1)
    ttk.Label(launcher_card, text="PsHelpScreenTool", style="Title.TLabel").grid(row=0, column=0, sticky="w")
    ttk.Label(
        launcher_card,
        text="Choose a workflow to keep the interface focused. Each mode only shows the tabs that matter for that task.",
        style="CardMuted.TLabel",
        wraplength=760,
    ).grid(row=1, column=0, sticky="w", pady=(8, 20))
    ttk.Button(launcher_card, text="Create Help Screen PSD", style="Launcher.TButton", command=lambda: _select_nav_target("files")).grid(row=2, column=0, sticky="ew", pady=6)
    ttk.Button(launcher_card, text="Update Help Screens", style="Launcher.TButton", command=lambda: _select_mode("update")).grid(row=3, column=0, sticky="ew", pady=6)
    ttk.Button(launcher_card, text="Export JSON of Custom Layout", style="Launcher.TButton", command=lambda: _select_mode("export")).grid(row=4, column=0, sticky="ew", pady=6)

    main_shell = ttk.Frame(root)
    sidebar_frame = ttk.Frame(main_shell, style="Sidebar.TFrame", width=220)
    sidebar_frame.pack(side="left", fill="y")
    sidebar_frame.pack_propagate(False)
    content_shell = ttk.Frame(main_shell)
    content_shell.pack(side="left", fill="both", expand=True)

    sidebar_canvas = tk.Canvas(sidebar_frame, bg=palette["sidebar_bg"], highlightthickness=0, bd=0, relief="flat")
    sidebar_scroll = ttk.Scrollbar(sidebar_frame, orient="vertical", command=sidebar_canvas.yview)
    sidebar_canvas.configure(yscrollcommand=sidebar_scroll.set)
    sidebar_inner = ttk.Frame(sidebar_frame, style="Sidebar.TFrame", padding=(18, 22))
    sidebar_window = sidebar_canvas.create_window((0, 0), window=sidebar_inner, anchor="nw")
    sidebar_canvas.pack(side="left", fill="both", expand=True)
    sidebar_scroll.pack(side="right", fill="y")

    def _resize_sidebar_content(event):
        try:
            sidebar_canvas.itemconfigure(sidebar_window, width=event.width)
        except Exception:
            pass

    def _refresh_sidebar_scroll(_event=None):
        try:
            sidebar_canvas.configure(scrollregion=sidebar_canvas.bbox("all"))
        except Exception:
            pass

    def _enable_sidebar_scroll(widget):
        try:
            widget.bind("<Enter>", lambda _event, c=sidebar_canvas: _bind_scroll_canvas(c), add="+")
            widget.bind("<Leave>", lambda _event, c=sidebar_canvas: _unbind_scroll_canvas(c), add="+")
        except Exception:
            pass

    sidebar_canvas.bind("<Configure>", _resize_sidebar_content)
    sidebar_inner.bind("<Configure>", _refresh_sidebar_scroll)
    for sidebar_widget in (sidebar_frame, sidebar_canvas, sidebar_inner):
        _enable_sidebar_scroll(sidebar_widget)
    sidebar_inner.columnconfigure(0, weight=1)
    sidebar_title_label = ttk.Label(sidebar_inner, text="PsHelpScreenTool", style="SidebarTitle.TLabel")
    sidebar_title_label.grid(row=0, column=0, sticky="w")
    _enable_sidebar_scroll(sidebar_title_label)
    sidebar_mode_var = tk.StringVar(value="Create Help Screen PSD")
    sidebar_mode_label = ttk.Label(sidebar_inner, textvariable=sidebar_mode_var, style="SidebarCaption.TLabel", wraplength=160)
    sidebar_mode_label.grid(row=1, column=0, sticky="w", pady=(6, 18))
    _enable_sidebar_scroll(sidebar_mode_label)

    mode_switch_frame = ttk.Frame(sidebar_inner, style="Sidebar.TFrame")
    mode_switch_frame.grid(row=2, column=0, sticky="ew")
    _enable_sidebar_scroll(mode_switch_frame)
    nav_button_frame = ttk.Frame(sidebar_inner, style="Sidebar.TFrame")
    nav_button_frame.grid(row=3, column=0, sticky="nsew", pady=(18, 12))
    _enable_sidebar_scroll(nav_button_frame)
    sidebar_inner.rowconfigure(3, weight=1)
    sidebar_footer_label = ttk.Label(sidebar_inner, text="Sunflower utility UI. Rendering logic stays untouched.", style="SidebarCaption.TLabel", wraplength=160)
    sidebar_footer_label.grid(row=4, column=0, sticky="sw", pady=(10, 0))
    _enable_sidebar_scroll(sidebar_footer_label)

    content_header = ttk.Frame(content_shell, padding=(18, 18, 18, 8))
    content_header.pack(fill="x")
    content_header.columnconfigure(0, weight=1)
    section_title_var = tk.StringVar(value="Project")
    section_subtitle_var = tk.StringVar(value="Configure files, typography, icons, layouts, and build behavior.")
    ttk.Label(content_header, textvariable=section_title_var, style="Title.TLabel").grid(row=0, column=0, sticky="w")
    ttk.Label(content_header, textvariable=section_subtitle_var, style="Muted.TLabel", wraplength=920).grid(row=1, column=0, sticky="w", pady=(6, 0))

    content_body = ttk.Frame(content_shell, padding=(12, 0, 12, 12))
    content_body.pack(fill="both", expand=True)
    notebook = ttk.Notebook(content_body, style="Content.TNotebook")
    notebook.pack(fill="both", expand=True)
    tab_dashboard_tab = ttk.Frame(notebook)
    tab_project = ttk.Frame(notebook)
    tab_text = ttk.Frame(notebook)
    tab_alignment_tab = ttk.Frame(notebook)
    tab_layer_styles_tab = ttk.Frame(notebook)
    tab_table_tab = ttk.Frame(notebook)
    tab_table_json_tab = ttk.Frame(notebook)
    tab_png_builder_tab = ttk.Frame(notebook)
    tab_icons = ttk.Frame(notebook)
    tab_dynamic = ttk.Frame(notebook)
    tab_build_tab = ttk.Frame(notebook)
    tab_update_tab = ttk.Frame(notebook)
    tab_rerender_tab = ttk.Frame(notebook)
    tab_custom_tab = ttk.Frame(notebook)
    tab_report_tab = ttk.Frame(notebook)
    tab_missing_icons_tab = ttk.Frame(notebook)
    tab_presets_tab = ttk.Frame(notebook)
    tab_preview_tab = ttk.Frame(notebook)
    tab_export_tab = ttk.Frame(notebook)
    tab_safety_tab = ttk.Frame(notebook)
    tab_guide_tab = ttk.Frame(notebook)

    _dashboard_scroll_host, tab_dashboard = _make_scrollable_host(tab_dashboard_tab, palette["app_bg"], show_scrollbar=False)
    _dashboard_scroll_host.pack(fill="both", expand=True)
    _alignment_scroll_host, tab_alignment = _make_scrollable_host(tab_alignment_tab, palette["app_bg"])
    _alignment_scroll_host.pack(fill="both", expand=True)
    _layer_styles_scroll_host, tab_layer_styles = _make_scrollable_host(tab_layer_styles_tab, palette["app_bg"])
    _layer_styles_scroll_host.pack(fill="both", expand=True)
    _table_scroll_host, tab_table = _make_scrollable_host(tab_table_tab, palette["app_bg"])
    _table_scroll_host.pack(fill="both", expand=True)
    _table_json_scroll_host, tab_table_json = _make_scrollable_host(tab_table_json_tab, palette["app_bg"])
    _table_json_scroll_host.pack(fill="both", expand=True)

    _png_scroll_host, tab_png_builder = _make_scrollable_host(tab_png_builder_tab, palette["app_bg"])
    _png_scroll_host.pack(fill="both", expand=True)
    _build_scroll_host, tab_build = _make_scrollable_host(tab_build_tab, palette["app_bg"])
    _build_scroll_host.pack(fill="both", expand=True)
    _update_scroll_host, tab_update = _make_scrollable_host(tab_update_tab, palette["app_bg"])
    _update_scroll_host.pack(fill="both", expand=True)
    _rerender_scroll_host, tab_rerender = _make_scrollable_host(tab_rerender_tab, palette["app_bg"])
    _rerender_scroll_host.pack(fill="both", expand=True)
    _custom_scroll_host, tab_custom = _make_scrollable_host(tab_custom_tab, palette["app_bg"])
    _custom_scroll_host.pack(fill="both", expand=True)
    _report_scroll_host, tab_report = _make_scrollable_host(tab_report_tab, palette["app_bg"])
    _report_scroll_host.pack(fill="both", expand=True)
    _missing_icons_scroll_host, tab_missing_icons = _make_scrollable_host(tab_missing_icons_tab, palette["app_bg"])
    _missing_icons_scroll_host.pack(fill="both", expand=True)
    _presets_scroll_host, tab_presets = _make_scrollable_host(tab_presets_tab, palette["app_bg"])
    _presets_scroll_host.pack(fill="both", expand=True)
    _preview_scroll_host, tab_preview = _make_scrollable_host(tab_preview_tab, palette["app_bg"])
    _preview_scroll_host.pack(fill="both", expand=True)
    _safety_scroll_host, tab_safety = _make_scrollable_host(tab_safety_tab, palette["app_bg"])
    _safety_scroll_host.pack(fill="both", expand=True)
    _guide_scroll_host, tab_guide = _make_scrollable_host(tab_guide_tab, palette["app_bg"])
    _guide_scroll_host.pack(fill="both", expand=True)

    project_nb = ttk.Notebook(tab_project)
    project_nb.pack(fill="both", expand=True, padx=10, pady=10)
    text_nb = ttk.Notebook(tab_text)
    text_nb.pack(fill="both", expand=True, padx=10, pady=10)
    icons_nb = ttk.Notebook(tab_icons)
    icons_nb.pack(fill="both", expand=True, padx=10, pady=10)
    dynamic_nb = ttk.Notebook(tab_dynamic)
    dynamic_nb.pack(fill="both", expand=True, padx=10, pady=10)

    # Dashboard is GUI-only: quick navigation into the existing workflows.
    dash_intro = ttk.LabelFrame(tab_dashboard, text="Dashboard")
    dash_intro.pack(fill="x", padx=10, pady=(10, 12))
    ttk.Label(
        dash_intro,
        text="PsHelpScreenTool is ready. Pick a workflow or jump directly to the settings section you need.",
        style="CardMuted.TLabel",
        wraplength=920,
    ).grid(row=0, column=0, columnspan=4, sticky="w", padx=14, pady=(14, 10))
    ttk.Button(dash_intro, text="Create New PSD", command=lambda: _select_nav_target("files"), style="Primary.TButton").grid(row=1, column=0, sticky="ew", padx=(14, 8), pady=(0, 14))
    ttk.Button(dash_intro, text="Update PSD", command=lambda: _select_nav_target("update"), style="Warning.TButton").grid(row=1, column=1, sticky="ew", padx=8, pady=(0, 14))
    ttk.Button(dash_intro, text="Re-render Pages", command=lambda: _select_nav_target("rerender"), style="Warning.TButton").grid(row=1, column=2, sticky="ew", padx=8, pady=(0, 14))
    ttk.Button(dash_intro, text="Export JSON", command=lambda: _select_nav_target("export"), style="Secondary.TButton").grid(row=1, column=3, sticky="ew", padx=(8, 14), pady=(0, 14))
    for _col in range(4):
        dash_intro.columnconfigure(_col, weight=1)

    dash_setup = ttk.LabelFrame(tab_dashboard, text="Build Setup")
    dash_setup.pack(fill="x", padx=10, pady=(0, 12))
    dash_items = [
        ("Files & Canvas", "files"),
        ("Text Styles", "text"),
        ("Tables", "tables"),
        ("Paytable / Custom Layouts", "paytable"),
        ("Icons & Mapping", "icons"),
        ("Settings", "settings"),
    ]
    for idx, (label, key) in enumerate(dash_items):
        ttk.Button(dash_setup, text=label, command=lambda k=key: _select_nav_target(k), style="Secondary.TButton").grid(row=idx // 4, column=idx % 4, sticky="ew", padx=10, pady=8)
    sep = ttk.Separator(dash_setup, orient="horizontal")
    sep.grid(row=2, column=0, columnspan=4, sticky="ew", padx=10, pady=6)
    ttk.Button(dash_setup, text="Build PNGs Only", command=lambda: _run_png_build(), style="Primary.TButton").grid(row=3, column=0, sticky="ew", padx=10, pady=8)
    ttk.Button(dash_setup, text="Open Batch Export", command=lambda: _show_dashboard_batch_export(), style="Primary.TButton").grid(row=3, column=1, sticky="ew", padx=10, pady=8)
    for _col in range(4):
        dash_setup.columnconfigure(_col, weight=1)

    dashboard_tools = ttk.LabelFrame(tab_dashboard, text="Dashboard Tools")
    dashboard_tools.pack(fill="x", padx=10, pady=(0, 12))
    ttk.Label(
        dashboard_tools,
        text="Open focused production tools only when you need them.",
        style="CardMuted.TLabel",
        wraplength=820,
    ).grid(row=0, column=0, sticky="w", padx=14, pady=(12, 10))
    ttk.Button(dashboard_tools, text="Open Batch Export", command=lambda: _show_dashboard_batch_export(), style="Primary.TButton").grid(row=0, column=1, sticky="e", padx=14, pady=(12, 10))
    _make_danger_toggle(
        dashboard_tools,
        "Performance Mode",
        performance_mode_var,
        width=28,
    ).grid(row=1, column=0, sticky="w", padx=14, pady=(0, 8))
    ttk.Button(
        dashboard_tools,
        text="Performance Report",
        command=lambda: _show_performance_mode_report(),
        style="Secondary.TButton",
    ).grid(row=1, column=1, sticky="e", padx=14, pady=(0, 8))
    ttk.Label(
        dashboard_tools,
        text="Experimental speed path: copies same-layout, low-difference page bundles and patches safe changed cells. JSON/paytable/custom pages fall back to normal rendering.",
        style="CardMuted.TLabel",
        wraplength=900,
    ).grid(row=2, column=0, columnspan=2, sticky="w", padx=14, pady=(0, 12))
    dashboard_tools.columnconfigure(0, weight=1)

    dashboard_export_nb = ttk.Notebook(tab_dashboard)
    tab_dashboard_export = ttk.Frame(dashboard_export_nb)
    dashboard_export_nb.add(tab_dashboard_export, text="Batch Export")

    # Project / files
    tab_files_tab = ttk.Frame(project_nb)
    project_nb.add(tab_files_tab, text="Files & Canvas")
    _files_scroll_host, tab_files = _make_scrollable_host(tab_files_tab, palette["app_bg"])
    _files_scroll_host.pack(fill="both", expand=True)

    for _col in range(4):
        tab_files.columnconfigure(_col, weight=0)
    tab_files.columnconfigure(1, weight=1)

    ttk.Label(tab_files, text="Current Excel", style="FieldLabel.TLabel").grid(row=0, column=0, sticky="w", pady=(10, 2), padx=10)
    ttk.Entry(tab_files, textvariable=excel_var, state="readonly", width=58).grid(row=0, column=1, sticky="ew", padx=5, pady=(10, 2))
    ttk.Button(tab_files, text="Browse", command=_choose_excel_file).grid(row=0, column=2, padx=(0, 4), pady=(10, 2))
    ttk.Button(tab_files, text="Remove", command=lambda: _clear_path(excel_var)).grid(row=0, column=3, pady=(10, 2), padx=(0, 10))

    ttk.Label(tab_files, text="Icons Folder", style="FieldLabel.TLabel").grid(row=1, column=0, sticky="w", pady=2, padx=10)
    ttk.Entry(tab_files, textvariable=icon_var, state="readonly", width=58).grid(row=1, column=1, sticky="ew", padx=5, pady=2)
    ttk.Button(tab_files, text="Browse", command=_choose_icon_folder).grid(row=1, column=2, padx=(0, 4), pady=2)
    ttk.Button(tab_files, text="Remove", command=lambda: _clear_path(icon_var)).grid(row=1, column=3, pady=2, padx=(0, 10))

    ttk.Label(tab_files, text="Background", style="FieldLabel.TLabel").grid(row=2, column=0, sticky="w", pady=2, padx=10)
    ttk.Entry(tab_files, textvariable=bg_var, state="readonly", width=58).grid(row=2, column=1, sticky="ew", padx=5, pady=2)
    ttk.Button(tab_files, text="Browse", command=_choose_bg_file).grid(row=2, column=2, padx=(0, 4), pady=2)
    ttk.Button(tab_files, text="Remove", command=lambda: _clear_path(bg_var)).grid(row=2, column=3, pady=2, padx=(0, 10))

    ttk.Label(tab_files, text="PSD Save Folder", style="FieldLabel.TLabel").grid(row=3, column=0, sticky="w", pady=2, padx=10)
    ttk.Entry(tab_files, textvariable=output_dir_var, state="readonly", width=58).grid(row=3, column=1, sticky="ew", padx=5, pady=2)
    ttk.Button(tab_files, text="Browse", command=_choose_output_dir).grid(row=3, column=2, padx=(0, 4), pady=2)
    ttk.Button(tab_files, text="Remove", command=lambda: _clear_path(output_dir_var)).grid(row=3, column=3, pady=2, padx=(0, 10))
    ttk.Label(tab_files, text="Generated PSD/PSB is saved in this folder. Blank = Excel folder.", foreground="gray").grid(row=4, column=1, columnspan=3, sticky="w")

    ttk.Label(tab_files, text="PSD File Name", style="FieldLabel.TLabel").grid(row=5, column=0, sticky="w", pady=(10, 2), padx=10)
    name_frame = ttk.Frame(tab_files)
    name_frame.grid(row=5, column=1, columnspan=3, sticky="w", padx=5, pady=(10, 2))
    ttk.Entry(name_frame, textvariable=output_name_var, width=34).grid(row=0, column=0, padx=(0, 12))
    ttk.Radiobutton(name_frame, text="PSD", variable=output_format_var, value="PSD").grid(row=0, column=1, padx=(0, 8))
    ttk.Radiobutton(name_frame, text="PSB", variable=output_format_var, value="PSB").grid(row=0, column=2)
    ttk.Label(tab_files, text="Blank name keeps timestamped naming. Previous Excel is only used inside Update Help Screens.", foreground="gray").grid(row=6, column=1, columnspan=3, sticky="w")

    ttk.Label(tab_files, text="BG Mode:", style="FieldLabel.TLabel").grid(row=7, column=0, sticky="w", pady=(10, 2), padx=10)
    ttk.Radiobutton(tab_files, text="Stretch to Fill Canvas", variable=bg_mode_var, value="stretch").grid(row=7, column=1, sticky="w")
    ttk.Radiobutton(tab_files, text="Center As-Is", variable=bg_mode_var, value="center").grid(row=8, column=1, sticky="w")

    cf = ttk.Frame(tab_files)
    cf.grid(row=9, column=0, columnspan=4, pady=15, sticky="w", padx=10)
    ttk.Label(cf, text="Canvas Preset:").grid(row=0, column=0, padx=(0, 5))
    canvas_preset_cb = ttk.Combobox(cf, textvariable=canvas_preset_var, values=_canvas_preset_values(), width=18, state="readonly")
    canvas_preset_cb.grid(row=0, column=1, padx=(0, 8))
    canvas_preset_cb.bind("<<ComboboxSelected>>", _apply_canvas_preset)
    ttk.Button(cf, text="Save Custom", command=_save_custom_canvas_preset).grid(row=0, column=2, padx=(0, 18))
    ttk.Label(cf, text="Width:").grid(row=0, column=3, padx=(0, 5))
    c_w_spin = ttk.Spinbox(cf, from_=500, to=12000, width=7); c_w_spin.set(1920); c_w_spin.grid(row=0, column=4, padx=(0, 12))
    ttk.Label(cf, text="Height:").grid(row=0, column=5, padx=(0, 5))
    c_h_spin = ttk.Spinbox(cf, from_=500, to=12000, width=7); c_h_spin.set(1080); c_h_spin.grid(row=0, column=6, padx=(0, 12))
    ttk.Label(cf, text="Max Excel Col:").grid(row=0, column=7, padx=(0, 5))
    max_col_spin = ttk.Spinbox(cf, from_=1, to=100, width=5); max_col_spin.set(10); max_col_spin.grid(row=0, column=8)

    def _selected_sheet_names():
        if sheet_listbox is None:
            return []
        return [sheet_listbox.get(i) for i in sheet_listbox.curselection()]

    def _apply_selected_sheet_names(names):
        if sheet_listbox is None:
            return
        wanted = {str(name) for name in (names or [])}
        sheet_listbox.selection_clear(0, tk.END)
        for idx in range(sheet_listbox.size()):
            if sheet_listbox.get(idx) in wanted:
                sheet_listbox.selection_set(idx)

    def _refresh_sheet_list(show_message=True):
        if sheet_listbox is None:
            return
        remembered = _selected_sheet_names()
        sheet_listbox.delete(0, tk.END)
        excel_path = excel_var.get().strip()
        if not excel_path or not os.path.exists(excel_path):
            return
        try:
            wb_preview = load_workbook(excel_path, read_only=True, data_only=True)
            names = list(wb_preview.sheetnames)
            try:
                wb_preview.close()
            except Exception:
                pass
        except Exception as exc:
            if show_message:
                messagebox.showwarning("Page Selection", f"Could not load Excel tabs:\n{exc}")
            return
        for name in names:
            sheet_listbox.insert(tk.END, name)
        _apply_selected_sheet_names(remembered)

    def _select_all_sheets():
        if sheet_listbox is None:
            return
        sheet_listbox.selection_set(0, tk.END)

    def _clear_selected_sheets():
        if sheet_listbox is None:
            return
        sheet_listbox.selection_clear(0, tk.END)

    def _selected_rerender_sheet_names():
        if rerender_listbox is None:
            return []
        return [rerender_listbox.get(i) for i in rerender_listbox.curselection()]

    def _refresh_rerender_sheet_list(show_message=True):
        if rerender_listbox is None:
            return
        remembered = _selected_rerender_sheet_names()
        rerender_listbox.delete(0, tk.END)
        excel_path = excel_var.get().strip()
        if not excel_path or not os.path.exists(excel_path):
            return
        try:
            wb_preview = load_workbook(excel_path, read_only=True, data_only=True)
            names = list(wb_preview.sheetnames)
            try:
                wb_preview.close()
            except Exception:
                pass
        except Exception as exc:
            if show_message:
                messagebox.showwarning("Re-render", f"Could not load Excel tabs:\n{exc}")
            return
        wanted = {str(name) for name in remembered}
        for name in names:
            rerender_listbox.insert(tk.END, name)
        for idx in range(rerender_listbox.size()):
            if rerender_listbox.get(idx) in wanted:
                rerender_listbox.selection_set(idx)

    def _select_all_rerender_sheets():
        if rerender_listbox is not None:
            rerender_listbox.selection_set(0, tk.END)

    def _clear_rerender_sheets():
        if rerender_listbox is not None:
            rerender_listbox.selection_clear(0, tk.END)

    # Dedicated Page Selection tab. This list drives partial builds/updates only. Re-render has its own list.
    tab_page_select = ttk.Frame(project_nb)
    project_nb.add(tab_page_select, text="Page Selection")
    page_select_frame = ttk.LabelFrame(tab_page_select, text="Page Selection")
    page_select_frame.pack(fill="both", expand=True, padx=10, pady=10)
    _make_toggle(
        page_select_frame,
        "Render only selected Excel tabs",
        render_selected_pages_var,
        width=36,
    ).grid(row=0, column=0, columnspan=4, sticky="w", padx=10, pady=(10, 4))
    ttk.Label(
        page_select_frame,
        text="Use this for partial builds and targeted re-renders. In Update PSD mode, selected tabs are the only PSD groups that get deleted and rebuilt.",
        foreground="gray",
        wraplength=760,
    ).grid(row=1, column=0, columnspan=4, sticky="w", padx=10, pady=(0, 8))
    ttk.Button(page_select_frame, text="Refresh Tabs", command=_refresh_sheet_list).grid(row=2, column=0, sticky="w", padx=10, pady=(0, 8))
    ttk.Button(page_select_frame, text="Select All", command=_select_all_sheets).grid(row=2, column=1, sticky="w", padx=(0, 8), pady=(0, 8))
    ttk.Button(page_select_frame, text="Clear", command=_clear_selected_sheets).grid(row=2, column=2, sticky="w", pady=(0, 8))
    sheet_listbox = tk.Listbox(page_select_frame, selectmode=tk.MULTIPLE, exportselection=False, height=18)
    sheet_listbox.grid(row=3, column=0, columnspan=3, sticky="nsew", padx=10, pady=(0, 10))
    sheet_scroll = ttk.Scrollbar(page_select_frame, orient="vertical", command=sheet_listbox.yview)
    sheet_scroll.grid(row=3, column=3, sticky="ns", pady=(0, 10), padx=(0, 10))
    sheet_listbox.configure(yscrollcommand=sheet_scroll.set)
    _style_listbox(sheet_listbox)
    page_column_frame = ttk.LabelFrame(page_select_frame, text="Per-Page Render Columns")
    page_column_frame.grid(row=4, column=0, columnspan=4, sticky="ew", padx=10, pady=(0, 10))
    page_column_frame.columnconfigure(0, weight=1)
    page_render_column_overrides_text = tk.Text(
        page_column_frame,
        height=3,
        wrap="word",
        bg=palette["input_bg"],
        fg=palette["text"],
        insertbackground=palette["text"],
        relief="solid",
        bd=1,
        highlightthickness=0,
    )
    page_render_columns_scroll = ttk.Scrollbar(page_column_frame, orient="vertical", command=page_render_column_overrides_text.yview)
    page_render_column_overrides_text.configure(yscrollcommand=page_render_columns_scroll.set)
    page_render_column_overrides_text.grid(row=0, column=0, sticky="ew", padx=(10, 0), pady=(10, 4))
    page_render_columns_scroll.grid(row=0, column=1, sticky="ns", padx=(0, 10), pady=(10, 4))
    ttk.Label(
        page_column_frame,
        text="Optional. Overrides the global Max Excel Col per sheet. Examples: GameRules=8, BBB(4)=B:H, Paytable=2-9.",
        foreground="gray",
        wraplength=840,
    ).grid(row=1, column=0, columnspan=2, sticky="w", padx=10, pady=(0, 8))
    page_select_frame.columnconfigure(0, weight=1)
    page_select_frame.rowconfigure(3, weight=1)
    tab_page_select.rowconfigure(0, weight=1)
    tab_page_select.columnconfigure(0, weight=1)

    # Page Alignment Overrides
    alignment_page_cb = None

    def _spinbox_int(widget, fallback=0):
        try:
            return int(float(widget.get()))
        except Exception:
            return int(fallback or 0)

    def _alignment_defaults_config():
        try:
            heading_left_margin = _spinbox_int(heading_left_margin_spin, 80)
        except Exception:
            heading_left_margin = 80
        try:
            body_left_margin = _spinbox_int(body_left_margin_spin, 80)
        except Exception:
            body_left_margin = 80
        return {
            "heading": heading_alignment_var.get(),
            "body": body_alignment_var.get(),
            "table": table_alignment_var.get(),
            "bottom": bottom_alignment_var.get(),
            "paytable_notes": paytable_notes_alignment_var.get(),
            "heading_left_margin": heading_left_margin,
            "body_left_margin": body_left_margin,
        }

    def _alignment_source_key():
        selected = alignment_source_var.get().strip().casefold()
        if "excel" in selected:
            return "excel"
        if "override" in selected:
            return "page_override"
        return "tool"

    def _alignment_settings_config():
        return {
            "source": _alignment_source_key(),
            "global": _alignment_defaults_config(),
            "overrides": dict(page_alignment_overrides),
            "heading_image_folder": heading_image_folder_var.get().strip(),
            "heading_image_height": _spinbox_int(heading_image_height_spin, 0),
        }

    def _refresh_alignment_pages(show_message=False):
        nonlocal alignment_page_cb
        excel_path = excel_var.get().strip()
        names = []
        if excel_path and os.path.exists(excel_path):
            try:
                wb_preview = load_workbook(excel_path, read_only=True, data_only=True)
                names = list(wb_preview.sheetnames)
                try:
                    wb_preview.close()
                except Exception:
                    pass
            except Exception as exc:
                if show_message:
                    messagebox.showwarning("Page Alignment", f"Could not load Excel tabs:\n{exc}")
        if alignment_page_cb is not None:
            alignment_page_cb["values"] = names
        if names and alignment_page_var.get() not in names:
            alignment_page_var.set(names[0])
            _load_alignment_override()

    def _load_alignment_override(_event=None):
        page_name = alignment_page_var.get().strip()
        cfg = dict(page_alignment_overrides.get(page_name) or {})
        alignment_use_global_var.set(bool(cfg.get("use_global", True)))
        alignment_override_heading_var.set(cfg.get("heading", heading_alignment_var.get()))
        alignment_override_body_var.set(cfg.get("body", body_alignment_var.get()))
        alignment_override_table_var.set(cfg.get("table", table_alignment_var.get()))
        alignment_override_bottom_var.set(cfg.get("bottom", bottom_alignment_var.get()))
        alignment_override_paytable_var.set(cfg.get("paytable_notes", paytable_notes_alignment_var.get()))
        alignment_override_heading_image_var.set(cfg.get("heading_image_path", ""))
        try:
            alignment_override_heading_left_margin_spin.set(cfg.get("heading_left_margin", _spinbox_int(heading_left_margin_spin, 80)))
            alignment_override_body_left_margin_spin.set(cfg.get("body_left_margin", _spinbox_int(body_left_margin_spin, 80)))
        except Exception:
            pass

    def _save_alignment_override():
        page_name = alignment_page_var.get().strip()
        if not page_name:
            messagebox.showwarning("Page Alignment", "Select an Excel tab first.")
            return
        page_alignment_overrides[page_name] = {
            "use_global": alignment_use_global_var.get(),
            "heading": alignment_override_heading_var.get(),
            "body": alignment_override_body_var.get(),
            "table": alignment_override_table_var.get(),
            "bottom": alignment_override_bottom_var.get(),
            "paytable_notes": alignment_override_paytable_var.get(),
            "heading_left_margin": _spinbox_int(alignment_override_heading_left_margin_spin, _spinbox_int(heading_left_margin_spin, 80)),
            "body_left_margin": _spinbox_int(alignment_override_body_left_margin_spin, _spinbox_int(body_left_margin_spin, 80)),
            "heading_image_path": alignment_override_heading_image_var.get().strip(),
        }
        _save_current_session()
        messagebox.showinfo("Page Alignment", f"Alignment override saved for {page_name}.")

    def _clear_alignment_override():
        page_name = alignment_page_var.get().strip()
        if page_name in page_alignment_overrides:
            del page_alignment_overrides[page_name]
        _load_alignment_override()
        _save_current_session()

    alignment_global_frame = ttk.LabelFrame(tab_alignment, text="Global Alignment Defaults")
    alignment_global_frame.pack(fill="x", padx=10, pady=(10, 8))
    ttk.Label(alignment_global_frame, text="Alignment source:").grid(row=0, column=0, sticky="w", padx=10, pady=(12, 6))
    ttk.Combobox(
        alignment_global_frame,
        textvariable=alignment_source_var,
        values=["Use tool alignment", "Use Excel alignment", "Use page override if available, else global"],
        width=38,
        state="readonly",
    ).grid(row=0, column=1, sticky="w", padx=5, pady=(12, 6))
    global_align_specs = [
        ("Heading", heading_alignment_var, ALIGN_CHOICES),
        ("Body", body_alignment_var, BODY_ALIGN_CHOICES),
        ("Table text", table_alignment_var, ALIGN_CHOICES),
        ("Bottom / legal", bottom_alignment_var, ALIGN_CHOICES),
        ("Paytable notes", paytable_notes_alignment_var, ALIGN_CHOICES),
    ]
    ttk.Label(alignment_global_frame, text="Left margin px:").grid(row=0, column=2, sticky="w", padx=(22, 5), pady=(12, 6))
    heading_left_margin_spin = ttk.Spinbox(alignment_global_frame, from_=0, to=3000, width=8)
    heading_left_margin_spin.set(80)
    body_left_margin_spin = ttk.Spinbox(alignment_global_frame, from_=0, to=3000, width=8)
    body_left_margin_spin.set(80)
    for idx, (label, variable, choices) in enumerate(global_align_specs, start=1):
        ttk.Label(alignment_global_frame, text=f"{label}:").grid(row=idx, column=0, sticky="w", padx=10, pady=5)
        ttk.Combobox(alignment_global_frame, textvariable=variable, values=choices, width=14, state="readonly").grid(row=idx, column=1, sticky="w", padx=5, pady=5)
        if label == "Heading":
            heading_left_margin_spin.grid(row=idx, column=2, sticky="w", padx=(22, 5), pady=5)
        elif label == "Body":
            body_left_margin_spin.grid(row=idx, column=2, sticky="w", padx=(22, 5), pady=5)
    ttk.Label(
        alignment_global_frame,
        text="Left margin is used only when Heading or Body is set to left/justify. Justify currently falls back to left alignment because Photoshop point-text lines are rendered individually.",
        foreground="gray",
        wraplength=780,
    ).grid(row=6, column=0, columnspan=3, sticky="w", padx=10, pady=(6, 12))

    alignment_override_frame = ttk.LabelFrame(tab_alignment, text="Per-page Overrides")
    alignment_override_frame.pack(fill="x", padx=10, pady=(0, 10))
    ttk.Label(alignment_override_frame, text="Excel tab:").grid(row=0, column=0, sticky="w", padx=10, pady=(12, 6))
    alignment_page_cb = ttk.Combobox(alignment_override_frame, textvariable=alignment_page_var, width=34, state="readonly")
    alignment_page_cb.grid(row=0, column=1, sticky="w", padx=5, pady=(12, 6))
    alignment_page_cb.bind("<<ComboboxSelected>>", _load_alignment_override)
    ttk.Button(alignment_override_frame, text="Refresh Tabs", command=lambda: _refresh_alignment_pages(True)).grid(row=0, column=2, sticky="w", padx=5, pady=(12, 6))
    _make_toggle(alignment_override_frame, "Use global defaults for this page", alignment_use_global_var, width=34).grid(row=1, column=0, columnspan=3, sticky="w", padx=10, pady=6)
    override_specs = [
        ("Heading", alignment_override_heading_var, ALIGN_CHOICES),
        ("Body", alignment_override_body_var, BODY_ALIGN_CHOICES),
        ("Table", alignment_override_table_var, ALIGN_CHOICES),
        ("Bottom / legal", alignment_override_bottom_var, ALIGN_CHOICES),
        ("Paytable notes", alignment_override_paytable_var, ALIGN_CHOICES),
    ]
    ttk.Label(alignment_override_frame, text="Left margin px:").grid(row=1, column=2, sticky="w", padx=(22, 5), pady=6)
    alignment_override_heading_left_margin_spin = ttk.Spinbox(alignment_override_frame, from_=0, to=3000, width=8)
    alignment_override_heading_left_margin_spin.set(80)
    alignment_override_body_left_margin_spin = ttk.Spinbox(alignment_override_frame, from_=0, to=3000, width=8)
    alignment_override_body_left_margin_spin.set(80)
    for idx, (label, variable, choices) in enumerate(override_specs, start=2):
        ttk.Label(alignment_override_frame, text=f"{label}:").grid(row=idx, column=0, sticky="w", padx=10, pady=5)
        ttk.Combobox(alignment_override_frame, textvariable=variable, values=choices, width=14, state="readonly").grid(row=idx, column=1, sticky="w", padx=5, pady=5)
        if label == "Heading":
            alignment_override_heading_left_margin_spin.grid(row=idx, column=2, sticky="w", padx=(22, 5), pady=5)
        elif label == "Body":
            alignment_override_body_left_margin_spin.grid(row=idx, column=2, sticky="w", padx=(22, 5), pady=5)
    ttk.Label(alignment_override_frame, text="Heading PNG override:").grid(row=7, column=0, sticky="w", padx=10, pady=(8, 5))
    ttk.Entry(alignment_override_frame, textvariable=alignment_override_heading_image_var, width=52).grid(row=7, column=1, columnspan=2, sticky="ew", padx=5, pady=(8, 5))
    ttk.Button(alignment_override_frame, text="Browse", command=_choose_heading_override_image).grid(row=7, column=3, sticky="w", padx=5, pady=(8, 5))
    ttk.Button(alignment_override_frame, text="Clear", command=lambda: alignment_override_heading_image_var.set(""), style="Secondary.TButton").grid(row=7, column=4, sticky="w", padx=5, pady=(8, 5))
    ttk.Button(alignment_override_frame, text="Save Override", command=_save_alignment_override, style="Primary.TButton").grid(row=8, column=0, sticky="w", padx=10, pady=(10, 12))
    ttk.Button(alignment_override_frame, text="Clear Override", command=_clear_alignment_override, style="Danger.TButton").grid(row=8, column=1, sticky="w", padx=5, pady=(10, 12))
    alignment_override_frame.columnconfigure(2, weight=1)

    # Text / heading
    tab_head_tab = ttk.Frame(text_nb)
    text_nb.add(tab_head_tab, text="Heading")
    _head_scroll_host, tab_head = _make_scrollable_host(tab_head_tab, palette["app_bg"])
    _head_scroll_host.pack(fill="both", expand=True)
    ttk.Label(tab_head, text="Font:").grid(row=0, column=0, sticky="w", pady=10, padx=10)
    h_font_cb = ttk.Combobox(tab_head, values=sys_fonts, width=28)
    h_font_cb.set("Arial")
    h_font_cb.grid(row=0, column=1, sticky="w", pady=10)
    h_font_cb.bind("<KeyRelease>", lambda _event: _filter_font_combo(h_font_cb))
    ttk.Label(tab_head, text="Style:").grid(row=0, column=2, sticky="e", padx=(14, 5), pady=10)
    h_font_style_cb = ttk.Combobox(tab_head, textvariable=h_font_style_var, values=FONT_STYLE_CHOICES, width=12, state="readonly")
    h_font_style_cb.grid(row=0, column=3, sticky="w", pady=10)
    ttk.Label(tab_head, text="Text Size:").grid(row=1, column=0, sticky="w", pady=10, padx=10)
    h_size_spin = ttk.Spinbox(tab_head, from_=10, to=250, width=7); h_size_spin.set(55); h_size_spin.grid(row=1, column=1, sticky="w", pady=10)
    ttk.Label(tab_head, text="Color:").grid(row=2, column=0, sticky="w", pady=10, padx=10)
    h_color_btn = tk.Button(tab_head, text="      ", bg=h_color_var.get(), relief="ridge", width=6,
                            command=lambda: _pick_rgb("Heading Font Color", h_rgb_val, h_color_var, h_color_btn))
    h_color_btn.grid(row=2, column=1, sticky="w", pady=10)
    ttk.Label(tab_head, text="Heading PNG folder:").grid(row=3, column=0, sticky="w", pady=10, padx=10)
    ttk.Entry(tab_head, textvariable=heading_image_folder_var, width=56).grid(row=3, column=1, columnspan=3, sticky="ew", pady=10)
    ttk.Button(tab_head, text="Browse", command=_choose_heading_image_folder).grid(row=3, column=4, sticky="w", padx=6, pady=10)
    ttk.Button(tab_head, text="Clear", command=lambda: heading_image_folder_var.set(""), style="Secondary.TButton").grid(row=3, column=5, sticky="w", padx=4, pady=10)
    ttk.Label(tab_head, text="Auto matches Excel tab names like Game Rules.png, Paytable.png, or cleaned filename variants.", foreground="gray", wraplength=720).grid(row=4, column=1, columnspan=5, sticky="w", pady=(0, 8))
    ttk.Label(tab_head, text="PNG target height:").grid(row=5, column=0, sticky="w", pady=10, padx=10)
    heading_image_height_spin = ttk.Spinbox(tab_head, from_=0, to=600, width=7)
    heading_image_height_spin.set(0)
    heading_image_height_spin.grid(row=5, column=1, sticky="w", pady=10)
    ttk.Label(tab_head, text="0 = original image size", foreground="gray").grid(row=5, column=2, columnspan=2, sticky="w", pady=10)
    _make_toggle(tab_head, "Uppercase headings", heading_uppercase_var, width=28).grid(row=6, column=0, columnspan=2, sticky="w", padx=10, pady=(8, 4))
    ttk.Label(tab_head, text="Game Name heading text:").grid(row=7, column=0, sticky="w", pady=8, padx=10)
    ttk.Entry(tab_head, textvariable=heading_game_name_text_var, width=36).grid(row=7, column=1, columnspan=3, sticky="ew", pady=8)
    ttk.Label(tab_head, text="Blank = render <Game Name> as an icon if Icon Mapper or Icons Folder can resolve it.", foreground="gray", wraplength=720).grid(row=8, column=1, columnspan=5, sticky="w", pady=(0, 8))
    _make_toggle(tab_head, "Keep heading in one row", heading_keep_one_line_var, width=32).grid(row=9, column=0, columnspan=2, sticky="w", padx=10, pady=(8, 4))
    ttk.Label(tab_head, text="Safe side margin:").grid(row=9, column=2, sticky="e", padx=(14, 5), pady=(8, 4))
    heading_one_line_margin_spin = ttk.Spinbox(tab_head, from_=0, to=400, width=7)
    heading_one_line_margin_spin.set(80)
    heading_one_line_margin_spin.grid(row=9, column=3, sticky="w", pady=(8, 4))
    ttk.Label(tab_head, text="Per-page heading sizes:").grid(row=10, column=0, sticky="nw", pady=(8, 4), padx=10)
    heading_size_overrides_text = tk.Text(tab_head, height=3, width=58)
    heading_size_overrides_text.configure(
        bg=palette["input_bg"],
        fg=palette["text"],
        insertbackground=palette["text"],
        relief="flat",
        bd=0,
        highlightthickness=1,
        highlightbackground=palette["border"],
        highlightcolor=palette["accent_alt"],
        font=(ui_font_family, 10),
        wrap="word",
    )
    heading_size_overrides_text.grid(row=10, column=1, columnspan=5, sticky="ew", pady=(8, 4))
    ttk.Label(tab_head, text="Examples: BBB=42; Bingo Rules=34. Blank uses the global heading size above.", foreground="gray", wraplength=720).grid(row=11, column=1, columnspan=5, sticky="w", pady=(0, 8))
    ttk.Label(tab_head, text="Per-Page Multi Heading Assignments:").grid(row=12, column=0, sticky="nw", pady=(10, 4), padx=10)
    page_multi_heading_text = tk.Text(
        tab_head,
        height=4,
        wrap="word",
        bg=palette["input_bg"],
        fg=palette["text"],
        insertbackground=palette["text"],
        relief="solid",
        bd=1,
        highlightthickness=0,
    )
    page_multi_heading_scroll = ttk.Scrollbar(tab_head, orient="vertical", command=page_multi_heading_text.yview)
    page_multi_heading_text.configure(yscrollcommand=page_multi_heading_scroll.set)
    page_multi_heading_text.grid(row=13, column=1, columnspan=5, sticky="ew", pady=(10, 4))
    page_multi_heading_scroll.grid(row=13, column=6, sticky="nsw", pady=(10, 4), padx=(0, 10))
    ttk.Label(
        tab_head,
        text="Examples: PageName1=Heading1:B12, Heading2:C45, Heading3:G16; PageName2=Heading1:B12, Heading2:C45",
        foreground="gray",
        font=(ui_font_family, 9, "italic"),
        wraplength=820,
    ).grid(row=14, column=1, columnspan=6, sticky="w", pady=(0, 2))
    ttk.Label(
        tab_head,
        text="Separate pages with semicolons, headings with commas. Each entry: Label:CellRef.",
        foreground="gray",
        wraplength=820,
    ).grid(row=15, column=1, columnspan=6, sticky="w", pady=(0, 6))
    ttk.Label(tab_head, text="Font note: UI shows Windows family names. The builder now resolves them to Photoshop PostScript names automatically.", foreground="gray", wraplength=620).grid(row=16, column=0, columnspan=4, sticky="w", padx=10, pady=10)
    tab_head.columnconfigure(3, weight=1)

    # Text / body
    tab_body_tab = ttk.Frame(text_nb)
    text_nb.add(tab_body_tab, text="Body Text")
    _body_scroll_host, tab_body = _make_scrollable_host(tab_body_tab, palette["app_bg"])
    _body_scroll_host.pack(fill="both", expand=True)
    ttk.Label(tab_body, text="Font:").grid(row=0, column=0, sticky="w", pady=10, padx=10)
    b_font_cb = ttk.Combobox(tab_body, values=sys_fonts, width=28)
    b_font_cb.set("Arial")
    b_font_cb.grid(row=0, column=1, sticky="w", pady=10)
    b_font_cb.bind("<KeyRelease>", lambda _event: _filter_font_combo(b_font_cb))
    ttk.Label(tab_body, text="Style:").grid(row=0, column=2, sticky="e", padx=(14, 5), pady=10)
    b_font_style_cb = ttk.Combobox(tab_body, textvariable=b_font_style_var, values=FONT_STYLE_CHOICES, width=12, state="readonly")
    b_font_style_cb.grid(row=0, column=3, sticky="w", pady=10)
    ttk.Label(tab_body, text="Text Size:").grid(row=1, column=0, sticky="w", pady=10, padx=10)
    b_size_spin = ttk.Spinbox(tab_body, from_=10, to=250, width=7); b_size_spin.set(45); b_size_spin.grid(row=1, column=1, sticky="w", pady=10)
    ttk.Label(tab_body, text="Color:").grid(row=2, column=0, sticky="w", pady=10, padx=10)
    b_color_btn = tk.Button(tab_body, text="      ", bg=b_color_var.get(), relief="ridge", width=6,
                            command=lambda: _pick_rgb("Body Font Color", b_rgb_val, b_color_var, b_color_btn))
    b_color_btn.grid(row=2, column=1, sticky="w", pady=10)

    tab_subhead_tab = ttk.Frame(text_nb)
    text_nb.add(tab_subhead_tab, text="Subheadings")
    _subhead_scroll_host, tab_subhead = _make_scrollable_host(tab_subhead_tab, palette["app_bg"])
    _subhead_scroll_host.pack(fill="both", expand=True)
    ttk.Label(tab_subhead, text="Subheading Font:").grid(row=0, column=0, sticky="w", pady=10, padx=10)
    subheading_font_cb = ttk.Combobox(tab_subhead, values=sys_fonts, width=28)
    subheading_font_cb.set("Arial")
    subheading_font_cb.grid(row=0, column=1, sticky="w", pady=10)
    subheading_font_cb.bind("<KeyRelease>", lambda _event: _filter_font_combo(subheading_font_cb))
    ttk.Label(tab_subhead, text="Style:").grid(row=0, column=2, sticky="e", padx=(14, 5), pady=10)
    ttk.Combobox(tab_subhead, textvariable=subheading_font_style_var, values=FONT_STYLE_CHOICES, width=12, state="readonly").grid(row=0, column=3, sticky="w", pady=10)
    ttk.Label(tab_subhead, text="Size:").grid(row=1, column=0, sticky="w", pady=10, padx=10)
    subheading_size_spin = ttk.Spinbox(tab_subhead, from_=8, to=250, width=7)
    subheading_size_spin.set(36)
    subheading_size_spin.grid(row=1, column=1, sticky="w", pady=10)
    ttk.Label(tab_subhead, text="Color:").grid(row=2, column=0, sticky="w", pady=10, padx=10)
    subheading_color_btn = tk.Button(
        tab_subhead,
        text="      ",
        bg=subheading_text_color_var.get(),
        relief="ridge",
        width=6,
        command=lambda: _pick_rgb("Subheading Font Color", subheading_rgb_val, subheading_text_color_var, subheading_color_btn),
    )
    subheading_color_btn.grid(row=2, column=1, sticky="w", pady=10)
    ttk.Label(tab_subhead, text="Page heading cells:").grid(row=3, column=0, sticky="nw", pady=(12, 4), padx=10)
    page_heading_cells_text = tk.Text(
        tab_subhead,
        height=3,
        wrap="word",
        bg=palette["input_bg"],
        fg=palette["text"],
        insertbackground=palette["text"],
        relief="solid",
        bd=1,
        highlightthickness=0,
    )
    page_heading_cells_scroll = ttk.Scrollbar(tab_subhead, orient="vertical", command=page_heading_cells_text.yview)
    page_heading_cells_text.configure(yscrollcommand=page_heading_cells_scroll.set)
    page_heading_cells_text.grid(row=3, column=1, columnspan=3, sticky="ew", pady=(12, 4))
    page_heading_cells_scroll.grid(row=3, column=4, sticky="nsw", pady=(12, 4), padx=(0, 10))
    ttk.Label(
        tab_subhead,
        text="Optional. Treat these cells as section headings on only the named sheets. Examples: Feature=A7,A11; Bonus Page=A3:A5.",
        foreground="gray",
        wraplength=820,
    ).grid(row=4, column=1, columnspan=4, sticky="w", pady=(0, 8))
    ttk.Label(tab_subhead, text="Page subheading cells:").grid(row=5, column=0, sticky="nw", pady=(4, 4), padx=10)
    page_subheading_cells_text = tk.Text(
        tab_subhead,
        height=3,
        wrap="word",
        bg=palette["input_bg"],
        fg=palette["text"],
        insertbackground=palette["text"],
        relief="solid",
        bd=1,
        highlightthickness=0,
    )
    page_subheading_cells_scroll = ttk.Scrollbar(tab_subhead, orient="vertical", command=page_subheading_cells_text.yview)
    page_subheading_cells_text.configure(yscrollcommand=page_subheading_cells_scroll.set)
    page_subheading_cells_text.grid(row=5, column=1, columnspan=3, sticky="ew", pady=(4, 4))
    page_subheading_cells_scroll.grid(row=5, column=4, sticky="nsw", pady=(4, 4), padx=(0, 10))
    ttk.Label(
        tab_subhead,
        text="Subheadings render in flow with these font settings and optional 'Subheading text' layer style assignment.",
        foreground="gray",
        wraplength=820,
    ).grid(row=6, column=1, columnspan=4, sticky="w", pady=(0, 10))
    tab_subhead.columnconfigure(1, weight=1)

    # Tables
    _make_toggle(tab_table, "Enable Table Rendering", enable_tables_var, width=30).grid(row=0, column=0, columnspan=2, sticky="w", pady=(10, 5), padx=10)
    _make_toggle(tab_table, "Merge Auto Table", table_merge_layers_var, width=24).grid(row=0, column=2, columnspan=3, sticky="w", pady=(10, 5), padx=10)
    ttk.Label(tab_table, text="Overlay Opacity %:").grid(row=1, column=0, sticky="w", pady=5, padx=10)
    table_opacity_spin = ttk.Spinbox(tab_table, from_=0, to=100, width=6); table_opacity_spin.set(80); table_opacity_spin.grid(row=1, column=1, sticky="w", pady=5)
    ttk.Label(tab_table, text="Cell Style:").grid(row=2, column=0, sticky="w", pady=5, padx=10)
    cell_style_cb = ttk.Combobox(tab_table, values=["Fill Only", "Stroke Only", "Fill + Stroke"], width=14, state="readonly"); cell_style_cb.set("Fill + Stroke"); cell_style_cb.grid(row=2, column=1, sticky="w", pady=5)
    ttk.Label(tab_table, text="Stroke Color:").grid(row=3, column=0, sticky="w", pady=5, padx=10)
    stroke_color_btn = tk.Button(tab_table, text="      ", bg=stroke_color_var.get(), relief="ridge", width=6,
                                 command=lambda: _pick_rgb("Table Stroke Color", table_stroke_rgb_val, stroke_color_var, stroke_color_btn))
    stroke_color_btn.grid(row=3, column=1, sticky="w", pady=5)
    ttk.Label(tab_table, text="Stroke Width:").grid(row=4, column=0, sticky="w", pady=5, padx=10)
    stroke_width_spin = ttk.Spinbox(tab_table, from_=1, to=20, width=6); stroke_width_spin.set(2); stroke_width_spin.grid(row=4, column=1, sticky="w", pady=5)
    ttk.Label(tab_table, text="Header Fill:").grid(row=5, column=0, sticky="w", pady=5, padx=10)
    header_fill_btn = tk.Button(tab_table, text="      ", bg=header_fill_var.get(), relief="ridge", width=6,
                                command=lambda: _pick_rgb("Header Fill", table_header_rgb_val, header_fill_var, header_fill_btn))
    header_fill_btn.grid(row=5, column=1, sticky="w", pady=5)
    ttk.Label(tab_table, text="Header Style:").grid(row=5, column=2, sticky="w", pady=5, padx=(20, 5))
    header_style_cb = ttk.Combobox(tab_table, values=["Follow Global", "Fill Only", "Stroke Only", "Fill + Stroke"], width=14, state="readonly")
    header_style_cb.set("Follow Global"); header_style_cb.grid(row=5, column=3, sticky="w", pady=5)
    ttk.Label(tab_table, text="Row 1 Fill:").grid(row=6, column=0, sticky="w", pady=5, padx=10)
    row1_fill_btn = tk.Button(tab_table, text="      ", bg=row1_fill_var.get(), relief="ridge", width=6,
                              command=lambda: _pick_rgb("Row 1 Fill", table_row1_rgb_val, row1_fill_var, row1_fill_btn))
    row1_fill_btn.grid(row=6, column=1, sticky="w", pady=5)
    ttk.Label(tab_table, text="Row 1 Style:").grid(row=6, column=2, sticky="w", pady=5, padx=(20, 5))
    row1_style_cb = ttk.Combobox(tab_table, values=["Follow Global", "Fill Only", "Stroke Only", "Fill + Stroke"], width=14, state="readonly")
    row1_style_cb.set("Follow Global"); row1_style_cb.grid(row=6, column=3, sticky="w", pady=5)
    ttk.Label(tab_table, text="Row 2 Fill:").grid(row=7, column=0, sticky="w", pady=5, padx=10)
    row2_fill_btn = tk.Button(tab_table, text="      ", bg=row2_fill_var.get(), relief="ridge", width=6,
                              command=lambda: _pick_rgb("Row 2 Fill", table_row2_rgb_val, row2_fill_var, row2_fill_btn))
    row2_fill_btn.grid(row=7, column=1, sticky="w", pady=5)
    ttk.Label(tab_table, text="Row 2 Style:").grid(row=7, column=2, sticky="w", pady=5, padx=(20, 5))
    row2_style_cb = ttk.Combobox(tab_table, values=["Follow Global", "Fill Only", "Stroke Only", "Fill + Stroke"], width=14, state="readonly")
    row2_style_cb.set("Follow Global"); row2_style_cb.grid(row=7, column=3, sticky="w", pady=5)
    ttk.Label(tab_table, text="Row Gap (px):").grid(row=8, column=0, sticky="w", pady=5, padx=10)
    row_gap_spin = ttk.Spinbox(tab_table, from_=0, to=100, width=6); row_gap_spin.set(0); row_gap_spin.grid(row=8, column=1, sticky="w", pady=5)
    _make_toggle(tab_table, "Inherit body font for table text", table_inherit_font_var, width=34).grid(row=9, column=0, columnspan=4, sticky="w", pady=(12, 5), padx=10)

    ttk.Label(tab_table, text="Header Font:").grid(row=10, column=0, sticky="w", pady=5, padx=10)
    table_header_font_cb = ttk.Combobox(tab_table, values=sys_fonts, width=24)
    table_header_font_cb.set("Arial")
    table_header_font_cb.grid(row=10, column=1, sticky="w", pady=5)
    table_header_font_cb.bind("<KeyRelease>", lambda _event: _filter_font_combo(table_header_font_cb))
    table_header_style_cb = ttk.Combobox(tab_table, textvariable=table_header_font_style_var, values=FONT_STYLE_CHOICES, width=12, state="readonly")
    table_header_style_cb.grid(row=10, column=2, sticky="w", padx=5, pady=5)
    ttk.Label(tab_table, text="Size:").grid(row=10, column=3, sticky="e", padx=(10, 4))
    table_header_size_spin = ttk.Spinbox(tab_table, from_=0, to=250, width=6); table_header_size_spin.set(0); table_header_size_spin.grid(row=10, column=4, sticky="w", pady=5)

    ttk.Label(tab_table, text="Body Font:").grid(row=11, column=0, sticky="w", pady=5, padx=10)
    table_body_font_cb = ttk.Combobox(tab_table, values=sys_fonts, width=24)
    table_body_font_cb.set("Arial")
    table_body_font_cb.grid(row=11, column=1, sticky="w", pady=5)
    table_body_font_cb.bind("<KeyRelease>", lambda _event: _filter_font_combo(table_body_font_cb))
    table_body_style_cb = ttk.Combobox(tab_table, textvariable=table_body_font_style_var, values=FONT_STYLE_CHOICES, width=12, state="readonly")
    table_body_style_cb.grid(row=11, column=2, sticky="w", padx=5, pady=5)
    ttk.Label(tab_table, text="Size:").grid(row=11, column=3, sticky="e", padx=(10, 4))
    table_body_size_spin = ttk.Spinbox(tab_table, from_=0, to=250, width=6); table_body_size_spin.set(0); table_body_size_spin.grid(row=11, column=4, sticky="w", pady=5)
    ttk.Label(tab_table, text="Table Icon Height:").grid(row=12, column=0, sticky="w", pady=5, padx=10)
    table_icon_height_spin = ttk.Spinbox(tab_table, from_=0, to=500, width=6); table_icon_height_spin.set(0); table_icon_height_spin.grid(row=12, column=1, sticky="w", pady=5)
    ttk.Label(tab_table, text="0 = same as table body text size. Row height uses the larger of text/icon plus vertical padding.", foreground="gray").grid(row=12, column=2, columnspan=3, sticky="w", pady=5)
    ttk.Label(tab_table, text="Table Target Height:").grid(row=13, column=0, sticky="w", pady=5, padx=10)
    table_target_height_spin = ttk.Spinbox(tab_table, from_=0, to=2000, width=6); table_target_height_spin.set(0); table_target_height_spin.grid(row=13, column=1, sticky="w", pady=5)
    ttk.Label(tab_table, text="0 = automatic. Positive values scale the whole auto table group proportionally.", foreground="gray").grid(row=13, column=2, columnspan=3, sticky="w", pady=5)

    ttk.Label(tab_table, text="Table Target Width:").grid(row=14, column=0, sticky="w", pady=5, padx=10)
    table_target_width_spin = ttk.Spinbox(tab_table, from_=0, to=4000, width=6); table_target_width_spin.set(0); table_target_width_spin.grid(row=14, column=1, sticky="w", pady=5)
    ttk.Label(tab_table, text="0 = content width. Positive values force auto-table width within safe margins.", foreground="gray").grid(row=14, column=2, columnspan=3, sticky="w", pady=5)

    ttk.Label(tab_table, text="Header Text Color:").grid(row=15, column=0, sticky="w", pady=5, padx=10)
    table_header_text_color_btn = tk.Button(tab_table, text="      ", bg=table_header_text_color_var.get(), relief="ridge", width=6,
                                            command=lambda: _pick_rgb("Table Header Text Color", table_header_text_rgb_val, table_header_text_color_var, table_header_text_color_btn))
    table_header_text_color_btn.grid(row=15, column=1, sticky="w", pady=5)
    ttk.Label(tab_table, text="Body Text Color:").grid(row=16, column=0, sticky="w", pady=5, padx=10)
    table_body_text_color_btn = tk.Button(tab_table, text="      ", bg=table_body_text_color_var.get(), relief="ridge", width=6,
                                          command=lambda: _pick_rgb("Table Body Text Color", table_body_text_rgb_val, table_body_text_color_var, table_body_text_color_btn))
    table_body_text_color_btn.grid(row=16, column=1, sticky="w", pady=5)

    ttk.Label(tab_table, text="Text Margin After Table:").grid(row=17, column=0, sticky="w", pady=5, padx=10)
    table_after_margin_spin = ttk.Spinbox(tab_table, from_=0, to=300, width=6); table_after_margin_spin.set(30); table_after_margin_spin.grid(row=17, column=1, sticky="w", pady=5)
    ttk.Label(tab_table, text="Min room for next text:").grid(row=18, column=0, sticky="w", pady=5, padx=10)
    table_min_text_room_spin = ttk.Spinbox(tab_table, from_=0, to=500, width=6); table_min_text_room_spin.set(70); table_min_text_room_spin.grid(row=18, column=1, sticky="w", pady=5)
    ttk.Label(tab_table, text="If this much safe space is not left after the table margin, the next text starts on a continued page.", foreground="gray", wraplength=680).grid(row=18, column=2, columnspan=3, sticky="w", padx=8)

    manual_ranges_frame = ttk.LabelFrame(tab_table, text="Manual Auto-Table Ranges")
    manual_ranges_frame.grid(row=19, column=0, columnspan=5, sticky="ew", padx=10, pady=(16, 8))
    manual_ranges_frame.columnconfigure(0, weight=1)
    manual_table_ranges_text = tk.Text(
        manual_ranges_frame,
        height=4,
        wrap="word",
        bg=palette["input_bg"],
        fg=palette["text"],
        insertbackground=palette["text"],
        relief="solid",
        bd=1,
        highlightthickness=0,
    )
    manual_ranges_scroll = ttk.Scrollbar(manual_ranges_frame, orient="vertical", command=manual_table_ranges_text.yview)
    manual_table_ranges_text.configure(yscrollcommand=manual_ranges_scroll.set)
    manual_table_ranges_text.grid(row=0, column=0, sticky="ew", padx=(10, 0), pady=(12, 6))
    manual_ranges_scroll.grid(row=0, column=1, sticky="ns", padx=(0, 10), pady=(12, 6))
    ttk.Label(
        manual_ranges_frame,
        text="One per line or separated by commas/semicolons. Examples: B10:C33, Sheet Name: B10:C33; E10:F20, Sheet Name!B10:C33.",
        foreground="gray",
        wraplength=920,
    ).grid(row=1, column=0, columnspan=2, sticky="w", padx=10, pady=(0, 10))

    excel_fill_ranges_frame = ttk.LabelFrame(tab_table, text="Use Excel Fill Colors For Specific Auto Tables")
    excel_fill_ranges_frame.grid(row=20, column=0, columnspan=5, sticky="ew", padx=10, pady=(0, 8))
    excel_fill_ranges_frame.columnconfigure(0, weight=1)
    table_excel_fill_ranges_text = tk.Text(
        excel_fill_ranges_frame,
        height=3,
        wrap="word",
        bg=palette["input_bg"],
        fg=palette["text"],
        insertbackground=palette["text"],
        relief="solid",
        bd=1,
        highlightthickness=0,
    )
    table_excel_fill_scroll = ttk.Scrollbar(excel_fill_ranges_frame, orient="vertical", command=table_excel_fill_ranges_text.yview)
    table_excel_fill_ranges_text.configure(yscrollcommand=table_excel_fill_scroll.set)
    table_excel_fill_ranges_text.grid(row=0, column=0, sticky="ew", padx=(10, 0), pady=(10, 4))
    table_excel_fill_scroll.grid(row=0, column=1, sticky="ns", padx=(0, 10), pady=(10, 4))
    ttk.Label(
        excel_fill_ranges_frame,
        text="Only listed auto/manual table ranges use Excel cell fill as background. JSON mapped table slot colors stay in charge. Examples: BBB(3)=B10:C33, BBB(4)!E9:F13.",
        foreground="gray",
        wraplength=920,
    ).grid(row=1, column=0, columnspan=2, sticky="w", padx=10, pady=(0, 8))
    ttk.Label(
        excel_fill_ranges_frame,
        text="Fallback cell fill HEX values if Excel color read fails:",
    ).grid(row=2, column=0, columnspan=2, sticky="w", padx=10, pady=(0, 4))
    table_excel_fill_hex_overrides_text = tk.Text(
        excel_fill_ranges_frame,
        height=3,
        wrap="word",
        bg=palette["input_bg"],
        fg=palette["text"],
        insertbackground=palette["text"],
        relief="solid",
        bd=1,
        highlightthickness=0,
    )
    table_excel_fill_hex_scroll = ttk.Scrollbar(excel_fill_ranges_frame, orient="vertical", command=table_excel_fill_hex_overrides_text.yview)
    table_excel_fill_hex_overrides_text.configure(yscrollcommand=table_excel_fill_hex_scroll.set)
    table_excel_fill_hex_overrides_text.grid(row=3, column=0, sticky="ew", padx=(10, 0), pady=(0, 4))
    table_excel_fill_hex_scroll.grid(row=3, column=1, sticky="ns", padx=(0, 10), pady=(0, 4))
    ttk.Label(
        excel_fill_ranges_frame,
        text="Examples: B13=#4F81BD, B13:B15=#92D050, BBB(3)!B13=#FF0000, BBB(3)=B13:#FF0000, BBB(3)=B13:B15,=#FF0000.",
        foreground="gray",
        wraplength=920,
    ).grid(row=4, column=0, columnspan=2, sticky="w", padx=10, pady=(0, 10))

    excel_font_ranges_frame = ttk.LabelFrame(tab_table, text="Use Excel Font Colors For Specific Auto Tables")
    excel_font_ranges_frame.grid(row=21, column=0, columnspan=5, sticky="ew", padx=10, pady=(0, 8))
    excel_font_ranges_frame.columnconfigure(0, weight=1)
    table_excel_font_color_ranges_text = tk.Text(
        excel_font_ranges_frame,
        height=3,
        wrap="word",
        bg=palette["input_bg"],
        fg=palette["text"],
        insertbackground=palette["text"],
        relief="solid",
        bd=1,
        highlightthickness=0,
    )
    table_excel_font_color_scroll = ttk.Scrollbar(excel_font_ranges_frame, orient="vertical", command=table_excel_font_color_ranges_text.yview)
    table_excel_font_color_ranges_text.configure(yscrollcommand=table_excel_font_color_scroll.set)
    table_excel_font_color_ranges_text.grid(row=0, column=0, sticky="ew", padx=(10, 0), pady=(10, 4))
    table_excel_font_color_scroll.grid(row=0, column=1, sticky="ns", padx=(0, 10), pady=(10, 4))
    ttk.Label(
        excel_font_ranges_frame,
        text="Only listed auto/manual table ranges use Excel font colors/default black before Table tab text colors. JSON mapped table slot colors stay in charge.",
        foreground="gray",
        wraplength=920,
    ).grid(row=1, column=0, columnspan=2, sticky="w", padx=10, pady=(0, 8))
    ttk.Label(
        excel_font_ranges_frame,
        text="Fallback cell font HEX values if Excel font color read fails or needs manual override:",
    ).grid(row=2, column=0, columnspan=2, sticky="w", padx=10, pady=(0, 4))
    table_excel_font_hex_overrides_text = tk.Text(
        excel_font_ranges_frame,
        height=3,
        wrap="word",
        bg=palette["input_bg"],
        fg=palette["text"],
        insertbackground=palette["text"],
        relief="solid",
        bd=1,
        highlightthickness=0,
    )
    table_excel_font_hex_scroll = ttk.Scrollbar(excel_font_ranges_frame, orient="vertical", command=table_excel_font_hex_overrides_text.yview)
    table_excel_font_hex_overrides_text.configure(yscrollcommand=table_excel_font_hex_scroll.set)
    table_excel_font_hex_overrides_text.grid(row=3, column=0, sticky="ew", padx=(10, 0), pady=(0, 4))
    table_excel_font_hex_scroll.grid(row=3, column=1, sticky="ns", padx=(0, 10), pady=(0, 4))
    ttk.Label(
        excel_font_ranges_frame,
        text="Examples: C13=#FF00FF, B13:C15=#000000, BBB(3)!C13=#FF00FF, BBB(3)=C13:#FF00FF, BBB(3)=C13:C15,=#FF00FF.",
        foreground="gray",
        wraplength=920,
    ).grid(row=4, column=0, columnspan=2, sticky="w", padx=10, pady=(0, 10))

    text_rect_frame = ttk.LabelFrame(tab_table, text="Text Rectangles")
    text_rect_frame.grid(row=22, column=0, columnspan=5, sticky="ew", padx=10, pady=(0, 8))
    text_rect_frame.columnconfigure(1, weight=1)
    ttk.Label(text_rect_frame, text="Rectangle cells:").grid(row=0, column=0, sticky="nw", padx=10, pady=(12, 4))
    text_rectangle_cells_text = tk.Text(
        text_rect_frame,
        height=3,
        wrap="word",
        bg=palette["input_bg"],
        fg=palette["text"],
        insertbackground=palette["text"],
        relief="solid",
        bd=1,
        highlightthickness=0,
    )
    text_rectangle_cells_scroll = ttk.Scrollbar(text_rect_frame, orient="vertical", command=text_rectangle_cells_text.yview)
    text_rectangle_cells_text.configure(yscrollcommand=text_rectangle_cells_scroll.set)
    text_rectangle_cells_text.grid(row=0, column=1, columnspan=5, sticky="ew", padx=(0, 0), pady=(12, 4))
    text_rectangle_cells_scroll.grid(row=0, column=6, sticky="nsw", padx=(0, 10), pady=(12, 4))
    ttk.Label(
        text_rect_frame,
        text="Optional single-cell callouts in normal page flow. Examples: Scatter Feature=F13; Bonus Page=B10:B12.",
        foreground="gray",
        wraplength=900,
    ).grid(row=1, column=1, columnspan=6, sticky="w", pady=(0, 8))
    ttk.Label(text_rect_frame, text="Fill / opacity:").grid(row=2, column=0, sticky="w", padx=10, pady=5)
    text_rect_fill_btn = tk.Button(
        text_rect_frame,
        text="      ",
        bg=text_rect_fill_var.get(),
        relief="ridge",
        width=6,
        command=lambda: _pick_rgb("Text Rectangle Fill", text_rect_fill_rgb_val, text_rect_fill_var, text_rect_fill_btn),
    )
    text_rect_fill_btn.grid(row=2, column=1, sticky="w", pady=5)
    text_rect_opacity_spin = ttk.Spinbox(text_rect_frame, from_=0, to=100, width=6)
    text_rect_opacity_spin.set(100)
    text_rect_opacity_spin.grid(row=2, column=2, sticky="w", padx=5, pady=5)
    ttk.Label(text_rect_frame, text="Stroke / width:").grid(row=2, column=3, sticky="e", padx=(12, 5), pady=5)
    text_rect_stroke_btn = tk.Button(
        text_rect_frame,
        text="      ",
        bg=text_rect_stroke_var.get(),
        relief="ridge",
        width=6,
        command=lambda: _pick_rgb("Text Rectangle Stroke", text_rect_stroke_rgb_val, text_rect_stroke_var, text_rect_stroke_btn),
    )
    text_rect_stroke_btn.grid(row=2, column=4, sticky="w", pady=5)
    text_rect_stroke_width_spin = ttk.Spinbox(text_rect_frame, from_=0, to=40, width=6)
    text_rect_stroke_width_spin.set(2)
    text_rect_stroke_width_spin.grid(row=2, column=5, sticky="w", padx=5, pady=5)
    ttk.Label(text_rect_frame, text="Font:").grid(row=3, column=0, sticky="w", padx=10, pady=5)
    text_rect_font_cb = ttk.Combobox(text_rect_frame, values=sys_fonts, width=24)
    text_rect_font_cb.set("")
    text_rect_font_cb.grid(row=3, column=1, sticky="w", pady=5)
    text_rect_font_cb.bind("<KeyRelease>", lambda _event: _filter_font_combo(text_rect_font_cb))
    ttk.Combobox(text_rect_frame, textvariable=text_rect_font_style_var, values=FONT_STYLE_CHOICES, width=12, state="readonly").grid(row=3, column=2, sticky="w", padx=5, pady=5)
    ttk.Label(text_rect_frame, text="Size:").grid(row=3, column=3, sticky="e", padx=(12, 5), pady=5)
    text_rect_font_size_spin = ttk.Spinbox(text_rect_frame, from_=0, to=250, width=6)
    text_rect_font_size_spin.set(0)
    text_rect_font_size_spin.grid(row=3, column=4, sticky="w", pady=5)
    ttk.Label(text_rect_frame, text="Text color:").grid(row=4, column=0, sticky="w", padx=10, pady=5)
    text_rect_text_color_btn = tk.Button(
        text_rect_frame,
        text="      ",
        bg=text_rect_text_color_var.get(),
        relief="ridge",
        width=6,
        command=lambda: _pick_rgb("Text Rectangle Text Color", text_rect_text_rgb_val, text_rect_text_color_var, text_rect_text_color_btn),
    )
    text_rect_text_color_btn.grid(row=4, column=1, sticky="w", pady=5)
    ttk.Label(text_rect_frame, text="Align:").grid(row=4, column=2, sticky="e", padx=(12, 5), pady=5)
    ttk.Combobox(text_rect_frame, textvariable=text_rect_alignment_var, values=ALIGN_CHOICES, width=10, state="readonly").grid(row=4, column=3, sticky="w", pady=5)
    ttk.Label(text_rect_frame, text="Padding X/Y:").grid(row=4, column=4, sticky="e", padx=(12, 5), pady=5)
    text_rect_pad_x_spin = ttk.Spinbox(text_rect_frame, from_=0, to=200, width=6)
    text_rect_pad_x_spin.set(10)
    text_rect_pad_x_spin.grid(row=4, column=5, sticky="w", pady=5)
    text_rect_pad_y_spin = ttk.Spinbox(text_rect_frame, from_=0, to=200, width=6)
    text_rect_pad_y_spin.set(5)
    text_rect_pad_y_spin.grid(row=4, column=6, sticky="w", padx=(0, 10), pady=5)
    ttk.Label(
        text_rect_frame,
        text="Font or size 0 uses body text settings. These rectangles are normal-flow callouts, not JSON table slots.",
        foreground="gray",
        wraplength=900,
    ).grid(row=5, column=1, columnspan=6, sticky="w", pady=(0, 10))

    table_json_mapper_status_var = tk.StringVar(
        value="Load/export an @table JSON, map it, then Build will use it before the auto-table fallback."
    )

    def _mapped_table_json_paths():
        raw = mapped_table_json_var.get().strip()
        if not raw:
            return []
        return [
            item.strip()
            for item in re.split(r"[;\n]+", raw)
            if item.strip()
        ]

    def _set_mapped_table_json_paths(paths):
        unique = []
        seen = set()
        for path in paths or []:
            cleaned = str(path or "").strip()
            if not cleaned:
                continue
            key = os.path.abspath(cleaned).casefold()
            if key in seen:
                continue
            seen.add(key)
            unique.append(cleaned)
        mapped_table_json_var.set("; ".join(unique))
        if not unique:
            table_json_mapper_status_var.set("No active table JSON selected.")
        elif len(unique) == 1:
            table_json_mapper_status_var.set(f"Active table JSON: {os.path.basename(unique[0])}")
        else:
            table_json_mapper_status_var.set(
                f"Active table JSONs: {len(unique)} files selected for Build. Mapper opens latest: {os.path.basename(unique[-1])}"
            )

    def _show_sheet_picker(json_paths):
        """Show a dialog matching the main UI theme to assign JSONs to sheets."""
        all_sheets = _selected_sheet_names() or []
        if not all_sheets:
            try:
                wb = load_workbook(excel_var.get().strip(), read_only=True, data_only=True)
                all_sheets = list(wb.sheetnames)
                wb.close()
            except Exception:
                pass
        if not all_sheets:
            return
        dia = tk.Toplevel(root)
        dia.title("Assign JSON to Sheets")
        dia.configure(bg=palette["app_bg"])
        dia.transient(root)
        dia.grab_set()
        w = min(660, root.winfo_width() - 40)
        h = min(520, root.winfo_height() - 40)
        dia.geometry(f"{w}x{h}")
        dia.minsize(480, 360)

        header = ttk.Frame(dia)
        header.pack(fill="x", padx=14, pady=(14, 6))
        ttk.Label(header, text="Assign JSON Templates to Pages", style="Title.TLabel").pack(anchor="w")
        ttk.Label(header, text="Check which sheet(s) each JSON template should apply to. Same JSON can be used on multiple pages.",
                  style="CardMuted.TLabel", wraplength=w - 50).pack(anchor="w", pady=(2, 0))

        main_frame = ttk.Frame(dia)
        main_frame.pack(fill="both", expand=True, padx=14, pady=6)

        col_canvas = tk.Canvas(main_frame, bg=palette["panel_bg"], highlightthickness=0)
        col_scroll = ttk.Scrollbar(main_frame, orient="vertical", command=col_canvas.yview)
        col_canvas.configure(yscrollcommand=col_scroll.set)
        col_scroll.pack(side="right", fill="y")
        col_canvas.pack(side="left", fill="both", expand=True)
        col_inner = ttk.Frame(col_canvas)
        col_win = col_canvas.create_window((0, 0), window=col_inner, anchor="nw")
        def _sync_col(_event=None):
            col_canvas.configure(scrollregion=col_canvas.bbox("all"))
            col_canvas.itemconfigure(col_win, width=col_canvas.winfo_width())
        col_inner.bind("<Configure>", _sync_col)
        col_canvas.bind("<Configure>", _sync_col)

        # Top header row: JSON file names in columns
        json_list = list(dict.fromkeys(json_paths))
        header_row = ttk.Frame(col_inner)
        header_row.pack(fill="x", pady=(6, 4))
        ttk.Label(header_row, text="Page / Sheet", style="FieldLabel.TLabel", width=24).pack(side="left", padx=(8, 4))
        for jp in json_list:
            lbl = os.path.basename(jp)
            ttk.Label(header_row, text=lbl, style="FieldLabel.TLabel", width=20).pack(side="left", padx=2)
        ttk.Separator(col_inner, orient="horizontal").pack(fill="x", pady=2)

        checkboxes = {}
        for sheet in all_sheets:
            row = ttk.Frame(col_inner)
            row.pack(fill="x", pady=1)
            sheet_lbl = ttk.Label(row, text=sheet, style="CardMuted.TLabel", width=24, anchor="w")
            sheet_lbl.pack(side="left", padx=(8, 4))
            sheet_vars = {}
            for jp in json_list:
                var = tk.BooleanVar(value=sheet in (json_sheet_overrides.get(jp) or []))
                cb = ttk.Checkbutton(row, variable=var)
                cb.pack(side="left", padx=8)
                sheet_vars[jp] = var
            checkboxes[sheet] = sheet_vars

        def _set_all_sheet_cbs(value):
            for sheet_vars in checkboxes.values():
                for var in sheet_vars.values():
                    var.set(value)

        def _confirm():
            for sheet, sheet_vars in checkboxes.items():
                for jp, var in sheet_vars.items():
                    if var.get():
                        cur = json_sheet_overrides.setdefault(jp, [])
                        if sheet not in cur:
                            cur.append(sheet)
                    else:
                        cur = json_sheet_overrides.get(jp, [])
                        if sheet in cur:
                            cur.remove(sheet)
            for jp in list(json_sheet_overrides.keys()):
                if not json_sheet_overrides[jp]:
                    del json_sheet_overrides[jp]
            dia.destroy()

        btn_bar = ttk.Frame(dia)
        btn_bar.pack(fill="x", padx=14, pady=(6, 12))
        ttk.Button(btn_bar, text="Select All", command=lambda: _set_all_sheet_cbs(True)).pack(side="left", padx=(0, 4))
        ttk.Button(btn_bar, text="Clear All", command=lambda: _set_all_sheet_cbs(False)).pack(side="left")
        ttk.Button(btn_bar, text="Confirm", command=_confirm, style="Primary.TButton").pack(side="right", padx=(4, 0))
        ttk.Button(btn_bar, text="Cancel", command=dia.destroy).pack(side="right")

    def _browse_mapped_table_json():
        paths = list(filedialog.askopenfilenames(filetypes=[("JSON", "*.json")]))
        if paths:
            _set_mapped_table_json_paths(_mapped_table_json_paths() + paths)
            for p in paths:
                json_sheet_overrides.setdefault(p, [])
            root.after(100, lambda: _show_sheet_picker(paths))
            status_var.set("Mapped table JSON selected")

    def _mapped_table_saved(path, table_name):
        _set_mapped_table_json_paths(_mapped_table_json_paths() + [path])
        json_sheet_overrides.setdefault(path, [])
        table_json_mapper_status_var.set(
            f"Ready for Build: {table_name or 'table'} uses {path}"
        )
        status_var.set("Table JSON mapping saved")
        root.after(100, lambda: _show_sheet_picker([path]))

    def _open_table_json_mapper():
        json_paths = _mapped_table_json_paths()
        source_json = json_paths[-1] if json_paths else mapped_table_json_var.get().strip()
        if len(json_paths) > 1:
            table_json_mapper_status_var.set(
                f"Opening mapper for latest JSON: {os.path.basename(source_json)}. Build will still use all {len(json_paths)} selected JSONs."
            )
        def _spin_int(widget, fallback):
            try:
                value = int(float(widget.get() or 0))
            except Exception:
                value = 0
            return value if value > 0 else fallback

        initial_size = _spin_int(table_body_size_spin, _spin_int(b_size_spin, 30))
        table_json_mapper_status_var.set("Table mapper open. Save mapped JSON to use it in the next Build.")
        return open_table_mapper(
            root,
            initial_excel=excel_var.get().strip(),
            initial_json=source_json,
            output_folder=os.path.dirname(source_json) if source_json else output_dir_var.get().strip(),
            on_saved=_mapped_table_saved,
            palette=palette,
            initial_font_size=initial_size,
            icons_folder=icon_var.get().strip(),
            initial_icon_mappings=dict(icon_mappings),
            extra_json_paths=json_paths,
        )

    # -- JSON Tables content --
    tab_table_json_frame = ttk.LabelFrame(tab_table_json, text="Dynamic Table JSON Mapper")
    tab_table_json_frame.grid(row=0, column=0, columnspan=5, sticky="ew", padx=10, pady=(10, 10))
    tab_table_json_frame.columnconfigure(1, weight=1)
    ttk.Label(tab_table_json_frame, text="Active @table JSON:").grid(row=0, column=0, sticky="w", padx=10, pady=(12, 5))
    ttk.Entry(tab_table_json_frame, textvariable=mapped_table_json_var, state="readonly").grid(row=0, column=1, sticky="ew", padx=5, pady=(12, 5))
    ttk.Button(tab_table_json_frame, text="Add JSON(s)", command=_browse_mapped_table_json).grid(row=0, column=2, sticky="w", padx=5, pady=(12, 5))
    ttk.Button(tab_table_json_frame, text="Remove All", command=lambda: _set_mapped_table_json_paths([])).grid(row=0, column=3, sticky="w", padx=(0, 10), pady=(12, 5))
    ttk.Button(tab_table_json_frame, text="Edit Sheet Assignments", command=lambda: _show_sheet_picker(_mapped_table_json_paths())).grid(row=0, column=4, sticky="w", pady=(12, 5))
    ttk.Button(
        tab_table_json_frame,
        text="OPEN TABLE JSON MAPPER",
        style="Mapper.TButton",
        command=_open_table_json_mapper,
    ).grid(row=1, column=0, columnspan=4, sticky="ew", padx=10, pady=(8, 6), ipady=6)
    ttk.Label(
        tab_table_json_frame,
        textvariable=table_json_mapper_status_var,
        foreground="gray",
        wraplength=820,
    ).grid(row=2, column=0, columnspan=4, sticky="w", padx=10, pady=(0, 8))
    ttk.Label(
        tab_table_json_frame,
        text=(
            "Layer names can start with @table., @slot., or any @ prefix. Use @table.name.bounds for predictable placement; "
            "slot names after the prefix can be custom."
        ),
        foreground="gray",
        wraplength=820,
    ).grid(row=3, column=0, columnspan=4, sticky="w", padx=10, pady=(0, 12))

    # Dynamic Pages addon - explicit tab-name/template mapping only
    tab_dynamic_paytable_host = ttk.Frame(dynamic_nb)
    tab_dynamic_rules_host = ttk.Frame(dynamic_nb)
    tab_dynamic_bingo_host = ttk.Frame(dynamic_nb)
    tab_dynamic_pages_host = ttk.Frame(dynamic_nb)
    dynamic_nb.add(tab_dynamic_paytable_host, text="Paytable")
    dynamic_nb.add(tab_dynamic_rules_host, text="Game Rules")
    dynamic_nb.add(tab_dynamic_bingo_host, text="Bingo Rules")
    dynamic_nb.add(tab_dynamic_pages_host, text="Page Overrides")
    _paytable_scroll_host, tab_dynamic_paytable = _make_scrollable_host(tab_dynamic_paytable_host, palette["app_bg"]); _paytable_scroll_host.pack(fill="both", expand=True)
    _rules_scroll_host, tab_dynamic_rules = _make_scrollable_host(tab_dynamic_rules_host, palette["app_bg"]); _rules_scroll_host.pack(fill="both", expand=True)
    _bingo_scroll_host, tab_dynamic_bingo = _make_scrollable_host(tab_dynamic_bingo_host, palette["app_bg"]); _bingo_scroll_host.pack(fill="both", expand=True)
    _pages_scroll_host, tab_dynamic_pages = _make_scrollable_host(tab_dynamic_pages_host, palette["app_bg"]); _pages_scroll_host.pack(fill="both", expand=True)

    paytable_json_choice_var = tk.StringVar()
    paytable_json_paths = {}

    def _activate_paytable_json(path):
        path = os.path.abspath(os.path.expanduser(str(path or "")))
        if not os.path.isfile(path):
            messagebox.showwarning("Paytable JSON", "Select an existing JSON file.")
            return False
        dynamic_template_json_var.set(path)
        dynamic_template_folder_var.set(os.path.dirname(path))
        paytable_json_choice_var.set(os.path.basename(path))
        try:
            with open(path, "r", encoding="utf-8") as handle:
                template_data = json.load(handle)
            sheet_matches = template_data.get("sheet_match") or []
            if sheet_matches:
                dynamic_sheet_var.set(str(sheet_matches[0]))
        except Exception:
            pass
        status_var.set(f"Active Paytable JSON: {os.path.basename(path)}")
        return True

    def _browse_paytable_json():
        path = filedialog.askopenfilename(filetypes=[("JSON", "*.json")])
        if path and _activate_paytable_json(path):
            _refresh_paytable_json_library(select_active=True)

    def _refresh_paytable_json_library(select_active=False):
        folder = dynamic_template_folder_var.get().strip()
        if not folder or not os.path.isdir(folder):
            folder = os.path.dirname(dynamic_template_json_var.get().strip())
        paytable_json_paths.clear()
        if folder and os.path.isdir(folder):
            for name in sorted(os.listdir(folder), key=str.casefold):
                if name.lower().endswith(".json"):
                    paytable_json_paths[name.casefold()] = os.path.join(folder, name)
        query = paytable_json_choice_var.get().strip()
        values = [os.path.basename(path) for path in paytable_json_paths.values()]
        if query and not select_active:
            values = [name for name in values if query.casefold() in name.casefold()]
        paytable_json_library_cb["values"] = values
        if select_active:
            active = dynamic_template_json_var.get().strip()
            if active:
                paytable_json_choice_var.set(os.path.basename(active))

    def _load_selected_paytable_json(_event=None):
        selected = paytable_json_choice_var.get().strip()
        path = paytable_json_paths.get(selected.casefold())
        if not path and os.path.isfile(selected):
            path = selected
        if path:
            _activate_paytable_json(path)

    def _save_current_paytable_json_as():
        source = dynamic_template_json_var.get().strip()
        if not source or not os.path.isfile(source):
            messagebox.showwarning("Save Game JSON", "Load or map a Paytable JSON first.")
            return
        folder = dynamic_template_folder_var.get().strip()
        if not folder or not os.path.isdir(folder):
            folder = filedialog.askdirectory(title="Choose the saved game JSON folder")
            if not folder:
                return
            dynamic_template_folder_var.set(folder)
        default_name = os.path.splitext(os.path.basename(source))[0]
        game_name = simpledialog.askstring("Save Game JSON", "Game/template name:", initialvalue=default_name)
        game_name = str(game_name or "").strip()
        if not game_name:
            return
        safe_name = "".join(ch if ch not in r'<>:\"/\\|?*' else "_" for ch in game_name).strip()
        output_path = os.path.join(folder, safe_name + ".json")
        try:
            with open(source, "r", encoding="utf-8") as handle:
                template_data = json.load(handle)
            with open(output_path, "w", encoding="utf-8") as handle:
                json.dump(template_data, handle, indent=2, ensure_ascii=True)
                handle.write("\n")
            _activate_paytable_json(output_path)
            _refresh_paytable_json_library(select_active=True)
        except Exception as exc:
            messagebox.showerror("Save Game JSON", str(exc))

    routing_frame = ttk.LabelFrame(tab_dynamic_paytable, text="Paytable Routing & JSON Library")
    routing_frame.pack(fill="x", padx=10, pady=(10, 8))
    _make_toggle(routing_frame, "Enable tab-name custom layout rendering", dynamic_enable_var, width=42).grid(row=0, column=0, columnspan=5, sticky="w", padx=10, pady=(12, 8))
    ttk.Label(routing_frame, text="Saved JSON folder:").grid(row=1, column=0, sticky="w", padx=10, pady=4)
    ttk.Entry(routing_frame, textvariable=dynamic_template_folder_var, state="readonly", width=58).grid(row=1, column=1, columnspan=2, sticky="ew", pady=4)
    ttk.Button(routing_frame, text="Browse", command=_choose_template_folder).grid(row=1, column=3, sticky="w", padx=5)
    ttk.Button(routing_frame, text="Remove", command=lambda: _clear_path(dynamic_template_folder_var)).grid(row=1, column=4, sticky="w", padx=5)
    ttk.Label(routing_frame, text="Search saved JSON:").grid(row=2, column=0, sticky="w", padx=10, pady=4)
    paytable_json_library_cb = ttk.Combobox(routing_frame, textvariable=paytable_json_choice_var, width=46)
    paytable_json_library_cb.grid(row=2, column=1, columnspan=2, sticky="ew", pady=4)
    paytable_json_library_cb.bind("<KeyRelease>", lambda _event: _refresh_paytable_json_library())
    paytable_json_library_cb.bind("<<ComboboxSelected>>", _load_selected_paytable_json)
    ttk.Button(routing_frame, text="Load", command=_load_selected_paytable_json).grid(row=2, column=3, sticky="w", padx=5)
    ttk.Button(routing_frame, text="Save Current As", command=_save_current_paytable_json_as).grid(row=2, column=4, sticky="w", padx=5)
    ttk.Label(routing_frame, text="Excel tab name:").grid(row=3, column=0, sticky="w", padx=10, pady=4)
    ttk.Entry(routing_frame, textvariable=dynamic_sheet_var, width=24).grid(row=3, column=1, sticky="w", pady=4)
    ttk.Label(routing_frame, text="Active Paytable JSON:").grid(row=4, column=0, sticky="w", padx=10, pady=4)
    ttk.Entry(routing_frame, textvariable=dynamic_template_json_var, state="readonly", width=58).grid(row=4, column=1, columnspan=2, sticky="ew", pady=4)
    ttk.Button(routing_frame, text="Browse", command=_browse_paytable_json).grid(row=4, column=3, sticky="w", padx=5)
    ttk.Button(routing_frame, text="Remove", command=lambda: _clear_path(dynamic_template_json_var)).grid(row=4, column=4, sticky="w", padx=5)
    ttk.Label(routing_frame, text="The active JSON is passed directly into the mapper and is used for this Paytable tab during Build.", foreground="gray", wraplength=820).grid(row=5, column=1, columnspan=4, sticky="w", padx=8, pady=(0, 12))
    routing_frame.columnconfigure(1, weight=1)
    root.after_idle(lambda: _refresh_paytable_json_library(select_active=True))

    paytable_assets_frame = ttk.LabelFrame(tab_dynamic_paytable, text="Core Assets")
    paytable_assets_frame.pack(fill="x", padx=10, pady=(10, 8))
    ttk.Label(paytable_assets_frame, text="Wild / Scatter asset:").grid(row=0, column=0, sticky="w", padx=10, pady=(12, 6))
    ttk.Entry(paytable_assets_frame, textvariable=dynamic_wild_asset_var, width=42).grid(row=0, column=1, sticky="w", pady=(12, 6))
    ttk.Button(paytable_assets_frame, text="Browse", command=_choose_wild_asset_file).grid(row=0, column=2, sticky="w", padx=5, pady=(12, 6))
    ttk.Label(paytable_assets_frame, text="Can be a filename from the Icons Folder or a direct file path. Slot names: wild, wild.icon, feature.icon.", foreground="gray", wraplength=760).grid(row=1, column=1, columnspan=2, sticky="w", padx=0, pady=(0, 12))

    paytable_mapper_status_var = tk.StringVar(
        value="Load the Excel workbook and slot JSON, then map every text row and icon token to its PSD slot."
    )
    paytable_mapper_frame = ttk.LabelFrame(tab_dynamic_paytable, text="Excel to JSON Slot Mapper")
    paytable_mapper_frame.pack(fill="x", padx=10, pady=(0, 8))
    paytable_mapper_frame.columnconfigure(1, weight=1)
    ttk.Label(paytable_mapper_frame, text="Current Excel:").grid(row=0, column=0, sticky="w", padx=10, pady=(12, 5))
    ttk.Entry(paytable_mapper_frame, textvariable=excel_var, state="readonly").grid(
        row=0, column=1, sticky="ew", padx=(0, 10), pady=(12, 5)
    )
    ttk.Label(paytable_mapper_frame, text="Active slot JSON:").grid(row=1, column=0, sticky="w", padx=10, pady=5)
    ttk.Entry(paytable_mapper_frame, textvariable=dynamic_template_json_var, state="readonly").grid(
        row=1, column=1, sticky="ew", padx=(0, 10), pady=5
    )
    btn_row = ttk.Frame(paytable_mapper_frame)
    btn_row.grid(row=2, column=0, columnspan=2, sticky="ew", padx=10, pady=(8, 6))
    tk.Button(
        btn_row,
        text="PAYTABLE LAYOUT MAPPER",
        bg="#B22222",
        fg="#FFFFFF",
        activebackground="#DC143C",
        activeforeground="#FFFFFF",
        relief="raised",
        bd=1,
        padx=20,
        pady=8,
        cursor="hand2",
        font=("Segoe UI", 10, "bold"),
        command=lambda: _open_paytable_mapper(),
    ).pack(side="left", fill="x", expand=True, padx=(0, 6))
    ttk.Label(
        paytable_mapper_frame,
        textvariable=paytable_mapper_status_var,
        foreground="gray",
        wraplength=820,
    ).grid(row=3, column=0, columnspan=2, sticky="w", padx=10, pady=(0, 12))

    # ---- Paytable Quick Style Presets ----
    paytable_preset_frame = ttk.LabelFrame(tab_dynamic_paytable, text="Quick Style Presets")
    paytable_preset_frame.pack(fill="x", padx=10, pady=(0, 8))

    _PAYTABLE_STYLE_PRESETS = {
        "Gold Premium": {
            "count_size": 36, "count_hex": "#FFD700",
            "value_size": 40, "value_hex": "#FFFFFF",
            "fallback_size": 120, "fallback_hex": "#FFD700",
            "wild_text_size": 32, "wild_text_hex": "#FFD700",
            "notes_size": 28, "notes_hex": "#CCC0A0",
            "top_bg_hex": "#1A0A00", "top_bg_opacity": 60,
            "lower_bg_hex": "#120800", "lower_bg_opacity": 55,
            "card_stroke_hex": "#FFD700", "card_stroke_width": 2,
            "text_bg_hex": "#0D0800", "text_bg_opacity": 70,
            "wild_title_size": 72, "wild_title_hex": "#FFD700",
            "top_icon_height": 280, "lower_icon_height": 220,
            "wild_icon_height": 200,
        },
        "Classic Dark": {
            "count_size": 38, "count_hex": "#FFAF37",
            "value_size": 42, "value_hex": "#FFFFFF",
            "fallback_size": 110, "fallback_hex": "#FFFFFF",
            "wild_text_size": 30, "wild_text_hex": "#FFFFFF",
            "notes_size": 30, "notes_hex": "#FFFFFF",
            "top_bg_hex": "#080A12", "top_bg_opacity": 65,
            "lower_bg_hex": "#100A1C", "lower_bg_opacity": 65,
            "card_stroke_hex": "#232332", "card_stroke_width": 0,
            "text_bg_hex": "#0A0A12", "text_bg_opacity": 70,
            "wild_title_size": 72, "wild_title_hex": "#FFFFFF",
            "top_icon_height": 260, "lower_icon_height": 210,
            "wild_icon_height": 190,
        },
        "Neon Arcade": {
            "count_size": 42, "count_hex": "#00FFAA",
            "value_size": 46, "value_hex": "#FFFFFF",
            "fallback_size": 130, "fallback_hex": "#00FFAA",
            "wild_text_size": 34, "wild_text_hex": "#FF44FF",
            "notes_size": 28, "notes_hex": "#AAAAFF",
            "top_bg_hex": "#08001A", "top_bg_opacity": 75,
            "lower_bg_hex": "#0A0020", "lower_bg_opacity": 70,
            "card_stroke_hex": "#00FFAA", "card_stroke_width": 1,
            "text_bg_hex": "#060010", "text_bg_opacity": 80,
            "wild_title_size": 80, "wild_title_hex": "#FF44FF",
            "top_icon_height": 300, "lower_icon_height": 240,
            "wild_icon_height": 220,
        },
        "Clean White": {
            "count_size": 34, "count_hex": "#222222",
            "value_size": 38, "value_hex": "#111111",
            "fallback_size": 100, "fallback_hex": "#333333",
            "wild_text_size": 28, "wild_text_hex": "#111111",
            "notes_size": 26, "notes_hex": "#555555",
            "top_bg_hex": "#EEEEEE", "top_bg_opacity": 80,
            "lower_bg_hex": "#DDDDDD", "lower_bg_opacity": 80,
            "card_stroke_hex": "#AAAAAA", "card_stroke_width": 1,
            "text_bg_hex": "#F5F5F5", "text_bg_opacity": 85,
            "wild_title_size": 68, "wild_title_hex": "#000000",
            "top_icon_height": 240, "lower_icon_height": 190,
            "wild_icon_height": 170,
        },
    }

    def _apply_paytable_quick_preset(name):
        p = _PAYTABLE_STYLE_PRESETS.get(name)
        if not p:
            return
        _set_spin(dynamic_count_size_spin, p.get("count_size", 38))
        _set_hex_color(dynamic_count_rgb_val, dynamic_count_color_var, dynamic_count_color_btn, p.get("count_hex", "#FFAF37"))
        _set_spin(dynamic_value_size_spin, p.get("value_size", 42))
        _set_hex_color(dynamic_value_rgb_val, dynamic_value_color_var, dynamic_value_color_btn, p.get("value_hex", "#FFFFFF"))
        _set_spin(dynamic_fallback_size_spin, p.get("fallback_size", 110))
        _set_hex_color(dynamic_fallback_rgb_val, dynamic_fallback_color_var, dynamic_fallback_color_btn, p.get("fallback_hex", "#FFFFFF"))
        _set_spin(dynamic_wild_text_size_spin, p.get("wild_text_size", 30))
        _set_hex_color(dynamic_wild_text_rgb_val, dynamic_wild_text_color_var, dynamic_wild_text_color_btn, p.get("wild_text_hex", "#FFFFFF"))
        _set_spin(dynamic_notes_size_spin, p.get("notes_size", 30))
        _set_hex_color(dynamic_notes_rgb_val, dynamic_notes_color_var, dynamic_notes_color_btn, p.get("notes_hex", "#FFFFFF"))
        _set_spin(dynamic_wild_title_size_spin, p.get("wild_title_size", 72))
        _set_hex_color(dynamic_wild_title_rgb_val, dynamic_wild_title_color_var, dynamic_wild_title_color_btn, p.get("wild_title_hex", "#FFFFFF"))
        _set_hex_color(dynamic_top_bg_rgb_val, dynamic_top_bg_color_var, dynamic_top_bg_color_btn, p.get("top_bg_hex", "#080A12"))
        _set_spin(dynamic_top_bg_opacity_spin, p.get("top_bg_opacity", 65))
        _set_hex_color(dynamic_lower_bg_rgb_val, dynamic_lower_bg_color_var, dynamic_lower_bg_color_btn, p.get("lower_bg_hex", "#100A1C"))
        _set_spin(dynamic_lower_bg_opacity_spin, p.get("lower_bg_opacity", 65))
        _set_hex_color(dynamic_card_stroke_rgb_val, dynamic_card_stroke_color_var, dynamic_card_stroke_color_btn, p.get("card_stroke_hex", "#232332"))
        _set_spin(dynamic_card_stroke_width_spin, p.get("card_stroke_width", 0))
        _set_hex_color(dynamic_text_bg_rgb_val, dynamic_text_bg_color_var, dynamic_text_bg_color_btn, p.get("text_bg_hex", "#0A0A12"))
        _set_spin(dynamic_text_bg_opacity_spin, p.get("text_bg_opacity", 70))
        _set_spin(dynamic_top_icon_height_spin, p.get("top_icon_height", 260))
        _set_spin(dynamic_lower_icon_height_spin, p.get("lower_icon_height", 210))
        _set_spin(dynamic_wild_icon_height_spin, p.get("wild_icon_height", 190))
        paytable_mapper_status_var.set(f"Applied preset: {name}")

    def _set_spin(spin, value):
        try:
            spin.set(max(spin.cget("from"), min(spin.cget("to"), int(value))))
        except Exception:
            pass

    def _set_hex_color(rgb_list, color_var, btn, hex_str):
        try:
            hex_str = str(hex_str or "#FFFFFF").lstrip("#")
            if len(hex_str) == 6:
                rgb_list[:] = [int(hex_str[i:i+2], 16) for i in (0, 2, 4)]
                color_var.set("#" + hex_str.upper())
                if btn and btn.winfo_exists():
                    btn.configure(bg=color_var.get())
        except Exception:
            pass

    btn_index = 0
    for preset_name in _PAYTABLE_STYLE_PRESETS:
        ttk.Button(
            paytable_preset_frame,
            text=preset_name,
            command=lambda n=preset_name: _apply_paytable_quick_preset(n),
        ).grid(row=0, column=btn_index, padx=6, pady=(8, 8), ipadx=6)
        btn_index += 1
    ttk.Label(
        paytable_preset_frame,
        text="Click to apply all paytable style settings at once.",
        foreground="gray",
    ).grid(row=0, column=btn_index, sticky="w", padx=(12, 0), pady=(8, 8))

    paytable_text_frame = ttk.LabelFrame(tab_dynamic_paytable, text="Payout Typography")
    paytable_text_frame.pack(fill="x", padx=10, pady=(0, 8))
    ttk.Label(paytable_text_frame, text="Payout count:").grid(row=0, column=0, sticky="w", padx=10, pady=(12, 6))
    dynamic_count_font_cb = ttk.Combobox(paytable_text_frame, values=sys_fonts, width=22)
    dynamic_count_font_cb.grid(row=0, column=1, sticky="w", pady=(12, 6))
    dynamic_count_font_cb.bind("<KeyRelease>", lambda _event: _filter_font_combo(dynamic_count_font_cb))
    dynamic_count_style_cb = ttk.Combobox(paytable_text_frame, textvariable=dynamic_count_font_style_var, values=FONT_STYLE_CHOICES, width=12, state="readonly")
    dynamic_count_style_cb.grid(row=0, column=2, sticky="w", padx=5, pady=(12, 6))
    dynamic_count_size_spin = ttk.Spinbox(paytable_text_frame, from_=8, to=250, width=7); dynamic_count_size_spin.set(38); dynamic_count_size_spin.grid(row=0, column=3, sticky="w", pady=(12, 6))
    dynamic_count_color_btn = tk.Button(paytable_text_frame, text="      ", bg=dynamic_count_color_var.get(), relief="ridge", width=6, command=lambda: _pick_rgb("Paytable Count Color", dynamic_count_rgb_val, dynamic_count_color_var, dynamic_count_color_btn))
    dynamic_count_color_btn.grid(row=0, column=4, sticky="w", pady=(12, 6))
    ttk.Label(paytable_text_frame, text="Payout value:").grid(row=1, column=0, sticky="w", padx=10, pady=6)
    dynamic_value_font_cb = ttk.Combobox(paytable_text_frame, values=sys_fonts, width=22)
    dynamic_value_font_cb.grid(row=1, column=1, sticky="w", pady=6)
    dynamic_value_font_cb.bind("<KeyRelease>", lambda _event: _filter_font_combo(dynamic_value_font_cb))
    dynamic_value_style_cb = ttk.Combobox(paytable_text_frame, textvariable=dynamic_value_font_style_var, values=FONT_STYLE_CHOICES, width=12, state="readonly")
    dynamic_value_style_cb.grid(row=1, column=2, sticky="w", padx=5, pady=6)
    dynamic_value_size_spin = ttk.Spinbox(paytable_text_frame, from_=8, to=250, width=7); dynamic_value_size_spin.set(42); dynamic_value_size_spin.grid(row=1, column=3, sticky="w", pady=6)
    dynamic_value_color_btn = tk.Button(paytable_text_frame, text="      ", bg=dynamic_value_color_var.get(), relief="ridge", width=6, command=lambda: _pick_rgb("Paytable Value Color", dynamic_value_rgb_val, dynamic_value_color_var, dynamic_value_color_btn))
    dynamic_value_color_btn.grid(row=1, column=4, sticky="w", pady=6)
    ttk.Label(paytable_text_frame, text="Leave the font blank to inherit the main body font.", foreground="gray").grid(row=2, column=1, columnspan=4, sticky="w", pady=(0, 12))
    ttk.Label(paytable_text_frame, text="Payout placement:").grid(row=3, column=0, sticky="w", padx=10, pady=(6, 12))
    payout_placement_mode_var = tk.StringVar(value="Bottom of icon")
    ttk.Combobox(
        paytable_text_frame, textvariable=payout_placement_mode_var,
        values=("Bottom of icon", "Left of icon", "Right of icon", "Use JSON pay/value slots"),
        width=22, state="readonly",
    ).grid(row=3, column=1, columnspan=3, sticky="w", pady=(6, 12))
    ttk.Label(paytable_text_frame, text="Priority: mapper > JSON slots > placement mode > bottom fallback.", foreground="gray").grid(row=3, column=4, columnspan=2, sticky="w", pady=(6, 12), padx=(8, 0))

    paytable_style_frame = ttk.LabelFrame(tab_dynamic_paytable, text="Card Styling")
    paytable_style_frame.pack(fill="x", padx=10, pady=(0, 8))
    ttk.Label(paytable_style_frame, text="Fallback symbol size:").grid(row=0, column=0, sticky="w", padx=10, pady=(12, 6))
    dynamic_fallback_size_spin = ttk.Spinbox(paytable_style_frame, from_=20, to=500, width=7); dynamic_fallback_size_spin.set(110); dynamic_fallback_size_spin.grid(row=0, column=1, sticky="w", pady=(12, 6))
    dynamic_fallback_color_btn = tk.Button(paytable_style_frame, text="      ", bg=dynamic_fallback_color_var.get(), relief="ridge", width=6, command=lambda: _pick_rgb("Fallback Symbol Color", dynamic_fallback_rgb_val, dynamic_fallback_color_var, dynamic_fallback_color_btn))
    dynamic_fallback_color_btn.grid(row=0, column=2, sticky="w", pady=(12, 6))
    ttk.Label(paytable_style_frame, text="Top-card background:").grid(row=1, column=0, sticky="w", padx=10, pady=6)
    dynamic_top_bg_color_btn = tk.Button(paytable_style_frame, text="      ", bg=dynamic_top_bg_color_var.get(), relief="ridge", width=6, command=lambda: _pick_rgb("Top Card Background", dynamic_top_bg_rgb_val, dynamic_top_bg_color_var, dynamic_top_bg_color_btn))
    dynamic_top_bg_color_btn.grid(row=1, column=1, sticky="w", pady=6)
    dynamic_top_bg_opacity_spin = ttk.Spinbox(paytable_style_frame, from_=0, to=100, width=7); dynamic_top_bg_opacity_spin.set(65); dynamic_top_bg_opacity_spin.grid(row=1, column=2, sticky="w", pady=6)
    ttk.Label(paytable_style_frame, text="Opacity").grid(row=1, column=3, sticky="w", pady=6)
    ttk.Label(paytable_style_frame, text="Lower-card background:").grid(row=2, column=0, sticky="w", padx=10, pady=6)
    dynamic_lower_bg_color_btn = tk.Button(paytable_style_frame, text="      ", bg=dynamic_lower_bg_color_var.get(), relief="ridge", width=6, command=lambda: _pick_rgb("Lower Card Background", dynamic_lower_bg_rgb_val, dynamic_lower_bg_color_var, dynamic_lower_bg_color_btn))
    dynamic_lower_bg_color_btn.grid(row=2, column=1, sticky="w", pady=6)
    dynamic_lower_bg_opacity_spin = ttk.Spinbox(paytable_style_frame, from_=0, to=100, width=7); dynamic_lower_bg_opacity_spin.set(65); dynamic_lower_bg_opacity_spin.grid(row=2, column=2, sticky="w", pady=6)
    ttk.Label(paytable_style_frame, text="Opacity").grid(row=2, column=3, sticky="w", pady=6)
    ttk.Label(paytable_style_frame, text="Card stroke:").grid(row=3, column=0, sticky="w", padx=10, pady=6)
    dynamic_card_stroke_color_btn = tk.Button(paytable_style_frame, text="      ", bg=dynamic_card_stroke_color_var.get(), relief="ridge", width=6, command=lambda: _pick_rgb("Card Stroke", dynamic_card_stroke_rgb_val, dynamic_card_stroke_color_var, dynamic_card_stroke_color_btn))
    dynamic_card_stroke_color_btn.grid(row=3, column=1, sticky="w", pady=6)
    dynamic_card_stroke_width_spin = ttk.Spinbox(paytable_style_frame, from_=0, to=30, width=7); dynamic_card_stroke_width_spin.set(0); dynamic_card_stroke_width_spin.grid(row=3, column=2, sticky="w", pady=6)
    ttk.Label(paytable_style_frame, text="Width (0 = off)").grid(row=3, column=3, sticky="w", pady=6)
    ttk.Label(paytable_style_frame, text="Wild title size:").grid(row=4, column=0, sticky="w", padx=10, pady=6)
    dynamic_wild_title_size_spin = ttk.Spinbox(paytable_style_frame, from_=8, to=300, width=7); dynamic_wild_title_size_spin.set(72); dynamic_wild_title_size_spin.grid(row=4, column=1, sticky="w", pady=6)
    dynamic_wild_title_color_btn = tk.Button(paytable_style_frame, text="      ", bg=dynamic_wild_title_color_var.get(), relief="ridge", width=6, command=lambda: _pick_rgb("Wild Title Color", dynamic_wild_title_rgb_val, dynamic_wild_title_color_var, dynamic_wild_title_color_btn))
    dynamic_wild_title_color_btn.grid(row=4, column=2, sticky="w", pady=6)
    ttk.Label(paytable_style_frame, text="Side-panel text size:").grid(row=5, column=0, sticky="w", padx=10, pady=6)
    dynamic_wild_text_size_spin = ttk.Spinbox(paytable_style_frame, from_=8, to=200, width=7); dynamic_wild_text_size_spin.set(30); dynamic_wild_text_size_spin.grid(row=5, column=1, sticky="w", pady=6)
    dynamic_wild_text_color_btn = tk.Button(paytable_style_frame, text="      ", bg=dynamic_wild_text_color_var.get(), relief="ridge", width=6, command=lambda: _pick_rgb("Wild Panel Text Color", dynamic_wild_text_rgb_val, dynamic_wild_text_color_var, dynamic_wild_text_color_btn))
    dynamic_wild_text_color_btn.grid(row=5, column=2, sticky="w", pady=6)
    ttk.Label(paytable_style_frame, text="Bottom notes size:").grid(row=6, column=0, sticky="w", padx=10, pady=6)
    dynamic_notes_size_spin = ttk.Spinbox(paytable_style_frame, from_=8, to=200, width=7); dynamic_notes_size_spin.set(30); dynamic_notes_size_spin.grid(row=6, column=1, sticky="w", pady=6)
    dynamic_notes_color_btn = tk.Button(paytable_style_frame, text="      ", bg=dynamic_notes_color_var.get(), relief="ridge", width=6, command=lambda: _pick_rgb("Bottom Notes Color", dynamic_notes_rgb_val, dynamic_notes_color_var, dynamic_notes_color_btn))
    dynamic_notes_color_btn.grid(row=6, column=2, sticky="w", pady=6)
    ttk.Label(paytable_style_frame, text="Text panel (@slot.textBG):").grid(row=7, column=0, sticky="w", padx=10, pady=(6, 12))
    dynamic_text_bg_color_btn = tk.Button(paytable_style_frame, text="      ", bg=dynamic_text_bg_color_var.get(), relief="ridge", width=6, command=lambda: _pick_rgb("Paytable Text Panel Background", dynamic_text_bg_rgb_val, dynamic_text_bg_color_var, dynamic_text_bg_color_btn))
    dynamic_text_bg_color_btn.grid(row=7, column=1, sticky="w", pady=(6, 12))
    dynamic_text_bg_opacity_spin = ttk.Spinbox(paytable_style_frame, from_=0, to=100, width=7); dynamic_text_bg_opacity_spin.set(70); dynamic_text_bg_opacity_spin.grid(row=7, column=2, sticky="w", pady=(6, 12))
    ttk.Label(paytable_style_frame, text="Opacity").grid(row=7, column=3, sticky="w", pady=(6, 12))

    special_title_frame = ttk.LabelFrame(tab_dynamic_paytable, text="JSON Wild / Scatter Title Slots")
    special_title_frame.pack(fill="x", padx=10, pady=(0, 8))
    _make_toggle(special_title_frame, "Render @slot.wildTitle", dynamic_wild_title_slot_enabled_var, width=30).grid(row=0, column=0, sticky="w", padx=10, pady=(12, 6))
    ttk.Label(special_title_frame, text="Text:").grid(row=0, column=1, sticky="e", padx=(8, 4), pady=(12, 6))
    ttk.Entry(special_title_frame, textvariable=dynamic_wild_title_slot_text_var, width=20).grid(row=0, column=2, sticky="w", pady=(12, 6))
    _make_toggle(special_title_frame, "Render @slot.scatterTitle", dynamic_scatter_title_slot_enabled_var, width=30).grid(row=1, column=0, sticky="w", padx=10, pady=(0, 12))
    ttk.Label(special_title_frame, text="Text:").grid(row=1, column=1, sticky="e", padx=(8, 4), pady=(0, 12))
    ttk.Entry(special_title_frame, textvariable=dynamic_scatter_title_slot_text_var, width=20).grid(row=1, column=2, sticky="w", pady=(0, 12))
    ttk.Label(special_title_frame, text="Uses the main heading font, color, and saved/copied layer FX. Size uses the Wild title size above.", foreground="gray", wraplength=720).grid(row=2, column=0, columnspan=4, sticky="w", padx=10, pady=(0, 12))

    paytable_icon_frame = ttk.LabelFrame(tab_dynamic_paytable, text="Paytable Icon Layout")
    paytable_icon_frame.pack(fill="x", padx=10, pady=(0, 10))
    ttk.Label(paytable_icon_frame, text="Top symbol icon height:").grid(row=0, column=0, sticky="w", padx=10, pady=(12, 6))
    dynamic_top_icon_height_spin = ttk.Spinbox(paytable_icon_frame, from_=20, to=1200, width=7); dynamic_top_icon_height_spin.set(260); dynamic_top_icon_height_spin.grid(row=0, column=1, sticky="w", pady=(12, 6))
    ttk.Label(paytable_icon_frame, text="Target-canvas pixels").grid(row=0, column=2, columnspan=2, sticky="w", pady=(12, 6))
    ttk.Label(paytable_icon_frame, text="Lower symbol icon height:").grid(row=1, column=0, sticky="w", padx=10, pady=6)
    dynamic_lower_icon_height_spin = ttk.Spinbox(paytable_icon_frame, from_=20, to=1200, width=7); dynamic_lower_icon_height_spin.set(210); dynamic_lower_icon_height_spin.grid(row=1, column=1, sticky="w", pady=6)
    ttk.Label(paytable_icon_frame, text="Wild icon height:").grid(row=2, column=0, sticky="w", padx=10, pady=6)
    dynamic_wild_icon_height_spin = ttk.Spinbox(paytable_icon_frame, from_=20, to=1200, width=7); dynamic_wild_icon_height_spin.set(190); dynamic_wild_icon_height_spin.grid(row=2, column=1, sticky="w", pady=6)
    ttk.Label(paytable_icon_frame, text="Inline exception icon height:").grid(row=3, column=0, sticky="w", padx=10, pady=6)
    dynamic_inline_icon_height_spin = ttk.Spinbox(paytable_icon_frame, from_=8, to=500, width=7); dynamic_inline_icon_height_spin.set(54); dynamic_inline_icon_height_spin.grid(row=3, column=1, sticky="w", pady=6)
    ttk.Label(paytable_icon_frame, text="Inline icon gap:").grid(row=4, column=0, sticky="w", padx=10, pady=6)
    dynamic_inline_icon_gap_spin = ttk.Spinbox(paytable_icon_frame, from_=0, to=100, width=7); dynamic_inline_icon_gap_spin.set(8); dynamic_inline_icon_gap_spin.grid(row=4, column=1, sticky="w", pady=6)
    ttk.Label(paytable_icon_frame, text="Inline line height:").grid(row=5, column=0, sticky="w", padx=10, pady=6)
    dynamic_inline_line_height_spin = ttk.Spinbox(paytable_icon_frame, from_=0, to=500, width=7); dynamic_inline_line_height_spin.set(0); dynamic_inline_line_height_spin.grid(row=5, column=1, sticky="w", pady=6)
    ttk.Label(paytable_icon_frame, text="0 = automatic text line height; icons will not force huge line gaps.", foreground="gray").grid(row=5, column=2, columnspan=3, sticky="w", pady=6)

    custom_layout_pages = []
    page_override_intro = ttk.Label(tab_dynamic_pages, text="Optional per-page JSON overrides. Blank JSON uses the main JSON folder auto-match.", foreground="gray", wraplength=860)
    page_override_intro.pack(anchor="w", padx=10, pady=(10, 6))
    custom_pages_toolbar = ttk.Frame(tab_dynamic_pages)
    custom_pages_toolbar.pack(fill="x", padx=10, pady=(0, 8))
    custom_pages_nb = ttk.Notebook(tab_dynamic_pages)
    custom_pages_nb.pack(fill="both", expand=True, padx=10, pady=(0, 10))

    def _choose_page_json(target_var):
        path = filedialog.askopenfilename(filetypes=[("JSON", "*.json")])
        if path:
            target_var.set(path)

    def _add_custom_layout_page(name=None, json_path=""):
        if name is None:
            name = simpledialog.askstring("Custom Layout Page", "Excel tab name:")
        name = str(name or "").strip()
        if not name:
            return
        frame = ttk.Frame(custom_pages_nb)
        page_name_var = tk.StringVar(value=name)
        page_json_var = tk.StringVar(value=json_path)
        custom_pages_nb.add(frame, text=name)
        custom_layout_pages.append({
            "frame": frame,
            "name_var": page_name_var,
            "json_var": page_json_var,
        })
        ttk.Label(frame, text="Excel Tab Name:").grid(row=0, column=0, sticky="w", padx=10, pady=(12, 4))
        page_name_entry = ttk.Entry(frame, textvariable=page_name_var, width=28)
        page_name_entry.grid(row=0, column=1, sticky="w", pady=(12, 4))
        ttk.Label(frame, text="Specific JSON Override:").grid(row=1, column=0, sticky="w", padx=10, pady=4)
        ttk.Entry(frame, textvariable=page_json_var, state="readonly", width=56).grid(row=1, column=1, sticky="ew", pady=4)
        ttk.Button(frame, text="Browse", command=lambda: _choose_page_json(page_json_var)).grid(row=1, column=2, sticky="w", padx=5, pady=4)
        ttk.Button(frame, text="Remove", command=lambda: _clear_path(page_json_var)).grid(row=1, column=3, sticky="w", padx=5, pady=4)
        ttk.Label(
            frame,
            text="Blank JSON uses the main JSON folder auto-match. Save JSON as the exact Excel tab name, for example Paytable.json.",
            foreground="gray",
            wraplength=760,
        ).grid(row=2, column=0, columnspan=4, sticky="w", padx=10, pady=(4, 10))

        def _sync_tab_title(_event=None):
            new_name = page_name_var.get().strip() or "Custom"
            try:
                custom_pages_nb.tab(frame, text=new_name)
            except Exception:
                pass

        page_name_entry.bind("<KeyRelease>", _sync_tab_title)
        frame.columnconfigure(1, weight=1)

    def _remove_selected_custom_layout_page():
        selected = custom_pages_nb.select()
        if not selected:
            return
        for item in list(custom_layout_pages):
            if str(item["frame"]) == str(selected):
                custom_layout_pages.remove(item)
                break
        custom_pages_nb.forget(selected)

    def _reset_custom_layout_pages(saved_pages=None):
        for item in list(custom_layout_pages):
            try:
                custom_pages_nb.forget(item["frame"])
            except Exception:
                pass
        custom_layout_pages.clear()
        pages = saved_pages or [
            {"name": "Paytable", "json": ""},
            {"name": "Jackpot", "json": ""},
            {"name": "GameRules", "json": ""},
        ]
        for page in pages:
            _add_custom_layout_page(page.get("name", ""), page.get("json", ""))

    ttk.Button(custom_pages_toolbar, text="Add Custom Page", command=lambda: _add_custom_layout_page()).grid(row=0, column=0, sticky="w", padx=(0, 8))
    ttk.Button(custom_pages_toolbar, text="Remove Selected Page", command=_remove_selected_custom_layout_page).grid(row=0, column=1, sticky="w")
    _reset_custom_layout_pages()

    game_rules_frame = ttk.LabelFrame(tab_dynamic_rules, text="Game Rules Page Options")
    game_rules_frame.pack(fill="x", padx=10, pady=(10, 10))
    ttk.Label(game_rules_frame, text="Bottom-section font:").grid(row=0, column=0, sticky="w", padx=10, pady=(10, 4))
    game_rules_bottom_font_cb = ttk.Combobox(game_rules_frame, values=sys_fonts, width=24)
    game_rules_bottom_font_cb.grid(row=0, column=1, sticky="w", pady=(10, 4))
    game_rules_bottom_font_cb.bind("<KeyRelease>", lambda _event: _filter_font_combo(game_rules_bottom_font_cb))
    ttk.Combobox(game_rules_frame, textvariable=game_rules_bottom_font_style_var, values=FONT_STYLE_CHOICES, width=12, state="readonly").grid(row=0, column=2, sticky="w", padx=5, pady=(10, 4))
    ttk.Label(game_rules_frame, text="Bottom-section size:").grid(row=1, column=0, sticky="w", padx=10, pady=4)
    game_rules_bottom_size_spin = ttk.Spinbox(game_rules_frame, from_=8, to=250, width=7); game_rules_bottom_size_spin.set(30); game_rules_bottom_size_spin.grid(row=1, column=1, sticky="w", pady=4)
    ttk.Label(game_rules_frame, text="Gap before malfunction section:").grid(row=2, column=0, sticky="w", padx=10, pady=4)
    game_rules_bottom_gap_spin = ttk.Spinbox(game_rules_frame, from_=0, to=300, width=7); game_rules_bottom_gap_spin.set(26); game_rules_bottom_gap_spin.grid(row=2, column=1, sticky="w", pady=4)
    ttk.Label(game_rules_frame, text="Separator width / stroke:").grid(row=2, column=2, sticky="w", padx=10, pady=4)
    game_rules_separator_width_spin = ttk.Spinbox(game_rules_frame, from_=50, to=3000, width=8); game_rules_separator_width_spin.set(1000); game_rules_separator_width_spin.grid(row=2, column=3, sticky="w", pady=4)
    game_rules_separator_height_spin = ttk.Spinbox(game_rules_frame, from_=1, to=20, width=6); game_rules_separator_height_spin.set(2); game_rules_separator_height_spin.grid(row=2, column=4, sticky="w", padx=5, pady=4)
    ttk.Label(game_rules_frame, text="Separator color:").grid(row=3, column=0, sticky="w", padx=10, pady=4)
    game_rules_separator_color_btn = tk.Button(game_rules_frame, text="      ", bg=game_rules_separator_color_var.get(), relief="ridge", width=6,
                                               command=lambda: _pick_rgb("Game Rules Separator Color", game_rules_separator_rgb_val, game_rules_separator_color_var, game_rules_separator_color_btn))
    game_rules_separator_color_btn.grid(row=3, column=1, sticky="w", pady=4)
    ttk.Label(game_rules_frame, text="Separator placement / margin:").grid(row=3, column=2, sticky="w", padx=10, pady=4)
    ttk.Combobox(game_rules_frame, textvariable=game_rules_separator_alignment_var, values=ALIGN_CHOICES, width=10, state="readonly").grid(row=3, column=3, sticky="w", pady=4)
    game_rules_separator_margin_spin = ttk.Spinbox(game_rules_frame, from_=0, to=3000, width=7); game_rules_separator_margin_spin.set(80); game_rules_separator_margin_spin.grid(row=3, column=4, sticky="w", padx=5, pady=4)
    ttk.Label(game_rules_frame, text="Upper/body L/R margin:").grid(row=4, column=0, sticky="w", padx=10, pady=4)
    game_rules_bottom_lr_margin_spin = ttk.Spinbox(game_rules_frame, from_=0, to=3000, width=8); game_rules_bottom_lr_margin_spin.set(200); game_rules_bottom_lr_margin_spin.grid(row=4, column=1, sticky="w", pady=4)
    ttk.Label(game_rules_frame, text="Malfunction L/R margin:").grid(row=4, column=2, sticky="w", padx=10, pady=4)
    game_rules_malfunction_lr_margin_spin = ttk.Spinbox(game_rules_frame, from_=0, to=3000, width=8); game_rules_malfunction_lr_margin_spin.set(200); game_rules_malfunction_lr_margin_spin.grid(row=4, column=3, sticky="w", pady=4)
    ttk.Label(game_rules_frame, text="Icon-safe line height / dynamic blank line:").grid(row=5, column=0, sticky="w", padx=10, pady=4)
    game_rules_line_height_spin = ttk.Spinbox(game_rules_frame, from_=0, to=300, width=6); game_rules_line_height_spin.set(0); game_rules_line_height_spin.grid(row=5, column=1, sticky="w", pady=4)
    game_rules_dynamic_line_height_spin = ttk.Spinbox(game_rules_frame, from_=0, to=300, width=6); game_rules_dynamic_line_height_spin.set(0); game_rules_dynamic_line_height_spin.grid(row=5, column=2, sticky="w", padx=5, pady=4)
    ttk.Label(game_rules_frame, text="Malfunction paragraph line height:").grid(row=6, column=0, sticky="w", padx=10, pady=4)
    game_rules_malfunction_line_height_spin = ttk.Spinbox(game_rules_frame, from_=0, to=300, width=7); game_rules_malfunction_line_height_spin.set(0); game_rules_malfunction_line_height_spin.grid(row=6, column=1, sticky="w", pady=4)
    ttk.Label(game_rules_frame, text="0 = auto. Malfunction margin/line height affect only the lower legal paragraph.", foreground="gray").grid(row=6, column=2, columnspan=3, sticky="w", padx=10, pady=4)
    ttk.Label(
        game_rules_frame,
        text="Game Rules stays one page. Only <dynamic...> placeholders become blank spacing; normal <symbol> tokens still render as icons. Lower legal text is rendered as one centered paragraph block.",
        foreground="gray",
        wraplength=900,
    ).grid(row=7, column=0, columnspan=5, sticky="w", padx=10, pady=(4, 10))
    ttk.Label(game_rules_frame, text="Legal split overrides:").grid(row=8, column=0, sticky="nw", padx=10, pady=(4, 4))
    game_rules_legal_split_text = tk.Text(
        game_rules_frame,
        height=3,
        wrap="word",
        bg=palette["input_bg"],
        fg=palette["text"],
        insertbackground=palette["text"],
        relief="solid",
        bd=1,
        highlightthickness=0,
    )
    game_rules_legal_split_scroll = ttk.Scrollbar(game_rules_frame, orient="vertical", command=game_rules_legal_split_text.yview)
    game_rules_legal_split_text.configure(yscrollcommand=game_rules_legal_split_scroll.set)
    game_rules_legal_split_text.grid(row=8, column=1, columnspan=3, sticky="ew", padx=(0, 0), pady=(4, 4))
    game_rules_legal_split_scroll.grid(row=8, column=4, sticky="nsw", padx=(0, 10), pady=(4, 4))
    ttk.Label(
        game_rules_frame,
        text="Optional per sheet. Example: GameRules=B12; GameRules($1+)=B16. From that cell onward, text uses the lower legal style and gets a separator before it.",
        foreground="gray",
        wraplength=900,
    ).grid(row=9, column=0, columnspan=5, sticky="w", padx=10, pady=(0, 10))
    game_rules_frame.columnconfigure(1, weight=1)

    bingo_rules_frame = ttk.LabelFrame(tab_dynamic_bingo, text="Bingo Rules Page Options")
    bingo_rules_frame.pack(fill="x", padx=10, pady=(10, 10))
    _make_toggle(bingo_rules_frame, "Keep Bingo Rules on one page", bingo_rules_one_page_var, width=34).grid(row=0, column=0, columnspan=3, sticky="w", padx=10, pady=(12, 6))
    ttk.Label(bingo_rules_frame, text="Bingo body size:").grid(row=1, column=0, sticky="w", padx=10, pady=5)
    bingo_rules_body_size_spin = ttk.Spinbox(bingo_rules_frame, from_=0, to=250, width=7)
    bingo_rules_body_size_spin.set(0)
    bingo_rules_body_size_spin.grid(row=1, column=1, sticky="w", pady=5)
    ttk.Label(bingo_rules_frame, text="0 = use normal body size; one-page mode may shrink only Bingo text if needed.", foreground="gray").grid(row=1, column=2, sticky="w", padx=8, pady=5)
    ttk.Label(bingo_rules_frame, text="Main paragraph cells:").grid(row=2, column=0, sticky="w", padx=10, pady=5)
    ttk.Entry(bingo_rules_frame, textvariable=bingo_rules_body_ranges_var).grid(row=2, column=1, columnspan=2, sticky="ew", padx=(0, 10), pady=5)
    ttk.Label(
        bingo_rules_frame,
        text="Optional. Blank = auto. Examples: Bingo Rules=B5:H24; BingoRules=B3:H66.",
        foreground="gray",
        wraplength=900,
    ).grid(row=3, column=1, columnspan=3, sticky="w", pady=(0, 6))
    ttk.Label(bingo_rules_frame, text="Footer/alignment overrides:").grid(row=4, column=0, sticky="nw", padx=10, pady=(6, 4))
    bingo_rules_alignment_text = tk.Text(
        bingo_rules_frame,
        height=3,
        wrap="word",
        bg=palette["input_bg"],
        fg=palette["text"],
        insertbackground=palette["text"],
        relief="solid",
        bd=1,
        highlightthickness=0,
    )
    bingo_rules_alignment_scroll = ttk.Scrollbar(bingo_rules_frame, orient="vertical", command=bingo_rules_alignment_text.yview)
    bingo_rules_alignment_text.configure(yscrollcommand=bingo_rules_alignment_scroll.set)
    bingo_rules_alignment_text.grid(row=4, column=1, columnspan=2, sticky="ew", padx=(0, 0), pady=(6, 4))
    bingo_rules_alignment_scroll.grid(row=4, column=3, sticky="nsw", padx=(0, 10), pady=(6, 4))
    ttk.Label(
        bingo_rules_frame,
        text="Optional. Examples: Bingo Rules=B25:left:80:80; Bingo Rules=H25:H26:right:80:80. Footer cells are vertically centered together.",
        foreground="gray",
        wraplength=900,
    ).grid(row=5, column=1, columnspan=3, sticky="w", pady=(0, 10))

    bingo_rules_left_margin_var = tk.StringVar(value="0")
    bingo_rules_line_spacing_var = tk.StringVar(value="0")
    bingo_rules_para_spacing_var = tk.StringVar(value="0")
    bingo_rules_bottom_margin_var = tk.StringVar(value="0")
    ttk.Separator(bingo_rules_frame, orient="horizontal").grid(row=6, column=0, columnspan=4, sticky="ew", pady=6)
    ttk.Label(bingo_rules_frame, text="Bingo-specific overrides (0 = use global):").grid(row=7, column=0, columnspan=4, sticky="w", padx=10, pady=(4, 4))
    ttk.Label(bingo_rules_frame, text="L/R margin:").grid(row=8, column=0, sticky="w", padx=10, pady=3)
    bingo_rules_left_margin_spin = ttk.Spinbox(bingo_rules_frame, from_=0, to=500, width=7, textvariable=bingo_rules_left_margin_var)
    bingo_rules_left_margin_spin.grid(row=8, column=1, sticky="w", pady=3)
    ttk.Label(bingo_rules_frame, text="Line spacing:").grid(row=8, column=2, sticky="w", padx=(20, 0), pady=3)
    bingo_rules_line_spacing_spin = ttk.Spinbox(bingo_rules_frame, from_=0, to=200, width=7, textvariable=bingo_rules_line_spacing_var)
    bingo_rules_line_spacing_spin.grid(row=8, column=3, sticky="w", pady=3)
    ttk.Label(bingo_rules_frame, text="Para spacing:").grid(row=9, column=0, sticky="w", padx=10, pady=3)
    bingo_rules_para_spacing_spin = ttk.Spinbox(bingo_rules_frame, from_=0, to=200, width=7, textvariable=bingo_rules_para_spacing_var)
    bingo_rules_para_spacing_spin.grid(row=9, column=1, sticky="w", pady=3)
    ttk.Label(bingo_rules_frame, text="Bottom margin:").grid(row=9, column=2, sticky="w", padx=(20, 0), pady=3)
    bingo_rules_bottom_margin_spin = ttk.Spinbox(bingo_rules_frame, from_=0, to=500, width=7, textvariable=bingo_rules_bottom_margin_var)
    bingo_rules_bottom_margin_spin.grid(row=9, column=3, sticky="w", pady=3)
    bingo_rules_frame.columnconfigure(1, weight=1)

    xtra_reels_frame = ttk.LabelFrame(tab_dynamic_rules, text="XTRAA REELS Side Icons")
    xtra_reels_frame.pack(fill="x", padx=10, pady=(0, 10))
    _make_toggle(xtra_reels_frame, "Render Game Rules with XTRAA REELS icons", game_rules_xtra_reels_enabled_var, width=44).grid(row=0, column=0, columnspan=4, sticky="w", padx=10, pady=(12, 6))
    ttk.Label(xtra_reels_frame, text="Icon asset:").grid(row=1, column=0, sticky="w", padx=10, pady=6)
    ttk.Entry(xtra_reels_frame, textvariable=game_rules_xtra_reels_asset_var, state="readonly", width=60).grid(row=1, column=1, sticky="ew", pady=6)

    def _choose_game_rules_xtra_reels_asset():
        path = filedialog.askopenfilename(filetypes=[("Image assets", "*.png;*.jpg;*.jpeg;*.psd"), ("All files", "*.*")])
        if path:
            game_rules_xtra_reels_asset_var.set(path)

    ttk.Button(xtra_reels_frame, text="Browse", command=_choose_game_rules_xtra_reels_asset).grid(row=1, column=2, padx=5, pady=6)
    ttk.Button(xtra_reels_frame, text="Remove", style="Danger.TButton", command=lambda: _clear_path(game_rules_xtra_reels_asset_var)).grid(row=1, column=3, padx=(0, 10), pady=6)
    ttk.Label(xtra_reels_frame, text="Each icon width:").grid(row=2, column=0, sticky="w", padx=10, pady=6)
    game_rules_xtra_reels_width_spin = ttk.Spinbox(xtra_reels_frame, from_=10, to=2000, width=8); game_rules_xtra_reels_width_spin.set(100); game_rules_xtra_reels_width_spin.grid(row=2, column=1, sticky="w", pady=6)
    ttk.Label(xtra_reels_frame, text="Outer canvas margin:").grid(row=2, column=2, sticky="e", padx=(10, 5), pady=6)
    game_rules_xtra_reels_outer_margin_spin = ttk.Spinbox(xtra_reels_frame, from_=0, to=1500, width=8); game_rules_xtra_reels_outer_margin_spin.set(100); game_rules_xtra_reels_outer_margin_spin.grid(row=2, column=3, sticky="w", padx=(0, 10), pady=6)
    ttk.Label(xtra_reels_frame, text="Text clearance from icon:").grid(row=3, column=0, sticky="w", padx=10, pady=6)
    game_rules_xtra_reels_text_gap_spin = ttk.Spinbox(xtra_reels_frame, from_=0, to=1000, width=8); game_rules_xtra_reels_text_gap_spin.set(50); game_rules_xtra_reels_text_gap_spin.grid(row=3, column=1, sticky="w", pady=6)
    ttk.Label(xtra_reels_frame, text="Vertical offset:").grid(row=3, column=2, sticky="e", padx=(10, 5), pady=6)
    game_rules_xtra_reels_y_offset_spin = ttk.Spinbox(xtra_reels_frame, from_=-1000, to=1000, width=8); game_rules_xtra_reels_y_offset_spin.set(0); game_rules_xtra_reels_y_offset_spin.grid(row=3, column=3, sticky="w", padx=(0, 10), pady=6)
    ttk.Label(xtra_reels_frame, text="The same asset is placed left and right. Text width reserves outer margin + icon width + clearance on both sides. Vertical offset 0 centers the icons beside the main rules text.", foreground="gray", wraplength=900).grid(row=4, column=0, columnspan=4, sticky="w", padx=10, pady=(4, 12))
    xtra_reels_frame.columnconfigure(1, weight=1)

    # Icons / global defaults
    tab_icon_defaults_tab = ttk.Frame(icons_nb)
    icons_nb.add(tab_icon_defaults_tab, text="Defaults")
    _icon_defaults_scroll_host, tab_icon_defaults = _make_scrollable_host(tab_icon_defaults_tab, palette["app_bg"])
    _icon_defaults_scroll_host.pack(fill="both", expand=True)
    default_icon_frame = ttk.LabelFrame(tab_icon_defaults, text="Default Icon Sizing")
    default_icon_frame.pack(fill="x", padx=10, pady=(10, 8))
    ttk.Label(default_icon_frame, text="Heading inline icon height:").grid(row=0, column=0, sticky="w", padx=10, pady=(12, 6))
    h_icon_spin = ttk.Spinbox(default_icon_frame, from_=10, to=300, width=7); h_icon_spin.set(55); h_icon_spin.grid(row=0, column=1, sticky="w", pady=(12, 6))
    ttk.Label(default_icon_frame, text="Body inline icon height:").grid(row=1, column=0, sticky="w", padx=10, pady=6)
    b_icon_spin = ttk.Spinbox(default_icon_frame, from_=10, to=300, width=7); b_icon_spin.set(45); b_icon_spin.grid(row=1, column=1, sticky="w", pady=6)
    _make_toggle(default_icon_frame, "Use original source size for body icons", body_icon_original_size_var, width=44).grid(row=2, column=0, columnspan=3, sticky="w", padx=10, pady=6)
    ttk.Label(default_icon_frame, text="Heading icons always use the heading height. Body icons use custom body-size overrides first; otherwise this toggle can keep the source icon height.", foreground="gray", wraplength=780).grid(row=3, column=0, columnspan=3, sticky="w", padx=10, pady=(0, 12))

    placement_icon_frame = ttk.LabelFrame(tab_icon_defaults, text="Inline Icon Placement")
    placement_icon_frame.pack(fill="x", padx=10, pady=(0, 8))
    ttk.Label(placement_icon_frame, text="Icon left / right gap:").grid(row=0, column=0, sticky="w", padx=10, pady=(12, 6))
    gap_spin = ttk.Spinbox(placement_icon_frame, from_=0, to=100, width=7); gap_spin.set(0); gap_spin.grid(row=0, column=1, sticky="w", pady=(12, 6))
    ttk.Label(placement_icon_frame, text="Icon Y-offset:").grid(row=1, column=0, sticky="w", padx=10, pady=6)
    yoff_spin = ttk.Spinbox(placement_icon_frame, from_=-50, to=50, width=7); yoff_spin.set(0); yoff_spin.grid(row=1, column=1, sticky="w", pady=6)
    ttk.Label(placement_icon_frame, text="Use this when symbols need tiny visual nudges without changing text layout.", foreground="gray", wraplength=760).grid(row=2, column=0, columnspan=3, sticky="w", padx=10, pady=(0, 12))

    icon_fx_frame = ttk.LabelFrame(tab_icon_defaults, text="Optional Icon Layer Style")
    icon_fx_frame.pack(fill="x", padx=10, pady=(0, 8))
    _make_toggle(icon_fx_frame, "Apply a saved layer style to body icons", icon_layer_style_enabled_var, width=42).grid(row=0, column=0, columnspan=2, sticky="w", padx=10, pady=(12, 6))
    ttk.Label(icon_fx_frame, text="Saved style:").grid(row=1, column=0, sticky="w", padx=10, pady=(0, 12))
    icon_saved_style_cb = ttk.Combobox(icon_fx_frame, textvariable=icon_saved_style_var, width=32, state="readonly")
    icon_saved_style_cb.grid(row=1, column=1, sticky="w", padx=5, pady=(0, 12))
    ttk.Label(icon_fx_frame, text="Off by default. Styles are created and captured in Heading or Body Text.", foreground="gray").grid(row=1, column=2, sticky="w", padx=8, pady=(0, 12))

    # Icon Mapping. Treeview is used instead of thousands of Browse widgets,
    # so very large workbooks remain responsive.
    tab_mapping_tab = ttk.Frame(icons_nb)
    icons_nb.add(tab_mapping_tab, text="Icon Mapping")
    _mapping_scroll_host, tab_mapping = _make_scrollable_host(tab_mapping_tab, palette["app_bg"])
    _mapping_scroll_host.pack(fill="both", expand=True)
    ttk.Label(
        tab_mapping,
        text="Scans every unique <icon_name> in the Excel. Select a row, then map it from the Icons Folder dropdown or browse any file. Body icon size overrides apply to normal body text only; heading, table, and paytable icons use their own size controls.",
        foreground="gray", wraplength=790,
    ).grid(row=0, column=0, columnspan=5, sticky="w", padx=10, pady=(10, 6))

    mapping_tree = ttk.Treeview(tab_mapping, columns=("Token", "Mapped Asset", "Custom Size", "Status", "Mode"), show="headings", height=24)
    mapping_tree.heading("Token", text="Excel pointer")
    mapping_tree.heading("Mapped Asset", text="Asset used")
    mapping_tree.heading("Custom Size", text="Body size")
    mapping_tree.heading("Status", text="Available")
    mapping_tree.heading("Mode", text="Mode")
    mapping_tree.column("Token", width=210, anchor="w")
    mapping_tree.column("Mapped Asset", width=390, anchor="w")
    mapping_tree.column("Custom Size", width=110, anchor="center")
    mapping_tree.column("Status", width=110, anchor="center")
    mapping_tree.column("Mode", width=90, anchor="center")
    mapping_scroll = ttk.Scrollbar(tab_mapping, orient="vertical", command=mapping_tree.yview)
    mapping_tree.configure(yscrollcommand=mapping_scroll.set)
    mapping_tree.grid(row=1, column=0, columnspan=4, sticky="nsew", padx=(10, 0), pady=5)
    mapping_scroll.grid(row=1, column=4, sticky="ns", padx=(0, 10), pady=5)

    mapping_toolbar = ttk.Frame(tab_mapping)
    mapping_toolbar.grid(row=2, column=0, columnspan=5, sticky="ew", padx=10, pady=5)
    ttk.Button(mapping_toolbar, text="Scan Excel", command=lambda: _scan_mapping_tokens(show_message=True)).grid(row=0, column=0, padx=(0, 8))
    ttk.Button(mapping_toolbar, text="Refresh Icons Folder", command=lambda: (_refresh_mapping_choices(), _refresh_mapping_tree())).grid(row=0, column=1, padx=(0, 8))
    ttk.Label(mapping_toolbar, textvariable=mapping_selected_token_var, style="FieldLabel.TLabel").grid(row=0, column=2, padx=(15, 8))

    mapping_editor = ttk.Frame(tab_mapping)
    mapping_editor.grid(row=3, column=0, columnspan=5, sticky="ew", padx=10, pady=(4, 12))
    ttk.Label(mapping_editor, text="Icons Folder asset:").grid(row=0, column=0, sticky="w")
    mapping_choice_cb = ttk.Combobox(mapping_editor, textvariable=mapping_choice_var, state="readonly", width=42)
    mapping_choice_cb.grid(row=0, column=1, padx=5, sticky="w")
    ttk.Button(mapping_editor, text="Apply Dropdown", command=lambda: _apply_mapping_dropdown()).grid(row=0, column=2, padx=4)
    ttk.Button(mapping_editor, text="Browse File", command=lambda: _browse_mapping_file()).grid(row=0, column=3, padx=4)
    ttk.Button(mapping_editor, text="✕ Clear Override", command=lambda: _clear_mapping()).grid(row=0, column=4, padx=4)
    ttk.Label(mapping_editor, text="Body icon size px:").grid(row=1, column=0, sticky="w", pady=(8,0))
    ttk.Entry(mapping_editor, textvariable=mapping_size_var, width=10).grid(row=1, column=1, sticky="w", padx=5, pady=(8,0))
    ttk.Button(mapping_editor, text="Apply Size", command=lambda: _apply_mapping_size()).grid(row=1, column=2, padx=4, pady=(8,0))
    ttk.Button(mapping_editor, text="Clear Size", command=lambda: _clear_mapping_size()).grid(row=1, column=3, padx=4, pady=(8,0))
    ttk.Label(mapping_editor, text="Blank = use default body icon height. Heading/table/paytable icons are not affected.", foreground="gray").grid(row=1, column=4, sticky="w", pady=(8,0))

    def _selected_mapping_token():
        tree = mapping_tree
        selection = mapping_tree.selection()
        if not selection and missing_icon_tree is not None:
            selection = missing_icon_tree.selection()
            tree = missing_icon_tree
        if not selection:
            return ""
        values = tree.item(selection[0]).get("values", [])
        return str(values[0]) if values else ""

    def _refresh_mapping_choices():
        choices = list_icon_files(icon_var.get())
        mapping_choice_cb["values"] = choices
        try:
            missing_choice_cb["values"] = choices
        except Exception:
            pass
        if mapping_choice_var.get() not in choices:
            mapping_choice_var.set("")

    def _icon_status_rows():
        combined = list(icon_tokens)
        seen = {normalize_token(token) for token in combined}
        for token in icon_mappings:
            if normalize_token(token) not in seen:
                combined.append(token)
                seen.add(normalize_token(token))
        rows = []
        for token in combined:
            override = next((value for key, value in icon_mappings.items() if normalize_token(key) == normalize_token(token)), "")
            resolved = resolve_icon_path(token, icon_var.get(), icon_mappings)
            if override:
                display = os.path.basename(override) if os.path.dirname(override) else override
                mode = "Override"
                if resolved:
                    if os.path.basename(resolved).casefold() == os.path.basename(override).casefold():
                        status = "Found"
                    else:
                        status = "Override missing"
                        display = f"{display}  → fallback: {os.path.basename(resolved)}"
                else:
                    status = "Missing"
            else:
                mode = "Default"
                if resolved:
                    display = os.path.basename(resolved)
                    status = "Found"
                else:
                    display = f"{token}.png (normal lookup)"
                    status = "Missing"
            size_value = ""
            for size_key, size_override in icon_size_overrides.items():
                if normalize_token(size_key) == normalize_token(token):
                    size_value = str(size_override)
                    break
            rows.append((token, display, size_value, status, mode, resolved or ""))
        return rows

    def _fill_icon_tree(tree, rows):
        if tree is None:
            return
        for item in tree.get_children():
            tree.delete(item)
        for row in rows:
            tree.insert("", "end", values=row[:5])

    def _refresh_mapping_tree():
        rows = _icon_status_rows()
        _fill_icon_tree(mapping_tree, rows)
        _fill_icon_tree(missing_icon_tree, rows)
        missing_count = sum(1 for row in rows if row[3] == "Missing")
        if missing_count:
            try:
                status_var.set(f"Icon scan: {missing_count} missing icon(s)")
            except Exception:
                pass

    def _scan_mapping_tokens(show_message=False):
        path = excel_var.get()
        if not path or not os.path.isfile(path):
            if show_message:
                messagebox.showwarning("Icon Mapping", "Select an Excel file first.")
            return
        icon_tokens[:] = scan_excel_icon_tokens(path)
        _refresh_mapping_choices()
        _refresh_mapping_tree()
        if show_message:
            messagebox.showinfo("Icon Mapping", f"Loaded {len(icon_tokens)} unique icon pointer(s).")

    def _on_mapping_select(_event=None):
        token = _selected_mapping_token()
        mapping_selected_token_var.set(f"Selected: <{token}>" if token else "No token selected")
        override = next((value for key, value in icon_mappings.items() if normalize_token(key) == normalize_token(token)), "")
        basename = os.path.basename(override) if override else ""
        mapping_choice_var.set(basename if basename in list(mapping_choice_cb["values"]) else "")
        size_val = ""
        for key, value in icon_size_overrides.items():
            if normalize_token(key) == normalize_token(token):
                size_val = str(value)
                break
        mapping_size_var.set(size_val)

    def _set_mapping(token, path):
        if not token:
            messagebox.showwarning("Icon Mapping", "Select an icon pointer row first.")
            return
        # Replace any differently-cased key for the same token.
        for key in list(icon_mappings):
            if normalize_token(key) == normalize_token(token):
                del icon_mappings[key]
        if path:
            icon_mappings[token] = path
        _refresh_mapping_tree()

    def _apply_mapping_dropdown():
        token = _selected_mapping_token()
        filename = mapping_choice_var.get().strip()
        if not filename:
            messagebox.showwarning("Icon Mapping", "Choose an asset from the dropdown first.")
            return
        _set_mapping(token, filename)

    def _browse_mapping_file():
        token = _selected_mapping_token()
        if not token:
            messagebox.showwarning("Icon Mapping", "Select an icon pointer row first.")
            return
        path = filedialog.askopenfilename(filetypes=[("Images / PSD", "*.png;*.jpg;*.jpeg;*.psd"), ("All files", "*.*")])
        if path:
            _set_mapping(token, path)

    def _clear_mapping():
        token = _selected_mapping_token()
        _set_mapping(token, "")
        mapping_choice_var.set("")

    def _apply_mapping_size():
        token = _selected_mapping_token()
        if not token:
            messagebox.showwarning("Icon Size", "Select an icon pointer row first.")
            return
        raw = mapping_size_var.get().strip()
        if not raw:
            _clear_mapping_size()
            return
        try:
            size = int(float(raw))
            if size <= 0:
                raise ValueError
        except Exception:
            messagebox.showwarning("Icon Size", "Enter a positive pixel size, for example 54 or 120.")
            return
        for key in list(icon_size_overrides):
            if normalize_token(key) == normalize_token(token):
                del icon_size_overrides[key]
        icon_size_overrides[token] = size
        _refresh_mapping_tree()

    def _clear_mapping_size():
        token = _selected_mapping_token()
        for key in list(icon_size_overrides):
            if normalize_token(key) == normalize_token(token):
                del icon_size_overrides[key]
        mapping_size_var.set("")
        _refresh_mapping_tree()

    mapping_tree.bind("<<TreeviewSelect>>", _on_mapping_select)
    tab_mapping.grid_rowconfigure(1, weight=1)
    tab_mapping.grid_columnconfigure(3, weight=1)

    # Production Missing Icon Manager. Uses the same mapping dictionaries as the Icons tab.
    missing_panel = ttk.LabelFrame(tab_missing_icons, text="Missing Icon Manager")
    missing_panel.pack(fill="both", expand=True, padx=10, pady=(10, 8))
    ttk.Label(
        missing_panel,
        text="Scan Excel tokens, check found/missing icon status, map a specific token to an asset, and add body-text-only icon size overrides.",
        foreground="gray",
        wraplength=900,
    ).grid(row=0, column=0, columnspan=6, sticky="w", padx=10, pady=(12, 8))
    ttk.Button(missing_panel, text="Scan Excel Icons", command=lambda: _scan_mapping_tokens(show_message=True)).grid(row=1, column=0, sticky="w", padx=10, pady=5)
    ttk.Button(missing_panel, text="Select All Missing", command=lambda: [missing_icon_tree.selection_add(item) for item in missing_icon_tree.get_children() if missing_icon_tree.item(item).get("values", ["", "", "", ""])[3] == "Missing"] if missing_icon_tree is not None else None).grid(row=1, column=1, sticky="w", padx=5, pady=5)
    missing_icon_tree = ttk.Treeview(missing_panel, columns=("Token", "Asset", "Size", "Status", "Mode"), show="headings", height=16)
    for col, width in (("Token", 180), ("Asset", 320), ("Size", 80), ("Status", 110), ("Mode", 110)):
        missing_icon_tree.heading(col, text=col)
        missing_icon_tree.column(col, width=width, anchor="w")
    missing_icon_tree.heading("Size", text="Body size")
    missing_icon_tree.grid(row=2, column=0, columnspan=5, sticky="nsew", padx=(10, 0), pady=8)
    missing_scroll = ttk.Scrollbar(missing_panel, orient="vertical", command=missing_icon_tree.yview)
    missing_scroll.grid(row=2, column=5, sticky="ns", padx=(0, 10), pady=8)
    missing_icon_tree.configure(yscrollcommand=missing_scroll.set)

    missing_editor = ttk.Frame(missing_panel)
    missing_editor.grid(row=3, column=0, columnspan=6, sticky="ew", padx=10, pady=(4, 12))
    missing_editor.columnconfigure(4, weight=1)
    ttk.Label(missing_editor, textvariable=mapping_selected_token_var, style="FieldLabel.TLabel").grid(row=0, column=0, columnspan=5, sticky="w", pady=(0, 8))
    ttk.Label(missing_editor, text="Icons Folder asset:").grid(row=1, column=0, sticky="w")
    missing_choice_cb = ttk.Combobox(missing_editor, textvariable=mapping_choice_var, width=32)
    missing_choice_cb.grid(row=1, column=1, padx=5, sticky="w")
    ttk.Button(missing_editor, text="Apply Mapping", command=lambda: _apply_mapping_dropdown()).grid(row=1, column=2, padx=4)
    ttk.Button(missing_editor, text="Browse", command=lambda: _browse_mapping_file()).grid(row=1, column=3, padx=4)
    ttk.Button(missing_editor, text="Clear Mapping", command=lambda: _clear_mapping()).grid(row=1, column=4, padx=4, sticky="w")
    ttk.Label(missing_editor, text="Body icon size px:").grid(row=2, column=0, sticky="w", pady=(8, 0))
    ttk.Entry(missing_editor, textvariable=mapping_size_var, width=10).grid(row=2, column=1, sticky="w", padx=5, pady=(8, 0))
    ttk.Button(missing_editor, text="Apply Size", command=lambda: _apply_mapping_size()).grid(row=2, column=2, padx=4, pady=(8, 0))
    ttk.Button(missing_editor, text="Clear Size", command=lambda: _clear_mapping_size()).grid(row=2, column=3, padx=4, pady=(8, 0))
    missing_icon_preview_label = ttk.Label(missing_editor, text="Preview appears here when Tk can load the selected image.", foreground="gray")
    missing_icon_preview_label.grid(row=3, column=0, columnspan=5, sticky="w", pady=(12, 0))

    def _on_missing_icon_select(_event=None):
        try:
            mapping_tree.selection_remove(mapping_tree.selection())
        except Exception:
            pass
        _on_mapping_select()
        token = _selected_mapping_token()
        resolved = resolve_icon_path(token, icon_var.get(), icon_mappings)
        if not resolved:
            missing_icon_preview_ref["image"] = None
            missing_icon_preview_label.configure(image="", text="No preview: icon is missing or unmapped.")
            return
        try:
            img = tk.PhotoImage(file=resolved)
            while img.width() > 180 or img.height() > 120:
                img = img.subsample(2, 2)
            missing_icon_preview_ref["image"] = img
            missing_icon_preview_label.configure(image=img, text="")
        except Exception:
            missing_icon_preview_ref["image"] = None
            missing_icon_preview_label.configure(image="", text=f"Preview unavailable: {os.path.basename(resolved)}")

    missing_icon_tree.bind("<<TreeviewSelect>>", _on_missing_icon_select)
    missing_panel.rowconfigure(2, weight=1)
    missing_panel.columnconfigure(4, weight=1)

    # Heading layer styles: kept inside the Heading tab so all heading-related
    # controls live together instead of being split across separate tabs.
    tab_style = ttk.LabelFrame(tab_head, text="Heading Layer Style / FX")
    tab_style.grid(row=14, column=0, columnspan=5, sticky="ew", padx=10, pady=(12, 10))

    def _refresh_heading_style_status(*_args):
        style_name = copied_heading_style_name_var.get().strip() or "Copied Photoshop layer style"
        captured = " Exact copied FX captured." if heading_captured_style.get("hex") else ""
        if paste_heading_style_var.get():
            heading_style_status_var.set(f"{style_name}: current Photoshop clipboard FX will be pasted.{captured}")
        else:
            heading_style_status_var.set(f"{style_name}: live clipboard paste is off.{captured}")

    def _clear_heading_layer_styles():
        paste_heading_style_var.set(False)
        heading_captured_style["hex"] = ""
        heading_captured_style["params"] = {}
        copied_heading_style_name_var.set("Copied Photoshop layer style")
        layer_style_assignments.pop("Heading text", None)
        heading_saved_style_var.set("")
        h_stroke_enable_var.set(False)
        h_shadow_enable_var.set(False)
        h_stroke_rgb_val[:] = [255, 255, 255]
        h_shadow_rgb_val[:] = [0, 0, 0]
        h_stroke_color_var.set("#FFFFFF")
        h_shadow_color_var.set("#000000")
        _set_btn_color(h_stroke_color_btn, h_stroke_color_var.get())
        _set_btn_color(h_shadow_color_btn, h_shadow_color_var.get())
        h_stroke_size_spin.set(3)
        h_stroke_opacity_spin.set(100)
        h_shadow_blend_var.set("Multiply")
        h_shadow_opacity_spin.set(60)
        h_shadow_distance_spin.set(8)
        h_shadow_size_spin.set(12)
        h_shadow_angle_spin.set(120)
        h_shadow_spread_spin.set(0)
        _refresh_heading_style_status()
        try:
            _refresh_named_style_choices()
            _save_current_session()
        except Exception:
            pass
        style_manager_status_var.set("Heading text layer style cleared. Headings will render with no saved FX unless reassigned.")

    paste_heading_style_var.trace_add("write", _refresh_heading_style_status)
    copied_heading_style_name_var.trace_add("write", _refresh_heading_style_status)

    _make_toggle(tab_style, "Paste copied Photoshop style", paste_heading_style_var, _refresh_heading_style_status, width=34).grid(row=0, column=0, columnspan=2, sticky="w", padx=10, pady=(12, 6))
    ttk.Label(tab_style, text="Style label:").grid(row=0, column=2, sticky="e", padx=(10, 5), pady=(12, 6))
    ttk.Entry(tab_style, textvariable=copied_heading_style_name_var, width=28).grid(row=0, column=3, sticky="ew", pady=(12, 6))
    ttk.Button(tab_style, text="Clear Layer Styles", command=_clear_heading_layer_styles).grid(row=0, column=4, sticky="w", padx=8, pady=(12, 6))
    ttk.Label(tab_style, textvariable=heading_style_status_var, foreground="gray", wraplength=820).grid(row=1, column=0, columnspan=5, sticky="w", padx=10, pady=(0, 4))
    ttk.Label(tab_style, text="Photoshop copied styles can include stroke, shadow, bevel, glow, and other FX. Copy the style in Photoshop, enable this toggle, and the setting is remembered with the session.", foreground="gray", wraplength=820).grid(row=2, column=0, columnspan=5, sticky="w", padx=10, pady=(0, 12))

    _make_toggle(tab_style, "Manual Stroke", h_stroke_enable_var, width=22).grid(row=3, column=0, sticky="w", padx=10, pady=6)
    ttk.Label(tab_style, text="Color:").grid(row=3, column=1, sticky="e")
    h_stroke_color_btn = tk.Button(tab_style, text="      ", bg=h_stroke_color_var.get(), relief="ridge", width=6,
                                   command=lambda: _pick_rgb("Heading Stroke Color", h_stroke_rgb_val, h_stroke_color_var, h_stroke_color_btn))
    h_stroke_color_btn.grid(row=3, column=2, sticky="w", padx=5)
    ttk.Label(tab_style, text="Size:").grid(row=4, column=1, sticky="e")
    h_stroke_size_spin = ttk.Spinbox(tab_style, from_=1, to=50, width=6); h_stroke_size_spin.set(3); h_stroke_size_spin.grid(row=4, column=2, sticky="w", padx=5)
    ttk.Label(tab_style, text="Opacity:").grid(row=4, column=3, sticky="e")
    h_stroke_opacity_spin = ttk.Spinbox(tab_style, from_=0, to=100, width=6); h_stroke_opacity_spin.set(100); h_stroke_opacity_spin.grid(row=4, column=4, sticky="w", padx=5)

    ttk.Separator(tab_style, orient="horizontal").grid(row=5, column=0, columnspan=5, sticky="ew", pady=12, padx=10)
    _make_toggle(tab_style, "Manual Drop Shadow", h_shadow_enable_var, width=26).grid(row=6, column=0, sticky="w", padx=10, pady=6)
    ttk.Label(tab_style, text="Color:").grid(row=6, column=1, sticky="e")
    h_shadow_color_btn = tk.Button(tab_style, text="      ", bg=h_shadow_color_var.get(), relief="ridge", width=6,
                                   command=lambda: _pick_rgb("Heading Shadow Color", h_shadow_rgb_val, h_shadow_color_var, h_shadow_color_btn))
    h_shadow_color_btn.grid(row=6, column=2, sticky="w", padx=5)
    ttk.Label(tab_style, text="Blend Mode:").grid(row=6, column=3, sticky="e")
    h_shadow_blend_cb = ttk.Combobox(tab_style, textvariable=h_shadow_blend_var, values=["Normal", "Multiply", "Screen", "Overlay", "Soft Light", "Hard Light", "Color Dodge", "Color Burn", "Linear Dodge", "Linear Burn", "Difference", "Exclusion"], width=14, state="readonly")
    h_shadow_blend_cb.grid(row=6, column=4, sticky="w", padx=5)
    ttk.Label(tab_style, text="Opacity:").grid(row=7, column=0, sticky="e", padx=10)
    h_shadow_opacity_spin = ttk.Spinbox(tab_style, from_=0, to=100, width=6); h_shadow_opacity_spin.set(60); h_shadow_opacity_spin.grid(row=7, column=1, sticky="w", padx=5)
    ttk.Label(tab_style, text="Distance:").grid(row=7, column=2, sticky="e")
    h_shadow_distance_spin = ttk.Spinbox(tab_style, from_=0, to=100, width=6); h_shadow_distance_spin.set(8); h_shadow_distance_spin.grid(row=7, column=3, sticky="w", padx=5)
    ttk.Label(tab_style, text="Size:").grid(row=8, column=0, sticky="e", padx=10)
    h_shadow_size_spin = ttk.Spinbox(tab_style, from_=0, to=150, width=6); h_shadow_size_spin.set(12); h_shadow_size_spin.grid(row=8, column=1, sticky="w", padx=5)
    ttk.Label(tab_style, text="Angle:").grid(row=8, column=2, sticky="e")
    h_shadow_angle_spin = ttk.Spinbox(tab_style, from_=-180, to=180, width=6); h_shadow_angle_spin.set(120); h_shadow_angle_spin.grid(row=8, column=3, sticky="w", padx=5)
    ttk.Label(tab_style, text="Spread:").grid(row=9, column=0, sticky="e", padx=10)
    h_shadow_spread_spin = ttk.Spinbox(tab_style, from_=0, to=100, width=6); h_shadow_spread_spin.set(0); h_shadow_spread_spin.grid(row=9, column=1, sticky="w", padx=5)
    ttk.Separator(tab_style, orient="horizontal").grid(row=10, column=0, columnspan=5, sticky="ew", pady=12, padx=10)
    ttk.Label(tab_style, text="Saved style:").grid(row=11, column=0, sticky="w", padx=10, pady=(0, 10))
    heading_saved_style_cb = ttk.Combobox(tab_style, textvariable=heading_saved_style_var, width=28, state="readonly")
    heading_saved_style_cb.grid(row=11, column=1, columnspan=2, sticky="ew", padx=5, pady=(0, 10))
    ttk.Button(tab_style, text="Capture Copied FX", command=lambda: _capture_copied_style("heading")).grid(row=11, column=3, sticky="ew", padx=4, pady=(0, 10))
    ttk.Button(tab_style, text="Save Named", command=lambda: _save_named_layer_style("heading")).grid(row=12, column=0, sticky="ew", padx=10, pady=(0, 10))
    ttk.Button(tab_style, text="Load", command=lambda: _load_named_layer_style("heading")).grid(row=12, column=1, sticky="ew", padx=4, pady=(0, 10))
    ttk.Button(tab_style, text="Delete", style="Danger.TButton", command=lambda: _delete_named_layer_style("heading")).grid(row=12, column=2, sticky="ew", padx=4, pady=(0, 10))
    tab_style.columnconfigure(3, weight=1)
    _refresh_heading_style_status()

    body_style_frame = ttk.LabelFrame(tab_body, text="Body Text Layer Style / FX")
    body_style_frame.grid(row=4, column=0, columnspan=5, sticky="ew", padx=10, pady=(12, 10))

    def _refresh_body_style_status(*_args):
        style_name = copied_body_style_name_var.get().strip() or "Copied Photoshop layer style"
        captured = " Exact copied FX captured." if body_captured_style.get("hex") else ""
        if paste_body_style_var.get():
            body_style_status_var.set(f"{style_name}: current Photoshop clipboard FX will be pasted.{captured}")
        else:
            body_style_status_var.set(f"{style_name}: live clipboard paste is off.{captured}")

    def _clear_body_layer_styles():
        paste_body_style_var.set(False)
        body_captured_style["hex"] = ""
        copied_body_style_name_var.set("Copied Photoshop layer style")
        for _style_target in ("Body text", "Game Rules text", "Malfunction/legal text"):
            layer_style_assignments.pop(_style_target, None)
        body_saved_style_var.set("")
        b_stroke_enable_var.set(False)
        b_shadow_enable_var.set(False)
        b_stroke_rgb_val[:] = [255, 255, 255]
        b_shadow_rgb_val[:] = [0, 0, 0]
        b_stroke_color_var.set("#FFFFFF")
        b_shadow_color_var.set("#000000")
        _set_btn_color(b_stroke_color_btn, b_stroke_color_var.get())
        _set_btn_color(b_shadow_color_btn, b_shadow_color_var.get())
        b_stroke_size_spin.set(3); b_stroke_opacity_spin.set(100)
        b_shadow_blend_var.set("Multiply"); b_shadow_opacity_spin.set(60)
        b_shadow_distance_spin.set(8); b_shadow_size_spin.set(12)
        b_shadow_angle_spin.set(120); b_shadow_spread_spin.set(0)
        _refresh_body_style_status()
        try:
            _refresh_named_style_choices()
            _save_current_session()
        except Exception:
            pass
        style_manager_status_var.set("Body, Game Rules, and legal text layer styles cleared. These categories will render with no saved FX unless reassigned.")

    paste_body_style_var.trace_add("write", _refresh_body_style_status)
    copied_body_style_name_var.trace_add("write", _refresh_body_style_status)
    _make_toggle(body_style_frame, "Paste current Photoshop style", paste_body_style_var, _refresh_body_style_status, width=34).grid(row=0, column=0, columnspan=2, sticky="w", padx=10, pady=(12, 6))
    ttk.Label(body_style_frame, text="Style label:").grid(row=0, column=2, sticky="e", padx=(10, 5), pady=(12, 6))
    ttk.Entry(body_style_frame, textvariable=copied_body_style_name_var, width=28).grid(row=0, column=3, sticky="ew", pady=(12, 6))
    ttk.Button(body_style_frame, text="Clear Layer Styles", command=_clear_body_layer_styles).grid(row=0, column=4, sticky="w", padx=8, pady=(12, 6))
    ttk.Label(body_style_frame, textvariable=body_style_status_var, foreground="gray", wraplength=820).grid(row=1, column=0, columnspan=5, sticky="w", padx=10, pady=(0, 8))
    _make_toggle(body_style_frame, "Manual Stroke", b_stroke_enable_var, width=22).grid(row=2, column=0, sticky="w", padx=10, pady=6)
    ttk.Label(body_style_frame, text="Color:").grid(row=2, column=1, sticky="e")
    b_stroke_color_btn = tk.Button(body_style_frame, text="      ", bg=b_stroke_color_var.get(), relief="ridge", width=6,
                                   command=lambda: _pick_rgb("Body Stroke Color", b_stroke_rgb_val, b_stroke_color_var, b_stroke_color_btn))
    b_stroke_color_btn.grid(row=2, column=2, sticky="w", padx=5)
    ttk.Label(body_style_frame, text="Size:").grid(row=3, column=1, sticky="e")
    b_stroke_size_spin = ttk.Spinbox(body_style_frame, from_=1, to=50, width=6); b_stroke_size_spin.set(3); b_stroke_size_spin.grid(row=3, column=2, sticky="w", padx=5)
    ttk.Label(body_style_frame, text="Opacity:").grid(row=3, column=3, sticky="e")
    b_stroke_opacity_spin = ttk.Spinbox(body_style_frame, from_=0, to=100, width=6); b_stroke_opacity_spin.set(100); b_stroke_opacity_spin.grid(row=3, column=4, sticky="w", padx=5)
    ttk.Separator(body_style_frame, orient="horizontal").grid(row=4, column=0, columnspan=5, sticky="ew", pady=12, padx=10)
    _make_toggle(body_style_frame, "Manual Drop Shadow", b_shadow_enable_var, width=26).grid(row=5, column=0, sticky="w", padx=10, pady=6)
    ttk.Label(body_style_frame, text="Color:").grid(row=5, column=1, sticky="e")
    b_shadow_color_btn = tk.Button(body_style_frame, text="      ", bg=b_shadow_color_var.get(), relief="ridge", width=6,
                                   command=lambda: _pick_rgb("Body Shadow Color", b_shadow_rgb_val, b_shadow_color_var, b_shadow_color_btn))
    b_shadow_color_btn.grid(row=5, column=2, sticky="w", padx=5)
    ttk.Label(body_style_frame, text="Blend Mode:").grid(row=5, column=3, sticky="e")
    ttk.Combobox(body_style_frame, textvariable=b_shadow_blend_var, values=["Normal", "Multiply", "Screen", "Overlay", "Soft Light", "Hard Light", "Color Dodge", "Color Burn", "Linear Dodge", "Linear Burn", "Difference", "Exclusion"], width=14, state="readonly").grid(row=5, column=4, sticky="w", padx=5)
    ttk.Label(body_style_frame, text="Opacity:").grid(row=6, column=0, sticky="e", padx=10)
    b_shadow_opacity_spin = ttk.Spinbox(body_style_frame, from_=0, to=100, width=6); b_shadow_opacity_spin.set(60); b_shadow_opacity_spin.grid(row=6, column=1, sticky="w", padx=5)
    ttk.Label(body_style_frame, text="Distance:").grid(row=6, column=2, sticky="e")
    b_shadow_distance_spin = ttk.Spinbox(body_style_frame, from_=0, to=100, width=6); b_shadow_distance_spin.set(8); b_shadow_distance_spin.grid(row=6, column=3, sticky="w", padx=5)
    ttk.Label(body_style_frame, text="Size:").grid(row=7, column=0, sticky="e", padx=10)
    b_shadow_size_spin = ttk.Spinbox(body_style_frame, from_=0, to=150, width=6); b_shadow_size_spin.set(12); b_shadow_size_spin.grid(row=7, column=1, sticky="w", padx=5)
    ttk.Label(body_style_frame, text="Angle:").grid(row=7, column=2, sticky="e")
    b_shadow_angle_spin = ttk.Spinbox(body_style_frame, from_=-180, to=180, width=6); b_shadow_angle_spin.set(120); b_shadow_angle_spin.grid(row=7, column=3, sticky="w", padx=5)
    ttk.Label(body_style_frame, text="Spread:").grid(row=8, column=0, sticky="e", padx=10)
    b_shadow_spread_spin = ttk.Spinbox(body_style_frame, from_=0, to=100, width=6); b_shadow_spread_spin.set(0); b_shadow_spread_spin.grid(row=8, column=1, sticky="w", padx=5)
    ttk.Separator(body_style_frame, orient="horizontal").grid(row=9, column=0, columnspan=5, sticky="ew", pady=12, padx=10)
    ttk.Label(body_style_frame, text="Saved style:").grid(row=10, column=0, sticky="w", padx=10, pady=(0, 10))
    body_saved_style_cb = ttk.Combobox(body_style_frame, textvariable=body_saved_style_var, width=28, state="readonly")
    body_saved_style_cb.grid(row=10, column=1, columnspan=2, sticky="ew", padx=5, pady=(0, 10))
    ttk.Button(body_style_frame, text="Capture Copied FX", command=lambda: _capture_copied_style("body")).grid(row=10, column=3, sticky="ew", padx=4, pady=(0, 10))
    ttk.Button(body_style_frame, text="Save Named", command=lambda: _save_named_layer_style("body")).grid(row=11, column=0, sticky="ew", padx=10, pady=(0, 10))
    ttk.Button(body_style_frame, text="Load", command=lambda: _load_named_layer_style("body")).grid(row=11, column=1, sticky="ew", padx=4, pady=(0, 10))
    ttk.Button(body_style_frame, text="Delete", style="Danger.TButton", command=lambda: _delete_named_layer_style("body")).grid(row=11, column=2, sticky="ew", padx=4, pady=(0, 10))
    body_style_frame.columnconfigure(3, weight=1)
    _refresh_body_style_status()

    def _snapshot_style_controls(target):
        if target == "heading":
            return {
                "paste_copied_style": paste_heading_style_var.get(), "copied_style_name": copied_heading_style_name_var.get().strip(),
                "captured_effects_hex": heading_captured_style.get("hex", ""),
                "captured_params": heading_captured_style.get("params") or {},
                "stroke_enabled": h_stroke_enable_var.get(), "stroke_rgb": tuple(h_stroke_rgb_val),
                "stroke_size": int(h_stroke_size_spin.get()), "stroke_opacity": int(h_stroke_opacity_spin.get()),
                "shadow_enabled": h_shadow_enable_var.get(), "shadow_rgb": tuple(h_shadow_rgb_val), "shadow_blend_mode": h_shadow_blend_var.get(),
                "shadow_opacity": int(h_shadow_opacity_spin.get()), "shadow_distance": int(h_shadow_distance_spin.get()),
                "shadow_size": int(h_shadow_size_spin.get()), "shadow_angle": int(h_shadow_angle_spin.get()), "shadow_spread": int(h_shadow_spread_spin.get()),
            }
        return {
            "paste_copied_style": paste_body_style_var.get(), "copied_style_name": copied_body_style_name_var.get().strip(),
            "captured_effects_hex": body_captured_style.get("hex", ""),
            "captured_params": body_captured_style.get("params") or {},
            "stroke_enabled": b_stroke_enable_var.get(), "stroke_rgb": tuple(b_stroke_rgb_val),
            "stroke_size": int(b_stroke_size_spin.get()), "stroke_opacity": int(b_stroke_opacity_spin.get()),
            "shadow_enabled": b_shadow_enable_var.get(), "shadow_rgb": tuple(b_shadow_rgb_val), "shadow_blend_mode": b_shadow_blend_var.get(),
            "shadow_opacity": int(b_shadow_opacity_spin.get()), "shadow_distance": int(b_shadow_distance_spin.get()),
            "shadow_size": int(b_shadow_size_spin.get()), "shadow_angle": int(b_shadow_angle_spin.get()), "shadow_spread": int(b_shadow_spread_spin.get()),
        }

    def _style_config_for_assignment(target):
        style_name = str(layer_style_assignments.get(target) or "").strip()
        if style_name.casefold() in {"", "none", "no style", "__none__"}:
            return None
        style_config = layer_style_library.get(style_name)
        if not style_config:
            return None
        return json.loads(json.dumps(style_config))

    def _style_config_with_fallback(target, fallback_config):
        return _style_config_for_assignment(target) or fallback_config

    def _sync_assigned_styles_to_controls():
        heading_cfg = _style_config_for_assignment("Heading text")
        if heading_cfg:
            heading_saved_style_var.set(layer_style_assignments.get("Heading text", ""))
            _apply_style_controls("heading", heading_cfg)
        body_cfg = _style_config_for_assignment("Body text")
        if body_cfg:
            body_saved_style_var.set(layer_style_assignments.get("Body text", ""))
            _apply_style_controls("body", body_cfg)
        icon_cfg = _style_config_for_assignment("Body icons")
        if icon_cfg:
            icon_saved_style_var.set(layer_style_assignments.get("Body icons", ""))
            icon_layer_style_enabled_var.set(True)

    def _refresh_named_style_choices():
        values = sorted(layer_style_library, key=str.casefold)
        for combo in (heading_saved_style_cb, body_saved_style_cb, icon_saved_style_cb):
            combo["values"] = values
        try:
            if style_manager_cb is not None:
                style_manager_cb["values"] = values
        except Exception:
            pass

    def _capture_copied_style(target):
        try:
            captured = capture_copied_layer_style_from_photoshop()
            if isinstance(captured, dict):
                captured_hex = str(captured.get("hex") or "")
                captured_params = captured.get("captured_params") or {}
            else:
                captured_hex = str(captured or "")
                captured_params = {}
            if target == "heading":
                heading_captured_style["hex"] = captured_hex
                heading_captured_style["params"] = captured_params
                paste_heading_style_var.set(False)
                heading_style_status_var.set("Exact copied Photoshop FX captured and ready to save or render.")
            else:
                body_captured_style["hex"] = captured_hex
                body_captured_style["params"] = captured_params
                paste_body_style_var.set(False)
                body_style_status_var.set("Exact copied Photoshop FX captured and ready to save or render.")
        except Exception as exc:
            messagebox.showerror("Capture Layer Style", str(exc))

    def _save_named_layer_style(target):
        current = heading_saved_style_var.get() if target == "heading" else body_saved_style_var.get()
        name = simpledialog.askstring("Save Layer Style", "Style name:", initialvalue=current or "My Layer Style", parent=root)
        if not name or not name.strip():
            return
        clean_name = name.strip()
        layer_style_library[clean_name] = json.loads(json.dumps(_snapshot_style_controls(target)))
        _save_global_style_name(clean_name)
        if target == "heading": heading_saved_style_var.set(clean_name)
        else: body_saved_style_var.set(clean_name)
        _refresh_named_style_choices()

    def _apply_style_controls(target, style_config):
        cfg = dict(style_config or {})
        if target == "heading":
            paste_heading_style_var.set(bool(cfg.get("paste_copied_style", False)))
            copied_heading_style_name_var.set(cfg.get("copied_style_name", "Copied Photoshop layer style"))
            heading_captured_style["hex"] = str(cfg.get("captured_effects_hex", "") or "")
            heading_captured_style["params"] = dict(cfg.get("captured_params") or {})
            h_stroke_enable_var.set(bool(cfg.get("stroke_enabled", False))); h_stroke_rgb_val[:] = cfg.get("stroke_rgb", [255,255,255])
            h_stroke_color_var.set("#%02x%02x%02x" % tuple(h_stroke_rgb_val)); _set_btn_color(h_stroke_color_btn, h_stroke_color_var.get())
            h_stroke_size_spin.set(cfg.get("stroke_size", 3)); h_stroke_opacity_spin.set(cfg.get("stroke_opacity", 100))
            h_shadow_enable_var.set(bool(cfg.get("shadow_enabled", False))); h_shadow_rgb_val[:] = cfg.get("shadow_rgb", [0,0,0])
            h_shadow_color_var.set("#%02x%02x%02x" % tuple(h_shadow_rgb_val)); _set_btn_color(h_shadow_color_btn, h_shadow_color_var.get())
            h_shadow_blend_var.set(cfg.get("shadow_blend_mode", "Multiply")); h_shadow_opacity_spin.set(cfg.get("shadow_opacity", 60))
            h_shadow_distance_spin.set(cfg.get("shadow_distance", 8)); h_shadow_size_spin.set(cfg.get("shadow_size", 12)); h_shadow_angle_spin.set(cfg.get("shadow_angle", 120)); h_shadow_spread_spin.set(cfg.get("shadow_spread", 0))
            _refresh_heading_style_status()
        else:
            paste_body_style_var.set(bool(cfg.get("paste_copied_style", False)))
            copied_body_style_name_var.set(cfg.get("copied_style_name", "Copied Photoshop layer style"))
            body_captured_style["hex"] = str(cfg.get("captured_effects_hex", "") or "")
            body_captured_style["params"] = dict(cfg.get("captured_params") or {})
            b_stroke_enable_var.set(bool(cfg.get("stroke_enabled", False))); b_stroke_rgb_val[:] = cfg.get("stroke_rgb", [255,255,255])
            b_stroke_color_var.set("#%02x%02x%02x" % tuple(b_stroke_rgb_val)); _set_btn_color(b_stroke_color_btn, b_stroke_color_var.get())
            b_stroke_size_spin.set(cfg.get("stroke_size", 3)); b_stroke_opacity_spin.set(cfg.get("stroke_opacity", 100))
            b_shadow_enable_var.set(bool(cfg.get("shadow_enabled", False))); b_shadow_rgb_val[:] = cfg.get("shadow_rgb", [0,0,0])
            b_shadow_color_var.set("#%02x%02x%02x" % tuple(b_shadow_rgb_val)); _set_btn_color(b_shadow_color_btn, b_shadow_color_var.get())
            b_shadow_blend_var.set(cfg.get("shadow_blend_mode", "Multiply")); b_shadow_opacity_spin.set(cfg.get("shadow_opacity", 60))
            b_shadow_distance_spin.set(cfg.get("shadow_distance", 8)); b_shadow_size_spin.set(cfg.get("shadow_size", 12)); b_shadow_angle_spin.set(cfg.get("shadow_angle", 120)); b_shadow_spread_spin.set(cfg.get("shadow_spread", 0))
            _refresh_body_style_status()

    def _load_named_layer_style(target):
        name = heading_saved_style_var.get() if target == "heading" else body_saved_style_var.get()
        if name not in layer_style_library:
            messagebox.showwarning("Layer Style", "Select a saved layer style first.")
            return
        _apply_style_controls(target, layer_style_library[name])

    def _delete_named_layer_style(target):
        name = heading_saved_style_var.get() if target == "heading" else body_saved_style_var.get()
        if name in layer_style_library:
            del layer_style_library[name]
            _delete_global_style_name(name)
        if heading_saved_style_var.get() == name: heading_saved_style_var.set("")
        if body_saved_style_var.get() == name: body_saved_style_var.set("")
        if icon_saved_style_var.get() == name: icon_saved_style_var.set("")
        _refresh_named_style_choices()

    # Layer Styles manager: sidecar and global JSON preset storage.
    style_targets = [
        "Heading text",
        "Subheading text",
        "Body text",
        "Table header",
        "Table body",
        "Paytable payout count",
        "Paytable payout value",
        "Game Rules text",
        "Malfunction/legal text",
        "Body icons",
        "Custom selected target",
    ]

    def _style_config_from_hex(effects_hex, label, captured_params=None):
        if isinstance(effects_hex, dict):
            captured_params = effects_hex.get("captured_params") or captured_params
            effects_hex = str(effects_hex.get("hex") or "")
        return {
            "paste_copied_style": False,
            "copied_style_name": label,
            "captured_effects_hex": str(effects_hex or ""),
            "captured_params": captured_params or {},
            "stroke_enabled": False,
            "shadow_enabled": False,
        }

    def _style_sidecar_default_path():
        for candidate in (prev_psd_var.get().strip(), rerender_psd_var.get().strip()):
            if candidate:
                return os.path.splitext(candidate)[0] + ".pshelpscreen_styles.json"
        base_dir = output_dir_var.get().strip() or os.path.dirname(excel_var.get().strip() or os.path.abspath("."))
        base_name = output_name_var.get().strip() or "PsHelpScreenTool"
        return os.path.join(base_dir, base_name + ".pshelpscreen_styles.json")

    def _style_sidecar_path():
        path = style_sidecar_path_var.get().strip()
        if not path:
            path = _style_sidecar_default_path()
            style_sidecar_path_var.set(path)
        return path

    def _style_payload():
        return {
            "version": "V46.18",
            "styles": dict(layer_style_library),
            "assignments": dict(layer_style_assignments),
        }

    def _load_style_payload(path):
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        if "styles" in data:
            layer_style_library.update(data.get("styles") or {})
            layer_style_assignments.clear()
            layer_style_assignments.update(data.get("assignments") or {})
        else:
            name = data.get("name") or os.path.splitext(os.path.basename(path))[0]
            layer_style_library[name] = data.get("style") or data
        _refresh_named_style_choices()
        _sync_assigned_styles_to_controls()

    def _save_styles_sidecar():
        path = _style_sidecar_path()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as handle:
            json.dump(_style_payload(), handle, indent=2)
        style_manager_status_var.set(f"Saved PSD sidecar styles: {path}")

    def _load_styles_sidecar(show_dialog=True):
        path = style_sidecar_path_var.get().strip() or _style_sidecar_default_path()
        if not os.path.exists(path):
            if show_dialog:
                messagebox.showwarning("Layer Styles", f"No sidecar style JSON found:\n{path}")
            return
        _load_style_payload(path)
        style_sidecar_path_var.set(path)
        style_manager_status_var.set(f"Loaded PSD sidecar styles: {path}")

    def _choose_style_sidecar():
        path = filedialog.askopenfilename(filetypes=[("PsHelpScreen style JSON", "*.json"), ("JSON", "*.json")])
        if path:
            style_sidecar_path_var.set(path)
            _load_styles_sidecar(show_dialog=True)

    def _choose_style_global_folder():
        folder = filedialog.askdirectory()
        if folder:
            style_global_folder_var.set(folder)

    def _safe_style_file_name(name):
        safe_name = "".join(ch if ch not in '<>:"/\\|?*' else "_" for ch in str(name or "")).strip()
        return safe_name or "LayerStyle"

    def _global_style_folder():
        folder = style_global_folder_var.get().strip()
        if not folder:
            folder = os.path.join(os.path.dirname(os.path.dirname(__file__)), "Layer Styles")
            style_global_folder_var.set(folder)
        return folder

    def _global_style_path(name):
        return os.path.join(_global_style_folder(), _safe_style_file_name(name) + ".json")

    def _save_global_style_name(name):
        name = str(name or "").strip()
        if not name or name not in layer_style_library:
            return
        folder = _global_style_folder()
        os.makedirs(folder, exist_ok=True)
        with open(_global_style_path(name), "w", encoding="utf-8") as handle:
            json.dump({"name": name, "style": layer_style_library[name]}, handle, indent=2)

    def _delete_global_style_name(name):
        name = str(name or "").strip()
        if not name:
            return
        path = _global_style_path(name)
        if os.path.exists(path):
            try:
                os.remove(path)
            except Exception as exc:
                style_manager_status_var.set(f"Could not delete global style JSON: {exc}")

    def _load_global_style_files(show_warning=True):
        folder = _global_style_folder()
        if not os.path.isdir(folder):
            if show_warning:
                messagebox.showwarning("Layer Styles", "Choose an existing global style preset folder first.")
            return 0
        loaded = 0
        for file_name in os.listdir(folder):
            if not file_name.lower().endswith(".json"):
                continue
            path = os.path.join(folder, file_name)
            try:
                with open(path, "r", encoding="utf-8") as handle:
                    data = json.load(handle)
                if "styles" in data:
                    layer_style_library.update(data.get("styles") or {})
                else:
                    name = data.get("name") or os.path.splitext(os.path.basename(path))[0]
                    layer_style_library[name] = data.get("style") or data
                loaded += 1
            except Exception as exc:
                style_manager_status_var.set(f"Skipped {file_name}: {exc}")
        _refresh_named_style_choices()
        return loaded

    def _save_style_as_global():
        name = style_manager_choice_var.get().strip()
        if not name or name not in layer_style_library:
            messagebox.showwarning("Layer Styles", "Select a saved style first.")
            return
        _save_global_style_name(name)
        path = _global_style_path(name)
        style_manager_status_var.set(f"Saved global style preset: {path}")

    def _load_global_styles():
        loaded = _load_global_style_files(show_warning=True)
        style_manager_status_var.set(f"Loaded {loaded} global style preset(s).")

    def _capture_selected_style_to_library():
        name = style_manager_name_var.get().strip() or simpledialog.askstring(
            "Capture Selected Layer Style", "Style name:", initialvalue="Selected Photoshop Style", parent=root
        )
        if not name or not name.strip():
            return
        try:
            captured = capture_selected_layer_style_from_photoshop()
        except Exception as exc:
            messagebox.showerror("Capture Selected Layer Style", str(exc))
            return
        clean_name = name.strip()
        layer_style_library[clean_name] = _style_config_from_hex(captured, clean_name)
        _save_global_style_name(clean_name)
        style_manager_choice_var.set(clean_name)
        style_manager_name_var.set(clean_name)
        _refresh_named_style_choices()
        style_manager_status_var.set(f"Captured selected Photoshop layer style: {clean_name}")

    def _capture_copied_style_to_library():
        name = style_manager_name_var.get().strip() or simpledialog.askstring(
            "Capture Copied Layer Style", "Style name:", initialvalue="Copied Photoshop Style", parent=root
        )
        if not name or not name.strip():
            return
        try:
            captured = capture_copied_layer_style_from_photoshop()
        except Exception as exc:
            messagebox.showerror("Capture Copied Layer Style", str(exc))
            return
        clean_name = name.strip()
        layer_style_library[clean_name] = _style_config_from_hex(captured, clean_name)
        _save_global_style_name(clean_name)
        style_manager_choice_var.set(clean_name)
        style_manager_name_var.set(clean_name)
        _refresh_named_style_choices()
        style_manager_status_var.set(f"Captured copied Photoshop layer style: {clean_name}")

    def _apply_style_to_active_photoshop_layer(style_config):
        try:
            import photoshop.api as ps
            app = ps.Application()
            if not app.documents.length:
                raise RuntimeError("Open a Photoshop document first.")
            doc = app.activeDocument
            layer = doc.activeLayer
            effects_hex = (style_config or {}).get("captured_effects_hex")
            if not effects_hex:
                raise RuntimeError("This preset has no captured Photoshop descriptor.")
            if not apply_serialized_layer_style(app, doc, layer, effects_hex):
                raise RuntimeError("Photoshop rejected the saved layer-style descriptor.")
            return True
        except Exception as exc:
            messagebox.showwarning("Layer Styles", f"Could not apply to active Photoshop layer:\n{exc}")
            return False

    def _apply_style_assignment():
        style_name = style_manager_choice_var.get().strip()
        target = style_manager_target_var.get().strip()
        if style_name not in layer_style_library:
            messagebox.showwarning("Layer Styles", "Select a saved style first.")
            return
        layer_style_assignments[target] = style_name
        if target == "Heading text":
            heading_saved_style_var.set(style_name)
            _apply_style_controls("heading", layer_style_library[style_name])
        elif target in ("Body text", "Game Rules text", "Malfunction/legal text"):
            body_saved_style_var.set(style_name)
            _apply_style_controls("body", layer_style_library[style_name])
        elif target == "Body icons":
            icon_saved_style_var.set(style_name)
            icon_layer_style_enabled_var.set(True)
        if style_manager_apply_active_var.get() or target == "Custom selected target":
            _apply_style_to_active_photoshop_layer(layer_style_library[style_name])
        _refresh_named_style_choices()
        _save_current_session()
        style_manager_status_var.set(f"Assigned '{style_name}' to {target}.")

    def _clear_style_assignment():
        target = style_manager_target_var.get().strip()
        if not target:
            return
        layer_style_assignments.pop(target, None)
        if target == "Heading text":
            heading_saved_style_var.set("")
        elif target in ("Body text", "Game Rules text", "Malfunction/legal text"):
            body_saved_style_var.set("")
        elif target == "Body icons":
            icon_saved_style_var.set("")
            icon_layer_style_enabled_var.set(False)
        _refresh_named_style_choices()
        _save_current_session()
        style_manager_status_var.set(f"No Style assigned to {target}.")

    def _delete_style_manager_style():
        name = style_manager_choice_var.get().strip()
        if name in layer_style_library and messagebox.askyesno("Layer Styles", f"Delete style '{name}'?"):
            del layer_style_library[name]
            _delete_global_style_name(name)
            for key, value in list(layer_style_assignments.items()):
                if value == name:
                    del layer_style_assignments[key]
            if heading_saved_style_var.get() == name: heading_saved_style_var.set("")
            if body_saved_style_var.get() == name: body_saved_style_var.set("")
            if icon_saved_style_var.get() == name: icon_saved_style_var.set("")
            style_manager_choice_var.set("")
            _refresh_named_style_choices()

    def _rename_style_manager_style():
        old_name = style_manager_choice_var.get().strip()
        if old_name not in layer_style_library:
            messagebox.showwarning("Layer Styles", "Select a saved style first.")
            return
        new_name = simpledialog.askstring("Rename Layer Style", "New name:", initialvalue=old_name, parent=root)
        if not new_name or not new_name.strip():
            return
        clean_name = new_name.strip()
        layer_style_library[clean_name] = layer_style_library.pop(old_name)
        _delete_global_style_name(old_name)
        _save_global_style_name(clean_name)
        for key, value in list(layer_style_assignments.items()):
            if value == old_name:
                layer_style_assignments[key] = clean_name
        if heading_saved_style_var.get() == old_name: heading_saved_style_var.set(clean_name)
        if body_saved_style_var.get() == old_name: body_saved_style_var.set(clean_name)
        if icon_saved_style_var.get() == old_name: icon_saved_style_var.set(clean_name)
        style_manager_choice_var.set(clean_name)
        _refresh_named_style_choices()

    def _duplicate_style_manager_style():
        name = style_manager_choice_var.get().strip()
        if name not in layer_style_library:
            messagebox.showwarning("Layer Styles", "Select a saved style first.")
            return
        new_name = simpledialog.askstring("Duplicate Layer Style", "Duplicate name:", initialvalue=f"{name} Copy", parent=root)
        if not new_name or not new_name.strip():
            return
        clean_name = new_name.strip()
        layer_style_library[clean_name] = json.loads(json.dumps(layer_style_library[name]))
        _save_global_style_name(clean_name)
        style_manager_choice_var.set(clean_name)
        _refresh_named_style_choices()

    layer_mgr_intro = ttk.LabelFrame(tab_layer_styles, text="Layer Style Library")
    layer_mgr_intro.pack(fill="x", padx=10, pady=(10, 8))
    ttk.Label(layer_mgr_intro, text="Capture FX from the selected Photoshop layer, save them as reusable JSON, and assign them to render categories.", foreground="gray", wraplength=900).grid(row=0, column=0, columnspan=5, sticky="w", padx=10, pady=(12, 8))
    ttk.Label(layer_mgr_intro, text="Style name:").grid(row=1, column=0, sticky="w", padx=10, pady=5)
    ttk.Entry(layer_mgr_intro, textvariable=style_manager_name_var, width=34).grid(row=1, column=1, sticky="ew", padx=5, pady=5)
    ttk.Button(layer_mgr_intro, text="Capture Selected Layer", command=_capture_selected_style_to_library, style="Primary.TButton").grid(row=1, column=2, sticky="ew", padx=5, pady=5)
    ttk.Button(layer_mgr_intro, text="Capture Copied FX", command=_capture_copied_style_to_library).grid(row=1, column=3, sticky="ew", padx=5, pady=5)
    ttk.Label(layer_mgr_intro, text="Saved style:").grid(row=2, column=0, sticky="w", padx=10, pady=5)
    style_manager_cb = ttk.Combobox(layer_mgr_intro, textvariable=style_manager_choice_var, width=34, state="readonly")
    style_manager_cb.grid(row=2, column=1, sticky="ew", padx=5, pady=5)
    ttk.Label(layer_mgr_intro, text="Apply to:").grid(row=2, column=2, sticky="e", padx=5, pady=5)
    ttk.Combobox(layer_mgr_intro, textvariable=style_manager_target_var, values=style_targets, width=24, state="readonly").grid(row=2, column=3, sticky="ew", padx=5, pady=5)
    ttk.Button(layer_mgr_intro, text="Apply Assignment", command=_apply_style_assignment, style="Primary.TButton").grid(row=2, column=4, sticky="ew", padx=5, pady=5)
    _make_toggle(layer_mgr_intro, "Also apply to active selected Photoshop layer", style_manager_apply_active_var, width=38).grid(row=3, column=1, columnspan=3, sticky="w", padx=5, pady=(4, 10))
    ttk.Button(layer_mgr_intro, text="Clear / No Style", command=_clear_style_assignment, style="Danger.TButton").grid(row=3, column=4, sticky="ew", padx=5, pady=(4, 10))
    ttk.Button(layer_mgr_intro, text="Rename", command=_rename_style_manager_style).grid(row=4, column=1, sticky="ew", padx=5, pady=(0, 12))
    ttk.Button(layer_mgr_intro, text="Duplicate", command=_duplicate_style_manager_style).grid(row=4, column=2, sticky="ew", padx=5, pady=(0, 12))
    ttk.Button(layer_mgr_intro, text="Delete", command=_delete_style_manager_style, style="Danger.TButton").grid(row=4, column=3, sticky="ew", padx=5, pady=(0, 12))
    for _col in range(5):
        layer_mgr_intro.columnconfigure(_col, weight=1 if _col in (1, 3, 4) else 0)

    layer_mgr_storage = ttk.LabelFrame(tab_layer_styles, text="Style JSON Storage")
    layer_mgr_storage.pack(fill="x", padx=10, pady=(0, 8))
    ttk.Label(layer_mgr_storage, text="PSD sidecar JSON:").grid(row=0, column=0, sticky="w", padx=10, pady=(12, 5))
    ttk.Entry(layer_mgr_storage, textvariable=style_sidecar_path_var, width=70).grid(row=0, column=1, sticky="ew", padx=5, pady=(12, 5))
    ttk.Button(layer_mgr_storage, text="Browse/Load", command=_choose_style_sidecar).grid(row=0, column=2, sticky="ew", padx=5, pady=(12, 5))
    ttk.Button(layer_mgr_storage, text="Save Sidecar", command=_save_styles_sidecar, style="Primary.TButton").grid(row=0, column=3, sticky="ew", padx=(5, 10), pady=(12, 5))
    ttk.Label(layer_mgr_storage, text="Global preset folder:").grid(row=1, column=0, sticky="w", padx=10, pady=5)
    ttk.Entry(layer_mgr_storage, textvariable=style_global_folder_var, width=70).grid(row=1, column=1, sticky="ew", padx=5, pady=5)
    ttk.Button(layer_mgr_storage, text="Browse", command=_choose_style_global_folder).grid(row=1, column=2, sticky="ew", padx=5, pady=5)
    ttk.Button(layer_mgr_storage, text="Load Globals", command=_load_global_styles).grid(row=1, column=3, sticky="ew", padx=(5, 10), pady=5)
    ttk.Button(layer_mgr_storage, text="Save Selected as Global", command=_save_style_as_global, style="Primary.TButton").grid(row=2, column=1, sticky="w", padx=5, pady=(5, 12))
    ttk.Label(layer_mgr_storage, textvariable=style_manager_status_var, foreground="gray", wraplength=900).grid(row=3, column=0, columnspan=4, sticky="w", padx=10, pady=(0, 12))
    layer_mgr_storage.columnconfigure(1, weight=1)
    _load_global_style_files(show_warning=False)
    _refresh_named_style_choices()

    # Text / keywords
    tab_kw_tab = ttk.Frame(text_nb)
    text_nb.add(tab_kw_tab, text="Keywords")
    _kw_scroll_host, tab_kw = _make_scrollable_host(tab_kw_tab, palette["app_bg"])
    _kw_scroll_host.pack(fill="both", expand=True)
    ttk.Label(tab_kw, text="Keyword colors are applied inside a single Photoshop text layer using character ranges, not duplicate overlay layers.", foreground="gray", wraplength=760).grid(row=4, column=0, columnspan=5, sticky="w", padx=10, pady=(4, 8))
    kw_tree = ttk.Treeview(tab_kw, columns=("Keyword", "Color", "Bold"), show="headings", height=10, selectmode="extended")
    kw_tree.heading("Keyword", text="Keyword"); kw_tree.heading("Color", text="Color (RGB)"); kw_tree.heading("Bold", text="Bold")
    kw_tree.column("Keyword", width=260); kw_tree.column("Color", width=180); kw_tree.column("Bold", width=70, stretch=False)
    kw_tree.grid(row=0, column=0, columnspan=5, padx=10, pady=(10, 5), sticky="nsew")

    def _keyword_rgb_and_bold(value):
        if isinstance(value, dict):
            rgb = value.get("rgb") or value.get("color") or [255, 255, 255]
            bold = bool(value.get("bold", False))
        else:
            rgb = value
            bold = False
        try:
            rgb = tuple(int(v) for v in list(rgb)[:3])
        except Exception:
            rgb = (255, 255, 255)
        return rgb, bold

    def refresh_kw_tree():
        for item in kw_tree.get_children():
            kw_tree.delete(item)
        for kw, cfg in keyword_mgr.get_dict().items():
            rgb, bold = _keyword_rgb_and_bold(cfg)
            kw_tree.insert("", "end", values=(kw, f"{rgb}  #{rgb[0]:02x}{rgb[1]:02x}{rgb[2]:02x}", "Yes" if bold else "No"))

    ttk.Label(tab_kw, text="New Keyword:").grid(row=1, column=0, sticky="w", padx=10, pady=(10, 2))
    kw_entry = ttk.Entry(tab_kw, width=28); kw_entry.grid(row=1, column=1, sticky="w", pady=(10, 2))
    kw_rgb_val = [255, 255, 255]
    kw_bold_var = tk.BooleanVar(value=False)
    kw_hex_var = tk.StringVar(value="#FFFFFF")
    kw_color_btn = tk.Button(tab_kw, text="      ", bg="#FFFFFF", relief="ridge", width=4,
                             command=lambda: _pick_rgb("Keyword Color", kw_rgb_val, kw_hex_var, kw_color_btn))
    kw_color_btn.grid(row=1, column=2, sticky="w", pady=(10, 2))
    ttk.Checkbutton(tab_kw, text="Bold", variable=kw_bold_var).grid(row=1, column=3, sticky="w", padx=8, pady=(10, 2))

    def add_keyword():
        kw = kw_entry.get().strip()
        if kw:
            keyword_mgr.add(kw, tuple(kw_rgb_val), bold=kw_bold_var.get()); refresh_kw_tree(); kw_entry.delete(0, tk.END)

    def remove_keyword():
        sel = kw_tree.selection()
        if sel:
            for item in sel:
                values = kw_tree.item(item).get('values') or []
                if values:
                    keyword_mgr.remove(str(values[0]))
            refresh_kw_tree()

    def apply_keyword_bold_to_selected():
        sel = kw_tree.selection()
        if not sel:
            return
        data = keyword_mgr.get_dict()
        for item in sel:
            values = kw_tree.item(item).get('values') or []
            if not values:
                continue
            key = str(values[0])
            for existing_key, cfg in list(data.items()):
                if existing_key == key or existing_key.casefold() == key.casefold():
                    rgb, _bold = _keyword_rgb_and_bold(cfg)
                    keyword_mgr.add(existing_key, rgb, bold=kw_bold_var.get())
                    break
        refresh_kw_tree()

    ttk.Button(tab_kw, text="Add Keyword", command=add_keyword).grid(row=2, column=0, padx=10, pady=5, sticky="w")
    ttk.Button(tab_kw, text="Remove Selected", command=remove_keyword).grid(row=2, column=1, padx=10, pady=5, sticky="w")
    ttk.Button(tab_kw, text="Apply Bold to Selected", command=apply_keyword_bold_to_selected).grid(row=2, column=2, padx=10, pady=5, sticky="w")
    ttk.Button(tab_kw, text="Save Keyword Preset", command=lambda: keyword_mgr.save(filedialog.asksaveasfilename(defaultextension=".json", filetypes=[("JSON", "*.json")]))).grid(row=3, column=0, padx=10, pady=10, sticky="w")

    def _load_kw():
        path = filedialog.askopenfilename(filetypes=[("JSON", "*.json")])
        if path:
            keyword_mgr.load(path); refresh_kw_tree()
    ttk.Button(tab_kw, text="Load Keyword Preset", command=_load_kw).grid(row=3, column=1, padx=10, pady=10, sticky="w")

    # Custom Layouts / Template JSON export

    ttk.Label(
        tab_custom,
        text="Custom Layout JSON Exporter",
        style="SubTitle.TLabel",
    ).grid(row=0, column=0, columnspan=3, sticky="w", padx=10, pady=(12, 4))

    ttk.Label(
        tab_custom,
        text=(
            "Open a premade PSD in Photoshop, or browse a PSD/PSB below. Choose which layer prefix to export. "
            "Use @slot for normal custom layouts/paytables, @table for artist-made table components, or @ to scan all @-prefixed layers. "
            "Examples: @slot.title, @slot.FLOW|B5:O6, @table.cashExpressTrains.bounds, @table.cashExpressTrains.row1.trainIcon. "
            "The exporter does not save or modify the PSD."
        ),
        foreground="gray",
        wraplength=880,
    ).grid(row=1, column=0, columnspan=4, sticky="w", padx=10, pady=(0, 10))

    custom_status_var = tk.StringVar(value="Ready. Browse a PSD/PSB, scan its groups, then export the selected group.")
    custom_psd_var = tk.StringVar()
    custom_group_var = tk.StringVar()
    custom_slot_prefix_var = tk.StringVar(value="@slot")
    custom_group_values = []

    def _handle_export_result(result):
        if result.startswith("SAVED:"):
            saved_path = result.split(":", 1)[1]
            custom_status_var.set(f"Saved JSON: {saved_path}")
            status_var.set("Custom layout JSON exported")
            messagebox.showinfo("JSON Exported", f"Custom layout JSON saved to:\n{saved_path}\n\nThe PSD was not modified or saved.")
        elif result.startswith("CANCELLED"):
            custom_status_var.set(result)
            status_var.set("Custom layout JSON export cancelled")
        elif result.startswith("ERROR"):
            custom_status_var.set(result)
            status_var.set("Custom layout JSON export failed")
            messagebox.showerror("Export Error", result)
        else:
            custom_status_var.set(result or "Exporter finished")
            status_var.set("Custom layout JSON exporter finished")

    def _export_active_paytable_json():
        slot_prefix = custom_slot_prefix_var.get().strip() or "@slot"
        status_var.set("Exporting Custom layout JSON from active Photoshop PSD...")
        custom_status_var.set(f"Running detector in Photoshop on active PSD using prefix {slot_prefix}...")
        root.update()
        try:
            result = export_paytable_json_from_active_psd(slot_prefix)
            _handle_export_result(result)
        except Exception as e:
            custom_status_var.set("Export failed")
            status_var.set("Custom layout JSON export failed")
            messagebox.showerror("Export Error", f"Could not export Custom layout JSON:\n{e}")

    def _browse_custom_psd():
        path = filedialog.askopenfilename(filetypes=[("Photoshop documents", "*.psd;*.psb"), ("PSD", "*.psd"), ("PSB", "*.psb")])
        if path:
            custom_psd_var.set(path)
            custom_group_var.set("")

    def _scan_custom_psd_groups():
        nonlocal custom_group_values
        psd_path = custom_psd_var.get().strip()
        status_var.set("Scanning PSD groups...")
        custom_status_var.set("Opening/scanning PSD/PSB groups in Photoshop. PNG/JPG files are not accepted. File will not be saved or modified...")
        root.update()
        try:
            groups = list_psd_group_paths(psd_path)
            custom_group_values = groups
            custom_group_cb["values"] = groups
            preferred = ""
            for g in groups:
                if g.strip().split("/")[-1].casefold() == "paytable":
                    preferred = g
                    break
            if not preferred and groups:
                preferred = groups[0]
            custom_group_var.set(preferred)
            custom_status_var.set(f"Found {len(groups)} group(s). Select the page/group to export.")
            status_var.set("PSD groups scanned")
            if not groups:
                messagebox.showwarning("No Groups Found", "No groups were found in this PSD.")
        except Exception as e:
            custom_status_var.set("Group scan failed")
            status_var.set("PSD group scan failed")
            messagebox.showerror("Scan Error", f"Could not scan PSD/PSB groups:\n{e}")

    def _export_selected_group_json():
        psd_path = custom_psd_var.get().strip()
        group_path = custom_group_var.get().strip()
        slot_prefix = custom_slot_prefix_var.get().strip() or "@slot"
        status_var.set("Exporting JSON from selected PSD group...")
        custom_status_var.set(f"Running detector on selected group using prefix {slot_prefix}. Choose save location when Photoshop asks...")
        root.update()
        try:
            result = export_paytable_json_from_psd_group(psd_path, group_path, slot_prefix)
            _handle_export_result(result)
        except Exception as e:
            custom_status_var.set("Selected-group export failed")
            status_var.set("Selected-group JSON export failed")
            messagebox.showerror("Export Error", f"Could not export JSON from selected group:\n{e}")

    ttk.Label(tab_custom, text="Export layers starting with:").grid(row=2, column=0, sticky="w", padx=10, pady=(8, 4))
    custom_slot_prefix_cb = ttk.Combobox(
        tab_custom,
        textvariable=custom_slot_prefix_var,
        values=("@slot", "@table", "@page", "@heading", "@"),
        width=22,
    )
    custom_slot_prefix_cb.grid(row=2, column=1, sticky="w", padx=5, pady=(8, 4))
    ttk.Label(
        tab_custom,
        text="@slot keeps old exports. @table exports table component placeholders. @ scans every visible layer that starts with @.",
        foreground="gray",
    ).grid(row=2, column=2, columnspan=2, sticky="w", padx=8, pady=(8, 4))

    ttk.Button(
        tab_custom,
        text="Export JSON from Active PSD",
        command=_export_active_paytable_json,
    ).grid(row=3, column=0, sticky="w", padx=10, pady=(8, 8))
    ttk.Label(tab_custom, text="Uses the active Photoshop document. Selecting a group below is safer for custom layouts.", foreground="gray").grid(row=3, column=1, columnspan=3, sticky="w", padx=8)

    ttk.Separator(tab_custom, orient="horizontal").grid(row=4, column=0, columnspan=4, sticky="ew", padx=10, pady=12)
    ttk.Label(tab_custom, text="PSD/PSB file:").grid(row=5, column=0, sticky="w", padx=10, pady=4)
    ttk.Entry(tab_custom, textvariable=custom_psd_var, width=70).grid(row=5, column=1, sticky="ew", padx=5, pady=4)
    ttk.Button(tab_custom, text="Browse PSD/PSB", command=_browse_custom_psd).grid(row=5, column=2, sticky="w", padx=5, pady=4)
    ttk.Button(tab_custom, text="Load / Scan Groups", command=_scan_custom_psd_groups).grid(row=5, column=3, sticky="w", padx=5, pady=4)

    ttk.Label(tab_custom, text="Page/group to export:").grid(row=6, column=0, sticky="w", padx=10, pady=4)
    custom_group_cb = ttk.Combobox(tab_custom, textvariable=custom_group_var, width=68, state="readonly")
    custom_group_cb.grid(row=6, column=1, sticky="ew", padx=5, pady=4)
    ttk.Button(tab_custom, text="Export JSON from Selected Group", command=_export_selected_group_json).grid(row=6, column=2, columnspan=2, sticky="w", padx=5, pady=4)

    ttk.Label(
        tab_custom,
        textvariable=custom_status_var,
        style="Status.TLabel",
    ).grid(row=7, column=0, columnspan=4, sticky="ew", padx=10, pady=(10, 10))

    ttk.Label(
        tab_custom,
        text=(
            "Layer naming guide: use @slot.* for full-page/paytable slots and @table.<templateName>.* for table components. "
            "For example @table.cashExpressTrains.bounds, @table.cashExpressTrains.header.train, and @table.cashExpressTrains.row1.prizeIcon1. "
            "The exported JSON stores the chosen prefix and strips it from slot keys so mapper/rendering can work with clean names."
        ),
        foreground="gray",
        wraplength=980,
    ).grid(row=8, column=0, columnspan=4, sticky="w", padx=10, pady=(4, 10))

    def _mapped_template_saved(path, sheet_name):
        # The per-page override has router priority. Update it as well as the
        # fallback path so the very next Build uses the mapped production JSON,
        # even when the selected folder still contains an older Paytable.json.
        matched_override = False
        for item in custom_layout_pages:
            if item["name_var"].get().strip().casefold() == str(sheet_name).strip().casefold():
                item["json_var"].set(path)
                matched_override = True
                break
        if not matched_override:
            _add_custom_layout_page(str(sheet_name), path)
        _activate_paytable_json(path)
        dynamic_sheet_var.set(sheet_name)
        dynamic_enable_var.set(True)
        _refresh_paytable_json_library(select_active=True)
        paytable_mapper_status_var.set(
            f"Ready for Build: {sheet_name} is mapped to {path}"
        )
        custom_status_var.set(f"Mapped production JSON saved: {path}")
        status_var.set("Visual template mapping saved")

    def _open_paytable_mapper():
        sheet_name = dynamic_sheet_var.get().strip() or "Paytable"
        initial_json = dynamic_template_json_var.get().strip()
        paytable_mapper_status_var.set("Mapper open. Save with 'Save Mapped JSON' to use it in the next Build.")
        return open_table_mapper(
            root,
            initial_excel=excel_var.get().strip(),
            initial_json=initial_json,
            output_folder=dynamic_template_folder_var.get().strip(),
            on_saved=_mapped_template_saved,
            palette=palette,
            initial_font_size=int(dynamic_wild_text_size_spin.get()),
            icons_folder=icon_var.get().strip(),
            initial_icon_mappings=dict(icon_mappings),
        )

    tab_custom.columnconfigure(1, weight=1)

    # Production panels
    def _style_text_widget(widget):
        widget.configure(
            bg=palette["input_bg"],
            fg=palette["text"],
            insertbackground=palette["text"],
            relief="flat",
            bd=0,
            highlightthickness=1,
            highlightbackground=palette["border"],
            highlightcolor=palette["accent_alt"],
            font=(ui_font_family, 10),
            wrap="word",
        )

    def _set_text_widget(widget, value):
        if widget is None:
            return
        widget.configure(state="normal")
        widget.delete("1.0", tk.END)
        widget.insert("1.0", value or "")
        widget.configure(state="disabled")

    def _show_render_report(report, focus=False):
        text = format_render_report(report or last_render_report or {})
        _set_text_widget(render_report_text, text)
        if focus:
            try:
                _select_nav_target("report")
            except Exception:
                try:
                    notebook.select(tab_report_tab)
                except Exception:
                    pass
            try:
                root.deiconify()
                root.lift()
                root.focus_force()
            except Exception:
                pass

    def _save_report_now():
        if not last_render_report:
            messagebox.showwarning("Render Report", "No render report is available yet.")
            return
        fallback = output_dir_var.get().strip() or (os.path.dirname(excel_var.get()) if excel_var.get() else os.getcwd())
        path = save_render_report(last_render_report, last_render_report.get("output_psd_path", ""), fallback)
        messagebox.showinfo("Render Report", f"Saved render report:\n{path}")

    report_frame = ttk.LabelFrame(tab_report, text="Render Report")
    report_frame.pack(fill="both", expand=True, padx=10, pady=(10, 8))
    ttk.Label(report_frame, text="The report updates after Build, Update, Re-render, or Batch Export and is saved as render_report.txt next to the output PSD when possible.", foreground="gray", wraplength=900).grid(row=0, column=0, columnspan=3, sticky="w", padx=10, pady=(12, 8))
    ttk.Button(report_frame, text="Save Report Now", command=_save_report_now).grid(row=1, column=0, sticky="w", padx=10, pady=(0, 8))
    ttk.Button(report_frame, text="Refresh View", command=lambda: _show_render_report(last_render_report)).grid(row=1, column=1, sticky="w", padx=5, pady=(0, 8))
    render_report_text = tk.Text(report_frame, height=24)
    _style_text_widget(render_report_text)
    render_report_text.grid(row=2, column=0, columnspan=3, sticky="nsew", padx=10, pady=(0, 12))
    report_frame.rowconfigure(2, weight=1)
    report_frame.columnconfigure(2, weight=1)

    def _preset_folder():
        folder = preset_folder_var.get().strip() or os.path.join(os.path.dirname(__file__), "presets")
        os.makedirs(folder, exist_ok=True)
        return folder

    def _refresh_preset_list():
        if preset_listbox is None:
            return
        preset_listbox.delete(0, tk.END)
        folder = _preset_folder()
        for name in sorted([n for n in os.listdir(folder) if n.lower().endswith(".json")], key=str.casefold):
            preset_listbox.insert(tk.END, os.path.splitext(name)[0])

    def _selected_preset_name():
        if preset_listbox is not None and preset_listbox.curselection():
            return preset_listbox.get(preset_listbox.curselection()[0])
        return preset_name_var.get().strip()

    def _preset_path(name):
        return os.path.join(_preset_folder(), _safe_preset_name(name) + ".json")

    def _safe_preset_name(name):
        cleaned = "".join(ch if ch.isalnum() or ch in (" ", "-", "_") else "_" for ch in str(name or "").strip())
        return cleaned.strip() or "Style Preset"

    def _save_style_preset():
        name = _safe_preset_name(preset_name_var.get() or "Style Preset")
        with open(_preset_path(name), "w", encoding="utf-8") as handle:
            json.dump(_session_dict(), handle, indent=2)
        _refresh_preset_list()
        messagebox.showinfo("Preset Saved", f"Saved preset:\n{_preset_path(name)}")

    def _load_style_preset():
        name = _selected_preset_name()
        if not name:
            messagebox.showwarning("Presets", "Select a preset first.")
            return
        with open(_preset_path(name), "r", encoding="utf-8") as handle:
            _apply_loaded(json.load(handle))
        _save_current_session()
        messagebox.showinfo("Preset Loaded", f"Loaded preset: {name}")

    def _delete_style_preset():
        name = _selected_preset_name()
        if not name:
            return
        path = _preset_path(name)
        if os.path.exists(path) and messagebox.askyesno("Delete Preset", f"Delete preset '{name}'?"):
            os.remove(path)
            _refresh_preset_list()

    def _duplicate_style_preset():
        name = _selected_preset_name()
        if not name:
            return
        src = _preset_path(name)
        new_name = simpledialog.askstring("Duplicate Preset", "New preset name:", initialvalue=f"{name} Copy")
        if new_name and os.path.exists(src):
            with open(src, "r", encoding="utf-8") as handle:
                data = json.load(handle)
            with open(_preset_path(new_name), "w", encoding="utf-8") as handle:
                json.dump(data, handle, indent=2)
            _refresh_preset_list()

    preset_frame = ttk.LabelFrame(tab_presets, text="Style Presets")
    preset_frame.pack(fill="both", expand=True, padx=10, pady=(10, 8))
    ttk.Label(preset_frame, text="Presets store fonts, colors, sizes, margins, line heights, icon sizes, table/paytable/Game Rules settings, canvas settings, and keywords.", foreground="gray", wraplength=900).grid(row=0, column=0, columnspan=5, sticky="w", padx=10, pady=(12, 8))
    ttk.Label(preset_frame, text="Preset folder:").grid(row=1, column=0, sticky="w", padx=10, pady=4)
    ttk.Entry(preset_frame, textvariable=preset_folder_var, state="readonly", width=62).grid(row=1, column=1, columnspan=3, sticky="ew", pady=4)
    ttk.Button(preset_frame, text="Browse", command=lambda: (preset_folder_var.set(filedialog.askdirectory() or preset_folder_var.get()), _refresh_preset_list())).grid(row=1, column=4, padx=5, pady=4)
    preset_listbox = tk.Listbox(preset_frame, height=14, exportselection=False)
    _style_listbox(preset_listbox)
    preset_listbox.grid(row=2, column=0, columnspan=2, sticky="nsew", padx=10, pady=8)
    preset_scroll = ttk.Scrollbar(preset_frame, orient="vertical", command=preset_listbox.yview)
    preset_scroll.grid(row=2, column=2, sticky="ns", pady=8)
    preset_listbox.configure(yscrollcommand=preset_scroll.set)
    ttk.Label(preset_frame, text="Preset name:").grid(row=3, column=0, sticky="w", padx=10, pady=4)
    ttk.Entry(preset_frame, textvariable=preset_name_var, width=28).grid(row=3, column=1, sticky="w", pady=4)
    ttk.Button(preset_frame, text="Save Current", command=_save_style_preset).grid(row=4, column=0, sticky="ew", padx=10, pady=5)
    ttk.Button(preset_frame, text="Load Selected", command=_load_style_preset).grid(row=4, column=1, sticky="ew", padx=5, pady=5)
    ttk.Button(preset_frame, text="Duplicate", command=_duplicate_style_preset).grid(row=5, column=0, sticky="ew", padx=10, pady=5)
    ttk.Button(preset_frame, text="Delete", command=_delete_style_preset).grid(row=5, column=1, sticky="ew", padx=5, pady=5)
    preset_frame.rowconfigure(2, weight=1)
    preset_frame.columnconfigure(3, weight=1)
    _refresh_preset_list()

    def _refresh_preview_tabs():
        names = []
        if excel_var.get() and os.path.isfile(excel_var.get()):
            try:
                wb = load_workbook(excel_var.get(), read_only=True, data_only=False)
                names = list(wb.sheetnames)
                wb.close()
            except Exception:
                names = []
        preview_sheet_cb["values"] = names
        if names and preview_sheet_var.get() not in names:
            preview_sheet_var.set(names[0])
    def _run_preview():
        _refresh_preview_tabs()
        text = preview_excel_tab(excel_var.get(), preview_sheet_var.get(), int(max_col_spin.get()))
        missing = scan_icon_status(excel_var.get(), icon_var.get(), icon_mappings, icon_size_overrides) if excel_var.get() else []
        missing_names = [row["token"] for row in missing if row["status"] == "Missing"]
        if missing_names:
            text += "\n\nOverflow/Icon warnings:\n- Missing icons: " + ", ".join(f"<{name}>" for name in missing_names[:30])
        if auto_fit_enabled_var.get():
            text += f"\n- Auto Text Fit mode selected: {auto_fit_mode_var.get()}"
        _set_text_widget(preview_text, text)

    def _run_diff_preview(show_message=False):
        diff = excel_diff_summary(prev_excel_var.get(), excel_var.get(), int(max_col_spin.get()))
        lines = ["Excel Diff Preview", "==================", ""]
        for title, key in (("Changed", "changed"), ("Added", "added"), ("Removed", "removed"), ("Unchanged", "unchanged")):
            values = diff.get(key, [])
            lines.append(f"{title}: {len(values)}")
            lines.extend(f"- {value}" for value in values[:80])
            lines.append("")
        if diff.get("details"):
            lines.append("Details")
            lines.append("-------")
            lines.extend(f"- {value}" for value in diff["details"][:120])
        text = "\n".join(lines)
        _set_text_widget(diff_preview_text, text)
        if show_message:
            messagebox.showinfo("Excel Diff Preview", text[:1800] + ("\n..." if len(text) > 1800 else ""))
        return diff

    def _confirm_update_diff():
        if not confirm_update_diff_var.get():
            return True
        diff = _run_diff_preview(show_message=False)
        total = sum(len(diff.get(key, [])) for key in ("changed", "added", "removed"))
        summary = f"Changed/added/removed pages: {total}\n\nChanged: {len(diff.get('changed', []))}\nAdded: {len(diff.get('added', []))}\nRemoved: {len(diff.get('removed', []))}\nUnchanged: {len(diff.get('unchanged', []))}\n\nContinue with Update PSD?"
        return messagebox.askyesno("Confirm Update PSD", summary)

    preview_frame = ttk.LabelFrame(tab_preview, text="Preview Before Render")
    preview_frame.pack(fill="both", expand=True, padx=10, pady=(10, 8))
    ttk.Label(preview_frame, text="Lightweight Excel preview. It does not open Photoshop; it helps catch missing icons and obvious overflow risks before rendering.", foreground="gray", wraplength=900).grid(row=0, column=0, columnspan=5, sticky="w", padx=10, pady=(12, 8))
    ttk.Label(preview_frame, text="Excel tab:").grid(row=1, column=0, sticky="w", padx=10, pady=4)
    preview_sheet_cb = ttk.Combobox(preview_frame, textvariable=preview_sheet_var, width=34, state="readonly")
    preview_sheet_cb.grid(row=1, column=1, sticky="w", pady=4)
    ttk.Button(preview_frame, text="Refresh Tabs", command=_refresh_preview_tabs).grid(row=1, column=2, padx=5, pady=4)
    ttk.Button(preview_frame, text="Preview Selected Tab", command=_run_preview).grid(row=1, column=3, padx=5, pady=4)
    preview_text = tk.Text(preview_frame, height=16)
    _style_text_widget(preview_text)
    preview_text.grid(row=2, column=0, columnspan=5, sticky="nsew", padx=10, pady=(8, 12))
    preview_frame.rowconfigure(2, weight=1)
    preview_frame.columnconfigure(4, weight=1)

    diff_frame = ttk.LabelFrame(tab_preview, text="Excel Diff Preview")
    diff_frame.pack(fill="both", expand=True, padx=10, pady=(0, 8))
    ttk.Button(diff_frame, text="Show Old vs New Excel Diff", command=lambda: _run_diff_preview(show_message=False)).grid(row=0, column=0, sticky="w", padx=10, pady=(12, 8))
    _make_toggle(diff_frame, "Ask confirmation before Update PSD", confirm_update_diff_var, width=38).grid(row=0, column=1, sticky="w", padx=10, pady=(12, 8))
    diff_preview_text = tk.Text(diff_frame, height=14)
    _style_text_widget(diff_preview_text)
    diff_preview_text.grid(row=1, column=0, columnspan=4, sticky="nsew", padx=10, pady=(0, 12))
    diff_frame.rowconfigure(1, weight=1)
    diff_frame.columnconfigure(3, weight=1)

    safety_frame = ttk.LabelFrame(tab_safety, text="Backup & Safety")
    safety_frame.pack(fill="x", padx=10, pady=(10, 8))
    _make_toggle(safety_frame, "Save PSD backup before destructive update/re-render", safe_backup_enabled_var, width=54).grid(row=0, column=0, columnspan=4, sticky="w", padx=10, pady=(12, 8))
    ttk.Label(safety_frame, text="Backup folder:").grid(row=1, column=0, sticky="w", padx=10, pady=4)
    ttk.Entry(safety_frame, textvariable=safe_backup_folder_var, state="readonly", width=58).grid(row=1, column=1, sticky="ew", pady=4)
    ttk.Button(safety_frame, text="Browse", command=lambda: safe_backup_folder_var.set(filedialog.askdirectory() or safe_backup_folder_var.get())).grid(row=1, column=2, padx=5, pady=4)
    ttk.Button(safety_frame, text="Clear", command=lambda: safe_backup_folder_var.set("")).grid(row=1, column=3, padx=5, pady=4)
    _make_toggle(safety_frame, "Prefer copy mode for re-render page groups", safe_duplicate_group_var, width=42).grid(row=2, column=0, columnspan=4, sticky="w", padx=10, pady=8)
    ttk.Label(safety_frame, text="Blank backup folder uses a _BACKUP folder next to the PSD. Copy mode does not delete old selected page groups.", foreground="gray", wraplength=900).grid(row=3, column=0, columnspan=4, sticky="w", padx=10, pady=(0, 12))
    safety_frame.columnconfigure(1, weight=1)

    auto_fit_frame = ttk.LabelFrame(tab_safety, text="Auto Text Fit")
    auto_fit_frame.pack(fill="x", padx=10, pady=(0, 8))
    _make_toggle(auto_fit_frame, "Enable Auto Text Fit preflight", auto_fit_enabled_var, width=36).grid(row=0, column=0, sticky="w", padx=10, pady=(12, 8))
    ttk.Label(auto_fit_frame, text="Mode:").grid(row=0, column=1, sticky="e", padx=10, pady=(12, 8))
    ttk.Combobox(auto_fit_frame, textvariable=auto_fit_mode_var, values=["Warn only", "Reduce font size", "Reduce line height", "Reduce paragraph spacing", "Move overflow to next page"], width=28, state="readonly").grid(row=0, column=2, sticky="w", pady=(12, 8))
    ttk.Label(auto_fit_frame, text="This release logs auto-fit intent in previews/reports and keeps the existing renderer overflow behavior intact.", foreground="gray", wraplength=850).grid(row=1, column=0, columnspan=4, sticky="w", padx=10, pady=(0, 12))

    def _refresh_export_groups():
        if not batch_export_psd_var.get().strip():
            batch_export_psd_var.set(rerender_psd_var.get().strip() or prev_psd_var.get().strip())
        if export_group_listbox is None:
            return
        selected_now = {export_group_listbox.get(i) for i in export_group_listbox.curselection()}
        export_group_listbox.delete(0, tk.END)
        psd_path = batch_export_psd_var.get().strip()
        if not psd_path:
            return
        try:
            groups = list_psd_top_level_groups(psd_path)
        except Exception as exc:
            messagebox.showerror("Batch Export", f"Could not read PSD groups:\n{exc}")
            return
        for name in groups:
            export_group_listbox.insert(tk.END, name)
        for idx in range(export_group_listbox.size()):
            if export_group_listbox.get(idx) in selected_now:
                export_group_listbox.selection_set(idx)

    def _select_all_export_groups():
        if export_group_listbox is not None:
            export_group_listbox.selection_set(0, tk.END)

    def _clear_export_groups():
        if export_group_listbox is not None:
            export_group_listbox.selection_clear(0, tk.END)

    def _show_dashboard_batch_export():
        _refresh_export_groups()
        if not dashboard_export_nb.winfo_ismapped():
            dashboard_export_nb.pack(fill="x", padx=10, pady=(0, 12))
        dashboard_export_nb.select(tab_dashboard_export)

    def _browse_export_psd():
        path = filedialog.askopenfilename(filetypes=[("Photoshop", "*.psd;*.psb"), ("All files", "*.*")])
        if path:
            batch_export_psd_var.set(path)
            _refresh_export_groups()

    def _run_batch_export():
        selected = []
        if export_group_listbox is not None:
            selected = [export_group_listbox.get(i) for i in export_group_listbox.curselection()]
        if not selected:
            messagebox.showwarning("Batch Export", "Select one or more PSD groups to export.")
            return
        report = start_render_report("Batch Export", selected)
        try:
            exported = batch_export_psd_groups(
                batch_export_psd_var.get().strip(),
                batch_export_folder_var.get().strip(),
                selected,
                batch_export_format_var.get(),
                int(batch_export_quality_var.get() or 90),
                batch_export_transparent_var.get(),
                batch_export_suffix_var.get(),
                True,
                False,
                batch_export_bottom_to_top_var.get(),
            )
            report["rendered_pages"] = [os.path.basename(path) for path in exported]
            report["notes"].append(f"Exported {len(exported)} file(s).")
            report["notes"].append(f"Selected PSD groups: {', '.join(selected)}")
            report["notes"].append(f"Export mode: selected_groups=True, bottom_to_top={batch_export_bottom_to_top_var.get()}, suffix={batch_export_suffix_var.get() or 'MyExport'}.")
            finish_render_report(report, batch_export_psd_var.get().strip())
            last_render_report.clear(); last_render_report.update(report)
            _show_render_report(report)
            save_render_report(report, batch_export_psd_var.get().strip(), batch_export_folder_var.get().strip())
            messagebox.showinfo("Batch Export", f"Exported {len(exported)} file(s).")
        except Exception as exc:
            report["errors"].append(str(exc))
            finish_render_report(report, batch_export_psd_var.get().strip())
            last_render_report.clear(); last_render_report.update(report)
            _show_render_report(report)
            messagebox.showerror("Batch Export", f"Batch export failed:\n{exc}")

    export_frame = ttk.LabelFrame(tab_dashboard_export, text="Batch Export")
    export_frame.pack(fill="x", padx=10, pady=12)
    ttk.Label(export_frame, text="Select the PSD page groups you want to export. The exporter duplicates each selected group, hides everything else, and saves it with suffix numbering.", foreground="gray", wraplength=900).grid(row=0, column=0, columnspan=5, sticky="w", padx=10, pady=(12, 8))
    ttk.Label(export_frame, text="PSD/PSB:").grid(row=1, column=0, sticky="w", padx=10, pady=4)
    ttk.Entry(export_frame, textvariable=batch_export_psd_var, state="readonly", width=62).grid(row=1, column=1, columnspan=2, sticky="ew", pady=4)
    ttk.Button(export_frame, text="Browse", command=_browse_export_psd).grid(row=1, column=3, padx=5, pady=4)
    ttk.Button(export_frame, text="Use Current PSD", command=lambda: batch_export_psd_var.set(rerender_psd_var.get().strip() or prev_psd_var.get().strip())).grid(row=1, column=4, padx=5, pady=4)
    ttk.Label(export_frame, text="Output folder:").grid(row=2, column=0, sticky="w", padx=10, pady=4)
    ttk.Entry(export_frame, textvariable=batch_export_folder_var, state="readonly", width=62).grid(row=2, column=1, columnspan=2, sticky="ew", pady=4)
    ttk.Button(export_frame, text="Browse", command=lambda: batch_export_folder_var.set(filedialog.askdirectory() or batch_export_folder_var.get())).grid(row=2, column=3, padx=5, pady=4)
    ttk.Label(export_frame, text="Format:").grid(row=3, column=0, sticky="w", padx=10, pady=4)
    ttk.Combobox(export_frame, textvariable=batch_export_format_var, values=["PNG", "JPG", "PSD", "PDF"], width=8, state="readonly").grid(row=3, column=1, sticky="w", pady=4)
    ttk.Label(export_frame, text="JPG quality:").grid(row=3, column=2, sticky="e", padx=10, pady=4)
    ttk.Entry(export_frame, textvariable=batch_export_quality_var, width=8).grid(row=3, column=3, sticky="w", pady=4)
    ttk.Label(export_frame, text="Suffix:").grid(row=4, column=0, sticky="w", padx=10, pady=4)
    ttk.Entry(export_frame, textvariable=batch_export_suffix_var, width=24).grid(row=4, column=1, sticky="w", pady=4)
    ttk.Button(export_frame, text="Refresh PSD Groups", command=_refresh_export_groups).grid(row=5, column=0, sticky="w", padx=10, pady=(10, 6))
    ttk.Button(export_frame, text="Select All", command=_select_all_export_groups).grid(row=5, column=1, sticky="w", padx=5, pady=(10, 6))
    ttk.Button(export_frame, text="Clear", command=_clear_export_groups).grid(row=5, column=2, sticky="w", padx=5, pady=(10, 6))
    export_group_listbox = tk.Listbox(export_frame, selectmode=tk.MULTIPLE, height=8, exportselection=False)
    _style_listbox(export_group_listbox)
    export_group_listbox.grid(row=6, column=0, columnspan=4, sticky="nsew", padx=(10, 0), pady=(4, 10))
    export_scroll = ttk.Scrollbar(export_frame, orient="vertical", command=export_group_listbox.yview)
    export_scroll.grid(row=6, column=4, sticky="ns", padx=(0, 10), pady=(4, 10))
    export_group_listbox.configure(yscrollcommand=export_scroll.set)
    _make_toggle(export_frame, "Bottom-to-top order", batch_export_bottom_to_top_var, width=26).grid(row=7, column=0, columnspan=2, sticky="w", padx=10, pady=6)
    _make_toggle(export_frame, "Transparent PNG when possible", batch_export_transparent_var, width=34).grid(row=7, column=2, columnspan=3, sticky="w", padx=10, pady=6)
    ttk.Button(export_frame, text="Batch Export Selected Groups", command=_run_batch_export, style="Primary.TButton").grid(row=8, column=1, columnspan=2, sticky="ew", padx=5, pady=(10, 14))
    export_frame.rowconfigure(6, weight=1)
    export_frame.columnconfigure(2, weight=1)

    guide_frame = ttk.LabelFrame(tab_guide, text="Layer Naming Guide")
    guide_frame.pack(fill="both", expand=True, padx=10, pady=(10, 8))
    guide_text = tk.Text(guide_frame, height=28)
    _style_text_widget(guide_text)
    guide_text.grid(row=0, column=0, sticky="nsew", padx=10, pady=12)
    _set_text_widget(guide_text, (
        "Normal Page Group Structure\n"
        "===========================\n"
        "- Each Excel tab becomes a top-level Photoshop group named after the tab.\n"
        "- Continued pages use the same tab base name with a page suffix.\n"
        "- Heading text and heading symbols are grouped separately so text FX do not touch icons.\n"
        "- Body text, inline icons, tables, and custom layout objects remain inside the page group.\n\n"
        "Paytable / Custom Layout JSON Slots\n"
        "===================================\n"
        "- title: main page title.\n"
        "- pic1, pic2, pic3, pic4, pic5: top symbol card artwork slots.\n"
        "- ace, king, queen, jack, ten / 10: lower symbol artwork slots.\n"
        "- symbol.1, symbol.2, etc.: repeated generic symbol slots.\n"
        "- wild, wild.icon, feature.icon: feature/wild/scatter artwork.\n"
        "- wild.title, wild.text1, wild.text2: side-panel text slots.\n"
        "- bottom_notes: lower rules/notes block.\n"
        "- FLOW|B5:O6: measured text plus inline <icon> tokens from an Excel range.\n"
        "- TEXT|B8:O8: measured literal text from an Excel range.\n"
        "- FLOW|PT_RULES_TOP: the same behavior using an Excel named range.\n"
        "- JSON flow_regions can stack several ranges or named ranges inside one slot.\n\n"
        "Visual Template Mapper\n"
        "======================\n"
        "- Artists may use generic placeholders such as @slot.region.1 and @slot.icon.1.\n"
        "- Export the base slot JSON, then open the Visual Template Mapper under Export JSON.\n"
        "- Map Excel rows to regions, or expand a row and map individual tokens to dedicated icon slots.\n"
        "- The mapper generates flow_regions and token_bindings automatically.\n\n"
        "Dynamic Table JSON Slots\n"
        "========================\n"
        "- Name table placeholder layers with @table, then export JSON using the @table prefix.\n"
        "- Fixed table: use @table.tableName.bounds plus slots like @table.tableName.header.title and @table.tableName.row1.prizeText.\n"
        "- Repeating table: draw one artist row with @table.tableName.rowTemplate.icon, @table.tableName.rowTemplate.text, etc.\n"
        "- Open the Dynamic Table JSON Mapper in the Tables tab to connect Excel cells, ranges, and <icon> tokens to slots.\n"
        "- Expand an Excel row in the mapper to assign exact cells such as D8, H8, or J8 instead of the whole row.\n"
        "- Select multiple Excel cells/ranges together to combine them into one slot when a slot needs several pieces of text.\n"
        "- The mapper saves table_templates and export_kind=table while keeping slots and table_slots for compatibility.\n"
        "- Build can insert mapped tables after an Excel row, at a <table:tableName> marker, or at an absolute position.\n\n"
        "Exporter Naming Tip\n"
        "===================\n"
        "In Photoshop, prefix placeholder layers with @slot, for example @slot.title, @slot.pic1, or @slot.FLOW|B5:O6. Save JSON with the exact Excel tab name, such as Paytable.json."
    ))
    guide_frame.rowconfigure(0, weight=1)
    guide_frame.columnconfigure(0, weight=1)

    # Layout & Build
    build_spacing_frame = ttk.LabelFrame(tab_build, text="Page Flow & Margins")
    build_spacing_frame.pack(fill="x", padx=10, pady=(10, 8))
    ttk.Label(build_spacing_frame, text="L/R Margins:").grid(row=0, column=0, sticky="w", pady=(12, 6), padx=10)
    margin_spin = ttk.Spinbox(build_spacing_frame, from_=0, to=500, width=7); margin_spin.set(80); margin_spin.grid(row=0, column=1, sticky="w", pady=(12, 6))
    ttk.Label(build_spacing_frame, text="Line Spacing:").grid(row=1, column=0, sticky="w", pady=6, padx=10)
    line_spin = ttk.Spinbox(build_spacing_frame, from_=0, to=100, width=7); line_spin.set(25); line_spin.grid(row=1, column=1, sticky="w", pady=6)
    ttk.Label(build_spacing_frame, text="Para Spacing:").grid(row=2, column=0, sticky="w", pady=6, padx=10)
    para_spin = ttk.Spinbox(build_spacing_frame, from_=0, to=200, width=7); para_spin.set(40); para_spin.grid(row=2, column=1, sticky="w", pady=6)
    ttk.Label(build_spacing_frame, text="Heading Top Margin:").grid(row=3, column=0, sticky="w", pady=6, padx=10)
    heading_margin_spin = ttk.Spinbox(build_spacing_frame, from_=0, to=500, width=7); heading_margin_spin.set(150); heading_margin_spin.grid(row=3, column=1, sticky="w", pady=6)
    ttk.Label(build_spacing_frame, text="Bottom Safe Margin:").grid(row=4, column=0, sticky="w", pady=6, padx=10)
    bottom_margin_spin = ttk.Spinbox(build_spacing_frame, from_=0, to=500, width=7); bottom_margin_spin.set(50); bottom_margin_spin.grid(row=4, column=1, sticky="w", pady=6)
    ttk.Label(build_spacing_frame, text="No normal text/table content will intentionally render inside this bottom area.", foreground="gray").grid(row=4, column=2, sticky="w", pady=6)
    ttk.Label(build_spacing_frame, text="Continued Gap:").grid(row=5, column=0, sticky="w", pady=6, padx=10)
    continued_gap_spin = ttk.Spinbox(build_spacing_frame, from_=0, to=100, width=7); continued_gap_spin.set(15); continued_gap_spin.grid(row=5, column=1, sticky="w", pady=6)
    ttk.Label(build_spacing_frame, text="Distance between heading and (Continued), in px.", foreground="gray").grid(row=5, column=2, sticky="w", pady=6)
    ttk.Label(build_spacing_frame, text="Text/Table Gap After Heading:").grid(row=6, column=0, sticky="w", pady=6, padx=10)
    heading_to_body_gap_spin = ttk.Spinbox(build_spacing_frame, from_=0, to=250, width=7); heading_to_body_gap_spin.set(40); heading_to_body_gap_spin.grid(row=6, column=1, sticky="w", pady=6)
    ttk.Label(build_spacing_frame, text="Distance after heading or continued label before body/table starts.", foreground="gray").grid(row=6, column=2, sticky="w", pady=6)

    build_note_frame = ttk.LabelFrame(tab_build, text="Workflow Notes")
    build_note_frame.pack(fill="x", padx=10, pady=(0, 8))
    ttk.Label(build_note_frame, text="Existing PSD update controls live in the Update PSD tab. Inline icon sizing and offsets now live in the Icons tab.", foreground="gray", wraplength=860).grid(row=0, column=0, sticky="w", padx=10, pady=12)

    def _session_dict():
        return {
            'excel_path': excel_var.get(), 'prev_excel_path': prev_excel_var.get(), 'prev_psd_path': prev_psd_var.get(),
            'icon_folder': icon_var.get(), 'bg_path': bg_var.get(), 'output_dir': output_dir_var.get(),
            'output_name': output_name_var.get(), 'output_format': output_format_var.get(),
            'update_save_mode': update_save_mode_var.get(), 'rerender_psd': rerender_psd_var.get(), 'rerender_mode': rerender_mode_var.get(), 'canvas_preset': canvas_preset_var.get(),
            'preset_folder': preset_folder_var.get(),
            'auto_fit_enabled': auto_fit_enabled_var.get(), 'auto_fit_mode': auto_fit_mode_var.get(),
            'safe_backup_enabled': safe_backup_enabled_var.get(), 'safe_backup_folder': safe_backup_folder_var.get(),
            'safe_duplicate_group': safe_duplicate_group_var.get(), 'confirm_update_diff': confirm_update_diff_var.get(),
            'performance_mode': performance_mode_var.get(),
            'batch_export_psd': batch_export_psd_var.get(), 'batch_export_folder': batch_export_folder_var.get(),
            'batch_export_format': batch_export_format_var.get(), 'batch_export_quality': batch_export_quality_var.get(),
            'batch_export_suffix': batch_export_suffix_var.get(),
            'batch_export_transparent': batch_export_transparent_var.get(),
            'batch_export_groups': batch_export_groups_var.get(), 'batch_export_layers': batch_export_layers_var.get(),
            'batch_export_bottom_to_top': batch_export_bottom_to_top_var.get(),
            'render_selected_pages': render_selected_pages_var.get(), 'selected_sheet_names': _selected_sheet_names(),
            'page_render_column_overrides': page_render_column_overrides_text.get("1.0", "end-1c"),
            'custom_canvas_presets': dict(custom_canvas_presets), 'bg_mode': bg_mode_var.get(),
            'canvas_w': c_w_spin.get(), 'canvas_h': c_h_spin.get(), 'max_col': max_col_spin.get(),
            'h_font': h_font_cb.get(), 'h_font_style': h_font_style_var.get(), 'h_size': h_size_spin.get(), 'h_icon_h': h_icon_spin.get(), 'h_rgb': h_rgb_val,
            'heading_image_folder': heading_image_folder_var.get(), 'heading_image_height': heading_image_height_spin.get(),
            'heading_uppercase_enabled': heading_uppercase_var.get(),
            'heading_game_name_text': heading_game_name_text_var.get(),
            'heading_keep_one_line': heading_keep_one_line_var.get(),
            'heading_one_line_margin': heading_one_line_margin_spin.get(),
            'heading_size_overrides': heading_size_overrides_text.get("1.0", "end-1c"),
            'page_multi_heading_overrides': page_multi_heading_text.get("1.0", "end-1c"),
            'b_font': b_font_cb.get(), 'b_font_style': b_font_style_var.get(), 'b_size': b_size_spin.get(), 'b_icon_h': b_icon_spin.get(), 'b_rgb': b_rgb_val,
            'body_icons_use_original_size': body_icon_original_size_var.get(),
            'subheading_font': subheading_font_cb.get(), 'subheading_font_style': subheading_font_style_var.get(),
            'subheading_size': subheading_size_spin.get(), 'subheading_rgb': subheading_rgb_val,
            'subheading_hex': subheading_text_color_var.get(),
            'page_heading_cell_overrides': page_heading_cells_text.get("1.0", "end-1c"),
            'page_subheading_cell_overrides': page_subheading_cells_text.get("1.0", "end-1c"),
            'margin': margin_spin.get(), 'line_spacing': line_spin.get(), 'para_spacing': para_spin.get(),
            'gap': gap_spin.get(), 'icon_y_offset': yoff_spin.get(), 'enable_tables': enable_tables_var.get(),
            'mapped_table_json': mapped_table_json_var.get(),
            'json_sheet_overrides': dict(json_sheet_overrides),
            'manual_table_ranges': manual_table_ranges_text.get("1.0", "end-1c"),
            'table_excel_fill_ranges': table_excel_fill_ranges_text.get("1.0", "end-1c"),
            'table_excel_fill_hex_overrides': table_excel_fill_hex_overrides_text.get("1.0", "end-1c"),
            'table_excel_font_color_ranges': table_excel_font_color_ranges_text.get("1.0", "end-1c"),
            'table_excel_font_hex_overrides': table_excel_font_hex_overrides_text.get("1.0", "end-1c"),
            'table_merge_layers': table_merge_layers_var.get(),
            'text_rectangle_cells': text_rectangle_cells_text.get("1.0", "end-1c"),
            'text_rectangle_fill_rgb': text_rect_fill_rgb_val, 'text_rectangle_fill_hex': text_rect_fill_var.get(),
            'text_rectangle_stroke_rgb': text_rect_stroke_rgb_val, 'text_rectangle_stroke_hex': text_rect_stroke_var.get(),
            'text_rectangle_stroke_width': text_rect_stroke_width_spin.get(), 'text_rectangle_opacity': text_rect_opacity_spin.get(),
            'text_rectangle_font': text_rect_font_cb.get(), 'text_rectangle_font_style': text_rect_font_style_var.get(),
            'text_rectangle_font_size': text_rect_font_size_spin.get(),
            'text_rectangle_text_rgb': text_rect_text_rgb_val, 'text_rectangle_text_hex': text_rect_text_color_var.get(),
            'text_rectangle_alignment': text_rect_alignment_var.get(),
            'text_rectangle_pad_x': text_rect_pad_x_spin.get(), 'text_rectangle_pad_y': text_rect_pad_y_spin.get(),
            'table_opacity': table_opacity_spin.get(), 'table_cell_style': cell_style_cb.get(),
            'table_stroke_rgb': table_stroke_rgb_val, 'table_stroke_width': stroke_width_spin.get(),
            'table_stroke_color_hex': stroke_color_var.get(), 'table_header_rgb': table_header_rgb_val,
            'table_row1_rgb': table_row1_rgb_val, 'table_row2_rgb': table_row2_rgb_val,
            'table_header_hex': header_fill_var.get(), 'table_row1_hex': row1_fill_var.get(), 'table_row2_hex': row2_fill_var.get(),
            'table_header_style_mode': header_style_cb.get(), 'table_row1_style_mode': row1_style_cb.get(), 'table_row2_style_mode': row2_style_cb.get(),
            'row_gap': row_gap_spin.get(), 'table_inherit_font': table_inherit_font_var.get(),
            'table_header_font': table_header_font_cb.get(), 'table_header_font_style': table_header_font_style_var.get(), 'table_header_font_size': table_header_size_spin.get(),
            'table_body_font': table_body_font_cb.get(), 'table_body_font_style': table_body_font_style_var.get(), 'table_body_font_size': table_body_size_spin.get(),
            'table_icon_height': table_icon_height_spin.get(), 'table_target_height': table_target_height_spin.get(), 'table_target_width': table_target_width_spin.get(),
            'table_header_text_rgb': table_header_text_rgb_val, 'table_header_text_hex': table_header_text_color_var.get(),
            'table_body_text_rgb': table_body_text_rgb_val, 'table_body_text_hex': table_body_text_color_var.get(),
            'table_after_margin': table_after_margin_spin.get(), 'table_min_text_room': table_min_text_room_spin.get(),
            'heading_top_margin': heading_margin_spin.get(), 'bottom_margin': bottom_margin_spin.get(), 'continued_gap': continued_gap_spin.get(), 'heading_to_body_gap': heading_to_body_gap_spin.get(),
            'paste_heading_style': paste_heading_style_var.get(),
            'copied_heading_style_name': copied_heading_style_name_var.get(),
            'h_stroke_enabled': h_stroke_enable_var.get(), 'h_stroke_rgb': h_stroke_rgb_val, 'h_stroke_hex': h_stroke_color_var.get(),
            'h_stroke_size': h_stroke_size_spin.get(), 'h_stroke_opacity': h_stroke_opacity_spin.get(),
            'h_shadow_enabled': h_shadow_enable_var.get(), 'h_shadow_rgb': h_shadow_rgb_val, 'h_shadow_hex': h_shadow_color_var.get(), 'h_shadow_blend_mode': h_shadow_blend_var.get(),
            'h_shadow_opacity': h_shadow_opacity_spin.get(), 'h_shadow_distance': h_shadow_distance_spin.get(),
            'h_shadow_size': h_shadow_size_spin.get(), 'h_shadow_angle': h_shadow_angle_spin.get(), 'h_shadow_spread': h_shadow_spread_spin.get(),
            'heading_captured_effects_hex': heading_captured_style.get('hex', ''),
            'heading_captured_params': heading_captured_style.get('params') or {},
            'paste_body_style': paste_body_style_var.get(), 'copied_body_style_name': copied_body_style_name_var.get(),
            'b_stroke_enabled': b_stroke_enable_var.get(), 'b_stroke_rgb': b_stroke_rgb_val, 'b_stroke_hex': b_stroke_color_var.get(),
            'b_stroke_size': b_stroke_size_spin.get(), 'b_stroke_opacity': b_stroke_opacity_spin.get(),
            'b_shadow_enabled': b_shadow_enable_var.get(), 'b_shadow_rgb': b_shadow_rgb_val, 'b_shadow_hex': b_shadow_color_var.get(), 'b_shadow_blend_mode': b_shadow_blend_var.get(),
            'b_shadow_opacity': b_shadow_opacity_spin.get(), 'b_shadow_distance': b_shadow_distance_spin.get(),
            'b_shadow_size': b_shadow_size_spin.get(), 'b_shadow_angle': b_shadow_angle_spin.get(), 'b_shadow_spread': b_shadow_spread_spin.get(),
            'body_captured_effects_hex': body_captured_style.get('hex', ''),
            'body_captured_params': body_captured_style.get('params') or {},
            'layer_style_library': dict(layer_style_library), 'heading_saved_style': heading_saved_style_var.get(),
            'body_saved_style': body_saved_style_var.get(), 'icon_layer_style_enabled': icon_layer_style_enabled_var.get(),
            'icon_saved_style': icon_saved_style_var.get(),
            'dynamic_enabled': dynamic_enable_var.get(), 'dynamic_sheet_name': dynamic_sheet_var.get(), 'dynamic_template_json': dynamic_template_json_var.get(),
            'dynamic_template_folder': dynamic_template_folder_var.get(), 'dynamic_wild_asset': dynamic_wild_asset_var.get(),
            'dynamic_wild_title_slot_enabled': dynamic_wild_title_slot_enabled_var.get(), 'dynamic_wild_title_slot_text': dynamic_wild_title_slot_text_var.get(),
            'dynamic_scatter_title_slot_enabled': dynamic_scatter_title_slot_enabled_var.get(), 'dynamic_scatter_title_slot_text': dynamic_scatter_title_slot_text_var.get(),
            'custom_layout_pages': [
                {'name': item['name_var'].get(), 'json': item['json_var'].get()}
                for item in custom_layout_pages
            ],
            'dynamic_top_icon_height': dynamic_top_icon_height_spin.get(), 'dynamic_lower_icon_height': dynamic_lower_icon_height_spin.get(),
            'dynamic_wild_icon_height': dynamic_wild_icon_height_spin.get(), 'dynamic_inline_icon_height': dynamic_inline_icon_height_spin.get(), 'dynamic_inline_icon_gap': dynamic_inline_icon_gap_spin.get(),
            'dynamic_inline_line_height': dynamic_inline_line_height_spin.get(),
            'payout_placement_mode': payout_placement_mode_var.get(),
            'dynamic_count_font': dynamic_count_font_cb.get(), 'dynamic_count_font_style': dynamic_count_font_style_var.get(),
            'dynamic_count_size': dynamic_count_size_spin.get(), 'dynamic_count_rgb': dynamic_count_rgb_val, 'dynamic_count_hex': dynamic_count_color_var.get(),
            'dynamic_value_font': dynamic_value_font_cb.get(), 'dynamic_value_font_style': dynamic_value_font_style_var.get(),
            'dynamic_value_size': dynamic_value_size_spin.get(), 'dynamic_value_rgb': dynamic_value_rgb_val, 'dynamic_value_hex': dynamic_value_color_var.get(),
            'dynamic_fallback_size': dynamic_fallback_size_spin.get(), 'dynamic_fallback_rgb': dynamic_fallback_rgb_val, 'dynamic_fallback_hex': dynamic_fallback_color_var.get(),
            'dynamic_top_bg_rgb': dynamic_top_bg_rgb_val, 'dynamic_top_bg_hex': dynamic_top_bg_color_var.get(), 'dynamic_top_bg_opacity': dynamic_top_bg_opacity_spin.get(),
            'dynamic_lower_bg_rgb': dynamic_lower_bg_rgb_val, 'dynamic_lower_bg_hex': dynamic_lower_bg_color_var.get(), 'dynamic_lower_bg_opacity': dynamic_lower_bg_opacity_spin.get(),
            'dynamic_card_stroke_rgb': dynamic_card_stroke_rgb_val, 'dynamic_card_stroke_hex': dynamic_card_stroke_color_var.get(), 'dynamic_card_stroke_width': dynamic_card_stroke_width_spin.get(),
            'dynamic_text_bg_rgb': dynamic_text_bg_rgb_val, 'dynamic_text_bg_hex': dynamic_text_bg_color_var.get(), 'dynamic_text_bg_opacity': dynamic_text_bg_opacity_spin.get(),
            'dynamic_wild_title_size': dynamic_wild_title_size_spin.get(), 'dynamic_wild_title_rgb': dynamic_wild_title_rgb_val, 'dynamic_wild_title_hex': dynamic_wild_title_color_var.get(),
            'dynamic_wild_text_size': dynamic_wild_text_size_spin.get(), 'dynamic_wild_text_rgb': dynamic_wild_text_rgb_val, 'dynamic_wild_text_hex': dynamic_wild_text_color_var.get(),
            'dynamic_notes_size': dynamic_notes_size_spin.get(), 'dynamic_notes_rgb': dynamic_notes_rgb_val, 'dynamic_notes_hex': dynamic_notes_color_var.get(),
            'game_rules_bottom_font': game_rules_bottom_font_cb.get(), 'game_rules_bottom_font_style': game_rules_bottom_font_style_var.get(),
            'game_rules_bottom_size': game_rules_bottom_size_spin.get(), 'game_rules_bottom_gap': game_rules_bottom_gap_spin.get(),
            'game_rules_legal_split_overrides': game_rules_legal_split_text.get("1.0", "end-1c"),
            'bingo_rules_one_page': bingo_rules_one_page_var.get(),
            'bingo_rules_body_size': bingo_rules_body_size_spin.get(),
            'bingo_rules_body_ranges': bingo_rules_body_ranges_var.get(),
            'bingo_rules_alignment_overrides': bingo_rules_alignment_text.get("1.0", "end-1c"),
            'bingo_rules_left_margin': bingo_rules_left_margin_spin.get(),
            'bingo_rules_line_spacing': bingo_rules_line_spacing_spin.get(),
            'bingo_rules_para_spacing': bingo_rules_para_spacing_spin.get(),
            'bingo_rules_bottom_margin': bingo_rules_bottom_margin_spin.get(),
            'icon_mappings': dict(icon_mappings),
            'icon_size_overrides': dict(icon_size_overrides),
            'game_rules_separator_width': game_rules_separator_width_spin.get(),
            'game_rules_separator_height': game_rules_separator_height_spin.get(),
            'game_rules_separator_rgb': game_rules_separator_rgb_val,
            'game_rules_separator_hex': game_rules_separator_color_var.get(),
            'game_rules_separator_alignment': game_rules_separator_alignment_var.get(),
            'game_rules_separator_margin': game_rules_separator_margin_spin.get(),
            'game_rules_bottom_lr_margin': game_rules_bottom_lr_margin_spin.get(),
            'game_rules_malfunction_lr_margin': game_rules_malfunction_lr_margin_spin.get(),
            'game_rules_line_height': game_rules_line_height_spin.get(),
            'game_rules_malfunction_line_height': game_rules_malfunction_line_height_spin.get(),
            'game_rules_dynamic_line_height': game_rules_dynamic_line_height_spin.get(),
            'game_rules_xtra_reels_enabled': game_rules_xtra_reels_enabled_var.get(),
            'game_rules_xtra_reels_asset': game_rules_xtra_reels_asset_var.get(),
            'game_rules_xtra_reels_width': game_rules_xtra_reels_width_spin.get(),
            'game_rules_xtra_reels_outer_margin': game_rules_xtra_reels_outer_margin_spin.get(),
            'game_rules_xtra_reels_text_gap': game_rules_xtra_reels_text_gap_spin.get(),
            'game_rules_xtra_reels_y_offset': game_rules_xtra_reels_y_offset_spin.get(),
            'alignment_source': alignment_source_var.get(),
            'alignment_defaults': _alignment_defaults_config(),
            'page_alignment_overrides': dict(page_alignment_overrides),
            'layer_style_assignments': dict(layer_style_assignments),
            'style_sidecar_path': style_sidecar_path_var.get(),
            'style_global_folder': style_global_folder_var.get(),
            'keywords': keyword_mgr.to_json_dict(),
        }

    def _save_current_session():
        save_session(_session_dict())

    def save_preset():
        path = filedialog.asksaveasfilename(defaultextension=".json", filetypes=[("JSON", "*.json")])
        if path:
            with open(path, 'w') as f:
                json.dump(_session_dict(), f, indent=2)
            messagebox.showinfo("Saved", f"Preset saved to:\n{path}")

    def _apply_loaded(p):
        excel_var.set(p.get('excel_path', '')); prev_excel_var.set(p.get('prev_excel_path', '')); prev_psd_var.set(p.get('prev_psd_path', ''))
        icon_var.set(p.get('icon_folder', '')); bg_var.set(p.get('bg_path', '')); output_dir_var.set(p.get('output_dir', '')); bg_mode_var.set(p.get('bg_mode', 'stretch'))
        output_name_var.set(p.get('output_name', '')); output_format_var.set(p.get('output_format', 'PSD')); update_save_mode_var.set(p.get('update_save_mode', 'new_copy')); rerender_psd_var.set(p.get('rerender_psd', p.get('prev_psd_path', ''))); rerender_mode_var.set(p.get('rerender_mode', 'replace'))
        preset_folder_var.set(p.get('preset_folder', preset_folder_var.get())); auto_fit_enabled_var.set(p.get('auto_fit_enabled', False)); auto_fit_mode_var.set(p.get('auto_fit_mode', 'Warn only'))
        safe_backup_enabled_var.set(p.get('safe_backup_enabled', True)); safe_backup_folder_var.set(p.get('safe_backup_folder', '')); safe_duplicate_group_var.set(p.get('safe_duplicate_group', False)); confirm_update_diff_var.set(p.get('confirm_update_diff', True)); performance_mode_var.set(p.get('performance_mode', False))
        batch_export_psd_var.set(p.get('batch_export_psd', '')); batch_export_folder_var.set(p.get('batch_export_folder', '')); batch_export_format_var.set(p.get('batch_export_format', 'PNG')); batch_export_quality_var.set(p.get('batch_export_quality', '90'))
        batch_export_suffix_var.set(p.get('batch_export_suffix', 'MyExport'))
        batch_export_transparent_var.set(p.get('batch_export_transparent', True)); batch_export_groups_var.set(p.get('batch_export_groups', True)); batch_export_layers_var.set(p.get('batch_export_layers', False)); batch_export_bottom_to_top_var.set(p.get('batch_export_bottom_to_top', False))
        try:
            _refresh_preset_list()
        except Exception:
            pass
        custom_canvas_presets.clear(); custom_canvas_presets.update(p.get('custom_canvas_presets', {}) or {}); _refresh_canvas_presets(); canvas_preset_var.set(p.get('canvas_preset', 'FHD 1920x1080'))
        c_w_spin.set(p.get('canvas_w', 1920)); c_h_spin.set(p.get('canvas_h', 1080)); max_col_spin.set(p.get('max_col', 10))
        render_selected_pages_var.set(p.get('render_selected_pages', False)); _refresh_sheet_list(show_message=False); _apply_selected_sheet_names(p.get('selected_sheet_names', []))
        page_render_column_overrides_text.delete("1.0", tk.END)
        page_render_column_overrides_text.insert("1.0", p.get('page_render_column_overrides', ''))
        h_font_cb.set(p.get('h_font', 'Arial')); h_font_style_var.set(p.get('h_font_style', 'Regular')); h_size_spin.set(p.get('h_size', 55)); h_icon_spin.set(p.get('h_icon_h', 55))
        heading_image_folder_var.set(p.get('heading_image_folder', '')); heading_image_height_spin.set(p.get('heading_image_height', 0))
        heading_uppercase_var.set(p.get('heading_uppercase_enabled', False))
        heading_game_name_text_var.set(p.get('heading_game_name_text', ''))
        heading_keep_one_line_var.set(p.get('heading_keep_one_line', False))
        heading_one_line_margin_spin.set(p.get('heading_one_line_margin', 80))
        heading_size_overrides_text.delete("1.0", tk.END)
        heading_size_overrides_text.insert("1.0", p.get('heading_size_overrides', ''))
        page_multi_heading_text.delete("1.0", tk.END)
        page_multi_heading_text.insert("1.0", p.get('page_multi_heading_overrides', ''))
        b_font_cb.set(p.get('b_font', 'Arial')); b_font_style_var.set(p.get('b_font_style', 'Regular')); b_size_spin.set(p.get('b_size', 45)); b_icon_spin.set(p.get('b_icon_h', 45))
        body_icon_original_size_var.set(p.get('body_icons_use_original_size', False))
        h_rgb_val[:] = p.get('h_rgb', [30, 30, 30]); h_color_var.set('#%02x%02x%02x' % tuple(h_rgb_val)); _set_btn_color(h_color_btn, h_color_var.get())
        b_rgb_val[:] = p.get('b_rgb', [30, 30, 30]); b_color_var.set('#%02x%02x%02x' % tuple(b_rgb_val)); _set_btn_color(b_color_btn, b_color_var.get())
        subheading_font_cb.set(p.get('subheading_font', p.get('h_font', 'Arial')))
        subheading_font_style_var.set(p.get('subheading_font_style', 'SemiBold'))
        subheading_size_spin.set(p.get('subheading_size', 36))
        subheading_rgb_val[:] = p.get('subheading_rgb', [255, 255, 255])
        subheading_text_color_var.set(p.get('subheading_hex', '#%02x%02x%02x' % tuple(subheading_rgb_val)))
        _set_btn_color(subheading_color_btn, subheading_text_color_var.get())
        page_heading_cells_text.delete("1.0", tk.END)
        page_heading_cells_text.insert("1.0", p.get('page_heading_cell_overrides', ''))
        page_subheading_cells_text.delete("1.0", tk.END)
        page_subheading_cells_text.insert("1.0", p.get('page_subheading_cell_overrides', ''))
        margin_spin.set(p.get('margin', 80)); line_spin.set(p.get('line_spacing', 25)); para_spin.set(p.get('para_spacing', 40))
        gap_spin.set(p.get('gap', 0)); yoff_spin.set(p.get('icon_y_offset', 0)); enable_tables_var.set(p.get('enable_tables', True));         mapped_table_json_var.set(p.get('mapped_table_json', ''))
        json_sheet_overrides.clear()
        json_sheet_overrides.update(dict(p.get('json_sheet_overrides') or {}))
        manual_table_ranges_text.delete("1.0", tk.END)
        manual_table_ranges_text.insert("1.0", p.get('manual_table_ranges', ''))
        table_excel_fill_ranges_text.delete("1.0", tk.END)
        table_excel_fill_ranges_text.insert("1.0", p.get('table_excel_fill_ranges', ''))
        table_excel_fill_hex_overrides_text.delete("1.0", tk.END)
        table_excel_fill_hex_overrides_text.insert("1.0", p.get('table_excel_fill_hex_overrides', ''))
        table_excel_font_color_ranges_text.delete("1.0", tk.END)
        table_excel_font_color_ranges_text.insert("1.0", p.get('table_excel_font_color_ranges', ''))
        table_excel_font_hex_overrides_text.delete("1.0", tk.END)
        table_excel_font_hex_overrides_text.insert("1.0", p.get('table_excel_font_hex_overrides', ''))
        text_rectangle_cells_text.delete("1.0", tk.END)
        text_rectangle_cells_text.insert("1.0", p.get('text_rectangle_cells', ''))
        text_rect_fill_rgb_val[:] = p.get('text_rectangle_fill_rgb', [20, 20, 30])
        text_rect_fill_var.set(p.get('text_rectangle_fill_hex', '#%02x%02x%02x' % tuple(text_rect_fill_rgb_val)))
        _set_btn_color(text_rect_fill_btn, text_rect_fill_var.get())
        text_rect_stroke_rgb_val[:] = p.get('text_rectangle_stroke_rgb', [255, 255, 255])
        text_rect_stroke_var.set(p.get('text_rectangle_stroke_hex', '#%02x%02x%02x' % tuple(text_rect_stroke_rgb_val)))
        _set_btn_color(text_rect_stroke_btn, text_rect_stroke_var.get())
        text_rect_stroke_width_spin.set(p.get('text_rectangle_stroke_width', 2))
        text_rect_opacity_spin.set(p.get('text_rectangle_opacity', 100))
        text_rect_font_cb.set(p.get('text_rectangle_font', ''))
        text_rect_font_style_var.set(p.get('text_rectangle_font_style', 'Regular'))
        text_rect_font_size_spin.set(p.get('text_rectangle_font_size', 0))
        text_rect_text_rgb_val[:] = p.get('text_rectangle_text_rgb', [255, 255, 255])
        text_rect_text_color_var.set(p.get('text_rectangle_text_hex', '#%02x%02x%02x' % tuple(text_rect_text_rgb_val)))
        _set_btn_color(text_rect_text_color_btn, text_rect_text_color_var.get())
        text_rect_alignment_var.set(p.get('text_rectangle_alignment', 'center'))
        text_rect_pad_x_spin.set(p.get('text_rectangle_pad_x', 10))
        text_rect_pad_y_spin.set(p.get('text_rectangle_pad_y', 5))
        table_opacity_spin.set(p.get('table_opacity', 80)); cell_style_cb.set(p.get('table_cell_style', 'Fill + Stroke'))
        table_stroke_rgb_val[:] = p.get('table_stroke_rgb', [255, 255, 255]); stroke_color_var.set(p.get('table_stroke_color_hex', '#FFFFFF')); _set_btn_color(stroke_color_btn, stroke_color_var.get())
        stroke_width_spin.set(p.get('table_stroke_width', 2))
        table_header_rgb_val[:] = p.get('table_header_rgb', [20, 20, 30]); header_fill_var.set(p.get('table_header_hex', '#14141E')); _set_btn_color(header_fill_btn, header_fill_var.get())
        table_row1_rgb_val[:] = p.get('table_row1_rgb', [35, 35, 50]); row1_fill_var.set(p.get('table_row1_hex', '#232332')); _set_btn_color(row1_fill_btn, row1_fill_var.get())
        table_row2_rgb_val[:] = p.get('table_row2_rgb', [28, 28, 42]); row2_fill_var.set(p.get('table_row2_hex', '#1C1C2A')); _set_btn_color(row2_fill_btn, row2_fill_var.get())
        header_style_cb.set(p.get('table_header_style_mode', 'Follow Global')); row1_style_cb.set(p.get('table_row1_style_mode', 'Follow Global')); row2_style_cb.set(p.get('table_row2_style_mode', 'Follow Global'))
        row_gap_spin.set(p.get('row_gap', 0)); table_inherit_font_var.set(p.get('table_inherit_font', True)); table_merge_layers_var.set(p.get('table_merge_layers', False))
        table_header_font_cb.set(p.get('table_header_font', p.get('b_font', 'Arial'))); table_header_font_style_var.set(p.get('table_header_font_style', 'Regular')); table_header_size_spin.set(p.get('table_header_font_size', 0))
        table_body_font_cb.set(p.get('table_body_font', p.get('b_font', 'Arial'))); table_body_font_style_var.set(p.get('table_body_font_style', 'Regular')); table_body_size_spin.set(p.get('table_body_font_size', 0))
        table_icon_height_spin.set(p.get('table_icon_height', 0)); table_target_height_spin.set(p.get('table_target_height', 0)); table_target_width_spin.set(p.get('table_target_width', 0))
        table_header_text_rgb_val[:] = p.get('table_header_text_rgb', [255, 255, 255]); table_header_text_color_var.set(p.get('table_header_text_hex', '#FFFFFF')); _set_btn_color(table_header_text_color_btn, table_header_text_color_var.get())
        table_body_text_rgb_val[:] = p.get('table_body_text_rgb', [255, 255, 255]); table_body_text_color_var.set(p.get('table_body_text_hex', '#FFFFFF')); _set_btn_color(table_body_text_color_btn, table_body_text_color_var.get())
        table_after_margin_spin.set(p.get('table_after_margin', 30)); table_min_text_room_spin.set(p.get('table_min_text_room', 70))
        heading_margin_spin.set(p.get('heading_top_margin', 150)); bottom_margin_spin.set(p.get('bottom_margin', 50)); continued_gap_spin.set(p.get('continued_gap', 15)); heading_to_body_gap_spin.set(p.get('heading_to_body_gap', 40))
        paste_heading_style_var.set(p.get('paste_heading_style', False)); copied_heading_style_name_var.set(p.get('copied_heading_style_name', 'Copied Photoshop layer style'))
        h_stroke_enable_var.set(p.get('h_stroke_enabled', False)); h_stroke_rgb_val[:] = p.get('h_stroke_rgb', [255, 255, 255]); h_stroke_color_var.set(p.get('h_stroke_hex', '#FFFFFF')); _set_btn_color(h_stroke_color_btn, h_stroke_color_var.get())
        h_stroke_size_spin.set(p.get('h_stroke_size', 3)); h_stroke_opacity_spin.set(p.get('h_stroke_opacity', 100))
        h_shadow_enable_var.set(p.get('h_shadow_enabled', False)); h_shadow_rgb_val[:] = p.get('h_shadow_rgb', [0, 0, 0]); h_shadow_color_var.set(p.get('h_shadow_hex', '#000000')); _set_btn_color(h_shadow_color_btn, h_shadow_color_var.get()); h_shadow_blend_var.set(p.get('h_shadow_blend_mode', 'Multiply'))
        h_shadow_opacity_spin.set(p.get('h_shadow_opacity', 60)); h_shadow_distance_spin.set(p.get('h_shadow_distance', 8)); h_shadow_size_spin.set(p.get('h_shadow_size', 12)); h_shadow_angle_spin.set(p.get('h_shadow_angle', 120)); h_shadow_spread_spin.set(p.get('h_shadow_spread', 0))
        heading_captured_style['hex'] = str(p.get('heading_captured_effects_hex', '') or '')
        heading_captured_style['params'] = dict(p.get('heading_captured_params', {}) or {})
        paste_body_style_var.set(p.get('paste_body_style', False)); copied_body_style_name_var.set(p.get('copied_body_style_name', 'Copied Photoshop layer style'))
        b_stroke_enable_var.set(p.get('b_stroke_enabled', False)); b_stroke_rgb_val[:] = p.get('b_stroke_rgb', [255, 255, 255]); b_stroke_color_var.set(p.get('b_stroke_hex', '#FFFFFF')); _set_btn_color(b_stroke_color_btn, b_stroke_color_var.get())
        b_stroke_size_spin.set(p.get('b_stroke_size', 3)); b_stroke_opacity_spin.set(p.get('b_stroke_opacity', 100))
        b_shadow_enable_var.set(p.get('b_shadow_enabled', False)); b_shadow_rgb_val[:] = p.get('b_shadow_rgb', [0, 0, 0]); b_shadow_color_var.set(p.get('b_shadow_hex', '#000000')); _set_btn_color(b_shadow_color_btn, b_shadow_color_var.get()); b_shadow_blend_var.set(p.get('b_shadow_blend_mode', 'Multiply'))
        b_shadow_opacity_spin.set(p.get('b_shadow_opacity', 60)); b_shadow_distance_spin.set(p.get('b_shadow_distance', 8)); b_shadow_size_spin.set(p.get('b_shadow_size', 12)); b_shadow_angle_spin.set(p.get('b_shadow_angle', 120)); b_shadow_spread_spin.set(p.get('b_shadow_spread', 0))
        body_captured_style['hex'] = str(p.get('body_captured_effects_hex', '') or '')
        body_captured_style['params'] = dict(p.get('body_captured_params', {}) or {})
        style_global_folder_var.set(p.get('style_global_folder', style_global_folder_var.get()))
        layer_style_library.clear()
        _load_global_style_files(show_warning=False)
        layer_style_library.update(p.get('layer_style_library', {}) or {})
        heading_saved_style_var.set(p.get('heading_saved_style', '')); body_saved_style_var.set(p.get('body_saved_style', ''))
        icon_layer_style_enabled_var.set(p.get('icon_layer_style_enabled', False)); icon_saved_style_var.set(p.get('icon_saved_style', ''))
        layer_style_assignments.clear(); layer_style_assignments.update(p.get('layer_style_assignments', {}) or {})
        style_sidecar_path_var.set(p.get('style_sidecar_path', style_sidecar_path_var.get()))
        _refresh_named_style_choices(); _refresh_heading_style_status(); _refresh_body_style_status()
        _sync_assigned_styles_to_controls()
        alignment_source_var.set(p.get('alignment_source', alignment_source_var.get()))
        align_defaults = p.get('alignment_defaults', {}) or {}
        heading_alignment_var.set(align_defaults.get('heading', p.get('heading_alignment', heading_alignment_var.get())))
        body_alignment_var.set(align_defaults.get('body', p.get('body_alignment', body_alignment_var.get())))
        table_alignment_var.set(align_defaults.get('table', p.get('table_alignment', table_alignment_var.get())))
        bottom_alignment_var.set(align_defaults.get('bottom', p.get('bottom_alignment', bottom_alignment_var.get())))
        paytable_notes_alignment_var.set(align_defaults.get('paytable_notes', p.get('paytable_notes_alignment', paytable_notes_alignment_var.get())))
        heading_left_margin_spin.set(align_defaults.get('heading_left_margin', p.get('heading_left_margin', 80)))
        body_left_margin_spin.set(align_defaults.get('body_left_margin', p.get('body_left_margin', 80)))
        page_alignment_overrides.clear(); page_alignment_overrides.update(p.get('page_alignment_overrides', {}) or {})
        try:
            _refresh_alignment_pages(show_message=False)
            _load_alignment_override()
        except Exception:
            pass
        dynamic_enable_var.set(p.get('dynamic_enabled', True)); dynamic_sheet_var.set(p.get('dynamic_sheet_name', 'Paytable')); dynamic_template_json_var.set(p.get('dynamic_template_json', default_template_json)); dynamic_template_folder_var.set(p.get('dynamic_template_folder', os.path.dirname(default_template_json))); dynamic_wild_asset_var.set(p.get('dynamic_wild_asset', 'gold_scat.png'))
        dynamic_wild_title_slot_enabled_var.set(p.get('dynamic_wild_title_slot_enabled', False)); dynamic_wild_title_slot_text_var.set(p.get('dynamic_wild_title_slot_text', 'WILD'))
        dynamic_scatter_title_slot_enabled_var.set(p.get('dynamic_scatter_title_slot_enabled', False)); dynamic_scatter_title_slot_text_var.set(p.get('dynamic_scatter_title_slot_text', 'SCATTER'))
        _reset_custom_layout_pages(p.get('custom_layout_pages') or None)
        dynamic_top_icon_height_spin.set(p.get('dynamic_top_icon_height', 260)); dynamic_lower_icon_height_spin.set(p.get('dynamic_lower_icon_height', 210)); dynamic_wild_icon_height_spin.set(p.get('dynamic_wild_icon_height', 190)); dynamic_inline_icon_height_spin.set(p.get('dynamic_inline_icon_height', 54)); dynamic_inline_icon_gap_spin.set(p.get('dynamic_inline_icon_gap', 8)); dynamic_inline_line_height_spin.set(p.get('dynamic_inline_line_height', 0))
        payout_placement_mode_var.set(p.get('payout_placement_mode', 'Bottom of icon'))
        dynamic_count_font_cb.set(p.get('dynamic_count_font', '')); dynamic_count_font_style_var.set(p.get('dynamic_count_font_style', 'Regular'))
        dynamic_count_size_spin.set(p.get('dynamic_count_size', 38)); dynamic_count_rgb_val[:] = p.get('dynamic_count_rgb', [255,175,55]); dynamic_count_color_var.set(p.get('dynamic_count_hex', '#FFAF37')); _set_btn_color(dynamic_count_color_btn, dynamic_count_color_var.get())
        dynamic_value_font_cb.set(p.get('dynamic_value_font', '')); dynamic_value_font_style_var.set(p.get('dynamic_value_font_style', 'Regular'))
        dynamic_value_size_spin.set(p.get('dynamic_value_size', 42)); dynamic_value_rgb_val[:] = p.get('dynamic_value_rgb', [255,255,255]); dynamic_value_color_var.set(p.get('dynamic_value_hex', '#FFFFFF')); _set_btn_color(dynamic_value_color_btn, dynamic_value_color_var.get())
        dynamic_fallback_size_spin.set(p.get('dynamic_fallback_size', 110)); dynamic_fallback_rgb_val[:] = p.get('dynamic_fallback_rgb', [255,255,255]); dynamic_fallback_color_var.set(p.get('dynamic_fallback_hex', '#FFFFFF')); _set_btn_color(dynamic_fallback_color_btn, dynamic_fallback_color_var.get())
        dynamic_top_bg_rgb_val[:] = p.get('dynamic_top_bg_rgb', [8,10,18]); dynamic_top_bg_color_var.set(p.get('dynamic_top_bg_hex', '#080A12')); _set_btn_color(dynamic_top_bg_color_btn, dynamic_top_bg_color_var.get()); dynamic_top_bg_opacity_spin.set(p.get('dynamic_top_bg_opacity', 65))
        dynamic_lower_bg_rgb_val[:] = p.get('dynamic_lower_bg_rgb', [16,10,28]); dynamic_lower_bg_color_var.set(p.get('dynamic_lower_bg_hex', '#100A1C')); _set_btn_color(dynamic_lower_bg_color_btn, dynamic_lower_bg_color_var.get()); dynamic_lower_bg_opacity_spin.set(p.get('dynamic_lower_bg_opacity', 65))
        dynamic_card_stroke_rgb_val[:] = p.get('dynamic_card_stroke_rgb', [35,35,50]); dynamic_card_stroke_color_var.set(p.get('dynamic_card_stroke_hex', '#232332')); _set_btn_color(dynamic_card_stroke_color_btn, dynamic_card_stroke_color_var.get()); dynamic_card_stroke_width_spin.set(p.get('dynamic_card_stroke_width', 0))
        dynamic_text_bg_rgb_val[:] = p.get('dynamic_text_bg_rgb', [10,10,18]); dynamic_text_bg_color_var.set(p.get('dynamic_text_bg_hex', '#0A0A12')); _set_btn_color(dynamic_text_bg_color_btn, dynamic_text_bg_color_var.get()); dynamic_text_bg_opacity_spin.set(p.get('dynamic_text_bg_opacity', 70))
        dynamic_wild_title_size_spin.set(p.get('dynamic_wild_title_size', 72)); dynamic_wild_title_rgb_val[:] = p.get('dynamic_wild_title_rgb', [255,205,50]); dynamic_wild_title_color_var.set(p.get('dynamic_wild_title_hex', '#FFCD32')); _set_btn_color(dynamic_wild_title_color_btn, dynamic_wild_title_color_var.get())
        dynamic_wild_text_size_spin.set(p.get('dynamic_wild_text_size', 30)); dynamic_wild_text_rgb_val[:] = p.get('dynamic_wild_text_rgb', [255,255,255]); dynamic_wild_text_color_var.set(p.get('dynamic_wild_text_hex', '#FFFFFF')); _set_btn_color(dynamic_wild_text_color_btn, dynamic_wild_text_color_var.get())
        dynamic_notes_size_spin.set(p.get('dynamic_notes_size', 30)); dynamic_notes_rgb_val[:] = p.get('dynamic_notes_rgb', [255,255,255]); dynamic_notes_color_var.set(p.get('dynamic_notes_hex', '#FFFFFF')); _set_btn_color(dynamic_notes_color_btn, dynamic_notes_color_var.get())
        game_rules_bottom_font_cb.set(p.get('game_rules_bottom_font', '')); game_rules_bottom_font_style_var.set(p.get('game_rules_bottom_font_style', 'Regular')); game_rules_bottom_size_spin.set(p.get('game_rules_bottom_size', 30)); game_rules_bottom_gap_spin.set(p.get('game_rules_bottom_gap', 26))
        game_rules_legal_split_text.delete("1.0", tk.END)
        game_rules_legal_split_text.insert("1.0", p.get('game_rules_legal_split_overrides', ''))
        bingo_rules_one_page_var.set(p.get('bingo_rules_one_page', True))
        bingo_rules_body_size_spin.set(p.get('bingo_rules_body_size', 0))
        bingo_rules_body_ranges_var.set(p.get('bingo_rules_body_ranges', ''))
        bingo_rules_alignment_text.delete("1.0", tk.END)
        bingo_rules_alignment_text.insert("1.0", p.get('bingo_rules_alignment_overrides', ''))
        bingo_rules_left_margin_spin.set(p.get('bingo_rules_left_margin', 0))
        bingo_rules_line_spacing_spin.set(p.get('bingo_rules_line_spacing', 0))
        bingo_rules_para_spacing_spin.set(p.get('bingo_rules_para_spacing', 0))
        bingo_rules_bottom_margin_spin.set(p.get('bingo_rules_bottom_margin', 0))
        icon_mappings.clear(); icon_mappings.update(p.get('icon_mappings', {}) or {})
        icon_size_overrides.clear(); icon_size_overrides.update(p.get('icon_size_overrides', {}) or {})
        game_rules_separator_width_spin.set(p.get('game_rules_separator_width', 1000))
        game_rules_separator_height_spin.set(p.get('game_rules_separator_height', 2))
        game_rules_separator_rgb_val[:] = p.get('game_rules_separator_rgb', [255, 255, 255])
        game_rules_separator_color_var.set(p.get('game_rules_separator_hex', '#%02x%02x%02x' % tuple(game_rules_separator_rgb_val)))
        _set_btn_color(game_rules_separator_color_btn, game_rules_separator_color_var.get())
        game_rules_separator_alignment_var.set(p.get('game_rules_separator_alignment', 'center'))
        game_rules_separator_margin_spin.set(p.get('game_rules_separator_margin', 80))
        game_rules_bottom_lr_margin_spin.set(p.get('game_rules_bottom_lr_margin', 200))
        game_rules_malfunction_lr_margin_spin.set(p.get('game_rules_malfunction_lr_margin', p.get('game_rules_bottom_lr_margin', 200)))
        game_rules_line_height_spin.set(p.get('game_rules_line_height', 0))
        game_rules_malfunction_line_height_spin.set(p.get('game_rules_malfunction_line_height', 0))
        game_rules_dynamic_line_height_spin.set(p.get('game_rules_dynamic_line_height', 0))
        _refresh_mapping_choices(); _scan_mapping_tokens(show_message=False); _refresh_mapping_tree()
        game_rules_xtra_reels_enabled_var.set(p.get('game_rules_xtra_reels_enabled', False)); game_rules_xtra_reels_asset_var.set(p.get('game_rules_xtra_reels_asset', ''))
        game_rules_xtra_reels_width_spin.set(p.get('game_rules_xtra_reels_width', 100)); game_rules_xtra_reels_outer_margin_spin.set(p.get('game_rules_xtra_reels_outer_margin', 100)); game_rules_xtra_reels_text_gap_spin.set(p.get('game_rules_xtra_reels_text_gap', 50)); game_rules_xtra_reels_y_offset_spin.set(p.get('game_rules_xtra_reels_y_offset', 0))
        keyword_mgr.set_dict(p.get('keywords', {})); refresh_kw_tree()

    def load_preset():
        path = filedialog.askopenfilename(filetypes=[("JSON", "*.json")])
        if path and os.path.exists(path):
            with open(path, 'r') as f:
                _apply_loaded(json.load(f))
            _save_current_session()
            messagebox.showinfo("Loaded", "Preset loaded successfully!")

    preset_frame = ttk.LabelFrame(tab_build, text="Presets")
    preset_frame.pack(fill="x", padx=10, pady=(0, 12))
    ttk.Button(preset_frame, text="Save Full Preset", command=save_preset).grid(row=0, column=0, padx=10, pady=12, sticky="w")
    ttk.Button(preset_frame, text="Load Full Preset", command=load_preset).grid(row=0, column=1, padx=0, pady=12, sticky="w")


    # Update PSD
    tab_update.columnconfigure(1, weight=1)

    ttk.Label(tab_update, text="New Excel", style="FieldLabel.TLabel").grid(row=0, column=0, sticky="w", pady=(12, 3), padx=10)
    ttk.Entry(tab_update, textvariable=excel_var, state="readonly", width=60).grid(row=0, column=1, sticky="ew", padx=5, pady=(12, 3))
    ttk.Button(tab_update, text="Browse", command=_choose_excel_file).grid(row=0, column=2, padx=(0, 4), pady=(12, 3))
    ttk.Button(tab_update, text="Remove", command=lambda: _clear_path(excel_var)).grid(row=0, column=3, padx=(0, 10), pady=(12, 3))

    ttk.Label(tab_update, text="Old Excel", style="FieldLabel.TLabel").grid(row=1, column=0, sticky="w", pady=3, padx=10)
    ttk.Entry(tab_update, textvariable=prev_excel_var, state="readonly", width=60).grid(row=1, column=1, sticky="ew", padx=5, pady=3)
    ttk.Button(tab_update, text="Browse", command=_choose_prev_excel_file).grid(row=1, column=2, padx=(0, 4), pady=3)
    ttk.Button(tab_update, text="Remove", command=lambda: _clear_path(prev_excel_var)).grid(row=1, column=3, padx=(0, 10), pady=3)

    ttk.Label(tab_update, text="Last Updated PSD", style="FieldLabel.TLabel").grid(row=2, column=0, sticky="w", pady=3, padx=10)
    ttk.Entry(tab_update, textvariable=prev_psd_var, state="readonly", width=60).grid(row=2, column=1, sticky="ew", padx=5, pady=3)
    ttk.Button(tab_update, text="Browse", command=_choose_existing_psd).grid(row=2, column=2, padx=(0, 4), pady=3)
    ttk.Button(tab_update, text="Remove", command=lambda: _clear_path(prev_psd_var)).grid(row=2, column=3, padx=(0, 10), pady=3)

    ttk.Separator(tab_update, orient="horizontal").grid(row=3, column=0, columnspan=4, sticky="ew", padx=10, pady=12)

    ttk.Label(tab_update, text="Icons Folder", style="FieldLabel.TLabel").grid(row=4, column=0, sticky="w", pady=3, padx=10)
    ttk.Entry(tab_update, textvariable=icon_var, state="readonly", width=60).grid(row=4, column=1, sticky="ew", padx=5, pady=3)
    ttk.Button(tab_update, text="Browse", command=_choose_icon_folder).grid(row=4, column=2, padx=(0, 4), pady=3)
    ttk.Button(tab_update, text="Remove", command=lambda: _clear_path(icon_var)).grid(row=4, column=3, padx=(0, 10), pady=3)

    ttk.Label(tab_update, text="Background", style="FieldLabel.TLabel").grid(row=5, column=0, sticky="w", pady=3, padx=10)
    ttk.Entry(tab_update, textvariable=bg_var, state="readonly", width=60).grid(row=5, column=1, sticky="ew", padx=5, pady=3)
    ttk.Button(tab_update, text="Browse", command=_choose_bg_file).grid(row=5, column=2, padx=(0, 4), pady=3)
    ttk.Button(tab_update, text="Remove", command=lambda: _clear_path(bg_var)).grid(row=5, column=3, padx=(0, 10), pady=3)

    ttk.Label(tab_update, text="Save Folder", style="FieldLabel.TLabel").grid(row=6, column=0, sticky="w", pady=3, padx=10)
    ttk.Entry(tab_update, textvariable=output_dir_var, state="readonly", width=60).grid(row=6, column=1, sticky="ew", padx=5, pady=3)
    ttk.Button(tab_update, text="Browse", command=_choose_output_dir).grid(row=6, column=2, padx=(0, 4), pady=3)
    ttk.Button(tab_update, text="Remove", command=lambda: _clear_path(output_dir_var)).grid(row=6, column=3, padx=(0, 10), pady=3)

    save_mode_frame = ttk.Frame(tab_update)
    save_mode_frame.grid(row=7, column=1, columnspan=3, sticky="w", padx=5, pady=(12, 3))
    ttk.Radiobutton(save_mode_frame, text="Save as new", variable=update_save_mode_var, value="new_copy").grid(row=0, column=0, padx=(0, 12))
    ttk.Radiobutton(save_mode_frame, text="Overwrite selected PSD", variable=update_save_mode_var, value="overwrite").grid(row=0, column=1, padx=(0, 18))
    ttk.Label(save_mode_frame, text="Name:").grid(row=0, column=2, padx=(0, 5))
    ttk.Entry(save_mode_frame, textvariable=output_name_var, width=28).grid(row=0, column=3, padx=(0, 12))
    ttk.Radiobutton(save_mode_frame, text="PSD", variable=output_format_var, value="PSD").grid(row=0, column=4, padx=(0, 8))
    ttk.Radiobutton(save_mode_frame, text="PSB", variable=output_format_var, value="PSB").grid(row=0, column=5)

    ttk.Label(
        tab_update,
        text="Update mode needs New Excel, Old Excel, the last PSD, icons, and background. If a PSD settings JSON exists, selecting the PSD loads the matching fonts/colors/sizes automatically.",
        foreground="gray",
        wraplength=900,
    ).grid(row=8, column=0, columnspan=4, sticky="w", padx=10, pady=(8, 12))

    ttk.Button(tab_update, text="Update Changed Pages", command=lambda: _run_build(update_mode=True)).grid(row=9, column=1, sticky="w", padx=5, pady=8)

    # Re-render selected pages into the current/last PSD without using the Page Selection tab.
    tab_rerender.columnconfigure(1, weight=1)
    tab_rerender.rowconfigure(6, weight=1)
    ttk.Label(tab_rerender, text="Re-render Specific Page(s)", style="SubTitle.TLabel").grid(row=0, column=0, columnspan=5, sticky="w", padx=10, pady=(12, 8))
    ttk.Label(tab_rerender, text="This has its own page list. Select the page(s) here and the tool re-renders only those groups into the current/last PSD.", foreground="gray", wraplength=980).grid(row=1, column=0, columnspan=5, sticky="w", padx=10, pady=(0, 10))
    ttk.Label(tab_rerender, text="Current / target PSD", style="FieldLabel.TLabel").grid(row=2, column=0, sticky="w", padx=10, pady=4)
    ttk.Entry(tab_rerender, textvariable=rerender_psd_var, state="readonly", width=70).grid(row=2, column=1, columnspan=3, sticky="ew", padx=5, pady=4)
    ttk.Label(tab_rerender, text="Auto-filled after Build/Update. You can also use the Update PSD target if needed.", foreground="gray").grid(row=3, column=1, columnspan=3, sticky="w", padx=5, pady=(0, 6))
    ttk.Label(tab_rerender, text="Pages to re-render", style="FieldLabel.TLabel").grid(row=4, column=0, sticky="w", padx=10, pady=(8, 4))
    ttk.Button(tab_rerender, text="Refresh Pages", command=lambda: _refresh_rerender_sheet_list()).grid(row=4, column=1, sticky="w", padx=5, pady=(8, 4))
    ttk.Button(tab_rerender, text="Select All", command=_select_all_rerender_sheets).grid(row=4, column=2, sticky="w", padx=5, pady=(8, 4))
    ttk.Button(tab_rerender, text="Clear", command=_clear_rerender_sheets).grid(row=4, column=3, sticky="w", padx=5, pady=(8, 4))
    rerender_listbox = tk.Listbox(tab_rerender, selectmode=tk.MULTIPLE, exportselection=False, height=14)
    rerender_listbox.grid(row=5, column=0, columnspan=4, sticky="nsew", padx=10, pady=(0, 10))
    rerender_scroll = ttk.Scrollbar(tab_rerender, orient="vertical", command=rerender_listbox.yview)
    rerender_scroll.grid(row=5, column=4, sticky="ns", pady=(0, 10), padx=(0, 10))
    rerender_listbox.configure(yscrollcommand=rerender_scroll.set)
    _style_listbox(rerender_listbox)
    ttk.Label(tab_rerender, text="Mode", style="FieldLabel.TLabel").grid(row=6, column=0, sticky="nw", padx=10, pady=(12, 4))
    mode_frame = ttk.Frame(tab_rerender)
    mode_frame.grid(row=6, column=1, columnspan=3, sticky="nw", padx=5, pady=(10, 4))
    ttk.Radiobutton(mode_frame, text="Delete old page group(s) and render again", variable=rerender_mode_var, value="replace").grid(row=0, column=0, sticky="w", pady=3)
    ttk.Radiobutton(mode_frame, text="Render as copy above old group(s)", variable=rerender_mode_var, value="copy").grid(row=1, column=0, sticky="w", pady=3)
    ttk.Button(tab_rerender, text="Re-render Selected Page(s)", command=lambda: _run_rerender()).grid(row=7, column=1, sticky="w", padx=5, pady=18, ipadx=16, ipady=6)
    ttk.Label(tab_rerender, text="Replace mode saves back to the same PSD. Copy mode keeps the old group and adds a timestamped copy group.", foreground="gray", wraplength=900).grid(row=8, column=0, columnspan=5, sticky="w", padx=10)

    action_frame = ttk.Frame(root, style="Card.TFrame", padding=(18, 14))
    action_inner = ttk.Frame(action_frame, style="Card.TFrame")
    action_inner.pack(fill="x")
    status_var = tk.StringVar(value="Ready")
    action_status = ttk.Label(action_frame, textvariable=status_var, style="Status.TLabel")
    action_status.pack(fill="x", pady=(8, 0))

    def _heading_style_config():
        return _style_config_with_fallback("Heading text", _snapshot_style_controls("heading"))

    def _body_style_config():
        return _style_config_with_fallback("Body text", _snapshot_style_controls("body"))

    def _icon_style_config():
        if not icon_layer_style_enabled_var.get():
            return None
        selected = icon_saved_style_var.get().strip()
        style_config = layer_style_library.get(selected)
        return json.loads(json.dumps(style_config)) if style_config else None

    def _dynamic_settings_config():
        template_json_map = {}
        for item in custom_layout_pages:
            page_name = item['name_var'].get().strip()
            page_json = item['json_var'].get().strip()
            if page_name and page_json:
                template_json_map[page_name] = page_json
        active_paytable_sheet = dynamic_sheet_var.get().strip() or 'Paytable'
        active_paytable_json = dynamic_template_json_var.get().strip()
        if active_paytable_json:
            template_json_map[active_paytable_sheet] = active_paytable_json
        return {
            'enabled': dynamic_enable_var.get(),
            'sheet_name': dynamic_sheet_var.get().strip() or 'Paytable',
            'page_type': 'paytable',
            'template_json': dynamic_template_json_var.get(),
            'template_folder': dynamic_template_folder_var.get(),
            'template_json_map': template_json_map,
            'title_size': int(h_size_spin.get()),
            'title_rgb': tuple(h_rgb_val),
            'heading_uppercase_enabled': heading_uppercase_var.get(),
            'heading_game_name_text': heading_game_name_text_var.get().strip(),
            'heading_keep_one_line': heading_keep_one_line_var.get(),
            'heading_one_line_margin': int(heading_one_line_margin_spin.get()),
            'heading_size_overrides': heading_size_overrides_text.get("1.0", "end-1c").strip(),
            'page_multi_heading_overrides': page_multi_heading_text.get("1.0", "end-1c").strip(),
            'subheading_font_request': _font_request(subheading_font_cb.get(), subheading_font_style_var.get()) if subheading_font_cb.get().strip() else '',
            'subheading_size': int(subheading_size_spin.get()),
            'subheading_rgb': tuple(subheading_rgb_val),
            'subheading_style': _style_config_for_assignment("Subheading text"),
            'page_heading_cell_overrides': page_heading_cells_text.get("1.0", "end-1c").strip(),
            'page_subheading_cell_overrides': page_subheading_cells_text.get("1.0", "end-1c").strip(),
            'count_font_request': _font_request(dynamic_count_font_cb.get(), dynamic_count_font_style_var.get()) if dynamic_count_font_cb.get().strip() else '',
            'count_size': int(dynamic_count_size_spin.get()),
            'count_rgb': tuple(dynamic_count_rgb_val),
            'value_font_request': _font_request(dynamic_value_font_cb.get(), dynamic_value_font_style_var.get()) if dynamic_value_font_cb.get().strip() else '',
            'value_size': int(dynamic_value_size_spin.get()),
            'value_rgb': tuple(dynamic_value_rgb_val),
            'fallback_symbol_size': int(dynamic_fallback_size_spin.get()),
            'fallback_symbol_rgb': tuple(dynamic_fallback_rgb_val),
            'top_card_bg_rgb': tuple(dynamic_top_bg_rgb_val),
            'top_card_bg_opacity': int(dynamic_top_bg_opacity_spin.get()),
            'lower_card_bg_rgb': tuple(dynamic_lower_bg_rgb_val),
            'lower_card_bg_opacity': int(dynamic_lower_bg_opacity_spin.get()),
            'card_stroke_rgb': tuple(dynamic_card_stroke_rgb_val),
            'card_stroke_width': int(dynamic_card_stroke_width_spin.get()),
            'text_bg_rgb': tuple(dynamic_text_bg_rgb_val),
            'text_bg_opacity': int(dynamic_text_bg_opacity_spin.get()),
            'wild_title_size': int(dynamic_wild_title_size_spin.get()),
            'wild_title_rgb': tuple(dynamic_wild_title_rgb_val),
            'wild_title_slot_enabled': dynamic_wild_title_slot_enabled_var.get(),
            'wild_title_slot_text': dynamic_wild_title_slot_text_var.get().strip() or 'WILD',
            'scatter_title_slot_enabled': dynamic_scatter_title_slot_enabled_var.get(),
            'scatter_title_slot_text': dynamic_scatter_title_slot_text_var.get().strip() or 'SCATTER',
            'wild_text_size': int(dynamic_wild_text_size_spin.get()),
            'wild_text_rgb': tuple(dynamic_wild_text_rgb_val),
            'notes_text_size': int(dynamic_notes_size_spin.get()),
            'notes_text_rgb': tuple(dynamic_notes_rgb_val),
            'wild_asset': dynamic_wild_asset_var.get().strip() or 'gold_scat.png',
            'top_symbol_icon_height': int(dynamic_top_icon_height_spin.get()),
            'lower_symbol_icon_height': int(dynamic_lower_icon_height_spin.get()),
            'wild_icon_height': int(dynamic_wild_icon_height_spin.get()),
            'inline_icon_height': int(dynamic_inline_icon_height_spin.get()),
            'inline_icon_gap': int(dynamic_inline_icon_gap_spin.get()),
            'inline_line_height': int(dynamic_inline_line_height_spin.get()),
            'paytable_notes_alignment': paytable_notes_alignment_var.get(),
            'payout_placement_mode': payout_placement_mode_var.get(),
            'page_render_column_overrides': page_render_column_overrides_text.get("1.0", "end-1c").strip(),
            'style_assignments': dict(layer_style_assignments),
            'paytable_count_style': _style_config_for_assignment("Paytable payout count"),
            'paytable_value_style': _style_config_for_assignment("Paytable payout value"),
            'paytable_notes_style': _style_config_for_assignment("Body text"),
            'game_rules_text_style': _style_config_for_assignment("Game Rules text"),
            'game_rules_legal_style': _style_config_for_assignment("Malfunction/legal text"),
            'game_rules_bottom_font_request': _font_request(game_rules_bottom_font_cb.get(), game_rules_bottom_font_style_var.get()) if game_rules_bottom_font_cb.get().strip() else '',
            'game_rules_bottom_font_size': int(game_rules_bottom_size_spin.get()),
            'game_rules_bottom_gap': int(game_rules_bottom_gap_spin.get()),
            'game_rules_legal_split_overrides': game_rules_legal_split_text.get("1.0", "end-1c").strip(),
            'game_rules_separator_width': int(game_rules_separator_width_spin.get()),
            'game_rules_separator_height': int(game_rules_separator_height_spin.get()),
            'game_rules_separator_rgb': tuple(game_rules_separator_rgb_val),
            'game_rules_separator_alignment': game_rules_separator_alignment_var.get(),
            'game_rules_separator_margin': int(game_rules_separator_margin_spin.get()),
            'game_rules_bottom_lr_margin': int(game_rules_bottom_lr_margin_spin.get()),
            'game_rules_malfunction_lr_margin': int(game_rules_malfunction_lr_margin_spin.get()),
            'game_rules_line_height': int(game_rules_line_height_spin.get()),
            'game_rules_malfunction_line_height': int(game_rules_malfunction_line_height_spin.get()),
            'game_rules_dynamic_line_height': int(game_rules_dynamic_line_height_spin.get()),
            'game_rules_xtra_reels_enabled': game_rules_xtra_reels_enabled_var.get(),
            'game_rules_xtra_reels_asset': game_rules_xtra_reels_asset_var.get().strip(),
            'game_rules_xtra_reels_width': int(game_rules_xtra_reels_width_spin.get()),
            'game_rules_xtra_reels_outer_margin': int(game_rules_xtra_reels_outer_margin_spin.get()),
            'game_rules_xtra_reels_text_gap': int(game_rules_xtra_reels_text_gap_spin.get()),
            'game_rules_xtra_reels_y_offset': int(game_rules_xtra_reels_y_offset_spin.get()),
            'bingo_rules_one_page': bingo_rules_one_page_var.get(),
            'bingo_rules_body_size': int(bingo_rules_body_size_spin.get()),
            'bingo_rules_body_ranges': bingo_rules_body_ranges_var.get().strip(),
            'bingo_rules_alignment_overrides': bingo_rules_alignment_text.get("1.0", "end-1c").strip(),
            'bingo_rules_left_margin': int(bingo_rules_left_margin_spin.get()),
            'bingo_rules_line_spacing': int(bingo_rules_line_spacing_spin.get()),
            'bingo_rules_para_spacing': int(bingo_rules_para_spacing_spin.get()),
            'bingo_rules_bottom_margin': int(bingo_rules_bottom_margin_spin.get()),
            'icon_mappings': dict(icon_mappings),
            'layer_style_library': dict(layer_style_library),
        }

    def _show_performance_mode_report():
        excel_path = excel_var.get().strip()
        if not excel_path:
            messagebox.showerror("Performance Report", "Please select a Current Excel file first.")
            return
        if not os.path.exists(excel_path):
            messagebox.showerror("Performance Report", f"Excel file not found:\n{excel_path}")
            return
        selected_sheet_names = _selected_sheet_names() if render_selected_pages_var.get() else []
        if render_selected_pages_var.get() and not selected_sheet_names:
            messagebox.showerror("Performance Report", "Select at least one Excel tab, or turn off selected-tab rendering.")
            return
        try:
            report = build_performance_mode_report(
                excel_path,
                max_col_limit=int(max_col_spin.get()),
                dynamic_settings=_dynamic_settings_config(),
                table_style={
                    "mapped_table_jsons": mapped_table_json_var.get().strip(),
                },
                selected_sheets=selected_sheet_names,
            )
        except Exception as exc:
            messagebox.showerror("Performance Report", f"Could not build the Performance Mode report:\n{exc}")
            return

        lines = list(report.get("lines") or [])
        if not performance_mode_var.get():
            lines.insert(0, "Performance Mode is currently OFF. This is a dry-run only.")
            lines.insert(1, "")

        dialog = tk.Toplevel(root)
        dialog.title("Performance Mode Report")
        dialog.geometry("980x620")
        dialog.minsize(760, 420)
        try:
            dialog.attributes("-topmost", False)
        except Exception:
            pass

        outer = ttk.Frame(dialog, padding=12)
        outer.pack(fill="both", expand=True)
        ttk.Label(outer, text="Performance Mode Report", style="SubTitle.TLabel").pack(anchor="w")
        ttk.Label(
            outer,
            text="Dry-run only. Build will still do final Photoshop safety checks before copying a page.",
            style="Muted.TLabel",
            wraplength=900,
        ).pack(anchor="w", fill="x", pady=(4, 10))

        text_frame = ttk.Frame(outer)
        text_frame.pack(fill="both", expand=True)
        text = tk.Text(
            text_frame,
            wrap="none",
            bg=palette["input_bg"],
            fg=palette["text"],
            insertbackground=palette["text"],
            relief="solid",
            bd=1,
            font=("Consolas", 10),
        )
        y_scroll = ttk.Scrollbar(text_frame, orient="vertical", command=text.yview)
        x_scroll = ttk.Scrollbar(text_frame, orient="horizontal", command=text.xview)
        text.configure(yscrollcommand=y_scroll.set, xscrollcommand=x_scroll.set)
        text.grid(row=0, column=0, sticky="nsew")
        y_scroll.grid(row=0, column=1, sticky="ns")
        x_scroll.grid(row=1, column=0, sticky="ew")
        text_frame.rowconfigure(0, weight=1)
        text_frame.columnconfigure(0, weight=1)
        text.insert("1.0", "\n".join(lines))
        text.configure(state="disabled")

        button_row = ttk.Frame(outer)
        button_row.pack(fill="x", pady=(10, 0))
        ttk.Button(button_row, text="Close", command=dialog.destroy, style="Primary.TButton").pack(side="right")

    build_worker_state = {"active": False}

    def _format_elapsed_seconds(seconds):
        seconds = max(0, int(seconds or 0))
        minutes, secs = divmod(seconds, 60)
        if minutes >= 60:
            hours, minutes = divmod(minutes, 60)
            return f"{hours:d}:{minutes:02d}:{secs:02d}"
        return f"{minutes:d}:{secs:02d}"

    def _start_build_worker(
            title, report, fallback_folder, execute_args, execute_kwargs, on_success,
            on_error_title="Build Error", executor=execute_build):
        if build_worker_state.get("active"):
            messagebox.showwarning("Build In Progress", "A build is already running. Stop it or wait for it to finish first.")
            return

        build_worker_state["active"] = True
        fallback_folder = fallback_folder or output_dir_var.get().strip() or os.path.dirname(excel_var.get() or os.getcwd())
        event_queue = queue.Queue()
        cancel_event = threading.Event()
        start_time = time.time()
        progress_state = {"total": 0, "done": 0, "sheet": ""}

        dialog = tk.Toplevel(root)
        dialog.title(title)
        dialog.resizable(True, False)
        try:
            dialog.attributes("-topmost", False)
        except Exception:
            pass
        dialog.protocol("WM_DELETE_WINDOW", dialog.iconify)

        # --- Animated GIF loading ---
        gif_frames = []
        gif_delays = []
        gif_idx = 0
        gif_label = None
        try:
            from PIL import Image, ImageTk
            script_dir = os.path.dirname(os.path.abspath(__file__))
            gif_path = os.path.join(script_dir, "loading.gif")
            if not os.path.isfile(gif_path):
                gif_path = os.path.join(os.getcwd(), "loading.gif")
            if os.path.isfile(gif_path):
                img = Image.open(gif_path)
                while True:
                    frame = img.copy().convert("RGBA")
                    frame = frame.resize((500, 500), Image.Resampling.LANCZOS)
                    gif_frames.append(ImageTk.PhotoImage(frame))
                    gif_delays.append(img.info.get("duration", 100))
                    img.seek(img.tell() + 1)
        except EOFError:
            pass
        except Exception:
            gif_frames.clear()

        def _animate_gif():
            nonlocal gif_idx
            if not gif_frames or gif_label is None:
                return
            gif_label.config(image=gif_frames[gif_idx])
            delay = gif_delays[gif_idx] if gif_idx < len(gif_delays) else 100
            gif_idx = (gif_idx + 1) % len(gif_frames)
            gif_label.after(delay, _animate_gif)

        if gif_frames:
            dialog.geometry("1060x540")
            dialog.minsize(960, 500)
            outer = ttk.Frame(dialog, padding=16)
            outer.pack(fill="both", expand=True)
            left_gif = ttk.Frame(outer)
            left_gif.pack(side="left", fill="y")
            gif_label = ttk.Label(left_gif)
            gif_label.pack(padx=8, pady=8)
            _animate_gif()
            content = ttk.Frame(outer)
            content.pack(side="right", fill="both", expand=True, padx=(16, 0))
        else:
            dialog.geometry("520x230")
            dialog.minsize(460, 210)
            content = ttk.Frame(dialog, padding=16)
            content.pack(fill="both", expand=True)

        ttk.Label(content, text=title, style="SubTitle.TLabel").pack(anchor="w")
        progress_text_var = tk.StringVar(value="Starting build...")
        ttk.Label(content, textvariable=progress_text_var, wraplength=470).pack(anchor="w", fill="x", pady=(8, 8))
        progress_bar = ttk.Progressbar(content, mode="indeterminate", length=460)
        progress_bar.pack(fill="x", pady=(0, 8))
        progress_bar.start(12)
        time_text_var = tk.StringVar(value="Elapsed 0:00 | ETA calculating...")
        ttk.Label(content, textvariable=time_text_var, foreground="gray").pack(anchor="w", fill="x")
        button_row = ttk.Frame(content)
        button_row.pack(fill="x", pady=(16, 0))
        stop_btn = ttk.Button(button_row, text="Stop Build")
        stop_btn.pack(side="left")
        ttk.Button(button_row, text="Minimize", command=dialog.iconify).pack(side="right")

        if gif_frames:
            ttk.Label(content, text="Andre of Astora", foreground="#FFD700", font=("", 10, "bold")).pack(anchor="w", pady=(8, 2))
            andre_text = "Andre is a relatively short man, sporting long white hair that is tied back into a long ponytail, and a long white beard. Andre appears to have various scars and burn marks on his upper body and arms, whilst wearing pants, a belt, and gloves. He can always be found sitting at an anvil, forging an Estoc with a hammer. He has a multitude of tools and weapons lying around him. While similar in appearance to Andre of Astora from Lordran, it is unknown for certain whether or not the Andre found in Dark Souls 3 is the same person. Some theorize that they are different people,[1] but Andre's knowledge of the Giant Blacksmith, and references to knowing him for ages, has led some to believe that they are in fact one and the same."
            ttk.Label(content, text=andre_text, wraplength=470, foreground="gray", font=("", 10)).pack(anchor="w", fill="x", pady=(2, 0))

        def _request_stop():
            cancel_event.set()
            progress_text_var.set("Stopping after the current Photoshop page finishes...")
            try:
                stop_btn.configure(state="disabled")
            except Exception:
                pass

        stop_btn.configure(command=_request_stop)

        def _progress_callback(payload):
            event_queue.put(("progress", payload or {}))

        def _worker():
            co_initialized = False
            try:
                try:
                    import pythoncom
                    pythoncom.CoInitialize()
                    co_initialized = True
                except Exception:
                    pythoncom = None
                kwargs = dict(execute_kwargs or {})
                kwargs.update({
                    "progress_callback": _progress_callback,
                    "cancel_event": cancel_event,
                    "show_completion_dialogs": False,
                })
                save_path = executor(*execute_args, **kwargs)
                event_queue.put(("done", save_path))
            except Exception as exc:
                event_queue.put(("error", str(exc)))
            finally:
                if co_initialized:
                    try:
                        pythoncom.CoUninitialize()
                    except Exception:
                        pass

        def _save_report_snapshot(save_path=""):
            finish_render_report(report, save_path or "")
            last_render_report.clear()
            last_render_report.update(report)
            _show_render_report(report, focus=True)
            try:
                save_render_report(report, save_path or "", fallback_folder)
            except Exception as report_error:
                messagebox.showwarning("Render Report", f"Render finished, but render_report.txt could not be saved:\n{report_error}")

        def _finish_common():
            build_worker_state["active"] = False
            try:
                progress_bar.stop()
            except Exception:
                pass
            try:
                stop_btn.configure(state="disabled")
            except Exception:
                pass

        def _update_time_text():
            elapsed = max(0.0, time.time() - start_time)
            total = int(progress_state.get("total") or 0)
            done = int(progress_state.get("done") or 0)
            eta_text = "calculating..."
            if total > 0 and done > 0:
                remaining = max(0, total - done)
                eta_seconds = (elapsed / done) * remaining
                eta_text = _format_elapsed_seconds(eta_seconds)
            time_text_var.set(f"Elapsed {_format_elapsed_seconds(elapsed)} | ETA {eta_text}")

        def _handle_progress(payload):
            event = payload.get("event")
            total = int(payload.get("total") or progress_state.get("total") or 0)
            if total:
                progress_state["total"] = total
                try:
                    progress_bar.stop()
                    progress_bar.configure(mode="determinate", maximum=max(1, total))
                except Exception:
                    pass
            if event == "build_start":
                progress_state["done"] = 0
                progress_text_var.set(f"Preparing {total} page(s)...")
                try:
                    progress_bar.configure(value=0)
                except Exception:
                    pass
            elif event == "sheet_start":
                sheet = str(payload.get("sheet") or "")
                index = int(payload.get("index") or 0)
                progress_state["sheet"] = sheet
                progress_state["done"] = max(0, index - 1)
                progress_text_var.set(f"Rendering {sheet} ({index}/{total or '?'})")
                try:
                    progress_bar.configure(value=progress_state["done"])
                except Exception:
                    pass
            elif event == "sheet_done":
                sheet = str(payload.get("sheet") or progress_state.get("sheet") or "")
                index = int(payload.get("index") or progress_state.get("done") or 0)
                progress_state["done"] = max(progress_state.get("done") or 0, index)
                progress_text_var.set(f"Finished {sheet} ({progress_state['done']}/{total or '?'})")
                try:
                    progress_bar.configure(value=progress_state["done"])
                except Exception:
                    pass
            elif event == "cancelled":
                progress_text_var.set("Build stopped before saving.")
            elif event == "build_done":
                progress_state["done"] = total or progress_state.get("done") or 0
                progress_text_var.set("Saving report and finishing...")
                try:
                    progress_bar.configure(value=progress_state["done"])
                except Exception:
                    pass
            _update_time_text()

        def _poll_worker():
            try:
                while True:
                    kind, payload = event_queue.get_nowait()
                    if kind == "progress":
                        _handle_progress(payload)
                    elif kind == "done":
                        _finish_common()
                        total_elapsed = _format_elapsed_seconds(time.time() - start_time)
                        report.setdefault("notes", []).append(f"Total UI build time: {total_elapsed}")
                        save_path = payload
                        if cancel_event.is_set() or not save_path:
                            report.setdefault("warnings", []).append("Build stopped by user." if cancel_event.is_set() else "Build finished without an output PSD path.")
                            _save_report_snapshot(save_path or "")
                            status_var.set("Build stopped" if cancel_event.is_set() else "Build finished without output")
                            if cancel_event.is_set():
                                messagebox.showwarning("Build Stopped", "Build stopped before saving the final PSD/PSB.")
                            else:
                                messagebox.showwarning(title, "Build finished without an output PSD path. Check the render report.")
                        else:
                            try:
                                dialog.destroy()
                            except Exception:
                                pass
                            on_success(save_path)
                            return
                        try:
                            dialog.destroy()
                        except Exception:
                            pass
                        return
                    elif kind == "error":
                        _finish_common()
                        total_elapsed = _format_elapsed_seconds(time.time() - start_time)
                        report.setdefault("notes", []).append(f"Total UI build time: {total_elapsed}")
                        report.setdefault("errors", []).append(str(payload))
                        _save_report_snapshot("")
                        status_var.set("Build failed - see error dialog")
                        messagebox.showerror(on_error_title, f"An error occurred:\n{payload}")
                        try:
                            dialog.destroy()
                        except Exception:
                            pass
                        return
            except queue.Empty:
                pass
            _update_time_text()
            if build_worker_state.get("active"):
                root.after(250, _poll_worker)

        threading.Thread(target=_worker, name="PsHelpScreenBuildWorker", daemon=True).start()
        root.after(250, _poll_worker)

    def _current_table_style_config():
        ts = TABLE_DEFAULTS.copy()
        ts['overlay_opacity'] = int(table_opacity_spin.get())
        ts['render_mode'] = {"Fill Only": "fill", "Stroke Only": "stroke", "Fill + Stroke": "both"}.get(cell_style_cb.get(), "both")
        ts['header_render_mode'] = {"Follow Global": "", "Fill Only": "fill", "Stroke Only": "stroke", "Fill + Stroke": "both"}.get(header_style_cb.get(), "")
        ts['row1_render_mode'] = {"Follow Global": "", "Fill Only": "fill", "Stroke Only": "stroke", "Fill + Stroke": "both"}.get(row1_style_cb.get(), "")
        ts['row2_render_mode'] = {"Follow Global": "", "Fill Only": "fill", "Stroke Only": "stroke", "Fill + Stroke": "both"}.get(row2_style_cb.get(), "")
        ts['stroke_rgb'] = tuple(table_stroke_rgb_val)
        ts['stroke_width'] = int(stroke_width_spin.get())
        ts['header_bg_rgb'] = tuple(table_header_rgb_val)
        ts['row1_bg_rgb'] = tuple(table_row1_rgb_val)
        ts['row2_bg_rgb'] = tuple(table_row2_rgb_val)
        ts['row_gap'] = int(row_gap_spin.get())
        ts['merge_table_layers'] = bool(table_merge_layers_var.get())
        ts['mapped_table_jsons'] = mapped_table_json_var.get().strip()
        ts['json_sheet_overrides'] = dict(json_sheet_overrides)
        ts['manual_table_ranges'] = manual_table_ranges_text.get("1.0", "end-1c").strip()
        ts['table_excel_fill_ranges'] = table_excel_fill_ranges_text.get("1.0", "end-1c").strip()
        ts['table_excel_fill_hex_overrides'] = table_excel_fill_hex_overrides_text.get("1.0", "end-1c").strip()
        ts['table_excel_font_color_ranges'] = table_excel_font_color_ranges_text.get("1.0", "end-1c").strip()
        ts['table_excel_font_hex_overrides'] = table_excel_font_hex_overrides_text.get("1.0", "end-1c").strip()
        ts['text_rectangle_cells'] = text_rectangle_cells_text.get("1.0", "end-1c").strip()
        ts['text_rectangle_fill_rgb'] = tuple(text_rect_fill_rgb_val)
        ts['text_rectangle_stroke_rgb'] = tuple(text_rect_stroke_rgb_val)
        ts['text_rectangle_stroke_width'] = int(text_rect_stroke_width_spin.get())
        ts['text_rectangle_opacity'] = int(text_rect_opacity_spin.get())
        ts['text_rectangle_font_name'] = _font_request(text_rect_font_cb.get(), text_rect_font_style_var.get()) if text_rect_font_cb.get().strip() else ""
        ts['text_rectangle_font_size'] = int(text_rect_font_size_spin.get())
        ts['text_rectangle_text_rgb'] = tuple(text_rect_text_rgb_val)
        ts['text_rectangle_alignment'] = text_rect_alignment_var.get()
        ts['text_rectangle_pad_x'] = int(text_rect_pad_x_spin.get())
        ts['text_rectangle_pad_y'] = int(text_rect_pad_y_spin.get())
        ts['header_text_rgb'] = tuple(table_header_text_rgb_val)
        ts['table_body_text_rgb'] = tuple(table_body_text_rgb_val)
        ts['after_table_margin'] = int(table_after_margin_spin.get())
        ts['after_table_min_text_room'] = int(table_min_text_room_spin.get())
        ts['table_header_font_size'] = int(table_header_size_spin.get())
        ts['table_body_font_size'] = int(table_body_size_spin.get())
        ts['table_icon_height'] = int(table_icon_height_spin.get())
        ts['table_target_height'] = int(table_target_height_spin.get())
        ts['table_target_width'] = int(table_target_width_spin.get())
        ts['table_alignment'] = table_alignment_var.get()
        ts['table_header_alignment'] = table_alignment_var.get()
        ts['table_body_alignment'] = table_alignment_var.get()
        ts['table_header_style'] = _style_config_for_assignment("Table header")
        ts['table_body_style'] = _style_config_for_assignment("Table body")
        if table_inherit_font_var.get():
            ts['table_header_font_name'] = ""
            ts['table_body_font_name'] = ""
        else:
            ts['table_header_font_name'] = _font_request(table_header_font_cb.get(), table_header_font_style_var.get())
            ts['table_body_font_name'] = _font_request(table_body_font_cb.get(), table_body_font_style_var.get())
        return ts

    def _scan_icon_warning(excel_path, icon_folder, mappings):
        from .ui_web.icon_scan import scan_icon_status_web

        status = scan_icon_status_web(excel_path, icon_folder)
        if not status.get("ok"):
            return ""
        mapped = {normalize_token(key) for key in (mappings or {})}
        missing = [t for t in status.get("missing", []) if normalize_token(t) not in mapped]
        if not missing:
            return ""
        preview = ", ".join(missing[:5]) + ("…" if len(missing) > 5 else "")
        return f"{len(missing)} missing icon(s): {preview}"

    def _run_png_build():
        if not excel_var.get():
            messagebox.showerror("Build PNGs Only", "Please select a Current Excel file first.")
            return
        png_suffix = simpledialog.askstring(
            "PNG Suffix",
            "Optional suffix for PNG filenames.\n"
            "If empty, sheet names are used (e.g. 'Paytable.png').\n"
            "If provided, files are named like '{suffix}_1.png', '{suffix}_2.png'.",
            parent=root,
        )
        if png_suffix is None:
            return
        png_suffix = png_suffix.strip()
        selected_sheet_names = _selected_sheet_names() if render_selected_pages_var.get() else []
        report = start_render_report("Build PNGs Only", selected_sheet_names)
        try:
            icon_warning = _scan_icon_warning(excel_var.get(), icon_var.get(), icon_mappings)
            if icon_warning:
                report["warnings"].append(icon_warning)
        except Exception as scan_error:
            report["warnings"].append(f"Icon scan skipped: {scan_error}")
        if render_selected_pages_var.get() and not selected_sheet_names:
            messagebox.showerror("Build PNGs Only", "Select at least one Excel tab, or turn off selected-tab rendering.")
            return
        if auto_fit_enabled_var.get():
            report["notes"].append("Auto-fit is Photoshop-specific and is ignored by PNG-only build.")
        report["notes"].append("PNG-only output is flat raster output; editable Photoshop layers and Photoshop-only layer FX are not created.")
        _save_current_session()
        status_var.set("Building PNGs... please wait")
        root.update()
        try:
            ts = _current_table_style_config()
            execute_args = (
                excel_var.get(), icon_var.get(), bg_var.get(),
                int(c_w_spin.get()), int(c_h_spin.get()), int(max_col_spin.get()),
                _font_request(h_font_cb.get(), h_font_style_var.get()), int(h_size_spin.get()), int(h_icon_spin.get()), h_rgb_val,
                _font_request(b_font_cb.get(), b_font_style_var.get()), int(b_size_spin.get()), int(b_icon_spin.get()), b_rgb_val,
                int(margin_spin.get()), int(line_spin.get()), int(para_spin.get()),
                int(gap_spin.get()), int(yoff_spin.get())
            )
            execute_kwargs = dict(
                bg_mode=bg_mode_var.get(), table_style=ts, enable_tables=enable_tables_var.get(),
                keyword_colors=keyword_mgr.get_dict(), heading_top_margin=int(heading_margin_spin.get()),
                continued_gap=int(continued_gap_spin.get()), heading_to_body_gap=int(heading_to_body_gap_spin.get()),
                heading_style=_heading_style_config(), body_style=_body_style_config(), icon_style=_icon_style_config(),
                dynamic_settings=_dynamic_settings_config(), output_dir=output_dir_var.get().strip() or None,
                icon_mappings=dict(icon_mappings), icon_size_overrides=dict(icon_size_overrides),
                bottom_margin=int(bottom_margin_spin.get()), output_name=output_name_var.get().strip() or None,
                output_format="png", overwrite_existing=True, selected_sheets=selected_sheet_names,
                body_icons_use_original_size=body_icon_original_size_var.get(), report_collector=report,
                alignment_settings=_alignment_settings_config(), performance_mode=False,
                png_suffix=png_suffix or None,
            )
            fallback_folder = output_dir_var.get().strip() or os.path.dirname(excel_var.get())

            def _on_png_success(save_path):
                finish_render_report(report, save_path or "")
                last_render_report.clear(); last_render_report.update(report); _show_render_report(report, focus=True)
                try:
                    save_render_report(report, save_path or "", fallback_folder)
                except Exception as report_error:
                    messagebox.showwarning("Render Report", f"PNG build finished, but render_report.txt could not be saved:\n{report_error}")
                status_var.set("PNG build complete!")
                messagebox.showinfo("PNG Build Complete", f"All selected PNG helpscreens are made.\nSaved to:\n{save_path}\n\nCheck the Render Report/logs for more details.")

            _start_build_worker(
                "Build PNGs Only",
                report,
                fallback_folder,
                execute_args,
                execute_kwargs,
                _on_png_success,
                on_error_title="PNG Build Error",
                executor=build_pngs_only,
            )
        except Exception as e:
            report["errors"].append(str(e))
            finish_render_report(report)
            last_render_report.clear(); last_render_report.update(report); _show_render_report(report, focus=True)
            try:
                save_render_report(report, "", output_dir_var.get().strip() or os.path.dirname(excel_var.get()))
            except Exception:
                pass
            messagebox.showerror("PNG Build Error", f"An error occurred:\n{str(e)}")
            status_var.set("PNG build failed - see error dialog")

    png_builder_card = ttk.LabelFrame(tab_png_builder, text="PNG Builder")
    png_builder_card.pack(fill="x", padx=10, pady=(10, 12))
    ttk.Label(
        png_builder_card,
        text="Build flat PNG helpscreens from the same Excel, typography, icon, table, GameRules, Bingo, and custom-layout settings used by the PSD builder.",
        style="CardMuted.TLabel",
        wraplength=900,
    ).grid(row=0, column=0, columnspan=4, sticky="w", padx=14, pady=(12, 10))
    ttk.Label(png_builder_card, text="Output:", style="FieldLabel.TLabel").grid(row=1, column=0, sticky="w", padx=14, pady=4)
    ttk.Entry(png_builder_card, textvariable=output_dir_var, state="readonly").grid(row=1, column=1, columnspan=2, sticky="ew", padx=5, pady=4)
    ttk.Button(png_builder_card, text="Files & Canvas", command=lambda: _select_nav_target("files")).grid(row=1, column=3, sticky="ew", padx=(5, 14), pady=4)
    ttk.Label(png_builder_card, text="Selected-tab rendering, output name, background, fonts, layer style choices, and table controls are inherited from the main UI.", foreground="gray", wraplength=900).grid(row=2, column=0, columnspan=4, sticky="w", padx=14, pady=(4, 12))
    ttk.Button(
        png_builder_card,
        text="BUILD PNGs ONLY",
        command=_run_png_build,
        style="BigBuild.TButton",
    ).grid(row=3, column=0, columnspan=4, sticky="ew", padx=14, pady=(0, 16), ipady=8)
    for _col in range(4):
        png_builder_card.columnconfigure(_col, weight=1 if _col in (1, 2, 3) else 0)

    def _run_build(update_mode=False):
        if not excel_var.get():
            messagebox.showerror("Error", "Please select a Current Excel file.")
            return
        selected_sheet_names = _selected_sheet_names() if render_selected_pages_var.get() else []
        report = start_render_report("Update PSD" if update_mode else "Build New PSD", selected_sheet_names)
        if auto_fit_enabled_var.get():
            report["notes"].append(f"Auto Text Fit selected: {auto_fit_mode_var.get()}")
        try:
            for row in scan_icon_status(excel_var.get(), icon_var.get(), icon_mappings, icon_size_overrides):
                if row["status"] == "Missing" and row["token"] not in report["missing_icons"]:
                    report["missing_icons"].append(row["token"])
        except Exception as scan_error:
            report["warnings"].append(f"Could not scan icons before render: {scan_error}")
        if render_selected_pages_var.get() and not selected_sheet_names:
            messagebox.showerror("Page Selection", "Select at least one Excel tab, or turn off selected-tab rendering.")
            return
        if update_mode:
            missing = []
            if not prev_excel_var.get():
                missing.append("Old Excel")
            if not prev_psd_var.get():
                missing.append("Last Updated PSD")
            if not icon_var.get():
                missing.append("Icons Folder")
            if not bg_var.get():
                missing.append("Background")
            if missing:
                messagebox.showerror("Update PSD", "Update mode needs: " + ", ".join(missing) + ".")
                return
            if not _validate_update_source():
                return
            if not _confirm_update_diff():
                report["warnings"].append("Update cancelled from Excel Diff Preview confirmation.")
                finish_render_report(report)
                last_render_report.clear(); last_render_report.update(report); _show_render_report(report, focus=True)
                return
            if update_save_mode_var.get() == "overwrite":
                if not messagebox.askyesno("Overwrite PSD", "This will overwrite the selected PSD/PSB. Continue?"):
                    return
            if safe_backup_enabled_var.get() and prev_psd_var.get().strip():
                try:
                    backup_path = copy_psd_backup(prev_psd_var.get().strip(), safe_backup_folder_var.get().strip())
                    if backup_path:
                        report["notes"].append(f"PSD backup saved: {backup_path}")
                except Exception as backup_error:
                    report["warnings"].append(f"PSD backup failed: {backup_error}")
        _save_current_session()
        status_var.set("Building... please wait")
        root.update()
        try:
            ts = TABLE_DEFAULTS.copy()
            ts['overlay_opacity'] = int(table_opacity_spin.get())
            ts['render_mode'] = {"Fill Only": "fill", "Stroke Only": "stroke", "Fill + Stroke": "both"}.get(cell_style_cb.get(), "both")
            ts['header_render_mode'] = {"Follow Global": "", "Fill Only": "fill", "Stroke Only": "stroke", "Fill + Stroke": "both"}.get(header_style_cb.get(), "")
            ts['row1_render_mode'] = {"Follow Global": "", "Fill Only": "fill", "Stroke Only": "stroke", "Fill + Stroke": "both"}.get(row1_style_cb.get(), "")
            ts['row2_render_mode'] = {"Follow Global": "", "Fill Only": "fill", "Stroke Only": "stroke", "Fill + Stroke": "both"}.get(row2_style_cb.get(), "")
            ts['stroke_rgb'] = tuple(table_stroke_rgb_val)
            ts['stroke_width'] = int(stroke_width_spin.get())
            ts['header_bg_rgb'] = tuple(table_header_rgb_val)
            ts['row1_bg_rgb'] = tuple(table_row1_rgb_val)
            ts['row2_bg_rgb'] = tuple(table_row2_rgb_val)
            ts['row_gap'] = int(row_gap_spin.get())
            ts['merge_table_layers'] = bool(table_merge_layers_var.get())
            ts['mapped_table_jsons'] = mapped_table_json_var.get().strip()
            ts['manual_table_ranges'] = manual_table_ranges_text.get("1.0", "end-1c").strip()
            ts['table_excel_fill_ranges'] = table_excel_fill_ranges_text.get("1.0", "end-1c").strip()
            ts['table_excel_fill_hex_overrides'] = table_excel_fill_hex_overrides_text.get("1.0", "end-1c").strip()
            ts['table_excel_font_color_ranges'] = table_excel_font_color_ranges_text.get("1.0", "end-1c").strip()
            ts['table_excel_font_hex_overrides'] = table_excel_font_hex_overrides_text.get("1.0", "end-1c").strip()
            ts['text_rectangle_cells'] = text_rectangle_cells_text.get("1.0", "end-1c").strip()
            ts['text_rectangle_fill_rgb'] = tuple(text_rect_fill_rgb_val)
            ts['text_rectangle_stroke_rgb'] = tuple(text_rect_stroke_rgb_val)
            ts['text_rectangle_stroke_width'] = int(text_rect_stroke_width_spin.get())
            ts['text_rectangle_opacity'] = int(text_rect_opacity_spin.get())
            ts['text_rectangle_font_name'] = _font_request(text_rect_font_cb.get(), text_rect_font_style_var.get()) if text_rect_font_cb.get().strip() else ""
            ts['text_rectangle_font_size'] = int(text_rect_font_size_spin.get())
            ts['text_rectangle_text_rgb'] = tuple(text_rect_text_rgb_val)
            ts['text_rectangle_alignment'] = text_rect_alignment_var.get()
            ts['text_rectangle_pad_x'] = int(text_rect_pad_x_spin.get())
            ts['text_rectangle_pad_y'] = int(text_rect_pad_y_spin.get())
            ts['header_text_rgb'] = tuple(table_header_text_rgb_val)
            ts['table_body_text_rgb'] = tuple(table_body_text_rgb_val)
            ts['after_table_margin'] = int(table_after_margin_spin.get())
            ts['after_table_min_text_room'] = int(table_min_text_room_spin.get())
            ts['table_header_font_size'] = int(table_header_size_spin.get())
            ts['table_body_font_size'] = int(table_body_size_spin.get())
            ts['table_icon_height'] = int(table_icon_height_spin.get())
            ts['table_target_height'] = int(table_target_height_spin.get())
            ts['table_target_width'] = int(table_target_width_spin.get())
            ts['table_alignment'] = table_alignment_var.get()
            ts['table_header_alignment'] = table_alignment_var.get()
            ts['table_body_alignment'] = table_alignment_var.get()
            ts['table_header_style'] = _style_config_for_assignment("Table header")
            ts['table_body_style'] = _style_config_for_assignment("Table body")
            if table_inherit_font_var.get():
                ts['table_header_font_name'] = ""
                ts['table_body_font_name'] = ""
            else:
                ts['table_header_font_name'] = _font_request(table_header_font_cb.get(), table_header_font_style_var.get())
                ts['table_body_font_name'] = _font_request(table_body_font_cb.get(), table_body_font_style_var.get())

            execute_args = (
                excel_var.get(), icon_var.get(), bg_var.get(),
                int(c_w_spin.get()), int(c_h_spin.get()), int(max_col_spin.get()),
                _font_request(h_font_cb.get(), h_font_style_var.get()), int(h_size_spin.get()), int(h_icon_spin.get()), h_rgb_val,
                _font_request(b_font_cb.get(), b_font_style_var.get()), int(b_size_spin.get()), int(b_icon_spin.get()), b_rgb_val,
                int(margin_spin.get()), int(line_spin.get()), int(para_spin.get()),
                int(gap_spin.get()), int(yoff_spin.get())
            )
            execute_kwargs = dict(
                bg_mode=bg_mode_var.get(), table_style=ts, enable_tables=enable_tables_var.get(),
                prev_excel_path=(prev_excel_var.get() or None) if update_mode else None,
                prev_psd_path=(prev_psd_var.get() or None) if update_mode else None,
                keyword_colors=keyword_mgr.get_dict(), heading_top_margin=int(heading_margin_spin.get()),
                continued_gap=int(continued_gap_spin.get()), heading_to_body_gap=int(heading_to_body_gap_spin.get()), heading_style=_heading_style_config(),
                body_style=_body_style_config(), icon_style=_icon_style_config(),
                dynamic_settings=_dynamic_settings_config(), output_dir=output_dir_var.get().strip() or None,
                icon_mappings=dict(icon_mappings), icon_size_overrides=dict(icon_size_overrides), bottom_margin=int(bottom_margin_spin.get()),
                output_name=output_name_var.get().strip() or None, output_format=output_format_var.get(),
                overwrite_existing=(update_mode and update_save_mode_var.get() == "overwrite"),
                selected_sheets=selected_sheet_names,
                body_icons_use_original_size=body_icon_original_size_var.get(),
                report_collector=report,
                alignment_settings=_alignment_settings_config(),
                performance_mode=performance_mode_var.get(),
            )
            fallback_folder = output_dir_var.get().strip() or os.path.dirname(excel_var.get())

            def _on_build_success(save_path):
                if save_path:
                    try:
                        prev_psd_var.set(save_path)
                        rerender_psd_var.set(save_path)
                        style_sidecar_path_var.set(os.path.splitext(save_path)[0] + ".pshelpscreen_styles.json")
                        save_settings_for_psd(save_path, _session_dict())
                        _save_styles_sidecar()
                    except Exception as settings_error:
                        messagebox.showwarning("Settings JSON", f"PSD saved, but settings JSON could not be saved:\n{settings_error}")
                finish_render_report(report, save_path or "")
                last_render_report.clear(); last_render_report.update(report); _show_render_report(report, focus=True)
                try:
                    save_render_report(report, save_path or "", fallback_folder)
                except Exception as report_error:
                    messagebox.showwarning("Render Report", f"Render finished, but render_report.txt could not be saved:\n{report_error}")
                status_var.set("Update complete!" if update_mode else "Build complete!")
                completion_text = "All selected helpscreens are made." if update_mode else "All helpscreens are made."
                messagebox.showinfo("Build Complete", f"{completion_text}\nCheck the Render Report/logs for more details.")

            _start_build_worker(
                "Update PSD" if update_mode else "Build New PSD",
                report,
                fallback_folder,
                execute_args,
                execute_kwargs,
                _on_build_success,
                on_error_title="Update Error" if update_mode else "Build Error",
            )
        except Exception as e:
            report["errors"].append(str(e))
            finish_render_report(report)
            last_render_report.clear(); last_render_report.update(report); _show_render_report(report, focus=True)
            try:
                save_render_report(report, "", output_dir_var.get().strip() or os.path.dirname(excel_var.get()))
            except Exception:
                pass
            messagebox.showerror("Build Error", f"An error occurred:\n{str(e)}")
            status_var.set("Build failed - see error dialog")

    def _run_rerender():
        if not excel_var.get():
            messagebox.showerror("Re-render", "Please select the current Excel file first.")
            return
        target_psd = rerender_psd_var.get().strip() or prev_psd_var.get().strip()
        if not target_psd:
            messagebox.showerror("Re-render", "No current PSD target found. Build/Update a PSD first, or set Last Updated PSD in the Update workflow.")
            return
        rerender_psd_var.set(target_psd)
        selected_sheet_names = _selected_rerender_sheet_names()
        if not selected_sheet_names:
            messagebox.showerror("Re-render", "Select one or more tabs inside the Re-render tab first.")
            return
        report = start_render_report("Re-render", selected_sheet_names)
        if auto_fit_enabled_var.get():
            report["notes"].append(f"Auto Text Fit selected: {auto_fit_mode_var.get()}")
        if safe_backup_enabled_var.get():
            try:
                backup_path = copy_psd_backup(target_psd, safe_backup_folder_var.get().strip())
                if backup_path:
                    report["notes"].append(f"PSD backup saved: {backup_path}")
            except Exception as backup_error:
                report["warnings"].append(f"PSD backup failed: {backup_error}")
        _save_current_session()
        status_var.set("Re-rendering selected page(s)... please wait")
        root.update()
        try:
            ts = TABLE_DEFAULTS.copy()
            ts['overlay_opacity'] = int(table_opacity_spin.get())
            ts['render_mode'] = {"Fill Only": "fill", "Stroke Only": "stroke", "Fill + Stroke": "both"}.get(cell_style_cb.get(), "both")
            ts['header_render_mode'] = {"Follow Global": "", "Fill Only": "fill", "Stroke Only": "stroke", "Fill + Stroke": "both"}.get(header_style_cb.get(), "")
            ts['row1_render_mode'] = {"Follow Global": "", "Fill Only": "fill", "Stroke Only": "stroke", "Fill + Stroke": "both"}.get(row1_style_cb.get(), "")
            ts['row2_render_mode'] = {"Follow Global": "", "Fill Only": "fill", "Stroke Only": "stroke", "Fill + Stroke": "both"}.get(row2_style_cb.get(), "")
            ts['stroke_rgb'] = tuple(table_stroke_rgb_val)
            ts['stroke_width'] = int(stroke_width_spin.get())
            ts['header_bg_rgb'] = tuple(table_header_rgb_val)
            ts['row1_bg_rgb'] = tuple(table_row1_rgb_val)
            ts['row2_bg_rgb'] = tuple(table_row2_rgb_val)
            ts['row_gap'] = int(row_gap_spin.get())
            ts['merge_table_layers'] = bool(table_merge_layers_var.get())
            ts['mapped_table_jsons'] = mapped_table_json_var.get().strip()
            ts['manual_table_ranges'] = manual_table_ranges_text.get("1.0", "end-1c").strip()
            ts['table_excel_fill_ranges'] = table_excel_fill_ranges_text.get("1.0", "end-1c").strip()
            ts['table_excel_fill_hex_overrides'] = table_excel_fill_hex_overrides_text.get("1.0", "end-1c").strip()
            ts['table_excel_font_color_ranges'] = table_excel_font_color_ranges_text.get("1.0", "end-1c").strip()
            ts['table_excel_font_hex_overrides'] = table_excel_font_hex_overrides_text.get("1.0", "end-1c").strip()
            ts['text_rectangle_cells'] = text_rectangle_cells_text.get("1.0", "end-1c").strip()
            ts['text_rectangle_fill_rgb'] = tuple(text_rect_fill_rgb_val)
            ts['text_rectangle_stroke_rgb'] = tuple(text_rect_stroke_rgb_val)
            ts['text_rectangle_stroke_width'] = int(text_rect_stroke_width_spin.get())
            ts['text_rectangle_opacity'] = int(text_rect_opacity_spin.get())
            ts['text_rectangle_font_name'] = _font_request(text_rect_font_cb.get(), text_rect_font_style_var.get()) if text_rect_font_cb.get().strip() else ""
            ts['text_rectangle_font_size'] = int(text_rect_font_size_spin.get())
            ts['text_rectangle_text_rgb'] = tuple(text_rect_text_rgb_val)
            ts['text_rectangle_alignment'] = text_rect_alignment_var.get()
            ts['text_rectangle_pad_x'] = int(text_rect_pad_x_spin.get())
            ts['text_rectangle_pad_y'] = int(text_rect_pad_y_spin.get())
            ts['header_text_rgb'] = tuple(table_header_text_rgb_val)
            ts['table_body_text_rgb'] = tuple(table_body_text_rgb_val)
            ts['after_table_margin'] = int(table_after_margin_spin.get())
            ts['after_table_min_text_room'] = int(table_min_text_room_spin.get())
            ts['table_header_font_size'] = int(table_header_size_spin.get())
            ts['table_body_font_size'] = int(table_body_size_spin.get())
            ts['table_icon_height'] = int(table_icon_height_spin.get())
            ts['table_target_height'] = int(table_target_height_spin.get())
            ts['table_target_width'] = int(table_target_width_spin.get())
            ts['table_alignment'] = table_alignment_var.get()
            ts['table_header_alignment'] = table_alignment_var.get()
            ts['table_body_alignment'] = table_alignment_var.get()
            ts['table_header_style'] = _style_config_for_assignment("Table header")
            ts['table_body_style'] = _style_config_for_assignment("Table body")
            if table_inherit_font_var.get():
                ts['table_header_font_name'] = ""
                ts['table_body_font_name'] = ""
            else:
                ts['table_header_font_name'] = _font_request(table_header_font_cb.get(), table_header_font_style_var.get())
                ts['table_body_font_name'] = _font_request(table_body_font_cb.get(), table_body_font_style_var.get())

            execute_args = (
                excel_var.get(), icon_var.get(), bg_var.get(),
                int(c_w_spin.get()), int(c_h_spin.get()), int(max_col_spin.get()),
                _font_request(h_font_cb.get(), h_font_style_var.get()), int(h_size_spin.get()), int(h_icon_spin.get()), h_rgb_val,
                _font_request(b_font_cb.get(), b_font_style_var.get()), int(b_size_spin.get()), int(b_icon_spin.get()), b_rgb_val,
                int(margin_spin.get()), int(line_spin.get()), int(para_spin.get()),
                int(gap_spin.get()), int(yoff_spin.get())
            )
            execute_kwargs = dict(
                bg_mode=bg_mode_var.get(), table_style=ts, enable_tables=enable_tables_var.get(),
                prev_excel_path=None, prev_psd_path=target_psd,
                keyword_colors=keyword_mgr.get_dict(), heading_top_margin=int(heading_margin_spin.get()),
                continued_gap=int(continued_gap_spin.get()), heading_to_body_gap=int(heading_to_body_gap_spin.get()), heading_style=_heading_style_config(),
                body_style=_body_style_config(), icon_style=_icon_style_config(),
                dynamic_settings=_dynamic_settings_config(), output_dir=output_dir_var.get().strip() or None,
                icon_mappings=dict(icon_mappings), icon_size_overrides=dict(icon_size_overrides), bottom_margin=int(bottom_margin_spin.get()),
                output_name=None, output_format=output_format_var.get(), overwrite_existing=True,
                selected_sheets=selected_sheet_names, preserve_selected_existing=(rerender_mode_var.get() == "copy" or safe_duplicate_group_var.get()),
                body_icons_use_original_size=body_icon_original_size_var.get(),
                report_collector=report,
                alignment_settings=_alignment_settings_config(),
                performance_mode=performance_mode_var.get(),
            )
            fallback_folder = output_dir_var.get().strip() or os.path.dirname(excel_var.get())

            def _on_rerender_success(save_path):
                if save_path:
                    rerender_psd_var.set(save_path)
                    prev_psd_var.set(save_path)
                    style_sidecar_path_var.set(os.path.splitext(save_path)[0] + ".pshelpscreen_styles.json")
                    save_settings_for_psd(save_path, _session_dict())
                    _save_styles_sidecar()
                finish_render_report(report, save_path or target_psd)
                last_render_report.clear(); last_render_report.update(report); _show_render_report(report, focus=True)
                try:
                    save_render_report(report, save_path or target_psd, fallback_folder)
                except Exception as report_error:
                    messagebox.showwarning("Render Report", f"Re-render finished, but render_report.txt could not be saved:\n{report_error}")
                status_var.set("Re-render complete!")
                messagebox.showinfo("Re-render Complete", "Selected helpscreens are made.\nCheck the Render Report/logs for more details.")

            _start_build_worker(
                "Re-render Selected Page(s)",
                report,
                fallback_folder,
                execute_args,
                execute_kwargs,
                _on_rerender_success,
                on_error_title="Re-render Error",
            )
        except Exception as e:
            report["errors"].append(str(e))
            finish_render_report(report, target_psd)
            last_render_report.clear(); last_render_report.update(report); _show_render_report(report, focus=True)
            messagebox.showerror("Re-render Error", f"An error occurred:\n{str(e)}")
            status_var.set("Re-render failed - see error dialog")

    build_btn = ttk.Button(action_inner, text="BUILD NEW PSD", command=lambda: _run_build(update_mode=False), style="BigBuild.TButton")
    build_btn.pack(anchor="center", pady=(0, 2), ipadx=36, ipady=8)

    active_mode = {"name": "create"}
    active_nav_key = {"key": "dashboard"}
    visible_tab_specs = []
    nav_buttons = {}
    mode_buttons = {}
    tab_descriptions = {
        "Dashboard": "Fast access to build, update, re-render, export, and the main settings groups.",
        "Project": "Files, canvas presets, output destination, and page selection.",
        "Text": "Heading, body, and keyword color settings with searchable font controls.",
        "Page Alignment": "Global text alignment defaults plus per-Excel-tab overrides.",
        "Layer Styles": "Capture, save, assign, and reuse Photoshop layer-style presets.",
        "Tables": "Normal table rendering, fills, strokes, typography, and spacing after the table block.",
        "JSON Tables": "Dynamic table JSON mapper — add, remove, assign JSONs to sheets, and open the table mapper.",
        "PNG Builder": "Build flat PNG helpscreens from the current UI settings without creating editable Photoshop layers.",
        "Icons": "Default icon sizing plus Excel icon-to-asset mapping and body-icon size overrides.",
        "Custom Page Layouts": "Routing, paytable, game rules, and per-page JSON overrides for dynamic layouts.",
        "Layout & Build": "Margins, spacing, presets, and overall build behavior.",
        "Update PSD": "Update an existing PSD using old/new Excel plus the saved PSD settings manifest.",
        "Re-render": "Target only selected pages in the current PSD without rebuilding everything else.",
        "Export JSON": "Scan a PSD or active document and export slot JSON for custom layouts.",
        "Render Report": "View and save build/update/re-render reports with missing icons, warnings, timing, and output path.",
        "Missing Icons": "Scan Excel tokens, find missing icons, preview assets, and manage mappings.",
        "Presets": "Save, load, duplicate, and delete complete style/settings presets.",
        "Preview": "Preview selected Excel tabs and compare old/new Excel before updating.",
        "Export": "Batch export PSD page groups as PNG or JPG.",
        "Backup & Safety": "Safe PSD backups, update confirmations, and auto-fit preflight settings.",
        "Layer Guide": "Normal page group structure and custom layout slot naming reference.",
    }
    mode_labels = {
        "dashboard": "Dashboard",
        "create": "Create Help Screen PSD",
        "update": "Update Help Screens",
        "rerender": "Re-render Pages",
        "export": "Export JSON of Custom Layout",
    }
    mode_descriptions = {
        "dashboard": "Overview and quick access to the main workflows.",
        "create": "Build a brand-new help screen PSD or PSB from Excel.",
        "update": "Compare Excel versions and update only the changed pages in an existing PSD.",
        "rerender": "Replace or copy only selected page groups in the current PSD.",
        "export": "Extract slot JSON from a prepared Photoshop layout without touching the renderer.",
    }
    tab_specs = [
        (tab_dashboard_tab, "Dashboard"),
        (tab_project, "Project"),
        (tab_text, "Text"),
        (tab_alignment_tab, "Page Alignment"),
        (tab_layer_styles_tab, "Layer Styles"),
        (tab_table_tab, "Normal Tables"),
        (tab_table_json_tab, "JSON Tables"),
        (tab_png_builder_tab, "PNG Builder"),
        (tab_icons, "Icons"),
        (tab_dynamic, "Custom Page Layouts"),
        (tab_build_tab, "Layout & Build"),
        (tab_update_tab, "Update PSD"),
        (tab_rerender_tab, "Re-render"),
        (tab_custom_tab, "Export JSON"),
        (tab_report_tab, "Render Report"),
        (tab_missing_icons_tab, "Missing Icons"),
        (tab_presets_tab, "Presets"),
        (tab_preview_tab, "Preview"),
        (tab_safety_tab, "Backup & Safety"),
        (tab_guide_tab, "Layer Guide"),
    ]
    sidebar_targets = [
        ("workflow", "Dashboard", "dashboard", "Dashboard", "Overview and quick links.", "create", tab_dashboard_tab, None),
        ("workflow", "Create New PSD", "create", "Files & Canvas", mode_descriptions["create"], "create", tab_project, (project_nb, tab_files_tab)),
        ("workflow", "Update PSD", "update", "Update PSD", mode_descriptions["update"], "update", tab_update_tab, None),
        ("workflow", "Re-render Pages", "rerender", "Re-render Pages", mode_descriptions["rerender"], "create", tab_rerender_tab, None),
        ("workflow", "Export JSON", "export", "Export JSON", mode_descriptions["export"], "export", tab_custom_tab, None),
        ("sections", "Files & Canvas", "files", "Files & Canvas", "Excel, icons, background, output name, and canvas presets.", "create", tab_project, (project_nb, tab_files_tab)),
        ("sections", "Text Styles", "text", "Text Styles", "Heading, body, keyword colors, spacing, and layer style controls.", "create", tab_text, (text_nb, tab_head_tab)),
        ("sections", "Page Alignment", "alignment", "Page Alignment", tab_descriptions["Page Alignment"], "create", tab_alignment_tab, None),
        ("sections", "Layer Styles", "layer_styles", "Layer Styles", tab_descriptions["Layer Styles"], "create", tab_layer_styles_tab, None),
        ("sections", "Normal Tables", "tables", "Normal Tables", tab_descriptions["Tables"], "create", tab_table_tab, None),
        ("sections", "JSON Tables", "json_tables", "JSON Tables", tab_descriptions["JSON Tables"], "create", tab_table_json_tab, None),
        ("sections", "PNG Builder", "png_builder", "PNG Builder", tab_descriptions["PNG Builder"], "create", tab_png_builder_tab, None),
        ("sections", "Paytable / Custom Layouts", "paytable", "Paytable / Custom Layouts", tab_descriptions["Custom Page Layouts"], "create", tab_dynamic, (dynamic_nb, tab_dynamic_paytable_host)),
        ("sections", "Icons & Mapping", "icons", "Icons & Mapping", tab_descriptions["Icons"], "create", tab_icons, (icons_nb, tab_mapping_tab)),
        ("sections", "Settings", "settings", "Settings", tab_descriptions["Layout & Build"], "create", tab_build_tab, None),
        ("production", "Render Report", "report", "Render Report", tab_descriptions["Render Report"], "create", tab_report_tab, None),
        ("production", "Missing Icons", "missing_icons", "Missing Icons", tab_descriptions["Missing Icons"], "create", tab_missing_icons_tab, None),
        ("production", "Presets", "presets", "Presets", tab_descriptions["Presets"], "create", tab_presets_tab, None),
        ("production", "Preview / Diff", "preview", "Preview", tab_descriptions["Preview"], "create", tab_preview_tab, None),
        ("production", "Backup & Safety", "safety", "Backup & Safety", tab_descriptions["Backup & Safety"], "create", tab_safety_tab, None),
        ("production", "Layer Guide", "guide", "Layer Guide", tab_descriptions["Layer Guide"], "create", tab_guide_tab, None),
    ]
    target_by_key = {item[2]: item for item in sidebar_targets}

    def _style_sidebar_button(button, selected=False, compact=False):
        button.configure(
            bg=palette["accent"] if selected else palette["sidebar_bg"],
            fg=palette["button_text_on_accent"] if selected else palette["muted"],
            activebackground=palette["accent_alt"] if selected else palette["panel_bg"],
            activeforeground=palette["button_text_on_accent"] if selected else palette["text"],
            relief="flat",
            bd=0,
            highlightthickness=1,
            highlightbackground=palette["accent"] if selected else palette["sidebar_bg"],
            highlightcolor=palette["accent_alt"],
            padx=14,
            pady=9 if compact else 11,
            anchor="w",
            font=ui_font_semibold,
            cursor="hand2",
            wraplength=160,
        )

    def _set_primary_action(text, command, style_name="BigBuild.TButton", visible=True):
        build_btn.configure(text=text, command=command, style=style_name)
        if visible and not build_btn.winfo_manager():
            build_btn.pack(anchor="center", pady=(0, 2), ipadx=36, ipady=8)
        elif not visible and build_btn.winfo_manager():
            build_btn.pack_forget()

    def _refresh_mode_buttons():
        for key, button in mode_buttons.items():
            _style_sidebar_button(button, selected=(key == active_nav_key["key"]), compact=True)

    def _refresh_primary_action():
        current_tab = str(notebook.select()) if notebook.tabs() else ""
        if current_tab == str(tab_rerender_tab):
            _set_primary_action("RE-RENDER SELECTED PAGE(S)", _run_rerender, "BigWarning.TButton", visible=True)
        elif current_tab == str(tab_preview_tab):
            _set_primary_action("PREVIEW SELECTED TAB", _run_preview, "BigBuild.TButton", visible=True)
        elif current_tab == str(tab_png_builder_tab):
            _set_primary_action("BUILD PNGs ONLY", _run_png_build, "BigBuild.TButton", visible=True)
        elif current_tab == str(tab_missing_icons_tab):
            _set_primary_action("SCAN ICONS", lambda: _scan_mapping_tokens(show_message=True), "BigBuild.TButton", visible=True)
        elif current_tab == str(tab_presets_tab):
            _set_primary_action("SAVE CURRENT PRESET", _save_style_preset, "BigBuild.TButton", visible=True)
        elif current_tab == str(tab_report_tab):
            _set_primary_action("SAVE RENDER REPORT", _save_report_now, "BigBuild.TButton", visible=True)
        elif active_mode["name"] == "update":
            _set_primary_action("UPDATE CHANGED PAGES", lambda: _run_build(update_mode=True), "BigWarning.TButton", visible=True)
        elif active_mode["name"] == "export":
            export_command = _export_selected_group_json if custom_group_var.get().strip() else _export_active_paytable_json
            _set_primary_action("EXPORT LAYOUT JSON", export_command, "BigBuild.TButton", visible=True)
        else:
            _set_primary_action("BUILD NEW PSD", lambda: _run_build(update_mode=False), "BigBuild.TButton", visible=True)

    def _sync_sidebar_selection(_event=None):
        current_tab = str(notebook.select()) if notebook.tabs() else ""
        if active_nav_key["key"] in ("dashboard", "create") and current_tab == str(tab_dashboard_tab):
            current_key = active_nav_key["key"]
        else:
            current_key = _infer_nav_key_from_selection()
            active_nav_key["key"] = current_key
        for key, button in nav_buttons.items():
            _style_sidebar_button(button, selected=(key == active_nav_key["key"]))
        target = target_by_key.get(active_nav_key["key"])
        current_label = target[3] if target else "Dashboard"
        current_description = target[4] if target else tab_descriptions.get(current_label, "")
        section_title_var.set(current_label)
        section_subtitle_var.set(current_description)
        _refresh_mode_buttons()
        _refresh_primary_action()

    def _rebuild_sidebar_nav():
        for child in nav_button_frame.winfo_children():
            child.destroy()
        nav_buttons.clear()
        build_setup_label = ttk.Label(nav_button_frame, text="Build Setup", style="SidebarSection.TLabel")
        build_setup_label.pack(anchor="w", pady=(0, 10))
        _enable_sidebar_scroll(build_setup_label)
        for section_name, group_name in (("Build Setup", "sections"), ("Production Tools", "production")):
            if group_name == "production":
                section_label = ttk.Label(nav_button_frame, text=section_name, style="SidebarSection.TLabel")
                section_label.pack(anchor="w", pady=(12, 10))
                _enable_sidebar_scroll(section_label)
            for group, label, key, _title, _description, _mode, _tab, _nested in sidebar_targets:
                if group != group_name:
                    continue
                btn = tk.Button(nav_button_frame, text=label, command=lambda k=key: _select_nav_target(k))
                btn.pack(fill="x", pady=(0, 8))
                _enable_sidebar_scroll(btn)
                nav_buttons[key] = btn
        _refresh_sidebar_scroll()
        _sync_sidebar_selection()

    def _build_sidebar_modes():
        for child in mode_switch_frame.winfo_children():
            child.destroy()
        mode_buttons.clear()
        workflow_label = ttk.Label(mode_switch_frame, text="Workflow", style="SidebarSection.TLabel")
        workflow_label.pack(anchor="w", pady=(0, 10))
        _enable_sidebar_scroll(workflow_label)
        for group, label, key, _title, _description, _mode, _tab, _nested in sidebar_targets:
            if group != "workflow":
                continue
            btn = tk.Button(mode_switch_frame, text=label, command=lambda k=key: _select_nav_target(k))
            btn.pack(fill="x", pady=(0, 8))
            _enable_sidebar_scroll(btn)
            mode_buttons[key] = btn
        _refresh_sidebar_scroll()
        _refresh_mode_buttons()

    def _arrange_main_views(show_action=True):
        if launcher_frame.winfo_manager():
            launcher_frame.pack_forget()
        if main_shell.winfo_manager():
            main_shell.pack_forget()
        if action_frame.winfo_manager():
            action_frame.pack_forget()
        if show_action:
            action_frame.pack(fill="x", side="bottom", padx=16, pady=(0, 16))
        main_shell.pack(side="top", fill="both", expand=True, padx=16, pady=(16, 8 if show_action else 16))

    def _show_only_tabs(selected):
        visible_tab_specs[:] = list(selected)
        for tab, _label in tab_specs:
            try:
                notebook.hide(tab)
            except Exception:
                pass
        for tab, label in selected:
            try:
                notebook.add(tab, text=label)
            except Exception:
                pass
        _rebuild_sidebar_nav()
        if selected:
            notebook.select(selected[0][0])
        _sync_sidebar_selection()

    def _visible_tabs_for_mode(mode):
        if mode == "update":
            return [
                (tab_dashboard_tab, "Dashboard"),
                (tab_update_tab, "Update PSD"),
                (tab_project, "Project"),
                (tab_text, "Text"),
                (tab_alignment_tab, "Page Alignment"),
                (tab_layer_styles_tab, "Layer Styles"),
                (tab_table_tab, "Normal Tables"),
                (tab_table_json_tab, "JSON Tables"),
                (tab_png_builder_tab, "PNG Builder"),
                (tab_icons, "Icons"),
                (tab_dynamic, "Custom Page Layouts"),
                (tab_build_tab, "Layout & Build"),
                (tab_rerender_tab, "Re-render"),
                (tab_report_tab, "Render Report"),
                (tab_missing_icons_tab, "Missing Icons"),
                (tab_presets_tab, "Presets"),
                (tab_preview_tab, "Preview"),
                (tab_safety_tab, "Backup & Safety"),
                (tab_guide_tab, "Layer Guide"),
            ]
        if mode == "export":
            return [(tab_dashboard_tab, "Dashboard"), (tab_custom_tab, "Export JSON")]
        return [
            (tab_dashboard_tab, "Dashboard"),
            (tab_project, "Project"),
            (tab_text, "Text"),
            (tab_alignment_tab, "Page Alignment"),
            (tab_layer_styles_tab, "Layer Styles"),
            (tab_table_tab, "Normal Tables"),
            (tab_table_json_tab, "JSON Tables"),
            (tab_png_builder_tab, "PNG Builder"),
            (tab_icons, "Icons"),
            (tab_dynamic, "Custom Page Layouts"),
            (tab_build_tab, "Layout & Build"),
            (tab_rerender_tab, "Re-render"),
            (tab_report_tab, "Render Report"),
            (tab_missing_icons_tab, "Missing Icons"),
            (tab_presets_tab, "Presets"),
            (tab_preview_tab, "Preview"),
            (tab_safety_tab, "Backup & Safety"),
            (tab_guide_tab, "Layer Guide"),
        ]

    def _infer_nav_key_from_selection():
        current_tab = str(notebook.select()) if notebook.tabs() else ""
        if current_tab == str(tab_dashboard_tab):
            return "dashboard"
        if current_tab == str(tab_update_tab):
            return "update"
        if current_tab == str(tab_rerender_tab):
            return "rerender"
        if current_tab == str(tab_custom_tab):
            return "export"
        if current_tab == str(tab_report_tab):
            return "report"
        if current_tab == str(tab_missing_icons_tab):
            return "missing_icons"
        if current_tab == str(tab_presets_tab):
            return "presets"
        if current_tab == str(tab_preview_tab):
            return "preview"
        if current_tab == str(tab_safety_tab):
            return "safety"
        if current_tab == str(tab_guide_tab):
            return "guide"
        if current_tab == str(tab_project):
            return "files"
        if current_tab == str(tab_table_tab):
            return "tables"
        if current_tab == str(tab_table_json_tab):
            return "json_tables"
        if current_tab == str(tab_png_builder_tab):
            return "png_builder"
        if current_tab == str(tab_alignment_tab):
            return "alignment"
        if current_tab == str(tab_layer_styles_tab):
            return "layer_styles"
        if current_tab == str(tab_icons):
            return "icons"
        if current_tab == str(tab_build_tab):
            return "settings"
        if current_tab == str(tab_text):
            return "text"
        if current_tab == str(tab_dynamic):
            selected_dynamic_tab = str(dynamic_nb.select())
            if selected_dynamic_tab == str(tab_dynamic_rules_host):
                return "paytable"
            return "paytable"
        return active_nav_key.get("key") or "dashboard"

    def _select_mode(mode, preserve_nav=False):
        active_mode["name"] = mode
        if not preserve_nav:
            active_nav_key["key"] = "create" if mode == "create" else mode
        sidebar_mode_var.set(f"{mode_labels.get(mode, mode)}\n{mode_descriptions.get(mode, '')}".strip())
        _arrange_main_views(show_action=True)
        _show_only_tabs(_visible_tabs_for_mode(mode))
        if mode == "update":
            status_var.set("Update PSD mode")
        elif mode == "export":
            status_var.set("Export JSON mode")
        else:
            status_var.set("Create New PSD mode")
        _refresh_mode_buttons()
        _refresh_primary_action()

    def _select_nav_target(key):
        target = target_by_key.get(key)
        if not target:
            return
        _group, _label, target_key, _title, _description, target_mode, target_tab, nested_target = target
        active_nav_key["key"] = target_key
        if active_mode["name"] != target_mode or str(target_tab) not in {str(tab) for tab, _label in visible_tab_specs}:
            _select_mode(target_mode, preserve_nav=True)
        else:
            _arrange_main_views(show_action=True)
        active_nav_key["key"] = target_key
        try:
            notebook.select(target_tab)
        except Exception:
            pass
        if nested_target:
            nested_notebook, nested_tab = nested_target
            try:
                nested_notebook.select(nested_tab)
            except Exception:
                pass
        _sync_sidebar_selection()

    notebook.bind("<<NotebookTabChanged>>", _sync_sidebar_selection)
    _build_sidebar_modes()

    def _apply_visual_tweaks(widget):
        for child in widget.winfo_children():
            try:
                if isinstance(child, ttk.Button) and child is not build_btn:
                    text = str(child.cget("text") or "").strip().casefold()
                    if "remove" in text or "clear override" in text or text == "clear size":
                        child.configure(style="Danger.TButton")
                    elif "re-render" in text or "update changed pages" in text or text.startswith("overwrite"):
                        child.configure(style="Warning.TButton")
                    elif text.startswith("build") or text.startswith("export") or text.startswith("scan") or text.startswith("apply"):
                        child.configure(style="Primary.TButton")
                    else:
                        child.configure(style="Secondary.TButton")
                elif isinstance(child, tk.Button):
                    if not str(child.cget("text") or "").strip():
                        _set_btn_color(child, child.cget("bg"))
                elif isinstance(child, tk.Listbox):
                    _style_listbox(child)
            except Exception:
                pass
            _apply_visual_tweaks(child)

    def _on_close():
        try:
            _save_current_session()
        except Exception as e:
            print(f"Could not save session on close: {e}")
        root.destroy()

    root.protocol("WM_DELETE_WINDOW", _on_close)

    last_session = load_session()
    if last_session:
        try:
            _apply_loaded(last_session)
        except Exception as e:
            print(f"Could not auto-load session: {e}")
    try:
        _refresh_mapping_choices()
        _scan_mapping_tokens(show_message=False)
    except Exception as e:
        print(f"Could not initialize icon mappings: {e}")
    refresh_kw_tree()
    _apply_visual_tweaks(root)
    root.mainloop()
