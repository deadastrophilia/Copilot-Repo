"""photoshop_heading_renderer.py — Photoshop heading compositing (optional).

When enabled (see config.USE_PHOTOSHOT_HEADING_COMPOSITING / the
PSH_USE_PHOTOSHOT_HEADING_COMPOSITING env var), headings are rendered through
real Photoshop so the PNG output and the Live Preview show the exact same
text layer styles (stroke / shadow / glow / gradient / bevel / overlay /
kerning / tracking / alignment) as the PSD renderer.

Flow
----
1. The caller (png_builder / visualiser_data) measures the heading exactly as
   it always has (same wrap + PIL measurement), so the block box (x, y, width,
   height) is unchanged and downstream layout math never shifts.
2. ``render_heading_png`` creates a temporary Photoshop document, one text
   layer per wrapped line (mirroring the PSD heading group), applies the same
   layer style through ``layer_styles.apply_heading_layer_style``, and exports
   a transparent PNG (PNG-24, save-for-web) from the cache dir.
3. The caller alpha-composites the PNG at the exact box it already computed.

Nothing here is mandatory: every function degrades to None when the flag is
off, Photoshop is not running, or the render fails, and the caller falls back
to the historical drawing path. The cache lives in
%LOCALAPPDATA%/PsHelpScreenTool/heading_cache/ and is keyed on the full
heading identity (text, font, size, color, style hash, width, alignment,
scale) so changing any of them invalidates the render automatically.
"""

import hashlib
import json
import os
import tempfile

from .config import photoshop_heading_compositing_enabled

# ---------------------------------------------------------------------------
# Cache
# ---------------------------------------------------------------------------

_CACHE_DIR = None


def heading_cache_dir():
    """%LOCALAPPDATA%/PsHelpScreenTool/heading_cache/ (created on demand)."""
    global _CACHE_DIR
    if _CACHE_DIR is None:
        base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
        _CACHE_DIR = os.path.join(base, "PsHelpScreenTool", "heading_cache")
        try:
            os.makedirs(_CACHE_DIR, exist_ok=True)
        except Exception:
            _CACHE_DIR = tempfile.gettempdir()
    return _CACHE_DIR


def _style_hash(style_config):
    """Stable hash of the layer-style config so style edits invalidate the cache."""
    try:
        raw = json.dumps(style_config or {}, sort_keys=True, default=str)
    except Exception:
        raw = str(style_config or "")
    return hashlib.sha256(raw.encode("utf-8", "replace")).hexdigest()[:24]


def heading_cache_key(text, font_name, font_size, color_rgb, style_config,
                      box_width, alignment, scale):
    """Cache key covering the whole visual identity of the heading."""
    payload = "|".join([
        str(text or ""),
        str(font_name or ""),
        str(font_size),
        repr(color_rgb),
        _style_hash(style_config),
        str(box_width),
        str(alignment or ""),
        str(scale),
    ])
    return hashlib.sha256(payload.encode("utf-8", "replace")).hexdigest()


# ---------------------------------------------------------------------------
# Photoshop helpers
# ---------------------------------------------------------------------------

_PS_PROBE = None  # None = unknown, True = connected, False = unavailable
_PS_PROBE_AT = 0.0  # monotonic timestamp of the last probe
_PS_PROBE_TTL_OK = 300.0  # trust a successful connection for 5 minutes
_PS_PROBE_TTL_FAIL = 15.0  # re-probe failures quickly (PS may open/recover)
_PS_PROBE_RETRIES = 3
_PS_PROBE_RETRY_DELAY = 0.7


def _photoshop_available():
    """Probe Photoshop over COM with retries; never raise.

    Photoshop rejects automation with 'message filter' errors whenever it is
    busy or has a modal state, so a single failed probe must never be final:
    failures are retried immediately and re-probed after a short TTL so the
    app recovers as soon as Photoshop becomes responsive."""
    global _PS_PROBE, _PS_PROBE_AT
    import time

    now = time.monotonic()
    if _PS_PROBE is True and (now - _PS_PROBE_AT) < _PS_PROBE_TTL_OK:
        return True
    if _PS_PROBE is False and (now - _PS_PROBE_AT) < _PS_PROBE_TTL_FAIL:
        return False
    # COM reaches only the *registered* Photoshop. When that version is not the
    # one running (e.g. 2023 open, 2026 registered) CoCreateInstance tries to
    # start it and blocks for minutes per call — treat it as unavailable.
    try:
        from . import photoshop_bridge

        # (photoshop.api below always uses the shared ProgID — a version-specific one doesn't help it)
        _info = photoshop_bridge.describe()
        if _info.get("route") != "com" or _info.get("progid") != "Photoshop.Application" \
                or not photoshop_bridge.running_photoshops():
            _PS_PROBE = False
            _PS_PROBE_AT = now
            return False
    except Exception:
        pass
    last_exc = None
    for _attempt in range(max(1, _PS_PROBE_RETRIES)):
        try:
            import photoshop.api as ps

            app = ps.Application()
            _ = app.version  # forces a real connection
            _PS_PROBE = True
            _PS_PROBE_AT = now
            return True
        except Exception as exc:
            last_exc = exc
            try:
                time.sleep(_PS_PROBE_RETRY_DELAY)
            except Exception:
                pass
    print(f"[Photoshop] unavailable ({last_exc})")
    _PS_PROBE = False
    _PS_PROBE_AT = now
    return False


def _num(value, fallback):
    try:
        return float(value)
    except Exception:
        return fallback


def _rgb(value, fallback=(255, 255, 255)):
    try:
        if isinstance(value, (list, tuple)) and len(value) >= 3:
            return [int(round(min(255, max(0, float(c))))) for c in value[:3]]
        if isinstance(value, str):
            import re

            m = re.fullmatch(r"#?([0-9a-fA-F]{6})", value.strip())
            if m:
                n = int(m.group(1), 16)
                return [(n >> 16) & 255, (n >> 8) & 255, n & 255]
    except Exception:
        pass
    return list(fallback)


def _justification(alignment):
    """Map UI alignment to the Photoshop Justification enum."""
    try:
        import photoshop.api as ps

        align = str(alignment or "center").strip().lower()
        if align == "left":
            return ps.Justification.Left
        if align == "right":
            return ps.Justification.Right
        return ps.Justification.Center
    except Exception:
        return None


def _export_png(doc, out_path):
    """Export the document as a transparent PNG-24 via save-for-web."""
    import photoshop.api as ps

    opts = ps.ExportOptionsSaveForWeb()
    opts.format = ps.SaveDocumentType.PNGSave
    opts.PNG8 = False
    opts.transparency = True
    doc.exportDocument(str(out_path), ps.ExportType.SaveForWeb, opts)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def render_heading_png(text, font_name, font_size, color_rgb, style_config,
                       box_width, alignment="center", scale=1.0,
                       lines=None, line_widths=None, line_heights=None,
                       line_spacing=0, tracking=None):
    """Render the heading through Photoshop to a transparent PNG.

    Parameters mirror the block the PNG renderer already measures:
      text         — heading text (may be multi-line if pre-wrapped lines pass)
      font_name    — UI font request (resolved to a PS PostScript name)
      font_size    — heading size in px (72 PPI temp doc -> px == pt)
      color_rgb    — heading colour (tuple/hex)
      style_config — the layer-style config (``captured_effects_hex`` etc.)
      box_width    — the heading box width the PNG renderer uses
      alignment    — center / left / right
      scale        — canvas scale (cache key member; renders at scale 1:1)
      lines        — optional pre-wrapped lines; when None the text is one line
      line_widths  — PIL-measured widths for each line (alignment math)
      line_heights — PIL-measured line box heights for each line
      line_spacing — px gap between wrapped lines
      tracking     — optional tracking value (0 disables)

    Returns ``(png_path, ink_bounds)`` where ink_bounds is
    ``[left, top, right, bottom]`` of the rendered ink inside the PNG
    (already trimmed to the visible pixels), or ``(None, None)`` when the
    feature is disabled / Photoshop is unavailable / rendering failed.
    """
    if not photoshop_heading_compositing_enabled():
        return None, None
    if not text or not str(text).strip():
        return None, None
    if not _photoshop_available():
        return None, None

    lines = [ln for ln in (lines or [str(text)]) if str(ln or "").strip() != ""]
    if not lines:
        return None, None
    color = _rgb(color_rgb)
    key = heading_cache_key(
        "|".join(lines), font_name, font_size, color, style_config,
        box_width, alignment, scale,
    )
    cache_dir = heading_cache_dir()
    png_path = os.path.join(cache_dir, key + ".png")
    meta_path = os.path.join(cache_dir, key + ".json")
    if os.path.isfile(png_path) and os.path.isfile(meta_path):
        try:
            with open(meta_path, "r", encoding="utf-8") as fh:
                meta = json.load(fh)
            return png_path, tuple(meta.get("ink_bounds") or (0, 0, 0, 0))
        except Exception:
            pass

    try:
        return _render_heading_png_inner(
            png_path, meta_path, lines, font_name, font_size, color,
            style_config, box_width, alignment, line_widths, line_heights,
            line_spacing, tracking,
        )
    except Exception as exc:
        print(f"[Heading PS] Photoshop heading render failed; falling back: {exc}")
        try:
            if os.path.isfile(png_path):
                os.remove(png_path)
        except Exception:
            pass
        return None, None


def _render_heading_png_inner(png_path, meta_path, lines, font_name, font_size,
                              color, style_config, box_width, alignment,
                              line_widths, line_heights, line_spacing, tracking):
    """Create the temp doc, text layers, styles, export; returns (path, bounds)."""
    import photoshop.api as ps

    from .layer_styles import apply_heading_layer_style
    from .photoshop_fonts import resolve_photoshop_font

    app = ps.Application()
    ps_font = resolve_photoshop_font(app, font_name) or font_name

    # Per-line geometry (mirror the PNG renderer's alignment math).
    line_widths = list(line_widths or [0] * len(lines))
    line_heights = list(line_heights or [0] * len(lines))
    pad = max(40, int(font_size) * 2)
    doc_w = max(16, int(round(float(box_width)))) + pad * 2
    total_h = 0
    for i, line in enumerate(lines):
        lh = float(line_heights[i]) if i < len(line_heights) and line_heights[i] else (float(font_size) * 1.2)
        total_h += max(1, int(round(lh)))
        if i < len(lines) - 1:
            total_h += max(0, int(round(float(line_spacing or 0))))
    doc_h = max(16, total_h) + pad * 2

    doc = app.documents.add(
        doc_w, doc_h, 72.0, "heading_render",
        ps.NewDocumentMode.NewRGB, ps.DocumentFill.Transparent,
    )
    try:
        justify = _justification(alignment)
        y_cursor = pad
        for i, line in enumerate(lines):
            layer = doc.artLayers.add()
            layer.kind = ps.LayerKind.TextLayer
            layer.name = f"Heading {i + 1}"
            layer.textItem.contents = str(line).replace(" ", "\xa0")
            layer.textItem.size = float(font_size)  # 72 PPI -> px == pt
            try:
                layer.textItem.font = ps_font
            except Exception as exc:
                print(f"[Heading PS] font '{ps_font}' failed: {exc}")
            color_obj = ps.SolidColor()
            color_obj.rgb.red, color_obj.rgb.green, color_obj.rgb.blue = color
            layer.textItem.color = color_obj
            # The per-line x below is the line's LEFT edge (same cursor_x the
            # PNG renderer computes); keep justification LEFT so Photoshop
            # does not re-anchor the line around x (center justification on
            # point text centers the glyphs ON the position, shifting them).
            if justify is not None:
                layer.textItem.justification = ps.Justification.Left
            if tracking:
                try:
                    layer.textItem.tracking = float(tracking)
                except Exception:
                    pass

            lw = float(line_widths[i]) if i < len(line_widths) and line_widths[i] else float(font_size) * 0.55 * len(line)
            align = str(alignment or "center").strip().lower()
            if align == "left":
                x = pad
            elif align == "right":
                x = pad + max(0.0, float(box_width) - lw)
            else:
                x = pad + max(0.0, (float(box_width) - lw) / 2.0)
            # Photoshop textItem.position is the BASELINE (PSD engine passes
            # top + font_size); mirror _baseline_from_top for parity.
            layer.textItem.position = [x, y_cursor + float(font_size)]
            apply_heading_layer_style(app, doc, layer, style_config)

            lh = float(line_heights[i]) if i < len(line_heights) and line_heights[i] else (float(font_size) * 1.2)
            y_cursor += max(1, int(round(lh)))
            if i < len(lines) - 1:
                y_cursor += max(0, int(round(float(line_spacing or 0))))

        _export_png(doc, png_path)

        # Trim to the visible ink so the caller gets exact rendered bounds.
        ink_bounds = _png_ink_bounds(png_path)
        try:
            with open(meta_path, "w", encoding="utf-8") as fh:
                json.dump({"ink_bounds": list(ink_bounds)}, fh)
        except Exception:
            pass
        return png_path, ink_bounds
    finally:
        try:
            doc.close(2)  # DoNotSaveChanges
        except Exception:
            pass


def _png_ink_bounds(png_path):
    """Return [left, top, right, bottom] of non-transparent pixels (or zeros)."""
    try:
        from PIL import Image

        img = Image.open(png_path).convert("RGBA")
        bbox = img.getbbox()
        if not bbox:
            return (0, 0, 0, 0)
        return tuple(bbox)
    except Exception:
        return (0, 0, 0, 0)


def composite_heading_png(page, png_path, x, y, ink_bounds=None):
    """Alpha-composite a rendered heading PNG onto the RGBA page.

    ``ink_bounds`` ([l, t, r, b] inside the PNG) is optional; when provided
    the PNG is placed so its ink top-left lands at (x, y) exactly (the box
    the PNG renderer computed). When omitted the whole PNG is pasted at (x, y).
    Returns True on success.
    """
    if not png_path or not os.path.isfile(png_path):
        return False
    try:
        from PIL import Image

        img = Image.open(png_path).convert("RGBA")
        if ink_bounds:
            l, t, r, b = ink_bounds
            page.alpha_composite(img, (int(round(x - l)), int(round(y - t))))
        else:
            page.alpha_composite(img, (int(round(x)), int(round(y))))
        return True
    except Exception as exc:
        print(f"[Heading PS] composite failed: {exc}")
        return False


def invalidate_cache(text, font_name, font_size, color_rgb, style_config,
                     box_width, alignment, scale):
    """Remove a cached heading render (edits to any member regenerate it)."""
    key = heading_cache_key(text, font_name, font_size, color_rgb, style_config,
                            box_width, alignment, scale)
    for ext in (".png", ".json"):
        try:
            p = os.path.join(heading_cache_dir(), key + ext)
            if os.path.isfile(p):
                os.remove(p)
        except Exception:
            pass
