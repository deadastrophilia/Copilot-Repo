"""Which layers of a PSD show which AGR content: the binding that lets a PSD be updated in place.

A binding is made once per design (from the clone's matching, confirmed by the
artist in the links review) and kept, so the next AGR version or another market
updates the same layers without matching again. See DESIGN_PRESERVING_UPDATES.md.

    {"schema": 1, "made": "...",
     "psd": {"name", "size", "width", "height", "layers", "doc_id", "instance_id"},
     "agr": {"path", "name", "sha256"},                 # the AGR the content refs point into
     "pages":    [{"group": <layer id>, "name", "sheet", "how"}],
     "elements": [{"layer": <layer id>, "place": <n>, "page": <group id>, "kind": "text" | "symbol",
                   "owner": "data" | "review", "content": {...}, "fp": {...}}],
     "static": <text layers kept as design>}

Layers are keyed by their Photoshop layer ID (unique in files Photoshop wrote; the
place in the layer list is kept for files with repeated IDs). Each element carries a
fingerprint (kind, text hash, box, parent group, name) so a changed file is noticed:
validate() reports layers that are gone or replaced (the element can't be updated)
and layers whose text, place, group or name changed since (it can, after a look).

Content refs ("content") say what a text layer shows, in the binding's AGR:
    {"kind": "cells", "sheet": S, "cells": [[row, col], ...]}   one cell or a column / row of cells
    {"kind": "row",   "sheet": S, "rows": [row, ...]}            whole rows
    {"kind": "words", "sheet": S, "rows": [row, ...]}            a stretch of a sheet's prose
    {"kind": "paragraphs", "parts": [<one of the above>, ...]}   each paragraph its own
and for a symbol picture {"token": "<name>"}.

Bindings are stored per game on this PC (bindings/<game>/<psd>.json beside the games
registry); a PSD the tool writes also carries its own inside its XMP (psd_memory).
The artist's original PSD is never written.
"""
import datetime
import hashlib
import os
import re

SCHEMA = 1
BROKEN = ("missing", "replaced")                      # the element can't be updated any more
_DOC_ID = re.compile(rb'xmpMM:DocumentID(?:="|>)([^"<]+)')
_INSTANCE_ID = re.compile(rb'xmpMM:InstanceID(?:="|>)([^"<]+)')


# ── fingerprints ──────────────────────────────────────────────────────────────
def _text_hash(layer):
    try:
        text = str(layer.text or "")
    except Exception:
        return ""
    return hashlib.sha1(text.rstrip("\r").encode("utf-8")).hexdigest()[:12]


def fingerprint(layer):
    """What a bound layer looked like: changes to it are told apart by validate()."""
    rec = layer._record
    parent = getattr(layer, "parent", None)
    fp = {"kind": layer.kind, "box": [rec.left, rec.top, rec.right, rec.bottom],
          "parent": getattr(parent, "layer_id", None) if parent is not None and parent.kind != "psdimage" else None,
          "name": layer.name}
    if layer.kind == "type":
        fp["text"] = _text_hash(layer)
    return fp


# ── identity ──────────────────────────────────────────────────────────────────
def _record_xmp(psd_record):
    from psd_tools.constants import Resource

    res = psd_record.image_resources
    return res[Resource.XMP_METADATA].data if Resource.XMP_METADATA in res else b""


def _ids(xmp):
    doc, inst = _DOC_ID.search(xmp or b""), _INSTANCE_ID.search(xmp or b"")
    return (doc.group(1).decode("ascii", "replace") if doc else "",
            inst.group(1).decode("ascii", "replace") if inst else "")


def identity(psd, psd_path=""):
    """Which file a binding belongs to: name, size, canvas, layer count and Photoshop's own
    document IDs (the DocumentID stays the same through Save As; the InstanceID changes on save)."""
    doc_id, inst = _ids(_record_xmp(psd._record))
    return {"name": os.path.basename(psd_path) if psd_path else "",
            "size": os.path.getsize(psd_path) if psd_path and os.path.isfile(psd_path) else None,
            "width": psd.width, "height": psd.height, "layers": sum(1 for _ in psd.descendants()),
            "doc_id": doc_id, "instance_id": inst}


def _agr(path):
    if not path:
        return {}
    from . import project_package

    return {"path": os.path.abspath(path), "name": os.path.basename(path),
            "sha256": project_package.file_sha256(path) if os.path.isfile(path) else ""}


# ── making one ────────────────────────────────────────────────────────────────
def _side(content, side):
    """A plan item's content ({"kind", "a", "b"} from market_clone._content) as one workbook sees it."""
    if not content:
        return None
    if content["kind"] == "paragraphs":
        parts = [_side(p, side) for p in content.get("parts") or []]
        parts = [p for p in parts if p]
        return {"kind": "paragraphs", "parts": parts} if parts else None
    ref = content.get(side)
    return dict(ref, kind=content["kind"]) if ref else None


def make(psd, the_plan, psd_path="", agr_path="", side="a"):
    """The binding of `psd` from a clone plan made on it. `side` "a": the content refs point into
    the AGR the plan read the PSD with (the artist's PSD and its own AGR); "b": into the new AGR
    (the PSD the clone writes)."""
    from .artist_design import psd_render

    tops = psd_render.page_tops(psd)                  # (pages in a group of pages count as pages)
    page_ids = {t.layer_id for t in tops if t.is_group()}
    layers = list(psd.descendants())
    by_id, repeated = {}, set()
    for n, layer in enumerate(layers):
        if layer.layer_id in by_id:
            repeated.add(layer.layer_id)
        by_id.setdefault(layer.layer_id, (n, layer))
    view_b = the_plan.get("_sheets_b") or {}

    def lookup(lid, place):
        """(place, layer): by ID; in a file whose IDs repeat (written without Photoshop), by place."""
        if lid not in repeated:
            return by_id.get(lid)
        if place is not None and 0 <= place < len(layers) and layers[place].layer_id == lid:
            return place, layers[place]
        return None

    def sheet_name(name):
        if side == "a" or not name:
            return name or ""
        got = view_b.get(name)
        return got.name if got is not None else ""

    def group_of(layer):
        top = layer
        while getattr(top, "parent", None) is not None and top.parent.kind != "psdimage" and top.layer_id not in page_ids:
            top = top.parent                          # up to its page (or its top-level group)
        return top.layer_id if top is not layer or layer.is_group() else None

    pages = []
    for p in the_plan.get("page_links") or []:
        if str(p.get("page_key")).isdigit() and int(p["page_key"]) < len(tops):
            g = tops[int(p["page_key"])]
            pages.append({"group": g.layer_id, "name": p.get("page") or g.name, "sheet": sheet_name(p.get("sheet")),
                          "how": p.get("how") or ""})
    elements, static = [], 0
    for item in the_plan.get("items") or []:
        status = item.get("status")
        if status in ("design", "empty"):
            static += status == "design"
            continue
        found = lookup(item.get("layer_id"), item.get("place"))
        if found is None:
            continue
        n, layer = found
        content = _side(item.get("content"), side)
        # on the written side a layer whose new text was not put in (a page the artist kept, a change
        # left to the artist) still shows the old AGR: it waits for a look instead of claiming the new
        stale = side == "b" and status in ("kept", "artist", "missing")
        owner = "data" if content and status != "ambiguous" and not stale else "review"
        elements.append({"layer": layer.layer_id, "place": n, "page": group_of(layer), "kind": "text",
                         "owner": owner, "content": content, "source": item.get("source") or "",
                         "fp": fingerprint(layer)})
    for sym in the_plan.get("symbol_layers") or []:
        found = lookup(sym["layer"], sym.get("place"))
        if found is not None:
            n, layer = found
            elements.append({"layer": layer.layer_id, "place": n, "page": group_of(layer), "kind": "symbol",
                             "owner": "data", "content": {"token": sym["token"]}, "fp": fingerprint(layer)})
    return {"schema": SCHEMA, "made": datetime.datetime.now().isoformat(timespec="seconds"),
            "psd": identity(psd, psd_path), "agr": _agr(agr_path), "pages": pages, "elements": elements,
            "static": static}


def follow(binding, idmap, psd_path):
    """A binding made on the PSD in memory, made true of the file Photoshop saved from the same
    ops: copied layers take the IDs Photoshop gave them (`idmap`: {planned ID: Photoshop's}), and
    every element's place and fingerprint is read again from the file (Photoshop lays text out
    itself). Elements whose layers Photoshop didn't make are dropped ("dropped": how many)."""
    from .artist_design import psd_reader

    psd = psd_reader.open_lazy(psd_path)
    layers = list(psd.descendants())
    by_id = {l.layer_id: (n, l) for n, l in enumerate(layers)}

    def ps_id(lid):
        return idmap.get(str(lid), lid) if lid is not None else None

    pages = []
    for page in binding.get("pages") or []:
        page["group"] = ps_id(page.get("group"))
        if page["group"] in by_id:                   # a page made in memory only (a Continued page) goes
            pages.append(page)
    binding["pages"] = pages
    kept = []
    for e in binding.get("elements") or []:
        found = by_id.get(ps_id(e["layer"]))
        if found is None:
            continue
        n, layer = found
        e.update(layer=layer.layer_id, place=n, page=ps_id(e.get("page")), fp=fingerprint(layer))
        kept.append(e)
    binding["dropped"] = len(binding.get("elements") or []) - len(kept)
    binding["elements"] = kept
    binding["psd"] = identity(psd, psd_path)
    return binding


# ── checking one against a file ───────────────────────────────────────────────
def validate(binding, psd):
    """Is `binding` still right for `psd` (a PSDImage, or a path)? Returns {"ok", "checked",
    "problems": [{"layer", "kind", "issue", "content"/"page"}], "counts": {issue: n}}. "ok" is False
    only when a bound layer is gone or is another kind of layer now (BROKEN); text, place, group and
    name changes are reported but the element can still be updated."""
    if isinstance(psd, str):
        from .artist_design import psd_reader

        psd = psd_reader.open_lazy(psd)
    layers = list(psd.descendants())
    by_id, repeated = {}, set()
    for n, layer in enumerate(layers):
        if layer.layer_id in by_id:
            repeated.add(layer.layer_id)
        by_id.setdefault(layer.layer_id, layer)
    problems = []

    def find(lid, place):
        if lid in repeated:                           # IDs repeat in this file: the one at its place
            got = layers[place] if place is not None and 0 <= place < len(layers) else None
            return got if got is not None and got.layer_id == lid else None
        return by_id.get(lid)

    for page in binding.get("pages") or []:
        if page.get("group") not in by_id:
            problems.append({"layer": page.get("group"), "kind": "page", "issue": "missing", "page": page.get("name")})
    for e in binding.get("elements") or []:
        layer = find(e.get("layer"), e.get("place"))
        note = {"layer": e.get("layer"), "kind": e.get("kind"), "content": e.get("content")}
        if layer is None:
            problems.append(dict(note, issue="missing"))
            continue
        now, then = fingerprint(layer), e.get("fp") or {}
        if now["kind"] != then.get("kind"):
            problems.append(dict(note, issue="replaced", was=then.get("kind"), now=now["kind"]))
            continue
        if then.get("text") and now.get("text") != then["text"]:
            problems.append(dict(note, issue="text_changed"))
        if then.get("box") and now["box"] != then["box"]:
            problems.append(dict(note, issue="moved", was=then["box"], now=now["box"]))
        if "parent" in then and now["parent"] != then["parent"]:
            problems.append(dict(note, issue="regrouped"))
        if then.get("name") is not None and now["name"] != then["name"]:
            problems.append(dict(note, issue="renamed", was=then["name"], now=now["name"]))
    counts = {}
    for p in problems:
        counts[p["issue"]] = counts.get(p["issue"], 0) + 1
    return {"ok": not any(p["issue"] in BROKEN for p in problems),
            "checked": len(binding.get("elements") or []) + len(binding.get("pages") or []),
            "problems": problems, "counts": counts}


def summary(binding):
    """Counts for the UI: pages, bound text layers, symbols, layers waiting for a look, kept as design."""
    els = binding.get("elements") or []
    return {"made": binding.get("made") or "", "agr": (binding.get("agr") or {}).get("name") or "",
            "pages": sum(1 for p in binding.get("pages") or [] if p.get("sheet")),
            "texts": sum(1 for e in els if e["kind"] == "text" and e["owner"] == "data"),
            "symbols": sum(1 for e in els if e["kind"] == "symbol"),
            "review": sum(1 for e in els if e["owner"] == "review"), "static": binding.get("static") or 0}


# ── storing ───────────────────────────────────────────────────────────────────
def key_of(psd_path):
    """A PSD's binding is found by its file name (the same file copied elsewhere is the same design)."""
    return os.path.basename(str(psd_path or "")).casefold()


def store_dir(game_id=None):
    from . import games

    return os.path.join(games._store_dir(), "bindings", re.sub(r"[^\w.-]+", "_", game_id or "") or "_no_game")


def path_for(psd_path, game_id=None):
    stem = re.sub(r"[^\w.-]+", "_", os.path.splitext(key_of(psd_path))[0])[:60]
    tag = hashlib.sha1(key_of(psd_path).encode("utf-8")).hexdigest()[:8]
    return os.path.join(store_dir(game_id), f"{stem}_{tag}.json")


def save(binding, psd_path, game_id=None):
    """Keep `binding` for the PSD at `psd_path` with the game (or with no game); returns the file."""
    from .safe_json import write_json

    path = path_for(psd_path, game_id)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    write_json(path, dict(binding, key=key_of(psd_path)))
    return path


def load(psd_path, game_id=None):
    """The binding kept for this PSD, or None."""
    from .safe_json import read_json_recover

    path = path_for(psd_path, game_id)
    if not os.path.isfile(path):
        return None
    try:
        data, _note = read_json_recover(path)
    except Exception:
        return None
    return data if isinstance(data, dict) and data.get("schema") == SCHEMA else None


# ── inside a PSD the tool writes ──────────────────────────────────────────────
def embed(psd_record, binding):
    """Put `binding` into a PSD's own memory (XMP) before it is written; anything else the memory
    holds (a tool-made PSD's project) is kept."""
    from . import psd_memory

    found = psd_memory._MEMORY_RE.search(_record_xmp(psd_record))
    mem = None
    if found:
        try:
            mem = psd_memory._unpack(found.group(1).decode("ascii"))
        except Exception:
            mem = None
    mem = mem if isinstance(mem, dict) else {"schema": psd_memory.SCHEMA, "tool": "PsHelpScreenTool"}
    mem["binding"] = binding
    psd_memory.attach(psd_record, mem)


def read_embedded(psd_path):
    """The binding a PSD carries in its XMP, or None (reads only the file's header part)."""
    from . import psd_memory

    got = (psd_memory.read(psd_path) or {}).get("binding")
    return got if isinstance(got, dict) else None


def find(psd_path, game_id=None):
    """The binding for a PSD: the one it carries, else the one kept with the game."""
    return read_embedded(psd_path) or load(psd_path, game_id)
