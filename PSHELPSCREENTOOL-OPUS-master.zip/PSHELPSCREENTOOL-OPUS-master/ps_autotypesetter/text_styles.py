"""Word styles and line strips: artist rules applied to Excel text everywhere.

Rules live in ``dynamic_settings["text_style_rules"]`` (a list) and match TEXT,
never character positions, so they survive Excel revisions and carry across
the markets of a game:

  word  {"kind": "word", "text": "Extra", "whole_word": True, "case": False,
         "color": "#FF3030", "bold": True, "italic": False, "font": "",
         "size": 120 (percent of the text's size), "fx": "<layer style name>",
         "scope": "game" | "page", "sheet": "<sheet name when scope=page>"}

       scope "starts": every row (on every page) whose first words are ``starts`` (``"prizes displayed
       during bought games"``, all of them, case and spacing ignored) — the rule's ``text`` in it, or
       the whole row when ``whole_row`` (the artist styled a whole row: rows that differ later, a
       number say, get it too).

  strip {"kind": "strip", "text": "Note:", "match": "starts" | "contains" | "exact",
         "case": False, "color": "#1E3A8A", "opacity": 0.85,
         "pad_x": 24, "pad_y": 6, "full_width": True, "width_pct": 100, "radius": 6,
         "text_color": "#FFFFFF" | "", "scope": ..., "sheet": ...}

  a strip's look (strip rules as named here; a word rule's strip the same keys with "bg_" in front:
  bg_radius, bg_radii, bg_border, bg_fx):
         "radius": 6, "radii": [tl, tr, br, bl] (each corner its own, over radius),
         "border": {"width": 2, "color": "#FFFFFF", "opacity": 100, "align": "inside"|"center"|"outside"},
         "fx": "<layer style name>"
  Every strip is drawn as a live Photoshop rounded rectangle (paytable_box), its opacity the layer's Fill.

The active rules (and the sheet being drawn) are held in a context variable
set by the build / preview, so every renderer that draws text through
png_builder._draw_inline picks them up without extra plumbing.
"""
import contextlib
import contextvars
import functools
import re

_ACTIVE = contextvars.ContextVar("text_style_rules", default=None)   # (rules, sheet_name)
_LIBRARY = contextvars.ContextVar("layer_style_library", default=None)  # the game's layer styles, by name


_ROW = contextvars.ContextVar("text_style_row", default="")   # the Excel row being drawn (its text)


def _untag(text):
    """Row text without icon size tags (icon_scales): sizing an icon never loses its row's strip / styles."""
    from .text_edits import _untag as untag

    return untag(text)


def _row_key(text):
    return " ".join(_untag(text).split()).casefold()


@contextlib.contextmanager
def row(row_text):
    """Drawing (or measuring) the text of one Excel row: rules made for just that row apply."""
    token = _ROW.set(_row_key(row_text))
    token_text = _ROW_TEXT.set(_untag(row_text))
    try:
        yield
    finally:
        _ROW_TEXT.reset(token_text)
        _ROW.reset(token)


# ── one exact occurrence ("nth") ─────────────────────────────────────────────
# A rule with "nth" styles only the nth place its text appears in its row (the
# characters the artist selected), not every copy. Rows are drawn in pieces
# (between icons, line by line), so each piece is found in its row by its
# "skeleton": the row's characters without spaces and <ICON> tokens, lower-cased.
# Wrapping and spacing never change the skeleton, so the piece lands on the same
# place however the row is laid out. Mirrored by visualiser_live.js (skel/nthRuns).
_ROW_TEXT = contextvars.ContextVar("text_style_row_text", default="")
_WITHIN = contextvars.ContextVar("text_style_within", default=None)   # (enclosing piece, offset of this one in it)
_TOKEN_RE = re.compile(r"<[^<>]*>")


def _lower1(c):
    low = c.lower()
    return low if len(low) == 1 else c


def skeleton(text):
    """(skeleton, index): the characters that count, and where each one is in `text`."""
    return _skeleton(str(text or ""))


@functools.lru_cache(maxsize=8192)
def _skeleton(text):
    # one row's text is measured word by word while laying out: worked out once per text (index is a tuple)
    hidden = [False] * len(text)
    for m in _TOKEN_RE.finditer(text):
        for i in range(m.start(), m.end()):
            hidden[i] = True
    chars, index = [], []
    for i, c in enumerate(text):
        if not hidden[i] and not c.isspace():
            chars.append(_lower1(c))
            index.append(i)
    return "".join(chars), tuple(index)


def occurrences(haystack, needle):
    """Every start of `needle` in `haystack`, overlapping ones too (the editor counts the same way)."""
    out, i = [], haystack.find(needle) if needle else -1
    while i >= 0:
        out.append(i)
        i = haystack.find(needle, i + 1)
    return out


def nth_of(row_text, start, end):
    """For characters [start, end) of `row_text`: (text, nth) of a rule that styles exactly them."""
    text = str(row_text or "")[start:end]
    row_sk, row_ix = skeleton(row_text)
    want, _ = skeleton(text)
    if not want:
        return text, 0
    first = next((k for k, i in enumerate(row_ix) if i >= start), len(row_ix))
    return text, sum(1 for s in occurrences(row_sk, want) if s < first)


@contextlib.contextmanager
def within(piece, offset):
    """Drawing a part of `piece` that starts `offset` characters into it (a justified line, word by word)."""
    token = _WITHIN.set((str(piece or ""), int(offset)))
    try:
        yield
    finally:
        _WITHIN.reset(token)


class RowText(str):
    """A line or piece of a row's text that remembers where it was cut from (`src`, `src_off`):
    the same words can be in a row several times (" with one or more " after every icon), and only
    the place tells which copy a selection's style belongs to. Behaves as a plain str everywhere."""


def cut(src, offset, text):
    """`text`, cut from `src` starting `offset` characters into it (png_builder wrapping / icon split)."""
    piece = RowText(text)
    piece.src, piece.src_off = src, int(offset)
    return piece


def place_key(text):
    """Part of a cache key: where `text` was cut from, when a selection's style could depend on it."""
    if not any(r.get("nth") is not None for r in _rules("word")):
        return ()
    out, t = [], text
    while getattr(t, "src", None) is not None:
        out.append(t.src_off)
        t = t.src
    return tuple(out)


def _full_skeleton(text):
    """Skeleton keeping the icon tokens (untagged): which line of a row this is — "<greenbag>" tells."""
    text = _untag(text)
    inside = [False] * len(text)
    for m in _TOKEN_RE.finditer(text):
        for i in range(m.start(), m.end()):
            inside[i] = True
    chars, flags = [], []
    for i, c in enumerate(text):
        if not c.isspace():
            chars.append(_lower1(c))
            flags.append(inside[i])
    return "".join(chars), flags


def _place(text, row_sk):
    """Where `text` starts in the row's (token-less) skeleton: through what it was cut from, else
    found in the row with its icon tokens (lines are unique by their icons), else None."""
    src = getattr(text, "src", None)
    if src is not None:
        base = _place(src, row_sk)
        if base is not None:
            return base + len(skeleton(str(src)[:text.src_off])[0])
    sk, _ = skeleton(text)
    if sk and sk == row_sk:
        return 0                                      # the row itself
    full, _flags = _full_skeleton(text)
    row_full, row_flags = _full_skeleton(_ROW_TEXT.get())
    hits = occurrences(row_full, full) if full else []
    if len(hits) == 1 or (hits and not any(_flags)):
        return sum(1 for f in row_flags[:hits[0]] if not f)
    return None


def _piece_start(row_sk, text):
    """Where `text` (a piece being drawn) starts in the row's skeleton, or None."""
    sk, _ = skeleton(text)
    if not sk:
        return None
    at = _place(text, row_sk) if getattr(text, "src", None) is not None else None
    if at is not None and row_sk[at:at + len(sk)] == sk:
        return at
    hint = _WITHIN.get()
    if hint and hint[0]:
        outer, off = hint
        outer_sk, outer_ix = skeleton(outer)
        found = occurrences(row_sk, outer_sk)
        if found:
            before = sum(1 for i in outer_ix if i < off)
            if outer_sk[before:before + len(sk)] == sk:
                return found[0] + before
    found = occurrences(row_sk, sk)
    return found[0] if found else None


def _nth_marks(text, rules):
    """{character index of `text`: [what each rule sets, in rule order]} for the rules with "nth" here."""
    row_text = _ROW_TEXT.get()
    if not rules or not row_text:
        return {}
    row_sk, _ = skeleton(row_text)
    start = _piece_start(row_sk, text)
    if start is None:
        return {}
    sk, ix = skeleton(text)
    marks = {}
    for rule in rules:
        want, _ = skeleton(rule.get("text"))
        hits = occurrences(row_sk, want)
        try:
            n = int(rule.get("nth"))
        except (TypeError, ValueError):
            continue
        if not want or not 0 <= n < len(hits):
            continue                                  # the text changed: that occurrence is gone
        a, b = max(hits[n], start), min(hits[n] + len(want), start + len(sk))
        if a >= b:
            continue
        first, last = ix[a - start], ix[b - 1 - start]
        props = _props(rule)
        for i in range(first, last + 1):              # the spaces between its characters too
            marks.setdefault(i, []).append(props)
    return marks


def library():
    """The layer-style library of the build / preview being drawn (tables look styles up here)."""
    return _LIBRARY.get() or {}


def normalize_rules(rules, library=None):
    """Valid rules; a word's layer style (by name) is looked up in `library` once, here."""
    out = []
    for r in rules or []:
        if not isinstance(r, dict) or not str(r.get("text") or "").strip():
            continue
        kind = str(r.get("kind") or "word").casefold()
        if kind not in ("word", "strip"):
            continue
        rule = dict(r, kind=kind)
        # a word's layer style; a strip rule's ("fx") or a word strip's ("bg_fx") for the strip itself
        for key, to in (("fx", "_fx"), ("bg_fx", "_bg_fx")) if kind == "word" else (("fx", "_fx"),):
            style = _enrich(library, r.get(key))
            if style is not None:
                rule[to] = style
        out.append(rule)
    return out


def _enrich(library, name):
    name = str(name or "").strip()
    if not name or not isinstance(library, dict) or not isinstance(library.get(name), dict):
        return None
    try:
        from .fx_descriptor import enrich_style

        return enrich_style(library[name])
    except Exception:
        return dict(library[name])


@contextlib.contextmanager
def active(rules, sheet_name="", library=None):
    """Apply `rules` to everything drawn inside the block (sheet-scoped rules
    only on `sheet_name`)."""
    if isinstance(library, dict):
        _LIBRARY.set(library)
    token = _ACTIVE.set((normalize_rules(rules, library), str(sheet_name or "")))
    try:
        yield
    finally:
        _ACTIVE.reset(token)


@contextlib.contextmanager
def sheet(sheet_name):
    """Same rules, now drawing `sheet_name`."""
    cur = _ACTIVE.get()
    if cur is None:
        yield
        return
    token = _ACTIVE.set((cur[0], str(sheet_name or "")))
    try:
        yield
    finally:
        _ACTIVE.reset(token)


def begin(rules, library=None):
    """Turn rules on for the rest of this build (pair with end(token))."""
    if isinstance(library, dict):
        _LIBRARY.set(library)
    return _ACTIVE.set((normalize_rules(rules, library), ""))


def end(token):
    _ACTIVE.reset(token)


def set_sheet(sheet_name):
    """Within an active build: the sheet now being drawn."""
    cur = _ACTIVE.get()
    if cur is not None:
        _ACTIVE.set((cur[0], str(sheet_name or "")))


def _rules(kind):
    cur = _ACTIVE.get()
    if not cur:
        return []
    rules, sheet_name = cur
    out = []
    for r in rules:
        if r["kind"] != kind:
            continue
        scope = str(r.get("scope") or "game").casefold()
        if scope in ("page", "row"):
            if str(r.get("sheet") or "").strip().casefold() != sheet_name.strip().casefold():
                continue
        if scope == "row" and _row_key(r.get("row_text")) != _ROW.get():
            continue                                  # made for one line of text, not this one
        if scope == "starts" and not starts_with(_ROW.get(), r.get("starts")):
            continue                                  # rows starting with other words
        out.append(r)
    return out


_NUMBER = re.compile(r"^[$€£]?\d[\d,.]*[%x]?[,.:;]?$")


def starts_with(row_key, starts):
    """True when the row (its _row_key) begins with every one of the words of `starts` — a number
    standing for any number (the same sentence on each denomination's page: "5 or more", "25 or more")."""
    want = str(starts or "").casefold().split()
    have = str(row_key or "").split()[:len(want)]
    return bool(want) and len(have) == len(want) and all(
        a == b or (_NUMBER.match(a) and _NUMBER.match(b)) for a, b in zip(have, want))


def has_word_rules():
    return bool(_rules("word"))


def _hex_rgb(value):
    v = str(value or "").strip().lstrip("#")
    if len(v) == 3:
        v = "".join(c * 2 for c in v)
    try:
        return tuple(int(v[i:i + 2], 16) for i in (0, 2, 4))
    except (ValueError, IndexError):
        return None


def _word_pattern(rule):
    text = str(rule.get("text") or "").strip()
    body = re.escape(text).replace(r"\ ", r"\s+")
    if rule.get("whole_word", True):
        body = r"(?<![^\W_])" + body + r"(?![^\W_])"
    return re.compile(body, 0 if rule.get("case") else re.IGNORECASE)


_EMPTY_STYLE = {"rgb": None, "bold": False, "italic": False, "font": "", "size": None,
                "fx": "", "fx_config": None, "tracking": None, "bg": None}


def _props(rule):
    """Only what a word rule sets (a selection keeps every other property of its text)."""
    p = {}
    rgb = _hex_rgb(rule.get("color"))
    if rgb:
        p["rgb"] = rgb
    if rule.get("bold"):
        p["bold"] = True
    if rule.get("italic"):
        p["italic"] = True
    font = str(rule.get("font") or "").strip()
    if font:
        p["font"] = font
    try:
        size = float(rule.get("size") or 0)
    except (TypeError, ValueError):
        size = 0.0
    cur = _ACTIVE.get()
    # pages whose paragraph was given one size for all its text: the rule's size is not theirs
    off = {str(s).strip().casefold() for s in (rule.get("size_off") or [])}
    if size > 0 and abs(size - 100) > 0.5 and not (cur and cur[1].strip().casefold() in off):
        p["size"] = size
    fx = str(rule.get("fx") or "").strip()
    if fx:
        p["fx"], p["fx_config"] = fx, rule.get("_fx")
    if rule.get("tracking") not in (None, ""):
        try:
            p["tracking"] = max(-200.0, min(1000.0, float(rule.get("tracking"))))
        except (TypeError, ValueError):
            pass
    bg = bg_of(rule)
    if bg:
        p["bg"] = bg
    return p


def bg_of(rule):
    """A strip behind just these characters: {"rgba", "pad_x", "pad_y", "radius"} or None."""
    rgb = _hex_rgb(rule.get("bg"))
    if not rgb:
        return None

    def num(key, default, lo, hi):
        try:
            return max(lo, min(hi, float(rule.get(key, default))))
        except (TypeError, ValueError):
            return default

    alpha = num("bg_opacity", 1.0, 0.0, 1.0)
    return dict(strip_look(rule, "bg_", 4), rgba=rgb + (int(round(alpha * 255)),), pad_x=num("bg_pad_x", 6, 0, 200),
                pad_y=num("bg_pad_y", 2, -100, 200))


def strip_look(rule, prefix="", radius=6):
    """A strip's corners, border and layer style, as draw_strip takes them: {"radius", "radii",
    "border", "fx", "_fx"} — read from a strip rule, or (prefix "bg_") a word rule's strip."""
    def num(v, default, lo, hi):
        try:
            return max(lo, min(hi, float(v)))
        except (TypeError, ValueError):
            return default

    rule = rule or {}
    out = {"radius": num(rule.get(prefix + "radius", radius), radius, 0, 2000)}
    radii = rule.get(prefix + "radii")
    if isinstance(radii, (list, tuple)) and len(radii) == 4:
        out["radii"] = [num(v, out["radius"], 0, 2000) for v in radii]
    border = rule.get(prefix + "border")
    if isinstance(border, dict) and num(border.get("width"), 0, 0, 200) > 0:
        align = str(border.get("align") or "inside").lower()
        out["border"] = {"width": num(border.get("width"), 0, 0, 200), "color": border.get("color") or "#ffffff",
                         "opacity": num(border.get("opacity", 100), 100, 0, 100),
                         "align": align if align in ("inside", "center", "outside") else "inside"}
    # a card look on it (pasted from a paytable card, or picked from the card looks): corner shapes and a
    # gradient into a second colour, as the paytable's cards draw them
    corners = rule.get(prefix + "corners")
    if isinstance(corners, (list, tuple)) and len(corners) == 4:
        out["corners"] = [str(v) for v in corners]
    elif rule.get(prefix + "corner") and rule.get(prefix + "corner") != "round":
        out["corner"] = str(rule[prefix + "corner"])
    if rule.get(prefix + "fill_to") and rule.get(prefix + "gradient_dir") != "none":
        out["fill_to"] = _mix_hex(rule.get(prefix + "color") or rule.get("bg" if prefix else "color"),
                                  rule[prefix + "fill_to"], rule.get(prefix + "gradient_amount", 100))
        out["gradient_dir"] = str(rule.get(prefix + "gradient_dir") or "vertical")
    fx = rule.get(prefix + "fx")
    if isinstance(fx, dict):                          # its own layer style (a card look's glow, shadow…)
        out["fx"], out["_fx"] = "inline", fx
        return out
    name = str(fx or "").strip()
    if name:
        out["fx"] = name
        style = rule.get("_bg_fx" if prefix else "_fx")
        if not isinstance(style, dict):               # a heading plate's library style: resolved for the Canvas too
            try:
                style = _enrich(library(), name)
            except Exception:
                style = None
        if isinstance(style, dict):
            out["_fx"] = style
    return out


def _mix_hex(a, b, pct):
    """#RRGGBB: colour b taken pct % of the way from colour a (a gradient's strength); b when a isn't one."""
    try:
        k = max(0.0, min(1.0, float(100 if pct in (None, "") else pct) / 100.0))
        ca, cb = (tuple(int(str(c).lstrip("#")[i:i + 2], 16) for i in (0, 2, 4)) for c in (a, b))
    except (TypeError, ValueError):
        return str(b)
    return "#%02X%02X%02X" % tuple(int(round(x + (y - x) * k)) for x, y in zip(ca, cb))


def style_of(rule):
    """The visual style a word rule applies: {"rgb", "bold", "italic", "font", "size", "fx", "fx_config",
    "tracking", "bg"} (size: percent of the surrounding text, None = same; fx_config: its own layer
    style; tracking: 1/1000 em, None = the text's own; bg: a strip behind these characters)."""
    return dict(_EMPTY_STYLE, **_props(rule))


def word_runs(text):
    """[(segment, style | None)] for `text`; style is None where no rule matches.

    Longer rule texts win where matches overlap ("Extra Spins" over "Extra"). Rules for one exact
    occurrence ("nth", a selection) then add what they set on top, the later rule last.
    """
    text = text if isinstance(text, str) else str(text or "")   # keep a RowText: where it is in its row
    every = _rules("word")
    if not every or not text.strip():
        return [(text, None)]
    exact = [r for r in every if r.get("nth") is not None]
    rules = sorted((r for r in every if r.get("nth") is None), key=lambda r: -len(str(r.get("text") or "")))
    taken = [None] * len(text)
    for rule in rules:
        st = style_of(rule)
        if rule.get("whole_row"):                     # the whole row (scope "starts")
            for i in range(len(text)):
                if taken[i] is None and not text[i].isspace():
                    taken[i] = st
            for i in range(1, len(text) - 1):         # its spaces too, between styled characters
                if text[i].isspace() and taken[i - 1] is st and any(taken[j] is st for j in range(i + 1, len(text)) if not text[j].isspace()):
                    taken[i] = st
            continue
        for m in _word_pattern(rule).finditer(text):
            if all(taken[i] is None for i in range(m.start(), m.end())):
                for i in range(m.start(), m.end()):
                    taken[i] = st
    merged = {}                                       # one style object per look, so equal runs join
    for i, layers in _nth_marks(text, exact).items():
        key = (id(taken[i]),) + tuple(id(p) for p in layers)
        if key not in merged:
            st = dict(taken[i] or _EMPTY_STYLE)
            for props in layers:
                st.update(props)
            merged[key] = st
        taken[i] = merged[key]
    runs, start = [], 0
    for i in range(1, len(text) + 1):
        if i == len(text) or taken[i] is not taken[start]:
            runs.append((text[start:i], taken[start]))
            start = i
    return runs


def strip_for(text):
    """The strip rule whose match fits this line / Excel row text, or None."""
    t = " ".join(_untag(text).split())
    if not t:
        return None
    for rule in _rules("strip"):
        want = " ".join(_untag(rule.get("text")).split())
        a, b = (t, want) if rule.get("case") else (t.casefold(), want.casefold())
        how = str(rule.get("match") or "starts").casefold()
        if (how == "exact" and a == b) or (how == "contains" and b in a) or (how == "starts" and a.startswith(b)):
            return rule
    return None


def strip_geometry(rule, x, y, w, h, text_left=None, text_right=None):
    """(left, top, width, height) of the strip behind a block at (x, y, w, h).

    Full width spans the text box, narrowed to ``width_pct`` percent of it
    (kept centred); otherwise it hugs the text ink extents plus ``pad_x``.
    ``pad_y`` is the strip's extra height above and below the text — below 0 it is thinner than the
    text, down to no height at all (it stays centred on the text and follows it when an icon grows).
    """
    pads = rule.get("pads")
    if isinstance(pads, (list, tuple)) and len(pads) == 4:
        # its own margin on each side of the text (a plate sized by hand: any size — below 0 a side is inside
        # the text), so it keeps to its heading when the words change
        try:
            pl, pt, pr, pb = (float(v or 0) for v in pads)
            fit = not rule.get("full_width", True) and text_left is not None and text_right is not None
            left, right = ((text_left, text_right) if fit else (x, x + w))
            left, right, top, bottom = left - pl, right + pr, y - pt, y + h + pb
            return left, top, max(1.0, right - left), max(1.0, bottom - top)
        except (TypeError, ValueError):
            pass
    pad_x = float(rule.get("pad_x", 24) or 0)
    pad_y = float(rule.get("pad_y", 6) or 0)
    if rule.get("full_width", True) or text_left is None or text_right is None:
        left, right = x - pad_x, x + w + pad_x
        try:
            pct = max(5.0, min(100.0, float(rule.get("width_pct", 100) or 100)))
        except (TypeError, ValueError):
            pct = 100.0
        if pct < 100.0:
            mid, half = (left + right) / 2.0, (right - left) * pct / 200.0
            left, right = mid - half, mid + half
    else:
        left, right = text_left - pad_x, text_right + pad_x
    height = max(0.0, h + 2 * pad_y)
    return left, y + (h - height) / 2.0, right - left, height


def strip_rgba(rule):
    rgb = _hex_rgb(rule.get("color")) or (30, 58, 138)
    try:
        alpha = max(0.0, min(1.0, float(rule.get("opacity", 0.85))))
    except (TypeError, ValueError):
        alpha = 0.85
    return rgb + (int(round(alpha * 255)),)


def strip_text_rgb(rule):
    return _hex_rgb(rule.get("text_color"))


def draw_strip(base, rule, box, group=None):
    """Paint the strip — or record it under the text as a live Photoshop rounded rectangle, its
    opacity the layer's Fill, with its border and layer style (paytable_box draws both the same)."""
    from . import paytable_box

    left, top, width, height = (float(v) for v in box)
    if width < 1 or height < 1:
        return
    look = strip_look(rule, "", float(rule.get("radius", 6) or 0))
    border = look.get("border")
    shape = {"radius": look["radius"], "fill": "#%02x%02x%02x" % strip_rgba(rule)[:3],
             "fill_opacity": strip_rgba(rule)[3] / 2.55,
             "stroke": dict(border, enabled=True) if border else {"enabled": False}}
    if look.get("radii"):
        shape["radii"] = look["radii"]
    for k in ("corner", "corners", "fill_to", "gradient_dir"):      # a card look's shape and gradient
        if look.get(k):
            shape[k] = look[k]
    fx = look.get("_fx") if isinstance(look.get("_fx"), dict) else _enrich(library(), look.get("fx"))
    if fx:
        shape["fx"] = fx
    name = "strip · " + " ".join(str(rule.get("text") or "").split())[:40]
    paytable_box.draw(base, {"shape": shape}, round(left), round(top), round(width), round(height),
                      group=group, name=name)
