import json
from .config import DEFAULT_KEYWORDS


def _rgb_tuple(value, fallback=(255, 255, 255)):
    try:
        if isinstance(value, dict):
            value = value.get("rgb") or value.get("color") or value.get("value")
        rgb = tuple(int(v) for v in list(value)[:3])
        if len(rgb) == 3:
            return rgb
    except Exception:
        pass
    return tuple(fallback)


def _keyword_config(value):
    if isinstance(value, dict):
        return {
            "rgb": _rgb_tuple(value),
            "bold": bool(value.get("bold", False)),
            "exact": bool(value.get("exact", True)),
        }
    return {"rgb": _rgb_tuple(value), "bold": False, "exact": True}


def _keyword_boundary_ok(text, start, end, keyword):
    if not keyword:
        return False

    def is_word_char(ch):
        return ch.isalnum() or ch == "_"

    if keyword[0].isalnum() and start > 0 and is_word_char(text[start - 1]):
        return False
    if keyword[-1].isalnum() and end < len(text) and is_word_char(text[end]):
        return False
    return True


class KeywordManager:
    def __init__(self, initial=None):
        self.keywords = {}
        self.set_dict(initial or {})

    def add(self, text, rgb, bold=False):
        key = str(text or "").strip()
        if key:
            self.keywords[key] = {
                "rgb": _rgb_tuple(rgb),
                "bold": bool(bold),
                "exact": True,
            }

    def remove(self, text):
        wanted = str(text or "").strip()
        for key in list(self.keywords.keys()):
            if key == wanted or key.casefold() == wanted.casefold():
                del self.keywords[key]

    def get_dict(self):
        return {key: dict(value) for key, value in self.keywords.items()}

    def set_dict(self, data):
        self.keywords = {}
        for key, value in dict(data or {}).items():
            key_s = str(key or "").strip()
            if key_s:
                self.keywords[key_s] = _keyword_config(value)

    def to_json_dict(self):
        return {
            key: {
                "rgb": list(value.get("rgb") or (255, 255, 255)),
                "bold": bool(value.get("bold", False)),
                "exact": bool(value.get("exact", True)),
            }
            for key, value in self.keywords.items()
        }

    def save(self, path):
        if not path:
            return
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(self.to_json_dict(), f, indent=2)

    def load(self, path):
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        self.set_dict(data)

def get_colored_segments(text, keyword_colors=None):
    if keyword_colors is None:
        keyword_colors = DEFAULT_KEYWORDS
    if not text:
        return [(text, None)]

    segments = []
    remaining = text
    while remaining:
        best_match = None
        best_pos = len(remaining)
        remaining_folded = remaining.casefold()
        for keyword, color in keyword_colors.items():
            keyword = str(keyword or "")
            if not keyword:
                continue
            config = _keyword_config(color)
            search_pos = 0
            while True:
                pos = remaining_folded.find(keyword.casefold(), search_pos)
                if pos == -1:
                    break
                end = pos + len(keyword)
                if _keyword_boundary_ok(remaining, pos, end, keyword):
                    if pos < best_pos:
                        best_pos = pos
                        best_match = (keyword, config["rgb"], pos)
                    break
                search_pos = pos + 1
        if best_match is None:
            segments.append((remaining, None))
            break
        keyword, color, pos = best_match
        if pos > 0:
            segments.append((remaining[:pos], None))
        segments.append((remaining[pos:pos + len(keyword)], color))
        remaining = remaining[pos + len(keyword):]
    return segments
