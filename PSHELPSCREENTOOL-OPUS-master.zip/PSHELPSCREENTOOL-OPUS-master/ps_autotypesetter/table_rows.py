"""A table's rows and columns as the artist set them on the Canvas — table_style.table_rows[design key]:

    text: [row offset, …]                  rows that leave the table: drawn as normal text where they were
    rows: {row offset: "header" | "body"}  a row's role over what the tool decided
    cols: {column index: "header" | "body"} the same for a column

row offset = Excel row − the detected table's first row; column index = column − its first column. The
key is the table's design key (sheet + header text, as table_layouts / split_tables), taken from the table
as detected — before any of this — so the settings survive Excel edits and taking the top row out.

Nothing is deleted from the Excel. A row taken out of the middle of a table splits it: the rows above stay
the table (its key), the rows below are drawn as the next table ("<key>#1", same design and look). When
the header row is taken out the next row becomes the header. Every renderer reads the tables from
png_builder._prepare_tables, which calls apply() — the PNG / PSD build and the Canvas alike."""

ROLES = ("header", "body")


def spec_for(table_style, key):
    raw = ((table_style or {}).get("table_rows") or {}).get(str(key or ""))
    return raw if isinstance(raw, dict) else {}


def _ints(values):
    out = set()
    for v in values or []:
        try:
            out.add(int(v))
        except (TypeError, ValueError):
            pass
    return out


def _roles(raw):
    out = {}
    for k, v in (raw or {}).items() if isinstance(raw, dict) else []:
        try:
            if v in ROLES:
                out[int(k)] = v
        except (TypeError, ValueError):
            pass
    return out


def _row_text(cells, row):
    vals = [str(c.get("value") or "").strip() for c in sorted(cells, key=lambda c: int(c.get("col") or 0))
            if int(c.get("row")) == row and str(c.get("value") or "").strip()]
    return " ".join(vals)


def parent_key(key):
    """The table a lower piece belongs to ("<key>#1" → "<key>")."""
    k = str(key or "")
    head, sep, tail = k.rpartition("#")
    return head if sep and tail.isdigit() else k


def apply(table, spec):
    """The table as the artist set it: a list of tables (none when every row became text, more than one
    when a row in the middle became text). Each keeps rows_key / rows_start (where its settings live)
    and text_rows (its rows drawn as text) for the Canvas."""
    cells = [dict(c) for c in (table.get("grid_cells") or [])]
    key = table.get("design_key") or ""
    start, min_c = int(table.get("start_row") or 0), int(table.get("min_col") or 1)
    base = dict(table, rows_key=key, rows_start=start, text_rows=[])
    if not cells:
        return [base]
    text = {start + o for o in _ints((spec or {}).get("text"))}
    row_ov = {start + o: v for o, v in _roles((spec or {}).get("rows")).items()}
    col_ov = {min_c + o: v for o, v in _roles((spec or {}).get("cols")).items()}
    all_rows = sorted({int(c.get("row")) for c in cells})
    text &= set(all_rows)
    base["text_rows"] = [{"row": r, "off": r - start, "text": _row_text(cells, r)} for r in sorted(text)]
    if not text and not row_ov and not col_ov:
        return [base]
    kept = [c for c in cells if int(c.get("row")) not in text]
    if not kept:
        return []
    # pieces: a text row between two kept rows starts a new table
    groups, cur = [], []
    for r in sorted({int(c.get("row")) for c in kept}):
        if cur and any(t in text for t in range(cur[-1] + 1, r)):
            groups.append(cur)
            cur = []
        cur.append(r)
    groups.append(cur)
    auto_head = {int(r) for r in (table.get("header_row_indices") or [])}
    out = []
    for gi, rows in enumerate(groups):
        rset, last = set(rows), rows[-1]
        mine = []
        for c in kept:
            r = int(c.get("row"))
            if r not in rset:
                continue
            # a merge running into a text row (or past the piece) ends above it
            end = min(last, r + max(1, int(c.get("rowspan") or 1)) - 1)
            stop = min((t for t in text if r < t <= end), default=None)
            c["rowspan"] = max(1, (stop - 1 if stop else end) - r + 1)
            mine.append(c)
        head = auto_head & rset if gi == 0 else set()
        if gi == 0 and not head and auto_head and auto_head <= text:
            head = {rows[0]}                     # its header row became text: the next row is the header
        role_of = {r: row_ov.get(r) or ("header" if r in head else "body") for r in rows}
        lead = []                                # header rows at its top: repeated on each ✂ part
        for r in rows:
            if role_of[r] != "header":
                break
            lead.append(r)
        for c in mine:
            r, col = int(c.get("row")), int(c.get("col"))
            role = role_of[r]
            if col_ov.get(col) == "header":
                role = "header"
            elif col_ov.get(col) == "body" and row_ov.get(r) != "header":
                role = "body"
            c["role"] = role
        piece = dict(base, grid_cells=mine, start_row=rows[0], end_row=last, row_indices=list(range(rows[0], last + 1)),
                     header_row_indices=lead, header_row_idx=lead[0] if lead else rows[0], head_rows=lead,
                     row_roles={r: role_of.get(r, "body") for r in range(rows[0], last + 1)}, piece=gi)
        piece["data_rows"], piece["excel_row_map"] = [], []
        for r in rows:
            if r in lead:
                continue
            vals = {int(c.get("col")): c.get("value") for c in mine if int(c.get("row")) == r and c.get("value") not in (None, "")}
            if vals:
                piece["data_rows"].append(vals)
                piece["excel_row_map"].append(r)
        if gi:
            piece["design_key"] = f"{key}#{gi}"
        out.append(piece)
    return out


# layout settings that belong to one table's rows / boxes by their place: a lower piece doesn't take them
_PLACED = ("cells", "row_h", "height", "boxes")


def piece_layout(layouts, key):
    """A table's layout; a lower piece: its table's look (without what is set row by row / box by box)
    with what was set on the piece itself on top."""
    own = (layouts or {}).get(key)
    own = own if isinstance(own, dict) else {}
    lay = (layouts or {}).get(parent_key(key)) if parent_key(key) != key else None
    if not isinstance(lay, dict):
        return own
    out = {k: v for k, v in lay.items() if k not in _PLACED}
    boxes = {k: v for k, v in (lay.get("boxes") or {}).items() if not str(k).startswith("row:")}
    if boxes:
        out["boxes"] = boxes
    for k, v in own.items():
        out[k] = dict(out[k], **v) if isinstance(v, dict) and isinstance(out.get(k), dict) else v
    return out
