import colorsys
import re

# Excel's default Office theme (used when a workbook carries no theme of its own):
# lt1, dk1, lt2, dk2, accent1..6, hlink, folHlink — in the order Excel's theme indexes use
_OFFICE_THEME = ["FFFFFF", "000000", "E7E6E6", "44546A", "4472C4", "ED7D31", "A5A5A5", "FFC000",
                 "5B9BD5", "70AD47", "0563C1", "954F72"]
_THEME_CACHE = {}


def _theme_colours(workbook):
    """The workbook's theme colours by Excel's theme index (0 = lt1/window background …)."""
    key = id(workbook)
    hit = _THEME_CACHE.get(key)
    if hit is not None and hit[0] is workbook:
        return hit[1]
    colours = list(_OFFICE_THEME)
    raw = getattr(workbook, "loaded_theme", None) if workbook is not None else None
    if raw:
        try:
            text = raw.decode("utf-8", "ignore") if isinstance(raw, (bytes, bytearray)) else str(raw)
            found = {}
            for name in ("dk1", "lt1", "dk2", "lt2", "accent1", "accent2", "accent3", "accent4",
                         "accent5", "accent6", "hlink", "folHlink"):
                m = re.search(rf"<a:{name}>(.*?)</a:{name}>", text, re.S)
                if not m:
                    continue
                v = re.search(r'srgbClr val="([0-9A-Fa-f]{6})"', m.group(1)) or re.search(r'lastClr="([0-9A-Fa-f]{6})"', m.group(1))
                if v:
                    found[name] = v.group(1).upper()
            order = ["lt1", "dk1", "lt2", "dk2", "accent1", "accent2", "accent3", "accent4", "accent5", "accent6",
                     "hlink", "folHlink"]
            colours = [found.get(n, colours[i]) for i, n in enumerate(order)]
        except Exception:
            pass
    _THEME_CACHE[key] = (workbook, colours)
    return colours


def _apply_tint(rgb, tint):
    """Excel's tint: lighter towards white (tint > 0) or darker towards black (tint < 0), in HLS."""
    try:
        tint = float(tint or 0)
    except (TypeError, ValueError):
        tint = 0.0
    if abs(tint) < 1e-6:
        return rgb
    h, l, s = colorsys.rgb_to_hls(*(c / 255.0 for c in rgb))
    l = l * (1.0 + tint) if tint < 0 else l * (1.0 - tint) + tint
    r, g, b = colorsys.hls_to_rgb(h, max(0.0, min(1.0, l)), s)
    return (int(round(r * 255)), int(round(g * 255)), int(round(b * 255)))


def _openpyxl_color_to_rgb(color, workbook=None):
    if not color:
        return None
    if color.type == 'rgb' and color.rgb:
        hex_str = str(color.rgb)
        if len(hex_str) == 8:
            hex_str = hex_str[2:]
        if len(hex_str) == 6:
            try:
                return (int(hex_str[0:2], 16), int(hex_str[2:4], 16), int(hex_str[4:6], 16))
            except ValueError:
                return None
    elif color.type == 'theme' and color.theme is not None:
        try:
            colours = _theme_colours(workbook)
            idx = int(color.theme)
            if 0 <= idx < len(colours):
                hx = colours[idx]
                base = (int(hx[0:2], 16), int(hx[2:4], 16), int(hx[4:6], 16))
                return _apply_tint(base, getattr(color, "tint", 0))
        except Exception:
            return None
    elif color.type == 'indexed' and color.index is not None:
        try:
            from openpyxl.styles.colors import COLOR_INDEX
            idx = color.index
            if idx in (64, 65):                      # "system foreground / background": Excel's black / white
                return (0, 0, 0) if idx == 64 else (255, 255, 255)
            if idx < len(COLOR_INDEX):
                hex_str = COLOR_INDEX[idx]
                if hex_str and len(hex_str) >= 6:
                    if len(hex_str) == 8:
                        hex_str = hex_str[2:]
                    return (int(hex_str[0:2], 16), int(hex_str[2:4], 16), int(hex_str[4:6], 16))
        except Exception:
            pass
    return None


def _workbook_of(cell):
    ws = getattr(cell, "parent", None)
    return getattr(ws, "parent", None) if ws is not None else None


def get_excel_color(cell):
    """Read explicit font RGB from an openpyxl cell. Returns None if no color."""
    if not cell.font or not cell.font.color:
        return None
    return _openpyxl_color_to_rgb(cell.font.color, _workbook_of(cell))


def get_excel_fill_color(cell):
    """Read explicit solid fill RGB from an openpyxl cell. Returns None if no fill."""
    if not cell.fill:
        return None
    pattern_type = str(getattr(cell.fill, "patternType", "") or "").lower()
    if pattern_type in ("", "none"):
        return None
    for attr in ("fgColor", "start_color"):
        color = getattr(cell.fill, attr, None)
        rgb = _openpyxl_color_to_rgb(color, _workbook_of(cell))
        if rgb is not None:
            return rgb
    return None


def get_excel_border(cell):
    """{side: (width px, rgb)} for the sides of a cell that Excel draws a line on."""
    out = {}
    border = getattr(cell, "border", None)
    if border is None:
        return out
    widths = {"hair": 1, "thin": 1, "dotted": 1, "dashed": 1, "dashDot": 1, "dashDotDot": 1,
              "medium": 2, "mediumDashed": 2, "mediumDashDot": 2, "mediumDashDotDot": 2, "slantDashDot": 2,
              "thick": 3, "double": 3}
    wb = _workbook_of(cell)
    for side in ("left", "right", "top", "bottom"):
        s = getattr(border, side, None)
        if s is None or not s.style:
            continue
        rgb = _openpyxl_color_to_rgb(s.color, wb) if s.color is not None else None
        out[side] = (widths.get(s.style, 1), rgb or (0, 0, 0))
    return out
