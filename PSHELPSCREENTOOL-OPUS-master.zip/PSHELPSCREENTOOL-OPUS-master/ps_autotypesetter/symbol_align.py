"""Name a PSD's symbol pictures by lining its text up with the AGR it was made from.

The user's method (2026-10-29, the MO' FEATURES page): read every text layer of the PSD and every line of
the AGR; find the AGR sentence the PSD shows ("<Mummy> or <Special Mummy> with one or more <Pink Gem>
awards Mo' Boosts feature."); the picture that stands where the AGR has a <symbol> is that symbol — the
picture before "or" is <Mummy>, the one after it <Special Mummy>, the one before "awards" <Pink Gem>.

How:
  1. Each PSD page is read as a person reads it: its text layers and pictures sorted into lines by
     where they are (top to bottom, left to right) — the layers' order and the page's groups don't
     matter. A line is words and picture slots. A text layer that leaves runs of spaces for icons
     ("with one or more          awards …") gets the pictures over its gaps as slots, in reading order.
  2. Each AGR sheet is one stream of words and symbol slots, cell after cell.
  3. Every PSD line is lined up with the sheet streams word by word (difflib): words match words, a
     picture slot only a symbol slot, and a slot counts only inside a run that matches — the words on
     both sides of it are the cue. Small differences (a capital, a line split across two layers, a
     word the artist changed elsewhere in the sentence) don't stop the rest of the line. The PSD page's
     own sheet (the one most of its lines match) is preferred, but a line matching another sheet better
     counts there: an AGR page split over several PSD pages, Continued pages, all work.
  4. Every sentence votes: the same picture (by its pixels) is named by every line it is in; the
     majority wins, and a picture its sentences disagree on is reported, never guessed.

Layers hidden on their page are skipped (a picture is never named from an old, hidden version); a
hidden page is read — a help PSD shows one page at a time.
"""

import difflib
import re
from collections import Counter, defaultdict

from .content_model import TOKEN, tokens_in

SLOT = "\x00"                                     # a picture / symbol slot in a stream
_ICON_GAP = re.compile(r"[  ]{3,}")          # the room an artist leaves for an icon layer
_WORD = re.compile(r"[^\W_]+(?:['’][^\W_]+)*|[^\w\s]", re.UNICODE)
_MIN_RUN_WORDS = 2                                # a matched run needs this many real words around its slots
# not real words for that: punctuation and the little words a list of symbols is made of ("[pic], [pic] and
# [pic]" would line up one slot over)
_LITTLE = {"or", "and", "the", "a", "an", "of", "to", "in", "on", "x", "&", "+"}


def _real(u):
    # letters: pay numbers ("[pic] 5 400 [pic] 5 100") repeat from card to card, so they tell nothing —
    # a paytable's pictures are named by their pay cards (market_clone's card evidence)
    return u != SLOT and u not in _LITTLE and any(ch.isalpha() for ch in u)


def _words(text):
    return [w.casefold().replace("’", "'") for w in _WORD.findall(str(text or "").replace("\r", " "))]


def agr_units(text):
    """An AGR cell as units: words, and SLOT for each <token>; the tokens in order."""
    units, toks = [], []
    for part in re.split(r"(<[^<>]*>)", str(text or "")):
        if part and TOKEN.fullmatch(part):
            units.append(SLOT)
            toks.append(part[1:-1])
        else:
            units += _words(part)
    return units, toks


def sheet_stream(sheet):
    """(units, the token of each SLOT unit by its index) for one AGR sheet, cell after cell."""
    units, slot_tok = [], {}
    for key in sorted(sheet.cells):
        u, toks = agr_units(sheet.cells[key])
        it = iter(toks)
        for x in u:
            if x == SLOT:
                slot_tok[len(units)] = next(it)
            units.append(x)
    return units, slot_tok


def _visible(layer, root):
    """Shown on its page: the layer and its groups up to the page switched on. The page itself may be
    hidden — a help PSD shows one page at a time."""
    node = layer
    while node is not None and node is not root:
        if not bool(getattr(node, "visible", True)):
            return False
        node = getattr(node, "parent", None)
    return True


def _justification(layer):
    """"left" / "right" / "center" of a text layer's first paragraph (centre when it can't be read)."""
    try:
        j = int(layer.engine_dict["ParagraphRun"]["RunArray"][0]["ParagraphSheet"]["Properties"].get("Justification", 2))
    except Exception:
        return "center"
    return {0: "left", 1: "right"}.get(j, "center")


def _slot_xs(ln, lead, trail, widest, t, just):
    """The x of each icon slot of a text line, estimated from where its room is among the line's
    characters (the line's width taken as its share of the layer's widest line)."""
    def width(text):                              # spaces are about half as wide as letters
        return sum(0.5 if ch in "  " else 1.0 for ch in text)
    W = float(t.right - t.left)
    lw = W * width(ln) / max(1.0, float(widest))
    x0 = t.left if just == "left" else (t.right - lw if just == "right" else t.left + (W - lw) / 2.0)
    per = lw / max(1.0, width(ln))
    core = ln.strip("  ")
    xs = []
    if lead >= 3:
        xs.append(x0 + per * width(ln[:lead]) / 2.0)
    for m in _ICON_GAP.finditer(core):
        xs.append(x0 + per * (width(ln[:lead]) + width(core[:m.start()]) + width(core[m.start():m.end()]) / 2.0))
    if trail >= 3:
        xs.append(x0 + per * (width(ln) - width(ln[len(ln) - trail:]) / 2.0))
    return xs


def _picture_rows(pics):
    """The pictures' lines (as _reading_order groups them)."""
    rows = []
    for p in sorted(pics, key=lambda q: (q.top + q.bottom) / 2.0):
        mid, hh = (p.top + p.bottom) / 2.0, max(4.0, p.bottom - p.top)
        if rows and abs(rows[-1][0] - mid) <= hh * 0.5:
            rows[-1][1].append(p)
        else:
            rows.append([mid, [p]])
    return rows


def _reading_order(pics):
    """Pictures as a person reads them: rows top to bottom (middles within half a picture), each row
    left to right."""
    rows = []
    for p in sorted(pics, key=lambda q: (q.top + q.bottom) / 2.0):
        mid, hh = (p.top + p.bottom) / 2.0, max(4.0, p.bottom - p.top)
        if rows and abs(rows[-1][0] - mid) <= hh * 0.5:
            rows[-1][1].append(p)
        else:
            rows.append([mid, [p]])
    return [p for _m, row in rows for p in sorted(row, key=lambda q: q.left)]


def _fill_slots(xs, pics):
    """The picture for each slot (or None): pictures and slots matched in left-to-right order, each
    either matched to the other or skipped, so the total distance is smallest (an edit-distance DP)."""
    ps = [((p.left + p.right) / 2.0, p) for p in pics]
    n, m = len(xs), len(ps)
    if not n:
        return []
    skip = max(40.0, 1.5 * (sum(p.right - p.left for p in pics) / max(1, m)))
    INF = float("inf")
    cost = [[INF] * (m + 1) for _ in range(n + 1)]
    back = [[None] * (m + 1) for _ in range(n + 1)]
    cost[0][0] = 0.0
    for i in range(n + 1):
        for j in range(m + 1):
            c = cost[i][j]
            if c == INF:
                continue
            if i < n and j < m:
                d = c + abs(xs[i] - ps[j][0])
                if d < cost[i + 1][j + 1]:
                    cost[i + 1][j + 1], back[i + 1][j + 1] = d, (i, j, True)
            if i < n and c + skip < cost[i + 1][j]:
                cost[i + 1][j], back[i + 1][j] = c + skip, (i, j, False)
            if j < m and c + skip < cost[i][j + 1]:
                cost[i][j + 1], back[i][j + 1] = c + skip, (i, j, False)
    out = [None] * n
    i, j = n, m
    while back[i][j] is not None:
        pi, pj, took = back[i][j]
        if took:
            out[pi] = ps[pj][1]
        i, j = pi, pj
    return out


class Stack:
    """Pictures stacked into one symbol — two coins / gems drawn on top of each other, offset (an AGR's
    <Double Feature Coin>): one picture slot, named and saved as one symbol (their pictures composed)."""

    def __init__(self, layers):
        self.layers = layers                       # bottom first (the PSD's layer order)
        self.left = min(l.left for l in layers)
        self.top = min(l.top for l in layers)
        self.right = max(l.right for l in layers)
        self.bottom = max(l.bottom for l in layers)
        self.kind = "stack"
        self.name = " + ".join(str(l.name or "") for l in layers)
        self.visible = True

    @property
    def width(self):
        return self.right - self.left

    @property
    def height(self):
        return self.bottom - self.top


def _base_name(layer):
    return re.sub(r"(\s+copy(\s+\d+)?)+\s*$", "", str(getattr(layer, "name", "") or ""), flags=re.I).strip().casefold()


def _stacked(a, b):
    """a and b make one symbol: two copies of one picture (the same layer name less "copy N", or the same
    size) that overlap by at least a fifth of the smaller, one shifted from the other (a picture centred
    on its frame is not a stack, nor are two different gems that just touch)."""
    wa, ha, wb, hb = a.right - a.left, a.bottom - a.top, b.right - b.left, b.bottom - b.top
    same = _base_name(a) == _base_name(b) or (abs(wa - wb) <= 0.03 * max(wa, wb) and abs(ha - hb) <= 0.03 * max(ha, hb))
    if not same:
        return False
    ix = max(0, min(a.right, b.right) - max(a.left, b.left))
    iy = max(0, min(a.bottom, b.bottom) - max(a.top, b.top))
    sa, sb = max(1, (a.right - a.left) * (a.bottom - a.top)), max(1, (b.right - b.left) * (b.bottom - b.top))
    if ix * iy < 0.2 * min(sa, sb) or max(sa, sb) > 2.2 * min(sa, sb):
        return False
    dx = abs((a.left + a.right) - (b.left + b.right)) / 2.0
    dy = abs((a.top + a.bottom) - (b.top + b.bottom)) / 2.0
    return max(dx, dy) >= 0.1 * min(a.right - a.left, a.bottom - a.top, b.right - b.left, b.bottom - b.top)


def stack_pictures(pics):
    """The page's pictures, with each group of stacked pictures (_stacked) as one Stack."""
    groups = []
    for p in pics:
        hit = next((g for g in groups if len(g) < 2 and any(_stacked(p, q) for q in g)), None)   # a pair
        if hit is None:
            groups.append([p])
        else:
            hit.append(p)
    return [g[0] if len(g) == 1 else Stack(g) for g in groups]


def page_lines(root, is_picture):
    """The page as lines a person reads: [[unit, …]] with SLOT units, and for each line the picture
    layer of each SLOT (same order)."""
    texts, pics = [], []
    for l in root.descendants():
        try:
            kind = l.kind
        except Exception:
            continue
        if not _visible(l, root):
            continue
        if kind == "type" and str(l.text or "").strip():
            texts.append(l)
        elif is_picture(l):
            pics.append(l)
    pics = stack_pictures(pics)                   # two pictures stacked as one symbol (<Double Pink Gem>)
    used = set()
    pieces = []                                   # (top, bottom, left, units, slot pictures)
    for t in texts:
        body = str(t.text or "").replace("\r\n", "\r").strip("\r")
        lines = body.split("\r")
        top, bottom = t.top, t.bottom
        if not any(_ICON_GAP.search(ln.strip(" ")) for ln in lines):
            # plain text: each of its lines is a piece, placed in the layer's height
            n = max(1, len(lines))
            h = (bottom - top) / float(n)
            for i, ln in enumerate(lines):
                u = _words(ln)
                if u:
                    pieces.append((top + i * h, top + (i + 1) * h, t.left, u, []))
            continue
        # a layer with icon gaps: the pictures over it fill its gaps
        over = [p for p in pics if id(p) not in used and t.left - 8 <= (p.left + p.right) / 2.0 <= t.right + 8
                and top - 8 <= (p.top + p.bottom) / 2.0 <= bottom + 8]
        n = max(1, len(lines))
        h = (bottom - top) / float(n)
        widest = max(sum(0.5 if ch in "  " else 1.0 for ch in ln) for ln in lines) or 1
        just = _justification(t)
        made = []                                 # (line index, units, slot x estimates, lead, trail)
        for i, ln in enumerate(lines):
            # every gap is a slot, and room left at the start / end of the line too ("          or …":
            # the line starts with a picture)
            core = ln.strip("  ")
            lead = len(ln) - len(ln.lstrip("  "))
            trail = len(ln) - len(ln.rstrip("  "))
            parts = _ICON_GAP.split(core)
            units = [SLOT] if lead >= 3 else []
            for k, part in enumerate(parts):
                units += _words(part)
                if k < len(parts) - 1:
                    units.append(SLOT)
            if trail >= 3:
                units.append(SLOT)
            made.append((i, units, _slot_xs(ln, lead, trail, widest, t, just), lead >= 3, trail >= 3))
        ordered = _reading_order(over)
        n_slots = sum(u.count(SLOT) for _i, u, _x, _l, _t in made)
        edges = sum(int(l_) + int(t_) for _i, _u, _x, l_, t_ in made)
        if edges and n_slots - len(ordered) == edges:
            # more slots than pictures by just the room at the lines' ends ("… respectively      "): that is
            # spacing, not icons
            made = [(i, (u[1:] if l_ else u)[:-1] if t_ else (u[1:] if l_ else u),
                     (xs[1:] if l_ else xs)[:-1] if t_ else (xs[1:] if l_ else xs), False, False)
                    for i, u, xs, l_, t_ in made]
            n_slots = len(ordered)
        made = [(i, u, xs) for i, u, xs, *_e in made]
        pic_rows = _picture_rows(over)
        if n_slots and (len(ordered) == n_slots or len(pic_rows) > len(lines)):
            # as many pictures as gaps — or a paragraph box that wraps by itself (its pictures stand on more
            # lines than its text has): the pictures fill the gaps in reading order
            # as many pictures as gaps: the n-th picture (reading order) is the n-th gap — this holds for
            # a paragraph box that wraps by itself too (its lines aren't the text's lines)
            it = iter(ordered)
            fills = [[next(it, None) for _ in range(u.count(SLOT))] for _i, u, _x in made]
        else:
            # not as many: each slot where it is in its line (by its characters), the pictures matched to
            # the slots nearest them in order — an extra picture (a decoration) or a missing one shifts nothing
            fills = []
            for i, u, xs in made:
                y0, y1 = top + i * h, top + (i + 1) * h
                row_pics = sorted((p for p in over if y0 - h * 0.35 <= (p.top + p.bottom) / 2.0 <= y1 + h * 0.35),
                                  key=lambda p: p.left)
                fills.append(_fill_slots(xs, row_pics))
        for (i, units, _xs), slots in zip(made, fills):
            for p in slots:
                if p is not None:
                    used.add(id(p))
            if units:
                pieces.append((top + i * h, top + (i + 1) * h, t.left, units, slots))
    for p in pics:                                # pictures standing beside separate text layers
        if id(p) not in used:
            pieces.append((p.top, p.bottom, p.left, [SLOT], [p]))
    # rows: pieces whose middles share a line, each row left to right
    pieces.sort(key=lambda x: ((x[0] + x[1]) / 2.0, x[2]))
    rows = []
    for pc in pieces:
        mid, hh = (pc[0] + pc[1]) / 2.0, max(4.0, pc[1] - pc[0])
        for r in rows:
            if abs(r["mid"] - mid) <= max(r["h"], hh) * 0.55:
                r["pieces"].append(pc)
                break
        else:
            rows.append({"mid": mid, "h": hh, "pieces": [pc]})
    out = []
    for r in rows:
        units, slots = [], []
        for pc in sorted(r["pieces"], key=lambda x: x[2]):
            units += pc[3]
            slots += pc[4]
        if any(u != SLOT for u in units):         # a row of pictures only says nothing
            out.append((units, slots))
    return out


def _runs(line, stream):
    """Matching runs of `line` in `stream`: [(a, b, size)] with at least _MIN_RUN_WORDS words."""
    sm = difflib.SequenceMatcher(None, line, stream, autojunk=False)
    out = []
    for a, b, size in sm.get_matching_blocks():
        if size and sum(1 for u in line[a:a + size] if _real(u)) >= _MIN_RUN_WORDS:
            out.append((a, b, size))
    return out


def name_pictures(pages, sheets, is_picture, sig_of):
    """{picture id (sig_of(layer)): Counter({token: votes})} and the evidence lines, from every PSD page
    (pages: [(name, root)]) lined up with every AGR sheet (sheets: {name: content_model.Sheet})."""
    streams = {n: sheet_stream(s) for n, s in sheets.items()}
    matchers = {}
    for n, (units, _t) in streams.items():
        sm = difflib.SequenceMatcher(None, autojunk=False)
        sm.set_seq2(units)
        matchers[n] = sm
    votes = defaultdict(Counter)
    evidence = defaultdict(list)
    for page_name, root in pages:
        if root is None:
            continue
        lines = page_lines(root, is_picture)
        if not lines:
            continue
        # the page's sheet: the one most of its words match
        score = Counter()
        for units, _slots in lines:
            for n, sm in matchers.items():
                sm.set_seq1(units)
                score[n] += sum(size for _a, _b, size in sm.get_matching_blocks() if size >= 2)
        page_sheet = score.most_common(1)[0][0] if score else None
        for units, slots in lines:
            if SLOT not in units:
                continue
            best = None                           # (matched words, sheet, runs)
            for n, sm in matchers.items():
                sm.set_seq1(units)
                runs = [(a, b, s) for a, b, s in sm.get_matching_blocks()
                        if s and sum(1 for u in units[a:a + s] if _real(u)) >= _MIN_RUN_WORDS]
                got = sum(s for _a, _b, s in runs)
                if got and (best is None or got > best[0] or (got == best[0] and n == page_sheet)):
                    best = (got, n, runs)
            if best is None:
                continue
            got, n, runs = best
            slot_tok = streams[n][1]
            words_in_line = sum(1 for u in units if u != SLOT)
            k = 0                                 # index of the slot in the line
            slot_at = {}
            for i, u in enumerate(units):
                if u == SLOT:
                    slot_at[i] = k
                    k += 1
            for a, b, size in runs:
                for off in range(size):
                    if units[a + off] != SLOT:
                        continue
                    pic = slots[slot_at[a + off]]
                    tok = slot_tok.get(b + off)
                    if pic is None or tok is None:
                        continue
                    # an exact sentence counts more than a partly matched one
                    w = 2 if got >= words_in_line + units.count(SLOT) else 1
                    sid = sig_of(pic)
                    votes[sid][tok] += w
                    evidence[sid].append({"page": page_name, "sheet": n, "token": tok,
                                          "line": " ".join("[pic]" if u == SLOT else u for u in units)[:160],
                                          "exact": w == 2})
    return votes, evidence


def decide(votes):
    """{picture id: (token, how, others)}: the majority token; "text" when every vote agrees, "text_majority"
    when most do (others = the tokens the rest said)."""
    out = {}
    for sid, c in votes.items():
        (tok, n), *rest = c.most_common()
        if rest and rest[0][1] == n:
            out[sid] = (None, "conflict", sorted(c))
            continue
        out[sid] = (tok, "text" if not rest else "text_majority", sorted(t for t, _n in rest))
    return out
