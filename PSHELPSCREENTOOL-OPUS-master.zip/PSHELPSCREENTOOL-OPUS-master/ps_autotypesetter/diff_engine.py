def compare_workbooks(wb_old, wb_new, max_col_limit):
    changed = {}
    old_names = set(wb_old.sheetnames)
    new_names = set(wb_new.sheetnames)

    for name in old_names.symmetric_difference(new_names):
        if name in new_names:
            changed[name] = ["Tab added"]
        else:
            changed[name] = ["Tab removed"]

    for name in old_names & new_names:
        ws_old = wb_old[name]
        ws_new = wb_new[name]
        old_rows = list(ws_old.iter_rows(min_row=1, max_col=max_col_limit, values_only=True))
        new_rows = list(ws_new.iter_rows(min_row=1, max_col=max_col_limit, values_only=True))

        changes = []
        if len(old_rows) != len(new_rows):
            changes.append(f"Row count changed ({len(old_rows)} → {len(new_rows)})")

        max_len = max(len(old_rows), len(new_rows))
        for i in range(max_len):
            r_old = old_rows[i] if i < len(old_rows) else []
            r_new = new_rows[i] if i < len(new_rows) else []
            v_old = tuple(str(v).strip() if v is not None else "" for v in r_old)
            v_new = tuple(str(v).strip() if v is not None else "" for v in r_new)
            if v_old != v_new:
                diff_cells = []
                max_cells = max(len(r_old), len(r_new))
                for j in range(max_cells):
                    c_old = str(r_old[j]).strip() if j < len(r_old) and r_old[j] is not None else ""
                    c_new = str(r_new[j]).strip() if j < len(r_new) and r_new[j] is not None else ""
                    if c_old != c_new:
                        diff_cells.append(f"Col{j+1}")
                if diff_cells:
                    changes.append(f"Row {i+1} changed ({', '.join(diff_cells)})")
                else:
                    changes.append(f"Row {i+1} changed")

        if changes:
            changed[name] = changes
    return changed
