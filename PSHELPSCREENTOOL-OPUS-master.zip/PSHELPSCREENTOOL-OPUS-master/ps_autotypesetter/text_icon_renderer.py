import os
import re
import json
import atexit
import photoshop.api as ps
from .build_profiler import GLOBAL as _PROFILER, timed as _timed
from .icon_mapping import get_icon_size_override, resolve_icon_path


try:
    from PIL import ImageFont
    _HAS_PIL = True
except ImportError:
    _HAS_PIL = False

_PIL_FONT_CACHE = {}
_MEASURE_LAYER_STATE = {}  # id(measure_layer) -> {last_font_size, last_font_name}


def _px_to_pt(value, doc_or_layer, default_ppi=72.0):
    """Convert a Web-UI pixel font size into the Photoshop point value to store.

    Photoshop stores textItem.size / leading in points, and one point renders as
    (document PPI / 72) pixels.  Passing the raw UI pixel number therefore makes
    the text come out bigger at higher PPI (e.g. 20 px at 120 PPI becomes 20 *
    120 / 72 = 33.33 px).  This helper returns px * 72 / PPI so the finished
    pixel size always equals the UI value, whatever the document resolution.
    """
    try:
        fval = float(value)
    except (TypeError, ValueError):
        return 0.0
    scale = 1.0
    node = doc_or_layer
    for _ in range(16):
        if node is None:
            break
        try:
            res = float(getattr(node, "resolution", None) or 0)
            if res > 0:
                scale = 72.0 / res
                break
        except Exception:
            pass
        try:
            node = node.parent
        except Exception:
            break
    return fval * scale

# Batch capability: some Photoshop versions fail on parts of the batch JSX and
# silently drop text. The batch self-heals per spec via COM fallback (flags
# returned from the JSX), so no upfront capability probe is needed.
_TEXT_BATCH_GROUP_CACHE = {}
_BATCH_LOG_PATH = None
_PROBE_FONT = "ArialMT"

# Template + duplicate() text creation inside batch flushes: each spec clones a
# parent (size,font) template and only sets contents/color/position, skipping
# the slow artLayers.add()+kind=TEXT conversion cost for repeated styles.
# Disable with PSH_TEXT_DUP_BATCH=0 if a Photoshop build misbehaves.
_BATCH_DUP_ENABLED = os.environ.get("PSH_TEXT_DUP_BATCH", "1") not in ("0", "false", "False")

# Single-text-layer JSX fast path: None = untested, True = works, False =
# permanently disabled for this run after a failure (falls back to COM).
_TEXT_FAST_ENABLED = None


def _batch_log(msg):
    """Print and append to a temp log so EXE runs (no console) can be debugged."""
    print(msg)
    global _BATCH_LOG_PATH
    try:
        if _BATCH_LOG_PATH is None:
            tmp = os.environ.get("TEMP") or os.environ.get("TMP") or os.path.expanduser("~")
            _BATCH_LOG_PATH = os.path.join(tmp, "ps_autotypesetter_batch.log")
        with open(_BATCH_LOG_PATH, "a", encoding="utf-8") as fh:
            fh.write(msg + "\n")
    except Exception:
        pass


def _doc_anchor_jsx(doc):
    """Return JSX that resolves the TARGET document (by id, then name, then active).

    The batch historically used app.activeDocument, which silently writes into
    the wrong document when another PSD is active (ids/names then fail with
    'No such element'). Anchoring by the Python-side doc id fixes that."""
    doc_id = None
    doc_name = None
    try:
        doc_id = int(doc.id)
    except Exception:
        pass
    try:
        doc_name = str(doc.name)
    except Exception:
        pass
    id_bit = str(doc_id) if doc_id else "null"
    name_bit = json.dumps(doc_name) if doc_name else '""'
    return f"""
    var doc = null;
    try {{ doc = app.documents.getByID({id_bit}); }} catch(e) {{}}
    if (!doc) {{
        var docs = app.documents;
        for (var i = 0; i < docs.length; i++) {{
            if (docs[i].name == {name_bit}) {{ doc = docs[i]; break; }}
        }}
    }}
    if (!doc) doc = app.activeDocument;
    """

_FONT_PATH_CACHE = {}


def _get_font_path(font_name):
    """Resolve a Photoshop font name to a font file path on Windows (cached)."""
    if not font_name:
        return None
    key = str(font_name).strip().lower()
    if key in _FONT_PATH_CACHE:
        return _FONT_PATH_CACHE[key]
    path = _get_font_path_uncached(font_name)
    _FONT_PATH_CACHE[key] = path
    return path


def _get_font_path_uncached(font_name):
    if not font_name:
        return None
    try:
        from ps_autotypesetter.ui_web.paytable_style_common import resolve_font_file
        path = resolve_font_file(font_name)
        if path:
            return path
    except Exception:
        pass
    key = str(font_name).strip().lower()
    try:
        import winreg
        reg_key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                                 r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Fonts")
        i = 0
        while True:
            name, value, _ = winreg.EnumValue(reg_key, i)
            if key in name.lower():
                winreg.CloseKey(reg_key)
                fonts_dir = os.path.join(os.environ.get('WINDIR', 'C:\\Windows'), 'Fonts')
                return os.path.join(fonts_dir, value)
            i += 1
    except Exception:
        pass
    fallback_dirs = [os.path.join(os.environ.get('WINDIR', 'C:\\Windows'), 'Fonts')]
    common_exts = ['.ttf', '.otf', '.ttc']
    for fd in fallback_dirs:
        if not os.path.isdir(fd):
            continue
        for fname in os.listdir(fd):
            base, ext = os.path.splitext(fname)
            if ext.lower() in common_exts and key in base.lower():
                return os.path.join(fd, fname)
    return None

def _measure_text_pil(text, font_size, font_name):
    if not _HAS_PIL or not text:
        return None
    font_path = _get_font_path(font_name)
    if not font_path:
        return None
    cache_key = (font_path, font_size)
    if cache_key not in _PIL_FONT_CACHE:
        try:
            _PIL_FONT_CACHE[cache_key] = ImageFont.truetype(font_path, int(font_size))
        except Exception:
            return None
    font = _PIL_FONT_CACHE[cache_key]
    try:
        # getlength() returns the true ADVANCE width (includes kerning and side
        # bearings) -- exactly how far the next glyph/icon must move to the
        # right. The ink bbox (getbbox) is narrower, so an icon placed after
        # text measured with it could overlap the text's right edge.
        w = float(font.getlength(str(text)))
        return w if w > 0 else None
    except Exception:
        return None


def _measure_line_height_pil(font_size, font_name):
    """Real glyph box height (ascent + descent) in px for the same PIL font the
    width measurement uses. Lets the PSD engine step baselines by the same full
    glyph box the PNG renderer uses, so PSD lines can never overlap."""
    if not _HAS_PIL or not font_name:
        return None
    font_path = _get_font_path(font_name)
    if not font_path:
        return None
    try:
        font_px = int(round(float(font_size)))
    except Exception:
        return None
    if font_px < 1:
        return None
    cache_key = (font_path, font_px)
    if cache_key not in _PIL_FONT_CACHE:
        try:
            _PIL_FONT_CACHE[cache_key] = ImageFont.truetype(font_path, font_px)
        except Exception:
            return None
    font = _PIL_FONT_CACHE[cache_key]
    try:
        ascent, descent = font.getmetrics()
        height = float(ascent + descent)
        return height if height > 0 else None
    except Exception:
        return None

_MEASURE_GLOBAL_CACHE = {}
_MEASURE_GLOBAL_CACHE_MAX = 8000

# Disk-persisted measure cache: survives process restarts so the ~886 PS-jsx
# measure calls of a build drop to zero once the same workbook is rebuilt.
# Disable with PSH_MEASURE_DISK_CACHE=0. Values only come from PS-exact jsx
# measures (anchor mode); PIL widths are recomputed, never persisted.
_MEASURE_DISK_PATH = os.path.join(
    os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"),
    "pshelptool_measure_cache.json",
)
_MEASURE_DISK_MAX = 120000
_MEASURE_DISK_CACHE = None  # lazy: None = not loaded / disabled
_MEASURE_DISK_DIRTY = 0
_MEASURE_DISK_FLUSH_EVERY = 500


def _measure_disk_enabled():
    return os.environ.get("PSH_MEASURE_DISK_CACHE", "1") != "0"


def _measure_disk_load():
    global _MEASURE_DISK_CACHE
    if not _measure_disk_enabled():
        _MEASURE_DISK_CACHE = {}
        return
    cache = {}
    try:
        if os.path.isfile(_MEASURE_DISK_PATH):
            with open(_MEASURE_DISK_PATH, "r", encoding="utf-8") as fh:
                raw = json.load(fh)
            if isinstance(raw, list):
                for row in raw:
                    try:
                        cache[(str(row[0]), int(row[1]), str(row[2]))] = float(row[3])
                    except Exception:
                        continue
            if len(cache) > _MEASURE_DISK_MAX:
                cache = dict(list(cache.items())[-_MEASURE_DISK_MAX:])
    except Exception:
        cache = {}
    _MEASURE_DISK_CACHE = cache


def _measure_disk_set(key, width):
    global _MEASURE_DISK_DIRTY
    if _MEASURE_DISK_CACHE is None:
        _measure_disk_load()
    if not _measure_disk_enabled():
        return
    if len(_MEASURE_DISK_CACHE) >= _MEASURE_DISK_MAX:
        try:
            _MEASURE_DISK_CACHE.pop(next(iter(_MEASURE_DISK_CACHE)))
        except Exception:
            return
    _MEASURE_DISK_CACHE[key] = width
    _MEASURE_DISK_DIRTY += 1
    if _MEASURE_DISK_DIRTY >= _MEASURE_DISK_FLUSH_EVERY:
        _measure_disk_save()


def _measure_disk_save():
    global _MEASURE_DISK_DIRTY
    if _MEASURE_DISK_CACHE is None or not _MEASURE_DISK_DIRTY:
        return
    try:
        dir_path = os.path.dirname(_MEASURE_DISK_PATH)
        if dir_path and not os.path.isdir(dir_path):
            os.makedirs(dir_path, exist_ok=True)
        tmp_path = _MEASURE_DISK_PATH + ".tmp"
        with open(tmp_path, "w", encoding="utf-8") as fh:
            json.dump(
                [[k[0], k[1], k[2], v] for k, v in _MEASURE_DISK_CACHE.items()],
                fh,
            )
        os.replace(tmp_path, _MEASURE_DISK_PATH)
        _MEASURE_DISK_DIRTY = 0
    except Exception as e:
        print(f"[Measure] disk cache save failed: {e}")


atexit.register(_measure_disk_save)


def _measure_global_get(key):
    w = _MEASURE_GLOBAL_CACHE.get(key)
    if w is not None:
        return w
    if _MEASURE_DISK_CACHE is None:
        _measure_disk_load()
    return _MEASURE_DISK_CACHE.get(key) if _measure_disk_enabled() else None


def _measure_global_set(key, width):
    if len(_MEASURE_GLOBAL_CACHE) >= _MEASURE_GLOBAL_CACHE_MAX:
        _MEASURE_GLOBAL_CACHE.pop(next(iter(_MEASURE_GLOBAL_CACHE)))
    _MEASURE_GLOBAL_CACHE[key] = width
    _measure_disk_set(key, width)


def _measure_text_jsx(measure_layer, text, font_size, font_name, full_bounds=False):
    """PS-exact text width in ONE doJavaScript call; None when it cannot run.

    Mirrors the COM measure exactly (size/font/contents on the hidden measure
    layer, '|text|' bounds minus '||' bounds) so the returned width is the same
    value the COM path produced, just without the ~6 COM round-trips. With
    full_bounds=True the raw layer-bounds width is returned instead (no anchor
    pipes), matching what a real layer's bounds report.
    """
    try:
        doc, app = _doc_and_app_from(measure_layer)
        if doc is None or app is None:
            return None
        size_pt = _px_to_pt(font_size, measure_layer)
        safe_text = json.dumps(str(text).replace(" ", "\xa0"))
        safe_font = json.dumps(str(font_name or ""))
        layer_name = json.dumps(str(getattr(measure_layer, "name", "") or "MeasureLayer"))
        jsx = f"""
        (function() {{
            {_doc_anchor_jsx(doc)}
            var ml = null;
            try {{ ml = doc.artLayers.getByName({layer_name}); }} catch(e) {{ ml = null; }}
            var created = false;
            if (!ml) {{
                try {{ ml = doc.artLayers.add(); ml.kind = LayerKind.TEXT; ml.visible = false; created = true; }} catch(e) {{ return null; }}
            }}
            try {{
                ml.textItem.size = {size_pt};
                try {{ ml.textItem.font = {safe_font}; }} catch(e) {{}}
                if ({1 if full_bounds else 0}) {{
                    ml.textItem.contents = {safe_text};
                    var b1 = ml.bounds;
                    var w = Math.max(0, b1[2] - b1[0]);
                }} else {{
                    ml.textItem.contents = '|' + {safe_text} + '|';
                    var b1 = ml.bounds;
                    var w1 = b1[2] - b1[0];
                    ml.textItem.contents = '||';
                    var b2 = ml.bounds;
                    var w2 = b2[2] - b2[0];
                    var w = Math.max(0, w1 - w2);
                }}
            }} catch(e) {{
                return null;
            }} finally {{
                if (created) {{ try {{ ml.remove(); }} catch(e) {{}} }}
            }}
            return w;
        }})();
        """
        result = app.doJavaScript(jsx)
        try:
            return float(result)
        except Exception:
            return None
    except Exception:
        return None


def _premeasure_parts_and_words(parts, font_size, font_name, measure_layer, font_cache):
    """Pre-measure all parts + their words of a text block in ONE JSX call.

    Mirrors exactly which keys the wrap loops measure (parts via
    re.split('<tag>'), words via re.split('( )')) so every later
    _measure_text_cached call in this block hits the cache."""
    texts, sizes, fonts = [], [], []
    for part in parts:
        part = str(part or "")
        if not part or (part.startswith('<') and part.endswith('>')):
            continue
        texts.append(part)
        sizes.append(font_size)
        fonts.append(font_name)
        for word in re.split(r'( )', part):
            if word:
                texts.append(word)
                sizes.append(font_size)
                fonts.append(font_name)
    if not texts:
        return
    premeasure_texts_batch(texts, sizes, fonts, measure_layer, font_cache)


def premeasure_texts_batch(texts, font_sizes, font_names, measure_layer, font_cache, full_bounds=False):
    with _timed("measure_batch_total"):
        return _premeasure_texts_batch_impl(texts, font_sizes, font_names, measure_layer, font_cache, full_bounds)


def _premeasure_texts_batch_impl(texts, font_sizes, font_names, measure_layer, font_cache, full_bounds=False):
    """Measure many (text,size,font) keys in ONE doJavaScript, filling font_cache.

    texts/font_sizes/font_names are parallel lists; only keys not already
    cached/PIL-able are measured (the wrap functions use the exact same keys).
    Failure of the batch leaves the cache untouched -> callers fall back to the
    per-key paths exactly as before. Returns the number of keys measured.

    full_bounds=True measures raw layer-bounds widths (no anchor pipes) and
    neither reads nor writes the anchor-width global cache, so anchor and
    full-bounds widths never mix."""
    if not texts or measure_layer is None:
        return 0
    try:
        doc, app = _doc_and_app_from(measure_layer)
        if doc is None or app is None:
            return 0
    except Exception:
        return 0
    missing = []
    for text, font_size, font_name in zip(texts, font_sizes, font_names):
        text = str(text or "")
        if not text:
            continue
        try:
            font_size = int(font_size)
        except Exception:
            continue
        key = (text, font_size, font_name)
        if key in font_cache:
            continue
        if full_bounds:
            missing.append((text, font_size, font_name))
            continue
        if _measure_text_pil(text, font_size, font_name) is not None:
            font_cache[key] = _measure_text_pil(text, font_size, font_name)
            continue
        global_w = _measure_global_get(key)
        if global_w is not None:
            font_cache[key] = global_w
            continue
        missing.append((text, font_size, font_name))
    if not missing:
        return 0
    # Group by (size, font) so the JSX sets them once per group.
    by_style = {}
    for text, font_size, font_name in missing:
        by_style.setdefault((font_size, font_name), []).append(text)
    layer_name = json.dumps(str(getattr(measure_layer, "name", "") or "MeasureLayer"))
    entries = []
    orig_tuples = []
    for (font_size, font_name), texts_same_style in by_style.items():
        size_pt = round(float(_px_to_pt(font_size, measure_layer)), 4)
        font_str = str(font_name or "")
        for text in texts_same_style:
            entries.append({
                "s": size_pt,
                "f": font_str,
                "t": str(text).replace(" ", "\xa0")
            })
            orig_tuples.append((text, font_size, font_name))
    if not entries:
        return 0
    chunk_size = 1200
    chunks_entries = [entries[i:i + chunk_size] for i in range(0, len(entries), chunk_size)]
    chunks_tuples = [orig_tuples[i:i + chunk_size] for i in range(0, len(orig_tuples), chunk_size)]
    measured = 0
    for chunk_e, chunk_t in zip(chunks_entries, chunks_tuples):
        entries_json = json.dumps(chunk_e)
        jsx = f"""
        (function() {{
            {_doc_anchor_jsx(doc)}
            var ml = null;
            try {{ ml = doc.artLayers.getByName({layer_name}); }} catch(e) {{ ml = null; }}
            var created = false;
            if (!ml) {{
                try {{ ml = doc.artLayers.add(); ml.kind = LayerKind.TEXT; ml.visible = false; created = true; }} catch(e) {{ return ""; }}
            }}
            var res = [];
            var entries = {entries_json};
            var last_s = -1;
            var last_f = '';
            var w2_cache = {{}};
            for (var i = 0; i < entries.length; i++) {{
                var w = -1;
                try {{
                    if (entries[i].s != last_s || entries[i].f != last_f) {{
                        ml.textItem.size = entries[i].s;
                        last_s = entries[i].s;
                        try {{ ml.textItem.font = entries[i].f; }} catch(e) {{}}
                        last_f = entries[i].f;
                    }}
                    if ({1 if full_bounds else 0}) {{
                        ml.textItem.contents = entries[i].t;
                        var b1 = ml.bounds;
                        w = Math.max(0, b1[2] - b1[0]);
                    }} else {{
                        var w2k = last_s + '|' + last_f;
                        var w2 = w2_cache[w2k];
                        if (w2 === undefined) {{
                            ml.textItem.contents = '||';
                            var b2 = ml.bounds;
                            w2 = b2[2] - b2[0];
                            w2_cache[w2k] = w2;
                        }}
                        ml.textItem.contents = '|' + entries[i].t + '|';
                        var b1 = ml.bounds;
                        w = Math.max(0, (b1[2] - b1[0]) - w2);
                    }}
                }} catch(e) {{
                    w = -1;
                }}
                res.push(w);
            }}
            if (created) {{ try {{ ml.remove(); }} catch(e) {{}} }}
            return res.join("|");
        }})();
        """
        try:
            result = app.doJavaScript(jsx)
        except Exception:
            continue
        if isinstance(result, str):
            raw_vals = result.split("|")
        elif isinstance(result, (list, tuple)):
            raw_vals = result
        else:
            raw_vals = []
        for (text, font_size, font_name), w in zip(chunk_t, raw_vals):
            try:
                width = float(w)
                if width < 0:
                    continue
            except Exception:
                continue
            key = (text, font_size, font_name)
            font_cache[key] = width
            if not full_bounds:
                _measure_global_set(key, width)
            measured += 1
    if measured:
        _PROFILER.inc("measure_batch_keys", measured)
        _PROFILER.inc("measure_batch_calls", 1)
    return measured


def _measure_text_cached(text, font_size, font_name, measure_layer, font_cache):
    with _timed("measure_text_total"):
        return _measure_text_cached_impl(text, font_size, font_name, measure_layer, font_cache)


def _measure_text_cached_impl(text, font_size, font_name, measure_layer, font_cache):
    if not text:
        return 0
    _PROFILER.inc("measure_calls")
    cache_key = (text, font_size, font_name)
    if cache_key in font_cache:
        return font_cache[cache_key]

    pil_w = _measure_text_pil(text, font_size, font_name)
    if pil_w is not None:
        font_cache[cache_key] = pil_w
        return pil_w

    if measure_layer is None:
        estimate = len(str(text)) * float(font_size) * 0.55
        font_cache[cache_key] = estimate
        return estimate

    global_w = _measure_global_get(cache_key)
    if global_w is not None:
        font_cache[cache_key] = global_w
        return global_w

    jsx_w = _measure_text_jsx(measure_layer, text, font_size, font_name)
    if jsx_w is not None:
        _PROFILER.inc("measure_jsx")
        _measure_global_set(cache_key, jsx_w)
        font_cache[cache_key] = jsx_w
        return jsx_w

    _PROFILER.inc("measure_com_fallback")

    safe_text = str(text).replace(" ", "\xa0")
    ml_state = _MEASURE_LAYER_STATE.setdefault(id(measure_layer), {})
    if ml_state.get('last_font_size') != font_size:
        measure_layer.textItem.size = _px_to_pt(font_size, measure_layer)
        ml_state['last_font_size'] = font_size
    if ml_state.get('last_font_name') != font_name:
        measure_layer.textItem.font = font_name
        ml_state['last_font_name'] = font_name
    measure_layer.textItem.contents = "|" + safe_text + "|"
    b_total = measure_layer.bounds
    w_total = float(b_total[2]) - float(b_total[0])
    measure_layer.textItem.contents = "||"
    b_anchors = measure_layer.bounds
    w_anchors = float(b_anchors[2]) - float(b_anchors[0])
    true_w = max(0, w_total - w_anchors)
    font_cache[cache_key] = true_w
    return true_w


def _solid_color_from_rgb(rgb_tuple):
    c = ps.SolidColor()
    try:
        c.rgb.red, c.rgb.green, c.rgb.blue = [int(v) for v in rgb_tuple]
    except Exception:
        c.rgb.red, c.rgb.green, c.rgb.blue = 255, 255, 255
    return c


def _keyword_style_config(value):
    try:
        if isinstance(value, dict):
            raw_rgb = value.get("rgb") or value.get("color") or value.get("value")
            bold = bool(value.get("bold", False))
        else:
            raw_rgb = value
            bold = False
        rgb = tuple(int(v) for v in list(raw_rgb)[:3])
        if len(rgb) != 3:
            raise ValueError("keyword rgb needs 3 values")
    except Exception:
        rgb = (255, 255, 255)
        bold = False
    return {"rgb": rgb, "bold": bold}


def _keyword_boundary_ok(text_string, start, end, keyword):
    def is_word_char(ch):
        return ch.isalnum() or ch == "_"

    if not keyword:
        return False
    if keyword[0].isalnum() and start > 0 and is_word_char(text_string[start - 1]):
        return False
    if keyword[-1].isalnum() and end < len(text_string) and is_word_char(text_string[end]):
        return False
    return True


def _keyword_segments(text_string, keyword_colors=None):
    """Return [(segment_text, rgb_or_None), ...] with case-insensitive keyword matches.

    Longest keywords are matched first. The result is non-overlapping and preserves
    all original characters/spaces. This is shared by normal text and table text.
    """
    text_string = str(text_string or "")
    if not keyword_colors:
        return [(text_string, None)]

    usable = []
    for key, value in (keyword_colors or {}).items():
        key_s = str(key or "")
        if key_s:
            usable.append((key_s, _keyword_style_config(value)["rgb"]))
    if not usable:
        return [(text_string, None)]

    usable.sort(key=lambda item: len(item[0]), reverse=True)
    hits = _keyword_color_ranges(text_string, {key: {"rgb": rgb} for key, rgb in usable})
    if not hits:
        return [(text_string, None)]

    segments = []
    last = 0
    for start, end, rgb, _bold in hits:
        if start > last:
            segments.append((text_string[last:start], None))
        segments.append((text_string[start:end], rgb))
        last = end
    if last < len(text_string):
        segments.append((text_string[last:], None))
    return segments or [(text_string, None)]


def _doc_and_app_from(parent_group):
    """Walk the COM parent chain up to the Application; return (Document, Application).

    The comtypes photoshop.api wrapper raises NameError when accessing
    typename on Document/Application objects (raw dispatch), so the chain is
    walked to its root (the Application, whose parent access fails) and the
    Document is the deepest node that exposes a positive resolution."""
    chain = []
    node = parent_group
    for _ in range(32):
        if node is None:
            break
        chain.append(node)
        try:
            node = node.parent
        except Exception:
            break
    if not chain:
        return None, None
    app = chain[-1]
    doc = None
    for n in reversed(chain):
        try:
            if float(n.resolution) > 0:
                doc = n
                break
        except Exception:
            continue
    return doc, app


def _text_fast_jsx(doc, parent_group, contents, font_size, font_name, color, x, y, name, line_height,
                   use_nbsp=True, size_pt_override=None):
    """Build JSX creating ONE text layer via the DOM (no suspendHistory).

    Mirrors the COM property sets exactly (kind, name, contents with NBSP,
    size, font, color, leading, position) so the result is an identical layer.
    NOTE: suspendHistory was tried for speed but this Photoshop build REVERTS
    layer creation inside it, so creation must persist on its own (~0.31s/layer,
    still faster than the ~0.44s/layer COM route). Returns None if the parent
    group cannot be resolved to a group id.
    use_nbsp=True keeps the classic behaviour (spaces become NBSP). Set
    use_nbsp=False to keep plain spaces (e.g. paytable layers created via COM
    today). size_pt_override, when given, is used verbatim as the textItem.size
    point value (caller already did px->pt conversion, e.g. int-truncated)."""
    try:
        r = int(color.rgb.red)
        g = int(color.rgb.green)
        b = int(color.rgb.blue)
    except Exception:
        r, g, b = 255, 255, 255
    raw_contents = str(contents)
    if use_nbsp:
        raw_contents = raw_contents.replace(" ", "\xa0")
    contents_s = json.dumps(raw_contents)
    font_s = json.dumps(str(font_name or ""))
    name_s = json.dumps(str(name))
    if size_pt_override is not None:
        try:
            size_pt = float(size_pt_override)
        except Exception:
            size_pt = _px_to_pt(font_size, parent_group)
    else:
        size_pt = _px_to_pt(font_size, parent_group)
    leading_jsx = ""
    try:
        if line_height and float(line_height) > 0:
            leading_jsx = f"try {{ l.textItem.leading = {_px_to_pt(line_height, parent_group)}; }} catch(e) {{}}"
    except Exception:
        pass
    font_jsx = f"try {{ l.textItem.font = {font_s}; }} catch(e) {{}}" if font_name else ""
    is_doc = False
    try:
        is_doc = float(parent_group.resolution) > 0
    except Exception:
        is_doc = False
    if is_doc:
        parent_bit = "var parent = doc;"
    else:
        try:
            gid = int(parent_group.id)
        except Exception:
            return None
        parent_bit = (
            "function __findSet(node, id) {\n"
            "    var sets = node.layerSets;\n"
            "    for (var i = 0; i < sets.length; i++) {\n"
            "        if (sets[i].id == id) return sets[i];\n"
            "        var hit = __findSet(sets[i], id);\n"
            "        if (hit) return hit;\n"
            "    }\n"
            "    return null;\n"
            "}\n"
            f"var parent = __findSet(doc, {gid});\n"
            "if (!parent) throw new Error('text fast path: parent group not found');"
        )
    anchor = _doc_anchor_jsx(doc)
    return f"""
    (function() {{
        {anchor}
        try {{
            {parent_bit}
            var l = parent.artLayers.add();
            l.name = {name_s};
            l.kind = LayerKind.TEXT;
            l.textItem.contents = {contents_s};
            l.textItem.size = {size_pt};
            {font_jsx}
            var c = new SolidColor();
            c.rgb.red = {r}; c.rgb.green = {g}; c.rgb.blue = {b};
            l.textItem.color = c;
            {leading_jsx}
            l.textItem.position = [{float(x)}, {float(y)}];
            return "OK:" + l.id;
        }} catch (e) {{
            return "ERR: " + e;
        }}
    }})();
    """

def _add_text_layer_fast(parent_group, contents, font_size, font_name, color, x, y, name, line_height):
    """Create one text layer via JSX; return its COM object (or None -> COM fallback).

    The fresh layer is left active by Photoshop, so it is re-acquired via
    doc.activeLayer; its name is verified to make sure the JSX really ran
    against the expected parent document/group."""
    global _TEXT_FAST_ENABLED
    doc, app = _doc_and_app_from(parent_group)
    if doc is None or app is None:
        return None
    jsx = _text_fast_jsx(doc, parent_group, contents, font_size, font_name, color, x, y, name, line_height)
    if not jsx:
        return None
    try:
        with _timed("text_layers_jsx"):
            result = app.doJavaScript(jsx)
    except Exception as exc:
        print(f"Text fast path failed; using COM for '{name}': {exc}")
        _TEXT_FAST_ENABLED = False
        _PROFILER.inc("text_layers_jsx_fallback")
        return None
    if isinstance(result, str) and result.startswith("ERR:"):
        print(f"Text fast path JSX error for '{name}': {result}")
        _TEXT_FAST_ENABLED = False
        _PROFILER.inc("text_layers_jsx_fallback")
        return None
    if not (isinstance(result, str) and result.startswith("OK")):
        _TEXT_FAST_ENABLED = False
        _PROFILER.inc("text_layers_jsx_fallback")
        return None
    _PROFILER.inc("text_layers_jsx")
    if _TEXT_FAST_ENABLED is None:
        _TEXT_FAST_ENABLED = True
    try:
        # NOTE: photoshop.api has no getByID, so the freshly created layer is
        # re-acquired via doc.activeLayer (it is still the active layer) and
        # its name verified against what the JSX was asked to create.
        layer = doc.activeLayer
        if getattr(layer, "name", None) != str(name):
            print(f"Text fast path name mismatch for '{name}'; using COM fallback")
            _PROFILER.inc("text_layers_jsx_fallback")
            return None
        return layer
    except Exception:
        return None


def _add_text_layer(parent_group, contents, font_size, font_name, color, x, y, name="Text", line_height=None, backend=None, fast=True):
    _PROFILER.inc("text_layers")
    if backend is not None:
        with _timed("text_layers_backend"):
            return backend.create_text_layer(parent_group, contents, font_name, font_size, color, x, y, name, line_height)
    global _TEXT_FAST_ENABLED
    if fast and _TEXT_FAST_ENABLED is not False:
        layer = _add_text_layer_fast(parent_group, contents, font_size, font_name, color, x, y, name, line_height)
        if layer is not None:
            return layer
    with _timed("text_layers_com"):
        layer = parent_group.artLayers.add()
        layer.kind = ps.LayerKind.TextLayer
        layer.name = name
        layer.textItem.contents = str(contents).replace(" ", "\xa0")
        layer.textItem.size = _px_to_pt(font_size, layer)
        try:
            if font_name:
                layer.textItem.font = font_name
        except Exception as exc:
            print(f"Text font warning: could not apply font '{font_name}' to {name}: {exc}")
        layer.textItem.color = color
        try:
            if line_height and float(line_height) > 0:
                layer.textItem.leading = _px_to_pt(line_height, layer)
        except Exception:
            pass
        layer.textItem.position = [x, y]
        return layer



def add_text_spec_to_batch(batch, parent_group, contents, font_size, font_name, color, x, y, name="Text", line_height=None):
    try:
        r = int(color.rgb.red)
        g = int(color.rgb.green)
        b = int(color.rgb.blue)
    except Exception:
        r, g, b = 255, 255, 255
    group_path = []
    try:
        cur = parent_group
        while cur is not None:
            try:
                typename = str(getattr(cur, "typename", "") or "")
            except Exception:
                typename = ""
            if typename != "LayerSet":
                break
            group_path.append(str(cur.name))
            try:
                cur = cur.parent
            except Exception:
                break
        group_path = list(reversed(group_path))
    except Exception:
        group_path = []
    batch.append({
        'parent': parent_group,
        'group_id': int(parent_group.id),
        'group_path': group_path,
        'contents': str(contents).replace(" ", "\xa0"),
        'font_size': int(font_size),
        'font_name': str(font_name or ""),
        'r': r, 'g': g, 'b': b,
        'x': float(x), 'y': float(y),
        'name': str(name),
        'line_height': float(line_height) if line_height else None,
    })

def _probe_text_batch(app, doc):
    """Test whether the JSX batch text-creation mechanism actually works.

    The probe mirrors the REAL batch exactly: it runs against the TARGET
    document (not app.activeDocument), creates a nested group, sets contents
    containing a non-breaking space and applies a real font. It also verifies
    the layerSets.getByID lookup the real batch depends on. Returns True only
    if the probe text layer is found inside the nested group via BOTH the
    path walk and getByID."""
    anchor = _doc_anchor_jsx(doc)
    jsx = f'''
    (function(){{
        {anchor}
        var probe = null;
        var ok = false;
        var gid = 0;
        try {{
            probe = doc.layerSets.add();
            probe.name = "__text_batch_probe__";
            var nested = probe.layerSets.add();
            nested.name = "__probe_nested__";
            gid = probe.id;
            var l = nested.artLayers.add();
            l.name = "__probe_text__";
            l.kind = LayerKind.TEXT;
            l.textItem.contents = "probe\\u00a0text";
            try {{ l.textItem.font = {json.dumps(_PROBE_FONT)}; }} catch(e) {{}}
            var sets = probe.layerSets;
            for (var i = 0; i < sets.length; i++) {{
                if (sets[i].name == "__probe_nested__") {{
                    ok = (sets[i].artLayers.length === 1);
                    break;
                }}
            }}
            var viaId = null;
            try {{ viaId = doc.layerSets.getByID(gid); }} catch(e2) {{ viaId = null; }}
            if (viaId) ok = true;
            else {{
                var byName = null;
                var sets2 = doc.layerSets;
                for (var k = 0; k < sets2.length; k++) {{
                    if (sets2[k].name == probe.name) {{ byName = sets2[k]; break; }}
                }}
                ok = ok && (byName != null);
            }}
        }} catch (e) {{
            ok = false;
        }}
        try {{ if (probe) probe.remove(); }} catch (e2) {{}}
        return ok ? "OK" : "NO_LAYER";
    }})();
    '''
    try:
        result = app.doJavaScript(jsx)
        _batch_log(f"[Batch] probe result: {result}")
        return result == "OK"
    except Exception as exc:
        _batch_log(f"[Batch] probe threw: {exc}")
        return False


def _find_layerset_by_id(doc, target_id):
    """Walk the COM layer-set tree to find a group by id. Cached per doc+id."""
    doc_key = None
    try:
        doc_key = int(doc.id)
    except Exception:
        doc_key = 0
    cache_key = (doc_key, int(target_id))
    if cache_key in _TEXT_BATCH_GROUP_CACHE:
        return _TEXT_BATCH_GROUP_CACHE[cache_key]
    found = [None]

    def walk(parent):
        if found[0] is not None:
            return
        try:
            count = len(parent.layerSets)
        except Exception:
            return
        for i in range(count):
            try:
                child = parent.layerSets[i]
            except Exception:
                continue
            try:
                if int(child.id) == target_id:
                    found[0] = child
                    return
            except Exception:
                pass
            walk(child)
            if found[0] is not None:
                return

    walk(doc)
    _TEXT_BATCH_GROUP_CACHE[cache_key] = found[0]
    return found[0]


def _render_spec_direct(app, doc, spec):
    """Fallback: create a text layer for one spec via direct COM (no JSX).

    Uses the parent group object captured at batch-add time, so no group lookup
    can fail. Property failures are isolated (same strategy as _add_text_layer,
    which is the proven heading path) so a bad font can never kill the layer."""
    parent = spec.get('parent')
    if parent is None:
        parent = _find_layerset_by_id(doc, spec.get('group_id'))
    if parent is None:
        _batch_log(f"[Batch] WARNING: could not locate group for '{spec.get('name')}'")
        return
    try:
        l = parent.artLayers.add()
    except Exception as exc:
        _batch_log(f"[Batch] FAILED to add layer '{spec.get('name')}': {exc}")
        return
    try:
        l.name = spec['name']
        l.kind = ps.LayerKind.TextLayer
    except Exception as exc:
        _batch_log(f"[Batch] name/kind failed for '{spec.get('name')}': {exc}")
    try:
        l.textItem.contents = spec['contents'].replace("\xa0", " ")
        l.textItem.size = _px_to_pt(spec['font_size'], l)
        try:
            if spec.get('font_name'):
                l.textItem.font = spec['font_name']
        except Exception as exc:
            _batch_log(f"[Batch] font warning for '{spec.get('name')}': {exc}")
        c = ps.SolidColor()
        c.rgb.red = spec['r']
        c.rgb.green = spec['g']
        c.rgb.blue = spec['b']
        l.textItem.color = c
        l.textItem.position = (int(round(spec['x'])), int(round(spec['y'])))
        if spec.get('line_height'):
            l.textItem.leading = _px_to_pt(spec['line_height'], l)
    except Exception as exc:
        _batch_log(f"[Batch] partial text failure for '{spec.get('name')}': {exc}")


def _parse_batch_result(result, expected_len):
    """Parse doJavaScript's result into a list of booleans.

    Different COM wrappers return different types: win32com returns a Python
    list of ints/bools, comtypes (photoshop.api) returns a comma-separated
    STRING like "true,false,true" (or "1,0,1"). Normalize all of them."""
    if result is None:
        return [True] * expected_len
    if isinstance(result, str):
        flags = []
        for part in result.split(","):
            part = part.strip().lower()
            if part in ("true", "1"):
                flags.append(True)
            elif part in ("false", "0"):
                flags.append(False)
            elif part == "":
                continue
            else:
                flags.append(bool(part))
        return flags[:expected_len]
    if isinstance(result, (list, tuple)):
        return [bool(v) for v in result][:expected_len]
    return [True] * expected_len


def flush_text_spec_batch(batch, app, doc):
    if not batch:
        return
    _PROFILER.inc("text_batch_specs", len(batch))
    with _timed("text_batch_flush"):
        return _flush_text_spec_batch_inner(batch, app, doc)


def _flush_text_spec_batch_inner(batch, app, doc):
    items = batch[:]
    batch.clear()
    jsx_parts = [_doc_anchor_jsx(doc), "var __batch_res = [];", (
        "function __findSet(node, id) {\n"
        "    var sets = node.layerSets;\n"
        "    for (var i = 0; i < sets.length; i++) {\n"
        "        if (sets[i].id == id) return sets[i];\n"
        "        var hit = __findSet(sets[i], id);\n"
        "        if (hit) return hit;\n"
        "    }\n"
        "    return null;\n"
        "}\n"
    )]
    if _BATCH_DUP_ENABLED:
        jsx_parts.append("var __tpls = {};")
    for spec in items:
        safe_contents = json.dumps(spec['contents'])
        safe_name = json.dumps(spec['name'])
        safe_font = json.dumps(spec['font_name'])
        r, g, b = spec['r'], spec['g'], spec['b']
        lh = spec['line_height']
        path_items = json.dumps(spec.get('group_path') or [])
        group_id_bit = str(int(spec.get('group_id') or 0))
        size_pt_bit = str(round(spec['font_size'] * _px_to_pt(1.0, doc), 4))
        leading_bit = ("try {{ l.textItem.leading = " + str(round(float(lh) * _px_to_pt(1.0, doc), 4)) + "; }} catch(eLead) {{}}" if lh else "")
        if _BATCH_DUP_ENABLED:
            # Template + duplicate: artLayers.add() + kind=TEXT conversion is the
            # expensive part of a DOM create (~0.25s/layer on this PS build).
            # One template per (size, font) is built, every spec duplicates it
            # and only touches contents/color/position ~3 property sets.
            tpl_key = json.dumps("t|" + str(round(float(size_pt_bit), 1)) + "|" + str(spec.get('font_name') or ""))
            jsx_parts.append(f"""
                (function(){{
                    var created = false;
                    try {{
                        var parent = __findSet(doc, {group_id_bit});
                        if (!parent) {{
                            var pathArr = {path_items};
                            var start = 0;
                            for (var s = 0; s < pathArr.length; s++) {{
                                var found0 = false;
                                for (var j = 0; j < doc.layerSets.length; j++) {{
                                    if (doc.layerSets[j].name == pathArr[s]) {{ found0 = true; break; }}
                                }}
                                if (found0) {{ start = s; break; }}
                            }}
                            var cur = doc;
                            var found = null;
                            for (var i = start; i < pathArr.length; i++) {{
                                found = null;
                                var sets = cur.layerSets;
                                for (var j = 0; j < sets.length; j++) {{
                                    if (sets[j].name == pathArr[i]) found = sets[j];
                                }}
                                if (!found) break;
                                cur = found;
                            }}
                            if (cur != doc) parent = cur;
                        }}
                        if (!parent) {{ __batch_res.push(false); return; }}
                        var tpl = __tpls[{tpl_key}];
                        if (!tpl) {{
                            var t = parent.artLayers.add();
                            t.name = "__duptpl__";
                            t.kind = LayerKind.TEXT;
                            t.textItem.contents = " ";
                            t.textItem.size = {size_pt_bit};
                            try {{ t.textItem.font = {safe_font}; }} catch(eFont) {{}}
                            __tpls[{tpl_key}] = t;
                            tpl = t;
                        }}
                        var l = tpl.duplicate();
                        l.name = {safe_name};
                        l.textItem.contents = {safe_contents};
                        var c = new SolidColor();
                        c.rgb.red = {r}; c.rgb.green = {g}; c.rgb.blue = {b};
                        l.textItem.color = c;
                        {leading_bit}
                        l.textItem.position = [{int(round(spec['x']))}, {int(round(spec['y']))}];
                        created = true;
                    }} catch(e){{ created = false; }}
                    __batch_res.push(created);
                }})();
            """)
        else:
            jsx_parts.append(f"""
                (function(){{
                    var created = false;
                    try {{
                        var parent = __findSet(doc, {group_id_bit});
                        if (!parent) {{
                            var pathArr = {path_items};
                            var start = 0;
                            for (var s = 0; s < pathArr.length; s++) {{
                                var found0 = false;
                                for (var j = 0; j < doc.layerSets.length; j++) {{
                                    if (doc.layerSets[j].name == pathArr[s]) {{ found0 = true; break; }}
                                }}
                                if (found0) {{ start = s; break; }}
                            }}
                            var cur = doc;
                            var found = null;
                            for (var i = start; i < pathArr.length; i++) {{
                                found = null;
                                var sets = cur.layerSets;
                                for (var j = 0; j < sets.length; j++) {{
                                    if (sets[j].name == pathArr[i]) found = sets[j];
                                }}
                                if (!found) break;
                                cur = found;
                            }}
                            if (cur != doc) parent = cur;
                        }}
                        if (!parent) {{ __batch_res.push(false); return; }}
                        var l = parent.artLayers.add();
                        l.name = {safe_name};
                        l.kind = LayerKind.TEXT;
                        l.textItem.contents = {safe_contents};
                        l.textItem.size = {size_pt_bit};
                        try {{ l.textItem.font = {safe_font}; }} catch(eFont) {{}}
                        var c = new SolidColor();
                        c.rgb.red = {r}; c.rgb.green = {g}; c.rgb.blue = {b};
                        l.textItem.color = c;
                        l.textItem.position = [{int(round(spec['x']))}, {int(round(spec['y']))}];
                        {leading_bit}
                        created = true;
                    }} catch(e){{ created = false; }}
                    __batch_res.push(created);
                }})();
            """)
    if _BATCH_DUP_ENABLED:
        # Remove every template (and any stray partial template left by a failed
        # template creation) by name, recursively through all groups.
        jsx_parts.append(
            "(function(){"
            " function __clean(node){"
            "  try { for (var i = node.artLayers.length - 1; i >= 0; i--) {"
            "   try { if (node.artLayers[i].name === \"__duptpl__\") node.artLayers[i].remove(); } catch(e) {}"
            "  } } catch(e) {}"
            "  try { for (var j = node.layerSets.length - 1; j >= 0; j--) __clean(node.layerSets[j]); } catch(e) {}"
            " }"
            " __clean(doc);"
            "})();"
        )
    created_count = 0
    result = None
    try:
        body_jsx = "\n".join(jsx_parts)
        jsx = body_jsx + "\n__batch_res;"
        result = app.doJavaScript(jsx)
    except Exception as exc:
        _batch_log(f"[Batch] Text layer flush failed ({len(items)} layers): {exc}")
        created_count = 0
    ok_flags = _parse_batch_result(result, len(items))
    created_count = sum(1 for v in ok_flags if v)
    _batch_log(f"[Batch] JSX flush created {created_count}/{len(items)} layers (flags={ok_flags})")
    if created_count < len(items):
        missing = [spec for spec, ok in zip(items, ok_flags) if not ok]
        if not missing:
            missing = items
        _batch_log(f"[Batch] Falling back to direct COM for {len(missing)} layer(s)")
        for spec in missing:
            _render_spec_direct(app, doc, spec)


def _keyword_color_ranges(text_string, keyword_colors=None):
    """Return non-overlapping [(start, end, rgb, bold), ...] ranges for keyword hits.

    Matching is case-insensitive and longest-keyword-first. The returned ranges
    use Python/JS string character offsets; spaces may later be converted to
    non-breaking spaces, but the character count remains the same.
    """
    text_string = str(text_string or "")
    if not text_string or not keyword_colors:
        return []

    usable = []
    for key, value in (keyword_colors or {}).items():
        key_s = str(key or "")
        if key_s:
            config = _keyword_style_config(value)
            usable.append((key_s, config["rgb"], bool(config.get("bold", False))))
    if not usable:
        return []

    usable.sort(key=lambda item: len(item[0]), reverse=True)
    occupied = [False] * len(text_string)
    hits = []
    lower_text = text_string.casefold()

    for keyword, rgb, bold in usable:
        lower_key = keyword.casefold()
        pos = 0
        while True:
            pos = lower_text.find(lower_key, pos)
            if pos < 0:
                break
            end = pos + len(keyword)
            if (
                end <= len(text_string)
                and _keyword_boundary_ok(text_string, pos, end, keyword)
                and not any(occupied[pos:end])
            ):
                for i in range(pos, end):
                    occupied[i] = True
                hits.append((pos, end, rgb, bold))
            pos = max(pos + 1, end)

    hits.sort(key=lambda item: item[0])
    return hits


def _apply_keyword_colors_to_text_layer(app, layer, text, keyword_colors=None):
    """Apply keyword colors inside ONE Photoshop text layer using text ranges.

    This is the Photoshop-like approach: create a single text layer, then change
    the color of selected character ranges. It avoids duplicate overlay layers
    and avoids manually splitting decorative heading fonts into separate layers.

    Photoshop does not expose this through the simple Python textItem API, so we
    use Action Manager JSX. If Photoshop rejects the range edit, the caller keeps
    the normal base-color layer instead of creating heavy/overlapping fallback
    layers.
    """
    ranges = _keyword_color_ranges(text, keyword_colors)
    if not app or not ranges:
        return False

    try:
        layer_id = int(getattr(layer, "id", 0) or 0)
    except Exception:
        layer_id = 0

    ranges_json = json.dumps([
        {"from": int(a), "to": int(b), "rgb": [int(c[0]), int(c[1]), int(c[2])], "bold": bool(bold)}
        for a, b, c, bold in ranges
    ])

    fallback_len = len(str(text or ""))
    jsx = f"""
    (function() {{
        var layerId = {layer_id};
        var ranges = {ranges_json};
        if (!ranges || !ranges.length) return true;

        function sid(s) {{ return stringIDToTypeID(s); }}
        function cid(s) {{ return charIDToTypeID(s); }}

        function selectLayerById(id) {{
            if (!id) return;
            var ref = new ActionReference();
            ref.putIdentifier(cid("Lyr "), id);
            var desc = new ActionDescriptor();
            desc.putReference(cid("null"), ref);
            executeAction(cid("slct"), desc, DialogModes.NO);
        }}

        function cloneDescriptor(d) {{
            var n = new ActionDescriptor();
            n.fromStream(d.toStream());
            return n;
        }}

        function putRGB(styleDesc, rgb) {{
            var colorDesc = new ActionDescriptor();
            colorDesc.putDouble(cid("Rd  "), rgb[0]);
            colorDesc.putDouble(cid("Grn "), rgb[1]);
            colorDesc.putDouble(cid("Bl  "), rgb[2]);
            try {{
                styleDesc.putObject(cid("Clr "), cid("RGBC"), colorDesc);
            }} catch (e1) {{}}
            try {{
                styleDesc.putObject(sid("color"), sid("RGBColor"), colorDesc);
            }} catch (e2) {{}}
        }}

        function putBold(styleDesc) {{
            try {{ styleDesc.putBoolean(sid("syntheticBold"), true); }} catch (e1) {{}}
            try {{ styleDesc.putBoolean(sid("fauxBold"), true); }} catch (e2) {{}}
            try {{ styleDesc.putBoolean(sid("bold"), true); }} catch (e3) {{}}
        }}

        function getTextKey() {{
            var ref = new ActionReference();
            ref.putProperty(cid("Prpr"), sid("textKey"));
            ref.putEnumerated(cid("TxLr"), cid("Ordn"), cid("Trgt"));
            return executeActionGet(ref).getObjectValue(sid("textKey"));
        }}

        function getBaseStyle(textKey) {{
            var oldRanges = textKey.getList(sid("textStyleRange"));
            if (oldRanges.count < 1) throw new Error("No base text style range found");
            var firstRange = oldRanges.getObjectValue(0);
            return firstRange.getObjectValue(sid("textStyle"));
        }}

        function addStyleRange(list, fromIndex, toIndex, styleDesc) {{
            if (toIndex <= fromIndex) return;
            var rangeDesc = new ActionDescriptor();
            rangeDesc.putInteger(sid("from"), fromIndex);
            rangeDesc.putInteger(sid("to"), toIndex);
            rangeDesc.putObject(sid("textStyle"), sid("textStyle"), styleDesc);
            list.putObject(sid("textStyleRange"), rangeDesc);
        }}

        selectLayerById(layerId);
        var textKey = getTextKey();
        var contents = "";
        try {{ contents = textKey.getString(cid("Txt ")); }} catch (eTxt) {{ contents = ""; }}
        var totalLen = contents.length;
        if (!totalLen) totalLen = {fallback_len};

        var baseStyle = getBaseStyle(textKey);
        var newList = new ActionList();
        var cursor = 0;

        ranges.sort(function(a, b) {{ return a.from - b.from; }});
        for (var i = 0; i < ranges.length; i++) {{
            var r = ranges[i];
            var fromIndex = Math.max(0, Math.min(totalLen, r.from));
            var toIndex = Math.max(0, Math.min(totalLen, r.to));
            if (toIndex <= fromIndex) continue;
            if (fromIndex < cursor) continue;

            if (fromIndex > cursor) {{
                addStyleRange(newList, cursor, fromIndex, cloneDescriptor(baseStyle));
            }}
            var coloredStyle = cloneDescriptor(baseStyle);
            putRGB(coloredStyle, r.rgb);
            if (r.bold) putBold(coloredStyle);
            addStyleRange(newList, fromIndex, toIndex, coloredStyle);
            cursor = toIndex;
        }}
        if (cursor < totalLen) {{
            addStyleRange(newList, cursor, totalLen, cloneDescriptor(baseStyle));
        }}

        textKey.putList(sid("textStyleRange"), newList);
        var setDesc = new ActionDescriptor();
        var setRef = new ActionReference();
        setRef.putEnumerated(cid("TxLr"), cid("Ordn"), cid("Trgt"));
        setDesc.putReference(cid("null"), setRef);
        setDesc.putObject(cid("T   "), cid("TxLr"), textKey);
        executeAction(cid("setd"), setDesc, DialogModes.NO);
        return true;
    }})();
    """

    try:
        app.doJavaScript(jsx)
        return True
    except Exception as exc:
        print(f"Keyword character styling failed; kept base-color text layer: {exc}")
        return False


def _render_text_with_keyword_overlays(parent_group, text, font_size, font_name, base_color,
                                       x, y, measure_layer, font_cache, keyword_colors=None,
                                       layer_name="Text", app=None, line_height=None,
                                       text_batch=None, backend=None):
    text = str(text or "")
    if text.strip() == "":
        return []

    if text_batch is not None and not keyword_colors and backend is None:
        add_text_spec_to_batch(text_batch, parent_group, text, font_size, font_name, base_color,
                               x, y, layer_name, line_height=line_height)
        return [None]

    layer = _add_text_layer(parent_group, text, font_size, font_name, base_color, x, y, layer_name, line_height=line_height, backend=backend, fast=(backend is None and not keyword_colors))
    if keyword_colors and backend is None:
        _apply_keyword_colors_to_text_layer(app, layer, text, keyword_colors)
    return [layer]

def _icon_dup_group_id(groups_memo, group):
    key = id(group)
    if key not in groups_memo:
        try:
            groups_memo[key] = int(group.id)
        except Exception:
            groups_memo[key] = None
    return groups_memo[key]


def _place_icon_duplicate_com(src_layer, parent_group, scale_pct, x, y):
    """Per-icon COM path: duplicate + move + resize + translate (unbatched fallback)."""
    try:
        new_icon = src_layer.duplicate()
        new_icon.move(parent_group, ps.ElementPlacement.PlaceInside)
        new_icon.visible = True
        new_icon.resize(scale_pct, scale_pct)
        b = new_icon.bounds
        new_icon.translate(x - float(b[0]), y - float(b[1]))
    except Exception:
        pass


def _render_cell_with_icons(doc, parent_group, text, font_size, font_name, text_color,
                            icon_h, start_x, start_y, max_width, cell_height, icon_y_offset, gap_px,
                            icon_folder, icon_cache, missing_icons_log, asset_group,
                            app, measure_layer, font_cache, row_idx, col_letter,
                            icon_mappings=None, keyword_colors=None, icon_size_overrides=None,
                            alignment="center", layer_name_prefix=None, line_height=None,
                            vertical_align="center", text_batch=None, backend=None,
                            icon_dup_batch=None, icon_dup_groups=None):
    parts = re.split(r'(<[^>]+>)', str(text or ""))
    lines, current_line, current_w = [], [], 0

    _premeasure_parts_and_words(parts, font_size, font_name, measure_layer, font_cache)

    for part in parts:
        if not part:
            continue
        if part.startswith('<') and part.endswith('>'):
            icon_name = part[1:-1].strip(" .;,-!")
            if icon_name not in icon_cache:
                icon_path = resolve_icon_path(icon_name, icon_folder, icon_mappings)
                if not icon_path or not os.path.exists(icon_path):
                    missing_icons_log.add(icon_name)
                    fallback_txt = f"<{icon_name}>"
                    fb_w = _measure_text_cached(fallback_txt, font_size, font_name, measure_layer, font_cache)
                    if current_w + fb_w <= max_width:
                        current_line.append({'type': 'text', 'val': fallback_txt, 'w': fb_w})
                        current_w += fb_w
                    else:
                        if current_line:
                            lines.append(current_line)
                        current_line = [{'type': 'text', 'val': fallback_txt, 'w': fb_w}]
                        current_w = fb_w
                    continue

                _PROFILER.inc("icons_unique_placed")
                with _timed("icons_total"):
                    icon_path_safe = json.dumps(icon_path)
                    jsx = f'''
                    var __doc = app.activeDocument;
                    var idPlc = charIDToTypeID("Plc ");
                    var desc = new ActionDescriptor();
                    desc.putPath(charIDToTypeID("null"), new File({icon_path_safe}));
                    executeAction(idPlc, desc, DialogModes.NO);
                    '''
                    try:
                        app.doJavaScript(jsx)
                        layer = doc.activeLayer
                        layer.name = icon_name
                        layer.move(asset_group, ps.ElementPlacement.PlaceInside)
                    except Exception:
                        icon_doc = app.open(icon_path)
                        icon_doc.activeLayer.duplicate(doc)
                        icon_doc.close(2)
                        app.activeDocument = doc
                        layer = doc.activeLayer
                        layer.name = icon_name
                        try:
                            app.executeAction(app.stringIDToTypeID("newPlacedLayer"))
                        except Exception:
                            pass
                        layer.move(asset_group, ps.ElementPlacement.PlaceInside)

                    b = layer.bounds
                    icon_cache[icon_name] = {
                        'layer': layer,
                        'id': int(layer.id),
                        'orig_h': float(b[3]) - float(b[1]),
                        'orig_w': float(b[2]) - float(b[0])
                    }

            resolved_icon_h = get_icon_size_override(icon_name, icon_size_overrides) or icon_h
            ratio = icon_cache[icon_name]['orig_w'] / icon_cache[icon_name]['orig_h']
            icon_w = resolved_icon_h * ratio
            w = gap_px + icon_w + gap_px
            if current_w + w > max_width and current_line:
                lines.append(current_line)
                current_line, current_w = [], 0
            current_line.append({'type': 'icon', 'val': icon_name, 'w': w, 'icon_h': resolved_icon_h})
            current_w += w
        else:
            part_w = _measure_text_cached(part, font_size, font_name, measure_layer, font_cache)
            if current_w + part_w <= max_width:
                current_line.append({'type': 'text', 'val': part, 'w': part_w})
                current_w += part_w
            else:
                words = re.split(r'( )', part)
                for word in words:
                    if not word:
                        continue
                    word_w = _measure_text_cached(word, font_size, font_name, measure_layer, font_cache)
                    if current_w + word_w > max_width:
                        if word == ' ':
                            continue
                        if current_line:
                            lines.append(current_line)
                        current_line, current_w = [], 0
                    current_line.append({'type': 'text', 'val': word, 'w': word_w})
                    current_w += word_w

    if current_line:
        lines.append(current_line)

    for line in lines:
        if line and line[0].get('type') == 'text':
            line[0]['val'] = str(line[0]['val']).lstrip()
        if line and line[-1].get('type') == 'text':
            line[-1]['val'] = str(line[-1]['val']).rstrip()
        while line and line[0].get('type') == 'text' and not str(line[0].get('val') or '').strip():
            line.pop(0)
        while line and line[-1].get('type') == 'text' and not str(line[-1].get('val') or '').strip():
            line.pop()
        for item in line:
            if item.get('type') == 'text':
                item['w'] = _measure_text_cached(str(item.get('val') or ''), font_size, font_name, measure_layer, font_cache)
    lines = [line for line in lines if line]

    def _line_height(line):
        max_icon_h = max((float(item.get('icon_h', 0)) for item in line if item.get('type') == 'icon'), default=0.0)
        natural = max(float(font_size) + 5.0, max_icon_h + 12.0 if max_icon_h else float(font_size) + 5.0)
        try:
            requested = float(line_height or 0)
        except Exception:
            requested = 0.0
        return max(natural, requested) if requested > 0 else natural

    total_block_h = sum(_line_height(line) for line in lines)
    valign = str(vertical_align or "center").strip().lower()
    if valign == "top":
        current_y = start_y
    elif valign == "bottom":
        current_y = start_y + cell_height - total_block_h
    else:
        current_y = start_y + (cell_height - total_block_h) / 2

    for line in lines:
        line_h = _line_height(line)
        line_width = sum(item['w'] for item in line)
        align = str(alignment or "center").strip().lower()
        if align == "justify":
            align = "left"
        if align == "left":
            current_x = start_x
        elif align == "right":
            current_x = start_x + max_width - line_width
        else:
            current_x = start_x + (max_width - line_width) / 2
        line_mid = current_y + (line_h / 2)
        text_y = line_mid + (font_size * 0.35)

        grouped, txt_block = [], ""
        for item in line:
            if item['type'] == 'text':
                txt_block += item['val']
            else:
                if txt_block:
                    grouped.append({'type': 'text', 'val': txt_block})
                    txt_block = ""
                grouped.append(item)
        if txt_block:
            grouped.append({'type': 'text', 'val': txt_block})

        for item in grouped:
            if item['type'] == 'text':
                if item['val'].strip() != "":
                    layer_name = layer_name_prefix or f"R{row_idx+1}_{col_letter}"
                    _render_text_with_keyword_overlays(
                        parent_group, item['val'], font_size, font_name, text_color,
                        current_x, text_y, measure_layer, font_cache, keyword_colors,
                        f"{layer_name}_txt", app=app, line_height=line_height,
                        text_batch=text_batch
                    )
                current_x += _measure_text_cached(item['val'], font_size, font_name, measure_layer, font_cache)
            elif item['type'] == 'icon':
                current_x += gap_px
                new_icon = None
                resolved_icon_h = float(item.get('icon_h', icon_h))
                scale_pct = (resolved_icon_h / icon_cache[item['val']]['orig_h']) * 100
                target_x = current_x
                target_y = line_mid - (resolved_icon_h / 2) + icon_y_offset
                if icon_dup_batch is not None:
                    _icon_entry = icon_cache[item['val']]
                    icon_dup_batch.append({
                        'src': _icon_entry['layer'],
                        'src_id': _icon_entry.get('id') or int(_icon_entry['layer'].id),
                        'group': parent_group,
                        'group_id': _icon_dup_group_id(icon_dup_groups, parent_group) if icon_dup_groups is not None else None,
                        'scale_pct': scale_pct,
                        'x': target_x,
                        'y': target_y,
                    })
                else:
                    _place_icon_duplicate_com(
                        icon_cache[item['val']]['layer'], parent_group, scale_pct, target_x, target_y
                    )
                current_x += (item['w'] - (gap_px * 2)) + gap_px
        current_y += line_h
