"""paylines_layout — the Paylines / Win Lines pages as canonical PageLayouts for the Canvas.

These pages have their own renderer (png_builder._render_paylines_png_pages → dynamic_pages/paylines.py:
one page per payline count, each line a little reel grid with its cells lit and a numbered badge). The
Canvas shows them like the Game / Bingo Rules pages (rules_layout.py): the renderer runs once inside
png_builder.line_sink(skip_text=True). The heading's lines are recorded and drawn by the Canvas as the
page heading (clicked, it is the Heading, as on every page); everything else the renderer draws — the
grids, the lit cells, the badges and their numbers (drawn on purpose: `_sink_ctx(draw=True)`) — is each
page's picture, exactly the build's pixels, drawn on the Canvas's background.

Where the lines landed (paylines.render_pages meta["pages"]) rides along as "paylines": the Canvas's
handles (paylines_canvas.js) move and size the block, the grid and the badges from it.
"""

from __future__ import annotations

from .page_layout import ImageElement, PageLayout, TextElement


def heading_element(lines, margin_x):
    """The page heading (its sunk lines, ctx kind "heading") as a TextElement, or None."""
    heading = [ln for ln in lines if (ln.get("ctx") or {}).get("kind") == "heading"]
    if not heading:
        return None
    h0 = heading[0]
    return TextElement(
        element_id="heading", x=h0["box_x"], y=h0["y"], width=h0["box_w"],
        height=heading[-1]["y"] + heading[-1]["h"] - h0["y"],
        text=" ".join(ln["text"] for ln in heading), font=h0["font"], size=h0["size"], bold=True,
        color=h0["color"], align=h0["align"], line_spacing=h0["spacing"], icon_height=h0["icon_h"],
        icon_gap_left=h0["gap_l"], icon_gap_right=h0["gap_r"],
        wrapped_lines=[ln["text"] for ln in heading], line_heights=[ln["h"] for ln in heading],
        line_widths=[ln["w"] for ln in heading], line_runs=[ln["runs"] for ln in heading],
        effects=dict(h0["fx"] or {}), style_role="Heading",
        meta={"kind": "heading", "page": 1, "tracking": h0["tracking"]},
    )


def build_layout(page_info, lines, index, sheet_name, canvas_w, canvas_h, margin_x, decor_url="", decor_box=None):
    """One payline page's PageLayout: its picture (grids, cells, badges, numbers) and its heading."""
    layout = PageLayout(
        source={"sheet_name": sheet_name, "page_index": index, "layout_mode": "paylines",
                "page_name": page_info.get("name", ""), "count": page_info.get("count"), "on": bool(page_info.get("on", True))},
        canvas={"width": canvas_w, "height": canvas_h},
        safe_area={"left": margin_x, "top": 0, "width": max(0.0, canvas_w - 2 * margin_x), "height": canvas_h, "bottom": canvas_h},
        margins={"margin_x": margin_x},
    )
    if decor_url:
        bx, by, bw, bh = decor_box or (0, 0, canvas_w, canvas_h)
        layout.add(ImageElement(element_id=f"paylines_decor_{index}", x=bx, y=by, width=bw, height=bh,
                                style_role="Decor", meta={"kind": "picture", "url": decor_url, "paylines": True}))
    head = heading_element(lines, margin_x)
    if head is not None:
        layout.add(head)
    return layout


def _page_report(info):
    """What the Canvas's handles need of one page (JSON-safe)."""
    keep = ("name", "denoms", "count", "key", "first", "last", "on", "heading_bottom", "warning", "cols", "nrows",
            "grid_w", "grid_h", "lines")
    out = {k: info.get(k) for k in keep}
    out["block"] = list(info["block"]) if info.get("block") else None
    return out


def layout_payload(render, sheet_name, canvas_w, canvas_h, margin_x, heading_top, register_preview=None, extra=None):
    """The /api/layout/preview payload of a payline sheet: one layout per page (built or not).

    render(meta) runs the renderer for every page of the sheet and returns ([(name, page)], warnings);
    it raises paylines.PaylineError when the Excel's lines are wrong — then the payload is still a page
    (the background, no lines) with the error, so the Canvas shows what to fix."""
    from . import png_builder, rules_layout
    from .dynamic_pages import paylines as pl

    meta = {}
    error, warnings, rendered = "", [], []
    with png_builder.line_sink(skip_text=True) as rec:
        try:
            rendered, warnings = render(meta)
        except pl.PaylineError as exc:
            error = str(exc)
    infos = meta.get("pages") or []
    sunk = rec["lines"]
    layouts = []
    for i, (info, (_name, page)) in enumerate(zip(infos, rendered)):
        end = infos[i + 1]["sunk_from"] if i + 1 < len(infos) else len(sunk)
        url, box = "", None
        if callable(register_preview):
            try:
                url, box = rules_layout._decor_url(page, register_preview)
            except Exception:
                url, box = "", None
        layouts.append(build_layout(info, sunk[info["sunk_from"]:end], i, sheet_name, canvas_w, canvas_h, margin_x, url, box))
    if not layouts:                                  # bad data: an empty page that says so
        layouts.append(PageLayout(source={"sheet_name": sheet_name, "page_index": 0, "layout_mode": "paylines"},
                                  canvas={"width": canvas_w, "height": canvas_h}, margins={"margin_x": margin_x}))
    lays = [lay.to_dict() for lay in layouts]
    report = {"pages": [_page_report(p) for p in infos], "error": error, "warnings": list(dict.fromkeys(warnings)),
              "canvas": [canvas_w, canvas_h], "margin_x": margin_x, "heading_top": heading_top}
    report.update(meta.get("data") or {})
    report.update(extra or {})
    return {
        "ok": True, "sheet_name": sheet_name, "mode": "canonical", "use_canonical_layout": True,
        "layouts": lays, "canvas": lays[0]["canvas"], "live_overrides": [],
        "paylines": report,
    }
