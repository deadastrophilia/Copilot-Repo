"""PsHelpScreenTool modular package."""
__version__ = "20-modular-cleanup-1"

# Only the AGR text inside each sheet's drawn frame reaches the tool (notes like
# "< modified 7/2/25" beside the box never render). See excel_frame.py.
try:
    from . import excel_frame as _excel_frame

    _excel_frame.install()
except Exception:                       # pragma: no cover - never block the tool from starting
    pass
