import re
from openpyxl.utils import get_column_letter, range_boundaries

from .excel_utils import get_excel_color, get_excel_fill_color

_MARKER_CELL_RE = re.compile(
    r"^(?:mod(?:ified|ify)?|update?d?|del(?:et?e)?d?|add(?:ed)?|remov(?:e|ed)|edit(?:ed)?|fix(?:ed)?)(?![a-z])",
    re.I,
)


_SENTENCE_END = (".", ":", "!", "?", "…")


def _sentence_like(text):
    """A sentence, not a label: at least three words, ending as a sentence ends (icon tags aside)."""
    plain = re.sub(r"<[^<>]*>", " ", str(text or "")).strip().rstrip("\"'”’)] ")
    return len(plain.split()) >= 3 and plain.endswith(_SENTENCE_END)


def _is_markerish(value):
    """Workflow-annotation cells that must never count as table content.

    Exact status tags, plus unclosed "<" annotations such as "<mod 3/10",
    "< Update" or "<del 1/4" (no closing '>'), which are editor notes, not
    content."""
    raw = str(value or "").strip()
    if not raw:
        return False
    low = raw.casefold()
    if low.rstrip(">") in {
        "<<modified", "<modified>", "<modified", "<removed>", "<removed",
        "<added>", "<deleted>", "modified", "removed", "added", "deleted",
    }:
        return True
    if raw.startswith("<") and ">" not in raw:
        return bool(_MARKER_CELL_RE.match(raw[1:].lstrip()))
    return False


def _clean_table_value(value):
    if value is None:
        return ""
    return str(value).strip()


def _is_table_status_tag(value):
    cleaned = _clean_table_value(value).casefold()
    return cleaned in {
        "<<modified", "<modified>", "<removed>", "<added>", "<deleted>",
        "modified", "removed", "added", "deleted",
    }


def _has_visible_border(cell):
    if not cell.border:
        return False
    for side in ("left", "right", "top", "bottom"):
        border_side = getattr(cell.border, side)
        if border_side and border_side.style and str(border_side.style).lower() not in ("none",):
            return True
    return False


def _manual_cell_meta(cell):
    value = _clean_table_value(cell.value)
    if not value or _is_table_status_tag(value) or _is_markerish(value):
        return None
    return {
        "value": value,
        "col_letter": get_column_letter(cell.column),
        "is_bold": bool(cell.font and cell.font.bold),
        "color": get_excel_color(cell),
        "fill_color": get_excel_fill_color(cell),
    }


def _merged_indexes_for_sheet(ws, max_col_limit=100, min_col_limit=1):
    lookup = {}
    starts = {}
    try:
        merged_ranges = list(ws.merged_cells.ranges)
    except Exception:
        merged_ranges = []
    for merged in merged_ranges:
        min_c, min_r, max_c, max_r = merged.bounds
        if min_c > max_col_limit or max_c < min_col_limit:
            continue
        min_c = max(min_c, min_col_limit)
        max_c = min(max_c, max_col_limit)
        span = (min_r, min_c, max_r, max_c)
        starts[(min_r, min_c)] = span
        for row_idx in range(min_r, max_r + 1):
            for col_idx in range(min_c, max_c + 1):
                lookup[(row_idx, col_idx)] = span
    return lookup, starts


def manual_table_from_range(ws, range_ref, max_col_limit=100):
    """Build an exact table model from a user-provided Excel range."""
    try:
        min_c, min_r, max_c, max_r = range_boundaries(str(range_ref or "").strip())
    except Exception:
        return None
    if min_c > max_c:
        min_c, max_c = max_c, min_c
    if min_r > max_r:
        min_r, max_r = max_r, min_r
    max_c = min(max_c, max_col_limit)
    if min_c > max_c or min_r > max_r or (max_c - min_c + 1) < 2 or (max_r - min_r + 1) < 2:
        return None

    merge_lookup, _merge_starts = _merged_indexes_for_sheet(ws, max_col_limit)
    table_cells = {}
    border_cells = set()
    for row_idx in range(min_r, max_r + 1):
        for col_idx in range(min_c, max_c + 1):
            cell = ws.cell(row=row_idx, column=col_idx)
            if _has_visible_border(cell):
                border_cells.add((row_idx, col_idx))
            meta = _manual_cell_meta(cell)
            if meta:
                table_cells[(row_idx, col_idx)] = meta

    if not table_cells:
        return None

    content_rows = sorted({row_idx for row_idx, _col_idx in table_cells})
    header_row_idx = content_rows[0]
    header_row_indices = [header_row_idx]
    header_set = set(header_row_indices)
    columns = [(get_column_letter(col_idx), col_idx) for col_idx in range(min_c, max_c + 1)]

    header_data = {}
    for col_idx in range(min_c, max_c + 1):
        meta = table_cells.get((header_row_idx, col_idx))
        if meta:
            header_data[col_idx] = meta["value"]

    data_rows = []
    data_row_indices = []
    for row_idx in range(min_r, max_r + 1):
        if row_idx in header_set:
            continue
        row_dict = {}
        for col_idx in range(min_c, max_c + 1):
            meta = table_cells.get((row_idx, col_idx))
            if meta:
                row_dict[col_idx] = meta["value"]
        if row_dict:
            data_rows.append(row_dict)
            data_row_indices.append(row_idx)

    cell_colors = {}
    cell_fill_colors = {}
    for coord, meta in table_cells.items():
        if meta["color"] is not None:
            cell_colors[coord] = meta["color"]
        if meta.get("fill_color") is not None:
            cell_fill_colors[coord] = meta["fill_color"]

    covered = set()
    grid_cells = []
    for row_idx in range(min_r, max_r + 1):
        for col_idx in range(min_c, max_c + 1):
            if (row_idx, col_idx) in covered:
                continue
            span = merge_lookup.get((row_idx, col_idx), (row_idx, col_idx, row_idx, col_idx))
            span_min_r, span_min_c, span_max_r, span_max_c = span
            if row_idx != span_min_r or col_idx != span_min_c:
                continue
            span_min_r = max(span_min_r, min_r)
            span_min_c = max(span_min_c, min_c)
            span_max_r = min(span_max_r, max_r)
            span_max_c = min(span_max_c, max_c)
            for rr in range(span_min_r, span_max_r + 1):
                for cc in range(span_min_c, span_max_c + 1):
                    if (rr, cc) != (row_idx, col_idx):
                        covered.add((rr, cc))

            meta = table_cells.get((row_idx, col_idx), {})
            grid_cells.append({
                "row": row_idx,
                "col": col_idx,
                "row_pos": row_idx - min_r,
                "col_pos": col_idx - min_c,
                "rowspan": max(1, span_max_r - span_min_r + 1),
                "colspan": max(1, span_max_c - span_min_c + 1),
                "value": meta.get("value", ""),
                "is_bold": bool(meta.get("is_bold", False)),
                "color": meta.get("color"),
                "fill_color": meta.get("fill_color"),
                "role": "header" if row_idx in header_set else "body",
                "manual_range": str(range_ref or "").strip(),
            })

    return {
        "start_row": min_r,
        "end_row": max_r,
        "min_col": min_c,
        "max_col": max_c,
        "columns": columns,
        "row_indices": list(range(min_r, max_r + 1)),
        "header_row": header_data,
        "header_row_idx": header_row_idx,
        "header_row_indices": header_row_indices,
        "data_rows": data_rows,
        "excel_row_map": data_row_indices,
        "header_bold": any(table_cells.get((header_row_idx, col_idx), {}).get("is_bold", False)
                           for col_idx in range(min_c, max_c + 1)),
        "cell_colors": cell_colors,
        "cell_fill_colors": cell_fill_colors,
        "grid_mode": True,
        "grid_cells": grid_cells,
        "row_roles": {row_idx: ("header" if row_idx in header_set else "body")
                      for row_idx in range(min_r, max_r + 1)},
        "manual_range": str(range_ref or "").strip(),
        "manual_table": True,
    }


def manual_tables_from_ranges(ws, ranges, max_col_limit=100):
    tables = []
    for range_ref in ranges or []:
        table = manual_table_from_range(ws, range_ref, max_col_limit)
        if table:
            tables.append(table)
            print(
                f"[Manual Table] Rows {table['start_row']}-{table['end_row']}, "
                f"Cols {table['min_col']}-{table['max_col']} from {range_ref}"
            )
        else:
            print(f"[Manual Table] Ignored invalid/empty range: {range_ref}")
    tables.sort(key=lambda item: (item["start_row"], item["min_col"]))
    return tables


def detect_tables_in_sheet(ws, max_col_limit=100, min_col_limit=1):
    """Detect real bordered Excel table regions without swallowing page frames.

    Help-screen workbooks often use merged cells and large outer borders to define
    the printable page. Those are not tables. A real table is usually a compact
    band of consecutive rows with repeated bordered columns and multi-column
    content. This detector finds those dense row bands, trims away blank frame
    columns, and then emits the rich grid model used by the table renderer.

    When the border-driven pass finds no tables, an add-on fallback pass
    (_content_aligned_candidates) recovers style-free tables by column
    alignment. That pass never runs when bordered tables were already found,
    so it cannot change any existing detection result.
    """
    tables = []
    exclude_tags = {
        "<<modified", "<modified>", "<removed>", "<added>", "<deleted>",
        "modified", "removed", "added", "deleted",
    }

    def _clean_value(value):
        if value is None:
            return ""
        return str(value).strip()

    def _is_status_tag(value):
        return _clean_value(value).casefold() in exclude_tags

    def _has_visible_border(cell):
        if not cell.border:
            return False
        for side in ("left", "right", "top", "bottom"):
            border_side = getattr(cell.border, side)
            if border_side and border_side.style and str(border_side.style).lower() not in ("none",):
                return True
        return False

    def _cell_meta(cell):
        value = _clean_value(cell.value)
        if not value or _is_status_tag(value) or _is_markerish(value):
            return None
        return {
            "value": value,
            "col_letter": get_column_letter(cell.column),
            "is_bold": bool(cell.font and cell.font.bold),
            "color": get_excel_color(cell),
            "fill_color": get_excel_fill_color(cell),
        }

    def _merged_indexes():
        lookup = {}
        starts = {}
        try:
            merged_ranges = list(ws.merged_cells.ranges)
        except Exception:
            merged_ranges = []

        for merged in merged_ranges:
            min_c, min_r, max_c, max_r = merged.bounds
            if min_col_limit is not None and max_c < min_col_limit:
                continue
            if min_c > max_col_limit:
                continue
            if min_col_limit is not None:
                min_c = max(min_c, min_col_limit)
            max_c = min(max_c, max_col_limit)
            span = (min_r, min_c, max_r, max_c)
            starts[(min_r, min_c)] = span
            for row_idx in range(min_r, max_r + 1):
                for col_idx in range(min_c, max_c + 1):
                    lookup[(row_idx, col_idx)] = span
        return lookup, starts

    merge_lookup, merge_starts = _merged_indexes()

    border_cells = set()
    content_map = {}
    for row in ws.iter_rows(min_row=1, min_col=min_col_limit, max_col=max_col_limit):
        for cell in row:
            coord = (cell.row, cell.column)
            if _has_visible_border(cell):
                border_cells.add(coord)
            meta = _cell_meta(cell)
            if meta:
                content_map[coord] = meta

    if not border_cells:
        print("[Table Detection] No bordered cells found.")

    max_row = ws.max_row or 0
    max_col = min(ws.max_column or max_col_limit, max_col_limit)

    row_border_cols = {}
    row_content_cols = {}
    for row_idx in range(1, max_row + 1):
        bcols = sorted(
            col_idx for (r, col_idx) in border_cells
            if r == row_idx and min_col_limit <= col_idx <= max_col
        )
        ccols = sorted(
            col_idx for (r, col_idx) in content_map
            if r == row_idx and min_col_limit <= col_idx <= max_col
        )
        if bcols:
            row_border_cols[row_idx] = bcols
        if ccols:
            row_content_cols[row_idx] = ccols

    def _longest_contiguous_run(cols):
        if not cols:
            return 0
        longest = 1
        current = 1
        last = cols[0]
        for col_idx in cols[1:]:
            if col_idx == last + 1:
                current += 1
            else:
                longest = max(longest, current)
                current = 1
            last = col_idx
        return max(longest, current)

    def _row_is_dense(row_idx):
        bcols = row_border_cols.get(row_idx, [])
        ccols = row_content_cols.get(row_idx, [])
        longest = _longest_contiguous_run(bcols)

        # Three or more adjacent bordered cells is a strong grid signal. For
        # legacy two-column tables, allow a two-cell run only when that row has
        # content in at least two cells. This avoids page-frame text rows.
        if longest >= 3:
            return True
        return longest >= 2 and len(ccols) >= 2

    dense_rows = [row_idx for row_idx in range(1, max_row + 1) if _row_is_dense(row_idx)]

    row_bands = []
    idx = 0
    while idx < len(dense_rows):
        start = dense_rows[idx]
        end = start
        idx += 1
        while idx < len(dense_rows) and dense_rows[idx] == end + 1:
            end = dense_rows[idx]
            idx += 1
        if end - start + 1 >= 2:
            row_bands.append([start, end])

    def _overlap_width(a_min, a_max, b_min, b_max):
        return max(0, min(a_max, b_max) - max(a_min, b_min) + 1)

    def _expanded_content_columns(row_min, row_max, col_min, col_max):
        cols = set()
        rows = set()
        for (row_idx, col_idx), meta in content_map.items():
            if not (row_min <= row_idx <= row_max and col_min <= col_idx <= col_max):
                continue
            span = merge_lookup.get((row_idx, col_idx), (row_idx, col_idx, row_idx, col_idx))
            span_min_r, span_min_c, span_max_r, span_max_c = span
            if span_max_r < row_min or span_min_r > row_max or span_max_c < col_min or span_min_c > col_max:
                continue
            rows.add(row_idx)
            for cc in range(max(span_min_c, col_min), min(span_max_c, col_max) + 1):
                cols.add(cc)
        return rows, cols

    def _split_contiguous(cols):
        cols = sorted(set(cols))
        if not cols:
            return []
        ranges = []
        start = cols[0]
        end = start
        for col_idx in cols[1:]:
            if col_idx == end + 1:
                end = col_idx
            else:
                ranges.append((start, end))
                start = end = col_idx
        ranges.append((start, end))
        return ranges

    def _intro_text_marker(text):
        lowered = str(text or "").casefold()
        markers = (
            "table below",
            "below table",
            "defined below",
            "mentioned in below table",
            "per the table below",
            "as per the table below",
        )
        if any(marker in lowered for marker in markers):
            return True
        return "table" in lowered and any(marker in lowered for marker in ("are per", " is per", " as per"))

    def _looks_like_table_label_row(texts):
        texts = [str(text or "").strip() for text in texts if str(text or "").strip()]
        if not texts:
            return False
        lowered = " ".join(texts).casefold()
        if _intro_text_marker(lowered):
            return False
        avg_len = sum(len(text) for text in texts) / float(max(1, len(texts)))
        longest = max(len(text) for text in texts)
        return avg_len <= 40 and longest <= 60

    def _texts_in_row(row_idx, min_c, max_c):
        return [
            str(content_map[(row_idx, col_idx)].get("value") or "").strip()
            for col_idx in range(min_c, max_c + 1)
            if (row_idx, col_idx) in content_map
        ]

    def _is_sentence_row(row_idx, min_c, max_c):
        """One lone / merged text cell holding a sentence ("Possible prizes are shown below.") — body
        text that sits on or just above a table's top row, never the table's header."""
        texts = [t for t in _texts_in_row(row_idx, min_c, max_c) if t]
        return len(texts) == 1 and _sentence_like(texts[0])

    def _trim_candidate(row_min, row_max, col_min, col_max):
        content_rows, content_cols = _expanded_content_columns(row_min, row_max, col_min, col_max)
        if len(content_rows) < 2:
            return None
        if len(content_cols) < 2:
            # Compact reels-layout grids (e.g. "initial layout" diagrams) are
            # fully bordered but keep their text in a single column. Only
            # accept them when the box itself is small; wide rectangles with
            # a single content column are page frames, not tables. The exact
            # bordered box is returned — borderless title/header/label rows
            # around it belong to body flow, not to the table.
            box_w = col_max - col_min + 1
            box_h = row_max - row_min + 1
            if box_w < 3 or box_h > 40:
                return None
            return (row_min, row_max, col_min, col_max)

        trim_row_min = min(content_rows)
        trim_row_max = max(content_rows)
        trim_col_min = min(content_cols)
        trim_col_max = max(content_cols)

        # Bordered intro sentences such as "cash prizes are per table below"
        # often sit immediately above the real grid. They belong to body flow,
        # not to the table header.
        while trim_row_min < trim_row_max:
            first_texts = _texts_in_row(trim_row_min, trim_col_min, trim_col_max)
            if not first_texts or not _intro_text_marker(" ".join(first_texts)):
                break
            remaining_rows, remaining_cols = _expanded_content_columns(
                trim_row_min + 1, trim_row_max, trim_col_min, trim_col_max
            )
            if len(remaining_rows) < 2 or len(remaining_cols) < 2:
                break
            trim_row_min += 1

        # A lone sentence on the top row ("Possible letter prizes are shown below.") is body text above
        # the table, not its header: the table starts at the next row when that row is a real table row.
        while trim_row_min < trim_row_max and _is_sentence_row(trim_row_min, trim_col_min, trim_col_max):
            nxt = min((r for r in range(trim_row_min + 1, trim_row_max + 1) if _texts_in_row(r, trim_col_min, trim_col_max)),
                      default=None)
            remaining_rows, remaining_cols = _expanded_content_columns(
                nxt or trim_row_max, trim_row_max, trim_col_min, trim_col_max
            ) if nxt else (set(), set())
            if nxt is None or len(remaining_rows) < 2 or len(remaining_cols) < 2                     or len(_texts_in_row(nxt, trim_col_min, trim_col_max)) < 2:
                break
            trim_row_min = nxt

        # Preserve a merged/table title row immediately above the data band.
        if trim_row_min > row_min:
            prev_row = trim_row_min - 1
            prev_borders = [c for c in row_border_cols.get(prev_row, []) if trim_col_min <= c <= trim_col_max]
            prev_content_rows, prev_content_cols = _expanded_content_columns(prev_row, prev_row, col_min, col_max)
            prev_texts = _texts_in_row(prev_row, trim_col_min, trim_col_max)
            if (
                prev_borders
                and prev_content_cols
                and _overlap_width(min(prev_content_cols), max(prev_content_cols), trim_col_min, trim_col_max) >= 2
                and _looks_like_table_label_row(prev_texts)
                and not _is_sentence_row(prev_row, trim_col_min, trim_col_max)
            ):
                trim_row_min = prev_row

        # Trim blank page-frame columns at both sides, but keep columns covered by
        # merged headers because those define the real table width.
        if trim_col_max - trim_col_min + 1 < 2:
            return None

        # Some simple two-column tables have a header/label row directly above a
        # dense bordered body band. If that row has lighter borders or only text,
        # the dense-row scan can start at the first body row, causing values like
        # "Boardwalk / 1500" to be styled as the header. Pull in a short,
        # column-aligned label row immediately above the candidate.
        prev_row = trim_row_min - 1
        if prev_row >= 1:
            prev_rows, prev_cols = _expanded_content_columns(prev_row, prev_row, col_min, col_max)
            prev_texts = _texts_in_row(prev_row, trim_col_min, trim_col_max)
            overlap = _overlap_width(
                min(prev_cols), max(prev_cols), trim_col_min, trim_col_max
            ) if prev_cols else 0
            prev_borders = [
                col_idx for col_idx in row_border_cols.get(prev_row, [])
                if trim_col_min <= col_idx <= trim_col_max
            ]
            lowered = " ".join(prev_texts).casefold()
            value_markers = (" or more", "reels ", "mini bonus", "repeat win", "credit prizes with value")
            avg_len = sum(len(text) for text in prev_texts) / float(max(1, len(prev_texts)))
            if (
                prev_rows
                and len(prev_texts) >= 2
                and overlap >= min(2, trim_col_max - trim_col_min + 1)
                and (prev_borders or avg_len <= 32)
                and "<" not in lowered
                and not any(marker in lowered for marker in value_markers)
                and _looks_like_table_label_row(prev_texts)
                and avg_len <= 40
            ):
                trim_row_min = prev_row

        # Header row two-up with a blank gap row: some sheets keep the table
        # header on a fully bordered row that is separated from the dense body
        # band by an empty annotation row (e.g. a "< Update" marker column).
        # Walk up at most 2 rows; the intermediate row must be empty inside
        # the candidate columns and the header row must be bordered and short.
        if trim_row_min - 2 >= 1:
            gap_row = trim_row_min - 1
            header_row = trim_row_min - 2
            header_content_rows, _unused = _expanded_content_columns(
                header_row, header_row, trim_col_min, trim_col_max
            )
            header_texts = _texts_in_row(header_row, trim_col_min, trim_col_max)
            header_borders = [
                c for c in row_border_cols.get(header_row, [])
                if trim_col_min <= c <= trim_col_max
            ]
            if (
                not _expanded_content_columns(gap_row, gap_row, trim_col_min, trim_col_max)[0]
                and header_content_rows
                and len(header_texts) >= 2
                and len(header_borders) >= 2
                and "<" not in " ".join(header_texts).casefold()
                and _looks_like_table_label_row(header_texts)
            ):
                trim_row_min = header_row

        return trim_row_min, trim_row_max, trim_col_min, trim_col_max

    def _candidate_border_cells(row_min, row_max, col_min, col_max):
        return {
            (r, c)
            for (r, c) in border_cells
            if row_min <= r <= row_max and col_min <= c <= col_max
        }

    def _looks_like_table(row_min, row_max, col_min, col_max):
        width = col_max - col_min + 1
        height = row_max - row_min + 1
        if width < 2 or height < 2:
            return False

        candidate_borders = _candidate_border_cells(row_min, row_max, col_min, col_max)
        if not candidate_borders:
            return False
        density = len(candidate_borders) / float(max(width * height, 1))

        content_rows, content_cols = _expanded_content_columns(row_min, row_max, col_min, col_max)
        rows_with_content = len(content_rows)
        cols_with_content = len(content_cols)
        if rows_with_content < 2:
            return False
        if cols_with_content < 2 and not (width <= 12 and height <= 40):
            return False

        rows_with_multi_border = 0
        for row_idx in range(row_min, row_max + 1):
            bcols = [c for c in row_border_cols.get(row_idx, []) if col_min <= c <= col_max]
            if _longest_contiguous_run(bcols) >= min(3, width):
                rows_with_multi_border += 1

        if rows_with_multi_border < 2:
            return False

        # Huge sparse rectangles are almost always page frames, not tables.
        if width >= 8 and height >= 8 and density < 0.18:
            return False

        return True

    candidates = []
    for row_min, row_max in row_bands:
        candidate_cols = set()
        for row_idx in range(row_min, row_max + 1):
            candidate_cols.update(row_border_cols.get(row_idx, []))

        for col_min, col_max in _split_contiguous(candidate_cols):
            if col_max - col_min + 1 < 2:
                continue
            trimmed = _trim_candidate(row_min, row_max, col_min, col_max)
            if not trimmed:
                continue
            trim_row_min, trim_row_max, trim_col_min, trim_col_max = trimmed
            if not _looks_like_table(trim_row_min, trim_row_max, trim_col_min, trim_col_max):
                continue
            candidates.append((trim_row_min, trim_row_max, trim_col_min, trim_col_max))

    # Remove duplicate/nested candidates. Prefer the larger, earlier rectangle.
    unique = []
    for candidate in sorted(set(candidates), key=lambda item: (item[0], item[2], -(item[1] - item[0] + 1) * (item[3] - item[2] + 1))):
        r1, r2, c1, c2 = candidate
        contained = False
        for kept in unique:
            kr1, kr2, kc1, kc2 = kept
            if kr1 <= r1 <= r2 <= kr2 and kc1 <= c1 <= c2 <= kc2:
                contained = True
                break
        if not contained:
            unique.append(candidate)

    def _row_has_content(row_idx, min_c, max_c):
        return any((row_idx, col_idx) in content_map for col_idx in range(min_c, max_c + 1))

    def _row_has_bold(row_idx, min_c, max_c):
        return any(content_map.get((row_idx, col_idx), {}).get("is_bold", False)
                   for col_idx in range(min_c, max_c + 1))

    def _row_has_span(row_idx, min_c, max_c):
        for col_idx in range(min_c, max_c + 1):
            span = merge_starts.get((row_idx, col_idx))
            if span:
                _, start_col, _, end_col = span
                if end_col > start_col:
                    return True
        return False

    def _row_has_vertical_span(row_idx, min_c, max_c):
        for col_idx in range(min_c, max_c + 1):
            span = merge_starts.get((row_idx, col_idx))
            if span:
                start_row, _, end_row, _ = span
                if start_row == row_idx and end_row > start_row:
                    return True
        return False

    def _row_content_count(row_idx, min_c, max_c):
        return sum(1 for col_idx in range(min_c, max_c + 1) if (row_idx, col_idx) in content_map)

    def _row_texts(row_idx, min_c, max_c):
        return _texts_in_row(row_idx, min_c, max_c)

    def _looks_like_followup_header(row_idx, min_r, max_r, min_c, max_c):
        # A second header row is useful for title + column-header layouts, but
        # only when there are real body rows after it.
        if row_idx >= max_r:
            return False
        if _row_has_vertical_span(row_idx, min_c, max_c):
            return False
        texts = _row_texts(row_idx, min_c, max_c)
        if not texts:
            return False
        width = max_c - min_c + 1
        if _row_content_count(row_idx, min_c, max_c) < max(2, min(width, 3)):
            return False
        lowered = " ".join(texts).casefold()
        # Rows that begin repeated data blocks or carry icon tokens should stay
        # body rows even if they sit directly under a merged title row.
        if "<" in lowered and ">" in lowered:
            return False
        value_markers = (" or more", "reels ", "mini bonus", "repeat win", "credit prizes with value")
        if any(marker in lowered for marker in value_markers):
            return False
        avg_len = sum(len(text) for text in texts) / float(max(1, len(texts)))
        return avg_len <= 36

    def _header_rows(min_r, max_r, min_c, max_c):
        content_rows = [row_idx for row_idx in range(min_r, max_r + 1) if _row_has_content(row_idx, min_c, max_c)]
        if not content_rows:
            return []
        first_row = content_rows[0]
        header_rows = [first_row]

        if _row_has_span(first_row, min_c, max_c):
            for row_idx in content_rows[1:]:
                if row_idx == first_row + 1 and _looks_like_followup_header(row_idx, min_r, max_r, min_c, max_c):
                    header_rows.append(row_idx)
                break
            return header_rows

        return header_rows

    def _content_aligned_candidates():
        """Addon fallback: detect style-free tables from column alignment.

        This pass only runs when the border-driven detection above found
        nothing, so existing detections are never affected. A table is a run
        of >= 3 rows whose content/border columns stay within one shared
        column set of >= 2 columns, with at most one blank row skipped.
        Merged text cells count as a single column and long merged prose is
        ignored, so paragraph blocks cannot form tables.
        """
        status_prefixes = ("<modified", "<removed", "<added", "<deleted")

        def _is_status_prefix(value):
            lowered = _clean_value(value).casefold()
            return any(lowered.startswith(prefix) for prefix in status_prefixes)

        # Help-screen sheets often draw a printable-page frame with borders:
        # full-width top/bottom rows and left/right edge columns. Those frame
        # cells must not count as table structure, or every row would look
        # aligned to the same wide column set.
        frame_col_counts = {}
        row_border_counts = {}
        for (row_idx, col_idx) in border_cells:
            frame_col_counts[col_idx] = frame_col_counts.get(col_idx, 0) + 1
            row_border_counts[row_idx] = row_border_counts.get(row_idx, 0) + 1
        frame_cols = {
            col_idx
            for col_idx, count in frame_col_counts.items()
            if count >= 0.6 * max(1, max_row)
        }
        sheet_width = max(1, max_col - min_col_limit + 1)
        frame_rows = {
            row_idx
            for row_idx, count in row_border_counts.items()
            if count >= 0.6 * sheet_width
        }

        def _row_cols(row_idx):
            cols = set()
            if row_idx in frame_rows:
                for col_idx in range(min_col_limit, max_col + 1):
                    meta = content_map.get((row_idx, col_idx))
                    if not meta or _is_status_prefix(meta["value"]):
                        continue
                    span = merge_lookup.get((row_idx, col_idx))
                    if span:
                        _, span_min_c, _, span_max_c = span
                        if span_max_c > span_min_c:
                            if len(meta["value"]) > 80:
                                continue
                            cols.add(span_min_c)
                            continue
                    cols.add(col_idx)
                return cols
            for col_idx in range(min_col_limit, max_col + 1):
                coord = (row_idx, col_idx)
                if coord in border_cells and col_idx not in frame_cols:
                    cols.add(col_idx)
                    continue
                meta = content_map.get(coord)
                if not meta:
                    continue
                if _is_status_prefix(meta["value"]):
                    continue
                span = merge_lookup.get(coord)
                if span:
                    _, span_min_c, _, span_max_c = span
                    if span_max_c > span_min_c:
                        if len(meta["value"]) > 80:
                            continue
                        cols.add(span_min_c)
                        continue
                cols.add(col_idx)
            return cols

        nonempty = []
        for row_idx in range(1, max_row + 1):
            cols = _row_cols(row_idx)
            if cols:
                nonempty.append((row_idx, cols))

        bands = []
        band_rows = []
        band_union = set()
        last_row = None
        for row_idx, cols in nonempty:
            if not band_rows:
                if len(cols) < 2:
                    continue
                band_rows = [row_idx]
                band_union = set(cols)
                last_row = row_idx
                continue
            if row_idx - last_row - 1 <= 1 and (
                cols <= band_union or len(cols & band_union) >= 2
            ):
                band_rows.append(row_idx)
                band_union |= cols
                last_row = row_idx
                continue
            bands.append((band_rows, band_union))
            if len(cols) < 2:
                band_rows = []
                band_union = set()
                last_row = None
                continue
            band_rows = [row_idx]
            band_union = set(cols)
            last_row = row_idx
        if band_rows:
            bands.append((band_rows, band_union))

        candidates = []
        used_rows = set()
        for band_rows, band_union in bands:
            if len(band_rows) < 3 or len(band_union) < 2:
                continue
            band_min_col = min(band_union)
            band_max_col = max(band_union)
            multi_col_rows = 0
            max_row_avg_len = 0.0
            for row_idx in band_rows:
                texts = _texts_in_row(row_idx, band_min_col, band_max_col)
                if texts:
                    row_avg_len = sum(len(text) for text in texts) / float(len(texts))
                    max_row_avg_len = max(max_row_avg_len, row_avg_len)
                row_cols = _row_cols(row_idx)
                if sum(1 for col in row_cols if band_min_col <= col <= band_max_col) >= 2:
                    multi_col_rows += 1
            if multi_col_rows < 2:
                continue
            if max_row_avg_len > 80:
                continue

            def _is_title_row(texts):
                texts = [str(t or "").strip() for t in texts if str(t or "").strip()]
                if not texts:
                    return False
                lowered = " ".join(texts).casefold()
                if _intro_text_marker(lowered):
                    return False
                avg_len = sum(len(t) for t in texts) / float(max(1, len(texts)))
                longest = max(len(t) for t in texts)
                return avg_len <= 60 and longest <= 80

            prev_row = band_rows[0] - 1
            if prev_row >= 1 and prev_row not in used_rows:
                prev_cols = _row_cols(prev_row)
                prev_texts = _texts_in_row(prev_row, band_min_col, band_max_col)
                if prev_cols and prev_cols <= band_union and _is_title_row(prev_texts)                         and not _is_sentence_row(prev_row, band_min_col, band_max_col):
                    band_rows = [prev_row] + band_rows

            # Header two-up with a blank gap row (mirror of the bordered pass).
            if band_rows[0] > 2 and band_rows[0] - 1 not in used_rows:
                gap_row = band_rows[0] - 1
                header_row = band_rows[0] - 2
                gap_in_band = [c for c in _row_cols(gap_row) if band_min_col <= c <= band_max_col]
                header_cols = _row_cols(header_row)
                header_texts = _texts_in_row(header_row, band_min_col, band_max_col)
                if (
                    header_row not in used_rows
                    and not gap_in_band
                    and len(header_texts) >= 2
                    and all(c in band_union for c in header_cols if band_min_col <= c <= band_max_col)
                    and "<" not in " ".join(header_texts).casefold()
                    and _is_title_row(header_texts)
                ):
                    band_rows = [header_row] + band_rows
            used_rows.update(band_rows)
            candidates.append((
                band_rows[0],
                band_rows[-1],
                band_min_col,
                band_max_col,
            ))
        return candidates

    if not unique:
        print("[Table Detection] No bordered tables; trying content-aligned fallback.")
        unique = _content_aligned_candidates()
        if unique:
            print(f"[Table Detection] Fallback found {len(unique)} table(s) by column alignment.")

    for min_r, max_r, min_c, max_c in unique:
        table_cells = {}
        for row_idx in range(min_r, max_r + 1):
            for col_idx in range(min_c, max_c + 1):
                meta = content_map.get((row_idx, col_idx))
                if meta:
                    table_cells[(row_idx, col_idx)] = meta

        if not table_cells:
            continue

        columns = [(get_column_letter(col_idx), col_idx) for col_idx in range(min_c, max_c + 1)]
        header_row_indices = _header_rows(min_r, max_r, min_c, max_c)
        header_set = set(header_row_indices)
        header_row_idx = header_row_indices[0] if header_row_indices else min_r

        header_data = {}
        for col_idx in range(min_c, max_c + 1):
            meta = table_cells.get((header_row_idx, col_idx))
            if meta:
                header_data[col_idx] = meta["value"]

        data_rows = []
        data_row_indices = []
        for row_idx in range(min_r, max_r + 1):
            if row_idx in header_set:
                continue
            row_dict = {}
            for col_idx in range(min_c, max_c + 1):
                meta = table_cells.get((row_idx, col_idx))
                if meta:
                    row_dict[col_idx] = meta["value"]
            if row_dict:
                data_rows.append(row_dict)
                data_row_indices.append(row_idx)

        cell_colors = {}
        cell_fill_colors = {}
        for coord, meta in table_cells.items():
            if meta["color"] is not None:
                cell_colors[coord] = meta["color"]
            if meta.get("fill_color") is not None:
                cell_fill_colors[coord] = meta["fill_color"]

        covered = set()
        grid_cells = []
        for row_idx in range(min_r, max_r + 1):
            for col_idx in range(min_c, max_c + 1):
                if (row_idx, col_idx) in covered:
                    continue
                span = merge_lookup.get((row_idx, col_idx), (row_idx, col_idx, row_idx, col_idx))
                span_min_r, span_min_c, span_max_r, span_max_c = span
                if row_idx != span_min_r or col_idx != span_min_c:
                    continue
                span_min_r = max(span_min_r, min_r)
                span_min_c = max(span_min_c, min_c)
                span_max_r = min(span_max_r, max_r)
                span_max_c = min(span_max_c, max_c)
                for rr in range(span_min_r, span_max_r + 1):
                    for cc in range(span_min_c, span_max_c + 1):
                        if (rr, cc) != (row_idx, col_idx):
                            covered.add((rr, cc))

                meta = table_cells.get((row_idx, col_idx), {})
                has_grid_cell = (
                    bool(meta.get("value")) or
                    (row_idx, col_idx) in border_cells or
                    span_max_r > span_min_r or
                    span_max_c > span_min_c
                )
                if not has_grid_cell:
                    continue
                grid_cells.append({
                    "row": row_idx,
                    "col": col_idx,
                    "row_pos": row_idx - min_r,
                    "col_pos": col_idx - min_c,
                    "rowspan": max(1, span_max_r - span_min_r + 1),
                    "colspan": max(1, span_max_c - span_min_c + 1),
                    "value": meta.get("value", ""),
                    "is_bold": bool(meta.get("is_bold", False)),
                    "color": meta.get("color"),
                    "fill_color": meta.get("fill_color"),
                    "role": "header" if row_idx in header_set else "body",
                })

        tables.append({
            "start_row": min_r,
            "end_row": max_r,
            "min_col": min_c,
            "max_col": max_c,
            "columns": columns,
            "row_indices": list(range(min_r, max_r + 1)),
            "header_row": header_data,
            "header_row_idx": header_row_idx,
            "header_row_indices": header_row_indices,
            "data_rows": data_rows,
            "excel_row_map": data_row_indices,
            "header_bold": any(_row_has_bold(row_idx, min_c, max_c) for row_idx in header_row_indices),
            "cell_colors": cell_colors,
            "cell_fill_colors": cell_fill_colors,
            "grid_mode": True,
            "grid_cells": grid_cells,
            "row_roles": {row_idx: ("header" if row_idx in header_set else "body")
                          for row_idx in range(min_r, max_r + 1)},
        })
        print(
            f"[Table Detected] Rows {min_r}-{max_r}, Cols {min_c}-{max_c}, "
            f"{len(data_rows)} data rows, {len(grid_cells)} grid cells"
        )

    tables.sort(key=lambda item: item["start_row"])
    print(f"[Table Detection] Total tables found: {len(tables)}")
    return tables
