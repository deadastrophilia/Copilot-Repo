import os

APP_TITLE = "PsHelpScreenTool"
SESSION_FILE = os.path.join(os.path.expanduser("~"), "PsHelpScreenTool_Session.json")

# ---------------------------------------------------------------------------
# Canonical layout pipeline feature flag.
#
# When True (default), the build pipeline MAY compute pages through
# layout_engine.py (PageLayout becomes the single source of truth shared by
# the live preview, PNG renderer and Photoshop renderer). The canonical path
# only activates for sheets whose features are fully modeled by PageLayout;
# every other sheet keeps the historical rendering paths untouched.
#
# When False, the application behaves exactly as before: no layout engine,
# no adapters, no PageLayout objects — all renderers use their historical
# code paths verbatim.
#
# The environment variable PSH_USE_CANONICAL_LAYOUT overrides this constant:
#   0 / false / off / no  -> disabled
#   1 / true  / on  / yes -> enabled
# ---------------------------------------------------------------------------
USE_CANONICAL_LAYOUT = True


def canonical_layout_enabled() -> bool:
    raw = (os.environ.get("PSH_USE_CANONICAL_LAYOUT") or "").strip().casefold()
    if raw in ("0", "false", "off", "no"):
        return False
    if raw in ("1", "true", "on", "yes"):
        return True
    return bool(USE_CANONICAL_LAYOUT)

# ---------------------------------------------------------------------------
# Photoshop heading compositing feature flag.
#
# When True, headings in the PNG renderer and the Live Preview are rendered
# through real Photoshop (temp document + text layer + the same layer styles
# the PSD renderer applies) and the resulting transparent PNG is alpha-
# composited onto the page. This gives pixel-perfect parity with Photoshop
# layer styles (stroke / shadow / glow / gradient / bevel / tracking).
#
# When False, the historical PIL heading rendering is used unchanged.
# The compositor is always optional: if Photoshop is not running / the render
# fails, the caller falls back to the existing drawing path, so this flag can
# never break a build.
#
# Environment override: PSH_USE_PHOTOSHOT_HEADING_COMPOSITING
#   0 / false / off / no  -> disabled
#   1 / true  / on  / yes -> enabled
# ---------------------------------------------------------------------------
USE_PHOTOSHOT_HEADING_COMPOSITING = True


def photoshop_heading_compositing_enabled() -> bool:
    raw = (os.environ.get("PSH_USE_PHOTOSHOT_HEADING_COMPOSITING") or "").strip().casefold()
    if raw in ("0", "false", "off", "no"):
        return False
    if raw in ("1", "true", "on", "yes"):
        return True
    return bool(USE_PHOTOSHOT_HEADING_COMPOSITING)

# ---------------------------------------------------------------------------
# Photoshop style-assets compositing feature flag.
#
# Generalizes the heading compositor to EVERY styled text element: elements
# whose layer style needs real Photoshop (captured byte-exact effects, pasted
# styles, or effects the PIL approximate renderer cannot reproduce faithfully)
# are rendered once in an isolated temporary Photoshop document and exported
# as a transparent PNG, then alpha-composited by the PNG renderer at the exact
# logical box the layout engine computed. Cached on a deterministic SHA-256
# key so 100 pages with 10 unique styled elements render 10 assets once.
#
# Safe by construction: when Photoshop is not running / the render fails the
# historical PIL path draws unchanged, so this flag can never break a build.
#
# OFF by default: the Photoshop-free effects engine (ps_fx_png on the server,
# ps_fx_canvas.js on the live canvas) renders every layer style, including
# gradient overlays, multiple strokes/shadows, satin and bevel & emboss.
# Photoshop is only used when the artist asks for it ("Verify in Photoshop",
# fx_verify.py) or when this flag is switched on explicitly.
#
# Environment override: PSH_USE_PHOTOSHOT_STYLE_ASSETS
#   0 / false / off / no  -> disabled
#   1 / true  / on  / yes -> enabled
# ---------------------------------------------------------------------------
USE_PHOTOSHOT_STYLE_ASSETS = False
_STYLE_ASSETS_OVERRIDE = None


def photoshop_style_assets_enabled() -> bool:
    global _STYLE_ASSETS_OVERRIDE
    if _STYLE_ASSETS_OVERRIDE is not None:
        return _STYLE_ASSETS_OVERRIDE
    raw = (os.environ.get("PSH_USE_PHOTOSHOT_STYLE_ASSETS") or "").strip().casefold()
    if raw in ("0", "false", "off", "no"):
        return False
    if raw in ("1", "true", "on", "yes"):
        return True
    return bool(USE_PHOTOSHOT_STYLE_ASSETS)


def set_photoshop_style_assets_enabled(value):
    """Process-wide override (used by tests and the debug/validation tooling)."""
    global _STYLE_ASSETS_OVERRIDE
    _STYLE_ASSETS_OVERRIDE = None if value is None else bool(value)

# ---------------------------------------------------------------------------
# Headless (PSAPI) rendering feature flag.
#
# When True, new PSD builds bypass Adobe Photoshop entirely and produce PSD
# files through the PSAPI library (headless, in-process Python). This is
# dramatically faster (~2-5s per page vs ~15-30s via Photoshop COM) but has
# some limitations: existing PSDs cannot be opened/updated, layer styles are
# limited, and table rendering uses a simplified path.
#
# Update-mode builds (editing an existing PSD) always fall back to the COM
# engine regardless of this flag.
#
# Environment override: PSH_USE_HEADLESS
#   0 / false / off / no  -> disabled (default)
#   1 / true  / on  / yes -> enabled
# ---------------------------------------------------------------------------
USE_HEADLESS = False


def headless_enabled() -> bool:
    raw = (os.environ.get("PSH_USE_HEADLESS") or "").strip().casefold()
    if raw in ("0", "false", "off", "no"):
        return False
    if raw in ("1", "true", "on", "yes"):
        return True
    return bool(USE_HEADLESS)


TABLE_DEFAULTS = {
    "overlay_opacity": 0,
    "header_bg_rgb": (20, 20, 30),
    "row1_bg_rgb": (35, 35, 50),
    "row2_bg_rgb": (28, 28, 42),
    "header_text_rgb": (255, 255, 255),
    "cell_padding_x": 10,
    "cell_padding_y": 5,
    "table_margin_x": 60,
    "table_width_pct": 85,
    "table_width_mode": "content",
    "table_target_width": 0,
    "border_rgb": (80, 80, 100),
    "border_width": 2,
    "header_font_size_delta": 4,
    "table_body_font_size_delta": 8,
    "render_mode": "both",
    "header_render_mode": "",
    "row1_render_mode": "",
    "row2_render_mode": "",
    "stroke_rgb": (255, 255, 255),
    "stroke_width": 2,
    "row_gap": 0,
    "after_table_margin": 30,
    "after_table_min_text_room": 70,
    "table_header_font_name": "",
    "table_body_font_name": "",
    "table_header_font_size": 0,
    "table_body_font_size": 0,
    "table_icon_height": 0,
    "table_icon_gap_left": 8,
    "table_icon_gap_right": 8,
    "table_target_height": 0,
    "table_header_line_height": 0,
    "table_body_line_height": 0,
    "row_height_multiplier": 1.2,
    "header_height_multiplier": 1.2,
    "table_body_text_rgb": None,
}

DEFAULT_KEYWORDS = {}
