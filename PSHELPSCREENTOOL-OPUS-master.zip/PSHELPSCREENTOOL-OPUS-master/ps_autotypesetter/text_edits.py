"""Text the artist edited on a preview (a line broken in two, two lines joined) — never written to Excel.

Stored in the session as ``dynamic_settings.text_edits``::

    {"<sheet>": {"row:12": {"from": "<the Excel text>", "to": "<the text to show>"},   # normal pages
                 "B25":    {"from": ..., "to": ...}}}                              # Game Rules cells

An edit applies only while the Excel still says ``from`` (whitespace ignored): when the document
changes, its own text comes back. ``to`` may hold line breaks ("\\n"); an empty ``to`` hides a row
(it was joined into the one above). Every reader of page text (the builds, the live window, the
thumbnails) goes through ``apply``.
"""
import contextlib
import contextvars
import re
import threading

_LOCK = threading.Lock()
_EDITS = {}
# the text being typed in a preview editor, not saved yet (one request lays the page out with it)
_DRAFT = contextvars.ContextVar("text_edits_draft", default=None)


_TAG = re.compile(r"<([^<>]*?)(?:~\d+(?:\.\d+)?(?:\^[\d.]+,[\d.]+)?|\^[\d.]+,[\d.]+)\s*>")


def _untag(text):
    """Icon size tags (icon_scales) never belong to an edit: '<WILD~140>' -> '<WILD>'."""
    return _TAG.sub(r"<\1>", str(text or ""))


def _norm(text):
    return re.sub(r"\s+", " ", _untag(text)).strip()


def _clean(edits):
    clean = {}
    for sheet, items in (edits or {}).items() if isinstance(edits, dict) else ():
        if isinstance(items, dict):
            clean[str(sheet)] = {str(k): v for k, v in items.items() if isinstance(v, dict) and "to" in v}
    return clean


def set_all(edits):
    """Use these edits from now on (the server calls this whenever the settings change)."""
    clean = _clean(edits)
    with _LOCK:
        _EDITS.clear()
        _EDITS.update(clean)


@contextlib.contextmanager
def draft(edits):
    """Inside this block, these edits (typed in a preview, not saved) win over the saved ones."""
    token = _DRAFT.set(_clean(edits) or None)
    try:
        yield
    finally:
        _DRAFT.reset(token)


def apply(sheet, key, text):
    """The text to show for this row / cell: the artist's edit while the Excel text is unchanged."""
    typed = _DRAFT.get()
    entry = typed.get(str(sheet), {}).get(str(key)) if typed else None
    if entry is None:
        entry = _EDITS.get(str(sheet), {}).get(str(key))
    if entry and _norm(entry.get("from")) == _norm(text):
        return _untag(entry.get("to") or "")
    return text
