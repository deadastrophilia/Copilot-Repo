import json
import os


def _escape_js_string(value):
    value = str(value or "")
    return value.replace("\\", "\\\\").replace('"', '\\"').replace("\r", "\\r").replace("\n", "\\n")


def _require_photoshop_document_path(path):
    """Validate that Custom Layout scanning/exporting is pointed at a PSD/PSB, not a PNG/JPG asset."""
    path = str(path or "").strip()
    if not path:
        raise ValueError("Select a PSD/PSB file first. This scanner works on Photoshop documents, not PNG/JPG assets.")
    ext = os.path.splitext(path)[1].lower()
    if ext not in (".psd", ".psb"):
        raise ValueError(
            "Custom Layouts can scan only Photoshop documents (.psd/.psb).\n"
            f"You selected: {os.path.basename(path) or path}"
        )
    if not os.path.exists(path):
        raise FileNotFoundError(f"PSD/PSB file not found:\n{path}")
    return path


def _run_jsx(jsx, error_prefix="Photoshop JSX failed"):
    # Any installed Photoshop version works: the bridge uses whichever one is open.
    from .photoshop_bridge import run_jsx

    try:
        return str(run_jsx(jsx) or "")
    except Exception as exc:
        raise RuntimeError(f"{error_prefix}:\n{exc}") from exc


def _load_exporter_jsx(psd_path="", group_path="", slot_prefix="@slot"):
    jsx_path = os.path.abspath(
        os.path.join(os.path.dirname(__file__), "jsx", "export_template_slots_DEBUG.jsx")
    )
    if not os.path.exists(jsx_path):
        raise FileNotFoundError(f"Missing JSX exporter file:\n{jsx_path}")

    with open(jsx_path, "r", encoding="utf-8") as f:
        body = f.read()

    prelude = (
        '$.global.PSHST_EXPORT_PSD_PATH = "' + _escape_js_string(psd_path) + '";\n'
        '$.global.PSHST_EXPORT_GROUP_PATH = "' + _escape_js_string(group_path) + '";\n'
        '$.global.PSHST_SLOT_PREFIX = "' + _escape_js_string(slot_prefix or "@slot") + '";\n'
        'if ($.global.PSHST_EXPORT_PSD_PATH) {\n'
        '  var __pshstFile = new File($.global.PSHST_EXPORT_PSD_PATH);\n'
        '  if (!__pshstFile.exists) { alert("PSD file does not exist:\\n" + __pshstFile.fsName); throw new Error("PSD_NOT_FOUND"); }\n'
        '  app.open(__pshstFile);\n'
        '}\n'
    )
    return prelude + body


def export_paytable_json_from_active_psd(slot_prefix="@slot"):
    """Run the generic slot exporter on the active PSD or active layer group."""
    return _run_jsx(_load_exporter_jsx(slot_prefix=slot_prefix), "Photoshop rejected the custom layout JSON exporter script")


def export_paytable_json_from_psd_group(psd_path, group_path, slot_prefix="@slot"):
    """Open the given PSD/PSB, scan only the selected group path, and ask where to save JSON."""
    psd_path = _require_photoshop_document_path(psd_path)
    if not group_path:
        raise ValueError("Select a group/page from the PSD first.")
    return _run_jsx(_load_exporter_jsx(psd_path, group_path, slot_prefix), "Photoshop rejected the selected-group custom layout JSON exporter script")


def export_table_slots_json(psd_path, preview_path="", slot_prefix="@table"):
    """Scan a PSD/PSB for @table.* slot layers and return the template JSON dict.

    Runs a dialog-free JSX inside Photoshop (which must be running), rasterizes
    a flattened copy to ``preview_path`` (optional), and returns the parsed
    template dict. Raises RuntimeError/ValueError on failure.
    """
    psd_path = _require_photoshop_document_path(psd_path)

    jsx_path = os.path.abspath(
        os.path.join(os.path.dirname(__file__), "jsx", "export_table_slots.jsx")
    )
    if not os.path.exists(jsx_path):
        raise FileNotFoundError(f"Missing JSX table scanner file:\n{jsx_path}")

    with open(jsx_path, "r", encoding="utf-8") as f:
        body = f.read()

    prelude = (
        '$.global.PSHST_EXPORT_PSD_PATH = "' + _escape_js_string(psd_path) + '";\n'
        '$.global.PSHST_SLOT_PREFIX = "' + _escape_js_string(slot_prefix or "@table") + '";\n'
        '$.global.PSHST_PREVIEW_PATH = "' + _escape_js_string(preview_path or "") + '";\n'
        'var __pshstFile = new File($.global.PSHST_EXPORT_PSD_PATH);\n'
        'if (!__pshstFile.exists) { throw new Error("PSD_NOT_FOUND"); }\n'
        'app.open(__pshstFile);\n'
    )

    result = _run_jsx(prelude + body, "Photoshop rejected the table slot scanner script")
    if result.startswith("ERROR:"):
        raise RuntimeError(result[len("ERROR:"):])
    try:
        return json.loads(result)
    except Exception as exc:
        raise RuntimeError(f"Table slot scanner returned unparseable output: {result[:200]}") from exc


def export_paytable_slots_from_active_document(slot_prefix="@slot"):
    """Dialog-free scan of the ACTIVE Photoshop document for @slot.* layers.

    Runs the same non-interactive table-slot scanner JSX as
    :func:`export_table_slots_json` but without opening a file — it reads the
    document that is currently open in Photoshop and returns the parsed
    template dict (canvas + slots). Raises RuntimeError/ValueError on failure.
    """
    jsx_path = os.path.abspath(
        os.path.join(os.path.dirname(__file__), "jsx", "export_table_slots.jsx")
    )
    if not os.path.exists(jsx_path):
        raise FileNotFoundError(f"Missing JSX table scanner file:\n{jsx_path}")

    with open(jsx_path, "r", encoding="utf-8") as f:
        body = f.read()

    prelude = (
        '$.global.PSHST_EXPORT_PSD_PATH = "";\n'
        '$.global.PSHST_SLOT_PREFIX = "' + _escape_js_string(slot_prefix or "@slot") + '";\n'
        '$.global.PSHST_PREVIEW_PATH = "";\n'
    )

    result = _run_jsx(prelude + body, "Photoshop rejected the table slot scanner script")
    if result.startswith("ERROR:"):
        raise RuntimeError(result[len("ERROR:"):])
    try:
        return json.loads(result)
    except Exception as exc:
        raise RuntimeError(f"Table slot scanner returned unparseable output: {result[:200]}") from exc


def list_psd_group_paths(psd_path=""):
    """Return all group paths from a PSD/PSB file. PSD is not saved or modified."""
    if not psd_path:
        raise ValueError("Browse/select a PSD/PSB file first. This avoids accidentally scanning the currently active PNG/JPG document in Photoshop.")
    psd_path = _require_photoshop_document_path(psd_path)

    open_line = ""
    if psd_path:
        open_line = (
            'var f = new File("' + _escape_js_string(psd_path) + '");\n'
            'if (!f.exists) { alert("PSD file does not exist:\\n" + f.fsName); return "ERROR:PSD_NOT_FOUND"; }\n'
            'app.open(f);\n'
        )

    jsx = r'''
(function () {
    function walkGroups(container, path, out) {
        try {
            var sets = container.layerSets;
            for (var i = 0; i < sets.length; i++) {
                var g = sets[i];
                var p = path ? (path + "/" + g.name) : String(g.name || "");
                out.push(p);
                walkGroups(g, p, out);
            }
        } catch (e) {}
    }
    try {
        __OPEN_LINE__
        if (!app.documents.length) {
            alert("Open a PSD first or select a PSD file.");
            return "ERROR:NO_DOCUMENT";
        }
        var groups = [];
        walkGroups(app.activeDocument, "", groups);
        return "GROUPS:\n" + groups.join("\n");
    } catch (err) {
        alert("Could not list PSD groups:\n" + err);
        return "ERROR:" + err;
    }
})();
'''.replace("__OPEN_LINE__", open_line)

    result = _run_jsx(jsx, "Photoshop rejected the group-list script")
    if result.startswith("GROUPS:\n"):
        lines = result.split("\n")[1:]
        return [line for line in lines if line.strip()]
    if result.startswith("ERROR"):
        raise RuntimeError(result)
    return []
