"""Clone a market: an artist's hand-made PSD for market A, filled with market B's Excel.

The markets of one game share one design; only the data differs. Instead of
rebuilding the design, the artist's own file is kept and only the text layers
that show Excel data get market B's values — every position, layer style,
picture, strip and page stays exactly as the artist made it.

  1. match   every text layer to the market A cells it shows (one cell, a
             column / row of cells, a whole row, or the closest wording);
             each page group is first pinned to the sheet most of its
             layers come from, so a lone "5" is looked for there.
  2. map     each market A cell to market B: the rows of the two sheets are
             aligned by content, so a row added in market B does not shift
             everything under it.
  3. write   changed layers are edited in place (artist_design/psd_reader
             never rebuilds the layer section — Photoshop refuses that), each
             character keeping the style it had where the text is unchanged.
  4. report  what changed, what was kept as design, what could not be told
             apart, text around icons that needs the artist, and market B
             rows nothing shows yet.
"""
import copy
import difflib
from collections import Counter
import os
import re

from openpyxl import load_workbook

# reading and comparing AGRs is shared with the rest of the tool (content_model / content_diff);
# the names stay importable from here
from . import binding, content_diff
from .content_diff import RowMap, WordMap, sheet_likeness, sheet_renames  # noqa: F401
from .content_diff import name_like as _name_like
from .content_model import (TOKEN as _TOKEN, Index, Sheet, Stream, cell_text, norm, read_workbook,  # noqa: F401
                            sym_key, token_for_name, tokens_in)
from .content_model import lines as _lines
from .content_model import word_key as _key


# ── 1. match layers to market A cells ─────────────────────────────────────────
def _runs_of_cells(index, lines, sheet=None):
    """Sources for a layer whose lines are consecutive cells (a pay column, a row of values)."""
    want = [norm(ln) for ln in lines if norm(ln)]
    if len(want) < 2:
        return []
    out = []
    for name, r, c in index.cell.get(want[0], []):
        if sheet and name != sheet:
            continue
        s = index.sheets[name]
        for dr, dc in ((1, 0), (0, 1)):
            refs, rr, cc, ok = [(name, r, c)], r, c, True
            for w in want[1:]:
                for _skip in range(4):                # blank cells between values are skipped
                    rr, cc = rr + dr, cc + dc
                    if (rr, cc) in s.cells:
                        break
                if norm(s.cells.get((rr, cc), "")) != w:
                    ok = False
                    break
                refs.append((name, rr, cc))
            if ok:
                out.append({"kind": "cells", "refs": refs})
    return out


def candidates(index, text, sheet=None):
    """Every way the layer's text can come from the workbook, best kind first."""
    n = norm(text)
    if not n:
        return []
    keep = (lambda name: name == sheet) if sheet else (lambda name: True)
    cells = [{"kind": "cell", "refs": [ref]} for ref in index.cell.get(n, []) if keep(ref[0])]
    cell_rows = {(ref[0], ref[1]) for ref in index.cell.get(n, [])}       # a row of one cell: that cell
    rows = [{"kind": "row", "refs": [(nm, r)]} for nm, r in index.row.get(n, []) if keep(nm) and (nm, r) not in cell_rows]
    runs = _runs_of_cells(index, _lines(text), sheet)
    return cells + runs + rows


def fuzzy(index, text, sheet=None, at_least=0.8):
    """The closest cell or row for prose the artist reworded slightly (line breaks, a typo)."""
    n = norm(text)
    if len(n) < 12:
        return None
    best = (0.0, None)
    for name, s in index.sheets.items():
        if sheet and name != sheet:
            continue
        pool = [({"kind": "cell", "refs": [(name, r, c)]}, norm(t)) for (r, c), t in s.cells.items() if len(t) >= 8]
        pool += [({"kind": "row", "refs": [(name, r)]}, norm(s.row_text(r))) for r in s.rows]
        for src, cand in pool:
            if not cand or min(len(cand), len(n)) / max(len(cand), len(n)) < at_least:
                continue
            sm = difflib.SequenceMatcher(None, cand, n, autojunk=False)
            if sm.real_quick_ratio() < best[0] or sm.quick_ratio() < best[0]:
                continue
            r = sm.ratio()
            if r > best[0]:
                best = (r, src)
    if best[0] >= at_least:
        return dict(best[1], score=round(best[0], 3))
    return None


def b_column(a, b, ra, rb, col):
    """The market B column of market A cell (ra, col), its row being rb in B. A row with as many
    filled cells in both is matched cell by cell in order — a market's Excel can have the table a
    column or two further over (JuCaiJin: the paytable moved two columns right, row by row) — else
    the same column."""
    cols_a, cols_b = a.row_cols(ra), b.row_cols(rb)
    if len(cols_a) == len(cols_b) and col in cols_a:
        return cols_b[cols_a.index(col)]
    return col


def target_of(src, sheets_b, rowmaps, sheets_a=None):
    """(text in market B, problem or None) for a matched source."""
    out = []
    for ref in src["refs"]:
        name = ref[0]
        b = sheets_b.get(name)
        if b is None:
            return None, f"sheet “{name}” is not in the new Excel"
        r = rowmaps[name].map.get(ref[1])
        if r is None:
            return None, f"row {ref[1]} of “{name}” has no matching row in the new Excel"
        if src["kind"] == "row":
            out.append(b.row_text(r))
        else:
            col = b_column(sheets_a[name], b, ref[1], r, ref[2]) if sheets_a and name in sheets_a else ref[2]
            out.append(b.cells.get((r, col), ""))
    return out, None


# ── 3. the new text, made from the artist's own text ──────────────────────────
_ICON_GAP = re.compile(r"[  ]{3,}")             # where the artist left room for an icon layer
_GROUPED = re.compile(r"^\d{1,3}(,\d{3})+(\.\d+)?$")


def _like(old, new):
    """`new` written the way the artist wrote `old` (1,250 keeps its comma grouping)."""
    if _GROUPED.match(old) and re.fullmatch(r"\d{4,}(\.\d+)?", new):
        whole, _, frac = new.partition(".")
        return f"{int(whole):,}" + ("." + frac if frac else "")
    return new


def word_diff(artist, text_a, text_b, icons=False):
    """The artist's text with market A's words changed into market B's, everything else kept
    (line breaks, icon gaps, spacing). Returns (text, why_not) — why_not when it can't be done
    safely: a change that would move text next to an icon the artist placed by hand (allowed with
    `icons`: the caller moves the icon's picture with the text, see follow_gaps)."""
    spans = [(m.start(), m.end(), m.group()) for m in re.finditer(r"\S+", artist)]
    wa = _TOKEN.sub(" ", str(text_a or "")).split()
    wb = _TOKEN.sub(" ", str(text_b or "")).split()
    keys = [_key(s[2]) for s in spans]
    if keys == [_key(w) for w in wb]:
        # the artist already typed the new wording (their PSD was made from a later text than the old
        # Excel): nothing to change — applying the old -> new difference again doubled words
        return artist, None
    ka, kb = [_key(w) for w in wa], [_key(w) for w in wb]
    if difflib.SequenceMatcher(None, keys, kb, autojunk=False).ratio() > \
            difflib.SequenceMatcher(None, keys, ka, autojunk=False).ratio():
        # the artist's text is nearer the new wording than the old one: lining the old words up
        # against it pairs the wrong words (a sentence lost, "the the the") — left as it is
        return None, "the artist's text is already closer to the new Excel than the old one — check it"
    pos = {}                                          # market A word -> artist word
    for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, [_key(w) for w in wa], [_key(s[2]) for s in spans],
                                                      autojunk=False).get_opcodes():
        if op == "equal" or (op == "replace" and i2 - i1 == j2 - j1):
            for k in range(i2 - i1):
                pos[i1 + k] = j1 + k
    edits = []
    for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, [_key(w) for w in wa], [_key(w) for w in wb],
                                                      autojunk=False).get_opcodes():
        if op == "equal":
            # the same word with new punctuation ("zones" -> "zones," once "randomly," went): taken
            # over when the artist had typed it as the old Excel did
            for k in range(i2 - i1):
                i, w = i1 + k, wb[j1 + k]
                if wa[i] != w and i in pos and spans[pos[i]][2] == wa[i]:
                    edits.append((spans[pos[i]][0], spans[pos[i]][1], _like(wa[i], w)))
            continue
        new_words = wb[j1:j2]
        if i2 > i1:
            if any(i not in pos for i in range(i1, i2)):
                return None, "the artist's wording differs from the Excel here"
            a, b = spans[pos[i1]][0], spans[pos[i2 - 1]][1]
            # new words the artist already has just after (or before) this spot are not typed twice
            first, last = pos[i1], pos[i2 - 1]
            while len(new_words) > 1 and last + 1 < len(keys) and _key(new_words[-1]) == keys[last + 1] \
                    and (i2 >= len(wa) or i2 not in pos or pos[i2] != last + 1):
                new_words = new_words[:-1]
                last += 1
            while len(new_words) > 1 and first > 0 and _key(new_words[0]) == keys[first - 1] \
                    and (i1 == 0 or (i1 - 1) not in pos or pos[i1 - 1] != first - 1):
                new_words = new_words[1:]
                first -= 1
            old_words = [s[2] for s in spans[pos[i1]:pos[i2 - 1] + 1]]
            if len(old_words) == len(new_words):
                new_words = [_like(o, n) for o, n in zip(old_words, new_words)]
            edits.append((a, b, " ".join(new_words)))
        else:                                         # words added in market B
            want = [_key(w) for w in new_words]
            if i1 > 0 and (i1 - 1) in pos:
                j = pos[i1 - 1] + 1
                if keys[j:j + len(want)] == want:     # the artist has these words here already
                    continue
                at = spans[pos[i1 - 1]][1]
                edits.append((at, at, " " + " ".join(new_words)))
            elif i1 in pos:
                j = pos[i1] - len(want)
                if j >= 0 and keys[j:pos[i1]] == want:
                    continue
                at = spans[pos[i1]][0]
                edits.append((at, at, " ".join(new_words) + " "))
            else:
                return None, "the artist's wording differs from the Excel here"
    out, cut = artist, []
    for a, b, rep in edits:
        line_a, line_b = artist.rfind("\r", 0, a) + 1, artist.find("\r", b)
        line_b = len(artist) if line_b < 0 else line_b
        if len(rep) != b - a and _ICON_GAP.search(artist[line_a:line_b]) and not icons:
            return None, "text next to an icon changed — the icon would not move with it"
        if _ICON_GAP.search(artist[a:b]):
            return None, "the change spans an icon"
        if not rep:                                   # words removed: their space goes too, and
            if not artist[line_a:a].strip() and not artist[b:line_b].strip():
                # a whole line (a removed sentence) goes with its line break: no blank line left
                a, b = (line_a, line_b + 1) if line_b < len(artist) else (max(0, line_a - 1), line_b)
            elif b < line_b and artist[b] == " ":
                b += 1
            elif a > line_a and artist[a - 1] == " ":
                a -= 1
        cut.append((a, b, rep))
    cut.sort()
    for n in range(1, len(cut)):                      # two removals sharing one space
        if cut[n][0] < cut[n - 1][1]:
            cut[n] = (cut[n - 1][1], max(cut[n][1], cut[n - 1][1]), cut[n][2])
    for a, b, rep in sorted(cut, reverse=True):
        out = out[:a] + rep + out[b:]
    return out, None


def lines_diffed(artist, a_values, b_values):
    """A column of cells: each of the artist's lines changed from its market A value into its market
    B value, word by word — a cell with icons keeps its icon gaps (never a literal "<gold_scat>").
    Returns (text, why_not)."""
    lines = _lines(artist)
    filled = [i for i, ln in enumerate(lines) if ln.strip()]
    if len(filled) != len(b_values) or len(a_values) != len(b_values):
        return None, "the values no longer line up with the artist's lines"
    for i, va, vb in zip(filled, a_values, b_values):
        if norm(va) == norm(vb) and tokens_in(va) == tokens_in(vb):
            continue
        new, why = word_diff(lines[i], va, vb, icons=True)
        if new is None:
            if _TOKEN.search(va + vb) or _ICON_GAP.search(lines[i].strip()) or len(vb.split()) > 1:
                return None, why
            ln = lines[i]                             # a lone value the artist wrote their own way
            new = ln[:len(ln) - len(ln.lstrip())] + _like(ln.strip(), vb) + ln[len(ln.rstrip()):]
        lines[i] = new
    return "\r".join(lines), None


def lines_replaced(artist, values):
    """A column / row of values: each of the artist's lines gets its new value, spacing kept."""
    lines = _lines(artist)
    filled = [i for i, ln in enumerate(lines) if ln.strip()]
    if len(filled) != len(values):
        return None
    for i, v in zip(filled, values):
        ln = lines[i]
        lead, tail = ln[:len(ln) - len(ln.lstrip())], ln[len(ln.rstrip()):]
        lines[i] = lead + _like(ln.strip(), v) + tail
    return "\r".join(lines)


# ── the plan ──────────────────────────────────────────────────────────────────
def _tops(psd):
    """The PSD's pages (and other top-level layers) as page keys number them: psd_render.page_tops —
    a group of pages (a game's pages in a multi-game PSD) counts as its pages."""
    from .artist_design import psd_render

    return psd_render.page_tops(psd)


def _pages(psd):
    """[(page name, [type layers])]: each page group is a page (top-level, or one of the pages a group
    of pages holds); loose text layers are "(document)"."""
    out, loose = [], []
    for n, top in enumerate(_tops(psd)):
        if top.is_group():
            layers = [l for l in top.descendants() if l.kind == "type"]
            if layers:
                name = re.sub(r"[\x00-\x1f]", "", top.name)  # Photoshop names can end in a NUL
                out.append((f"{n}", name, layers, top))       # page names can repeat: keyed by place
        elif top.kind == "type":
            loose.append(top)
    if loose:
        out.append(("doc", "(document)", loose, None))
    return out


def _sources(ia, streams, text, sheet):
    """Every place the layer's text can come from: whole cells / rows / columns of cells, then a
    stretch of a sheet's words (prose); only in `sheet` when the page is pinned to one."""
    keep = (lambda n: n == sheet) if sheet else (lambda n: True)
    out = candidates(ia, text, sheet)
    want = [_key(w) for w in _TOKEN.sub(" ", text).split()]
    want = [w for w in want if w]
    if len(want) >= 3 and not any(c["kind"] in ("cell", "row", "cells") for c in out):
        for name, st in streams.items():
            if keep(name):
                out += [{"kind": "words", "sheet": name, "span": (i, i + len(want))} for i in st.find(want)]
    return out


def _outcome(src, sheets_a, sheets_b, rowmaps, wordmaps):
    """(market A text(s), market B text(s), market B rows used, problem)."""
    if src["kind"] == "words":
        name, (i, j) = src["sheet"], src["span"]
        words = wordmaps[name].a.words
        whole = (i == 0 or words[i - 1][2] != words[i][2]) and (j >= len(words) or words[j][2] != words[j - 1][2])
        if whole and name in sheets_b:
            # whole rows: their market B text row for row (rows are matched by content); lining the
            # whole sheet up word by word can tie a phrase to the same phrase elsewhere and cut the
            # text short (JuCaiJin Mega Feature: "One of the Minor Bonus letters and" lost)
            # rows dropped in market B give nothing; rows it inserted among them are part of the text
            mapped = [rowmaps[name].map.get(r) for r in sorted({w[2] for w in words[i:j]})]
            mapped = [r for r in mapped if r is not None]
            if mapped:
                b = sheets_b[name]
                rows_b = [r for r in b.rows if min(mapped) <= r <= max(mapped)]
                return ([" ".join(w[1] for w in words[i:j])],
                        [" ".join(" ".join(_TOKEN.sub(" ", b.row_text(r)).split()) for r in rows_b)], set(rows_b), None)
        got = wordmaps[name].text(*src["span"])
        if got is None:
            return None, None, set(), f"“{src['sheet']}” has no matching text in the new Excel"
        return [got[0]], [got[1]], got[2], None
    vals, problem = target_of(src, sheets_b, rowmaps, sheets_a)
    if problem:
        return None, None, set(), problem
    a_vals = [(sheets_a[r[0]].row_text(r[1]) if src["kind"] == "row" else sheets_a[r[0]].cells.get((r[1], r[2]), ""))
              for r in src["refs"]]
    rows = {rowmaps[r[0]].map.get(r[1]) for r in src["refs"]} - {None}
    return a_vals, vals, rows, None


def _src_key(src):
    if src["kind"] == "words":
        return (src["sheet"], "words", src["span"])
    return tuple((r[0], r[1], r[2] if len(r) > 2 else None) for r in src["refs"])


def _content(src, sheets_b, rowmaps, streams, wordmaps, sheets_a=None):
    """What a matched layer shows, in both workbooks: {"kind", "a": refs in market A, "b": refs in
    market B or None when that content left the new AGR} — kept in the binding (binding.py)."""
    if src["kind"] == "words":
        name, (i, j) = src["sheet"], src["span"]
        b_sheet = sheets_b[name].name if name in sheets_b else None
        got = wordmaps[name].text(i, j) if name in wordmaps else None
        return {"kind": "words", "a": {"sheet": name, "rows": sorted({w[2] for w in streams[name].words[i:j]})},
                "b": {"sheet": b_sheet, "rows": sorted(got[2])} if b_sheet and got else None}
    name = src["refs"][0][0]
    rm = rowmaps.get(name)
    b_sheet = sheets_b[name].name if name in sheets_b else None
    rows_b = [rm.map.get(r[1]) if rm else None for r in src["refs"]]
    gone = b_sheet is None or None in rows_b
    if src["kind"] == "row":
        return {"kind": "row", "a": {"sheet": name, "rows": [r[1] for r in src["refs"]]},
                "b": None if gone else {"sheet": b_sheet, "rows": rows_b}}
    return {"kind": "cells", "a": {"sheet": name, "cells": [[r[1], r[2]] for r in src["refs"]]},
            "b": None if gone else {"sheet": b_sheet, "cells": [
                [rb, b_column(sheets_a[name], sheets_b[name], r[1], rb, r[2]) if sheets_a and name in sheets_a else r[2]]
                for rb, r in zip(rows_b, src["refs"])]}}


def _added_tokens(a_vals, vals):
    """Symbol tokens the new Excel has here that the old one hadn't (counted: a second <X> is added)."""
    had, out = Counter(t for v in a_vals for t in tokens_in(v)), []
    for t in (t for v in vals for t in tokens_in(v)):
        if had[t] > 0:
            had[t] -= 1
        else:
            out.append(t)
    return out


_SLOT = "qqsymbolslotqq"                              # a symbol the new Excel adds, as a word while texts are diffed


def _gap_of(n):
    """An icon gap n characters wide: no-break spaces inside, so a wrapping line never splits it."""
    n = max(3, int(n))
    return " " + chr(0xA0) * (n - 2) + " "


def _slotted(a_vals, vals):
    """`vals` with each symbol the new Excel adds (as _added_tokens counts them) a stand-in word."""
    had, out = Counter(t for v in a_vals for t in tokens_in(v)), []

    def put(m):
        t = m.group()[1:-1]
        if had[t] > 0:
            had[t] -= 1
            return m.group()
        return f" {_SLOT} "
    for v in vals:
        out.append(_TOKEN.sub(put, str(v or "")))
    return out


def _gapped(text, gap):
    """(text with each stand-in a gap, [(start, end)] of each gap) — the stand-in's spaces go too."""
    out, spans, pos = [], [], 0
    for m in re.finditer(rf"[ ]*{_SLOT}[ ]*", text):
        out.append(text[pos:m.start()])
        at = sum(len(s) for s in out)
        # at a line's start or end the gap needs no space on that side
        g = gap
        if m.start() == 0 or text[m.start() - 1] == "\r":
            g = g.lstrip(" ")
        if m.end() == len(text) or text[m.end()] == "\r":
            g = g.rstrip(" ")
        out.append(g)
        spans.append((at, at + len(g)))
        pos = m.end()
    out.append(text[pos:])
    return "".join(out), spans


def _decide(item, src, a_vals, vals):
    """Fill in what happens to the layer once its source is known."""
    old = item["old"]
    item["source"] = _ref_text(src)
    added = _added_tokens(a_vals, vals)
    if added:
        # (text is compared without its tokens: checked first, or a symbol added to an unchanged line
        # would be lost)
        names = ", ".join(f"<{t}>" for t in added)
        new, why = None, "add it by hand"
        if src["kind"] in ("cell", "cells", "row") and item.get("_gap"):
            # the artist's text changed as the Excel changed, each added symbol a word while diffing,
            # then a gap in its place (as wide as the artist's icon gaps) for its picture (place_symbols);
            # the artist's own icons move with the text (icon_edits, follow_gaps) or the layer is theirs
            slotted = _slotted(a_vals, vals)
            if src["kind"] == "cells":
                new, why = lines_diffed(old, a_vals, slotted)
            else:
                new, why = word_diff(old, a_vals[0], slotted[0], icons=True)
            if (new is None or new.count(_SLOT) != len(added)) and src["kind"] == "cell" and "\r" not in old.strip("\r"):
                new = " ".join(slotted[0].split())       # one line the artist wrote their own way: the new text
            if new is not None and new.count(_SLOT) != len(added):
                new, why = None, "add it by hand"
        if new is None:
            item.update(status="artist", new_excel=" / ".join(vals), added_symbols=added,
                        why=f"the new Excel adds {names} here — {why}")
            return
        new, spans = _gapped(new, item["_gap"])
        item.update(status="change", new=new, added_symbols=added, gap_spans=spans,
                    why=f"the new Excel adds {names} here — a gap was left for it: put the picture in")
        return
    if [norm(v) for v in a_vals] == [norm(v) for v in vals]:
        item["status"] = "same"
        return
    if src["kind"] == "cells":
        new, why = lines_diffed(old, a_vals, vals)
    else:
        new, why = word_diff(old, a_vals[0], vals[0], icons=True)
    if new is None:
        item.update(status="artist", why=why, new_excel=" / ".join(vals))
        return
    if new == old:                                    # the artist's text already says it
        item.update(status="same", why="already reads like the new Excel")
        return
    item.update(status="change", new=new)
    if src.get("score"):
        item["why"] = "the artist had reworded this text — check the new wording"


def page_link_key(page_key, page_name):
    return f"{page_key}|{str(page_name or '').strip()}"


def _linked_sheet(saved, page_key, page_name, sheets_a):
    """The sheet saved for this page in `saved` ({page key: sheet}; "" = not from the Excel), or None."""
    saved = saved or {}
    key = page_link_key(page_key, page_name)
    if key in saved:
        got = saved[key]
    else:                                             # the same page in another copy of the PSD: by its name
        same = [v for k, v in saved.items() if k.split("|", 1)[-1] == str(page_name or "").strip()]
        if len(same) != 1:
            return None
        got = same[0]
    return got if got == "" or got in sheets_a else None


def plan(psd, sheets_a, sheets_b, excel_a=None, icon_folder=None, links=None):
    """What to do with every text layer. Nothing is written. Look-alike pay columns are told apart by
    the symbol on their card, named from the PSD itself (see Symbols); `icon_folder` (the game's
    symbol pictures) is an extra, optional way. `links` is what the artist confirmed in the clone
    dialog: {"chosen": {page key: sheet} (the artist's choices: binding), "pages": {page key: sheet}
    (what the dialog showed: only for pages the tool can't place), "symbols": {picture signature: token}}."""
    ia = Index(sheets_a)
    place = {id(l): n for n, l in enumerate(psd.descendants())}   # layer ids can repeat: found by place
    rowmaps = {name: RowMap(s, sheets_b.get(name)) for name, s in sheets_a.items()}
    streams = {name: Stream(s) for name, s in sheets_a.items()}
    wordmaps = {name: WordMap(st, Stream(sheets_b[name]) if name in sheets_b else None) for name, st in streams.items()}
    pages = _pages(psd)
    texts, page_sheet, page_links = {}, {}, []
    for page, page_name, layers, _root in pages:      # pin the page to its sheet: unambiguous text votes
        votes, shared = {}, {}
        for l in layers:
            t = texts[id(l)] = str(l.text or "")
            sheets = {c.get("sheet") or c["refs"][0][0] for c in _sources(ia, streams, t, None)}
            for name in sheets:
                shared[name] = shared.get(name, 0) + len(norm(t))
            if len(sheets) == 1:
                name = next(iter(sheets))
                votes[name] = votes.get(name, 0) + len(norm(t))
        how, sheet = None, None
        if votes:
            sheet, how = max(votes, key=votes.get), "text"
        elif shared:
            # the same text is on several sheets (denom 1&2, 3&4, 5&6…): the page's name decides
            top = max(shared.values())
            tied = [n for n, v in shared.items() if v >= top * 0.9]
            sheet, how = max(tied, key=lambda n: _name_like(page_name, n)), ("name" if len(tied) > 1 else "text")
        # what the artist chose in the clone dialog binds ("chosen"); a link the dialog only showed
        # ("pages": what the tool had found, saved before choices were told apart) never outranks what
        # the tool finds in the Excel now — a sheet that left the AGR must be noticed — it only names a
        # page the tool can't place itself
        chosen = _linked_sheet((links or {}).get("chosen"), page, page_name, sheets_a)
        seen = _linked_sheet((links or {}).get("pages"), page, page_name, sheets_a)
        if chosen is not None:
            sheet, how = chosen or None, "link"
        elif seen is not None and not sheet:
            sheet, how = seen or None, "link"
        if sheet:
            page_sheet[page] = sheet
        score = {n: votes.get(n, 0) * 2 + shared.get(n, 0) for n in set(votes) | set(shared)}
        page_links.append({"page_key": page, "page": page_name, "key": page_link_key(page, page_name),
                           "sheet": sheet or "", "how": how or "none", "chosen": chosen is not None,
                           "likely": sorted(score, key=score.get, reverse=True)[:4]})
    off_excel = {p["page_key"] for p in page_links if p["how"] == "link" and not p["sheet"]}
    items, pending, claimed, used_rows = [], [], set(), {}
    roots = {}
    # the room the artist leaves for an icon (the commonest run of spaces in their text): the page's
    # own, else the PSD's; the gap is widened when the picture put in it is wider (add_symbol)
    all_runs = Counter(len(m.group()) for t in texts.values() for m in _ICON_GAP.finditer(t))
    for page, page_name, layers, root in pages:
        roots[page] = root
        sheet = page_sheet.get(page)
        runs = Counter(len(m.group()) for l in layers for m in _ICON_GAP.finditer(texts[id(l)])) or all_runs
        gap = _gap_of(runs.most_common(1)[0][0] if runs else 3)
        for l in layers:
            old = texts[id(l)]
            item = {"page": page_name, "page_key": page, "layer": l.name, "layer_id": l.layer_id, "place": place[id(l)], "old": old, "sheet": sheet, "_gap": gap,
                    "top": l.top, "left": l.left, "_layer": l}
            items.append(item)
            if not norm(old):
                item["status"] = "empty"
                continue
            if page in off_excel:
                item.update(status="design", why="this page is not from the Excel (as chosen in the clone dialog)")
                continue
            cs = (_sources(ia, streams, old, sheet) if sheet else []) or _sources(ia, streams, old, None)
            if not cs:
                want = [w for w in (_key(x) for x in _TOKEN.sub(" ", old).split()) if w]
                for name, st in streams.items():
                    if len(want) >= 4 and (not sheet or name == sheet):
                        got = st.near(want)
                        if got and (not cs or got[2] > cs[0]["score"]):
                            cs = [{"kind": "words", "sheet": name, "span": got[:2], "score": round(got[2], 3)}]
            if not cs:
                if not _by_paragraph(item, ia, streams, sheet, sheets_a, sheets_b, rowmaps, wordmaps, claimed, used_rows):
                    item.update(status="design", why="no Excel text like this — kept as design")
                continue
            outs = [(c,) + _outcome(c, sheets_a, sheets_b, rowmaps, wordmaps) for c in cs]
            good = [o for o in outs if o[4] is None]
            if not good:
                item.update(status="missing", why=outs[0][4], source=_ref_text(outs[0][0]))
                continue
            if len({tuple(norm(v) for v in o[2]) for o in good}) > 1:
                pending.append((item, good))          # decided below, once the clear ones are claimed
                continue
            c, a_vals, vals, rows, _ = good[0]
            claimed.add(_src_key(c))
            for r in rows:
                used_rows.setdefault(c.get("sheet") or c["refs"][0][0], set()).add(r)
            _decide(item, c, a_vals, vals)
            item["_src"] = c
            item["content"] = _content(c, sheets_b, rowmaps, streams, wordmaps, sheets_a)
            item["rows_b"] = sorted(rows)                 # the new sheet's rows this layer shows
            if len(good) > 1:                             # e.g. "5 / 4 / 3" on every card: same either way
                item["_multi"] = True
                item["source"] += f" (+{len(good) - 1} more places, all the same)"
    # ── the symbols, named from the PSD itself ──
    symbols = Symbols(psd, sheets_a, links, sheets_b)
    for page, _n, _l, root in pages:
        sh = page_sheet.get(page)
        if root is not None and sh in sheets_a:
            symbols.learn_rows(root, sheets_a[sh].cells)
    cards = Cards(excel_a, icon_folder) if excel_a else None
    page_images = {}

    def images(key):
        if key not in page_images:
            page_images[key] = _page_images(roots[key]) if roots.get(key) is not None else []
        return page_images[key]

    def owner_of(src):
        if cards is None or src is None or src["kind"] not in ("cells", "cell"):
            return None
        ref = src["refs"][0]
        tok = cards.owner(ref[0], ref[1], ref[2])
        return symbols.tokens.get(sym_key(tok), str(tok).strip("<>")) if tok else None

    # a pay column on one card only names the picture above it (and its card)
    for item in items:
        tok = None if item.get("_multi") else owner_of(item.get("_src"))
        if tok:
            pic = cards.picture_above(item["_layer"], images(item["page_key"]))
            item["_card"] = (pic, tok)
            if pic is not None:
                symbols.cards.add(symbols.sig(pic))
                symbols.add(symbols.sig(pic), tok, "card")

    # look-alike layers ("50 / 10 / 5" on several pay cards): among the sources nobody else shows,
    # the one whose symbol is the picture on this layer's card (never a guess by position)
    def _overlaps(c):
        if c["kind"] == "words":
            return False
        cells = {(r[0], r[1], r[2] if len(r) > 2 else None) for r in c["refs"]}
        return any(cells & set(k) for k in claimed if k and k[0] != "words" and isinstance(k[0], tuple))

    def neighbour(item, pic):
        """The card of a column beside this one (the pays next to the counts), when that one is known."""
        l, best = item["_layer"], None
        for other in items:
            got = other.get("_card")
            if not got or other["page_key"] != item["page_key"] or other is item:
                continue
            if pic is not None and got[0] is pic:
                return got[1]
            if pic is not None and got[0] is not None:
                continue                              # under another card's symbol
            o = other["_layer"]
            gap = max(o.left - l.right, l.left - o.right)
            if abs(o.top - l.top) <= 12 and abs(o.bottom - l.bottom) <= max(30, (l.bottom - l.top) * 0.25) \
                    and gap <= max(l.width, o.width, 1) * 3 and (best is None or gap < best[0]):
                best = (gap, got[1])
        return best[1] if best else None

    left, later = list(pending), []
    for _round in range(2):                           # a card told apart can tell its neighbour apart
        later = []
        for item, good in left:
            free = [o for o in good if _src_key(o[0]) not in claimed and not _overlaps(o[0])] or good
            pick, how = None, ""
            if len({tuple(norm(v) for v in o[2]) for o in free}) == 1:
                pick, how = free[0], ""               # the cards nobody else shows all say the same
            elif cards and all(o[0]["kind"] in ("cells", "cell") for o in free):
                owners = {}
                for o in free:
                    owners.setdefault(owner_of(o[0]), []).append(o)
                if None not in owners:
                    pic = cards.picture_above(item["_layer"], images(item["page_key"]))
                    if pic is not None:
                        symbols.cards.add(symbols.sig(pic))
                        item["_pic"] = pic
                    token, how = symbols.token(pic), "card told apart by its symbol"
                    if token not in owners:
                        token, how = neighbour(item, pic), "card told apart by the column beside it"
                    if token not in owners and icon_folder:
                        token, how = cards.which(pic, list(owners)), "card told apart by its symbol picture"
                        if token and pic is not None:
                            symbols.add(symbols.sig(pic), token, "folder")
                    if token in owners and len(owners[token]) == 1:
                        pick = owners[token][0]
                        item["_card"] = (pic, token)
            if pick is None:
                later.append((item, good, free))
                continue
            c, a_vals, vals, rows, _ = pick
            claimed.add(_src_key(c))
            _decide(item, c, a_vals, vals)
            item["_src"] = c
            item["content"] = _content(c, sheets_b, rowmaps, streams, wordmaps, sheets_a)
            item["rows_b"] = sorted(rows)
            if how:
                item["why"] = (item.get("why") + " · " if item.get("why") else "") + how
        left = [(i, g) for i, g, _f in later]
        if not later:
            break
    for item, good, free in later:
        if item.get("_pic") is not None:
            symbols.needed.add(symbols.sig(item["_pic"]))
        item.update(status="ambiguous",
                    why="the same text is on several cards — can't tell which one this is"
                        " (name the card's symbol under Symbols in the clone dialog)",
                    source=", ".join(_ref_text(o[0]) for o in free[:4]))
    new_content = []
    for name, rm in rowmaps.items():
        b = sheets_b.get(name)
        if b is None or name not in page_sheet.values():
            continue
        for r in rm.new_rows:
            if r not in used_rows.get(name, set()):
                new_content.append({"sheet": name, "row": r, "text": b.row_text(r)})
    missing_sheets = [n for n in sheets_a if n not in sheets_b and n in page_sheet.values()]
    the_plan = {"items": items, "page_sheet": page_sheet, "new_rows": new_content, "missing_sheets": missing_sheets,
                "page_links": page_links, "symbols": symbols.listing(), "_symbols": symbols, "_roots": roots,
                "_size": psd.size, "_box0": {n: tuple(l.bbox) for n, l in enumerate(psd.descendants())}}
    the_plan["icon_edits"] = icon_edits(the_plan, sheets_a, sheets_b, rowmaps)
    the_plan["work_area"] = working_area(psd)         # before anything moves
    # each named symbol picture by its layer ID (a pixel picture's signature is its place, which moves
    # once rows or pages are added)
    the_plan["symbol_layers"] = [{"layer": l.layer_id, "place": n, "token": tok} for n, l in enumerate(psd.descendants())
                                 if _is_picture(l) and (tok := symbols.token(l))]
    for item in items:
        for k in ("_layer", "_src", "_multi", "_card", "_pic", "_gap"):
            item.pop(k, None)
    return the_plan


def _by_paragraph(item, ia, streams, sheet, sheets_a, sheets_b, rowmaps, wordmaps, claimed, used_rows):
    """A layer holding several paragraphs, only some of them from the Excel (or each from its own
    row): every paragraph is matched on its own; the ones that aren't stay as the artist typed them.
    True when at least one paragraph came from the Excel."""
    paras = item["old"].split("\r")
    if sum(1 for p in paras if norm(p)) < 2:
        return False
    out, found, changed, problems, kept = [], 0, 0, [], 0
    for para in paras:
        words = [w for w in (_key(x) for x in _TOKEN.sub(" ", para).split()) if w]
        if len(words) < 3:
            out.append(para)
            kept += bool(norm(para))
            continue
        cs = (_sources(ia, streams, para, sheet) if sheet else []) or _sources(ia, streams, para, None)
        outs = [(c,) + _outcome(c, sheets_a, sheets_b, rowmaps, wordmaps) for c in cs]
        good = [o for o in outs if o[4] is None]
        if not good or len({tuple(norm(v) for v in o[2]) for o in good}) > 1:
            out.append(para)
            kept += 1
            continue
        c, a_vals, vals, rows, _ = good[0]
        found += 1
        item.setdefault("content", {"kind": "paragraphs", "parts": []})["parts"].append(
            _content(c, sheets_b, rowmaps, streams, wordmaps, sheets_a))
        item.setdefault("rows_b", [])
        item["rows_b"] = sorted(set(item["rows_b"]) | set(rows))
        claimed.add(_src_key(c))
        for r in rows:
            used_rows.setdefault(c.get("sheet") or c["refs"][0][0], set()).add(r)
        if [norm(v) for v in a_vals] == [norm(v) for v in vals]:
            out.append(para)
            continue
        new, why = lines_diffed(para, a_vals, vals) if c["kind"] == "cells" else word_diff(para, a_vals[0], vals[0], icons=True)
        if new is None:
            problems.append(why or "this paragraph can't be changed safely")
            out.append(para)
            continue
        out.append(new)
        changed += 1
    if not found:
        return False
    item["source"] = "by paragraph"
    note = f"{kept} paragraph(s) not in the Excel kept as typed" if kept else ""
    if problems:
        item.update(status="artist", why="; ".join(dict.fromkeys(problems)), new_excel="")
    elif changed:
        item.update(status="change", new="\r".join(out), why=note)
    else:
        item.update(status="same", why=note)
    return True


def _first_cell(src):
    if src["kind"] == "words":
        return (0, src["span"][0])
    r = src["refs"][0]
    return (r[1], r[2] if len(r) > 2 else 0)


def _ref_text(src):
    if src["kind"] == "words":
        return f"{src['sheet']}!text"
    refs = src["refs"]
    if src["kind"] == "row":
        return f"{refs[0][0]}!row {refs[0][1]}"
    from openpyxl.utils import get_column_letter

    cells = [f"{get_column_letter(c)}{r}" for _s, r, c in refs]
    return f"{refs[0][0]}!" + (cells[0] if len(cells) == 1 else f"{cells[0]}-{cells[-1]}")


# ── writing: the artist's file, only the data layers edited in place ─────────
_FONT_FILES = {}


def _font_file(ps_name):
    """The installed font file for a PostScript name (Photoshop stores fonts by it)."""
    if not _FONT_FILES:
        from .psd_writer.fontnames import postscript_name

        roots = [os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts"),
                 os.path.join(os.environ.get("LOCALAPPDATA", ""), "Microsoft", "Windows", "Fonts")]
        for root in roots:
            if not os.path.isdir(root):
                continue
            for f in os.listdir(root):
                if f.lower().endswith((".ttf", ".otf", ".ttc")):
                    path = os.path.join(root, f)
                    for idx in range(4 if f.lower().endswith(".ttc") else 1):
                        try:
                            n = postscript_name(path, idx)
                        except Exception:
                            n = None
                        if n:
                            _FONT_FILES.setdefault(n, (path, idx))
        _FONT_FILES.setdefault("", ("arial.ttf", 0))
    return _FONT_FILES.get(str(ps_name or "").strip("'"))


def _run_styles(layer):
    """[(font name, size px, (r, g, b), faux bold, leading px or None)] per style run, and the run lengths."""
    eng, fonts = layer.engine_dict, layer.resource_dict["FontSet"]
    yy = float(layer.transform[3]) or 1.0
    styles, lengths = [], [int(n) for n in eng["StyleRun"]["RunLengthArray"]]
    for run in eng["StyleRun"]["RunArray"]:
        sd = run["StyleSheet"]["StyleSheetData"]
        col = sd.get("FillColor", {}).get("Values") if hasattr(sd, "get") else None
        rgb = tuple(int(round(float(v) * 255)) for v in col[1:4]) if col else (0, 0, 0)
        try:
            name = str(fonts[int(sd.get("Font", 0))]["Name"]).strip("'")
        except Exception:
            name = ""
        size = float(sd.get("FontSize", 12)) * yy
        auto = bool(sd.get("AutoLeading", True))
        leading = float(sd["Leading"]) * yy if (not auto and "Leading" in sd) else None
        styles.append((name, size, rgb, bool(sd.get("FauxBold", False)), leading))
    return styles, lengths


def _scales(layer):
    """(horizontal, vertical) scale of a text layer's characters (Photoshop's Character panel: 80%
    makes them narrower) — its longest style run's. Lines are laid out and drawn unscaled, then the
    whole drawing is scaled: a box text wraps at its width / horizontal scale."""
    try:
        sr = layer.engine_dict["StyleRun"]
        lengths = [int(n) for n in sr["RunLengthArray"]]
        sd = sr["RunArray"][lengths.index(max(lengths))]["StyleSheet"]["StyleSheetData"]
        hs, vs = float(sd.get("HorizontalScale", 1.0)), float(sd.get("VerticalScale", 1.0))
        return (hs if 0.05 < hs < 20 else 1.0), (vs if 0.05 < vs < 20 else 1.0)
    except Exception:
        return 1.0, 1.0


def _per_char(lengths, n):
    out = []
    for i, ln in enumerate(lengths):
        out += [i] * ln
    return (out + [out[-1] if out else 0] * n)[:n]


def _carry(old, new, old_index):
    """Each new character's style: the style it had where the text is unchanged; new characters
    take the style of the character before them (like typing in Photoshop)."""
    out = []
    for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, old, new, autojunk=False).get_opcodes():
        if op == "equal":
            out += old_index[i1:i2]
        elif op == "replace":
            span = old_index[i1:i2] or [old_index[max(0, i1 - 1)] if old_index else 0]
            out += [span[min(k, len(span) - 1)] for k in range(j2 - j1)]
        elif op == "insert":
            prev = out[-1] if out else (old_index[i1] if i1 < len(old_index) else (old_index[-1] if old_index else 0))
            out += [prev] * (j2 - j1)
    return out


def _compress(index):
    runs, lengths = [], []
    for i in index:
        if runs and runs[-1] == i:
            lengths[-1] += 1
        else:
            runs.append(i)
            lengths.append(1)
    return runs, lengths


def edit_text_layer(layer, new_text):
    """Replace a type layer's characters in place, each keeping the style run it had."""
    from psd_tools.constants import Tag

    from .psd_apply import splice

    splice.mark(layer)                                # written again, not copied (psd_apply.splice)
    from psd_tools.psd.engine_data import Integer, List, String

    _wrap_factor(layer)                               # where Photoshop broke the artist's lines: before they change

    tool = layer._record.tagged_blocks.get_data(Tag.TYPE_TOOL_OBJECT_SETTING)
    eng = tool.text_data[b"EngineData"].value["EngineDict"]
    old = str(eng["Editor"]["Text"].value)
    tail = old[len(old.rstrip("\r")):] or "\r"           # the artist's trailing returns
    new = new_text.replace("\n", "\r").rstrip("\r") + tail
    sr = eng["StyleRun"]
    old_runs = list(sr["RunArray"])
    style_idx = _carry(old, new, _per_char([int(n) for n in sr["RunLengthArray"]], len(old)))
    runs, lengths = _compress(style_idx)
    sr["RunArray"] = List([copy.deepcopy(old_runs[min(i, len(old_runs) - 1)]) for i in runs])
    sr["RunLengthArray"] = List([Integer(n) for n in lengths])
    # paragraphs: each new paragraph keeps the paragraph style of the one it came from
    pr = eng["ParagraphRun"]
    old_paras = list(pr["RunArray"])
    old_para_of = []
    for k, ln in enumerate(int(n) for n in pr["RunLengthArray"]):
        old_para_of += [k] * ln
    old_para_of = (old_para_of + [old_para_of[-1] if old_para_of else 0] * len(old))[:len(old)]
    new_para_of = _carry(old, new, old_para_of)
    paras, start = [], 0
    for chunk in new.split("\r")[:-1]:
        end = start + len(chunk) + 1
        paras.append((new_para_of[start] if start < len(new_para_of) else 0, end - start))
        start = end
    pr["RunArray"] = List([copy.deepcopy(old_paras[min(k, len(old_paras) - 1)]) for k, _n in paras])
    pr["RunLengthArray"] = List([Integer(n) for _k, n in paras])
    eng["Editor"]["Text"] = String(new)
    tool.text_data[b"Txt "].value = new[:-1] + "\x00"
    return new


def _txt2_object(psd, layer):
    """(Photoshop's document text block, this layer's object in it) or (None, None)."""
    from psd_tools.constants import Tag

    try:
        blk = psd._record.layer_and_mask_information.tagged_blocks.get_data(Tag.TEXT_ENGINE_DATA)
        tool = layer._record.tagged_blocks.get_data(Tag.TYPE_TOOL_OBJECT_SETTING)
        return blk, blk["1"]["1"][int(tool.text_data[b"TextIndex"])]
    except Exception:
        return None, None


def set_leading(psd, layer, spans):
    """Characters given a leading of their own: `spans` [(start, end, leading px)]. A line is as far
    below the one before as the largest leading of its characters, so this makes only those lines
    taller — in the layer and in Photoshop's document copy (Txt2), each character keeping the rest of
    its style. Draw the layer again afterwards (set_layer_text)."""
    from psd_tools.constants import Tag
    from psd_tools.psd.engine_data import Bool, Dict, Float, Integer, List

    from .psd_apply import splice

    yy = float(layer.transform[3]) or 1.0
    tool = layer._record.tagged_blocks.get_data(Tag.TYPE_TOOL_OBJECT_SETTING)
    eng = tool.text_data[b"EngineData"].value["EngineDict"]
    text = str(eng["Editor"]["Text"].value)

    def restyled(entries, lengths, style_of):
        idx, out, made = _per_char(lengths, len(text)), list(entries), {}
        for a, b, px in spans:
            for i in range(max(0, a), min(b, len(text))):
                key = (idx[i], round(px, 3))
                if key not in made:
                    e = copy.deepcopy(entries[min(idx[i], len(entries) - 1)])
                    style_of(e, px / yy)
                    made[key] = len(out)
                    out.append(e)
                idx[i] = made[key]
        return _compress(idx), out

    def layer_style(run, lead):
        sd = run["StyleSheet"]["StyleSheetData"]
        sd["AutoLeading"], sd["Leading"] = Bool(False), Float(lead)

    sr = eng["StyleRun"]
    (runs, lengths), entries = restyled(list(sr["RunArray"]), [int(n) for n in sr["RunLengthArray"]], layer_style)
    sr["RunArray"] = List([copy.deepcopy(entries[k]) for k in runs])
    sr["RunLengthArray"] = List([Integer(n) for n in lengths])
    splice.mark(layer)
    _blk, obj = _txt2_object(psd, layer)
    if obj is not None and str(obj["0"]["0"].value) == text:

        def txt2_style(e, lead):                      # Txt2's keys are numbers: 4 auto leading, 5 leading
            sheet = e["0"]["0"]
            if "6" not in sheet:
                sheet["6"] = Dict()
            sheet["6"]["4"], sheet["6"]["5"] = Bool(False), Float(lead)

        styles = list(obj["0"]["6"]["0"])
        (runs, lengths), entries = restyled(styles, [int(e["1"]) for e in styles], txt2_style)
        out = []
        for k, n in zip(runs, lengths):
            e = copy.deepcopy(entries[k])
            e["1"] = Integer(n)
            out.append(e)
        obj["0"]["6"]["0"] = List(out)
        splice.mark_document(psd)


def grow_box(psd, layer, height):
    """A paragraph text's box made `height` document pixels tall (its top kept) — in the layer and in
    Photoshop's document copy of its frame — or Photoshop hides the lines past the old bottom."""
    from psd_tools.constants import Tag

    from .psd_apply import splice

    yy = float(layer.transform[3]) or 1.0
    tool = layer._record.tagged_blocks.get_data(Tag.TYPE_TOOL_OBJECT_SETTING)
    eng = tool.text_data[b"EngineData"].value["EngineDict"]
    bb = eng["Rendered"]["Shapes"]["Children"][0]["Cookie"]["Photoshop"]["BoxBounds"]
    old, new = float(bb[3]), float(bb[1]) + height / yy
    if new <= old:
        return False
    bb[3] = type(bb[3])(new)
    bounds = tool.text_data.get(b"bounds") if hasattr(tool.text_data, "get") else None
    if bounds is not None and b"Btom" in bounds:
        bounds[b"Btom"] = type(bounds[b"Btom"])(new)
    splice.mark(layer)
    blk, obj = _txt2_object(psd, layer)
    try:
        frame = blk["0"]["8"]["0"][int(obj["1"]["0"][0]["0"])]["0"]["1"]["0"]
        for n in range(1, len(frame), 2):             # the frame's outline: its bottom edge's y values
            if abs(float(frame[n]) - old) < 0.01:
                frame[n] = type(frame[n])(new)
        splice.mark_document(psd)
    except Exception:
        pass
    return True


class _Tracked:
    """A font whose lengths include the layer's tracking (Photoshop's letter spacing, added after every
    character): what lines are wrapped and placed by. `font` is the face itself, for drawing."""

    def __init__(self, font, extra):
        self.font, self.extra = font, extra

    def getlength(self, text):
        return self.font.getlength(text) + self.extra * len(text)


def _fonts_for(layer, styles, SS, adjust=None):
    """font(style index) -> _Tracked, at SS x the layer's size; tracking in the same (unscaled) units,
    plus the spacing the layer's own Photoshop lines showed the tool's lacked (_letter_adjust)."""
    from PIL import ImageFont

    hs = _scales(layer)[0]
    adjust = _letter_adjust(layer) if adjust is None else adjust
    try:
        tracking = [float(r["StyleSheet"]["StyleSheetData"].get("Tracking", 0)) for r in layer.engine_dict["StyleRun"]["RunArray"]]
    except Exception:
        tracking = []
    fonts = {}

    def font(k):
        if k not in fonts:
            name, size = styles[min(k, len(styles) - 1)][:2]
            entry = _font_file(name) or _font_file("")
            try:
                face = ImageFont.truetype(entry[0], max(1, int(round(size * SS))), index=entry[1])
            except Exception:
                face = ImageFont.truetype("arial.ttf", max(1, int(round(size * SS))))
            track = tracking[min(k, len(tracking) - 1)] if tracking else 0.0
            fonts[k] = _Tracked(face, (track / 1000.0 * size + adjust) * SS / hs)      # (scaled by hs afterwards)
        return fonts[k]
    return font


def _preview(layer, new):
    """The layer's pixels drawn again with its new text (each run its own font / colour), placed on
    the artist's anchor edge — a paragraph (box) text wraps inside its box as Photoshop wraps it.
    Returns (image, justification, left edge or None, overflows the box) or None. Photoshop redraws
    it exactly once the layer is laid out again (Fix text layers / the Photoshop finish)."""
    from PIL import Image, ImageDraw

    styles, lengths = _run_styles(layer)
    idx = _per_char(lengths, len(new))
    SS = 4                                            # drawn 4x and scaled down: faux bold is a fraction of a pixel
    font = _fonts_for(layer, styles, SS)

    hs, vs = _scales(layer)
    frame = _box_frame(layer)
    # laid out and drawn unscaled (the box as wide as it is unscaled, the leading as tall), then scaled
    wf = (_wrap_factor(layer) or 1.0) if frame else 1.0      # where Photoshop breaks the lines
    lines, leads, size, box = _layout(new, styles, idx, font, SS,
                                      frame and (frame[0], frame[1], frame[2] / hs * wf, frame[3]))
    if not lines:
        return None
    leads = [x / vs for x in leads]
    width = max(sum(font(k).getlength(t) for t, k in segs) for segs in lines) or 1
    if box:
        width = frame[2] / hs * SS                    # lines sit in the (whole) box: centred / right in it
    pad = 20 * SS
    img = Image.new("RGBA", (int(width) + 2 * pad, int(sum(leads) + size) + 2 * pad), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    just = _justification(layer)
    for n, segs in enumerate(lines):
        lw = sum(font(k).getlength(t) for t, k in segs)
        x = pad + {1: width - lw, 2: (width - lw) / 2.0}.get(just, 0.0)
        y = pad + size + sum(leads[1:n + 1])           # each line its own leading, as Photoshop spaces them
        for t, k in segs:
            st = styles[min(k, len(styles) - 1)]
            fill = st[2] + (255,)
            f = font(k)
            for piece in (list(t) if f.extra else [t]):   # letter spaced: a character at a time
                d.text((x, y), piece, font=f.font, fill=fill, anchor="ls",
                       stroke_width=int(round(st[1] * SS * 0.0125)) if st[3] else 0, stroke_fill=fill)   # faux bold (measured)
                x += f.getlength(piece)
    img = img.resize((max(1, int(round(img.width * hs / SS))), max(1, int(round(img.height * vs / SS)))), Image.LANCZOS)
    ink = img.getbbox()
    if not ink:
        return None
    left = (box[0] - pad * hs / SS + ink[0]) if box else None
    if not box and just in (1, 2):
        # point text: its lines sit on Photoshop's anchor, each as wide as all its characters — a trailing
        # icon gap is invisible, so lining up the ink instead would shift the line by half the gap
        try:
            anchor = float(layer.transform[4])
            left = anchor - width * hs / SS * (1.0 if just == 1 else 0.5) - pad * hs / SS + ink[0]
        except Exception:
            left = None
    overflow = bool(box) and (sum(leads[1:]) + size) * vs / SS > box[3] * 1.02
    return img.crop(ink), just, left, overflow


def _layout(text, styles, idx, font, SS, box):
    """The visual lines of a text ([(text, style)] each), the leading above each line and the
    largest size, all at SS scale; a paragraph text wraps in its `box`. A line's leading is the
    largest of the characters on it (the artist's own, else Photoshop's auto 120%)."""
    def lead_of(k):
        st = styles[min(k, len(styles) - 1)]
        return (st[4] or st[1] * 1.2) * SS

    lines, keys, pos = [], [], 0
    for chunk in text.split("\r"):
        segs, i = [], pos
        while i < pos + len(chunk):
            j = i
            while j < pos + len(chunk) and idx[j] == idx[i]:
                j += 1
            segs.append((text[i:j], idx[i]))
            i = j
        own = idx[pos] if pos < len(idx) else (idx[-1] if idx else 0)
        for ln in (_wrap_segs(segs, box[2] * SS, font) if box and segs else [segs]):
            lines.append(ln)
            keys.append(own)
        pos += len(chunk) + 1
    while lines and not lines[-1]:
        lines.pop()
        keys.pop()
    while lines and not lines[0]:                     # empty lines above the ink: the ink's top is the anchor
        lines.pop(0)
        keys.pop(0)
    leads = [max([lead_of(k) for _t, k in ln] or [lead_of(keys[n])]) for n, ln in enumerate(lines)]
    size = max(s[1] for s in styles) * SS
    return lines, leads, size, box


def _layout_height(layer, text):
    """How tall a text layer's lines are (document pixels), laid out as _preview lays them out."""
    from PIL import ImageFont

    styles, lengths = _run_styles(layer)
    font = _fonts_for(layer, styles, 4)

    hs, vs = _scales(layer)
    frame = _box_frame(layer)
    lines, leads, size, _box = _layout(text, styles, _per_char(lengths, len(text)), font, 4,
                                       frame and (frame[0], frame[1], frame[2] / hs * (_wrap_factor(layer) or 1.0), frame[3]))
    return (sum(leads[1:]) + size * vs) / 4.0 if lines else 0.0


def _box_frame(layer):
    """(left, top, width, height) of a paragraph text's box in document pixels; None for point text."""
    try:
        shape = layer.engine_dict["Rendered"]["Shapes"]["Children"][0]
        if int(shape["ShapeType"]) != 1:
            return None
        bb = [float(v) for v in shape["Cookie"]["Photoshop"]["BoxBounds"]]
        xx, yy, tx, ty = (float(layer.transform[i]) for i in (0, 3, 4, 5))
        return (tx + bb[0] * xx, ty + bb[1] * yy, (bb[2] - bb[0]) * xx, (bb[3] - bb[1]) * yy)
    except Exception:
        return None


def _wrap_segs(segs, width, font):
    """One paragraph's [(text, style)] broken into lines no wider than `width`, at spaces, the way
    Photoshop wraps paragraph text (a word wider than the box stays whole on its own line)."""
    chars = [(ch, k) for t, k in segs for ch in t]
    if not chars:
        return [segs]
    adv = [font(k).getlength(ch) for ch, k in chars]
    lines = [chars[a:b] for a, b in _wrap_breaks([ch for ch, _k in chars], adv, width)]
    out = []
    for ln in lines:
        segs_ln = []
        for ch, k in ln:
            if segs_ln and segs_ln[-1][1] == k:
                segs_ln[-1] = (segs_ln[-1][0] + ch, k)
            else:
                segs_ln.append((ch, k))
        if segs_ln:                                   # trailing spaces don't count for centring
            segs_ln[-1] = (segs_ln[-1][0].rstrip(" "), segs_ln[-1][1])
        out.append(segs_ln)
    return out


def _wrap_breaks(chars, adv, width):
    """[(start, end)] of each line one paragraph's characters wrap into (see _wrap_segs)."""
    out, start, n = [], 0, len(chars)
    while start < n:
        x, end, last_break = 0.0, start, None
        while end < n:
            if chars[end] == " ":
                last_break = end
            x += adv[end]
            if x > width and chars[end] != " " and last_break is not None and last_break > start:
                end = last_break + 1                  # the space stays at the end of its line
                break
            end += 1
        out.append((start, end))
        start = end
    return out


_WRAP = {}                                           # id(layer record) -> (record, (letter adjust, wrap factor))


def _ink_lines(layer):
    """[(left, right)] in document pixels of each line of text in the layer's own pixels (as Photoshop
    drew them), top to bottom; None when they can't be read."""
    import numpy as np

    try:
        img = layer.topil()
        if img is None:
            return None
        a = np.asarray(img.convert("RGBA"))[:, :, 3] > 40
    except Exception:
        return None
    rows = a.any(axis=1)
    size = max(s[1] for s in _run_styles(layer)[0])
    out, y, n = [], 0, len(rows)
    while y < n:
        if not rows[y]:
            y += 1
            continue
        y0 = y
        while y < n and (rows[y] or (y + 1 < n and rows[y + 1:y + 1 + int(size * 0.12)].any())):
            y += 1                                    # (a line's accents / dots are part of it)
        cols = np.where(a[y0:y].any(axis=0))[0]
        out.append((layer.left + float(cols[0]), layer.left + float(cols[-1] + 1)))
    return out


def _filled_widths(spots, lines, text):
    """Per line with text: (ink width as laid out, characters from its first to its last mark)."""
    out = []
    for n, (_top, _size, count) in enumerate(lines):
        idx = sorted(i for i, s in spots.items() if s[2] == n and text[i] not in "  ")
        if count and idx:
            out.append((spots[idx[-1]][0] + spots[idx[-1]][1] - spots[idx[0]][0], idx[-1] - idx[0] + 1))
    return out


def _calibrate(layer):
    """(letter adjust px, wrap factor) that make the tool lay the layer's text out as Photoshop laid out
    the artist's: the spacing per character its own lines in the PSD show beyond the tool's (Spooky's
    letter-spaced Arial ran 2.8 px a character wider than its tracking says), and the share of a
    paragraph box's width its lines break at (Photoshop wraps a little short of the edge). Worked out
    once per layer on the text as the artist left it, kept with the layer. The factor is None when no
    width gives the artist's lines — then the tool can't tell where the text's icons sit."""
    rec = layer._record
    got = _WRAP.get(id(rec))
    if got is not None and got[0] is rec:
        return got[1]
    text = str(layer.text or "")
    box = _box_frame(layer)
    ink = _ink_lines(layer)
    size = max(s[1] for s in _run_styles(layer)[0])
    factors = [1.0 - 0.005 * k for k in range(13)] if box else [1.0]      # 100% down to 94%

    def lay(f, adjust):
        try:
            return _laid_out(layer, text, factor=f, adjust=adjust)
        except Exception:
            return None

    def fits(got):
        if got is None:
            return False
        spots, lines = got
        filled = [x for x in lines if x[2]]
        if ink is not None:
            return len(filled) == len(ink)
        if not filled:
            return True
        lead = (filled[1][0] - filled[0][0]) if len(filled) > 1 else filled[0][1] * 1.2
        return abs(layer.bottom - (filled[-1][0] + 0.72 * filled[-1][1] * _scales(layer)[1])) <= 0.5 * lead

    adjust = 0.0
    if ink:                                           # the spacing: from lines laid out as Photoshop's are
        for f in factors:
            got = lay(f, 0.0)
            if fits(got):
                widths = _filled_widths(got[0], got[1], text)
                per = sorted((w_ps[1] - w_ps[0] - w) / max(1, n - 1) for (w, n), w_ps in zip(widths, ink) if n > 3)
                if per:
                    adjust = per[len(per) // 2]
                    if abs(adjust) > 0.25 * size:     # nothing like the artist's lines: not a measure
                        adjust = 0.0
                break
    factor = next((f for f in factors if fits(lay(f, adjust))), None)
    if factor is None and not box:
        factor = 1.0                                  # point text breaks where its text says
    if len(_WRAP) > 20000:
        _WRAP.clear()
    _WRAP[id(rec)] = (rec, (adjust, factor))
    return adjust, factor


def _wrap_factor(layer):
    """The share of a paragraph box's width the tool wraps at (_calibrate); 1.0 for point text; None
    when the tool can't break the artist's lines where Photoshop did."""
    return _calibrate(layer)[1]


def _letter_adjust(layer):
    return _calibrate(layer)[0]


def _wrap_ok(layer):
    return _wrap_factor(layer) is not None


_WRAP_WHY = "the tool can't lay this paragraph out the way Photoshop wraps it — move its icons by hand"


def _laid_out(layer, text, factor=None, adjust=None):
    """Where a text layer's characters sit as _preview draws them, in document pixels:
    ({character index: (left, width, line)}, [(top, font size, characters)] per line) — a paragraph text wraps
    in its box (at _wrap_factor of its width), each line placed by the layer's justification."""
    from PIL import ImageFont

    SS = 4
    styles, lengths = _run_styles(layer)
    idx = _per_char(lengths, len(text))
    font = _fonts_for(layer, styles, SS, adjust)

    def style(i):
        return styles[min(idx[i] if i < len(idx) else 0, len(styles) - 1)]

    box = _box_frame(layer)
    hs = _scales(layer)[0]
    wf = factor if factor is not None else (_wrap_factor(layer) or 1.0) if box else 1.0
    lines, pos = [], 0                                # [[character index]] per line, as _layout makes them
    for chunk in text.split("\r"):
        adv = [font(idx[pos + i]).getlength(ch) * hs / SS for i, ch in enumerate(chunk)]
        breaks = _wrap_breaks(chunk, adv, box[2] * wf) if box and chunk else [(0, len(chunk))]
        lines += [[(pos + i, adv[i]) for i in range(a, b)] for a, b in breaks]
        pos += len(chunk) + 1
    while lines and not lines[-1]:
        lines.pop()
    while lines and not lines[0]:                     # empty lines above the ink: the ink's top is the anchor
        lines.pop(0)
    if not lines:
        return {}, []

    def size_of(ln):
        return max([style(i)[1] for i, _w in ln] or [max(s[1] for s in styles)])

    def lead_of(ln):
        return max([style(i)[4] or style(i)[1] * 1.2 for i, _w in ln] or [max(s[1] for s in styles) * 1.2])

    def width_of(ln):                                 # trailing spaces don't count for centring
        k = len(ln)
        while k and text[ln[k - 1][0]] == " ":
            k -= 1
        return sum(w for _i, w in ln[:k])

    widest = max(width_of(ln) for ln in lines)
    just = _justification(layer)
    left, room = (box[0], box[2]) if box else (layer.left, widest)
    if not box and just in (1, 2):                    # point text: Photoshop lines it up on its anchor
        try:
            anchor = float(layer.transform[4])
            left, room = (anchor - widest, widest) if just == 1 else (anchor - widest / 2.0, widest)
        except Exception:
            pass
    spots, tops, y = {}, [], float(layer.top)
    for n, ln in enumerate(lines):
        if n:
            y += lead_of(ln)
        tops.append((y, size_of(ln), len(ln)))
        x = left + {1: room - width_of(ln), 2: (room - width_of(ln)) / 2.0}.get(just, 0.0)
        for i, w in ln:
            spots[i] = (x, w, n)
            x += w
    return spots, tops


def _swap_pixels(psd, layer, img, just, left=None):
    from psd_tools.api import layers as ptl
    from psd_tools.constants import Compression

    from .psd_apply import splice

    splice.mark(layer)

    old_l, old_t, old_r = layer.left, layer.top, layer.right
    if left is None:
        left = old_r - img.width if just == 1 else ((old_l + old_r) / 2.0 - img.width / 2.0 if just == 2 else old_l)
    rec, chans = ptl.PixelLayer._build_layer_record_and_channels(
        img, layer.name, int(round(left)), int(round(old_t)), Compression.RLE, version=psd._record.header.version)
    r = layer._record
    r.top, r.left, r.bottom, r.right = rec.top, rec.left, rec.bottom, rec.right
    # the same channel ids in the same order, so the record and its data stay paired
    new_by_id = {c.id: (c, d) for c, d in zip(rec.channel_info, chans)}
    infos, datas = [], []
    for old_info, old_data in zip(r.channel_info, layer._channels):
        if old_info.id in new_by_id:
            infos.append(new_by_id[old_info.id][0])
            datas.append(new_by_id[old_info.id][1])
        else:                                         # a user mask: kept as it is
            infos.append(old_info)
            datas.append(old_data)
    r.channel_info = infos
    layer._channels._items[:] = datas


def apply(psd, the_plan):
    """The planned changes made to `psd` in memory (the PSD the plan was made on); returns the number
    of layers edited. Never rebuilds the layer section (Photoshop refuses such a file): records are
    patched (psd_apply.records).
    the_plan["text_engine"] says afterwards what became of Photoshop's document text block:
    "updated" (only the edited layers' entries changed), "dropped" or "untouched"."""
    from .psd_apply.records import RecordExecutor

    ops = text_ops(psd, the_plan)
    the_plan.setdefault("_ops", []).extend(ops)
    return RecordExecutor(psd, the_plan).apply_text_ops(ops)


def text_ops(psd, the_plan):
    """The text layers to change and the symbols to remove, as ops (psd_apply): every planned change
    not left out by the artist."""
    from .psd_apply import layer_ref

    layers = list(psd.descendants())

    def ref(place):
        if place is None or not 0 <= place < len(layers):
            return {"layer": None, "place": place}
        return layer_ref(layers[place], place)

    ops = []
    for n, item in enumerate(the_plan["items"]):
        if item.get("status") != "change" or item.get("skip"):
            continue
        ops.append({"op": "set_text", "layer": item.get("layer_id"), "place": item.get("place"),
                    "old": item["old"], "text": item["new"], "ref": ["items", n],
                    **({"draw_later": True} if item.get("gap_spans") else {})})
    for n, edit in enumerate(the_plan.get("icon_edits") or []):     # symbols removed: hidden, the rest closed up
        if edit.get("status") != "change" or edit.get("skip"):
            continue
        ops.append({"op": "remove_symbols", "hide": [ref(p) for p in edit["hide"]],
                    "move": [dict(ref(m[0]), dx=m[1], dy=m[2] if len(m) > 2 else 0) for m in edit["move"]],
                    "ref": ["icon_edits", n]})
    return ops


class TextEngine:
    """Photoshop's document-wide copy of every text layer (the Txt2 block), kept in step with the
    edited layers: each edited layer's entry gets the new text and its style / paragraph runs
    carried the way the layer's own are; its stored line layout, made for the old text, is dropped
    so Photoshop lays the new text out itself. Every other layer's entry stays byte for byte as
    Photoshop wrote it — so only the edited layers can show the "requires a layout change" triangle,
    not all of them (as when the whole block was dropped)."""

    def __init__(self, block):
        self.block, self.edited, self.failed = block, 0, []
        try:
            self.objects = block["1"]["1"] if block is not None else None
        except Exception:
            self.objects = None

    def state(self):
        if self.block is None:
            return "none"
        if self.failed:
            return "dropped"
        return "updated" if self.edited else "untouched"

    def update(self, layer, old, new):
        from psd_tools.constants import Tag

        if self.block is None:
            return
        try:
            tool = layer._record.tagged_blocks.get_data(Tag.TYPE_TOOL_OBJECT_SETTING)
            obj = self.objects[int(tool.text_data[b"TextIndex"])]
            if str(obj["0"]["0"].value) != old:
                raise ValueError("the document copy of this text differs from the layer's")
            _txt2_carry(obj, old, new)
            self.edited += 1
        except Exception as exc:
            self.failed.append(f"{layer.name}: {exc}")


def _editor_text(layer):
    from psd_tools.constants import Tag

    tool = layer._record.tagged_blocks.get_data(Tag.TYPE_TOOL_OBJECT_SETTING)
    return str(tool.text_data[b"EngineData"].value["EngineDict"]["Editor"]["Text"].value)


def _txt2_carry(obj, old, new):
    """One Txt2 text object changed from `old` to `new` (both as the layer's Editor text)."""
    from psd_tools.psd.engine_data import Integer, List, String

    model, view = obj["0"], obj["1"]

    def runs_of(entries):
        lengths = [int(e["1"]) for e in entries]
        return _per_char(lengths, len(old))

    def rebuilt(entries, idx):
        runs, lengths = _compress(idx)
        out = []
        for k, n in zip(runs, lengths):
            e = copy.deepcopy(entries[min(k, len(entries) - 1)])
            e["1"] = Integer(n)
            out.append(e)
        return List(out)

    styles = list(model["6"]["0"])
    model["6"]["0"] = rebuilt(styles, _carry(old, new, runs_of(styles)))
    paras = list(model["5"]["0"])
    para_of = _carry(old, new, runs_of(paras))
    per_char, start = [], 0                          # a paragraph keeps one style: its first character's
    for chunk in new.split("\r")[:-1] if new.endswith("\r") else new.split("\r"):
        end = min(len(new), start + len(chunk) + 1)
        k = para_of[start] if start < len(para_of) else (para_of[-1] if para_of else 0)
        per_char += [k] * (end - start)
        start = end
    per_char += [per_char[-1] if per_char else 0] * (len(new) - len(per_char))
    model["5"]["0"] = rebuilt(paras, per_char)
    if "1" in view and "0" in view["1"]:
        view["1"]["0"] = rebuilt(list(view["1"]["0"]), per_char)
    if "2" in view:
        del view["2"]                                # the old text's line layout: Photoshop redoes it
    model["0"] = String(new)


# ── whole pages: sheets added to / removed from / renamed in the AGR ──────────
# A sheet new in the AGR gets a copy of the page group(s) of the sheet most like it
# (another denom, another Game Rules…), placed in AGR order and filled from the new
# sheet; a sheet that left the AGR keeps its group, labelled red and renamed, for the
# artist to remove. A sheet only renamed is the same sheet. A new sheet like no other
# (a first Bingo Rules page) is listed for a page made from the design language — later.
NEW_TAG, GONE_TAG = " - NEW from Excel", "DELETED FROM EXCEL - "
GONE_GROUP = "[Deleted From Excel]"                  # pages whose sheets left the AGR: hidden, red, in here
LIKE_ENOUGH = 0.3


def _holds_pages(group):
    """True for a group that holds several pages of its own (psd_render.stacked_pages)."""
    from .artist_design import psd_render

    return group.is_group() and bool(psd_render.stacked_pages(group))


def _sheet_share(first_plan, page_key, sheet):
    """How much of a page's matched text (by characters) came from `sheet` (0..1)."""
    total = mine = 0
    for item in first_plan["items"]:
        if str(item.get("page_key")) != str(page_key) or item.get("status") in ("empty", None):
            continue
        n = len(norm(item.get("old", "")))
        total += n
        src = ((item.get("content") or {}).get("a") or {}).get("sheet")
        if src is None:                               # (text whose sheet left the AGR: only its source says)
            src = str(item.get("source") or "").split("!", 1)[0] if "!" in str(item.get("source") or "") else None
        if src == sheet:
            mine += n
    return mine / total if total else 0.0


def plan_pages(psd, first_plan, sheets_a, sheets_b, renames, links=None):
    """The page changes the new AGR asks for: {"new": [...], "removed": [...]}. Uses the pages'
    sheets as `first_plan` pinned them; `links["new_pages"]` = {new sheet: sheet to copy, or ""}."""
    tops = _tops(psd)
    page_sheet = first_plan["page_sheet"]
    groups_of = {}
    for key, sheet in page_sheet.items():
        if str(key).isdigit():
            groups_of.setdefault(sheet, []).append(int(key))
    as_b = {a: renames.get(a, a) for a in sheets_a}
    known_b = {as_b[a] for a in sheets_a if a in groups_of}
    chosen = (links or {}).get("new_pages") or {}
    order_b = list(sheets_b)
    # which way the AGR runs in the Layers panel: page groups going up (records) as sheets go on
    pinned = sorted((order_b.index(as_b[s]), min(idx)) for s, idx in groups_of.items() if as_b.get(s) in sheets_b)
    ups = sum(1 for (a, i), (b, j) in zip(pinned, pinned[1:]) if (j - i) * (b - a) > 0)
    upward = ups >= (len(pinned) - 1) / 2.0 if len(pinned) > 1 else True
    new = []
    for name in order_b:
        b = sheets_b[name]
        if name in known_b or name in sheets_a or name in renames.values() or not b.rows:
            continue
        likes = sorted(((sheet_likeness(sheets_a[a], b) + 0.05 * _name_like(a, name), a) for a in groups_of if a in sheets_a),
                       reverse=True)
        sibling, how = (likes[0][1], "closest") if likes and likes[0][0] >= LIKE_ENOUGH else (None, "none")
        if name in chosen:
            sibling, how = (chosen[name] or None), "link"
            if sibling and sibling not in groups_of:
                sibling, how = None, "none"
        entry = {"sheet": name, "sibling": sibling, "how": how,
                 "likeness": round(likes[0][0], 3) if likes else 0.0,
                 "likely": [a for _s, a in likes[:4]],
                 "groups": sorted(groups_of.get(sibling, [])) if sibling else [],
                 "status": "add" if sibling else ("skip" if how == "link" else "template")}
        if entry["status"] == "add" and any(_holds_pages(tops[i]) for i in entry["groups"]):
            # its look-alike's group holds several pages: a copy of it all would not be one new page
            entry.update(status="template", groups=[],
                         why="the closest page's group holds several pages — make this page by hand")
        new.append(entry)
    # where each copy goes: after the page of the sheet before it in the AGR (else before the next)
    placed = {as_b[s]: sorted(idx) for s, idx in groups_of.items()}
    for entry in new:
        if entry["status"] != "add":
            continue
        k = order_b.index(entry["sheet"])
        prev = next((placed[n] for n in reversed(order_b[:k]) if n in placed), None)
        nxt = next((placed[n] for n in order_b[k + 1:] if n in placed), None)
        if prev is not None:
            entry["after"], entry["anchor"] = True, (max(prev) if upward else min(prev))
        elif nxt is not None:
            entry["after"], entry["anchor"] = False, (min(nxt) if upward else max(nxt))
        else:
            entry["after"], entry["anchor"] = True, len(tops) - 1
        entry["upward"] = upward
        placed[entry["sheet"]] = [entry["anchor"]]         # a later new sheet goes after this one
    removed = []
    for sheet, idx in sorted(groups_of.items(), key=lambda kv: min(kv[1])):
        if sheet in sheets_a and sheet not in sheets_b and sheet not in renames:
            # only a page clearly the sheet's goes: one page (not a group of pages), most of its text
            # from that sheet — Buffalo's pick / free-games pages were linked to a removed MYSTERY
            # FEATURE sheet by two shared sentences, Hunt's "Group 1" of every page to Bingo Rules
            sure = [i for i in sorted(idx) if not _holds_pages(tops[i]) and _sheet_share(first_plan, i, sheet) >= 0.6]
            unsure = [i for i in sorted(idx) if i not in sure]
            if sure:
                removed.append({"sheet": sheet, "groups": sure, "pages": [tops[i].name for i in sure],
                                "status": "mark"})
            if unsure:
                removed.append({"sheet": sheet, "groups": unsure, "pages": [tops[i].name for i in unsure],
                                "status": "check",
                                "why": "this sheet left the AGR, but these groups aren't clearly its pages — "
                                       "delete them by hand if they are"})
    return {"new": new, "removed": removed, "renamed": [{"from": a, "to": b} for a, b in renames.items()],
            "upward": upward}


def _apply_pages(psd, pages, reject=()):
    """Copy page groups for new sheets, and move the pages of sheets that left the AGR into the
    hidden, red "[Deleted From Excel]" group (records only). Returns ({copy's top record: (new sheet,
    sibling, its index)}, the deleted group's record or None, the same written as ops: copy_page /
    delete_pages, see psd_apply) — the tree must be rebuilt from the record afterwards."""
    from psd_tools.constants import Tag

    from .artist_design import psd_pages

    recs = psd._record.layer_and_mask_information.layer_info.layer_records

    def rid(rec):
        return int(rec.tagged_blocks.get_data(Tag.LAYER_ID) or -1)

    tops = _tops(psd)
    copies, gone, ops = {}, [], []
    for entry in pages["removed"]:
        if entry.get("status") != "mark":             # ("check": not clearly the sheet's pages — left be)
            continue
        if f"removed:{entry['sheet']}" in reject:
            entry["status"] = "kept"
            continue
        gone += [tops[i] for i in entry["groups"]]
    for entry in pages["new"]:
        if entry["status"] != "add":
            continue
        if f"new:{entry['sheet']}" in reject:
            entry["status"] = "rejected"
            continue
        anchor = tops[entry["anchor"]]
        # in the panel the copy sits after (or before) its neighbour page, in the AGR's direction
        if entry["after"] == entry["upward"]:
            above = anchor
        else:
            below = entry["anchor"] - 1
            above = tops[below] if below >= 0 else None
        groups = [tops[i] for i in entry["groups"]]
        names = []
        for n, g in enumerate(groups if entry["upward"] else list(reversed(groups))):
            label = entry["sheet"] + NEW_TAG + (f" ({n + 1})" if len(groups) > 1 else "")
            span = psd_pages.group_span(psd, g)
            originals = [rid(recs[i]) for i in range(span[0], span[1] + 1)]
            op = {"op": "copy_page", "group": g.layer_id, "above": rid(above._record) if above is not None else None,
                  "name": label, "color": "green"}
            if above is None:                         # the very bottom of the document
                first, last = psd_pages.duplicate_group(psd, g, above=None, name=label)
                _move_records_to_bottom(psd, first, last)
                first, last = 0, last - first
            else:
                first, last = psd_pages.duplicate_group(psd, g, above=above, name=label)
            top_rec = psd._record.layer_and_mask_information.layer_info.layer_records[last]
            # each copied layer and the layer it copies: Photoshop's copies get IDs of their own
            op["pairs"] = [[o, rid(recs[first + k])] for k, o in enumerate(originals)]
            ops.append(op)
            copies[id(top_rec)] = (entry["sheet"], entry["sibling"], tops.index(g))
            names.append(label)
            above = _TopRef(top_rec)
        entry["pages"] = names
    holder = psd_pages.nest_groups(psd, gone, GONE_GROUP, color="red", hidden=True) if gone else None
    if holder is not None:
        ops.append({"op": "delete_pages", "groups": [g.layer_id for g in gone], "name": GONE_GROUP, "color": "red",
                    "hidden": True, "holder": rid(holder)})
    return copies, holder, ops


class _TopRef:
    """Stands in for a top-level layer that duplicate_group can place a copy above."""

    def __init__(self, record):
        self._record = record

    def is_group(self):
        return False


def _move_records_to_bottom(psd, first, last):
    info = psd._record.layer_and_mask_information.layer_info
    for lst in (info.layer_records._items, info.channel_image_data._items):
        block = lst[first:last + 1]
        del lst[first:last + 1]
        lst[0:0] = block
    res = psd._record.image_resources
    for key in (1026, 1072):
        items = getattr(getattr(res.get(key), "data", None), "_items", None)
        if items is not None and len(items) > last:
            block = items[first:last + 1]
            del items[first:last + 1]
            items[0:0] = block


# ── rows the new AGR added to a page's sheet ──────────────────────────────────
# A row no layer shows is placed the way an artist adds one: a copy of the page's
# most alike row (its text layer, with the symbols over it), filled with the new
# row, below the row before it; what is under it moves down. When the page then
# runs past the space the artist's pages use, the rows that don't fit go onto a
# "Continued" copy of the page (the PSD's own "(CONTINUED)" label under the
# heading, as on the artist's continued pages).
def _row_text_b(sheet, r):
    return sheet.row_text(r)


def _para_spans(text):
    """[(start, end)] of each paragraph of a layer's text."""
    out, pos = [], 0
    for chunk in str(text).split("\r"):
        out.append((pos, pos + len(chunk)))
        pos += len(chunk) + 1
    return out


def _rows_in_layer(text, rows, sheet):
    """{B row: (first paragraph, last paragraph)} — each row the layer shows, found by joining
    paragraphs (an artist's manual line break splits one row over several) until they read as it."""
    paras = str(text).split("\r")
    out, k = {}, 0
    for r in rows:
        want = norm(_row_text_b(sheet, r))
        while k < len(paras) and not norm(paras[k]):
            k += 1
        acc, j = "", k
        while j < len(paras):
            acc = (acc + " " + paras[j]).strip()
            if norm(acc) == want:
                out[r] = (k, j)
                k = j + 1
                break
            if len(norm(acc)) > len(want) + 2:
                break
            j += 1
    return out


def _line_tops(layer, text):
    """Each paragraph's (top, bottom) on the page, as the layer's lines are laid out (approximate:
    the ink's top is the first line's)."""
    from PIL import ImageFont

    styles, lengths = _run_styles(layer)
    font = _fonts_for(layer, styles, 4)

    idx = _per_char(lengths, len(text))
    box = _box_frame(layer)
    hs = _scales(layer)[0]
    size = max(s[1] for s in styles)
    out, y, first = [], None, True
    for a, b in _para_spans(text):
        segs = [(text[a:b], idx[a] if a < len(idx) else 0)] if b > a else []
        k = idx[a] if a < len(idx) else 0
        lead = (styles[min(k, len(styles) - 1)][4] or styles[min(k, len(styles) - 1)][1] * 1.2)
        n_lines = len(_wrap_segs(segs, box[2] / hs * (_wrap_factor(layer) or 1.0) * 4, font)) if (box and segs) else 1
        if not text[a:b].strip():
            if not first:
                y += lead
            out.append(None)
            continue
        if first:
            y, first = float(layer.top), False
            out.append((y, y + (n_lines - 1) * lead + size))
            y += n_lines * lead
            continue
        out.append((y, y + (n_lines - 1) * lead + size))
        y += n_lines * lead
    return out


def _page_content(page, canvas_h):
    """The layers on a page that are its content (not a full-page frame or backdrop)."""
    return [l for l in page.descendants()
            if not l.is_group() and l.visible and l.kind in ("type", "pixel", "smartobject", "shape")
            and (l.bottom - l.top) < canvas_h * 0.6 and l.width * l.height > 0]


def _row_bands(layers):
    """Layers in rows: groups of layers whose heights overlap, top to bottom."""
    out = []
    for l in sorted(layers, key=lambda l: (l.top, l.left)):
        if out and l.top < out[-1]["bottom"] - 4:
            out[-1]["layers"].append(l)
            out[-1]["bottom"] = max(out[-1]["bottom"], l.bottom)
        else:
            out.append({"top": l.top, "bottom": l.bottom, "layers": [l]})
    return out


def working_area(psd):
    """(left, top, right, bottom) the artist keeps content inside, whatever the canvas or backdrop:
    the furthest any page's content (text, icons, tables — not backdrops or frames spanning the page)
    reaches each way, over all the pages. Measured on the artist's own PSD, before anything changes."""
    from .artist_design import psd_render

    w, h = psd.size
    ext = []
    for page in _tops(psd):
        if not psd_render.is_page(page):
            continue
        content = [l for l in _page_content(page, h) if l.width < w * 0.95]
        if content:
            ext.append((min(l.left for l in content), min(l.top for l in content),
                        max(l.right for l in content), max(l.bottom for l in content)))
    if len(ext) < 3:                                  # too few pages to show where the artist stops
        return (int(w * 0.04), int(h * 0.04), int(w * 0.96), int(h * 0.92))
    return (min(e[0] for e in ext), min(e[1] for e in ext), max(e[2] for e in ext), max(e[3] for e in ext))


def content_limit(psd):
    """How far down the artist lets a page go: the lowest content on any of the PSD's pages."""
    from .artist_design import psd_render

    h = psd.size[1]
    lows = [max((l.bottom for l in _page_content(t, h)), default=0) for t in _tops(psd) if psd_render.is_page(t)]
    if len(lows) < 3:                                 # too few pages to show where the artist stops
        return max(lows + [int(h * 0.92)])
    return max(lows)


def place_new_rows(psd, the_plan, progress=None):
    """Place the rows the new AGR added (see above) into `psd` in memory. Returns the PSD (its layer
    tree rebuilt when layers were added) and fills the_plan["rows_added"]."""
    from .psd_apply.records import RecordExecutor

    ops = row_ops(psd, the_plan)
    if ops is None:
        return psd
    the_plan.setdefault("_ops", []).extend(ops)
    # remember every planned layer by its record: places shift once layers are added
    rec_of = {n: id(l._record) for n, l in enumerate(psd.descendants())}
    top_rec = {i: id(t._record) for i, t in enumerate(_tops(psd))}
    run = RecordExecutor(psd, the_plan)
    run.run_all(ops)
    psd = run.psd
    _remap_places(psd, the_plan, rec_of, top_rec)
    return psd


def place_symbols(psd, the_plan):
    """Put a picture of each symbol the new Excel added into the gap left for it (_decide), sized and
    sat like the page's other icons (psd_apply add_symbol). Returns the PSD (its tree rebuilt when
    pictures were added)."""
    from .psd_apply import layer_ref
    from .psd_apply.records import RecordExecutor

    layers = list(psd.descendants())
    by_id = {l.layer_id: (n, l) for n, l in enumerate(layers)}
    tops = _tops(psd)
    sources = {}
    for s in the_plan.get("symbol_layers") or []:
        got = by_id.get(s["layer"])
        if got is not None:
            sources.setdefault(sym_key(s["token"]), []).append(got)
    ops = []
    for n, item in enumerate(the_plan["items"]):
        if not item.get("gap_spans") or item.get("status") != "change":
            continue
        page = int(item["page_key"]) if str(item.get("page_key", "")).isdigit() else None
        text = by_id.get(item.get("layer_id"))
        if page is None or page >= len(tops) or text is None:
            if text is not None and text[1].kind == "type":
                redraw(psd, text[1])                  # its new text wasn't drawn yet (set_text: draw_later)
            continue
        symbols = []                                  # each gap of the new text, in order
        for token, at in zip(item["added_symbols"], item["gap_spans"]):
            cands = sorted(sources.get(sym_key(token), []), key=lambda c: (not c[1].visible, -c[1].width * c[1].height))
            symbols.append({"token": token, "at": list(at), "sources": [layer_ref(l, p) for p, l in cands]})
        icons = [dict(layer_ref(by_id[f["layer"]][1], by_id[f["layer"]][0]), dx=f["dx"], dy=f["dy"])
                 if f["layer"] in by_id else {"layer": None, "place": None} for f in item.get("follow_icons") or []]
        ops.append({"op": "add_symbol", "text": layer_ref(text[1], text[0]), "page": tops[page].layer_id,
                    "symbols": symbols, "icons": icons, "ref": ["items", n]})
    if not ops:
        return psd
    the_plan.setdefault("_ops", []).extend(ops)
    rec_of = {n: id(l._record) for n, l in enumerate(layers)}
    top_rec = {i: id(t._record) for i, t in enumerate(tops)}
    run = RecordExecutor(psd, the_plan)
    run.run_all(ops)
    _remap_places(run.psd, the_plan, rec_of, top_rec)
    return run.psd


def row_ops(psd, the_plan):
    """The rows the new AGR added that no layer shows, as ops (psd_apply): each a copy of the page's
    most alike row with the new text, under the row before it; then, per page, a Continued page if
    it now runs too long. Rows that can't be placed safely go to the artist (in rows_added).
    None when no page has rows to add."""
    from .psd_apply import layer_ref

    sheets_b = the_plan.get("_sheets_b") or {}
    page_sheet = the_plan["page_sheet"]
    todo = {}
    for row in the_plan.get("new_rows") or []:
        pages = sorted(int(k) for k, s in page_sheet.items() if s == row["sheet"] and str(k).isdigit())
        if pages and row["sheet"] in sheets_b:
            todo.setdefault(pages[-1], []).append(row["row"])
    added = the_plan.setdefault("rows_added", [])
    if not todo:
        return None
    layers0 = list(psd.descendants())
    place_of = {id(l._record): n for n, l in enumerate(layers0)}
    tops0 = _tops(psd)
    limit = content_limit(psd)
    ops = []
    for page_key, rows in sorted(todo.items()):
        page = tops0[page_key]
        sheet_name = page_sheet[str(page_key)] if str(page_key) in page_sheet else page_sheet.get(page_key)
        sheet = sheets_b[sheet_name]
        shown = []                                    # (B row, layer, (first, last) paragraph)
        for item in the_plan["items"]:
            if str(item.get("page_key")) != str(page_key) or not item.get("rows_b"):
                continue
            layer = layers0[item["place"]]
            text = _editor_text(layer)
            for r, span in _rows_in_layer(text, item["rows_b"], sheet).items():
                shown.append((r, layer, span))
        placed = set()                                # B rows this page gets
        for r in sorted(rows):
            want = sheet.row_text(r)
            cands = sorted(((difflib.SequenceMatcher(None, norm(sheet.row_text(sr)), norm(want), autojunk=False).ratio()
                             + (0.2 if tokens_in(sheet.row_text(sr)) == tokens_in(want) else 0.0), sr, lay, span)
                            for sr, lay, span in shown), key=lambda c: -c[0])
            entry = {"page_key": page_key, "page": page.name, "sheet": sheet_name, "row": r, "text": want}
            added.append(entry)
            if not cands or cands[0][0] < 0.5:
                entry.update(status="artist", why="no row on this page looks like it — add it by hand")
                continue
            _score, tmpl_row, tmpl, (p0, p1) = cands[0]
            text = _editor_text(tmpl)
            spans = _para_spans(text)
            para = text[spans[p0][0]:spans[p1][1]]
            new, why = word_diff(para, sheet.row_text(tmpl_row), want, icons=True)
            if new is None or tokens_in(sheet.row_text(tmpl_row)) != tokens_in(want):
                entry.update(status="artist", why=why or "its symbols differ from the row it would copy — add it by hand")
                continue
            # where it goes: under the row before it (shown, or placed just now)
            prev_placed = max((x for x in placed if x < r), default=None)
            prev_rows = [(sr, lay, sp) for sr, lay, sp in shown if sr < r]
            prev_shown = max((x[0] for x in prev_rows), default=None)
            if prev_placed is not None and (prev_shown is None or prev_placed > prev_shown):
                after = {"row": prev_placed}
            elif prev_rows:
                _sr, lay, sp = max(prev_rows, key=lambda x: x[0])
                after = dict(layer_ref(lay, place_of[id(lay._record)]), paragraph=sp[1])
            else:
                entry.update(status="artist", why="no row before it on this page — add it by hand")
                continue
            ops.append({"op": "add_row", "page": page.layer_id, "page_key": page_key, "sheet": sheet_name, "row": r,
                        "template": dict(layer_ref(tmpl, place_of[id(tmpl._record)]), paragraphs=[p0, p1]),
                        "template_row": tmpl_row, "text": new, "symbols": bool(_ICON_GAP.search(para)),
                        "after": after, "ref": ["rows_added", len(added) - 1]})
            placed.add(r)
        # too long for the page now: the rows past the artist's content area go onto a Continued copy
        ops.append({"op": "continue_if_over", "page": page.layer_id, "page_key": page_key, "sheet": sheet_name,
                    "limit": limit})
    return ops


def _continue_page(psd, the_plan, page_key, bands, over, sheet_name, limit, name=None):
    """Move the rows bands[over:] of page `page_key` onto a new Continued page right after it: a new
    group holding copies of the heading (bands[0]), a copy of the PSD's own "(CONTINUED)" label and
    the rows themselves — moved there, not copied: nothing is left hidden on either page (Photoshop
    may show a hidden copied text layer, so the tool never builds a page out of hidden layers)."""
    from psd_tools import PSDImage

    from .artist_design import psd_pages

    page = _tops(psd)[page_key]
    upward = (the_plan.get("page_changes") or {}).get("upward", True)
    over_layers = [l for b in bands[over:] for l in b["layers"]]
    head_layers = list(bands[0]["layers"])
    order = {id(r): n for n, r in enumerate(psd._record.layer_and_mask_information.layer_info.layer_records)}
    over_layers.sort(key=lambda l: order[id(l._record)])  # bottom to top, as they stack now
    head_layers.sort(key=lambda l: order[id(l._record)])
    tops = _tops(psd)
    above = page if upward else (tops[page_key - 1] if page_key > 0 else None)
    name = name or f"{sheet_name} (Continued){NEW_TAG}"
    cont_rec = psd_pages.empty_group_like(psd, page, above=above, name=name, color="green")
    psd = PSDImage(psd._record)
    cont = next(t for t in psd.descendants() if t._record is cont_rec)   # (in its group of pages, if any)
    label, d_label, d_text = None, 48.0, 76.0
    for top in _tops(psd):                            # the artist's own "(CONTINUED)" label, and its spacing
        for t in top.descendants() if top.is_group() else []:
            if t.kind == "type" and t.visible and norm(t.text) in ("(continued)", "continued", "(cont.)"):
                label = t
                own = _row_bands([l for l in _page_content(top, psd.size[1]) if l._record is not t._record])
                if len(own) > 1:                      # heading, then label, then the text on that page
                    d_label = t.top - own[0]["bottom"]
                    d_text = own[1]["top"] - t.bottom
                break
        if label is not None:
            break
    if any(t.kind == "type" and re.search(r"\bcontinued\b", str(t.text or ""), re.I) for t in head_layers):
        label = None                                  # its heading says "continued" already (a continued page's)
        labelled = True
    else:
        labelled = label is not None
    head_copies = psd_pages.copy_layers(psd, head_layers, into=cont)
    label_rec = psd_pages.copy_layers(psd, [label], into=cont)[0] if label is not None else None
    psd_pages.move_layers(psd, over_layers, into=cont)
    psd = PSDImage(psd._record)
    by_rec = {id(l._record): l for l in psd.descendants()}
    first_content = bands[1]["top"] if len(bands) > 1 else bands[0]["bottom"]
    y0 = first_content
    if label_rec is not None:
        lab = by_rec[id(label_rec)]
        move_layer(lab, psd.size[0] / 2.0 - (lab.left + lab.right) / 2.0, bands[0]["bottom"] + d_label - lab.top)
        y0 = max(first_content, lab.bottom + d_text)
    dy = y0 - bands[over]["top"]
    for l in over_layers:
        move_layer(by_rec[id(l._record)], 0, dy)
    the_plan.setdefault("rows_added", []).append({
        "page_key": page_key, "page": name, "sheet": sheet_name, "row": None,
        "text": f"{len(over_layers)} layer(s) moved onto a Continued page ({len(head_copies)} heading layer(s) copied)",
        "status": "change", "why": "the page ran past the space the artist's pages use"
                                   + ("" if labelled else " — add the (CONTINUED) label by hand"),
        "_continued": id(cont_rec), "_from_page": page_key})
    return psd


_CONT_WORD = re.compile(r"\b(cont|cont\.|con|continued)\b\.?", re.I)


def _page_base(name):
    """A page group's name without its number and any "cont"/"continued": what its continued pages share
    ("6_Feature Upgrade" and "7_Feature Upgrade cont" are both "feature upgrade")."""
    name = re.sub(r"[\x00-\x1f]", "", str(name or ""))
    name = re.sub(r"^\s*\d+\s*[_\-. ]\s*", "", name)
    name = re.sub(r"[(\[]\s*[)\]]", " ", _CONT_WORD.sub(" ", name))   # "Bonus (Continued)": no "()" left
    return " ".join(name.split()).casefold()


def _page_number(name):
    m = re.match(r"^\s*(\d+)", str(name or ""))
    return int(m.group(1)) if m else None


def continued_page(psd, index):
    """The top-level index of the artist's own continued page of page `index` — a page further on whose
    name is its name with "cont" / "continued" — or None."""
    from .artist_design import psd_render

    tops = _tops(psd)
    page = tops[index]
    base, num = _page_base(page.name), _page_number(page.name)
    cands = []
    for i, t in enumerate(tops):
        if i == index or not psd_render.is_page(t) or not _CONT_WORD.search(re.sub(r"[\x00-\x1f]", "", t.name)):
            continue
        if _page_base(t.name) != base:
            continue
        n = _page_number(t.name)
        if num is not None and n is not None:
            if n > num:
                cands.append((n - num, i))
        else:                                         # unnumbered: the nearest group in the stack
            cands.append((abs(i - index), i))
    return min(cands)[1] if cands else None


def _overflow(page, h, limit):
    """(bands, first band to move) of a page whose content runs past `limit`, or None. The band before a
    section — its sub-heading, one line of text on its own — goes with it."""
    bands = _row_bands(_page_content(page, h))
    over = next((k for k, b in enumerate(bands) if k > 0 and b["bottom"] > limit + 4), None)
    if over is None:
        return None
    if over > 1:
        prev = bands[over - 1]
        lone = all(l.kind == "type" for l in prev["layers"]) and \
            all("\r" not in str(l.text or "").strip("\r") for l in prev["layers"])
        if lone and over - 1 > 1:                     # (never the page's own heading, band 0)
            over -= 1
    return bands, over


def flow_over(psd, the_plan, index, limit, depth=0):
    """Page `index` runs past the bottom of the artist's working area (`limit`): its last sections go
    onto the artist's own continued page — at the top of its content, which moves down to make room —
    and on from there when that page then runs over too; a new Continued page (a copy of the page) is
    made only where there's no continued page of the artist's. Returns the PSD (rebuilt)."""
    from psd_tools import PSDImage

    from .artist_design import psd_pages

    h = psd.size[1]
    tops = _tops(psd)
    page = tops[index]
    got = _overflow(page, h, limit)
    if got is None or depth > 8:
        return psd
    bands, over = got
    if over <= 1 and bands[over]["bottom"] - bands[over]["top"] > limit - bands[0]["bottom"]:
        _flow_note(the_plan, page, "a section is taller than a whole page — split it by hand")
        return psd
    cont_i = continued_page(psd, index)
    if cont_i is None:
        sheet = (the_plan.get("page_sheet") or {}).get(str(index)) or re.sub(r"^\s*\d+\s*_", "", page.name)
        # named the artist's way: "6_Feature Upgrade" → "6_Feature Upgrade cont", a continued page's own
        # → "7_Feature Upgrade cont 2" (the next number is the artist's next page: not taken)
        own = _clean_name(page.name).strip()
        if _CONT_WORD.search(own):
            m = re.search(r"\s(\d+)$", own)
            own = own[:m.start()] + f" {int(m.group(1)) + 1}" if m else own + " 2"
        else:
            own += " cont"
        the_plan.setdefault("_flowed", []).append({"from": id(page._record), "to": None, "to_name": own,
                                                   "layers": [id(l._record) for b in bands[over:] for l in b["layers"]]})
        return _continue_page(psd, the_plan, index, bands, over, sheet, limit, name=own + NEW_TAG)
    cont = tops[cont_i]
    moving = [l for b in bands[over:] for l in b["layers"]]
    block_top = bands[over]["top"]
    block_h = max(l.bottom for l in moving) - block_top
    gap = block_top - bands[over - 1]["bottom"]       # the space the artist left before this section
    cbands = _row_bands(_page_content(cont, h))
    k0 = 1
    if len(cbands) > 1 and all(l.kind == "type" and norm(l.text) in ("(continued)", "continued", "(cont.)")
                               for l in cbands[1]["layers"]):
        k0 = 2                                        # under the page's "(CONTINUED)" label
    if len(cbands) > k0:
        at = cbands[k0]["top"]
        first = next((l for l in cbands[k0]["layers"] if l.kind == "type"), cbands[k0]["layers"][0])
        into = first.parent if first.parent is not None and first.parent.is_group() else cont
    else:
        at = cbands[-1]["bottom"] + gap if cbands else block_top
        into = cont
    for b in cbands[k0:]:                             # the continued page's content makes room
        for l in b["layers"]:
            move_layer(l, 0, block_h + gap)
    for l in moving:
        move_layer(l, 0, at - block_top)
    order = {id(r): n for n, r in enumerate(psd._record.layer_and_mask_information.layer_info.layer_records)}
    moving.sort(key=lambda l: order[id(l._record)])  # bottom to top, as they stack now
    psd_pages.move_layers(psd, moving, into=into)
    psd = PSDImage(psd._record)
    the_plan.setdefault("_flowed", []).append({"from": id(page._record), "to": id(cont._record),
                                               "to_name": _clean_name(cont.name),
                                               "layers": [id(l._record) for l in moving]})
    return flow_over(psd, the_plan, cont_i, limit, depth + 1)


def reflow_pages(psd, the_plan):
    """Every page this update changed that now runs past the bottom of the artist's working area
    (the_plan["work_area"]) flowed onto its continued page (flow_over, as psd_apply ops). The plan's
    layer places / page keys follow, and each moved layer's change says where it went. Returns the PSD."""
    from .psd_apply.records import RecordExecutor

    area = the_plan.get("work_area")
    if not area:
        return psd
    tops = _tops(psd)
    touched = sorted({int(i["page_key"]) for i in the_plan["items"] + (the_plan.get("icon_edits") or [])
                      if i.get("status") == "change" and str(i.get("page_key", "")).isdigit()})
    h = psd.size[1]
    ops = [{"op": "flow_over", "page": tops[k].layer_id, "limit": area[3]} for k in touched
           if k < len(tops) and tops[k].is_group() and _overflow(tops[k], h, area[3]) is not None]
    if not ops:
        return psd
    the_plan.setdefault("_ops", []).extend(ops)
    layers = list(psd.descendants())
    rec_of = {n: id(l._record) for n, l in enumerate(layers)}
    top_rec = {i: id(t._record) for i, t in enumerate(tops)}
    run = RecordExecutor(psd, the_plan)
    run.run_all(ops)
    psd = run.psd
    _remap_places(psd, the_plan, rec_of, top_rec)
    # each changed layer that moved: on its new page, saying so; a page whose overflow went no longer
    # needs the artist to move it
    new_tops = _tops(psd)
    index_of = {id(t._record): i for i, t in enumerate(new_tops)}
    moved_to = {r: f["to_name"] for f in the_plan.pop("_flowed", []) for r in f["layers"]}
    page_of = {id(l._record): i for i, t in enumerate(new_tops) if t.is_group() for l in t.descendants()}
    layers = list(psd.descendants())
    flowed_pages = set()
    for item in the_plan["items"]:
        place = item.get("place")
        if place is None or not 0 <= place < len(layers):
            continue
        rec = id(layers[place]._record)
        if rec in moved_to:
            i = page_of.get(rec)
            if i is not None:
                flowed_pages.add(item.get("page_key"))
                item.update(page_key=str(i), page=_clean_name(new_tops[i].name), moved_to=moved_to[rec])
                item["why"] = (item.get("why", "") + f" · moved onto “{moved_to[rec]}”: it ran past the bottom "
                               "of the area the artist keeps content in").strip(" ·")
    for item in the_plan["items"]:                    # their page's overflow went: nothing left to move by hand
        if "move what doesn't fit onto a Continued page" in str(item.get("why", "")) and (
                item.get("moved_to") or item.get("page_key") in flowed_pages):
            item["why"] = re.sub(r"\s*·?\s*the page now runs \d+ px below[^·]*", "", item["why"]).strip(" ·")
    for rec, why in the_plan.pop("_flow_notes", []):
        i = index_of.get(rec)
        item = next((x for x in the_plan["items"] if x.get("page_key") == str(i) and x.get("status") == "change"), None)
        if item is not None:
            item["why"] = (item.get("why", "") + " · " + why).strip(" ·")
    return psd


def _clean_name(name):
    return re.sub(r"[\x00-\x1f]", "", str(name or ""))


def _flow_note(the_plan, page, why):
    the_plan.setdefault("_flow_notes", []).append((id(page._record), why))


def _remap_places(psd, the_plan, rec_of, top_rec):
    """After layers were added: the plan's layer places / page keys follow their records."""
    place_of = {id(l._record): n for n, l in enumerate(psd.descendants())}
    page_of = {id(l._record): i for i, t in enumerate(_tops(psd)) if t.is_group() for l in t.descendants()}
    tops = _tops(psd)
    index_of = {id(t._record): i for i, t in enumerate(tops)}
    remap = {n: place_of.get(r) for n, r in rec_of.items()}
    page_remap = {i: index_of.get(r) for i, r in top_rec.items()}
    for item in the_plan["items"]:
        if item.get("place") is not None:
            item["place"] = remap.get(item["place"], item["place"])
        if str(item.get("page_key", "")).isdigit() and page_remap.get(int(item["page_key"])) is not None:
            item["page_key"] = str(page_remap[int(item["page_key"])])
    for e in the_plan.get("icon_edits") or []:
        e["hide"] = [remap.get(p, p) for p in e["hide"]]
        e["move"] = [[remap.get(m[0], m[0])] + list(m[1:]) for m in e["move"]]
        if str(e.get("page_key", "")).isdigit() and page_remap.get(int(e["page_key"])) is not None:
            e["page_key"] = str(page_remap[int(e["page_key"])])
    the_plan["_box0"] = {remap[n]: b for n, b in (the_plan.get("_box0") or {}).items() if remap.get(n) is not None}
    the_plan["page_sheet"] = {(str(page_remap.get(int(k), int(k))) if str(k).isdigit() else k): v
                              for k, v in the_plan["page_sheet"].items()}
    src_index = {}
    for i, v in (the_plan.get("_src_index") or {}).items():
        if page_remap.get(i) is not None:
            src_index[page_remap[i]] = v
    for row in the_plan.get("rows_added") or []:    # the rows placed: shown like the page's other changes
        if row.get("_continued") is not None:
            i = index_of.get(row["_continued"])
            j = (the_plan.get("_src_index") or {}).get(row["_from_page"], ("page", row["_from_page"], None))
            if i is not None:
                src_index[i] = ("new", j[1], row["sheet"] + " (Continued)")
                row["page_key"] = i
                cont = tops[i]
                shown = [l for l in _page_content(cont, psd.size[1])]
                if shown:                             # one picture of the whole continued page's content
                    box = [min(l.left for l in shown), min(l.top for l in shown), max(l.right for l in shown),
                           max(l.bottom for l in shown)]
                    the_plan["items"].append({"page": cont.name, "page_key": str(i), "layer": "continued page",
                                              "box": box, "old": "", "new": row["text"], "status": "change",
                                              "why": row["why"], "source": row["sheet"]})
        elif row.get("_rec") is not None and row.get("status") == "change" and \
                page_of.get(row["_rec"]) == page_remap.get(row["page_key"], row["page_key"]):
            # (a row that went on to a Continued page shows there, not here)
            row["page_key"] = page_remap.get(row["page_key"], row["page_key"])
            the_plan["items"].append({"page": row["page"], "page_key": str(row["page_key"]), "layer": "row added",
                                      "place": place_of.get(row["_rec"]), "old": "", "new": row["text"],
                                      "status": "change", "why": row["why"], "source": f"{row['sheet']}!row {row['row']}"})
        row.pop("_rec", None)
        row.pop("_continued", None)
        row.pop("_from_page", None)
    the_plan["_src_index"] = src_index
    placed_rows = {(r["sheet"], r["row"]) for r in the_plan.get("rows_added") or [] if r.get("status") == "change" and r.get("row")}
    the_plan["new_rows"] = [r for r in the_plan.get("new_rows") or [] if (r["sheet"], r["row"]) not in placed_rows]
    missing = {}
    for page_key, rows in list((the_plan.get("_missing_rows") or {}).items()):
        left = [t for t in rows if any(t == r["text"] for r in the_plan["new_rows"])]
        new_key = page_remap.get(page_key, page_key)
        if left:
            missing[new_key] = left
    the_plan["_missing_rows"] = missing


# ── one pass: plan in memory, preview, write ──────────────────────────────────
def prepare(source_psd, excel_a, excel_b, links=None, icon_folder=None, reject=()):
    """(psd in memory, plan): the artist's PSD opened once, page groups copied / marked for the
    sheets the new AGR added / removed, every layer planned. Nothing is written. `reject`: page ids
    the artist kept as they were ("page:<group name>", "new:<sheet>", "removed:<sheet>")."""
    from psd_tools import PSDImage

    from .artist_design import psd_reader

    sheets_a, sheets_b = read_workbook(excel_a), read_workbook(excel_b)
    renames = sheet_renames(sheets_a, sheets_b)
    view_b = dict(sheets_b)
    for a, b in renames.items():                      # a renamed sheet is the same sheet
        view_b[a] = sheets_b[b]
    src = psd_reader.open_lazy(source_psd)
    from .psd_apply import splice

    splice.remember(src, source_psd)                  # the new PSD copies what the update leaves alone
    the_plan = plan(src, sheets_a, view_b, excel_a, icon_folder, links)
    # the artist's PSD as it is, bound to its own AGR (kept with the game once the PSD is cloned)
    source_binding = binding.make(src, the_plan, source_psd, excel_a, side="a")
    # a PSD written without Photoshop has no layer IDs: the new PSD gets them (in memory here, before
    # pages are copied), so its own binding can find every layer by ID
    from .artist_design import psd_pages

    ids_given = psd_pages.ensure_layer_ids(src)
    if ids_given:
        now = list(src.descendants())                 # nothing added yet: places still hold
        for item in the_plan["items"]:
            item["layer_id"] = now[item["place"]].layer_id
        for sym in the_plan["symbol_layers"]:
            sym["layer"] = now[sym["place"]].layer_id
    source_ids = {l.layer_id for l in src.descendants()}
    pages = plan_pages(src, the_plan, sheets_a, sheets_b, renames, links)
    reject = set(reject or ())
    src_tops = _tops(src)
    psd, page_ops = src, []
    if any(e["status"] == "add" for e in pages["new"]) or any(e["status"] == "mark" for e in pages["removed"]):
        copies, holder, page_ops = _apply_pages(src, pages, reject)
        psd = PSDImage(src._record)                   # the same records, with the copies, as a tree
        sheets_a2 = dict(sheets_a)
        links2 = {"pages": dict((links or {}).get("pages") or {}), "chosen": dict((links or {}).get("chosen") or {}),
                  "symbols": dict((links or {}).get("symbols") or {})}
        src_index, n = {}, 0
        for i, top in enumerate(_tops(psd)):
            if holder is not None and top._record is holder:   # not a page: nothing in it is edited
                src_index[i] = ("deleted", None, None)
                links2["chosen"][page_link_key(str(i), top.name)] = ""
                continue
            got = copies.get(id(top._record))
            if got:
                sheet, sibling, from_index = got
                twin = copy.copy(sheets_a[sibling])   # the copy still shows its sibling sheet's text
                twin.name = sheet
                sheets_a2[sheet] = twin
                links2["chosen"][page_link_key(str(i), top.name)] = sheet
                src_index[i] = ("new", from_index, sheet)
                continue
            while n < len(src_tops) and src_tops[n]._record is not top._record:
                n += 1
            src_index[i] = ("page", n, None)
            # each of the artist's pages keeps the sheet it showed: a copy shows the same text as its
            # original, and the original must not be taken for the copy (Hunt's Bonuses page read as
            # "Bonuses NEW" once that page was added)
            was = the_plan["page_sheet"].get(str(n))
            key = page_link_key(str(i), top.name)
            if was and was in sheets_a2 and key not in links2["chosen"]:
                links2["chosen"][key] = was
            n += 1
        the_plan = plan(psd, sheets_a2, view_b, excel_a, icon_folder, links2)
    else:
        src_index = {i: ("page", i, None) for i in range(len(src_tops))}
    the_plan["page_changes"] = pages
    the_plan["content_changes"] = content_diff.compare(sheets_a, sheets_b, renames)
    the_plan["_source_binding"] = source_binding
    the_plan["_ops"] = list(page_ops)                 # every change, in order, as ops (psd_apply)
    the_plan["_ids_given"] = ids_given                # layers the file had no ID for (Photoshop's would differ)
    the_plan["_source_ids"] = source_ids              # the layers the artist's file has (by ID)
    the_plan["_src_index"] = src_index
    the_plan["_removed"] = [(i, e["sheet"]) for e in pages["removed"] if e["status"] == "mark" for i in e["groups"]]
    the_plan["_sheets_b"] = view_b
    last_page = {}
    for key, sheet in the_plan["page_sheet"].items():
        if str(key).isdigit():
            last_page[sheet] = max(last_page.get(sheet, -1), int(key))
    missing = {}
    for row in the_plan["new_rows"]:                  # rows of a page's sheet no layer shows yet
        if row["sheet"] in last_page:
            missing.setdefault(last_page[row["sheet"]], []).append(row["text"])
    the_plan["_missing_rows"] = missing
    the_plan["_source"] = src_tops
    for item in the_plan["items"] + (the_plan.get("icon_edits") or []):   # pages the artist kept as they are
        kind, i, _s = src_index.get(int(item["page_key"]), ("", None, None)) if str(item.get("page_key", "")).isdigit() else ("", None, None)
        if kind == "page" and page_id(src_tops[i]) in reject and item.get("status") == "change":
            item.update(status="kept", skip=True, why="kept as the artist made it (not approved)")
    return psd, the_plan


def color_pages(psd, the_plan):
    """The Layers panel says what happened to each page: new pages yellow, pages with changes orange,
    pages of the Excel with no changes green ("[Deleted From Excel]" is red already). Groups that
    show no sheet (backgrounds, buttons, pay-line pictures) keep the artist's colours."""
    from .psd_apply.records import RecordExecutor

    src_index = the_plan.get("_src_index") or {}
    changed = {int(i["page_key"]) for i in the_plan["items"] + (the_plan.get("icon_edits") or [])
               if i.get("status") == "change" and str(i.get("page_key", "")).isdigit()}
    linked = {int(k) for k, sheet in the_plan["page_sheet"].items() if str(k).isdigit() and sheet}
    counts = {"yellow": 0, "orange": 0, "green": 0}
    ops = []
    for i, top in enumerate(_tops(psd)):
        kind = src_index.get(i, ("page", i, None))[0]
        if kind == "deleted" or not top.is_group():
            continue
        color = "yellow" if kind == "new" else "orange" if i in changed else "green" if i in linked else None
        if color:
            ops.append({"op": "label", "group": top.layer_id, "color": color})
            counts[color] += 1
    the_plan.setdefault("_ops", []).extend(ops)
    RecordExecutor(psd, the_plan).run_all(ops)
    return counts


def page_id(top):
    return "page:" + re.sub(r"[\x00-\x1f]", "", top.name)


def save(psd, out_path):
    """Write the PSD. One read from the artist's file (prepare) is written by copying everything the
    update didn't touch byte for byte (psd_apply.splice); returns what was copied, else None."""
    from .psd_apply import splice

    os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
    if splice.known(psd):
        return splice.write(psd, out_path)
    tmp = out_path + ".tmp"
    with open(tmp, "wb") as f:
        psd._record.write(f)
    os.replace(tmp, out_path)
    return None


def untouched_spliced(psd, the_plan, written):
    """untouched_check for a PSD written by the splice writer: a page nothing was planned for is the
    artist's byte for byte when every layer in it was copied raw (its own record — the colour label —
    aside). Nothing is read again."""
    touched = {int(i["page_key"]) for i in the_plan["items"] + (the_plan.get("icon_edits") or [])
               if i.get("status") == "change" and str(i.get("page_key", "")).isdigit()}
    tops = _tops(psd)
    same, differ = 0, []
    for i, (kind, _j, _s) in sorted((the_plan.get("_src_index") or {}).items()):
        if kind != "page" or i in touched or i >= len(tops) or not tops[i].is_group():
            continue
        if all(id(l._record) in written["clean"] for l in tops[i].descendants()):
            same += 1
        else:
            differ.append(re.sub(r"[\x00-\x1f]", "", tops[i].name))
    return {"pages": same, "differ": differ}


def write(source_psd, the_plan, out_path):
    """The artist's PSD with `the_plan` (made on a fresh open of it) applied, saved to out_path."""
    from .artist_design import psd_reader

    psd = psd_reader.open_lazy(source_psd)
    edited = apply(psd, the_plan)
    save(psd, out_path)
    return edited


def untouched_check(source_psd, out_path, the_plan):
    """Every page group nothing was planned for, compared with the artist's file: its layers, their
    pixels and their document text entries. Returns {"pages": n identical, "differ": [names]}."""
    import io

    from psd_tools.constants import Tag

    from .artist_design import psd_pages, psd_reader

    src, out = psd_reader.open_lazy(source_psd), psd_reader.open_lazy(out_path)
    touched = {int(i["page_key"]) for i in the_plan["items"] + (the_plan.get("icon_edits") or [])
               if i.get("status") == "change" and str(i.get("page_key", "")).isdigit()}
    version = src._record.header.version

    def engine(p):
        blocks = p._record.layer_and_mask_information.tagged_blocks
        data = blocks.get_data(Tag.TEXT_ENGINE_DATA) if blocks is not None else None
        try:
            return data["1"]["1"] if data is not None else None
        except Exception:
            return None

    def raw(element, **kw):
        b = io.BytesIO()
        element.write(b, **kw)
        return b.getvalue()

    def unchanged(ra, rb):
        if raw(ra, encoding="macroman", version=version) == raw(rb, encoding="macroman", version=version):
            return True
        # a layer the artist's file has no ID for got one (psd_pages.ensure_layer_ids): not a change
        if ra.tagged_blocks.get_data(Tag.LAYER_ID) is None and rb.tagged_blocks.get_data(Tag.LAYER_ID) is not None:
            del rb.tagged_blocks[Tag.LAYER_ID]        # `out` is only read here
            return raw(ra, encoding="macroman", version=version) == raw(rb, encoding="macroman", version=version)
        return False

    se, oe = engine(src), engine(out)
    s_tops, o_tops = _tops(src), _tops(out)
    same, differ = 0, []
    for i, (kind, j, _s) in sorted(the_plan["_src_index"].items()):
        if kind != "page" or i in touched or not s_tops[j].is_group():
            continue
        try:
            (a0, a1), (b0, b1) = psd_pages.group_span(src, s_tops[j]), psd_pages.group_span(out, o_tops[i])
            sl, ol = src._record.layer_and_mask_information.layer_info, out._record.layer_and_mask_information.layer_info
            ok = (a1 - a0) == (b1 - b0)
            for k in range(a1 - a0) if ok else ():     # everything in the group (its own record: the colour label)
                ra, rb = sl.layer_records[a0 + k], ol.layer_records[b0 + k]
                if not unchanged(ra, rb) or \
                        [c.data for c in sl.channel_image_data[a0 + k]] != [c.data for c in ol.channel_image_data[b0 + k]]:
                    ok = False
                    break
                ta = ra.tagged_blocks.get_data(Tag.TYPE_TOOL_OBJECT_SETTING)
                if ta is not None and se is not None and oe is not None:
                    n = int(ta.text_data[b"TextIndex"])
                    if raw(se[n]) != raw(oe[n]):
                        ok = False
                        break
        except Exception:
            ok = False
        if ok:
            same += 1
        else:
            differ.append(s_tops[j].name)
    return {"pages": same, "differ": differ}


def preview(source_psd, excel_a, excel_b, folder, links=None, icon_folder=None, reject=(), progress=None, draw=True):
    """What the new PSD would be — nothing written: the report, and for every page that would
    change, be added or be marked deleted, a picture before and after (for the artist to approve)."""
    if progress:
        progress("Reading the PSD and both Excel files…", 10)
    psd, the_plan = prepare(source_psd, excel_a, excel_b, links, icon_folder, reject)
    if progress:
        progress("Changing the pages in memory…", 30)
    edited = apply(psd, the_plan)
    psd = place_new_rows(psd, the_plan)
    psd = place_symbols(psd, the_plan)                # pictures of symbols the new Excel added
    psd = reflow_pages(psd, the_plan)                 # what now runs past the working area: continued pages
    report = summary(the_plan)
    report.update(source_psd=source_psd, excel_a=excel_a, excel_b=excel_b, edited=edited,
                  pages=review_pictures(source_psd, psd, the_plan, folder, progress, draw=draw))
    # for the caller that draws the crops later / shows whole pages on demand (not part of the report)
    report.update(_psd=psd, _plan=the_plan, _crop_jobs=the_plan.pop("_crop_jobs", []))
    return report


def clone(source_psd, excel_a, excel_b, out_path, report_path=None, icon_folder=None, pictures=True, progress=None,
          links=None, photoshop=False, reject=(), edits=None, game_id=None, engine="records", photoshop_redraw=True):
    """Market B's PSD from market A's hand-made PSD. Returns the report (also saved as JSON), with
    before / after pictures of every page that changed (or needs a look) unless `pictures` is off.
    `links`: the page / symbol links the artist confirmed (see plan). `reject`: pages the artist
    kept as they were (see prepare). `photoshop`: let Photoshop (when installed) lay out the edited
    text layers and save, so none shows a warning triangle. Both PSDs' bindings (binding.py) are
    kept with the game `game_id`; the new PSD also carries its own.
    `engine`: "records" (the PSD written by the tool, psd_apply.records) or "photoshop" (the changes
    made by Photoshop on the artist's PSD, psd_apply.photoshop; the tool's own way when Photoshop
    can't — the report's "engine" and "engine_note" say which made it and why)."""
    import json

    psd, the_plan = prepare(source_psd, excel_a, excel_b, links, icon_folder, reject)
    the_plan["photoshop_redraw"] = photoshop_redraw     # edited text: Photoshop asks to update it on open
    edited = apply(psd, the_plan)
    psd = place_new_rows(psd, the_plan)
    psd = place_symbols(psd, the_plan)                # pictures of symbols the new Excel added
    lost_edits = apply_edits(psd, edits)               # what the artist typed in the preview
    psd = reflow_pages(psd, the_plan)                 # what now runs past the working area: continued pages
    colors = color_pages(psd, the_plan)
    made_by, note, ps_run = "records", "", None
    if engine == "photoshop":
        made_by, note, ps_run, ps_edited = _made_in_photoshop(source_psd, out_path, psd, the_plan, progress)
        if made_by == "photoshop":
            edited = ps_edited
    out_binding = binding.make(psd, the_plan, "", excel_b, side="b")
    if made_by == "photoshop":
        binding.follow(out_binding, ps_run.get("idmap") or {}, out_path)
    else:
        binding.embed(psd._record, out_binding)
        if progress:
            progress("Saving the new PSD…", 55)
        spliced = save(psd, out_path)
    bindings = _keep_bindings(the_plan["_source_binding"], source_psd, out_binding, out_path, game_id)
    fix = ""
    if edited and made_by == "records":
        try:
            from .psd_writer import photoshop_finish

            fix = photoshop_finish.write_fix_script(out_path)
        except Exception:
            fix = ""
    review = []
    if pictures == "list":
        # the changes listed, their pictures drawn only when the artist asks (draw_crops on a job)
        try:
            review = review_pictures(source_psd, psd, the_plan, os.path.splitext(out_path)[0] + " - review", draw=False)
        except Exception as exc:
            review = [{"error": f"the changes could not be listed: {exc}"}]
    elif pictures:
        try:
            review = review_pictures(source_psd, psd, the_plan, os.path.splitext(out_path)[0] + " - review", progress)
        except Exception as exc:                      # the PSD is fine without its pictures
            review = [{"error": f"pictures could not be drawn: {exc}"}]
    try:
        if progress:
            progress("Checking the pages nothing changed are exactly the artist's…", 92)
        if made_by != "records":
            untouched = untouched_layers(source_psd, out_path, the_plan)
        elif spliced:
            untouched = untouched_spliced(psd, the_plan, spliced)
        else:
            untouched = untouched_check(source_psd, out_path, the_plan)
    except Exception as exc:
        untouched = {"pages": 0, "differ": [], "error": str(exc)}
    finished = ""
    if edited and photoshop and made_by == "records":
        try:
            from .psd_writer import photoshop_finish

            if progress:
                progress("Photoshop is laying out the edited text layers…", 97)
            finished = photoshop_finish.finish(out_path)
            if " finished " in finished:
                photoshop_finish.remove_fix_script(out_path)
                fix = ""
        except Exception as exc:
            finished = f"Photoshop finish skipped: {exc}"
    report = summary(the_plan)
    report.update(source_psd=source_psd, excel_a=excel_a, excel_b=excel_b, out_psd=out_path,
                  edited=edited, fix_script=fix, pages=review, text_engine=the_plan.get("text_engine", ""),
                  photoshop=finished, untouched=untouched, edits_applied=len(edits or {}) - len(lost_edits),
                  edits_lost=lost_edits, colors=colors, bindings=bindings, engine=made_by, engine_note=note,
                  photoshop_run=dict({k: ps_run.get(k) for k in ("version", "was_open", "timings", "wall_s", "error")},
                                     not_made=[r.get("why") for r in ps_run.get("results") or [] if not r.get("ok")])
                  if ps_run else None)
    report_path = report_path or os.path.splitext(out_path)[0] + " - clone report.json"
    with open(report_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=1, ensure_ascii=False)
    report["report_path"] = report_path
    if pictures == "list":                            # for the caller that draws a change when it's clicked
        report.update(_psd=psd, _plan=the_plan, _crop_jobs=the_plan.pop("_crop_jobs", []))
    return report


def _made_in_photoshop(source_psd, out_path, psd, the_plan, progress=None):
    """The planned ops made by Photoshop on the artist's PSD (psd_apply.photoshop). Returns
    (engine that made it, note, Photoshop's report, layers edited): "records" with the reason when
    Photoshop can't make this one — the clone then writes the PSD itself."""
    from .psd_apply import photoshop as ps

    if the_plan.get("_ids_given"):
        return "records", ("made by the tool, not Photoshop: this PSD's layers have no IDs (it wasn't saved by "
                           "Photoshop), so Photoshop's layers can't be matched to the plan"), None, 0
    try:
        if progress:
            progress("Asking Photoshop…", 50)
        ps.ready()
    except Exception as exc:
        return "records", f"made by the tool, not Photoshop: {exc}", None, 0
    ops, skipped = ps.payload(psd, the_plan)
    if progress:
        progress(f"Photoshop is making {len(ops)} change(s) and saving the new PSD…", 55)
    try:
        run = ps.execute(source_psd, out_path, ops)
    except Exception as exc:
        run = {"error": str(exc)}
    if run.get("error") or not os.path.isfile(out_path):
        return "records", f"made by the tool, not Photoshop: Photoshop stopped ({run.get('error')})", run, 0
    return "photoshop", "", run, ps.merge(the_plan, ops, skipped, run)


def untouched_layers(source_psd, out_path, the_plan):
    """untouched_check for a PSD Photoshop saved (its bytes are never the artist's file's): every page
    nothing was planned for, compared layer by layer — kind, name, place, group, text, visibility,
    opacity, blending. Returns {"pages": n identical, "differ": [names]}."""
    from .artist_design import psd_reader

    src, out = psd_reader.open_lazy(source_psd), psd_reader.open_lazy(out_path)
    touched = {int(i["page_key"]) for i in the_plan["items"] + (the_plan.get("icon_edits") or [])
               if i.get("status") == "change" and str(i.get("page_key", "")).isdigit()}
    out_by_id = {l.layer_id: l for l in out.descendants()}

    def look(layer):
        return dict(binding.fingerprint(layer), visible=layer.visible, opacity=layer.opacity,
                    blend=str(layer.blend_mode))

    s_tops = _tops(src)
    same, differ = 0, []
    for i, (kind, j, _s) in sorted(the_plan["_src_index"].items()):
        if kind != "page" or i in touched or not s_tops[j].is_group():
            continue
        page = s_tops[j]
        ok = True
        for layer in list(page.descendants()):
            got = out_by_id.get(layer.layer_id)
            if got is None or look(got) != look(layer):
                ok = False
                break
        if ok:
            same += 1
        else:
            differ.append(page.name)
    return {"pages": same, "differ": differ}


def _keep_bindings(source_binding, source_psd, out_binding, out_path, game_id=None):
    """Keep both PSDs' bindings with the game: the artist's PSD (never written itself) and the new one
    (which also carries its own). Returns what the report says about them; never fails the clone."""
    out = {}
    for name, b, path in (("source", source_binding, source_psd), ("new", out_binding, out_path)):
        try:
            if name == "new":
                b["psd"].update(name=os.path.basename(path), size=os.path.getsize(path))
            out[name] = dict(binding.summary(b), file=binding.save(b, path, game_id))
        except Exception as exc:
            out[name] = {"error": str(exc)}
    return out


def default_out(source_psd, excel_b):
    """Beside the artist's PSD: "<its name> (<market B Excel name>).psd", never over an existing file."""
    folder = os.path.dirname(os.path.abspath(source_psd))
    stem = os.path.splitext(os.path.basename(source_psd))[0]
    market = os.path.splitext(os.path.basename(excel_b))[0]
    path, n = os.path.join(folder, f"{stem} ({market}).psd"), 2
    while os.path.exists(path):
        path, n = os.path.join(folder, f"{stem} ({market}) ({n}).psd"), n + 1
    return path


# ── the links the artist confirmed, saved with the game ───────────────────────
# {psd file name: {"chosen": {page key: sheet}, "pages": {page key: sheet}, "symbols": {signature: token}}} in the
# game's file ("clone_links"), or — with no game open — in a file beside the games list. A
# smart object's name is shared by every PSD of the game, so its symbol link is reused for the
# game's other markets' PSDs too.
def _link_store(game_id=None):
    from . import games

    if game_id:
        game = games.get(game_id)
        if game is not None:
            return game, game.setdefault("clone_links", {})
    path = os.path.splitext(games.REGISTRY_FILE)[0] + "_clone_links.json"
    try:
        from .safe_json import read_json_recover

        data, _note = read_json_recover(path)
    except Exception:
        data = None
    return path, data if isinstance(data, dict) else {}


def load_links(source_psd, game_id=None):
    _where, store = _link_store(game_id)
    key = os.path.basename(str(source_psd)).casefold()
    shared = {}
    for name, entry in store.items():                 # the game's other PSDs: their smart objects' names
        if name != key and isinstance(entry, dict):
            shared.update({s: t for s, t in (entry.get("symbols") or {}).items() if s.startswith("so:") and t})
    own = store.get(key) if isinstance(store.get(key), dict) else {}
    return {"pages": dict(own.get("pages") or {}), "chosen": dict(own.get("chosen") or {}),
            "symbols": dict(shared, **(own.get("symbols") or {})), "saved": own.get("saved", "")}


def save_links(source_psd, links, game_id=None):
    import datetime

    from . import games

    where, store = _link_store(game_id)
    store[os.path.basename(str(source_psd)).casefold()] = {
        "pages": {str(k): str(v or "") for k, v in ((links or {}).get("pages") or {}).items()},
        "chosen": {str(k): str(v or "") for k, v in ((links or {}).get("chosen") or {}).items()},
        "symbols": {str(k): str(v) for k, v in ((links or {}).get("symbols") or {}).items() if v},
        "saved": datetime.datetime.now().isoformat(timespec="seconds")}
    if isinstance(where, dict):
        games.save(where)
    else:
        from .safe_json import write_json

        write_json(where, store)


def symbol_thumbs(source_psd, report, folder, size=96):
    """A small picture of every symbol in a check report (for the clone dialog): adds "thumb"."""
    from PIL import Image

    from .artist_design import psd_reader

    os.makedirs(folder, exist_ok=True)
    layers = dict(enumerate(psd_reader.open_lazy(source_psd).descendants()))
    for n, sym in enumerate(report.get("symbols") or []):
        layer = layers.get(sym.get("place"))
        path = os.path.join(folder, f"sym_{n}.png")
        try:
            img = layer.topil()
            if img is None:
                continue
            img = img.convert("RGBA")
            img.thumbnail((size, size), Image.LANCZOS)
            img.save(path)
            sym["thumb"] = path
        except Exception:
            continue
    return report


def check(source_psd, excel_a, excel_b, links=None, icon_folder=None, game_id=None):
    """What the clone would do, nothing written: which sheet each page shows, the symbols it named
    (and the ones a pay card waits on), and the counts. For the clone dialog's links review.
    "binding": whether this PSD was mapped before (binding.py) and whether that still fits the file."""
    from .artist_design import psd_reader

    sheets_a, sheets_b = read_workbook(excel_a), read_workbook(excel_b)
    renames = sheet_renames(sheets_a, sheets_b)
    view_b = dict(sheets_b)
    for a, b in renames.items():
        view_b[a] = sheets_b[b]
    psd = psd_reader.open_lazy(source_psd)
    the_plan = plan(psd, sheets_a, view_b, excel_a, icon_folder, links)
    the_plan["page_changes"] = plan_pages(psd, the_plan, sheets_a, sheets_b, renames, links)
    the_plan["content_changes"] = content_diff.compare(sheets_a, sheets_b, renames)
    report = summary(the_plan)
    report["sheets"] = list(sheets_a)
    report["tokens"] = sorted(set(the_plan["_symbols"].tokens.values()), key=str.casefold)
    kept = binding.find(source_psd, game_id)
    report["binding"] = {"saved": False}
    if kept:
        valid = binding.validate(kept, psd)
        report["binding"] = dict(binding.summary(kept), saved=True, ok=valid["ok"], issues=valid["counts"])
    return report


def summary(the_plan):
    """The plan as the report the artist reads: counts, then the layers that need a look."""
    items = the_plan["items"]
    count = {}
    for i in items:
        count[i.get("status", "?")] = count.get(i.get("status", "?"), 0) + 1
    keep = ("page", "page_key", "layer", "status", "why", "source", "old", "new", "new_excel", "by_position")
    look = [{k: i[k] for k in keep if k in i} for i in items if i.get("status") in ("change", "artist", "ambiguous", "missing")]
    for e in the_plan.get("icon_edits") or []:      # rows whose symbols changed
        if e.get("follow"):
            continue                                  # icons moved with a changed text: listed with it
        count[e["status"]] = count.get(e["status"], 0) + 1
        look.append(dict({k: e[k] for k in keep if k in e}, layer="symbols", kind="symbols"))
    design = [{"page": i["page"], "layer": i["layer"], "text": i["old"][:120]} for i in items if i.get("status") == "design"]
    return {"counts": count, "layers": look, "kept_as_design": design, "new_rows": the_plan["new_rows"],
            "missing_sheets": the_plan["missing_sheets"], "page_links": the_plan.get("page_links", []),
            "symbols": the_plan.get("symbols", []), "page_changes": the_plan.get("page_changes") or {},
            "rows_added": the_plan.get("rows_added") or [],
            "content_changes": the_plan.get("content_changes") or {}}     # what the new AGR changed (content_diff)


# ── look-alike pay columns: which card is this? ───────────────────────────────
# Several symbols can pay the same ("50 / 10 / 5"), so the text can't say which
# cells a column shows. The card can: the Excel says which symbol owns each block
# of pay cells, and the PSD has that symbol's picture just above the column; the
# picture is told apart by comparing it with the game's symbol images.
def _thumb(img, size=48):
    import numpy as np
    from PIL import Image

    img = img.convert("RGBA")
    box = img.getbbox()
    if box:
        img = img.crop(box)
    flat = Image.new("RGB", img.size, (0, 0, 0))
    flat.paste(img, mask=img.split()[3])
    return np.asarray(flat.resize((size, size), Image.LANCZOS), dtype=np.float32) / 255.0


class Cards:
    def __init__(self, excel_a, icon_folder):
        self.excel_a, self.icon_folder = excel_a, icon_folder
        self._blocks, self._icons, self._seen = {}, {}, {}

    def owner(self, sheet, row, col):
        """The symbol token owning market A cell (row, col) of `sheet`, or None."""
        if sheet not in self._blocks:
            owners = {}
            try:
                from openpyxl.utils import coordinate_to_tuple

                from . import workbook_cache
                from .ui_web import engine_api

                with workbook_cache.borrow(self.excel_a, data_only=True) as wb:   # parsed once, not per sheet
                    blocks = engine_api.automap_paytable_slots_ws(wb[sheet], {"slots": {}, "slot_prefix": "@slot"})["blocks"]
                for b in blocks:
                    for refs in (b.get("pay_ref"), b.get("value_ref")):
                        for ref in str(refs or "").split(","):
                            if ref.strip():
                                owners[coordinate_to_tuple(ref.strip())] = b.get("token")
            except Exception:
                owners = {}
            self._blocks[sheet] = owners
        return self._blocks[sheet].get((row, col))

    def icon(self, token):
        if token not in self._icons:
            self._icons[token] = None
            try:
                from PIL import Image

                from .icon_mapping import resolve_icon_path

                path = resolve_icon_path(token, self.icon_folder, {}) if self.icon_folder else None
                if path:
                    self._icons[token] = _thumb(Image.open(path))
            except Exception:
                pass
        return self._icons[token]

    def picture_above(self, layer, page_images):
        """The symbol picture on the same card, just above this text layer."""
        cx, best = (layer.left + layer.right) / 2.0, None
        for img in page_images:
            if img.bottom <= layer.top + 5 and img.left - 80 <= cx <= img.right + 80:
                d = (layer.top - img.bottom) + abs(cx - (img.left + img.right) / 2.0) * 0.5
                if best is None or d < best[0]:
                    best = (d, img)
        return best[1] if best else None

    def which(self, picture, tokens):
        """The token among `tokens` this picture shows, when one is clearly the closest."""
        import numpy as np

        if picture is None:
            return None
        key = picture.layer_id
        if key not in self._seen:
            try:
                self._seen[key] = _thumb(picture.topil())
            except Exception:
                self._seen[key] = None
        seen = self._seen[key]
        if seen is None:
            return None
        scores = sorted((float(np.mean((seen - self.icon(t)) ** 2)), t) for t in set(tokens) if self.icon(t) is not None)
        if not scores or scores[0][0] > 0.04 or (len(scores) > 1 and scores[1][0] - scores[0][0] < 0.004):
            return None
        return scores[0][1]


def _page_images(layers_root):
    return [l for l in layers_root.descendants()
            if l.kind in ("pixel", "smartobject") and l.width * l.height > 60 * 60]


# ── symbols: named from the artist's PSD itself ───────────────────────────────
# No symbol folder is needed: a picture's token is learned, strongest first, from
#   links   what the artist confirmed in the clone dialog (saved with the game)
#   row     a row of text and pictures that lines up with an Excel cell's text and
#           tokens ("SCATTERED <purple_scat>, <blue_scat>…": the n-th picture is the
#           n-th token), or a text layer whose icon gaps line up with its tokens
#   card    a pay card whose values are on one card only names the picture above it
#   name    the layer's / embedded file's name spells the token ("PIC_04" = <PIC4>)
#   folder  the game's symbol pictures, when a folder is given (the old way)
# Copies of one smart object share one name, wherever they are in the file.
_HOW_RANK = {"link": 5, "row": 4, "card": 3, "name": 2, "folder": 1}


def picture_sig(layer, place=None):
    """What copies of one symbol share: a smart object's embedded file; a pixel layer is itself."""
    if layer.kind == "smartobject":
        try:
            so = layer.smart_object
            return "so:" + (str(so.filename or "").strip("\x00") or str(so.unique_id).strip("\x00"))
        except Exception:
            pass
    return f"px:{place if place is not None else layer.layer_id}"


def _is_picture(layer):
    """A symbol-like picture: not a strip or a bar behind the text."""
    w, h = layer.width, layer.height
    return layer.kind in ("pixel", "smartobject") and w * h >= 24 * 24 and w <= h * 3 and h <= w * 3


class Symbols:
    """Picture signature -> (token, how), from every kind of evidence above."""

    def __init__(self, psd, sheets_a, links=None, sheets_b=None):
        self.place = {id(l): n for n, l in enumerate(psd.descendants())}
        self.tokens = {}                              # sym_key -> token as the Excel spells it
        # the old Excel's tokens first, then the ones only the new one has (a picture the artist
        # already drew for the new market — JuCaiJin's turtles — is named too)
        for sheets in (sheets_a, sheets_b or {}):
            for s in sheets.values():
                for t in s.cells.values():
                    for tok in tokens_in(t):
                        self.tokens.setdefault(sym_key(tok), tok)
        spelled = list(self.tokens.values())
        self.named = {}                               # sig -> (token, how)
        self.conflicts = {}                           # sig -> {token, ...} the evidence disagreed on
        self.sample = {}                              # sig -> a layer showing it (for the dialog)
        self.cards, self.needed = set(), set()        # pictures on pay cards; the ones a card waits on
        for l in psd.descendants():
            if _is_picture(l):
                sig = self.sig(l)
                self.sample.setdefault(sig, l)
                for name in (l.name, sig[3:] if sig.startswith("so:") else ""):
                    # the name as it is, else spelled out (Grd_A = Grand_A, Mnr_I_X2 = MINORx2 I)
                    tok = self.tokens.get(sym_key(name)) or (token_for_name(name, spelled) if name else None)
                    if tok:
                        self.add(sig, tok, "name")
                        break
        for sig, tok in ((links or {}).get("symbols") or {}).items():
            if tok:
                self.named[sig] = (tok, "link")

    def sig(self, layer):
        return picture_sig(layer, self.place.get(id(layer)))

    def add(self, sig, token, how):
        old = self.named.get(sig)
        if old and old[0] != token:
            self.conflicts.setdefault(sig, set()).update((old[0], token))
        if old is None or _HOW_RANK[how] > _HOW_RANK[old[1]]:
            self.named[sig] = (token, how)

    def token(self, layer):
        got = self.named.get(self.sig(layer)) if layer is not None else None
        return got[0] if got else None

    def learn_rows(self, root, cells):
        """Name the pictures of a page from its rows of text and pictures. `cells`: {key: Excel text}
        of the page's sheet."""
        for _run, pics, toks, _key in inline_rows(root, cells):
            for pic, tok in zip(pics, toks):
                self.add(self.sig(pic), tok, "row")
        for _text, pics, toks, _keys, _rows in gap_rows(root, cells):
            for pic, tok in zip(pics, toks):
                self.add(self.sig(pic), tok, "row")

    def listing(self):
        """For the clone dialog: every picture that was named, or that is on a pay card."""
        out = []
        for sig, layer in self.sample.items():
            tok, how = self.named.get(sig, (None, None))
            if tok is None and not sig.startswith("so:") and sig not in self.cards:
                continue                              # plain pixel layers: decoration, unless on a card
            out.append({"sig": sig, "layer": layer.name, "token": tok, "how": how,
                        "conflict": sorted(self.conflicts.get(sig, ())), "card": sig in self.cards,
                        "needed": sig in self.needed, "place": self.place.get(id(layer)),
                        "size": [layer.width, layer.height]})
        out.sort(key=lambda x: (not x["needed"], not x["card"], x["token"] is not None, x["layer"].casefold()))
        return out


def _units(text):
    """An Excel text / a text layer as words and punctuation; tokens as None."""
    out = []
    for part in re.split(r"(<[^<>]*>)", str(text or "")):
        if _TOKEN.fullmatch(part or ""):
            out.append(None)
        else:
            out += [w.casefold() for w in re.findall(r"[^\W_]+(?:['’][^\W_]+)*|[^\w\s]", part.replace("\r", " "))]
    return out


def _single_line(layer):
    return layer.kind == "type" and "\r" not in str(layer.text or "").strip("\r") and not _ICON_GAP.search(str(layer.text or "").strip())


def _bands(root):
    """Rows of a page made of separate layers: single-line text layers and pictures whose middles sit
    on one line, each row left to right."""
    els = [l for l in root.descendants() if l.visible and ((_single_line(l) and norm(l.text)) or _is_picture(l))]
    texts = [l for l in els if l.kind == "type"]
    out = []
    for t in texts:
        h = max(1, t.bottom - t.top)
        mid = (t.top + t.bottom) / 2.0
        row = [l for l in els if abs((l.top + l.bottom) / 2.0 - mid) <= h * 0.6 and (l.kind == "type" or (l.bottom - l.top) <= h * 3.2)]
        row.sort(key=lambda l: l.left)
        # one connected run around `t`: neighbours closer than twice the text's height
        i = row.index(t)
        lo = hi = i
        while lo > 0 and row[lo].left - row[lo - 1].right <= h * 2:
            lo -= 1
        while hi < len(row) - 1 and row[hi + 1].left - row[hi].right <= h * 2:
            hi += 1
        run = row[lo:hi + 1]
        if any(l.kind != "type" for l in run) and run not in out:
            out.append(run)
    return out


def _row_units(run):
    units, owners = [], []
    for l in run:
        if l.kind == "type":
            for u in _units(l.text):
                units.append(u)
                owners.append(l)
        else:
            units.append(None)
            owners.append(l)
    return units, owners


def inline_rows(root, cells):
    """[(row of layers, its pictures, their tokens, cell key)] for every row of separate text and picture
    layers that spells an Excel cell. `cells`: {key: Excel text}."""
    by_units = {}
    for key, text in cells.items():
        if tokens_in(text):
            by_units.setdefault(tuple(_units(text)), key)
    out = []
    for run in _bands(root):
        units, _owners = _row_units(run)
        key = by_units.get(tuple(units))
        if key is not None:
            out.append((run, [l for l in run if l.kind != "type"], tokens_in(cells[key]), key))
    return out


def gap_rows(root, cells):
    """[(text layer, pictures in reading order, tokens, cell keys, picture row of each picture)] for text
    layers that leave icon gaps, when their gaps, the pictures over them and the tokens of the Excel
    text they show all line up. `cells`: {key: Excel text}."""
    pics = [l for l in root.descendants() if l.visible and _is_picture(l)]
    out = []
    for t in root.descendants():
        if t.kind != "type" or not t.visible:
            continue
        body = str(t.text or "")
        gaps = sum(len(_ICON_GAP.findall(ln.rstrip())) for ln in body.split("\r"))
        if not gaps:
            continue
        over = [p for p in pics if t.left - 8 <= (p.left + p.right) / 2.0 <= t.right + 8
                and t.top - 8 <= (p.top + p.bottom) / 2.0 <= t.bottom + 8 and p.height <= (t.bottom - t.top) * 1.5 + 40]
        if not over:
            continue
        h = sorted(p.height for p in over)[len(over) // 2]
        over.sort(key=lambda p: ((p.top + p.bottom) / 2.0, p.left))
        lines, cur = [], []
        for p in over:                                # reading order: rows of pictures, each left to right
            if cur and abs((p.top + p.bottom) / 2.0 - (cur[0].top + cur[0].bottom) / 2.0) > h * 0.5:
                lines.append(sorted(cur, key=lambda q: q.left))
                cur = []
            cur.append(p)
        if cur:
            lines.append(sorted(cur, key=lambda q: q.left))
        ordered = [p for ln in lines for p in ln]
        row_of = [n for n, ln in enumerate(lines) for _p in ln]
        keys = _cells_for_words([u for u in _units(body) if u is not None], cells)
        toks = [tok for k in keys or [] for tok in tokens_in(cells[k])]
        if keys and len(toks) == len(ordered) == gaps:
            out.append((t, ordered, toks, keys, row_of))
    return out


def _cells_for_words(words, cells):
    """The Excel cells (in sheet order) a text layer's words come from: one cell, or consecutive ones."""
    keys = sorted(cells)
    seq = [tuple(u for u in _units(cells[k]) if u is not None) for k in keys]
    words = list(words)
    for i in range(len(seq)):
        acc, used = [], []
        for k, w in zip(keys[i:], seq[i:]):
            if not w and not acc:
                break
            acc += w
            used.append(k)
            if len(acc) >= len(words):
                break
        if acc == words and any(tokens_in(cells[k]) for k in used):
            return used
    return None


# ── symbols removed in the new market ─────────────────────────────────────────
# "SCATTERED <purple_scat>, <blue_scat>…" -> "SCATTERED, <blue_scat>…": the removed
# symbol's picture (and whatever text went with it) is hidden — never deleted, so
# the artist can bring it back — and the rest of the row closes up, centred again
# when the row was centred. A symbol ADDED in the new market is left to the artist.
def _units_tok(text):
    """Like _units, with each token kept as "<name>" so a removed symbol shows in the diff."""
    out = []
    for part in re.split(r"(<[^<>]*>)", str(text or "")):
        if _TOKEN.fullmatch(part or ""):
            out.append(part.casefold())
        else:
            out += [w.casefold() for w in re.findall(r"[^\W_]+(?:['’][^\W_]+)*|[^\w\s]", part.replace("\r", " "))]
    return out


def _deleted_only(ua, ub):
    """Indexes of `ua` removed to give `ub`, or None when anything was added or changed."""
    gone = []
    for op, i1, i2, _j1, _j2 in difflib.SequenceMatcher(None, ua, ub, autojunk=False).get_opcodes():
        if op == "delete":
            gone += range(i1, i2)
        elif op != "equal":
            return None
    return gone


def _centred(xs_left, xs_right, width):
    mid = (xs_left + xs_right) / 2.0
    return abs(mid - width / 2.0) <= width * 0.03


def icon_edits(the_plan, sheets_a, sheets_b, rowmaps):
    """Rows whose symbols changed between the markets: [{page, page_key, source, status, old, new, why,
    hide: [place], move: [[place, dx]], text: {place: new text}}]."""
    roots, symbols = the_plan["_roots"], the_plan["_symbols"]
    place = symbols.place
    by_place = {i["place"]: i for i in the_plan["items"]}
    out, followed = [], set()
    for page, sheet in the_plan["page_sheet"].items():
        root, a, b = roots.get(page), sheets_a.get(sheet), sheets_b.get(sheet)
        if root is None or a is None or b is None:
            continue
        rm = rowmaps[sheet].map

        def b_text(key):
            r = rm.get(key[0])
            return None if r is None else b.cells.get((r, key[1]), "")

        # cells whose added symbols already have a gap in their layer's new text (_decide): the picture
        # is the artist's to put in, nothing here to hide or move
        gapped = {tuple(c) for i in the_plan["items"] if i.get("added_symbols") and i.get("status") == "change"
                  and (i.get("content") or {}).get("kind") == "cells" and i["content"]["a"]["sheet"] == sheet
                  for c in i["content"]["a"]["cells"]}
        changed = {k: t for k, t in a.cells.items() if k not in gapped and tokens_in(t) and b_text(k) is not None
                   and tokens_in(t) != tokens_in(b_text(k))}
        page_name = next((i["page"] for i in the_plan["items"] if i["page_key"] == page), "")
        doc_w = the_plan["_size"][0]
        grows = gap_rows(root, a.cells)
        # text changed beside an icon ("random additional credits" -> "additional credits"): the
        # icon's picture moves with the text
        for t, pics, _toks, keys, row_of in grows:
            item = by_place.get(place[id(t)])
            if item is None or item.get("status") != "change" or any(k in changed for k in keys):
                continue
            if item.get("gap_spans"):
                # symbols added here too: their gaps are widened as their pictures need (add_symbol), so the
                # artist's icons are set from the final text there — each where it sits in its gap now
                got = _icon_offsets(t, pics, item["old"])
                followed.add(item["place"])
                if isinstance(got, str):
                    item.update(status="artist", why=got, new_excel=item.pop("new"))
                else:
                    item["follow_icons"] = got
                continue
            got = follow_gaps(t, pics, row_of, item["old"], item["new"], item.get("gap_spans") or ())
            followed.add(item["place"])
            if isinstance(got, str):
                item.update(status="artist", why=got, new_excel=item.pop("new"))
            elif got:
                out.append({"page": page_name, "page_key": page, "status": "change", "follow": True,
                            "source": item.get("source", ""), "old": item["old"], "new": item["new"],
                            "hide": [], "move": [[place[id(p)], round(d)] for p, d in got if round(d)],
                            "why": "the icons moved with the text"})
        if not changed:
            continue
        done = set()
        # rows of separate layers: hide the removed ones, close the row up
        for run, _pics, _toks, key in inline_rows(root, a.cells):
            if key not in changed or key in done:
                continue
            done.add(key)
            ua, ub = _units_tok(a.cells[key]), _units_tok(b_text(key))
            gone = _deleted_only(ua, ub)
            edit = {"page": page_name, "page_key": page, "source": _ref_text({"kind": "cell", "refs": [(sheet,) + key]}),
                    "old": a.cells[key], "new_excel": b_text(key), "hide": [], "move": []}
            out.append(edit)
            _units_list, owners = _row_units(run)
            whole = [l for l in run if all(i in gone for i, o in enumerate(owners) if o is l)] if gone is not None else []
            part = {owners[i] for i in (gone or [])} - set(whole)
            if gone is None or part:
                edit.update(status="artist", why="symbols were added or changed in this row — place them by hand"
                            if gone is None else "part of a text layer in this row went — edit it by hand")
                continue
            dx, shift = {}, 0.0
            n = len(run)
            k = 0
            while k < n:                              # each stretch of removed layers, left to right
                if run[k] not in whole:
                    dx[id(run[k])] = -shift
                    k += 1
                    continue
                k2 = k
                while k2 + 1 < n and run[k2 + 1] in whole:
                    k2 += 1
                if k > 0:
                    shift += run[k2].right - run[k - 1].right
                elif k2 + 1 < n:
                    shift += run[k2 + 1].left - run[k].left
                k = k2 + 1
            if _centred(run[0].left, run[-1].right, doc_w):
                for l in run:
                    if l not in whole:
                        dx[id(l)] = dx.get(id(l), 0.0) + shift / 2.0
            edit["hide"] = [place[id(l)] for l in whole]
            edit["move"] = [[place[id(l)], round(dx[id(l)])] for l in run if l not in whole and round(dx.get(id(l), 0))]
            edit.update(status="change", new=b_text(key),
                        why=f"{len([l for l in whole if l.kind != 'type'])} symbol(s) removed — hidden in the PSD, the row closed up")
        # one text layer with icon gaps, pictures over them
        for t, pics, toks, keys, row_of in grows:
            keys_changed = [k for k in keys if k in changed and k not in done]
            if not keys_changed:
                continue
            done.update(keys)
            new_cells = [b_text(k) for k in keys]
            edit = {"page": page_name, "page_key": page, "source": _ref_text({"kind": "cells", "refs": [(sheet,) + k for k in keys]}),
                    "old": "\n".join(a.cells[k] for k in keys), "new_excel": "\n".join(new_cells),
                    "hide": [], "move": []}
            out.append(edit)
            got = _gap_layer_edit(t, pics, toks, row_of, [a.cells[k] for k in keys], new_cells)
            if isinstance(got, str):
                edit.update(status="artist", why=got)
                continue
            new_text, hidden, moves = got
            followed.add(place[id(t)])
            edit["hide"] = [place[id(p)] for p in hidden]
            edit["move"] = [[place[id(p)], round(dx), round(dy)] for p, dx, dy in moves if round(dx) or round(dy)]
            edit.update(status="change", new="\n".join(new_cells),
                        why=f"{len(hidden)} symbol(s) removed — hidden in the PSD, the text closed up")
            item = by_place.get(place[id(t)])
            if item is not None:                      # the text layer is written by the symbol edit
                item.update(status="change", new=new_text, why="symbol removed", source=edit["source"])
        # a row a layer on the page already reads like (the artist's PSD made from a later text) is up to date
        shown = [norm(i["old"]) for i in the_plan["items"] if i.get("page_key") == page]
        for key in changed:
            if key not in done and not any(norm(b_text(key)) in t for t in shown):
                out.append({"page": page_name, "page_key": page, "status": "artist",
                            "source": _ref_text({"kind": "cell", "refs": [(sheet,) + key]}),
                            "old": a.cells[key], "new_excel": b_text(key), "hide": [], "move": [],
                            "why": "the symbols changed here, but this row's pictures couldn't be found — change them by hand"})
    for item in the_plan["items"]:                    # text moved beside an icon nobody could move
        if item.get("added_symbols") and not _ICON_GAP.search(item["old"]):
            continue                                  # the only gap is the one left for the new symbol
        if item.get("status") == "change" and item["place"] not in followed and _gap_lines_changed(item["old"], item["new"]):
            item.update(status="artist", new_excel=item.pop("new"),
                        why="text next to an icon changed — the icon's picture couldn't be found to move it with the text")
    return out


def _gaps(text):
    """[(line number, start, end)] of the icon gaps in a text (a gap at a line's end doesn't count)."""
    out, pos = [], 0
    for n, ln in enumerate(str(text or "").split("\r")):
        for m in _ICON_GAP.finditer(ln.rstrip()):
            out.append((n, pos + m.start(), pos + m.end()))
        pos += len(ln) + 1
    return out


def page_icons(*pages):
    """How the artist sizes and sits icons in text on these pages, relative to the font size of the
    icon's line: (icon height / font size, (icon centre - its line's centre) / font size) — medians
    over the pictures sitting on the lines of the pages' text layers that have icon gaps — or None.
    A line's centre is half its font size below its top (_laid_out)."""
    ratios, offsets = [], []
    for page in pages:
        if not page.is_group():
            continue
        texts = [l for l in page.descendants() if l.kind == "type" and l.visible]
        pics = [l for l in page.descendants() if not l.is_group() and l.visible and _is_picture(l)]
        _icons_on(texts, pics, ratios, offsets)
    if not ratios:
        return None
    ratios.sort()
    offsets.sort()
    return ratios[len(ratios) // 2], offsets[len(offsets) // 2]


def _icons_on(texts, pics, ratios, offsets):
    for t in texts:
        text = str(t.text or "")
        if not _gaps(text.rstrip("\r")):
            continue
        try:
            _spots, lines = _laid_out(t, text)
        except Exception:
            continue
        if not lines:
            continue
        for p in pics:
            cx, cy = (p.left + p.right) / 2.0, (p.top + p.bottom) / 2.0
            if not (t.left - 8 <= cx <= t.right + 8 and t.top - p.height <= cy <= t.bottom + p.height):
                continue
            top, size, _n = min(lines, key=lambda ln: abs(cy - (ln[0] + ln[1] / 2.0)))
            if size:
                ratios.append(p.height / size)
                offsets.append((cy - (top + size / 2.0)) / size)


def put_pixels(psd, layer, img, left, top):
    """A layer's pixels replaced by `img` at (left, top); the channels a picture has (a mask aside)."""
    from psd_tools.api import layers as ptl
    from psd_tools.constants import Compression

    from .psd_apply import splice

    splice.mark(layer)
    rec, chans = ptl.PixelLayer._build_layer_record_and_channels(
        img, layer.name, int(round(left)), int(round(top)), Compression.RLE, version=psd._record.header.version)
    r = layer._record
    r.top, r.left, r.bottom, r.right = rec.top, rec.left, rec.bottom, rec.right
    by_id = {c.id: (c, d) for c, d in zip(rec.channel_info, chans)}
    infos, datas = [], []
    for info, data in zip(r.channel_info, layer._channels):
        if info.id in by_id:
            infos.append(by_id[info.id][0])
            datas.append(by_id[info.id][1])
        else:
            infos.append(info)
            datas.append(data)
    r.channel_info = infos
    layer._channels._items[:] = datas


def set_placement(layer, box):
    """A smart object's placement (where Photoshop draws its contents when it renders it again) set to
    `box` (left, top, right, bottom): the four corners, unrotated."""
    from psd_tools.constants import Tag

    l, t, r, b = (float(v) for v in box)
    quad = (l, t, r, t, r, b, l, b)
    blocks = layer._record.tagged_blocks
    for tag in (Tag.PLACED_LAYER1, Tag.PLACED_LAYER2):
        pl = blocks.get_data(tag)
        if pl is not None and getattr(pl, "transform", None):
            pl.transform = quad
    for tag in (Tag.SMART_OBJECT_LAYER_DATA1, Tag.SMART_OBJECT_LAYER_DATA2):
        so = blocks.get_data(tag)
        if so is not None:
            for key in (b"Trnf", b"nonAffineTransform"):
                pts = so.data.get(key)
                if pts is not None and len(pts) == 8:
                    for n in range(8):
                        pts[n] = type(pts[n])(quad[n])


def _gap_lines_changed(old, new):
    """True when a line holding an icon gap reads differently (the icon would sit in the wrong place)."""
    go, gn = _gaps(old), _gaps(new)
    if len(go) != len(gn):
        return True
    lo, ln_ = str(old).split("\r"), str(new).split("\r")
    return any(lo[a[0]].rstrip() != ln_[b[0]].rstrip() for a, b in zip(go, gn))


def rewrap_point(layer, old, new):
    """Point text with a line that grew wider than any line the artist had: that line is broken at
    spaces into lines as wide as the artist's widest (balanced, so no lone last word)."""
    wo, wn = _measure(layer, old), _measure(layer, new)
    if not wo or not wn:
        return new

    def widths(text, w):
        out, pos = [], 0
        for ln in text.split("\r"):
            out.append(sum(w[pos:pos + len(ln.rstrip())]))
            pos += len(ln) + 1
        return out

    limit = max(widths(old, wo) or [0])
    if limit <= 0:
        return new
    old_lines = {ln.strip() for ln in old.split("\r")}
    out, pos = [], 0
    for ln, lw in zip(new.split("\r"), widths(new, wn)):
        adv = wn[pos:pos + len(ln)]
        pos += len(ln) + 1
        if lw <= limit * 1.03 or ln.strip() in old_lines or _ICON_GAP.search(ln.strip()) or " " not in ln.strip():
            out.append(ln)
            continue
        target = min(limit, lw / (int(lw // limit) + 1) * 1.08)
        pieces, first, prev = [], None, None
        for m in re.finditer(r"\S+", ln):
            if first is not None and sum(adv[first.start():m.end()]) > target:
                pieces.append((first.start(), prev.end()))
                first = None
            first = first or m
            prev = m
        pieces.append((first.start(), len(ln)))
        pieces[0] = (0, pieces[0][1])                 # the line's own indent stays on its first piece
        out += [ln[a:b] for a, b in pieces]
    return "\r".join(out)


def _box_width(layer):
    """A paragraph (box) text layer's box width in document pixels; None for point text."""
    frame = _box_frame(layer)
    return frame[2] if frame else None


def _justification(layer):
    try:
        return int(layer.engine_dict["ParagraphRun"]["RunArray"][0]["ParagraphSheet"]["Properties"].get("Justification", 0))
    except Exception:
        return 0


def _gap_spots(spots, lines, text, a, b):
    """(centre x, centre y of its line) of the gap at text[a:b] as laid out (_laid_out), or None."""
    mid = next((i for i in range((a + b) // 2, b) if i in spots), None)
    if mid is None:
        return None
    ln = spots[mid][2]
    on = [spots[i] for i in range(a, b) if i in spots and spots[i][2] == ln and text[i] == chr(0xA0)] \
        or [spots[i] for i in range(a, b) if i in spots and spots[i][2] == ln]
    top, size, _n = lines[ln]
    return (on[0][0] + on[-1][0] + on[-1][1]) / 2.0, top + size / 2.0


def _icon_offsets(t, pics, text):
    """[{"layer", "dx", "dy"}]: each of the artist's icons (in gap order) by its layer id, and how far its
    centre sits from its gap's centre and its line's centre in the layer's text as it is laid out now —
    kept when the text changes (add_symbol) — or why not."""
    if not _wrap_ok(t):
        return "text next to an icon changed — " + _WRAP_WHY
    gaps = _gaps(str(text).rstrip("\r"))
    try:
        spots, lines = _laid_out(t, str(text))
    except Exception:
        spots = None
    if not spots or len(gaps) != len(pics):
        return "text next to an icon changed — its icons couldn't be lined up with their gaps; place them by hand"
    out = []
    for (_n, a, b), p in zip(gaps, pics):
        at = _gap_spots(spots, lines, str(text), a, b)
        if at is None:
            return "text next to an icon changed — its icons couldn't be lined up with their gaps; place them by hand"
        out.append({"layer": p.layer_id, "dx": (p.left + p.right) / 2.0 - at[0], "dy": (p.top + p.bottom) / 2.0 - at[1]})
    return out


def follow_gaps(t, pics, row_of, old, new, added=()):
    """[(picture, dx)] that keep each icon in its gap after the text around it changed, or why not.
    `added`: [(start, end)] of the gaps left in `new` for symbols the new Excel adds (no picture yet)."""
    if not _wrap_ok(t):
        return "text next to an icon changed — " + _WRAP_WHY
    go = _gaps(old)
    gn = [g for g in _gaps(new) if not any(g[1] < b and a < g[2] for a, b in added)]
    if len(go) != len(gn) or len(go) != len(pics):
        return "text next to an icon changed — an icon gap was added or removed; place the icons by hand"
    wo, wn = _measure(t, old), _measure(t, new)
    if wo is None or wn is None:
        return "text next to an icon changed — the layer's font isn't installed to measure it"
    box, just = _box_width(t), _justification(t)
    lo, ln_ = str(old).split("\r"), str(new).split("\r")
    starts = lambda lines: [sum(len(x) + 1 for x in lines[:k]) for k in range(len(lines))]
    so, sn = starts(lo), starts(ln_)
    width = lambda w, s, line: sum(w[s:s + len(line.rstrip(" "))])   # (an added symbol's gap at the end counts)
    moves = []
    for k, (a, b) in enumerate(zip(go, gn)):
        if lo[a[0]].rstrip(" ") == ln_[b[0]].rstrip(" "):
            continue
        old_w, new_w = width(wo, so[a[0]], lo[a[0]]), width(wn, sn[b[0]], ln_[b[0]])
        on_line = [n for n, g in enumerate(go) if g[0] == a[0]]
        if len({row_of[n] for n in on_line}) != 1 or (box and max(old_w, new_w) > box * 0.985):
            return "text next to an icon changed in a paragraph that wraps — move the icons by hand"
        dx = sum(wn[sn[b[0]]:b[1]]) - sum(wo[so[a[0]]:a[1]])
        dx += {1: old_w - new_w, 2: (old_w - new_w) / 2.0}.get(just, 0.0)
        moves.append((pics[k], dx))
    return moves


def _gap_layer_edit(t, pics, toks, row_of, a_texts, b_texts):
    """(new text, pictures to hide, [(picture, dx)]) for a text layer with icon gaps whose Excel text
    lost symbols, or why it can't be done."""
    body = str(t.text or "")
    if not _wrap_ok(t):
        return "a symbol went from this text, but " + _WRAP_WHY.replace("move its icons", "change it")
    ua = [u for txt in a_texts for u in _units_tok(txt)]
    ub = [u for txt in b_texts for u in _units_tok(txt)]
    gone = _deleted_only(ua, ub)
    if gone is None:
        return "symbols were added or changed in this text — place them by hand"
    # the layer's own units, each with its characters; gaps stand for the tokens in order
    spans, g = [], 0
    for m in re.finditer(_ICON_GAP.pattern + r"|[^\W_]+(?:['’][^\W_]+)*|[^\w\s]", body):
        if m.group().strip("  "):
            spans.append((m.start(), m.end(), m.group().casefold()))
        elif body[m.end():].split("\r")[0].strip():
            spans.append((m.start(), m.end(), "<" + toks[g].casefold() + ">") if g < len(toks) else (m.start(), m.end(), "?"))
            g += 1
    if [s[2] for s in spans] != ua:
        return "the artist's text and the Excel don't line up here — change the symbols by hand"
    gap_index = {i: n for n, i in enumerate(i for i, s in enumerate(spans) if s[2].startswith("<"))}
    for i in gone:                                    # the whole picture row must be one line of text
        if i in gap_index:
            line_of = body.count("\r", 0, spans[i][0])
            same_line = [n for j, n in gap_index.items() if body.count("\r", 0, spans[j][0]) == line_of]
            if len({row_of[n] for n in same_line}) != 1:
                return "the symbol was in a paragraph that wraps over several lines — remove it by hand"
    # characters to cut: each removed unit with the space after it (or before it, at a line's end)
    cuts = []
    for i in gone:
        a0, a1 = spans[i][0], spans[i][1]
        nxt = spans[i + 1][0] if i + 1 < len(spans) else len(body)
        if i + 1 < len(spans) and "\r" not in body[a1:nxt] and (i + 1) not in gone:
            a1 = nxt
            # an icon's gap is all the space between the words beside it: one space stays between them
            # ("is shown as [icon] and" read "is shown asand"); none before a comma or full stop
            if spans[i][2].startswith("<") and i > 0 and (i - 1) not in gone and "\r" not in body[spans[i - 1][1]:a0] \
                    and body[a1:a1 + 1].isalnum():
                a0 += 1
        elif i > 0 and (i - 1) not in gone:
            a0 = spans[i - 1][1]
        cuts.append((a0, a1))
    cuts = _merge_spans(cuts)
    widths = _measure(t, body)
    if widths is None:
        return "the layer's font isn't installed — remove the symbol by hand"
    try:
        just = int(t.engine_dict["ParagraphRun"]["RunArray"][0]["ParagraphSheet"]["Properties"].get("Justification", 0))
    except Exception:
        just = 0
    hide, moves = [], {}
    for i in gone:
        if i in gap_index:
            hide.append(pics[gap_index[i]])
    for c0, c1 in cuts:
        w = sum(widths[c0:c1])
        line = body.count("\r", 0, c0)
        for j, n in gap_index.items():
            p = pics[n]
            if p in hide or body.count("\r", 0, spans[j][0]) != line:
                continue
            d = -w if spans[j][0] >= c1 else 0.0
            d += {1: w, 2: w / 2.0}.get(just, 0.0)        # the line is anchored right / centred
            moves[id(p)] = (p, moves.get(id(p), (p, 0.0))[1] + d)
    new = body
    for c0, c1 in sorted(cuts, reverse=True):
        new = new[:c0] + new[c1:]
    # each icon left from where its gap was to where it is, the text laid out before and after: the
    # shorter text can wrap differently (Spooky's Mo' Spins: "awarded." came back up a line and every
    # icon below it with it) — side shifts alone left icons over the words
    try:
        so, lo = _laid_out(t, body)
        sn, ln_ = _laid_out(t, new)
    except Exception:
        so = None
    if so:
        def shifted(i):                               # a character's place in the new text
            return i - sum(c1 - c0 for c0, c1 in cuts if c1 <= i)
        laid = {}
        for j, n in gap_index.items():
            p = pics[n]
            if p in hide:
                continue
            a, b = spans[j][0], spans[j][1]
            was = _gap_spots(so, lo, body, a, b)
            now = _gap_spots(sn, ln_, new, shifted(a), shifted(b))
            if was is None or now is None:
                laid = None
                break
            laid[id(p)] = (p, now[0] - was[0], now[1] - was[1])
        if laid is not None:
            return new, hide, list(laid.values())
    return new, hide, [(p, d, 0.0) for p, d in moves.values()]


def _merge_spans(spans):
    out = []
    for a, b in sorted(spans):
        if out and a <= out[-1][1]:
            out[-1] = (out[-1][0], max(out[-1][1], b))
        else:
            out.append((a, b))
    return out


def _measure(layer, text):
    """Each character's advance in document pixels, in the layer's own fonts (or None)."""
    from PIL import ImageFont

    styles, lengths = _run_styles(layer)
    idx = _per_char(lengths, len(text))
    hs = _scales(layer)[0]
    fonts, out = {}, []
    for ch, k in zip(text, idx):
        if k not in fonts:
            name, size = styles[min(k, len(styles) - 1)][:2]
            entry = _font_file(name)
            if entry is None:
                return None
            fonts[k] = ImageFont.truetype(entry[0], max(1, int(round(size * 4))), index=entry[1])
        out.append(0.0 if ch == "\r" else fonts[k].getlength(ch) * hs / 4.0)
    try:                                              # Photoshop tracking: 1/1000 em per character
        tracking = [float(r["StyleSheet"]["StyleSheetData"].get("Tracking", 0)) for r in layer.engine_dict["StyleRun"]["RunArray"]]
        out = [w + (tracking[min(k, len(tracking) - 1)] / 1000.0) * styles[min(k, len(styles) - 1)][1] if w else w
               for w, k in zip(out, idx)]
    except Exception:
        pass
    adjust = _letter_adjust(layer)                    # the spacing the layer's own lines showed (_calibrate)
    return [w + adjust if w else w for w in out]


def move_layer(layer, dx, dy=0):
    """Slide a layer by (dx, dy) pixels: its pixels' frame, a mask, the text's or smart object's
    placement (Photoshop re-draws from those) and the effects' reference point all move together."""
    from psd_tools.constants import Tag

    from .psd_apply import splice

    splice.mark(layer)
    dx, dy = int(round(dx)), int(round(dy))
    if not dx and not dy:
        return
    r = layer._record
    r.left += dx
    r.right += dx
    r.top += dy
    r.bottom += dy
    md = getattr(r, "mask_data", None)
    if md is not None:
        for a, d in (("left", dx), ("right", dx), ("real_left", dx), ("real_right", dx),
                     ("top", dy), ("bottom", dy), ("real_top", dy), ("real_bottom", dy)):
            if getattr(md, a, None) is not None:
                setattr(md, a, getattr(md, a) + d)
    blocks = r.tagged_blocks
    ty = blocks.get_data(Tag.TYPE_TOOL_OBJECT_SETTING)
    if ty is not None:
        tr = list(ty.transform)
        tr[4] += dx
        tr[5] += dy
        ty.transform = tuple(tr)
    for tag in (Tag.PLACED_LAYER1, Tag.PLACED_LAYER2):
        pl = blocks.get_data(tag)
        if pl is not None and getattr(pl, "transform", None):
            pl.transform = tuple(v + (dx if n % 2 == 0 else dy) for n, v in enumerate(pl.transform))
    for tag in (Tag.SMART_OBJECT_LAYER_DATA1, Tag.SMART_OBJECT_LAYER_DATA2):
        so = blocks.get_data(tag)
        if so is not None:
            for key in (b"Trnf", b"nonAffineTransform"):
                pts = so.data.get(key)
                if pts is not None:
                    for n in range(len(pts)):
                        pts[n] = type(pts[n])(float(pts[n]) + (dx if n % 2 == 0 else dy))
    ref = blocks.get_data(Tag.REFERENCE_POINT)
    if ref is not None and len(ref) >= 2:
        ref[0] = type(ref[0])(float(ref[0]) + dx)
        ref[1] = type(ref[1])(float(ref[1]) + dy)
    for tag in (Tag.VECTOR_MASK_SETTING1, Tag.VECTOR_MASK_SETTING2):
        vm = blocks.get_data(tag)
        if vm is not None:
            psd = getattr(layer, "_psd", None)
            w, h = (float(psd.width), float(psd.height)) if psd is not None else (None, None)
            for rec in getattr(vm.path, "_items", vm.path) if w else []:
                for attr in ("preceding", "anchor", "leaving"):
                    pt = getattr(rec, attr, None)
                    if pt:
                        setattr(rec, attr, (pt[0] + dy / h, pt[1] + dx / w))


# ── review: before / after pictures of every page that changed ────────────────
_MARK = {"change": (255, 159, 26), "artist": (255, 64, 64), "ambiguous": (255, 64, 64), "missing": (255, 64, 64)}


def _before_page(source_psd, psd, top_index, progress=None):
    """The source page as it looks, cached on disk per source file (rendering a page takes seconds)."""
    import hashlib
    import tempfile

    from PIL import Image

    from .artist_design import psd_render

    st = os.stat(source_psd)
    key = hashlib.sha1(f"{os.path.abspath(source_psd)}|{st.st_size}|{st.st_mtime_ns}|v1".encode("utf-8")).hexdigest()[:20]
    path = os.path.join(tempfile.gettempdir(), "psh_clone_pages", key, f"{top_index}.png")
    if os.path.isfile(path):
        try:
            return Image.open(path).convert("RGBA")
        except OSError:
            pass
    img = psd_render.render_page(psd, _tops(psd)[top_index])
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img.save(path)
    return img


def _box(layer, pad, size):
    l, t, r, b = layer.bbox
    return (max(0, l - pad), max(0, t - pad), min(size[0], r + pad), min(size[1], b + pad))


def review_pictures(source_psd, out, the_plan, folder, progress=None, max_width=1400, draw=True):
    """What the artist approves, fast: for every page that would change, be added or be marked
    deleted, a before / after crop of each changed area only (a crop draws in well under a second;
    a whole page takes ~15 s, so whole pages are drawn only when asked for — see page_picture).
    `out` is the new PSD in memory (or a path). Returns, in page order,
    [{id, kind, page, page_key, sheet, from, changed, issues, missing, crops: [{status, before, after,
    old, new, why}]}]. With `draw` off the crops are only listed: the_plan["_crop_jobs"] holds what
    draw_crops() draws (in the background, while the artist reads the changes)."""
    from .artist_design import psd_reader

    if isinstance(out, str):
        out = psd_reader.open_lazy(out)
    # listing needs only the artist's page names (the plan has them); their pictures are drawn from
    # the artist's file, opened when the first one is drawn (draw_crops)
    src = source_psd if not draw and the_plan.get("_source") else psd_reader.open_lazy(source_psd)
    src_tops, out_tops = (the_plan["_source"] if isinstance(src, str) else _tops(src)), _tops(out)
    out_layers = list(out.descendants())
    box0 = the_plan.get("_box0") or {}
    src_index = the_plan.get("_src_index") or {i: ("page", i, None) for i in range(len(out_tops))}
    missing = the_plan.get("_missing_rows") or {}
    pages = {}
    for item in the_plan["items"]:
        if item.get("status") in _MARK and str(item.get("page_key", "")).isdigit():
            pages.setdefault(int(item["page_key"]), []).append(item)
    for e in the_plan.get("icon_edits") or []:
        if e.get("status") in _MARK and str(e.get("page_key", "")).isdigit():
            pages.setdefault(int(e["page_key"]), []).append(e)
    for i, (kind, _j, _s) in src_index.items():       # new pages are shown even unchanged
        if kind == "new" or missing.get(i):
            pages.setdefault(i, [])
    removed = {}                                      # pages moved into "[Deleted From Excel]": shown as they were
    for k, (j, sheet) in enumerate(the_plan.get("_removed") or []):
        removed[-1 - k] = ("removed", j, sheet)
        pages[-1 - k] = []
    os.makedirs(folder, exist_ok=True)
    W, H = out.size
    result, n_crop, jobs = [], 0, []
    for n, (top_index, items) in enumerate(sorted(pages.items(), key=lambda kv: (kv[0] < 0, abs(kv[0]))), start=1):
        kind, j, sheet = removed.get(top_index) or src_index.get(top_index, ("page", top_index, None))
        top = src_tops[j] if kind == "removed" else out_tops[top_index]
        name = re.sub(r"[\x00-\x1f]", "", top.name)
        if progress:
            progress(f"Drawing the changes of page {n} of {len(pages)}: {name.strip()}…", 40 + int(50 * n / len(pages)))
        crops = []

        def shot(box, status, item):
            nonlocal n_crop
            box = (max(0, int(box[0])), max(0, int(box[1])), min(W, int(box[2])), min(H, int(box[3])))
            if box[2] <= box[0] or box[3] <= box[1]:
                return
            n_crop += 1
            files = {}
            for label, psd, group in (("before", src, j if isinstance(src, str) else src_tops[j]), ("after", out, top)):
                if label == "after" and kind == "removed":
                    continue
                path = os.path.join(folder, f"{n:02d}-{n_crop:03d} {label}.jpg")
                jobs.append((path, psd, group, box, max_width))
                files[label] = path
            layer = out_layers[item["place"]] if item and item.get("place") is not None and item["place"] < len(out_layers) else None
            crops.append({"status": status, "before": files.get("before", ""), "after": files.get("after", ""),
                          "box": list(box), "page_key": top_index,
                          "key": layer_key(out, layer) if layer is not None and layer.kind == "type" else "",
                          "text": _editor_text(layer).rstrip("\r") if layer is not None and layer.kind == "type" else "",
                          "old": item.get("old", "") if item else "", "new": (item.get("new") or item.get("new_excel") or "") if item else "",
                          "why": item.get("why", "") if item else "", "source": item.get("source", "") if item else ""})

        seen = set()
        for item in items:
            places = [item["place"]] if "place" in item else list(item.get("hide", [])) + [m[0] for m in item.get("move", [])]
            boxes = [tuple(item["box"])] if item.get("box") else []
            for p in places:
                if p is None or p >= len(out_layers):
                    continue
                boxes.append(_box(out_layers[p], 0, out.size))
                if box0.get(p):
                    boxes.append(tuple(box0[p]))
            if not boxes or id(item) in seen:
                continue
            seen.add(id(item))
            l, t = min(b[0] for b in boxes), min(b[1] for b in boxes)
            r, b = max(b[2] for b in boxes), max(b[3] for b in boxes)
            pad = 24
            shot((l - pad, t - pad, r + pad, b + pad), item["status"], item)
        if kind == "removed" or (kind == "new" and not crops):
            shot((0, 0, W, int(H * 0.3)), "removed" if kind == "removed" else "change", None)
        once = {}
        for i in items:
            once[id(i)] = i["status"]
        page_id_ = f"new:{sheet}" if kind == "new" else f"removed:{sheet}" if kind == "removed" else page_id(src_tops[j])
        result.append({"id": page_id_, "kind": kind, "page": name, "page_key": top_index, "sheet": sheet or "",
                       "from": re.sub(r"[\x00-\x1f]", "", src_tops[j].name) if kind == "new" else "",
                       "src_index": j, "crops": crops, "missing": missing.get(top_index, []),
                       "changed": sum(1 for v in once.values() if v == "change"),
                       "issues": sum(1 for v in once.values() if v != "change")})
    if draw:
        draw_crops(jobs, progress=progress)
    else:
        the_plan["_crop_jobs"] = jobs
    return result


def draw_crops(jobs, threads=4, progress=None):
    """Draw listed crops, a few at a time (the compositing is numpy: threads overlap well). Each
    picture is written under a temporary name and renamed, so a half-written one is never shown."""
    from concurrent.futures import ThreadPoolExecutor

    from .artist_design import psd_render

    if not jobs:
        return
    from .artist_design import psd_reader

    def resolve(psd, group):
        """A job may name the artist's PSD by path and its page by place: opened (once, cached) here."""
        if isinstance(psd, str):
            psd = psd_reader.open_psd(psd)
        if isinstance(group, int):
            group = _tops(psd)[group]
        return psd, group

    psd_render.render_page(*resolve(jobs[0][1], jobs[0][2]), (0, 0, 1, 1))   # the one-time compositor set-up

    def one(job):
        path, psd, group, box, max_width = job
        psd, group = resolve(psd, group)
        img = psd_render.render_page(psd, group, box).convert("RGB")
        k = min(1.0, max_width / float(img.width))
        if k < 1.0:
            img = img.resize((int(img.width * k), int(img.height * k)))
        tmp = path + ".part.jpg"
        img.save(tmp, quality=88)
        os.replace(tmp, path)

    done = 0
    with ThreadPoolExecutor(max(1, threads)) as ex:
        for _ in ex.map(one, jobs):
            done += 1
            if progress:
                progress(f"Drawing the changes… {done} of {len(jobs)}", 40 + int(55 * done / len(jobs)))


def _layer_keys(psd):
    """{layer record: layer_key} for every layer of every page group, worked out in one pass and kept
    on the tree (walking every group for every key made the review pictures quadratic: seconds per
    page on a big PSD); worked out again when layers were added."""
    count = len(psd._record.layer_and_mask_information.layer_info.layer_records)
    got = getattr(psd, "_psh_layer_keys", None)
    if got is None or got[0] != count:
        keys = {}
        for top in psd:
            if top.is_group():
                page, seen = re.sub(r"[\x00-\x1f]", "", top.name), {}
                for l in top.descendants():
                    n = seen[l.name] = seen.get(l.name, -1) + 1
                    keys[id(l._record)] = f"{page}/{l.name}#{n}"
        got = (count, keys)
        psd._psh_layer_keys = got
    return got[1]


def layer_key(psd, layer):
    """A text layer's name that stays the same between the preview and the PSD written after it:
    its page group, its name, and which of the page's layers of that name it is."""
    return _layer_keys(psd).get(id(layer._record), f"/{layer.name}#0")


def find_layer(psd, key):
    keys = _layer_keys(psd)
    for top in psd:
        if top.is_group():
            for l in top.descendants():
                if l.kind == "type" and keys.get(id(l._record)) == key:
                    return l
    return None


def redraw(psd, layer):
    """A text layer's pixels drawn again from its text and styles as they now are."""
    got = _preview(layer, _editor_text(layer).rstrip("\r"))
    if got:
        _swap_pixels(psd, layer, *got[:3])
    return got


def ask_photoshop_to_redraw(psd):
    """Drop Photoshop's document text block (Txt2) after text was changed outside Photoshop: on open it
    asks "Some text layers might need to be updated…" and Update lays every text out with its own
    engine and the artist's real fonts (our preview pixels are only close). Each layer keeps its own
    text, styles and effects. Returns True when the block was there."""
    from psd_tools.constants import Tag

    blocks = psd._record.layer_and_mask_information.tagged_blocks
    if blocks is None or Tag.TEXT_ENGINE_DATA not in blocks:
        return False
    del blocks[Tag.TEXT_ENGINE_DATA]
    return True


def set_layer_text(psd, layer, text, draw=True, photoshop_redraw=True):
    """The artist's own text for a layer, from the preview's editor: written like any other change
    (style runs carried, the document text entry kept in step, its preview drawn again — unless
    `draw` is False: more changes to come, then redraw)."""
    from psd_tools.constants import Tag

    blocks = psd._record.layer_and_mask_information.tagged_blocks
    engine = TextEngine(blocks.get_data(Tag.TEXT_ENGINE_DATA) if blocks is not None else None)
    old = _editor_text(layer)
    new = edit_text_layer(layer, str(text).replace("\r\n", "\r").replace("\n", "\r"))
    engine.update(layer, old, new)
    if engine.edited:
        from .psd_apply import splice

        if photoshop_redraw:
            ask_photoshop_to_redraw(psd)              # Photoshop lays the edited text out itself on open
        splice.mark_document(psd)
    if draw:
        got = _preview(layer, new)
        if got:
            _swap_pixels(psd, layer, *got[:3])
    if engine.failed:
        raise ValueError("; ".join(engine.failed))
    return new


def apply_edits(psd, edits):
    """The artist's edits from the preview ({layer key: text}); returns the keys not found."""
    from .psd_apply import layer_ref
    from .psd_apply.records import RecordExecutor

    place_of = {id(l._record): n for n, l in enumerate(psd.descendants())}
    lost, ops = [], []
    for key, text in (edits or {}).items():
        layer = find_layer(psd, key)
        if layer is None:
            lost.append(key)
            continue
        ops.append(dict(layer_ref(layer, place_of[id(layer._record)]), op="edit_text", key=key, text=text))
    RecordExecutor(psd).run_all(ops)
    return lost


def edit_crop(psd, key, text, box, folder, max_width=1400):
    """Edit one layer of the preview in memory and draw its crop again; returns the new picture."""
    import uuid

    from .artist_design import psd_render

    layer = find_layer(psd, key)
    if layer is None:
        raise ValueError("That layer is not in this preview any more — show the changes again.")
    set_layer_text(psd, layer, text)
    top = next(t for t in _tops(psd) if t.is_group() and any(l._record is layer._record for l in t.descendants()))
    l, t, r, b = box
    box = (max(0, min(l, layer.left - 24)), max(0, min(t, layer.top - 24)),
           min(psd.size[0], max(r, layer.right + 24)), min(psd.size[1], max(b, layer.bottom + 24)))
    img = psd_render.render_page(psd, top, box).convert("RGB")
    k = min(1.0, max_width / float(img.width))
    if k < 1.0:
        img = img.resize((int(img.width * k), int(img.height * k)))
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, f"edit {uuid.uuid4().hex[:8]}.jpg")
    img.save(path, quality=88)
    return path, list(box)


def page_picture(source_psd, psd, the_plan, page_key, which, folder):
    """One whole page, before or after (drawn on demand: ~15 s the first time; "before" is cached)."""
    out_tops = _tops(psd)
    _kind, j, _sheet = (the_plan.get("_src_index") or {}).get(int(page_key), ("page", int(page_key), None))
    if int(page_key) < 0:                             # a page now in "[Deleted From Excel]": as it was
        j, which = the_plan["_removed"][-1 - int(page_key)][0], "before"
    path = os.path.join(folder, f"page {page_key} {which}.jpg")
    if os.path.isfile(path):
        return path
    if which == "before":
        from .artist_design import psd_reader

        img = _before_page(source_psd, psd_reader.open_lazy(source_psd), j)
    else:
        from .artist_design import psd_render

        img = psd_render.render_page(psd, out_tops[int(page_key)])
    img = img.convert("RGB")
    k = min(1.0, 1800 / float(img.width))
    if k < 1.0:
        img = img.resize((int(img.width * k), int(img.height * k)))
    os.makedirs(folder, exist_ok=True)
    img.save(path, quality=88)
    return path
