import json


def set_layer_color(layer, app, color_code=1):
    """Set Photoshop layer/group label color. 1=Red, 2=Orange, 3=Yellow, 4=Green, 5=Blue, 6=Violet, 7=Gray, 0=None."""
    try:
        original_active_layer = app.activeDocument.activeLayer
    except Exception:
        original_active_layer = None
    try:
        layer_id = int(getattr(layer, "id", 0) or 0)
    except Exception:
        layer_id = 0
    try:
        name = str(layer.name or "")
    except Exception:
        name = ""
    color_char_ids = {
        0: "None",
        1: "Rd  ",
        2: "Orng",
        3: "Ylw ",
        4: "Grn ",
        5: "Bl  ",
        6: "Vlt ",
        7: "Gry ",
    }
    try:
        color_key = color_char_ids.get(int(color_code or 0), "None")
    except Exception:
        color_key = "None"

    if layer_id or name:
        try:
            name_js = json.dumps(name)
            jsx = f'''
            (function() {{
                var doc = app.activeDocument;
                var colorKey = "{color_key}";
                var targetId = {layer_id};
                var targetName = {name_js};

                function selectLayerById(id) {{
                    var desc = new ActionDescriptor();
                    var ref = new ActionReference();
                    ref.putIdentifier(charIDToTypeID("Lyr "), id);
                    desc.putReference(charIDToTypeID("null"), ref);
                    desc.putBoolean(charIDToTypeID("MkVs"), false);
                    executeAction(charIDToTypeID("slct"), desc, DialogModes.NO);
                }}

                function selectLayerByName(name) {{
                    var desc = new ActionDescriptor();
                    var ref = new ActionReference();
                    ref.putName(charIDToTypeID("Lyr "), name);
                    desc.putReference(charIDToTypeID("null"), ref);
                    desc.putBoolean(charIDToTypeID("MkVs"), false);
                    executeAction(charIDToTypeID("slct"), desc, DialogModes.NO);
                }}

                function setSelectedLayerColor(colorId) {{
                    var desc = new ActionDescriptor();
                    var ref = new ActionReference();
                    ref.putEnumerated(charIDToTypeID("Lyr "), charIDToTypeID("Ordn"), charIDToTypeID("Trgt"));
                    desc.putReference(charIDToTypeID("null"), ref);
                    var layerDesc = new ActionDescriptor();
                    layerDesc.putEnumerated(charIDToTypeID("Clr "), charIDToTypeID("Clr "), charIDToTypeID(colorId));
                    desc.putObject(charIDToTypeID("T   "), charIDToTypeID("Lyr "), layerDesc);
                    executeAction(charIDToTypeID("setd"), desc, DialogModes.NO);
                }}

                try {{
                    if (targetId) {{
                        selectLayerById(targetId);
                    }} else if (targetName) {{
                        selectLayerByName(targetName);
                    }} else {{
                        return;
                    }}
                    setSelectedLayerColor(colorKey);
                }} catch (e) {{
                    // Fallback for versions where Action Manager rejects a color key.
                    var colorMap = {{
                        "None": LayerColor.NONE,
                        "Rd  ": LayerColor.RED,
                        "Orng": LayerColor.ORANGE,
                        "Ylw ": LayerColor.YELLOW,
                        "Grn ": LayerColor.GREEN,
                        "Bl  ": LayerColor.BLUE,
                        "Vlt ": LayerColor.VIOLET,
                        "Gry ": LayerColor.GRAY
                    }};
                    app.activeDocument.activeLayer.color = colorMap[colorKey] || LayerColor.NONE;
                }}
            }})();
            '''
            app.doJavaScript(jsx)
            if original_active_layer is not None:
                try:
                    app.activeDocument.activeLayer = original_active_layer
                except Exception:
                    pass
            return
        except Exception:
            pass
    try:
        layer.color = color_code
    except Exception as e:
        print(f"Could not set layer color for {getattr(layer, 'name', '')}: {e}")
    finally:
        if original_active_layer is not None:
            try:
                app.activeDocument.activeLayer = original_active_layer
            except Exception:
                pass


def collapse_all_layer_groups(app):
    """Collapse Photoshop layer groups in the Layers panel when Photoshop supports it."""
    try:
        app.doJavaScript(
            '''
            (function() {
                try {
                    executeAction(stringIDToTypeID("collapseAllGroupsEvent"), new ActionDescriptor(), DialogModes.NO);
                } catch (e) {}
            })();
            '''
        )
    except Exception as e:
        print(f"Could not collapse layer groups: {e}")
