"""Built-in paytable layouts.

The Paytable mapper ships with a handful of ready-made JSON layouts so the tab
opens with a usable default instead of an empty state. Layouts are plain
mapped-paytable templates (``canvas`` + ``slots`` dict). Users can also drop
their own ``*_layout.json`` files into ``paytable_layouts/user/`` next to this
module, or use the web "Save as layout" action — they show up automatically.
"""

import copy
import json
import os


def _box(x, y, w, h):
    return {"x": x, "y": y, "w": w, "h": h}


def _symbol_column(symbol_index, col_count=6, left=60, right=60, gap=24, width=280):
    """Return (x, w) for one symbol column across a full-width row band."""
    total_w = col_count * width + (col_count - 1) * gap
    x = left + symbol_index * (width + gap)
    return x, width, total_w


def _classic_slots():
    """Two-band layout: 5 top symbol columns + a wild column, and a second
    row of 5 lower-band cards below them. Every card column owns pay and
    value slots under its icon, so a 10-card sheet auto-fills the whole
    template (pic1..pic5 + wild on top, pic6..pic10 below)."""
    slots = {}
    slot_key = "@slot"
    title_h = 88
    icon_y, icon_h = 170, 300
    pay_y, pay_h = 486, 54
    val_y, val_h = 552, 54
    bot_icon_y, bot_icon_h = 630, 150
    bot_pay_y, bot_pay_h = 794, 48
    bot_val_y, bot_val_h = 856, 48
    notes_y, notes_h = 940, 108
    left, gap, width = 60, 24, 280
    for i in range(5):
        x, w, _ = _symbol_column(i, 6, left=left, gap=gap, width=width)
        n = i + 1
        slots[f"{slot_key}.pic{n}"] = _box(x, icon_y, w, icon_h)
        slots[f"{slot_key}.pay{n}"] = _box(x, pay_y, w, pay_h)
        slots[f"{slot_key}.value{n}"] = _box(x, val_y, w, val_h)
    x, w, _ = _symbol_column(5, 6, left=left, gap=gap, width=width)
    slots[f"{slot_key}.wild"] = _box(x, icon_y, w, icon_h)
    slots[f"{slot_key}.wildpay"] = _box(x, pay_y, w, pay_h)
    slots[f"{slot_key}.wildvalue"] = _box(x, val_y, w, val_h)
    for i in range(5):
        x, w, _ = _symbol_column(i, 5, left=left, gap=gap, width=width)
        n = i + 6
        slots[f"{slot_key}.pic{n}"] = _box(x, bot_icon_y, w, bot_icon_h)
        slots[f"{slot_key}.pay{n}"] = _box(x, bot_pay_y, w, bot_pay_h)
        slots[f"{slot_key}.value{n}"] = _box(x, bot_val_y, w, bot_val_h)
    slots[f"{slot_key}.title"] = _box(left, 40, 1920 - left * 2, title_h)
    slots[f"{slot_key}.notes"] = _box(left, notes_y, 1920 - left * 2, notes_h)
    return slots


def _compact_slots():
    """Single strip: 5 compact rows of symbol + pays + value."""
    slots = {}
    slot_key = "@slot"
    left, right = 60, 60
    title_y, title_h = 40, 80
    row_y, row_h = 160, 150
    row_gap = 22
    col_gap = 36
    pic_w, pays_w, value_w = 240, 540, 540
    slots[f"{slot_key}.title"] = _box(left, title_y, 1920 - left - right, title_h)
    for i in range(5):
        n = i + 1
        y = row_y + i * (row_h + row_gap)
        slots[f"{slot_key}.pic{n}"] = _box(left, y, pic_w, row_h)
        slots[f"{slot_key}.pay{n}"] = _box(left + pic_w + col_gap, y, pays_w, row_h)
        slots[f"{slot_key}.value{n}"] = _box(left + pic_w + col_gap + pays_w + col_gap, y, value_w, row_h)
    return slots


def _two_column_slots():
    """Symbols stacked on the left; pays and value columns on the right."""
    slots = {}
    slot_key = "@slot"
    title_y, title_h = 40, 80
    body_y, body_h = 170, 800
    left, right = 60, 60
    col_gap = 60
    sym_w = 420
    pays_w = 420
    value_w = 420
    row_h = 128
    row_gap = 28
    slots[f"{slot_key}.title"] = _box(left, title_y, 1920 - left - right, title_h)
    for i in range(5):
        n = i + 1
        y = body_y + i * (row_h + row_gap)
        slots[f"{slot_key}.pic{n}"] = _box(left, y, sym_w, row_h)
        slots[f"{slot_key}.pay{n}"] = _box(left + sym_w + col_gap, y, pays_w, row_h)
        slots[f"{slot_key}.value{n}"] = _box(left + sym_w + col_gap + pays_w + col_gap, y, value_w, row_h)
    return slots


def _pays_right_slots():
    """Icons centered across the top; a pays/value panel on the right side."""
    slots = {}
    slot_key = "@slot"
    title_y, title_h = 40, 80
    icon_y, icon_h = 190, 430
    panel_x, panel_w = 1380, 480
    header_y, header_h = 190, 80
    row_y, row_h = 290, 110
    row_gap = 22
    slots[f"{slot_key}.title"] = _box(60, title_y, 1920 - 120, title_h)
    icon_w = 230
    icon_gap = 30
    total = 5 * icon_w + 4 * icon_gap
    icon_left = 60 + (900 - total) // 2
    for i in range(5):
        n = i + 1
        x = icon_left + i * (icon_w + icon_gap)
        slots[f"{slot_key}.pic{n}"] = _box(x, icon_y, icon_w, icon_h)
    slots[f"{slot_key}.paytitle"] = _box(panel_x, header_y, panel_w // 2 - 10, header_h)
    slots[f"{slot_key}.valuetitle"] = _box(panel_x + panel_w // 2 + 10, header_y, panel_w // 2 - 10, header_h)
    for i in range(5):
        n = i + 1
        y = row_y + i * (row_h + row_gap)
        slots[f"{slot_key}.pay{n}"] = _box(panel_x, y, panel_w // 2 - 10, row_h)
        slots[f"{slot_key}.value{n}"] = _box(panel_x + panel_w // 2 + 10, y, panel_w // 2 - 10, row_h)
    slots[f"{slot_key}.notes"] = _box(60, 860, 1200, 180)
    return slots


def _wild_slots():
    """Wild-feature emphasis: large wild block plus 5 compact symbol columns."""
    slots = {}
    slot_key = "@slot"
    title_y, title_h = 40, 80
    left, right = 60, 60
    wild_x, wild_w = 60, 520
    wild_icon_y, wild_icon_h = 170, 470
    wild_pay_y, wild_pay_h = 660, 96
    wild_val_y, wild_val_h = 776, 96
    slots[f"{slot_key}.title"] = _box(left, title_y, 1920 - left - right, title_h)
    slots[f"{slot_key}.wild"] = _box(wild_x, wild_icon_y, wild_w, wild_icon_h)
    slots[f"{slot_key}.wildpay"] = _box(wild_x, wild_pay_y, wild_w, wild_pay_h)
    slots[f"{slot_key}.wildvalue"] = _box(wild_x, wild_val_y, wild_w, wild_val_h)
    col_count = 5
    col_gap = 24
    width = (1920 - left - right - wild_w - 60 - (col_count - 1) * col_gap) // col_count
    x0 = wild_x + wild_w + 60
    for i in range(5):
        n = i + 1
        x = x0 + i * (width + col_gap)
        slots[f"{slot_key}.pic{n}"] = _box(x, wild_icon_y, width, wild_icon_h)
        slots[f"{slot_key}.pay{n}"] = _box(x, wild_pay_y, width, wild_pay_h)
        slots[f"{slot_key}.value{n}"] = _box(x, wild_val_y, width, wild_val_h)
    slots[f"{slot_key}.notes"] = _box(left, 916, 1920 - left - right, 120)
    return slots


def _grid_dim(value):
    """Coerce a rows/cols layout option to a positive int, or ``None`` (=auto)."""
    try:
        n = int(value)
    except (TypeError, ValueError):
        return None
    return n if n > 0 else None


def _emit_symbol_cluster(slots, slot_key, name, is_wild, x, y, w, h, placement="right"):
    """Place one symbol cluster with its pay and value columns positioned by
    ``placement`` relative to the icon:

    * ``right`` (default) — icon on the LEFT, pay then value columns to its
      RIGHT; pay/value are vertically CENTERED on their own box.
    * ``left`` — pay then value columns on the LEFT, icon on the RIGHT;
      pay/value vertically CENTERED.
    * ``below`` — icon on TOP (full cell width), pay and value side-by-side
      beneath it; pay/value TOP-aligned.

    Names are dotted and symbol-scoped (``pic3`` / ``pic3.pay`` /
    ``pic3.value``) so the automapper's positional ``_pic_block`` fallback fills
    each from the sheet's Nth card regardless of its real label. A wild cluster
    uses the ``wild`` / ``wildpay`` / ``wildvalue`` names the automapper already
    special-cases. The ``vertical_align`` hint stamped on the pay/value boxes is
    read by the automapper (which otherwise defaults pay/value to ``top``) and
    dropped by ``scale_template_slots`` — so it steers text alignment without
    affecting scaled geometry."""
    icon_key = "wild" if is_wild else name
    pay_key = "wildpay" if is_wild else f"{name}.pay"
    value_key = "wildvalue" if is_wild else f"{name}.value"

    def _put(key, bx, by, bw, bh, valign=None):
        box = _box(bx, by, bw, bh)
        if valign:
            box["vertical_align"] = valign
        slots[f"{slot_key}.{key}"] = box

    placement = str(placement or "right").strip().casefold()
    if placement not in ("right", "left", "below"):
        placement = "right"

    if placement == "below":
        row_gap = max(6, int(round(h * 0.04)))
        icon_h = int(round(h * 0.52))
        lower_y = y + icon_h + row_gap
        lower_h = max(1, h - icon_h - row_gap)
        col_gap = max(6, int(round(w * 0.04)))
        pay_w = (w - col_gap) // 2
        value_w = w - col_gap - pay_w
        _put(icon_key, x, y, w, icon_h)
        _put(pay_key, x, lower_y, pay_w, lower_h, "top")
        _put(value_key, x + pay_w + col_gap, lower_y, value_w, lower_h, "top")
        return

    icon_w = int(round(w * 0.44))
    col_gap = max(6, int(round(w * 0.03)))
    remaining = max(1, w - icon_w - 2 * col_gap)
    pay_w = remaining // 2
    value_w = remaining - pay_w
    if placement == "left":
        pay_x = x
        value_x = pay_x + pay_w + col_gap
        icon_x = value_x + value_w + col_gap
        _put(pay_key, pay_x, y, pay_w, h, "center")
        _put(value_key, value_x, y, value_w, h, "center")
        _put(icon_key, icon_x, y, icon_w, h)
    else:  # right (default)
        _put(icon_key, x, y, icon_w, h)
        pay_x = x + icon_w + col_gap
        _put(pay_key, pay_x, y, pay_w, h, "center")
        value_x = pay_x + pay_w + col_gap
        _put(value_key, value_x, y, value_w, h, "center")


def _emit_symbol_band(slots, slot_key, cells, band_x, band_w, band_y, band_h, placement="right"):
    """Distribute ``cells`` (a list of ``(name, is_wild)``) evenly across one
    full-width horizontal band, each as a ``placement``-positioned cluster."""
    n = len(cells)
    if n <= 0:
        return
    cell_gap = 20
    cell_w = (band_w - (n - 1) * cell_gap) // n
    for idx, (name, is_wild) in enumerate(cells):
        cx = band_x + idx * (cell_w + cell_gap)
        _emit_symbol_cluster(slots, slot_key, name, is_wild, cx, band_y, cell_w, band_h, placement=placement)


def generate_paytable_slots(top_count, lower_count=0, pay_rows=3, has_wild=False,
                            top_names=None, lower_names=None,
                            placement="right", rows=None, cols=None):
    """Paytable layout sized to the sheet's own symbol structure.

    Each symbol is an icon with its pay and value columns, positioned by
    ``placement`` (``right`` / ``left`` / ``below`` — see
    :func:`_emit_symbol_cluster`). A full-width ``title`` band sits at the top,
    a full-width ``text`` rules band (the automapper's catch-all for all
    leftover body text) sits between the title and the grid. Positions are on
    the standard 1920x1080 design canvas; ``scale_template_slots`` scales them
    to the real output canvas at render time.

    Symbol arrangement:

    * ``rows``/``cols`` both ``None`` (default) — sheet-driven bands: one top
      band (plus an optional appended ``wild`` cluster) and, when
      ``lower_count`` > 0, a second band below it.
    * ``rows`` and/or ``cols`` given — every symbol (top + lower + wild) is
      flattened into one ordered list and arranged **row-major** into a grid.
      The missing dimension is derived (``cols = ceil(n / rows)`` etc.); if the
      requested ``rows x cols`` cannot hold every symbol, ``rows`` grows until
      they all fit, so no symbol is ever dropped.

    ``top_names`` / ``lower_names`` (the sheet's real ordered symbol keys, e.g.
    ``["pic1".."pic5"]`` + ``["ace","king",...]``) name each cell for its
    symbol, so the automapper fills it by name AND the live-sheet render filter
    keeps it. This matters: the filter treats any ``picN`` slot with ``N`` past
    the top-row count as a stray top-row card and drops it, so a continuous
    ``pic1..pic10`` numbering would silently lose the entire lower band. When
    names are omitted the bands fall back to positional ``picN`` placeholders
    (a nameless standing default that ``auto_map_page`` regenerates with real
    names before rendering).

    ``pay_rows`` is accepted for forward-compatible per-symbol row sizing; v1
    keeps a uniform band height and relies on the renderer's shrink-to-fit."""
    import math

    slots = {}
    slot_key = "@slot"

    # Real names win over raw counts.
    if top_names:
        top_names = [str(n) for n in top_names]
        top_count = len(top_names)
    else:
        top_names = None
        top_count = max(0, int(top_count or 0))
    if lower_names:
        lower_names = [str(n) for n in lower_names]
        lower_count = len(lower_names)
    else:
        lower_names = None
        lower_count = max(0, int(lower_count or 0))
    if top_count == 0 and lower_count == 0:
        top_count = 1  # never emit an empty grid

    def _cells(names, count, start_index):
        if names is not None:
            return [(nm, str(nm).strip().casefold() == "wild") for nm in names]
        return [(f"pic{start_index + i}", False) for i in range(count)]

    width, height = 1920, 1080
    left = right = 60
    top_margin, bottom_margin = 40, 40
    usable_w = width - left - right

    # Vertical rhythm: title -> rules-text band -> symbol band(s).
    title_y, title_h = top_margin, 90
    text_y, text_h = title_y + title_h + 20, 150
    grid_top = text_y + text_h + 24
    grid_bottom = height - bottom_margin
    grid_h = grid_bottom - grid_top

    slots[f"{slot_key}.title"] = _box(left, title_y, usable_w, title_h)
    slots[f"{slot_key}.text"] = _box(left, text_y, usable_w, text_h)

    # Full ordered cell list (top row, optional wild, then lower row).
    top_cells = _cells(top_names, top_count, 1)
    if has_wild:
        top_cells.append(("wild", True))
    lower_cells = _cells(lower_names, lower_count, top_count + 1) if lower_count > 0 else []

    rows = _grid_dim(rows)
    cols = _grid_dim(cols)
    if rows or cols:
        # Explicit grid: flatten every symbol and fill row-major, growing rows
        # so the chosen grid always holds them all.
        all_cells = top_cells + lower_cells
        n = len(all_cells)
        if n <= 0:
            return slots
        if rows and cols:
            r, c = rows, cols
            if r * c < n:
                r = int(math.ceil(n / float(c)))
        elif rows:
            r = rows
            c = int(math.ceil(n / float(r)))
        else:  # cols only
            c = cols
            r = int(math.ceil(n / float(c)))
        row_gap = 40
        row_h = (grid_h - (r - 1) * row_gap) // r if r > 0 else grid_h
        cell_gap = 20
        cell_w = (usable_w - (c - 1) * cell_gap) // c if c > 0 else usable_w
        for ri in range(r):
            row_cells = all_cells[ri * c:(ri + 1) * c]
            if not row_cells:
                break
            ry = grid_top + ri * (row_h + row_gap)
            for ci, (name, is_wild) in enumerate(row_cells):
                cx = left + ci * (cell_w + cell_gap)
                _emit_symbol_cluster(slots, slot_key, name, is_wild, cx, ry, cell_w, row_h,
                                     placement=placement)
        return slots

    # Auto (sheet-driven) bands.
    band_gap = 40
    has_lower = lower_count > 0
    if has_lower:
        band_h = (grid_h - band_gap) // 2
        band_ys = [grid_top, grid_top + band_h + band_gap]
    else:
        band_h = grid_h
        band_ys = [grid_top]

    _emit_symbol_band(slots, slot_key, top_cells, left, usable_w, band_ys[0], band_h,
                      placement=placement)
    if has_lower:
        _emit_symbol_band(slots, slot_key, lower_cells, left, usable_w, band_ys[1], band_h,
                          placement=placement)

    return slots


def generate_paytable_layout(top_count, lower_count=0, pay_rows=3, has_wild=False, name="auto",
                             top_names=None, lower_names=None,
                             placement="right", rows=None, cols=None):
    """Wrap :func:`generate_paytable_slots` in a full mapped-paytable template
    (canvas 1920x1080), tagged so the mapper knows it was auto-generated."""
    eff_top = len(top_names) if top_names else max(0, int(top_count or 0))
    eff_lower = len(lower_names) if lower_names else max(0, int(lower_count or 0))
    return {
        "template_id": "Paytable_auto",
        "source_psd": "",
        "canvas": {"width": 1920, "height": 1080},
        "slots": generate_paytable_slots(top_count, lower_count, pay_rows, has_wild,
                                         top_names=top_names, lower_names=lower_names,
                                         placement=placement, rows=rows, cols=cols),
        "slot_prefix": "@slot",
        "mapper_meta": {
            "generated_by": "web_paytable_mapper",
            "layout": name,
            "builtin": True,
            "auto_generated": True,
            "top_count": eff_top,
            "lower_count": eff_lower,
            "has_wild": bool(has_wild),
            "placement": str(placement or "right"),
            "rows": _grid_dim(rows),
            "cols": _grid_dim(cols),
        },
        "mappings": {},
    }


_BUILTINS = [
    {
        "name": "auto",
        "title": "Auto (fits your sheet)",
        "description": "Automatically lays out the symbols from your Excel — two bands sized to the sheet, each symbol with its pay and value columns beside it, plus a rules-text band under the heading. No manual box placement.",
        "auto": True,
        "default": True,
    },
    {
        "name": "simple",
        "title": "SimplePaytable",
        "description": "The bundled SimplePaytable JSON default template — 5 symbol cards with pays/values, wild panel and text blocks (3840x2160).",
        "file": "SimplePaytable-JSON_Default_Template.json",
        "default": False,
    },
    {
        "name": "classic",
        "title": "Classic 5-symbol grid",
        "description": "5 symbol columns plus a wild column — icon, pays and value per column. Mirrors the classic Paytable_v28 layout.",
        "build": _classic_slots,
    },
    {
        "name": "compact",
        "title": "Compact rows",
        "description": "One strip of 5 rows: symbol icon, pays and value per row. Great for tall slot boxes.",
        "build": _compact_slots,
    },
    {
        "name": "two_column",
        "title": "Two-column table",
        "description": "Symbols stacked left, pays and value columns on the right, one row per symbol.",
        "build": _two_column_slots,
    },
    {
        "name": "pays_right",
        "title": "Pays-right panel",
        "description": "Symbol icons centered across the top with a right-side pays/value panel and notes.",
        "build": _pays_right_slots,
    },
    {
        "name": "wild",
        "title": "Wild-feature variant",
        "description": "Large wild block on the left with pays/values, plus 5 compact symbol columns.",
        "build": _wild_slots,
    },
]


def _bundled_layouts_dir():
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "paytable_layouts")


def _user_layouts_dir():
    return os.path.join(_bundled_layouts_dir(), "user")


def _load_bundled_file(item):
    path = os.path.join(_bundled_layouts_dir(), item.get("file") or "")
    if not os.path.isfile(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except Exception:
        return None


def _template_for(name, build_fn):
    template_id = f"Paytable_{name}"
    template = {
        "template_id": template_id,
        "source_psd": "",
        "canvas": {"width": 1920, "height": 1080},
        "slots": build_fn(),
        "slot_prefix": "@slot",
        "mapper_meta": {
            "generated_by": "web_paytable_mapper",
            "layout": name,
            "builtin": True,
        },
        "mappings": {},
    }
    return template


def list_paytable_layouts():
    """Return metadata for all available layouts (built-in + user JSONs)."""
    out = []
    for item in _BUILTINS:
        if item.get("file"):
            doc = _load_bundled_file(item)
            slots = (doc or {}).get("slots") or {}
            out.append({
                "name": item["name"],
                "title": item["title"],
                "description": item["description"],
                "slot_count": len(slots) if isinstance(slots, dict) else 0,
                "builtin": True,
                "default": bool(item.get("default")),
            })
            continue
        if item.get("auto"):
            out.append({
                "name": item["name"],
                "title": item["title"],
                "description": item["description"],
                "slot_count": 0,
                "builtin": True,
                "default": bool(item.get("default")),
                "auto": True,
            })
            continue
        slots = item["build"]()
        out.append({
            "name": item["name"],
            "title": item["title"],
            "description": item["description"],
            "slot_count": len(slots),
            "builtin": True,
            "default": bool(item.get("default")),
        })
    user_dir = _user_layouts_dir()
    if os.path.isdir(user_dir):
        for fname in sorted(os.listdir(user_dir)):
            if not str(fname).casefold().endswith(".json"):
                continue
            path = os.path.join(user_dir, fname)
            try:
                with open(path, "r", encoding="utf-8") as handle:
                    doc = json.load(handle)
            except Exception:
                continue
            if not isinstance(doc, dict):
                continue
            slots = doc.get("slots") or {}
            out.append({
                "name": str(doc.get("template_id") or os.path.splitext(fname)[0]),
                "title": str(doc.get("template_id") or os.path.splitext(fname)[0]),
                "description": f"User layout: {fname}",
                "slot_count": len(slots) if isinstance(slots, dict) else 0,
                "builtin": False,
            })
    return out


def get_paytable_layout(name):
    """Return the full template for a layout name (built-in or user JSON)."""
    name = str(name or "").strip()
    for item in _BUILTINS:
        if item["name"] != name:
            continue
        if item.get("file"):
            doc = _load_bundled_file(item)
            if doc:
                doc = copy.deepcopy(doc)
                doc.setdefault("slot_prefix", "@slot")
                doc.setdefault("mappings", {})
                doc["mapper_meta"] = dict(doc.get("mapper_meta") or {})
                doc["mapper_meta"].update({"layout": name, "builtin": True})
                return doc
            return None
        if item.get("auto"):
            # A sensible standing default (5 top + 5 lower) so the name always
            # resolves to a valid template; auto_map_page regenerates this to
            # fit the actual sheet before mapping.
            return generate_paytable_layout(5, 5, name=name)
        return _template_for(name, item["build"])
    user_dir = _user_layouts_dir()
    if os.path.isdir(user_dir):
        wanted = str(name).casefold()
        for fname in sorted(os.listdir(user_dir)):
            if not str(fname).casefold().endswith(".json"):
                continue
            path = os.path.join(user_dir, fname)
            try:
                with open(path, "r", encoding="utf-8") as handle:
                    doc = json.load(handle)
            except Exception:
                continue
            if str(doc.get("template_id") or os.path.splitext(fname)[0]).casefold() == wanted:
                doc["mapper_meta"] = dict(doc.get("mapper_meta") or {})
                doc["mapper_meta"]["layout"] = str(doc.get("template_id") or name)
                doc["mapper_meta"]["builtin"] = False
                doc.setdefault("slot_prefix", "@slot")
                return doc
    return None


def save_user_layout(template, template_id=None):
    """Persist a template as a user layout JSON. Returns the saved path."""
    if not isinstance(template, dict) or not (template.get("slots") or {}):
        raise ValueError("Missing template slots.")
    template_id = str(template_id or template.get("template_id") or "paytable").strip()
    safe_name = re_sub_safe(template_id)
    user_dir = _user_layouts_dir()
    os.makedirs(user_dir, exist_ok=True)
    doc = copy.deepcopy(template)
    doc["template_id"] = template_id
    doc["mapper_meta"] = dict(doc.get("mapper_meta") or {})
    doc["mapper_meta"]["layout"] = template_id
    doc["mapper_meta"]["builtin"] = False
    path = os.path.join(user_dir, f"{safe_name}_layout.json")
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(doc, handle, indent=2)
    return path


def re_sub_safe(value):
    import re

    return re.sub(r"[^A-Za-z0-9_\-]+", "_", str(value or "")).strip("_") or "paytable"
