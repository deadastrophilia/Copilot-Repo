"""Granted-folder policy for filesystem-touching web API endpoints.

The server binds to localhost and the Host/Origin guard blocks cross-site
requests; this module adds a second layer of defense for endpoints that read
or write arbitrary paths. A path is only accessible when it lives under a
root granted by one of:

- the native file/folder dialogs (pywebview bridge),
- the session/preset configuration (seeded on load and re-granted on save),
- workspace defaults (cwd + temp dir).

Paths picked through the OS dialogs are trusted because they require desktop
interaction; everything else must fall inside an already-granted tree.
"""

from __future__ import annotations

import os
import tempfile
import threading

_lock = threading.Lock()
_roots = set()

_PATH_KEY_SUFFIXES = ("_path", "_folder", "_dir", "_file")
_KNOWN_PATH_KEYS = {
    "excel_path",
    "icon_folder",
    "bg_path",
    "output_dir",
    "prev_excel_path",
    "prev_psd_path",
    "safe_backup_folder",
    "heading_image_folder",
}


def _normalize(path) -> str:
    try:
        expanded = os.path.expanduser(str(path or "").strip())
        return os.path.normcase(os.path.abspath(expanded))
    except Exception:
        return ""


def _nearest_existing_dir(path: str) -> str:
    current = path
    for _ in range(12):
        if os.path.isdir(current):
            return current
        if os.path.isfile(current):
            return os.path.dirname(current)
        parent = os.path.dirname(current)
        if not parent or parent == current:
            return ""
        current = parent
    return ""


def grant(path) -> None:
    """Trust the folder containing `path` (or `path` itself when a folder)."""
    normalized = _normalize(path)
    if not normalized:
        return
    target = _nearest_existing_dir(normalized)
    if not target:
        return
    with _lock:
        _roots.add(os.path.normcase(os.path.realpath(target)))


def grant_tree(path) -> None:
    """Trust a folder even when it does not exist yet."""
    normalized = _normalize(path)
    if not normalized:
        return
    with _lock:
        _roots.add(os.path.normcase(os.path.realpath(normalized)))


def grant_config_paths(config, _depth: int = 0) -> int:
    """Grant every filesystem-looking value inside a session config mapping.

    Returns how many new roots were granted. Nested dicts/lists are walked so
    values like ``dynamic_settings.template_json_map`` are covered too.
    """
    granted = 0
    if _depth > 6:
        return granted
    if isinstance(config, dict):
        for key, value in config.items():
            granted += grant_config_paths(value, _depth + 1)
            if not isinstance(value, str) or not value.strip():
                continue
            name = str(key or "")
            is_known = name in _KNOWN_PATH_KEYS or name.endswith(_PATH_KEY_SUFFIXES)
            looks_like_existing_path = os.path.isabs(value) and (
                os.path.isfile(value) or os.path.isdir(value)
            )
            if is_known or looks_like_existing_path:
                before = allowed_root_count()
                grant(value)
                if allowed_root_count() != before:
                    granted += 1
    elif isinstance(config, (list, tuple)):
        for item in config:
            granted += grant_config_paths(item, _depth + 1)
    return granted


def seed_defaults(workspace=None, include_temp: bool = True) -> None:
    """Seed baseline roots: workspace and (optionally) the temp directory."""
    candidates = [workspace or os.getcwd()]
    if include_temp:
        candidates.append(tempfile.gettempdir())
    with _lock:
        for candidate in candidates:
            if candidate:
                _roots.add(os.path.normcase(os.path.realpath(candidate)))


def is_allowed(path) -> bool:
    raw = str(path or "").strip()
    if not raw:
        return False
    normalized = _normalize(raw)
    if not normalized:
        return False
    try:
        real = os.path.normcase(os.path.realpath(normalized))
    except Exception:
        return False
    with _lock:
        roots = tuple(_roots)
    for root in roots:
        if real == root:
            return True
        trimmed = root.rstrip("\\/") if root else root
        if trimmed and real.startswith(trimmed + os.sep):
            return True
    return False


def allowed_roots() -> list:
    with _lock:
        return sorted(_roots)


def allowed_root_count() -> int:
    with _lock:
        return len(_roots)


def reset_for_tests(workspace=None) -> None:
    with _lock:
        _roots.clear()
    seed_defaults(workspace, include_temp=False)
