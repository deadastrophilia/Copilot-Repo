"""Native desktop window for the Web UI (pywebview).

Gives the SPA a real app window (Edge WebView2 / Chromium) plus native
file/folder dialogs and drag-and-drop — so artists get real paths, not
browser-only picks.
"""

from __future__ import annotations

import threading

import webview

from .path_policy import grant as grant_path_policy
from .server import create_app, find_free_port

DEFAULT_PORT = 8750
WINDOW_TITLE = "PsHelpScreenTool"
BG_COLOR = "#0B0E14"

_EXCEL_TYPES = ("Excel files (*.xlsx;*.xlsm)",)
_IMAGE_TYPES = ("Images (*.png;*.jpg;*.jpeg;*.bmp;*.gif)",)
_PSD_TYPES = ("Photoshop files (*.psd;*.psb)",)
_JSON_TYPES = ("JSON files (*.json)",)
_ALL_TYPES = ("All files (*.*)",)


class NativeApi:
    """Exposed to the page as window.pywebview.api."""

    def __init__(self, window=None):
        self._window = window

    def browse_file(self, kind: str = "all") -> str:
        """Open a native file dialog; return the chosen path (or '')."""
        types = {
            "excel": _EXCEL_TYPES,
            "image": _IMAGE_TYPES,
            "file": _IMAGE_TYPES,
            "psd": _PSD_TYPES,
            "json": ("JSON files (*.json)",),
            "template": (_PSD_TYPES[0], "JSON files (*.json)"),
        }.get(kind, _ALL_TYPES)
        try:
            result = self._window.create_file_dialog(
                webview.OPEN_DIALOG,
                file_types=types,
                allow_multiple=False,
            )
        except Exception:
            return ""
        if not result:
            return ""
        chosen = str(result[0]) if isinstance(result, (list, tuple)) else str(result)
        if chosen:
            grant_path_policy(chosen)
        return chosen

    def browse_folder(self) -> str:
        try:
            result = self._window.create_file_dialog(webview.FOLDER_DIALOG)
        except Exception:
            return ""
        if not result:
            return ""
        chosen = str(result[0]) if isinstance(result, (list, tuple)) else str(result)
        if chosen:
            grant_path_policy(chosen)
        return chosen

    def save_file(self, title: str = "Save file", default_name: str = "file.json") -> str:
        """Open the native Windows Save-As dialog; return the chosen path (or '')."""
        try:
            result = self._window.create_file_dialog(
                webview.SAVE_DIALOG,
                file_types=_JSON_TYPES,
                save_filename=default_name or "file.json",
            )
        except Exception:
            return ""
        if isinstance(result, (list, tuple)):
            chosen = str(result[0]) if result else ""
        else:
            chosen = str(result) if result else ""
        if chosen:
            grant_path_policy(chosen)
        return chosen


def launch_desktop(port: int = DEFAULT_PORT, title: str = WINDOW_TITLE, width: int = 1500, height: int = 940):
    """Start the Flask server in a thread and open a native app window."""
    server_app = create_app()
    actual_port = find_free_port(port)
    threading.Thread(
        target=lambda: server_app.run(
            host="127.0.0.1", port=actual_port, debug=False, use_reloader=False, threaded=True
        ),
        daemon=True,
    ).start()

    url = f"http://127.0.0.1:{actual_port}/"
    api = NativeApi()
    window = webview.create_window(
        title,
        url,
        js_api=api,
        width=width,
        height=height,
        min_size=(1080, 700),
        background_color=BG_COLOR,
    )
    api._window = window
    webview.start(debug=False, private_mode=True)
