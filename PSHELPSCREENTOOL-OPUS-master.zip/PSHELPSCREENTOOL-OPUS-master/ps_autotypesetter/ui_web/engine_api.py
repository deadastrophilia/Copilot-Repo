"""Web UI backend: config, Excel/icon scanning, presets, AI commands, build dispatch.

Only openpyxl-backed helpers are imported at module level so the server can
start even when Photoshop is not installed or closed. Build entry points
(build_engine / png_builder) are imported lazily inside the build worker.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import sys
import threading

from openpyxl import load_workbook

from .. import safe_json
from .. import bg_place as _bg_place

_SESSION_FILE = os.path.join(os.path.expanduser("~"), "PsHelpScreenTool_Web_Session.json")



def _raw_sheet(value):
    """A sheet name as the workbook has it (Excel allows a trailing space: "BONUS 1 " — trimmed, it is
    a sheet that doesn't exist); a blank name is "none"."""
    raw = str(value or "")
    return raw if raw.strip() else ""

def _preset_folder() -> str:
    """Preset folder. Frozen builds keep a writable copy next to the EXE,
    seeded from the bundled (read-only) resources on first run."""
    if getattr(sys, "frozen", False):
        exe_dir = os.path.dirname(sys.executable)
        folder = os.path.join(exe_dir, "presets")
        if not os.path.isdir(folder) or not os.listdir(folder):
            os.makedirs(folder, exist_ok=True)
            bundled = os.path.join(getattr(sys, "_MEIPASS", ""), "ui_web", "presets")
            if os.path.isdir(bundled):
                for fn in os.listdir(bundled):
                    if fn.lower().endswith(".json"):
                        try:
                            shutil.copy2(os.path.join(bundled, fn), os.path.join(folder, fn))
                        except OSError:
                            pass
        return folder
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "presets")

CANVAS_PRESETS = [
    {"name": "Full HD", "width": 1920, "height": 1080},
    {"name": "HD Ready", "width": 1280, "height": 720},
    {"name": "2K QHD", "width": 2560, "height": 1440},
    {"name": "4K UHD", "width": 3840, "height": 2160},
    {"name": "8K UHD", "width": 7680, "height": 4320},
    {"name": "Standard", "width": 1024, "height": 768},
    {"name": "Square 2048x2048", "width": 2048, "height": 2048},
    {"name": "Portrait 1080x1920", "width": 1080, "height": 1920},
]

_DEFAULT_ALIGNMENT_SETTINGS = {
    "source": "page_override",
    "global": {
        "heading": "center",
        "body": "center",
        "table": "center",
        "bottom": "center",
        "paytable_notes": "center",
        "heading_left_margin": 80,
        "body_left_margin": 80,
    },
    "overrides": {},
    "heading_image_folder": "",
    "heading_image_height": 0,
}

_DEFAULT_DYNAMIC_SETTINGS = {
    "enabled": True,
    "sheet_name": "Paytable",
    "page_type": "paytable",
    "heading_uppercase_enabled": False,
    "heading_game_name_text": "",
    "heading_keep_one_line": False,
    "heading_one_line_margin": 80,
    "subheading_font_request": "",
    "subheading_size": 36,
    "subheading_rgb": [255, 255, 255],
    "paytable_notes_alignment": "center",
    "payout_placement_mode": "Bottom of icon",
    "wild_title_slot_text": "WILD",
    "scatter_title_slot_text": "SCATTER",
    "wild_asset": "gold_scat.png",
    "count_font_request": "",
    "value_font_request": "",
}

DEFAULT_CONFIG = {
    "excel_path": "",
    "icon_folder": "",
    "bg_path": "",
    "output_dir": "",
    "output_name": "",
    "recent_projects": [],
    "c_width": 1920,
    "c_height": 1080,
    "c_resolution": 72,
    "canvas_preset": "Full HD",
    "margin_x": 80,
    "max_col_limit": 12,
    "h_font": "ArialMT",
    "h_font_style": "regular",
    "h_size": 60,
    "h_icon_h": 40,
    "h_rgb": "#FFFFFF",
    "h_bold": True,
    "b_font": "ArialMT",
    "b_font_style": "regular",
    "b_size": 30,
    "b_icon_h": 28,
    "b_rgb": "#FFFFFF",
    "line_spacing": 1.1,
    "para_spacing": 14,
    "gap_px": 20,
    "heading_icon_gap": 15,
    "heading_icon_gap_left": 15,
    "heading_icon_gap_right": 15,
    "icon_gap_left": 15,
    "icon_gap_right": 15,
    "icon_y_offset": 0,
    "alignment": "center",
    "bg_mode": "cover",          # fill the canvas proportionally (no stretch, no side bars)
    "bg_source": "image",
    "bg_color": "#FFFFFF",
    "enable_tables": True,
    "heading_png_mode": False,
    "render_all_pages": True,
    "selected_sheets": [],
    "build_output": "both",
    "keyword_colors": {},
    "heading_style": None,
    "body_style": None,
    "icon_style": None,
    "table_style": None,
    "dynamic_settings": None,
    "icon_mappings": {},
    "icon_size_overrides": {},
    "prev_excel_path": "",
    "prev_psd_path": "",
    "overwrite_existing": False,
    "update_save_mode": "overwrite",
    "output_format": "PSD",
    "performance_mode": False,
    "headless_mode": False,
    "heading_top_margin": 150,
    "continued_gap": 15,
    "heading_to_body_gap": 40,
    "bottom_margin": 50,
    "inner_canvas_width": 0,
    "png_suffix": "",
    "update_mode": False,
    "safe_backup": False,
    "safe_backup_folder": "",
    "write_links_folder": False,     # also write MyGame_Links/ + .project.json (the PSD holds the project anyway)
    "alignment_settings": None,
    "render_game_rules": True,
    "render_bingo_rules": True,
    "icon_simple_mode": True,
    "body_icons_use_original_size": False,
    "ai_suggestions": [],
}


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _hex_to_rgb(value, fallback=(255, 255, 255)):
    if not isinstance(value, str):
        return fallback
    m = re.match(r"^#?([0-9a-fA-F]{6})$", value.strip())
    if not m:
        return fallback
    h = m.group(1)
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))


def _color_tuple(value, fallback=None):
    """Accept [r,g,b] tuples/lists or #RRGGBB strings; always return a tuple."""
    if value is None:
        return tuple(fallback) if fallback is not None else None
    if isinstance(value, str):
        return _hex_to_rgb(value, fallback or (255, 255, 255))
    try:
        return tuple(int(v) for v in value)
    except Exception:
        return tuple(fallback) if fallback is not None else None


def _as_int(value, fallback=0):
    try:
        return int(float(value))
    except Exception:
        return int(fallback or 0)


def _font_request(name, style="regular"):
    name = (name or "").strip()
    if not name:
        return ""
    from .. import fontfaces

    if fontfaces.is_face_style(style):                 # a face from the font's own style menu: exactly that face
        return fontfaces.request(name, style)
    style = (style or "regular").strip().casefold()
    if style in ("regular", "normal", ""):
        return name
    parts = [name]
    if "bold" in style:
        parts.append("bold")
    if "italic" in style:
        parts.append("italic")
    return "|".join(parts)


_TABLE_COLOR_KEYS = (
    "header_bg_rgb", "row1_bg_rgb", "row2_bg_rgb", "header_text_rgb",
    "table_body_text_rgb", "stroke_rgb", "border_rgb", "text_rectangle_fill_rgb",
    "text_rectangle_stroke_rgb", "text_rectangle_text_rgb",
)


def _normalize_table_style(ts):
    if not isinstance(ts, dict):
        return None
    out = {}
    for k, v in ts.items():
        if k in _TABLE_COLOR_KEYS:
            out[k] = _color_tuple(v, (255, 255, 255))
        elif k in ("overlay_opacity", "stroke_width", "row_gap", "after_table_margin",
                   "after_table_min_text_room", "table_header_font_size", "table_body_font_size",
                   "table_icon_height", "table_icon_gap_left", "table_icon_gap_right",
                   "table_target_height", "table_target_width",
                   "text_rectangle_stroke_width", "text_rectangle_opacity", "text_rectangle_font_size",
                   "text_rectangle_pad_x", "text_rectangle_pad_y", "cell_padding_x", "cell_padding_y"):
            out[k] = _as_int(v, 0)
        else:
            out[k] = v
    return out


_DYNAMIC_COLOR_KEYS = (
    "title_rgb", "subheading_rgb", "count_rgb", "value_rgb", "fallback_symbol_rgb",
    "top_card_bg_rgb", "lower_card_bg_rgb", "card_stroke_rgb", "text_bg_rgb",
    "wild_title_rgb", "wild_text_rgb", "notes_text_rgb", "game_rules_separator_rgb",
)


def _normalize_dynamic_settings(ds):
    if not isinstance(ds, dict):
        return None
    out = {}
    for k, v in ds.items():
        if k in _DYNAMIC_COLOR_KEYS:
            out[k] = _color_tuple(v, (255, 255, 255))
        elif k in ("heading_one_line_margin", "subheading_size", "count_size", "value_size",
                   "fallback_symbol_size", "top_card_bg_opacity", "lower_card_bg_opacity",
                   "card_stroke_width", "text_bg_opacity", "wild_title_size", "wild_text_size",
                   "notes_text_size", "top_symbol_icon_height", "lower_symbol_icon_height",
                   "wild_icon_height", "inline_icon_height", "inline_icon_gap", "inline_line_height",
                   "game_rules_bottom_font_size", "game_rules_bottom_gap", "game_rules_separator_width",
                   "game_rules_separator_height", "game_rules_separator_margin",
                   "game_rules_bottom_lr_margin", "game_rules_malfunction_lr_margin",
                   "game_rules_line_height", "game_rules_malfunction_line_height",
                   "game_rules_dynamic_line_height", "game_rules_xtra_reels_width",
                   "game_rules_xtra_reels_outer_margin", "game_rules_xtra_reels_text_gap",
                   "game_rules_xtra_reels_y_offset", "bingo_rules_body_size",
                   "bingo_rules_left_margin", "bingo_rules_line_spacing", "bingo_rules_para_spacing",
                   "bingo_rules_bottom_margin", "line_gap"):
            out[k] = _as_int(v, 0)
        else:
            out[k] = v
    return out


def _normalize_alignment_settings(settings):
    if not isinstance(settings, dict):
        settings = {}
    out = dict(settings)
    global_cfg = out.get("global")
    if not isinstance(global_cfg, dict):
        global_cfg = dict(_DEFAULT_ALIGNMENT_SETTINGS["global"])
    out["global"] = dict(global_cfg)
    for k in ("heading_left_margin", "body_left_margin"):
        out["global"][k] = _as_int(out["global"].get(k), 80)
    out["heading_image_height"] = _as_int(out.get("heading_image_height"), 0)
    out["overrides"] = dict(out.get("overrides") or {})
    return out


def _merged_dynamic_settings(config):
    ds = config.get("dynamic_settings")
    merged = dict(_DEFAULT_DYNAMIC_SETTINGS)
    if isinstance(ds, dict):
        merged.update(ds)
    # Icon-spacing sliders live on the top-level config (layoutConfig); the
    # GR/Bingo PNG renderers read them from dynamic_settings, so fold the
    # explicit top-level values in here. The same merge feeds both the live
    # previews and the final PNG build (build_pngs_only ignores top-level
    # kwargs like heading_icon_gap_left via **_ignored).
    head_gap = config.get("heading_icon_gap")
    if head_gap not in (None, ""):
        merged.setdefault("heading_icon_gap", head_gap)
    for key in ("heading_icon_gap_left", "heading_icon_gap_right"):
        val = config.get(key)
        if val is not None and val != "":
            merged[key] = val
    for key in ("icon_gap_left", "icon_gap_right"):
        val = config.get(key)
        if val is not None and val != "":
            merged[key] = val
    return _normalize_dynamic_settings(merged)


def _sheet_type(name: str) -> str:
    from ..content_model import page_kind

    return page_kind(name)


_SAVE_LOCK = threading.Lock()
_SESSION_STATE = {"last_saved": None, "note": ""}


def _load_config() -> dict:
    cfg = dict(DEFAULT_CONFIG)
    # An unreadable session used to reset everything to defaults, and the next
    # save then overwrote it; now it is moved aside and .bak / a backup loaded.
    stored, note = safe_json.read_json_recover(_SESSION_FILE)
    _SESSION_STATE["note"] = note
    if note:
        print(f"[session] {note}")
    if isinstance(stored, dict):
        cfg.update(stored)
    return cfg


def session_note() -> str:
    """What _load_config had to recover, or "" (shown once in the UI)."""
    return _SESSION_STATE["note"]


def _save_config(cfg: dict) -> None:
    try:
        text = json.dumps(cfg, sort_keys=True, default=str)
    except Exception as exc:
        print(f"[session] not saved, config is not JSON: {exc}")
        return
    with _SAVE_LOCK:                                   # one writer at a time, in call order
        if text == _SESSION_STATE["last_saved"] and os.path.isfile(_SESSION_FILE):
            return                                     # unchanged: skip the disk write
        try:
            safe_json.keep_previous(_SESSION_FILE)
            safe_json.snapshot(_SESSION_FILE)
        except OSError as exc:
            print(f"[session] backup failed: {exc}")
        try:
            safe_json.write_json(_SESSION_FILE, cfg)
            _SESSION_STATE["last_saved"] = text
        except Exception as exc:
            print(f"[session] save failed, previous file kept: {exc}")


def set_session_file(path: str) -> None:
    global _SESSION_FILE
    _SESSION_FILE = path
    _SESSION_STATE.update(last_saved=None, note="")


def _sanitize_preset_name(name: str) -> str:
    name = name.strip()
    return re.sub(r"[^A-Za-z0-9 _\-]+", "", name) or "Preset"


# ---------------------------------------------------------------------------
# project discovery & recent projects (reusable dashboard workflow)
# ---------------------------------------------------------------------------

def _first_bg_image_file(bg_path: str) -> str:
    """Pick the first background image inside a legacy folder-valued bg_path.

    Mirrors page_thumbs._first_bg_image: prefers files whose name starts
    with bg/background, then any png/jpg image in the folder.
    """
    try:
        names = sorted(os.listdir(bg_path))
    except Exception:
        return ""
    for fn in names:
        if fn.lower().startswith(("bg", "background")) and fn.lower().endswith(
            (".png", ".jpg", ".jpeg", ".bmp", ".gif")
        ):
            return os.path.join(bg_path, fn)
    for fn in names:
        if fn.lower().endswith((".png", ".jpg", ".jpeg", ".bmp")):
            return os.path.join(bg_path, fn)
    return ""


def project_discovery(folder: str) -> dict:
    """Discover a game project inside a folder. Reusable by Create New PSD,
    Update PSD and Export PNGs; wraps ai_assist.detect_project with a
    dashboard-ready summary."""
    from .. import ai_assist  # local import: keeps server boot Photoshop-free

    folder = str(folder or "").strip().strip('"')
    if not folder:
        return {"ok": False, "error": "No folder provided.", "folder": ""}
    if not os.path.isdir(folder):
        return {"ok": False, "error": f"Folder not found: {folder}", "folder": folder}
    det = ai_assist.detect_project(folder)
    if det.get("error"):
        return {"ok": False, "error": det["error"], "folder": folder}

    excel_path = det.get("excel_path")
    icon_folder = det.get("icon_folder")
    bg_path = det.get("bg_path")  # background image FILE (or folder, legacy)
    output_dir = det.get("output_dir")

    # Legacy configs may hold a folder; resolve it to the actual image file
    # so the Project section and the renderers always see a usable path.
    if bg_path and os.path.isdir(bg_path):
        bg_path = _first_bg_image_file(bg_path) or bg_path
    will_create = bool(det.get("output_will_be_created"))

    def _resolved(path, is_dir=False):
        if not path:
            return None
        return path if (os.path.isdir(path) if is_dir else os.path.isfile(path)) else None

    found = {
        "folder": os.path.isdir(folder),
        "excel": bool(_resolved(excel_path)),
        "icons": bool(_resolved(icon_folder, is_dir=True)),
        "background": bool(bg_path and (os.path.isfile(bg_path) or os.path.isdir(bg_path))),
        "output": bool(_resolved(output_dir, is_dir=True)) or will_create,
    }
    missing = [k for k, ok in found.items() if k != "folder" and not ok]
    return {
        "ok": True,
        "folder": folder,
        "name": os.path.basename(folder.rstrip("\\/")) or folder,
        "found": found,
        "missing": missing,
        "excel_path": _resolved(excel_path),
        "excel_candidates": det.get("excel_candidates") or [],
        "icon_folder": _resolved(icon_folder, is_dir=True),
        "bg_path": bg_path,
        "output_dir": output_dir,
        "output_will_be_created": will_create,
        "psd_files": det.get("psd_files") or [],
        "excel_count": det.get("excel_count") or 0,
        "bg_count": det.get("bg_count") or 0,
    }


def record_recent_project(cfg: dict, folder: str, name: str = "") -> dict:
    """Push a game folder onto the recent-projects ring (cap 8, newest first).
    Mutates and returns cfg so the caller persists once."""
    import datetime

    folder = str(folder or "").strip()
    if not folder:
        return cfg
    entry = {
        "folder": folder,
        "name": name or os.path.basename(folder.rstrip("\\/")) or folder,
        "opened_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
    }
    entries = [e for e in (cfg.get("recent_projects") or []) if e.get("folder") != folder]
    entries.insert(0, entry)
    cfg["recent_projects"] = entries[:8]
    return cfg


# ---------------------------------------------------------------------------
# project package (MyGame.project.json + MyGame_Links/)
# ---------------------------------------------------------------------------

def detect_project_package(psd_path: str) -> dict:
    """Does a master manifest exist beside this PSD? For the Update PSD flow.

    "package" carries the manifest dict itself (files.excel is the remembered
    source workbook); "baseline" reports the saved Excel baseline state.
    """
    from .. import project_package as pp

    psd_path = str(psd_path or "").strip()
    path = pp.manifest_path_for_psd(psd_path)
    stem = os.path.splitext(os.path.basename(psd_path))[0] if psd_path else ""
    if not path or not os.path.isfile(path):
        return {
            "ok": True,
            "exists": False,
            "manifest": None,
            "links": None,
            "project_name": stem,
            "project_id": "",
            "package": None,
            "baseline": pp.load_baseline_info(psd_path),
        }
    m = pp.load_package_manifest(path) or {}
    return {
        "ok": True,
        "exists": True,
        "manifest": os.path.abspath(path),
        "links": pp.links_dir_for_psd(psd_path),
        "project_name": m.get("project_name") or stem,
        "project_id": m.get("project_id") or "",
        "updated_at": m.get("updated_at") or "",
        "package": m,
        "baseline": pp.load_baseline_info(psd_path),
    }


def load_project_package(path: str, session_cfg: dict) -> dict:
    """Restore a project package into a session config copy."""
    from .. import project_package as pp

    result = pp.load_project(str(path or "").strip(), session_cfg)
    if result.get("ok"):
        project = result.get("project") or {}
        folder = os.path.dirname(result.get("manifest") or "") or ""
        record_recent_project(result["config"], folder, project.get("project_name") or "")
    return result


def update_diff_preview(config: dict) -> dict:
    """Excel diff for the Update PSD flow. Never raises.

    The Old Excel (diff source) is resolved in this order:
      1. an explicit prev_excel_path (legacy / manual override),
      2. the saved baseline copy in the project package (auto),
      3. nothing -> empty diff.

    When the baseline exists and the current Excel is byte-identical to it
    (same SHA-256), the diff short-circuits with "no_changes": True — no
    sheet hashing needed at all.

    Returns {"ok": bool, "diff": dict, "prev_excel_path": str,
             "new_excel_path": str, "baseline_used": bool,
             "baseline": {...}, "no_changes": bool?}."""
    from .. import project_package as pp
    from ..production_features import excel_diff_summary

    prev_psd = str(config.get("prev_psd_path") or "").strip()
    prev_excel = str(config.get("prev_excel_path") or "").strip()
    new_excel = str(config.get("excel_path") or "").strip()
    max_col = int(config.get("max_col_limit") or 12)

    baseline = None
    baseline_used = False
    if not prev_excel or not os.path.isfile(prev_excel):
        info = pp.load_baseline_info(prev_psd)
        if info.get("exists"):
            prev_excel = info.get("baseline") or ""
            baseline = info
            baseline_used = True
            print(
                f"[COMPARE] Diffing against saved baseline V{info.get('version_number')} "
                f"({info.get('baseline')})"
            )

    result = {
        "ok": True,
        "prev_excel_path": prev_excel,
        "new_excel_path": new_excel,
        "baseline_used": baseline_used,
        "baseline": {
            "exists": bool(baseline and baseline.get("exists")),
            "version_number": (baseline or {}).get("version_number") or 0,
            "original_path": (baseline or {}).get("original_path") or "",
            "file_hash": (baseline or {}).get("file_hash") or "",
        },
    }

    # Fast path: the workbook at the source path is byte-identical to the one
    # the PSD was built from — nothing to update, no sheet hashing required.
    if baseline and baseline_used and new_excel and os.path.isfile(new_excel):
        new_hash = pp.file_sha256(new_excel)
        if new_hash and new_hash == baseline.get("file_hash"):
            print("[COMPARE] File hashes identical — no changes detected.")
            result["no_changes"] = True
            result["diff"] = {"changed": [], "added": [], "removed": [],
                              "unchanged": [], "details": []}
            return result

    diff = excel_diff_summary(prev_excel, new_excel, max_col)
    result["diff"] = diff
    return result


# ---------------------------------------------------------------------------
# excel / icon scanning (offline-safe)
# ---------------------------------------------------------------------------

def scan_excel(excel_path: str) -> dict:
    """Return sheet list, page types, paytables and a small preview grid."""
    result = {
        "ok": False,
        "error": "",
        "file": excel_path,
        "sheets": [],
        "pages": [],
        "paytables": [],
        "game_rules": [],
        "bingo_rules": [],
    }
    if not excel_path or not os.path.isfile(excel_path):
        result["error"] = "Excel file not found."
        return result
    try:
        wb = load_workbook(excel_path, read_only=True, data_only=True)
    except Exception as e:
        result["error"] = f"Could not open Excel file: {e}"
        return result

    try:
        from ps_autotypesetter.build_engine import detect_master_border

        for ws in wb.worksheets:
            if str(getattr(ws, "sheet_state", "visible") or "visible") != "visible":
                continue                      # hidden in Excel: not a page of the help screen
            preview = []
            for row in ws.iter_rows(min_row=1, max_row=6, max_col=min(ws.max_column or 1, 8)):
                preview.append(
                    [("" if v is None else str(v))[:60] for v in (cell.value for cell in row)]
                )
            entry = {
                "name": ws.title,
                "type": _sheet_type(ws.title),
                "rows": ws.max_row or 0,
                "cols": ws.max_column or 0,
                "preview": preview,
                "master_border": detect_master_border(ws),
            }
            result["sheets"].append(entry)
            key_for_type = {"page": "pages", "paytable": "paytables", "game_rules": "game_rules", "bingo_rules": "bingo_rules"}
            result[key_for_type[entry["type"]]].append(entry)
    finally:
        wb.close()

    result["ok"] = True
    return result


def scan_icons(excel_path: str, icon_folder: str, icon_mappings: dict = None) -> dict:
    from .icon_scan import scan_icon_status_web

    return scan_icon_status_web(excel_path, icon_folder, icon_mappings)


def list_icon_files(icon_folder: str) -> list:
    from .icon_scan import list_icon_files_web

    return list_icon_files_web(icon_folder)


def list_presets() -> list:
    names = []
    if os.path.isdir(_preset_folder()):
        for fn in sorted(os.listdir(_preset_folder())):
            if fn.lower().endswith(".json"):
                names.append(fn[:-5])
    return names


def preset_path(name: str) -> str:
    return os.path.join(_preset_folder(), _sanitize_preset_name(name) + ".json")


def save_preset(name: str, config: dict) -> dict:
    name = _sanitize_preset_name(name)
    path = preset_path(name)
    safe_json.write_json(path, config)
    return {"ok": True, "name": name}


def load_preset(name: str) -> dict:
    path = preset_path(name)
    if not os.path.isfile(path):
        raise FileNotFoundError(f"Preset '{name}' not found.")
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def delete_preset(name: str) -> dict:
    path = preset_path(name)
    if os.path.isfile(path):
        os.remove(path)
    return {"ok": True, "name": name}


def _seed_default_preset() -> None:
    if list_presets():
        return
    os.makedirs(_preset_folder(), exist_ok=True)
    candidates = [
        os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "ui_qt", "ui_qt_presets", "Default.json"),
        os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "presets", "DefaultPreset.json"),
    ]
    for c in candidates:
        if os.path.isfile(c):
            try:
                with open(c, "r", encoding="utf-8") as f:
                    data = json.load(f)
                with open(preset_path("Default"), "w", encoding="utf-8") as f:
                    json.dump(data, f, indent=2)
                return
            except Exception:
                continue


# ---------------------------------------------------------------------------
# AI command interpreter (rule based, applied to the config)
# ---------------------------------------------------------------------------

_AI_CAPABILITIES = [
    "Make all headings larger / smaller (or by N px)",
    "Make body text larger / smaller (or by N%)",
    "Create a 4K version",
    "Center all icons",
    "Fix text overflow",
    "Increase / decrease line spacing",
    "Generate a cleaner table layout",
    "Apply the same paytable layout to all matching pages",
    "Match Photoshop heading style (requires Photoshop + selected layer)",
]

_AI_INTENTS = [
    ("heading_larger", re.compile(r"(heading|title).*(larger|bigger|increase|big|up)", re.I)),
    ("heading_smaller", re.compile(r"(heading|title).*(smaller|decrease|reduce|small|down)", re.I)),
    ("body_larger", re.compile(r"(body|text|body text).*(larger|bigger|increase|big)", re.I)),
    ("body_smaller", re.compile(r"(body|text|body text).*(smaller|decrease|reduce|small)", re.I)),
    ("4k", re.compile(r"4k|4 k|uhd", re.I)),
    ("center_icons", re.compile(r"(center|centre).*icon|icon.*(center|centre)", re.I)),
    ("overflow", re.compile(r"overflow|fit|truncat", re.I)),
    ("line_spacing_up", re.compile(r"(line spacing|spacing|air).*(increase|more|larger|up)", re.I)),
    ("line_spacing_down", re.compile(r"(line spacing|spacing).*(decrease|less|smaller|down)", re.I)),
    ("table_layout", re.compile(r"(table|layout).*(cleaner|better|neat|generate)", re.I)),
    ("photoshop_style", re.compile(r"photoshop.*(style|heading)|match.*photoshop", re.I)),
    ("increase_by", re.compile(r"(heading|title|body|text).*(\d+)\s*px", re.I)),
    ("reduce_pct", re.compile(r"(body|text).*(\d+)%", re.I)),
]

_INTENT_DESCRIPTIONS = {
    "heading_larger": "Heading size increased.",
    "heading_smaller": "Heading size decreased.",
    "body_larger": "Body text size increased.",
    "body_smaller": "Body text size decreased.",
    "4k": "Canvas upgraded to 4K UHD.",
    "center_icons": "Icons centered and aligned.",
    "overflow": "Text overflow fix applied: body 5% smaller, looser line spacing.",
    "line_spacing_up": "Line spacing increased.",
    "line_spacing_down": "Line spacing decreased.",
    "table_layout": "Cleaner table layout applied.",
    "photoshop_style": "Photoshop layer style capture requested.",
    "increase_by": "Font size adjusted.",
    "reduce_pct": "Body text reduced by percentage.",
}


def interpret_ai_command(config: dict, command: str) -> dict:
    """Rule-based assistant: apply simple commands to the config."""
    cfg = dict(config)
    changes = {}
    message = ""
    low = command.lower()

    def bump(key, delta):
        cfg[key] = max(6, round((cfg.get(key) or 0) + delta))
        changes[key] = cfg[key]

    def scale(key, factor):
        cfg[key] = max(6, round((cfg.get(key) or 0) * factor))
        changes[key] = cfg[key]

    matched = set()
    for name, rx in _AI_INTENTS:
        if rx.search(command):
            matched.add(name)

    if "increase_by" in matched:
        m = re.search(r"(\d+)\s*px", low)
        if m:
            delta = int(m.group(1))
            if "heading" in low:
                bump("h_size", delta)
            elif "body" in low or "text" in low:
                bump("b_size", delta)
        matched.discard("heading_larger")
        matched.discard("heading_smaller")
        matched.discard("body_larger")
        matched.discard("body_smaller")
    elif "reduce_pct" in matched:
        m = re.search(r"(\d+)%", low)
        if m:
            pct = int(m.group(1))
            if "body" in low or "text" in low:
                scale("b_size", 1 - pct / 100.0)
        matched.discard("heading_larger")
        matched.discard("heading_smaller")
        matched.discard("body_larger")
        matched.discard("body_smaller")

    if "heading_larger" in matched:
        bump("h_size", 10)
    if "heading_smaller" in matched:
        bump("h_size", -8)
    if "body_larger" in matched:
        bump("b_size", 4)
    if "body_smaller" in matched:
        bump("b_size", -3)
    if "4k" in matched:
        cfg["c_width"], cfg["c_height"] = 3840, 2160
        cfg["canvas_preset"] = "4K UHD"
        changes["c_width"], changes["c_height"] = 3840, 2160
        changes["canvas_preset"] = "4K UHD"
    if "center_icons" in matched:
        cfg["alignment"] = "center"
        cfg["icon_y_offset"] = 0
        changes["alignment"] = "center"
        changes["icon_y_offset"] = 0
    if "overflow" in matched:
        scale("b_size", 0.95)
        cfg["line_spacing"] = round((cfg.get("line_spacing") or 1.1) + 0.05, 2)
        changes["line_spacing"] = cfg["line_spacing"]
    if "line_spacing_up" in matched:
        cfg["line_spacing"] = round((cfg.get("line_spacing") or 1.1) + 0.1, 2)
        changes["line_spacing"] = cfg["line_spacing"]
    if "line_spacing_down" in matched:
        cfg["line_spacing"] = max(0.8, round((cfg.get("line_spacing") or 1.1) - 0.1, 2))
        changes["line_spacing"] = cfg["line_spacing"]
    if "table_layout" in matched:
        cfg["table_style"] = {
            "border_width": 2,
            "header_bg_rgb": [20, 20, 30],
            "row1_bg_rgb": [35, 35, 50],
            "row2_bg_rgb": [28, 28, 42],
            "cell_padding_x": 10,
            "cell_padding_y": 5,
        }
        changes["table_style"] = "cleaner table defaults applied"

    if matched:
        primary = next((name for name, _ in _AI_INTENTS if name in matched), sorted(matched)[0])
        message = _INTENT_DESCRIPTIONS.get(primary, "Command applied to your project.")
        message += " Changes are shown in the properties panel; press Build to render."
    else:
        message = (
            "I can help with: " + "; ".join(_AI_CAPABILITIES[:6])
            + ". Describe what you want in your own words."
        )
    return {"message": message, "changes": changes, "config": cfg}


# ---------------------------------------------------------------------------
# build dispatch (lazy imports; run inside a worker thread)
# ---------------------------------------------------------------------------

_BUILD_EVENT_LABELS = {
    "build_start": "Build started",
    "photoshop_connected": "Connected to Photoshop",
    "excel_loaded": "Excel data loaded",
    "preimport_icons": "Pre-importing icons",
    "background_applied": "Background applied",
    "page_started": "Rendering page",
    "page_done": "Page rendered",
    "tables_started": "Rendering tables",
    "tables_done": "Tables rendered",
    "paytable_started": "Building paytable",
    "paytable_done": "Paytable built",
    "psd_saved": "PSD saved",
    "png_saved": "PNG saved",
    "build_done": "Build complete",
    "cancelled": "Cancelled",
    "error": "Error",
}


def _build_kwargs(config: dict) -> dict:
    alignment = _normalize_alignment_settings(config.get("alignment_settings"))
    legacy_align = config.get("alignment") or "center"
    if not config.get("alignment_settings"):
        for key in ("heading", "body", "table", "bottom", "paytable_notes"):
            if key not in alignment["global"] or not alignment["global"].get(key):
                alignment["global"][key] = legacy_align

    dynamic_settings = _merged_dynamic_settings(config)

    # UI "Row spacing" is a top-level config key; the engines read it from
    # dynamic_settings/dynamic_runtime. Only inject when the user actually set
    # it (0 is meaningful: rows touch their own bounds, like the PSD engine).
    if config.get("line_gap") not in (None, ""):
        dynamic_settings = dict(dynamic_settings)
        dynamic_settings["line_gap"] = _as_int(config.get("line_gap"), 0)

    # Smart Paytable session settings ride inside dynamic_settings so BOTH
    # engines (png_builder and build_engine) see them without signature
    # changes. Sheets stay historical unless paytable_auto is explicitly set.
    if isinstance(config.get("paytable_auto"), dict):
        dynamic_settings = dict(dynamic_settings)
        dynamic_settings["paytable_auto"] = dict(config["paytable_auto"])

    def _role_style(role):
        if not isinstance(dynamic_settings, dict):
            return None
        library = dynamic_settings.get("layer_style_library") or {}
        assignments = dynamic_settings.get("style_assignments") or {}
        name = str(assignments.get(role) or "").strip()
        if not name or name.casefold() in {"", "none", "no style", "__none__"}:
            return None
        return library.get(name) or None

    merged_heading_style = _role_style("Heading text")
    merged_body_style = _role_style("Body text")
    merged_subheading_style = _role_style("Subheading text")
    if isinstance(dynamic_settings, dict):
        if merged_subheading_style:
            dynamic_settings["subheading_style"] = merged_subheading_style
        hrgb = _hex_to_rgb(config.get("h_rgb"))
        dynamic_settings["title_rgb"] = hrgb
        dynamic_settings["heading_rgb"] = hrgb

    return {
        "excel_path": config.get("excel_path", ""),
        "icon_folder": config.get("icon_folder", ""),
        "bg_path": config.get("bg_path", ""),
        "c_width": config.get("c_width", 1920),
        "c_height": config.get("c_height", 1080),
        "c_resolution": config.get("c_resolution", 72),
        "max_col_limit": config.get("max_col_limit", 12),
        "h_font": _font_request(config.get("h_font", "ArialMT"), config.get("h_font_style", "regular")),
        "h_size": config.get("h_size", 60),
        "h_icon_h": config.get("h_icon_h", 40),
        "h_rgb": _hex_to_rgb(config.get("h_rgb")),
        "b_font": _font_request(config.get("b_font", "ArialMT"), config.get("b_font_style", "regular")),
        "b_size": config.get("b_size", 30),
        "b_icon_h": config.get("b_icon_h", 28),
        "b_rgb": _hex_to_rgb(config.get("b_rgb")),
        "margin_x": config.get("margin_x", 80),
        "line_spacing": config.get("line_spacing", 1.1),
        "para_spacing": config.get("para_spacing", 14),
        "gap_px": config.get("gap_px", 20),
        "heading_icon_gap": config.get("heading_icon_gap", 15),
        "heading_icon_gap_left": config.get("heading_icon_gap_left", config.get("heading_icon_gap", 15)),
        "heading_icon_gap_right": config.get("heading_icon_gap_right", config.get("heading_icon_gap", 15)),
        "icon_gap_left": config.get("icon_gap_left", 15),
        "icon_gap_right": config.get("icon_gap_right", 15),
        "icon_y_offset": config.get("icon_y_offset", 0),
        "bg_mode": _bg_place.spec(config),        # cover / fit / … / "fit_width:bottom" / "place:x,y,w,h"
        "bg_color": _bg_place.behind(config),     # behind a picture: transparent unless "Colour behind" is on
        "enable_tables": config.get("enable_tables", True),
        "keyword_colors": config.get("keyword_colors") or None,
        "heading_style": merged_heading_style or config.get("heading_style") or None,
        "body_style": merged_body_style or config.get("body_style") or None,
        "icon_style": config.get("icon_style") or None,
        "table_style": _normalize_table_style(config.get("table_style")),
        "dynamic_settings": dynamic_settings,
        "output_dir": config.get("output_dir") or None,
        "output_name": config.get("output_name") or "",
        "selected_sheets": None if config.get("render_all_pages") else (config.get("selected_sheets") or None),
        "icon_mappings": config.get("icon_mappings") or None,
        "icon_size_overrides": config.get("icon_size_overrides") or None,
        "overwrite_existing": config.get("overwrite_existing", False),
        "performance_mode": config.get("performance_mode", False),
        "prev_excel_path": config.get("prev_excel_path") or None,
        "prev_psd_path": config.get("prev_psd_path") or None,
        "heading_top_margin": config.get("heading_top_margin", 150),
        "continued_gap": config.get("continued_gap", 15),
        "heading_to_body_gap": config.get("heading_to_body_gap", 40),
        "bottom_margin": config.get("bottom_margin", 50),
        "inner_canvas_width": config.get("inner_canvas_width", 0),
        "body_icons_use_original_size": config.get("body_icons_use_original_size", False),
        "alignment_settings": alignment,
        "page_overrides": config.get("page_overrides") or None,
        "show_completion_dialogs": False,
    }


def _psd_backup_copy(config: dict):
    """Copy a safe backup of the previous PSD before an update-mode build."""
    if not config.get("safe_backup"):
        return None
    prev_psd = config.get("prev_psd_path") or ""
    if not prev_psd or not os.path.isfile(prev_psd):
        return None
    try:
        from . import ps_actions

        result = ps_actions.copy_backup(prev_psd, config.get("safe_backup_folder") or "")
        return result.get("path") or result.get("error") or ""
    except Exception as exc:
        return f"backup failed: {exc}"


def _with_auto_paytables(config: dict, cb=None) -> dict:
    """Paytable sheets without a template get the auto layout for this build.

    Every paytable is custom, so nothing is guessed silently into a fixed
    design: the sheet's own symbols/pays/rules are laid out with the "auto"
    layout and auto-mapped (the same path as the mapper's Auto button). The
    mapped JSON is written next to the output so the artist can open it in
    the Paytable Mapper / slot editor, adjust it and save — a saved template
    is then used instead. Returns a build-only copy of `config`; the session
    is not changed. Set ``paytable_default_auto`` to False to opt out.
    """
    if config.get("paytable_default_auto", True) is False:
        return config
    excel_path = str(config.get("excel_path") or "").strip()
    if not excel_path or not os.path.isfile(excel_path):
        return config
    try:
        from openpyxl import load_workbook
        wb = load_workbook(excel_path, read_only=True)
        sheet_names = list(wb.sheetnames)
        wb.close()
    except Exception:
        return config
    if not config.get("render_all_pages") and config.get("selected_sheets"):
        wanted = {str(s) for s in config.get("selected_sheets") or []}
        sheet_names = [s for s in sheet_names if s in wanted]

    ds = _merged_dynamic_settings(config)
    card_tpl = ds.get("paytable_card_template")
    if isinstance(card_tpl, dict) and card_tpl.get("kind") == "card_template":
        cards = {}
        for sheet in sheet_names:
            if _sheet_type(sheet) != "paytable":
                continue
            try:
                result, _ = auto_map_page(json.loads(json.dumps(config)), sheet, "", {"card_template": card_tpl})
            except Exception as exc:
                result = {"ok": False, "error": str(exc)}
            if result.get("ok") and result.get("path"):
                cards[sheet] = result["path"]
            elif callable(cb):
                cb({"event": "note", "message": f"[PAYTABLE] Card template on '{sheet}' failed: {result.get('error')}"})
        if cards:
            if callable(cb):
                cb({"event": "note", "message": (
                    f"[PAYTABLE] '{card_tpl.get('name') or 'Card template'}' laid out {len(cards)} paytable page(s) "
                    f"from their own Excel data: {', '.join(cards)}")})
            new_cfg = dict(config)
            new_ds = dict(config.get("dynamic_settings") or {})
            new_ds["enabled"] = True
            new_ds["template_json"] = ""                 # one mapped JSON per sheet, not one for all
            new_ds["template_json_map"] = dict(new_ds.get("template_json_map") or {}, **cards)
            new_cfg["dynamic_settings"] = new_ds
            return new_cfg
    template_map = dict(ds.get("template_json_map") or {})
    default_json = str(ds.get("template_json") or "")
    dyn_sheet = str(ds.get("sheet_name") or "").casefold()
    added = {}
    for sheet in sheet_names:
        if _sheet_type(sheet) != "paytable":
            continue
        assigned = template_map.get(sheet) or (default_json if sheet.casefold() == dyn_sheet else "")
        if assigned and os.path.isfile(str(assigned)):
            continue
        try:
            result, _ = auto_map_page(json.loads(json.dumps(config)), sheet, "")
        except Exception as exc:
            result = {"ok": False, "error": str(exc)}
        if result.get("ok") and result.get("path"):
            added[sheet] = result["path"]
            if callable(cb):
                cb({"event": "note", "message": (
                    f"[PAYTABLE] '{sheet}' had no template: auto layout created from the sheet "
                    f"({result.get('mapped', 0)} slots mapped). Open it in the Paytable Mapper to adjust: "
                    f"{result['path']}")})
        elif callable(cb):
            cb({"event": "note", "message": f"[PAYTABLE] Auto layout for '{sheet}' failed: {result.get('error')}"})
    if not added:
        return config
    new_cfg = dict(config)
    new_ds = dict(config.get("dynamic_settings") or {})
    new_ds["enabled"] = True
    new_ds["template_json_map"] = dict(new_ds.get("template_json_map") or {}, **added)
    new_cfg["dynamic_settings"] = new_ds
    return new_cfg


def run_build(config: dict, mode: str, progress_callback=None, cancel_event=None) -> dict:
    """mode: 'psd' | 'png' | 'both'. Lazy-imports the real engines.

    Returns {"psd_path": str?, "png_dir": str?} with the produced outputs
    (empty dict when nothing was written)."""
    from ps_autotypesetter import build_engine
    from ps_autotypesetter import png_builder

    def cb(data):
        if callable(progress_callback):
            progress_callback(data)

    config = _with_auto_paytables(config, cb)
    if config.get("active_game"):
        # depot games: Help Screen/Working + Static are created when missing, and a PSD an
        # artist edited (or that is read-only in Perforce) is never overwritten (games.py)
        try:
            from .. import games as _games

            for made in _games.ensure_output_folders(config):
                cb({"event": "note", "message": f"[FOLDERS] Created {made}"})
            if mode in ("psd", "both"):
                protect_note = _games.protect_artist_psd(config)
                if protect_note:
                    cb({"event": "note", "message": f"[SAFE] {protect_note}"})
        except Exception as exc:
            cb({"event": "note", "message": f"[FOLDERS] {exc}"})
    base = _build_kwargs(config)
    outputs: dict = {}

    legacy_com = bool(config.get("legacy_photoshop_engine"))

    if mode in ("psd", "both"):
        cb({"event": "build_start"})
        backup = _psd_backup_copy(config)
        if backup:
            cb({"event": "note", "message": f"Safe backup: {backup}"})

        excel_path = str(config.get("excel_path") or "").strip()
        cb({"event": "note", "message": f"[SOURCE] Excel source: {excel_path or '(none)'}"})

        from .. import project_package as _pp

        # Update builds diff against the saved baseline when no explicit Old
        # Excel was given; legacy PSDs fall back to the PSD manifest diff.
        baseline_info = None
        if config.get("update_mode"):
            if not base.get("prev_excel_path"):
                baseline_info = _pp.load_baseline_info(base.get("prev_psd_path") or "")
                if baseline_info.get("exists"):
                    base["prev_excel_path"] = baseline_info.get("baseline")
                    cb({"event": "note", "message": (
                        f"[BASELINE] Using saved baseline (V{baseline_info.get('version_number')}) "
                        "as the diff source — no Old Excel needed."
                    )})
                else:
                    cb({"event": "note", "message": (
                        "[BASELINE] This PSD does not have a saved Excel baseline — "
                        "falling back to the PSD manifest diff."
                    )})

        # Fast path: current workbook is byte-identical to the baseline. Skip
        # the Photoshop round-trip entirely — there is nothing to update.
        fast_path_skip = False
        if config.get("update_mode") and base.get("prev_psd_path"):
            bi = _pp.load_baseline_info(base["prev_psd_path"])
            if bi.get("exists") and excel_path and os.path.isfile(excel_path):
                new_hash = _pp.file_sha256(excel_path)
                if new_hash and new_hash == bi.get("file_hash"):
                    fast_path_skip = True
                    cb({"event": "note", "message": f"[HASH] {new_hash}"})
                    cb({"event": "note", "message": (
                        "[UPDATE] No changes detected in source Excel — nothing to update."
                    )})

        if fast_path_skip:
            # Tell the UI explicitly: no PSD was written because it is already current.
            outputs["skipped"] = "unchanged"
            outputs["up_to_date_psd"] = str(base.get("prev_psd_path") or "")
        else:
            if legacy_com:
                from . import ps_actions
                ps_actions.ensure_com_initialized()
                cb({"event": "note", "message": "[ENGINE] Legacy Photoshop (COM) engine"})
            else:
                cb({"event": "note", "message": "[ENGINE] Headless PSD writer — no Photoshop needed"})
            # update_save_mode: "overwrite" writes back into the Old PSD in place;
            # "new_copy" keeps the Old PSD untouched and writes a new file (the
            # output_name/output_dir below decide where it lands). Only update
            # builds honor this; regular builds keep the user's overwrite toggle.
            if config.get("update_mode"):
                save_mode = str(config.get("update_save_mode") or "overwrite").strip()
                # "overwrite" writes back into the Old PSD in place — EXCEPT
                # when the user typed an output name (Project → PSD name):
                # the build must land with that exact name.
                base["overwrite_existing"] = bool(save_mode == "overwrite") and not str(config.get("output_name") or "").strip()
            else:
                base["overwrite_existing"] = bool(config.get("overwrite_existing"))
            if legacy_com:
                build_fn = build_engine.execute_build
            else:
                from ..psd_writer import build as psd_build
                build_fn = psd_build.build_psd
            extra = {} if legacy_com else {"project_config": config}   # project stored inside the PSD
            save_path = build_fn(
                **base,
                output_format=str(config.get("output_format") or "PSD").strip().upper(),
                progress_callback=cb,
                cancel_event=cancel_event,
                **extra,
            )
            if save_path:
                outputs["psd_path"] = os.path.abspath(str(save_path))
                cb({"event": "note", "message": f"[SAVE] PSD saved: {outputs['psd_path']}"})
                if config.get("active_game"):
                    try:
                        from .. import games

                        entry = games.record_version(config, outputs["psd_path"],
                                                     note="update" if config.get("update_mode") else "build")
                        if entry:
                            outputs["version"] = entry["n"]
                            cb({"event": "note", "message": f"[VERSION] Saved as version {entry['n']} of this market."})
                    except Exception as exc:
                        cb({"event": "note", "message": f"[VERSION] Could not record the version: {exc}"})
                if not legacy_com:
                    from ..psd_writer import photoshop_finish as _psf
                    from ..psd_writer import txt2 as _txt2

                    _mode = _psf.mode_of(config)
                    if _txt2.has_block(outputs["psd_path"]):
                        # the writer already produced Photoshop's text block: the layers open
                        # as normal, editable type with no warning — no Photoshop step needed
                        outputs["text_finished"] = True
                    elif _psf.available(_mode):
                        _msg = _psf.finish(outputs["psd_path"], note=lambda m: cb({"event": "note", "message": m}))
                        outputs["text_finished"] = _msg.startswith("[PSD] Photoshop finished")
                        cb({"event": "note", "message": _msg})
                    elif _mode != "off":
                        outputs["text_finished"] = False
                    # Not finished by Photoshop: leave a script beside the PSD so whoever
                    # receives it can fix the text layers in their own Photoshop.
                    if outputs.get("text_finished") is False:
                        try:
                            _js = _psf.write_fix_script(outputs["psd_path"])
                            outputs["fix_script"] = _js
                            cb({"event": "note", "message": (
                                f"[PSD] Wrote '{os.path.basename(_js)}' next to the PSD: anyone with Photoshop can run it "
                                "(File > Scripts > Browse…) to update the text layers without this tool.")})
                        except OSError as exc:
                            cb({"event": "note", "message": f"[PSD] Could not write the Fix text layers script: {exc}"})
                    elif outputs.get("text_finished"):
                        _psf.remove_fix_script(outputs["psd_path"])
                        cb({"event": "note", "message": (
                            "[PSD] Photoshop isn't installed here, so the text layers can't be finished "
                            "automatically (the text itself is already correct).")})

        # Baseline lifecycle: create on first build; advance ONLY after a
        # successful PSD save (update builds force it; anything else keeps the
        # existing baseline untouched).
        write_links = bool(config.get("write_links_folder"))
        if outputs.get("psd_path") and write_links:
            # optional _Links/source baseline (the PSD already carries its own Excel snapshot)
            from .. import project_package as _pp
            baseline_res = _pp.commit_baseline(
                outputs["psd_path"], excel_path,
                int(config.get("max_col_limit") or 12),
                force=bool(config.get("update_mode")),
            )
            if baseline_res.get("ok"):
                action = baseline_res.get("action")
                if action in ("created", "advanced"):
                    cb({"event": "note", "message": (
                        f"[BASELINE] Excel baseline {action} (V{baseline_res.get('version_number')}) "
                        f"-> {os.path.basename(baseline_res.get('baseline') or '')}"
                    )})
                else:
                    cb({"event": "note", "message": (
                        f"[BASELINE] Existing Excel baseline preserved (V{baseline_res.get('version_number')})."
                    )})
            elif baseline_res.get("action") == "error":
                cb({"event": "note", "message": f"[BASELINE] {baseline_res.get('error')}"})
    if mode in ("png", "both"):
        png_dir = png_builder.build_pngs_only(
            **base,
            output_format="png",
            png_output_dir=str(config.get("png_output_dir") or "").strip() or None,
            png_suffix=(config.get("png_suffix") or "").strip() or None,
            progress_callback=cb,
            cancel_event=cancel_event,
        )
        if png_dir:
            outputs["png_dir"] = os.path.abspath(str(png_dir))

    # Project package: written beside the PSD whenever a PSD is saved; an
    # existing package is refreshed even for PNG-only builds so the links
    # tree always matches the latest settings.
    try:
        from .. import project_package as pp
    except Exception:
        pp = None
    if pp is not None and not config.get("write_links_folder"):
        pp = None                                  # project lives inside the PSD (psd_memory); _Links is opt-in
        if outputs.get("psd_path"):
            cb({"event": "note", "message": "[PROJECT] Project saved inside the PSD (settings, templates, Excel, layer links)."})
    if pp is not None:
        if outputs.get("psd_path"):
            pkg = pp.write_project_package(config, outputs["psd_path"])
        else:
            prev_psd = str(config.get("prev_psd_path") or "").strip()
            if prev_psd and pp.detect_for_psd(prev_psd):
                pkg = pp.write_project_package(config, prev_psd)
            else:
                pkg = None
        if pkg:
            if pkg.get("ok"):
                cb({"event": "note", "message": f"[PROJECT] Package saved: {os.path.basename(pkg['manifest'])}"})
            else:
                cb({"event": "note", "message": f"[PROJECT] {pkg.get('error') or 'Package warning.'}"})

    cb({"event": "build_done"})
    return outputs


# ---------------------------------------------------------------------------
# table mapper (mapped @table JSON workflow)
# ---------------------------------------------------------------------------

def _auto_role_for_kind_and_slot(kind, slot_name):
    kind = str(kind or "").casefold()
    slot = str(slot_name or "").casefold()
    if kind == "dedicated_icon":
        return "dedicated_icon"
    if kind == "heading" or any(word in slot for word in ("header", "heading", "title")):
        return "heading"
    if kind in ("flow", "text"):
        return "text_icon"
    if kind == "background" or "box" in slot:
        return "slot_style"
    return "normal_text"


def automap_table_slots(template, excel_path, sheet_name):
    """Map every cell-ref slot (B7, table.B7, D8:J22...) to its Excel content.

    Mirrors the desktop mapper: bare refs, ``@table.X`` and ``<tableName>.X``
    prefixed slots are all resolved. Slots that are bounds-like or have no
    cell reference are skipped (stay unmapped).

    Returns ``{"mappings": [...], "unmapped": [...]}`` in the mapped-JSON schema;
    ``unmapped`` lists the non-bounds-like slot names that do not resolve to an
    Excel cell reference.
    """
    from ps_autotypesetter.table_mapping import (
        parse_table_slot_ref,
        _slot_name_is_bounds_like,
    )

    slots = (template or {}).get("slots") or {}
    if not isinstance(slots, dict) or not excel_path or not sheet_name:
        return {"mappings": [], "unmapped": []}

    prefix_candidates = ["@table.", "@slot."]
    base_name = str((template or {}).get("name") or (template or {}).get("template_id") or "").strip()
    if base_name:
        prefix_candidates.append(f"{base_name}.")
    for table_key in ((template or {}).get("table_templates") or {}):
        prefix_candidates.append(f"{table_key}.")
    prefix_candidates = sorted(set(prefix_candidates), key=len, reverse=True)

    workbook = None
    try:
        workbook = load_workbook(excel_path, data_only=True, read_only=True)
        if sheet_name not in workbook.sheetnames:
            return []
        ws = workbook[sheet_name]
        try:
            max_row = ws.max_row if ws.max_row is not None else 2 ** 31
            max_col = ws.max_column if ws.max_column is not None else 2 ** 31
        except Exception:
            max_row, max_col = 2 ** 31, 2 ** 31

        mappings = []
        unmapped = []
        for slot, box in slots.items():
            if _slot_name_is_bounds_like(slot):
                continue
            ref = parse_table_slot_ref(slot)
            if not ref:
                for prefix in prefix_candidates:
                    if str(slot).casefold().startswith(prefix.casefold()):
                        ref = parse_table_slot_ref(str(slot)[len(prefix):])
                        if ref:
                            break
            if not ref:
                unmapped.append(slot)
                continue
            col1, row1, col2, row2 = ref
            if row1 < 1 or row1 > max_row:
                unmapped.append(slot)
                continue
            col_idx = 0
            for ch in col1.upper():
                col_idx = col_idx * 26 + (ord(ch) - 64)
            if col_idx < 1 or col_idx > max_col:
                unmapped.append(slot)
                continue
            ref_str = f"{col1}{row1}" if col1 == col2 and row1 == row2 else f"{col1}{row1}:{col2}{row2}"
            cell_val = str(ws[f"{col1}{row1}"].value or "")
            kind = "flow"
            if cell_val.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.bmp', '.svg')):
                kind = "dedicated_icon"
            mappings.append({
                "kind": kind,
                "source": ref_str,
                "slot": slot,
                "role": _auto_role_for_kind_and_slot(kind, slot),
                "font_size": 30,
                "icon_height": 48,
                "color": "#FFFFFF",
                "alignment": "center",
                "vertical_align": "center",
                "padding": [0, 0, 0, 0],
            })
        return {"mappings": mappings, "unmapped": unmapped}
    except Exception:
        return {"mappings": [], "unmapped": []}
    finally:
        if workbook is not None:
            try:
                workbook.close()
            except Exception:
                pass

_PAYTABLE_CELL_REF_RE = re.compile(r"^([A-Za-z]{1,3})(\d+)(?::([A-Za-z]{1,3})(\d+))?$")

_PAYTABLE_BOUNDS_NAMES = {"bounds", "bound", "container", "tablebox", "bg", "background", "textbg", "textbackground"}

_PAYTABLE_TEXT_SLOT_NAMES = {
    "title", "count", "payout", "payouts", "notes", "text", "note",
    "label", "description", "subtitle", "heading",
}

# Title-like text slots: these resolve the sheet's best title cell (the
# cell that most looks like the page title) instead of the plain text pool.
_PAYTABLE_TITLE_SLOT_NAMES = {"title", "subtitle", "heading"}

# Wild-feature title slots always render "WILD" (renderer fallback) — the
# automap must not steal a text cell for them.
_PAYTABLE_WILD_TITLE_SLOTS = {"wild.title", "wild.text", "feature.title", "special.title"}

# Cells that are clearly artist/production notes, never real page text.
_PAYTABLE_META_HINTS = (
    "note <bo>", "<initial mod", "initial mod", "brand per agreement",
    "do not need", "don't need", "dont need",
)

# Text slots read the main text area only — far-right columns are almost
# always artist notes / brand comments (mirrors the paytable parser).
_PAYTABLE_MAIN_TEXT_COL_LIMIT = 12

_PAYTABLE_NUMBER_ALIASES = {
    "one": "1", "two": "2", "three": "3", "four": "4", "five": "5",
    "six": "6", "seven": "7", "eight": "8", "nine": "9", "ten": "10",
}

# Canonical symbol labels: Excel anchor cell text ("<A>", "K", "10"...) maps
# to the canonical slot base name ("ace", "king", "ten"...). Keys are already
# normalized (lowercase, no spaces); "Pic 1" -> "pic1" is handled generically
# by _paytable_norm_name.
_PAYTABLE_SYMBOL_CANON = {
    "a": "ace", "ace": "ace",
    "k": "king", "king": "king",
    "q": "queen", "queen": "queen",
    "j": "jack", "jack": "jack",
    "10": "ten", "ten": "ten",
}

# Numeric cell values that can name a low symbol card (the "10" card). Every
# payout row contains such numbers too, so numeric anchors are only accepted
# when the cell is the row's LEFTMOST numeric cell — a symbol label; payout
# values always sit to the right of the label.
_PAYTABLE_LOW_SYMBOL_NUMBERS = {"2", "3", "4", "5", "6", "7", "8", "9", "10"}


def _paytable_alias_keys(key):
    """Normalized key plus its number-word aliases ("ten" -> {"ten", "10"})."""
    out = {key}
    alias = _PAYTABLE_NUMBER_ALIASES.get(key)
    if alias:
        out.add(alias)
    return out


def _paytable_symbol_variants(sym):
    """Anchor/token lookup keys for a symbol name: exact key first, then
    number-word aliases ("ten" -> "10"), then — for word-like symbols that
    don't carry a number (ace/king/queen/ten...) — the first letter, so an
    ``<A>`` anchor cell can resolve an ``ace`` slot. ``picN``/``wild`` names
    only match exactly (never their first letter)."""
    keys = []
    seen = set()
    for key in sorted(_paytable_alias_keys(sym), key=len, reverse=True):
        if key not in seen:
            seen.add(key)
            keys.append(key)
    if not re.fullmatch(r"(?:pic|wild)\d*", sym) and len(sym) > 1:
        keys.append(sym[0])
    return keys


def _paytable_norm_name(value):
    """Normalize a slot name for matching: strip the @slot./@table. prefix,
    drop whitespace and fold case ("@slot.Pic 1" -> "pic1")."""
    name = str(value or "").strip()
    for pfx in ("@slot.", "@table."):
        if name.casefold().startswith(pfx.casefold()):
            name = name[len(pfx):]
            break
    return re.sub(r"\s+", "", name).casefold()


def _paytable_cell_ref(ref):
    match = _PAYTABLE_CELL_REF_RE.fullmatch(str(ref or "").strip())
    if not match:
        return None
    col_letter = match.group(1).upper()
    row = int(match.group(2))
    col_idx = 0
    for ch in col_letter:
        col_idx = col_idx * 26 + (ord(ch) - 64)
    return col_letter, row, col_idx


def _paytable_numeric(value):
    if value is None:
        return False
    if isinstance(value, (int, float)):
        return True
    text = str(value).strip()
    if not text:
        return False
    return bool(re.fullmatch(r"[\d\s,.+-]+", text))


def _paytable_refs_text(source, vals):
    """Resolve comma-joined single-cell refs ("F14,F15,F16,F17") to the
    literal newline-joined values ("5\\n4\\n3\\n2") so pay/value slots carry
    their resolved text and render without a second Excel pass."""
    lines = []
    for part in str(source or "").split(","):
        match = _PAYTABLE_CELL_REF_RE.fullmatch(str(part).strip())
        if not match or match.group(3):
            continue
        row = int(match.group(2))
        col_idx = 0
        for ch in match.group(1).upper():
            col_idx = col_idx * 26 + (ord(ch) - 64)
        value = vals.get((row, col_idx))
        if value is None:
            continue
        lines.append(str(value).strip())
    return "\n".join(lines)


def _slot_valign(box, default="top"):
    """Vertical-align hint for a pay/value spec.

    Generated auto-layout slot boxes may carry a ``vertical_align`` hint (the
    layout generator stamps ``center`` when pay/value sit beside the icon and
    ``top`` when they sit below it). Honor that hint when present; otherwise
    fall back to ``default`` — which keeps every hand-authored template (plain
    ``{x,y,w,h}`` boxes: SimplePaytable, classic, imported PSDs) rendering
    pay/value top-aligned exactly as before."""
    if isinstance(box, dict):
        v = box.get("vertical_align")
        if isinstance(v, str) and v.strip():
            return v.strip().casefold()
    return default


def automap_paytable_slots(template, excel_path, sheet_name):
    """Smart auto-map for the Paytable mapper.

    Every ``@slot.*`` (or bare) slot name is classified and mapped:
      * cell refs (``@slot.E6``, ``@slot.B7:C9``)        -> mode "excel"
      * symbol names (``@slot.pic1``, ``@slot.Ace``, ``@slot.wild``) -> mode
        "icon" from the slot name itself: ``@slot.whatever`` maps to the
        ``<whatever>`` icon (case-insensitive file lookup at render time); no
        Excel token cell is needed. pay/value suffixes are mapped by anchor
      * ``payN`` / ``valueN`` (and ``wildpay``/``wildvalue``) -> the pay /
        value cells for that symbol's row-block: the symbol's anchor cell
        ("<PIC1>", "PIC2", "ACE" — with or without < >) is located anywhere
        in the sheet, the first numeric column right of it is the pay column,
        the next numeric column right is the value column, and the contiguous
        numeric run closest to the anchor row is the block (top is walked
        upward while numeric, bottom downward). Headers ("Pays"/"Values") and
        token-cell lookups remain as fallbacks.
      * text-ish names (``text``/``notes``/``count``/...) -> mode "excel"
        against a plain-text cell: every text slot takes the next unused
        non-numeric, non-anchor cell in scan order. Title-like slots
        (``title``/``subtitle``/``heading``) stay unmapped — the renderer
        always fills the page heading into ``.title`` itself — and
        wild-feature titles (``wild.title`` / ``feature.title`` ...) stay
        unmapped too (they render "WILD").
    Returns ``{"mappings": [...], "unmapped": [...], "pays_column": "",
    "values_column": "", "symbols": [...]}`` in the mapped-paytable schema.
    """
    if not (template or {}).get("slots") or not excel_path or not sheet_name:
        return {"mappings": [], "unmapped": [], "pays_column": "", "values_column": "", "sheet_dims": {"rows": 0, "cols": 0}, "symbols": []}
    meta = (template or {}).get("mapper_meta") or {}
    if meta.get("layout") == "cards":
        # card studio: the mapping depends on the slot names and row counts, not on where the cards
        # sit, so dragging things around reuses it (per Excel file version)
        import copy

        try:
            st = os.stat(excel_path)
            key = (os.path.normcase(os.path.abspath(excel_path)), st.st_size, st.st_mtime_ns, sheet_name,
                   tuple(template["slots"]), repr(template.get("row_counts")), repr(meta.get("row_counts")),
                   meta.get("top_count"), meta.get("lower_count"))
        except (OSError, TypeError):
            key = None
        if key is not None:
            if key not in _AUTOMAP_CACHE:
                if len(_AUTOMAP_CACHE) > 32:
                    _AUTOMAP_CACHE.clear()
                _AUTOMAP_CACHE[key] = _automap_paytable_slots_file(template, excel_path, sheet_name)
            return copy.deepcopy(_AUTOMAP_CACHE[key])
    return _automap_paytable_slots_file(template, excel_path, sheet_name)


_AUTOMAP_CACHE = {}


def _automap_paytable_slots_file(template, excel_path, sheet_name):
    workbook = None
    try:
        workbook = load_workbook(excel_path, data_only=True, read_only=True)
        if sheet_name not in workbook.sheetnames:
            return {"mappings": [], "unmapped": [], "pays_column": "", "values_column": "", "sheet_dims": {"rows": 0, "cols": 0}, "symbols": []}
        ws = workbook[sheet_name]
        return automap_paytable_slots_ws(ws, template)
    except Exception:
        return {"mappings": [], "unmapped": [], "pays_column": "", "values_column": "", "symbols": []}
    finally:
        if workbook is not None:
            try:
                workbook.close()
            except Exception:
                pass


_STRUCTURE_CACHE = {}


def paytable_sheet_structure(excel_path, sheet_name):
    """The sheet's structure, remembered per Excel file version (the card studio asks on every edit)."""
    import copy

    try:
        st = os.stat(str(excel_path or "").strip())
        key = (os.path.normcase(os.path.abspath(str(excel_path).strip())), st.st_size, st.st_mtime_ns, str(sheet_name or "").strip())
    except (OSError, TypeError, ValueError):
        return _paytable_sheet_structure(excel_path, sheet_name)
    if key not in _STRUCTURE_CACHE:
        if len(_STRUCTURE_CACHE) > 64:
            _STRUCTURE_CACHE.clear()
        _STRUCTURE_CACHE[key] = _paytable_sheet_structure(excel_path, sheet_name)
    return copy.deepcopy(_STRUCTURE_CACHE[key])


def _paytable_sheet_structure(excel_path, sheet_name):
    """Detect a paytable sheet's symbol structure for auto-layout.

    Reuses the automapper's own block/card-count detection
    (``automap_paytable_slots_ws`` with an empty probe template) so the band
    split matches exactly what the mapper would infer — no duplicate
    heuristics. Returns ``{"top", "lower", "total", "has_wild", "has_scatter",
    "max_pay_rows", "symbols"}``; all-zero counts when the sheet can't be read.

    ``has_wild`` is True only for an icon-only wild (a wild symbol with no
    payout block of its own) — that one gets a dedicated wild cluster. A wild
    that owns pays is already a positional card block and flows into the grid
    like any other symbol, so it must not be added twice.
    """
    empty = {"top": 0, "lower": 0, "total": 0, "has_wild": False,
             "has_scatter": False, "max_pay_rows": 0, "symbols": [], "block_keys": []}
    excel_path = str(excel_path or "").strip()
    sheet_name = str(sheet_name or "").strip()
    if not excel_path or not os.path.isfile(excel_path) or not sheet_name:
        return dict(empty)
    workbook = None
    try:
        workbook = load_workbook(excel_path, data_only=True, read_only=True)
        if sheet_name not in workbook.sheetnames:
            return dict(empty)
        ws = workbook[sheet_name]
        info = automap_paytable_slots_ws(ws, {"slots": {}})
    except Exception:
        return dict(empty)
    finally:
        if workbook is not None:
            try:
                workbook.close()
            except Exception:
                pass

    blocks = info.get("blocks") or []
    counts = info.get("card_counts") or {}
    symbols = set(info.get("symbols") or [])
    # one card per symbol: the detector also lists a royal under its long name ("<A>" -> "a" AND "ace"),
    # both on the same pay cells — keep the first (the sheet's own spelling)
    _pair = {"a": "ace", "k": "king", "q": "queen", "j": "jack", "10": "ten", "9": "nine"}
    _pair.update({v: k for k, v in list(_pair.items())})
    _seen, _uniq = {}, []
    for b in blocks:
        ref, key = str(b.get("pay_ref") or ""), str(b.get("key") or "").casefold()
        if ref and _pair.get(key) in _seen.get(ref, set()):
            continue                                   # "ace" on the same cells as "a": one symbol
        _seen.setdefault(ref, set()).add(key)
        _uniq.append(b)
    if len(_uniq) < len(blocks):
        dropped = len(blocks) - len(_uniq)
        blocks = _uniq
        counts = dict(counts, lower=max(0, int(counts.get("lower") or 0) - dropped))
    total = len(blocks)
    top = int(counts.get("top") or 0)
    lower = int(counts.get("lower") or 0)
    if total and (top + lower) == 0:
        top = (total + 1) // 2
        lower = total - top

    wild_is_block = any((b.get("key") == "wild") for b in blocks)
    has_wild = ("wild" in symbols) and not wild_is_block
    has_scatter = ("scatter" in symbols) or any("scat" in str(b.get("key") or "") for b in blocks)

    def _row_count(ref):
        return len([r for r in str(ref or "").split(",") if r.strip()])

    max_pay_rows = max((_row_count(b.get("pay_ref")) for b in blocks), default=0)

    return {
        "top": top,
        "lower": lower,
        "total": total,
        "has_wild": bool(has_wild),
        "has_scatter": bool(has_scatter),
        "max_pay_rows": int(max_pay_rows or 0),
        "symbols": sorted(symbols),
        # Ordered anchor keys (top row first, then lower row) so the generator
        # can name each cell for its real symbol instead of a positional picN.
        "block_keys": [str(b.get("key") or "") for b in blocks],
    }


def read_paytable_sheet_data(excel_path, sheet_name=""):
    """Every filled cell of a paytable sheet, for the mapper's data sidebar:
    ``{"ok": True, "rows": [{"ref": "A1", "row": 1, "col": 1, "text": "..."}],
    "dims": {"rows": N, "cols": M}}`` in sheet order. Cells are read with
    ``data_only`` so formulas resolve to their cached values."""
    if not excel_path:
        return {"ok": False, "error": "No Excel file configured."}
    if not sheet_name:
        return {"ok": False, "error": "No sheet selected."}
    workbook = None
    try:
        workbook = load_workbook(excel_path, data_only=True, read_only=True)
        if sheet_name not in workbook.sheetnames:
            return {"ok": False, "error": f"Sheet '{sheet_name}' not found."}
        ws = workbook[sheet_name]

        def _column_letter(idx):
            letters = ""
            while idx > 0:
                idx, rem = divmod(idx - 1, 26)
                letters = chr(65 + rem) + letters
            return letters

        rows = []
        max_r = max_c = 0
        for row in ws.iter_rows():
            for cell in row:
                if cell is None or cell.value is None:
                    continue
                text = str(cell.value).strip()
                if not text:
                    continue
                rows.append({
                    "ref": f"{_column_letter(cell.column)}{cell.row}",
                    "row": cell.row,
                    "col": cell.column,
                    "text": text,
                })
                max_r = max(max_r, cell.row)
                max_c = max(max_c, cell.column)
        rows.sort(key=lambda c: (c["row"], c["col"]))
        return {"ok": True, "rows": rows, "dims": {"rows": max_r, "cols": max_c}}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}
    finally:
        if workbook is not None:
            try:
                workbook.close()
            except Exception:
                pass


def automap_paytable_slots_ws(ws, template):
    """Core ``automap_paytable_slots`` against an already-open worksheet.

    Identical classification, but the worksheet is provided by the caller
    (renderers already hold it). Also returns ``symbols`` — the normalized
    anchor keys found in the sheet (every text/number cell that can name a
    card), so callers can tell whether a saved mapping still belongs to a
    card the CURRENT sheet contains.

    Also returns ``blocks`` — every card anchor cell that owns pay/value
    refs, in sheet order — and ``card_counts``. A card is identified by
    POSITION, never by name: a ``picN`` slot whose name has no anchor falls
    back to the sheet's ``N``-th block, so a sheet that names its 4th card
    ``<SPACESHIP>`` auto-fills ``pic4`` / ``pic4.pay`` / ``pic4.value`` with
    the sheet's own token and refs (name-claimed blocks are never
    re-assigned).
    """
    from ps_autotypesetter.table_mapping import _slot_name_is_bounds_like

    slots = (template or {}).get("slots") or {}
    if not isinstance(slots, dict) or ws is None:
        return {"mappings": [], "unmapped": [], "pays_column": "", "values_column": "", "sheet_dims": {"rows": 0, "cols": 0}, "symbols": []}

    def _column_letter(idx):
        letters = ""
        while idx > 0:
            idx, rem = divmod(idx - 1, 26)
            letters = chr(65 + rem) + letters
        return letters

    def _cell_ref(row_idx, col_idx):
        if row_idx < 1 or col_idx < 1:
            return ""
        return f"{_column_letter(col_idx)}{row_idx}"

    token_map = {}
    pays_headers = {}
    values_headers = {}
    vals = {}
    numeric_cells = set()
    try:
        max_row = ws.max_row if ws.max_row is not None else 2 ** 31
        max_col = ws.max_column if ws.max_column is not None else 2 ** 31
    except Exception:
        max_row, max_col = 2 ** 31, 2 ** 31

    for row in ws.iter_rows(min_row=1, max_row=min(max_row, 4000), max_col=min(max_col, 120)):
        for cell in row:
            if cell is None or cell.value is None:
                continue
            text = str(cell.value).strip()
            if not text:
                continue
            vals[(cell.row, cell.column)] = text
            if isinstance(cell.value, (int, float)):
                numeric_cells.add((cell.row, cell.column))
            norm = _paytable_norm_name(text)
            for token in re.findall(r"<([^<>]+)>", text):
                tkey = _paytable_norm_name(token)
                if tkey:
                    info = {
                        "ref": _cell_ref(cell.row, cell.column),
                        "row": cell.row,
                        "col": cell.column,
                        "token": f"<{token}>",
                    }
                    token_map.setdefault(tkey, info)
                    for alias in _paytable_alias_keys(tkey):
                        token_map.setdefault(alias, info)
            if norm in {"wild"} and "wild" not in token_map:
                token_map["wild"] = {
                    "ref": _cell_ref(cell.row, cell.column),
                    "row": cell.row,
                    "col": cell.column,
                    "token": "<wild>",
                }
            header_key = re.sub(r"[^a-z]", "", norm)
            if header_key in {"pays", "pay", "payouts", "multipliers", "multiplier"} and not pays_headers:
                pays_headers = {"row": cell.row, "col": cell.column}
            elif header_key in {"values", "value"} and not values_headers:
                values_headers = {"row": cell.row, "col": cell.column}

    # Anchor map: every cell whose text names a symbol (with or without
    # < >, e.g. "<PIC1>", "PIC2", "ACE") -> its (row, col). Numeric cells
    # (pay/value numbers) are never anchors — a bare value "10" must not
    # be mistaken for the "<10>" ten-symbol anchor. The one exception: a
    # numeric cell in {2..10} that is the row's leftmost numeric cell is a
    # bare low-symbol label ("10" written as a number for the ten card),
    # so it anchors too. Each anchor is also registered under its
    # canonical symbol name (see _PAYTABLE_SYMBOL_CANON), so "<A>" is
    # found by an "ace" slot and "ten"/"TEn"/"10" by a "ten" slot.
    leftmost_numeric_in_row = {}
    for (r, c) in numeric_cells:
        prev = leftmost_numeric_in_row.get(r)
        if prev is None or c < prev:
            leftmost_numeric_in_row[r] = c
    anchors = {}
    for (r, c), text in vals.items():
        if (r, c) in numeric_cells:
            if leftmost_numeric_in_row.get(r) != c:
                continue
            if str(text) not in _PAYTABLE_LOW_SYMBOL_NUMBERS:
                continue
        key = _paytable_norm_name(str(text).strip("<> "))
        if not key:
            continue
        anchors.setdefault(key, []).append((r, c))
        canon = _PAYTABLE_SYMBOL_CANON.get(key)
        if canon and canon != key:
            anchors.setdefault(canon, []).append((r, c))

    def _pay_value_columns(anchor_row, anchor_col):
        """First (pay) and second (value) numeric column right of the
        anchor. The anchor may be centered vertically, so columns are
        probed in a row window around the anchor row; columns whose
        numeric run lies nearest the anchor row win (this keeps the
        next block's column from being mistaken for this block's)."""
        candidates = []
        row_min = max(1, anchor_row - 12)
        row_max = min(max_row, anchor_row + 12)
        for c in range(anchor_col + 1, min(max_col, anchor_col + 20) + 1):
            dist = None
            for r in range(row_min, row_max + 1):
                value = vals.get((r, c))
                if value is not None and _paytable_numeric(value):
                    d = abs(r - anchor_row)
                    if dist is None or d < dist:
                        dist = d
            if dist is not None and dist <= 6:
                candidates.append((dist, c))
        candidates.sort()
        pay_col = candidates[0][1] if candidates else None
        value_col = candidates[1][1] if len(candidates) > 1 else None
        return pay_col, value_col

    def _symbol_pay_value_refs(sym_key):
        """Anchor-based pay/value refs: first numeric column right of the
        symbol's anchor cell = pay, second = value; the block top/bottom is
        the contiguous numeric run closest to the anchor row (the anchor
        may sit above the first payout row). The anchor key is matched
        through ``_paytable_symbol_variants`` so "ace" can resolve an
        "<A>" cell and "ten" a "<10>" cell."""
        for key in _paytable_symbol_variants(sym_key):
            for row_idx, col_idx in anchors.get(key, []):
                pay_col, value_col = _pay_value_columns(row_idx, col_idx)
                if not pay_col and not value_col:
                    continue
                pay_ref = _numeric_run_in_column(pay_col, around_row=row_idx) if pay_col else ""
                value_ref = _numeric_run_in_column(value_col, around_row=row_idx) if value_col else ""
                if pay_ref or value_ref:
                    return pay_ref, value_ref
        return "", ""

    def _numeric_run_in_column(col_idx, around_row=None):
        """Comma-joined refs of the contiguous numeric run in one column
        closest to around_row — single cells become single refs, stacked
        pay/value cells (e.g. F14:F17 for a symbol at row 15) join up."""
        col_letter = _column_letter(col_idx)
        rows = []
        for r in range(1, min(max_row, 4000) + 1):
            value = vals.get((r, col_idx))
            if value is not None and _paytable_numeric(value):
                rows.append(r)
        if not rows:
            return ""
        if around_row is not None:
            nearest = min(rows, key=lambda r: abs(r - around_row))
            start = nearest
            while start - 1 in rows:
                start -= 1
            end = nearest
            while end + 1 in rows:
                end += 1
            return ",".join(f"{col_letter}{r}" for r in range(start, end + 1))
        return f"{col_letter}{rows[0]}"

    def _numeric_columns_around(row_idx, col_idx, span_rows=6, span_cols=10):
        hits = []
        for r in range(max(1, row_idx - span_rows), min(max_row, row_idx + span_rows) + 1):
            for c in range(col_idx + 1, min(max_col, col_idx + span_cols) + 1):
                value = vals.get((r, c))
                if value is not None and _paytable_numeric(value):
                    hits.append((c, abs(r - row_idx)))
        if not hits:
            return "", ""
        hits.sort()
        first_col = hits[0][0]
        pay_ref = _numeric_run_in_column(first_col, around_row=row_idx)
        value_ref = ""
        for c, _dist in hits:
            if c != first_col:
                value_ref = _numeric_run_in_column(c, around_row=row_idx)
                break
        return pay_ref or "", value_ref or ""

    def _token_info(target_norm):
        """Token-map lookup that also tries the number-word aliases and
        the first-letter variant (ace -> <A>)."""
        for key in _paytable_symbol_variants(target_norm):
            info = token_map.get(key)
            if info:
                return info
        return None

    def _pay_value_cells(target_norm):
        info = _token_info(target_norm)
        if not info:
            return "", ""
        row_idx = info["row"]
        col_idx = info["col"]
        pays_col = pays_headers.get("col")
        values_col = values_headers.get("col")
        pay_ref = ""
        value_ref = ""
        if pays_col:
            pay_ref = _numeric_run_in_column(pays_col, around_row=row_idx)
        if values_col:
            value_ref = _numeric_run_in_column(values_col, around_row=row_idx)
        if not pay_ref or not value_ref:
            fallback_pay, fallback_value = _numeric_columns_around(row_idx, col_idx)
            if not pay_ref:
                pay_ref = fallback_pay
            if not value_ref:
                value_ref = fallback_value
        return pay_ref, value_ref

    # Card blocks: every card anchor cell that also owns a pay/value block,
    # in sheet order (row asc, col asc). The anchor token is whatever the
    # sheet names it ("<PIC1>", "<SPACESHIP>", "<BASE GREEN EGG>" ...) — a
    # card is identified by POSITION, never by name, so a `<randomname>`
    # label still auto-lays out into the pic1.. slots in sheet order. Card
    # label cells are non-numeric anchor text ("<PIC1>", "ACE" ...) plus
    # bare low-symbol numbers ("10" for the ten card) — rule text
    # (len > 12), paytable header cells ("PAYS"/"VALUE") and payout digits
    # ("4"/"3"/"150" that anchor as row-leftmost numbers) are never cards.
    # A cell that is exactly one <TOKEN> names a symbol whatever its length or spelling: a long name
    # ("<WATER LILY_pays>") is still a card, and so is a number written as a token ("<9>").
    def _token_cell(cells):
        return any(re.fullmatch(r"<[^<>]+>", str(vals.get(rc) or "").strip()) for rc in cells)

    card_cells = {}
    for key, cells in anchors.items():
        token = _token_cell(cells)
        if len(key) > (40 if token else 12):
            continue
        if key.isdigit():
            if key in _PAYTABLE_SYMBOL_CANON:
                key = _PAYTABLE_SYMBOL_CANON[key]
            elif not token:
                continue
        if key in _PAYTABLE_HEADER_KEYS:
            continue
        card_cells.setdefault(key, cells[0])

    blocks = []
    for key, rc in card_cells.items():
        r, c = rc
        pay_ref, value_ref = _symbol_pay_value_refs(key)
        if not pay_ref and not value_ref:
            continue
        blocks.append({
            "token": f"<{key}>",
            "key": key,
            "row": r,
            "col": c,
            "pay_ref": pay_ref,
            "value_ref": value_ref,
        })
    blocks.sort(key=lambda b: (b["row"], b["col"]))

    # Card blocks the template claims by name: any block whose own key is a
    # template slot name ("ACE" -> "ace", "<PIC1>" -> "pic1") is already
    # rendered by that slot and must not be re-assigned to a picN position
    # by the positional fallback below.
    slot_names = {_paytable_norm_name(s) for s in slots}
    claimed = set()
    for b in blocks:
        if any(n in _paytable_symbol_variants(b["key"]) for n in slot_names):
            claimed.add(b["key"])

    # Card block counts from the live blocks. Priority: 1) the user's chosen
    # row capacities (mapper_meta.row_counts, e.g. top=4/bottom=6); 2) Excel
    # itself: the bottom (royals) band starts at the first <ace> card, every
    # card before it is a top card (pic1..pic3 + <spaceship> + ACE..NINE ->
    # 4 + 6); 3) the template's own card-BG slot count; 4) picN-named
    # anchors; 5) the largest row-gap split. A sheet with fewer cards than
    # the template (9 vs 10) reports {"top": 5, "lower": 4} so card-position
    # slots (TopCardsBG.N / BottomCardsBG.N) render only what actually exists.
    total_blocks = len(blocks)
    if total_blocks:
        user_top, user_bottom = _paytable_row_counts(template)
        ace_at = next((i for i, b in enumerate(blocks) if _paytable_norm_name(b["key"]) in ("ace", "a")), 0)
        if user_top:
            top = user_top
        elif ace_at:
            top = ace_at
        else:
            top = _paytable_template_bg_count(template, "topcardsbg")
            if not top:
                top_pic = sum(1 for b in blocks if re.fullmatch(r"pic\d+", b["key"]))
                if top_pic:
                    top = top_pic
                elif total_blocks > 1:
                    rows = [b["row"] for b in blocks]
                    best, split = 0, total_blocks // 2
                    for i in range(1, total_blocks):
                        gap = rows[i] - rows[i - 1]
                        if gap > best:
                            best, split = gap, i
                    top = split
                else:
                    top = total_blocks
        top = min(top, total_blocks)
        lower = max(0, total_blocks - top)
        if user_bottom:
            lower = min(lower, user_bottom)
        card_counts = {"top": top, "lower": lower}
    else:
        card_counts = {"top": 0, "lower": 0}

    # ---- text-cell pool for text slots (text / notes / ...) ----
    # Plain non-numeric cells in the main text area that are NOT pay/value
    # numbers, card labels (a card block cell, a template symbol-name cell,
    # a known low-symbol label like "10"/"ACE"), PAYS/VALUE headers or
    # artist notes. The ".text" slot collects ALL remaining plain cells (in
    # scan order, comma-joined refs, newline-joined texts) so the slot holds
    # every line of normal body text the paytable has left over after the
    # symbols, pays, values and heading are taken; other text slots (notes,
    # label, ...) take the next single unused cell. The best title cell is
    # reserved for the page heading (the ".title" slot renders the heading
    # itself and never takes a text cell).
    excluded_anchor_keys = set(card_cells) | set(slot_names)
    excluded_anchor_keys |= set(_PAYTABLE_SYMBOL_CANON.values()) | _PAYTABLE_LOW_SYMBOL_NUMBERS
    excluded_anchor_cells = set()
    for key, cells in anchors.items():
        if key in excluded_anchor_keys or key in _PAYTABLE_SYMBOL_CANON:
            for rc in cells:
                excluded_anchor_cells.add(rc)
    text_pool = []
    for rc in sorted(vals, key=lambda pos: (pos[0], pos[1])):
        r, c = rc
        if c > _PAYTABLE_MAIN_TEXT_COL_LIMIT:
            continue
        if rc in numeric_cells or rc in excluded_anchor_cells:
            continue
        text = str(vals[rc]).strip()
        if not text:
            continue
        # Token-bearing cells ARE body text (e.g. "<WILD> substitutes for all
        # symbols except <purple_scat>.") and belong in the text slot with
        # their inline icons. Only pure-token cells ("<WILD>" alone — a
        # symbol legend / section label row) are skipped.
        if not re.sub(r"<[^<>]*>", "", text).strip():
            continue
        norm = _paytable_norm_name(text)
        if not norm or norm in _PAYTABLE_HEADER_KEYS:
            continue
        lower = text.casefold()
        if any(h in lower for h in _PAYTABLE_META_HINTS):
            continue
        text_pool.append({"row": r, "col": c, "ref": _cell_ref(r, c), "text": text})

    def _best_title_cell():
        """The cell that most looks like the page title: contains
        PAYTABLE (huge bonus), then top-leftmost of the pool."""
        best = None
        for cell in text_pool:
            lower = str(cell["text"]).casefold()
            score = 1000 if "paytable" in lower else 0
            score -= cell["row"] * 4 + cell["col"]
            if best is None or score > best["score"]:
                best = {"score": score, **cell}
        return best or (text_pool[0] if text_pool else None)

    title_cell = _best_title_cell()
    # a sheet whose title cell is just "PAYTABLE" (a header key, kept out of the pool) has its title:
    # the top-left rules sentence must not be taken for it and dropped from the rules text
    _tt = str((title_cell or {}).get("text") or "")
    _hidden_title = any("paytable" in str(v).casefold() for v in vals.values() if isinstance(v, str))
    title_skip = None if (title_cell and "paytable" not in _tt.casefold() and _hidden_title) else title_cell
    used_text_cells = set()

    def _pic_block(index):
        """Position-based fallback for a ``picN`` slot whose name has no
        anchor: the sheet's ``index``-th card block in position order (1-based,
        across BOTH bands). Top-row indices resolve inside the top band and
        higher indices continue into the lower band, so a two-band template
        (``pic1..N`` top, ``picN+1..M`` bottom) auto-fills from the sheet's
        full card order. Name-claimed blocks are skipped (ACE sitting at the
        5th top position is not double-mapped into pic5), and indices past
        the sheet's total card count are out of range."""
        if index < 1 or index > len(blocks):
            return None
        block = blocks[index - 1]
        if block["key"] in claimed:
            return None
        return block

    mappings = []
    unmapped = []
    has_literal_text_slot = "text" in {_paytable_norm_name(s) for s in slots}
    catch_all_assigned = False
    for slot, box in slots.items():
        if _slot_name_is_bounds_like(slot):
            continue
        base = _paytable_norm_name(slot)
        if base in _PAYTABLE_BOUNDS_NAMES:
            continue
        ref = _paytable_cell_ref(base)
        if (ref and 1 <= ref[1] <= max_row and 1 <= ref[2] <= max_col
                and vals.get((ref[1], ref[2])) is not None):
            mappings.append({
                "mode": "excel",
                "source": f"{ref[0]}{ref[1]}",
                "slot": slot,
                "font_size": 30,
                "icon_height": 48,
                "color": "#FFFFFF",
                "alignment": "center",
                "vertical_align": "center",
                "padding": [0, 0, 0, 0],
            })
            continue

        if base in {"wildpay", "wildvalue"}:
            pay_ref, value_ref = _symbol_pay_value_refs("wild")
            if not pay_ref or not value_ref:
                legacy_pay, legacy_value = _pay_value_cells("wild")
                if not pay_ref:
                    pay_ref = legacy_pay
                if not value_ref:
                    value_ref = legacy_value
            source = pay_ref if base == "wildpay" else value_ref
            if source:
                mappings.append({
                    "mode": "excel",
                    "source": source,
                    "slot": slot,
                    "role": "pay" if base == "wildpay" else "value",
                    "symbol": "wild",
                    "font_size": 30,
                    "icon_height": 48,
                    "color": "#FFFFFF",
                    "alignment": "center",
                    "vertical_align": _slot_valign(box),
                    "text": _paytable_refs_text(source, vals),
                    "padding": [0, 0, 0, 0],
                })
            else:
                unmapped.append(slot)
            continue

        wild_num = re.fullmatch(r"wild\.\d+", base)
        if wild_num:
            mappings.append({
                "mode": "icon",
                "source": "",
                "slot": slot,
                "token": "<wild>",
                "icon_height": 120,
                "color": "#FFFFFF",
                "alignment": "center",
                "vertical_align": "center",
                "padding": [0, 0, 0, 0],
            })
            continue

        # any symbol name ("lion_pays", "gold_coin", "pic1"): a sheet's <GOLD_COIN> card has numbers too
        sym_kind = re.fullmatch(r"([^.]+)\.(pay|value)s?(\d*)", base)
        if sym_kind:
            sym = sym_kind.group(1)
            role = sym_kind.group(2)
            pay_ref, value_ref = _symbol_pay_value_refs(sym)
            if not pay_ref or not value_ref:
                legacy_pay, legacy_value = "", ""
                if sym in token_map or any(a in token_map for a in _paytable_alias_keys(sym)):
                    legacy_pay, legacy_value = _pay_value_cells(sym)
                if not pay_ref:
                    pay_ref = legacy_pay
                if not value_ref:
                    value_ref = legacy_value
            mapped_sym = sym
            if (not pay_ref or not value_ref) and re.fullmatch(r"pic\d+", sym):
                block = _pic_block(int(sym[3:]))
                if block:
                    if not pay_ref:
                        pay_ref = block["pay_ref"]
                    if not value_ref:
                        value_ref = block["value_ref"]
                    mapped_sym = block["key"]
            source = pay_ref if role == "pay" else value_ref
            if source:
                mappings.append({
                    "mode": "excel",
                    "source": source,
                    "slot": slot,
                    "role": role,
                    "symbol": mapped_sym,
                    "font_size": 30,
                    "icon_height": 48,
                    "color": "#FFFFFF",
                    "alignment": "center",
                    "vertical_align": _slot_valign(box),
                    "text": _paytable_refs_text(source, vals),
                    "padding": [0, 0, 0, 0],
                })
            else:
                unmapped.append(slot)
            continue

        kind_match = re.fullmatch(r"(pay|value)s?(\d*)", base)
        if kind_match:
            role = kind_match.group(1)
            index_str = kind_match.group(2) or ""
            pay_ref = ""
            value_ref = ""
            block = None
            if index_str:
                pay_ref, value_ref = _symbol_pay_value_refs(f"pic{int(index_str)}")
                if not pay_ref or not value_ref:
                    legacy_pay, legacy_value = _pay_value_cells(f"pic{int(index_str)}")
                    if not pay_ref:
                        pay_ref = legacy_pay
                    if not value_ref:
                        value_ref = legacy_value
                block = _pic_block(int(index_str))
                if block:
                    if not pay_ref:
                        pay_ref = block["pay_ref"]
                    if not value_ref:
                        value_ref = block["value_ref"]
            else:
                anchor = next(iter(token_map.values()), None)
                pay_ref = ""
                value_ref = ""
                if pays_headers:
                    pay_ref = _numeric_run_in_column(pays_headers.get("col"))
                if values_headers:
                    value_ref = _numeric_run_in_column(values_headers.get("col"))
                if anchor and (not pay_ref or not value_ref):
                    fallback_pay, fallback_value = _numeric_columns_around(anchor["row"], anchor["col"])
                    if not pay_ref:
                        pay_ref = fallback_pay
                    if not value_ref:
                        value_ref = fallback_value
            source = pay_ref if role == "pay" else value_ref
            if source:
                mappings.append({
                    "mode": "excel",
                    "source": source,
                    "slot": slot,
                    "role": role,
                    "symbol": block["key"] if (block and index_str) else (f"pic{int(index_str)}" if index_str else ""),
                    "font_size": 30,
                    "icon_height": 48,
                    "color": "#FFFFFF",
                    "alignment": "center",
                    "vertical_align": _slot_valign(box),
                    "text": _paytable_refs_text(source, vals),
                    "padding": [0, 0, 0, 0],
                })
            else:
                unmapped.append(slot)
            continue

        if base == "wild":
            mappings.append({
                "mode": "icon",
                "source": "",
                "slot": slot,
                "token": "<wild>",
                "icon_height": 120,
                "color": "#FFFFFF",
                "alignment": "center",
                "vertical_align": "center",
                "padding": [0, 0, 0, 0],
            })
            continue

        last_part = base.rsplit(".", 1)[-1]
        first_part = base.split(".", 1)[0]
        if base in _PAYTABLE_TEXT_SLOT_NAMES or last_part in _PAYTABLE_TEXT_SLOT_NAMES or first_part in _PAYTABLE_TEXT_SLOT_NAMES:
            is_wild_ish = base in _PAYTABLE_WILD_TITLE_SLOTS or first_part in {"wild", "feature", "special"}
            title_like = (base in _PAYTABLE_TITLE_SLOT_NAMES
                          or last_part in _PAYTABLE_TITLE_SLOT_NAMES
                          or first_part in _PAYTABLE_TITLE_SLOT_NAMES)
            if not is_wild_ish and (base == "text" or (not has_literal_text_slot and not catch_all_assigned and not title_like)):
                # THE ".text" slot (any prefix) always owns ALL the remaining
                # plain text of the page — no other slot may take it. Only
                # when the template has no literal "text" slot at all does
                # the first text-ish slot fall back to the whole pool.
                catch_all_assigned = True
                cells = []
                for pool_cell in text_pool:
                    rc = (pool_cell["row"], pool_cell["col"])
                    if rc in used_text_cells:
                        continue
                    if title_skip and rc == (title_skip["row"], title_skip["col"]):
                        continue
                    cells.append(pool_cell)
                    used_text_cells.add(rc)
                if cells:
                    mappings.append({
                        "mode": "excel",
                        "source": ",".join(c["ref"] for c in cells),
                        "slot": slot,
                        "font_size": 30,
                        "icon_height": 48,
                        "color": "#FFFFFF",
                        "alignment": "center",
                        "vertical_align": "center",
                        "text": "\n".join(c["text"] for c in cells),
                        "padding": [0, 0, 0, 0],
                    })
                else:
                    unmapped.append(slot)
                continue
            # Any OTHER text-ish slot (text.1, notes, description, ...) is
            # never auto-filled from the pool — automap leaves it empty so
            # the user can map duplicate data onto it manually.
            unmapped.append(slot)
            continue

        pic_num = re.fullmatch(r"pic(\d+)", base)
        if pic_num:
            name_pay, name_value = _symbol_pay_value_refs(base)
            block = None if (name_pay or name_value) else _pic_block(int(pic_num.group(1)))
            if block:
                mappings.append({
                    "mode": "icon",
                    "source": "",
                    "slot": slot,
                    "token": f"<{block['key']}>",
                    "symbol": block["key"],
                    "icon_height": 120,
                    "color": "#FFFFFF",
                    "alignment": "center",
                    "vertical_align": "center",
                    "padding": [0, 0, 0, 0],
                })
                continue

        mappings.append({
            "mode": "icon",
            "source": "",
            "slot": slot,
            "token": f"<{base}>",
            "icon_height": 120,
            "color": "#FFFFFF",
            "alignment": "center",
            "vertical_align": "center",
            "padding": [0, 0, 0, 0],
        })
        continue

    pays_col_label = _column_letter(pays_headers.get("col", 0)) if pays_headers else ""
    values_col_label = _column_letter(values_headers.get("col", 0)) if values_headers else ""
    used_rows = max((r for r, _c in vals), default=0)
    used_cols = max((c for _r, c in vals), default=0)

    return {
        "mappings": mappings,
        "unmapped": unmapped,
        "pays_column": pays_col_label,
        "values_column": values_col_label,
        "sheet_dims": {"rows": used_rows, "cols": used_cols},
        "symbols": [key for key in sorted(anchors) if key],
        "blocks": blocks,
        "card_counts": card_counts,
    }


_PAY_VALUE_SUFFIXES = ("pay", "value", "pays", "values")

_PAYTABLE_CARD_BG_SLOT_RE = re.compile(r"^(topcardsbg|bottomcardsbg|cardbg)\.(\d+)$")

# Short anchor keys that name paytable structure instead of a card ("PAYS",
# "VALUE" header cells). They must never count as card blocks even when a
# numeric run sits to their right.
_PAYTABLE_HEADER_KEYS = {"pay", "pays", "payout", "payouts", "value", "values", "multiplier", "multipliers"}


def _paytable_template_bg_count(template, kind):
    """Highest ``<kind>.N`` card-background slot index in the template
    (``TopCardsBG.5`` -> 5 for "topcardsbg"); 0 when the template carries
    none. The count is authoritative for the sheet's top-row card count, so
    a sheet whose top row mixes ``PIC1..PIC3`` with ``<SPACESHIP>/<ACE>``
    still reports top=5."""
    slots = (template or {}).get("slots") or {}
    if not isinstance(slots, dict):
        return 0
    count = 0
    for slot_name in slots:
        match = _PAYTABLE_CARD_BG_SLOT_RE.match(_paytable_norm_name(str(slot_name)))
        if match and match.group(1) == kind:
            count = max(count, int(match.group(2)))
    return count


def _paytable_row_counts(template):
    """User-chosen per-row card capacities — ``mapper_meta.row_counts``
    (or a top-level ``row_counts`` passthrough) with ``top`` / ``bottom``.

    Returns ``(top, bottom)`` ints, both 0 when the user set nothing (the
    "auto" mode where the template's card-BG slot counts decide the split).
    """
    try:
        rc = (template or {}).get("row_counts") or {}
        if not rc:
            rc = ((template or {}).get("mapper_meta") or {}).get("row_counts") or {}
        top = int(rc.get("top") or 0)
        bottom = int(rc.get("bottom") or 0)
    except Exception:
        top = bottom = 0
    return max(0, top), max(0, bottom)


def _paytable_live_slot_data(worksheet, template):
    """Live-sheet card data for the mapped-paytable render filter.

    Returns ``(symbols, top_cap, lower_cap, total_cap, block_keys)`` — the
    normalized anchor symbols actually present in the CURRENT worksheet,
    the top/lower card-block counts (``picN`` anchors = top row, symbol-
    named anchors = lower row; or the user's ``mapper_meta.row_counts``
    overrides) and the ordered block keys from position 1 onward — or
    ``None`` when the sheet cannot be read.
    """
    if worksheet is None:
        return None
    try:
        result = automap_paytable_slots_ws(worksheet, template) or {}
    except Exception:
        return None
    symbols = set(result.get("symbols") or [])
    counts = result.get("card_counts") or {}
    top_cap = int(counts.get("top") or 0)
    lower_cap = int(counts.get("lower") or 0)
    total_cap = top_cap + lower_cap
    block_keys = [b.get("key") or "" for b in (result.get("blocks") or [])]
    if not symbols and not total_cap:
        return None
    return symbols, top_cap, lower_cap, total_cap, block_keys


def paytable_slot_is_dead(slot_name, spec, live):
    """True when a paytable slot belongs to a card the LIVE sheet lacks.

    ``slot_name`` is classified (``TopCardsBG.N`` / ``BottomCardsBG.N``
    card fills are capped by the sheet's card counts; text/title/wild-title
    legend slots are never dead), then the mapping spec's symbol (the
    automap's ``symbol`` key, or the icon ``token``, or the name-based
    default) is matched against the sheet's anchors. ``spec`` may be None
    for unmapped slots.

    WILD is universal: an icon slot the JSON explicitly carries (``@slot.wild``
    / ``wild.1`` / ``wild.2`` ... with a ``<wild>`` token) always renders
    ``<wild>`` even when the workbook has no bare WILD anchor row. Only the
    DATA slots of wild (``wildpay`` / ``wildvalue``) stay subject to the
    sheet — they read Excel cells that must exist.

    Positional row capacities (``mapper_meta.row_counts``: top=4/bottom=6)
    hide the slots beyond the chosen row size: ``pic5``/``pic5.pay``/
    ``pay5`` die when the top row holds 4, and a bottom-row card sitting at
    position 5 dies when the bottom row holds 4 — regardless of whether the
    card label exists in the sheet.
    """
    try:
        symbols, top_cap, lower_cap, total_cap = live[0], live[1], live[2], live[3]
        block_keys = list(live[4]) if len(live) > 4 else []
    except Exception:
        return False
    if isinstance(spec, dict) and (spec.get("symbol_pinned") or spec.get("asset_path")):
        return False            # the artist chose this card's symbol/image by hand: always draw it
    base = _paytable_norm_name(str(slot_name or ""))
    if base in _PAYTABLE_TEXT_SLOT_NAMES or base in {"wild.title", "wild.text", "feature.title", "special.title"}:
        return False
    bg = _PAYTABLE_CARD_BG_SLOT_RE.match(base)
    if bg:
        kind, index = bg.group(1), int(bg.group(2))
        cap = {"topcardsbg": top_cap, "bottomcardsbg": lower_cap}.get(kind, total_cap)
        return index > cap
    pic_slot = re.fullmatch(r"pic(\d+)(?:\.(?:pay|value)s?)?", base)
    if pic_slot and int(pic_slot.group(1)) > top_cap:
        return True
    kind_ix = re.fullmatch(r"(?:pay|value)s?(\d+)", base)
    if kind_ix and int(kind_ix.group(1)) > top_cap:
        return True
    sym = ""
    mode = ""
    if spec is not None and isinstance(spec, dict):
        mode = str(spec.get("mode") or "").casefold()
        sym = str(spec.get("symbol") or "").strip()
        if not sym and str(spec.get("fit") or "").casefold() == "exact":
            return False        # design art (title art, frames) that belongs to no card
        if not sym:
            token = str(spec.get("token") or "").strip()
            if token:
                sym = _paytable_norm_name(str(token).strip("<> "))
        else:
            sym = _paytable_norm_name(sym)
    if not sym:
        return False
    if sym == "wild" and mode in {"icon", "symbol"}:
        return False
    # Data slots (excel / excel_text / text / literal / mixed) read cells by
    # source, so a stray token carried over from an older auto-map must never
    # convince the filter the slot belongs to a card the sheet lacks. Only
    # card-like data slots (picN.pay / payN / wildpay / ...) and specs that
    # carry an explicit automap ``symbol`` stay subject to the live-sheet
    # symbol check.
    card_like = bool(re.fullmatch(
        r"pic\d+|(?:pay|value)s?\d*|wildpay|wildvalue|wild\.\d+|[a-z0-9]+\.(?:pay|value)s?",
        base,
    ))
    explicit_symbol = bool(((spec or {}).get("symbol") or "").strip()) if isinstance(spec, dict) else False
    if mode in {"excel", "excel_text", "text", "literal", "mixed"} and not card_like and not explicit_symbol:
        return False
    # Bottom-row position rule: a card whose block sits beyond the chosen
    # bottom capacity is hidden even though its label exists in the sheet.
    if block_keys:
        for i, bkey in enumerate(block_keys):
            if i < top_cap or not bkey:
                continue
            if sym in _paytable_symbol_variants(bkey):
                return (i - top_cap + 1) > lower_cap
    return not any(v in symbols for v in _paytable_symbol_variants(sym))


def filter_paytable_mappings_to_sheet(mappings, worksheet, template):
    """Drop mapping specs for cards the CURRENT worksheet no longer contains.

    The mapped template JSON was saved against some other sheet (10 cards);
    the sheet actually being rendered may hold fewer (9). Icon/pay/value
    specs whose symbol has no anchor in the live sheet, and card-background
    fills (``TopCardsBG.N`` / ``BottomCardsBG.N``) beyond the sheet's card
    counts, are skipped so only what's present in Excel renders. Title /
    wild-title / text / legend slots are never dropped, and WILD icon slots
    (``@slot.wild`` / ``wild.1`` ...) are universal — they always render
    ``<wild>`` when the JSON carries them. Mutates ``mappings`` in place;
    returns the number of dropped specs.
    """
    live = _paytable_live_slot_data(worksheet, template)
    if live is None or not mappings:
        return 0
    dropped = 0
    for slot_name, spec in list(mappings.items()):
        if paytable_slot_is_dead(slot_name, spec, live):
            del mappings[slot_name]
            dropped += 1
    return dropped


def auto_fill_pay_value_slots(template, mappings, excel_path, sheet_name):
    """Background fill of every mapped symbol's ``.pay`` / ``.value`` slots.

    The user only maps the main symbol (e.g. ``pic2``); this fills
    ``pic2.pay`` / ``pic2.value`` from the Excel pay/value block with no
    manual ``source`` assignment. Slots that don't exist in the template are
    skipped silently (Excel symbol without a slot -> no error), and
    already-populated mappings (user text or a prior auto-map) are never
    overridden.

    Returns ``{"ok": True, "mappings": {slot: spec}, "filled": N}`` — each
    spec is ``mode:"excel"`` with comma-joined ``source`` refs and the
    literal newline-joined ``text``.
    """
    slots = (template or {}).get("slots") or {}
    if not isinstance(slots, dict) or not isinstance(mappings, dict) or not excel_path or not sheet_name:
        return {"ok": True, "mappings": {}, "filled": 0}
    try:
        result = automap_paytable_slots(template, excel_path, sheet_name)
    except Exception:
        return {"ok": True, "mappings": {}, "filled": 0}
    out = {}
    for m in result.get("mappings") or []:
        slot = str(m.get("slot") or "")
        base, sep, suffix = slot.rpartition(".")
        if not sep or suffix not in _PAY_VALUE_SUFFIXES:
            if slot not in ("wildpay", "wildvalue"):
                continue
            base = "wild"
        if slot not in slots or not mappings.get(base):
            continue
        existing = mappings.get(slot)
        if existing and (existing.get("source") or existing.get("text")):
            continue
        out[slot] = m
    return {"ok": True, "mappings": out, "filled": len(out)}


def table_mapper_source_range(mappings):
    """Compute the component source range from mapping refs (union of cells)."""
    from ps_autotypesetter.table_mapping import direct_range_bounds, get_column_letter

    bounds = []
    for mapping in (mappings or []):
        for part in re.split(r"[;\n]+", str(mapping.get("source") or "")):
            item = direct_range_bounds(part)
            if item:
                bounds.append(item)
    if not bounds:
        return "A1"
    min_col = min(b[0] for b in bounds)
    min_row = min(b[1] for b in bounds)
    max_col = max(b[2] for b in bounds)
    max_row = max(b[3] for b in bounds)
    start = f"{get_column_letter(min_col)}{min_row}"
    end = f"{get_column_letter(max_col)}{max_row}"
    return f"{start}:{end}"


def load_table_mapper_session(path):
    """Load an existing mapped table JSON for editing. Returns a payload dict."""
    from ps_autotypesetter.table_mapping import load_table_template

    template = load_table_template(path, strict=False)
    table_name = ""
    spec = None
    for name, s in (template.get("table_templates") or {}).items():
        table_name = str(name)
        spec = s
        break
    return {
        "template": template,
        "table_name": table_name,
        "sheet_name": str((spec or {}).get("source_sheet") or ""),
        "source_range": str((spec or {}).get("source_range") or ""),
        "mappings": list((spec or {}).get("mappings") or []),
        "spec": spec,
    }


def load_paytable_mapper_session(path):
    """Load a mapped paytable JSON (scanned PSD template + slot mappings)."""
    from ps_autotypesetter.dynamic_pages.template_loader import load_template_json

    template = load_template_json(path)
    return {
        "template": template,
        "template_id": str(template.get("template_id") or ""),
        "sheet_name": str((template.get("mapper_meta") or {}).get("sheet_name") or ""),
        "mappings": template.get("mappings") or {},
    }


def save_paytable_mapping(cfg, payload):
    """Save a web Paytable Mapper session to a global mapped JSON.

    The JSON keeps the scanned PSD template (canvas + @slot.* boxes) and adds
    per-slot ``mappings`` (dict of slot name -> spec) plus ``mapper_meta`` so
    the dynamic router can detect it as mapper-authored. When
    ``payload["output_path"]`` is set the JSON is saved there instead of the
    default ``mapped_paytables/`` folder. The saved path is stored as
    ``dynamic_settings.template_json`` (global template).
    """
    template = payload.get("template") or {}
    if not isinstance(template, dict) or not (template.get("slots") or {}):
        return {"ok": False, "error": "Missing template slots."}, cfg
    raw_mappings = payload.get("mappings") or {}
    if isinstance(raw_mappings, list):
        mappings = {}
        for m in raw_mappings:
            if isinstance(m, dict) and m.get("slot"):
                mappings[str(m["slot"])] = m
    elif isinstance(raw_mappings, dict):
        mappings = dict(raw_mappings)
    else:
        mappings = {}
    template_id = str(
        payload.get("template_id")
        or template.get("template_id")
        or template.get("name")
        or "paytable"
    )
    psd_path = str(payload.get("psd_path") or template.get("source_psd") or "")
    sheet_name = _raw_sheet(payload.get("sheet_name"))
    safe_name = re.sub(r"[^A-Za-z0-9_\-]+", "_", template_id).strip("_") or "paytable"
    base_safe_name = safe_name

    base_dir = str((cfg or {}).get("output_dir") or "").strip()
    if not base_dir or not os.path.isdir(base_dir):
        base_dir = os.path.dirname(os.path.abspath(psd_path)) if psd_path else ""
    requested_path = str(payload.get("output_path") or "").strip()
    if requested_path:
        out_path = os.path.abspath(requested_path)
        if not out_path.lower().endswith(".json"):
            out_path += ".json"
        out_dir = os.path.dirname(out_path) or os.getcwd()
    elif payload.get("template_dir"):
        from . import paytable_templates

        out_dir = paytable_templates.templates_dir()
        if os.path.exists(os.path.join(out_dir, f"{safe_name}.json")):
            i = 2
            while os.path.exists(os.path.join(out_dir, f"{safe_name}_{i}.json")):
                i += 1
            safe_name = f"{safe_name}_{i}"
        out_path = os.path.abspath(os.path.join(out_dir, f"{safe_name}.json"))
    else:
        out_dir = os.path.join(base_dir, "mapped_paytables") if base_dir else os.path.abspath("mapped_paytables")
        out_path = os.path.abspath(os.path.join(out_dir, f"{safe_name}_mapped.json"))

    canvas = template.get("canvas") or {}
    try:
        cw = float(canvas.get("width") or 0)
        ch = float(canvas.get("height") or 0)
    except Exception:
        cw = ch = 0.0
    if cw <= 0 or ch <= 0:
        cw = float(_as_int((cfg or {}).get("c_width"), 1920))
        ch = float(_as_int((cfg or {}).get("c_height"), 1080))

    meta = dict(template.get("mapper_meta") or {})
    row_counts = payload.get("row_counts")
    if row_counts:
        try:
            meta["row_counts"] = {
                "top": max(0, int(row_counts.get("top") or 0)),
                "bottom": max(0, int(row_counts.get("bottom") or 0)),
            }
        except Exception:
            pass

    document = {
        "template_id": template_id,
        "source_psd": psd_path,
        "canvas": {"width": cw, "height": ch},
        "slots": template.get("slots") or {},
        "slot_prefix": str(payload.get("slot_prefix") or "@slot"),
        "mapper_meta": {
            **meta,
            "generated_by": "web_paytable_mapper",
            "sheet_name": sheet_name,
        },
        "mappings": mappings,
    }
    try:
        os.makedirs(out_dir, exist_ok=True)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(document, f, indent=2)
    except Exception as exc:
        return {"ok": False, "error": str(exc)}, cfg

    # Mirror the design into the tool's PaytableTemplates library so the
    # saved template always appears in the Template name dropdown.
    # Card-template layouts are regenerated from their template every time:
    # no library entry and no copy in the game folder (the card template is what's kept).
    _generated = str(((template or {}).get("mapper_meta") or {}).get("layout") or "") == "cards"
    library_path = ""
    try:
        from . import paytable_templates

        if _generated:
            raise StopIteration
        lib_dir = os.path.normcase(os.path.abspath(paytable_templates.templates_dir()))
        if os.path.normcase(os.path.abspath(out_path)).startswith(lib_dir + os.sep):
            library_path = os.path.abspath(out_path)
        else:
            library_path = paytable_templates.save_template(document, template_id)
    except StopIteration:
        pass
    except Exception as exc:
        print(f"[PaytableMapper] could not mirror template into PaytableTemplates: {exc}")

    # Also save a copy in the project root folder (config ``output_dir``, or
    # the PSD's directory) so the mapped paytable always travels with the game
    # files — even for templates authored straight inside the PaytableTemplates
    # library. The folder is only skipped when neither candidate exists or both
    # live inside the library (a library-internal copy is never written, so
    # auto-saves can never grow an endless ``_mapped`` chain there).
    root_path = ""
    try:
        root_candidates = []
        if _generated:
            pass
        elif base_dir and os.path.isdir(base_dir):
            root_candidates.append(os.path.abspath(base_dir))
        psd_dir = os.path.dirname(os.path.abspath(psd_path)) if psd_path and not _generated else ""
        if psd_dir and os.path.isdir(psd_dir):
            root_candidates.append(os.path.abspath(psd_dir))
        root_dir = ""
        expected_name = f"{base_safe_name}_mapped.json"
        for candidate in root_candidates:
            try:
                from . import paytable_templates as _pt
                lib_dir_nc = os.path.normcase(os.path.normpath(os.path.abspath(_pt.templates_dir()))).rstrip("\\/")
            except Exception:
                lib_dir_nc = ""
            cand_nc = os.path.normcase(os.path.normpath(candidate)).rstrip("\\/")
            inside_library = bool(lib_dir_nc) and (
                cand_nc == lib_dir_nc or cand_nc.startswith(lib_dir_nc + os.sep)
            )
            if inside_library:
                continue
            if candidate.lower().endswith(expected_name.lower()):
                continue
            root_dir = candidate
            break
        if root_dir and os.path.isdir(root_dir):
            root_copy = os.path.abspath(os.path.join(root_dir, expected_name))
            existing_targets = {
                os.path.normcase(os.path.abspath(p))
                for p in (out_path, library_path)
                if p
            }
            if os.path.normcase(root_copy) not in existing_targets:
                with open(root_copy, "w", encoding="utf-8") as f:
                    json.dump(document, f, indent=2)
                root_path = root_copy
    except Exception as exc:
        print(f"[PaytableMapper] could not copy template into project root: {exc}")

    new_cfg = dict(cfg)
    ds = dict(new_cfg.get("dynamic_settings") or {})
    ds["template_json"] = out_path
    new_cfg["dynamic_settings"] = ds
    return {
        "ok": True,
        "path": out_path,
        "library_path": library_path,
        "root_path": root_path,
        "mappings": len(mappings),
    }, new_cfg


def _auto_paytable_template(excel_path, sheet_name, options=None):
    """Generate an auto-fitted (unmapped) paytable template for a sheet.

    Scans the sheet's symbol structure and generates a layout sized to it,
    naming each cell for its real detected symbol (top row first, then lower
    row) so the automapper fills it by name and the live-sheet render filter
    keeps the lower band. The optional ``options`` dict steers the layout:

      * ``placement`` — ``"right"`` (default) / ``"left"`` / ``"below"``: where
        each symbol's pay & value columns sit relative to its icon. This is
        what stamps the pay/value ``vertical_align`` hint (center beside the
        icon, top below it) that :func:`_slot_valign` later honors.
      * ``rows`` / ``cols`` — grid shape (positive int, or ``None``/absent =
        auto). When given, all symbols fill a rows x cols grid row-major and
        rows grow so none are dropped; both absent = sheet-driven bands.

    Returns a full mapped-paytable template dict (slots only, no mappings)."""
    from . import paytable_layouts

    opts = options if isinstance(options, dict) else {}
    placement = str(opts.get("placement") or "right").strip().casefold()
    if placement not in ("right", "left", "below"):
        placement = "right"

    def _dim(value):
        try:
            n = int(value)
        except (TypeError, ValueError):
            return None
        if n < 1:
            return None
        return min(n, 8)  # generous ceiling; auto-fit grows rows past this anyway

    rows = _dim(opts.get("rows"))
    cols = _dim(opts.get("cols"))

    structure = paytable_sheet_structure(excel_path, sheet_name)
    top = structure.get("top", 0)
    lower = structure.get("lower", 0)
    keys = [k for k in (structure.get("block_keys") or []) if k]
    if (top + lower) <= 0:
        top, lower = 5, 5  # no detectable symbols -> a familiar full grid
        keys = []
    top_names = keys[:top] or None
    lower_names = keys[top:top + lower] or None
    return paytable_layouts.generate_paytable_layout(
        top, lower,
        pay_rows=structure.get("max_pay_rows") or 3,
        has_wild=structure.get("has_wild", False),
        top_names=top_names,
        lower_names=lower_names,
        placement=placement,
        rows=rows,
        cols=cols,
    )


def auto_map_page(cfg, sheet_name, layout_name="", options=None):
    """Zero-map convention path for paytables (the artist happy-path).

    Chains the existing convention engine end-to-end with **no** manual mapping
    and **no** new render logic: resolve a bundled/user paytable layout ->
    classify + auto-map every ``@slot.*`` against the conventionally-named
    sheet (cell refs, symbols, pay/value blocks, text — via
    ``automap_paytable_slots``) -> ``save_paytable_mapping`` writes the mapped
    JSON and registers it as the global ``dynamic_settings.template_json`` so
    the dynamic router renders it on the next build.

    Returns ``(result, new_cfg)`` where result is
    ``{"ok", "error", "path", "layout", "sheet_name", "mapped", "unmapped",
       "warnings"}``. The caller persists ``new_cfg`` exactly as it does for
    ``save_paytable_mapping``.
    """
    from . import paytable_layouts

    sheet_name = str(sheet_name or "").strip()
    excel_path = str((cfg or {}).get("excel_path") or "").strip()
    if not excel_path or not os.path.isfile(excel_path):
        return {"ok": False, "error": "Choose an Excel file first.", "unmapped": [], "warnings": []}, cfg
    if not sheet_name:
        return {"ok": False, "error": "No sheet selected.", "unmapped": [], "warnings": []}, cfg

    # Resolve a layout template. An empty name resolves to the default layout
    # ("auto"); the auto layout is GENERATED to fit this sheet's own symbol
    # counts, while any explicit named layout keeps its fixed slots.
    layout_name = str(layout_name or "").strip()
    if not layout_name:
        try:
            default = next((l for l in paytable_layouts.list_paytable_layouts() if l.get("default")), None)
        except Exception:
            default = None
        layout_name = (default or {}).get("name") or "auto"

    template = None
    style_maps = None
    card_tpl = (options or {}).get("card_template") if isinstance(options, dict) else None
    if isinstance(card_tpl, dict):
        # a card template (built-in or the user's): cards for this sheet's own symbols
        from ..dynamic_pages.paytable import card_templates as _cards

        from .. import workbook_cache as _wbc

        _structure = paytable_sheet_structure(excel_path, sheet_name)
        # the title goes where every other page's heading is (canvas px -> the page-shaped design frame)
        from .. import bg_place as _bgp

        _ctx = {"canvas": (float(cfg.get("c_width") or 1920), float(cfg.get("c_height") or 1080)),
                "bg_area": _bgp.area(cfg),              # a background on part of the page: the paytable goes there
                "heading_top": float(cfg.get("heading_top_margin") or 150),
                # the other pages' margins (canvas px): a design that keeps to them (page.use_page_margins)
                "page_margins": (float(cfg.get("margin_x") or 0), float(cfg.get("bottom_margin") or 0)),
                "heading_size": float(cfg.get("h_size") or 60),
                "body_size": float(cfg.get("b_size") or 0),      # the paragraph size of the other pages (canvas px)
                "icon_folder": str(cfg.get("icon_folder") or ""),
                "icon_mappings": cfg.get("icon_mappings") or {}}
        try:                                # the parsed workbook is reused between previews (fast editing)
            with _wbc.borrow(excel_path, data_only=True) as _wb:
                _ws = _wb[sheet_name] if sheet_name in _wb.sheetnames else None
                template, style_maps = _cards.compile_template(card_tpl, _structure, _ws, _ctx)
        except (OSError, KeyError, ValueError):
            template, style_maps = _cards.compile_template(card_tpl, _structure, None, _ctx)
        layout_name = "cards"
    elif layout_name == "auto":
        template = _auto_paytable_template(excel_path, sheet_name, options)
    else:
        template = paytable_layouts.get_paytable_layout(layout_name)

    if template is None:
        template = paytable_layouts.get_paytable_layout("simple")
        layout_name = "simple"
    if not isinstance(template, dict) or not (template.get("slots") or {}):
        return {"ok": False, "error": f"Layout '{layout_name or 'default'}' has no slots.", "unmapped": [], "warnings": []}, cfg

    # Classify + auto-map every slot against the sheet (reuse the convention
    # engine verbatim; it returns a mappings LIST + an unmapped list).
    automap = automap_paytable_slots(template, excel_path, sheet_name)
    mappings = automap.get("mappings") or []
    unmapped = automap.get("unmapped") or []
    overflow, overflow_note = [], ""
    if style_maps is not None:
        from ..dynamic_pages.paytable import card_templates as _cards

        # 2nd pass: the rules lines the auto-mapper found go into the template's text boxes
        _rules = next((str(m.get("source") or "") for m in mappings
                       if isinstance(m, dict) and m.get("slot") == "@slot.text"), "")
        _ctx["rules_cells"] = [c.strip() for c in _rules.split(",") if c.strip()]
        template, style_maps = _cards.compile_template(card_tpl, _structure, _ws, _ctx)
        auto_list = mappings
        mappings = _cards.merge_mappings(auto_list, style_maps, excel_path)
        # numbers that don't fit their card: shrink the text or grow the cards (the user's choice)
        _font = str(cfg.get("b_font") or "ArialMT")
        _dw, _dh = _cards.design_frame(_ctx["canvas"])
        _scale = min(_ctx["canvas"][0] / _dw, _ctx["canvas"][1] / _dh)
        overflow = _cards.measure_overflow(template, mappings, _font, _scale)
        mode = str((card_tpl.get("card") or {}).get("overflow") or "")
        if overflow and mode == "grow":
            grown = _cards.grown(card_tpl, overflow)
            _base_geo = (template.get("mapper_meta") or {}).get("band_geo")
            template, style_maps = _cards.compile_template(grown, _structure, _ws, _ctx)
            # the studio reads each row's card size back into the design when it edits: give it the
            # design's own size, never this render's enlarged one (else every edit grows the cards again)
            if _base_geo is not None:
                template.setdefault("mapper_meta", {})["band_geo"] = _base_geo
            mappings = _cards.merge_mappings(auto_list, style_maps, excel_path)
            overflow = _cards.measure_overflow(template, mappings, _font, _scale)
            if overflow:                                   # no room left to grow: shrink what still doesn't fit
                _cards.shrink_slots(mappings, overflow)
                overflow_note = "Some cards had no room to grow — their numbers were made smaller."
        elif overflow and mode != "grow":
            _cards.shrink_slots(mappings, overflow)       # "shrink", or not decided yet (the studio asks)
        have = {m.get("slot") for m in mappings}
        unmapped = [u for u in unmapped if (u.get("slot") if isinstance(u, dict) else u) not in have]

    if (options or {}).get("dry_run"):
        # the studio's live view: the mapped layout only — nothing rendered, nothing written
        return {"ok": True, "error": "", "sheet_name": sheet_name, "_template": template, "_mappings": mappings,
                "overflow": overflow, "unmapped": unmapped, "warnings": []}, cfg

    # save_paytable_mapping accepts a mappings list and returns (result, new_cfg)
    # with dynamic_settings.template_json set to the saved path.
    payload = {
        "template": template,
        "mappings": mappings,
        "sheet_name": sheet_name,
        "template_id": template.get("template_id") or "AutoPaytable",
        "slot_prefix": template.get("slot_prefix") or "@slot",
        "psd_path": template.get("source_psd") or "",
    }
    if style_maps is not None:
        # card layouts are regenerated from the card template: keep them out of game folders
        _safe = re.sub(r"[^A-Za-z0-9._-]+", "_", f"{os.path.splitext(os.path.basename(excel_path))[0]}__{sheet_name}")
        payload["output_path"] = os.path.join(os.path.expanduser("~"), "PsHelpScreenTool_CardLayouts", _safe + ".json")
        os.makedirs(os.path.dirname(payload["output_path"]), exist_ok=True)
    result, new_cfg = save_paytable_mapping(cfg, payload)
    if not result.get("ok"):
        return {"ok": False, "error": result.get("error") or "Could not save the mapped paytable.", "unmapped": unmapped, "warnings": []}, cfg

    warnings = []
    if unmapped:
        warnings.append(f"{len(unmapped)} slot(s) had no matching Excel data and will render empty.")
    if overflow_note:
        warnings.append(overflow_note)

    return {
        "ok": True,
        "error": "",
        "path": result.get("path", ""),
        "layout": layout_name,
        "sheet_name": sheet_name,
        "mapped": result.get("mappings", len(mappings)),
        "unmapped": unmapped,
        "warnings": warnings,
        # Private hand-off for the /api/auto_page route to mint a preview token
        # (the token registry lives in server.py). The route pops these before
        # returning the result to the client.
        "_template": template,
        "_mappings": mappings,
        "overflow": overflow,
    }, new_cfg


def preflight(cfg):
    """Structured, side-effect-free pre-build check.

    Assembles the facts the scanners already compute into a single
    blocking/warning report so artists see problems BEFORE a build runs
    (instead of alien mid-build popups). This never writes files or mutates
    config — it only reads and reports.

    Returns ``{"ok": bool, "blocking": [item...], "warnings": [item...]}``
    where each item is ``{"code", "message", "fix"}`` and ``ok`` is True only
    when there are no blocking items.
    """
    cfg = cfg or {}
    blocking = []
    warnings = []

    def _add(bucket, code, message, fix=""):
        bucket.append({"code": code, "message": message, "fix": fix})

    # --- Excel workbook -----------------------------------------------------
    excel_path = str(cfg.get("excel_path") or "").strip()
    excel = None
    if not excel_path:
        _add(blocking, "excel_missing", "No Excel workbook is set.", "Choose an Excel file in Project.")
    elif not os.path.isfile(excel_path):
        _add(blocking, "excel_not_found", f"Excel file not found: {excel_path}", "Re-select the workbook — it may have moved or been renamed.")
    else:
        excel = scan_excel(excel_path)
        if not excel.get("ok"):
            _add(blocking, "excel_unreadable", excel.get("error") or "Could not open the Excel workbook.", "Close the file in Excel and try again, or pick a different workbook.")
            excel = None
        elif cfg.get("active_game"):
            # a game's workspace builds only that game's Excel (its PSDs must never take another game's text)
            try:
                from .. import games as _games

                _game = _games.get(cfg.get("active_game"))
                if _game is not None and not _games.belongs(_game, excel_path):
                    _add(blocking, "excel_other_game",
                         f"This Excel doesn't look like {_game.get('name') or 'this game'}'s AGR — it has different symbols and sheets.",
                         "Switch to that game's workspace or make a new one on the Dashboard; or, if it really is a new "
                         "revision of this game, pick it again in Project and choose \"It is " + (_game.get("name") or "this game") + "\".")
            except Exception:
                pass

    # --- Canvas -------------------------------------------------------------
    cw = _as_int(cfg.get("c_width"), 0)
    ch = _as_int(cfg.get("c_height"), 0)
    if cw <= 0 or ch <= 0:
        _add(blocking, "canvas_invalid", f"Canvas size is invalid ({cw}x{ch}).", "Set a positive width and height (e.g. 1920x1080).")

    # --- Sheets that will build --------------------------------------------
    # Sheet NAMES are reliable (from wb.worksheets); row/col dimensions are NOT
    # under openpyxl read_only (they come back 0 for dimensionless workbooks),
    # so we validate presence only — never declare a sheet "empty" from dims.
    if excel:
        valid = {str(s.get("name", "")).strip() for s in excel.get("sheets", [])}
        if not valid:
            _add(blocking, "no_sheets", "The workbook has no readable sheets.", "Open the workbook and confirm it contains data.")
        selected = [str(s).strip() for s in (cfg.get("selected_sheets") or []) if str(s).strip()]
        if selected:
            missing = [s for s in selected if s not in valid]
            if missing:
                _add(blocking, "sheet_missing", "Selected sheet(s) are not in the workbook: " + ", ".join(missing), "Re-scan the workbook or update the page selection.")

    # --- Icons --------------------------------------------------------------
    if excel_path and os.path.isfile(excel_path):
        icon_folder = str(cfg.get("icon_folder") or "").strip()
        if not icon_folder:
            _add(warnings, "icon_folder_missing", "No icon folder is set.", "Point at the game's icon/symbol folder so <token> markers resolve.")
        else:
            # same rules as the build: the game's saved symbol links (icon_mappings)
            # count, and text placeholders (<GAME NAME>, <dynamic Text>) aren't symbols
            from .. import symbol_tokens

            try:
                missing_icons = symbol_tokens.check(cfg).get("unresolved") or []
            except Exception:
                missing_icons = []
            if missing_icons:
                shown = ", ".join(missing_icons[:8]) + ("…" if len(missing_icons) > 8 else "")
                _add(warnings, "icons_unresolved", f"{len(missing_icons)} icon token(s) have no matching file: {shown}", "Add the missing PNGs to the icon folder or remap them in the Icon Mapper.")

    # --- Paylines (drawn from the Excel table: wrong data must not build) ---
    if excel_path and os.path.isfile(excel_path):
        try:
            from .. import workbook_cache
            from ..dynamic_pages import paylines as _pl

            with workbook_cache.borrow(excel_path, data_only=True) as _wb:   # the cached parse
                _wanted = {str(s) for s in (cfg.get("selected_sheets") or [])}
                _ds = cfg.get("dynamic_settings") if isinstance(cfg.get("dynamic_settings"), dict) else {}
                _plcfg = _pl.settings_for(_ds, _as_int(cfg.get("c_width"), 1920))
                for _name in _wb.sheetnames:
                    if _wanted and _name not in _wanted:
                        continue
                    _ws = _wb[_name]
                    if not _pl.is_payline_page(_ws):
                        continue
                    _parsed = _pl.parse(_ws, _plcfg.get("rows", 3))
                    for _err in _parsed["errors"][:6]:
                        _add(blocking, "paylines_data", _err, "Fix the payline table in the Excel, or untick this sheet.")
                    for _prob in _pl.validate_layout(_plcfg):
                        _add(blocking, "paylines_settings", _prob, "Fix it in Paylines.")
                    if not _parsed["errors"]:
                        _on = [_p for _p in _pl.page_list(_parsed, _plcfg) if _p["on"]]
                        if not _on:
                            _add(warnings, "paylines_none", f'"{_name}": every payline page is switched off — none will be built.',
                                 "Tick the pages to build in Paylines.")
                        for _p in _on:
                            _label, _count = _p["denoms"], _p["count"]
                            _pos, _fit = _pl.layout(_count, _plcfg, _as_int(cfg.get("c_width"), 1920),
                                                    _as_int(cfg.get("c_height"), 1080), _parsed["reels"], _parsed["rows"])
                            if _fit:
                                _add(warnings, "paylines_fit", f"{_pl.page_name(_name, _label, _count, _plcfg)}: {_fit}",
                                     "Adjust the layout in Paylines.")
        except Exception:
            pass

    # --- Output -------------------------------------------------------------
    if not str(cfg.get("output_dir") or "").strip():
        _add(warnings, "output_dir_missing", "No output folder is set.", "Set an output folder in Output, or the build uses a default location.")

    return {"ok": not blocking, "blocking": blocking, "warnings": warnings}


def save_table_mapper_mapping(cfg, payload):
    """Build + save a mapped table JSON and update config keys in a copy of cfg.

    Returns (result_dict, updated_config). ``mapped_table_jsons`` is stored as
    a newline-separated path list (the format load_mapped_table_templates
    expects); ``json_sheet_overrides`` maps absolute JSON path -> sheet names.

    When ``payload["output_path"]`` is set, the JSON is saved there instead of
    the default ``mapped_tables/`` folder. Mappings saved for the same sheet
    (page) override older ones: previous entries targeting the same sheet are
    removed from the config list and reported in the result as ``removed``.
    """
    from ps_autotypesetter.table_mapping import save_mapped_table_template

    template = payload.get("template") or {}
    mappings = payload.get("mappings") or []
    if not isinstance(template, dict) or not (template.get("slots") or {}):
        return {"ok": False, "error": "Missing template slots."}, cfg
    sheet_name = _raw_sheet(payload.get("sheet_name"))
    table_name = str(payload.get("table_name") or "").strip() or "table"
    source_range = str(payload.get("source_range") or "").strip() or table_mapper_source_range(mappings)
    psd_path = str(payload.get("psd_path") or "").strip()

    out_path = str(payload.get("output_path") or "").strip()
    if not out_path:
        base_dir = str((cfg or {}).get("output_dir") or "").strip()
        if not base_dir or not os.path.isdir(base_dir):
            base_dir = os.path.dirname(os.path.abspath(psd_path)) if psd_path else ""
        out_dir = os.path.join(base_dir, "mapped_tables") if base_dir else os.path.abspath("mapped_tables")
        safe_name = re.sub(r"[^A-Za-z0-9_\-]+", "_", table_name).strip("_") or "table"
        out_path = os.path.join(out_dir, f"{safe_name}_mapped.json")
    out_path = os.path.abspath(out_path)

    try:
        _, warnings = save_mapped_table_template(
            template, sheet_name, table_name, source_range, mappings, out_path,
            insert_mode=str(payload.get("insert_mode") or "after_row"),
            insert_after_row=_as_int(payload.get("insert_after_row"), 0),
            marker=str(payload.get("marker") or "").strip(),
            absolute_x=payload.get("absolute_x"),
            absolute_y=payload.get("absolute_y"),
            margin_before=_as_int(payload.get("margin_before"), 30),
            margin_after=_as_int(payload.get("margin_after"), 30),
            fit_mode=str(payload.get("fit_mode") or "scale"),
            scale_if_needed=bool(payload.get("scale_if_needed", True)),
            alternate_template="",
            source_sheets=payload.get("source_sheets") or None,
        )
    except Exception as exc:
        return {"ok": False, "error": str(exc)}, cfg

    new_cfg = dict(cfg)
    ts = dict(new_cfg.get("table_style") or {})
    existing = ts.get("mapped_table_jsons") or ""
    paths = [p for p in re.split(r"[\n;]+", str(existing)) if str(p).strip()]
    overrides = dict(ts.get("json_sheet_overrides") or {})
    kept = []
    removed = []
    if sheet_name:
        sheet_key = sheet_name.casefold()
        for p in paths:
            p_abs = os.path.abspath(p)
            if p_abs == out_path:
                continue
            prev_sheets = overrides.get(p_abs) or overrides.get(p) or []
            prev_keys = {str(s).strip().casefold() for s in prev_sheets if str(s).strip()}
            if sheet_key in prev_keys:
                removed.append(p_abs)
                continue
            kept.append(p_abs)
    else:
        kept = [os.path.abspath(p) for p in paths]
    if out_path not in kept:
        kept.append(out_path)
    for key in list(overrides.keys()):
        if os.path.abspath(key) in removed:
            del overrides[key]
    ts["mapped_table_jsons"] = "\n".join(kept)
    overrides[out_path] = [sheet_name] if sheet_name else []
    ts["json_sheet_overrides"] = overrides
    new_cfg["table_style"] = ts
    return {
        "ok": True,
        "path": out_path,
        "removed": removed,
        "warnings": warnings or [],
        "table_style": ts,
    }, new_cfg


def check_photoshop() -> dict:
    """Status dot: is a Photoshop (any version) open?

    Never launches Photoshop and runs no script (it is polled): the version
    comes from the running executable's file info, so a version that is not
    the one registered for automation (e.g. 2023 open, 2026 registered) still
    reports as available.
    """
    from .. import photoshop_bridge

    running = photoshop_bridge.running_photoshops()
    if not running:
        return {"available": False, "error": "Photoshop is not running."}
    exe = running[0][1]
    version = "?"
    try:
        import win32api
        info = win32api.GetFileVersionInfo(exe, "\\")
        ms, ls = info["FileVersionMS"], info["FileVersionLS"]
        version = f"{ms >> 16}.{ms & 0xFFFF}.{ls >> 16}"
    except Exception:
        pass
    return {"available": True, "version": version, "exe": exe, "route": photoshop_bridge.describe()["route"]}


_seed_default_preset()


# ── paytable layout learned from an artist PSD ──────────────────────────────
def artist_psd_groups(psd_path: str) -> dict:
    """Top-level page groups of an artist PSD (lazy open: text is parsed on demand)."""
    from ps_autotypesetter.artist_design import psd_reader

    psd = psd_reader.open_psd(psd_path)
    groups = []
    for layer in psd:
        if layer.is_group():
            groups.append({"name": layer.name, "visible": bool(layer.visible),
                           "layers": sum(1 for _ in layer.descendants())})
    guess = next((g["name"] for g in groups if "paytable" in g["name"].casefold()), "")
    return {"ok": True, "width": psd.width, "height": psd.height, "groups": groups, "guess": guess}


def learn_artist_paytable(psd_path: str, group: str, excel_path: str, sheet_name: str,
                          icon_folder: str = "", icon_mappings: dict = None, name: str = "",
                          symbol_overrides: dict = None, progress=None) -> dict:
    """Learn `group`'s paytable layout and save it as a mapped-paytable template.

    Design art goes to ``<templates>/<name>_assets``; re-learning under the same
    name (e.g. after fixing a symbol in the UI) replaces that template.
    """
    import re as _re

    from openpyxl import load_workbook

    from ps_autotypesetter.artist_design import psd_reader
    from ps_autotypesetter.artist_design.learn_paytable import learn_paytable

    from .. import workbook_cache
    from . import paytable_templates

    say = progress if callable(progress) else (lambda *a, **k: None)
    if not psd_path or not os.path.isfile(psd_path):
        return {"ok": False, "error": "Artist PSD not found."}
    if not excel_path or not os.path.isfile(excel_path):
        return {"ok": False, "error": "Choose the Excel file in Project first."}
    say("Opening the artist PSD…", 15)
    psd = psd_reader.open_psd(psd_path)
    with workbook_cache.borrow(excel_path, data_only=True) as wb:
        if sheet_name not in wb.sheetnames:
            return {"ok": False, "error": f"Sheet '{sheet_name}' is not in the workbook."}
        name = (name or f"{os.path.splitext(os.path.basename(psd_path))[0]}_{group}").strip()
        safe = _re.sub(r"[^A-Za-z0-9_\-]+", "_", name).strip("_") or "artist_paytable"
        assets = os.path.join(paytable_templates.templates_dir(), f"{safe}_assets")
        steps = iter(range(25, 90, 15))
        res = learn_paytable(psd, group, wb[sheet_name], icon_folder, assets, icon_mappings or {},
                             progress=lambda m: say(m, next(steps, 90)), symbol_overrides=symbol_overrides)
    template = res["template"]
    template["source_psd"] = psd_path
    template["mapper_meta"]["sheet_name"] = sheet_name
    template["mapper_meta"]["artist_design"]["source_psd"] = psd_path
    say("Saving the template…", 95)
    path = paytable_templates.save_template(template, name)
    report = res["report"]
    meta = template["mapper_meta"]["artist_design"]
    return {"ok": True, "path": path, "name": os.path.splitext(os.path.basename(path))[0],
            "slots": len(template.get("slots") or {}), "cards": len(meta.get("cards") or []),
            "group": group, "psd_path": psd_path, "sheet_name": sheet_name, "report": report}


# ── symbol choices belong to the Excel file they were made for ─────────────
def excel_key(path) -> str:
    """Identity of a workbook for remembered choices: its file name, case-folded."""
    return os.path.basename(str(path or "")).strip().casefold()


def drop_foreign_symbol_picks(mapped, excel_path) -> int:
    """Forget hand-picked card symbols that are not for THIS workbook.

    A pick applies only to the workbook it was made for (``pinned_excel``);
    picks saved before that was recorded can't be placed, so they are ignored
    too. Those cards auto-map from the current Excel again (<pic4> -> PIC4.png).
    """
    key = excel_key(excel_path)
    if not key or not isinstance(mapped, dict):
        return 0
    dropped = 0
    for spec in mapped.values():
        if not isinstance(spec, dict) or not (spec.get("asset_path") or spec.get("symbol_pinned")
                                              or spec.get("source_pinned")):
            continue
        if excel_key(spec.get("pinned_excel")) != key:
            # hand-picked symbols AND hand-picked cells: only for the workbook they were made on
            spec.pop("asset_path", None)
            spec.pop("symbol_pinned", None)
            spec.pop("source_pinned", None)
            dropped += 1
    return dropped


def swap_scoped_icon_mappings(cfg: dict, previous_excel) -> None:
    """Relinks made with "Everywhere <token> appears" live per workbook
    (``icon_mappings_by_excel``); switching the project's Excel swaps them."""
    scoped = cfg.get("icon_mappings_by_excel") or {}
    old = scoped.get(excel_key(previous_excel)) or {}
    new = scoped.get(excel_key(cfg.get("excel_path"))) or {}
    if not (old or new):
        return
    mappings = dict(cfg.get("icon_mappings") or {})
    for token, path in old.items():
        if mappings.get(token) == path:
            mappings.pop(token, None)
    mappings.update(new)
    cfg["icon_mappings"] = mappings


# ── which cells of the paytable sheet the page actually renders ────────────
_CELL_REF_RE = re.compile(r"^\$?([A-Za-z]{1,3})\$?(\d+)$")


def _expand_cell_refs(source):
    """'F13,F14' / 'B7:C9' / 'Sheet!D4' -> {'F13', 'F14', ...} (this sheet's cells only)."""
    from openpyxl.utils import column_index_from_string, get_column_letter

    out = set()
    for part in re.split(r"[,;\n]+", str(source or "")):
        part = part.strip()
        if not part:
            continue
        if "!" in part:
            part = part.split("!", 1)[1]
        if ":" in part:
            a, b = part.split(":", 1)
            ma, mb = _CELL_REF_RE.match(a.strip()), _CELL_REF_RE.match(b.strip())
            if not (ma and mb):
                continue
            c0, c1 = sorted((column_index_from_string(ma.group(1).upper()), column_index_from_string(mb.group(1).upper())))
            r0, r1 = sorted((int(ma.group(2)), int(mb.group(2))))
            if (c1 - c0 + 1) * (r1 - r0 + 1) > 5000:
                continue
            for c in range(c0, c1 + 1):
                for r in range(r0, r1 + 1):
                    out.add(f"{get_column_letter(c)}{r}")
        else:
            m = _CELL_REF_RE.match(part)
            if m:
                out.add(f"{m.group(1).upper()}{int(m.group(2))}")
    return out


def paytable_sheet_coverage(template, mappings, ws, excel_path="", max_rows=250, max_cols=16):
    """Grid of the paytable sheet with each filled cell marked used / not used.

    Mirrors the renderer: drop symbol picks of other workbooks, lay the card
    grid out from Excel, re-bind stale cells, skip cards the sheet lacks. Used
    = a pay/value/text slot reads the cell, a drawn card shows the symbol in
    that anchor cell, or the cell is the page heading.
    """
    from openpyxl.utils import get_column_letter

    from ps_autotypesetter.dynamic_pages.paytable import card_grid
    from ps_autotypesetter.dynamic_pages.router import _is_mapper_design

    from . import ps_actions

    mapped = {k: dict(v) for k, v in ps_actions._mapping_dict(mappings or (template or {}).get("mappings") or {}).items()}
    drop_foreign_symbol_picks(mapped, excel_path)
    tmpl = dict(template or {}, mappings=mapped)
    if _is_mapper_design(tmpl):
        try:
            tmpl = card_grid.adapt(tmpl, ws)
            mapped = {k: dict(v) for k, v in ps_actions._mapping_dict(tmpl.get("mappings") or {}).items()}
        except Exception:
            pass
    ps_actions._sanitize_preview_mappings(mapped, ws, tmpl)
    live = _paytable_live_slot_data(ws, tmpl)
    auto = automap_paytable_slots_ws(ws, tmpl) or {}
    anchors = {str(b.get("key")): f"{get_column_letter(int(b['col']))}{int(b['row'])}"
               for b in auto.get("blocks") or [] if b.get("row") and b.get("col")}
    slots = tmpl.get("slots") or {}
    used, why = set(), {}
    for slot, spec in mapped.items():
        if slot not in slots:
            continue
        try:
            if live is not None and paytable_slot_is_dead(slot, spec, live):
                continue
        except Exception:
            pass
        mode = str(spec.get("mode") or "").casefold()
        if mode in ("excel", "excel_text", "mixed") or spec.get("role"):
            for ref in _expand_cell_refs(spec.get("source")):
                used.add(ref)
                why.setdefault(ref, slot)
        if mode == "icon":
            sym = _paytable_norm_name(spec.get("symbol") or str(spec.get("token") or "").strip("<> "))
            if sym in anchors:
                used.add(anchors[sym])
                why.setdefault(anchors[sym], slot)
    heading = ps_actions._preview_page_heading(ws, tmpl)
    rows, unused = [], []
    max_r = min(int(ws.max_row or 0), max_rows)
    max_c = min(int(ws.max_column or 0), max_cols)
    for r in range(1, max_r + 1):
        cells = []
        for c in range(1, max_c + 1):
            v = ws.cell(row=r, column=c).value
            if v is None or (isinstance(v, str) and not v.strip()):
                continue
            ref = f"{get_column_letter(c)}{r}"
            text = str(v).strip()
            is_used = ref in used or (heading and text == heading)
            if heading and text == heading:
                why.setdefault(ref, "title")
            cells.append({"ref": ref, "c": c, "v": text[:200], "used": bool(is_used), "slot": why.get(ref, "")})
            if not is_used:
                unused.append({"ref": ref, "v": text[:120]})
        if cells:
            rows.append({"r": r, "cells": cells})
    return {"ok": True, "rows": rows, "cols": max_c, "used": len([1 for row in rows for c in row["cells"] if c["used"]]),
            "unused": unused, "heading": heading or ""}
