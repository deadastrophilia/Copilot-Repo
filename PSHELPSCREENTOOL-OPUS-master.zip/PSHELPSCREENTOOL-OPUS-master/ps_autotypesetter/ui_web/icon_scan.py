"""Offline-safe icon scanning for the web UI (openpyxl + icon_mapping only)."""

from __future__ import annotations

import os

from ps_autotypesetter.icon_mapping import scan_excel_icon_tokens
from ps_autotypesetter.production_features import missing_icon_tokens


def list_icon_files_web(icon_folder: str) -> list:
    files = []
    if not icon_folder or not os.path.isdir(icon_folder):
        return files
    try:
        entries = sorted(os.listdir(icon_folder))
    except OSError:
        return files
    for fn in entries:
        low = fn.lower()
        if low.endswith((".png", ".jpg", ".jpeg", ".gif", ".svg", ".bmp")):
            files.append({
                "name": fn,
                "size": os.path.getsize(os.path.join(icon_folder, fn)),
                "path": os.path.join(icon_folder, fn),
            })
    return files


def scan_icon_status_web(excel_path: str, icon_folder: str, icon_mappings: dict = None) -> dict:
    result = {
        "ok": False,
        "error": "",
        "tokens": [],
        "missing": [],
        "matched": [],
        "icon_count": 0,
    }
    if not excel_path or not os.path.isfile(excel_path):
        result["error"] = "Excel file not found."
        return result
    if not icon_folder or not os.path.isdir(icon_folder):
        # still say which symbols the Excel needs: every one of them is missing
        result["error"] = "Icon folder not found."
        try:
            tokens = sorted(set(scan_excel_icon_tokens(excel_path)))
            result.update({"tokens": tokens, "missing": tokens, "no_folder": True})
        except Exception:
            pass
        return result

    try:
        tokens = scan_excel_icon_tokens(excel_path)
        missing = missing_icon_tokens(excel_path, icon_folder, icon_mappings)
        matched = sorted(set(tokens) - set(missing))
        result.update(
            {
                "ok": True,
                "tokens": sorted(set(tokens)),
                "missing": sorted(set(missing)),
                "matched": matched,
                "icon_count": len(list_icon_files_web(icon_folder)),
            }
        )
    except Exception as e:
        result["error"] = f"Icon scan failed: {e}"
    return result
