"""Export Symbols from a PSD.

Pure-Python PSD reading via psd-tools (no running Photoshop required):
list the PNG/JPG pixel layers, smart objects, shape/text layers and groups
of a user-chosen PSD, render per-layer previews, and export the selected
layers as trimmed (alpha-cropped), transparent-background PNG icons.
"""

from __future__ import annotations

import os
import re
import threading

try:
    from psd_tools import PSDImage

    _PSD_TOOLS_OK = True
except Exception:  # pragma: no cover
    PSDImage = None
    _PSD_TOOLS_OK = False

# Layer kinds that never carry icon pixels (drop them from the picker).
_IGNORED_KINDS = {"adjustment", "fill", "sectiondivider"}

_cache_lock = threading.Lock()
_cache = {}  # psd_path -> (mtime, PSDImage, layers_info)


def psd_tools_available() -> bool:
    return _PSD_TOOLS_OK


# ---------------------------------------------------------------- helpers


def _open_psd(psd_path: str):
    """Open a PSD once (cached by path + mtime) and return (psd, layers)."""
    if not _PSD_TOOLS_OK:
        raise RuntimeError("psd-tools is not installed (pip install psd-tools)")
    key = os.path.abspath(psd_path)
    try:
        mtime = os.path.getmtime(key)
    except OSError:
        mtime = -1
    with _cache_lock:
        cached = _cache.get(key)
        if cached and cached[0] == mtime:
            return cached[1], cached[2]
        psd = PSDImage.open(key)
        layers = _collect_layers(psd)
        _cache[key] = (mtime, psd, layers)
        if len(_cache) > 3:  # keep at most 3 PSDs open at once
            _cache.pop(next(iter(_cache)))
        return psd, layers


def _collect_layers(psd) -> list:
    """Flatten the layer tree into keyed layer entries (document order)."""
    out = []

    def walk(container, prefix):
        for layer in container:
            kind = getattr(layer, "kind", "") or ""
            if kind in _IGNORED_KINDS:
                continue
            name = str(layer.name or "")
            path = f"{prefix}/{name}" if prefix else name
            try:
                bbox = layer.bbox
                w = max(0, int(bbox[2] - bbox[0]))
                h = max(0, int(bbox[3] - bbox[1]))
            except Exception:
                w = h = 0
            entry = {
                "key": str(len(out)),
                "name": name,
                "path": path,
                "kind": kind,
                "w": w,
                "h": h,
                "visible": bool(getattr(layer, "visible", True)),
                "layer": layer,
            }
            if kind == "group":
                out.append(entry)
                walk(layer, path)
            elif w > 0 and h > 0:
                out.append(entry)

    walk(psd, "")
    return out


def _by_key(layers: list, key) -> dict:
    try:
        idx = int(str(key))
        if 0 <= idx < len(layers):
            return layers[idx]
    except (TypeError, ValueError):
        pass
    for info in layers:
        if info["key"] == str(key):
            return info
    return None


def _safe_name(name: str) -> str:
    name = re.sub(r'[\\/:*?"<>|\r\n]+', "_", str(name or "")).strip(" ._")
    return name[:100]


# ---------------------------------------------------------------- public


def list_psd_layers(psd_path: str) -> dict:
    psd, layers = _open_psd(psd_path)
    return {
        "ok": True,
        "psd_path": os.path.abspath(psd_path),
        "width": int(getattr(psd, "width", 0) or 0),
        "height": int(getattr(psd, "height", 0) or 0),
        "layer_count": len(layers),
        "layers": [{k: v for k, v in info.items() if k != "layer"} for info in layers],
    }


def render_layer_image(psd_path: str, key, max_size: int = 0):
    """Render one layer as an RGBA PIL image (optionally downscaled)."""
    _, layers = _open_psd(psd_path)
    info = _by_key(layers, key)
    if info is None:
        raise ValueError("Layer not found.")
    img = info["layer"].composite()
    img = img.convert("RGBA")
    if max_size and (img.width > max_size or img.height > max_size):
        img.thumbnail((max_size, max_size))
    return img


def export_selected_layers(psd_path: str, keys, output_dir: str) -> dict:
    """Export selected layers as trimmed transparent PNG icons.

    Each layer is composited alone, cropped to its non-transparent alpha
    bounding box, and saved as "<sanitized layer name>.png" in output_dir.
    """
    _, layers = _open_psd(psd_path)
    os.makedirs(output_dir, exist_ok=True)
    files, skipped = [], []
    used = {}
    for key in keys:
        info = _by_key(layers, key)
        if info is None:
            skipped.append({"key": str(key), "name": "", "reason": "Layer not found."})
            continue
        if not info["visible"]:
            skipped.append({"key": str(key), "name": info["name"], "reason": "Layer is hidden."})
            continue
        try:
            img = info["layer"].composite().convert("RGBA")
        except Exception as exc:
            skipped.append({"key": str(key), "name": info["name"], "reason": f"Could not render: {exc}"})
            continue
        bbox = img.getbbox()
        if not bbox:
            skipped.append({"key": str(key), "name": info["name"], "reason": "Layer has no visible pixels."})
            continue
        img = img.crop(bbox)
        base = _safe_name(info["name"]) or f"layer_{info['key']}"
        n = used.get(base, 0)
        used[base] = n + 1
        out_name = base if n == 0 else f"{base}_{n + 1}"
        out_path = os.path.join(output_dir, out_name + ".png")
        try:
            img.save(out_path, "PNG")
        except Exception as exc:
            skipped.append({"key": str(key), "name": info["name"], "reason": f"Could not write file: {exc}"})
            continue
        files.append({
            "name": out_name + ".png",
            "path": out_path,
            "w": int(bbox[2] - bbox[0]),
            "h": int(bbox[3] - bbox[1]),
        })
    return {"files": files, "skipped": skipped}