/* Clone a market from its PSD.
   The markets of one game share one design: pick the artist's hand-made PSD of market A, the
   Excel it was made from, and the new market's Excel. The tool keeps the artist's file and gives
   every text layer that shows Excel data the new market's value — positions, layer styles,
   pictures and pages stay exactly as they are — then says what changed and what needs a look.
   Before the first clone of a PSD the artist confirms, once, which sheet each page shows and
   which picture is which symbol (worked out from the PSD itself — no symbols folder); that is
   saved with the game, so the next market of the game goes straight through.
   Then nothing is written until the artist has seen every page that would change: each changed,
   new (a copy of the closest page, for a sheet the AGR added) or deleted page (a sheet the AGR
   dropped — its group gets a red label) is shown before / after, one by one, to approve or keep as
   the artist made it. Pages nothing changes are never touched, and the report says it checked so.
   Server: /api/market_clone/check, /preview, /api/market_clone (market_clone.py), polled through /api/jobs/<id>. */

(() => {
  const MarketClone = (window.MarketClone = {});
  const S = { overlay: null, busy: false, check: null, checkFor: "", stage: "", preview: null, at: 0, decided: {}, edits: {} };
  const $ = (id) => document.getElementById(id);
  const escH = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const show = (t) => escH(String(t ?? "").replace(/\r/g, " ⏎ ").trim());
  const FIELDS = [
    ["mcPsd", "psd", "Market A's PSD", "The artist's hand-made PSD (.psd / .psb)"],
    ["mcExcelA", "excel", "Market A's Excel", "The Excel that PSD was made from"],
    ["mcExcelB", "excel", "New market's Excel", "The data for the new PSD"],
  ];

  MarketClone.open = () => {
    if (S.overlay) { S.overlay.hidden = false; return; }
    const cfg = App.state.config || {};
    const ov = document.createElement("div");
    ov.className = "overlay";
    ov.style.zIndex = "10050";
    ov.innerHTML = `
      <div class="mapper-dialog mc-dialog">
        <div class="canvas-dialog-title">Update Artist Made PSD</div>
        <div class="canvas-sub">Every market of a game looks the same — only the data differs. The artist's PSD is kept as it is;
          only the text layers that show Excel data get the new market's values. Nothing in the original files changes:
          the new PSD is saved next to it.</div>
        <div class="mc-fields">
          ${FIELDS.map(([id, kind, label, hint]) => `<label class="mc-row"><span class="mc-lab" title="${escH(hint)}">${label}</span>
            <input type="text" id="${id}" class="mapper-search" placeholder="${escH(hint)}" spellcheck="false" />
            <button class="btn secondary" data-browse="${id}" data-kind="${kind}">Browse…</button></label>`).join("")}
        </div>
        <label class="mc-ps" title="Photoshop opens the artist's PSD, makes the changes and saves the new PSD — its own text layout, no warning triangles. Uses the Photoshop on this PC (close any dialog in it first). Rows the new Excel added are left for you to add for now.">
          <input type="checkbox" id="mcPs"> Make the new PSD in Photoshop (exact text layout)</label>
        <div id="mcStatus" class="sym-status" hidden></div>
        <div id="mcReport" class="mc-report"></div>
        <div class="build-actions sym-actions">
          <span id="mcResult" class="sym-result"></span>
          <button class="btn ghost" id="mcClose">Close</button>
          <button class="btn secondary" id="mcReview" hidden>Review links</button>
          <button class="btn primary" id="mcRun">Update the PSD</button>
        </div>
      </div>`;
    document.body.appendChild(ov);
    S.overlay = ov;
    // a click outside never closes it (what was typed in it would be lost): its ✕ or Cancel do
    ov._onKey = (e) => { if (e.key === "Escape") MarketClone.close(); };
    document.addEventListener("keydown", ov._onKey);
    $("mcExcelB").value = cfg.excel_path || "";
    ov.querySelectorAll("[data-browse]").forEach((b) => b.addEventListener("click", async () => {
      const r = await api("/api/native/browse", { method: "POST", body: { kind: b.dataset.kind, title: b.parentElement.querySelector(".mc-lab").textContent } }).catch(() => null);
      if (r && r.ok && r.path) $(b.dataset.browse).value = r.path;
    }));
    try { $("mcPs").checked = localStorage.getItem("psh.clone.photoshop") === "1"; } catch (e) { /* private window */ }
    $("mcPs").addEventListener("change", () => {
      try { localStorage.setItem("psh.clone.photoshop", $("mcPs").checked ? "1" : "0"); } catch (e) { /* ignore */ }
    });
    $("mcClose").addEventListener("click", MarketClone.close);
    $("mcRun").addEventListener("click", MarketClone.run);
    $("mcReview").addEventListener("click", () => MarketClone.run({ review: true }));
  };

  MarketClone.close = () => {
    if (!S.overlay || S.busy) return;
    document.removeEventListener("keydown", S.overlay._onKey);
    S.overlay.remove();
    S.overlay = null;
  };

  function status(text, kind) {
    const el = $("mcStatus");
    el.hidden = !text;
    el.className = "sym-status" + (kind ? " " + kind : "");
    el.textContent = text || "";
  }

  const inputs = () => ({ source_psd: $("mcPsd").value.trim(), excel_a: $("mcExcelA").value.trim(),
                          excel_b: $("mcExcelB").value.trim() });

  async function job(url, body, waiting) {
    const start = await api(url, { method: "POST", body });
    status(waiting);
    let misses = 0;
    for (;;) {
      await new Promise((r) => setTimeout(r, 600));
      let j;
      try {
        j = (await api(`/api/jobs/${start.job_id}`)).job;
        misses = 0;
      } catch (e) {
        // the server is busy with the PSD (or a request dropped): the job carries on, so ask again
        if (++misses > 20) throw e;
        continue;
      }
      if (j.status === "running") { status((j.log || []).slice(-1)[0] || waiting); continue; }
      if (j.status !== "done") throw new Error(j.error || "Something went wrong.");
      return j.result || {};
    }
  }

  // Does the artist need to look at the links? The first time for this PSD, or when a pay card
  // waits on an unnamed symbol, or a page was matched by its name only / not at all.
  function needsReview(c) {
    if (!c.saved || !c.saved.saved) return true;
    if ((c.symbols || []).some((x) => x.needed)) return true;
    // a page matched by its group name only, and not confirmed yet (pages with no sheet at all, like
    // pay-line pictures, were seen at the first review: they don't ask again)
    return (c.page_links || []).some((p) => p.how === "name" && !(p.key in (c.saved.pages || {})));
  }

  // What the new Excel changes compared with the PSD's Excel (content_diff): one line per sheet.
  // Content = texts / values / symbols; layout = rows or sheets added, removed or moved.
  function excelChanges(cc, open) {
    const lines = (cc && cc.summary) || [], cats = (cc && cc.categories) || {};
    if (!cc || !cc.changes) return "";
    if (!lines.length) return `<div class="mc-out">The two Excel files have the same content.</div>`;
    return `<details class="mc-details"${open ? " open" : ""}><summary>What the new Excel changes — ${cats.content || 0} text / value / symbol change(s), ${cats.structural || 0} row or sheet change(s)</summary>
      <ul class="mc-list">${lines.map((s) => `<li>${escH(s)}</li>`).join("")}</ul></details>`;
  }

  // Update the PSD straight away with the links saved for it (write first, look after): the changes are
  // listed when it's done, each drawn only when clicked. "Review links" checks the page / symbol links
  // first; after them the PSD is made again with what was confirmed.
  MarketClone.run = async (opts = {}) => {
    if (S.busy) return;
    const body = inputs();
    const key = JSON.stringify(body);
    if (S.stage === "links" && S.checkFor === key && !opts.review) { await create(body, currentLinks(S.check)); return; }
    if (!opts.review) { await create(body, null); return; }
    S.stage = "";
    setRun("Update the PSD", false);
    $("mcReport").innerHTML = "";
    $("mcResult").textContent = "";
    S.busy = true;
    $("mcRun").disabled = true;
    try {
      if (!opts.links) {
        const c = await job("/api/market_clone/check", body, "Reading the PSD and both Excel files…");
        S.check = c;
        S.checkFor = key;
        status("");
        if (opts.review || needsReview(c)) { showLinks(c); return; }
        opts.links = currentLinks(c);
      }
      S.links = opts.links;
      const r = await job("/api/market_clone/preview", { ...body, links: opts.links },
        "Working out every page that changes… nothing is written yet");
      status("");
      showApproval(r);
    } catch (e) {
      status(e.message, "err");
    } finally {
      S.busy = false;
      $("mcRun").disabled = S.stage === "approve" ? !allDecided() : false;
    }
  };

  function setRun(text, disabled) {
    $("mcRun").textContent = text;
    $("mcRun").disabled = !!disabled;
  }

  async function create(body, links) {
    const t0 = Date.now();
    S.busy = true;
    setRun("Updating…", true);
    try {
      $("mcReport").innerHTML = "";
      $("mcResult").textContent = "";
      const r = await job("/api/market_clone", { ...body, links: links || undefined, pictures: "list", photoshop: $("mcPs").checked },
        "Updating the PSD…");
      status("");
      S.stage = "done";
      S.done = r;
      r.seconds = Math.round((Date.now() - t0) / 100) / 10;
      render(r);
      $("mcReview").hidden = false;
    } catch (e) {
      status(e.message, "err");
    } finally {
      S.busy = false;
      setRun("Update the PSD", false);
    }
  }

  // ── approval: every page that would change, on one screen ──
  // Each change shows as a before / after crop of just its area (drawn in the background — each
  // appears when ready); a whole page is drawn only when asked for. A page decides as a whole:
  // approve it, or keep it as the artist made it. "Approve all" for the usual case.
  const KIND = { page: ["Changed", ""], new: ["New page", "ok"], removed: ["Deleted from the Excel", "warn"] };
  const ACTIONS = { page: ["Keep the artist's page", "Approve"], new: ["Don't add", "Add this page"],
                    removed: ["Leave it as it is", "Label it deleted"] };
  const allDecided = () => (S.preview?.pages || []).every((p) => S.decided[p.id]);

  function showApproval(r) {
    S.preview = r;
    S.stage = "approve";
    S.decided = {};
    S.edits = {};
    const pages = r.pages || [];
    if (!pages.length) {
      $("mcReport").innerHTML = `<div class="mc-out">Nothing in the new Excel changes any page — no new PSD is needed.</div>`;
      S.stage = "";
      return;
    }
    // a page that can't show all of its sheet is never added by default
    pages.forEach((p) => { if (p.kind === "new" && (p.missing || []).length) S.decided[p.id] = "keep"; });
    drawApproval();
  }

  const waitImg = (path, alt) => (path ? `<img class="mc-wait" data-src="${escH(path)}" alt="${escH(alt)}">` : "");

  function loadImages(root) {
    // crops are drawn in the background: a picture not drawn yet is asked for again a moment later
    root.querySelectorAll("img.mc-wait").forEach((img) => {
      let tries = 0;
      const load = () => { img.src = pic(img.dataset.src); };
      img.addEventListener("load", () => img.classList.remove("mc-wait"));
      img.addEventListener("error", () => { if (++tries < 200) setTimeout(load, 1500); });
      load();
    });
  }

  function drawApproval() {
    const pages = S.preview.pages;
    const layers = S.preview.layers || [];
    const section = (p, i) => {
      const kind = KIND[p.kind] || KIND.page, d = S.decided[p.id];
      const crops = (p.crops || []).map((c, ci) => `<div class="mc-crop mc-${c.status}" data-crop="${i}:${ci}">
          <div class="mc-crop-pics${p.kind === "removed" ? " single" : ""}">
            <div><span>${p.kind === "new" ? "Copied from" : p.kind === "removed" ? "This page" : "Before"}</span>${waitImg(c.before, "before")}</div>
            ${p.kind === "removed" ? "" : `<div><span>After${S.edits[c.key] !== undefined ? " — edited" : ""}</span>${waitImg(c.edited || c.after, "after")}</div>`}
          </div>
          ${c.key && p.kind !== "removed" ? `<div class="mc-edit-row"><button class="btn ghost small" data-edit="${i}:${ci}">Edit text</button></div>
            <div class="mc-editor" hidden><textarea rows="4" spellcheck="false">${escH(S.edits[c.key] ?? (c.text || "").replace(/\r/g, "\n"))}</textarea>
              <div class="mc-edit-row"><span class="hint">One line per line on the page. Drawn again in a second.</span>
              <button class="btn ghost small" data-cancel="1">Cancel</button><button class="btn primary small" data-apply="${i}:${ci}">Update</button></div></div>` : ""}
          ${c.old || c.new ? `<div class="mc-text">${show(c.old)}${c.new ? `<div class="mc-new">→ ${show(c.new)}</div>` : ""}</div>` : ""}
          ${c.why ? `<div class="mc-why">${escH(c.why)}</div>` : ""}
        </div>`).join("");
      const issues = layers.filter((l) => String(l.page_key) === String(p.page_key) && l.status !== "change");
      return `<section class="mc-pg${d ? " " + d : ""}" data-pg="${i}">
        <header><span class="mc-badge ${kind[1]}">${kind[0]}</span><b>${escH(p.page)}</b>
          <span class="mc-src">${p.kind === "new" ? `from the sheet ${escH(p.sheet)} · copied from ${escH(p.from)}` : p.kind === "page" ? `${p.changed} change(s)` : ""}</span>
          <span class="mc-pg-acts">
            <button class="btn ghost small" data-whole="${i}" data-which="before">Whole page: before</button>
            ${p.kind === "removed" ? "" : `<button class="btn ghost small" data-whole="${i}" data-which="after">after</button>`}
            <button class="btn ${d === "keep" ? "secondary on" : "ghost"} small" data-keep="${i}">${ACTIONS[p.kind][0]}</button>
            <button class="btn ${d === "ok" ? "primary" : "secondary"} small" data-ok="${i}">${d === "ok" ? "✓ " : ""}${ACTIONS[p.kind][1]}</button>
          </span></header>
        ${(p.missing || []).length ? `<div class="sym-status warn">Incomplete: ${p.missing.length} row(s) of its sheet aren't on this page — ${escH(p.missing.slice(0, 2).map((t) => t.slice(0, 60)).join(" / "))}${p.missing.length > 2 ? " …" : ""}.
            ${p.kind === "new" ? "It is not added unless you choose to." : ""}</div>` : ""}
        ${p.kind === "removed" ? `<div class="hint">Its sheet is no longer in the Excel. The group stays in the PSD, labelled red and renamed "DELETED FROM EXCEL", for the artist to remove.</div>` : ""}
        ${issues.length ? `<div class="hint">${issues.length} item(s) here need the artist: ${escH(issues.slice(0, 3).map((l) => (l.why || l.status)).join(" · "))}</div>` : ""}
        <div class="mc-crops">${crops}</div>
      </section>`;
    };
    const done = Object.keys(S.decided).length;
    $("mcReport").innerHTML = `<div class="mc-approve">
        <div class="mc-bar"><b>${pages.length} page(s) change</b> — every other page stays exactly as the artist made it.
          <span class="mc-key">${done} of ${pages.length} decided</span>
          <button class="btn secondary small" id="mcAll">Approve all the rest</button></div>
        ${excelChanges(S.preview.content_changes, false)}
        ${pages.map(section).join("")}
      </div>`;
    loadImages($("mcReport"));
    const decide = (i, v) => {
      S.decided[pages[i].id] = v;
      const top = $("mcReport").scrollTop;
      drawApproval();
      $("mcReport").scrollTop = top;
    };
    $("mcReport").querySelectorAll("[data-ok]").forEach((b) => b.addEventListener("click", () => decide(+b.dataset.ok, "ok")));
    $("mcReport").querySelectorAll("[data-keep]").forEach((b) => b.addEventListener("click", () => decide(+b.dataset.keep, "keep")));
    $("mcAll").addEventListener("click", () => {
      pages.forEach((p) => { if (!S.decided[p.id]) S.decided[p.id] = "ok"; });
      const top = $("mcReport").scrollTop;
      drawApproval();
      $("mcReport").scrollTop = top;
    });
    $("mcReport").querySelectorAll("[data-edit]").forEach((b) => b.addEventListener("click", () => {
      const box = b.closest(".mc-crop").querySelector(".mc-editor");
      box.hidden = !box.hidden;
      if (!box.hidden) box.querySelector("textarea").focus();
    }));
    $("mcReport").querySelectorAll("[data-cancel]").forEach((b) => b.addEventListener("click", () => {
      b.closest(".mc-editor").hidden = true;
    }));
    $("mcReport").querySelectorAll("[data-apply]").forEach((b) => b.addEventListener("click", async () => {
      const [pi, ci] = b.dataset.apply.split(":").map(Number);
      const c = pages[pi].crops[ci];
      const text = b.closest(".mc-editor").querySelector("textarea").value;
      b.disabled = true;
      status("Drawing your edit…");
      try {
        const r = await api("/api/market_clone/edit", { method: "POST",
          body: { preview_key: S.preview.preview_key, key: c.key, text, box: c.box } });
        S.edits[c.key] = text;
        c.edited = r.path;
        c.box = r.box;
        status("");
        const top = $("mcReport").scrollTop;
        drawApproval();
        $("mcReport").scrollTop = top;
      } catch (e) {
        status(e.message, "err");
        b.disabled = false;
      }
    }));
    $("mcReport").querySelectorAll("[data-whole]").forEach((b) => b.addEventListener("click", async () => {
      const p = pages[+b.dataset.whole];
      const tab = window.open("", "_blank");
      status("Drawing the whole page… (about 15 seconds the first time)");
      try {
        const r = await api("/api/market_clone/page", { method: "POST",
          body: { preview_key: S.preview.preview_key, page_key: p.page_key, which: b.dataset.which } });
        status("");
        if (tab) tab.location = pic(r.path); else window.open(pic(r.path), "_blank");
      } catch (e) {
        if (tab) tab.close();
        status(e.message, "err");
      }
    }));
    const kept = Object.values(S.decided).filter((v) => v === "keep").length;
    setRun(allDecided() ? `Create the PSD (${pages.length - kept} approved${kept ? `, ${kept} kept` : ""})` : "Create the PSD", !allDecided());
  }

  // the links as they stand: what the check found, with every choice the artist made
  function currentLinks(c) {
    const pages = {}, symbols = {};
    // what the artist picked binds ("chosen"); the rest is only what the tool found this time ("pages"):
    // found again from the Excel next time, so a sheet that leaves the AGR is noticed
    const chosen = {};
    (c.page_links || []).forEach((p) => {
      if (p.how !== "none" || p.sheet) pages[p.key] = p.sheet || "";
      if (p.chosen) chosen[p.key] = p.sheet || "";
    });
    (c.symbols || []).forEach((x) => { if (x.token) symbols[x.sig] = x.token; });
    const new_pages = {};
    ((c.page_changes || {}).new || []).forEach((n) => { if (n.how === "link") new_pages[n.sheet] = n.sibling || ""; });
    return { pages, chosen, symbols, new_pages };
  }

  const HOW_PAGE = { text: ["found by its text", "ok"], name: ["by its group name — check", "warn"],
                     link: ["as you chose", "ok"], none: ["not found — choose one", "warn"] };
  const HOW_SYM = { link: "as you chose", row: "from a row of text", card: "from its pay card",
                    name: "from its layer name", folder: "from the symbols folder" };

  function showLinks(c) {
    const sheets = c.sheets || [], tokens = c.tokens || [];
    const opt = (v, label, sel) => `<option value="${escH(v)}"${sel ? " selected" : ""}>${escH(label)}</option>`;
    const pageRows = (c.page_links || []).map((p, i) => {
      const how = HOW_PAGE[p.how] || HOW_PAGE.none;
      return `<tr><td><b>${escH(p.page)}</b></td>
        <td><select data-page="${i}">${opt("", "— not from the Excel —", !p.sheet)}${sheets.map((n) => opt(n, n, n === p.sheet)).join("")}</select></td>
        <td><span class="mc-badge ${how[1]}">${escH(how[0])}</span></td></tr>`;
    }).join("");
    const syms = (c.symbols || []);
    const symCard = (x, i) => `<div class="mc-sym${x.needed ? " need" : ""}" title="${escH(x.layer)}">
        ${x.thumb ? `<img src="${pic(x.thumb)}" alt="">` : `<div class="hint">no picture</div>`}
        <div class="mc-src">${escH(x.layer)}</div>
        <select data-sym="${i}">${opt("", "— not a symbol —", !x.token)}${tokens.map((t) => opt(t, "<" + t + ">", t === x.token)).join("")}</select>
        <span class="mc-badge ${x.needed ? "warn" : x.token ? "ok" : ""}">${escH(x.needed ? "a pay card needs this" : x.token ? (HOW_SYM[x.how] || "") : "not named")}</span>
      </div>`;
    const main = syms.map((x, i) => (x.token || x.card || x.needed ? symCard(x, i) : "")).join("");
    const others = syms.map((x, i) => (x.token || x.card || x.needed ? "" : symCard(x, i))).join("");
    const nOthers = syms.filter((x) => !(x.token || x.card || x.needed)).length;
    const waiting = syms.filter((x) => x.needed).length;
    const pc = c.page_changes || {}, groups = (c.page_links || []).filter((p) => p.sheet);
    const pageNames = (sheet) => groups.filter((p) => p.sheet === sheet).map((p) => p.page).join(", ");
    const newRows = (pc.new || []).map((n, i) => `<tr><td><b>${escH(n.sheet)}</b></td>
        <td><select data-new="${i}">${opt("", "— don't add a page —", !n.sibling)}${(n.likely || []).map((s) => opt(s, `copy ${pageNames(s) || s} (${s})`, s === n.sibling)).join("")}</select></td>
        <td>${n.status === "template" ? '<span class="mc-badge warn">no page like it — made from the design later</span>' : `<span class="mc-badge ok">${Math.round((n.likeness || 0) * 100)}% alike</span>`}</td></tr>`).join("");
    const goneRows = (pc.removed || []).map((g) => `<li><b>${escH(g.sheet)}</b>: ${escH((g.pages || []).join(", "))} — labelled red, renamed "DELETED FROM EXCEL"</li>`).join("");
    const renamed = (pc.renamed || []).map((r) => `<li>${escH(r.from)} → ${escH(r.to)}</li>`).join("");
    $("mcReport").innerHTML = `<div class="mc-links">
        ${excelChanges(c.content_changes, true)}
        <h4 class="mc-h">Check the links once — they are saved with the game</h4>
        <p>Which Excel sheet each page group shows, and which picture is which symbol. The tool worked these
           out from the PSD itself; fix anything that's wrong. Next time this PSD (or another market of the
           game) is cloned, these are used straight away.</p>
        <table class="mc-table"><thead><tr><th>Page group in the PSD</th><th>Excel sheet</th><th></th></tr></thead><tbody>${pageRows}</tbody></table>
        ${newRows ? `<h4 class="mc-h">New sheets in the new Excel — each gets a copy of the page most like it</h4>
          <table class="mc-table"><thead><tr><th>New sheet</th><th>Page to copy</th><th></th></tr></thead><tbody>${newRows}</tbody></table>` : ""}
        ${goneRows ? `<h4 class="mc-h">Sheets no longer in the Excel</h4><ul class="mc-list">${goneRows}</ul>` : ""}
        ${renamed ? `<h4 class="mc-h">Sheets renamed (the same pages)</h4><ul class="mc-list">${renamed}</ul>` : ""}
        <h4 class="mc-h">Symbols${waiting ? ` — <span class="mc-key">${waiting} pay card picture(s) need a name, or their values can't be changed</span>` : ""}</h4>
        <div class="mc-syms">${main || '<div class="hint">No symbol pictures found.</div>'}</div>
        ${nOthers ? `<details class="mc-details"><summary>Other pictures — not symbols as far as the tool can tell (${nOthers})</summary>
          <div class="mc-syms">${others}</div></details>` : ""}
      </div>`;
    $("mcReport").querySelectorAll("[data-page]").forEach((el) => el.addEventListener("change", () => {
      const p = c.page_links[+el.dataset.page];
      p.sheet = el.value;
      p.how = "link";
      p.chosen = true;
    }));
    $("mcReport").querySelectorAll("[data-new]").forEach((el) => el.addEventListener("change", () => {
      const n = c.page_changes.new[+el.dataset.new];
      n.sibling = el.value || null;
      n.how = "link";
    }));
    $("mcReport").querySelectorAll("[data-sym]").forEach((el) => el.addEventListener("change", () => {
      const x = c.symbols[+el.dataset.sym];
      x.token = el.value || null;
      x.how = "link";
    }));
    $("mcResult").innerHTML = "";
    S.stage = "links";
    setRun("Looks right — update the PSD", false);
  }

  const LABEL = { change: "Changed", same: "Same in both", design: "Not from the Excel", artist: "Needs the artist",
                  ambiguous: "Can't tell which", missing: "Not in the new Excel", empty: "Empty",
                  kept: "Kept as the artist made it" };

  // before / after of every page with changes: orange = changed, red = needs the artist
  const pic = (path) => `/api/market_clone/picture?path=${encodeURIComponent(path)}&v=${Date.now()}`;
  function pagesHtml(pages) {
    const ok = pages.filter((p) => p.before && p.after);
    const broken = pages.find((p) => p.error);
    if (!ok.length) return broken ? `<div class="hint">${escH(broken.error)}</div>` : "";
    return `<h4 class="mc-h">Pages (${ok.length}) — <span class="mc-key"><i class="mc-o"></i> changed <i class="mc-r"></i> needs a look</span></h4>
      ${ok.map((p, i) => `<div class="mc-page">
        <div class="mc-page-head"><b>${escH(p.page)}</b> · ${p.changed} changed${p.issues ? ` · ${p.issues} to look at` : ""}
          <span class="mc-flip"><button class="ts-tgt on" data-pg="${i}" data-side="pair">Side by side</button><button class="ts-tgt" data-pg="${i}" data-side="before">Before</button><button class="ts-tgt" data-pg="${i}" data-side="after">After</button></span></div>
        <div class="mc-pics" data-pics="${i}">
          <a href="${pic(p.before)}" target="_blank" class="mc-pic" data-which="before"><img src="${pic(p.before)}" alt="before" loading="lazy"><span>Before</span></a>
          <a href="${pic(p.after)}" target="_blank" class="mc-pic" data-which="after"><img src="${pic(p.after)}" alt="after" loading="lazy"><span>After</span></a>
        </div></div>`).join("")}`;
  }
  function wirePages() {
    document.querySelectorAll("#mcReport [data-side]").forEach((b) => b.addEventListener("click", () => {
      const i = b.dataset.pg, side = b.dataset.side;
      document.querySelectorAll(`#mcReport [data-pg="${i}"]`).forEach((x) => x.classList.toggle("on", x === b));
      document.querySelectorAll(`#mcReport [data-pics="${i}"] .mc-pic`).forEach((a) => { a.hidden = side !== "pair" && a.dataset.which !== side; });
      document.querySelector(`#mcReport [data-pics="${i}"]`).classList.toggle("single", side !== "pair");
    }));
  }

  // The pages that changed and each change on them; a change's before / after is drawn when clicked.
  const KIND_TXT = { page: "Changed", new: "New page", removed: "Deleted from the Excel" };
  function changesHtml(pages) {
    const ok = pages.filter((p) => !p.error);
    const broken = pages.find((p) => p.error);
    if (!ok.length) return broken ? `<div class="hint">${escH(broken.error)}</div>` : "";
    return `<h4 class="mc-h">Pages that changed (${ok.length}) — <span class="mc-key">click a change to see it before / after</span></h4>
      ${ok.map((p, i) => `<details class="mc-details mc-pgl"><summary><span class="mc-badge ${p.kind === "new" ? "ok" : p.kind === "removed" ? "warn" : ""}">${escH(KIND_TXT[p.kind] || "Changed")}</span>
          <b>${escH(p.page)}</b> <span class="mc-src">${p.changed ? `${p.changed} change(s)` : ""}${p.issues ? ` · ${p.issues} to look at` : ""}</span></summary>
        ${(p.crops || []).map((c, ci) => `<div class="mc-crop mc-${escH(c.status)}">
          ${c.old || c.new ? `<div class="mc-text">${show(c.old)}${c.new ? `<div class="mc-new">→ ${show(c.new)}</div>` : ""}</div>` : ""}
          ${c.why ? `<div class="mc-why">${escH(c.why)}</div>` : ""}
          <button class="btn ghost small" data-show="${i}:${ci}">Show before / after</button>
          <div class="mc-crop-pics" data-pics="${i}:${ci}" hidden></div></div>`).join("")}</details>`).join("")}`;
  }
  function wireChanges(r) {
    document.querySelectorAll("#mcReport [data-show]").forEach((b) => b.addEventListener("click", async () => {
      const [i, ci] = b.dataset.show.split(":").map(Number);
      const c = r.pages[i].crops[ci], box = document.querySelector(`#mcReport [data-pics="${i}:${ci}"]`);
      b.disabled = true;
      b.textContent = "Drawing…";
      try {
        await api("/api/market_clone/crop", { method: "POST", body: { preview_key: r.preview_key, paths: [c.before, c.after] } });
        box.innerHTML = [["Before", c.before], ["After", c.after]].filter(([, p]) => p)
          .map(([label, p]) => `<div><span>${label}</span><img src="${pic(p)}" alt="${label}"></div>`).join("");
        box.hidden = false;
        b.remove();
      } catch (e) {
        b.disabled = false;
        b.textContent = "Show before / after";
        toast(e.message, "err");
      }
    }));
  }

  function render(r) {
    const c = r.counts || {};
    const needs = (r.layers || []).filter((l) => l.status !== "change");
    const changed = (r.layers || []).filter((l) => l.status === "change");
    const chip = (k, cls) => (c[k] ? `<span class="mc-chip ${cls}">${c[k]} ${LABEL[k]}</span>` : "");
    const row = (l) => `<tr class="mc-${l.status}"><td>${escH(l.page)}</td><td>${escH(LABEL[l.status] || l.status)}</td>
        <td class="mc-text">${show(l.old)}${l.new ? `<div class="mc-new">→ ${show(l.new)}</div>` : l.new_excel ? `<div class="mc-new">new Excel: ${show(l.new_excel)}</div>` : ""}</td>
        <td class="mc-why">${escH(l.why || "")}${l.source ? `<div class="mc-src">${escH(l.source)}</div>` : ""}</td></tr>`;
    const table = (rows) => `<table class="mc-table"><thead><tr><th>Page</th><th></th><th>Text</th><th>Why / from</th></tr></thead><tbody>${rows.map(row).join("")}</tbody></table>`;
    $("mcReport").innerHTML = `
      <div class="mc-summary">${chip("change", "ok")}${chip("kept", "")}${chip("same", "")}${chip("artist", "warn")}${chip("ambiguous", "warn")}${chip("missing", "warn")}${chip("design", "")}</div>
      ${r.edited ? `<div class="mc-out">Saved: <b>${escH(r.out_psd)}</b>${r.seconds ? ` <span class="mc-key">in ${r.seconds} s</span>` : ""}${r.engine === "photoshop" && r.photoshop_run ? `<div class="hint">Made in Photoshop ${escH(r.photoshop_run.version || "")} in ${Math.round(r.photoshop_run.wall_s || 0)} s.</div>` : ""}${r.engine_note ? `<div class="hint">${escH(r.engine_note)}</div>` : ""}${r.photoshop ? `<div class="hint">${escH(r.photoshop.replace(/^\[PSD\]\s*/, ""))}</div>` : ""}${r.fix_script ? `<div class="hint">Only the edited text layers may show Photoshop's warning triangle. To clear it, open the PSD in Photoshop and run <b>File › Scripts › Browse… › ${escH(r.fix_script.split(/[\\/]/).pop())}</b> once.</div>` : ""}</div>`
        : `<div class="mc-out">Nothing differs between the two markets' Excel data — no PSD was needed${r.out_psd ? " (a copy was saved: " + escH(r.out_psd) + ")" : ""}.</div>`}
      ${r.untouched ? (r.untouched.differ || []).length
        ? `<div class="sym-status err">These pages should not have changed but differ from the artist's file: ${escH(r.untouched.differ.join(", "))}</div>`
        : `<div class="mc-out">✓ ${r.untouched.pages} page(s) nothing changed — checked identical to the artist's file.</div>` : ""}
      ${r.preview_key ? changesHtml(r.pages || []) : pagesHtml(r.pages || [])}
      ${needs.length ? `<h4 class="mc-h">Needs a look (${needs.length})</h4>${table(needs)}` : ""}
      ${(r.new_rows || []).length ? `<h4 class="mc-h">In the new Excel, not on any page yet (${r.new_rows.length})</h4>
        <ul class="mc-list">${r.new_rows.map((n) => `<li><b>${escH(n.sheet)}</b> row ${n.row}: ${escH(n.text)}</li>`).join("")}</ul>` : ""}
      ${(r.missing_sheets || []).length ? `<h4 class="mc-h">Sheets missing from the new Excel</h4><ul class="mc-list">${r.missing_sheets.map((s) => `<li>${escH(s)}</li>`).join("")}</ul>` : ""}
      ${changed.length ? `<details class="mc-details" open><summary>Changed (${changed.length})</summary>${table(changed)}</details>` : ""}
      ${(r.kept_as_design || []).length ? `<details class="mc-details"><summary>Kept as the artist made them — not from the Excel (${r.kept_as_design.length})</summary>
        <ul class="mc-list">${r.kept_as_design.map((d) => `<li><b>${escH(d.page)}</b>: ${show(d.text)}</li>`).join("")}</ul></details>` : ""}`;
    wirePages();
    if (r.preview_key) wireChanges(r);
    $("mcResult").innerHTML = r.out_psd && r.edited ? `<a href="#" id="mcOpenDir">Open folder</a>` : "";
    $("mcOpenDir")?.addEventListener("click", (e) => {
      e.preventDefault();
      api("/api/open-dir", { method: "POST", body: { path: r.out_psd.replace(/[\\/][^\\/]*$/, "") } }).catch((err) => toast(err.message, "err"));
    });
  }
})();
