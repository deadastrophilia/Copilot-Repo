/* Paylines / Win Lines pages on the Canvas.

   The page is drawn like a Game / Bingo Rules page (visualiser_live.js draws the layouts
   paylines_layout.py makes from the build's own renderer): the lines are the build's picture, the
   heading is the page heading (click it: the Heading bar, as on every page). This adds, over the page:
     click a line            the whole block of lines (Lines): drag it to move it (snaps to the page
                             centre), ↔ its sides = lines per row, ↕ its bottom = row spacing, its
                             corners = everything bigger / smaller; the top bar: align, per row,
                             spacing, Fit to page
     click a badge           the badges and numbers (Numbers): drag one = every badge moves on its
                             grid, its corner = badge size; the top bar: colours, number font, size…
     double-click a line     the grids (Grid): its corner = cell size; the top bar: cells, lines,
                             colours, this line's own colour
     nothing picked          the Page bar: build this page, the heading text, Fit to page
   Every change is saved in dynamic_settings.paylines (the build reads it) and the page drawn again.
   Where things are comes from the renderer (AppLive.state.canon.paylines).
   Uses app.js globals: App, api, esc, toast, debounce. */
window.PaylinesCanvas = (() => {
  const S = { sheets: new Set(), sel: null, line: null, dragged: false };
  // scaled together by the block's corners / Fit to page (as the Paylines studio)
  const SIZE_KEYS = ["cell_w", "cell_h", "cell_gap", "outline", "cell_radius", "pitch_x", "pitch_y", "badge_w", "badge_h",
                     "badge_dx", "badge_dy", "badge_radius", "badge_stroke", "badge_font_size", "badge_text_dy"];
  const SNAP = 10;                                    // screen px
  const el = (id) => document.getElementById(id);
  const ds = () => (App.state.config.dynamic_settings = App.state.config.dynamic_settings || {});
  const sheet = () => (window.AppTypoVis && AppTypoVis.state.sheet) || "";
  const isPl = (name) => S.sheets.has(name);
  const on = () => App.route === "typography" && !!window.AppTypoVis && isPl(sheet());
  const kind = () => (on() ? "paylines" : "");
  function setSheets(list) { S.sheets = new Set(list || []); }
  // the renderer's report for the sheet on the Canvas now (null while another sheet is drawn)
  function report() {
    const c = window.AppLive && AppLive.state && AppLive.state.canon;
    return c && c.paylines && c.sheet_name === sheet() ? c.paylines : null;
  }
  const pageNo = () => Math.max(0, Number((window.AppLive && AppLive.state.page) || 0));
  const page = () => (((report() || {}).pages || [])[pageNo()]) || null;
  const saved = () => ds().paylines || {};
  function value(k) {
    const s = saved();
    if (s[k] !== undefined && s[k] !== "") return s[k];
    return ((report() || {}).settings || {})[k];
  }
  const num = (k) => Number(value(k)) || 0;
  // a change: saved (App's undo has it), the page drawn again (the Canvas keeps its zoom)
  const redrawSoon = debounce(() => { if (on() && AppTypoVis.refreshPreview) AppTypoVis.refreshPreview(); }, 150);
  function save(obj) {
    ds().paylines = Object.assign({}, saved(), obj);
    App.pushConfig();
    redrawSoon();
  }

  /* ------------------------------ the frames over the page ------------------------------ */
  function view() {
    const c = el("typoVisCanvas"), host = el("typoVisHost"), R = report();
    if (!c || !host || !R || !R.canvas) return null;
    const cr = c.getBoundingClientRect(), hr = host.getBoundingClientRect(), [cw, ch] = R.canvas;
    const k = cr.width / cw;
    return { k, cw, ch, x: (v) => cr.left - hr.left + v * k, y: (v) => cr.top - hr.top + v * (cr.height / ch), host };
  }
  const rectCss = (V, r, pad = 0) => `left:${V.x(r[0] - pad)}px;top:${V.y(r[1] - pad)}px;width:${(r[2] + 2 * pad) * V.k}px;height:${(r[3] + 2 * pad) * V.k}px`;
  const blockRect = (p) => (p && p.block ? [p.block[0], p.block[1], p.block[2] - p.block[0], p.block[3] - p.block[1]] : null);
  // a line's whole drawing (grid + badge)
  function lineRect(ln) {
    const g = ln.grid, b = ln.badge, x0 = Math.min(g[0], b[0]), y0 = Math.min(g[1], b[1]);
    return [x0, y0, Math.max(g[0] + g[2], b[0] + b[2]) - x0, Math.max(g[1] + g[3], b[1] + b[3]) - y0];
  }
  const inside = (r, x, y) => x >= r[0] && x <= r[0] + r[2] && y >= r[1] && y <= r[1] + r[3];
  // the page's free space: below the heading, inside the side margins
  function unsafe(b) {
    const R = report() || {}, p = page() || {}, m = R.margin_x || 0;
    if (!b) return "";
    if (b[0] < m - 1 || b[2] > R.canvas[0] - m + 1) return "outside the side margins";
    if (b[1] < (p.heading_bottom || 0) && b[3] > (R.heading_top || 0)) return "over the heading";
    if (b[3] > R.canvas[1]) return "off the page";
    return "";
  }

  let framesQueued = 0;
  function paintFrames() {
    if (framesQueued) return;
    framesQueued = requestAnimationFrame(() => { framesQueued = 0; paintFramesNow(); });
  }
  function paintFramesNow() {
    document.querySelectorAll(".plc-frames").forEach((n) => n.remove());
    if (!on()) return;
    const V = view(), R = report(), p = page();
    if (!V) return;
    const layer = document.createElement("div");
    layer.className = "ptc-frames plc-frames";
    let html = "";
    if (R.error) {
      html += `<div class="plc-error" style="left:${V.x(R.canvas[0] * 0.1)}px;top:${V.y(R.canvas[1] * 0.4)}px;width:${R.canvas[0] * 0.8 * V.k}px">
        <b>This Paylines page can't be drawn</b><span>${esc(R.error)}</span></div>`;
    }
    if (p) {
      // every line: a hit area (click: the block, its badge: the numbers, double-click: the grids)
      html += (p.lines || []).map((ln) => `<div class="plc-hit ${S.sel && S.line === ln.n ? "cur" : ""}" data-n="${ln.n}" style="${rectCss(V, lineRect(ln))}"></div>`).join("");
      if (S.sel === "grid") html += (p.lines || []).map((ln) => `<div class="plc-part ${S.line === ln.n ? "cur" : ""}" style="${rectCss(V, ln.grid)}"></div>`).join("");
      if (S.sel === "badge") html += (p.lines || []).map((ln) => `<div class="plc-part ${S.line === ln.n ? "cur" : ""}" style="${rectCss(V, ln.badge)}"></div>`).join("");
      const br = blockRect(p);
      if (S.sel && br) {
        const bad = unsafe(p.block) || (p.warning ? "doesn't fit the page" : "");
        const handles = S.sel === "lines" ? `<i class="rlc-h ew l" data-h="cols-l" title="Lines per row"></i><i class="rlc-h ew r" data-h="cols-r" title="Lines per row"></i>
          ${p.nrows > 1 ? `<i class="rlc-h ns b" data-h="rows" title="Row spacing"></i>` : ""}
          <i class="rlc-h plc-c tl" data-h="size-tl" title="Size"></i><i class="rlc-h plc-c tr" data-h="size-tr" title="Size"></i>
          <i class="rlc-h plc-c bl" data-h="size-bl" title="Size"></i><i class="rlc-h plc-c br" data-h="size-br" title="Size"></i>` : "";
        html += `<div class="plc-block ${S.sel === "lines" ? "sel" : ""} ${bad ? "bad" : ""}" data-h="move" style="${rectCss(V, br, 6)}" title="${S.sel === "lines" ? "Drag: move the lines · sides: lines per row · bottom: row spacing · corners: size" : ""}">
          <span class="rlc-tag">${S.sel === "grid" ? "Grid" : S.sel === "badge" ? "Numbers" : "Lines"} · ${p.cols} per row · ${p.nrows} row${p.nrows === 1 ? "" : "s"}${p.on ? "" : " · not built"}${bad ? " · " + esc(bad) : ""}</span>${handles}<span class="plc-readout"></span></div>`;
        const cur = (p.lines || []).find((ln) => ln.n === S.line) || (p.lines || [])[0];
        if (S.sel === "badge" && cur) {
          html += `<div class="plc-own" data-h="badge" style="${rectCss(V, cur.badge)}" title="Drag: every badge moves on its grid · corner: badge size"><i class="rlc-h corner rb" data-h="badge-size" title="Badge size"></i></div>`;
        }
        if (S.sel === "grid" && cur) {
          html += `<div class="plc-own" style="${rectCss(V, cur.grid)}" title="Corner: cell size"><i class="rlc-h corner rb" data-h="grid-size" title="Cell size"></i></div>`;
        }
      }
    }
    html += guidesHtml(V);
    layer.innerHTML = html;
    V.host.appendChild(layer);
    wireFrames(layer, V);
  }

  /* the heading's top margin (the page heading's place, every page's) */
  function guidesHtml(V) {
    const R = report() || {};
    if (R.heading_top == null) return "";
    return `<div class="rlc-guide h" data-g="top" style="top:${V.y(R.heading_top)}px;left:${V.x(0)}px;width:${V.cw * V.k}px"><span>Header Top Margin</span></div>`
      + ["l", "r"].map((sd) => `<div class="rlc-guide v plc-ro" style="left:${V.x(sd === "l" ? R.margin_x : V.cw - R.margin_x)}px;top:${V.y(0)}px;height:${V.ch * V.k}px"><span>${sd === "l" ? "Left" : "Right"} Margin</span></div>`).join("");
  }
  function dragGuide(ev, n, V) {
    if (ev.button !== 0) return;
    ev.preventDefault();
    ev.stopPropagation();
    const host = V.host.getBoundingClientRect();
    let val = null;
    const move = (e) => {
      val = Math.max(0, Math.round(Math.min(V.ch, (e.clientY - host.top - V.y(0)) / V.k)));
      n.style.top = V.y(val) + "px";
    };
    const up = () => {
      document.removeEventListener("mousemove", move);
      document.removeEventListener("mouseup", up);
      if (val == null) return;
      App.set("heading_top_margin", val);
      App.pushConfig();
      redrawSoon();
    };
    document.addEventListener("mousemove", move);
    document.addEventListener("mouseup", up);
  }

  // a part picked (null: nothing — the Page bar); n = the line clicked
  function pick(sel, n) {
    S.sel = sel;
    if (n != null) S.line = n;
    if (window.IconStudio) IconStudio.deselect();
    if (window.AppTypoVis) AppTypoVis.selectRow(null);
    paintFrames();
    if (window.TypoStudio) TypoStudio.setTarget(sel ? "rules_part" : "rules_page");
  }
  // the page point under a mouse event
  function at(ev, V) {
    const h = V.host.getBoundingClientRect();
    return [(ev.clientX - h.left - V.x(0)) / V.k, (ev.clientY - h.top - V.y(0)) / V.k];
  }
  // what is under a click: a badge ("badge") or a line ("lines"), and its line number
  function hitAt(x, y) {
    for (const ln of (page() || {}).lines || []) {
      if (inside(ln.badge, x, y)) return { sel: "badge", n: ln.n };
      if (inside(lineRect(ln), x, y)) return { sel: "lines", n: ln.n };
    }
    return null;
  }
  function wireFrames(layer, V) {
    const stop = (ev) => ev.stopPropagation();
    layer.querySelectorAll(".plc-hit, .plc-block, .plc-own").forEach((n) => {
      n.addEventListener("mousedown", (ev) => {
        if (ev.button !== 0) return;
        ev.stopPropagation();
        const h = ev.target.closest("[data-h]");
        if (!h || !S.sel) return;
        // the block / a badge picked: dragged (a hit area under a picked block: the block moves)
        const mode = h.dataset.h === "badge" && S.sel !== "badge" ? "move" : h.dataset.h;
        if (S.sel === "lines" || mode === "badge" || mode === "badge-size" || mode === "grid-size") dragHandle(ev, mode, V);
      });
      n.addEventListener("click", (ev) => {
        ev.stopPropagation();
        if (S.dragged) return;
        const hit = hitAt(...at(ev, V));
        if (!hit) { if (!ev.target.closest(".plc-block")) pick(null); return; }
        pick(hit.sel, hit.n);
      });
      n.addEventListener("dblclick", (ev) => {
        ev.preventDefault();
        ev.stopPropagation();
        const hit = hitAt(...at(ev, V));
        if (hit) pick("grid", hit.n);
      });
      n.addEventListener("contextmenu", (ev) => { ev.preventDefault(); stop(ev); });
    });
    layer.querySelectorAll(".rlc-guide[data-g]").forEach((g) => g.addEventListener("mousedown", (ev) => dragGuide(ev, g, V)));
  }

  /* ------------------------------ dragging ------------------------------ */
  // the page's picture of the lines (moved live while the block is dragged)
  function picture() {
    return ((window.AppLive && AppLive.state.elements) || []).find((e) => e.kind === "picture" && /^paylines_decor_/.test(String(e.id)));
  }
  function redrawCanvas() {
    const c = el("typoVisCanvas");
    if (c && window.AppLive && AppLive.redrawInto) AppLive.redrawInto(c);
  }
  function scaled(s, keys = SIZE_KEYS) {
    const out = {};
    keys.forEach((key) => {
      const v = num(key);
      let n = Math.round(v * s);
      if (v > 0 && n < 1) n = 1;                     // a 1 px line stays visible
      if (v < 0 && n > -1) n = -1;
      out[key] = n;
    });
    return out;
  }
  function dragHandle(ev, mode, V) {
    ev.preventDefault();
    const p = page(), R = report(), b = p && p.block;
    if (!p || !b) return;
    const block = document.querySelector(".plc-block"), own = document.querySelector(".plc-own");
    const frame = mode === "badge" || mode === "badge-size" || mode === "grid-size" ? own : block;
    if (!frame) return;
    const r0 = { l: frame.offsetLeft, t: frame.offsetTop, w: frame.offsetWidth, h: frame.offsetHeight };
    const x0 = ev.clientX, y0 = ev.clientY, pic = picture(), pic0 = pic ? { x: pic.base.x, y: pic.base.y } : null;
    const readout = block && block.querySelector(".plc-readout");
    const say = (t) => { if (readout) { readout.textContent = t || ""; readout.style.display = t ? "block" : "none"; } };
    const align = String(value("align") || "center"), px = num("pitch_x"), py = num("pitch_y");
    const W = R.canvas[0], bw = b[2] - b[0], bh = b[3] - b[1];
    let result = null;
    S.dragged = false;
    const guide = document.createElement("div");
    guide.className = "plc-snap";
    V.host.appendChild(guide);
    const move = (e) => {
      const dxs = e.clientX - x0, dys = e.clientY - y0, dx = dxs / V.k, dy = dys / V.k;
      if (Math.abs(dxs) + Math.abs(dys) > 2) S.dragged = true;
      if (!S.dragged) return;
      const set = (l, t, w, h) => Object.assign(frame.style, { left: l + "px", top: t + "px", width: Math.max(12, w) + "px", height: Math.max(12, h) + "px" });
      if (mode === "move") {
        // the page's centre snaps; the lines' picture moves with the frame
        const snapX = Math.abs((b[0] + b[2]) / 2 + dx - W / 2) * V.k < SNAP;
        const fx = snapX ? W / 2 - (b[0] + b[2]) / 2 : dx;
        set(r0.l + fx * V.k, r0.t + dy * V.k, r0.w, r0.h);
        guide.style.cssText = snapX ? `left:${V.x(W / 2)}px;top:${V.y(0)}px;height:${R.canvas[1] * V.k}px;display:block` : "display:none";
        if (pic && pic0) { pic.base.x = pic0.x + fx; pic.base.y = pic0.y + dy; redrawCanvas(); }
        const moved = [b[0] + fx, b[1] + dy, b[2] + fx, b[3] + dy], bad = unsafe(moved);
        block.classList.toggle("bad", !!bad);
        say(`${snapX ? "centred" : (fx >= 0 ? "+" : "") + Math.round(fx) + " px"} · ${(dy >= 0 ? "+" : "") + Math.round(dy)} px${bad ? " · " + bad : ""}`);
        const gridTop = b[1] + Math.max(0, -num("badge_dy")), top = Math.max(0, Math.round(gridTop + dy));
        result = { top };
        if (snapX) { result.align = "center"; result.offset_x = 0; } else result.offset_x = Math.round(num("offset_x") + fx);
        const lowest = top + (b[3] - gridTop);
        if (lowest > num("bottom")) result.bottom = Math.round(lowest);    // kept from moving back up
      } else if (mode === "cols-l" || mode === "cols-r") {
        const sign = mode === "cols-r" ? 1 : -1;
        const grow = align === "center" ? 2 * sign * dx : align === "left" ? (sign > 0 ? dx : 0) : (sign < 0 ? -dx : 0);
        const extra = bw - ((p.cols - 1) * px + p.grid_w);         // the badges' overhang
        const cols = Math.max(1, Math.min(50, Math.round((bw + grow - extra - p.grid_w) / px) + 1));
        const shown = Math.min(cols, p.count), nrows = Math.ceil(p.count / shown);
        const w = ((shown - 1) * px + p.grid_w + extra) * V.k + 12;
        const l = align === "center" ? r0.l + (r0.w - w) / 2 : align === "left" ? r0.l : r0.l + r0.w - w;
        set(l, r0.t, w, ((nrows - 1) * py + (bh - (p.nrows - 1) * py)) * V.k + 12);
        say(`${cols} per row · ${nrows} row${nrows === 1 ? "" : "s"}${cols > p.count ? ` (this page has ${p.count})` : ""}`);
        result = cols !== Number(value("columns")) ? { columns: cols } : null;
      } else if (mode === "rows") {
        const pitch = Math.max(Math.round(p.grid_h * 0.6), Math.round(py + dy / Math.max(1, p.nrows - 1)));
        set(r0.l, r0.t, r0.w, (bh + (pitch - py) * (p.nrows - 1)) * V.k + 12);
        say(`row spacing ${pitch} px (gap ${pitch - p.grid_h} px)`);
        result = pitch !== py ? { pitch_y: pitch } : null;
      } else if (mode.startsWith("size-")) {
        const c = mode.slice(5), sx = c.includes("r") ? 1 : -1, sy = c.includes("b") ? 1 : -1;
        let s = ((bw + sx * dx * (align === "center" ? 2 : 1)) / bw + (bh + sy * dy) / bh) / 2;
        s = Math.max(0.3, Math.min(3, s));
        const w = bw * s * V.k + 12, h = bh * s * V.k + 12;
        set(align === "center" ? r0.l + (r0.w - w) / 2 : sx > 0 ? r0.l : r0.l + r0.w - w, sy > 0 ? r0.t : r0.t + r0.h - h, w, h);
        say(`size ${Math.round(s * 100)}%`);
        result = Math.abs(s - 1) < 0.01 ? null : scaled(s);
        if (result) {
          // from where the lines are drawn: the top corners keep the bottom edge, the bottom ones the top
          const gridTop = b[1] + Math.max(0, -num("badge_dy"));
          result.top = Math.max(0, Math.round(sy < 0 ? gridTop + bh * (1 - s) : gridTop));
          result.bottom = Math.max(num("bottom"), Math.round(result.top + (b[3] - gridTop) * s) + 1);
        }
      } else if (mode === "badge") {
        set(r0.l + dxs, r0.t + dys, r0.w, r0.h);
        result = { badge_dx: Math.round(num("badge_dx") + dx), badge_dy: Math.round(num("badge_dy") + dy) };
        say(`badge ${result.badge_dx}, ${result.badge_dy} px from the grid`);
      } else if (mode === "badge-size" || mode === "grid-size") {
        const s = Math.max(0.2, Math.min(5, ((r0.w + dxs) / r0.w + (r0.h + dys) / r0.h) / 2));
        set(r0.l, r0.t, r0.w * s, r0.h * s);
        result = Math.abs(s - 1) < 0.01 ? null
          : scaled(s, mode === "badge-size" ? ["badge_w", "badge_h", "badge_radius", "badge_font_size", "badge_text_dy"] : ["cell_w", "cell_h", "cell_radius"]);
        say(`${mode === "badge-size" ? "badge" : "cells"} ${Math.round(s * 100)}%`);
      }
    };
    const up = () => {
      document.removeEventListener("mousemove", move);
      document.removeEventListener("mouseup", up);
      guide.remove();
      setTimeout(() => { S.dragged = false; }, 0);
      if (!S.dragged) return;
      if (result && Object.keys(result).length) save(result);
      else { if (pic && pic0) { pic.base.x = pic0.x; pic.base.y = pic0.y; redrawCanvas(); } paintFrames(); }
    };
    document.addEventListener("mousemove", move);
    document.addEventListener("mouseup", up);
  }

  /* best lines per row (and size, when needed) for the biggest page — the Paylines studio's Fit to page */
  function fit() {
    const R = report(), p = page();
    if (!R || !p) return;
    const pages = R.pages || [], [W, H] = R.canvas, m = R.margin_x || 0;
    const above = Math.max(0, -num("badge_dy")), px = num("pitch_x"), py = num("pitch_y");
    const n = Math.max(...pages.map((q) => q.count), p.count);
    const y0 = (p.heading_bottom || 0) + 24, y1 = H - Math.max(40, Math.round(H * 0.07));
    const aw = W - 2 * m, ah = y1 - y0;
    let best = null;
    for (let cols = 1; cols <= n; cols++) {
      const rows = Math.ceil(n / cols), bw = (cols - 1) * px + p.grid_w, bh = (rows - 1) * py + p.grid_h + above;
      const s = Math.min(1, aw / bw, ah / bh), shape = Math.abs(Math.log((bw / bh) / (aw / ah)));
      if (!best || s > best.s + 1e-6 || (Math.abs(s - best.s) < 1e-6 && shape < best.shape)) best = { cols, rows, s, bh, shape };
    }
    if (!best) return;
    const s = best.s < 0.999 ? best.s : 1, out = s < 1 ? scaled(s) : {};
    const top = Math.round(y0 + (ah - best.bh * s) / 2 + above * s);
    Object.assign(out, { columns: best.cols, align: "center", offset_x: 0, top, bottom: Math.round(top - above * s + best.bh * s) + 1 });
    save(out);
    toast(`Fitted for ${n} lines: ${best.cols} per row, ${best.rows} row${best.rows === 1 ? "" : "s"}${s < 1 ? `, ${Math.round(s * 100)}% size` : ""}.`);
  }

  /* ------------------------------ bars (sections of the top bar) ------------------------------ */
  const sep = `<span class="ts-sep"></span>`;
  const hexOf = (v) => (/^#[0-9a-f]{6}$/i.test(String(v || "")) ? String(v) : "#ffffff");
  const numIn = (k, title, min, max, unit = "px") => `<input class="ts-size ts-narrow" type="number" data-pl="${k}" value="${esc(value(k) ?? "")}" min="${min}" max="${max}" title="${esc(title)}">${unit ? `<span class="ts-unit">${unit}</span>` : ""}`;
  const colIn = (k, title) => `<input type="color" class="rlc-col" data-pl="${k}" value="${esc(hexOf(value(k)))}" title="${esc(title)}">`;
  const check = (k, label, title) => `<label class="ts-lbl rlc-check" title="${esc(title)}"><input type="checkbox" data-pl="${k}" ${value(k) ? "checked" : ""}> ${label}</label>`;
  const selIn = (k, opts, title) => `<select class="ts-style" data-pl="${k}" title="${esc(title)}">${opts.map(([v, t]) => `<option value="${v}" ${String(value(k)) === v ? "selected" : ""}>${esc(t)}</option>`).join("")}</select>`;
  const lbl = (t) => `<span class="ts-lbl">${t}</span>`;
  const partsHtml = () => `<span class="plc-parts">${[["lines", "Lines"], ["grid", "Grid"], ["badge", "Numbers"]]
    .map(([k, t]) => `<button class="ts-tgt ${S.sel === k ? "on" : ""}" data-plpart="${k}">${t}</button>`).join("")}</span>`;
  const isOn = (p) => !!(p && p.on);

  /* the page itself (nothing picked): build it, its heading text, Fit to page */
  function pageBarHtml() {
    const R = report() || {}, p = page();
    const problems = R.error ? `<span class="ts-hint plc-bad">${esc(R.error)}</span>` : (p && p.warning ? `<span class="ts-hint plc-bad">${esc(p.warning)}</span>` : "");
    return `${p ? `<label class="ts-lbl rlc-check" title="Unticked: this page is left out of the PSD and PNG builds"><input type="checkbox" data-plbuild ${isOn(p) ? "checked" : ""}> Build this page</label>${sep}` : ""}
      ${lbl("Heading")}<input class="ts-style plc-text" type="text" data-pl="heading_text" value="${esc(value("heading_text") ?? "")}" title="The heading of every payline page (the Heading bar: its font, size, colour)">
      ${p ? `${sep}<button class="ts-tgt" data-plfit title="Best lines per row and size for the biggest page">Fit to page</button>` : ""}
      ${problems || `<span class="ts-hint">${p ? `${esc(p.name)} · lines ${p.first}–${p.last}${p.denoms ? " · denom " + esc(p.denoms) : ""} · click the lines to move or size them` : ""}</span>`}`;
  }
  /* the lines, the grids or the numbers, picked on the page */
  function partBarHtml() {
    const p = page() || {}, max = Math.min(50, Math.max(...((report() || {}).pages || [{ count: 10 }]).map((q) => q.count)));
    if (S.sel === "lines") {
      const al = String(value("align") || "center"), cols = Number(value("columns")) || p.cols || 10;
      return `${partsHtml()}${sep}${[["left", "⇤", "Align left"], ["center", "↔", "Centre"], ["right", "⇥", "Align right"]]
        .map(([a, ic, t]) => `<button class="ts-al ${al === a ? "on" : ""}" data-plalign="${a}" title="${t}">${ic}</button>`).join("")}
        ${sep}<select class="ts-style" data-plcols title="Lines per row">${Array.from({ length: Math.max(max, cols) }, (_, i) => i + 1).map((n) => `<option value="${n}" ${n === cols ? "selected" : ""}>${n}</option>`).join("")}</select>${lbl("per row")}
        ${sep}${lbl("↔")}${numIn("pitch_x", "Grid to grid, left to right", 1, 4000)}${lbl("↕")}${numIn("pitch_y", "Row to row", 1, 4000)}
        ${selIn("last_row", [["left", "Short row left"], ["center", "Short row centred"]], "A short last row")}
        ${sep}<button class="ts-tgt" data-plfit title="Best lines per row and size for the biggest page">Fit to page</button>
        <span class="ts-hint">drag: move · sides: per row · bottom: row spacing · corners: size</span>`;
    }
    if (S.sel === "grid") {
      const ln = S.line || 1, pal = (value("palette") || []).filter(Boolean), byLine = String(value("highlight_mode") || "line") === "line";
      return `${partsHtml()}${sep}${lbl("Cell")}${numIn("cell_w", "Cell width", 1, 400, "")}${lbl("×")}${numIn("cell_h", "Cell height", 1, 400)}
        ${lbl("Lines")}${numIn("cell_gap", "The lines between the cells", 0, 50)}${lbl("Edge")}${numIn("outline", "The grid's outer edge", 0, 20)}
        ${lbl("◜")}${numIn("cell_radius", "Cell corners", 0, 100)}
        ${sep}${colIn("cell_rgb", "Cell colour")}${colIn("gap_rgb", "Grid line colour")}${colIn("outline_rgb", "Edge colour")}
        ${sep}${selIn("highlight_mode", [["line", "Lit cells: each line's colour"], ["fixed", "Lit cells: one colour"]], "The colour of a line's cells")}
        ${byLine && pal.length ? `${lbl("Line " + ln)}<input type="color" class="rlc-col" data-plpal="${(ln - 1) % pal.length}" value="${esc(hexOf(pal[(ln - 1) % pal.length]))}" title="Line ${ln}'s colour${pal.length < 50 ? ` (also lines ${(ln - 1) % pal.length + 1} + ${pal.length}·n)` : ""}">` : colIn("highlight_rgb", "Lit cells' colour")}
        <span class="ts-hint">corner: cell size</span>`;
    }
    if (S.sel === "badge") {
      const fonts = (App.state.fonts || []).slice().sort((a, b) => String(a).localeCompare(String(b))), cur = String(value("badge_font") || "");
      const fixed = String(value("badge_color_mode") || "line") === "fixed";
      return `${partsHtml()}${sep}<select class="ts-font" data-pl="badge_font" title="Number font">${(fonts.includes(cur) ? fonts : [cur].concat(fonts)).map((f) => `<option value="${esc(f)}" ${f === cur ? "selected" : ""}>${esc(f)}</option>`).join("")}</select>
        ${numIn("badge_font_size", "Number size", 4, 300)}${colIn("badge_text_rgb", "Number colour")}${lbl("↕")}${numIn("badge_text_dy", "Number up (−) / down (+)", -100, 100)}
        ${check("badge_shadow", "Outline + shadow", "The number's thin outline and shadow")}
        ${sep}${lbl("Badge")}${numIn("badge_w", "Badge width", 1, 400, "")}${lbl("×")}${numIn("badge_h", "Badge height", 1, 400)}${lbl("◜")}${numIn("badge_radius", "Badge corners", 0, 200)}
        ${selIn("badge_color_mode", [["line", "Badge: the line's colour"], ["fixed", "Badge: one colour"]], "Badge colour")}${fixed ? colIn("badge_rgb", "Badge colour") : ""}
        ${lbl("Edge")}${numIn("badge_stroke", "Badge outline", 0, 30)}${colIn("badge_stroke_rgb", "Badge outline colour")}${check("badge_gloss", "Shine", "A glossy shine on the badge")}
        <span class="ts-hint">drag a badge: all move · corner: badge size</span>`;
    }
    return "";
  }
  function wireBar(root) {
    root.querySelectorAll("[data-pl]").forEach((c) => c.addEventListener("change", () => {
      let v = c.type === "checkbox" ? c.checked : c.value;
      if (c.type === "number") {
        if (c.value === "" || !Number.isFinite(Number(c.value))) return;
        v = Number(c.value);
      }
      save({ [c.dataset.pl]: v });
    }));
    root.querySelectorAll("[data-plpal]").forEach((c) => c.addEventListener("change", () => {
      const pal = (value("palette") || []).slice();
      pal[Number(c.dataset.plpal)] = c.value;
      save({ palette: pal });
    }));
    root.querySelectorAll("[data-plalign]").forEach((b) => b.addEventListener("click", () => save({ align: b.dataset.plalign, offset_x: 0 })));
    root.querySelector("[data-plcols]")?.addEventListener("change", (e) => save({ columns: Number(e.target.value) }));
    root.querySelectorAll("[data-plfit]").forEach((b) => b.addEventListener("click", fit));
    root.querySelectorAll("[data-plpart]").forEach((b) => b.addEventListener("click", () => pick(b.dataset.plpart)));
    root.querySelector("[data-plbuild]")?.addEventListener("change", (e) => setBuilt(e.target.checked));
  }
  // this sheet's page in or out of the builds ("Sheet|count"; an old switch by count alone covered every sheet)
  function setBuilt(yes) {
    const p = page();
    if (!p) return;
    const off = new Set((value("pages_off") || []).map(String));
    if (yes) { off.delete(p.key); off.delete(String(p.count)); } else off.add(p.key);
    save({ pages_off: [...off] });
  }

  function deselect(partOnly) {
    if (!S.sel) return false;
    S.sel = null;
    paintFrames();
    return true;
  }
  // Esc: the part let go; the arrows nudge the picked lines (Shift: 10 px)
  document.addEventListener("keydown", (ev) => {
    if (!on() || !S.sel || (ev.target.closest && ev.target.closest("input, textarea, select, [contenteditable]"))) return;
    if (ev.key === "Escape") { pick(null); return; }
    const step = ev.shiftKey ? 10 : 1, d = { ArrowLeft: [-step, 0], ArrowRight: [step, 0], ArrowUp: [0, -step], ArrowDown: [0, step] }[ev.key];
    if (!d || S.sel !== "lines") return;
    ev.preventDefault();
    const out = {};
    if (d[0]) out.offset_x = Math.round(num("offset_x") + d[0]);
    const p = page();
    if (d[1] && p && p.block) {
      // from where the lines are drawn (a tall block sits above "bottom", not at "top")
      const gridTop = p.block[1] + Math.max(0, -num("badge_dy"));
      out.top = Math.max(0, Math.round(gridTop + d[1]));
      if (p.block[3] + d[1] > num("bottom")) out.bottom = Math.round(p.block[3] - gridTop + out.top);
    }
    save(out);
  });
  return { setSheets, isPl, on, kind, report, page, paintFrames, pageBarHtml, partBarHtml, wireBar, deselect, pick, fit, state: S };
})();
