/* Typography studio: a Photoshop-like strip over the live page. Click the heading or a paragraph
   on the page (or the Heading / Paragraph buttons) — the strip then edits that text: font, style,
   size, alignment, colour, and its layer style (a dropdown with the library and "Copy from
   Photoshop…"). Click an icon: the strip becomes its Icon bar (icon_studio.js). Double-click text
   to edit it on the page. The pages of the sheet are in the rail on the right (typo-preview.js). */
window.TypoStudio = (() => {
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const T = {
    heading: { label: "Heading", font: "h_font", style: "h_font_style", size: "h_size", color: "h_rgb",
               align: "alignment_settings.global.heading", role: "Heading text", aligns: ["left", "center", "right"] },
    body: { label: "Paragraph", font: "b_font", style: "b_font_style", size: "b_size", color: "b_rgb",
            align: "alignment_settings.global.body", role: "Body text",
            aligns: ["left", "center", "right", "justify_center"] },      // (older justify modes still draw)
    // rows made subheadings (row_roles.subheading_look reads these); empty = its default
    subheading: { label: "Subheading", font: "dynamic_settings.subheading_font_request", style: "dynamic_settings.subheading_font_style",
                  size: "dynamic_settings.subheading_size", color: "dynamic_settings.subheading_rgb", align: "",
                  role: "Subheading text", aligns: [], single: true,
                  def: { font: () => App.get("h_font"), style: () => "bold", size: () => 36, color: () => "#FFFFFF" } },
    // the "(Continued)" line on pages 2+ (row_roles.continued_look reads these); empty = its default
    continued: { label: "Continued", font: "dynamic_settings.continued_font", style: "dynamic_settings.continued_font_style",
                 size: "dynamic_settings.continued_size", color: "dynamic_settings.continued_rgb",
                 align: "dynamic_settings.continued_align",          // its own (row_roles.continued_align); empty = the heading's
                 role: "Continued text", aligns: ["left", "center", "right"], single: true,
                 def: { font: () => App.get("h_font"), size: () => Math.max(12, Math.floor((Number(App.get("h_size")) || 48) * 0.38)),
                        color: () => App.get("b_rgb") || "#FFFFFF" } },
    // Game Rules / Bingo Rules paragraphs (page: rules_canvas.js kind): each its own keys, never the other
    // pages' (png_builder's rules renderers read them); lh = line height key, trk = letter spacing key
    gr_rules: { label: "Rules text", page: "game_rules", font: "dynamic_settings.game_rules_body_font", style: "dynamic_settings.game_rules_body_font_style",
                size: "dynamic_settings.game_rules_body_size", color: "dynamic_settings.game_rules_body_rgb", align: "dynamic_settings.game_rules_body_align",
                role: "Game Rules text", aligns: ["left", "center", "right"], lh: "dynamic_settings.game_rules_row_gap", trk: "game_rules_tracking",
                def: { font: () => App.get("b_font"), size: () => App.get("b_size"), color: () => App.get("b_rgb") || "#FFFFFF" } },
    gr_legal: { label: "Legal text", page: "game_rules", font: "dynamic_settings.game_rules_bottom_font", style: "dynamic_settings.game_rules_bottom_font_style",
                size: "dynamic_settings.game_rules_bottom_font_size", color: "dynamic_settings.game_rules_bottom_rgb", align: "dynamic_settings.game_rules_legal_align",
                role: "Malfunction/legal text", aligns: ["left", "center", "right"], lh: "dynamic_settings.game_rules_legal_row_gap", trk: "game_rules_legal_tracking",
                def: { font: () => App.get("b_font"), size: () => Math.max(8, (Number(App.get("b_size")) || 24) - 8), color: () => App.get("b_rgb") || "#FFFFFF" } },
    bingo: { label: "Paragraph", page: "bingo_rules", font: "dynamic_settings.bingo_rules_font", style: "dynamic_settings.bingo_rules_font_style",
             size: "dynamic_settings.bingo_rules_body_size", color: "dynamic_settings.bingo_rules_rgb", align: "dynamic_settings.bingo_rules_align",
             role: "Bingo Rules text", aligns: ["left", "center", "right"], lh: "dynamic_settings.bingo_rules_row_gap", trk: "bingo_rules_tracking",
             def: { font: () => App.get("b_font"), size: () => App.get("b_size"), color: () => App.get("b_rgb") || "#FFFFFF" } },
  };
  // the page on the Canvas: "" (a normal page), "game_rules", "bingo_rules" or "paylines"; PE() = the
  // overlay that edits that page beyond its text (rules_canvas.js / paylines_canvas.js), else null
  const PE = () => (window.RulesCanvas && RulesCanvas.on() ? RulesCanvas : window.PaylinesCanvas && PaylinesCanvas.on() ? PaylinesCanvas : null);
  const pageKind = () => (PE() ? PE().kind() : "");
  const onPage = (k) => k === "heading" || (T[k] && (T[k].page || "") === pageKind());
  const firstText = () => ({ game_rules: "gr_rules", bingo_rules: "bingo", paylines: "heading" })[pageKind()] || "body";
  const hex = (v) => Array.isArray(v) ? "#" + v.slice(0, 3).map((n) => Math.max(0, Math.min(255, Number(n) || 0)).toString(16).padStart(2, "0")).join("") : v;
  const val = (t, k) => { const v = App.get(t[k]); return hex(v === "" || v == null ? (t.def && t.def[k] ? t.def[k]() : v) : v); };
  // Photoshop's paragraph buttons: four lines, the last one short (left / centred / right) or stretched
  const alIcon = (a) => {
    const last = { left: "l", center: "c", right: "r", justify: "l", justify_center: "c", justify_right: "r", justify_all: "f" }[a] || "c";
    const full = String(a).startsWith("justify"), at = (w, how) => (how === "l" ? 1 : how === "r" ? 15 - w : (16 - w) / 2);
    const rows = [[14, full ? "f" : last], [full ? 14 : 9, full ? "f" : last], [14, full ? "f" : last], [last === "f" ? 14 : 8, last]];
    return `<svg width="16" height="14" viewBox="0 0 16 14" aria-hidden="true">${rows.map(([w, how], i) => {
      const ww = how === "f" ? 14 : w;
      return `<rect x="${how === "f" ? 1 : at(ww, how)}" y="${1 + i * 3.4}" width="${ww}" height="1.6" fill="currentColor"/>`;
    }).join("")}</svg>`;
  };
  const AL_TITLES = { left: "Align left", center: "Align centre", right: "Align right", justify: "Justify — last line left",
                      justify_center: "Justify — full lines to both sides, the last line centred", justify_right: "Justify — last line right",
                      justify_all: "Justify all lines" };
  let target = "heading";

  const iconSel = () => (window.IconStudio && IconStudio.selected ? IconStudio.selected() : null);
  const tableSel = () => (window.TableStudio ? TableStudio.selected() : []);
  const wordSel = () => (window.AppTypoVis && AppTypoVis.state.wordSel) || [];
  const rowSel = () => !!(window.AppTypoVis && AppTypoVis.rowSelected && AppTypoVis.rowSelected());
  const boxSel = () => !!(window.AppTypoVis && AppTypoVis.boxSelected && AppTypoVis.boxSelected());
  const targetsHtml = (ic) => `<div class="ts-target">${Object.entries(T).filter(([k]) => onPage(k)).map(([k, v]) => `<button class="ts-tgt ${k === target ? "on" : ""}" data-tstarget="${k}" title="Edit the ${v.label.toLowerCase()} (or click it on the page)">${v.label}</button>`).join("")}${ic ? `<button class="ts-tgt ${target === "icon" ? "on" : ""}" data-tstarget="icon" title="The icon selected on the page">Icon</button>` : ""}${tableSel().length ? `<button class="ts-tgt ${target === "table" ? "on" : ""}" data-tstarget="table" title="The table selected on the page">Table</button>` : ""}${rowSel() && pageKind() !== "game_rules" ? `<button class="ts-tgt ${target === "row" ? "on" : ""}" data-tstarget="row" title="The row clicked on the page">Row</button>` : ""}${boxSel() ? `<button class="ts-tgt ${target === "box" ? "on" : ""}" data-tstarget="box" title="The text box clicked on the page">Box</button>` : ""}${wordSel().length ? `<button class="ts-tgt ${target === "words" ? "on" : ""}" data-tstarget="words" title="The text selected on the page">Selection</button>` : ""}${pageKind() ? `<button class="ts-tgt ${target === "rules_page" ? "on" : ""}" data-tstarget="rules_page" title="This page: build it${pageKind() === "game_rules" ? ", its XTRAA REELS icons" : pageKind() === "paylines" ? ", its heading text" : ""}">Page</button>` : ""}${target === "rules_part" && pageKind() !== "paylines" ? `<button class="ts-tgt on" data-tstarget="rules_part">${RulesCanvas.state.sel === "xtra" ? "XTRAA REELS" : "Separator"}</button>` : ""}</div>`;

  function stripHtml() {
    // a Game / Bingo Rules page: its own paragraphs (rules_canvas.js), the page, the separator / XTRAA REELS
    if (T[target] && !onPage(target)) target = firstText();
    if (target === "rules_page" || target === "rules_part") {
      const part = target === "rules_part" && pageKind() ? PE().partBarHtml() : "";
      if (part) return targetsHtml(null) + `<span class="ts-sep"></span>` + part;
      if (pageKind()) { target = "rules_page"; return targetsHtml(null) + `<span class="ts-sep"></span>` + PE().pageBarHtml(); }
      target = firstText();
    }
    // Icon mode: an icon clicked on the page — its size, which copies, gaps, picture (icon_studio.js)
    if (target === "icon") {
      const ic = iconSel();
      if (ic) return targetsHtml(ic) + `<span class="ts-sep"></span>` + IconStudio.barHtml(ic);
      // still picked, but the page is being drawn again (its icons not back yet): keep Icon mode
      if (window.IconStudio && IconStudio.state.sel) return targetsHtml(null) + `<span class="ts-sep"></span><span class="ts-hint">Updating the icon…</span>`;
      target = "body";                               // the icon is no longer selected
    }
    // Selection: text selected on the page — the same controls, for just that text (typo-preview.js)
    if (target === "words") {
      if (wordSel().length) return targetsHtml(null) + `<span class="ts-sep"></span>` + AppTypoVis.selectionBarHtml();
      target = lastText;
    }
    // Row: a line clicked on the page — what it is, its text's look, the strip behind it (typo-preview.js)
    if (target === "row") {
      if (rowSel()) return targetsHtml(null) + `<span class="ts-sep"></span>` + AppTypoVis.rowBarHtml();
      target = lastText;
    }
    // Box: a text box clicked on the page — its font, size, colour, layer style; put back (typo-preview.js)
    if (target === "box") {
      if (boxSel()) return targetsHtml(null) + `<span class="ts-sep"></span>` + AppTypoVis.boxBarHtml();
      target = lastText;
    }
    // Table mode: a table clicked on the page — its look, which tables, copy / paste (table_studio.js)
    if (target === "table") {
      if (tableSel().length) return targetsHtml(null) + `<span class="ts-sep"></span>` + TableStudio.barHtml();
      target = "body";
    }
    const t = T[target];
    const fonts = (App.state.fonts || []).slice().sort((a, b) => String(a).localeCompare(String(b)));
    const cur = String(val(t, "font") || "");
    const curFam = (App.fontFace && App.fontFace(cur) || {}).family || cur;      // "MyriadPro-Bold" shows as its family
    if (curFam && !fonts.some((f) => String(f).toLowerCase() === curFam.toLowerCase())) fonts.unshift(curFam);
    const style = String(val(t, "style") || "regular").toLowerCase();
    let align = String((t.page && RulesCanvas.paraAlign(target)) || (target === "body" && pageAlign(curSheet()))
      || (t.align && App.get(t.align)) || (target === "continued" && App.get(T.heading.align)) || "center").toLowerCase();
    if (target === "body" && align.startsWith("justify")) align = "justify_center";
    let color = String(val(t, "color") || "#FFFFFF");
    if (target === "heading" && headScope === "page") {          // this page's own heading (page_overrides[sheet])
      const ov = headOwn(curSheet());
      const fam = ov.h_font ? ((App.fontFace && App.fontFace(ov.h_font) || {}).family || ov.h_font) : curFam;
      if (fam && !fonts.some((f) => String(f).toLowerCase() === String(fam).toLowerCase())) fonts.unshift(fam);
      if (ov.h_rgb) color = hex(ov.h_rgb);
      return `${targetsHtml(iconSel())}
      <span class="ts-sep"></span>
      <span class="ts-ico" title="Font">𝐓</span>
      <select class="ts-font" data-tshp="h_font" title="This page's heading font">${fonts.map((f) => `<option value="${esc(f)}" ${String(f).toLowerCase() === String(fam).toLowerCase() ? "selected" : ""}>${esc(f)}</option>`).join("")}</select>
      <span class="ts-ico" title="Font size"><small>t</small>T</span>
      <input class="ts-size" type="number" min="6" max="400" data-tshp="h_size" value="${esc(ov.h_size != null && ov.h_size !== "" ? ov.h_size : val(t, "size"))}" title="This page's heading size (px)"><span class="ts-unit">px</span>
      ${headScopeHtml()}
      <span class="ts-sep"></span>
      <label class="ts-color" title="This page's heading colour"><input type="color" data-tshp="h_rgb" value="${esc(color)}"></label>
      ${plateBtnHtml()}${hideBtnHtml("heading")}${restoreBtnHtml()}
      <span class="ts-hint">only the heading of ${esc(curSheet())} — the other pages keep the game's heading</span>`;
    }
    return `${targetsHtml(iconSel())}
      <span class="ts-sep"></span>
      <span class="ts-ico" title="Font">𝐓</span>
      <select class="ts-font" data-key="${t.font}" data-font title="Font">${fonts.map((f) => `<option value="${esc(f)}" ${String(f).toLowerCase() === curFam.toLowerCase() ? "selected" : ""}>${esc(f)}</option>`).join("")}</select>
      <select class="ts-style" data-key="${t.style}" data-style-of="${t.font}" data-forced="${target === "heading" || target === "subheading" ? 1 : 0}" title="Style">${App.fontStyleHtml(cur, val(t, "style"), target === "heading" || target === "subheading")}</select>
      <span class="ts-ico" title="Font size"><small>t</small>T</span>
      ${target === "body" && !t.page ? paraSizeHtml()
        : `<input class="ts-size" type="number" min="6" max="400" data-key="${t.size}" value="${esc(val(t, "size"))}" title="Font size (px)"><span class="ts-unit">px</span>`}
      ${target === "heading" ? headScopeHtml() : ""}
      ${t.single ? "" : `<span class="ts-ico" title="Line height — the space between lines">A<span class="ts-lh">↕</span>A</span>
      <input class="ts-size" type="number" min="0" max="400" data-tslh value="${esc(lineHeight())}" title="Line height (px between lines)"><span class="ts-unit">px</span>
      <span class="ts-ico" title="Letter spacing (tracking, 1/1000 em — like Photoshop)">V<span class="ts-lh">↔</span>A</span>
      <input class="ts-size" type="number" min="-200" max="1000" step="10" data-tsls value="${esc(letterSpacing())}" title="Letter spacing (1/1000 em)">`}
      <span class="ts-sep"></span>
      ${t.aligns.length ? t.aligns.map((a) => `<button class="ts-al ${a === align ? "on" : ""}" data-tsalign="${a}" title="${AL_TITLES[a] || "Align " + a}">${alIcon(a)}</button>`).join("")
        + (target === "body" && !t.page ? paraPagesHtml() : "") + `<span class="ts-sep"></span>` : ""}
      <label class="ts-color" title="Colour"><input type="color" data-key="${t.color}" value="${esc(color)}"></label>
      <span class="ts-sep"></span>
      ${fxButtonHtml(t)}
      ${t.page ? RulesCanvas.extraHtml(target) : ""}
      ${target === "heading" && window.AppTypoVis && AppTypoVis.headingRowRules && AppTypoVis.headingRowRules().length
        ? `<span class="ts-sep"></span><button class="ts-tgt" data-tsheadclear title="The heading has a look of its own from before (set while it was picked as a row) — it wins over these settings. Clear it.">Clear its own look</button>` : ""}
      ${target === "heading" ? plateBtnHtml() : ""}${hideBtnHtml(target)}${restoreBtnHtml()}
      <span class="ts-hint">click text: its frame · double-click: its row, typing · then double-click a word, triple-click a line · Esc = back</span>`;
  }

  /* the page heading / "(Continued)" deleted (dynamic_settings.hidden_parts[sheet], read by page_boxes.hidden
     — the Canvas and the builds): "heading_main" the heading on the page's first page, "heading_cont" on its
     Continued pages ("heading" from before = both), "continued" the "(Continued)" line. The text moves up into
     its place, e.g. under a row the artist made a heading instead. ♻ Restore brings back what is picked. */
  const hiddenOn = (sheet) => {
    const all = (App.state.config.dynamic_settings || {}).hidden_parts || {};
    const k = Object.keys(all).find((x) => x.toLowerCase() === String(sheet).toLowerCase());
    const out = new Set(((k && all[k]) || []).map((p) => String(p).toLowerCase()));
    if (out.delete("heading")) { out.add("heading_main"); out.add("heading_cont"); }
    return out;
  };
  const onContPage = () => ((window.AppLive && AppLive.state && AppLive.state.page) || 0) > 0;
  const hasContPages = () => ((window.AppLive && AppLive.state && AppLive.state.pages) || []).length > 1;
  function hideBtnHtml(part) {
    if (!["heading", "continued"].includes(part) || pageKind() || !curSheet()) return "";
    const gone = hiddenOn(curSheet());
    if (part === "continued") {
      return gone.has("continued")
        ? `<span class="ts-sep"></span><button class="ts-tgt on" data-tshide="continued" data-on="1" title="Put “(Continued)” back on the Continued pages">↺ Bring back “(Continued)”</button>`
        : `<span class="ts-sep"></span><button class="ts-tgt" data-tshide="continued" data-on="0" title="Take “(Continued)” off this page's Continued pages (the text moves up). ♻ Restore brings it back.">🗑 Delete “(Continued)”</button>`;
    }
    const here = onContPage() ? "heading_cont" : "heading_main", where = onContPage() ? "the Continued pages" : "this page";
    return gone.has(here)
      ? `<span class="ts-sep"></span><button class="ts-tgt on" data-tshide="${here}" data-on="1" title="Put the heading back on ${where}">↺ Bring back the heading</button><span class="ts-hint">deleted on ${where}</span>`
      : `<span class="ts-sep"></span><button class="ts-tgt" data-tshide="heading" data-on="0" title="Take the heading off (the text moves up into its place — make a row the heading instead). ♻ Restore brings it back.">🗑 Delete heading</button>`;
  }
  // the heading deleted: on a Continued page (or a page that has some) — from the main page too, or not?
  function askHeadingDelete() {
    const cont = onContPage();
    if (!cont && !hasContPages()) return Promise.resolve(["heading_main"]);
    return new Promise((done) => {
      const ov = document.createElement("div");
      ov.className = "overlay";
      ov.innerHTML = `<div class="canvas-dialog" style="max-width:480px"><div class="canvas-dialog-title">${cont ? "Delete the heading from the main page too?" : "Delete the heading from the Continued pages too?"}</div>
        <div class="canvas-sub">${esc(curSheet())} — ♻ Restore in the top bar brings it back any time.</div>
        <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:12px">
          <button class="btn secondary" data-hd="cancel">Cancel</button>
          <button class="btn secondary" data-hd="one">${cont ? "No — only the Continued pages" : "No — only this page"}</button>
          <button class="btn primary" data-hd="both">${cont ? "Yes — the main page too" : "Yes — the Continued pages too"}</button></div></div>`;
      document.body.appendChild(ov);
      ov.addEventListener("click", (ev) => {
        const b = ev.target.closest("[data-hd]");
        if (!b) return;
        ov.remove();
        done(b.dataset.hd === "cancel" ? null : b.dataset.hd === "both" ? ["heading_main", "heading_cont"] : [cont ? "heading_cont" : "heading_main"]);
      });
    });
  }
  async function setHidden(parts, hide) {
    const sheet = curSheet();
    if (!sheet || !parts || !parts.length) return;
    const ds = (App.state.config.dynamic_settings = App.state.config.dynamic_settings || {});
    const all = Object.assign({}, ds.hidden_parts || {});
    const k = Object.keys(all).find((x) => x.toLowerCase() === sheet.toLowerCase()) || sheet;
    const now = hiddenOn(sheet);
    parts.forEach((p) => (hide ? now.add(p) : now.delete(p)));
    if (now.size) all[k] = [...now]; else delete all[k];
    App.set("dynamic_settings.hidden_parts", all);
    await saveAndRedraw();
    const NAME = { heading_main: "the heading (main page)", heading_cont: "the heading (Continued pages)", continued: "“(Continued)”" };
    const what = parts.map((p) => NAME[p] || p).join(" and ");
    if (typeof toast === "function") toast(hide ? `Deleted ${what} on ${sheet} — ♻ Restore brings it back.` : `Back on ${sheet}: ${what}.`);
  }
  async function saveAndRedraw() {
    App.refreshUI();
    if (App.flushConfig) await App.flushConfig();
    if (window.AppTypoVis && AppTypoVis.refreshPreview) await AppTypoVis.refreshPreview(true);
    paint();
  }

  /* the heading plate: a shape behind each page's heading, fit to its text (page_boxes.heading_plate —
     the Canvas and the builds). One look for every heading (dynamic_settings.heading_plate), or this page's
     own (heading_plates[sheet]: its own look, or off) */
  const plateAll = () => (App.state.config.dynamic_settings || {}).heading_plate || null;
  const plateOwnKey = (sheet) => Object.keys((App.state.config.dynamic_settings || {}).heading_plates || {}).find((x) => x.toLowerCase() === String(sheet).toLowerCase());
  const plateOwn = (sheet) => { const k = plateOwnKey(sheet); return k ? App.state.config.dynamic_settings.heading_plates[k] : null; };
  const plateNow = (sheet) => plateOwn(sheet) || plateAll() || null;
  function plateBtnHtml() {
    if (pageKind() || !curSheet()) return "";
    const p = plateNow(curSheet()), on = !!(p && p.on);
    const clip = window.PshLook && PshLook.clip;
    return `<span class="ts-sep"></span><button class="ts-tgt ${on ? "on" : ""}" data-tsplate title="A plate behind the heading, fit to its text — every heading or this page's own">▭ Plate${plateOwn(curSheet()) ? " (this page)" : ""} ▾</button>
      <button class="ts-al" data-tsplatecopy ${on ? "" : "disabled"} title="${on ? "Copy the plate's look (paste it on a paytable card, a row strip, another plate)" : "No plate to copy"}">⧉</button><button class="ts-al" data-tsplatepaste ${clip ? "" : "disabled"} title="${clip ? `Paste the look of ${esc(clip.from)} on the plate` : "Copy a look first (a paytable card, a row strip, a plate: ⧉)"}">📋</button>`;
  }
  async function platePop(anchor) {
    if (!platePop.looks) {                            // the paytable's card looks, offered for the plate
      try { platePop.looks = ((await (await fetch("/api/card_looks")).json()) || {}).looks || []; } catch (e) { platePop.looks = []; }
    }
    document.querySelector(".ts-plate")?.remove();
    const sheet = curSheet(), own = !!plateOwn(sheet);
    let scope = own ? "page" : "all";
    const pop = document.createElement("div");
    pop.className = "tsel-pop vis-style-bar ts-plate";
    const row = (lab, html, tip) => `<label class="vsb-scope" style="display:flex;align-items:center;gap:6px;margin:3px 0" title="${esc(tip || "")}"><span style="width:78px">${lab}</span>${html}</label>`;
    const render = () => {
      const p = Object.assign({ on: false, color: "#1e3a8a", opacity: 0.85, pad_x: 40, pad_y: 12, radius: 12, border: {}, fx: "" },
        scope === "page" ? (plateOwn(sheet) || plateAll() || {}) : (plateAll() || {}));
      const bd = p.border || {};
      pop.innerHTML = `<div class="vsb-head"><b>Heading plate</b><button class="vsb-x" data-x title="Close">✕</button></div>
        ${row("Headings", `<select class="ts-style" data-pscope style="flex:1"><option value="all" ${scope === "all" ? "selected" : ""}>Every page's heading</option><option value="page" ${scope === "page" ? "selected" : ""}>Only ${esc(sheet)}</option></select>`, "Every heading together, or this page's heading on its own")}
        ${row("Plate", `<input type="checkbox" data-p="on" ${p.on ? "checked" : ""}> on`)}
        ${row("Colour", `<input type="color" data-p="color" value="${esc(p.color || "#1e3a8a")}"> <input type="number" class="ts-size" data-p="opacity" min="0" max="100" value="${Math.round((p.opacity == null ? 0.85 : Number(p.opacity)) * 100)}"><span class="ts-unit">%</span>`)}
        ${Array.isArray(p.pads) ? row("Size", `<input type="checkbox" data-p="pads" checked> as sized on the page`, "Its size and place as dragged on the page (its margin on each side of the heading). Off: the padding below sizes it again") : ""}
        ${row("Padding", `↔ <input type="number" class="ts-size" data-p="pad_x" min="-200" max="2000" value="${Number(p.pad_x) || 0}"> ↕ <input type="number" class="ts-size" data-p="pad_y" min="-200" max="2000" value="${Number(p.pad_y) || 0}"><span class="ts-unit">px</span>`, "Room around the heading's text: left and right, above and below")}
        ${row("Corners", `<input type="number" class="ts-size" data-p="radius" min="0" max="2000" value="${Number(p.radius) || 0}"><span class="ts-unit">px</span>`)}
        ${row("Border", `<input type="number" class="ts-size" data-p="bw" min="0" max="200" value="${Number(bd.width) || 0}"><span class="ts-unit">px</span> <input type="color" data-p="bc" value="${esc(bd.color || "#ffffff")}">`)}
        ${row("Layer style", `<button class="ts-tgt" data-pfx>${esc(typeof p.fx === "object" && p.fx ? "Its own" : p.fx || "None")} ▾</button>`)}
        ${row("Card look", `<select class="ts-style" data-plook style="flex:1"><option value="">${p.fill_to || p.corner || p.corners ? "As it is" : "None"}</option>${(platePop.looks || []).map((l) => `<option value="${esc(l.id)}">${esc(l.name)}</option>`).join("")}</select>`, "A paytable card look on the plate: its colours, gradient, corners, border and glow")}
        <div class="tsp-embed ts-plate-look">${window.PshLook ? PshLook.editorHtml(p) : ""}</div>
        <div class="vsb-row" style="gap:6px;justify-content:flex-end;margin-top:6px">
          ${scope === "page" && own ? `<button class="pt-btn secondary small" data-pdrop title="This page follows every heading's plate again">↺ Like every heading</button>` : ""}
          <button class="pt-btn small" data-ok>Apply</button></div>`;
      pop.querySelector("[data-x]").addEventListener("click", () => pop.remove());
      pop.querySelector("[data-pscope]").addEventListener("change", (e) => { scope = e.target.value; render(); });
      pop.querySelector("[data-pfx]").addEventListener("click", (e) => fxPicker(e.currentTarget, pop.dataset.fx != null ? pop.dataset.fx : (p.fx || ""), (name) => { pop.dataset.fx = name || ""; e.currentTarget.textContent = (name || "None") + " ▾"; }, "None"));
      pop.querySelector("[data-pdrop]")?.addEventListener("click", () => { pop.remove(); savePlate("page", null); });
      // gradient, corner shape, glow & shadow: saved as they change (the plate redraws), the pop-over stays
      if (window.PshLook) PshLook.wireEditor(pop.querySelector(".ts-plate-look"), p, async (ch) => {
        const cur = Object.assign({}, scope === "page" ? (plateOwn(sheet) || plateAll() || {}) : (plateAll() || {}), { on: true });
        Object.entries(ch).forEach(([k, v]) => { if (v == null) delete cur[k]; else cur[k] = v; });
        await savePlate(scope, cur);
        render();
      });
      pop.querySelector("[data-ok]").addEventListener("click", () => {
        const q = (k) => pop.querySelector(`[data-p="${k}"]`);
        const lk = (platePop.looks || []).find((l) => l.id === pop.querySelector("[data-plook]").value);
        if (lk) { pop.remove(); savePlate(scope, Object.assign(PshLook.applyToRule(p, Object.assign({}, lk.style, { fx: lk.fx || "" })), { on: true })); return; }
        const v = { on: q("on").checked, color: q("color").value, opacity: Math.max(0, Math.min(100, Number(q("opacity").value) || 0)) / 100,
                    pad_x: Math.round(Number(q("pad_x").value) || 0), pad_y: Math.round(Number(q("pad_y").value) || 0),
                    radius: Math.max(0, Math.round(Number(q("radius").value) || 0)),
                    fx: pop.dataset.fx != null ? pop.dataset.fx : (p.fx || "") };
        if (Array.isArray(p.pads) && q("pads") && q("pads").checked) v.pads = p.pads.slice();     // sized on the page: kept
        ["corner", "corners", "radii", "fill_to", "gradient_dir", "gradient_amount"].forEach((k) => { if (p[k] != null) v[k] = p[k]; });   // its card look stays
        if (pop.dataset.fx == null && p.fx && typeof p.fx === "object") v.fx = p.fx;
        const bw = Math.max(0, Math.round(Number(q("bw").value) || 0));
        if (bw) v.border = { width: bw, color: q("bc").value, opacity: 100, align: "inside" };
        pop.remove();
        savePlate(scope, v);
      });
    };
    render();
    document.body.appendChild(pop);
    const r = anchor.getBoundingClientRect();
    Object.assign(pop.style, { position: "fixed", left: Math.max(8, Math.min(innerWidth - 330, r.left - 100)) + "px", top: (r.bottom + 6) + "px", zIndex: 9999, width: "310px" });
    ["mousedown", "pointerdown"].forEach((ty) => pop.addEventListener(ty, (ev) => ev.stopPropagation()));
  }
  async function savePlate(scope, v) {
    const sheet = curSheet(), ds = (App.state.config.dynamic_settings = App.state.config.dynamic_settings || {});
    if (scope === "all") {
      ds.heading_plate = v;
      // every heading: the pages with a plate of their own keep it (↺ in their popup lets them follow)
    } else {
      const all = Object.assign({}, ds.heading_plates || {}), k = plateOwnKey(sheet) || sheet;
      if (v) all[k] = v; else delete all[k];
      if (Object.keys(all).length) ds.heading_plates = all; else delete ds.heading_plates;
    }
    await saveAndRedraw();
    if (typeof toast === "function") toast(scope === "all" ? `Every heading's plate ${v && v.on ? "on" : "off"}.` : v ? `${sheet}: its own heading plate.` : `${sheet}: like every heading.`);
  }

  /* ♻ Restore: what was deleted on this page — the heading (main / Continued pages), "(Continued)", and
     words or symbols taken out of a row while typing (text_edits: its Excel text "from", what shows "to").
     Only the items ticked come back: a removed word or symbol goes back where it was in its row. */
  const unitsOf = (t) => String(t || "").match(/\s*(?:<[^<>]+>|[^\s<]+|<)/g) || [];
  const unitKey = (u) => u.trim().replace(/<([^<>]*?)(?:~\d+(?:\.\d+)?(?:\^[\d.]+,[\d.]+)?|\^[\d.]+,[\d.]+)\s*>/g, "<$1>").toLowerCase();
  // from → to as units: equal / deleted (from) / inserted (to) — a plain LCS, rows are short
  function diffUnits(from, to) {
    const a = unitsOf(from), b = unitsOf(to), A = a.map(unitKey), B = b.map(unitKey);
    const L = Array.from({ length: a.length + 1 }, () => new Array(b.length + 1).fill(0));
    for (let i = a.length - 1; i >= 0; i--) for (let j = b.length - 1; j >= 0; j--) L[i][j] = A[i] === B[j] ? L[i + 1][j + 1] + 1 : Math.max(L[i + 1][j], L[i][j + 1]);
    const ops = [];
    let i = 0, j = 0;
    while (i < a.length || j < b.length) {
      if (i < a.length && j < b.length && A[i] === B[j]) { ops.push({ t: "eq", u: b[j] }); i++; j++; }
      else if (j < b.length && (i >= a.length || L[i][j + 1] >= L[i + 1][j])) { ops.push({ t: "ins", u: b[j] }); j++; }
      else { ops.push({ t: "del", u: a[i] }); i++; }
    }
    let run = -1, prevDel = false;                        // consecutive deletions: one item to restore
    ops.forEach((o) => { if (o.t === "del") { if (!prevDel) run++; o.run = run; prevDel = true; } else prevDel = false; });
    return ops;
  }
  function removedItems(sheet) {
    const edits = (((App.state.config.dynamic_settings || {}).text_edits) || {})[sheet] || {}, out = [];
    Object.entries(edits).forEach(([key, ed]) => {
      if (!ed || !String(ed.to || "").trim()) return;      // a row joined into the one above: not a deletion
      const runs = {};
      diffUnits(ed.from, ed.to).forEach((o) => { if (o.t === "del") (runs[o.run] = runs[o.run] || []).push(o.u.trim()); });
      Object.entries(runs).forEach(([run, us]) => {
        const text = us.join(" "), sym = /^<[^<>]+>$/.test(text);
        out.push({ id: `te|${key}|${run}`, key, run: Number(run), label: `${key.replace("row:", "Row ")}: ${sym ? "symbol " : ""}${text.length > 40 ? text.slice(0, 40) + "…" : text}` });
      });
    });
    return out;
  }
  function restoreItems() {
    const sheet = curSheet();
    if (!sheet || pageKind()) return [];
    const gone = hiddenOn(sheet), items = [];
    if (gone.has("heading_main")) items.push({ id: "hp|heading_main", label: "Heading — main page" });
    if (gone.has("heading_cont")) items.push({ id: "hp|heading_cont", label: "Heading — Continued pages" });
    if (gone.has("continued")) items.push({ id: "hp|continued", label: "“(Continued)” line" });
    return items.concat(removedItems(sheet));
  }
  function restoreBtnHtml() {
    const n = restoreItems().length;
    return n ? `<span class="ts-sep"></span><button class="ts-tgt" data-tsrestore title="Bring back what was deleted on this page — pick which">♻ Restore (${n}) ▾</button>` : "";
  }
  function restorePop(anchor) {
    document.querySelector(".ts-restore")?.remove();
    const items = restoreItems();
    if (!items.length) return;
    const pop = document.createElement("div");
    pop.className = "tsel-pop vis-style-bar ts-restore";
    pop.innerHTML = `<div class="vsb-head"><b>Restore on ${esc(curSheet())}</b><button class="vsb-x" data-x title="Close">✕</button></div>
      <div class="hint" style="margin:2px 0 6px">Tick what should come back — only those return.</div>
      <div style="display:flex;flex-direction:column;gap:4px;max-height:50vh;overflow:auto">${items.map((it) => `<label class="vsb-scope" style="display:flex;gap:6px;align-items:center"><input type="checkbox" data-ri="${esc(it.id)}"> ${esc(it.label)}</label>`).join("")}</div>
      <div class="vsb-row" style="gap:6px;justify-content:flex-end;margin-top:8px">
        <button class="pt-btn secondary small" data-all>Tick all</button><button class="pt-btn small" data-ok>Restore ticked</button></div>`;
    document.body.appendChild(pop);
    const r = anchor.getBoundingClientRect();
    Object.assign(pop.style, { position: "fixed", left: Math.max(8, Math.min(innerWidth - 340, r.left - 60)) + "px", top: (r.bottom + 6) + "px", zIndex: 9999, width: "320px" });
    ["mousedown", "pointerdown"].forEach((ty) => pop.addEventListener(ty, (ev) => ev.stopPropagation()));
    pop.querySelector("[data-x]").addEventListener("click", () => pop.remove());
    pop.querySelector("[data-all]").addEventListener("click", () => pop.querySelectorAll("[data-ri]").forEach((c) => { c.checked = true; }));
    pop.querySelector("[data-ok]").addEventListener("click", async () => {
      const ids = [...pop.querySelectorAll("[data-ri]:checked")].map((c) => c.dataset.ri);
      if (!ids.length) return;
      pop.remove();
      await restore(ids);
    });
  }
  async function restore(ids) {
    const sheet = curSheet(), ds = (App.state.config.dynamic_settings = App.state.config.dynamic_settings || {});
    const parts = ids.filter((id) => id.startsWith("hp|")).map((id) => id.slice(3));
    if (parts.length) {
      const all = Object.assign({}, ds.hidden_parts || {}), k = Object.keys(all).find((x) => x.toLowerCase() === sheet.toLowerCase()) || sheet;
      const now = hiddenOn(sheet);
      parts.forEach((p) => now.delete(p));
      if (now.size) all[k] = [...now]; else delete all[k];
      ds.hidden_parts = all;
    }
    const byRow = {};
    ids.filter((id) => id.startsWith("te|")).forEach((id) => { const [, key, run] = id.split("|"); (byRow[key] = byRow[key] || new Set()).add(Number(run)); });
    if (Object.keys(byRow).length) {
      const te = JSON.parse(JSON.stringify(ds.text_edits || {})), mine = te[sheet] || {};
      Object.entries(byRow).forEach(([key, runs]) => {
        const ed = mine[key];
        if (!ed) return;
        let out = "";
        diffUnits(ed.from, ed.to).forEach((o) => {
          if (o.t !== "del") out += o.u;
          else if (runs.has(o.run)) out += (out && !/\s$/.test(out) ? " " : "") + o.u.trim();   // back where it was
        });
        const norm = (t) => String(t || "").replace(/\s+/g, " ").trim();
        if (norm(out) === norm(ed.from)) delete mine[key]; else mine[key] = Object.assign({}, ed, { to: out.replace(/^\s+/, "") });
      });
      if (Object.keys(mine).length) te[sheet] = mine; else delete te[sheet];
      ds.text_edits = te;
    }
    await saveAndRedraw();
    if (typeof toast === "function") toast(`Restored ${ids.length} item${ids.length > 1 ? "s" : ""} on ${sheet}.`);
  }

  /* the heading: the game's (every page), or this page's own font, size and colour — page_overrides[sheet]
     h_font / h_size / h_rgb, read by the build, the Canvas and the paytable's title (each page's heading
     can look different) */
  let headScope = "all";
  const headOwn = (sheet) => {
    const all = App.get("page_overrides") || {}, k = Object.keys(all).find((x) => x.toLowerCase() === String(sheet).toLowerCase());
    return (k && all[k]) || {};
  };
  const hasOwnHead = (sheet) => ["h_font", "h_size", "h_rgb"].some((k) => headOwn(sheet)[k] != null && headOwn(sheet)[k] !== "");
  function headScopeHtml() {
    const own = hasOwnHead(curSheet());
    return `<select class="ts-style ts-narrow" data-tshscope title="Every page's heading, or only this page's">
        ${[["all", "All pages"], ["page", "This page"]].map(([v, l]) => `<option value="${v}" ${v === headScope ? "selected" : ""}>${l}</option>`).join("")}
      </select>${own ? `<button class="ts-tgt" data-tshreset title="This page's heading has a look of its own — back to the game's heading">↺ own</button>` : ""}`;
  }
  async function setPageHeading(key, value) {
    const sheet = curSheet();
    if (!sheet) return;
    const all = Object.assign({}, App.get("page_overrides") || {});
    const k = Object.keys(all).find((x) => x.toLowerCase() === sheet.toLowerCase()) || sheet;
    const ov = Object.assign({}, all[k] || {});
    if (value == null || value === "") delete ov[key]; else ov[key] = value;
    if (Object.keys(ov).length) all[k] = ov; else delete all[k];
    App.set("page_overrides", all);
    App.refreshUI();
    if (App.flushConfig) await App.flushConfig();
    if (window.AppTypoVis && AppTypoVis.refreshPreview) AppTypoVis.refreshPreview(true);
    paint();
  }

  /* the paragraph's size: ALL its text that size — the lines and selections given a size of their own
     on those pages too. Where: every page (the game's size), this page, or pages picked from a list
     (each page its own size: page_overrides[sheet].b_size, read by the Canvas and the build) */
  let paraScope = "all";
  const curSheet = () => String((window.AppTypoVis && AppTypoVis.state.sheet) || "");
  const allSheets = () => [...((document.getElementById("typoVisSheet") || {}).options || [])].map((o) => o.value).filter(Boolean);
  function pageSize(sheet) {
    const ov = (App.get("page_overrides") || {})[sheet] || {};
    return ov.b_size != null && ov.b_size !== "" ? ov.b_size : App.get("b_size");
  }
  function paraSizeHtml() {
    const own = ((App.get("page_overrides") || {})[curSheet()] || {}).b_size != null;
    return `<input class="ts-size" type="number" min="6" max="400" data-tsbsize value="${esc(pageSize(curSheet()))}" title="The paragraph's size (px): all of its text, lines with a size of their own too">
      <span class="ts-unit">px</span>
      <select class="ts-style ts-narrow" data-tsbscope title="Which pages the paragraph size goes to">
        ${[["all", "All pages"], ["page", "This page"], ["pick", "Pick pages…"]].map(([v, l]) => `<option value="${v}" ${v === paraScope ? "selected" : ""}>${l}</option>`).join("")}
      </select>${own ? `<span class="ts-hint" title="This page has a paragraph size of its own">this page's own</span>` : ""}`;
  }
  async function setParagraphSize(px, sheets) {
    const v = Math.max(6, Math.min(400, Math.round(Number(px) || 0)));
    if (!v) return;
    const every = !sheets, cfg = App.state.config, ds = (cfg.dynamic_settings = cfg.dynamic_settings || {});
    const fold = (x) => String(x || "").trim().toLowerCase(), mine = new Set((sheets || []).map(fold));
    const ov = Object.assign({}, cfg.page_overrides || {});
    if (every) {
      App.set("b_size", v);
      Object.keys(ov).forEach((k) => { if (ov[k] && ov[k].b_size != null) { ov[k] = Object.assign({}, ov[k]); delete ov[k].b_size; } });
    } else sheets.forEach((sh) => { ov[sh] = Object.assign({}, ov[sh] || {}, { b_size: v }); });
    App.set("page_overrides", ov);
    // sizes of lines / selections on those pages go: a page's rule loses its size there, a game-wide
    // rule keeps it on the other pages only
    let n = 0;
    ds.text_style_rules = (Array.isArray(ds.text_style_rules) ? ds.text_style_rules : []).map((r) => {
      if (!r || r.kind === "strip" || r.size == null) return r;
      const one = ["page", "row"].includes(String(r.scope || "game").toLowerCase());
      if (every || (one && mine.has(fold(r.sheet)))) { n++; const x = Object.assign({}, r); delete x.size; delete x.size_off; return x; }
      if (one) return r;
      n++;
      return Object.assign({}, r, { size_off: [...new Set([...(r.size_off || []), ...sheets])] });
    });
    App.refreshUI();
    if (App.flushConfig) await App.flushConfig();
    if (window.AppTypoVis && AppTypoVis.refreshPreview) AppTypoVis.refreshPreview(true);
    paint();
    const where = every ? "every page" : sheets.length === 1 ? sheets[0] : `${sheets.length} pages`;
    if (typeof toast === "function") toast(`Paragraph ${v}px on ${where}${n ? ` — ${n} line / selection size${n > 1 ? "s" : ""} now the same` : ""}.`);
  }
  function pickPages(anchor, px) {
    pagesPop(anchor, `Paragraph ${Math.round(Number(px) || 0)}px on…`, (sh) => `${pageSize(sh)}px`, (picked) => setParagraphSize(px, picked));
  }
  function applyParaSize(strip) {
    const inp = strip.querySelector("[data-tsbsize]"), sc = strip.querySelector("[data-tsbscope]");
    if (!inp) return;
    if (paraScope === "pick") pickPages(sc || inp, inp.value);
    else setParagraphSize(inp.value, paraScope === "page" ? [curSheet()] : null);
  }

  /* the paragraph's alignment and margins, every page or page by page: alignment_settings.overrides[sheet]
     (png_builder._text_alignment — the Canvas and the build) and page_boxes' body_boxes[sheet] (its sides,
     where it starts on page 1, where it moves on to a Continued page) */
  let alScope = "all";
  const alOverrides = () => {
    let o = (App.get("alignment_settings") || {}).overrides || {};
    if (typeof o === "string") { try { o = o.trim() ? JSON.parse(o) : {}; } catch (e) { o = {}; } }
    return o && typeof o === "object" ? o : {};
  };
  function pageAlign(sheet) {
    const o = alOverrides(), own = o[sheet] || Object.entries(o).find(([k]) => k.toLowerCase() === String(sheet).toLowerCase())?.[1];
    return own && own.use_global === false && own.body ? String(own.body) : "";
  }
  const pageHasMargins = (sheet) => Object.keys(((App.state.config.dynamic_settings || {}).body_boxes || {})[sheet] || {}).length > 0;
  function paraPagesHtml() {
    const sheet = curSheet(), ownAl = !!pageAlign(sheet), ownM = pageHasMargins(sheet);
    return `<select class="ts-style ts-narrow" data-tsalscope title="Which pages the alignment goes to">
        ${[["all", "All pages"], ["page", "This page"], ["pick", "Pick pages…"]].map(([v, l]) => `<option value="${v}" ${v === alScope ? "selected" : ""}>${l}</option>`).join("")}
      </select>${ownAl ? `<button class="ts-tgt" data-tsalreset title="This page has an alignment of its own — back to the alignment of all pages">↺ own</button>` : ""}
      <span class="ts-sep"></span>
      <span class="ts-ico" title="The paragraph box on the background">▭</span>
      ${["left", "center", "right"].map((a) => `<button class="ts-al" data-tsboxal="${a}" title="The paragraph box: ${a === "center" ? "centred" : "to the " + a} on the background (the pages chosen beside the alignment)">${boxIcon(a)}</button>`).join("")}
      <button class="ts-tgt ${ownM ? "on" : ""}" data-tsmargins title="The paragraph's margins: on this page, picked pages or every page">▭ Margins${ownM ? " ·" : ""}</button>`;
  }
  // the paragraph box on the background: a frame and a filled block inside it
  const boxIcon = (a) => {
    const x = a === "left" ? 2 : a === "right" ? 8 : 5;
    return `<svg width="16" height="14" viewBox="0 0 16 14" aria-hidden="true"><rect x="0.5" y="0.5" width="15" height="13" rx="1.5" fill="none" stroke="currentColor" stroke-width="1"/><rect x="${x}" y="3" width="6" height="8" fill="currentColor"/></svg>`;
  };
  /* where the background picture is on the page (canvas px x, y, w, h): its PSD rectangle when placed,
     else the whole page (bg_place.area) */
  function bgArea() {
    const c = App.state.config || {}, W = Number(c.c_width) || 1920, H = Number(c.c_height) || 1080;
    const r = Array.isArray(c.bg_rect) ? c.bg_rect.map(Number) : String(c.bg_rect || "").split(",").map(Number);
    if (String(c.bg_source || "image") !== "color" && String(c.bg_mode || "") === "place" && r.length === 4 && r.every(isFinite) && r[2] > 0 && r[3] > 0) {
      const x0 = Math.max(0, r[0]), y0 = Math.max(0, r[1]);
      return [x0, y0, Math.min(W, r[0] + r[2]) - x0, Math.min(H, r[1] + r[3]) - y0];
    }
    return [0, 0, W, H];
  }
  /* the paragraph box (its width kept) to the left / centre / right of the background on these pages: its
     sides into page_boxes.body_boxes. Left / right sit the project's side margin in from the background's
     edge (its text area's gap, as on the other pages) — never the box's own gap, which centring evens out. */
  async function alignParagraphBox(a, sheets) {
    const f = paraFrameNow(), [bx, , bw] = bgArea();
    if (f.left == null) { if (typeof toast === "function") toast("This page has no paragraph box to place.", "err"); return; }
    const ds = (App.state.config.dynamic_settings = App.state.config.dynamic_settings || {});
    const all = Object.assign({}, ds.body_boxes || {});
    const dflt = { left: f.left, right: f.W - f.right };                // this page's box (the project's when it has none)
    const cur = curSheet();
    const pd = paraDefault(), inset = Math.max(0, pd.left - bx, bx + bw - pd.right);
    sheets.forEach((sh) => {
      const own = all[sh] || {};
      const left = own.left != null ? Number(own.left) : sh === cur ? dflt.left : (all[cur] ? Number(paraDefault().left) : dflt.left);
      const right = own.right != null ? Number(own.right) : sh === cur ? dflt.right : (all[cur] ? Number(paraDefault().right) : dflt.right);
      const w = Math.max(40, right - left);
      const gap = Math.max(0, Math.min(inset, bw - w));
      const nl = a === "left" ? bx + gap : a === "right" ? bx + bw - gap - w : bx + (bw - w) / 2;
      all[sh] = Object.assign({}, own, { left: Math.round(nl), right: Math.round(nl + w) });
    });
    App.set("dynamic_settings.body_boxes", all);
    App.refreshUI();
    if (App.flushConfig) await App.flushConfig();
    if (window.AppTypoVis && AppTypoVis.refreshPreview) AppTypoVis.refreshPreview(true);
    paint();
    const where = sheets.length === 1 ? sheets[0] : `${sheets.length} pages`;
    if (typeof toast === "function") toast(`Paragraph box ${a === "center" ? "centred" : "to the " + a} on the background — ${where}.`);
  }
  // the project's paragraph box (no page's own sides): the page's text area, from the layout's safe area
  function paraDefault() {
    const c = window.AppLive && AppLive.state && AppLive.state.canon, lay = c && c.layouts ? c.layouts[0] : null;
    const sa = (lay && lay.safe_area) || {};
    return { left: Number(sa.left) || 0, right: (Number(sa.left) || 0) + (Number(sa.width) || 0) };
  }
  function applyBoxAlign(anchor, a) {
    if (alScope === "pick") pagesPop(anchor, `Paragraph box ${a === "center" ? "centred" : "to the " + a} on…`, (sh) => (pageHasMargins(sh) ? "its own box" : ""), (p) => alignParagraphBox(a, p));
    else alignParagraphBox(a, alScope === "page" ? [curSheet()] : allSheets());
  }
  // a page left with nothing of its own: out of the overrides
  const dropEmpty = (ov) => { Object.keys(ov).forEach((k) => { if (ov[k] && !Object.keys(ov[k]).some((x) => x !== "use_global")) delete ov[k]; }); return ov; };
  async function setParagraphAlign(a, sheets) {
    const cfg = App.state.config, al = Object.assign({}, cfg.alignment_settings || {});
    const ov = Object.assign({}, alOverrides());
    if (!sheets) {                                   // every page: the game's alignment, pages' own ones go
      al.global = Object.assign({}, al.global || {}, { body: a });
      Object.keys(ov).forEach((k) => { if (ov[k] && ov[k].body != null) { ov[k] = Object.assign({}, ov[k]); delete ov[k].body; } });
      dropEmpty(ov);
    } else sheets.forEach((sh) => { ov[sh] = Object.assign({}, ov[sh] || {}, { use_global: false, body: a }); });
    al.overrides = ov;
    App.set("alignment_settings", al);
    App.refreshUI();
    if (App.flushConfig) await App.flushConfig();
    if (window.AppTypoVis && AppTypoVis.refreshPreview) AppTypoVis.refreshPreview(true);
    paint();
    const where = !sheets ? "every page" : sheets.length === 1 ? sheets[0] : `${sheets.length} pages`;
    if (typeof toast === "function") toast(`Paragraph: ${(AL_TITLES[a] || a).toLowerCase()} on ${where}.`);
  }
  // a list of the pages to tick (paragraph size, alignment, margins), then `done(picked)`
  function pagesPop(anchor, title, label, done) {
    document.querySelector(".ts-pagepick")?.remove();
    const cur = curSheet(), pop = document.createElement("div");
    pop.className = "tsel-pop vis-style-bar ts-pagepick";
    pop.innerHTML = `<div class="vsb-head"><b>${esc(title)}</b><button class="vsb-x" data-x title="Cancel">✕</button></div>
      <div class="vsb-row"><button class="vsb-tog" data-all>All</button><button class="vsb-tog" data-none>None</button></div>
      <div class="ts-pagelist" style="max-height:260px;overflow:auto">${allSheets().map((sh) => `<label class="vsb-scope" style="display:block"><input type="checkbox" value="${esc(sh)}" ${sh === cur ? "checked" : ""}> ${esc(sh)} <span class="ts-hint">${esc(label(sh))}</span></label>`).join("")}</div>
      <div class="vsb-row" style="justify-content:flex-end"><button class="pt-btn small" data-ok>Apply</button></div>`;
    document.body.appendChild(pop);
    const r = anchor.getBoundingClientRect();
    Object.assign(pop.style, { position: "fixed", left: Math.max(8, Math.min(innerWidth - 300, r.left)) + "px", top: (r.bottom + 6) + "px", zIndex: 9999, width: "280px" });
    const boxes = () => [...pop.querySelectorAll("input[type=checkbox]")];
    pop.querySelector("[data-x]").addEventListener("click", () => pop.remove());
    pop.querySelector("[data-all]").addEventListener("click", () => boxes().forEach((b) => { b.checked = true; }));
    pop.querySelector("[data-none]").addEventListener("click", () => boxes().forEach((b) => { b.checked = false; }));
    pop.querySelector("[data-ok]").addEventListener("click", () => {
      const picked = boxes().filter((b) => b.checked).map((b) => b.value);
      pop.remove();
      if (picked.length) done(picked);
    });
  }
  function applyParaAlign(anchor, a) {
    if (alScope === "pick") pagesPop(anchor, `${AL_TITLES[a] || a} on…`, (sh) => pageAlign(sh) || "all pages'", (p) => setParagraphAlign(a, p));
    else setParagraphAlign(a, alScope === "page" ? [curSheet()] : null);
  }

  /* the paragraph's margins (px from the page's edges): left, right, the top of its text on page 1, the
     bottom where it moves on to a Continued page — page_boxes.body_boxes, as dragging its frame sets them */
  function paraFrameNow() {
    const c = window.AppLive && AppLive.state && AppLive.state.canon, d = window.AppLive && AppLive.state.data;
    const lay = c && c.layouts ? c.layouts[0] : null, b = lay && lay.safe_area && lay.safe_area.body;
    const W = Number(App.get("c_width")) || (d && d.canvas_w) || 1920, H = Number(App.get("c_height")) || (d && d.canvas_h) || 1080;
    if (!b) return { W, H, left: null, right: null, top: null, bottom: null };
    const firstLine = ((lay.elements || []).filter((e) => (e.meta || {}).kind !== "heading" && e.kind !== "table" && e.y != null)
      .map((e) => Number(e.y)).sort((x, y) => x - y)[0]);
    return { W, H, left: Math.round(b.left), right: Math.round(W - b.left - b.width), bottom: Math.round(H - b.bottom),
             top: Math.round(b.top != null ? b.top : isFinite(firstLine) ? firstLine : lay.safe_area.top || 0) };
  }
  function marginsPop(anchor) {
    document.querySelector(".ts-margins")?.remove();
    const f = paraFrameNow(), sheet = curSheet(), own = pageHasMargins(sheet);
    const pop = document.createElement("div");
    pop.className = "tsel-pop vis-style-bar ts-margins";
    pop.style.maxHeight = "none";
    const num = (k, lab, tip) => `<label class="vsb-scope" style="display:flex;align-items:center;gap:6px;margin:3px 0" title="${esc(tip)}">
        <span style="width:58px">${lab}</span><input type="number" class="ts-size" min="0" max="20000" data-m="${k}" value="${f[k] == null ? "" : f[k]}"><span class="ts-unit">px</span></label>`;
    pop.innerHTML = `<div class="vsb-head"><b>Paragraph margins</b><button class="vsb-x" data-x title="Close">✕</button></div>
      <div class="hint" style="margin:2px 0 6px">From the page's edges, as on ${esc(sheet)}${own ? " (its own)" : ""}. The heading keeps the page's margins.</div>
      <label class="vsb-scope" style="display:flex;align-items:center;gap:6px;margin:3px 0 6px" title="The page's first page, or the Continued pages it moves on to — each its own margins"><span style="width:58px">Pages</span>
        <select class="ts-style" data-mpages style="flex:1"><option value="first">First page</option><option value="cont">Continued pages</option></select></label>
      ${num("left", "Left", "From the page's left edge to the paragraph")}
      ${num("right", "Right", "From the paragraph to the page's right edge")}
      ${num("top", "Top", "Where the text starts on the page's first page (from the top)")}
      ${num("bottom", "Bottom", "Where the text moves on to a Continued page (from the bottom)")}
      <label class="vsb-scope" style="display:flex;align-items:center;gap:6px;margin:6px 0 4px"><span style="width:58px">Apply to</span>
        <select class="ts-style" data-mscope title="Which pages get these margins" style="flex:1">
          <option value="page">This page</option><option value="pick">Pick pages…</option><option value="all">All pages</option></select></label>
      <div class="vsb-row" style="gap:6px;justify-content:flex-end">
        <button class="pt-btn secondary small" data-reset style="white-space:nowrap" title="Back to the project's margins (Side margin, Bottom margin) on the pages chosen">↺ Project margins</button>
        <button class="pt-btn small" data-ok>Apply</button>
      </div>`;
    document.body.appendChild(pop);
    const r = anchor.getBoundingClientRect();
    Object.assign(pop.style, { position: "fixed", left: Math.max(8, Math.min(innerWidth - 300, r.left - 120)) + "px", top: (r.bottom + 6) + "px", zIndex: 9999, width: "290px" });
    ["mousedown", "pointerdown"].forEach((ty) => pop.addEventListener(ty, (ev) => ev.stopPropagation()));
    pop.querySelector("[data-x]").addEventListener("click", () => pop.remove());
    // Continued pages: their own margins (body_boxes[sheet].cont) — empty ones keep the first page's
    const contOf = () => {
      const c = (((App.state.config.dynamic_settings || {}).body_boxes || {})[sheet] || {}).cont || {};
      return { left: c.left, right: c.right != null ? f.W - c.right : null, top: c.top, bottom: c.bottom != null ? f.H - c.bottom : null };
    };
    const contMode = () => pop.querySelector("[data-mpages]").value === "cont";
    pop.querySelector("[data-mpages]").addEventListener("change", () => {
      const src = contMode() ? contOf() : f;
      pop.querySelectorAll("[data-m]").forEach((i) => { const v = src[i.dataset.m]; i.value = v == null ? (contMode() ? "" : "") : Math.round(v); });
      pop.querySelector('[data-m="top"]').closest("label").title = contMode() ? "Where the text starts on each Continued page (from the top)" : "Where the text starts on the page's first page (from the top)";
    });
    const scopeThen = (fn, title) => {
      const sc = pop.querySelector("[data-mscope]").value;
      if (sc === "pick") pagesPop(pop.querySelector("[data-mscope]"), title, (sh) => (pageHasMargins(sh) ? "its own" : ""), fn);
      else fn(sc === "all" ? allSheets() : [sheet]);
    };
    pop.querySelector("[data-ok]").addEventListener("click", () => {
      const v = {};
      pop.querySelectorAll("[data-m]").forEach((i) => { if (i.value !== "") v[i.dataset.m] = Math.max(0, Math.round(Number(i.value) || 0)); });
      const cont = contMode();
      scopeThen((sheets) => { pop.remove(); setParagraphMargins(v, sheets, f, cont); }, cont ? "Continued pages' margins on…" : "Paragraph margins on…");
    });
    pop.querySelector("[data-reset]").addEventListener("click", () => { const cont = contMode(); scopeThen((sheets) => { pop.remove(); setParagraphMargins(null, sheets, f, cont); }, "Page margins again on…"); });
  }
  // cont: the Continued pages' own margins (body_boxes[sheet].cont); else the first page's (cont kept)
  async function setParagraphMargins(v, sheets, f, cont) {
    const ds = (App.state.config.dynamic_settings = App.state.config.dynamic_settings || {});
    const all = Object.assign({}, ds.body_boxes || {});
    sheets.forEach((sh) => {
      const old = Object.assign({}, all[sh] || {}), keepCont = old.cont;
      const box = {};
      if (v) {
        if (v.left != null) box.left = v.left;
        if (v.right != null) box.right = f.W - v.right;
        if (v.top != null) box.top = v.top;
        if (v.bottom != null) box.bottom = f.H - v.bottom;
        if (box.right != null && box.left != null && box.right - box.left < 40) box.right = box.left + 40;
      }
      let next;
      if (cont) { next = Object.assign({}, old); delete next.cont; if (Object.keys(box).length) next.cont = box; }
      else { next = box; if (keepCont) next.cont = keepCont; }
      if (Object.keys(next).length) all[sh] = next; else delete all[sh];
    });
    App.set("dynamic_settings.body_boxes", all);
    App.refreshUI();
    if (App.flushConfig) await App.flushConfig();
    if (window.AppTypoVis && AppTypoVis.refreshPreview) AppTypoVis.refreshPreview(true);
    paint();
    const where = sheets.length === 1 ? sheets[0] : `${sheets.length} pages`;
    if (typeof toast === "function") toast(cont ? (v ? `Continued pages' margins set on ${where}.` : `${where}: the Continued pages follow the first page again.`)
      : v ? `Paragraph margins set on ${where}.` : `${where}: the project's margins again.`);
  }

  /* line height: the paragraph's row spacing (px, Typography "Row spacing"); the heading's gap
     between its own lines (Typography "Line spacing": a multiplier up to 3, px above that) */
  function lineHeight() {
    const t = T[target];
    if (t && t.lh) {                                 // a rules paragraph: its own row gap, else the one it is drawn with
      const v = App.get(t.lh);
      if (v !== "" && v != null) return Number(v);
      const rep = RulesCanvas.report() || {}, sz = rep.sizes || {}, fit = Number(rep.fit) || 1;
      const drawn = target === "gr_legal" ? sz.legal_row_gap : sz.row_gap;
      return drawn != null ? Math.round(drawn / fit) : 30;
    }
    if (target === "heading") {
      const ls = Number(App.get("line_spacing")), size = Number(App.get("h_size")) || 60;
      if (!isFinite(ls) || App.get("line_spacing") === "") return Math.round(size * 0.1);
      return ls <= 3 ? Math.round(size * Math.max(0, ls - 1)) : Math.round(ls);
    }
    const lg = App.get("line_gap");
    return lg === "" || lg == null ? 30 : Number(lg);
  }
  function setLineHeight(px) {
    px = Math.max(0, Math.round(Number(px) || 0));
    if (T[target] && T[target].lh) { App.set(T[target].lh, px); return; }
    if (target === "heading") {
      const size = Number(App.get("h_size")) || 60;
      App.set("line_spacing", px > 3 ? px : Math.round((1 + px / size) * 100) / 100);
    } else App.set("line_gap", px);
  }
  const trackKey = () => (T[target] && T[target].trk) || (target === "heading" ? "heading_tracking" : "body_tracking");
  function letterSpacing() {
    return Number(((App.state.config.dynamic_settings || {})[trackKey()]) || 0);
  }

  /* beside the page in Icon mode: what every icon shares (heights, original size) and the icon library */
  function iconSideHtml() {
    const num = (k, lab) => `<div class="ics-gap-row"><span class="ics-lab">${lab}</span>
        <input type="number" class="ics-num" data-key="${k}" value="${esc(App.get(k) ?? "")}" min="0" max="400" /> px</div>`;
    return `<div class="tbl-head">All icons</div>
      ${num("h_icon_h", "Heading icon height")}
      ${num("b_icon_h", "Body icon height")}
      <label class="ics-check"><input type="checkbox" data-key="body_icons_use_original_size" ${App.get("body_icons_use_original_size") ? "checked" : ""} /> Body icons at their original size</label>
      <div class="hint" style="margin:8px 0">Drag a corner of the selected icon to size it — "Apply to" in the bar above says which copies change. Every icon size keeps its proportion to these heights.</div>
      <button class="ts-copy" data-tsassets>Icon library (pictures, missing icons)…</button>`;
  }

  /* layer styles: a dropdown in the top bar — the current one, and the library to pick from */
  const fxLib = () => (App.state.config.dynamic_settings || {}).layer_style_library || {};
  const fxCur = (t) => ((App.state.config.dynamic_settings || {}).style_assignments || {})[t.role] || "";
  const fxSwatch = (n) => (n ? `/api/layer-styles/swatch?name=${encodeURIComponent(n)}&v=${JSON.stringify(fxLib()[n]).length}${lightTag()}` : "");
  const lightTag = () => { const l = ((App.state.config || {}).dynamic_settings || {}).fx_global_light; return l && l.angle != null ? "_" + Math.round(l.angle) : ""; };
  function fxButtonHtml(t) {
    const cur = fxCur(t);
    return `<button class="ts-fxbtn" data-tsfxopen title="Layer style of the ${t.label.toLowerCase()} (stroke, glow, overlay…)">
        ${cur ? `<img src="${fxSwatch(cur)}" alt="">` : `<span class="ts-fx-none">fx</span>`}<span class="ts-fx-name">${esc(cur || "No layer style")}</span><span class="ts-fx-caret">▾</span></button>`;
  }
  function openFxMenu(btn) {
    const t = T[target];
    showFxMenu(btn, layersHtml(true), (name) => {
      App.assignLayerStyle(t.role, name);
      if (target === "heading" && window.AppTypoVis && AppTypoVis.dropHeadingRowRules) AppTypoVis.dropHeadingRowRules("fx").then(() => paint());
      paint();
    });
    document.querySelector(".ts-fxmenu [data-tscopy]")?.addEventListener("click", () => { closeFxMenu(); App.captureLayerStyle(t.role, "selected"); });
    wireLight(document.querySelector(".ts-fxmenu"));
    wireFxSize(document.querySelector(".ts-fxmenu"), t);
    fxReopen = () => { const b = document.querySelector("[data-tsfxopen]"); if (b) openFxMenu(b); };
  }
  /* how the style's effect sizes follow the text (fx_scale.py): its stroke, shadow, glow, bevel and
     satin sizes worked out from the copied values for each text size — or as copied, or a custom % */
  const fxRoleSize = (role) => {
    const c = App.state.config || {}, ds = c.dynamic_settings || {};
    const v = Number({ "Heading text": c.h_size, "Body text": c.b_size, "Subheading text": ds.subheading_size }[role]);
    return v > 0 ? v : null;
  };
  function fxSizeHtml(cur) {
    const st = cur && fxLib()[cur];
    if (!st) return "";
    const base = Number(st.fx_base_size) > 0 ? Number(st.fx_base_size) : null;
    const mode = window.PsFx && PsFx.scaleMode ? PsFx.scaleMode(st) : "original";
    const pct = Number(st.fx_scale_pct) > 0 ? Number(st.fx_scale_pct) : 100;
    const opt = (v, lab) => `<option value="${v}" ${mode === v ? "selected" : ""}>${lab}</option>`;
    return `<div class="ts-light ts-fxsize" title="Stroke, shadow, glow, bevel and satin sizes. Opacity, colours, angles and contours never change.">
        <span>Effect sizes</span>
        <select class="ts-size" data-tsfxmode>${opt("proportional", "Follow the text size")}${opt("original", "As copied")}${opt("custom", "Custom %")}</select>
        <input class="ts-size ts-narrow" type="number" min="1" max="1000" step="1" value="${pct}" data-tsfxpct ${mode === "custom" ? "" : "hidden"}><span class="ts-unit" ${mode === "custom" ? "" : "hidden"}>%</span>
        <span class="hint">${base ? `Copied at ${Math.round(base * 10) / 10} px text — a bigger or smaller text gets effects to match.` : "The text size it was copied at isn't known: “Follow the text size” takes this text's size as the start."}</span></div>`;
  }
  function wireFxSize(menu, t) {
    const sel = menu && menu.querySelector("[data-tsfxmode]");
    if (!sel) return;
    const name = fxCur(t), pctIn = menu.querySelector("[data-tsfxpct]");
    const save = (patch) => {
      const lib = Object.assign({}, fxLib());
      if (!lib[name]) return;
      lib[name] = Object.assign({}, lib[name], patch);
      App.set("dynamic_settings.layer_style_library", lib);
      App.refreshUI();
    };
    sel.addEventListener("change", () => {
      const st = fxLib()[name] || {}, patch = { fx_scale_mode: sel.value };
      // no copied size yet: this text's size is the start, so nothing jumps
      if (sel.value === "proportional" && !(Number(st.fx_base_size) > 0)) {
        const s = fxRoleSize(t.role);
        if (s) patch.fx_base_size = s; else patch.fx_scale_mode = "original";
      }
      if (sel.value === "custom" && !(Number(st.fx_scale_pct) > 0)) patch.fx_scale_pct = 100;
      save(patch);
      const custom = patch.fx_scale_mode === "custom";
      pctIn.hidden = !custom;
      pctIn.nextElementSibling.hidden = !custom;
      if (patch.fx_scale_mode !== sel.value) sel.value = patch.fx_scale_mode;
    });
    pctIn.addEventListener("change", () => {
      const v = Number(pctIn.value);
      if (v > 0) save({ fx_scale_mode: "custom", fx_scale_pct: v });
    });
  }
  /* the project's Global Light (Photoshop's Layer Style › Global Light): the angle every "Use Global
     Light" shadow / bevel is drawn at, in the previews and the built PSD (global_light.py) */
  async function wireLight(menu) {
    const inp = menu && menu.querySelector("[data-tslight]");
    if (!inp) return;
    let info = null;
    try { info = await api("/api/layer-styles/light"); } catch (e) { info = null; }
    if (!info || !document.body.contains(inp)) return;
    const shown = info.light || info.effective;
    inp.value = shown ? Math.round(shown.angle) : "";
    const hint = menu.querySelector("[data-tslighthint]");
    const angles = (info.angles || []).map((a) => Math.round(a.angle));
    const distinct = [...new Set(angles)];
    if (hint) {
      hint.textContent = !distinct.length ? "No style here uses Global Light."
        : distinct.length > 1 ? `Styles were made at ${distinct.join("°, ")}° — Photoshop has one Global Light, so all draw at ${shown ? Math.round(shown.angle) : distinct[0]}°.`
        : info.light ? "" : "From the styles (not set yet).";
    }
    inp.addEventListener("change", () => {
      const v = Number(inp.value);
      if (inp.value === "" || !isFinite(v)) return;
      const alt = (info.light || info.effective || {}).altitude;
      App.set("dynamic_settings.fx_global_light", { angle: v, altitude: alt != null ? alt : 30 });
      App.refreshUI();
      info.light = { angle: v, altitude: alt != null ? alt : 30 };
      if (hint && distinct.length < 2) hint.textContent = "";
    });
  }
  /* the layer-style dropdown for something else (the selected text): `onPick(name)`, "" = none */
  function fxPicker(btn, cur, onPick, noneLabel) {
    if (document.querySelector(".ts-fxmenu")) { closeFxMenu(); return; }
    showFxMenu(btn, `<div class="tbl-head">Layer style · selection</div>
      ${fxGridHtml(cur, noneLabel || "None")}`, onPick);
    // after a rename / delete the picker is drawn again (a renamed current style stays picked)
    fxReopen = (name) => fxPicker(btn, name !== undefined ? name : (fxRenamed[cur] || (fxLib()[cur] ? cur : "")), onPick, noneLabel);
  }
  /* the styles as swatches: a search box, then None + every style (✎ rename, 🗑 delete on each) */
  function fxGridHtml(cur, noneLabel) {
    const lib = Object.keys(fxLib()).sort((a, b) => a.localeCompare(b));
    return `${lib.length > 3 ? `<input class="form-control ts-fxsearch" type="search" placeholder="Search ${lib.length} layer styles…" data-tsfxsearch>` : ""}
      <div class="ts-sw-grid">
        <div class="ts-sw ${!cur ? "on" : ""}" role="button" tabindex="0" data-tsfx=""><span class="ts-sw-img none">Aa</span><span>${esc(noneLabel)}</span></div>
        ${lib.map((n) => `<div class="ts-sw ${n === cur ? "on" : ""}" role="button" tabindex="0" data-tsfx="${esc(n)}" title="${esc(n)}">
          <span class="ts-sw-img"><img src="${fxSwatch(n)}" alt="" loading="lazy"></span>
          <span class="ts-sw-name" data-tsfxname>${esc(n)}</span>
          <span class="ts-sw-tools"><button type="button" data-tsfxren title="Rename">✎</button><button type="button" data-tsfxdel title="Delete">🗑</button></span></div>`).join("")}
      </div>
      <div class="hint" data-tsfxnone hidden>No layer style matches.</div>`;
  }
  let fxReopen = null;                               // draws the open dropdown again (a pick, a rename / delete)
  // where the open dropdown is, how far it is scrolled and what is searched — kept when it is drawn again
  function fxMenuState() {
    const m = document.querySelector(".ts-fxmenu");
    if (!m) return null;
    const q = m.querySelector("[data-tsfxsearch]");
    return { top: m.style.top, left: m.style.left, scroll: m.scrollTop, q: q ? q.value : "" };
  }
  function fxMenuRestore(st) {
    const m = document.querySelector(".ts-fxmenu");
    if (!m || !st) return;
    m.style.top = st.top;
    m.style.left = st.left;
    const q = m.querySelector("[data-tsfxsearch]");
    if (q && st.q) { q.value = st.q; q.dispatchEvent(new Event("input")); }
    m.scrollTop = st.scroll;
  }
  const fxRenamed = {};                              // old name -> new, for a reopened picker's current style
  function wireFxGrid(m) {
    const search = m.querySelector("[data-tsfxsearch]");
    if (search) {
      search.addEventListener("input", () => {
        const q = search.value.trim().toLowerCase();
        let shown = 0;
        m.querySelectorAll(".ts-sw[data-tsfx]").forEach((el) => {
          const n = el.dataset.tsfx;
          const on = !n ? !q : n.toLowerCase().includes(q);
          el.hidden = !on;
          if (on && n) shown++;
        });
        m.querySelector("[data-tsfxnone]").hidden = !q || shown > 0;
      });
      setTimeout(() => search.focus(), 0);
    }
    m.querySelectorAll("[data-tsfxren]").forEach((b) => b.addEventListener("click", (ev) => {
      ev.stopPropagation();
      const tile = b.closest("[data-tsfx]"), name = tile.dataset.tsfx, lab = tile.querySelector("[data-tsfxname]");
      const inp = document.createElement("input");
      inp.className = "form-control ts-sw-rename";
      inp.value = name;
      lab.replaceWith(inp);
      inp.focus(); inp.select();
      let done = false;
      const finish = async (save) => {
        if (done) return;
        done = true;
        const v = inp.value.trim();
        if (!save || !v || v === name) { inp.replaceWith(lab); return; }
        inp.disabled = true;
        if (await renameLayerStyle(name, v)) { fxRenamed[name] = v; redrawFxMenu(); } else { done = false; inp.disabled = false; inp.focus(); }
      };
      inp.addEventListener("click", (e) => e.stopPropagation());
      inp.addEventListener("keydown", (e) => {
        e.stopPropagation();
        if (e.key === "Enter") finish(true);
        else if (e.key === "Escape") finish(false);
      });
      inp.addEventListener("blur", () => finish(true));
    }));
    m.querySelectorAll("[data-tsfxdel]").forEach((b) => b.addEventListener("click", async (ev) => {
      ev.stopPropagation();
      const name = b.closest("[data-tsfx]").dataset.tsfx;
      if (!confirm(`Delete layer style “${name}”? Text that uses it is drawn without a layer style.`)) return;
      if (await deleteLayerStyle(name)) redrawFxMenu();
    }));
  }
  function redrawFxMenu() {
    const again = fxReopen, keep = fxMenuState();
    closeFxMenu();
    paint();
    if (again) { again(); fxMenuRestore(keep); }
  }
  /* rename / delete go through the server: every place the style is used follows the new name */
  async function renameLayerStyle(name, newName) {
    try {
      await App.configSettled();
      const d = await api("/api/layer-styles/rename", { method: "POST", body: { name, new_name: newName } });
      if (!d.ok) { toast(d.error || "Rename failed.", "err"); return false; }
      App.state.config = d.config;
      App.refreshUI();
      toast(`“${name}” is now “${newName}”.`);
      return true;
    } catch (e) { toast(e.message, "err"); return false; }
  }
  async function deleteLayerStyle(name) {
    try {
      await App.configSettled();
      const d = await api("/api/layer-styles/delete", { method: "POST", body: { name } });
      if (!d.ok) { toast(d.error || "Delete failed.", "err"); return false; }
      App.state.config = d.config;
      App.refreshUI();
      toast(`Layer style “${name}” deleted.`);
      return true;
    } catch (e) { toast(e.message, "err"); return false; }
  }
  function showFxMenu(btn, html, onPick) {
    closeFxMenu();
    const m = document.createElement("div");
    m.className = "ts-fxmenu";
    m.innerHTML = `<button type="button" class="ts-fxclose" data-tsfxclose title="Close (Esc)">✕</button>` + html;
    m.querySelector("[data-tsfxclose]").addEventListener("click", closeFxMenu);
    document.body.appendChild(m);
    const r = btn.getBoundingClientRect();
    m.style.top = (r.bottom + 6) + "px";
    m.style.left = Math.max(8, Math.min(window.innerWidth - m.offsetWidth - 8, r.left)) + "px";
    fxReopen = null;
    m.querySelectorAll("[data-tsfx]").forEach((b) => {
      // the dropdown stays open after a pick: try one style after another; ✕, Esc or its button close it
      const pick = () => {
        const name = b.dataset.tsfx, again = fxReopen, keep = fxMenuState();
        closeFxMenu();
        onPick(name);
        if (again) { again(name); fxMenuRestore(keep); }
      };
      b.addEventListener("click", pick);
      b.addEventListener("keydown", (e) => { if ((e.key === "Enter" || e.key === " ") && e.target === b) { e.preventDefault(); pick(); } });
    });
    wireFxGrid(m);
    // no closing on a click outside (the artist clicks the page to look at it): ✕ / Esc / the button
    setTimeout(() => document.addEventListener("keydown", fxEsc, true), 0);
  }
  function fxEsc(ev) {
    if (ev.key !== "Escape") return;
    if (ev.target.closest && ev.target.closest(".ts-sw-rename")) return;      // ends the rename only
    ev.stopPropagation();
    closeFxMenu();
  }
  function closeFxMenu() {
    document.querySelectorAll(".ts-fxmenu").forEach((n) => n.remove());
    document.removeEventListener("keydown", fxEsc, true);
  }

  function layersHtml(menu) {
    if (target === "icon") return iconSideHtml();
    if (target === "table" || target === "words" || target === "row" || target === "box" || target === "rules_page" || target === "rules_part") return "";
    if (!menu) return "";                            // the layer styles live in the top bar's dropdown
    const t = T[target];
    const cur = fxCur(t);
    return `<div class="tbl-head">Layer style · ${t.label}</div>
      ${fxGridHtml(cur, "None")}
      ${fxSizeHtml(cur)}
      <button class="ts-copy" data-tscopy>Copy from Photoshop…</button>
      <div class="hint">Select a text layer in Photoshop, then copy its style — it's saved here and given to the ${t.label.toLowerCase()}.</div>
      <div class="ts-light" title="Photoshop's Layer Style › Global Light: shadows and bevels with “Use Global Light” are drawn at this angle (previews and the built PSD)">
        <span>Global light</span><input class="ts-size ts-narrow" type="number" min="-180" max="360" step="1" data-tslight><span class="ts-unit">°</span>
        <span class="hint" data-tslighthint></span></div>`;
  }

  let painted = null;                                // the kind of page the bar was drawn for
  // another kind of page on the Canvas (a rules page / a normal one): its own targets
  const syncPage = () => { if (painted !== pageKind()) paint(); };
  function paint() {
    // a paytable page: its own Page / Row / Card / Box bar (paytable_canvas.js)
    if (window.PaytableCanvas && PaytableCanvas.on()) {
      PaytableCanvas.paint();
      const layers = document.getElementById("typoLayers");
      if (layers) layers.innerHTML = "";
      return;
    }
    painted = pageKind();
    if (window.AppTypoVis && AppTypoVis.state && AppTypoVis.state.target === undefined) AppTypoVis.state.target = target;
    const strip = document.getElementById("typoStrip"), layers = document.getElementById("typoLayers");
    if (strip) {
      strip.innerHTML = stripHtml();
      if (target === "icon") { if (iconSel()) IconStudio.wireBar(strip, iconSel()); }
      else if (target === "table") TableStudio.wireBar(strip);
      else if (target === "words") AppTypoVis.wireSelectionBar(strip);
      else if (target === "row") AppTypoVis.wireRowBar(strip);
      else if (target === "box") AppTypoVis.wireBoxBar(strip);
      else if (typeof bindForms === "function") bindForms(strip);
      if (pageKind() && target !== "row") PE().wireBar(strip);   // its own bar parts (data-set …)
      strip.querySelectorAll("[data-tstarget]").forEach((b) => b.addEventListener("click", () => {
        if (["icon", "table", "words", "row", "box", "rules_part"].includes(b.dataset.tstarget)) return;
        if (window.RulesCanvas) RulesCanvas.deselect();
        if (window.PaylinesCanvas) PaylinesCanvas.deselect();
        if (window.AppTypoVis) AppTypoVis.selectRow(null);           // the whole heading / paragraph again
        if (window.IconStudio) IconStudio.deselect();
        if (window.TableStudio) TableStudio.deselect();
        setTarget(b.dataset.tstarget);
      }));
      strip.querySelector("[data-tsbsize]")?.addEventListener("change", () => applyParaSize(strip));
      strip.querySelector("[data-tshscope]")?.addEventListener("change", (e) => { headScope = e.target.value; paint(); });
      strip.querySelector("[data-tshide]")?.addEventListener("click", async (e) => {
        const part = e.currentTarget.dataset.tshide, hide = e.currentTarget.dataset.on !== "1";
        if (part === "heading" && hide) { const parts = await askHeadingDelete(); if (parts) setHidden(parts, true); return; }
        setHidden([part], hide);
      });
      strip.querySelector("[data-tsrestore]")?.addEventListener("click", (e) => restorePop(e.currentTarget));
      strip.querySelector("[data-tsplate]")?.addEventListener("click", (e) => platePop(e.currentTarget));
      strip.querySelector("[data-tsplatecopy]")?.addEventListener("click", () => {
        const p = plateNow(curSheet());
        if (!p || !window.PshLook) return;
        PshLook.clip = { from: "the heading plate", look: PshLook.stripToCard(p), at: Date.now() };
        if (window.PaytableCanvas) PaytableCanvas.state.clip = { from: PshLook.clip.from, look: PshLook.clip.look };
        paint();
        toast("Plate look copied — paste it on a paytable card, the title's plate, a row strip or another page's plate.");
      });
      strip.querySelector("[data-tsplatepaste]")?.addEventListener("click", () => {
        const c = window.PshLook && PshLook.clip;
        if (!c) return;
        const sheet = curSheet(), own = !!plateOwn(sheet), p = plateNow(sheet) || { pad_x: 40, pad_y: 12 };
        savePlate(own ? "page" : "all", Object.assign(PshLook.applyToRule(p, c.look), { on: true }));
      });
      strip.querySelectorAll("[data-tshp]").forEach((n) => n.addEventListener("change", () => {
        const key = n.dataset.tshp;
        setPageHeading(key, key === "h_size" ? Math.max(6, Math.min(400, Math.round(Number(n.value) || 0))) || "" : n.value);
      }));
      strip.querySelector("[data-tshreset]")?.addEventListener("click", async () => {
        for (const key of ["h_font", "h_size", "h_rgb"]) {
          const all = Object.assign({}, App.get("page_overrides") || {}), sh = curSheet();
          const k = Object.keys(all).find((x) => x.toLowerCase() === sh.toLowerCase());
          if (k) { const ov = Object.assign({}, all[k]); delete ov[key]; if (Object.keys(ov).length) all[k] = ov; else delete all[k]; }
          App.set("page_overrides", all);
        }
        headScope = "all";
        await setPageHeading("h_size", null);
      });
      strip.querySelector("[data-tsbscope]")?.addEventListener("change", (e) => {
        paraScope = e.target.value;
        if (paraScope === "pick") applyParaSize(strip);             // the list, for the size shown
      });
      strip.querySelectorAll("[data-tsalign]").forEach((b) => b.addEventListener("click", () => {
        if (target === "body" && !T.body.page) { applyParaAlign(b, b.dataset.tsalign); return; }
        App.set(T[target].align, b.dataset.tsalign);
        App.refreshUI();
        paint();
      }));
      strip.querySelector("[data-tsalscope]")?.addEventListener("change", (e) => { alScope = e.target.value; });
      strip.querySelectorAll("[data-tsboxal]").forEach((b) => b.addEventListener("click", () => applyBoxAlign(b, b.dataset.tsboxal)));
      strip.querySelector("[data-tsalreset]")?.addEventListener("click", () => {
        const al = Object.assign({}, App.state.config.alignment_settings || {}), ov = Object.assign({}, alOverrides()), sh = curSheet();
        Object.keys(ov).forEach((k) => { if (k.toLowerCase() === sh.toLowerCase() && ov[k]) { ov[k] = Object.assign({}, ov[k]); delete ov[k].body; } });
        al.overrides = dropEmpty(ov);
        App.set("alignment_settings", al);
        App.refreshUI();
        if (App.flushConfig) App.flushConfig();
        if (window.AppTypoVis && AppTypoVis.refreshPreview) AppTypoVis.refreshPreview(true);
        paint();
      });
      strip.querySelector("[data-tsmargins]")?.addEventListener("click", (e) => marginsPop(e.currentTarget));
      strip.querySelectorAll("[data-key]").forEach((n) => n.addEventListener("change", () => {
        // the heading's settings win: the same property set on it as a row before goes
        if (target === "heading" && window.AppTypoVis && AppTypoVis.dropHeadingRowRules) AppTypoVis.dropHeadingRowRules(n.dataset.key).then(() => paint());
        setTimeout(paint, 0);
      }));
      strip.querySelector("[data-tsheadclear]")?.addEventListener("click", () => AppTypoVis.dropHeadingRowRules(null).then(() => paint()));
      strip.querySelector("[data-tslh]")?.addEventListener("change", (e) => { setLineHeight(e.target.value); App.refreshUI(); paint(); });
      strip.querySelector("[data-tsls]")?.addEventListener("change", (e) => {
        const ds = (App.state.config.dynamic_settings = App.state.config.dynamic_settings || {});
        ds[trackKey()] = Math.max(-200, Math.min(1000, Math.round(Number(e.target.value) || 0)));
        App.refreshUI();
        if (target === "heading" && window.AppTypoVis && AppTypoVis.dropHeadingRowRules) AppTypoVis.dropHeadingRowRules("heading_tracking").then(() => paint());
        paint();
      });
    }
    if (layers && target === "icon") {
      layers.innerHTML = layersHtml();
      if (typeof bindForms === "function") bindForms(layers);
      layers.querySelectorAll("[data-key]").forEach((n) => n.addEventListener("change", () => setTimeout(() => { if (window.IconStudio) IconStudio.sync(); }, 600)));
      layers.querySelector("[data-tsassets]")?.addEventListener("click", () => { location.hash = "#/assets"; });
    } else if (layers) {
      layers.innerHTML = layersHtml();               // empty: the card hides (the styles are in the top bar)
    }
    strip?.querySelector("[data-tsfxopen]")?.addEventListener("click", (ev) => {
      if (document.querySelector(".ts-fxmenu")) closeFxMenu(); else openFxMenu(ev.currentTarget);
    });
  }

  // text selected on the page: the bar is the selection's until nothing is selected
  let lastText = "body";
  function showSelection(role) {
    if (T[role]) lastText = role;
    else if (T[target]) lastText = target;
    target = "words";
    paint();
  }
  function endSelection() {
    if (target !== "words") return;
    target = rowSel() ? "row" : lastText;            // back to the row it is in, when one is clicked
    paint();
  }
  function showRow(role) {
    if (T[role]) lastText = role;
    target = "row";
    paint();
  }
  function endRow() {
    if (target !== "row") return;
    target = lastText;
    paint();
  }

  function setTarget(t) {
    if (t === "box") {                                // a text box picked on the page: its frame and its bar
      target = t;
      paint();
      if (window.AppTypoVis) AppTypoVis.showTarget("box");
      return;
    }
    if (t === "icon" || t === "table" || t === "words") {   // an icon / table / words picked on the page: no text highlighted
      target = t;
      paint();
      if (window.AppTypoVis) { AppTypoVis.selectRow(null); AppTypoVis.showTarget(null); }
      return;
    }
    if (t === "rules_page" || t === "rules_part") {   // a rules page itself / its separator, XTRAA REELS icons
      target = t;
      paint();
      if (window.AppTypoVis) AppTypoVis.showTarget(null);
      return;
    }
    if (!T[t]) return;
    if (window.RulesCanvas && RulesCanvas.state.sel) RulesCanvas.deselect();
    if (window.PaylinesCanvas && PaylinesCanvas.state.sel) PaylinesCanvas.deselect();
    target = t;
    paint();
    if (window.AppTypoVis && AppTypoVis.showTarget) AppTypoVis.showTarget(t);
  }

  return { paint, syncPage, setTarget, showSelection, endSelection, showRow, endRow, fxPicker, get target() { return target; } };
})();
