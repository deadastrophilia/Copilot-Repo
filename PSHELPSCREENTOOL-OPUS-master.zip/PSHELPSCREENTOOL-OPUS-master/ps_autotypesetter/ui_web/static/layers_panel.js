/* The Layers panel (right side of the Canvas, under Pages): what is on the page, grouped the way the PSD
   groups its layers — a text page's heading (and its plate), its rows (and their BG strips), text boxes,
   tables and pictures; a paytable's title, its rows of cards, the WILD / SCATTER boxes, text boxes, zones.
   A click picks the part on the Canvas (its bar opens, as a click on the page does); the part picked on
   the Canvas is lit here. It reads what the Canvas drew — it never changes the page itself. */
(function () {
  if (window.LayersPanel) return;
  const esc = (v) => String(v ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const host = () => document.getElementById("typoLayerList");
  const untag = (t) => String(t || "").replace(/<([^<>]*?)(?:~[^<>]*)?>/g, "<$1>").replace(/\s+/g, " ").trim();
  const short = (t, n = 34) => { const s = untag(t); return s.length > n ? s.slice(0, n - 1) + "…" : s; };
  let picks = [];                                     // the entries of the list, by index: what a click picks
  let sig = "";

  /* ---------- a text page (AppLive): heading, rows, text boxes, tables, pictures ---------- */
  function textTree() {
    const els = (window.AppLive && AppLive.state && AppLive.state.elements) || [];
    const out = [];
    const sel = (window.AppTypoVis && AppTypoVis.state) || {}, target = window.TypoStudio ? TypoStudio.target : "";
    const head = els.find((e) => e.kind === "heading"), plate = els.find((e) => e.meta && e.meta.plate === "heading");
    if (head) {
      out.push({ icon: "T", name: "Heading", note: short(head.rowText || head.text || (head.meta && head.meta.text) || (head.lines || []).join(" ")), on: target === "heading",
                 pick: () => pickText(head), kids: plate ? [{ icon: "▭", name: "Plate", note: "behind the heading", on: target === "heading", pick: () => pickText(head) }] : [] });
    }
    const strips = els.filter((e) => e.kind === "rect" && !(e.meta && e.meta.plate));
    const rows = [], boxes = new Map();
    els.filter((e) => e.kind === "line").forEach((e) => {
      if (e.boxId != null) { if (!boxes.has(e.boxId)) boxes.set(e.boxId, e); return; }
      const last = rows[rows.length - 1];
      if (last && last.row === e.row) { last.y1 = Math.max(last.y1, e.y + e.h); return; }
      rows.push({ row: e.row, el: e, y0: e.y, y1: e.y + e.h });
    });
    const selRow = sel.row && els.find((e) => e.id === sel.row.id);
    rows.forEach((r) => {
      const st = strips.filter((s) => s.y + s.h / 2 >= r.y0 - 2 && s.y + s.h / 2 <= r.y1 + 2);
      const n = String(r.row || "").replace(/^row:/, "");
      out.push({ icon: "¶", name: /^\d+$/.test(n) ? `Row ${n}` : "Row", note: short(r.el.rowText || r.el.text),
                 on: !!(selRow && selRow.row === r.row), pick: () => pickText(r.el),
                 kids: st.map(() => ({ icon: "▬", name: "BG strip", note: "behind the row", on: !!(selRow && selRow.row === r.row), pick: () => pickText(r.el) })) });
    });
    boxes.forEach((e, id) => out.push({ icon: "▣", name: "Text box", note: short(e.rowText || e.text), on: sel.box === id, pick: () => pickText(e) }));
    els.filter((e) => e.kind === "table").forEach((e, i) => out.push({ icon: "▦", name: `Table ${i + 1}`, note: "", on: false, pick: null }));
    els.filter((e) => e.kind === "picture").forEach((e, i) => out.push({ icon: "🖼", name: `Picture ${i + 1}`, note: "", on: false, pick: null }));
    return out;
  }
  function pickText(e) {
    if (window.AppTypoVis && AppTypoVis.pickElement) AppTypoVis.pickElement(e);
  }

  /* ---------- a paytable (PaytableCanvas): title, rows of cards, boxes, text boxes, zones ---------- */
  function paytableTree() {
    const P = window.PaytableCanvas, d = (P && P.state && P.state.data) || {}, b = d.blocks || {};
    const sk = P && P.selKey ? P.selKey() : "", out = [];
    const node = (k, icon, name, note, kids) => ({ icon, name, note: note || "", on: sk === k, pick: () => P.pickKey(k), kids: kids || [] });
    const mid = (r) => [(r[0] + r[2]) / 2, (r[1] + r[3]) / 2];
    const inside = (r, box) => { const [x, y] = mid(r); return x >= box[0] && x <= box[2] && y >= box[1] && y <= box[3]; };
    if (b.title) out.push(node("title", "T", "Title", "and its plate"));
    // the cards in the order they are on the page: row by row, left to right
    const cards = Object.keys(b).filter((k) => k.startsWith("card:"))
      .sort((p, q) => (Math.abs(b[p][1] - b[q][1]) > 0.01 ? b[p][1] - b[q][1] : b[p][0] - b[q][0])), used = new Set();
    [["high", "Top row"], ["mid", "Middle row"], ["low", "Bottom row"]].forEach(([k, name]) => {
      if (!b[k]) return;
      const mine = cards.filter((c) => !used.has(c) && inside(b[c], b[k]));
      mine.forEach((c) => used.add(c));
      out.push(node(k, "▤", name, `${mine.length} card${mine.length === 1 ? "" : "s"}`, mine.map((c) => node(c, "▢", c.slice(5).toUpperCase(), "card"))));
    });
    const free = cards.filter((c) => !used.has(c));
    if (free.length) out.push({ icon: "▢", name: "Cards on their own", note: `${free.length}`, on: false, pick: null, kids: free.map((c) => node(c, "▢", c.slice(5).toUpperCase(), "card")) });
    ["wild", "scatter"].forEach((k) => { if (b[k]) out.push(node(k, "◆", `${k.toUpperCase()} box`, "")); });
    Object.keys(b).filter((k) => k.startsWith("scard:")).forEach((k) => out.push(node(k, "◆", `SCATTER card ${k.slice(6).toUpperCase()}`, "")));
    Object.keys(b).filter((k) => k.startsWith("text:")).forEach((k) => {
      const tm = (d.texts || []).find((t) => "text:" + t.id === k);
      out.push(node(k, "¶", "Text box", short(tm && tm.text)));
    });
    Object.keys(b).filter((k) => k.startsWith("zone:")).forEach((k) => out.push(node(k, "▭", `Zone ${k.slice(5)}`, "")));
    return out;
  }

  function rowsHtml(list, depth) {
    return list.map((n) => {
      const i = picks.push(n.pick) - 1;
      return `<div class="lyr-row ${n.on ? "on" : ""} ${n.pick ? "" : "inert"}" data-lyr="${i}" style="padding-left:${8 + depth * 16}px" title="${esc(n.pick ? `Pick ${n.name} on the page` : n.name)}">
          <span class="lyr-ico">${esc(n.icon)}</span><span class="lyr-name">${esc(n.name)}</span><span class="lyr-note">${esc(n.note)}</span></div>`
        + (n.kids && n.kids.length ? rowsHtml(n.kids, depth + 1) : "");
    }).join("");
  }

  function tree() {
    if (window.PaytableCanvas && PaytableCanvas.on && PaytableCanvas.on()) return paytableTree();
    return textTree();
  }
  function render(force) {
    const h = host();
    if (!h) return;
    // App is app.js's own const (not on window)
    if (typeof App === "undefined" || App.route !== "typography") { h.innerHTML = ""; return; }
    let list;
    try { list = tree(); } catch (e) { list = []; }
    const s = JSON.stringify(list.map(function flat(n) { return [n.name, n.note, n.on, (n.kids || []).map(flat)]; }));
    if (!force && s === sig) return;
    sig = s;
    picks = [];
    h.closest(".tbl-side")?.classList.toggle("has-layers", list.length > 0);
    h.innerHTML = list.length ? `<div class="tbl-head">Layers <span class="lyr-count">${list.length}</span></div><div class="lyr-list">${rowsHtml(list, 0)}</div>` : "";
    h.querySelectorAll("[data-lyr]").forEach((r) => r.addEventListener("click", () => {
      const fn = picks[Number(r.dataset.lyr)];
      if (fn) { fn(); setTimeout(() => render(true), 60); }
    }));
  }
  // what the Canvas shows changes from many places (a page drawn, a pick, an edit): checked a few times a
  // second, drawn again only when it differs
  setInterval(() => { if (document.visibilityState === "visible") render(false); }, 500);
  window.LayersPanel = { render };
})();
