/* ---------------------------------------------------------------------------
 * Tables live preview — the Visualiser's live canvas (tables are the server's
 * pixel-exact renders) embedded in the Tables view. Click a table on it to give
 * it a design (or every table); click a line of text to style its words.
 *
 * The sheet is auto-selected: the tool prefers a page that actually contains
 * an Excel table, falling back to the first normal page. Settings changes made
 * anywhere on the Tables view re-render it automatically (AppTblVis.schedule()
 * is called from App.updatePreview). The safe-area guides are draggable and
 * write the real renderer settings through App.set/App.pushConfig.
 * ------------------------------------------------------------------------- */
(function () {
  "use strict";
  if (window.AppTblVis) return;

  const V = {
    state: {
      sheets: [],
      sheetTables: {},
      sheet: "",
      geometry: null,
      guides: [],
      scale: 1,
      tx: 0,
      ty: 0,
      fitted: false,
      pan: null,
      drag: null,
    },
  };

  const MIN_SCALE = 0.02;
  const MAX_SCALE = 2;                    // 200 %: further in, the page picture gets so big that drawing lags

  function el(id) {
    return document.getElementById(id);
  }

  /* where the table editor (handles, ✎ bar, boxes, ✥ move) works: the Tables preview, the
     Visualiser's own canvas, or the Typography page when a table is clicked there — the same edits */
  const T = { host: "tblVisHost", canvas: "tblVisCanvas", vis: false, typo: false };
  const H = () => el(T.host), C = () => el(T.canvas);
  function useTables() { Object.assign(T, { host: "tblVisHost", canvas: "tblVisCanvas", vis: false, typo: false }); }
  async function refreshNow() {
    if (T.typo) { if (window.AppTypoVis) await AppTypoVis.refreshPreview.now(true); renderHandles(); return; }
    if (T.vis) { await AppLive.refreshData(true); renderHandles(); return; }
    await V.refreshPreview.now(true);
  }

  /* ------------------------------ markup ------------------------------ */

  V.canvasHTML = function () {
    return `
      <div class="tbl-vis">
        <div class="pt-preview-head">
          <span class="pt-preview-name">Live Preview</span>
          <span style="flex:1"></span>
          <label style="font-size:12px;color:var(--pt-text2)">Sheet</label>
          <select id="tblVisSheet" style="max-width:260px" disabled></select>
          <span class="pt-pill idle" id="tblVisBadge">Ready</span>
        </div>
        <div class="vis-toolbar">
          ${App.histBar ? App.histBar() : ""}
          <button class="pt-btn small" onclick="AppTblVis.fit()" title="Fit page to window">⛶ Fit</button>
          <button class="pt-btn small" onclick="AppTblVis.setZoom(1)" title="Actual size">100%</button>
          <button class="pt-btn small" onclick="AppTblVis.center()" title="Center page">⌖ Center</button>
          <button class="pt-btn small" onclick="AppTblVis.zoomBy(1.25)" title="Zoom in">+</button>
          <button class="pt-btn small" onclick="AppTblVis.zoomBy(0.8)" title="Zoom out">−</button>
          <span class="tblv-pages" title="Pages of this sheet — tables on Continued pages too">
            <button class="pt-btn small" id="tblVisPrev" title="Previous page">◀</button>
            <span id="tblVisPage">Page 1</span>
            <button class="pt-btn small" id="tblVisNext" title="Next page">▶</button></span>
          <span style="flex:1"></span>
          <span class="vis-zoom-label" id="tblVisZoom">fit</span>
          <button class="pt-btn secondary small" onclick="AppTblVis.refreshPreview(true)">⟳ Render</button>
        </div>
        <div class="tblv-tabs" id="tblVisTabs" title="Every page of this sheet — Continued pages too"></div>
        <div class="vis-host tbl-vis-host" id="tblVisHost">
          <div class="vis-stage" id="tblVisStage">
            <canvas id="tblVisCanvas" class="vis-img" draggable="false"></canvas>
            <div class="vis-guides" id="tblVisGuides"></div>
          </div>
        </div>
        <div class="vis-hint-row">Live page preview — a page with an Excel table is picked automatically. <b>Click a table to choose its design</b> (just that table or every table) · <b>✂ hover its left / right edge to cut it</b>, drag a part anywhere, <b>right-click a part</b> for its page or to join · table settings re-render automatically · drag the shaded guides to adjust margins · scroll to zoom · drag empty space to pan.</div>
      </div>`;
  };

  /* ------------------------------ canvas ------------------------------ */

  function setBadge(mode, text) {
    const badge = el("tblVisBadge");
    if (!badge) return;
    badge.classList.toggle("idle", mode === "idle");
    badge.textContent = text || (mode === "busy" ? "Rendering…" : "Ready");
  }

  function layout() {
    const host = el("tblVisHost");
    const stage = el("tblVisStage");
    if (!host || !stage || !V.state.geometry) return;
    const g = V.state.geometry;
    const s = V.state.scale;
    host.style.setProperty("--typo-vis-ar", g.canvas_w + " / " + g.canvas_h);
    stage.style.width = (g.canvas_w * s) + "px";
    stage.style.height = (g.canvas_h * s) + "px";
    stage.style.transform = "translate(" + V.state.tx + "px," + V.state.ty + "px)";
    const zl = el("tblVisZoom");
    if (zl) zl.textContent = Math.round(s * 100) + "%";
    renderGuides();
    const c = el("tblVisCanvas");
    if (c && window.AppLive && window.AppLive.redrawInto) window.AppLive.redrawInto(c);
    renderHandles();
  }

  /* ---------------------- pages (Continued pages too) ---------------------- */
  function livePages() {
    return (window.AppLive && AppLive.state && AppLive.state.pages) || [];
  }
  /* the artist picked another page: a table selected on the old page is let go, so the next
     refresh stays on this page instead of following that table back */
  function goPage(n) {
    const pages = livePages(), to = Math.max(0, Math.min(pages.length - 1, n));
    if (V.state.selId && pageOf(V.state.selId) !== to) {
      V.state.selKey = null; V.state.selId = null; V.state.cells = []; V.state.barOpen = false;
    }
    showPage(to);
  }
  function showPage(n) {
    const pages = livePages();
    if (!pages.length) return;
    V.state.page = Math.max(0, Math.min(pages.length - 1, n));
    AppLive.setPage(V.state.page);
    const c = el("tblVisCanvas");
    if (c) AppLive.redrawInto(c);
    const lab = el("tblVisPage");
    if (lab) lab.textContent = `Page ${V.state.page + 1} of ${pages.length}`;
    const prev = el("tblVisPrev"), next = el("tblVisNext");
    if (prev) prev.disabled = V.state.page <= 0;
    if (next) next.disabled = V.state.page >= pages.length - 1;
    if (AppLive.hideTableBar) AppLive.hideTableBar();
    closeCellPop();
    renderHandles();
    renderTabs();
    document.querySelectorAll("#tblPagesGrid .tblp").forEach((b) => b.classList.toggle("on", Number(b.dataset.pg) === V.state.page));
  }
  /* one tab per page — "Continued" pages included; ▤ marks the pages with a table (or a part of one) */
  function renderTabs() {
    const box = el("tblVisTabs");
    if (!box) return;
    const pages = livePages();
    box.innerHTML = pages.map((pg, i) => {
      const tables = (pg.elements || []).filter((e) => e.kind === "table");
      const parts = tables.filter((e) => e.cut && e.cut.cuts && e.cut.cuts.length).length;
      const what = tables.length ? (parts ? ` ▤ ${parts} part${parts > 1 ? "s" : ""}` : " ▤") : "";
      return `<button class="tblv-tab ${i === (V.state.page || 0) ? "on" : ""}" data-pg="${i}">${i ? `Page ${i + 1} · Continued` : "Page 1"}${what}</button>`;
    }).join("");
    box.querySelectorAll("[data-pg]").forEach((b) => b.addEventListener("click", () => goPage(Number(b.dataset.pg))));
  }
  /* the side panel: a thumbnail of every page (Continued pages too); click one to edit it */
  let thumbTimer = null;
  function renderThumbs() {
    clearTimeout(thumbTimer);
    thumbTimer = setTimeout(() => {
      const grid = el("tblPagesGrid");
      if (!grid || !AppLive.renderThumb || T.vis) return;
      const pages = livePages();
      const urls = pages.map((_pg, i) => { try { return AppLive.renderThumb(i); } catch (e) { return ""; } });
      const mainCanvas = el("tblVisCanvas");
      if (mainCanvas) AppLive.redrawInto(mainCanvas);           // the preview stays the drawing target
      grid.innerHTML = pages.map((pg, i) => {
        const parts = (pg.elements || []).filter((e) => e.kind === "table").length;
        return `<button class="tblp ${i === (V.state.page || 0) ? "on" : ""}" data-pg="${i}" title="${i ? "Page " + (i + 1) + " (Continued)" : "Page 1"}">
          ${urls[i] ? `<img src="${urls[i]}" alt="">` : `<span class="tblp-empty">…</span>`}
          <span class="tblp-lab">${i ? `Page ${i + 1} · Continued` : "Page 1"}${parts ? " ▤" : ""}</span></button>`;
      }).join("") || `<div class="hint">No pages.</div>`;
      grid.querySelectorAll("[data-pg]").forEach((b) => b.addEventListener("click", () => goPage(Number(b.dataset.pg))));
    }, 250);
  }
  function pageOf(id) {                              // the page an element (a table / a part) is on
    if (!id) return -1;
    return livePages().findIndex((pg) => (pg.elements || []).some((e) => e.id === id));
  }
  function firstTablePage() {
    const i = livePages().findIndex((pg) => (pg.elements || []).some((e) => e.kind === "table"));
    return i < 0 ? 0 : i;
  }

  /* ---------------------- the selected table's handles ----------------------
     corners: the whole table and everything in it, proportionally (fonts, symbols, padding)
     sides: wider / narrower — the columns stretch, the content keeps its size
     bottom: taller — the rows get the room, the content stays centred
     column dividers / row lines: one column's width, one row's height */
  function selectedTable() {
    if (!V.state.selKey) return null;
    const els = (AppLive.state.elements || []).filter((e) => e.kind === "table" && e.design_key === V.state.selKey);
    return els.find((e) => e.id === V.state.selId) || els[0] || null;
  }
  function tableRect(e) {                            // where it is drawn (with the artist's move)
    const g = e.geo, cols = g.cols || [], rows = g.rows || [];
    const w = cols.reduce((a, b) => a + b, 0);
    const h = rows.reduce((a, b) => a + b, 0) + (g.row_gap || 0) * Math.max(0, rows.length - 1);
    const ov = e.ov || {};
    return { x: e.x + (g.x || 0) + (Number(ov.x) || 0), y: e.y + (Number(ov.y) || 0), w, h };
  }
  const globalRow = (e, i) => (e.geo && e.geo.rowMap ? e.geo.rowMap[i] : i);     // a part's row → the table's
  const localRow = (e, i) => (e.geo && e.geo.rowMap ? e.geo.rowMap.indexOf(i) : i);
  function renderHandles() {
    const host = H();
    if (!host) return;
    document.querySelectorAll(".tblh, .tblh-ghost").forEach((n) => n.remove());
    const e = selectedTable();
    const canvas = C();
    if (!e || !e.geo || !canvas || !AppLive.state.data) return;
    const cr = canvas.getBoundingClientRect(), hr = host.getBoundingClientRect();
    const k = cr.width / AppLive.state.data.canvas_w;
    const r = tableRect(e), g = e.geo;
    let acc = 0;
    const colLines = (g.cols || []).slice(0, -1).map((w, i) => { acc += w; return `<div class="tblh-col" data-h="col" data-i="${i}" style="left:${acc * k}px" title="Drag: this column's width"></div>`; }).join("");
    acc = 0;
    const rowLines = (g.rows || []).map((h, i) => { acc += h + (i ? (g.row_gap || 0) : 0); return `<div class="tblh-row" data-h="row" data-i="${i}" style="top:${acc * k}px" title="Drag: this row's height"></div>`; }).join("");
    const box = document.createElement("div");
    box.className = "tblh";
    Object.assign(box.style, { left: (cr.left - hr.left + r.x * k) + "px", top: (cr.top - hr.top + r.y * k) + "px", width: (r.w * k) + "px", height: (r.h * k) + "px" });
    // on the Canvas: no ✎ panel (the top bar has it all), and → / ↓ at the edges pick a row / column
    const arrows = T.typo ? arrowsHtml(g, k) : "";
    // the icon picked in it (and, sized together, the others it reaches): outlined
    const ic = window.TableStudio && TableStudio.state && TableStudio.state.icon;
    const icHtml = ic ? (g.icons || []).filter((i) => {
      const reach = TableStudio.state.iconReach || "cell";
      return reach === "table_all" || reach === "all_all" ? true : reach === "cell" ? i.cell === ic.cell && i.tok === ic.tok : i.tok === ic.tok;
    }).map((i) => { const on = i.cell === ic.cell && i.tok === ic.tok;
      return `<div class="tblh-icon ${on ? "on" : ""}" style="left:${(i.rect[0] - (g.x || 0)) * k}px;top:${(i.rect[1] - (g.y || 0)) * k}px;width:${i.rect[2] * k}px;height:${i.rect[3] * k}px">${on ? `<i class="tblh-ich" title="Drag: its size (what the Icon bar's choice reaches)"></i>` : ""}</div>`; }).join("") : "";
    box.innerHTML = `<div class="tblh-picks">${picksHtml(e, k)}${icHtml}</div>${colLines}${rowLines}${arrows}
      ${T.typo ? "" : `<button class="tblh-edit" title="This table's design and text">✎</button>`}
      <button class="tblh-move" title="Drag to move ${e.cut && e.cut.cuts.length ? "this part" : "this table"} anywhere on the page">✥</button>
      <div class="tblh-s l" data-h="w" data-sx="-1" title="Width — the content keeps its size"></div>
      <div class="tblh-s r" data-h="w" data-sx="1" title="Width — the content keeps its size"></div>
      <div class="tblh-s b" data-h="h" title="Height — the rows get the room"></div>
      ${[["tl", -1, -1], ["tr", 1, -1], ["bl", -1, 1], ["br", 1, 1]].map(([c, sx, sy]) => `<div class="tblh-c ${c}" data-h="scale" data-sx="${sx}" data-sy="${sy}" title="Scale the table and everything in it"></div>`).join("")}`;
    host.appendChild(box);
    box.querySelectorAll("[data-h]").forEach((hd) => hd.addEventListener("pointerdown", (ev) => startHandle(ev, hd, box, e, k)));
    // the picked icon's corner: drag it bigger / smaller (the icon follows the mouse, the size is set on release)
    box.querySelectorAll(".tblh-ich").forEach((hd) => {
      ["mousedown", "click", "dblclick"].forEach((t) => hd.addEventListener(t, (ev) => ev.stopPropagation()));
      hd.addEventListener("pointerdown", (ev) => {
        ev.stopPropagation(); ev.preventDefault();
        const ic = hd.parentElement, w0 = ic.offsetWidth, h0 = ic.offsetHeight, x0 = ev.clientX, y0 = ev.clientY;
        try { hd.setPointerCapture(ev.pointerId); } catch (_) { /* synthetic */ }
        let f = 1;
        const move = (mv) => {
          f = Math.max(0.2, Math.min(5, 1 + ((mv.clientX - x0) + (mv.clientY - y0)) / Math.max(10, w0 + h0)));
          Object.assign(ic.style, { width: `${w0 * f}px`, height: `${h0 * f}px` });
        };
        const up = () => {
          hd.removeEventListener("pointermove", move);
          hd.removeEventListener("pointerup", up);
          if (Math.abs(f - 1) > 0.02 && window.TableStudio && TableStudio.iconScaleBy) TableStudio.iconScaleBy(f);
        };
        hd.addEventListener("pointermove", move);
        hd.addEventListener("pointerup", up);
      });
    });
    box.addEventListener("pointerdown", (ev) => startMove(ev, box, e, k));
    const grip = box.querySelector(".tblh-move");
    grip.addEventListener("pointerdown", (ev) => { ev.stopPropagation(); startMove(ev, box, e, k, true); });
    ["mousedown", "click"].forEach((t) => grip.addEventListener(t, (ev) => ev.stopPropagation()));
    const pen = box.querySelector(".tblh-edit");
    if (pen) {
      pen.addEventListener("pointerdown", (ev) => ev.stopPropagation());
      pen.addEventListener("mousedown", (ev) => ev.stopPropagation());
      pen.addEventListener("click", (ev) => { ev.stopPropagation(); V.state.barOpen = true; closeCellPop(); openBar(e); });
    }
    wireArrows(box, e);
    // the other parts of a cut table: their own → ↓ arrows and picked boxes (an arrow there picks that part)
    if (T.typo) {
      (AppLive.state.elements || []).filter((x) => x.kind === "table" && x.design_key === e.design_key && x.id !== e.id && x.geo).forEach((part) => {
        const pr = tableRect(part), ghost = document.createElement("div");
        ghost.className = "tblh-ghost";
        Object.assign(ghost.style, { left: (cr.left - hr.left + pr.x * k) + "px", top: (cr.top - hr.top + pr.y * k) + "px", width: (pr.w * k) + "px", height: (pr.h * k) + "px" });
        ghost.innerHTML = `<div class="tblh-picks">${picksHtml(part, k)}</div>${arrowsHtml(part.geo, k)}`;
        host.appendChild(ghost);
        wireArrows(ghost, part);
      });
    }
  }
  // → at the left of each row, ↓ above each column: pick it
  function arrowsHtml(g, k) {
    let at = 0;
    let html = (g.rows || []).map((h, i) => { const y = at; at += h + (g.row_gap || 0); return `<div class="tblh-rsel" data-rsel="${i}" style="top:${y * k}px;height:${h * k}px" title="Pick this row (Shift / Ctrl: add it)">→</div>`; }).join("");
    at = 0;
    html += (g.cols || []).map((w, i) => { const x = at; at += w; return `<div class="tblh-csel" data-csel="${i}" style="left:${x * k}px;width:${w * k}px" title="Pick this column (Shift / Ctrl: add it)">↓</div>`; }).join("");
    return html;
  }
  function wireArrows(root, part) {
    root.querySelectorAll("[data-rsel], [data-csel]").forEach((a) => {
      ["pointerdown", "mousedown", "dblclick"].forEach((t) => a.addEventListener(t, (ev) => ev.stopPropagation()));
      a.addEventListener("click", (ev) => {
        ev.stopPropagation();
        if (part.id !== V.state.selId) V.pickInTypo(part);              // another part of the table: it gets the handles
        const n = part.geo, row = a.dataset.rsel != null, i = Number(row ? a.dataset.rsel : a.dataset.csel);
        const keys = row ? keysIn(part, i, i, 0, n.cols.length - 1) : keysIn(part, 0, n.rows.length - 1, i, i);
        V.state.anchor = keys[0];
        setCells(keys, ev.shiftKey || ev.ctrlKey || ev.metaKey ? "add" : "set");
      });
    });
  }
  // the picked boxes, outlined
  function picksHtml(e, k) {
    return (V.state.cells || []).map((key) => cellRect(e, key)).filter(Boolean)
      .map((c) => `<div class="tblh-cell" style="left:${c.x * k}px;top:${c.y * k}px;width:${c.w * k}px;height:${c.h * k}px"></div>`).join("");
  }

  /* a pop-up beside what it edits (host px rect): to its right, else its left; top level with
     it; always inside the preview, scrolling when taller than it */
  function placeBeside(pop, a) {
    const host = H();
    if (!host || !pop) return;
    pop.__anchor = a;
    if (!pop.__later) {                                // and again once its swatch pickers have filled in
      pop.__later = true;
      [60, 250, 700].forEach((ms) => setTimeout(() => { if (pop.isConnected) placeBeside(pop, pop.__anchor); }, ms));
    }
    if (!pop.__ro && window.ResizeObserver) {          // it grows as its pickers fill in: placed again
      pop.__ro = new ResizeObserver(() => {
        const size = pop.offsetWidth + "x" + pop.offsetHeight;
        if (pop.isConnected && size !== pop.__size) placeBeside(pop, pop.__anchor);
      });
      pop.__ro.observe(pop);
    }
    const hw = host.clientWidth, hh = host.clientHeight;
    pop.style.maxHeight = Math.max(160, hh - 16) + "px";
    pop.style.overflowY = "auto";
    const w = pop.offsetWidth, h = pop.offsetHeight;
    let left = a.r + 10;
    if (left + w > hw - 6) left = a.l - w - 10;
    left = Math.max(6, Math.min(hw - w - 6, left));
    const top = Math.max(6, Math.min(hh - h - 6, a.t));
    Object.assign(pop.style, { left: left + "px", top: top + "px" });
    pop.__size = w + "x" + h;
  }
  function hostRect(node) {
    const hr = H().getBoundingClientRect(), r = node.getBoundingClientRect();
    return { l: r.left - hr.left, r: r.right - hr.left, t: r.top - hr.top, b: r.bottom - hr.top };
  }
  if (window.AppLive) AppLive.state.tableBarAnchor = (bar) => {
    const pen = document.querySelector(".tblh .tblh-edit");
    if (!pen || !bar.closest("#" + T.host)) return false;
    placeBeside(bar, hostRect(pen));
    return true;
  };

  function openBar(e) {
    const canvas = C(), host = H();
    if (!canvas || !host || !AppLive.showTableBar) return;
    AppLive.showTableBar(host, canvas, e, () => refreshNow(), () => { V.state.barOpen = false; });
  }

  /* ---------------------- one box (or a few): double-click, Shift adds ---------------------- */
  function cellSpans(e) {
    return (e.geo && e.geo.cells) || [];
  }
  function cellAt(e, px, py) {                       // canvas px → the box's key "row,column"
    const g = e.geo, r = tableRect(e);
    let x = px - r.x, y = py - r.y, ci = -1, ri = -1;
    if (x < 0 || y < 0 || x > r.w || y > r.h) return null;
    for (let i = 0, acc = 0; i < g.cols.length; i++) { acc += g.cols[i]; if (x <= acc) { ci = i; break; } }
    for (let i = 0, acc = 0; i < g.rows.length; i++) { acc += g.rows[i] + (i ? (g.row_gap || 0) : 0); if (y <= acc) { ri = i; break; } }
    if (ri < 0 || ci < 0) return null;
    const hit = cellSpans(e).find(([r0, c0, rs, cs]) => ri >= r0 && ri < r0 + rs && ci >= c0 && ci < c0 + cs);
    return hit ? `${globalRow(e, hit[0])},${hit[1]}` : `${globalRow(e, ri)},${ci}`;
  }
  function cellRect(e, key) {
    const g = e.geo, [gri, ci] = key.split(",").map(Number), ri = localRow(e, gri);
    if (ri < 0) return null;
    const span = cellSpans(e).find(([r0, c0]) => r0 === ri && c0 === ci) || [ri, ci, 1, 1];
    if (ri >= g.rows.length || ci >= g.cols.length) return null;
    const sum = (a, n) => a.slice(0, n).reduce((x, y) => x + y, 0);
    const gap = g.row_gap || 0;
    const x = sum(g.cols, ci), w = sum(g.cols, Math.min(g.cols.length, ci + span[3])) - x;
    const y = sum(g.rows, ri) + gap * ri;
    const h = sum(g.rows, Math.min(g.rows.length, ri + span[2])) + gap * (Math.min(g.rows.length, ri + span[2]) - 1) - y;
    return { x, y, w, h };
  }
  function pointOnCanvas(ev) {
    const canvas = C();
    const cr = canvas.getBoundingClientRect(), k = cr.width / AppLive.state.data.canvas_w;
    return [(ev.clientX - cr.left) / k, (ev.clientY - cr.top) / k];
  }
  /* the boxes in a block of the grid (a part's own rows / columns, both ends in): their keys, a merged
     box once */
  function keysIn(e, r0, r1, c0, c1) {
    const g = e.geo, out = [];
    for (let ri = Math.min(r0, r1); ri <= Math.max(r0, r1) && ri < g.rows.length; ri++) {
      for (let ci = Math.min(c0, c1); ci <= Math.max(c0, c1) && ci < g.cols.length; ci++) {
        const hit = cellSpans(e).find(([a, b, rs, cs]) => ri >= a && ri < a + rs && ci >= b && ci < b + cs);
        const key = hit ? `${globalRow(e, hit[0])},${hit[1]}` : `${globalRow(e, ri)},${ci}`;
        if (!out.includes(key)) out.push(key);
      }
    }
    return out;
  }
  const gridAt = (e, key) => { const [gr, c] = key.split(",").map(Number); return [localRow(e, gr), c]; };
  // these boxes picked: "set" (only them), "add", "toggle"; the top bar (or the pop-up) follows
  function setCells(keys, how) {
    const now = V.state.cells || [];
    if (how === "add") V.state.cells = now.concat(keys.filter((x) => !now.includes(x)));
    else if (how === "toggle") V.state.cells = now.filter((x) => !keys.includes(x)).concat(keys.filter((x) => !now.includes(x)));
    else V.state.cells = keys.slice();
    V.state.barOpen = false;
    if (AppLive.hideTableBar) AppLive.hideTableBar();
    renderHandles();
    if (T.typo && window.TableStudio && TableStudio.showCells) { closeCellPop(); TableStudio.showCells(); }
    else if (V.state.cells.length) showCellPop();
    else closeCellPop();
  }
  /* boxes picked (the Canvas): a drag over the table picks a block of boxes, a click one box —
     Shift: from the last one clicked to this one, Ctrl: one more / one less. ✥ still moves it. */
  function startBlock(ev, box, e, k) {
    const [px, py] = pointOnCanvas(ev), k0 = cellAt(e, px, py);
    if (!k0) return;
    ev.preventDefault();
    try { box.setPointerCapture(ev.pointerId); } catch (_) { /* synthetic */ }
    const before = (V.state.cells || []).slice(), [r0, c0] = gridAt(e, k0), plus = ev.shiftKey || ev.ctrlKey || ev.metaKey;
    const D = { x: ev.clientX, y: ev.clientY, moved: false, last: "" };
    const move = (mv) => {
      if (!D.moved && Math.abs(mv.clientX - D.x) + Math.abs(mv.clientY - D.y) < 4) return;
      D.moved = true;
      const [qx, qy] = pointOnCanvas(mv), k1 = cellAt(e, qx, qy);
      if (!k1 || k1 === D.last) return;
      D.last = k1;
      const [r1, c1] = gridAt(e, k1);
      const block = keysIn(e, r0, r1, c0, c1);
      V.state.cells = plus ? before.concat(block.filter((x) => !before.includes(x))) : block;
      const layer = box.querySelector(".tblh-picks");
      if (layer) layer.innerHTML = picksHtml(e, k);
    };
    const up = () => {
      box.removeEventListener("pointermove", move);
      box.removeEventListener("pointerup", up);
      if (D.moved) { V.state.anchor = k0; setCells(V.state.cells, "set"); return; }
      if (ev.shiftKey && V.state.anchor) {
        const [ra, ca] = gridAt(e, V.state.anchor);
        if (ra >= 0) { setCells(keysIn(e, ra, r0, ca, c0), "add"); return; }
      }
      V.state.anchor = k0;
      setCells([k0], ev.ctrlKey || ev.metaKey ? "toggle" : "set");
    };
    box.addEventListener("pointermove", move);
    box.addEventListener("pointerup", up);
  }

  function pickCell(ev, add) {
    const e = selectedTable();
    if (!e || !e.geo) return false;
    const [px, py] = pointOnCanvas(ev);
    const key = cellAt(e, px, py);
    if (!key) return false;
    const now = V.state.cells || [];
    V.state.cells = add ? (now.includes(key) ? now.filter((k) => k !== key) : now.concat([key])) : [key];
    if (!add) V.state.anchor = key;
    V.state.barOpen = false;
    if (AppLive.hideTableBar) AppLive.hideTableBar();
    renderHandles();
    // on the Canvas the top bar becomes the Cell bar (table_studio.js); elsewhere the pop-up
    if (T.typo && window.TableStudio && TableStudio.showCells) { closeCellPop(); TableStudio.showCells(); }
    else showCellPop();
    return true;
  }
  function closeCellPop() {
    document.getElementById("tblCellPop")?.remove();
  }
  function cellLay() {
    const ts = (App.state.config.table_style = App.state.config.table_style || {});
    const lay = Object.assign({}, (ts.table_layouts || {})[V.state.selKey] || {});
    lay.cells = Object.assign({}, lay.cells || {});
    return { ts, lay };
  }
  function showCellPop() {
    closeCellPop();
    const e = selectedTable(), keys = V.state.cells || [];
    const host = H(), canvas = C();
    if (!e || !keys.length || !host || !canvas) return;
    const { lay } = cellLay();
    const spec = lay.cells[keys[0]] || {};
    const fonts = (App.state.fonts || []).slice().sort((a, b) => String(a).localeCompare(String(b)));
    const lib = Object.keys(((App.state.config.dynamic_settings || {}).layer_style_library) || {}).sort();
    const pop = document.createElement("div");
    pop.id = "tblCellPop";
    pop.className = "vis-style-bar tbl-cell-pop";
    pop.innerHTML = `<div class="vsb-head"><b>${keys.length === 1 ? "This box" : keys.length + " boxes"}</b>
        <span class="vsb-hint">Shift-click to add boxes · only these change</span><button class="vsb-x" data-cx title="Done">✕</button></div>
      <div class="vsb-row"><span class="vsb-lab">Box</span>
        <label class="vsb-scope" title="Its own fill colour"><input type="checkbox" id="tcFillOn" ${spec.fill ? "checked" : ""}> fill <input type="color" id="tcFill" value="${spec.fill || "#1e3a8a"}"></label>
        <label class="vsb-scope" title="Its own border"><input type="checkbox" id="tcBorderOn" ${spec.border ? "checked" : ""}> border <input type="color" id="tcBorder" value="${spec.border || "#ffd54a"}"></label>
        <input type="number" id="tcBorderW" class="vsb-num" min="1" max="20" value="${spec.border_width || 3}" title="Border width (px)">px</div>
      <div class="vsb-row"><span class="vsb-lab">Text</span>
        <select id="tcFont" class="vsb-font">${[["", "Same font"]].concat(fonts.map((f) => [f, f])).map(([v, t]) => `<option value="${esc(v)}" ${v === (spec.font || "") ? "selected" : ""}>${esc(t)}</option>`).join("")}</select>
        <label class="vsb-lab">Size <input type="number" id="tcSize" class="vsb-num" min="6" max="300" value="${spec.size || ""}" placeholder="same">px</label></div>
      <div class="vsb-row">
        <label class="vsb-scope"><input type="checkbox" id="tcColorOn" ${spec.color ? "checked" : ""}> colour <input type="color" id="tcColor" value="${spec.color || "#ffffff"}"></label>
        <button class="vsb-tog ${spec.bold ? "on" : ""}" id="tcBold" title="Bold"><b>B</b></button>
        <button class="vsb-tog ${spec.italic ? "on" : ""}" id="tcItalic" title="Italic"><i>I</i></button>
        <span class="vsb-lab">Layer style</span>
        <select id="tcFx" data-lsswatch>${[["", "None"]].concat(lib.map((n) => [n, n])).map(([v, t]) => `<option value="${esc(v)}" ${v === (spec.fx || "") ? "selected" : ""}>${esc(t)}</option>`).join("")}</select></div>
      <div class="vsb-row"><span style="flex:1"></span><button class="pt-btn secondary small" data-creset>Back to the table's look</button></div>`;
    ["pointerdown", "mousedown", "click", "dblclick"].forEach((t) => pop.addEventListener(t, (ev) => ev.stopPropagation()));
    host.appendChild(pop);
    // beside the box that was double-clicked (the last one picked)
    const cr = canvas.getBoundingClientRect(), hr = host.getBoundingClientRect(), k = cr.width / AppLive.state.data.canvas_w;
    const r = tableRect(e), c = cellRect(e, keys[keys.length - 1]) || { x: 0, y: 0, w: r.w, h: 0 };
    const bx = cr.left - hr.left + (r.x + c.x) * k, by = cr.top - hr.top + (r.y + c.y) * k;
    placeBeside(pop, { l: bx, r: bx + c.w * k, t: by, b: by + c.h * k });
    const q = (id) => pop.querySelector("#" + id);
    const write = (patch) => {
      const { ts, lay } = cellLay();
      keys.forEach((key) => {
        const next = Object.assign({}, lay.cells[key] || {}, patch);
        Object.keys(next).forEach((k2) => { if (next[k2] === undefined || next[k2] === "" || next[k2] === null) delete next[k2]; });
        if (Object.keys(next).length) lay.cells[key] = next; else delete lay.cells[key];
      });
      ts.table_layouts = Object.assign({}, ts.table_layouts || {}, { [V.state.selKey]: lay });
      saveAndRedraw();
    };
    q("tcFillOn").addEventListener("change", () => write({ fill: q("tcFillOn").checked ? q("tcFill").value : undefined }));
    q("tcFill").addEventListener("change", () => { q("tcFillOn").checked = true; write({ fill: q("tcFill").value }); });
    const border = () => write({ border: q("tcBorderOn").checked ? q("tcBorder").value : undefined,
                                 border_width: q("tcBorderOn").checked ? Number(q("tcBorderW").value) || 3 : undefined });
    q("tcBorderOn").addEventListener("change", border);
    q("tcBorder").addEventListener("change", () => { q("tcBorderOn").checked = true; border(); });
    q("tcBorderW").addEventListener("change", () => { q("tcBorderOn").checked = true; border(); });
    q("tcFont").addEventListener("change", () => write({ font: q("tcFont").value || undefined }));
    q("tcSize").addEventListener("change", () => {
      const v = Number(q("tcSize").value) || 0;
      write({ size: v > 0 ? Math.round(v / ((e.geo && e.geo.scale) || 1)) : undefined });   // stored at scale 1
    });
    q("tcColorOn").addEventListener("change", () => write({ color: q("tcColorOn").checked ? q("tcColor").value : undefined }));
    q("tcColor").addEventListener("change", () => { q("tcColorOn").checked = true; write({ color: q("tcColor").value }); });
    q("tcBold").addEventListener("click", () => write({ bold: !q("tcBold").classList.contains("on") }));
    q("tcItalic").addEventListener("click", () => write({ italic: !q("tcItalic").classList.contains("on") }));
    q("tcFx").addEventListener("change", () => write({ fx: q("tcFx").value || undefined }));
    pop.querySelector("[data-cx]").addEventListener("click", () => { V.state.cells = []; closeCellPop(); renderHandles(); });
    pop.querySelector("[data-creset]").addEventListener("click", () => {
      const { ts, lay } = cellLay();
      keys.forEach((key) => delete lay.cells[key]);
      ts.table_layouts = Object.assign({}, ts.table_layouts || {}, { [V.state.selKey]: lay });
      saveAndRedraw();
    });
  }
  async function saveAndRedraw() {
    App.refreshUI();
    if (App.flushConfig) await App.flushConfig();
    await refreshNow();
  }

  /* drag the selected table (or one part of a cut table) anywhere: live_overrides[sheet][its id] */
  function startMove(ev, box, e, k, grip) {
    if (ev.button !== 0 || (!grip && ev.target !== box && !ev.target.closest(".tblh-picks"))) return;
    if (!grip && T.typo && (V.state.cells || []).length) return startBlock(ev, box, e, k);   // boxes picked: a drag picks more
    const D = { x: ev.clientX, y: ev.clientY, l: parseFloat(box.style.left), t: parseFloat(box.style.top), moved: false };
    try { box.setPointerCapture(ev.pointerId); } catch (_) { /* synthetic */ }
    const move = (mv) => {
      const dx = mv.clientX - D.x, dy = mv.clientY - D.y;
      if (!D.moved && Math.abs(dx) + Math.abs(dy) < 4) return;
      if (!D.moved) {
        D.moved = true;
        if (AppLive.hideTableBar) AppLive.hideTableBar();
        if (AppLive.hideCutButtons) AppLive.hideCutButtons();
        closeCellPop();
      }
      Object.assign(box.style, { left: (D.l + dx) + "px", top: (D.t + dy) + "px" });
    };
    const up = async (u) => {
      box.removeEventListener("pointermove", move);
      box.removeEventListener("pointerup", up);
      if (!D.moved) return;                             // a click: the host selects / picks a box
      V.state.clickWasPan = true;
      setTimeout(() => { V.state.clickWasPan = false; }, 0);
      const dx = Math.round((u.clientX - D.x) / k), dy = Math.round((u.clientY - D.y) / k);
      const sheet = AppLive.state.data && AppLive.state.data.sheet_name;
      if (!sheet || (!dx && !dy)) return;
      const dyn = (App.state.config.dynamic_settings = App.state.config.dynamic_settings || {});
      const lo = Object.assign({}, dyn.live_overrides || {});
      const mine = Object.assign({}, lo[sheet] || {});
      const ov = Object.assign({}, mine[e.id] || {});
      ov.x = Math.round((Number(ov.x) || 0) + dx);
      ov.y = Math.round((Number(ov.y) || 0) + dy);
      if (!ov.x) delete ov.x;
      if (!ov.y) delete ov.y;
      if (Object.keys(ov).length) mine[e.id] = ov; else delete mine[e.id];
      lo[sheet] = mine;
      dyn.live_overrides = lo;
      App.refreshUI();
      if (App.flushConfig) await App.flushConfig();
      await refreshNow();
    };
    box.addEventListener("pointermove", move);
    box.addEventListener("pointerup", up);
  }

  function startHandle(ev, hd, box, e, k) {
    if (ev.button !== 0) return;
    ev.preventDefault(); ev.stopPropagation();
    try { hd.setPointerCapture(ev.pointerId); } catch (_) { /* synthetic */ }
    if (AppLive.hideTableBar) AppLive.hideTableBar();
    const kind = hd.dataset.h, sx = Number(hd.dataset.sx || 1), sy = Number(hd.dataset.sy || 1), i = Number(hd.dataset.i || 0);
    const g = e.geo, r = tableRect(e), s = g.scale || 1;
    const centred = String((App.state.config.table_style || {}).table_alignment || "center").toLowerCase() === "center";
    const b0 = { l: parseFloat(box.style.left), t: parseFloat(box.style.top), w: parseFloat(box.style.width), h: parseFloat(box.style.height) };
    const D = { x: ev.clientX, y: ev.clientY, dx: 0, dy: 0 };
    const tip = document.createElement("div");
    tip.className = "tblh-tip";
    box.appendChild(tip);
    const fScale = () => Math.max(0.2, Math.min(5, ((r.w + sx * D.dx / k) / r.w + (r.h + sy * D.dy / k) / r.h) / 2));
    const move = (mv) => {
      D.dx = mv.clientX - D.x; D.dy = mv.clientY - D.y;
      if (kind === "scale") {
        const f = fScale(), w = b0.w * f, h = b0.h * f;
        Object.assign(box.style, { width: w + "px", height: h + "px", left: (sx < 0 ? b0.l + b0.w - w : b0.l) + "px", top: (sy < 0 ? b0.t + b0.h - h : b0.t) + "px" });
        tip.textContent = Math.round(f * 100) + "%";
      } else if (kind === "w") {
        const grow = sx * D.dx * (centred ? 2 : 1);
        const w = Math.max(40, b0.w + grow);
        Object.assign(box.style, { width: w + "px", left: (centred ? b0.l - (w - b0.w) / 2 : sx < 0 ? b0.l + b0.w - w : b0.l) + "px" });
        tip.textContent = Math.round(w / k) + " px wide";
      } else if (kind === "h") {
        box.style.height = Math.max(20, b0.h + D.dy) + "px";
        tip.textContent = Math.round(Math.max(20, b0.h + D.dy) / k) + " px tall";
      } else if (kind === "col") {
        hd.style.transform = `translateX(${D.dx}px)`;
        tip.textContent = "column " + (i + 1) + ": " + Math.round(Math.max(16, g.cols[i] + D.dx / k)) + " px";
      } else if (kind === "row") {
        hd.style.transform = `translateY(${D.dy}px)`;
        tip.textContent = "row " + (i + 1) + ": " + Math.round(Math.max(8, g.rows[i] + D.dy / k)) + " px";
      }
    };
    const up = async () => {
      hd.removeEventListener("pointermove", move);
      hd.removeEventListener("pointerup", up);
      tip.remove();
      if (Math.abs(D.dx) + Math.abs(D.dy) < 2) { renderHandles(); return; }
      const ts = (App.state.config.table_style = App.state.config.table_style || {});
      const lay = Object.assign({}, (ts.table_layouts || {})[e.design_key] || {});
      if (kind === "scale") {
        lay.scale = Math.round(s * fScale() * 1000) / 1000;
      } else if (kind === "w") {
        lay.width = Math.round(Math.max(40, r.w + sx * D.dx / k * (centred ? 2 : 1)) / s);
        if (!lay.cols) lay.cols = g.cols.map((c) => c / r.w);
      } else if (kind === "h") {
        lay.height = Math.round(Math.max(10, r.h + D.dy / k) / s);
      } else if (kind === "col") {
        // the divider moves: this column grows by what the next one gives (both stay ≥ 16 px)
        const ws = g.cols.slice();
        const d = Math.max(16 - ws[i], Math.min(ws[i + 1] - 16, D.dx / k));
        ws[i] += d; ws[i + 1] -= d;
        const tot = ws.reduce((x, y) => x + y, 0);
        lay.cols = ws.map((c) => Math.round(c / tot * 10000) / 10000);
        lay.width = Math.round(tot / s);
      } else if (kind === "row") {
        const rh = (lay.row_h || []).slice(), gi = globalRow(e, i);
        while (rh.length <= gi) rh.push(0);
        rh[gi] = Math.round(Math.max(8, g.rows[i] + D.dy / k) / s);
        lay.row_h = rh;
      }
      ts.table_layouts = Object.assign({}, ts.table_layouts || {}, { [e.design_key]: lay });
      App.refreshUI();
      if (App.flushConfig) await App.flushConfig();
      await refreshNow();
    };
    hd.addEventListener("pointermove", move);
    hd.addEventListener("pointerup", up);
  }

  // the margins the guides move (same as the Typography preview)
  const GUIDE_DEFS = [
    { id: "header_top", label: "Header Top Margin", key: "heading_top_margin", orientation: "h", edge: "top", min: 0, max: 800 },
    { id: "heading_gap", label: "Heading–Body Gap", key: "heading_to_body_gap", orientation: "h", edge: "gap", min: 0, max: 400 },
    { id: "body_bottom", label: "Bottom Margin", key: "bottom_margin", orientation: "h", edge: "bottom", min: 0, max: 1000 },
    { id: "safe_left", label: "Inner Canvas Width", key: "inner_canvas_width", orientation: "v", edge: "left", min: 100, max: 5000 },
    { id: "safe_right", label: "Inner Canvas Width", key: "inner_canvas_width", orientation: "v", edge: "right", min: 100, max: 5000 },
  ];
  function guidesFor(g) {
    const cw = g.canvas_w, ch = g.canvas_h;
    return GUIDE_DEFS.map((gd) => {
      let x0 = 0, y0 = 0, value = 0;
      if (gd.edge === "top") { y0 = g.heading_top; value = g.heading_top; }
      else if (gd.edge === "gap") { y0 = g.body_top; value = Math.max(0, g.body_top - g.heading_bottom); }
      else if (gd.edge === "bottom") { y0 = g.body_bottom; value = Math.max(0, ch - g.body_bottom); }
      else if (gd.edge === "left") { x0 = g.safe_left; value = Math.max(0, cw - 2 * g.safe_left); }
      else { x0 = g.safe_right; value = Math.max(0, 2 * g.safe_right - cw); }
      return Object.assign({}, gd, { x0, y0, value });
    });
  }

  function renderGuides() {
    const hostEl = el("tblVisGuides");
    if (!hostEl || !V.state.geometry) return;
    const g = V.state.geometry;
    const s = V.state.scale;
    const rects = [
      { cls: "vis-rect-safe", l: g.safe_left * s, t: g.body_top * s, w: (g.safe_right - g.safe_left) * s, h: (g.body_bottom - g.body_top) * s },
      { cls: "vis-rect-head", l: g.safe_left * s, t: g.heading_top * s, w: (g.safe_right - g.safe_left) * s, h: (g.heading_bottom - g.heading_top) * s },
    ];
    const rectHTML = rects.filter((r) => r.w > 0 && r.h > 0 && isFinite(r.w) && isFinite(r.h))
      .map((r) => `<div class="vis-rect ${r.cls}" style="left:${r.l}px;top:${r.t}px;width:${r.w}px;height:${r.h}px"></div>`).join("");
    const lineHTML = (V.state.guides || []).map((gd) => {
      if (gd.orientation === "h") {
        return `<div class="vis-guide vis-guide-h" data-gid="${gd.id}" data-edge="${gd.edge}" style="top:${gd.y0 * s}px"><span class="vis-guide-tag">${esc(gd.label)}</span></div>`;
      }
      return `<div class="vis-guide vis-guide-v" data-gid="${gd.id}" data-edge="${gd.edge}" style="left:${gd.x0 * s}px"><span class="vis-guide-tag">${esc(gd.label)}</span></div>`;
    }).join("");
    hostEl.innerHTML = rectHTML + lineHTML;
  }

  function fit() {
    const host = el("tblVisHost");
    if (!host || !V.state.geometry) return;
    const rect = host.getBoundingClientRect();
    const g = V.state.geometry;
    const s = Math.max(MIN_SCALE, Math.min(MAX_SCALE, (rect.width - 40) / g.canvas_w, (rect.height - 40) / g.canvas_h));
    V.state.scale = s;
    V.state.tx = Math.max(0, (rect.width - g.canvas_w * s) / 2);
    V.state.ty = Math.max(0, (rect.height - g.canvas_h * s) / 2);
    V.state.fitted = true;
    V.state.userView = false;
    layout();
  }

  function centerOnly() {
    const host = el("tblVisHost");
    if (!host || !V.state.geometry) return;
    const rect = host.getBoundingClientRect();
    const g = V.state.geometry;
    V.state.tx = Math.max(0, (rect.width - g.canvas_w * V.state.scale) / 2);
    V.state.ty = Math.max(0, (rect.height - g.canvas_h * V.state.scale) / 2);
    layout();
  }

  V.fit = fit;
  V.center = centerOnly;
  V.setZoom = function (z) {
    V.state.scale = Math.max(MIN_SCALE, Math.min(MAX_SCALE, z));
    V.state.fitted = false;
    V.state.userView = true;               // zoomed by the artist: kept
    centerOnly();
  };
  V.zoomBy = function (f) {
    V.setZoom(V.state.scale * f);
  };

  /* --------------------------- pan / zoom --------------------------- */

  function bindCanvasEvents() {
    const host = el("tblVisHost");
    if (!host) return;
    host.addEventListener("wheel", (ev) => {
      ev.preventDefault();
      if (!V.state.geometry) return;
      const rect = host.getBoundingClientRect();
      const mx = ev.clientX - rect.left;
      const my = ev.clientY - rect.top;
      const prev = V.state.scale;
      const next = Math.max(MIN_SCALE, Math.min(MAX_SCALE, prev * (ev.deltaY < 0 ? 1.12 : 1 / 1.12)));
      const ratio = next / prev;
      V.state.tx = mx - (mx - V.state.tx) * ratio;
      V.state.ty = my - (my - V.state.ty) * ratio;
      V.state.scale = next;
      V.state.fitted = false;
      V.state.userView = true;             // zoomed by the artist: kept
      layout();
    }, { passive: false });

    host.addEventListener("mousedown", (ev) => {
      if (ev.button !== 0) return;
      const guideEl = ev.target.closest(".vis-guide");
      if (guideEl) {
        dragGuideStart(guideEl.dataset.gid, ev);
        return;
      }
      if (ev.target.closest("#visStyleBar, #visTableBar, .lsw-pop, .tblh, .vis-cut, #visPartMenu")) return;
      V.state.pan = { x: ev.clientX, y: ev.clientY, tx: V.state.tx, ty: V.state.ty, moved: false };
      host.classList.add("vis-panning");
      ev.preventDefault();
    });
    // a click (not a drag): a table → its design; a line of text → its word styles
    host.addEventListener("click", (ev) => {
      if (V.state.clickWasPan || ev.target.closest("#visStyleBar, #visTableBar, .lsw-pop, .vis-guide")) return;
      const canvas = el("tblVisCanvas");
      if (!canvas || !window.AppLive || !AppLive.styleRowAt) return;
      if (ev.target.closest(".tblh-c, .tblh-s, .tblh-col, .tblh-row")) return;
      if (ev.target.closest("#tblCellPop, .tblh-edit")) return;
      const r = canvas.getBoundingClientRect();
      const t = AppLive.tableAt ? AppLive.tableAt(canvas, ev.clientX - r.left, ev.clientY - r.top) : null;
      if (t && ev.shiftKey && t.design_key === V.state.selKey && (V.state.cells || []).length) { pickCell(ev, true); return; }
      const same = t && t.design_key === V.state.selKey && t.id === V.state.selId;
      V.state.selKey = t ? t.design_key : null;
      V.state.selId = t ? t.id : null;
      if (!same) { V.state.cells = []; V.state.barOpen = false; closeCellPop(); }
      AppLive.styleRowAt(canvas, host, ev.clientX - r.left, ev.clientY - r.top, () => V.refreshPreview.now(true), { selectOnly: true });
      if (!same) renderHandles();
    });
    // double-click a box: edit just that box (Shift adds more)
    host.addEventListener("dblclick", (ev) => {
      if (ev.target.closest("#visStyleBar, #visTableBar, #tblCellPop, .lsw-pop, .tblh-edit")) return;
      const canvas = el("tblVisCanvas");
      if (!canvas || !AppLive.tableAt) return;
      const r = canvas.getBoundingClientRect();
      const t = AppLive.tableAt(canvas, ev.clientX - r.left, ev.clientY - r.top);
      if (!t) return;
      if (t.design_key !== V.state.selKey || t.id !== V.state.selId) { V.state.selKey = t.design_key; V.state.selId = t.id; V.state.cells = []; }
      pickCell(ev, ev.shiftKey);
    });
    const refresh = () => V.refreshPreview.now(true);
    host.addEventListener("pointermove", (ev) => {
      const canvas = el("tblVisCanvas");
      if (canvas && AppLive.cutHover && !V.state.pan && !V.state.drag) AppLive.cutHover(ev, host, canvas, refresh);
    });
    host.addEventListener("pointerleave", () => AppLive.hideCutButtons && AppLive.hideCutButtons());
    host.addEventListener("contextmenu", (ev) => {
      const canvas = el("tblVisCanvas");
      if (!canvas || !AppLive.tablePartMenu || ev.target.closest("#visTableBar, #tblCellPop, .lsw-pop")) return;
      if (AppLive.tablePartMenu(ev, host, canvas, refresh)) {
        const r = canvas.getBoundingClientRect();
        const t = AppLive.tableAt(canvas, ev.clientX - r.left, ev.clientY - r.top);
        if (t) { V.state.selKey = t.design_key; V.state.selId = t.id; renderHandles(); }
      }
    });
    document.addEventListener("keydown", (ev) => {
      if (ev.key !== "Escape" || App.route !== "tables" || !(V.state.cells || []).length) return;
      V.state.cells = []; closeCellPop(); renderHandles();
    });

    if (V._bound) return;
    V._bound = true;

    document.addEventListener("mousemove", (ev) => {
      const d = V.state.drag;
      if (d) {
        dragGuideMove(ev);
        return;
      }
      const p = V.state.pan;
      if (!p) return;
      if (Math.abs(ev.clientX - p.x) + Math.abs(ev.clientY - p.y) > 3) { p.moved = true; V.state.userView = true; }
      V.state.tx = p.tx + (ev.clientX - p.x);
      V.state.ty = p.ty + (ev.clientY - p.y);
      layout();
    });

    document.addEventListener("mouseup", () => {
      if (V.state.drag) dragGuideEnd();
      V.state.clickWasPan = !!(V.state.pan && V.state.pan.moved);
      V.state.pan = null;
      const h = el("tblVisHost");
      if (h) h.classList.remove("vis-panning");
    });

    window.addEventListener("resize", () => {
      if (App.route === "tables" && V.state.geometry) {
        if (V.state.fitted) fit();
        else centerOnly();
      }
    });
  }

  /* --------------------------- guide drag --------------------------- */

  function posForValue(gd, geometry, value) {
    if (gd.edge === "top") return value;
    if (gd.edge === "gap") return geometry.heading_bottom + value;
    if (gd.edge === "bottom") return geometry.canvas_h - value;
    if (gd.edge === "left") return (geometry.canvas_w - value) / 2;
    return (geometry.canvas_w + value) / 2; // right
  }

  function dragGuideStart(gid, ev) {
    const gd = (V.state.guides || []).find((x) => x.id === gid);
    if (!gd || !V.state.geometry) return;
    V.state.drag = { gd, startX: ev.clientX, startY: ev.clientY, m0: App.get("margin_x") };
    ev.preventDefault();
  }
  // a side guide pulled wider than the side margins allow (the text never goes past Margin X on either
  // side): Margin X comes in with it, so the guide reaches the page's edge — never moved out again here
  function sideMargin(gd, value, m0, cw) {
    if (gd.edge !== "left" && gd.edge !== "right") return {};
    const m = Math.max(0, Math.round(Number(m0) || 0));
    return value > cw - 2 * m ? { margin_x: Math.max(0, Math.floor((cw - value) / 2)) } : (m !== Math.round(Number(App.get("margin_x")) || 0) ? { margin_x: m } : {});
  }

  function dragGuideMove(ev) {
    const d = V.state.drag;
    const delta = (d.gd.orientation === "h" ? ev.clientY - d.startY : ev.clientX - d.startX) / V.state.scale;
    let value;
    if (d.gd.edge === "left") value = d.gd.value - 2 * delta;
    else if (d.gd.edge === "right") value = d.gd.value + 2 * delta;
    else if (d.gd.edge === "bottom") value = d.gd.value - delta;
    else value = d.gd.value + delta;
    value = Math.round(value);
    // as far as the canvas goes, whatever its size (a 4K portrait page is 3840 px tall): a guide's own max is for 1080p
    const geo = V.state.geometry, maxAllowed = geo ? (d.gd.orientation === "h" ? geo.canvas_h : geo.canvas_w - 40) : d.gd.max;
    value = Math.max(d.gd.min, Math.min(maxAllowed, value));
    d.value = value;
    d.extra = geo ? sideMargin(d.gd, value, d.m0, geo.canvas_w) : {};
    const pos = posForValue(d.gd, V.state.geometry, value);
    const line = document.querySelector(`.vis-guide[data-gid="${d.gd.id}"]`);
    if (line) {
      const px = pos * V.state.scale;
      if (d.gd.orientation === "h") line.style.top = px + "px";
      else line.style.left = px + "px";
    }
  }

  function dragGuideEnd() {
    const d = V.state.drag;
    if (d && typeof d.value === "number") {
      App.set(d.gd.key, d.value);
      Object.entries(d.extra || {}).forEach(([k, v]) => App.set(k, v));
      App.pushConfig();
      V.refreshPreview();
    }
    V.state.drag = null;
  }

  /* ------------------------------ preview ------------------------------ */

  V.refreshPreview = debounce(async function (force) {
    if (!el("tblVisHost")) return;
    if (!V.state.sheet) {
      setBadge("idle");
      return;
    }
    setBadge("busy");
    try {
      if (!(await draw(force))) setBadge("idle", "Preview failed");
    } catch (e) {
      setBadge("idle", "Preview failed");
      return;
    }
    setBadge("idle");
  }, 450);

  async function draw(force) {                       // the page through the live canvas pipeline
    const canvas = el("tblVisCanvas");
    if (!canvas || !window.AppLive || !window.AppLive.renderInto) return false;
    if (AppLive.hideTableBar) AppLive.hideTableBar();
    closeCellPop();
    const seq = (V.state.drawSeq = (V.state.drawSeq || 0) + 1);     // overlapping refreshes: the newest wins
    const geo = await window.AppLive.renderInto(canvas, V.state.sheet, !!force);
    if (seq !== V.state.drawSeq) return true;
    if (!geo) { if (V.state.geometry) showPage(V.state.page || 0); return false; }   // keep showing the page being edited
    if (V.state.pageSheet !== V.state.sheet) { V.state.pageSheet = V.state.sheet; V.state.page = firstTablePage(); V.state.selKey = null; }
    const same = V.state.geometry && V.state.geometry.canvas_w === geo.canvas_w && V.state.geometry.canvas_h === geo.canvas_h;
    V.state.geometry = geo;
    V.state.guides = guidesFor(geo);
    const hostEl = el("tblVisHost");
    if (hostEl) hostEl.style.setProperty("--typo-vis-ar", geo.canvas_w + " / " + geo.canvas_h);
    // the view the artist zoomed / panned to stays through every edit: only a new canvas size (or ⛶ Fit) fits again
    if (!same || (!V.state.fitted && !V.state.userView)) { V.state.fitted = false; fit(); } else layout();
    // follow the selected table / part to the page it is on now (a cut part may have gone to a
     // Continued page, or been sent to the page before / after)
    renderThumbs();
    setTimeout(renderThumbs, 1500);                  // again once the table pictures / icons have loaded
    const followed = V.state.selId ? pageOf(V.state.selId) : -1;
    showPage(followed >= 0 ? followed : Math.min(V.state.page || 0, Math.max(0, livePages().length - 1)));
    const sel = selectedTable();                     // keep editing the same table
    if (sel) {
      const cr = canvas.getBoundingClientRect(), k = cr.width / AppLive.state.data.canvas_w;
      const tr = sel.geo ? tableRect(sel) : { x: sel.x, y: sel.y, w: sel.w };
      AppLive.styleRowAt(canvas, el("tblVisHost"), (tr.x + tr.w / 2) * k, (tr.y + 4) * k, () => V.refreshPreview.now(true), { selectOnly: true });
      renderHandles();
      if (V.state.barOpen) openBar(sel);
      else if ((V.state.cells || []).length) showCellPop();
    } else closeCellPop()
    return true;
  }
  V.refreshPreview.now = async function (force) {      // undebounced: the bars wait for it
    setBadge("busy");
    await draw(force);
    setBadge("idle");
  };

  // an undo / redo (App.hist): the Tables page redraws; on the Canvas its handles follow the redrawn page
  window.addEventListener("psh:history", () => {
    if (T.typo) { window.addEventListener("psh:canvas-ready", () => { if (T.typo) renderHandles(); }, { once: true }); return; }
    if (!T.vis && App.route === "tables" && H()) refreshNow();
  });

  V.schedule = function () {
    if (App.route !== "tables") return;
    if (!el("tblVisHost")) return;
    V.refreshPreview();
  };

  /* ------------------------------ init ------------------------------ */

  function preferredSheet() {
    const saved = V.state.sheet;
    if (saved && V.state.sheets.indexOf(saved) !== -1) return saved;
    const withTable = V.state.sheets.find((n) => V.state.sheetTables[n]);
    if (withTable) return withTable;
    return V.state.sheets[0] || "";
  }

  function fillSheetSelect() {
    const sel = el("tblVisSheet");
    if (!sel) return;
    if (!V.state.sheets.length) {
      sel.innerHTML = `<option value="">No normal pages</option>`;
      sel.disabled = true;
      return;
    }
    const current = V.state.sheet || V.state.sheets[0];
    sel.innerHTML = V.state.sheets.map((n) => `<option value="${esc(n)}" ${n === current ? "selected" : ""}>${esc(n)}${V.state.sheetTables[n] ? " · table" : ""}</option>`).join("");
    sel.disabled = false;
    sel.onchange = () => {
      V.state.sheet = sel.value;
      V.refreshPreview(true);
    };
  }

  V.init = async function () {
    useTables();
    V.state.fitted = false;
    const host = el("tblVisHost");
    if (!host) return;
    bindCanvasEvents();
    if (App.histPaint) App.histPaint();
    el("tblVisPrev")?.addEventListener("click", () => goPage((V.state.page || 0) - 1));
    el("tblVisNext")?.addEventListener("click", () => goPage((V.state.page || 0) + 1));
    try {
      const meta = await api("/api/visualiser/sheets", { method: "POST", body: {} });
      V.state.sheets = (meta && meta.sheets) || [];
      V.state.sheetTables = (meta && meta.sheet_tables) || {};
      V.state.sheet = preferredSheet();
      fillSheetSelect();
      if (!meta || meta.excel_ok === false) {
        host.innerHTML = `<div class="empty" style="margin:14px"><div class="empty-icon">▤</div><div class="empty-title">No workbook configured</div><div class="empty-sub">${esc((meta && meta.excel_error) || "Set the Excel file in the Project view to preview pages.")}</div></div>`;
        return;
      }
      if (!V.state.sheet) {
        host.innerHTML = `<div class="empty" style="margin:14px"><div class="empty-icon">▤</div><div class="empty-title">No normal pages</div><div class="empty-sub">The preview shows normal pages with Excel tables (Paytable / Game / Bingo Rules pages use their own editors).</div></div>`;
        return;
      }
      if (V.state.sheet) V.refreshPreview(true);
    } catch (e) {
      host.innerHTML = `<div class="empty" style="margin:14px"><div class="empty-icon">⚠</div><div class="empty-title">Preview unavailable</div><div class="empty-sub">${esc(e && e.message ? e.message : String(e))}</div></div>`;
    }
  };

  /* ---------------- the same editor on the Visualiser's canvas ---------------- */
  V.pickInVisualiser = function (t, ev) {           // a table clicked in the Visualiser
    Object.assign(T, { host: "visLiveHost", canvas: "visLiveCanvas", vis: true, typo: false });
    const same = V.state.selId === t.id;
    V.state.selKey = t.design_key;
    V.state.selId = t.id;
    if (!same) { V.state.cells = []; V.state.barOpen = false; closeCellPop(); }
    renderHandles();
    const box = document.querySelector(".tblh");
    if (box && ev) startMove(ev, box, t, C().getBoundingClientRect().width / AppLive.state.data.canvas_w, true);
    T.rect = "";
  };
  V.cellInVisualiser = function (ev) {              // double-click a box of the selected table
    if (!T.vis || !selectedTable()) return false;
    return pickCell(ev, ev.shiftKey);
  };
  V.clearVisualiser = function () {
    if (!T.vis) return;
    V.state.selKey = null; V.state.selId = null; V.state.cells = [];
    closeCellPop();
    document.querySelectorAll(".tblh, .tblh-ghost").forEach((n) => n.remove());
  };
  V.onVisDraw = function () {                        // the Visualiser panned / zoomed / redrew
    if (!T.vis || !V.state.selId) return;
    const c = C();
    if (!c) return;
    const r = c.getBoundingClientRect(), key = [r.left, r.top, r.width, (AppLive.state.elements || []).length].map(Math.round).join(",");
    if (key === T.rect) return;
    T.rect = key;
    renderHandles();
  };
  V.visActive = () => T.vis && !!V.state.selId;

  /* ---------------- the same editor on the Typography page (table_studio.js picks) ---------------- */
  V.pickInTypo = function (t) {                      // a table (or one part of a cut table) clicked there
    Object.assign(T, { host: "typoVisHost", canvas: "typoVisCanvas", vis: true, typo: true });
    const same = V.state.selId === t.id, sameTable = V.state.selKey === t.design_key;
    V.state.selKey = t.design_key;
    V.state.selId = t.id;
    if (!same) { V.state.barOpen = false; closeCellPop(); }
    if (!sameTable) V.state.cells = [];                  // another part of the same table keeps its picked boxes
    T.rect = "";
    renderHandles();
  };
  V.cellInTypo = function (ev) {                     // double-click a box: edit just that box (Shift adds)
    if (!T.typo) return false;
    const c = C();
    if (!c || !AppLive.tableAt) return false;
    const r = c.getBoundingClientRect();
    const t = AppLive.tableAt(c, ev.clientX - r.left, ev.clientY - r.top);
    if (!t || !t.design_key) return false;
    if (t.id !== V.state.selId) V.pickInTypo(t);
    return pickCell(ev, ev.shiftKey);
  };
  // the box of the selected table under the pointer: its key "row,column" (whole-table row), or null
  // the box under the pointer in ANY table on the page (the eyedropper): {table, key} or null
  V.boxAt = function (ev) {
    const c = C();
    if (!c || !AppLive.tableAt) return null;
    const r = c.getBoundingClientRect();
    const t = AppLive.tableAt(c, ev.clientX - r.left, ev.clientY - r.top);
    if (!t || !t.geo) return null;
    const [px, py] = pointOnCanvas(ev), key = cellAt(t, px, py);
    return key ? { table: t, key } : null;
  };
  // an icon drawn in a table under the pointer: {table, cell, tok, name, rect} (canvas px) or null
  V.iconAt = function (ev) {
    const c = C();
    if (!c || !AppLive.tableAt) return null;
    const r = c.getBoundingClientRect();
    const t = AppLive.tableAt(c, ev.clientX - r.left, ev.clientY - r.top);
    if (!t || !t.geo || !(t.geo.icons || []).length) return null;
    const [px, py] = pointOnCanvas(ev), tr = tableRect(t), g = t.geo;
    const hit = g.icons.find((i) => {
      const x = tr.x + i.rect[0] - (g.x || 0), y = tr.y + i.rect[1] - (g.y || 0);
      return px >= x - 2 && px <= x + i.rect[2] + 2 && py >= y - 2 && py <= y + i.rect[3] + 2;
    });
    return hit ? Object.assign({ table: t }, hit) : null;
  };
  // pick these boxes of the selected table ("Select same…")
  V.pickKeys = function (keys) { if (T.typo && V.state.selId) setCells(keys, "set"); };
  V.cellKeyAt = function (ev) {
    const e = selectedTable();
    if (!T.typo || !e || !e.geo) return null;
    const [px, py] = pointOnCanvas(ev);
    return cellAt(e, px, py);
  };
  V.clearTypo = function () {
    if (!T.typo) return;
    V.state.selKey = null; V.state.selId = null; V.state.cells = [];
    closeCellPop();
    if (AppLive.hideTableBar) AppLive.hideTableBar();
    document.querySelectorAll(".tblh, .tblh-ghost").forEach((n) => n.remove());
  };
  V.clearCells = function () {                       // Esc: the picked boxes first
    if (!(V.state.cells || []).length) return false;
    V.state.cells = []; closeCellPop(); renderHandles();
    if (T.typo && window.TableStudio && TableStudio.showCells) TableStudio.showCells();   // the Table bar again
    return true;
  };
  V.onTypoDraw = function () {                       // the Typography page panned / zoomed / redrew
    if (!T.typo || !V.state.selId) return;
    if (!(AppLive.state.elements || []).some((e) => e.id === V.state.selId)) { V.clearTypo(); return; }   // not on this page
    renderHandles();
  };
  V.typoActive = () => T.typo && !!V.state.selId;

  window.AppTblVis = V;
})();