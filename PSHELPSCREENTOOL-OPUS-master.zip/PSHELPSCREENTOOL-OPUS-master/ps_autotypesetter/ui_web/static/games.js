/* Games library UI: Game -> Market -> Version (server: games.py, /api/games*).
   The dashboard lists games; each game shows its markets with their state
   (up to date / Excel changed / never built) and one-click Open, Build, Update.
   Uses app.js globals: App, api, esc, jsStr, toast, navigate, renderRoute. */
(function () {
  "use strict";

  const G = { games: null, loading: false, add: null, changes: {} };

  const STATE = {
    up_to_date: { label: "Up to date", cls: "ok" },
    changed: { label: "Excel changed", cls: "warn" },
    never_built: { label: "Not built yet", cls: "idle" },
    excel_missing: { label: "Excel missing", cls: "err" },
  };

  App.gamesSection = () => `
    <div class="gm-section gm-recent">
      <div class="gm-head">
        <div>
          <div class="gm-title">Recent games</div>
          <div class="gm-sub">Each game keeps one shared look for all its markets. Excel changes are detected for you.</div>
        </div>
        <button class="btn primary" onclick="App.gameAddOpen()">+ Add a game</button>
      </div>
      <div class="gm-grid" id="gmGrid">${G.games ? gamesHTML() : `<div class="gm-empty">Loading your games…</div>`}</div>
    </div>`;

  function marketRow(game, m) {
    const st = STATE[m.state] || STATE.never_built;
    const active = App.state.config.active_game === game.id && App.state.config.active_market === m.id;
    const ver = m.version ? `v${m.version}` : "";
    const act = m.state === "changed"
      ? `<button class="btn primary small" onclick="App.gameUpdate('${jsStr(game.id)}','${jsStr(m.id)}')" title="Rebuild from the changed Excel — compared with version ${m.version}">Update PSD</button>`
      : m.state === "never_built"
        ? `<button class="btn secondary small" onclick="App.gameBuild('${jsStr(game.id)}','${jsStr(m.id)}')">Build PSD</button>`
        : "";
    const ck = game.id + "|" + m.id;
    const ch = G.changes[ck];
    const detail = m.state !== "changed" ? "" : !ch ? `<div class="gm-changes">Checking which pages changed…</div>`
      : !ch.known ? `<div class="gm-changes">The Excel file changed since v${m.version}.</div>`
        : `<div class="gm-changes">${changesText(ch)}</div>`;
    return `<div class="gm-market ${active ? "active" : ""}">
      <div class="gm-mname" title="${esc(m.excel_path)}">${esc(m.name)}${active ? ` <span class="gm-here">open</span>` : ""}</div>
      <span class="gm-state ${st.cls}">${st.label}${ver ? " · " + ver : ""}</span>
      <div class="gm-mact">
        ${act}
        <button class="btn secondary small" onclick="App.gameOpen('${jsStr(game.id)}','${jsStr(m.id)}')">Open</button>
      </div>
      ${detail}
    </div>`;
  }

  function changesText(ch) {
    const parts = [];
    const list = (a) => a.slice(0, 4).map(esc).join(", ") + (a.length > 4 ? ` +${a.length - 4} more` : "");
    if (ch.changed.length) parts.push(`${ch.changed.length} page${ch.changed.length === 1 ? "" : "s"} changed: ${list(ch.changed)}`);
    if (ch.added.length) parts.push(`new: ${list(ch.added)}`);
    if (ch.removed.length) parts.push(`removed: ${list(ch.removed)}`);
    return parts.join(" · ") || "Only formatting changed — no page content differs.";
  }

  /* which pages changed (computed on the server from the PSD's saved baseline) */
  async function loadChanges() {
    const todo = [];
    (G.games || []).forEach((g) => (g.markets || []).forEach((m) => {
      if (m.state === "changed" && !G.changes[g.id + "|" + m.id]) todo.push([g, m]);
    }));
    for (const [g, m] of todo) {
      try {
        const d = await api(`/api/games/${encodeURIComponent(g.id)}/markets/${encodeURIComponent(m.id)}/changes`);
        G.changes[g.id + "|" + m.id] = d && d.ok ? d : { known: false };
      } catch (e) { G.changes[g.id + "|" + m.id] = { known: false }; }
      const grid = document.getElementById("gmGrid");
      if (grid) grid.innerHTML = gamesHTML();
    }
  }

  function gamesHTML() {
    if (!G.games.length) {
      return `<div class="gm-empty">
        <b>No games yet.</b> Add a game folder: every Excel inside becomes a market, and the icons, background and heading art are found for you.
      </div>`;
    }
    // most recently built first
    return G.games.slice().sort((a, b) => String(b.last_built || "").localeCompare(String(a.last_built || ""))).map((g) => {
      if (g.missing) {
        return `<div class="gm-card missing"><div class="gm-name">${esc(g.name)}</div>
          <div class="gm-folder">Folder not found: ${esc(g.file)}</div></div>`;
      }
      const changed = g.changed ? `<span class="gm-badge warn">${g.changed} changed</span>` : "";
      const open = (g.markets || []).find((m) => App.state.config.active_game === g.id && App.state.config.active_market === m.id) || (g.markets || [])[0];
      const thumb = open ? `<div class="gm-thumb" title="Open ${esc(g.name)}${open ? " · " + esc(open.name) : ""}" onclick="App.gameOpen('${jsStr(g.id)}','${jsStr(open.id)}')">
          <img src="/api/games/${encodeURIComponent(g.id)}/thumb?v=${encodeURIComponent((g.last_built || "") + (g.changed || ""))}" alt="" loading="lazy"
            onload="this.parentNode.classList.add('ready')" onerror="this.parentNode.classList.add('none')">
          <span class="gm-thumb-wait">Drawing the paytable…</span></div>` : "";
      return `<div class="gm-card">
        ${thumb}
        <div class="gm-card-head">
          <div><div class="gm-name">${esc(g.name)} ${changed}</div>
            <div class="gm-folder" title="${esc(g.folder)}">${esc(g.folder)}</div></div>
          <button class="gm-x" title="Remove from this list (files are kept)" onclick="App.gameRemove('${jsStr(g.id)}','${jsStr(g.name)}')">✕</button>
        </div>
        <div class="gm-markets">${(g.markets || []).map((m) => marketRow(g, m)).join("") || `<div class="gm-empty small">No markets — add an Excel.</div>`}</div>
        <div class="gm-card-foot">
          <button class="btn ghost small" onclick="App.gameAddMarket('${jsStr(g.id)}')">+ Add market (Excel)</button>
          <button class="btn ghost small" onclick="App.gameMimicOpen('${jsStr(g.id)}')" title="Take the look of a PSD — only what you tick: canvas size, background, margins, heading / paragraph / subheading fonts and layer styles">🎨 Mimic a PSD design</button>
          <span class="gm-last">${g.last_built ? "Last build " + esc(g.last_built.replace("T", " ")) : ""}</span>
        </div>
      </div>`;
    }).join("");
  }

  function paint() {
    const grid = document.getElementById("gmGrid");
    if (grid) grid.innerHTML = gamesHTML();
    App.updateCtxBadge();
  }

  App.loadGames = async () => {
    if (G.loading) { G.again = true; return; }       // a refresh asked mid-load runs once more afterwards
    G.loading = true;
    try {
      const d = await api("/api/games");
      G.games = (d && d.games) || [];
    } catch (e) {
      G.games = G.games || [];
    }
    G.loading = false;
    G.changes = {};
    paint();
    loadChanges();
    if (G.again) { G.again = false; App.loadGames(); }
  };

  /* ---------------- top bar: which game / market is open ---------------- */
  App.updateCtxBadge = () => {
    const el = document.getElementById("ctxBadge");
    if (!el) return;
    const c = App.state.config || {};
    const game = (G.games || []).find((g) => g.id === c.active_game);
    if (!c.active_game || !game) { el.hidden = true; return; }
    const m = (game.markets || []).find((x) => x.id === c.active_market);
    el.hidden = false;
    el.innerHTML = `<span class="ctx-game">${esc(game.name)}</span><span class="ctx-sep">›</span>
      <span class="ctx-market">${esc(m ? m.name : "")}</span>${m && m.version ? `<span class="ctx-ver">v${m.version}</span>` : ""}`;
    el.title = "Settings you change now are shared by every market of " + game.name + ". Click to switch.";
    el.onclick = () => navigate("dashboard");
  };

  /* ---------------- open / build / update a market ---------------- */
  async function openMarket(gameId, marketId, update) {
    const d = await api(`/api/games/${encodeURIComponent(gameId)}/open`, { method: "POST", body: { market_id: marketId, update: !!update } });
    if (!d || !d.ok) { toast((d && d.error) || "Could not open the market.", "err"); return false; }
    App.state.config = d.config;
    await App.loadGames();
    if (App.scan) await App.scan();
    return true;
  }

  App.gameOpen = async (gameId, marketId) => {
    if (await openMarket(gameId, marketId, false)) {
      toast("Opened. Changes to the look apply to every market of this game.");
      navigate("project");
    }
  };

  App.gameBuild = async (gameId, marketId) => {
    if (await openMarket(gameId, marketId, false)) {
      navigate("render");
      setTimeout(() => App.startBuild("psd"), 300);
    }
  };

  App.gameUpdate = async (gameId, marketId) => {
    if (await openMarket(gameId, marketId, true)) {
      App._updateRequested = true;           // build_engine's "Update PSD" path (diff vs the PSD's saved baseline)
      navigate("render");
      setTimeout(() => App.startBuild("psd"), 300);
    }
  };

  App.gameRemove = async (gameId, name) => {
    if (!confirm(`Remove "${name}" from your games list?\n\nNothing is deleted — the folder and PSDs stay as they are.`)) return;
    await api(`/api/games/${encodeURIComponent(gameId)}`, { method: "DELETE" });
    await App.loadGames();
  };

  App.gameAddMarket = (gameId) => {
    App.pickPath("excel", async (path) => {
      path = path || prompt("Full path of the market's Excel file:") || "";
      if (!path) return;
      const d = await api(`/api/games/${encodeURIComponent(gameId)}/markets`, { method: "POST", body: { excel_path: path } });
      if (!d || !d.ok) { toast((d && d.error) || "Could not add the market.", "err"); return; }
      toast(`Market "${d.market.name}" added.`);
      App.loadGames();
    });
  };

  /* ---------------- open a PSD: its own stored project comes back ---------------- */
  App.openPsdProject = () => {
    App.pickPath("psd", async (path) => {
      path = (path || "").trim();
      if (!path) return;
      let info;
      try {
        info = await api("/api/psd/memory", { method: "POST", body: { path } });
      } catch (e) { toast(e.message, "err"); return; }
      if (!info || !info.has_memory) {
        toast("This PSD has no saved project — it wasn't built by this tool, or was built before projects were stored inside PSDs.", "err");
        return;
      }
      const id = info.identity || {};
      const where = id.game_name ? `${id.game_name} › ${id.market_name} (v${id.version})` : "";
      const lines = [
        where && `Game: ${where}`,
        `Excel: ${info.excel.name || "?"}${info.excel.embedded ? " (copy saved in the PSD)" : ""}`,
        `${info.excel.sheets.length} sheets · ${info.layers} text layers linked to Excel`,
        info.files.length ? `Templates: ${info.files.join(", ")}` : "",
        `Saved ${String(info.saved_at || "").replace("T", " ")}`,
      ].filter(Boolean);
      const NL = String.fromCharCode(10);
      if (!confirm("Restore this PSD's project?" + NL + NL + lines.join(NL) + NL + NL + "Your current settings will be replaced.")) return;
      const d = await api("/api/psd/restore", { method: "POST", body: { path } });
      if (!d || !d.ok) { toast((d && d.error) || "Could not restore the project.", "err"); return; }
      App.state.config = d.config;
      if (App.loadGames) await App.loadGames();
      if (App.scan) await App.scan();
      (d.notes || []).forEach((n) => toast(n, /^Added to Recent games/.test(n) ? "ok" : "warn"));
      toast("Project restored from the PSD.");
      navigate("project");
    });
  };

  /* ---------------- add a game (folder -> detected markets & assets) ---------------- */
  App.gameAddOpen = () => {
    G.add = { folder: "", found: null, busy: false, error: "", mode: "current" };
    let ov = document.getElementById("gmAddOverlay");
    if (!ov) {
      ov = document.createElement("div");
      ov.id = "gmAddOverlay";
      ov.className = "gm-overlay";
      // a click outside never closes it (what was typed in it would be lost): its ✕ or Cancel do
      document.body.appendChild(ov);
    }
    ov.hidden = false;
    renderAdd();
  };

  // a new workspace for an Excel from another game: the Add-a-game dialog, already on its folder
  App.gameAddFrom = (folder) => {
    App.gameAddOpen();
    G.add.folder = folder;
    const inp = document.getElementById("gmAddFolder");
    if (inp) inp.value = folder;
    App.gameAddScan();
  };

  App.gameAddClose = () => {
    const ov = document.getElementById("gmAddOverlay");
    if (ov) ov.hidden = true;
  };

  App.gameAddBrowse = () => {
    App.pickPath("dir", (p) => {
      if (!p) return;
      G.add.folder = p;
      const inp = document.getElementById("gmAddFolder");
      if (inp) inp.value = p;
      App.gameAddScan();
    });
  };

  App.gameAddScan = async () => {
    const inp = document.getElementById("gmAddFolder");
    if (inp) G.add.folder = inp.value.trim().replace(/^"|"$/g, "");
    if (!G.add.folder) return;
    G.add.busy = true;
    G.add.error = "";
    renderAdd();
    try {
      const d = await api("/api/games/discover", { method: "POST", body: { folder: G.add.folder } });
      G.add.found = d && d.ok ? d : null;
      if (!G.add.found) G.add.error = "That folder wasn't found. Use Browse… or paste the full path, e.g. E:\Games\Lucky Dragon";
      else {
        G.add.found.markets.forEach((m) => { m.use = true; });
        G.add.found.others = (G.add.found.other_excels || []).map((p) => ({ excel_path: p, use: false, name: "" }));
        if (!G.add.found.markets.length) G.add.error = "No Excel files in this folder (or its sub-folders). Each market needs its own Excel file.";
      }
    } catch (e) {
      G.add.found = null;
      const msg = (e && e.message) || "";
      G.add.error = /not found/i.test(msg) || !msg
        ? "That folder wasn't found. Use Browse… or paste the full path, e.g. E:\Games\Lucky Dragon"
        : msg;
    }
    G.add.busy = false;
    renderAdd();
  };

  App.gameAddCreate = async () => {
    const f = G.add.found;
    if (!f) return;
    const name = (document.getElementById("gmAddName") || {}).value || f.name;
    const markets = f.markets.filter((m) => m.use).map((m) => ({ excel_path: m.excel_path, name: m.name }));
    (f.others || []).filter((o) => o.use && o.name.trim()).forEach((o) => markets.push({ excel_path: o.excel_path, name: o.name.trim() }));
    if (!markets.length) { G.add.error = "Pick at least one market Excel."; renderAdd(); return; }
    G.add.busy = true;
    renderAdd();
    let d;
    try {
      const body = { folder: f.folder, name: name.trim(), markets, settings_mode: G.add.mode };
      if (G.add.mode === "psd") {
        const r = (G.add.psd || {}).result;
        if (!r) { G.add.busy = false; G.add.error = "Read the styles from a PSD first (or pick another settings option)."; renderAdd(); return; }
        body.psd_settings = { source: r.path, fields: r.fields, styles: r.styles };
      }
      d = await api("/api/games/create", { method: "POST", body });
    } catch (e) { d = { ok: false, error: e.message }; }
    G.add.busy = false;
    if (!d || !d.ok) { G.add.error = (d && d.error) || "Could not create the game."; renderAdd(); return; }
    App.gameAddClose();
    const dropped = (d.game.not_copied || []).length;
    toast(`"${d.game.name}" added with ${d.game.market_count} market(s).` +
      (G.add.mode === "psd" ? ` Settings taken from ${fileName(G.add.psd.result.path)}.` : "") +
      (G.add.mode === "current" && dropped ? ` ${dropped} path/game-specific setting(s) from the previous game were not copied.` : ""));
    await App.loadGames();
    const sp = G.add.mode === "psd" && G.add.psd && G.add.psd.sym ? G.add.psd : null;
    // symbols from the settings PSD: their review opens once the market's Excel is read (symbols_prompt.js)
    App._symbolsFromPsd = sp ? { psd: sp.path, agr: sp.agr || "" } : null;
    // open the first market: its Excel is scanned and missing symbols are asked for right away
    const first = (d.game.markets || [])[0];
    if (first) App.gameOpen(d.game.id, first.id);
  };

  App.gameAddMode = (m) => {
    G.add.mode = m;
    if (m === "psd") G.add.psd = G.add.psd || { path: "", busy: false, result: null, error: "" };
    renderAdd();
  };
  App.gameAddNameIn = (v) => { if (G.add.found) G.add.found.name = v; };

  /* "Use settings from a given PSD": read it (read only), review, edit. */
  const PS = () => (G.mimic ? G.mimic.psd : G.add.psd);
  const rerender = () => (G.mimic ? renderMimic() : renderAdd());
  App.gameAddPsdBrowse = () => {
    App.pickPath("psd", (p) => {
      if (!p) return;
      PS().path = p;
      App.gameAddPsdRead();
    });
  };
  App.gameAddPsdPath = (v) => { PS().path = v.trim().replace(/^"|"$/g, ""); };
  App.gameAddPsdRead = async () => {
    const P = PS();
    if (!P.path) { P.error = "Choose a PSD first."; rerender(); return; }
    P.busy = true; P.error = ""; P.result = null;
    rerender();
    try {
      P.result = await api("/api/games/psd_settings", { method: "POST", body: { psd_path: P.path } });
      // Mimic: nothing changes until it is ticked (pick just the heading font, or just the canvas size)
      if (G.mimic && P.result) {
        (P.result.fields || []).forEach((f) => { f.apply = false; });
        Object.values(P.result.styles || {}).forEach((st) => { st.apply = false; });
      }
    } catch (e) {
      P.error = e.message || "Could not read the PSD.";
    }
    P.busy = false;
    rerender();
  };
  App.gameAddPsdField = (i, prop, v) => { PS().result.fields[i][prop] = v; };
  App.gameAddPsdStyle = (role, on) => { PS().result.styles[role].apply = on; };
  // tick / untick a whole group (Canvas size, Background, Margins, Heading, Paragraph, Subheading)
  App.gameAddPsdGroup = (grp, on) => {
    const r = PS().result;
    (r.fields || []).forEach((f) => { if (psdGroup(f.key) === grp) f.apply = on; });
    Object.entries(r.styles || {}).forEach(([role, st]) => { if (styleGroup(role) === grp) st.apply = on; });
    rerender();
  };

  const PSD_GROUPS = [["canvas", "Canvas size"], ["bg", "Background"], ["margins", "Margins"], ["heading", "Heading"],
    ["body", "Paragraph"], ["sub", "Subheading"]];
  function psdGroup(key) {
    if (key === "c_width" || key === "c_height") return "canvas";
    if (/^bg_/.test(key)) return "bg";
    if (["margin_x", "heading_top_margin", "inner_canvas_width", "bottom_margin"].includes(key)) return "margins";
    if (/^h_/.test(key) || /^ds\.heading_/.test(key)) return "heading";
    if (/^ds\.subheading/.test(key)) return "sub";
    return "body";
  }
  const styleGroup = (role) => (/^heading/i.test(role) ? "heading" : /^subheading/i.test(role) ? "sub" : "body");

  function psdFieldInput(fl, i) {
    const on = `onchange="App.gameAddPsdField(${i}, 'value', this.type === 'checkbox' ? this.checked : this.value)"`;
    if (fl.key === "bg_rect") return `<input class="form-control" value="${esc((fl.value || []).join(", "))}" title="x, y, width, height (px on the canvas)"
      onchange="App.gameAddPsdField(${i}, 'value', this.value.split(',').map((v) => Math.round(Number(v) || 0)))">`;
    if (fl.key === "ds.fx_global_light") return `<input class="form-control" value="${esc((fl.value || []).join(", "))}" title="Angle, altitude (degrees): Use Global Light shadows and bevels are drawn at it"
      onchange="App.gameAddPsdField(${i}, 'value', this.value.split(',').map((v) => Number(v) || 0))">`;
    if (fl.key === "ds.heading_blend_if") return `<input class="form-control" value="${esc((fl.value || []).join(", "))}" title="Blend If, Underlying Layer: black low, black high, white low, white high (0–255). The heading is hidden where the background is darker / brighter than this"
      onchange="App.gameAddPsdField(${i}, 'value', this.value.split(',').map((v) => Math.round(Number(v) || 0)))">`;
    if (fl.key === "ds.heading_kerning") return `<select class="form-control" ${on}>${[["metrics", "Metrics (the font's pairs)"], ["none", "None (0)"]].map(([v, l]) => `<option value="${v}" ${v === fl.value ? "selected" : ""}>${l}</option>`).join("")}</select>`;
    if (fl.key === "bg_mode") return `<select class="form-control" ${on}>${[["place", "Placed where the PSD has it"], ["cover", "Fill the canvas"], ["fit_width", "Fit the width"], ["fit", "Fit inside"], ["stretch", "Stretch"]].map(([v, l]) => `<option value="${v}" ${v === fl.value ? "selected" : ""}>${l}</option>`).join("")}</select>`;
    if (fl.key === "bg_from_psd") return `<input type="checkbox" ${fl.value ? "checked" : ""} ${on}> <span class="gm-src">saved into the game folder</span>`;
    if (/_rgb$/.test(fl.key)) return `<input type="color" value="${esc(fl.value)}" ${on}>`;
    if (/_bold$/.test(fl.key)) return `<input type="checkbox" ${fl.value ? "checked" : ""} ${on}>`;
    if (fl.key === "alignment") return `<select class="form-control" ${on}>${["left", "center", "right"].map((a) => `<option ${a === fl.value ? "selected" : ""}>${a}</option>`).join("")}</select>`;
    const num = typeof fl.value === "number";
    return `<input class="form-control" ${num ? `type="number" step="${fl.key === "line_spacing" ? "0.05" : "1"}"` : ""} value="${esc(fl.value)}" ${on}>`;
  }

  function psdPanel() {
    const P = PS() || {};
    const r = P.result;
    return `<div class="gm-psd">
      <div class="gm-row">
        <input class="form-control" placeholder="Reference PSD, e.g. E:\Games\Old Game\Help.psd" value="${esc(P.path || "")}"
          oninput="App.gameAddPsdPath(this.value)" onkeydown="if(event.key==='Enter')App.gameAddPsdRead()">
        <button class="btn secondary" onclick="App.gameAddPsdBrowse()">Browse…</button>
        <button class="btn primary" onclick="App.gameAddPsdRead()" ${P.busy ? "disabled" : ""}>${P.busy ? "Reading…" : "Read styles"}</button>
      </div>
      <div class="hint">The PSD is only read, never changed. Only its look is taken (and its background picture, if you tick it) — never its symbols, Excel or other paths.</div>
      ${P.error ? `<div class="gm-error">${esc(P.error)}</div>` : ""}
      ${r ? `
        <table class="gm-psd-table"><thead><tr><th></th><th>Setting</th><th>Value</th><th>From</th></tr></thead><tbody>
          ${PSD_GROUPS.map(([grp, title]) => {
            const rows = r.fields.map((fl, i) => [fl, i]).filter(([fl]) => psdGroup(fl.key) === grp);
            const sty = Object.entries(r.styles || {}).filter(([role]) => styleGroup(role) === grp);
            if (!rows.length && !sty.length) return "";
            const all = rows.every(([fl]) => fl.apply) && sty.every(([, st]) => st.apply);
            return `<tr class="gm-psd-group"><td><input type="checkbox" title="Use all of ${esc(title)}" ${all ? "checked" : ""} onchange="App.gameAddPsdGroup('${grp}', this.checked)"></td><td colspan="3"><b>${esc(title)}</b></td></tr>`
              + rows.map(([fl, i]) => `<tr class="${fl.confidence}">
            <td><input type="checkbox" title="Use this value" ${fl.apply ? "checked" : ""} onchange="App.gameAddPsdField(${i}, 'apply', this.checked)"></td>
            <td>${esc(fl.label)}${fl.confidence !== "high" ? ` <span class="gm-conf ${fl.confidence}" title="${fl.confidence === "low" ? "Unsure guess — not used unless you tick it" : "Likely, please check"}">${fl.confidence === "low" ? "unsure" : "check"}</span>` : ""}</td>
            <td>${psdFieldInput(fl, i)}</td>
            <td class="gm-src" title="${esc(fl.source)}">${esc(fl.source)}</td></tr>`).join("")
              + sty.map(([role, st]) => `<tr>
            <td><input type="checkbox" ${st.apply ? "checked" : ""} onchange="App.gameAddPsdStyle('${esc(role)}', this.checked)"></td>
            <td>Layer style: ${esc(role)}</td><td colspan="2" class="gm-src">${esc(st.name)} (stroke, shadow, glow… as in the PSD)</td></tr>`).join("");
          }).join("")}
        </tbody></table>
        <details class="gm-psd-why" open><summary>What was found (${r.text_layers} text layers read)</summary>
          <ul>${r.detected.map((t) => `<li class="ok">${esc(t)}</li>`).join("")}</ul>
          <b>Not detected / not taken</b>
          <ul>${r.not_detected.map((t) => `<li class="no">${esc(t)}</li>`).join("")}</ul>
          <div class="hint">Anything not ticked keeps the default value; you can change everything later in Canvas.</div>
        </details>` : ""}
      ${!G.mimic && P.path ? psdSymbolsHtml(P) : ""}
    </div>`;
  }
  /* Add a game › PSD settings › Symbols: the symbols taken from the same PSD too, named from the AGR it was
     made from (symbol_match.py) — reviewed once the game is made, before anything is saved */
  function psdSymbolsHtml(P) {
    const markets = ((G.add.found || {}).markets || []).filter((m) => m.use);
    return `<div class="gm-psd-sym">
      <label class="gm-check"><input type="checkbox" ${P.sym ? "checked" : ""} onchange="App.gameAddPsdSym(this.checked)">
        <b>Symbols: take them from this PSD too</b></label>
      <div class="hint">If you want the symbols from the same PSD, you can give the Excel (AGR) this PSD was made from — the tool
        reads the PSD's text, finds each sentence of the AGR in it and names every picture after the symbol it stands for
        (one PNG per symbol, in the game's Symbols folder). You check them before anything is saved. Without the AGR only
        the layer names can tell. Optional.</div>
      ${P.sym ? `<div class="gm-row">
        <input class="form-control" placeholder="AGR this PSD was made from (optional)" value="${esc(P.agr || "")}"
          oninput="App.gameAddPsdAgr(this.value)">
        <button class="btn secondary" onclick="App.gameAddPsdAgrBrowse()">Browse…</button>
        ${markets.length ? `<select class="form-control gm-narrow" title="One of this game's market Excels" onchange="if(this.value){App.gameAddPsdAgr(this.value);App.gameAddPsdRerender()}">
          <option value="">A market's Excel…</option>${markets.map((m) => `<option value="${esc(m.excel_path)}">${esc(m.name)} — ${esc(fileName(m.excel_path))}</option>`).join("")}</select>` : ""}
      </div>` : ""}
    </div>`;
  }
  App.gameAddPsdSym = (on) => { PS().sym = !!on; rerender(); };
  App.gameAddPsdAgr = (v) => { PS().agr = String(v || "").trim().replace(/^"|"$/g, ""); };
  App.gameAddPsdRerender = () => rerender();
  App.gameAddPsdAgrBrowse = () => App.pickPath("excel", (p) => { if (p) { PS().agr = p; rerender(); } });
  App.gameAddPickExcel = (i, path) => { G.add.found.markets[i].excel_path = path; };
  App.gameAddOther = (i, on) => { G.add.found.others[i].use = on; };
  App.gameAddOtherName = (i, v) => { G.add.found.others[i].name = v; };

  App.gameAddToggle = (i, on) => { G.add.found.markets[i].use = on; };
  App.gameAddRename = (i, v) => { G.add.found.markets[i].name = v; };

  function fileName(p) {
    const parts = String(p || "").split(/[\\/]/);
    return parts[parts.length - 1];
  }

  function assetLine(label, path) {
    return `<div class="gm-asset ${path ? "ok" : "no"}"><span>${path ? "✓" : "–"}</span><b>${label}</b>
      <span class="gm-path" title="${esc(path || "")}">${path ? esc(path) : "not found — you can set it later"}</span></div>`;
  }

  /* "Mimic a PSD design" on a game: read a PSD, tick what to take, apply it to this game. Nothing is
     ticked at first — take only the heading font and its layer style, or only the canvas size. */
  App.gameMimicOpen = (id) => {
    const g = (G.games || []).find((x) => x.id === id);
    G.mimic = { id, name: (g && g.name) || "", psd: { path: "", busy: false, result: null, error: "" }, busy: false, error: "" };
    let ov = document.getElementById("gmMimicOverlay");
    if (!ov) {
      ov = document.createElement("div");
      ov.id = "gmMimicOverlay";
      ov.className = "gm-overlay";
      document.body.appendChild(ov);
    }
    ov.hidden = false;
    renderMimic();
  };
  App.gameMimicClose = () => {
    const ov = document.getElementById("gmMimicOverlay");
    if (ov) ov.hidden = true;
    G.mimic = null;
  };
  App.gameMimicApply = async () => {
    const M = G.mimic, r = M && M.psd.result;
    if (!r) return;
    const n = r.fields.filter((f) => f.apply).length + Object.values(r.styles || {}).filter((s) => s.apply).length;
    if (!n) { M.error = "Tick what to take from the PSD first."; renderMimic(); return; }
    M.busy = true; M.error = ""; renderMimic();
    try {
      const d = await api(`/api/games/${encodeURIComponent(M.id)}/psd_style`, { method: "POST",
        body: { psd_settings: { source: r.path, fields: r.fields, styles: r.styles } } });
      if (d.active && d.config) {                 // the game being worked on: its settings are the page's
        App.state.config = d.config;
        if (App.histReset) App.histReset();
        renderRoute();
      }
      App.gameMimicClose();
      toast(`${n} setting${n === 1 ? "" : "s"} from the PSD applied to ${M.name}.`);
      G.games = null;
      loadGamesAgain();
    } catch (e) {
      M.busy = false;
      M.error = e.message || "Could not apply the PSD design.";
      renderMimic();
    }
  };
  function loadGamesAgain() {
    if (App.loadGames) App.loadGames();
    else api("/api/games").then((d) => { G.games = (d && d.games) || []; paint(); }).catch(() => {});
  }
  function renderMimic() {
    const ov = document.getElementById("gmMimicOverlay");
    if (!ov || !G.mimic) return;
    const M = G.mimic, r = M.psd.result;
    ov.innerHTML = `<div class="gm-dialog">
      <div class="gm-dhead"><b>Mimic a PSD design — ${esc(M.name)}</b><button class="gm-x" onclick="App.gameMimicClose()">✕</button></div>
      <div class="gm-dbody">
        <div class="gm-help">Pick a PSD whose look you want. Tick only what to take — the heading font and its layer style, just the
          canvas size, the background and where it sits… Everything else in this game stays as it is.</div>
        ${psdPanel()}
        ${M.error ? `<div class="gm-error">${esc(M.error)}</div>` : ""}
      </div>
      <div class="gm-dfoot">
        <button class="btn secondary" onclick="App.gameMimicClose()">Cancel</button>
        <button class="btn primary" onclick="App.gameMimicApply()" ${!r || M.busy ? "disabled" : ""}>${M.busy ? "Applying…" : "Apply to this game"}</button>
      </div>
    </div>`;
  }

  function renderAdd() {
    const ov = document.getElementById("gmAddOverlay");
    if (!ov) return;
    const a = G.add, f = a.found;
    ov.innerHTML = `<div class="gm-dialog">
      <div class="gm-dhead"><b>Add a game</b><button class="gm-x" onclick="App.gameAddClose()">✕</button></div>
      <div class="gm-dbody">
        <label class="gm-lab">Game folder</label>
        <div class="gm-row">
          <input id="gmAddFolder" class="form-control" placeholder="E:\\Games\\MyGame" value="${esc(a.folder)}"
            onkeydown="if(event.key==='Enter')App.gameAddScan()">
          <button class="btn secondary" onclick="App.gameAddBrowse()">Browse…</button>
          <button class="btn primary" onclick="App.gameAddScan()" ${a.busy ? "disabled" : ""}>${a.busy && !f ? "Scanning…" : "Scan"}</button>
        </div>
        ${a.error ? `<div class="gm-error">${esc(a.error)}</div>` : ""}
        ${!f ? `<div class="gm-help">
          <b>Pick the game's main folder</b> — not a PSD. The tool looks inside it (and its sub-folders) for:
          <ul>
            <li><b>Excel files</b> — one per market (e.g. <i>Game_NYL.xlsx</i>, <i>Game_PA.xlsx</i>). Each becomes a market.</li>
            <li><b>Symbol / icon PNGs</b> — a folder of PNGs (named <i>icons</i>, <i>symbols</i> or <i>assets</i> is found first).</li>
            <li><b>Background</b> — <i>bg.png</i>, <i>background.jpg</i> or a <i>bg</i> folder.</li>
            <li><b>Heading art</b> (optional) — a folder named <i>heading</i>, <i>title</i> or <i>logo</i>.</li>
          </ul>
          PSDs are created by the tool into an <i>output</i> folder there. Anything not found can be set later.
        </div>` : ""}
        ${f ? `
          ${f.existing ? `<div class="gm-note">This folder already has a game file — it will be re-opened, not replaced.</div>` : ""}
          <label class="gm-lab">Game name</label>
          <input id="gmAddName" class="form-control" value="${esc(f.name)}" oninput="App.gameAddNameIn(this.value)">
          ${f.layout === "depot" ? `<div class="gm-note ok">Depot layout found: markets from <b>${esc(fileName(f.game_docs) || "the game folder")}</b>; PSDs go to each market's
            <b>Production › Video › Market › Help Screen › Working</b> and PNGs to <b>Static</b>.</div>` : ""}
          <label class="gm-lab">Markets found (${f.markets.length})</label>
          <div class="gm-mlist">${f.markets.map((m, i) => `
            <div class="gm-mpick ${f.layout === "depot" ? "depot" : ""}">
              <input type="checkbox" ${m.use ? "checked" : ""} onchange="App.gameAddToggle(${i}, this.checked)">
              <input class="form-control gm-mname-in" value="${esc(m.name)}" oninput="App.gameAddRename(${i}, this.value)">
              ${(m.excel_candidates || []).length > 1
                ? `<select class="form-control gm-xl-pick ${m.ambiguous ? "warn" : ""}" title="${m.ambiguous ? "Several help-screen Excels found — check this is the right one" : "Other Excel files found for this market"}"
                     onchange="App.gameAddPickExcel(${i}, this.value)">${m.excel_candidates.map((c) => `<option value="${esc(c)}" ${c === m.excel_path ? "selected" : ""}>${esc(fileName(c))}</option>`).join("")}</select>`
                : `<span class="gm-path" title="${esc(m.excel_path)}">${esc(fileName(m.excel_path))}${m.outside_market_folder ? ` <i>(not in its market folder)</i>` : ""}</span>`}
              ${f.layout === "depot" ? `<span class="gm-hs ${m.help_exists ? "ok" : "new"}" title="${esc(m.working)}">${m.help_exists ? "Help Screen ✓" : "Help Screen will be created"}</span>` : ""}
            </div>`).join("") || `<div class="gm-empty small">No market Excel files found.</div>`}
          </div>
          ${(f.others || []).length ? `<label class="gm-lab">Other Excel files (not matched to a market)</label>
            <div class="gm-mlist">${f.others.map((o, i) => `
              <div class="gm-mpick">
                <input type="checkbox" ${o.use ? "checked" : ""} onchange="App.gameAddOther(${i}, this.checked)">
                <input class="form-control gm-mname-in" placeholder="market name" value="${esc(o.name)}" oninput="App.gameAddOtherName(${i}, this.value)">
                <span class="gm-path" title="${esc(o.excel_path)}">${esc(fileName(o.excel_path))}</span>
              </div>`).join("")}</div>` : ""}
          <label class="gm-lab">Settings for this game</label>
          <div class="gm-modes">
            <label class="gm-mode"><input type="radio" name="gmMode" ${G.add.mode === "current" ? "checked" : ""} onchange="App.gameAddMode('current')">
              <span><b>Use current settings</b><br><i>Fonts, sizes, layer styles and spacing are kept. Paths (symbols, background, templates) and per-game data from the previous game are <u>not</u> copied.</i></span></label>
            <label class="gm-mode"><input type="radio" name="gmMode" ${G.add.mode === "new" ? "checked" : ""} onchange="App.gameAddMode('new')">
              <span><b>Start with new settings</b><br><i>Fresh default fonts, sizes and styles.</i></span></label>
            <label class="gm-mode"><input type="radio" name="gmMode" ${G.add.mode === "psd" ? "checked" : ""} onchange="App.gameAddMode('psd')">
              <span><b>Use settings from a given PSD</b><br><i>Read fonts, sizes, colours, alignment, spacing and layer styles from an existing help-screen PSD, review them, and save them for this game.</i></span></label>
          </div>
          ${G.add.mode === "psd" ? psdPanel() : ""}
          <label class="gm-lab">Assets found</label>
          ${f.icon_folder ? assetLine("Symbols", f.icon_folder)
            : `<div class="gm-asset no"><span>!</span><b>Symbols</b><span class="gm-path">No symbols folder found — you'll be asked for a folder or a symbol PSD.</span></div>`}
          ${assetLine("Background", f.bg_path)}
          ${assetLine("Heading art", f.heading_folder)}
          ${f.layout === "depot" ? "" : assetLine("Output", f.output_dir)}
` : ""}
      </div>
      <div class="gm-dfoot">
        <button class="btn secondary" onclick="App.gameAddClose()">Cancel</button>
        <button class="btn primary" onclick="App.gameAddCreate()" ${f && !a.busy ? "" : "disabled"}>${a.busy && f ? "Creating…" : "Create game"}</button>
      </div>
    </div>`;
  }
})();
