/* Table designs (Tables view): pick a look for every table, or give one table its own.
   Designs are colours / lines / fills only (never sizes), so pages don't move. "Like Excel"
   uses each cell's own Excel colours, coloured rules (conditional formatting) included. A
   table is remembered by its sheet and header text, so its design survives Excel revisions. */
window.TableDesigns = (() => {
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  let data = null, stamp = Date.now();

  const swatch = (id) => `/api/tables/design_swatch?id=${encodeURIComponent(id)}&v=${stamp}`;
  const ts = () => (App.state.config.table_style = App.state.config.table_style || {});

  function html() {
    if (!data) return `<div class="tbl-head">Table designs</div><div class="hint">Reading the Excel's tables…</div>`;
    const def = data.default || "current";
    const opt = (id, cur) => data.designs.map((d) => `<option value="${esc(d.id)}" ${d.id === cur ? "selected" : ""}>${esc(d.name)}</option>`).join("");
    const byId = Object.fromEntries(data.designs.map((d) => [d.id, d]));
    return `<div class="tbl-head">Table designs</div>
      <div class="hint" style="margin-bottom:8px">The look of every table — click one. Give a single table its own design below.</div>
      <div class="td-grid">${data.designs.map((d) => `<button class="td-opt ${d.id === def ? "on" : ""}" data-tddef="${esc(d.id)}" title="${esc(d.about || d.name)}">
          <img src="${swatch(d.id)}" alt=""><span>${esc(d.name)}</span></button>`).join("")}</div>
      <div class="btn-row" style="margin-top:8px"><button class="btn secondary small" data-tdsave>Save these colours as a design…</button></div>
      ${data.tables.length ? `<div class="td-tables-head">Tables in this Excel (${data.tables.length})</div>
      <div class="td-tables">${data.tables.map((t) => `<div class="td-table">
          <img src="${swatch(t.design)}" alt="" title="${esc((byId[t.design] || {}).name || "")}">
          <div class="td-tname"><b>${esc(t.sheet)}</b><span>${esc(t.header || "(no header)")}</span></div>
          <select data-tdkey="${esc(t.key)}"><option value="" ${t.own ? "" : "selected"}>Same as every table</option>${t.own ? opt(t.design, t.design) : opt("", "")}</select>
        </div>`).join("")}</div>` : `<div class="hint" style="margin-top:8px">${esc(data.error || "No tables found in this Excel's pages (switch Tables on above, or check the Excel).")}</div>`}`;
  }

  function paint() {
    const host = document.getElementById("tblDesigns");
    if (!host) return;
    host.innerHTML = html();
    host.querySelectorAll("[data-tddef]").forEach((b) => b.addEventListener("click", () => {
      ts().default_design = b.dataset.tddef;
      changed();
    }));
    host.querySelectorAll("[data-tdkey]").forEach((sel) => sel.addEventListener("change", () => {
      const own = Object.assign({}, ts().designs || {});
      if (sel.value) own[sel.dataset.tdkey] = sel.value; else delete own[sel.dataset.tdkey];
      ts().designs = own;
      changed();
    }));
    host.querySelector("[data-tdsave]")?.addEventListener("click", async () => {
      const name = prompt("Name for this design (the current Colors and Render behaviour):", "My design");
      if (!name) return;
      await App.flushConfig();
      const d = await api("/api/tables/save_design", { method: "POST", body: { name } });
      if (d && d.ok) { App.state.config = d.config; toast(`Design “${name}” saved.`); load(); }
    });
  }

  function changed() {
    App.refreshUI();                       // saves the settings and redraws the table preview
    stamp = Date.now();
    setTimeout(load, 400);
  }

  async function load() {
    if (!document.getElementById("tblDesigns")) return;
    try {
      await App.flushConfig();
      data = await api("/api/tables/designs", { method: "POST", body: {} });
    } catch (e) {
      data = { designs: [], tables: [], error: e.message };
    }
    stamp = Date.now();
    paint();
  }
  return { load, paint };
})();
