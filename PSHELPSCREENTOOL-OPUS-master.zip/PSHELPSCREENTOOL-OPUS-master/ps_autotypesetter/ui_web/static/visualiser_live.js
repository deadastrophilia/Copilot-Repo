/* ---------------------------------------------------------------------------
 * Visualiser LIVE Renderer — 60 FPS interactive canvas editor.
 *
 * Standalone route ("visualiser-live", nav: LIVE Renderer under Visualiser).
 * The page(s) are laid out and drawn CLIENT-SIDE (canvas 2D + rAF), mirroring
 * png_builder.build_pngs_only for normal pages:
 *   * heading (centered, bold, with layer FX)
 *   * body paragraphs (inline <token> icons, word-wrap)
 *   * multi-page flow: page 1 = heading + heading_to_body_gap; pages 2+ repeat
 *     the heading + "(Continued)" line (h_font @ 38%, body color) + continued_gap
 *   * read-only table strips (pixel-exact server renders)
 *
 * Element model (every element gets a STABLE, page-agnostic id):
 *   heading  -> "heading"                       (page 1 only)
 *   line     -> "line.{row}.{lineIndex}"
 *   icon     -> "icon.{TOKEN}.{ctxKey}.{lineIndex}.{runIndex}"
 *              (ctxKey = "heading" or the Excel row number)
 *   table    -> "table.{row_start}"
 *
 * Per-element overrides live in
 *   config.dynamic_settings.live_overrides[sheet_name][element_id] =
 *     { x, y            : offset from the auto-layout position (px)
 *       sx, sy          : scale multipliers
 *       rot             : rotation degrees
 *       opacity         : 0..100 }
 * They apply on top of the automatic layout, so re-flow never destroys them.
 *
 * Layout:
 *   left  = sheet rail: a thumbnail of EVERY page in the workbook (one sheet
 *           per help-screen page); click a thumbnail to edit that page
 *   center= large responsive editor canvas (fit / zoom / pan)
 *   right = sidebar with two tabs: "Pages" (thumbnails of every rendered
 *           flow page of the CURRENT sheet; click to edit that page) and
 *           "Controls" (the same settings controls as the static Visualiser).
 *
 * Interactions: "Text Edit" mode (default) — single click selects the ROW
 * (with its icons); "Icon Edit" mode — single click selects an ICON; double
 * clicking an icon edits it in either mode. Drag move (snapped to safe box) ·
 * corner scale (proportional, anchored at the icon's center point, constrained
 * to its row: the icon box never leaves the row and keeps the configured icon
 * left/right gaps from the row edges and its neighbours) · top handle rotate ·
 * arrows nudge (Shift = 10 px) · Ctrl+Z / Ctrl+Y undo-redo · Verify
 * pixel-diffs the CURRENT page against the authoritative PIL PNG (per-page
 * server render).
 *
 * Transformed icons re-flow the layout: the line reserves the transformed icon
 * width (+ gaps), line heights grow so a scaled icon never overlaps the text
 * above/below it, lines re-wrap and overflow moves to the next "(Continued)"
 * page (debounced relayout during the drag).
 * ------------------------------------------------------------------------- */
(function () {
  "use strict";
  if (window.AppLive) return;

  const TOKEN_RE = /<([^<>]+)>/g;
  const PART_SIDE_GAP = 40;          // = png_builder.TABLE_PART_SIDE_GAP (cut table parts side by side)
  const SNAP_PX = 8;
  const MIN_SCALE = 0.02;
  const MAX_SCALE = 2;                    // 200 %: further in, the page picture gets so big that drawing lags
  const THUMB_W = 168;

  const L = {
    state: {
      data: null,        // editor-data payload
      settings: null,    // merged settings snapshot
      fontsLoaded: false,
      icons: {},         // token -> {img, w, h} natural size
      stripImgs: {},     // table url -> Image
      images: null,      // bg image
      pages: [],         // [{index, elements}]
      page: 0,           // current page (0-based)
      elements: [],      // alias -> pages[page].elements
      selected: null,    // element id or null
      overrides: {},     // element_id -> override for the current sheet
      editMode: "text",  // "text" = click selects rows (with their icons) · "icon" = click selects icons
      freeform: false, // ON = icons move/rotate anywhere · OFF = icons stay on their row axis (x only, never tilted)
      guideDrag: null,  // {gd, geom, startX, startY, value} for margin guide drag
      drag: null,
      pan: null,
      scale: 1,
      tx: 0,
      ty: 0,
      fitted: false,
      undo: [],
      redo: [],
      dirty: true,
      fxEnabled: true, // layer-style preview (captured_params / flat FX) on/off
      fxDiag: null,    // {stage, error?, text?, hasFx?, headingFx?} — set when a sprite build fails or FX is skipped
      raf: 0,
      verify: null,      // last verify result
      showDiff: false,
      sheet: "",
      meta: null,        // sheets meta (sheets + controls)
      dataRefreshTimer: 0,
      thumbTimer: 0,
      thumbUrls: [],
      sheetThumbs: {},   // sheet name -> preview token (left rail thumbnails)
      paylines: null,    // {sheet, pages:[{name, img}], error} — Paylines / Win Lines sheet shown as build-rendered pages
      railTimer: 0,
      renderTarget: null,
      safe: { left: 0, width: 1, bottom: 0 },
      headingH: 0,       // page-1 heading block height (px)
      continuedH: 0,     // "(Continued)" line height (px)
      overflow: 0,
      _bound: false,
      _keyBound: false,
      _docBound: false,
    },
  };

  function el(id) { return document.getElementById(id); }

  function rgba(rgb, a) {
    const v = Array.isArray(rgb) ? rgb : [255, 255, 255];
    return "rgba(" + Math.round(Number(v[0]) || 0) + "," + Math.round(Number(v[1]) || 0) + "," + Math.round(Number(v[2]) || 0) + "," + (a == null ? 1 : a) + ")";
  }

  function normToken(t) {
    return untagToken(t).toUpperCase().replace(/[^A-Z0-9]+/g, "");
  }
  /* an icon sized in Assets & Icons arrives as '<WILD~140>' (icon_scales.py): the token and its factor */
  const SCALE_TAG = /~(\d+(?:\.\d+)?)\s*$/;
  // its own gaps, '<WILD~140^10,20>': 10 px left of it, 20 px right (icon_scales.py, after the size tag)
  const GAP_TAG = /\^(\d+(?:\.\d+)?),(\d+(?:\.\d+)?)\s*$/;
  function untagToken(t) {
    return String(t || "").replace(GAP_TAG, "").replace(SCALE_TAG, "").trim();
  }
  function tokenScale(t) {
    const m = SCALE_TAG.exec(String(t || "").replace(GAP_TAG, ""));
    return m ? Math.max(0.05, Math.min(10, Number(m[1]) / 100)) : 1;
  }
  // the gaps beside this icon: its own (a gap tag), else the text's ({l, r})
  function tokGaps(t, gaps) {
    const m = GAP_TAG.exec(String(t || ""));
    if (m) return { l: Number(m[1]) || 0, r: Number(m[2]) || 0 };
    return { l: (gaps && gaps.l) || 0, r: (gaps && gaps.r) || 0 };
  }

  function num(v, fb) {
    const n = Number(v);
    return isFinite(n) ? n : fb;
  }

  function rgbToHex(rgb) {
    if (Array.isArray(rgb) && rgb.length >= 3) {
      return "#" + rgb.slice(0, 3).map((c) => Math.max(0, Math.min(255, Math.round(Number(c) || 0))).toString(16).padStart(2, "0")).join("").toUpperCase();
    }
    return typeof rgb === "string" && /^#/.test(rgb) ? rgb : "#FFFFFF";
  }

  function hexToRgb(hex) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || "").trim());
    if (!m) return [255, 255, 255];
    const n = parseInt(m[1], 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }

  /* ------------------------------ settings ------------------------------ */

  /* Python round() is banker's rounding; keep JS Math.round-free so the
     row-gap below matches png_builder._row_gap_px bit-for-bit. */
  function pyRound(x) {
    const f = Math.floor(x);
    const d = x - f;
    if (d < 0.5) return f;
    if (d > 0.5) return f + 1;
    return (f % 2 === 0) ? f : f + 1;
  }

  /* Exact twin of png_builder._row_gap_px (build_engine._line_gap_margin_px):
     UI multiplier (0.5-3) -> font * (multiplier - 1) px; a px value is used
     directly; the explicit UI 'Row spacing' (line_gap, px) wins when given.
     This is the gap the FINAL PNG renderer applies between rows, so the live
     canvas must apply the same one to match the build output. */
  function rowGapPx(fontSize, lineSpacing, lineGap) {
    if (lineGap != null && lineGap !== "") {
      const lg = Number(lineGap);
      if (isFinite(lg)) return Math.max(0, pyRound(lg));
    }
    const raw = Number(lineSpacing);
    if (!isFinite(raw)) return 0;
    if (raw >= 0 && raw <= 3) {
      const f = Math.max(0, Number(fontSize) || 0);
      return pyRound(f * Math.max(0, raw - 1));
    }
    return Math.max(0, pyRound(raw));
  }

  /* UI 'Row spacing' (line_gap) is the SINGLE row-gap source in every
     renderer: a px gap between row content boxes; empty -> default 30. */
  function effectiveRowGap(lineGap) {
    if (lineGap != null && lineGap !== "") {
      const lg = Number(lineGap);
      if (isFinite(lg)) return Math.max(0, pyRound(lg));
    }
    return 30;
  }

  function mergedSettings() {
    const d = L.state.data;
    if (!d) return null;
    const s = Object.assign({}, d.settings);
    const cfg = (App.state && App.state.config) || {};
    const numv = (k, fb) => {
      const v = cfg[k];
      if (v === undefined || v === null || v === "") return fb;
      return Number(v);
    };
    // mirror build_pngs_only int coercion
    const pint = (k, fb) => Math.max(0, Math.round(numv(k, fb)));
    s.h_size = Math.max(8, Math.round(numv("h_size", s.h_size)));
    s.b_size = Math.max(8, Math.round(numv("b_size", s.b_size)));
    s.margin_x = pint("margin_x", s.margin_x);
    s.inner_canvas_width = pint("inner_canvas_width", s.inner_canvas_width);
    s.line_spacing = pint("line_spacing", s.line_spacing);
    // raw (possibly fractional) Typography value -> PSD row-gap math, exactly
    // like png_builder._row_gap_px in the final PNG render.
    const rawLs = numv("line_spacing", (s.line_spacing_raw !== undefined && s.line_spacing_raw !== null) ? s.line_spacing_raw : 1.1);
    s.line_spacing_raw = rawLs;
    const lgRaw = cfg["line_gap"];
    s.line_gap = (lgRaw === undefined || lgRaw === null || lgRaw === "") ? null : Number(lgRaw);
    // Headings keep the multiplier-derived gap; body rows use the Row Gap
    // ('line_gap') field as the SINGLE row-gap source (empty -> default 30px).
    s.heading_line_spacing = rowGapPx(s.h_size, rawLs);
    s.body_line_spacing = effectiveRowGap(s.line_gap);
    s.pxGapMode = true;
    s.para_spacing = pint("para_spacing", s.para_spacing);
    s.heading_top_margin = pint("heading_top_margin", s.heading_top_margin);
    // the Heading–Body Gap can go above the heading's bottom (the text overlapping it, the artist's choice)
    s.heading_to_body_gap = Math.round(numv("heading_to_body_gap", s.heading_to_body_gap));
    s.bottom_margin = pint("bottom_margin", s.bottom_margin);
    s.continued_gap = pint("continued_gap", s.continued_gap);
    s.icon_gap_l = pint("icon_gap_left", 0);
    s.icon_gap_r = pint("icon_gap_right", 0);
    s.head_icon_gap_l = pint("heading_icon_gap_left", 0);
    s.head_icon_gap_r = pint("heading_icon_gap_right", 0);
    s.icon_y_offset = Math.round(numv("icon_y_offset", s.icon_y_offset));
    s.h_icon_h = Math.max(1, Math.round(numv("h_icon_h", s.h_icon_h || s.h_size || 48)));
    s.b_icon_h = Math.max(1, Math.round(numv("b_icon_h", s.b_icon_h)));
    const ov = cfg.icon_size_overrides || {};
    s.icon_size_overrides = {};
    for (const k in ov) {
      const v = Number(ov[k]);
      if (v > 0) s.icon_size_overrides[normToken(k)] = Math.round(v);
    }
    return s;
  }

  /* a strip's height: the row's text height + 2 × pad_y (text_styles.strip_geometry), never below 0 */
  function stripRowH(e) {
    return Math.max(1, Math.round((e && ((e.cbox && e.cbox.h) || (e.base && e.base.h) || e.h)) || 40));
  }
  function stripTall(e, pad) {
    return Math.max(0, Math.round(stripRowH(e) + 2 * Number(pad || 0))) + " px tall";
  }

  function readOverrides() {
    const d = L.state.data;
    if (!d || !d.sheet_name) return {};
    const cfg = (App.state && App.state.config) || {};
    const dyn = cfg.dynamic_settings || {};
    const lo = dyn.live_overrides || {};
    const raw = lo[d.sheet_name] || {};
    const out = {};
    for (const id in raw) {
      const r = raw[id];
      const o = {};
      if (r.x != null) o.x = Math.round(num(r.x, 0));
      if (r.y != null) o.y = Math.round(num(r.y, 0));
      if (r.sx != null) o.sx = Math.max(0.05, num(r.sx, 1));
      if (r.sy != null) o.sy = Math.max(0.05, num(r.sy, 1));
      if (r.rot != null) o.rot = Math.round(num(r.rot, 0));
      if (r.opacity != null) o.opacity = Math.max(0, Math.min(100, Math.round(num(r.opacity, 100))));
      if (Object.keys(o).length) out[id] = o;
    }
    return out;
  }

  // undo / redo is the app's (App.hist): this keeps an unsaved change its own step before the next one
  function pushUndo() {
    if (App.histNote) App.histNote();
  }

  window.addEventListener("psh:history", () => {          // an undo / redo: draw the settings it put back
    if (App.route !== "visualiser-live" || !L.state.data) return;
    L.state.overrides = readOverrides();
    rebuildAfterConfig();
  });

  function rebuildAfterConfig() {
    buildPages();
    markDirty();
    scheduleThumbs(150);
    renderControls();
    scheduleSheetThumb(2500);
  }

  function commitOverrides() {
    const d = L.state.data;
    if (!d || !d.sheet_name) return;
    const dyn = Object.assign({}, App.get("dynamic_settings") || {});
    const lo = Object.assign({}, dyn.live_overrides || {});
    const clean = {};
    for (const id in L.state.overrides) {
      if (Object.keys(L.state.overrides[id] || {}).length) clean[id] = L.state.overrides[id];
    }
    lo[d.sheet_name] = clean;
    dyn.live_overrides = lo;
    pushUndo();
    App.set("dynamic_settings", dyn);
    App.pushConfig();
    scheduleThumbs(200);
    scheduleDataRefresh(900);
    scheduleSheetThumb(2500);
  }

  function undo() {
    App.undo();
  }

  function redo() {
    App.redo();
  }

  /* ------------------------------ fonts ------------------------------ */

  function subFamily() {                     // a subheading row's font: the build's when it loaded
    const f = L.state._fontFaces && L.state._fontFaces.visS;
    return f && L.state.data && L.state.data.fonts && f.file === L.state.data.fonts.subheading ? "visS" : "visH";
  }
  function rowRoleFamily(role) {
    return role === "heading" ? "visH" : role === "subheading" ? subFamily() : "visB";
  }

  function contFamily() {                    // "(Continued)" font: the build's when it loaded
    const f = L.state._fontFaces && L.state._fontFaces.visC;
    return f && L.state.data && L.state.data.fonts && f.file === L.state.data.fonts.continued ? "visC" : "visB";
  }

  async function ensureFonts() {
    const d = L.state.data;
    if (!d) return;
    const jobs = [
      ["visH", d.fonts.heading, 700],
      ["visB", d.fonts.body, 400],
      ["visC", d.fonts.continued, 400],              // the "(Continued)" line (heading font, regular)
      ["visS", d.fonts.subheading, 700],             // rows made subheadings (row_roles)
    ];
    L.state._fontFaces = L.state._fontFaces || {};
    const pending = [];
    for (const [family, file, weight] of jobs) {
      if (!file) continue;
      const prev = L.state._fontFaces[family];
      if (prev && prev.file === file && document.fonts.check("16px " + family)) {
        L.state.fontsLoaded = true;
        continue;
      }
      // Font setting changed (h_font / b_font / style) — swap the face so the
      // next layout/measure uses the newly selected font file.
      if (prev && prev.face) {
        try { if (document.fonts.has(prev.face)) document.fonts.delete(prev.face); } catch (e) { }
      }
      try {
        const ff = new FontFace(family, "url(/api/font_file?file=" + encodeURIComponent(file) + ")");
        pending.push(ff.load().then((f) => {
          document.fonts.add(f);
          L.state._fontFaces[family] = { face: f, file: file };
        }));
      } catch (e) { /* fall back to system font */ }
    }
    try { await Promise.all(pending); } catch (e) { /* non-fatal */ }
    L.state.fontsLoaded = true;
  }

  /* --------------------------- measurement --------------------------- */

  function setFont(ctx, family, size) {
    // a styled run's bold / italic while it is drawn with a layer style (drawStyledRun)
    const face = L.state.faceOverride ? L.state.faceOverride + " " : "";
    ctx.font = face + size + "px " + family + ', Arial, sans-serif';
    psText(ctx);
    const shape = famShape(family);
    if (shape && !shape.kern && "fontKerning" in ctx) ctx.fontKerning = "none";
    // Typography letter spacing (Photoshop tracking, 1/1000 em) — the same extra px per character
    // ps_text adds in the PNG / PSD builds
    if ("letterSpacing" in ctx) {
      const t = L.state.trackOverride != null ? L.state.trackOverride : familyTracking(family);
      ctx.letterSpacing = (t ? (size * t / 1000) : 0) + "px";
    }
  }
  // the heading's / paragraph's letter spacing for a font family ("Arial", visB → body)
  function familyTracking(family) {
    const ds = (App.state && App.state.config && App.state.config.dynamic_settings) || {};
    const fam = String(family || "").split(",").pop().trim();
    return fam === "visH" ? Number(ds.heading_tracking) || 0 : (fam === "visB" || fam === "visS") ? Number(ds.body_tracking) || 0 : 0;
  }

  /* the heading's Character-panel width / height scale and kerning (png_builder.heading_shape; a Mimic PSD
     learns them from the artist's heading): null when plain. Drawn with ctx.scale about the pen and the
     baseline, so the letter spacing (set before the scale) widens with the width scale like Photoshop's. */
  function famShape(family) {
    const fam = String(family || "").split(",").pop().trim();
    if (fam !== "visH") return null;
    const ds = (typeof App !== "undefined" && App.state && App.state.config && App.state.config.dynamic_settings) || {};
    const pct = (v) => { const n = Number(v); return v == null || v === "" || !isFinite(n) ? 1 : Math.max(0.01, Math.min(10, n / 100)); };
    const hs = pct(ds.heading_hscale), vs = pct(ds.heading_vscale);
    const kern = String(ds.heading_kerning || "metrics").toLowerCase() !== "none";
    return hs === 1 && vs === 1 && kern ? null : { hs, vs, kern };
  }
  function fillShaped(ctx, text, x, y, family) {
    const sh = famShape(family);
    if (!sh || (sh.hs === 1 && sh.vs === 1)) { ctx.fillText(text, x, y); return; }
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(sh.hs, sh.vs);
    ctx.fillText(text, 0, 0);
    ctx.restore();
  }

  /* Draw text like Photoshop (and ps_text.py): Metrics kerning (the font's own pairs; the PSD keeps
     Photoshop's Metrics on), exact outline geometry, baselines on whole pixels. */
  function psText(ctx) {
    if ("fontKerning" in ctx) ctx.fontKerning = "normal";
    if ("textRendering" in ctx) ctx.textRendering = "geometricPrecision";
  }

  /* Photoshop's pixel row for a baseline: nearest, halves going down (= ps_text.snap_baseline) */
  function snapBaseline(y) {
    return Math.floor(y + 0.5 + 1e-9);
  }

  function textMetrics(ctx, family, size, text) {
    setFont(ctx, family, size);
    const m = ctx.measureText(String(text || ""));
    const sh = famShape(family) || { hs: 1, vs: 1 };
    const w = m.width * sh.hs;
    const h = ((m.actualBoundingBoxAscent || 0) + (m.actualBoundingBoxDescent || 0)) * sh.vs;
    return { w, h, ascent: (m.actualBoundingBoxAscent || 0) * sh.vs };
  }

  function lineHeight(ctx, family, size) {
    const m = textMetrics(ctx, family, size, "Ag");
    return Math.max(m.h, size * 1.18);
  }

  function iconTargetH(token, roleIconH) {
    const ov = (L.state.settings && L.state.settings.icon_size_overrides) || {};
    const v = ov[normToken(token)];
    const h = v > 0 ? v : Math.max(1, roleIconH);
    const f = tokenScale(token);                       // = png_builder._load_icon_uncached
    return f !== 1 ? Math.max(1, Math.round(h * f)) : h;
  }

  function iconInfo(token) {
    return L.state.icons[token] || null;
  }

  function splitInline(raw) {
    const parts = [];
    let last = 0;
    TOKEN_RE.lastIndex = 0;
    let m;
    while ((m = TOKEN_RE.exec(raw))) {
      if (m.index > last) parts.push({ t: "text", v: raw.slice(last, m.index), src: raw, o: last });
      parts.push({ t: "icon", v: m[1].trim() });
      last = m.index + m[0].length;
    }
    if (last < raw.length) parts.push({ t: "text", v: raw.slice(last), src: raw, o: last });
    // trim spaces hugging tokens (mirrors png_builder._split_inline); src / o = where the part is in
    // its line, for word styles on one exact occurrence (" with one or more " is in a row 3 times)
    for (let i = 0; i < parts.length; i++) {
      const p = parts[i];
      if (p.t !== "text" || !p.v) continue;
      const prevIcon = i > 0 && parts[i - 1].t === "icon";
      const nextIcon = i + 1 < parts.length && parts[i + 1].t === "icon";
      let v = p.v;
      if (prevIcon) { const t = v.replace(/^\s+/, ""); p.o += v.length - t.length; v = t; }
      if (nextIcon) v = v.replace(/\s+$/, "");
      parts[i].v = v;
    }
    return parts.filter((p) => p.t === "icon" || String(p.v || ""));
  }

  function measureParts(ctx, parts, family, size, iconH, gaps) {
    let width = 0, height = 0;
    const lh = lineHeight(ctx, family, size);
    const gl = (gaps && gaps.l) || 0, gr = (gaps && gaps.r) || 0;
    for (const p of parts) {
      if (p.t === "icon") {
        const info = iconInfo(p.v);
        if (info) {
          const th = iconTargetH(p.v, iconH);
          const w = Math.max(1, Math.round(info.w * th / Math.max(1, info.h)));
          const g = tokGaps(p.v, { l: gl, r: gr });
          width += g.l + w + g.r;
          height = Math.max(height, th);
        } else {
          const m = textMetrics(ctx, family, size, "<" + untagToken(p.v) + ">");
          width += m.w;
          height = Math.max(height, m.h);
        }
      } else {
        const m = textMetrics(ctx, family, size, p.v);
        width += m.w;
        height = Math.max(height, m.h);
      }
    }
    return { w: width, h: Math.max(lh, height), inkH: height };
  }

  function measureTextRun(ctx, text, family, size) {
    return textMetrics(ctx, family, size, text);
  }

  /* a mapped icon token whose name has a space ("<Feature Gem>") is one word: a line never breaks
     inside it (= png_builder._keep_tokens); a token that is not mapped is text and breaks like text */
  function keepTokens(words) {
    const out = [];
    for (let i = 0; i < words.length;) {
      let acc = words[i], j = i;
      while (acc.lastIndexOf("<") > acc.lastIndexOf(">") && j + 1 < words.length) acc += words[++j];
      const spaced = j > i ? [...acc.matchAll(/<([^<>]+)>/g)].map((m) => m[1].trim()).filter((t) => /\s/.test(t)) : [];
      if (spaced.length && acc.lastIndexOf("<") < acc.lastIndexOf(">") && spaced.every((t) => iconInfo(t))) {
        out.push(acc);
        i = j + 1;
        continue;
      }
      out.push(words[i]);
      i += 1;
    }
    return out;
  }

  function wrapInline(ctx, raw, family, size, maxWidth, iconH, ctxKey, gaps, lineBase) {
    if (maxWidth <= 0) return [String(raw || "")];
    const text = String(raw || "");
    if (text.indexOf("\n") !== -1) {
      const out = [];
      for (const chunk of text.split("\n")) {
        for (const ln of wrapInline(ctx, chunk, family, size, maxWidth, iconH, ctxKey, gaps, (lineBase || 0) + out.length)) out.push(ln);
      }
      return out;
    }
    const words = keepTokens(text.split(/(\s+)/));
    const lines = [];
    let current = "", pos = 0, start = 0;
    // where each trial / line starts in the row (word styles on one exact occurrence: lineAt)
    const base = lineAt(text);
    const mark = (s, at) => { if (base != null) L.state.wsLineAt.set(s, base + skel(text.slice(0, at)).s.length); return s; };
    const line = (s, at) => mark(s.trim(), at + s.length - s.replace(/^\s+/, "").length);
    for (const word of words) {
      if (!current) start = pos;
      const trial = current + word;
      if (current.trim() && measurePartsLive(ctx, splitInline(mark(trial, start)), family, size, iconH, ctxKey, (lineBase || 0) + lines.length, gaps) > maxWidth) {
        lines.push(line(current, start));
        current = word.trim();
        start = pos;
      } else {
        current = trial;
      }
      pos += word.length;
    }
    if (current.trim()) lines.push(line(current, start));
    if (!lines.length) lines.push("");
    return lines;
  }

  /* ------------------------------ layout ------------------------------ */

  function recomputeSafeBox(s) {
    const d = L.state.data;
    const cw = d.canvas_w, ch = d.canvas_h;
    const defaultW = Math.max(100, cw - s.margin_x * 2);
    const explicit = s.inner_canvas_width;
    let inner;
    if (explicit > 0) inner = Math.min(Math.max(100, explicit), cw);
    else if (cw >= ch) inner = Math.min(defaultW, Math.max(100, ch - 20));
    else inner = defaultW;
    if (inner >= defaultW) return { left: s.margin_x, width: defaultW };
    return { left: Math.round((cw - inner) / 2), width: inner };
  }

  function applyOverride(e) {
    let ov = L.state.overrides[e.id];
    if (!ov) { ov = {}; L.state.overrides[e.id] = ov; }
    e.ov = ov;
    e.base = { x: e.x, y: e.y, w: e.w, h: e.h, x0: e.x0 };
    const sx = ov.sx != null ? ov.sx : 1;
    const sy = ov.sy != null ? ov.sy : 1;
    e.sx = sx;
    e.sy = sy;
    e.w = Math.max(1, Math.round(e.base.w * sx));
    e.h = Math.max(1, Math.round(e.base.h * sy));
    e.rot = ov.rot != null ? ov.rot : 0;
    e.opacity = ov.opacity != null ? ov.opacity : 100;
  }

  /* persistent offscreen context for measurement/layout, so buildPages never
     crashes on an undefined canvas (e.g. first data load before resize). */
  let _measureCv = null;
  function measureCtx() {
    if (!_measureCv) {
      _measureCv = document.createElement("canvas");
      _measureCv.width = _measureCv.height = 64;
    }
    return _measureCv.getContext("2d");
  }

  /* Multi-page flow mirroring png_builder._render_inline_block_line_by_line:
     page 1: heading + heading_to_body_gap; pages 2+: heading + "(Continued)"
     + max(0, continued_gap, 20); lines break to a new page when
     current_y + line_h > safe_bottom. */
  function buildPages() {
    const d = L.state.data;
    if (!d) return;
    if (L.state.paylines && L.state.paylines.sheet === d.sheet_name) {
      buildPagesPaylines();
      return;
    }
    if (L.state.canon && L.state.canon.mode === "canonical" && L.state.canon.layouts && L.state.canon.layouts.length) {
      try {
        buildPagesCanonical();
        return;
      } catch (e) {
        L.state.canon = null; // malformed payload -> independent render below
      }
    }
    L.state.canonActive = false;
    const s = mergedSettings();
    if (!s) return;
    L.state.settings = s;
    const ctx = L.state.ctx || measureCtx();
    const safe = recomputeSafeBox(s);
    const safeBottom = Math.max(s.heading_top_margin + 100, d.canvas_h - s.bottom_margin);
    const H_FAMILY = "visH", B_FAMILY = "visB";
    const headingIconH = Math.max(1, s.h_icon_h);
    const bodyIconH = s.b_icon_h;
    const headingLineSpacing = s.heading_line_spacing;
    const bodyLineSpacing = s.body_line_spacing;

    const hGaps = { l: s.head_icon_gap_l, r: s.head_icon_gap_r };
    const bGaps = { l: s.icon_gap_l, r: s.icon_gap_r };
    const rowLook = (role) => {                  // = png_builder's row look (row_roles.py)
      if (role === "heading") {
        return { fam: H_FAMILY, size: (d.heading && d.heading.size) || s.h_size, iconH: headingIconH, gaps: hGaps,
          rgb: d.heading.rgb, fx: d.heading.fx };
      }
      if (role === "subheading" && d.subheading) {
        return { fam: subFamily(), size: d.subheading.size, iconH: d.subheading.icon_h, gaps: bGaps,
          rgb: d.subheading.rgb, fx: d.subheading.fx };
      }
      return { fam: B_FAMILY, size: s.b_size, iconH: bodyIconH, gaps: bGaps, rgb: d.body.rgb, fx: d.body.fx };
    };
    const headingLines = wrapInline(ctx, d.heading.text, H_FAMILY, s.h_size, safe.width, headingIconH, "heading", hGaps);
    let headingH = 0;
    const headingLineHs = [];
    const headingLineHsBase = [];
    for (let li = 0; li < headingLines.length; li++) {
      const runParts = splitInline(headingLines[li]);
      const mp = measureParts(ctx, runParts, H_FAMILY, s.h_size, headingIconH, hGaps);
      const lh = mp.h;
      const lhAdj = Math.max(lh, lineIconMaxH(runParts, "heading", li, headingIconH, lh));
      headingLineHsBase.push(lh);
      headingLineHs.push(lhAdj);
      headingH += lhAdj;
    }
    if (headingLines.length > 1) headingH += (headingLines.length - 1) * headingLineSpacing;

    // "(Continued)": the server measures it with the build's own font (visualiser_data "continued")
    const cont = d.continued || {};
    const contSize = cont.size || Math.max(12, Math.round(s.h_size * 0.38));
    const continuedH = cont.h > 0 ? cont.h : Math.max(1, Math.ceil(textMetrics(ctx, contFamily(), contSize, "(Continued)").h));

    const pages = [];
    let cur = { index: 0, elements: [] };
    pages.push(cur);
    // page 1 of a page the Excel calls continued: spaced like a Continued page (visualiser_data "continued")
    // a Continued page: under "(Continued)", never above the Heading–Body Gap (as on page 1)
    // (or the artist's own Continued–Body Gap, its guide)
    const contTop = () => cont.body_gap != null
      ? s.heading_top_margin + headingH + Math.max(2, s.continued_gap, 8) + continuedH + Number(cont.body_gap)
      : Math.max(s.heading_top_margin + headingH + Math.max(2, s.continued_gap, 8) + continuedH + Math.max(0, s.continued_gap, 20),
                 Math.max(0, s.heading_top_margin + headingH + (Number(s.heading_to_body_gap) || 0)));
    let y = d.heading.continued ? contTop() : Math.max(0, s.heading_top_margin + headingH + s.heading_to_body_gap);
    let overflow = 0;

    function newPage() {
      cur = { index: pages.length, elements: [] };
      pages.push(cur);
      y = contTop();
      return cur;
    }

    // page 1 heading element + its inline icon hit targets
    {
      const hEl = {
        id: "heading", kind: "heading",
        x: safe.left, y: s.heading_top_margin, w: safe.width, h: headingH,
        family: H_FAMILY, size: s.h_size,
        lines: headingLines, lineHs: headingLineHs, lineHsBase: headingLineHsBase,
        iconH: headingIconH,
        rgb: d.heading.rgb, fx: d.heading.fx || null,
        binds: { size: "h_size" },
        role: "heading",
      };
      cur.elements.push(hEl);
      applyOverride(hEl);
      let hy = s.heading_top_margin;
      let cminX = Infinity, cmaxX = -Infinity;
      const hxs = [];
      for (let li = 0; li < headingLines.length; li++) {
        const lh = headingLineHs[li];
        const lhBase = headingLineHsBase[li];
        const runParts = splitInline(headingLines[li]);
        const mw = measurePartsLive(ctx, runParts, H_FAMILY, s.h_size, headingIconH, "heading", li, hGaps);
        const lineX0 = anchorLineX(ctx, runParts, H_FAMILY, s.h_size, headingIconH, "heading", li, mw, safe, hGaps, safe.left + Math.max(0, (safe.width - mw) / 2));
        cminX = Math.min(cminX, lineX0);
        cmaxX = Math.max(cmaxX, lineX0 + mw);
        hxs.push(lineX0);
        let hx = lineX0;
        let runIdx = 0;
        for (const p of runParts) {
          if (p.t === "icon") {
            const info = iconInfo(p.v);
            if (info) {
              const th = iconTargetH(p.v, headingIconH);
              const iw = Math.max(1, Math.round(info.w * th / Math.max(1, info.h)));
              const iconId = "icon." + normToken(p.v) + ".heading." + li + "." + runIdx;
              const ovi = L.state.overrides[iconId];
              const w = ovi && ovi.sx != null ? Math.max(1, Math.round(iw * ovi.sx)) : iw;
              const iEl = {
                id: iconId,
                kind: "icon",
                token: p.v, x: hx + hGaps.l, y: hy + Math.max(0, (lhBase - th) / 2) + s.icon_y_offset, w: iw, h: th,
                binds: { size: "__icon__" },
                role: "heading",
                row: "heading", lineIdx: li, runIdx: runIdx,
              };
              cur.elements.push(iEl);
              applyOverride(iEl);
              hx += hGaps.l + w + hGaps.r;
            } else {
              hx += textMetrics(ctx, H_FAMILY, s.h_size, "<" + untagToken(p.v) + ">").w;
            }
            runIdx++;
          } else {
            hx += textMetrics(ctx, H_FAMILY, s.h_size, p.v).w;
          }
        }
        hy += lh + (li < headingLines.length - 1 ? headingLineSpacing : 0);
      }
      if (isFinite(cminX) && isFinite(cmaxX)) {
        hEl.cbox = {
          x: cminX, y: s.heading_top_margin, w: cmaxX - cminX, h: headingH,
          cx: (cminX + cmaxX) / 2, cy: s.heading_top_margin + headingH / 2,
        };
      }
      hEl.lineXs = hxs;
    }

    const tableBlocks = (d.tables || []).slice();
    let tableIndex = 0;
    L.state.wsRow = "";
    L.state.wsRowText = "";
    let pageTop = null;                          // where the newest Continued page's body starts
    const turn = () => { newPage(); pageTop = y; };
    // a table that doesn't fit under the text starts a Continued page (never squeezed) — or, split by
    // the artist, it is cut by rows: as many as fit here, the rest on the next page, the header on each
    // part (exactly png_builder's table placement)
    function placeTable(tb) {
      if (!tb.url || !tb.height) return;
      const g = tb.geo || {};
      const rows = g.rows || [], gap = Number(g.row_gap) || 0, nHead = Math.min(rows.length, Number(g.header_rows) || 0);
      const nBody = rows.length - nHead;
      const tops = [];                           // each row's top in the table picture
      let acc = 0;
      rows.forEach((h, i) => { tops.push(acc); acc += h + (i < rows.length - 1 ? gap : 0); });
      const headH = nHead ? tops[nHead - 1] + rows[nHead - 1] : 0;
      const sliceH = (a, b) => headH + (b > a ? (nHead ? gap : 0) + (tops[nHead + b - 1] + rows[nHead + b - 1] - tops[nHead + a]) : 0);
      // what the ✂ / join hover needs: this element's body rows a..b and where each row line is
      // tx / tw: where the drawn table sits across the strip (a narrow table is centred in it)
      const tw = (g.cols || []).reduce((p, q) => p + (Number(q) || 0), 0);
      const cutInfo = (a, b, pi) => ({ a, b, pi, nBody, nHead, headH, gap, tops, rows, cuts: (tb.splits || []).slice(),
        tx: tw ? Number(g.x) || 0 : 0, tw: tw || safe.width, pages: Object.assign({}, tb.part_pages || {}) });
      const after = tb.after != null ? Number(tb.after) : 30;
      // a part's own rows (header + body rows a..b); rowMap: its row → the whole table's row
      const partGeo = (a, b) => {
        const rowMap = [];
        for (let i = 0; i < nHead; i++) rowMap.push(i);
        for (let i = a; i < b; i++) rowMap.push(nHead + i);
        const local = (gi) => rowMap.indexOf(gi);
        const cells = (g.cells || []).filter(([r0, , rs]) => local(r0) >= 0 && local(r0 + rs - 1) >= 0)
          .map(([r0, c0, rs, cs]) => [local(r0), c0, rs, cs]);
        return Object.assign({}, g, { rows: rowMap.map((gi) => rows[gi]), cells, rowMap });
      };
      const push = (h, parts, suffix, a, b, ox, oy, pi) => {
        const tEl = {
          id: "table." + tb.row_start + (suffix || ""), kind: "table",
          x: safe.left + (ox || 0), y: y + (oy || 0), w: safe.width, h,
          url: tb.url, token: tb.token, parts: parts || null, fullH: tb.height, geoGap: gap,
          row_start: tb.row_start, design_key: tb.design_key || "", design: tb.design || "current", geo: parts ? partGeo(a, b) : (tb.geo || null), texts: tb.texts || [],
          cut: rows.length ? cutInfo(a, b, pi || 0) : null,
          atTop: pageTop !== null && Math.abs(y - pageTop) < 1,          // it starts its (Continued) page
        };
        cur.elements.push(tEl);
        applyOverride(tEl);
      };
      const cuts = (tb.splits || []).filter((k) => k > 0 && k < nBody).sort((p, q) => p - q);
      if (!cuts.length || nBody < 2) {
        const fresh = pageTop !== null && Math.abs(y - pageTop) < 1;
        if (Number((tb.part_pages || {})[0]) === 1 && !fresh) turn();     // sent to the next page by the artist
        else if (y + tb.height > safeBottom && !fresh) turn();
        push(tb.height, null, "", 0, nBody);
        y += tb.height + after;
        return;
      }
      // cut by the artist (✂ in Tables) — exactly png_builder: the parts stay together on the
      // table's page (side by side when they fit across, else one under the other) except the ones
      // sent to the page before (under the text above) or the page after
      const bounds = [0].concat(cuts, [nBody]);
      const where = tb.part_pages || {};
      const parts = [];
      for (let pi = 0; pi < bounds.length - 1; pi++) {
        const a = bounds[pi], b = bounds[pi + 1];
        parts.push({ pi, a, b, h: sliceH(a, b), g: Number(where[pi]) === -1 ? -1 : Number(where[pi]) === 1 ? 1 : 0 });
      }
      const tableW = tw, tableX = tw ? Number(g.x) || 0 : 0;
      const block = (group) => {                     // = png_builder._table_part_block
        const n = group.length, total = n * tableW + (n - 1) * PART_SIDE_GAP;
        if (n > 1 && tableW > 0 && total <= safe.width) {
          const start = (safe.width - total) / 2;
          return { spots: group.map((_, i) => [Math.round(start + i * (tableW + PART_SIDE_GAP) - tableX), 0]), h: Math.max(...group.map((p) => p.h)) };
        }
        let yy = 0;
        const spots = group.map((p) => { const s0 = [0, yy]; yy += Math.max(1, p.h) + after; return s0; });
        return { spots, h: Math.max(1, yy - after) };
      };
      const place = (group) => {
        const bl = block(group);
        group.forEach((p, i) => {
          const segs = [];
          if (nHead) segs.push([0, headH]);
          segs.push([tops[nHead + p.a], tops[nHead + p.b - 1] + rows[nHead + p.b - 1]]);
          push(p.h, segs, p.pi ? "." + p.pi : "", p.a, p.b, bl.spots[i][0], bl.spots[i][1], p.pi);
        });
        y += bl.h + after;
      };
      const grp = (gv) => parts.filter((p) => p.g === gv);
      const prev = grp(-1), here = grp(0), next = grp(1);
      if (prev.length) {
        place(prev);
        if (here.length || next.length) turn();
        if (here.length) place(here);
      } else if (here.length) {
        const fresh = pageTop !== null && Math.abs(y - pageTop) < 1;
        if (y + block(here).h > safeBottom && !fresh) turn();
        place(here);
      }
      if (next.length) {
        if (!(pageTop !== null && Math.abs(y - pageTop) < 1)) turn();
        place(next);
      }
    }
    for (const row of d.rows) {
      while (tableIndex < tableBlocks.length && tableBlocks[tableIndex].row_start <= row.row) {
        placeTable(tableBlocks[tableIndex++]);
      }

      const parts = splitInline(row.text);
      if (!parts.length) continue;
      setWsRow(row.text);              // word rules made for just this row apply to it
      // a row the artist made a heading / subheading (row_roles.py): its own font, size, colour, style
      const rl = rowLook(row.role);
      // a heading / subheading row comes wrapped and measured by the server (png_builder's own math)
      const measured = Array.isArray(row.lines) && row.lines.length ? row.lines : null;
      const lines = measured ? measured.map((m) => m[0]) : wrapInline(ctx, row.text, rl.fam, rl.size, safe.width, rl.iconH, String(row.row), rl.gaps);
      for (let li = 0; li < lines.length; li++) {
        const ln = lines[li];
        const runParts = splitInline(ln);
        const mp = measureParts(ctx, runParts, rl.fam, rl.size, rl.iconH, rl.gaps);
        const lh = Math.max(1, Math.ceil(mp.h));
        let lhAdj = Math.max(lh, lineIconMaxH(runParts, row.row, li, rl.iconH, lh));
        // PSD-style 'Row spacing': rows advance from the REAL ink bottom
        // (glyph ink / icon boxes) + the px gap so the visual gap between
        // rows equals the Row Gap field exactly; paragraph gap is replaced
        // by the explicit row gap (mirrors the PNG renderer).
        const pxGap = s.pxGapMode;
        const ink = measured ? Math.max(1, Number(measured[li][2]) - Number(measured[li][1])) : 0;
        let contentH = pxGap ? (measured ? ink : Math.max(1, Math.round(mp.inkH || lh))) : null;
        const advEst = pxGap ? (measured ? ink : Math.max(contentH, Math.round(lineIconMaxH(runParts, row.row, li, rl.iconH, lh)))) : lhAdj;
        if (y + advEst > safeBottom) {
          newPage();
          overflow++;
          if (advEst > safeBottom - y) lhAdj = Math.max(8, Math.round(safeBottom - y));
        }
        const lineW = measurePartsLive(ctx, runParts, rl.fam, rl.size, rl.iconH, String(row.row), li, rl.gaps);
        const x0 = anchorLineX(ctx, runParts, rl.fam, rl.size, rl.iconH, String(row.row), li, lineW, safe, rl.gaps, safe.left + Math.max(0, (safe.width - lineW) / 2));
        const lineId = "line." + row.row + "." + li;
        const lineEl = {
          id: lineId, kind: "line",
          x: safe.left, y, w: safe.width, h: lhAdj,
          family: rl.fam, size: rl.size,
          runs: null, text: ln, lineW: lineW, x0: x0,
          cbox: { x: x0, y, w: lineW, h: lhAdj, cx: x0 + lineW / 2, cy: y + lhAdj / 2 },
          iconH: rl.iconH,
          rgb: rl.rgb, fx: rl.fx || null,
          binds: { size: "b_size" },
          role: "body", rowRole: row.role || "",
          row: row.row, lineIdx: li,
          rowText: String(row.text || ""),   // the whole Excel row: `text` is only this wrapped line
        };
        cur.elements.push(lineEl);
        applyOverride(lineEl);
        let cx = x0;
        let runIdx = 0;
        for (const p of runParts) {
          if (p.t === "icon") {
            const info = iconInfo(p.v);
            if (info) {
              const th = iconTargetH(p.v, rl.iconH);
              const iw = Math.max(1, Math.round(info.w * th / Math.max(1, info.h)));
              const iconId = "icon." + normToken(p.v) + "." + row.row + "." + li + "." + runIdx;
              const ovi = L.state.overrides[iconId];
              const w = ovi && ovi.sx != null ? Math.max(1, Math.round(iw * ovi.sx)) : iw;
              const iEl = {
                id: iconId,
                kind: "icon",
                token: p.v, x: cx + tokGaps(p.v, rl.gaps).l, y: y + Math.max(0, (lh - th) / 2) + s.icon_y_offset, w: iw, h: th,
                binds: { size: "__icon__" },
                role: "body",
                row: row.row, lineIdx: li, runIdx: runIdx,
              };
              cur.elements.push(iEl);
              applyOverride(iEl);
              if (pxGap && contentH != null && !measured) {
                contentH = Math.max(contentH, Math.round((iEl.y - y) + iEl.h));
              }
              cx += tokGaps(p.v, rl.gaps).l + w + tokGaps(p.v, rl.gaps).r;
            } else {
              cx += textMetrics(ctx, rl.fam, rl.size, "<" + untagToken(p.v) + ">").w;
            }
            runIdx++;
          } else {
            cx += textMetrics(ctx, rl.fam, rl.size, p.v).w;
          }
        }
        if (pxGap) {
          y += contentH + bodyLineSpacing;
        } else {
          y += lhAdj + bodyLineSpacing;
        }
      }
    }
    while (tableIndex < tableBlocks.length) placeTable(tableBlocks[tableIndex++]);

    L.state.safe = { left: safe.left, width: safe.width, bottom: safeBottom };
    L.state.headingH = headingH;
    L.state.continuedH = continuedH;
    L.state.overflow = overflow;
    L.state.pages = pages;
    if (L.state.page >= pages.length) L.state.page = Math.max(0, pages.length - 1);
    L.state.elements = pages[L.state.page].elements;
  }

  /* ---------------------- paylines pages ----------------------
     Paylines / Win Lines sheets ("Line | Reel1 | Reel2 …" table) build as
     mini reel-grid pages, one per denomination group. The live canvas shows
     the build renderer's own pages (/api/paylines/preview) read-only; they
     are edited in the Paylines studio. */

  const STUDIO = {
    paytable: { short: "Paytable", hash: "#/paytable", studio: "Paytable studio" },
    game_rules: { short: "Game Rules", hash: "#/gamerules", studio: "Game Rules studio" },
    bingo_rules: { short: "Bingo Rules", hash: "#/bingorules", studio: "Bingo Rules studio" },
  };
  function allSheets(meta) {
    return (meta && (meta.all_sheets || meta.sheets)) || [];
  }
  function studioKind(name) {
    const m = L.state.meta;
    return (m && m.studio_sheets && m.studio_sheets[name]) || "";
  }
  function studioTag(name) {                       // "Bonus — Paytable"; nothing when the name says it
    const k = studioKind(name);
    if (!k) return "";
    const short = STUDIO[k].short;
    return String(name).replace(/\s/g, "").toLowerCase().includes(short.replace(/\s/g, "").toLowerCase()) ? "" : short;
  }
  async function showStudioSheet(name) {
    const meta = L.state.meta || {};
    const kind = studioKind(name);
    const out = { sheet: name, studio: kind, pages: [], error: "" };
    try {
      const d = await api("/api/page_preview", { method: "POST", body: { sheet_name: name } });
      if (d && d.ok && d.preview_token) {
        const img = await loadImage("/api/table_preview/" + encodeURIComponent(d.preview_token) + "?v=" + Date.now());
        out.pages = [{ name, img }];
      } else out.error = (d && d.error) || "Can't draw this page.";
    } catch (e) { out.error = "Can't draw this page: " + ((e && e.message) || e); }
    if (L.state.sheet !== name) return;                 // another page was picked meanwhile
    const prev = L.state.data || {};
    L.state.data = { sheet_name: name, canvas_w: meta.canvas_width || prev.canvas_w || 1920,
                     canvas_h: meta.canvas_height || prev.canvas_h || 1080, settings: prev.settings || {} };
    L.state.paylines = out;
    L.state.canon = null;
    syncPaylineUi();
    buildPages();
    resize();
    if (!L.state.fitted && !L.state.userView) fit();
    renderPageBadge();
    scheduleThumbs(100);
    markDirty();
  }

  function isPaylineSheet(name) {
    const m = L.state.meta;
    return !!(m && (m.payline_sheets || []).indexOf(name) >= 0);
  }

  function loadImage(url) {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => resolve(null);
      img.src = url;
    });
  }

  async function fetchPaylinePages(sheet) {
    if (!isPaylineSheet(sheet)) return null;
    const out = { sheet, pages: [], error: "" };
    const call = (page) => api("/api/paylines/preview", { method: "POST", body: { sheet_name: sheet, page } });
    try {
      const first = await call(0);
      if (!first || !first.ok || !first.preview_token) {
        out.error = (first && first.error) || "Can't build the payline pages.";
        if (first && (first.errors || []).length) out.error += " " + first.errors.join(" · ");
        return out;
      }
      const metas = first.pages || [];
      const rest = await Promise.all(metas.slice(1).map((_, i) => call(i + 1).catch(() => null)));
      const tokens = [first.preview_token].concat(rest.map((r) => (r && r.ok && r.preview_token) || ""));
      const imgs = await Promise.all(tokens.map((t) => (t ? loadImage("/api/table_preview/" + encodeURIComponent(t) + "?v=" + Date.now()) : null)));
      out.pages = tokens.map((t, i) => ({ name: (metas[i] && metas[i].name) || ("Page " + (i + 1)), img: imgs[i] }));
    } catch (e) {
      out.error = "Can't build the payline pages: " + ((e && e.message) || e);
    }
    return out;
  }

  function buildPagesPaylines() {
    const pl = L.state.paylines;
    L.state.canonActive = false;
    L.state.settings = mergedSettings() || L.state.data.settings;
    const pages = pl.pages.length
      ? pl.pages.map((p, i) => ({ index: i, elements: [], payline: p }))
      : [{ index: 0, elements: [], payline: { name: "Pay Lines", img: null, error: pl.error || "No payline pages." } }];
    L.state.pages = pages;
    if (L.state.page >= pages.length) L.state.page = Math.max(0, pages.length - 1);
    L.state.elements = pages[L.state.page].elements;
  }

  function drawPaylinePage(ctx, pg, W, H) {
    const p = pg.payline;
    if (p.img) {
      ctx.drawImage(p.img, 0, 0, W, H);
      return;
    }
    ctx.save();
    ctx.fillStyle = "#c0392b";
    ctx.font = Math.round(W / 50) + "px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(p.error || "Payline page preview unavailable.", W / 2, H / 2, W * 0.9);
    ctx.restore();
  }

  function syncPaylineUi() {
    const on = !!(L.state.paylines && L.state.data && L.state.paylines.sheet === L.state.data.sheet_name);
    const st = on && L.state.paylines.studio ? STUDIO[L.state.paylines.studio] : null;
    const btn = el("visLivePaylinesLink");
    if (btn) {
      btn.style.display = on ? "" : "none";
      btn.textContent = "Edit in " + (st ? st.studio : "Paylines studio");
      btn.onclick = () => { location.hash = st ? st.hash : "#/paylines"; };
    }
    const note = el("visLiveNote");
    if (note) note.textContent = !on ? "" : st ? `${st.short} page — shown as the build draws it; edit it in the ${st.studio}.`
      : "Pay lines page — shown as the build draws it; edit it in the Paylines studio.";
    renderLiveGuides();
  }

  /* ---------------------- canonical viewer mode ----------------------
     When the server can model the sheet (/api/layout/preview, mode
     "canonical"), the live window becomes a VIEWER of the PageLayout: every
     line start x, line height, icon box, page break, "(Continued)" block and
     heading box comes from the server (PIL-measured), identical to the PNG
     renderer. No browser re-measurement / re-wrapping happens in this mode —
     glyph painting reuses the legacy drawTextRun/drawIconElement painters.
     Sheets the canonical engine cannot model (tables, heading images, ...)
     fall back to the independent render below. */

  async function fetchCanonicalData() {
    const d = L.state.data;
    try {
      const p = await api("/api/layout/preview", {
        method: "POST",
        body: { sheet_name: (d && d.sheet_name) || "", apply_overrides: true },
      });
      L.state.canon = (p && p.ok && p.mode === "canonical" && (p.layouts || []).length) ? p : null;
    } catch (e) {
      L.state.canon = null;
    }
    // text boxes with a font of their own: loaded before the page is drawn
    const files = new Set();
    for (const lay of (L.state.canon && L.state.canon.layouts) || []) {
      // (a Game / Bingo Rules paragraph's own font too)
      for (const el2 of lay.elements || []) if ((((el2.meta || {}).kind === "box") || (el2.meta || {}).rules) && el2.meta.font_file) files.add(el2.meta.font_file);
    }
    await Promise.all([...files].map(loadBoxFont));
  }

  /* a text box's own font: a face per font file ("visX1", "visX2"…), the paragraph's until it loads */
  const boxFaces = {};
  function boxFamily(file) {
    const f = file && boxFaces[file];
    return f && f.ready ? f.family : "visB";
  }
  function loadBoxFont(file) {
    if (!file || boxFaces[file]) return (boxFaces[file] && boxFaces[file].job) || Promise.resolve();
    const family = "visX" + (Object.keys(boxFaces).length + 1);
    const entry = boxFaces[file] = { family, ready: false, job: null };
    try {
      const ff = new FontFace(family, "url(/api/font_file?file=" + encodeURIComponent(file) + ")");
      entry.job = ff.load().then((f) => { document.fonts.add(f); entry.ready = true; }, () => { /* the paragraph's font */ });
    } catch (e) { entry.job = Promise.resolve(); }
    return entry.job;
  }

  /* server line x for one wrapped line (identical to png_builder._draw_inline
     align math: x + max(0, (box_width - line_width) / 2) for center, ...). */
  function canonicalLineX(blockX, blockW, lineW, align, trkPx) {
    const w = Math.max(0, Number(lineW) || 0), t = Number(trkPx) || 0;
    if (align === "left" || String(align).startsWith("justify")) return blockX;   // justified: words pre-spread
    // a tracked line: Photoshop centres / right-aligns it two tracking steps narrower (png_builder._align_tracking)
    if (align === "right") return blockX + Math.max(0, blockW - w) + 2 * t;
    return blockX + Math.max(0, (blockW - w) / 2) + t;
  }
  // a line's tracking in px (its own, else its family's), widened by the heading's width scale
  function alignTrackPx(family, size, trk) {
    const t = trk != null ? Number(trk) || 0 : familyTracking(family);
    const sh = famShape(family);
    return t ? size * t / 1000 * (sh ? sh.hs : 1) : 0;
  }

  function buildPagesCanonical() {
    const d = L.state.data;
    if (!d) return;
    const s = mergedSettings();
    L.state.settings = s;
    L.state.canonActive = true;
    const layouts = L.state.canon.layouts;
    const pages = [];
    for (let pi = 0; pi < layouts.length; pi++) {
      const lay = layouts[pi];
      const safeArea = lay.safe_area || {};
      const cur = { index: pi, elements: [] };
      for (const raw of lay.elements || []) {
        if ((raw.type || "element") !== "text") {
          if (raw.type === "table") {
            // a table (or one part of a cut table) where the layout placed it in the paragraph's flow —
            // the same element the legacy layout makes (placeTable), so moving, ✂, parts and boxes work
            const m = raw.meta || {};
            const tEl = {
              id: m.jsid || raw.id, kind: "table", x: Number(raw.x) || 0, y: Number(raw.y) || 0,
              w: Math.max(1, Number(raw.width) || 1), h: Math.max(1, Number(raw.height) || 1),
              url: m.url || "", token: "", parts: null, fullH: Number(raw.height) || 0,
              geoGap: Number((m.geo || {}).row_gap) || 0, row_start: m.row_start, design_key: m.design_key || "",
              design: m.design || "current", geo: m.geo || null, texts: m.texts || [], cut: m.cut || null,
              atTop: !!m.at_top, canonical: true,
            };
            applyOverride(tEl);
            cur.elements.push(tEl);
            loadStrip(tEl.url);
            continue;
          }
          if (raw.type === "image") {
            // a picture drawn as it is: a Game / Bingo Rules page's separator, strips and XTRAA REELS
            // icons, from its own renderer (rules_layout.py) — under the text
            const url = (raw.meta || {}).url || "";
            cur.elements.push({ id: raw.id || ("picture." + pi), kind: "picture", url, x: Number(raw.x) || 0, y: Number(raw.y) || 0,
              w: Math.max(1, Number(raw.width) || 1), h: Math.max(1, Number(raw.height) || 1), ov: {}, rot: 0, canonical: true });
            applyOverride(cur.elements[cur.elements.length - 1]);
            loadStrip(url);
            continue;
          }
          if (raw.type === "rect") {
            const rw = Math.max(0, Number(raw.width) || 0);
            const rh = Math.max(0, Number(raw.height) || 0);
            cur.elements.push({
              id: raw.id || ("rect." + pi), kind: "rect",
              x: raw.x, y: raw.y, w: rw, h: rh,
              ov: {}, rot: 0, opacity: Math.round((raw.opacity != null ? raw.opacity : 1) * 100),
              fill_rgb: raw.fill_rgb, fill_opacity: raw.fill_opacity != null ? raw.fill_opacity : 1,
              stroke_rgb: raw.stroke_rgb, stroke_width: raw.stroke_width || 0,
              radius: raw.meta && raw.meta.strip ? Number(raw.meta.radius) || 0 : 0,
              look: raw.meta && raw.meta.strip ? raw.meta.look || { radius: Number(raw.meta.radius) || 0 } : null,
              // the heading's plate: what it is and the text its margins are from (its handles, typo-preview)
              meta: raw.meta && raw.meta.plate ? { plate: raw.meta.plate, text_box: raw.meta.text_box } : undefined,
              canonical: true,
            });
            applyOverride(cur.elements[cur.elements.length - 1]);
          }
          continue;
        }
        const metaKind = (raw.meta || {}).kind;
        const isHeading = metaKind === "heading" || metaKind === "continued";
        const lines = raw.wrapped_lines || [];
        if (!lines.length) continue;
        const lineHs = raw.line_heights || [];
        const lineWs = raw.line_widths || [];
        const lineRuns = raw.line_runs || [];
        const spacing = Math.max(0, Math.round(raw.line_spacing || 0));
        const blockX = Number(raw.x) || 0;
        const blockY = Number(raw.y) || 0;
        const blockW = Math.max(1, Number(raw.width) || 1);
        const align = raw.align || "center";
        const color = Array.isArray(raw.color) && raw.color.length >= 3 ? raw.color : [255, 255, 255];
        const lineTops = [];
        {
          let acc = blockY;
          for (let li = 0; li < lines.length; li++) {
            lineTops.push(acc);
            acc += (lineHs[li] || 0) + (isHeading ? (li < lines.length - 1 ? spacing : 0) : spacing);
          }
        }
        if (isHeading) {
          const hEl = {
            id: raw.id || ("heading." + pi), kind: "heading",
            x: blockX, y: blockY, w: blockW, h: Math.max(0, Number(raw.height) || 0),
            ov: {}, rot: 0, sx: 1, sy: 1,
            opacity: Math.round((raw.opacity != null ? raw.opacity : 1) * 100),
            family: metaKind === "heading" ? "visH" : contFamily(), size: Math.max(1, Math.round(raw.size || s.h_size || 1)),
            iconH: Math.max(1, Math.round(raw.icon_height || s.h_size || 1)),
            lines: lines, lineHs: lineHs, lineWs: lineWs, runs: lineRuns,
            lineTops: lineTops, lineXs: [], align: align,
            rgb: color, fx: raw.effects || null,
            binds: { size: "h_size" },
            role: metaKind === "heading" ? "heading" : "continued",
            // a rules page's heading: its renderer's letter spacing (rules_layout.py)
            trk: L.state.canon.rules || L.state.canon.paylines ? Number((raw.meta || {}).tracking) || 0 : null,
            canonical: true,
          };
          applyOverride(hEl);
          let cminX = Infinity, cmaxX = -Infinity;
          for (let li = 0; li < lines.length; li++) {
            const x0 = canonicalLineX(blockX, blockW, lineWs[li], align, alignTrackPx(hEl.family, hEl.size, hEl.trk));
            hEl.lineXs.push(x0);
            cminX = Math.min(cminX, x0);
            cmaxX = Math.max(cmaxX, x0 + (lineWs[li] || 0));
          }
          if (isFinite(cminX) && isFinite(cmaxX)) {
            hEl.cbox = { x: cminX, y: blockY, w: cmaxX - cminX, h: hEl.base.h, cx: (cminX + cmaxX) / 2, cy: blockY + hEl.base.h / 2 };
          }
          cur.elements.push(hEl);
          for (let li = 0; li < lines.length; li++) {
            pushCanonicalIcons(cur, hEl, lineRuns[li] || [], "heading", li, lineTops[li]);
          }
          continue;
        }
        // body: one element per wrapped line (the engine may batch a whole row);
        // a text box (page_boxes): its lines, each knowing its box (boxId, boxFrame)
        const metaLine = (raw.meta || {}).line;
        const lineIdxBase = metaLine != null ? (Number(metaLine) - 1) : 0;
        const box = metaKind === "box" ? String((raw.meta || {}).box || "") : null;
        // a Game / Bingo Rules line: its Excel cell is its key ("cell:B7" — text_edits / icon_scales "B7")
        const cell = (raw.meta || {}).rules && (raw.meta || {}).cell ? String(raw.meta.cell) : null;
        const rowKey = box != null ? "box:" + box : cell != null ? "cell:" + cell : (raw.meta || {}).row != null ? String((raw.meta || {}).row) : "" + pi;
        // a box's lines come one element each (laid out like the paragraph's rows): the box's own frame rides on them
        const fr = (raw.meta || {}).frame;
        const boxFrame = box == null ? null : fr ? { x: Number(fr.x), y: Number(fr.y), w: Number(fr.w), h: Math.max(1, Number(fr.h) || 0) }
          : { x: blockX, y: blockY, w: blockW, h: Math.max(Number(raw.height) || 0, 1) };
        for (let li = 0; li < lines.length; li++) {
          const lh = Math.max(1, Math.round(lineHs[li] || raw.height || 1));
          const lineW = Math.max(0, Number(lineWs[li]) || 0);
          const lFam = (box != null && !(raw.meta || {}).role) || cell != null ? boxFamily((raw.meta || {}).font_file) : rowRoleFamily((raw.meta || {}).role);
          const x0 = canonicalLineX(blockX, blockW, lineW, align,
                                    alignTrackPx(lFam, Math.max(1, Math.round(raw.size || s.b_size || 1)), (raw.meta || {}).tracking));
          const lineEl = {
            id: (raw.id || ("line." + rowKey)) + (box != null && lines.length > 1 ? "." + li : raw.id ? "" : "." + li),
            kind: "line", x: blockX, y: lineTops[li], w: blockW, h: lh,
            ov: {}, rot: 0, sx: 1, sy: 1,
            opacity: Math.round((raw.opacity != null ? raw.opacity : 1) * 100),
            family: (box != null && !(raw.meta || {}).role) || cell != null ? boxFamily((raw.meta || {}).font_file) : rowRoleFamily((raw.meta || {}).role),
            size: Math.max(1, Math.round(raw.size || s.b_size || 1)),
            boxId: box, boxFrame, meta: raw.meta || {}, cell, rules: cell != null ? String(raw.meta.rules) : null,
            iconH: Math.max(1, Math.round(raw.icon_height || s.b_icon_h || 1)),
            text: lines[li], rowText: String(raw.text || lines[li] || ""), lineW: lineW, x0: x0, align: align,
            runs: [lineRuns[li] || []], lineTops: [lineTops[li]],
            lineHs: [lh], lineWs: [lineW],
            cbox: { x: x0, y: lineTops[li], w: lineW, h: lh, cx: x0 + lineW / 2, cy: lineTops[li] + lh / 2 },
            rgb: color, fx: raw.effects || null,
            binds: { size: "b_size" },
            role: box != null ? "box" : "body", row: rowKey, lineIdx: lineIdxBase + li,
            canonical: true,
          };
          applyOverride(lineEl);
          cur.elements.push(lineEl);
          pushCanonicalIcons(cur, lineEl, lineRuns[li] || [], rowKey, lineIdxBase + li, lineTops[li]);
        }
      }
      pages.push(cur);
    }
    const lay0 = layouts[0] || {};
    const safe0 = lay0.safe_area || {};
    const safeBottom = safe0.bottom != null ? safe0.bottom : (d.canvas_h - Math.max(0, Math.round(Number(s.bottom_margin) || 0)));
    L.state.safe = {
      left: safe0.left != null ? safe0.left : Math.max(0, Math.round(Number(s.margin_x) || 0)),
      width: safe0.width || Math.max(1, d.canvas_w - 2 * Math.max(0, Math.round(Number(s.margin_x) || 0))),
      bottom: safeBottom,
    };
    const headingRaw = (lay0.elements || []).find((el) => el.type === "text" && (el.meta || {}).kind === "heading");
    L.state.headingH = headingRaw ? Math.max(0, Number(headingRaw.height) || 0) : 0;
    L.state.continuedH = 0;
    L.state.overflow = 0;
    L.state.pages = pages;
    if (L.state.page >= pages.length) L.state.page = Math.max(0, pages.length - 1);
    L.state.elements = pages[L.state.page].elements;
  }

  /* body/heading icon hit targets in canonical mode: the server line_runs
     carry PIL-computed boxes; the element ids and override handling stay
     identical to the legacy pipeline. */
  function pushCanonicalIcons(pageElems, parent, runs, role, lineIdx, lineTop) {
    let runIdx = 0;
    for (const r of runs || []) {
      if (r.kind !== "icon") continue;
      const token = String(r.token || "");
      const iconId = "icon." + normToken(token) + "." + role + "." + lineIdx + "." + runIdx;
      const rx = (parent.x0 != null ? parent.x0 : (parent.lineXs && parent.lineXs[lineIdx] != null ? parent.lineXs[lineIdx] : parent.base.x)) + (Number(r.x) || 0);
      const ry = lineTop + (Number(r.y) || 0);
      const iw = Math.max(1, Math.round(Number(r.w) || 1));
      const ih = Math.max(1, Math.round(Number(r.h) || 1));
      const iconEl = {
        id: iconId, kind: "icon", token: token,
        x: rx, y: ry, w: iw, h: ih,
        ov: {}, rot: 0, row: parent.row, cell: parent.cell || null, lineIdx: lineIdx, runIdx: runIdx,
        binds: { size: "__icon__" }, role: role,
        canonical: true,
      };
      // Links e.ov to L.state.overrides[id] (live transforms persist) and
      // applies saved sx/sy/rot/opacity -- same contract as the legacy build.
      applyOverride(iconEl);
      pageElems.elements.push(iconEl);
      runIdx++;
    }
  }

  /* ------------------------------ drawing ------------------------------ */

  const fxSpriteCache = {};

  function fxSpriteKey(text, family, size, rgb, fx) {
    // "visH"/"visB" are fixed aliases whose font FILE changes with h_font /
    // b_font: key on the file too, or a sprite drawn with the old font is reused.
    const face = (L.state._fontFaces || {})[family];
    // ...and on the project's Global Light: "Use Global Light" shadows turn with it (ps_fx_canvas.js)
    const light = ((App.state.config || {}).dynamic_settings || {}).fx_global_light || null;
    return [text, family, face ? face.file : "", size, rgb.join(","), JSON.stringify(fx || null), JSON.stringify(light),
            L.state.faceOverride || "", L.state.trackOverride != null ? L.state.trackOverride : "",
            JSON.stringify(famShape(family))].join("|");
  }

  function rememberFxSprite(key, spr) {
    // bounded: typing in a styled heading would otherwise keep every keystroke's sprite
    const keys = Object.keys(fxSpriteCache);
    if (keys.length >= 400) keys.slice(0, 100).forEach((k) => { delete fxSpriteCache[k]; });
    fxSpriteCache[key] = spr;
  }

  /* ---------------------------------------------------------------------
   * Photoshop layer-style preview: static/ps_fx_canvas.js (window.PsFx), a
   * 1:1 port of ps_fx_png.py. Every effect renders here without Photoshop:
   * multiple drop shadows / strokes (solid or gradient), outer & inner glow,
   * inner shadow, colour & gradient overlays, satin, bevel & emboss. The
   * server decodes captured_effects_hex into captured_params
   * (fx_descriptor.enrich_style), so the full style arrives readable. The
   * glyphs are drawn once into a padded sprite and PsFx styles its pixels.
   * ------------------------------------------------------------------- */

  function normalizeFx(raw) {
    if (!window.PsFx) return { hasFx: false };
    const N = window.PsFx.normalize(raw);
    N.hasFx = N.has_fx;
    return N;
  }

  function buildFxSprite(text, m, family, size, rgb, fx) {
    if (!window.PsFx) return null;
    // the effects at this text size (fx_scale.py), as the build draws them
    const N = window.PsFx.normalize(window.PsFx.scaleFor ? window.PsFx.scaleFor(fx, size) : fx);
    if (!N.has_fx) return null;
    const pad = window.PsFx.effectPad(N);
    const w = Math.max(1, Math.ceil(m.w + pad * 2));
    const h = Math.max(1, Math.ceil(m.h + pad * 2));
    const spr = document.createElement("canvas");
    spr.width = w; spr.height = h;
    const c = spr.getContext("2d", { willReadFrequently: true });
    if (!c) return null;
    // the glyphs drawn twice as big and scaled down: Chrome's canvas text at 1× is ~1.5% heavier at
    // the edges than Photoshop / the build (tools/ps_text_roundtrip.py); at 2× it matches them
    const ss = w * h <= 8e6 ? 2 : 1;
    const g = ss > 1 ? document.createElement("canvas") : spr;
    if (ss > 1) { g.width = w * ss; g.height = h * ss; }
    const gc = ss > 1 ? g.getContext("2d") : c;
    if (ss > 1) gc.scale(ss, ss);
    setFont(gc, family, size);
    gc.textAlign = "left";
    gc.textBaseline = "alphabetic";
    gc.fillStyle = rgba(rgb, 1);
    fillShaped(gc, text, pad, pad + m.ascent, family);
    if (ss > 1) {
      c.imageSmoothingEnabled = true;
      c.imageSmoothingQuality = "high";
      c.drawImage(g, 0, 0, w, h);
    }
    c.putImageData(window.PsFx.renderImageData(c.getImageData(0, 0, w, h), N), 0, 0);
    spr.pad = pad;
    return spr;
  }

  /* background fill modes, same as png_builder._paint_background */
  /* where the background picture goes — bg_place.py's rule (the build, thumbnails, Photoshop):
     cover / stretch / fit / center / tile / "fit_width:top|center|bottom" / "place:x,y,w,h" (a PSD's) */
  function bgSpec(s) {
    const c = (typeof App !== "undefined" && App.state && App.state.config) || null;
    if (!c) return String(s.bg_mode || "cover");
    let mode = String(c.bg_mode || "cover").toLowerCase();
    if (mode === "fill") mode = "cover";
    if (mode === "fit_width") {
      const a = String(c.bg_anchor || "center").toLowerCase();
      return "fit_width:" + (["top", "center", "bottom"].includes(a) ? a : "center");
    }
    if (mode === "place") {
      const r = bgRect(c.bg_rect);
      return r ? "place:" + r.map((v) => Math.round(v)).join(",") : "cover";
    }
    return mode;
  }
  function bgRect(v) {
    const r = (Array.isArray(v) ? v : String(v || "").split(",")).map(Number);
    return r.length === 4 && r.every(isFinite) && r[2] > 0 && r[3] > 0 ? r : null;
  }
  function bgDest(spec, W, H, iw, ih) {
    const [name, arg] = String(spec || "cover").split(":");
    const mode = String(name || "cover").toLowerCase();
    if (mode === "place") { const r = bgRect(arg); if (r) return r; }
    if (mode === "fit_width") {
      const h = ih * W / iw, a = String(arg || "center").toLowerCase();
      return [0, a === "top" ? 0 : a === "bottom" ? H - h : (H - h) / 2, W, h];
    }
    if (mode === "fit") { const k = Math.min(W / iw, H / ih); return [(W - iw * k) / 2, (H - ih * k) / 2, iw * k, ih * k]; }
    if (mode === "center") return [(W - iw) / 2, (H - ih) / 2, iw, ih];
    if (mode === "cover" || mode === "place") { const k = Math.max(W / iw, H / ih); return [(W - iw * k) / 2, (H - ih * k) / 2, iw * k, ih * k]; }
    return [0, 0, W, H];
  }
  function drawBackgroundImage(ctx, img, W, H, spec) {
    const iw = img.naturalWidth || img.width, ih = img.naturalHeight || img.height;
    if (!iw || !ih) return;
    const mode = String(spec || "cover").split(":")[0].toLowerCase();
    if (mode === "tile") {
      for (let y = 0; y < H; y += ih) for (let x = 0; x < W; x += iw) ctx.drawImage(img, x, y);
      return;
    }
    const [x, y, w, h] = bgDest(spec, W, H, iw, ih);
    ctx.save();
    ctx.beginPath();
    ctx.rect(0, 0, W, H);                                   // a cover / placed picture is cut at the canvas edge
    ctx.clip();
    ctx.drawImage(img, x, y, w, h);
    ctx.restore();
  }
  L.bgSpec = bgSpec;
  L.bgDest = bgDest;

  /* a word-style run (text_styles rule): its own colour, weight, slant, family —
     drawn on the line's baseline like png_builder._draw_text_segment */
  function styledBaseline(ctx, text, y, lineH, e) {
    const base = textMetrics(ctx, e.family, e.size, text);
    return snapBaseline(y + Math.max(0, (lineH - base.h) / 2) + base.ascent);
  }
  // the size a styled run is drawn at (png_builder._styled_font: whole px)
  const styledSize = (e, st) => (st.size ? Math.max(4, Math.round(e.size * st.size / 100)) : e.size);
  function drawStyledRun(ctx, text, x, y, lineH, e, st) {
    const ty = styledBaseline(ctx, text, y, lineH, e);
    const fam = st.font ? `"${st.font}", ${e.family}` : e.family;
    const size = st.size ? e.size * st.size / 100 : e.size;       // a word bigger / smaller than its line
    const track = st.tracking != null ? st.tracking : familyTracking(e.family);
    // its own layer style, else its line's (png_builder: st.fx_config or fx_config) — a run styled only
    // by colour / font / letter spacing keeps the paragraph's layer style
    const fx = st.fx || e.fx;
    if (fx) {                                                       // same engine as the PNG
      const prev = L.state.trackOverride, prevFace = L.state.faceOverride;
      L.state.trackOverride = track;
      L.state.faceOverride = `${st.italic ? "italic " : ""}${st.bold ? "bold" : ""}`.trim();
      try { drawTextRun(ctx, text, x, y, lineH, fam, size, st.rgb || e.rgb, fx); } finally { L.state.trackOverride = prev; L.state.faceOverride = prevFace; }
      return;
    }
    ctx.font = `${st.italic ? "italic " : ""}${st.bold ? "bold " : ""}${size}px ${fam}, Arial, sans-serif`;
    psText(ctx);
    const shK = famShape(fam);
    if (shK && !shK.kern && "fontKerning" in ctx) ctx.fontKerning = "none";
    if ("letterSpacing" in ctx) ctx.letterSpacing = (track ? styledSize(e, st) * track / 1000 : 0) + "px";
    ctx.textAlign = "left";
    ctx.textBaseline = "alphabetic";
    ctx.fillStyle = rgba(st.rgb || e.rgb, 1);
    fillShaped(ctx, text, x, ty, fam);
  }
  /* the strip behind selected words — png_builder._draw_word_bg: from just above the capitals to just
     below the baseline at the run's size, plus padding, rounded (text_styles.draw_strip) */
  function drawWordBg(ctx, bg, x, baseline, w, size) {
    if (!bg || !(w > 0)) return;
    const top = baseline - 0.85 * size - bg.pad_y, bottom = baseline + 0.25 * size + bg.pad_y;
    const L0 = Math.round(x - bg.pad_x), T0 = Math.round(top), W = Math.round(w + 2 * bg.pad_x), H = Math.round(Math.max(0, bottom - top));
    if (W <= 0 || H <= 0) return;
    const c = bg.rgba || [30, 58, 138, 217];
    drawStripShape(ctx, c.slice(0, 3), (c[3] == null ? 255 : c[3]) / 255, L0, T0, W, H, bg);
  }

  /* a strip as its shape — psd_writer.shapes.render + paytable_box.draw: the border fills the outer
     outline, the strip's colour the inside, the opacity is the layer's Fill (its layer style keeps
     full strength). Drawn once into a sprite, remembered by look and size. */
  const STRIP_SPRITES = new Map();
  function drawStripShape(ctx, rgb, alpha, x, y, w, h, look) {
    look = look || {};
    if (!(w >= 1) || !(h >= 1)) return;
    const bd = look.border, sw = bd ? Number(bd.width) || 0 : 0;
    const grow = !sw ? 0 : bd.align === "outside" ? sw : bd.align === "center" ? sw / 2 : 0;
    const fx = look._fx && window.PsFx ? look._fx : null;
    const key = JSON.stringify([w, h, rgb, alpha, look.radius, look.radii, bd, fx ? look.fx : "", fx && look.fx === "inline" ? fx : "",
      look.corner, look.corners, look.fill_to, look.gradient_dir]);
    let spr = STRIP_SPRITES.get(key);
    if (!spr) {
      const N = fx ? window.PsFx.normalize(Object.assign({}, fx, { fill_opacity: alpha * 100 * (fx.fill_opacity != null ? Number(fx.fill_opacity) / 100 : 1) })) : null;
      const pad = Math.ceil(grow) + (N && N.has_fx ? window.PsFx.effectPad(N) : 0);
      spr = document.createElement("canvas");
      spr.width = Math.ceil(w + 2 * pad); spr.height = Math.ceil(h + 2 * pad);
      const c = spr.getContext("2d", { willReadFrequently: !!N });
      const r4 = Array.isArray(look.radii) ? look.radii : [0, 1, 2, 3].map(() => Number(look.radius) || 0);
      const shape = (inset) => {
        const W = w + 2 * grow - 2 * inset, H = h + 2 * grow - 2 * inset;
        if (W <= 0 || H <= 0) return false;
        const rs = r4.map((r) => Math.max(0, Math.min(Number(r) + grow - inset, W / 2, H / 2, Math.min(w, h) / 2 + grow - inset)));
        c.beginPath();
        if (c.roundRect) c.roundRect(pad - grow + inset, pad - grow + inset, W, H, rs); else c.rect(pad - grow + inset, pad - grow + inset, W, H);
        return true;
      };
      const card = (look.corner || look.corners || look.fill_to) && window.PCLive && PCLive.drawShape;
      if (card) {
        // a card look on the strip (corner shapes, a gradient): the paytable's own shape drawing (= the build's)
        PCLive.drawShape(c, { radius: Number(look.radius) || 0, radii: look.radii, corner: look.corner, corners: look.corners,
          fill: "#" + rgb.map((v) => Number(v).toString(16).padStart(2, "0")).join(""), fill_opacity: 100, fill_to: look.fill_to,
          gradient_dir: look.gradient_dir, stroke: bd && sw > 0 ? { enabled: true, width: sw, color: bd.color, opacity: bd.opacity, align: bd.align } : { enabled: false } },
          [pad, pad, w, h]);
      } else {
        if (sw > 0 && shape(0)) {
          c.fillStyle = `rgba(${hexRgb(bd.color).join(",")},${(Number(bd.opacity == null ? 100 : bd.opacity)) / 100})`;
          c.fill();
          if (shape(sw)) { c.save(); c.clip(); c.clearRect(0, 0, spr.width, spr.height); c.restore(); }
        }
        if (shape(sw)) { c.fillStyle = `rgb(${rgb[0]},${rgb[1]},${rgb[2]})`; c.fill(); }
      }
      if (N && N.has_fx) c.putImageData(window.PsFx.renderImageData(c.getImageData(0, 0, spr.width, spr.height), N), 0, 0);
      spr.pad = pad;
      spr.styled = !!(N && N.has_fx);
      if (STRIP_SPRITES.size > 64) STRIP_SPRITES.clear();
      STRIP_SPRITES.set(key, spr);
    }
    ctx.save();
    if (!spr.styled) ctx.globalAlpha *= Math.max(0, Math.min(1, alpha));
    smoothShrink(ctx);
    ctx.drawImage(spr, x - spr.pad, y - spr.pad);
    ctx.restore();
  }
  function hexRgb(v) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(v || ""));
    if (!m) return [255, 255, 255];
    const n = parseInt(m[1], 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }


  /* ------------------------------ word styles & line strips ------------------------------ */
  /* Floating bar on the selected text row (Text Edit mode): its strip and the rules on it.
     Double-clicking the row selects text like a document to style single words (TextSelect,
     typo-preview.js). Rules match TEXT (text_styles.py), so they survive Excel updates and
     carry to every market: "word Extra -> red bold" and "line starting with Note: -> blue strip". */

  const SB = { key: "", words: [] };

  function styleRules() {
    const ds = (App.state.config.dynamic_settings = App.state.config.dynamic_settings || {});
    ds.text_style_rules = Array.isArray(ds.text_style_rules) ? ds.text_style_rules : [];
    return ds.text_style_rules;
  }

  function selectedTextRow() {
    if (L.state.editMode === "icon" || !L.state.selected) return null;
    const e = elementAtId(L.state.selected);
    if (!e || (e.kind !== "line" && e.kind !== "heading")) return null;
    return e;
  }

  function syncStyleBar() {
    const host = L.state.barHost || el("visLiveHost");       // the Typography preview borrows the bar
    if (!host) return;
    // a table clicked in the Visualiser: its own bar (design, text, split across pages)
    if (!L.state.barHost) {
      const sel = L.state.selected && L.state.editMode !== "icon" ? elementAtId(L.state.selected) : null;
      if (sel && sel.kind === "table" && sel.design_key && !L.state.drag) {
        if (L.state.tableBarFor !== sel.id) {
          L.state.tableBarFor = sel.id;
          showTableBar(host, el("visLiveCanvas"), sel, null, () => { L.state.tableBarFor = null; L.state.selected = null; draw(); });
        }
      } else if (L.state.tableBarFor) {
        L.state.tableBarFor = null;
        hideTableBar();
      }
    }
    let bar = el("visStyleBar");
    const e = selectedTextRow();
    if (!e || L.state.drag) { if (bar) bar.style.display = "none"; return; }
    if (!bar) {
      bar = document.createElement("div");
      bar.id = "visStyleBar";
      bar.className = "vis-style-bar";
      bar.addEventListener("pointerdown", (ev) => ev.stopPropagation());
      host.appendChild(bar);
    }
    const rowText = String(e.rowText || e.text || (e.lines || []).join(" ") || "");
    const key = e.id + "|" + rowText;
    if (SB.key !== key) {
      SB.key = key;
      SB.words = rowText.split(/\s+/).filter(Boolean);
      renderStyleBar(bar, e, rowText);
    }
    // place it just above the selected row (below when there's no room)
    const canvas = L.state.barCanvas || el("visLiveCanvas");
    const cr = canvas.getBoundingClientRect(), hr = host.getBoundingClientRect();
    const k = cr.width / (L.state.data ? L.state.data.canvas_w : 1920);
    const top = cr.top - hr.top + e.y * k;
    bar.style.display = "";
    const h = bar.offsetHeight || 120;
    const below = cr.top - hr.top + (e.y + e.h) * k + 10;
    bar.style.top = (top - h - 10 >= 4 ? top - h - 10 : Math.min(below, Math.max(4, hr.height - h - 4))) + "px";
    bar.style.left = Math.max(4, Math.min(hr.width - bar.offsetWidth - 4, cr.left - hr.left + (e.x + e.w / 2) * k - bar.offsetWidth / 2)) + "px";
  }

  function renderStyleBar(bar, e, rowText) {
    const rules = styleRules();
    const sheet = L.state.sheet || "";
    const norm = (t) => String(t || "").replace(/<([^<>]*?)(?:~\d+(?:\.\d+)?(?:\^[\d.]+,[\d.]+)?|\^[\d.]+,[\d.]+)\s*>/g, "<$1>").replace(/\s+/g, " ").trim().toLowerCase();
    const applies = rules.map((r, i) => ({ r, i })).filter(({ r }) =>
      (r.scope !== "page" || norm(r.sheet) === norm(sheet)) &&
      (r.kind === "word" ? norm(rowText).includes(norm(r.text))
        : (r.match === "exact" ? norm(rowText) === norm(r.text) : r.match === "contains" ? norm(rowText).includes(norm(r.text)) : norm(rowText).startsWith(norm(r.text)))));
    const strip = applies.find(({ r }) => r.kind === "strip");
    const lead = SB.words.slice(0, 2).join(" ");
    const short = rowText.length > 48 ? rowText.slice(0, 48) + "…" : rowText;
    // single words are styled by double-clicking the row (text selection, like a document)
    bar.innerHTML = `
      <div class="vsb-head"><b>This row</b><span class="vsb-hint">double-click it to style single words</span>
        <button class="vsb-x" title="Close" data-act="close">✕</button></div>
      <div class="vsb-row"><span class="vsb-sel" title="${esc(rowText)}">“${esc(short)}”</span></div>
      <div class="vsb-row">
        <b class="vsb-lab">Strip behind</b>
        <input type="color" id="vsbStrip" value="${esc((strip && strip.r.color) || "#1e5aa8")}" title="Strip colour">
        <input type="range" id="vsbOpacity" min="10" max="100" value="${Math.round(((strip && strip.r.opacity) || 0.85) * 100)}" title="Strip opacity">
        <label class="vsb-scope" title="Text colour on the strip"><input type="checkbox" id="vsbTextOn" ${strip && strip.r.text_color ? "checked" : ""}> text
          <input type="color" id="vsbTextColor" value="${esc((strip && strip.r.text_color) || "#ffffff")}"></label>
        <select id="vsbMatch" title="Which lines get the strip">
          <option value="exact">this line</option>
          <option value="starts">every line starting “${esc(lead)}”</option>
        </select>
        <button class="pt-btn secondary small" data-act="strip">${strip ? "Update strip" : "Add strip"}</button>
      </div>
      <div class="vsb-row">
        <span class="vsb-lab" title="How wide the strip is (centred on the text area)">Width</span>
        <input type="range" id="vsbWidth" min="5" max="100" value="${Math.round((strip && strip.r.width_pct) || 100)}" ${strip && strip.r.full_width === false ? "disabled" : ""}>
        <span class="vsb-val" id="vsbWidthVal">${Math.round((strip && strip.r.width_pct) || 100)}%</span>
        <label class="vsb-scope" title="Hug the words instead of the text area"><input type="checkbox" id="vsbFit" ${strip && strip.r.full_width === false ? "checked" : ""}> fit text</label>
        <span class="vsb-lab" title="The strip's height — slide left to make it thinner than the text, down to 0 px">Height</span>
        <input type="range" id="vsbHeight" min="${-Math.ceil(stripRowH(e) / 2)}" max="80" value="${Math.round(strip && strip.r.pad_y != null ? strip.r.pad_y : 6)}">
        <span class="vsb-val" id="vsbHeightVal">${stripTall(e, Math.round(strip && strip.r.pad_y != null ? strip.r.pad_y : 6))}</span>
      </div>
      ${applies.length ? `<div class="vsb-rules">${applies.map(({ r, i }) => `<span class="vsb-rule" title="${r.scope === "page" ? "this page" : "whole game"}">
          ${r.kind === "word" ? `<i style="color:${esc(r.color || "#fff")};font-weight:${r.bold ? 700 : 400};font-style:${r.italic ? "italic" : "normal"}">${esc(r.text)}</i>${r.size ? ` ${Math.round(r.size)}%` : ""}${r.fx ? ` · ${esc(r.fx)}` : ""}` : `▬ strip “${esc(r.text.slice(0, 24))}${r.text.length > 24 ? "…" : ""}”`}
          <button data-act="del" data-i="${i}" title="Remove">✕</button></span>`).join("")}</div>` : ""}`;
    bar.querySelectorAll("[data-act]").forEach((b) => b.addEventListener("click", () => styleBarAction(b.dataset.act, b, bar, e, rowText)));
    // strip size: values follow the slider; an existing strip re-applies when it is let go
    const wIn = bar.querySelector("#vsbWidth"), hIn = bar.querySelector("#vsbHeight"), fit = bar.querySelector("#vsbFit");
    wIn.addEventListener("input", () => { bar.querySelector("#vsbWidthVal").textContent = wIn.value + "%"; });
    hIn.addEventListener("input", () => { bar.querySelector("#vsbHeightVal").textContent = stripTall(e, hIn.value); });
    fit.addEventListener("change", () => { wIn.disabled = fit.checked; });
    if (strip) [wIn, hIn, fit, bar.querySelector("#vsbStrip"), bar.querySelector("#vsbOpacity")].forEach((c) =>
      c.addEventListener("change", () => styleBarAction("strip", c, bar, e, rowText)));
  }

  async function styleBarAction(act, btn, bar, e, rowText) {
    const rules = styleRules();
    const sheet = L.state.sheet || "";
    const q = (id) => bar.querySelector("#" + id);
    if (act === "close") { L.state.selected = null; bar.style.display = "none"; markDirty(); return; }
    const borrowed = !!L.state.barHost;
    if (act === "del") {
      rules.splice(Number(btn.dataset.i), 1);
    } else if (act === "strip") {
      const how = q("vsbMatch").value;
      const text = how === "exact" ? rowText.replace(/\s+/g, " ").trim() : SB.words.slice(0, 2).join(" ");
      const rule = { kind: "strip", text, match: how, color: q("vsbStrip").value,
        opacity: Number(q("vsbOpacity").value) / 100, pad_x: 24, pad_y: Number(q("vsbHeight").value),
        full_width: !q("vsbFit").checked, width_pct: Number(q("vsbWidth").value), radius: 6,
        text_color: q("vsbTextOn").checked ? q("vsbTextColor").value : "", scope: "page", sheet };
      const same = rules.findIndex((r) => r.kind === "strip" && r.text.toLowerCase() === text.toLowerCase() && r.sheet === sheet);
      if (same >= 0) rules[same] = rule; else rules.push(rule);
    }
    await App.syncConfig();
    if (App._saveErr) { toast(App._saveErr, "err"); return; }
    SB.key = "";                                       // re-render the bar with the new rules
    const keep = e.id;
    if (borrowed) {                                    // Typography: its own preview redraws the page
      if (L.state.barRefresh) await L.state.barRefresh();
      if (elementAtId(keep)) { L.state.selected = keep; syncStyleBar(); draw(); }
      return;
    }
    await refreshData(true);
    if (elementAtId(keep)) L.state.selected = keep;     // the bar stays on the same row
    markDirty();
  }

  // a styled part is drawn at the page's full size, then shrunk to the zoom: the browser's default
  // "low" smoothing makes thin strokes and soft glows ragged when zoomed out — "high" keeps them
  function smoothShrink(ctx) { ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = "high"; }
  function drawTextRun(ctx, text, x, y, lineH, family, size, rgb, fx) {
    const m = textMetrics(ctx, family, size, text);
    const rawTy = y + Math.max(0, (lineH - m.h) / 2) + m.ascent;
    const ty = snapBaseline(rawTy);
    if (fx && L.state.fxEnabled !== false) {
      const key = fxSpriteKey(text, family, size, rgb, fx);
      let spr = fxSpriteCache[key];
      if (spr === undefined) {
        try {
          spr = buildFxSprite(text, m, family, size, rgb, fx);
        } catch (err) {
          console.error("[LiveFx] sprite build failed:", err);
          L.state.fxDiag = { stage: "build_error", error: String((err && err.message) || err), text: text, fx: fx };
          spr = null;
        }
        rememberFxSprite(key, spr);
      }
      if (spr) {
        const pad = spr.pad || 0;
        smoothShrink(ctx);
        const dx = x - pad, dy = y + Math.max(0, (lineH - m.h) / 2) - pad + (ty - rawTy);
        const under = blendIfUnder(fx);
        const R = under ? deviceRect(ctx, dx, dy, spr.width, spr.height) : null;
        const before = R ? grab(ctx, R) : null;
        ctx.drawImage(spr, dx, dy);
        if (before) blendIfMix(ctx, R, before, under);
        return;
      }
      if (!L.state.fxDiag) {
        // a style with no active effect ({} on body text) is simply drawn flat — not a failure
        const n = normalizeFx(fx);
        if (n.hasFx) L.state.fxDiag = { stage: "no_sprite", text: text, hasFx: true, fx: fx };
      }
    }
    ctx.fillStyle = rgba(rgb, 1);
    fillShaped(ctx, text, x, ty, family);
  }

  /* Blending Options › Blend If, "Underlying Layer" (blend_if.py): the layer shows only where the page
     under it is inside [black low, black high, white low, white high]; ramps between the split halves. */
  function blendIfUnder(fx) {
    const v = fx && fx.blend_if ? (Array.isArray(fx.blend_if) ? fx.blend_if : fx.blend_if.under) : null;
    if (!Array.isArray(v)) return null;
    let r = v.map((n) => Math.max(0, Math.min(255, Math.round(Number(n) || 0))));
    if (r.length === 2) r = [r[0], r[0], r[1], r[1]];
    if (r.length !== 4 || (r[0] === 0 && r[1] === 0 && r[2] === 255 && r[3] === 255)) return null;
    return r;
  }
  function blendIfK(g, u) {
    if (g < u[0] || g > u[3]) return 0;
    if (g < u[1]) return (g - u[0]) / (u[1] - u[0]);
    if (g > u[2]) return (u[3] - g) / (u[3] - u[2]);
    return 1;
  }
  // the device pixels a drawImage at (x, y, w, h) covers, through the zoom (getImageData ignores it)
  function deviceRect(ctx, x, y, w, h) {
    const T = ctx.getTransform();
    const x0 = Math.max(0, Math.floor(T.a * x + T.e)), y0 = Math.max(0, Math.floor(T.d * y + T.f));
    const x1 = Math.min(ctx.canvas.width, Math.ceil(T.a * (x + w) + T.e)), y1 = Math.min(ctx.canvas.height, Math.ceil(T.d * (y + h) + T.f));
    return x1 > x0 && y1 > y0 ? [x0, y0, x1 - x0, y1 - y0] : null;
  }
  function grab(ctx, R) {
    try { return ctx.getImageData(R[0], R[1], R[2], R[3]); } catch (e) { return null; }
  }
  function blendIfMix(ctx, R, before, u) {
    const after = grab(ctx, R);
    if (!after) return;
    const a = before.data, b = after.data;
    for (let i = 0; i < b.length; i += 4) {
      const al = a[i + 3] / 255;
      const k = blendIfK((a[i] * 0.3 + a[i + 1] * 0.59 + a[i + 2] * 0.11) * al, u);
      if (k >= 1) continue;
      for (let c = 0; c < 4; c++) b[i + c] = a[i + c] + (b[i + c] - a[i + c]) * k;
    }
    ctx.putImageData(after, R[0], R[1]);
  }

  function drawIcon(ctx, e) {
    const info = iconInfo(e.token);
    if (!info) return;
    ctx.drawImage(info.img, e.base.x, e.base.y, e.base.w, e.base.h);
  }

  /* draws an overridden inline icon at its FINAL transformed box (the same box
     the selection handles / clamp use), so drawing always matches the
     transform and the icon can never visually leave its row. */
  function drawIconElement(ctx, e) {
    const info = iconInfo(e.token);
    if (!info) return;
    const free = L.state.freeform;
    const b = finalBox(e);
    const x = b.x;
    const y = free ? b.y : e.base.y;
    const rot = free ? b.rot : 0;
    ctx.save();
    ctx.globalAlpha = (e.opacity != null ? e.opacity : 100) / 100;
    ctx.translate(x + b.w / 2, y + b.h / 2);
    if (rot) ctx.rotate(rot * Math.PI / 180);
    ctx.drawImage(info.img, -b.w / 2, -b.h / 2, b.w, b.h);
    ctx.restore();
  }

  /* live width of a line's parts: icons with a scale override reserve their
     TRANSFORMED width (plus the configured left/right gaps) so the text
     around them re-flows. */
  /* word styles (text_styles.py) on the browser's own pages: the server lays its own pages out with
     them already; here the same rules are matched while a row is measured, wrapped and drawn —
     exactly text_styles.word_runs: scope (game / this page / just this row), longest text first,
     whole words, case-insensitive. L.state.wsRow = the row being laid out (its text, untagged). */
  function rowKeyOf(t) {
    return String(t || "").replace(/<([^<>]*?)(?:~\d+(?:\.\d+)?(?:\^[\d.]+,[\d.]+)?|\^[\d.]+,[\d.]+)\s*>/g, "<$1>").split(/\s+/).filter(Boolean).join(" ").toLowerCase();
  }
  function setWsRow(t) {
    const text = String(t || "").replace(/<([^<>]*?)(?:~\d+(?:\.\d+)?(?:\^[\d.]+,[\d.]+)?|\^[\d.]+,[\d.]+)\s*>/g, "<$1>");
    if (text !== L.state.wsRowText || !L.state.wsLineAt) L.state.wsLineAt = new Map();   // line -> place in the row
    L.state.wsRow = rowKeyOf(t);
    L.state.wsRowText = text;
  }
  // skeleton keeping the icon tokens (text_styles._full_skeleton): "<greenbag>" tells the lines apart
  function skelFull(text) {
    text = String(text || "").replace(/<([^<>]*?)(?:~\d+(?:\.\d+)?(?:\^[\d.]+,[\d.]+)?|\^[\d.]+,[\d.]+)\s*>/g, "<$1>");
    const inside = new Array(text.length).fill(false), tok = /<[^<>]*>/g;
    let m;
    while ((m = tok.exec(text))) for (let i = m.index; i < m.index + m[0].length; i++) inside[i] = true;
    let s = "";
    const flags = [];
    for (let i = 0; i < text.length; i++) {
      if (/\s/.test(text[i])) continue;
      const low = text[i].toLowerCase();
      s += low.length === 1 ? low : text[i];
      flags.push(inside[i]);
    }
    return { s, flags };
  }
  /* where a line (or trial line) of the current row starts in the row's skeleton, or null:
     recorded by wrapInline, else the row itself, else found by its icons (text_styles._place) */
  function lineAt(text) {
    const rowText = L.state.wsRowText || "";
    if (!rowText) return null;
    if (L.state.wsLineAt && L.state.wsLineAt.has(text)) return L.state.wsLineAt.get(text);
    const sk = skel(text).s;
    if (sk && sk === skel(rowText).s) return 0;
    const full = skelFull(text), row = skelFull(rowText);
    const hits = full.s ? occurrences(row.s, full.s) : [];
    if (hits.length === 1 || (hits.length && !full.flags.some(Boolean))) return row.flags.slice(0, hits[0]).filter((f) => !f).length;
    return null;
  }
  /* one exact occurrence ("nth"): text_styles.skeleton / _nth_marks — a piece of a row is found in
     the row by its skeleton (no spaces, no <ICON> tokens, lower-cased), so wrapping never matters */
  function skel(text) {
    text = String(text || "");
    const hidden = new Array(text.length).fill(false);
    const tok = /<[^<>]*>/g;
    let m;
    while ((m = tok.exec(text))) for (let i = m.index; i < m.index + m[0].length; i++) hidden[i] = true;
    let s = "";
    const ix = [];
    for (let i = 0; i < text.length; i++) {
      const c = text[i];
      if (hidden[i] || /\s/.test(c)) continue;
      const low = c.toLowerCase();
      s += low.length === 1 ? low : c;
      ix.push(i);
    }
    return { s, ix };
  }
  function occurrences(hay, needle) {
    const out = [];
    if (!needle) return out;
    for (let i = hay.indexOf(needle); i >= 0; i = hay.indexOf(needle, i + 1)) out.push(i);
    return out;
  }
  function nthMarks(text, rules) {
    const rowText = L.state.wsRowText || "";
    const marks = new Map();
    if (!rules.length || !rowText) return marks;
    const row = skel(rowText).s, piece = skel(text);
    if (!piece.s) return marks;
    // the part being measured / drawn knows its line and where in it it is
    let start = null;
    const part = L.state.wsPart;
    if (part && part.v === text && part.src != null) {
      const at = lineAt(part.src);
      if (at != null) {
        const s = at + skel(String(part.src).slice(0, part.o || 0)).s.length;
        if (row.slice(s, s + piece.s.length) === piece.s) start = s;
      }
    }
    if (start == null) {
      const found = occurrences(row, piece.s);
      if (!found.length) return marks;
      start = found[0];
    }
    for (const r of rules) {
      const want = skel(r.text).s, hits = occurrences(row, want);
      if (!want || !(r.nth >= 0 && r.nth < hits.length)) continue;     // the text changed: that occurrence is gone
      const a = Math.max(hits[r.nth], start), b = Math.min(hits[r.nth] + want.length, start + piece.s.length);
      if (a >= b) continue;
      const first = piece.ix[a - start], last = piece.ix[b - 1 - start];
      for (let i = first; i <= last; i++) { if (!marks.has(i)) marks.set(i, []); marks.get(i).push(r.props); }   // the spaces between too
    }
    return marks;
  }
  // text_styles._EMPTY_STYLE / _props / bg_of: only what a rule sets (a selection keeps the rest)
  const EMPTY_STYLE = { rgb: null, bold: false, italic: false, font: "", size: null, fx: null, tracking: null, bg: null };
  function wordProps(r, hex, lib) {
    const p = {}, rgb = hex(r.color), font = String(r.font || "").trim(), size = Number(r.size) || 0, fx = String(r.fx || "").trim();
    if (rgb) p.rgb = rgb;
    if (r.bold) p.bold = true;
    if (r.italic) p.italic = true;
    if (font) p.font = font;
    if (size > 0 && Math.abs(size - 100) > 0.5) p.size = size;
    if (fx && lib[fx]) p.fx = lib[fx];
    if (r.tracking != null && r.tracking !== "" && isFinite(Number(r.tracking))) p.tracking = Math.max(-200, Math.min(1000, Number(r.tracking)));
    const bg = hex(r.bg);
    if (bg) {
      const num = (k, d, lo, hi) => { const v = Number(r[k] == null || r[k] === "" ? d : r[k]); return isFinite(v) ? Math.max(lo, Math.min(hi, v)) : d; };
      p.bg = Object.assign(stripLook(r, "bg_", 4, lib), { rgba: bg.concat([Math.round(num("bg_opacity", 1, 0, 1) * 255)]),
               pad_x: num("bg_pad_x", 6, 0, 200), pad_y: num("bg_pad_y", 2, -100, 200) });
    }
    return p;
  }
  function wordRules() {
    const ds = App.state.config.dynamic_settings || {};
    const raw = Array.isArray(ds.text_style_rules) ? ds.text_style_rules : [];
    const lib = ds.layer_style_library || {};
    const sheet = String((L.state.data && L.state.data.sheet_name) || "").trim().toLowerCase();
    const sig = JSON.stringify(raw) + "|" + sheet + "|" + Object.keys(lib).join(",");
    if (L.state._ws && L.state._ws.sig === sig) return L.state._ws.rules;
    const hex = (v) => {
      let h = String(v || "").trim().replace(/^#/, "");
      if (h.length === 3) h = h.split("").map((c) => c + c).join("");
      return /^[0-9a-f]{6}$/i.test(h) ? [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16)) : null;
    };
    const rules = raw.filter((r) => r && String(r.kind || "word").toLowerCase() === "word" && String(r.text || "").trim())
      .filter((r) => {
        const sc = String(r.scope || "game").toLowerCase();
        return !(sc === "page" || sc === "row") || String(r.sheet || "").trim().toLowerCase() === sheet;   // "starts": every sheet
      })
      .map((r, idx) => {
        const text = String(r.text).trim();
        let body = text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&").replace(/ /g, "\\s+");
        if (r.whole_word !== false) body = "(?<![^\\W_])" + body + "(?![^\\W_])";
        const nth = r.nth == null || r.nth === "" ? null : Number(r.nth);
        const props = wordProps(r, hex, lib);
        return {
          idx, len: text.length, re: new RegExp(body, r.case ? "g" : "gi"), text, nth: Number.isInteger(nth) ? nth : null,
          row: String(r.scope || "game").toLowerCase() === "row" ? rowKeyOf(r.row_text) : null,
          starts: String(r.scope || "").toLowerCase() === "starts" ? String(r.starts || "").toLowerCase().split(/\s+/).filter(Boolean) : null,
          whole: !!r.whole_row,
          props, st: Object.assign({}, EMPTY_STYLE, props),
        };
      })
      .sort((a, b) => b.len - a.len || a.idx - b.idx);
    L.state._ws = { sig, rules };
    return rules;
  }
  // [[segment, style | null], …] for one piece of a row's text; null when no rule touches it
  function wordRuns(text) {
    text = String(text || "");
    const row = L.state.wsRow || "";
    // "starts" rules: rows beginning with their words (a number for any number) — text_styles.starts_with
    const NUM = /^[$€£]?\d[\d,.]*[%x]?[,.:;]?$/i, rw = row.split(" ");
    const startsOk = (w) => rw.length >= w.length && w.every((x, i) => x === rw[i] || (NUM.test(x) && NUM.test(rw[i])));
    const every = wordRules().filter((r) => (r.row == null || r.row === row) && (!r.starts || startsOk(r.starts)));
    if (!every.length || !text.trim()) return null;
    const taken = new Array(text.length).fill(null);
    for (const r of every) {
      if (r.nth != null) continue;
      if (r.whole) {                                       // the whole row ("starts", whole_row)
        for (let i = 0; i < text.length; i++) if (!taken[i] && /\S/.test(text[i])) taken[i] = r.st;
        for (let i = 1; i < text.length - 1; i++) if (!taken[i] && taken[i - 1] === r.st && taken.slice(i + 1).some((x) => x === r.st)) taken[i] = r.st;
        continue;
      }
      r.re.lastIndex = 0;
      let m;
      while ((m = r.re.exec(text))) {
        if (!m[0].length) { r.re.lastIndex++; continue; }
        let free = true;
        for (let i = m.index; i < m.index + m[0].length; i++) if (taken[i]) { free = false; break; }
        if (free) for (let i = m.index; i < m.index + m[0].length; i++) taken[i] = r.st;
      }
    }
    // a selection's rules add what they set on top, the later rule last (one object per look)
    const exact = every.filter((r) => r.nth != null).sort((a, b) => a.idx - b.idx), merged = new Map(), ids = new Map();
    const idOf = (o) => { if (!ids.has(o)) ids.set(o, ids.size); return ids.get(o); };
    for (const [i, layers] of nthMarks(text, exact)) {
      const key = [taken[i] || EMPTY_STYLE, ...layers].map(idOf).join(",");
      if (!merged.has(key)) merged.set(key, Object.assign({}, taken[i] || EMPTY_STYLE, ...layers));
      taken[i] = merged.get(key);
    }
    if (!taken.some(Boolean)) return null;
    const runs = [];
    let start = 0;
    for (let i = 1; i <= text.length; i++) {
      if (i === text.length || taken[i] !== taken[start]) { runs.push([text.slice(start, i), taken[start]]); start = i; }
    }
    return runs;
  }
  /* a strip's look — text_styles.strip_look: corners (radius, or each corner its own: radii tl, tr, br,
     bl), a border, a layer style (a word rule's strip: the same keys with "bg_" in front) */
  function stripLook(r, prefix, radius, lib) {
    const num = (v, d, lo, hi) => { const n = Number(v == null || v === "" ? d : v); return isFinite(n) ? Math.max(lo, Math.min(hi, n)) : d; };
    const out = { radius: num(r[prefix + "radius"], radius, 0, 2000) };
    const radii = r[prefix + "radii"];
    if (Array.isArray(radii) && radii.length === 4) out.radii = radii.map((v) => num(v, out.radius, 0, 2000));
    const bd = r[prefix + "border"];
    if (bd && num(bd.width, 0, 0, 200) > 0) {
      const al = String(bd.align || "inside").toLowerCase();
      out.border = { width: num(bd.width, 0, 0, 200), color: bd.color || "#ffffff", opacity: num(bd.opacity, 100, 0, 100),
                     align: ["inside", "center", "outside"].includes(al) ? al : "inside" };
    }
    const fx = String(r[prefix + "fx"] || "").trim();
    if (fx) { out.fx = fx; if (lib && lib[fx]) out._fx = lib[fx]; }
    return out;
  }
  function styledSegW(ctx, family, size, seg, st) {
    const fam = st.font ? `"${st.font}", ${family}` : family;
    const sz = st.size ? size * st.size / 100 : size;
    ctx.font = `${st.italic ? "italic " : ""}${st.bold ? "bold " : ""}${sz}px ${fam}, Arial, sans-serif`;
    const track = st.tracking != null ? st.tracking : familyTracking(family);
    if ("letterSpacing" in ctx) ctx.letterSpacing = (track ? styledSize({ size }, st) * track / 1000 : 0) + "px";
    const sh = famShape(family);
    if (sh && !sh.kern && "fontKerning" in ctx) ctx.fontKerning = "none";
    return ctx.measureText(seg).width * (sh ? sh.hs : 1);
  }
  // a piece of text's advance with its styled words at their own width (png_builder._styled_width)
  // measuring / drawing one part of a line: its place in the row is known (exact-occurrence word styles)
  function onPart(p, fn) {
    const prev = L.state.wsPart;
    L.state.wsPart = p;
    try { return fn(); } finally { L.state.wsPart = prev; }
  }
  function textW(ctx, family, size, text) {
    const runs = wordRuns(text);
    if (!runs) return textMetrics(ctx, family, size, text).w;
    let w = 0;
    for (const [seg, st] of runs) w += st ? styledSegW(ctx, family, size, seg, st) : textMetrics(ctx, family, size, seg).w;
    return w;
  }
  // draw a piece of text, its styled words with their own look; returns its advance
  function drawWords(ctx, text, x, y, lh, e) {
    const runs = wordRuns(text);
    if (!runs) {
      drawTextRun(ctx, text, Math.round(x), y, lh, e.family, e.size, e.rgb, e.fx);
      return textMetrics(ctx, e.family, e.size, text).w;
    }
    let cx = x;
    for (const [seg, st] of runs) {                       // strips behind selected words first, under the text
      const w = st ? styledSegW(ctx, e.family, e.size, seg, st) : textMetrics(ctx, e.family, e.size, seg).w;
      if (st && st.bg) drawWordBg(ctx, st.bg, Math.round(cx), styledBaseline(ctx, seg, y, lh, e), w, styledSize(e, st));
      cx += w;
    }
    cx = x;
    for (const [seg, st] of runs) {
      if (st) { drawStyledRun(ctx, seg, Math.round(cx), y, lh, e, st); cx += styledSegW(ctx, e.family, e.size, seg, st); }
      else { drawTextRun(ctx, seg, Math.round(cx), y, lh, e.family, e.size, e.rgb, e.fx); cx += textMetrics(ctx, e.family, e.size, seg).w; }
    }
    return cx - x;
  }

  function measurePartsLive(ctx, parts, family, size, iconH, ctxKey, lineIdx, gaps) {
    let width = 0;
    const gl = (gaps && gaps.l) || 0, gr = (gaps && gaps.r) || 0;
    for (let ri = 0, runIdx = 0; ri < parts.length; ri++) {
      const p = parts[ri];
      if (p.t === "icon") {
        const info = iconInfo(p.v);
        if (info) {
          const th = iconTargetH(p.v, iconH);
          const iw = Math.max(1, Math.round(info.w * th / Math.max(1, info.h)));
          const iconId = "icon." + normToken(p.v) + "." + ctxKey + "." + lineIdx + "." + runIdx;
          const ovi = L.state.overrides[iconId];
          const w = (ovi && ovi.sx != null) ? Math.max(1, Math.round(iw * ovi.sx)) : iw;
          const g = tokGaps(p.v, { l: gl, r: gr });
          width += g.l + w + g.r;
        } else {
          width += textMetrics(ctx, family, size, "<" + untagToken(p.v) + ">").w;
        }
        runIdx++;
      } else {
        width += onPart(p, () => textW(ctx, family, size, p.v));
      }
    }
    return width;
  }

  /* tallest icon of a line (base height x override scale, plus the vertical
     centering offset of its base position); used to grow the line height so
     scaled-up icons never overlap the text/rows above or below. */
  function lineIconMaxH(parts, ctxKey, lineIdx, iconH, baseLh) {
    let maxH = 0;
    for (let ri = 0, runIdx = 0; ri < parts.length; ri++) {
      const p = parts[ri];
      if (p.t !== "icon") continue;
      const info = iconInfo(p.v);
      if (info) {
        const th = iconTargetH(p.v, iconH);
        const iconId = "icon." + normToken(p.v) + "." + ctxKey + "." + lineIdx + "." + runIdx;
        const ovi = L.state.overrides[iconId];
        const sy = ovi && ovi.sy != null ? ovi.sy : 1;
        const h = Math.max(1, Math.round(th * sy));
        maxH = Math.max(maxH, h + Math.max(0, (baseLh - th) / 2));
      }
      runIdx++;
    }
    return maxH;
  }

  /* draws one inline icon; when overridden it uses the transformed size and
     returns the width the rest of the line must reserve (icon + gaps). */
  function drawInlineIcon(ctx, info, rx, y, lh, th, iw, ovi, gaps) {
    const gl = (gaps && gaps.l) || 0, gr = (gaps && gaps.r) || 0;
    const yOff = (L.state.settings && L.state.settings.icon_y_offset) || 0;
    if (!ovi) {
      ctx.drawImage(info.img, Math.round(rx + gl), Math.round(y + (lh - th) / 2 + yOff), iw, th);
      return gl + iw + gr;
    }
    const sx = ovi.sx != null ? ovi.sx : 1;
    const sy = ovi.sy != null ? ovi.sy : 1;
    const w = Math.max(1, Math.round(iw * sx));
    const h = Math.max(1, Math.round(th * sy));
    const ox = Number(ovi.x) || 0;
    const oy = (L.state.freeform ? (Number(ovi.y) || 0) : 0) + yOff;
    const bx = Math.round(rx + gl) + ox;
    const by = Math.round(y + (lh - th) / 2) + oy;
    ctx.save();
    ctx.globalAlpha = (ovi.opacity != null ? ovi.opacity : 100) / 100;
    ctx.translate(bx + w / 2, by + h / 2);
    if (L.state.freeform && ovi.rot) ctx.rotate(ovi.rot * Math.PI / 180);
    ctx.drawImage(info.img, -w / 2, -h / 2, w, h);
    ctx.restore();
    return gl + w + gr;
  }

  function gapsForRole(role) {
    const s = L.state.settings || {};
    return role === "heading"
      ? { l: s.head_icon_gap_l || 0, r: s.head_icon_gap_r || 0 }
      : { l: s.icon_gap_l || 0, r: s.icon_gap_r || 0 };
  }

  /* per-element transform wrapper: draws with AUTO coordinates while the
     matrix maps them to the overridden position / rotation / scale. */
  function wrapElement(ctx, e, drawFn) {
    const ov = e.ov || {};
    const ox = Number(ov.x) || 0;
    const oy = Number(ov.y) || 0;
    ctx.save();
    ctx.globalAlpha = (e.opacity != null ? e.opacity : 100) / 100;
    if (ox || oy || e.rot || e.sx !== 1 || e.sy !== 1) {
      const p = transformPivot(e);
      ctx.translate(p.cx, p.cy);
      if (e.rot) ctx.rotate(e.rot * Math.PI / 180);
      if (e.sx !== 1 || e.sy !== 1) ctx.scale(e.sx, e.sy);
      ctx.translate(-p.cx, -p.cy);
    }
    drawFn(ctx, e);
    ctx.restore();
  }

  /* canonical-mode painter: draws each server run at its PIL position (no
     browser re-measurement). Text uses drawTextRun glyph painting; icons use
     the element hit-target (with the user's override transform) or fall back
     to a plain sprite draw at the server box. */
  function drawCanonicalRuns(ctx, e) {
    const headingLineSpacing = (L.state.settings && L.state.settings.heading_line_spacing) || 0;
    const isHeading = e.kind === "heading";
    for (let li = 0; li < (e.lineTops || []).length; li++) {
      const lh = (isHeading ? (e.lineHs[li] || e.base.h) : e.base.h);
      const cy = e.lineTops[li];
      const lineX = isHeading
        ? (e.lineXs && e.lineXs[li] != null ? e.lineXs[li] : e.base.x)
        : (e.x0 != null ? e.x0 : e.base.x);
      let runIdx = 0;
      // one baseline per line (png_builder._draw_inline): pieces split by icons or
      // word styles are shifted to the whole line's ink centring
      const lineRuns = (e.runs && e.runs[li]) || [];
      const texts = lineRuns.filter((r) => r.kind !== "icon").map((r) => String(r.text || ""));
      let refY = null;
      if (texts.filter((t) => t.trim()).length > 1) {
        const mj = textMetrics(ctx, e.family, e.size, texts.join(""));
        refY = Math.max(0, (lh - mj.h) / 2) + mj.ascent;
      }
      const runY = (text) => {
        if (refY == null || !text.trim()) return cy;
        const m = textMetrics(ctx, e.family, e.size, text);
        return cy + refY - (Math.max(0, (lh - m.h) / 2) + m.ascent);
      };
      for (const r of lineRuns) {                      // strips behind selected words, under all the line's text
        if (r.kind === "icon" || !r.style || !r.style.bg) continue;
        const t = String(r.text || "");
        drawWordBg(ctx, r.style.bg, Math.round(lineX + (Number(r.x) || 0)), styledBaseline(ctx, t, runY(t), lh, e), Number(r.w) || 0, styledSize(e, r.style));
      }
      // icons between two words with the same strip: the strip runs on behind them (png_builder._icon_bridges)
      for (let i = 0; i < lineRuns.length; i++) {
        const a = lineRuns[i];
        if (a.kind === "icon" || !String(a.text || "").trim()) continue;
        let j = i + 1;
        while (j < lineRuns.length && lineRuns[j].kind === "icon") j++;
        const b = lineRuns[j];
        if (j > i + 1 && b && a.style && b.style && a.style.bg && JSON.stringify(a.style.bg) === JSON.stringify(b.style.bg)) {
          const t = String(b.text || ""), x0 = (Number(a.x) || 0) + (Number(a.w) || 0);
          drawWordBg(ctx, b.style.bg, Math.round(lineX + x0), styledBaseline(ctx, t, runY(t), lh, e), (Number(b.x) || 0) - x0, styledSize(e, b.style));
        }
        i = j - 1;
      }
      for (const r of lineRuns) {
        if (r.kind === "icon") {
          const iconId = "icon." + normToken(String(r.token || "")) + "." + (isHeading ? "heading" : e.row) + "." + (isHeading ? li : e.lineIdx) + "." + runIdx;
          const iconEl = elementAtId(iconId);
          if (iconEl) {
            drawIconElement(ctx, iconEl);
          } else {
            const info = iconInfo(r.token);
            if (info) {
              ctx.drawImage(info.img, Math.round(lineX + (Number(r.x) || 0)), Math.round(cy + (Number(r.y) || 0)), Math.round(Number(r.w) || 1), Math.round(Number(r.h) || 1));
            }
          }
          runIdx++;
        } else if (r.style) {
          const x = Math.round(lineX + (Number(r.x) || 0)), t = String(r.text || "");
          inRunWidth(ctx, e, r, x, () => drawStyledRun(ctx, t, x, runY(t), lh, e, r.style));
        } else {
          const x = Math.round(lineX + (Number(r.x) || 0)), t = String(r.text || "");
          inRunWidth(ctx, e, r, x, () => drawTextRun(ctx, t, x, runY(t), lh, e.family, e.size, e.rgb, e.fx));
        }
      }
    }
  }

  /* a text run never reaches past the width the layout gave it (like Photoshop's paragraph box): drawn
     in the browser's font it can come out wider than the build measured it (a face still loading, a
     missing one) — then it is squeezed to that width. Same font: drawn exactly as it is. */
  function inRunWidth(ctx, e, r, x, draw) {
    const w = Number(r.w) || 0, t = String(r.text || "");
    const st = r.style || {};                          // a word style with its own font / size / spacing: drawn as it is
    const own = st.size || st.font || st.tracking != null || st.bold || st.italic;
    let m = 0;
    if (w > 0 && t.trim() && !own) {
      m = textMetrics(ctx, e.family, e.size, t).w;
      const sp = parseFloat(ctx.letterSpacing) || 0;
      if (m <= w + 2 + Math.abs(sp)) m = 0;              // the same font: pixels apart at most
    }
    if (!m) { draw(); return; }
    ctx.save();
    ctx.translate(x, 0);
    ctx.scale(w / m, 1);
    ctx.translate(-x, 0);
    try { draw(); } finally { ctx.restore(); }
  }

  function drawHeadingElement(ctx, e) {
    if (e.canonical) { drawCanonicalRuns(ctx, e); return; }
    const wsPrev = [L.state.wsRow, L.state.wsRowText];
    setWsRow((e.lines || []).join(" "));
    setFont(ctx, e.family, e.size);
    const headingLineSpacing = (L.state.settings && L.state.settings.heading_line_spacing) || 0;
    const gaps = gapsForRole("heading");
    let cy = e.base.y;
    for (let li = 0; li < e.lines.length; li++) {
      const ln = e.lines[li];
      const lh = e.lineHs[li];
      const lhBase = (e.lineHsBase && e.lineHsBase[li]) || lh;
      const runParts = splitInline(ln);
      const mw = measurePartsLive(ctx, runParts, e.family, e.size, e.iconH, "heading", li, gaps);
      const lineX = (e.lineXs && e.lineXs[li] != null) ? e.lineXs[li] : e.base.x + Math.max(0, (e.base.w - mw) / 2);
      let rx = lineX;
      let runIdx = 0;
      for (const p of runParts) {
        if (p.t === "icon") {
          const info = iconInfo(p.v);
          const iconId = "icon." + normToken(p.v) + ".heading." + li + "." + runIdx;
          const ovi = L.state.overrides[iconId];
          const hasOv = ovi && (ovi.x != null || ovi.y != null || ovi.sx != null || ovi.sy != null || ovi.rot != null || ovi.opacity != null);
          if (info) {
            const th = iconTargetH(p.v, e.iconH);
            const iw = Math.max(1, Math.round(info.w * th / Math.max(1, info.h)));
            if (hasOv) {
              const iconEl = elementAtId(iconId);
              if (iconEl) {
                const w = ovi.sx != null ? Math.max(1, Math.round(iw * ovi.sx)) : iw;
                drawIconElement(ctx, iconEl);
                rx += tokGaps(p.v, gaps).l + w + tokGaps(p.v, gaps).r;
              } else {
                rx += drawInlineIcon(ctx, info, rx, cy, lhBase, th, iw, ovi, tokGaps(p.v, gaps));
              }
            } else {
              rx += drawInlineIcon(ctx, info, rx, cy, lhBase, th, iw, null, tokGaps(p.v, gaps));
            }
          } else {
            const tm = textMetrics(ctx, e.family, e.size, "<" + untagToken(p.v) + ">");
            drawTextRun(ctx, "<" + untagToken(p.v) + ">", Math.round(rx), cy, lhBase, e.family, e.size, e.rgb, e.fx);
            rx += tm.w;
          }
          runIdx++;
        } else {
          rx += onPart(p, () => drawWords(ctx, p.v, rx, cy, lhBase, e));
        }
      }
      cy += lh + (li < e.lines.length - 1 ? headingLineSpacing : 0);
    }
    L.state.wsRow = wsPrev[0]; L.state.wsRowText = wsPrev[1];
  }

  function drawLineElement(ctx, e) {
    if (e.canonical) { drawCanonicalRuns(ctx, e); return; }
    const wsPrev = [L.state.wsRow, L.state.wsRowText];
    setWsRow(e.rowText || e.text);
    setFont(ctx, e.family, e.size);
    const gaps = gapsForRole(e.role);
    const runParts = splitInline(e.text);
    const mw = measurePartsLive(ctx, runParts, e.family, e.size, e.iconH, String(e.row), e.lineIdx, gaps);
    const lineX = (e.x0 != null) ? e.x0 : e.base.x + Math.max(0, (e.base.w - mw) / 2);
    let rx = lineX;
    let runIdx = 0;
    for (const p of runParts) {
        if (p.t === "icon") {
          const info = iconInfo(p.v);
          const iconId = "icon." + normToken(p.v) + "." + e.row + "." + e.lineIdx + "." + runIdx;
          const ovi = L.state.overrides[iconId];
          const hasOv = ovi && (ovi.x != null || ovi.y != null || ovi.sx != null || ovi.sy != null || ovi.rot != null || ovi.opacity != null);
          if (info) {
            const th = iconTargetH(p.v, e.iconH);
            const iw = Math.max(1, Math.round(info.w * th / Math.max(1, info.h)));
            if (hasOv) {
              const iconEl = elementAtId(iconId);
              if (iconEl) {
                const w = ovi.sx != null ? Math.max(1, Math.round(iw * ovi.sx)) : iw;
                drawIconElement(ctx, iconEl);
                rx += tokGaps(p.v, gaps).l + w + tokGaps(p.v, gaps).r;
              } else {
                rx += drawInlineIcon(ctx, info, rx, e.base.y, e.base.h, th, iw, ovi, tokGaps(p.v, gaps));
              }
            } else {
              rx += drawInlineIcon(ctx, info, rx, e.base.y, e.base.h, th, iw, null, tokGaps(p.v, gaps));
            }
          } else {
          const tm = textMetrics(ctx, e.family, e.size, "<" + untagToken(p.v) + ">");
          drawTextRun(ctx, "<" + untagToken(p.v) + ">", Math.round(rx), e.base.y, e.base.h, e.family, e.size, e.rgb, e.fx);
          rx += tm.w;
        }
        runIdx++;
      } else {
        rx += onPart(p, () => drawWords(ctx, p.v, rx, e.base.y, e.base.h, e));
      }
    }
    L.state.wsRow = wsPrev[0]; L.state.wsRowText = wsPrev[1];
  }

  /* a heading / line row's text runs where they are drawn, for selecting text over the canvas
     (typo-preview.js TextSelect): [{ x, top, h, runs: [{ kind, text, x, w }] }] in page px,
     run x relative to the line. Canonical rows carry the server's runs; otherwise they are laid
     out like drawHeadingElement / drawLineElement. */
  function textRows(e) {
    const heading = e.kind === "heading";
    if (e.canonical) {
      return (e.lineTops || []).map((top, li) => ({ top, h: heading ? (e.lineHs[li] || e.base.h) : e.base.h,
        x: heading ? (e.lineXs && e.lineXs[li] != null ? e.lineXs[li] : e.base.x) : (e.x0 != null ? e.x0 : e.base.x),
        runs: (e.runs && e.runs[li]) || [] }));
    }
    const ctx = measureCtx();
    const wsPrev = [L.state.wsRow, L.state.wsRowText];
    setWsRow(heading ? (e.lines || []).join(" ") : (e.rowText || e.text));
    const gaps = gapsForRole(heading ? "heading" : e.role);
    const spacing = (L.state.settings && L.state.settings.heading_line_spacing) || 0;
    const lines = heading ? (e.lines || []) : [String(e.text || "")];
    const out = [];
    let cy = e.base.y;
    lines.forEach((ln, li) => {
      const lh = heading ? e.lineHs[li] : e.base.h;
      const parts = splitInline(ln);
      let x = heading ? (e.lineXs && e.lineXs[li]) : e.x0;
      if (x == null) {
        setFont(ctx, e.family, e.size);
        const mw = measurePartsLive(ctx, parts, e.family, e.size, e.iconH, heading ? "heading" : String(e.row), heading ? li : e.lineIdx, gaps);
        x = e.base.x + Math.max(0, (e.base.w - mw) / 2);
      }
      const runs = [];
      let rx = 0, runIdx = 0;
      for (const p of parts) {
        let w;
        if (p.t === "icon") {
          const info = iconInfo(p.v);
          if (info) {
            const th = iconTargetH(p.v, e.iconH);
            const iw = Math.max(1, Math.round(info.w * th / Math.max(1, info.h)));
            const ovi = L.state.overrides["icon." + normToken(p.v) + "." + (heading ? "heading" : e.row) + "." + (heading ? li : e.lineIdx) + "." + runIdx];
            w = tokGaps(p.v, gaps).l + (ovi && ovi.sx != null ? Math.max(1, Math.round(iw * ovi.sx)) : iw) + tokGaps(p.v, gaps).r;
          } else {
            w = textMetrics(ctx, e.family, e.size, "<" + untagToken(p.v) + ">").w;
          }
          runs.push({ kind: "icon", x: rx, w, token: p.v, missing: !info });
          runIdx++;
        } else {
          w = onPart(p, () => textW(ctx, e.family, e.size, p.v));
          runs.push({ kind: "text", text: p.v, x: rx, w });
        }
        rx += w;
      }
      out.push({ x, top: cy, h: heading ? ((e.lineHsBase && e.lineHsBase[li]) || lh) : lh, runs });
      cy += lh + (heading && li < lines.length - 1 ? spacing : 0);
    });
    L.state.wsRow = wsPrev[0]; L.state.wsRowText = wsPrev[1];
    return out;
  }

  function drawTableElement(ctx, e) {
    const img = L.state.stripImgs && L.state.stripImgs[e.url];
    if (!img) return;
    // where the artist moved it (live_overrides x / y) — png_builder._table_offset draws it there too
    const ov = e.ov || {}, bx = e.base.x + (Number(ov.x) || 0), by = e.base.y + (Number(ov.y) || 0);
    if (!e.parts) { ctx.drawImage(img, bx, by, e.base.w, e.base.h); return; }
    // one part of a split table: its header band, then its rows, cut from the table picture
    const k = img.height / Math.max(1, e.fullH || img.height), sx = img.width / Math.max(1, e.base.w);
    let dy = by;
    for (const [y0, y1] of e.parts) {
      const h = y1 - y0;
      if (h <= 0) continue;
      ctx.drawImage(img, 0, y0 * k, img.width, h * k, bx, dy, img.width / sx, h);
      dy += h + (e.parts.length > 1 && y0 === 0 ? ((e.geoGap) || 0) : 0);
    }
  }

  // a new picture (the separator moved while typing) shows once it has loaded: until then the last one
  // stays where it was, never a page without it
  const lastPictures = {};
  function drawPictureElement(ctx, e) {
    const img = L.state.stripImgs && L.state.stripImgs[e.url];
    if (img) {
      lastPictures[e.id] = { img, x: e.base.x, y: e.base.y, w: e.base.w, h: e.base.h, sheet: (L.state.data || {}).sheet_name };
      ctx.drawImage(img, e.base.x, e.base.y, e.base.w, e.base.h);
      return;
    }
    const last = lastPictures[e.id];
    if (last && last.sheet === (L.state.data || {}).sheet_name) ctx.drawImage(last.img, last.x, last.y, last.w, last.h);
  }

  /* canonical rect element (mirrors canonical_png._render_rect_element) */
  function drawRectElement(ctx, e) {
    const b = e.base;
    if (e.look) { drawStripShape(ctx, e.fill_rgb, e.fill_opacity, b.x, b.y, b.w, b.h, e.look); return; }
    if (!(e.fill_opacity > 0) || !(b.w > 0) || !(b.h > 0)) {
      if (e.stroke_width > 0 && b.w > 0 && b.h > 0) {
        ctx.strokeStyle = rgba(e.stroke_rgb, 1);
        ctx.lineWidth = e.stroke_width;
        ctx.strokeRect(b.x, b.y, b.w, b.h);
      }
      return;
    }
    ctx.save();
    ctx.globalAlpha = Math.max(0, Math.min(1, e.fill_opacity));
    ctx.fillStyle = rgba(e.fill_rgb, 1);
    if (e.radius > 0 && ctx.roundRect) { ctx.beginPath(); ctx.roundRect(b.x, b.y, b.w, b.h, e.radius); ctx.fill(); }
    else ctx.fillRect(b.x, b.y, b.w, b.h);
    ctx.restore();
    if (e.stroke_width > 0 && b.w > 0 && b.h > 0) {
      ctx.strokeStyle = rgba(e.stroke_rgb, 1);
      ctx.lineWidth = e.stroke_width;
      ctx.strokeRect(b.x, b.y, b.w, b.h);
    }
  }

  /* auto heading + "(Continued)" for pages 2+ (mirrors png_builder.new_page) */
  function drawAutoPageHeader(ctx) {
    const d = L.state.data;
    const s = L.state.settings || d.settings;
    const safe = L.state.safe;
    const H_FAMILY = "visH", B_FAMILY = "visB";
    const headingIconH = Math.max(1, s.h_icon_h || s.h_size);
    const hGaps = { l: s.head_icon_gap_l || 0, r: s.head_icon_gap_r || 0 };
    const top = s.heading_top_margin;
    const lines = wrapInline(ctx, d.heading.text, H_FAMILY, s.h_size, safe.width, headingIconH, "heading", hGaps);
    let cy = top;
    for (const ln of lines) {
      const mp = measureParts(ctx, splitInline(ln), H_FAMILY, s.h_size, headingIconH, hGaps);
      const lh = mp.h;
      const mw = mp.w;
      const lineX = safe.left + Math.max(0, (safe.width - mw) / 2);
      let rx = lineX;
      const runParts = splitInline(ln);
      for (const p of runParts) {
        if (p.t === "icon") {
          const info = iconInfo(p.v);
          if (info) {
            const th = iconTargetH(p.v, headingIconH);
            const iw = Math.max(1, Math.round(info.w * th / Math.max(1, info.h)));
            rx += drawInlineIcon(ctx, info, rx, cy, lh, th, iw, null, tokGaps(p.v, hGaps));
          } else {
            rx += textMetrics(ctx, H_FAMILY, s.h_size, "<" + untagToken(p.v) + ">").w;
          }
        } else {
          drawTextRun(ctx, p.v, Math.round(rx), cy, lh, H_FAMILY, s.h_size, d.heading.rgb, d.heading.fx || null);
          rx += textMetrics(ctx, H_FAMILY, s.h_size, p.v).w;
        }
      }
      cy += lh + ((s.heading_line_spacing != null) ? s.heading_line_spacing : ((s.line_spacing || 0)));
    }
    drawContinuedLine(ctx);
  }

  // "(Continued)" — plain small text, never inherits heading/body layer styles
  function drawContinuedLine(ctx) {
    const d = L.state.data;
    const s = L.state.settings || d.settings;
    const safe = L.state.safe;
    const top = s.heading_top_margin;
    const contSize = (d.continued && d.continued.size) || Math.max(12, Math.round(s.h_size * 0.38));
    const contY = top + L.state.headingH + Math.max(2, s.continued_gap, 8);
    const contW = textMetrics(ctx, contFamily(), contSize, "(Continued)").w;
    const cl = d.continued || {};                  // Typography › Continued: its colour and layer style
    const al = cl.align || "center", free = Math.max(0, safe.width - contW);   // Typography › Continued › align
    drawTextRun(ctx, "(Continued)", safe.left + (al === "left" ? 0 : al === "right" ? free : free / 2), contY, L.state.continuedH, contFamily(), contSize, cl.rgb || d.body.rgb, cl.fx || null);
  }

  function drawChrome(ctx, scale) {
    const d = L.state.data;
    const s = L.state.settings || d.settings;
    const safe = L.state.safe;
    ctx.save();
    ctx.setLineDash([8, 6]);
    // heading block
    ctx.strokeStyle = "rgba(255,190,90,0.5)";
    ctx.lineWidth = 1 / scale;
    ctx.strokeRect(safe.left, s.heading_top_margin, safe.width, L.state.headingH);
    // body safe area
    ctx.strokeStyle = "rgba(90,200,255,0.5)";
    ctx.strokeRect(safe.left, s.heading_top_margin + L.state.headingH + s.heading_to_body_gap, safe.width, safe.bottom - (s.heading_top_margin + L.state.headingH + s.heading_to_body_gap));
    ctx.setLineDash([]);
    ctx.strokeStyle = "rgba(90,200,255,0.35)";
    ctx.beginPath();
    ctx.moveTo(safe.left, safe.bottom);
    ctx.lineTo(safe.left + safe.width, safe.bottom);
    ctx.stroke();
    ctx.restore();
  }

  /* = bg_place.behind: a colour background's colour; behind a picture the "Colour behind" when it is
     on, else "" (transparent) — from the settings as they are now (the switch redraws at once) */
  function bgBehind(s) {
    const c = (typeof App !== "undefined" && App.state && App.state.config) || null;
    if (!c) return s.bg_color || "";
    if (String(c.bg_source || "image") === "color") return c.bg_color || "#FFFFFF";
    return c.bg_behind_fill ? (c.bg_color || "#000000") : "";
  }

  function draw() {
    const d = L.state.data;
    if (!d) return;
    const target = L.state.renderTarget || el("visLiveCanvas");
    const ctx = target && target.getContext ? target.getContext("2d") : null;
    if (!target || !ctx) return;

    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, target.width, target.height);
    const s = mergedSettings() || d.settings;
    // what the background picture leaves uncovered is transparent (the canvas's checkerboard shows
    // through), unless "Colour behind" is on — bg_color is then that colour (bg_place.behind)
    const behind = bgBehind(s), pic = L.state.images && L.state.images.bg && s.bg_source !== "color";
    if (behind || !pic) {
      ctx.fillStyle = behind || "#FFFFFF";
      ctx.fillRect(0, 0, target.width, target.height);
    }
    const win = target._win;                                // a window of the page (redrawInto, zoomed in)
    const scale = win ? win.k : target.width / d.canvas_w;
    ctx.setTransform(scale, 0, 0, scale, win ? -win.x * scale : 0, win ? -win.y * scale : 0);

    const imgs = L.state.images;
    if (imgs && imgs.bg && s.bg_source !== "color") drawBackgroundImage(ctx, imgs.bg, d.canvas_w, d.canvas_h, bgSpec(s));

    const pg = L.state.pages[L.state.page];
    if (pg && pg.payline) {
      drawPaylinePage(ctx, pg, d.canvas_w, d.canvas_h);
      return;
    }
    if (pg) {
      if (L.state.page > 0 && !L.state.canonActive) drawAutoPageHeader(ctx);
      else if (L.state.page === 0 && !L.state.canonActive && d.heading && d.heading.continued) drawContinuedLine(ctx);
      for (const e of pg.elements) {
        if (e.kind === "picture") drawPictureElement(ctx, e);
        else if (e.kind === "heading" && e.trk != null) {          // a rules page's heading: its own letter spacing
          const prev = L.state.trackOverride;
          L.state.trackOverride = e.trk;
          try { wrapElement(ctx, e, drawHeadingElement); } finally { L.state.trackOverride = prev; }
        }
        else if (e.kind === "heading") wrapElement(ctx, e, drawHeadingElement);
        else if (e.kind === "line" && (e.boxId != null || e.cell != null)) {   // a text box / rules paragraph: its own letter spacing
          const prev = L.state.trackOverride;
          L.state.trackOverride = Number((e.meta || {}).tracking) || 0;
          try { wrapElement(ctx, e, drawLineElement); } finally { L.state.trackOverride = prev; }
        }
        else if (e.kind === "line") wrapElement(ctx, e, drawLineElement);
        else if (e.kind === "table") wrapElement(ctx, e, drawTableElement);
        else if (e.kind === "icon" && L.state.canonActive) wrapElement(ctx, e, drawIconElement);
        else if (e.kind === "rect" && L.state.canonActive) drawRectElement(ctx, e);
      }
    }

    if (!L.state.renderTarget) {
      drawChrome(ctx, scale);
      drawSelection(ctx, scale);
    }
    drawFxDiagChip(ctx, target);
    if (!L.state.renderTarget) syncStyleBar();
    if (!L.state.renderTarget && window.AppTblVis && AppTblVis.onVisDraw) AppTblVis.onVisDraw();   // its handles follow
    if (!L.state.renderTarget && window.IconStudio && IconStudio.onVisDraw) IconStudio.onVisDraw();
  }

  /* red/amber chip on the canvas explaining why FX is not visible (diagnostics) */
  function drawFxDiagChip(ctx, target) {
    const diag = L.state.fxDiag;
    if (!diag) return;
    const d = L.state.data;
    if (diag.headingFx === undefined) diag.headingFx = !!(d && d.heading && d.heading.fx);
    const msg = diag.stage === "build_error"
      ? "FX sprite error: " + (diag.error || "?")
      : diag.stage === "no_sprite"
        ? "FX skipped: hasFx=" + (diag.hasFx ? "true" : "FALSE") + " · heading.fx=" + (diag.headingFx ? "yes" : "no")
        : "FX unknown state: " + diag.stage;
    ctx.save();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    const w = Math.max(260, ctx.measureText(msg).width + 28);
    ctx.fillStyle = diag.stage === "build_error" ? "rgba(200,40,40,0.88)" : "rgba(210,150,20,0.88)";
    ctx.fillRect(8, 8, w, 24);
    ctx.fillStyle = "#fff";
    ctx.font = "12px monospace";
    ctx.fillText(msg, 20, 25);
    ctx.restore();
  }

  /* --------------------- selection / handles (page space) --------------------- */

  function finalBox(e) {
    const ov = e.ov || {};
    const free = !(e.kind === "icon" && !L.state.freeform);
    const x = e.base.x + (Number(ov.x) || 0);
    const y = e.base.y + (free ? (Number(ov.y) || 0) : 0);
    return {
      x, y, w: e.w, h: e.h,
      cx: x + e.w / 2, cy: y + e.h / 2,
      rot: free ? (e.rot || 0) : 0,
    };
  }

  /* rotation / scale pivot: the element's own CONTENT box center (+ its
     override offset), so short text lines spin around their own middle
     instead of the (much wider) row / canvas center. Icons and tables have no
     cbox, so they keep pivoting on their own transformed box center. */
  function transformPivot(e) {
    const ov = e.ov || {};
    const ox = Number(ov.x) || 0;
    const oy = Number(ov.y) || 0;
    const cb = e.cbox;
    return cb
      ? { cx: cb.cx + ox, cy: cb.cy + oy }
      : { cx: e.base.x + ox + e.w / 2, cy: e.base.y + oy + e.h / 2 };
  }

  function drawSelection(ctx, scale) {
    const sel = L.state.selected;
    if (!sel) return;
    const e = L.state.elements.find((x) => x.id === sel);
    if (!e) return;
    const b = finalBox(e);
    const p = transformPivot(e);
    const rad = b.rot * Math.PI / 180;
    ctx.save();
    ctx.translate(p.cx, p.cy);
    if (rad) ctx.rotate(rad);
    ctx.translate(b.cx - p.cx, b.cy - p.cy);
    ctx.setLineDash([6, 4]);
    ctx.strokeStyle = "rgba(90,200,255,0.95)";
    ctx.lineWidth = 2 / scale;
    ctx.strokeRect(-b.w / 2 - 3 / scale, -b.h / 2 - 3 / scale, b.w + 6 / scale, b.h + 6 / scale);
    ctx.setLineDash([]);
    const hs = 9 / scale;
    ctx.fillStyle = "#FFFFFF";
    ctx.strokeStyle = "#5AC8FF";
    ctx.lineWidth = 1.5 / scale;
    const corners = [[-1, -1], [1, -1], [1, 1], [-1, 1]];
    for (const [sx2, sy2] of corners) {
      const hx = sx2 * b.w / 2 - hs / 2, hy = sy2 * b.h / 2 - hs / 2;
      ctx.beginPath();
      ctx.rect(hx, hy, hs, hs);
      ctx.fill();
      ctx.stroke();
    }
    const rl = 14 / scale;
    // rotate handle hidden while Freeform is off (x-axis constraint)
    if (!(e.kind === "icon" && !L.state.freeform)) {
      ctx.beginPath();
      ctx.moveTo(0, -b.h / 2 - 8 / scale);
      ctx.lineTo(0, -b.h / 2 - 24 / scale);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(0, -b.h / 2 - 30 / scale, rl, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
    }
    ctx.restore();
  }

  /* ------------------------------ hit test ------------------------------ */

  function pointInElement(px, py, e) {
    if (e.kind === "picture") return false;          // a rules / paylines page's picture: its parts are picked by RulesCanvas / PaylinesCanvas
    if (e.cell != null && e.cbox && !(e.rot || 0)) {
      // a Game / Bingo Rules line: its drawn text (two Bingo cells of a row share the full-width box)
      const ox = Number(e.ov && e.ov.x) || 0, oy = Number(e.ov && e.ov.y) || 0, pad = 6;
      return px >= e.cbox.x + ox - pad && px <= e.cbox.x + e.cbox.w + ox + pad && py >= e.cbox.y + oy && py <= e.cbox.y + e.cbox.h + oy;
    }
    if (e.kind === "table" && e.cut && !(e.rot || 0)) {
      // the drawn table, not the full-width strip it sits in (cut parts side by side overlap there)
      const fb = finalBox(e), kx = fb.w / Math.max(1, e.base.w);
      const x0 = fb.x + e.cut.tx * kx;
      return px >= x0 && px <= x0 + e.cut.tw * kx && py >= fb.y && py <= fb.y + fb.h;
    }
    const b = finalBox(e);
    const rad = b.rot * Math.PI / 180;
    const dx = px - b.cx, dy = py - b.cy;
    const cos = Math.cos(-rad), sin = Math.sin(-rad);
    const lx = dx * cos - dy * sin;
    const ly = dx * sin + dy * cos;
    return Math.abs(lx) <= b.w / 2 && Math.abs(ly) <= b.h / 2;
  }

  function hitTest(px, py) {
    const els = L.state.elements;
    for (let i = els.length - 1; i >= 0; i--) {
      if (pointInElement(px, py, els[i])) return els[i];
    }
    return null;
  }

  function handleAt(px, py) {
    const sel = L.state.selected;
    if (!sel) return null;
    const e = L.state.elements.find((x) => x.id === sel);
    if (!e) return null;
    const b = finalBox(e);
    const p = transformPivot(e);
    const HS = 10;
    const rad = b.rot * Math.PI / 180;
    const cos = Math.cos(rad), sin = Math.sin(rad);
    const bx = p.cx + (b.cx - p.cx) * cos - (b.cy - p.cy) * sin;
    const by = p.cy + (b.cx - p.cx) * sin + (b.cy - p.cy) * cos;
    const names = ["nw", "ne", "se", "sw"];
    const corners = [[-1, -1], [1, -1], [1, 1], [-1, 1]];
    for (let i = 0; i < 4; i++) {
      const lx = corners[i][0] * b.w / 2, ly = corners[i][1] * b.h / 2;
      const wx = bx + lx * cos - ly * sin;
      const wy = by + lx * sin + ly * cos;
      if (Math.abs(px - wx) < HS && Math.abs(py - wy) < HS) return names[i];
    }
    const rlx = 0, rly = -(b.h / 2 + 30);
    const rwx = bx + rlx * cos - rly * sin;
    const rwy = by + rlx * sin + rly * cos;
    if (Math.abs(px - rwx) < HS && Math.abs(py - rwy) < HS) return "rot";
    return null;
  }

  function elementAtId(id) {
    return L.state.elements.find((x) => x.id === id)
      || (L.state.virtualRow && L.state.virtualRow.id === id ? L.state.virtualRow : null);   // a table's words
  }

  /* element lookup across ALL pages (not just the current one). */
  function elementAll(id) {
    const cur = elementAtId(id);
    if (cur) return cur;
    const pages = L.state.pages || [];
    for (let p = 0; p < pages.length; p++) {
      const e = pages[p].elements.find((x) => x.id === id);
      if (e) return e;
    }
    return null;
  }

  /* anchors a line's x so a transformed icon keeps its exact position while
     the rest of the line re-flows around it: the line starts at the (first)
     overridden icon's current left edge minus the widths before it. Lines
     without an overridden icon keep their normal centering. */
  function anchorLineX(ctx, parts, family, size, iconH, ctxKey, lineIdx, lineW, safe, gaps, fallbackX) {
    let acc = 0;
    let runIdx = 0;
    const gl = (gaps && gaps.l) || 0;
    const gr = (gaps && gaps.r) || 0;
    for (const p of parts) {
      if (p.t === "icon") {
        const info = iconInfo(p.v);
        if (info) {
          const th = iconTargetH(p.v, iconH);
          const iw = Math.max(1, Math.round(info.w * th / Math.max(1, info.h)));
          const iconId = "icon." + normToken(p.v) + "." + ctxKey + "." + lineIdx + "." + runIdx;
          const ovi = L.state.overrides[iconId];
          if (ovi && (ovi.x != null || ovi.sx != null || ovi.sy != null)) {
            const prev = elementAll(iconId);
            if (prev) {
              const x = prev.base.x + (Number(ovi.x) || 0);
              const anchor = x - acc - tokGaps(p.v, { l: gl, r: gr }).l;
              const minX = safe.left;
              const maxX = safe.left + Math.max(0, safe.width - lineW);
              return Math.min(Math.max(anchor, minX), Math.max(minX, maxX));
            }
          }
          const w = ovi && ovi.sx != null ? Math.max(1, Math.round(iw * ovi.sx)) : iw;
          acc += tokGaps(p.v, { l: gl, r: gr }).l + w + tokGaps(p.v, { l: gl, r: gr }).r;
        } else {
          acc += textMetrics(ctx, family, size, "<" + untagToken(p.v) + ">").w;
        }
        runIdx++;
      } else {
        acc += textMetrics(ctx, family, size, p.v).w;
      }
    }
    return fallbackX;
  }

  /* ------------------------------ interaction ------------------------------ */

  function snapOffset(ov, e, ox, oy) {
    const safe = L.state.safe || { left: 0, width: L.state.data ? L.state.data.canvas_w : 1 };
    const b = finalBox(e);
    const right = safe.left + safe.width;
    const centerX = safe.left + safe.width / 2;
    const elems = [b.x, b.cx, b.x + b.w];
    const targets = [safe.left, centerX, right];
    let bestX = ox, bestDx = SNAP_PX;
    for (const tx of targets) {
      for (const ex of elems) {
        const dx = tx - ex;
        if (Math.abs(dx) < bestDx) { bestDx = Math.abs(dx); bestX = ox + dx; }
      }
    }
    return { x: bestX, y: oy };
  }

  function iconRowBox(e) {
    if (e.role === "heading") {
      const hEl = elementAtId("heading");
      if (!hEl) return null;
      const s = L.state.settings || {};
      const ls = ((s.heading_line_spacing != null) ? s.heading_line_spacing : s.line_spacing) || 0;
      let ly = hEl.base.y;
      for (let li = 0; li < e.lineIdx; li++) {
        ly += ((hEl.lineHs && hEl.lineHs[li]) || 0) + ls;
      }
      return {
        x: hEl.base.x, y: ly, w: hEl.base.w,
        h: (hEl.lineHs && hEl.lineHs[e.lineIdx]) || 0,
      };
    }
    const rowId = e.role === "heading" ? "heading" : "line." + e.row + "." + e.lineIdx;
    const rowEl = elementAtId(rowId);
    return rowEl ? finalBox(rowEl) : null;
  }

  /* keeps an overridden icon in line: the scale is capped so the icon (with
     its configured left/right gaps) never exceeds the row width, and the box
     stays horizontally inside the row. Vertically the icon is free: the
     layout reserves (and grows) the line height for it on every rebuild, so a
     scaled-up icon stays in its line and never overlaps the rows around it. */
  function clampIconTransform(e, gaps) {
    const row = iconRowBox(e);
    if (!row) return;
    const own = tokGaps(e.token, gaps), gl = own.l, gr = own.r;
    const maxW = Math.max(6, row.w - gl - gr);
    let k = 1;
    if (e.w > maxW) k = Math.min(k, maxW / e.w);
    if (k < 1) {
      k = Math.max(0.02, Math.round(k * 1000) / 1000);
      e.ov.sx = k;
      e.ov.sy = k;
      e.sx = k;
      e.sy = k;
      e.w = Math.max(1, Math.round(e.base.w * k));
      e.h = Math.max(1, Math.round(e.base.h * k));
    }
    const w = e.w;
    const minCX = row.x + gl + w / 2, maxCX = row.x + row.w - gr - w / 2;
    let cx = e.base.x + (Number(e.ov.x) || 0) + w / 2;
    if (minCX > maxCX) cx = row.x + gl + w / 2;
    else cx = Math.min(Math.max(cx, minCX), maxCX);
    const nx = Math.round(cx - e.base.x - w / 2);
    if (nx) e.ov.x = nx; else delete e.ov.x;
    if (e.ov.sx != null && Math.abs(e.ov.sx - 1) < 0.02) delete e.ov.sx;
    if (e.ov.sy != null && Math.abs(e.ov.sy - 1) < 0.02) delete e.ov.sy;
  }

  function onPointerDown(ev) {
    const canvas = el("visLiveCanvas");
    if (!canvas || !L.state.data) return false;
    const rect = canvas.getBoundingClientRect();
    const scale = L.state.scale;
    const px = (ev.clientX - rect.left) / scale;
    const py = (ev.clientY - rect.top) / scale;

    const hd = handleAt(px, py);
    // rotate is locked for icons while Freeform is off (x-axis constraint)
    if (hd === "rot") {
      const se = L.state.selected ? elementAtId(L.state.selected) : null;
      if (se && se.kind === "icon" && !L.state.freeform) return true;
    }
    if (hd) {
      const e = elementAtId(L.state.selected);
      if (e) {
        const b = finalBox(e);
        if (hd === "rot") {
          const p = transformPivot(e);
          const startAngle = Math.atan2(py - p.cy, px - p.cx);
          L.state.drag = { kind: "rotate", x: ev.clientX, y: ev.clientY, el: e, elId: e.id, startAngle: startAngle, baseRot: e.rot || 0, changed: false };
        } else {
          const p = transformPivot(e);
          const rad0 = (e.rot || 0) * Math.PI / 180;
          const cos0 = Math.cos(-rad0), sin0 = Math.sin(-rad0);
          const dx0 = px - p.cx, dy0 = py - p.cy;
          const lx0 = dx0 * cos0 - dy0 * sin0;
          const ly0 = dx0 * sin0 + dy0 * cos0;
          L.state.drag = {
            kind: "resize", handle: hd, x: ev.clientX, y: ev.clientY,
            px, py, el: e, elId: e.id,
            baseW: e.base.w, baseH: e.base.h,
            sx0: e.sx || 1, sy0: e.sy || 1,
            pivotX: p.cx, pivotY: p.cy,
            // start distance of the grabbed corner from the pivot: scaling is
            // relative to it, so dragging always grows from the current size
            // instead of collapsing against the (much wider) row width.
            d0: Math.max(6, Math.max(Math.abs(lx0), Math.abs(ly0))),
            uniform: ev.shiftKey,
            changed: false,
          };
        }
        canvas.setPointerCapture(ev.pointerId);
        ev.preventDefault();
        ev.stopPropagation();
        markDirty();
        return true;
      }
    }

    const e = hitTest(px, py);
    // a table: the Tables editor (handles, ✎ design / text, boxes, ✥ move, ✂ cut, right-click parts)
    if (e && e.kind === "table" && e.design_key && L.state.editMode !== "icon" && window.AppTblVis && AppTblVis.pickInVisualiser) {
      L.state.selected = null;
      hideTableBar();
      L.state.tableBarFor = null;
      AppTblVis.pickInVisualiser(e, ev);
      draw();
      ev.preventDefault();
      ev.stopPropagation();
      return true;
    }
    if (window.AppTblVis && AppTblVis.clearVisualiser) AppTblVis.clearVisualiser();
    // an icon in Icon Edit (or double-clicked): its size for this copy / the page / the sheet, its gaps,
    // its picture — the Assets & Icons editing (sizes the PSD build reads), not a free transform
    if (e && e.kind === "icon" && window.IconStudio && (L.state.editMode === "icon" || (ev.detail && ev.detail >= 2))) {
      L.state.selected = null;
      IconStudio.pickVis(e);
      draw();
      ev.preventDefault();
      ev.stopPropagation();
      return true;
    }
    if (window.IconStudio) IconStudio.clearVis();
    if (!e && L.state.editMode === "icon" && window.IconStudio && IconStudio.clickVis(ev)) return true;   // a bare <TOKEN>
    if (e) {
      let sel = e;
      // "Icon Edit" mode or a double click edits the icon itself; in "Text
      // Edit" mode a single click on an icon selects its row instead.
      if (e.kind === "icon" && L.state.editMode !== "icon" && !(ev.detail && ev.detail >= 2)) {
        const rowId = e.role === "heading" ? "heading" : "line." + e.row + "." + e.lineIdx;
        const rowEl = elementAtId(rowId);
        if (rowEl) sel = rowEl;
      }
      L.state.selected = sel.id;
      L.state.drag = {
        kind: "move", x: ev.clientX, y: ev.clientY,
        px, py, el: sel, elId: sel.id,
        ox0: Number(sel.ov.x) || 0, oy0: Number(sel.ov.y) || 0,
        changed: false,
      };
      canvas.setPointerCapture(ev.pointerId);
      ev.preventDefault();
      ev.stopPropagation();
      markDirty();
      return true;
    }
    L.state.selected = null;
    markDirty();
    return false;
  }

  function onPointerMove(ev) {
    const d = L.state.drag;
    const canvas = el("visLiveCanvas");
    if (!d || !canvas || !L.state.data) return;
    const rect = canvas.getBoundingClientRect();
    const scale = L.state.scale;
    const px = (ev.clientX - rect.left) / scale;
    const py = (ev.clientY - rect.top) / scale;
    const e = d.elId ? (elementAtId(d.elId) || d.el) : d.el;

    // dead zone: clicks (and double clicks) must never micro-drag the element
    if (Math.abs(ev.clientX - d.x) < 4 && Math.abs(ev.clientY - d.y) < 4) return;

    if (d.kind === "move") {
      const snapped = snapOffset(e.ov, e, d.ox0 + (px - d.px), d.oy0 + (py - d.py));
      const nx = snapped.x || null, ny = snapped.y || null;
      if (nx !== (e.ov.x != null ? e.ov.x : null) || ny !== (e.ov.y != null ? e.ov.y : null)) d.changed = true;
if (nx != null) e.ov.x = nx;
    else if (e.ov.x != null) delete e.ov.x;
    if (e.kind === "icon" && !L.state.freeform) {
      // x-axis constraint: icons never leave their row vertically
      if (e.ov.y != null) delete e.ov.y;
    } else {
      if (ny != null) e.ov.y = ny;
      else if (e.ov.y != null) delete e.ov.y;
    }
    if (e.kind === "icon") clampIconTransform(e, gapsForRole(e.role));
    markDirty();
    return;
  }

  if (d.kind === "rotate") {
    if (e.kind === "icon" && !L.state.freeform) return;
    const p = transformPivot(e);
      const angle = Math.atan2(py - p.cy, px - p.cx);
      let deg = d.baseRot + (angle - d.startAngle) * 180 / Math.PI;
      deg = Math.round(((deg + 180) % 360) - 180);
      if (Math.abs(deg) < 1) deg = 0;
      if (deg !== e.rot) d.changed = true;
      e.rot = deg;
      if (deg) e.ov.rot = deg;
      else if (e.ov.rot != null) delete e.ov.rot;
      markDirty();
      return;
    }

    if (d.kind === "resize") {
      const b = finalBox(e);
      const rad = b.rot * Math.PI / 180;
      const cos = Math.cos(-rad), sin = Math.sin(-rad);
      const dx = px - d.pivotX, dy = py - d.pivotY;
      const lx = dx * cos - dy * sin;
      const ly = dx * sin + dy * cos;
      const cur = Math.max(6, Math.max(Math.abs(lx), Math.abs(ly)));
      const s = cur / d.d0;
      const newW = Math.max(6, Math.round(d.baseW * d.sx0 * s));
      const newH = Math.max(6, Math.round(d.baseH * d.sy0 * s));
      const sxn = newW / Math.max(1, e.base.w);
      const syn = newH / Math.max(1, e.base.h);
      if (Math.abs(sxn - 1) < 0.02) delete e.ov.sx; else e.ov.sx = Math.round(sxn * 1000) / 1000;
      if (Math.abs(syn - 1) < 0.02) delete e.ov.sy; else e.ov.sy = Math.round(syn * 1000) / 1000;
      const nextSx = e.ov.sx || 1, nextSy = e.ov.sy || 1;
      if (nextSx !== e.sx || nextSy !== e.sy) d.changed = true;
      e.sx = nextSx;
      e.sy = nextSy;
      e.w = Math.max(1, Math.round(e.base.w * e.sx));
      e.h = Math.max(1, Math.round(e.base.h * e.sy));
      // text rows/headings scale around their own content center (kept still);
      // icons keep their inline left edge — the row re-flows around them
      if (e.kind !== "icon") {
        const nx = Math.round(d.pivotX - e.base.x - e.w / 2);
        const ny = Math.round(d.pivotY - e.base.y - e.h / 2);
        if (nx) e.ov.x = nx; else delete e.ov.x;
        if (ny) e.ov.y = ny; else delete e.ov.y;
      }
      if (e.kind === "icon") clampIconTransform(e, gapsForRole(e.role));
      markDirty();
    }
  }

  function commitDrag() {
    const d = L.state.drag;
    if (!d) { L.state.drag = null; return; }
    clearTimeout(L.state.relayoutTimer);
    if (d.changed) {
      commitOverrides();
      buildPages();
      scheduleThumbs(150);
    }
    L.state.drag = null;
    markDirty();
  }

  function onPointerUp(ev) {
    if (L.state.drag) commitDrag();
    const canvas = el("visLiveCanvas");
    if (canvas && canvas.hasPointerCapture && canvas.hasPointerCapture(ev.pointerId)) {
      try { canvas.releasePointerCapture(ev.pointerId); } catch (e) { }
    }
  }

  /* clears every saved transform on this sheet — fresh layout, no stale
     sizes/angles from older editor builds */
  function resetOverrides() {
    const d = L.state.data;
    if (!d || !d.sheet_name) return;
    if (!Object.keys(L.state.overrides || {}).some((id) => Object.keys(L.state.overrides[id] || {}).length)) return;
    if (!confirm("Clear all transforms on this sheet? (Undo works after.)")) return;
    L.state.overrides = {};
    L.state.selected = null;
    commitOverrides();
    buildPages();
    scheduleThumbs(150);
    markDirty();
    toast("Transforms cleared for " + d.sheet_name, "ok");
  }

  function nudgeSelected(dx, dy) {
    const sel = L.state.selected;
    if (!sel) return;
    const e = elementAtId(sel);
    if (!e) return;
    if (e.kind === "icon" && !L.state.freeform) dy = 0; // x-axis constraint
    if (dx) e.ov.x = Math.round((Number(e.ov.x) || 0) + dx);
    if (dy) e.ov.y = Math.round((Number(e.ov.y) || 0) + dy);
    if (!e.ov.x) delete e.ov.x;
    if (!e.ov.y) delete e.ov.y;
    if (e.kind === "icon") clampIconTransform(e, gapsForRole(e.role));
    commitOverrides();
    buildPages();
    scheduleThumbs(150);
    markDirty();
  }

  /* ------------------------------ zoom / pan / fit ------------------------------ */

  function fit() {
    const host = el("visLiveHost");
    const d = L.state.data;
    if (!host || !d) return;
    const rect = host.getBoundingClientRect();
    const s = Math.max(MIN_SCALE, Math.min(MAX_SCALE, (rect.width - 40) / d.canvas_w, (rect.height - 40) / d.canvas_h));
    L.state.scale = s;
    L.state.tx = Math.max(0, (rect.width - d.canvas_w * s) / 2);
    L.state.ty = Math.max(0, (rect.height - d.canvas_h * s) / 2);
    L.state.fitted = true;
    L.state.userView = false;
    layout();
  }

  function setZoom(z) {
    L.state.scale = Math.max(MIN_SCALE, Math.min(MAX_SCALE, z));
    L.state.fitted = false;
    L.state.userView = true;                 // zoomed by the artist: kept through every edit
    centerOnly();
  }

  function zoomBy(f) {
    setZoom(L.state.scale * f);
  }

  function centerOnly() {
    const host = el("visLiveHost");
    const d = L.state.data;
    if (!host || !d) return;
    const rect = host.getBoundingClientRect();
    L.state.tx = Math.max(0, (rect.width - d.canvas_w * L.state.scale) / 2);
    L.state.ty = Math.max(0, (rect.height - d.canvas_h * L.state.scale) / 2);
    layout();
  }

  function layout() {
    const host = el("visLiveHost");
    const d = L.state.data;
    if (!host || !d) return;
    const s = L.state.scale;
    const zl = el("visLiveZoom");
    if (zl) zl.textContent = Math.round(s * 100) + "%";
    resize();
    renderLiveGuides();
    if (window.TextSelect && TextSelect.active) TextSelect.exit();      // its words no longer line up
  }

  /* ------------------------ margin guides (draggable) ------------------------ */

  /* JS twin of visualiser_state.GUIDE_DEFS: real renderer settings keys the
     LIVE canvas itself consumes (heading_top_margin / heading_to_body_gap /
     bottom_margin / inner_canvas_width). */
  const LIVE_GUIDE_DEFS = [
    { id: "header_top", label: "Header Top Margin", key: "heading_top_margin", orientation: "h", edge: "top", min: 0, max: 800 },
    { id: "heading_gap", label: "Heading–Body Gap", key: "heading_to_body_gap", orientation: "h", edge: "gap", min: -5000, max: 2000 },
    { id: "body_bottom", label: "Bottom Margin", key: "bottom_margin", orientation: "h", edge: "bottom", min: 0, max: 1000 },
    { id: "safe_left", label: "Inner Canvas Width", key: "inner_canvas_width", orientation: "v", edge: "left", min: 100, max: 5000 },
    { id: "safe_right", label: "Inner Canvas Width", key: "inner_canvas_width", orientation: "v", edge: "right", min: 100, max: 5000 },
  ];

  function liveGuideGeometry() {
    const d = L.state.data;
    const s = L.state.settings || mergedSettings() || {};
    const safe = recomputeSafeBox(s);
    const headingBottom = (s.heading_top_margin || 0) + (L.state.headingH || 0);
    const bodyTop = headingBottom + (s.heading_to_body_gap || 0);
    const bodyBottom = Math.max((s.heading_top_margin || 0) + 100, d.canvas_h - (s.bottom_margin || 0));
    return {
      canvas_w: d.canvas_w,
      canvas_h: d.canvas_h,
      heading_top: s.heading_top_margin || 0,
      heading_bottom: headingBottom,
      body_top: bodyTop,
      body_bottom: bodyBottom,
      safe_left: safe.left,
      safe_right: safe.left + safe.width,
    };
  }

  function liveGuideValue(gd, geom) {
    if (gd.edge === "top") return geom.heading_top;
    if (gd.edge === "gap") return geom.body_top - geom.heading_bottom;
    if (gd.edge === "bottom") return Math.max(0, geom.canvas_h - geom.body_bottom);
    if (gd.edge === "left") return Math.max(0, geom.canvas_w - 2 * geom.safe_left);
    return Math.max(0, 2 * geom.safe_right - geom.canvas_w); // right
  }

  function liveGuidePos(gd, geom, value) {
    const v = (value !== undefined && value !== null) ? value : liveGuideValue(gd, geom);
    if (gd.edge === "top") return { x: 0, y: v };
    if (gd.edge === "gap") return { x: 0, y: geom.heading_bottom + v };
    if (gd.edge === "bottom") return { x: 0, y: geom.canvas_h - v };
    if (gd.edge === "left") return { x: (geom.canvas_w - v) / 2, y: 0 };
    return { x: (geom.canvas_w + v) / 2, y: 0 }; // right
  }

  function renderLiveGuides() {
    const host = el("visLiveHost");
    const overlay = el("visLiveGuides");
    const canvas = el("visLiveCanvas");
    const d = L.state.data;
    if (!host || !overlay || !canvas || !d) return;
    // payline pages are the build's own image: no live margin guides to drag
    if (L.state.paylines && L.state.paylines.sheet === d.sheet_name) { overlay.innerHTML = ""; return; }
    const hr = host.getBoundingClientRect();
    const cr = canvas.getBoundingClientRect();
    if (!cr.width || !cr.height) return;
    overlay.style.left = (cr.left - hr.left) + "px";
    overlay.style.top = (cr.top - hr.top) + "px";
    overlay.style.width = cr.width + "px";
    overlay.style.height = cr.height + "px";
    const geom = liveGuideGeometry();
    const s = L.state.scale;
    const rects = [
      { cls: "vis-rect-safe", l: geom.safe_left * s, t: geom.body_top * s, w: (geom.safe_right - geom.safe_left) * s, h: (geom.body_bottom - geom.body_top) * s },
      { cls: "vis-rect-head", l: geom.safe_left * s, t: geom.heading_top * s, w: (geom.safe_right - geom.safe_left) * s, h: (geom.heading_bottom - geom.heading_top) * s },
    ];
    const rectHTML = rects.filter((r) => r.w > 0 && r.h > 0 && isFinite(r.w) && isFinite(r.h))
      .map((r) => `<div class="vis-rect ${r.cls}" style="left:${r.l}px;top:${r.t}px;width:${r.w}px;height:${r.h}px"></div>`).join("");
    const lineHTML = LIVE_GUIDE_DEFS.map((gd) => {
      const pos = liveGuidePos(gd, geom);
      if (gd.orientation === "h") {
        return `<div class="vis-guide vis-guide-h" data-gid="${gd.id}" data-edge="${gd.edge}" style="top:${pos.y * s}px"><span class="vis-guide-tag">${esc(gd.label)}</span></div>`;
      }
      return `<div class="vis-guide vis-guide-v" data-gid="${gd.id}" data-edge="${gd.edge}" style="left:${pos.x * s}px"><span class="vis-guide-tag">${esc(gd.label)}</span></div>`;
    }).join("");
    overlay.innerHTML = rectHTML + lineHTML;
  }

  function liveGuideDragStart(gid, ev) {
    const gd = LIVE_GUIDE_DEFS.find((x) => x.id === gid);
    if (!gd || !L.state.data) return;
    const geom = liveGuideGeometry();
    const startValue = liveGuideValue(gd, geom);
    L.state.guideDrag = { gd, geom, startX: ev.clientX, startY: ev.clientY, startValue, value: startValue };
    ev.preventDefault();
    ev.stopPropagation();
  }

  function liveGuideDragMove(ev) {
    const g = L.state.guideDrag;
    if (!g) return;
    // delta is the TOTAL mouse displacement from drag start; the guide must be
    // recomputed from the fixed startValue every move (like the static
    // Visualiser), never accumulated onto a mutated value — otherwise the full
    // delta is re-applied on every pointermove and the guide flies to the edge.
    const delta = (g.gd.orientation === "h" ? ev.clientY - g.startY : ev.clientX - g.startX) / L.state.scale;
    let value;
    if (g.gd.edge === "left") value = g.startValue - 2 * delta;
    else if (g.gd.edge === "right") value = g.startValue + 2 * delta;
    else if (g.gd.edge === "bottom") value = g.startValue - delta;
    else value = g.startValue + delta;
    value = Math.round(value);
    // as far as the canvas goes, whatever its size (a 4K portrait page is 3840 px tall): a guide's own max is for 1080p
    const dd = L.state.data, maxAllowed = dd ? (g.gd.orientation === "h" ? dd.canvas_h || g.gd.max : dd.canvas_w - 40) : g.gd.max;
    value = Math.max(g.gd.min, Math.min(maxAllowed, value));
    g.value = value;
    const pos = liveGuidePos(g.gd, g.geom, value);
    const line = document.querySelector(`#visLiveGuides .vis-guide[data-gid="${g.gd.id}"]`);
    if (line) {
      const px = pos[g.gd.orientation === "h" ? "y" : "x"] * L.state.scale;
      if (g.gd.orientation === "h") line.style.top = px + "px";
      else line.style.left = px + "px";
    }
  }

  function liveGuideDragEnd() {
    const g = L.state.guideDrag;
    L.state.guideDrag = null;
    if (g && typeof g.value === "number") {
      App.set(g.gd.key, g.value);
      // pulled wider than the side margins allow (the text never goes past Margin X): Margin X comes in with it
      const cw = (L.state.data || {}).canvas_w || 0, m0 = Math.max(0, Math.round(Number(App.get("margin_x")) || 0));
      if (cw && (g.gd.edge === "left" || g.gd.edge === "right") && g.value > cw - 2 * m0) App.set("margin_x", Math.max(0, Math.floor((cw - g.value) / 2)));
      App.pushConfig();
      sync();
      renderLiveGuides();
    }
  }

  function bindViewEvents() {
    const host = el("visLiveHost");
    if (!host) return;

    host.addEventListener("wheel", (ev) => {
      ev.preventDefault();
      if (!L.state.data) return;
      const rect = host.getBoundingClientRect();
      const mx = ev.clientX - rect.left;
      const my = ev.clientY - rect.top;
      const prev = L.state.scale;
      const next = Math.max(MIN_SCALE, Math.min(MAX_SCALE, prev * (ev.deltaY < 0 ? 1.12 : 1 / 1.12)));
      const ratio = next / prev;
      L.state.tx = mx - (mx - L.state.tx) * ratio;
      L.state.ty = my - (my - L.state.ty) * ratio;
      L.state.scale = next;
      L.state.fitted = false;
      L.state.userView = true;               // zoomed by the artist: kept through every edit
      layout();
    }, { passive: false });

    host.addEventListener("pointerdown", (ev) => {
      if (ev.button !== 0) return;
      const guideEl = ev.target && ev.target.closest ? ev.target.closest(".vis-guide") : null;
      if (guideEl) {
        liveGuideDragStart(guideEl.dataset.gid, ev);
        return;
      }
      if (ev.target && ev.target.closest && ev.target.closest(".tblh, .vis-cut, #visPartMenu, #tblCellPop, #visTableBar")) return;
      if (window.TextSelect && TextSelect.active) TextSelect.exit();   // a press outside the text: done
      if (ev.target && ev.target.id === "visLiveCanvas") {
        if (onPointerDown(ev)) return;
      }
      L.state.pan = { x: ev.clientX, y: ev.clientY, tx: L.state.tx, ty: L.state.ty };
      host.classList.add("vis-panning");
      ev.preventDefault();
    });
    // tables: ✂ on their edges, right-click a part for its page / join (same as the Tables section)
    const tableRefresh = () => refreshData(true);
    host.addEventListener("pointermove", (ev) => {
      if (!L.state.drag && !L.state.pan && L.state.editMode !== "icon") cutHover(ev, host, el("visLiveCanvas"), tableRefresh);
    });
    host.addEventListener("pointerleave", hideCutButtons);
    host.addEventListener("contextmenu", (ev) => {
      if (window.TextSelect && TextSelect.active) return;
      // an icon or a <TOKEN> without a picture: size / gaps / picture (Assets & Icons)
      if (window.IconStudio && !ev.target.closest(".tsel-menu, #visRoleMenu, #visPartMenu") && IconStudio.contextMenuVis(ev)) { ev.stopPropagation(); return; }
      if (L.state.editMode === "icon") return;
      if (tablePartMenu(ev, host, el("visLiveCanvas"), tableRefresh)) { ev.stopPropagation(); return; }
      if (rowRoleMenu(ev, host, el("visLiveCanvas"), tableRefresh)) ev.stopPropagation();
    });
    host.addEventListener("dblclick", (ev) => {     // a box of the selected table: its own look
      if (ev.target.closest && ev.target.closest(".tblh") && window.AppTblVis && AppTblVis.cellInVisualiser && AppTblVis.cellInVisualiser(ev)) {
        ev.stopImmediatePropagation();
      }
    });
    // double-click a row of text (Text Edit): select text like in a document, right-click to style it
    host.addEventListener("dblclick", (ev) => {
      const canvas = el("visLiveCanvas");
      if (L.state.editMode === "icon" || !canvas || ev.target !== canvas || !window.TextSelect || !L.state.data) return;
      const r = canvas.getBoundingClientRect();
      const e = hitTest((ev.clientX - r.left) / L.state.scale, (ev.clientY - r.top) / L.state.scale);
      if (!e || (e.kind !== "line" && e.kind !== "heading")) return;   // an icon: its own editor
      L.state.selected = null;
      L.state.drag = null;
      markDirty();
      TextSelect.enter(ev.clientX, ev.clientY, { host, canvas, sheet: () => L.state.sheet || "",
                                                 refresh: () => refreshData(true) });
    });

    if (L.state._docBound) return;
    L.state._docBound = true;

    document.addEventListener("pointermove", (ev) => {
      if (L.state.guideDrag) { liveGuideDragMove(ev); return; }
      if (L.state.drag) { onPointerMove(ev); return; }
      const p = L.state.pan;
      if (p) {
        L.state.userView = true;
        L.state.tx = p.tx + (ev.clientX - p.x);
        L.state.ty = p.ty + (ev.clientY - p.y);
        layout();
      }
    });

    document.addEventListener("pointerup", (ev) => {
      if (L.state.guideDrag) liveGuideDragEnd();
      if (L.state.drag) onPointerUp(ev);
      L.state.pan = null;
      const hostEl = el("visLiveHost");
      if (hostEl) hostEl.classList.remove("vis-panning");
    });

    window.addEventListener("resize", () => {
      if (App.route === "visualiser-live" && L.state.data) {
        if (L.state.fitted) fit();
        else centerOnly();
      }
    });
  }

  /* ------------------------------ keyboard ------------------------------ */

  function onKeyDown(ev) {
    if (!el("visLiveCanvas") || !L.state.data) return;
    const t = document.activeElement;
    if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT")) return;
    const k = ev.key.toLowerCase();
    if ((ev.ctrlKey || ev.metaKey) && k === "z" && !ev.shiftKey) {
      ev.preventDefault();
      undo();
      return;
    }
    if ((ev.ctrlKey || ev.metaKey) && (k === "y" || (k === "z" && ev.shiftKey))) {
      ev.preventDefault();
      redo();
      return;
    }
    if (ev.key === "Escape") {
      L.state.selected = null;
      L.state.drag = null;
      L.state.guideDrag = null;
      L.state.pan = null;
      markDirty();
      return;
    }
    if (k === "delete" || k === "backspace") {
      const sel = L.state.selected;
      if (!sel) return;
      ev.preventDefault();
      const e = elementAtId(sel);
      L.state.selected = null;
      if (e && L.state.overrides[sel] && Object.keys(L.state.overrides[sel]).length) {
        delete L.state.overrides[sel];
        applyOverride(e);
        commitOverrides();
        buildPages();
        scheduleThumbs(150);
      }
      markDirty();
      return;
    }
    if (k === "arrowup" || k === "arrowdown" || k === "arrowleft" || k === "arrowright") {
      if (!L.state.selected) return;
      ev.preventDefault();
      const step = ev.shiftKey ? 10 : 1;
      const dx = k === "arrowleft" ? -step : k === "arrowright" ? step : 0;
      const dy = k === "arrowup" ? -step : k === "arrowdown" ? step : 0;
      nudgeSelected(dx, dy);
    }
  }

  /* ------------------------------ verify ------------------------------ */

  function canvasToPng() {
    const d = L.state.data;
    if (!d) return "";
    const out = document.createElement("canvas");
    out.width = d.canvas_w;
    out.height = d.canvas_h;
    L.state.renderTarget = out;
    draw();
    L.state.renderTarget = null;
    return out.toDataURL("image/png").split(",")[1] || "";
  }

  async function verify() {
    const d = L.state.data;
    if (!d) return;
    if (!d.sheet_name) return;
    if (L.state.pages[L.state.page] && L.state.pages[L.state.page].payline) {
      toast("Pay lines pages are drawn by the build renderer itself — nothing to verify.", "ok");
      return;
    }
    const badge = el("visLiveBadge");
    const btn = el("visLiveVerify");
    if (badge) { badge.classList.remove("idle"); badge.textContent = "Verifying…"; }
    if (btn) btn.disabled = true;
    try {
      const png_b64 = canvasToPng();
      const res = await api("/api/visualiser/verify", {
        method: "POST",
        body: { sheet_name: d.sheet_name, page: L.state.page + 1, png_b64 },
      });
      if (res && res.ok) {
        L.state.verify = res;
        L.state.showDiff = false;
        if (btn) btn.textContent = "✓ Page " + (L.state.page + 1) + ": " + res.match_pct + "% match";
        const note = el("visLiveVerifyNote");
        if (note) note.textContent = "mean Δ " + res.mean_diff;
        if (badge) badge.textContent = res.match_pct + "% WYSIWYG";
        const diffImg = el("visLiveDiffImg");
        if (diffImg && res.diff_token) diffImg.src = "/api/table_preview/" + encodeURIComponent(res.diff_token) + "?v=" + Date.now();
      } else {
        toast((res && res.error) || "Verify failed", "warn");
        if (badge) badge.textContent = "Verify failed";
      }
    } catch (e) {
      if (badge) badge.textContent = "Verify error";
    }
    if (btn) btn.disabled = false;
    if (badge) badge.classList.add("idle");
  }

  function toggleDiff() {
    L.state.showDiff = !L.state.showDiff;
    markDirty();
    const ov = el("visLiveDiff");
    if (ov) ov.style.display = L.state.showDiff ? "block" : "none";
  }

  /* ------------------------------ rAF loop ------------------------------ */

  function markDirty() {
    L.state.dirty = true;
    if (!L.state.raf) {
      L.state.raf = requestAnimationFrame(() => {
        L.state.raf = 0;
        if (L.state.dirty) { draw(); L.state.dirty = false; }
      });
    }
    if (L.state.drag) scheduleRelayout();
  }

  /* during a live drag the auto-layout is rebuilt (debounced) so text re-wraps
     and content flows to the next continued page around transformed icons. */
  function scheduleRelayout(ms) {
    clearTimeout(L.state.relayoutTimer);
    if (!L.state.drag || !L.state.drag.changed) return;
    L.state.relayoutTimer = setTimeout(() => {
      if (!L.state.drag) return;
      buildPages();
      markDirty();
    }, ms || 180);
  }

  /* ------------------------------ page thumbs ------------------------------ */

  function renderThumb(p) {
    const d = L.state.data;
    if (!d) return "";
    const dpr = window.devicePixelRatio || 1;
    const w = THUMB_W * dpr;
    const h = Math.max(40, Math.round(w * d.canvas_h / d.canvas_w));
    const c = document.createElement("canvas");
    c.width = w; c.height = h;
    const savedTarget = L.state.renderTarget;
    const savedPage = L.state.page;
    L.state.renderTarget = c;
    L.state.page = p;
    draw();
    L.state.renderTarget = savedTarget;
    L.state.page = savedPage;
    return c.toDataURL("image/png");
  }

  function scheduleThumbs(ms) {
    clearTimeout(L.state.thumbTimer);
    L.state.thumbTimer = setTimeout(() => {
      const d = L.state.data;
      const host = el("visLiveThumbs");
      if (!d || !host) return;
      const urls = [];
      for (let p = 0; p < L.state.pages.length; p++) {
        try { urls.push(renderThumb(p)); } catch (e) { urls.push(""); }
      }
      L.state.thumbUrls = urls;
      host.innerHTML = urls.map((u, p) => {
        const pl = L.state.pages[p] && L.state.pages[p].payline;
        const label = pl ? esc(pl.name) : "Page " + (p + 1);
        return `
        <div class="vis-thumb ${p === L.state.page ? "active" : ""}" data-page="${p}" onclick="AppLive.setPage(${p})" title="${label}">
          ${u ? `<img src="${u}" alt="${label}" />` : `<div class="vis-thumb-empty">…</div>`}
          <span class="vis-thumb-label">${label}</span>
        </div>`;
      }).join("");
    }, ms || 200);
  }

  function setPage(p) {
    const pages = L.state.pages;
    if (!pages || p < 0 || p >= pages.length) return;
    if (window.AppTblVis && AppTblVis.clearVisualiser) AppTblVis.clearVisualiser();   // its table is on the old page
    if (window.IconStudio && IconStudio.clearVis) IconStudio.clearVis();
    L.state.page = p;
    L.state.selected = null;
    L.state.drag = null;
    L.state.elements = pages[p].elements;
    const btns = document.querySelectorAll(".vis-thumb");
    btns.forEach((b) => b.classList.toggle("active", Number(b.dataset.page) === p));
    markDirty();
  }

  /* ------------------------------ data ------------------------------ */

  function preloadIcons() {
    const d = L.state.data;
    if (!d) return;
    for (const token in d.icons) {
      if (L.state.icons[token] || !d.icons[token].url) continue;
      const img = new Image();
      const url = d.icons[token].url;
      img.onload = () => {
        L.state.icons[token] = { img, w: img.naturalWidth, h: img.naturalHeight, url };
        const before = (L.state.pages || []).length;
        buildPages();
        // with the picture in, the sheet can have another page: the Typography rail and page count follow
        if ((L.state.pages || []).length !== before && window.AppTypoVis && AppTypoVis.onPagesChanged) AppTypoVis.onPagesChanged();
        markDirty();
        scheduleThumbs(150);
      };
      img.src = d.icons[token].url + (d.icons[token].url.indexOf("?") === -1 ? "?" : "&") + Date.now();
    }
  }

  function preloadStrips() {
    const d = L.state.data;
    if (!d) return;
    L.state.stripImgs = L.state.stripImgs || {};
    for (const tb of d.tables || []) loadStrip(tb.url);
  }
  // a table's picture, loaded once (the page redraws when it arrives)
  function loadStrip(url) {
    L.state.stripImgs = L.state.stripImgs || {};
    if (!url || L.state.stripImgs[url]) return;
    const img = new Image();
    img.onload = () => { L.state.stripImgs[url] = img; markDirty(); scheduleThumbs(150); };
    img.src = url;
  }

  function preloadBg() {
    const d = L.state.data;
    if (!d) return;
    const url = d.settings.bg_image_url;
    const s = mergedSettings() || d.settings;
    if (!url || s.bg_source === "color") { L.state.images = null; return; }
    if (L.state.images && L.state.images.bgUrl === url) return;
    const img = new Image();
    img.onload = () => { L.state.images = { bg: img, bgUrl: url }; markDirty(); scheduleThumbs(150); };
    img.src = url;
  }

  function scheduleDataRefresh(ms) {
    clearTimeout(L.state.dataRefreshTimer);
    L.state.dataRefreshTimer = setTimeout(() => refreshData(false), ms || 600);
  }

  async function refreshData(force) {
    if (!L.state.sheet) return;
    if (studioKind(L.state.sheet)) { await showStudioSheet(L.state.sheet); return; }
    try {
      // the server lays the page out from the SAVED config: send pending edits first
      // (pushConfig is debounced, so a quick refresh could otherwise use old values)
      if (App.flushConfig) await App.flushConfig();
      const want = L.state.sheet;
      const d = await api("/api/visualiser/editor-data", { method: "POST", body: { sheet_name: want, force: !!force } });
      if (L.state.sheet !== want) return;            // another page was picked while this one loaded
      if (!d || !d.ok) {
        if (d && d.error) toast(d.error, "warn");
        return;
      }
      const sheetChanged = L.state.data && L.state.data.sheet_name !== d.data.sheet_name;
      // the pictures already loaded stay (each by its url): drawn without them, the page flashed
      const kept = sheetChanged ? {} : L.state.icons || {}, bgUrl = (d.data.settings || {}).bg_image_url;
      L.state.data = d.data;
      L.state.fxDiag = null;
      L.state.sheet = d.data.sheet_name;
      L.state.fontsLoaded = false;
      L.state.icons = {};
      Object.entries(d.data.icons || {}).forEach(([tok, info]) => {
        if (kept[tok] && info && kept[tok].url === info.url) L.state.icons[tok] = kept[tok];
      });
      if (sheetChanged) L.state.stripImgs = {};
      if (!(L.state.images && bgUrl && L.state.images.bgUrl === bgUrl)) L.state.images = null;
      L.state.selected = null;
      L.state.verify = null;
      if (sheetChanged) L.state.page = 0;
      L.state.overrides = readOverrides();
      L.state.paylines = await fetchPaylinePages(d.data.sheet_name);
      if (L.state.paylines) L.state.canon = null;
      else await fetchCanonicalData();
      syncPaylineUi();
      await ensureFonts();
      preloadIcons();
      preloadStrips();
      preloadBg();
      buildPages();
      resize();
      if (!L.state.fitted && !L.state.userView) fit();
      scheduleThumbs(100);
      renderPageBadge();
    } catch (e) { /* keep old data */ }
  }

  /* ----------------------- external render target -----------------------
     Typography preview reuses the EXACT live canvas pipeline: load the
     editor-data payload, preload fonts/icons/strips/bg, buildPages() and
     draw() into any <canvas> via L.state.renderTarget. */

  /* Load a sheet and render page 1 into the given canvas.
     Returns a geometry object for guides, or null when it fails. */
  /* Another preview (Typography) styles words too: click a text row there and the same
     bar opens in that preview. Returns true when a text row was hit. */
  function styleRowAt(canvas, host, cssX, cssY, refresh, opts) {
    const d = L.state.data;
    if (!d || !canvas) return false;
    const k = canvas.getBoundingClientRect().width / d.canvas_w;
    const e = hitTest(cssX / k, cssY / k);
    const old = el("visStyleBar");
    if (old && old.parentElement !== host) old.remove();         // the bar moves to this preview
    Object.assign(L.state, { barHost: host, barCanvas: canvas, barRefresh: refresh, editMode: "text", virtualRow: null });
    if (e && e.kind === "table" && e.design_key) {            // a table: pick its design right here
      const bar = el("visStyleBar");
      if (bar) bar.style.display = "none";
      L.state.selected = e.id;
      draw();
      if (!(opts && opts.selectOnly)) showTableBar(host, canvas, e, refresh);   // Tables: only from its ✎
      else hideTableBar();
      return true;
    }
    hideTableBar();
    if (!e || (e.kind !== "line" && e.kind !== "heading")) {
      L.state.selected = null;
      const bar = el("visStyleBar");
      if (bar) bar.style.display = "none";
      draw();
      return false;
    }
    L.state.selected = e.id;
    SB.key = "";
    syncStyleBar();
    draw();
    return true;
  }
  /* the table-design bar: this table's look (or every table's), by picture */
  async function showTableBar(host, canvas, e, refresh, onClose) {
    hideTableBar();
    const bar = document.createElement("div");
    bar.id = "visTableBar";
    bar.className = "vis-style-bar vis-table-bar";
    bar.addEventListener("pointerdown", (ev) => ev.stopPropagation());
    bar.addEventListener("mousedown", (ev) => ev.stopPropagation());
    bar.addEventListener("click", (ev) => ev.stopPropagation());
    host.appendChild(bar);
    let info;
    try { info = await api("/api/tables/designs", { method: "POST", body: {} }); } catch (_) { info = null; }
    const ts = (App.state.config.table_style = App.state.config.table_style || {});
    const own = (ts.designs || {})[e.design_key];
    const stamp = Date.now();
    const designs = (info && info.designs) || [];
    bar.innerHTML = `<div class="vsb-head"><b>This table's design</b><span class="vsb-hint">${own ? "its own" : "same as every table"}</span>
        <button class="vsb-x" title="Close" data-tbx>✕</button></div>
      <div class="td-grid">${designs.map((d) => `<button class="td-opt ${d.id === e.design ? "on" : ""}" data-tbd="${esc(d.id)}" title="${esc(d.about || d.name)}">
        <img src="/api/tables/design_swatch?id=${encodeURIComponent(d.id)}&v=${stamp}" alt=""><span>${esc(d.name)}</span></button>`).join("")}</div>
      <div class="vsb-row"><span class="vsb-hint">The design you pick here is for this table only — every table: the panel on the right.</span>
        ${own ? `<button class="pt-btn secondary small" data-tbreset>Same as every table</button>` : ""}
      </div>
      <div class="vsb-row">${tableCuts(ts, e.design_key).length
        ? `<span class="vsb-hint">Cut into ${tableCuts(ts, e.design_key).length + 1} parts (same header row) — right-click a part in Tables to choose its page.</span>
           <button class="pt-btn secondary small" data-tbjoin>Join back into one table</button>`
        : `<span class="vsb-hint">✂ To cut it into parts: open the Tables section, hover the table's left or right edge and click the scissors.</span>`}</div>
      ${tableTextHtml(ts, e)}`;
    const place = () => {
      if (L.state.tableBarAnchor && L.state.tableBarAnchor(bar)) return;   // the Tables preview: beside its ✎
      const cr = canvas.getBoundingClientRect(), hr = host.getBoundingClientRect();
      const k = cr.width / (L.state.data ? L.state.data.canvas_w : 1920);
      const top = cr.top - hr.top + (e.y + e.h) * k + 8;
      bar.style.top = Math.max(4, Math.min(top, hr.height - bar.offsetHeight - 4)) + "px";
      bar.style.left = Math.max(4, Math.min(hr.width - bar.offsetWidth - 4, cr.left - hr.left + (e.x + e.w / 2) * k - bar.offsetWidth / 2)) + "px";
    };
    place();
    const save = async () => {
      App.refreshUI();
      if (App.flushConfig) await App.flushConfig();
      hideTableBar();
      if (refresh) await refresh(); else await refreshData(true);
      if (window.TableDesigns) TableDesigns.load();
    };
    bar.querySelector("[data-tbx]").addEventListener("click", () => { hideTableBar(); if (onClose) onClose(); else { L.state.selected = null; draw(); } });
    bar.querySelectorAll("[data-tbd]").forEach((b) => b.addEventListener("click", () => {
      ts.designs = Object.assign({}, ts.designs || {}, { [e.design_key]: b.dataset.tbd });   // this table only
      save();
    }));
    bar.querySelector("[data-tbjoin]")?.addEventListener("click", () => {
      joinAllParts(e, App.route === "tables" && window.AppTblVis ? () => AppTblVis.refreshPreview.now(true) : null);
    });
    bar.querySelector("[data-tbreset]")?.addEventListener("click", () => {
      const d = Object.assign({}, ts.designs || {});
      delete d[e.design_key];
      ts.designs = d;
      save();
    });
    TB.onClose = onClose;
    wireTableText(bar, ts, e, save, host, canvas, refresh);
    place();
  }

  /* where the artist cut a table (✂): table_style.split_tables[key] = [body row a part starts at] */
  function tableCuts(ts, key) {
    const v = ((ts || {}).split_tables || {})[key];
    return Array.isArray(v) ? v.map(Number).filter((k) => k > 0) : [];
  }
  function setTableCuts(key, cuts) {
    const ts = (App.state.config.table_style = App.state.config.table_style || {});
    const sp = Object.assign({}, ts.split_tables || {});
    const list = [...new Set(cuts.map(Number).filter((k) => k > 0))].sort((p, q) => p - q);
    if (list.length) sp[key] = list; else delete sp[key];
    ts.split_tables = sp;
  }
  /* table_style.split_pages[key] = {part index: -1 (page before) | 1 (page after)}; the rest share the table's page */
  function partPages(ts, key) {
    return Object.assign({}, (((ts || {}).split_pages || {})[key]) || {});
  }
  function partsOf(key) {                            // the parts of a cut table on every page: [{e, page}]
    const out = [];
    (L.state.pages || []).forEach((pg, i) => (pg.elements || []).forEach((el2) => {
      if (el2.kind === "table" && el2.design_key === key) out.push({ e: el2, page: i + 1 });
    }));
    return out.sort((p, q) => ((p.e.cut && p.e.cut.pi) || 0) - ((q.e.cut && q.e.cut.pi) || 0));
  }

  /* change a cut table: its cuts, which page each part is on, and the parts' moves (live_overrides
     ids "table.<row>[.<part>]") renumbered so every part keeps what the artist did to it */
  async function saveCuts(key, cuts, message, opts) {
    opts = opts || {};
    const ts = (App.state.config.table_style = App.state.config.table_style || {});
    setTableCuts(key, cuts);
    if (opts.pages !== undefined) {
      const sp = Object.assign({}, ts.split_pages || {});
      const clean = {};
      Object.entries(opts.pages || {}).forEach(([k2, v]) => { if (Number(v) === -1 || Number(v) === 1) clean[k2] = Number(v); });
      // a whole (uncut) table can only start on the next page: {0: 1}
      const whole = !tableCuts(ts, key).length && Object.keys(clean).length === 1 && clean[0] === 1;
      if (Object.keys(clean).length && (tableCuts(ts, key).length || whole)) sp[key] = clean; else delete sp[key];
      ts.split_pages = sp;
    }
    if (opts.renumber && opts.rowStart != null && L.state.data) {
      const dyn = (App.state.config.dynamic_settings = App.state.config.dynamic_settings || {});
      const lo = Object.assign({}, dyn.live_overrides || {});
      const sheet = L.state.data.sheet_name, mine = Object.assign({}, lo[sheet] || {});
      const id = (pi) => "table." + opts.rowStart + (pi ? "." + pi : "");
      const old = {};
      for (let pi = 0; pi < 200; pi++) if (mine[id(pi)]) { old[pi] = mine[id(pi)]; delete mine[id(pi)]; }
      Object.entries(old).forEach(([pi, ov]) => {
        const to = opts.renumber(Number(pi));
        if (to != null && to >= 0) mine[id(to)] = ov;
      });
      lo[sheet] = mine;
      dyn.live_overrides = lo;
    }
    App.refreshUI();
    if (App.flushConfig) await App.flushConfig();
    hideCutButtons();
    hideTableBar();
    L.state.tableBarFor = null;
    if (opts.refresh) await opts.refresh(); else await refreshData(true);
    // say where the parts actually landed (page numbers as in the page list)
    const where = partsOf(key).map((p) => p.page);
    toast(typeof message === "function" ? message(where) : message);
  }
  function cutTableAt(e, i, refresh) {                // ✂ between body rows i-1 and i
    const c = e.cut, ts = App.state.config.table_style || {};
    const pages = partPages(ts, e.design_key), next = {};
    Object.entries(pages).forEach(([k2, v]) => { const j = Number(k2); next[j > c.pi ? j + 1 : j] = v; });
    if (pages[c.pi] != null) next[c.pi + 1] = pages[c.pi];       // both halves stay where the part was
    return saveCuts(e.design_key, c.cuts.concat([i]), (where) => {
      const top = where[c.pi], bottom = where[c.pi + 1];
      return (top === bottom ? `Table cut — both parts are on page ${top || "?"}. ` : `Table cut — the top part is on page ${top || "?"}, the bottom part on page ${bottom || "?"}. `)
        + "Right-click a part to put it on the previous or next page; drag it anywhere. Design, borders and text changes apply to both.";
    }, { pages: next, rowStart: e.row_start, renumber: (j) => (j > c.pi ? j + 1 : j), refresh });
  }
  function joinTableParts(e, withBelow, refresh) {    // put part pi back together with the one above / below
    const c = e.cut, ts = App.state.config.table_style || {};
    const lower = withBelow ? c.pi + 1 : c.pi;             // the part that disappears into the one above it
    const cut = c.cuts.slice().sort((p, q) => p - q)[lower - 1];
    if (cut == null) return null;
    const pages = partPages(ts, e.design_key), next = {};
    Object.entries(pages).forEach(([k2, v]) => { const j = Number(k2); if (j !== lower) next[j > lower ? j - 1 : j] = v; });
    return saveCuts(e.design_key, c.cuts.filter((k2) => Number(k2) !== cut), (where) =>
      where.length > 1 ? `Joined — that part is on page ${where[lower - 1] || "?"} now.` : `Joined back into one table — it is on page ${where[0] || "?"} (where it has room).`,
      { pages: next, rowStart: e.row_start, renumber: (j) => (j === lower ? -1 : j > lower ? j - 1 : j), refresh });
  }
  function joinAllParts(e, refresh) {
    return saveCuts(e.design_key, [], (where) => `Joined back into one table — it is on page ${where[0] || "?"} now (where it has room).`,
      { pages: {}, rowStart: e.row_start, renumber: (j) => (j === 0 ? 0 : -1), refresh });
  }
  function movePartToPage(e, g, refresh) {            // -1 page before the table's · 0 the table's page · 1 page after
    const c = e.cut, ts = App.state.config.table_style || {};
    const pages = partPages(ts, e.design_key);
    if (g) pages[c.pi] = g; else delete pages[c.pi];
    // a part sent to another page starts there afresh (its old move belonged to the old page)
    return saveCuts(e.design_key, c.cuts, (where) => {
      const part = partsOf(e.design_key)[c.pi], safe = L.state.safe;
      const over = part && safe && part.e.base.y + part.e.base.h > safe.bottom + 1;
      return `Part ${c.pi + 1} is on page ${where[c.pi] || "?"} now.`
        + (over ? " It is taller than the room left there — drag it, or cut it again with ✂." : "");
    },
      { pages, rowStart: e.row_start, renumber: (j) => (j === c.pi ? -1 : j), refresh });
  }

  /* right-click a part of a cut table: which page it goes on, join it, reset its move */
  function hidePartMenu() {
    document.getElementById("visPartMenu")?.remove();
  }
  function tablePartMenu(ev, host, canvas, refresh) {
    hidePartMenu();
    const d = L.state.data;
    if (!d || !canvas) return false;
    const r = canvas.getBoundingClientRect(), k = r.width / d.canvas_w;
    const e = hitTest((ev.clientX - r.left) / k, (ev.clientY - r.top) / k);
    if (!e || e.kind !== "table" || !e.cut || !e.design_key) return false;
    ev.preventDefault();
    const c = e.cut, n = c.cuts.length + 1, g = Number((c.pages || {})[c.pi]) || 0;
    const moved = !!(L.state.overrides[e.id] && (L.state.overrides[e.id].x || L.state.overrides[e.id].y));
    const items = [];
    if (n > 1) {
      if (g !== -1) items.push(["prev", g === 1 ? "Back to the table's page" : "Put on the previous page (under the text above)"]);
      if (g !== 1) items.push(["next", g === -1 ? "Back to the table's page" : "Put on the next page"]);
      if (Object.keys(c.pages || {}).length) items.push(["together", "Keep all parts together on one page"]);
      items.push(["sep"]);
      if (c.pi > 0) items.push(["joinUp", "Join with the part above"]);
      if (c.pi < n - 1) items.push(["joinDown", "Join with the part below"]);
      items.push(["joinAll", "Join all back into one table"]);
    } else {                                          // a whole table: start it on the next page, or back
      if (g === 1) items.push(["home", "Back to its own page"]);
      else if (e.atTop) items.push(["hint", "It already starts this page."]);
      else items.push(["next", "Start on the next page"]);
      items.push(["hint", "✂ Hover the table's left or right edge and click the scissors at a row line to cut it."]);
    }
    if (moved) items.push(["sep"], ["reset", "Put this part back in its place"]);
    if (!items.length) items.push(["hint", "✂ Hover the table's left or right edge and click the scissors at a row line to cut it."]);
    const menu = document.createElement("div");
    menu.id = "visPartMenu";
    menu.className = "tsel-menu vis-part-menu";
    menu.innerHTML = `<div class="vpm-head">${n > 1 ? `Table part ${c.pi + 1} of ${n}` : "Table"}</div>` + items.map(([id, label]) =>
      id === "sep" ? `<div class="vpm-sep"></div>` : id === "hint" ? `<div class="vpm-hint">${esc(label)}</div>` : `<button data-pm="${id}">${esc(label)}</button>`).join("");
    const hr = host.getBoundingClientRect();
    menu.style.left = (ev.clientX - hr.left) + "px";
    menu.style.top = (ev.clientY - hr.top) + "px";
    ["mousedown", "pointerdown", "click", "contextmenu", "wheel"].forEach((t) => menu.addEventListener(t, (e2) => e2.stopPropagation()));
    host.appendChild(menu);
    const mw = menu.offsetWidth, mh = menu.offsetHeight;
    menu.style.left = Math.max(4, Math.min(host.clientWidth - mw - 4, ev.clientX - hr.left)) + "px";
    menu.style.top = Math.max(4, Math.min(host.clientHeight - mh - 4, ev.clientY - hr.top)) + "px";
    menu.querySelectorAll("[data-pm]").forEach((b) => b.addEventListener("click", async () => {
      hidePartMenu();
      const a = b.dataset.pm;
      if (a === "prev") await movePartToPage(e, g === 1 ? 0 : -1, refresh);
      else if (a === "next") await movePartToPage(e, g === -1 ? 0 : 1, refresh);
      else if (a === "home") await movePartToPage(e, 0, refresh);
      else if (a === "together") await saveCuts(e.design_key, c.cuts, (where) => `All parts are on page ${where[0] || "?"} now.`, { pages: {}, refresh });
      else if (a === "joinUp") await joinTableParts(e, false, refresh);
      else if (a === "joinDown") await joinTableParts(e, true, refresh);
      else if (a === "joinAll") await joinAllParts(e, refresh);
      else if (a === "reset") await saveCuts(e.design_key, c.cuts, "Part put back in its place.", { rowStart: e.row_start, renumber: (j) => (j === c.pi ? -1 : j), refresh });
    }));
    setTimeout(() => document.addEventListener("mousedown", hidePartMenu, { once: true }), 0);
    return true;
  }

  /* right-click a row of text: treat it as a heading, a subheading or normal text
     (dynamic_settings.row_roles[sheet]["row:N"], row_roles.py — every renderer reads it) */
  function hideRoleMenu() {
    document.getElementById("visRoleMenu")?.remove();
  }
  function rowRoleMenu(ev, host, canvas, refresh) {
    hideRoleMenu();
    const d = L.state.data;
    if (!d || !canvas || !host) return false;
    const r = canvas.getBoundingClientRect(), k = r.width / d.canvas_w;
    let e = hitTest((ev.clientX - r.left) / k, (ev.clientY - r.top) / k);
    if (e && e.kind === "icon" && e.role !== "heading") {
      e = (L.state.elements || []).find((x) => x.kind === "line" && String(x.row) === String(e.row)) || null;
    }
    // its settings key: "row:N" — or "box:<id>", a text box being laid out like a row of the paragraph
    const key = e && ((e.meta && e.meta.key) || (/^\d+$/.test(String(e.row)) ? "row:" + e.row : ""));
    if (!e || e.kind !== "line" || !key) return false;
    ev.preventDefault();
    const sheet = d.sheet_name, what = key.startsWith("box:") ? "This text box" : `Row ${e.row}`;
    const ds = (App.state.config.dynamic_settings = App.state.config.dynamic_settings || {});
    const cur = ((ds.row_roles || {})[sheet] || {})[key] || "";
    // a row a table drew until the artist made it normal text (table_style.table_rows, table_rows.py)
    const inTable = (L.state.elements || []).map((t) => t.kind === "table" && t.geo && (t.geo.text_rows || []).find((x) => String(x.row) === String(e.row))
      && { rk: t.geo.rows_key || t.design_key, off: Number((t.geo.text_rows || []).find((x) => String(x.row) === String(e.row)).off) }).find(Boolean);
    const menu = document.createElement("div");
    menu.id = "visRoleMenu";
    menu.className = "tsel-menu vis-part-menu";
    menu.innerHTML = `<div class="vpm-head">${key.startsWith("box:") ? "This text box" : `This row (Excel row ${esc(e.row)})`}</div>`
      + [["heading", "Treat as heading"], ["subheading", "Treat as subheading"], ["", "Treat as normal text"]]
        .map(([v, t]) => `<button data-role="${v}" class="${cur === v ? "vpm-on" : ""}">${cur === v ? "✓ " : ""}${t}</button>`).join("")
      + `<div class="vpm-hint">Heading = the page heading's look · Subheading = Canvas › Subheading. The row stays where it is.</div>`
      + (inTable ? `<div class="vpm-sep"></div><button data-backtable title="This row was taken out of a table (Treat as normal text)">↺ Back in the table</button>` : "");
    ["mousedown", "pointerdown", "click", "contextmenu", "wheel"].forEach((t) => menu.addEventListener(t, (e2) => e2.stopPropagation()));
    host.appendChild(menu);
    const hr = host.getBoundingClientRect();
    menu.style.left = Math.max(4, Math.min(host.clientWidth - menu.offsetWidth - 4, ev.clientX - hr.left)) + "px";
    menu.style.top = Math.max(4, Math.min(host.clientHeight - menu.offsetHeight - 4, ev.clientY - hr.top)) + "px";
    menu.querySelector("[data-backtable]")?.addEventListener("click", async () => {
      hideRoleMenu();
      const ts = (App.state.config.table_style = App.state.config.table_style || {});
      const all = Object.assign({}, ts.table_rows || {}), sp = Object.assign({}, all[inTable.rk] || {});
      sp.text = (sp.text || []).filter((o) => Number(o) !== inTable.off);
      if (!sp.text.length) delete sp.text;
      if (Object.keys(sp).length) all[inTable.rk] = sp; else delete all[inTable.rk];
      ts.table_rows = all;
      App.refreshUI();
      if (App.flushConfig) await App.flushConfig();
      if (refresh) await refresh(); else await refreshData(true);
      toast(`${what} is back in the table.`);
    });
    menu.querySelectorAll("[data-role]").forEach((b) => b.addEventListener("click", async () => {
      hideRoleMenu();
      const v = b.dataset.role;
      const all = Object.assign({}, ds.row_roles || {});
      const mine = Object.assign({}, all[sheet] || {});
      if (v) mine[key] = v; else delete mine[key];
      if (Object.keys(mine).length) all[sheet] = mine; else delete all[sheet];
      ds.row_roles = all;
      App.refreshUI();
      if (App.flushConfig) await App.flushConfig();
      if (refresh) await refresh(); else await refreshData(true);
      toast(v ? `${what} is a ${v} now — it keeps its place on the page.` : `${what} is normal text again.`);
    }));
    setTimeout(() => document.addEventListener("mousedown", hideRoleMenu, { once: true }), 0);
    return true;
  }

  /* hover a table's left / right edge: ✂ at the nearest row line cuts it there; on a lower part's
     top edge, a join button puts the two parts back together (the Tables preview) */
  function hideCutButtons() {
    document.querySelectorAll(".vis-cut").forEach((n) => n.remove());
  }
  function cutHover(ev, host, canvas, refresh) {
    const d = L.state.data;
    if (!host || !canvas || !d || L.state.drag || L.state.pan || document.getElementById("visPartMenu")
        || (window.TextSelect && TextSelect.active)) { hideCutButtons(); return; }
    // over a ✂ / a handle / the → ↓ row and column arrows: left as it is (the ✂ sits beyond the arrows)
    if (ev.target && ev.target.closest && ev.target.closest(".vis-cut, .tblh-c, .tblh-s, .tblh-col, .tblh-row, .tblh-rsel, .tblh-csel, #visTableBar, #tblCellPop")) return;
    const r = canvas.getBoundingClientRect(), hr = host.getBoundingClientRect(), sc = r.width / d.canvas_w;
    const px = (ev.clientX - r.left) / sc, py = (ev.clientY - r.top) / sc;
    const edge = 60 / sc;
    // the drawn table's own box (not the full-width strip it sits in)
    const tableBox = (t) => {
      const fb = finalBox(t), kx = fb.w / Math.max(1, t.base.w);
      return { x: fb.x + t.cut.tx * kx, y: fb.y, w: t.cut.tw * kx, h: fb.h };
    };
    const e = (L.state.elements || []).slice().reverse().find((t) => {
      if (t.kind !== "table" || !t.cut || !t.design_key) return false;
      const b = tableBox(t);
      return py >= b.y - 6 / sc && py <= b.y + b.h + 6 / sc && px >= b.x - edge && px <= b.x + b.w + edge;
    });
    if (!e) { hideCutButtons(); return; }
    const b = tableBox(e), c = e.cut, k = b.h / Math.max(1, e.base.h);
    const local = (py - b.y) / k;
    const nearEdge = px <= b.x + edge || px >= b.x + b.w - edge;
    const bodyTop = c.headH + (c.nHead ? c.gap : 0);
    let best = null;
    for (let i = c.a + 1; i < c.b; i++) {              // the line between body rows i-1 and i
      const at = bodyTop + c.tops[c.nHead + i] - c.tops[c.nHead + c.a] - c.gap / 2;
      const dd = Math.abs(at - local);
      if (dd <= 16 / (sc * k) && (!best || dd < best.d)) best = { i, at, d: dd };
    }
    hideCutButtons();
    const place = (btn, x, y) => {
      btn.style.left = (r.left - hr.left + x * sc) + "px";
      btn.style.top = (r.top - hr.top + y * sc) + "px";
      ["pointerdown", "mousedown"].forEach((t) => btn.addEventListener(t, (e2) => e2.stopPropagation()));
      host.appendChild(btn);
    };
    if (best && nearEdge) {
      for (const side of ["l", "r"]) {
        const btn = document.createElement("button");
        btn.className = "vis-cut " + side;
        btn.textContent = "✂";
        btn.title = "Cut the table here — both parts stay on this page (right-click a part to move it to another page)";
        btn.addEventListener("click", (e2) => { e2.stopPropagation(); cutTableAt(e, best.i, refresh); });
        // on the Canvas the → row arrows sit just left of the table: the left ✂ goes beyond them
        const gutter = side === "l" && document.querySelector(".tblh-rsel") ? 24 / sc : 0;
        place(btn, side === "l" ? b.x - 4 - gutter : b.x + b.w + 4, b.y + best.at * k);
      }
    } else if (c.pi > 0 && local <= c.headH + 12) {    // a lower part's top: join it to the part above
      const btn = document.createElement("button");
      btn.className = "vis-cut join";
      btn.textContent = "⇡ Join with the part above";
      btn.title = "Put this part back together with the part above it";
      btn.addEventListener("click", (e2) => { e2.stopPropagation(); joinTableParts(e, false, refresh); });
      place(btn, b.x + b.w / 2, b.y);
    }
  }

  /* this table's text (header / body) and symbols — written to table_style.table_layouts[key] */
  const TB = { role: "body" };
  function tableLay(ts, e) {
    return Object.assign({}, (ts.table_layouts || {})[e.design_key] || {});
  }
  function tableTextHtml(ts, e) {
    const lay = tableLay(ts, e), role = TB.role, spec = lay[role] || {}, geo = e.geo || {};
    const fonts = (App.state.fonts || []).slice().sort((a, b) => String(a).localeCompare(String(b)));
    const bold = role === "header" ? spec.bold !== false : !!spec.bold;
    const lib = Object.keys(((App.state.config.dynamic_settings || {}).layer_style_library) || {}).sort();
    const size = spec.size || (role === "header" ? geo.header_size : geo.body_size) || "";
    return `<div class="vsb-sep"></div>
      <div class="vsb-row"><b class="vsb-lab">Text</b>
        <label class="vsb-scope"><input type="radio" name="tbRole" value="header" ${role === "header" ? "checked" : ""}> header row</label>
        <label class="vsb-scope"><input type="radio" name="tbRole" value="body" ${role === "body" ? "checked" : ""}> other rows</label>
        <button class="pt-btn secondary small" data-tbwords title="Pick words in this table and give them their own look">Style words…</button></div>
      <div class="vsb-row">
        <select id="tbFont" class="vsb-font" title="Font">${[["", "Same font"]].concat(fonts.map((f) => [f, f])).map(([v, t]) => `<option value="${esc(v)}" ${v === (spec.font || "") ? "selected" : ""}>${esc(t)}</option>`).join("")}</select>
        <label class="vsb-lab" title="Font size (px) — the corner handles scale it with the table">Size <input type="number" id="tbSize" class="vsb-num" min="6" max="300" value="${esc(size)}">px</label>
        <label class="vsb-scope" title="Its own text colour"><input type="checkbox" id="tbColorOn" ${spec.color ? "checked" : ""}> <input type="color" id="tbColor" value="${esc(spec.color || "#ffffff")}"></label>
        <button class="vsb-tog ${bold ? "on" : ""}" id="tbBold" title="Bold"><b>B</b></button>
        <button class="vsb-tog ${spec.italic ? "on" : ""}" id="tbItalic" title="Italic"><i>I</i></button>
      </div>
      <div class="vsb-row"><span class="vsb-lab">Layer style</span>
        <select id="tbFx" data-lsswatch>${[["", "None"]].concat(lib.map((n) => [n, n])).map(([v, t]) => `<option value="${esc(v)}" ${v === (spec.fx || "") ? "selected" : ""}>${esc(t)}</option>`).join("")}</select></div>
      ${tableLinesHtml(lay, e)}
      <div class="vsb-row"><b class="vsb-lab">Symbols</b>
        <button class="pt-btn secondary small" data-tbicon="-10" title="Smaller symbols (rows follow)">−</button>
        <span class="vsb-val">${Math.round(lay.icon_scale || 100)}%</span>
        <button class="pt-btn secondary small" data-tbicon="10" title="Bigger symbols (rows follow)">+</button>
        <span style="flex:1"></span>
        <button class="pt-btn secondary small" data-tbsizes title="Back to the size the Excel and Tables settings give it">Reset size</button></div>`;
  }
  /* the design is only a start: this table's own colours and lines on top of it */
  function tableLinesHtml(lay, e) {
    const st = lay.style || {}, excel = e.design === "excel";
    const sw = (key, label) => `<label class="vsb-scope" title="${label} — this table only">
        <input type="checkbox" data-tsown="${key}" ${st[key] ? "checked" : ""}> ${label}
        <input type="color" data-tscol="${key}" value="${esc(st[key] || "#ffffff")}"></label>`;
    const outer = lay.outer || {};
    const lib = Object.keys(((App.state.config.dynamic_settings || {}).layer_style_library) || {}).sort();
    return `<div class="vsb-sep"></div>
      <div class="vsb-row"><b class="vsb-lab">Colours</b>${excel ? `<span class="vsb-hint">fills and text from the Excel — double-click a box to change one</span>`
        : `${sw("header_bg_rgb", "header")}${sw("row1_bg_rgb", "rows")}${sw("row2_bg_rgb", "other rows")}`}</div>
      ${excel ? "" : `<div class="vsb-row"><span class="vsb-lab">Text</span>${sw("header_text_rgb", "header")}${sw("table_body_text_rgb", "rows")}</div>`}
      <div class="vsb-row"><b class="vsb-lab">Lines</b>
        <select id="tlMode" title="The lines between the boxes">
          <option value="design" ${!lay.lines || lay.lines === "design" ? "selected" : ""}>${excel ? "Excel's own" : "As the design"}</option>
          <option value="all" ${lay.lines === "all" ? "selected" : ""}>Every box</option>
          <option value="none" ${lay.lines === "none" ? "selected" : ""}>None</option></select>
        <input type="color" id="tlColor" value="${esc(lay.line_color || "#ffffff")}" title="Line colour" ${lay.lines === "all" ? "" : "disabled"}>
        <input type="number" id="tlWidth" class="vsb-num" min="1" max="20" value="${lay.line_width || 1}" title="Line width (px)" ${lay.lines === "all" ? "" : "disabled"}>px</div>
      <div class="vsb-row"><span class="vsb-lab">Border</span>
        <label class="vsb-scope" title="A border around the whole table"><input type="checkbox" id="toOn" ${outer.color ? "checked" : ""}> around the table
          <input type="color" id="toColor" value="${esc(outer.color || "#c8952b")}"></label>
        <input type="number" id="toWidth" class="vsb-num" min="1" max="40" value="${outer.width || 4}" title="Border width (px)">px</div>
      <div class="vsb-row"><span class="vsb-lab" title="A layer style on every line and border of this table">Lines style</span>
        <select id="tlFx" data-lsswatch>${[["", "None"]].concat(lib.map((n) => [n, n])).map(([v, t]) => `<option value="${esc(v)}" ${v === (lay.lines_fx || "") ? "selected" : ""}>${esc(t)}</option>`).join("")}</select></div>`;
  }

  function wireTableText(bar, ts, e, save, host, canvas, refresh) {
    const q = (id) => bar.querySelector("#" + id);
    const write = (fn) => {
      const lay = tableLay(ts, e);
      fn(lay);
      ts.table_layouts = Object.assign({}, ts.table_layouts || {}, { [e.design_key]: lay });
      save();
    };
    const setStyle = (key, val) => write((lay) => {
      const st = Object.assign({}, lay.style || {});
      if (val) st[key] = val; else delete st[key];
      lay.style = st;
    });
    bar.querySelectorAll("[data-tsown]").forEach((cb) => cb.addEventListener("change", () => {
      setStyle(cb.dataset.tsown, cb.checked ? bar.querySelector(`[data-tscol="${cb.dataset.tsown}"]`).value : "");
    }));
    bar.querySelectorAll("[data-tscol]").forEach((c) => c.addEventListener("change", () => {
      const cb = bar.querySelector(`[data-tsown="${c.dataset.tscol}"]`);
      if (cb) cb.checked = true;
      setStyle(c.dataset.tscol, c.value);
    }));
    const lines = () => write((lay) => {
      lay.lines = q("tlMode").value;
      if (lay.lines === "all") { lay.line_color = q("tlColor").value; lay.line_width = Number(q("tlWidth").value) || 1; }
    });
    q("tlMode")?.addEventListener("change", lines);
    q("tlColor")?.addEventListener("change", lines);
    q("tlWidth")?.addEventListener("change", lines);
    const outer = () => write((lay) => {
      if (q("toOn").checked) lay.outer = { color: q("toColor").value, width: Number(q("toWidth").value) || 4 };
      else delete lay.outer;
    });
    q("toOn")?.addEventListener("change", outer);
    q("toColor")?.addEventListener("change", () => { q("toOn").checked = true; outer(); });
    q("toWidth")?.addEventListener("change", () => { q("toOn").checked = true; outer(); });
    q("tlFx")?.addEventListener("change", () => write((lay) => { if (q("tlFx").value) lay.lines_fx = q("tlFx").value; else delete lay.lines_fx; }));
    // the header / other rows' text: every box of that role follows — a box's own value of the same
    // setting (double-click edits, lay.cells["row,column"]) goes, its other own settings stay
    const setSpec = (patch) => write((lay) => {
      lay[TB.role] = Object.assign({}, lay[TB.role] || {}, patch);
      if (!lay.cells || typeof lay.cells !== "object") return;
      const nHead = Math.max(0, Number(e.geo && e.geo.header_rows) || 0), cells = Object.assign({}, lay.cells);
      Object.keys(cells).forEach((ck) => {
        if ((TB.role === "header") !== (Number(String(ck).split(",")[0]) < nHead)) return;
        const spec = Object.assign({}, cells[ck]);
        Object.keys(patch).forEach((p) => delete spec[p]);
        if (Object.keys(spec).length) cells[ck] = spec; else delete cells[ck];
      });
      if (Object.keys(cells).length) lay.cells = cells; else delete lay.cells;
    });
    bar.querySelectorAll('input[name="tbRole"]').forEach((r) => r.addEventListener("change", () => {
      TB.role = r.value;
      showTableBar(host, canvas, e, refresh, TB.onClose);
    }));
    q("tbFont")?.addEventListener("change", () => setSpec({ font: q("tbFont").value || undefined }));
    q("tbSize")?.addEventListener("change", () => {
      const v = Number(q("tbSize").value) || 0;
      const scale = (e.geo && e.geo.scale) || 1;
      setSpec({ size: v > 0 ? Math.round(v / scale) : undefined });        // stored at scale 1
    });
    const colour = () => setSpec({ color: q("tbColorOn").checked ? q("tbColor").value : undefined });
    q("tbColorOn")?.addEventListener("change", colour);
    q("tbColor")?.addEventListener("change", () => { q("tbColorOn").checked = true; colour(); });
    q("tbBold")?.addEventListener("click", () => setSpec({ bold: !q("tbBold").classList.contains("on") }));
    q("tbItalic")?.addEventListener("click", () => setSpec({ italic: !q("tbItalic").classList.contains("on") }));
    q("tbFx")?.addEventListener("change", () => setSpec({ fx: q("tbFx").value || undefined }));
    bar.querySelectorAll("[data-tbicon]").forEach((b) => b.addEventListener("click", () => write((lay) => {
      lay.icon_scale = Math.max(20, Math.min(400, (Number(lay.icon_scale) || 100) + Number(b.dataset.tbicon)));
    })));
    bar.querySelector("[data-tbsizes]")?.addEventListener("click", () => write((lay) => {
      ["scale", "width", "height", "cols", "row_h", "icon_scale"].forEach((k) => delete lay[k]);
    }));
    bar.querySelector("[data-tbwords]")?.addEventListener("click", () => {
      // the word-style bar, on this table's words (a rule styles the word wherever it appears)
      hideTableBar();
      L.state.virtualRow = { id: "tablewords." + e.id, kind: "line", x: e.x, y: e.y, w: e.w, h: e.h,
                             rowText: (e.texts || []).join(" ") };
      L.state.selected = L.state.virtualRow.id;
      SB.key = "";
      syncStyleBar();
    });
  }
  function hideTableBar() {
    const b = el("visTableBar");
    if (b) b.remove();
  }

  /* the element at a point of a preview canvas (css px), or null; and every element of the page */
  function elementAt(canvas, cssX, cssY) {
    const d = L.state.data;
    if (!d || !canvas) return null;
    const k = canvas.getBoundingClientRect().width / d.canvas_w;
    return hitTest(cssX / k, cssY / k);
  }

  /* the table at a point of a preview canvas (css px), or null */
  function tableAt(canvas, cssX, cssY) {
    const d = L.state.data;
    if (!d || !canvas) return null;
    const k = canvas.getBoundingClientRect().width / d.canvas_w;
    const e = hitTest(cssX / k, cssY / k);
    return e && e.kind === "table" ? e : null;
  }

  function releaseStyleBar() {                                  // back to the Visualiser's own canvas
    const bar = el("visStyleBar");
    if (bar && L.state.barHost) bar.remove();
    Object.assign(L.state, { barHost: null, barCanvas: null, barRefresh: null });
  }

  /* the row text being typed in a preview editor (typo-preview.js), laid out live — nothing saved.
     edits = {"row:12": {from, to}} for this sheet (to "" = the row is joined into another one);
     null = back to the text the page was loaded with. Server-laid pages (canonical) get the draft
     as text_edits_draft; the browser's own pages re-wrap their rows here, icons tagged with their
     sizes as icon_scales.py does. Resolves true once the canvas shows it. */
  let draftSeq = 0;
  function tagIcons(sheet, rowKey, text) {
    const all = (App.state.config.dynamic_settings || {}).icon_scales || {};
    const table = all[sheet] || {}, everywhere = all["*"] || {};                // "*": every sheet of the project
    if (String(text).indexOf("<") < 0) return text;
    const seen = {};
    return String(text).replace(/<([^<>]+)>/g, (m, raw) => {
      const base = untagToken(raw), c = normToken(base), k = seen[c] || 0;
      seen[c] = k + 1;
      const own = table[c + "@" + rowKey + "#" + k] != null ? table[c + "@" + rowKey + "#" + k] : table[c] != null ? table[c] : everywhere[c];
      const pct = Number(own);
      if (!(pct > 0) || Math.abs(pct - 100) < 1e-6) return m;
      return "<" + base + "~" + (Math.abs(pct - Math.round(pct)) < 0.05 ? Math.round(pct) : pct.toFixed(1)) + ">";
    });
  }
  async function draftText(canvas, sheetName, edits) {
    const d = L.state.data;
    if (!d || !canvas || d.sheet_name !== sheetName) return false;
    const seq = ++draftSeq;
    if (L.state.canon && L.state.canon.mode === "canonical") {
      let p = null;
      try {
        p = await api("/api/layout/preview", { method: "POST",
          body: { sheet_name: sheetName, apply_overrides: true, text_edits_draft: edits ? { [sheetName]: edits } : null } });
      } catch (e) { return false; }
      if (seq !== draftSeq || L.state.data !== d || !p || !p.ok || p.mode !== "canonical" || !(p.layouts || []).length) return false;
      L.state.canon = p;
    } else {
      // the rows as loaded, kept once; a typed row is wrapped here (not the server's measured lines)
      if (!L.state.draftBase) L.state.draftBase = new Map((d.rows || []).map((r) => [String(r.row), { text: r.text, lines: r.lines }]));
      for (const r of d.rows || []) {
        const base = L.state.draftBase.get(String(r.row)), ed = edits && edits["row:" + r.row];
        if (!base) continue;
        if (ed) { r.text = ed.to ? tagIcons(sheetName, "row:" + r.row, ed.to) : ""; r.lines = null; }
        else { r.text = base.text; r.lines = base.lines; }
      }
      if (!edits) L.state.draftBase = null;
    }
    const page = L.state.page || 0;
    buildPages();
    L.state.page = Math.max(0, Math.min(page, (L.state.pages || []).length - 1));
    L.state.elements = ((L.state.pages || [])[L.state.page] || { elements: [] }).elements;
    redrawInto(canvas);
    return true;
  }

  async function renderInto(canvas, sheetName, force) {
    if (!canvas || !canvas.getContext) return null;
    try {
      const d = await api("/api/visualiser/editor-data", { method: "POST", body: { sheet_name: String(sheetName || ""), force: !!force } });
      if (!d || !d.ok || !d.data) return null;
      const sameSheet = !!(L.state.data && L.state.data.sheet_name === d.data.sheet_name);
      const samePage = sameSheet ? (L.state.page || 0) : 0;
      // the same sheet again (an edit): keep the icon pictures already loaded (same file) — laid out
      // without them the rows measure shorter, the sheet has fewer pages for a moment, and the page
      // being edited would jump back to page 1
      const kept = sameSheet ? L.state.icons || {} : {};
      L.state.draftBase = null;                                // fresh rows: no typed text on them
      L.state.data = d.data;
      L.state.fxDiag = null;
      L.state.sheet = d.data.sheet_name;
      L.state.fontsLoaded = false;
      L.state.icons = {};
      Object.entries(d.data.icons || {}).forEach(([tok, info]) => {
        if (kept[tok] && info && kept[tok].url === info.url) L.state.icons[tok] = kept[tok];
      });
      // ...and the background and table pictures already loaded (each kept by its url): thrown away,
      // the page was drawn once without them — a white flash on every edit until they loaded again
      if (!sameSheet) L.state.stripImgs = {};
      const bgUrl = (d.data.settings || {}).bg_image_url;
      if (!(L.state.images && bgUrl && L.state.images.bgUrl === bgUrl)) L.state.images = null;
      L.state.selected = null;
      L.state.verify = null;
      L.state.overrides = readOverrides();
      L.state.paylines = null;
      await fetchCanonicalData();
      L.state.renderTarget = canvas;
      await ensureFonts();
      preloadIcons();
      preloadStrips();
      preloadBg();
      buildPages();
      // the same sheet again (an edit): stay on the page being edited, never jump back to page 1
      L.state.page = Math.max(0, Math.min(samePage, (L.state.pages || []).length - 1));
      L.state.elements = (L.state.pages[L.state.page] || { elements: [] }).elements;
      L.state.ctx = canvas.getContext("2d");
      redrawInto(canvas);
      return pageGeometry();
    } catch (e) {
      return null;
    }
  }

  // where the page's margins and heading are now (the Canvas's guides)
  function pageGeometry() {
    const dd = L.state.data;
    const s = mergedSettings() || dd.settings;
    const headingTop = Math.max(0, Math.round(Number(s.heading_top_margin) || 0));
    return {
      canvas_w: dd.canvas_w,
      canvas_h: dd.canvas_h,
      heading_top: headingTop,
      heading_bottom: headingTop + L.state.headingH,
      heading_height: L.state.headingH,
      body_top: Math.max(0, headingTop + L.state.headingH + Math.round(Number(s.heading_to_body_gap) || 0)),   // never above the page
      body_bottom: L.state.safe.bottom,
      safe_left: L.state.safe.left,
      safe_right: L.state.safe.left + L.state.safe.width,
      inner_canvas_width: L.state.safe.width,
    };
  }

  /* A drag in progress: the page laid out by the server with the dragged values (draft =
     {"dynamic_settings.body_boxes": {...}, "heading_top_margin": 120}), never saved; drawn at once.
     Returns the new guides' geometry, or null (an older drag value, another sheet, no canonical layout). */
  let settingsSeq = 0;
  async function draftSettings(canvas, sheetName, draft) {
    const d = L.state.data;
    if (!d || !canvas || d.sheet_name !== sheetName || !(L.state.canon && L.state.canon.mode === "canonical")) return null;
    const seq = ++settingsSeq;
    let p = null;
    try {
      p = await api("/api/layout/preview", { method: "POST", body: { sheet_name: sheetName, apply_overrides: true, settings_draft: draft } });
    } catch (e) { return null; }
    if (seq !== settingsSeq || L.state.data !== d || !p || !p.ok || p.mode !== "canonical" || !(p.layouts || []).length) return null;
    L.state.canon = p;
    const page = L.state.page || 0;
    buildPages();
    L.state.page = Math.max(0, Math.min(page, (L.state.pages || []).length - 1));
    L.state.elements = ((L.state.pages || [])[L.state.page] || { elements: [] }).elements;
    redrawInto(canvas);
    return pageGeometry();
  }

  /* Re-size a preview canvas to its current CSS box and redraw the page.
     The canvas box itself is governed by `.vis-img { inset:0; width:100% }`
     inside the (layout-controlled) stage — only the pixel buffer re-syncs. */
  /* Zoomed in, the Canvas picture is far bigger than the screen (a 4K page at 200 % is ~11500 x 6500
     device px): drawing all of it on every edit, pan or zoom made the Canvas lag. Above VIEW_BUDGET only
     the part in view is drawn — into a screen-sized canvas laid over that part (canvas._view, clicks pass
     through). The page canvas itself keeps its full size and place on screen, so everything that measures
     it (guides, frames, handles, ✂, the text editor) works as before; its own picture is left empty. */
  const VIEW_BUDGET = 6e6;
  function viewCanvas(canvas) {
    let v = canvas._view;
    if (!v || !v.isConnected) {
      v = document.createElement("canvas");
      v.className = "vis-view";
      Object.assign(v.style, { position: "absolute", left: "0px", top: "0px", pointerEvents: "none", zIndex: "0" });
      canvas.after(v);
      canvas._view = v;
    }
    return v;
  }
  function hideView(canvas) {
    if (canvas && canvas._view) canvas._view.style.display = "none";
  }
  // the page canvas's part inside its viewport (css px of the canvas), or null when no window is needed
  function viewWindow(canvas, cssW, cssH, dpr) {
    const host = canvas.id === "typoVisCanvas" ? el("typoVisHost") : null;
    if (!host || cssW * cssH * dpr * dpr <= VIEW_BUDGET) return null;
    const cr = canvas.getBoundingClientRect(), hr = host.getBoundingClientRect();
    if (cr.width < 2 || hr.width < 2) return null;
    const x0 = Math.floor(Math.max(0, hr.left - cr.left)), y0 = Math.floor(Math.max(0, hr.top - cr.top));
    const x1 = Math.ceil(Math.min(cr.width, hr.right - cr.left)), y1 = Math.ceil(Math.min(cr.height, hr.bottom - cr.top));
    return { x0, y0, w: Math.max(0, x1 - x0), h: Math.max(0, y1 - y0), k: cr.width / L.state.data.canvas_w };
  }

  function redrawInto(canvas) {
    const d = L.state.data;
    if (!d || !canvas || !canvas.getContext) return;
    const dpr = window.devicePixelRatio || 1;
    const parent = canvas.parentElement;
    let cssW = parent ? parent.clientWidth : 0;
    if (cssW < 2) cssW = canvas.clientWidth;
    if (cssW < 2) cssW = d.canvas_w;
    const cssH = Math.max(1, Math.round(cssW * d.canvas_h / d.canvas_w));
    const win = viewWindow(canvas, cssW, cssH, dpr);
    if (win) {
      if (canvas.width !== 1 || canvas.height !== 1) { canvas.width = 1; canvas.height = 1; }
      const v = viewCanvas(canvas);
      if (!win.w || !win.h) { v.style.display = "none"; return; }      // scrolled off: nothing to draw
      Object.assign(v.style, { display: "", left: win.x0 + "px", top: win.y0 + "px", width: win.w + "px", height: win.h + "px" });
      v.width = Math.max(1, Math.round(win.w * dpr));
      v.height = Math.max(1, Math.round(win.h * dpr));
      v._win = { x: win.x0 / win.k, y: win.y0 / win.k, k: win.k * dpr };   // page px at its top-left, device px per page px
      L.state.renderTarget = v;
      draw();
      return;
    }
    hideView(canvas);
    canvas.width = Math.max(1, Math.round(cssW * dpr));
    canvas.height = Math.max(1, Math.round(cssH * dpr));
    L.state.renderTarget = canvas;
    draw();
  }

  function resize() {
    const d = L.state.data;
    const canvas = el("visLiveCanvas");
    if (!d || !canvas) return;
    L.state.renderTarget = null; // main route always draws into #visLiveCanvas
    const s = L.state.scale;
    const dpr = window.devicePixelRatio || 1;
    canvas.style.width = d.canvas_w * s + "px";
    canvas.style.height = d.canvas_h * s + "px";
    canvas.width = Math.max(1, Math.round(d.canvas_w * s * dpr));
    canvas.height = Math.max(1, Math.round(d.canvas_h * s * dpr));
    L.state.ctx = canvas.getContext("2d");
    markDirty();
  }

  function sync() {
    buildPages();
    markDirty();
    scheduleThumbs(250);
    renderPageBadge();
    scheduleDataRefresh(700);
    scheduleSheetThumb(2500);
  }

  function renderPageBadge() {
    const d = L.state.data;
    const badge = el("visLivePagesBadge");
    if (badge) badge.textContent = L.state.pages.length + " page" + (L.state.pages.length === 1 ? "" : "s");
    renderRangeBadge();
  }

  function colIndexToLetter(idx) {
    let s = "";
    while (idx > 0) {
      const r = (idx - 1) % 26;
      s = String.fromCharCode(65 + r) + s;
      idx = Math.floor((idx - 1) / 26);
    }
    return s;
  }

  function renderRangeBadge() {
    const d = L.state.data;
    const badge = el("visLiveRangeBadge");
    if (!badge || !d) return;
    const w = d.render_window || {};
    const mb = d.master_border;
    const hasCols = w.max_col >= w.min_col && w.min_col >= 1;
    const hasRows = w.max_row >= w.min_row && w.min_row >= 1;
    const range = hasCols && hasRows
      ? "R" + w.min_row + "–" + w.max_row + " · C" + colIndexToLetter(w.min_col) + "–" + colIndexToLetter(w.max_col)
      : "—";
    if (mb) {
      badge.textContent = "Data " + range + " (border)";
      badge.title =
        "Auto-detected master border rows " + mb.min_row + "–" + mb.max_row +
        ", columns " + colIndexToLetter(mb.min_col) + "–" + colIndexToLetter(mb.max_col) +
        " — PNG and PSD output render exactly this area. Override per sheet in Project → Pages → Data range.";
    } else {
      badge.textContent = "Data " + range + " (default)";
      badge.title =
        "No master border detected — default window rows 1..bottom, columns 1..max col limit. " +
        "Set an explicit range per sheet in Project → Pages → Data range.";
    }
  }

  /* ------------------------------ sheet rail (all pages, left) ------------------------------ */

  function renderSheetRail() {
    const meta = L.state.meta;
    const list = el("visLiveRailList");
    if (!list) return;
    const sheets = allSheets(meta);
    list.innerHTML = sheets.length
      ? sheets.map((n) => `
        <div class="vis-thumb ${n === L.state.sheet ? "active" : ""}" data-sheet="${esc(n)}" onclick="AppLive.setSheetFromRail('${esc(n).replace(/'/g, "\\'")}')" title="${esc(n)}">
          <div class="vis-thumb-empty">…</div>
          <span class="vis-thumb-label">${esc(n)}${studioTag(n) ? ` <i class="vis-thumb-kind">${esc(studioTag(n))}</i>` : ""}</span>
        </div>`).join("")
      : `<div class="hint" style="padding:10px">No pages — load the Excel workbook in Project view.</div>`;
    for (const n of sheets) {
      const t = L.state.sheetThumbs[n];
      if (t) setSheetThumbImg(n, t);
    }
    loadSheetThumbs();
  }

  /* fetch one authoritative preview per sheet (server-cached) and drop it into
     its rail cell; sequential so N PIL renders never hammer the server. */
  async function loadSheetThumbs() {
    const meta = L.state.meta;
    const sheets = allSheets(meta);
    let failed = 0, done = 0;
    for (const n of sheets) {
      if (L.state.sheetThumbs[n]) continue;
      try {
        const d = await railPreview(n, false);
        if (d && d.ok && d.preview_token) {
          L.state.sheetThumbs[n] = d.preview_token;
          setSheetThumbImg(n, d.preview_token);
        } else failed++;
      } catch (e) { failed++; }
      done++;
    }
    if (failed && failed === done && sheets.length) toast("Could not render page previews.", "warn");
  }

  /* payline sheets: first denomination page from the build renderer */
  function railPreview(name, force) {
    if (isPaylineSheet(name)) return api("/api/paylines/preview", { method: "POST", body: { sheet_name: name, page: 0 } });
    if (studioKind(name)) return api("/api/page_preview", { method: "POST", body: { sheet_name: name } });
    return api("/api/visualiser/preview", { method: "POST", body: { sheet_name: name, force: !!force } });
  }

  function sheetThumbEl(name) {
    const list = el("visLiveRailList");
    if (!list) return null;
    for (const n of list.children) if (n.dataset && n.dataset.sheet === name) return n;
    return null;
  }

  function setSheetThumbImg(name, token) {
    const t = sheetThumbEl(name);
    if (!t) return;
    let img = t.querySelector("img");
    if (!img) {
      img = document.createElement("img");
      img.alt = name;
      img.draggable = false;
      t.insertBefore(img, t.querySelector(".vis-thumb-label"));
    }
    img.src = "/api/table_preview/" + encodeURIComponent(token) + "?v=" + Date.now();
    const holder = t.querySelector(".vis-thumb-empty");
    if (holder) holder.remove();
  }

  function updateSheetRailActive() {
    const list = el("visLiveRailList");
    if (!list) return;
    for (const n of list.children) n.classList.toggle("active", n.dataset.sheet === L.state.sheet);
    const sel = el("visLiveSheet");
    if (sel) sel.value = L.state.sheet;
  }

  function setSheetFromRail(name) { setSheet(name); }

  /* after the user edits this sheet's settings/overrides, re-render the
     authoritative PNG (force) and refresh that sheet's rail thumbnail. */
  function scheduleSheetThumb(ms) {
    clearTimeout(L.state.railTimer);
    L.state.railTimer = setTimeout(() => {
      const n = L.state.sheet;
      if (!n || !el("visLiveRailList")) return;
      railPreview(n, true)
        .then((d) => { if (d && d.ok && d.preview_token) { L.state.sheetThumbs[n] = d.preview_token; setSheetThumbImg(n, d.preview_token); } })
        .catch(() => {});
    }, ms || 2500);
  }

  /* ------------------------------ controls tab ------------------------------ */

  function controlsHTML(meta) {
    const sections = meta.controls || [];
    return sections.map((sec) => {
      let body = "";
      if (sec.styles) {
        body = sec.styles.map((st) => {
          const head = st.name
            ? `${esc(st.title)} <span class="vis-style-src">· “${esc(st.name)}”</span>`
            : esc(st.title) + " <span class=\"vis-style-src\">· default</span>";
          return `<div class="vis-style-block"><div class="vis-style-title">${head}</div>${st.fields.map((f) => ctlField(st.path.concat([f.field]).join("."), f)).join("")}</div>`;
        }).join("");
      } else {
        body = (sec.items || []).map((f) => ctlField(f.key, f)).join("");
      }
      return `<div class="collapse"><button class="collapse-head" onclick="this.parentElement.classList.toggle('open')">${esc(sec.title)} ${icon("chevron")}</button><div class="collapse-body">${body || `<div class="hint" style="padding:8px 2px">No controls in this section.</div>`}</div></div>`;
    }).join("");
  }

  function ctlField(key, f) {
    const val = App.get(key);
    switch (f.type) {
      case "font":
        return fontField(key, f.label, f.placeholder || "ArialMT");
      case "color":
        if (f.tuple) {
          return `<div class="pt-ctl"><div class="pt-ctl-label"><span>${esc(f.label)}</span></div><input type="color" data-viscolor="${esc(key)}" value="${esc(rgbToHex(val))}" /></div>`;
        }
        return colorField(key, f.label);
      case "toggle":
        return toggleRow(key, f.label, f.hint || "");
      case "select": {
        const opts = (f.options || []).map((o) => ({ value: String(o), label: String(o) }));
        return selectField(key, f.label, opts);
      }
      case "slider":
        return ptSlider(key, f.label, { min: f.min || 0, max: f.max || 400, step: f.step || 1, unit: f.unit || "px", hint: f.hint || "" });
      case "info":
        return `<div class="hint vis-info">${esc(f.text || "")}</div>`;
      default:
        return field(key, f.label, { type: f.type || "number", hint: f.hint || "" });
    }
  }

  function renderControls() {
    const root = el("visLiveControls");
    if (!root || !L.state.meta) return;
    root.innerHTML = controlsHTML(L.state.meta);
    bindForms(root);
    root.querySelectorAll("input[data-viscolor]").forEach((inp) => {
      inp.addEventListener("input", () => {
        pushUndo();
        App.set(inp.dataset.viscolor, hexToRgb(inp.value));
        App.pushConfig();
        sync();
      });
    });
    root.querySelectorAll("[data-key]").forEach((ctl) => {
      if (ctl.tagName !== "INPUT" && ctl.tagName !== "SELECT" && ctl.tagName !== "TEXTAREA") return;
      ctl.addEventListener("change", () => { if (ctl.dataset.key) sync(); });
      // sliders re-lay the page while they move (icon gaps, sizes…), not only on release
      if (ctl.type === "range") ctl.addEventListener("input", () => { if (ctl.dataset.key) { markDirty(); scheduleDataRefresh(350); } });
    });
  }

  /* ------------------------------ view ------------------------------ */

  L.view = function () {
    const meta = L.state.meta;
    const sheets = allSheets(meta);
    const current = L.state.sheet || sheets[0] || "";
    const sheetOpts = sheets.length
      ? sheets.map((n) => `<option value="${esc(n)}" ${n === current ? "selected" : ""}>${esc(n)}</option>`).join("")
      : `<option value="">No normal pages</option>`;
    const excelOk = !!(meta && meta.excel_ok !== false);
    return `<div class="view">
      <div class="view-header">
        <div class="view-title">Visualiser</div>
        <div class="view-sub">60 FPS client-side editor — click, drag, scale and rotate real text and icons; every page renders live and matches the exported PNG.</div>
      </div>
      <div class="vis-live-root">
        <nav class="vis-live-rail">
          <div class="vis-live-rail-head">All Pages</div>
          <div class="vis-live-rail-list" id="visLiveRailList"><div class="hint" style="padding:10px">Loading…</div></div>
        </nav>
        <div class="vis-live-editor">
          <div class="vis-live-top">
            <label style="font-size:12px;color:var(--pt-text2)">Sheet</label>
            <select id="visLiveSheet" style="max-width:280px" ${sheetOpts ? "" : "disabled"}>${sheetOpts}</select>
            <span style="flex:1"></span>
            <button class="pt-btn small" id="visLivePaylinesLink" style="display:none" onclick="location.hash='#/paylines'" title="This page is designed in its own studio">Edit in Paylines studio</button>
            <span class="pt-pill" id="visLivePagesBadge"></span>
            <span class="pt-pill idle" id="visLiveRangeBadge" title=""></span>
            <span class="pt-pill idle" id="visLiveBadge">Ready</span>
          </div>
          <div class="vis-live-toolbar">
            <button class="pt-btn small" onclick="AppLive.fit()" title="Fit page to window">⛶ Fit</button>
            <button class="pt-btn small" onclick="AppLive.setZoom(1)" title="Actual size">100%</button>
            <button class="pt-btn small" onclick="AppLive.centerOnly()" title="Center page">⌖ Center</button>
            <button class="pt-btn small" onclick="AppLive.zoomBy(1.25)" title="Zoom in">+</button>
            <button class="pt-btn small" onclick="AppLive.zoomBy(0.8)" title="Zoom out">−</button>
            <span class="vis-zoom-label" id="visLiveZoom">fit</span>
            <span class="vis-mode" style="margin-left:8px">
              <button class="pt-btn small ${L.state.editMode === "icon" ? "" : "on"}" id="visModeText" onclick="AppLive.setEditMode('text')" title="Text Edit: click selects a row (with its symbols); double click an icon to edit it">Text Edit</button>
              <button class="pt-btn small ${L.state.editMode === "icon" ? "on" : ""}" id="visModeIcon" onclick="AppLive.setEditMode('icon')" title="Icon Edit: click selects an icon to transform it (stays in its row, center-anchored)">Icon Edit</button>
            </span>
            <button class="pt-btn small ${L.state.freeform ? "on" : ""}" id="visModeFree" onclick="AppLive.setFreeform()" title="Freeform: ON lets you move/rotate icons anywhere. OFF keeps icons on their row axis — left/right only, never moved up/down or tilted.">Freeform</button>
            <button class="pt-btn small ${L.state.fxEnabled ? "on" : ""}" id="visFxToggle" onclick="AppLive.toggleFx()" title="Layer style preview: shows the captured Photoshop layer style on headings/body. OFF renders plain flat text.">FX</button>
            <span style="flex:1"></span>
            <button class="pt-btn small" onclick="AppLive.undo()" title="Ctrl+Z">↶ Undo</button>
            <button class="pt-btn small" onclick="AppLive.redo()" title="Ctrl+Y">↷ Redo</button>
            <button class="pt-btn small" onclick="AppLive.resetOverrides()" title="Clear all transforms saved on this sheet (stale sizes/angles from older editor builds)">Reset transforms</button>
            <button class="pt-btn secondary small" id="visLiveVerify" onclick="AppLive.verify()">Verify WYSIWYG</button>
            <button class="pt-btn secondary small" onclick="AppLive.toggleDiff()">Show diff</button>
            <span id="visLiveVerifyNote" class="vis-live-note"></span>
          </div>
          <div class="vis-live-host" id="visLiveHost">
            <canvas id="visLiveCanvas"></canvas>
            <div class="vis-live-guides" id="visLiveGuides"></div>
            <div class="vis-diff" id="visLiveDiff" style="display:none"><img id="visLiveDiffImg" alt="diff" /></div>
            <div class="vis-live-empty" id="visLiveEmpty">${excelOk ? "" : '<div class="empty"><div class="empty-icon">▤</div><div class="empty-title">No workbook configured</div><div class="empty-sub">Set the Excel file in the Project view, then open the Visualiser again.</div></div>'}</div>
          </div>
          <div class="vis-live-hint-row">
            <span>scroll to zoom · drag empty space to pan · <b>Text Edit</b>: click selects a row (with its symbols) · <b>Icon Edit</b>: click an icon to transform it (stays in its row, center-anchored, respects icon left/right gaps) · double click an icon edits it in either mode · drag move · corner scale · top handle rotate · arrows nudge</span>
            <span id="visLiveNote"></span>
          </div>
        </div>
        <aside class="vis-live-sidebar">
          <div class="vis-live-tabs">
            <button class="pt-btn small on" id="visTabPages" onclick="AppLive.switchTab('pages')">Pages</button>
            <button class="pt-btn small" id="visTabControls" onclick="AppLive.switchTab('controls')">Controls</button>
          </div>
          <div class="vis-live-tab-body" id="visLivePagesTab">
            <div class="vis-live-thumbs" id="visLiveThumbs"><div class="hint" style="padding:12px">Loading…</div></div>
          </div>
          <div class="vis-live-tab-body" id="visLiveControlsTab" style="display:none">
            <div id="visLiveControls"><div class="hint" style="padding:12px">Loading…</div></div>
          </div>
        </aside>
      </div>
    </div>`;
  };

  function setEditMode(mode) {
    L.state.editMode = mode === "icon" ? "icon" : "text";
    const tBtn = el("visModeText");
    const iBtn = el("visModeIcon");
    if (tBtn) tBtn.classList.toggle("on", L.state.editMode === "text");
    if (iBtn) iBtn.classList.toggle("on", L.state.editMode === "icon");
  }

  function setFreeform() {
    L.state.freeform = !L.state.freeform;
    const fBtn = el("visModeFree");
    if (fBtn) fBtn.classList.toggle("on", L.state.freeform);
    markDirty();
  }

  function toggleFx() {
    L.state.fxEnabled = !L.state.fxEnabled;
    const fxBtn = el("visFxToggle");
    if (fxBtn) fxBtn.classList.toggle("on", L.state.fxEnabled);
    markDirty();
  }

  function switchTab(name) {
    const pagesBtn = el("visTabPages");
    const ctlBtn = el("visTabControls");
    const pagesTab = el("visLivePagesTab");
    const ctlTab = el("visLiveControlsTab");
    if (name === "controls") {
      if (pagesBtn) pagesBtn.classList.remove("on");
      if (ctlBtn) ctlBtn.classList.add("on");
      if (pagesTab) pagesTab.style.display = "none";
      if (ctlTab) ctlTab.style.display = "";
      if (!el("visLiveControls").innerHTML.trim()) renderControls();
    } else {
      if (pagesBtn) pagesBtn.classList.add("on");
      if (ctlBtn) ctlBtn.classList.remove("on");
      if (pagesTab) pagesTab.style.display = "";
      if (ctlTab) ctlTab.style.display = "none";
    }
  }

  /* ------------------------------ route init ------------------------------ */

  async function initRoute() {
    releaseStyleBar();                       // a bar borrowed by Typography comes home
    bindViewEvents();
    bindKeys();
    const sheetSel = el("visLiveSheet");
    if (!sheetSel) return;
    const badge = el("visLiveBadge");
    try {
      const meta = await api("/api/visualiser/sheets", { method: "POST", body: {} });
      L.state.meta = meta;
      // the page already picked stays picked when the screen is drawn again (scan finished, etc.)
      L.state.sheet = allSheets(meta).includes(L.state.sheet) ? L.state.sheet
        : (meta.sheets && meta.sheets[0]) || allSheets(meta)[0] || "";
      const nameEl = el("visLiveSheet");
      // the view was drawn before this list arrived: fill the picker and drop
      // the "No workbook configured" placeholder that covers the canvas
      if (nameEl) {
        nameEl.innerHTML = allSheets(meta).map((n) => `<option value="${esc(n)}">${esc(n)}${studioTag(n) ? " — " + studioTag(n) : ""}</option>`).join("");
        nameEl.value = L.state.sheet;
        nameEl.disabled = !L.state.sheet;
      }
      const emptyNow = el("visLiveEmpty");
      if (emptyNow && meta.excel_ok !== false && L.state.sheet) {
        emptyNow.innerHTML = "";
        emptyNow.style.display = "none";
      }
      renderSheetRail();
      if (L.state.sheet) {
        if (badge) { badge.classList.remove("idle"); badge.textContent = "Rendering…"; }
        const sameSheet = !!(L.state.data && L.state.data.sheet_name === L.state.sheet);
        if (sameSheet) {
          L.state.renderTarget = null;
          resize();
          markDirty();
        }
        try {
          await refreshData(sameSheet ? false : true);
        } catch (e) { /* refreshData keeps the last good data */ }
        if (badge) { badge.classList.add("idle"); badge.textContent = "Ready"; }
      } else {
        const emptyEl = el("visLiveEmpty");
        if (emptyEl) emptyEl.style.display = "";
        if (badge) badge.textContent = "No sheet";
      }
    } catch (e) {
      const emptyEl = el("visLiveEmpty");
      if (emptyEl) emptyEl.style.display = "";
      const list = el("visLiveRailList");
      if (list) list.innerHTML = `<div class="hint" style="padding:10px">No workbook loaded.</div>`;
      if (badge) { badge.classList.add("idle"); badge.textContent = "Unavailable"; }
    }
  }

  function bindKeys() {
    if (L.state._keyBound) return;
    L.state._keyBound = true;
    document.addEventListener("keydown", onKeyDown, true);
  }

  function bindSheetSelect() {
    const sel = el("visLiveSheet");
    if (!sel) return;
    sel.addEventListener("change", () => {
      setSheet(sel.value);
    });
  }

  function setSheet(name) {
    if (!name || name === L.state.sheet) return;
    L.state.sheet = name;
    updateSheetRailActive();
    scheduleSheetThumb(1500);
    L.state.data = null;
    L.state.elements = [];
    L.state.page = 0;
    L.state.selected = null;
    L.state.overrides = {};
    L.state.paylines = null;
    L.state.fitted = false;
    syncPaylineUi();
    refreshData(true);
  }

  function cancelDrag() {
    clearTimeout(L.state.relayoutTimer);
    L.state.drag = null;
    L.state.pan = null;
    L.state.selected = null;
    markDirty();
  }

  function destroy() {
    cancelDrag();
    L.state.data = null;
    L.state.pages = [];
    L.state.elements = [];
    L.state.icons = {};
    L.state.stripImgs = {};
    L.state.overrides = {};
    L.state.thumbUrls = [];
    L.state.sheetThumbs = {};
    clearTimeout(L.state.dataRefreshTimer);
    clearTimeout(L.state.thumbTimer);
    clearTimeout(L.state.railTimer);
  }

  function active() { return !!(L.state.data); }

  /* diagnostics: returns the last FX sprite state (null = all good) */
  window.LiveFxDiag = () => L.state.fxDiag;

  window.AppLive = {
    bgSpec, bgDest,
    view: L.view,
    initRoute, init: initRoute, setSheet, setPage, switchTab, renderControls,
    setEditMode, setFreeform, setSheetFromRail, toggleFx,
    fit, setZoom, zoomBy, centerOnly,
    undo, redo,
    sync, resize, refreshData, verify, toggleDiff, cancelDrag, active, markDirty,
    renderInto, redrawInto, draftText, draftSettings, pageGeometry, renderThumb, styleRowAt, releaseStyleBar, hideTableBar, tableAt, showTableBar, elementAt, textRows,
    cutHover, hideCutButtons, tablePartMenu, hidePartMenu, renderThumb, rowRoleMenu, iconTokens: { untag: untagToken, scale: tokenScale, norm: normToken, gaps: (t) => (GAP_TAG.test(String(t || "")) ? tokGaps(t) : null) },
    nudgeSelected, resetOverrides, destroy,
    wordText: { skel, occurrences },                 // exact-occurrence word styles (typo-preview.js selections)
    state: L.state,
  };

  document.addEventListener("DOMContentLoaded", () => { bindSheetSelect(); });
})();
