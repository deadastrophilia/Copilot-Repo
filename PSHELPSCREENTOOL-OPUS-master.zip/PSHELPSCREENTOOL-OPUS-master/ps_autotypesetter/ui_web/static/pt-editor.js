/* Advanced Edit Mode — standalone addon.
 * Opens a Photoshop-like slot editor (move/resize/rename/add/duplicate/
 * mirror, undo/redo, snapping, layer-style sidebar) for the currently
 * selected paytable template. Saving writes the template through the
 * existing /api/paytable_mapper/save endpoint and refreshes the live
 * preview. Self-contained: no edits to app.js internals required beyond
 * the entry button.
 */
(() => {
  "use strict";
  if (window.PTEditor) return;

  const $ = (id) => document.getElementById(id);
  const getApp = () => (typeof App !== "undefined" ? App : null);
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const deep = (o) => JSON.parse(JSON.stringify(o));
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const rnd = (v) => Math.round(v * 100) / 100;
  const emptyRect = () => ({ x: 0, y: 0, w: 0, h: 0 });

  const CSS = `
.pte-root{position:fixed;inset:0;z-index:9999;background:rgba(8,10,14,.72);display:flex;align-items:center;justify-content:center;font-family:inherit;color:#dfe6f0}
.pte-dialog{width:min(1240px,96vw);height:min(780px,93vh);background:#141821;border:1px solid #2a3240;border-radius:12px;display:flex;flex-direction:column;box-shadow:0 24px 80px rgba(0,0,0,.6);overflow:hidden}
.pte-head{display:flex;align-items:center;gap:10px;padding:10px 14px;border-bottom:1px solid #232b38;background:#171c26;flex:none}
.pte-title{font-size:13px;font-weight:600;letter-spacing:.3px}
.pte-dirty{font-size:11px;color:#ffb648;background:rgba(255,182,72,.12);border:1px solid rgba(255,182,72,.35);padding:2px 8px;border-radius:99px}
.pte-x{margin-left:auto;background:none;border:1px solid transparent;color:#9aa7b8;width:30px;height:30px;border-radius:7px;cursor:pointer;font-size:14px}
.pte-x:hover{background:#232b38;color:#fff}
.pte-body{flex:1;display:flex;flex-direction:column;min-height:0}
.pte-tools{display:flex;align-items:center;gap:6px;padding:8px 12px;border-bottom:1px solid #232b38;background:#171c26;flex-wrap:wrap;flex:none}
.pte-tools .sep{width:1px;height:22px;background:#2a3240;margin:0 4px}
.pte-tbtn{background:#1d232e;border:1px solid #2a3240;color:#cdd7e4;border-radius:7px;padding:5px 10px;font-size:12px;cursor:pointer;display:inline-flex;align-items:center;gap:6px}
.pte-tbtn:hover{background:#252d3b}
.pte-tbtn.on{background:#2c5fd0;border-color:#3f77e8;color:#fff}
.pte-tbtn.primary{background:#2c5fd0;border-color:#3f77e8;color:#fff}
.pte-tbtn:disabled{opacity:.4;cursor:not-allowed}
.pte-tbtn .kbd{margin-left:4px;font-size:10px;opacity:.6;border:1px solid rgba(255,255,255,.18);border-radius:4px;padding:0 4px}
.pte-main{flex:1;display:flex;min-height:0}
.pte-canvas-host{flex:1;position:relative;background:#0d1016;overflow:hidden}
#pteCanvas{position:absolute;inset:0;width:100%;height:100%;display:block;cursor:crosshair;touch-action:none}
.pte-canvas-host.pan #pteCanvas{cursor:grab}
.pte-canvas-host.pan.grabbing #pteCanvas{cursor:grabbing}
.pte-side{flex:none;width:264px;border-left:1px solid #232b38;background:#141821;display:flex;flex-direction:column;min-height:0}
.pte-side-head{padding:9px 12px;font-size:11px;font-weight:600;letter-spacing:.6px;text-transform:uppercase;color:#8b98aa;border-bottom:1px solid #232b38;display:flex;justify-content:space-between;flex:none}
.pte-list{flex:1;overflow-y:auto;padding:6px}
.pte-row{display:flex;align-items:center;gap:6px;padding:5px 7px;border-radius:7px;border:1px solid transparent;cursor:default;user-select:none}
.pte-row:hover{background:#1c222e}
.pte-row.sel{background:#22304a;border-color:#3f77e8}
.pte-row.dragging{opacity:.45}
.pte-row .pte-badge{flex:none;width:42px;text-align:center;font-size:9.5px;font-weight:700;letter-spacing:.4px;border-radius:5px;padding:2px 0;text-transform:uppercase;color:#0c0f14}
.pte-row .pte-name{flex:1;font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;cursor:pointer}
.pte-row .pte-pos{flex:none;font-size:10px;color:#5f6b7d;font-variant-numeric:tabular-nums}
.pte-row input.pte-ren{flex:1;font-size:12px;background:#0d1016;color:#fff;border:1px solid #3f77e8;border-radius:5px;padding:3px 6px;min-width:0}
.pte-row .pte-ic{flex:none;background:none;border:none;color:#6b7686;cursor:pointer;font-size:13px;padding:1px 3px;border-radius:4px;width:22px;height:22px}
.pte-row .pte-ic:hover{background:#2a3240;color:#fff}
.pte-row .pte-ic.on{color:#ffb648}
.pte-row .pte-ic.del:hover{color:#ff5c5c}
.pte-badge.pay{background:#5ad0a8}.pte-badge.value{background:#8f7bff}.pte-badge.text{background:#4fb3ff}
.pte-badge.wild{background:#ff7bd0}.pte-badge.bg{background:#8896a8}.pte-badge.symbol{background:#ffd24a}
.pte-status{flex:none;display:flex;align-items:center;gap:14px;padding:6px 12px;border-top:1px solid #232b38;background:#171c26;font-size:11.5px;color:#8b98aa;font-variant-numeric:tabular-nums}
.pte-status b{color:#cdd7e4;font-weight:600}
.pte-foot{flex:none;display:flex;align-items:center;justify-content:space-between;gap:10px;padding:10px 12px;border-top:1px solid #232b38;background:#171c26}
.pte-actions{display:flex;gap:6px;flex-wrap:wrap}
.pte-foot-right{display:flex;gap:8px;flex:none}
.pte-ren-float{position:absolute;z-index:20}
.pte-ren-float input{width:100%;background:#0d1016;color:#fff;border:1px solid #3f77e8;border-radius:6px;padding:4px 8px;font-size:12px;outline:none}
.pte-hint{font-size:11px;color:#5f6b7d;padding:8px 12px 0}
.pte-rows{display:flex;align-items:center;gap:8px;padding:6px 12px;border-bottom:1px solid #232b38;background:#141821;flex-wrap:wrap;flex:none}
.pte-rband{display:flex;align-items:center;gap:6px;padding:4px 8px;background:#1a202b;border:1px solid #2a3240;border-radius:7px;font-size:11px;color:#8b98aa;white-space:nowrap}
.pte-rlab{font-weight:600;color:#cdd7e4;margin-right:2px}
.pte-rin{width:44px;background:#0d1016;color:#fff;border:1px solid #2a3547;border-radius:5px;padding:2px 4px;font-size:11px;text-align:center;outline:none}
.pte-rin:focus{border-color:#3f77e8}
.pte-rst{display:inline-flex;align-items:center;gap:5px;font-size:11px;color:#8b98aa;white-space:nowrap;cursor:pointer}
.pte-rst input{accent-color:#3f77e8}
`;

  const S = {
    open: false,
    modal: null,
    host: null,
    canvas: null,
    ctx: null,
    template: null,
    slots: {},
    names: [],
    cw: 1,
    ch: 1,
    sel: [],
    locks: {},
    hides: {},
    zoom: 1,
    ox: 0,
    oy: 0,
    tool: "select",
    snap: true,
    grid: true,
    snapStep: 10,
    undo: [],
    redo: [],
    dirty: false,
    renames: {},
    drag: null,
    marquee: null,
    dpr: 1,
    lastId: 0,
    mouse: { x: 0, y: 0 },
    rows: null,
    scaleText: false,
  };
  let styleInjected = false;

  /* ------------------------------ view helpers ------------------------------ */

  const worldToScreen = (x, y) => ({ x: x * S.zoom + S.ox, y: y * S.zoom + S.oy });
  const screenToWorld = (sx, sy) => ({ x: (sx - S.ox) / S.zoom, y: (sy - S.oy) / S.zoom });

  const slotRect = (name) => {
    const b = S.slots[name] || {};
    return { x: b.x || 0, y: b.y || 0, w: b.w || 0, h: b.h || 0 };
  };

  const fitView = () => {
    const w = S.host.clientWidth || 800;
    const h = S.host.clientHeight || 500;
    S.zoom = Math.min((w - 48) / Math.max(1, S.cw), (h - 48) / Math.max(1, S.ch), 4);
    S.zoom = Math.max(S.zoom, 0.01);
    S.ox = (w - S.cw * S.zoom) / 2;
    S.oy = (h - S.ch * S.zoom) / 2;
  };

  const resizeCanvas = () => {
    const w = S.host.clientWidth || 800;
    const h = S.host.clientHeight || 500;
    S.dpr = window.devicePixelRatio || 1;
    S.canvas.width = Math.round(w * S.dpr);
    S.canvas.height = Math.round(h * S.dpr);
    S.canvas.style.width = w + "px";
    S.canvas.style.height = h + "px";
  };

  /* ------------------------------ drawing ------------------------------ */

  const typeBadge = (name) => {
    const n = String(name).toLowerCase();
    if (/(?:^|\.)pay\d*$/i.test(n) || n.endsWith(".pays")) return "pay";
    if (/(?:^|\.)value\d*$/i.test(n) || n.endsWith(".values")) return "value";
    if (n.startsWith("wild")) return "wild";
    if (n.includes("title") || n.includes("text") || n.includes("sub")) return "text";
    if (n.includes("bg") || n.includes("card")) return "bg";
    return "symbol";
  };

  const badgeColor = (t) => ({ pay: "#5ad0a8", value: "#8f7bff", text: "#4fb3ff", wild: "#ff7bd0", bg: "#8896a8", symbol: "#ffd24a" }[t] || "#8896a8");

  const draw = () => {
    const ctx = S.ctx;
    if (!ctx) return;
    const w = S.host.clientWidth || 800;
    const h = S.host.clientHeight || 500;
    ctx.setTransform(S.dpr, 0, 0, S.dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = "#0d1016";
    ctx.fillRect(0, 0, w, h);

    const tl = worldToScreen(0, 0);
    const br = worldToScreen(S.cw, S.ch);
    ctx.fillStyle = "#161b24";
    ctx.fillRect(tl.x, tl.y, br.x - tl.x, br.y - tl.y);
    ctx.strokeStyle = "#39445a";
    ctx.lineWidth = 1;
    ctx.strokeRect(tl.x + 0.5, tl.y + 0.5, br.x - tl.x, br.y - tl.y);

    if (S.grid && S.zoom >= 0.12) {
      const step = S.snapStep;
      const pxStep = step * S.zoom;
      if (pxStep >= 5) {
        ctx.strokeStyle = "rgba(120,140,175,.10)";
        ctx.lineWidth = 1;
        ctx.beginPath();
        for (let gx = step; gx < S.cw; gx += step) {
          const sx = Math.round(tl.x + gx * S.zoom) + 0.5;
          ctx.moveTo(sx, tl.y);
          ctx.lineTo(sx, br.y);
        }
        for (let gy = step; gy < S.ch; gy += step) {
          const sy = Math.round(tl.y + gy * S.zoom) + 0.5;
          ctx.moveTo(tl.x, sy);
          ctx.lineTo(br.x, sy);
        }
        ctx.stroke();
        if (pxStep >= 16) {
          const big = step * 5;
          ctx.strokeStyle = "rgba(120,140,175,.20)";
          ctx.beginPath();
          for (let gx = big; gx < S.cw; gx += big) {
            const sx = Math.round(tl.x + gx * S.zoom) + 0.5;
            ctx.moveTo(sx, tl.y);
            ctx.lineTo(sx, br.y);
          }
          for (let gy = big; gy < S.ch; gy += big) {
            const sy = Math.round(tl.y + gy * S.zoom) + 0.5;
            ctx.moveTo(tl.x, sy);
            ctx.lineTo(br.x, sy);
          }
          ctx.stroke();
        }
      }
    }

    const selSet = new Set(S.sel);
    for (const name of S.names) {
      if (S.hides[name]) continue;
      const b = slotRect(name);
      const r = worldToScreen(b.x, b.y);
      const rw = b.w * S.zoom;
      const rh = b.h * S.zoom;
      if (r.x > w || r.y > h || r.x + rw < 0 || r.y + rh < 0) continue;
      const locked = !!S.locks[name];
      const selected = selSet.has(name);
      const badge = typeBadge(name);
      const col = locked ? "#7a8596" : badgeColor(badge);
      ctx.fillStyle = selected ? "rgba(255,210,74,.14)" : "rgba(63,119,232,.10)";
      ctx.fillRect(r.x, r.y, rw, rh);
      ctx.strokeStyle = selected ? "#ffd24a" : col;
      ctx.lineWidth = selected ? 2 : 1;
      ctx.strokeRect(r.x + 0.5, r.y + 0.5, rw, rh);
      if (rw > 42 && rh > 14) {
        ctx.font = "11px system-ui, sans-serif";
        const tw = Math.min(rw - 6, ctx.measureText(name).width + 10);
        ctx.fillStyle = "rgba(10,12,16,.78)";
        ctx.fillRect(r.x + 2, r.y + 2, tw, 15);
        ctx.fillStyle = selected ? "#ffd24a" : col;
        ctx.textBaseline = "middle";
        ctx.fillText(name, r.x + 7, r.y + 9.5);
      }
      if (selected) drawHandles(r.x, r.y, rw, rh);
    }

    if (S.marquee) {
      const m = S.marquee;
      const x = Math.min(m.x0, m.x1);
      const y = Math.min(m.y0, m.y1);
      const mw = Math.abs(m.x1 - m.x0);
      const mh = Math.abs(m.y1 - m.y0);
      ctx.fillStyle = "rgba(63,119,232,.10)";
      ctx.fillRect(x, y, mw, mh);
      ctx.strokeStyle = "#3f77e8";
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 3]);
      ctx.strokeRect(x + 0.5, y + 0.5, mw, mh);
      ctx.setLineDash([]);
    }

    if (S.drag && S.drag.kind === "add") {
      const d = S.drag;
      const x = Math.min(d.x0, d.x1);
      const y = Math.min(d.y0, d.y1);
      const mw = Math.abs(d.x1 - d.x0);
      const mh = Math.abs(d.y1 - d.y0);
      ctx.fillStyle = "rgba(255,210,74,.12)";
      ctx.fillRect(x, y, mw, mh);
      ctx.strokeStyle = "#ffd24a";
      ctx.lineWidth = 1;
      ctx.setLineDash([5, 4]);
      ctx.strokeRect(x + 0.5, y + 0.5, mw, mh);
      ctx.setLineDash([]);
    }
  };

  const HANDLES = ["nw", "n", "ne", "e", "se", "s", "sw", "w"];

  const drawHandles = (x, y, rw, rh) => {
    const ctx = S.ctx;
    const s = 8;
    const pts = {
      nw: [x, y], n: [x + rw / 2, y], ne: [x + rw, y],
      e: [x + rw, y + rh / 2], se: [x + rw, y + rh], s: [x + rw / 2, y + rh],
      sw: [x, y + rh], w: [x, y + rh / 2],
    };
    ctx.fillStyle = "#ffd24a";
    ctx.strokeStyle = "#0d1016";
    ctx.lineWidth = 1;
    for (const hd of HANDLES) {
      const [hx, hy] = pts[hd];
      ctx.fillRect(hx - s / 2, hy - s / 2, s, s);
      ctx.strokeRect(hx - s / 2, hy - s / 2, s, s);
    }
  };

  /* ------------------------------ hit testing ------------------------------ */

  const hitHandle = (sx, sy) => {
    if (S.sel.length !== 1) return null;
    const name = S.sel[0];
    const b = slotRect(name);
    const r = worldToScreen(b.x, b.y);
    const rw = b.w * S.zoom;
    const rh = b.h * S.zoom;
    const s = 9;
    const pts = {
      nw: [r.x, r.y], n: [r.x + rw / 2, r.y], ne: [r.x + rw, r.y],
      e: [r.x + rw, r.y + rh / 2], se: [r.x + rw, r.y + rh], s: [r.x + rw / 2, r.y + rh],
      sw: [r.x, r.y + rh], w: [r.x, r.y + rh / 2],
    };
    for (const hd of HANDLES) {
      const [hx, hy] = pts[hd];
      if (Math.abs(sx - hx) <= s / 2 && Math.abs(sy - hy) <= s / 2) return hd;
    }
    return null;
  };

  const hitSlot = (sx, sy) => {
    for (let i = S.names.length - 1; i >= 0; i--) {
      const name = S.names[i];
      if (S.hides[name] || S.locks[name]) continue;
      const b = slotRect(name);
      const r = worldToScreen(b.x, b.y);
      const rw = b.w * S.zoom;
      const rh = b.h * S.zoom;
      if (sx >= r.x && sx <= r.x + rw && sy >= r.y && sy <= r.y + rh) return name;
    }
    return null;
  };

  /* ------------------------------ state mutations ------------------------------ */

  const snapshot = () => ({ slots: deep(S.slots), names: S.names.slice(), renames: deep(S.renames) });
  const pushUndo = () => {
    S.undo.push(snapshot());
    if (S.undo.length > 80) S.undo.shift();
    S.redo = [];
    setDirty();
    draw();
    renderList();
  };

  const setDirty = () => {
    S.dirty = true;
    const tag = $("pteDirtyTag");
    if (tag) tag.hidden = false;
  };

  const undo = () => {
    if (!S.undo.length) return;
    S.redo.push(snapshot());
    const st = S.undo.pop();
    S.slots = st.slots;
    S.names = st.names;
    S.renames = st.renames;
    S.sel = S.sel.filter((n) => S.slots[n]);
    draw();
    renderList();
    refreshRows();
    syncUndoBtns();
  };

  const redo = () => {
    if (!S.redo.length) return;
    S.undo.push(snapshot());
    const st = S.redo.pop();
    S.slots = st.slots;
    S.names = st.names;
    S.renames = st.renames;
    S.sel = S.sel.filter((n) => S.slots[n]);
    draw();
    renderList();
    refreshRows();
    syncUndoBtns();
  };

  const syncUndoBtns = () => {
    const u = $("pteUndo");
    const r = $("pteRedo");
    if (u) u.disabled = !S.undo.length;
    if (r) r.disabled = !S.redo.length;
  };

  const uniqueName = (base) => {
    let name = base;
    let i = 1;
    while (S.slots[name]) name = base + "." + (i++);
    return name;
  };

  const nextSlotId = () => {
    S.lastId += 1;
    return uniqueName("slot." + S.lastId);
  };

  const deleteSlots = (names) => {
    const list = names.filter((n) => S.slots[n]);
    if (!list.length) return;
    pushUndo();
    for (const n of list) {
      delete S.slots[n];
      delete S.locks[n];
      delete S.hides[n];
    }
    S.names = S.names.filter((n) => S.slots[n]);
    S.sel = S.sel.filter((n) => S.slots[n]);
    draw();
    renderList();
    refreshRows();
  };

  const duplicateSlots = (names, dx, dy) => {
    const list = names.filter((n) => S.slots[n]);
    if (!list.length) return [];
    pushUndo();
    const added = [];
    for (const n of list) {
      const b = slotRect(n);
      const nn = uniqueName(n + ".copy");
      S.slots[nn] = { x: rnd(b.x + (dx || 16)), y: rnd(b.y + (dy || 16)), w: rnd(b.w), h: rnd(b.h) };
      if (S.locks[n]) S.locks[nn] = true;
      if (S.hides[n]) S.hides[nn] = true;
      S.names.push(nn);
      added.push(nn);
    }
    S.sel = added;
    draw();
    renderList();
    return added;
  };

  const applySnap = (v) => (S.snap ? Math.round(v / S.snapStep) * S.snapStep : v);

  const nudge = (names, dx, dy) => {
    if (!names.length) return;
    pushUndo();
    for (const n of names) {
      const b = S.slots[n];
      b.x = rnd(b.x + dx);
      b.y = rnd(b.y + dy);
    }
    draw();
    renderList();
  };

  /* ------------------------------ rename ------------------------------ */

  const doRename = (oldName, newName) => {
    if (!S.slots[oldName] || !newName) return false;
    if (newName === oldName) return true;
    if (S.slots[newName]) return false;
    pushUndo();
    S.slots[newName] = S.slots[oldName];
    delete S.slots[oldName];
    if (S.locks[oldName]) { S.locks[newName] = true; delete S.locks[oldName]; }
    if (S.hides[oldName]) { S.hides[newName] = true; delete S.hides[oldName]; }
    S.names = S.names.map((n) => (n === oldName ? newName : n));
    S.sel = S.sel.map((n) => (n === oldName ? newName : n));
    S.renames[oldName] = newName;
    draw();
    renderList();
    refreshRows();
    return true;
  };

  const resolveRename = (name) => {
    let cur = name;
    let guard = 0;
    while (S.renames[cur] && guard++ < 10) cur = S.renames[cur];
    return cur;
  };

  /* ------------------------------ card rows ------------------------------ */

  const bandSlotNames = (band) => {
    const out = [];
    const rows = S.rows || [];
    let offset = 0;
    let idx = -1;
    for (let i = 0; i < rows.length; i++) {
      if (rows[i] === band) { idx = i; break; }
      offset += rows[i].count;
    }
    if (idx < 0) return out;
    for (let i = 1; i <= band.count; i++) {
      out.push(`@slot.pic${offset + i}`, `@slot.pay${offset + i}`, `@slot.value${offset + i}`);
    }
    return out;
  };

  const detectRows = () => {
    const cards = [];
    for (const n of S.names) {
      const m = /^@slot\.pic(\d+)$/i.exec(n);
      if (m) cards.push({ idx: parseInt(m[1], 10), b: slotRect(n) });
    }
    if (cards.length < 2) return null;
    cards.sort((a, b) => a.idx - b.idx);
    let best = -1, at = -1;
    for (let i = 1; i < cards.length; i++) {
      const g = cards[i].b.y - (cards[i - 1].b.y + cards[i - 1].b.h);
      if (g > best) { best = g; at = i; }
    }
    if (at < 1) return null;
    const groups = [cards.slice(0, at), cards.slice(at)];
    const bands = [];
    for (const list of groups) {
      const cs = list.slice().sort((a, b) => a.idx - b.idx);
      const y = cs[0].b.y;
      if (!cs.every((c) => Math.abs(c.b.y - y) <= 6)) return null;
      const idx0 = cs[0].idx;
      const x = cs[0].b.x;
      const card_w = cs[0].b.w;
      const card_h = cs[0].b.h;
      const gap = cs.length > 1 ? Math.max(0, cs[1].b.x - (cs[0].b.x + cs[0].b.w)) : 24;
      const pay = slotRect(`@slot.pay${idx0}`);
      const val = slotRect(`@slot.value${idx0}`);
      bands.push({
        count: cs.length,
        x, y, card_w, card_h, gap,
        pay_h: pay && pay.h ? pay.h : 54,
        pay_off: pay ? (pay.y - y) : card_h + 30,
        value_h: val && val.h ? val.h : 48,
        value_off: val ? (val.y - y) : card_h + 90,
      });
    }
    return bands;
  };

  const refreshRows = () => {
    const next = detectRows();
    if (next && next.length) S.rows = next;
    renderRowsPanel();
  };

  const setBandRect = (name, x, y, w, h) => {
    const b = (S.slots[name] = S.slots[name] || { x: 0, y: 0, w: 0, h: 0 });
    b.x = rnd(x); b.y = rnd(y); b.w = rnd(w); b.h = rnd(h);
  };

  const rebuildRows = () => {
    if (!S.rows || !S.rows.length) return;
    pushUndo();
    const total = S.rows.reduce((s, b) => s + b.count, 0);
    const kept = new Set();
    const re = /^@slot\.(pic|pay|value)\d+$/i;
    let offset = 0;
    for (const band of S.rows) {
      for (let i = 0; i < band.count; i++) {
        const n = offset + i + 1;
        const x = band.x + i * (band.card_w + band.gap);
        setBandRect(`@slot.pic${n}`, x, band.y, band.card_w, band.card_h);
        setBandRect(`@slot.pay${n}`, x, band.y + band.pay_off, band.card_w, band.pay_h);
        setBandRect(`@slot.value${n}`, x, band.y + band.value_off, band.card_w, band.value_h);
        kept.add(`@slot.pic${n}`); kept.add(`@slot.pay${n}`); kept.add(`@slot.value${n}`);
      }
      offset += band.count;
    }
    const app = getApp();
    for (const n of S.names.slice()) {
      if (re.test(n) && !kept.has(n)) {
        delete S.slots[n];
        if (app && app.paytableMapper && app.paytableMapper.mappings) delete app.paytableMapper.mappings[n];
      }
    }
    for (const k of kept) if (!S.names.includes(k)) S.names.push(k);
    S.names = S.names.filter((n) => S.slots[n]);
    S.sel = S.sel.filter((n) => S.slots[n]);
    draw();
    renderList();
  };

  const scaleBand = (bi, factor) => {
    const b = S.rows && S.rows[bi];
    if (!b || factor <= 0 || factor === 1) return;
    if (S.scaleText) {
      const app = getApp();
      const pm = app && app.paytableMapper;
      if (pm && pm.mappings) {
        for (const n of bandSlotNames(b)) {
          const m = pm.mappings[n];
          if (!m || typeof m !== "object") continue;
          const fs = parseFloat(m.font_size);
          if (fs > 0) m.font_size = Math.max(4, Math.round(fs * factor));
          const ih = parseFloat(m.icon_height);
          if (ih > 0) m.icon_height = Math.max(8, Math.round(ih * factor));
        }
      }
    }
    b.card_w = rnd(b.card_w * factor);
    b.card_h = rnd(b.card_h * factor);
    b.gap = Math.max(0, rnd(b.gap * factor));
    b.pay_h = Math.max(1, rnd(b.pay_h * factor));
    b.value_h = Math.max(1, rnd(b.value_h * factor));
    b.pay_off = rnd(b.pay_off * factor);
    b.value_off = rnd(b.value_off * factor);
    rebuildRows();
    renderRowsPanel();
  };

  const renderRowsPanel = () => {
    const host = $("pteRows");
    if (!host) return;
    if (!S.rows || !S.rows.length) { host.style.display = "none"; host.innerHTML = ""; return; }
    host.style.display = "";
    const labels = ["Top row", "Bottom row"];
    const label = (text, inner) => `<label class="pte-rlab">${text} ${inner}</label>`;
    const num = (bi, key, w) => `<input type="number" class="pte-rin" style="width:${w}px" value="${esc(S.rows[bi][key])}" data-band="${bi}" data-key="${key}" step="1">`;
    const parts = [
      `<label class="pte-rst"><input type="checkbox" ${S.scaleText ? "checked" : ""} id="pteScaleText"> Scale text with cards</label>`,
    ];
    S.rows.forEach((b, bi) => {
      parts.push(
        `<div class="pte-rband"><span class="pte-rlab">${labels[bi] || "Row " + (bi + 1)}</span>` +
        label("Cards", num(bi, "count", 44)) +
        label("X", num(bi, "x", 64)) +
        label("Y", num(bi, "y", 64)) +
        label("W", num(bi, "card_w", 56)) +
        label("H", num(bi, "card_h", 56)) +
        label("Gap", num(bi, "gap", 44)) +
        label("Pay H", num(bi, "pay_h", 44)) +
        label("Val H", num(bi, "value_h", 44)) +
        `<button type="button" class="pte-tbtn" data-band="${bi}" data-act="select">Select</button>` +
        `<button type="button" class="pte-tbtn" data-band="${bi}" data-act="scale" title="Scale the whole row ×2 around its top-left corner${S.scaleText ? " (text and icons scale too)" : ""}">Scale ×2</button>` +
        `</div>`
      );
    });
    host.innerHTML = parts.join("");
    host.querySelectorAll("input.pte-rin").forEach((el) => {
      el.addEventListener("change", () => {
        const bi = parseInt(el.dataset.band, 10);
        const key = el.dataset.key;
        if (!S.rows[bi]) return;
        if (key === "count") S.rows[bi].count = clamp(Math.round(parseFloat(el.value) || 1), 1, 30);
        else S.rows[bi][key] = parseFloat(el.value) || 0;
        rebuildRows();
        renderRowsPanel();
      });
    });
    const st = host.querySelector("#pteScaleText");
    if (st) st.addEventListener("change", () => { S.scaleText = !!st.checked; });
    host.querySelectorAll("button[data-act]").forEach((el) => {
      el.addEventListener("click", () => {
        const bi = parseInt(el.dataset.band, 10);
        if (!S.rows[bi]) return;
        if (el.dataset.act === "select") {
          S.sel = bandSlotNames(S.rows[bi]).filter((n) => S.slots[n]);
          draw();
          renderList();
        } else if (el.dataset.act === "scale") {
          scaleBand(bi, 2);
        }
      });
    });
  };

  const floatRename = (name, sx, sy) => {
    const host = S.host;
    const inp = document.createElement("input");
    inp.value = name;
    inp.className = "pte-ren-float";
    const box = document.createElement("div");
    box.className = "pte-ren-float";
    box.appendChild(inp);
    host.appendChild(box);
    box.style.left = clamp(sx - 40, 4, (host.clientWidth || 800) - 84) + "px";
    box.style.top = clamp(sy - 12, 4, (host.clientHeight || 500) - 32) + "px";
    box.style.width = "150px";
    inp.focus();
    inp.select();
    // closed once: removing the focused box fires its blur while it is still connected — a second
    // remove() threw "The node to be removed is no longer a child of this node" (and Esc renamed)
    let closed = false;
    const close = () => {
      if (closed) return false;
      closed = true;
      box.remove();
      return true;
    };
    const commit = () => {
      if (closed) return;
      const v = inp.value.trim();
      close();
      if (v && !doRename(name, v)) toastPTE(`"${v}" already exists or invalid — rename kept unchanged.`, "err");
    };
    inp.addEventListener("keydown", (e) => {
      e.stopPropagation();
      if (e.key === "Enter") commit();
      if (e.key === "Escape") close();
    });
    inp.addEventListener("blur", commit);
  };

  /* ------------------------------ mirror row ------------------------------ */

  const mirrorRow = () => {
    if (!S.sel.length) { toastPTE("Select a slot first.", "err"); return; }
    const src = S.sel[0];
    const b = slotRect(src);
    if (S.cw <= 0) return;
    const n = promptPTE("Number of mirrored copies:", "3");
    const count = parseInt(n, 10);
    if (!count || count < 1 || count > 40) return;
    pushUndo();
    const added = [];
    const mw = S.cw - (b.x + b.w);
    const start = b.x + b.w;
    const gap = count > 1 ? mw / count : 0;
    for (let i = 1; i <= count; i++) {
      const nn = uniqueName(src + ".mirror." + i);
      const x = start + gap * (i - 1);
      S.slots[nn] = { x: rnd(x), y: rnd(b.y), w: rnd(b.w), h: rnd(b.h) };
      S.names.push(nn);
      added.push(nn);
    }
    S.sel = added;
    draw();
    renderList();
    setDirty();
  };

  const alignSel = (mode) => {
    const list = S.sel.filter((n) => S.slots[n]);
    if (list.length < 2) { toastPTE("Select 2+ slots to align.", "err"); return; }
    pushUndo();
    const boxes = list.map((n) => slotRect(n));
    const minX = Math.min(...boxes.map((b) => b.x));
    const maxX = Math.max(...boxes.map((b) => b.x + b.w));
    const minY = Math.min(...boxes.map((b) => b.y));
    const maxY = Math.max(...boxes.map((b) => b.y + b.h));
    const cx = (minX + maxX) / 2;
    const cy = (minY + maxY) / 2;
    for (const n of list) {
      const bb = S.slots[n];
      if (mode === "left") bb.x = rnd(minX);
      else if (mode === "right") bb.x = rnd(maxX - bb.w);
      else if (mode === "hcenter") bb.x = rnd(cx - bb.w / 2);
      else if (mode === "top") bb.y = rnd(minY);
      else if (mode === "bottom") bb.y = rnd(maxY - bb.h);
      else if (mode === "vcenter") bb.y = rnd(cy - bb.h / 2);
    }
    draw();
    renderList();
  };

  const distributeSel = (axis) => {
    const list = S.sel.filter((n) => S.slots[n]);
    if (list.length < 3) { toastPTE("Select 3+ slots to distribute.", "err"); return; }
    pushUndo();
    const ord = list.slice().sort((a, b) =>
      axis === "h" ? (S.slots[a].x - S.slots[b].x) : (S.slots[a].y - S.slots[b].y));
    const first = ord[0];
    const last = ord[ord.length - 1];
    const fb = slotRect(first);
    const lb = slotRect(last);
    const mid = ord.slice(1, -1);
    const step = axis === "h"
      ? (lb.x - (fb.x + fb.w)) / (mid.length + 1)
      : (lb.y - (fb.y + fb.h)) / (mid.length + 1);
    mid.forEach((n, i) => {
      const bb = S.slots[n];
      if (axis === "h") bb.x = rnd(fb.x + fb.w + step * (i + 1));
      else bb.y = rnd(fb.y + fb.h + step * (i + 1));
    });
    draw();
    renderList();
  };

  /* ------------------------------ layer ordering ------------------------------ */

  const isBgSlot = (name) => {
    const t = typeBadge(name);
    return t === "bg";
  };

  // Draw/stack order: S.names goes bottom -> top. Background slots (cards/BG)
  // belong behind every other slot, so they sort first (bottom of the stack).
  // The sidebar renders the list reversed (topmost layer first, like
  // Photoshop), which puts the BG rows at the bottom of the panel.
  const sortLayers = () => {
    const bgs = [];
    const rest = [];
    for (const n of S.names) {
      (isBgSlot(n) ? bgs : rest).push(n);
    }
    S.names = bgs.concat(rest);
  };

  /* ------------------------------ sidebar ------------------------------ */

  const renderList = () => {
    const list = $("pteList");
    if (!list) return;
    const count = $("pteCount");
    if (count) count.textContent = S.names.length;
    const vis = S.names.slice().reverse();
    list.innerHTML = vis.map((name) => {
      const b = slotRect(name);
      const t = typeBadge(name);
      const locked = !!S.locks[name];
      const hidden = !!S.hides[name];
      const selected = S.sel.includes(name);
      return `<div class="pte-row ${selected ? "sel" : ""}" draggable="true" data-name="${esc(name)}">
        <span class="pte-badge ${t}" title="${esc(t)}">${t}</span>
        <span class="pte-name" title="${esc(name)}">${esc(name)}</span>
        <span class="pte-pos">${rnd(b.x)},${rnd(b.y)}</span>
        <button class="pte-ic ${locked ? "on" : ""}" data-act="lock" title="Lock (prevents moving)">${locked ? "🔒" : "🔓"}</button>
        <button class="pte-ic ${hidden ? "on" : ""}" data-act="hide" title="Hide">${hidden ? "👁" : "🚫"}</button>
        <button class="pte-ic del" data-act="del" title="Delete">🗑</button>
      </div>`;
    }).join("");
  };

  const bindList = () => {
    const list = $("pteList");
    if (!list) return;
    list.addEventListener("click", (e) => {
      const row = e.target.closest(".pte-row");
      if (!row) return;
      const name = row.dataset.name;
      const act = e.target.dataset.act;
      if (act === "lock") { pushUndo(); if (S.locks[name]) delete S.locks[name]; else S.locks[name] = true; draw(); renderList(); return; }
      if (act === "hide") { pushUndo(); if (S.hides[name]) delete S.hides[name]; else S.hides[name] = true; draw(); renderList(); return; }
      if (act === "del") { if (confirmPTE(`Delete slot "${name}"?`)) deleteSlots([name]); return; }
      if (e.shiftKey) {
        S.sel = S.sel.includes(name) ? S.sel.filter((n) => n !== name) : S.sel.concat(name);
      } else {
        S.sel = [name];
      }
      draw();
      renderList();
    });
    list.addEventListener("dblclick", (e) => {
      const row = e.target.closest(".pte-row");
      if (!row) return;
      if (e.target.dataset.act) return;
      const name = row.dataset.name;
      const b = slotRect(name);
      const p = worldToScreen(b.x + b.w / 2, b.y + b.h / 2);
      floatRename(name, p.x, p.y);
    });
    let dragRow = null;
    list.addEventListener("dragstart", (e) => {
      const row = e.target.closest(".pte-row");
      if (!row) return;
      dragRow = row;
      row.classList.add("dragging");
      e.dataTransfer.effectAllowed = "move";
      e.dataTransfer.setData("text/plain", row.dataset.name);
    });
    list.addEventListener("dragover", (e) => {
      e.preventDefault();
      const row = e.target.closest(".pte-row");
      if (row && row !== dragRow) {
        const after = e.clientY > row.getBoundingClientRect().top + row.offsetHeight / 2;
        row.style.borderBottom = after ? "2px solid #3f77e8" : "";
        row.style.borderTop = after ? "" : "2px solid #3f77e8";
      }
    });
    list.addEventListener("drop", (e) => {
      e.preventDefault();
      const from = e.dataTransfer.getData("text/plain");
      const row = e.target.closest(".pte-row");
      document.querySelectorAll(".pte-row").forEach((r) => { r.style.borderBottom = ""; r.style.borderTop = ""; });
      if (!row || !from || from === row.dataset.name) return;
      const to = row.dataset.name;
      const after = e.clientY > row.getBoundingClientRect().top + row.offsetHeight / 2;
      const vis = S.names.slice().reverse();
      const fromIdx = vis.indexOf(from);
      const toIdx = vis.indexOf(to);
      if (fromIdx < 0 || toIdx < 0) return;
      pushUndo();
      vis.splice(fromIdx, 1);
      const insertAt = vis.indexOf(to);
      vis.splice(insertAt + (after ? 1 : 0), 0, from);
      S.names = vis.reverse();
      draw();
      renderList();
    });
    list.addEventListener("dragend", () => {
      document.querySelectorAll(".pte-row").forEach((r) => { r.classList.remove("dragging"); r.style.borderBottom = ""; r.style.borderTop = ""; });
    });
  };

  /* ------------------------------ interactions ------------------------------ */

  const bindCanvas = () => {
    const c = S.canvas;
    c.addEventListener("contextmenu", (e) => e.preventDefault());

    c.addEventListener("wheel", (e) => {
      e.preventDefault();
      const rect = c.getBoundingClientRect();
      const sx = e.clientX - rect.left;
      const sy = e.clientY - rect.top;
      const wp = screenToWorld(sx, sy);
      const factor = e.deltaY < 0 ? 1.12 : 1 / 1.12;
      S.zoom = clamp(S.zoom * factor, 0.02, 40);
      S.ox = sx - wp.x * S.zoom;
      S.oy = sy - wp.y * S.zoom;
      draw();
    }, { passive: false });

    const pos = (e) => {
      const rect = c.getBoundingClientRect();
      return { x: e.clientX - rect.left, y: e.clientY - rect.top };
    };

    c.addEventListener("pointerdown", (e) => {
      if (e.button === 1) { S.drag = { kind: "pan", x: e.clientX, y: e.clientY }; S.host.classList.add("grabbing"); c.setPointerCapture(e.pointerId); return; }
      if (e.button !== 0) return;
      const p = pos(e);
      const wp = screenToWorld(p.x, p.y);
      if (S.tool === "add") {
        S.drag = { kind: "add", x0: p.x, y0: p.y, x1: p.x, y1: p.y };
        c.setPointerCapture(e.pointerId);
        return;
      }
      if (S.tool === "hand") {
        S.drag = { kind: "pan", x: e.clientX, y: e.clientY };
        S.host.classList.add("grabbing");
        c.setPointerCapture(e.pointerId);
        return;
      }
      const hd = hitHandle(p.x, p.y);
      if (hd) {
        const name = S.sel[0];
        S.drag = { kind: "resize", hd, name, start: { x: p.x, y: p.y }, orig: slotRect(name) };
        c.setPointerCapture(e.pointerId);
        return;
      }
      const hit = hitSlot(p.x, p.y);
      if (hit) {
        if (e.shiftKey) {
          S.sel = S.sel.includes(hit) ? S.sel.filter((n) => n !== hit) : S.sel.concat(hit);
        } else if (!S.sel.includes(hit)) {
          S.sel = [hit];
        }
        const orig = {};
        S.sel.forEach((n) => { orig[n] = slotRect(n); });
        S.drag = { kind: "move", start: { x: p.x, y: p.y }, wp0: { x: wp.x, y: wp.y }, orig };
        draw();
        renderList();
        c.setPointerCapture(e.pointerId);
        return;
      }
      if (e.shiftKey) {
        S.sel = [];
        draw();
        renderList();
      }
      S.marquee = { x0: p.x, y0: p.y, x1: p.x, y1: p.y };
      c.setPointerCapture(e.pointerId);
    });

    c.addEventListener("pointermove", (e) => {
      const rect = c.getBoundingClientRect();
      const p = { x: e.clientX - rect.left, y: e.clientY - rect.top };
      S.mouse = screenToWorld(p.x, p.y);
      if (S.marquee) {
        S.marquee.x1 = p.x;
        S.marquee.y1 = p.y;
        draw();
        return;
      }
      const d = S.drag;
      if (!d) { updateStatus(); return; }
      if (d.kind === "pan") {
        S.ox += e.clientX - d.x;
        S.oy += e.clientY - d.y;
        d.x = e.clientX;
        d.y = e.clientY;
        draw();
        return;
      }
      if (d.kind === "add") {
        d.x1 = p.x;
        d.y1 = p.y;
        draw();
        updateStatus();
        return;
      }
      if (d.kind === "move") {
        const wp = screenToWorld(p.x, p.y);
        let dx = wp.x - d.wp0.x;
        let dy = wp.y - d.wp0.y;
        dx = applySnap(dx);
        dy = applySnap(dy);
        for (const n of S.sel) {
          const b = S.slots[n];
          b.x = rnd(d.orig[n].x + dx);
          b.y = rnd(d.orig[n].y + dy);
        }
        draw();
        updateStatus();
        return;
      }
      if (d.kind === "resize") {
        const wp = screenToWorld(p.x, p.y);
        const o = d.orig;
        let x = o.x, y = o.y, w = o.w, h = o.h;
        const hd = d.hd;
        const sx = applySnap(wp.x);
        const sy = applySnap(wp.y);
        if (hd.includes("e")) w = sx - o.x;
        if (hd.includes("s")) h = sy - o.y;
        if (hd.includes("w")) { w = o.x + o.w - sx; x = sx; }
        if (hd.includes("n")) { h = o.y + o.h - sy; y = sy; }
        if (w < 1) { w = 1; if (hd.includes("w")) x = o.x + o.w - 1; }
        if (h < 1) { h = 1; if (hd.includes("n")) y = o.y + o.h - 1; }
        if (e.shiftKey) {
          const ratio = o.w / Math.max(1, o.h);
          const nw = Math.abs(w);
          const nh = nw / ratio;
          if (hd.includes("s")) { h = nh; if (hd.includes("n")) y = o.y + o.h - nh; }
          else if (hd.includes("n")) { h = nh; y = o.y + o.h - nh; }
          else if (hd.includes("e")) { w = nh * ratio; }
          else { w = nh * ratio; }
        }
        const b = S.slots[d.name];
        b.x = rnd(x); b.y = rnd(y); b.w = rnd(Math.abs(w)); b.h = rnd(Math.abs(h));
        draw();
        updateStatus();
      }
    });

    const finishDrag = () => {
      const d = S.drag;
      if (!d) return;
      if (d.kind === "move" || d.kind === "resize") pushUndo();
      if (d.kind === "add") {
        const x0 = Math.min(d.x0, d.x1);
        const y0 = Math.min(d.y0, d.y1);
        const x1 = Math.max(d.x0, d.x1);
        const y1 = Math.max(d.y0, d.y1);
        S.drag = null;
        const w = (x1 - x0) / S.zoom;
        const h = (y1 - y0) / S.zoom;
        if (w > 3 && h > 3) {
          const wd = screenToWorld(x0, y0);
          const name = nextSlotId();
          S.slots[name] = { x: rnd(wd.x), y: rnd(wd.y), w: rnd(w), h: rnd(h) };
          S.names.push(name);
          S.sel = [name];
          pushUndo();
        }
        draw();
        renderList();
        return;
      }
      S.drag = null;
      S.host.classList.remove("grabbing");
      if (d.kind === "pan") draw();
      renderList();
    };

    c.addEventListener("pointerup", (e) => {
      finishDrag();
      if (S.marquee) applyMarquee();
    });
    c.addEventListener("pointercancel", (e) => {
      finishDrag();
      S.marquee = null;
      draw();
    });

    c.addEventListener("dblclick", (e) => {
      const p = pos(e);
      const hit = hitSlot(p.x, p.y);
      if (hit) {
        S.sel = [hit];
        draw();
        renderList();
        floatRename(hit, p.x, p.y);
      }
    });
  };

  const updateStatus = () => {
    const st = $("pteStatus");
    if (!st) return;
    const parts = [];
    if (S.drag && S.drag.kind === "move" && S.sel.length === 1) {
      const b = slotRect(S.sel[0]);
      parts.push(`X <b>${rnd(b.x)}</b>  Y <b>${rnd(b.y)}</b>  W <b>${rnd(b.w)}</b>  H <b>${rnd(b.h)}</b>`);
    } else if (S.sel.length) {
      let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
      S.sel.forEach((n) => {
        const b = slotRect(n);
        minX = Math.min(minX, b.x); minY = Math.min(minY, b.y);
        maxX = Math.max(maxX, b.x + b.w); maxY = Math.max(maxY, b.y + b.h);
      });
      parts.push(`Selection: <b>${S.sel.length}</b> slot(s) · X <b>${rnd(minX)}</b> Y <b>${rnd(minY)}</b> W <b>${rnd(maxX - minX)}</b> H <b>${rnd(maxY - minY)}</b>`);
    } else {
      parts.push(`Canvas <b>${S.cw}×${S.ch}</b>`);
    }
    parts.push(`Mouse: ${Math.round(S.mouse.x)}, ${Math.round(S.mouse.y)}`);
    parts.push(`Zoom <b>${Math.round(S.zoom * 100)}%</b>`);
    st.innerHTML = parts.join(" &nbsp;·&nbsp; ");
  };

  /* ------------------------------ toolbar / modal ------------------------------ */

  const buildModal = () => {
    const root = document.createElement("div");
    root.className = "pte-root";
    root.innerHTML = `
      <div class="pte-dialog" role="dialog" aria-modal="true">
        <div class="pte-head">
          <span class="pte-title">Advanced Edit Mode — <span id="pteTitle">${esc(S.template.template_id || "template")}</span></span>
          <span class="pte-dirty" id="pteDirtyTag" hidden>unsaved changes</span>
          <button class="pte-x" id="pteClose" title="Close (discard changes)">✕</button>
        </div>
        <div class="pte-body">
          <div class="pte-tools">
            <button class="pte-tbtn on" id="pteToolSelect" title="Select / move (V)">◈ Select <span class="kbd">V</span></button>
            <button class="pte-tbtn" id="pteToolAdd" title="Draw new slot (R)">▣ Add slot <span class="kbd">R</span></button>
            <button class="pte-tbtn" id="pteToolHand" title="Pan canvas (H, or drag with middle mouse)">✋ Pan <span class="kbd">H</span></button>
            <span class="sep"></span>
            <button class="pte-tbtn on" id="pteSnap" title="Snap to ${S.snapStep}px grid">Snap</button>
            <button class="pte-tbtn on" id="pteGrid" title="Show grid">Grid</button>
            <span class="sep"></span>
            <button class="pte-tbtn" id="pteZoomOut">−</button>
            <button class="pte-tbtn" id="pteZoomPct">100%</button>
            <button class="pte-tbtn" id="pteZoomIn">+</button>
            <button class="pte-tbtn" id="pteZoomFit">Fit</button>
            <span class="sep"></span>
            <button class="pte-tbtn" id="pteUndo" title="Undo (Ctrl+Z)">↩ Undo</button>
            <button class="pte-tbtn" id="pteRedo" title="Redo (Ctrl+Shift+Z)">↪ Redo</button>
          </div>
          <div class="pte-rows" id="pteRows" style="display:none"></div>
          <div class="pte-main">
            <div class="pte-canvas-host" id="pteHost"><canvas id="pteCanvas"></canvas></div>
            <div class="pte-side">
              <div class="pte-side-head"><span>Slots</span><span id="pteCount">0</span></div>
              <div class="pte-hint">Drag to reorder · dbl-click name to rename · Del removes</div>
              <div class="pte-list" id="pteList"></div>
            </div>
          </div>
          <div class="pte-status" id="pteStatus"></div>
        </div>
        <div class="pte-foot">
          <div class="pte-actions">
            <button class="pte-tbtn" data-align="left" title="Align left">⇤ L</button>
            <button class="pte-tbtn" data-align="hcenter" title="Align horizontal center">⇹ C</button>
            <button class="pte-tbtn" data-align="right" title="Align right">⇥ R</button>
            <button class="pte-tbtn" data-align="top" title="Align top">⇧ T</button>
            <button class="pte-tbtn" data-align="vcenter" title="Align vertical center">⇕ M</button>
            <button class="pte-tbtn" data-align="bottom" title="Align bottom">⇩ B</button>
            <span class="sep"></span>
            <button class="pte-tbtn" data-dist="h" title="Distribute horizontally">⇆ H</button>
            <button class="pte-tbtn" data-dist="v" title="Distribute vertically">⇅ V</button>
            <span class="sep"></span>
            <button class="pte-tbtn" id="pteMirror" title="Create mirrored copies across canvas center">⧉ Mirror row…</button>
            <button class="pte-tbtn" id="pteDup" title="Duplicate selection (Ctrl+D)">⧉ Duplicate</button>
            <button class="pte-tbtn" id="pteDel" title="Delete selection (Del)">🗑 Delete</button>
          </div>
          <div class="pte-foot-right">
            <button class="pte-tbtn" id="pteCancel" title="Close without saving">Close</button>
            <button class="pte-tbtn primary" id="pteSave" title="Save template and refresh live preview">Save &amp; Close</button>
          </div>
        </div>
      </div>`;
    document.body.appendChild(root);
    S.modal = root;
    S.host = $("pteHost");
    S.canvas = $("pteCanvas");
    S.ctx = S.canvas.getContext("2d");

    $("pteClose").addEventListener("click", requestClose);
    $("pteCancel").addEventListener("click", requestClose);
    $("pteSave").addEventListener("click", saveAndClose);

    const tbtn = (id, on, fn) => {
      const el = $(id);
      if (!el) return;
      el.classList.toggle("on", !!on);
      el.addEventListener("click", fn);
    };
    tbtn("pteToolSelect", S.tool === "select", () => setTool("select"));
    tbtn("pteToolAdd", S.tool === "add", () => setTool("add"));
    tbtn("pteToolHand", S.tool === "hand", () => setTool("hand"));
    tbtn("pteSnap", S.snap, () => { S.snap = !S.snap; $("pteSnap").classList.toggle("on", S.snap); draw(); });
    tbtn("pteGrid", S.grid, () => { S.grid = !S.grid; $("pteGrid").classList.toggle("on", S.grid); draw(); });
    $("pteZoomOut").addEventListener("click", () => zoomAt(0.8));
    $("pteZoomIn").addEventListener("click", () => zoomAt(1.25));
    renderRowsPanel();
    $("pteZoomFit").addEventListener("click", () => { fitView(); draw(); updateStatus(); });
    $("pteUndo").addEventListener("click", undo);
    $("pteRedo").addEventListener("click", redo);
    $("pteMirror").addEventListener("click", mirrorRow);
    $("pteDup").addEventListener("click", () => duplicateSlots(S.sel, 16, 16));
    $("pteDel").addEventListener("click", () => { if (S.sel.length && confirmPTE(`Delete ${S.sel.length} slot(s)?`)) deleteSlots(S.sel); });
    document.querySelectorAll("[data-align]").forEach((b) => b.addEventListener("click", () => alignSel(b.dataset.align)));
    document.querySelectorAll("[data-dist]").forEach((b) => b.addEventListener("click", () => distributeSel(b.dataset.dist)));

    bindCanvas();
    bindList();

    window.addEventListener("resize", onWindowResize);
    document.addEventListener("keydown", onKeyDown);
    document.body.style.overflow = "hidden";
    resizeCanvas();
    fitView();
    renderList();
    syncUndoBtns();
    draw();
    updateStatus();
  };

  const setTool = (t) => {
    S.tool = t;
    $("pteToolSelect").classList.toggle("on", t === "select");
    $("pteToolAdd").classList.toggle("on", t === "add");
    $("pteToolHand").classList.toggle("on", t === "hand");
    S.host.classList.toggle("pan", t === "hand");
  };

  const zoomAt = (factor) => {
    const w = S.host.clientWidth || 800;
    const h = S.host.clientHeight || 500;
    const cx = w / 2;
    const cy = h / 2;
    const wp = screenToWorld(cx, cy);
    S.zoom = clamp(S.zoom * factor, 0.02, 40);
    S.ox = cx - wp.x * S.zoom;
    S.oy = cy - wp.y * S.zoom;
    draw();
    updateStatus();
  };

  const onWindowResize = () => {
    if (!S.open) return;
    resizeCanvas();
    draw();
  };

  const onKeyDown = (e) => {
    if (!S.open) return;
    const t = e.target;
    if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.isContentEditable)) return;
    const mod = e.ctrlKey || e.metaKey;
    if (mod && (e.key === "z" || e.key === "Z")) { e.preventDefault(); if (e.shiftKey) redo(); else undo(); return; }
    if (mod && (e.key === "y" || e.key === "Y")) { e.preventDefault(); redo(); return; }
    if (mod && (e.key === "d" || e.key === "D")) { e.preventDefault(); duplicateSlots(S.sel, 16, 16); return; }
    if (e.key === "Delete" || e.key === "Backspace") { if (S.sel.length) { e.preventDefault(); deleteSlots(S.sel); } return; }
    if (e.key === "Escape") { S.drag = null; S.marquee = null; draw(); return; }
    if (e.key === "v" || e.key === "V") { setTool("select"); return; }
    if (e.key === "r" || e.key === "R") { setTool("add"); return; }
    if (e.key === "h" || e.key === "H") { setTool("hand"); return; }
    if (e.key.startsWith("Arrow")) {
      e.preventDefault();
      const dx = e.key === "ArrowLeft" ? -1 : e.key === "ArrowRight" ? 1 : 0;
      const dy = e.key === "ArrowUp" ? -1 : e.key === "ArrowDown" ? 1 : 0;
      const m = e.shiftKey ? 10 : 1;
      nudge(S.sel, dx * m, dy * m);
    }
  };

  /* ------------------------------ marquee selection ------------------------------ */

  const applyMarquee = () => {
    if (!S.marquee) return;
    const m = S.marquee;
    const x0 = Math.min(m.x0, m.x1);
    const y0 = Math.min(m.y0, m.y1);
    const x1 = Math.max(m.x0, m.x1);
    const y1 = Math.max(m.y0, m.y1);
    const w0 = screenToWorld(x0, y0);
    const w1 = screenToWorld(x1, y1);
    const minX = Math.min(w0.x, w1.x), maxX = Math.max(w0.x, w1.x);
    const minY = Math.min(w0.y, w1.y), maxY = Math.max(w0.y, w1.y);
    S.sel = S.names.filter((n) => {
      if (S.hides[n] || S.locks[n]) return false;
      const b = slotRect(n);
      return b.x >= minX && b.y >= minY && b.x + b.w <= maxX && b.y + b.h <= maxY;
    });
    S.marquee = null;
    draw();
    renderList();
    updateStatus();
  };

  /* ------------------------------ close / save ------------------------------ */

  const requestClose = () => {
    if (S.dirty && !confirmPTE("Discard unsaved changes? Everything you edited will be lost.")) return;
    close();
  };

  const close = () => {
    if (!S.open) return;
    S.open = false;
    window.removeEventListener("resize", onWindowResize);
    document.removeEventListener("keydown", onKeyDown);
    document.body.style.overflow = "";
    if (S.modal && S.modal.isConnected) S.modal.remove();
    S.modal = null;
    S.host = null;
    S.canvas = null;
    S.ctx = null;
    S.drag = null;
    S.marquee = null;
  };

  const saveTargetDialog = (currentPath) => new Promise((resolve) => {
    const app = getApp();
    const overlay = document.createElement("div");
    overlay.className = "overlay";
    overlay.style.zIndex = "10050";
    const curName = currentPath ? String(currentPath).split(/[\\/]/).pop() : "";
    const base = curName ? String(currentPath).slice(0, -5) : (currentPath || "paytable_template");
    const defName = base.split(/[\\/]/).pop() + "_copy";
    overlay.innerHTML = `<div class="table-mapper-dialog" style="width:min(560px,92vw);max-height:unset;height:auto">
      <div class="panel-header" style="margin-bottom:14px"><span class="panel-title">Save paytable template</span></div>
      <p class="tm-label" style="margin:0 0 16px">${
        curName
          ? `Edited slot layout for <b>${esc(curName)}</b> (currently shown in the live preview).<br>Overwrite that template, or save the edits as a new template?`
          : "Save the edited template as a new file?"
      }</p>
      <label class="tm-label" style="margin:0 0 6px">New template name</label>
      <input type="text" id="pteSaveNewName" class="tm-path" value="${esc(defName)}" placeholder="my_paytable_copy" />
      <div class="tm-footer" style="flex-wrap:wrap;gap:10px;margin-top:14px">
        ${curName ? `<button class="btn btn-primary tm-done-btn" id="pteSaveOverwrite" style="flex:1;white-space:nowrap">Overwrite ${esc(curName)}</button>` : ""}
        <button class="btn tm-done-btn" id="pteSaveAsNew" style="flex:1;white-space:nowrap">Save as new</button>
        <button class="btn ghost" id="pteSaveCancel">Cancel</button>
      </div>
    </div>`;
    document.body.appendChild(overlay);
    const done = (result) => {
      if (!overlay.isConnected) return;
      overlay.remove();
      resolve(result);
    };
    // a click outside never closes it (what was typed in it would be lost): its ✕ or Cancel do
    document.getElementById("pteSaveCancel").addEventListener("click", () => done(null));
    const nameInput = document.getElementById("pteSaveNewName");
    const nameValue = () => nameInput.value.trim();
    if (currentPath) {
      document.getElementById("pteSaveOverwrite").addEventListener("click", () => done({ mode: "overwrite", path: currentPath }));
    }
    document.getElementById("pteSaveAsNew").addEventListener("click", async () => {
      const rawName = nameValue() || "paytable_copy";
      const native = window.pywebview?.api;
      if (native && typeof native.save_file === "function") {
        try {
          const path = await native.save_file("Save paytable template", rawName + ".json");
          const base = path ? String(path).split(/[\\/]/).pop().replace(/\.json$/i, "").trim() : "";
          if (base) { done({ mode: "new", path, name: base }); return; }
          done({ mode: "new", path: "", name: rawName });
        } catch (err) {
          toastPTE("Native save dialog failed (" + err.message + ") — saving to the default folder instead.", "err");
          done({ mode: "new", path: "", name: rawName });
        }
      } else {
        done({ mode: "new", path: "", name: rawName });
      }
    });
    nameInput.focus();
    nameInput.select();
  });

  const saveAndClose = async () => {
    const app = getApp();
    const pm = app?.paytableMapper;
    if (!pm || !pm.template) { toastPTE("Mapper state lost — reopen the paytable view and retry.", "err"); return; }
    const saveBtn = $("pteSave");
    if (saveBtn) { saveBtn.disabled = true; saveBtn.textContent = "Saving…"; }
    try {
      const template = deep(pm.template);
      template.slots = deep(S.slots);
      template.mapper_meta = template.mapper_meta || {};
      if (S.rows && S.rows.length) {
        template.mapper_meta.row_counts = {
          top: S.rows[0].count || 0,
          bottom: (S.rows[1] || { count: 0 }).count || 0,
        };
      } else {
        template.mapper_meta.row_counts = {};
      }
      const mappings = Object.values(pm.mappings || {}).filter((m) => m && m.slot);
      for (const m of mappings) m.slot = resolveRename(m.slot);
      const src = String(pm.mappedPath || app?.get?.("dynamic_settings.template_json") || "").trim();
      const currentPath = src.toLowerCase().endsWith(".json") ? src : "";
      const choice = await saveTargetDialog(currentPath);
      if (!choice) {
        if (saveBtn) { saveBtn.disabled = false; saveBtn.textContent = "Save & Close"; }
        return;
      }
      const newName = choice.mode === "new" ? String(choice.name || "paytable_copy").trim() : "";
      if (newName) template.template_id = newName;
      const body = {
        psd_path: pm.psdPath || "",
        sheet_name: pm.sheetName || "",
        template_id: newName || pm.tableName || template.template_id || "paytable",
        template,
        mappings,
        slot_prefix: template.slot_prefix || "@slot",
        annotations: app?._ptBlueprint !== false,
      };
      if (choice.mode === "overwrite") {
        body.output_path = choice.path;
      } else {
        body.template_dir = true;
      }
      const res = await fetch("/api/paytable_mapper/save", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const d = await res.json();
      if (!d.ok) { toastPTE(d.error || "Save failed.", "err"); return; }
      const savedPath = d.path || body.output_path;
      pm.template = template;
      if (Object.keys(S.renames).length) {
        for (const oldN of Object.keys(S.renames)) {
          const newN = resolveRename(oldN);
          if (oldN !== newN && pm.mappings[oldN]) {
            pm.mappings[newN] = pm.mappings[oldN];
            delete pm.mappings[oldN];
          }
        }
      }
      const savedBase = String(savedPath).split(/[\\/]/).pop().replace(/\.json$/i, "");
      pm.mappedPath = savedPath;
      pm.tableName = savedBase || "paytable";
      App.state.ptmUserPicked = true;
      pm.previewToken = d.preview_token || pm.previewToken;
      if (d.preview_token) app.state.paytablePreviewToken = d.preview_token;
      if (d.config) { app.state.config = d.config; }
      app?.set?.("dynamic_settings.template_json", savedPath);
      app?.pushConfig?.();
      // Reload + auto-map the saved template against the current Excel sheet
      // so every paytable renders its own true data (never another sheet's).
      try {
        const excelPath = (app?.state?.config?.excel_path || app?.get?.("excel_path") || "").trim();
        const sheet = document.getElementById("ptmSheet")?.value || pm.sheetName || "";
        if (excelPath && sheet) {
          const amRes = await fetch("/api/paytable_mapper/automap", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ template, excel_path: excelPath, sheet_name: sheet }),
          });
          const am = await amRes.json();
          if (am && am.ok) {
            if (app?.ptmApplyAutomap) {
              const dims = am.sheet_dims?.rows ? am.sheet_dims : undefined;
              app.ptmApplyAutomap(am, pm.mappings, dims);
            } else {
              (am.mappings || []).forEach((m) => { if (m && m.slot) pm.mappings[m.slot] = m; });
            }
            if (app?.ptmFillDefaults) app.ptmFillDefaults(pm.mappings);
          }
        }
      } catch (e) { console.warn("[PTEditor] automap after save failed", e); }
      app?.ptAdoptPreview?.();
      app?.ptmRenderPreviewOverlay?.();
      app?.ptmRenderPanel?.();
      if (app?.ptmLiveRender) app.ptmLiveRender();
      const savedName = String(savedPath).split(/[\\/]/).pop();
      S.dirty = false;
      close();
      app?.ptmRefreshTemplateList?.();
      const rr = window.renderRoute || (app && app.renderRoute);
      if (typeof rr === "function") { try { rr(); } catch (e) { /* non-fatal */ } }
      toastPTE(
        choice.mode === "overwrite"
          ? `Overwrote "${savedName}" — loaded and auto-mapped into the live preview.`
          : `Saved as new "${savedName}" — loaded and auto-mapped into the live preview.`,
        "ok"
      );
    } catch (e) {
      toastPTE("Save failed: " + (e && e.message ? e.message : e), "err");
    } finally {
      if (saveBtn) { saveBtn.disabled = false; saveBtn.textContent = "Save & Close"; }
    }
  };

  /* ------------------------------ toasts / prompts ------------------------------ */

  const toastPTE = (msg, kind) => {
    const app = getApp();
    if (app && typeof app.ptmToast === "function") { app.ptmToast(msg, kind); return; }
    if (typeof window.toast === "function") { window.toast(msg, kind); return; }
    alert(msg);
  };

  const promptPTE = (label, def) => {
    const app = getApp();
    if (app && typeof app.ptmPrompt === "function") return app.ptmPrompt(label, def);
    return prompt(label, def);
  };

  const confirmPTE = (msg) => {
    const app = getApp();
    if (app && typeof app.ptmConfirm === "function") return app.ptmConfirm(msg);
    return confirm(msg);
  };

  /* ------------------------------ public API ------------------------------ */

  const loadMapperState = async () => {
    const app = getApp();
    let pm = app?.paytableMapper;
    if (pm && pm.template && Object.keys(pm.template.slots || {}).length) return { pm, reason: "" };
    const path = app?.get?.("dynamic_settings.template_json");
    const cfgPath = (typeof path === "string" ? path : "").trim();
    try {
      const res = await fetch("/api/paytable_mapper/load", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(cfgPath ? { path: cfgPath } : {}),
      });
      const d = await res.json();
      if (!d.ok || !d.template || !Object.keys(d.template.slots || {}).length) {
        console.warn("[PTEditor] load failed", d);
        return { pm: null, reason: (d && d.error) || "load returned no template" };
      }
      const mappings = {};
      Object.entries(d.mappings || {}).forEach(([s, m]) => { if (m && typeof m === "object") mappings[s] = m; });
      pm = {
        psdPath: d.template.source_psd || "",
        template: d.template,
        mappings,
        sheetName: d.sheet_name || "",
        tableName: d.template_id || d.template.template_id || "paytable",
        mappedPath: cfgPath || d.path || "",
        previewToken: d.preview_token || "",
        selected: "",
      };
      if (app) {
        app.paytableMapper = pm;
        app.state.paytablePreviewToken = d.preview_token || app.state.paytablePreviewToken || "";
      }
      return { pm, reason: "" };
    } catch (e) {
      console.warn("[PTEditor] load exception", e);
      return { pm: null, reason: String((e && e.message) || e) };
    }
  };

  const open = async () => {
    if (S.open) return;
    const { pm, reason } = await loadMapperState();
    if (!pm) {
      toastPTE("No paytable template loaded — open the Paytable Mapper and load a layout first." + (reason ? ` (${reason})` : ""), "err");
      return;
    }
    const tpl = pm.template;
    S.template = tpl;
    S.scaleText = false;
    S.slots = deep(tpl.slots || {});
    S.names = Object.keys(S.slots);
    sortLayers();
    S.rows = detectRows();
    S.cw = tpl.canvas?.width || 3840;
    S.ch = tpl.canvas?.height || 2160;
    S.sel = [];
    S.locks = {};
    S.hides = {};
    S.undo = [];
    S.redo = [];
    S.dirty = false;
    S.renames = {};
    S.drag = null;
    S.marquee = null;
    S.tool = "select";
    S.lastId = 0;
    let max = 0;
    S.names.forEach((n) => {
      const m = /^slot\.(\d+)(\.|$)/.exec(n);
      if (m) max = Math.max(max, parseInt(m[1], 10) || 0);
    });
    S.lastId = max;
    if (!styleInjected) {
      const st = document.createElement("style");
      st.textContent = CSS;
      document.head.appendChild(st);
      styleInjected = true;
    }
    buildModal();
    S.open = true;
  };

  window.PTEditor = { open };
})();
