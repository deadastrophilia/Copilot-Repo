/* Symbol mapping + pre-build symbol check.

   SymMap.open({onDone}) — link every symbol the game's Excel uses (<WILD>,
   <PIC1>…) to a picture in the symbols folder. Files are never renamed: the
   links are saved per game as icon_mappings and every build uses them.
   One picture may serve several symbols; a symbol has only one picture, so
   giving it to another picture asks first.

   App.startBuild is wrapped: before any build the Excel's symbols are checked
   (/api/symbols/check). A missing/empty/unreadable folder blocks with a choice
   of Select Symbols Folder / Import Symbols From PSD; unlinked symbols get a
   separate prompt (Map symbols / Build anyway). Never falls back to another
   game's folder. Uses app.js globals (App, api, esc, toast). */
(() => {
  "use strict";
  const SymMap = (window.SymMap = {});
  const M = { ov: null, data: null, links: {}, auto: new Set(), onDone: null, dirty: false };

  const thumb = (folder, name) => `/api/icon_file?folder=${encodeURIComponent(folder)}&name=${encodeURIComponent(name)}`;
  const tag = (t) => `&lt;${esc(t)}&gt;`;

  function filesFor(file) {
    return Object.keys(M.links).filter((t) => (M.links[t] || "").toLowerCase() === file.toLowerCase());
  }

  SymMap.open = async (opts = {}) => {
    M.onDone = opts.onDone || null;
    let d;
    try {
      d = await api("/api/symbols/mapping");
    } catch (e) {
      toast(e.message || "Could not read the symbols.", "err");
      return;
    }
    M.data = d;
    M.links = {};
    M.auto = new Set();
    for (const r of d.tokens || []) {
      M.links[r.token] = r.file || "";
      if (r.via === "suggested") M.auto.add(r.token);       // likely match, applied for review
    }
    M.dirty = M.auto.size > 0;
    if (!M.ov) {
      M.ov = document.createElement("div");
      M.ov.className = "gm-overlay";
      M.ov.style.zIndex = "10080";
      M.ov.addEventListener("click", (e) => { if (e.target === M.ov) SymMap.close(); });
      document.body.appendChild(M.ov);
    }
    M.ov.hidden = false;
    render();
  };

  SymMap.close = async (saved) => {
    if (!M.ov) return;
    if (!saved && M.dirty) {
      const go = await App.choose("Leave without saving?", "Your symbol links haven't been saved.",
        [{ label: "Keep editing", value: false }, { label: "Discard", value: true, primary: true }]);
      if (!go) return;
    }
    M.ov.hidden = true;
    const cb = M.onDone;
    M.onDone = null;
    if (cb) cb(!!saved);
  };

  function render() {
    const d = M.data;
    const tokens = (d.tokens || []).map((r) => r.token);
    const files = d.files || [];
    const unmapped = tokens.filter((t) => !M.links[t]);
    const unused = files.filter((f) => !filesFor(f).length);
    const fresh = new Set(d.new_tokens || []);
    let body;
    if (!d.folder_exists) {
      body = `<div class="smap-empty">No symbols folder is set for this game${d.icon_folder ? ` (<code>${esc(d.icon_folder)}</code> doesn't exist)` : ""}.
        Choose one or import the symbols from a PSD first.</div>`;
    } else if (!tokens.length) {
      body = `<div class="smap-empty">This game's Excel doesn't use any symbols.</div>`;
    } else {
      const opts = (cur) => `<option value="">+ link a symbol…</option>` + tokens.map((t) => {
        const on = M.links[t];
        if (on && on.toLowerCase() === cur.toLowerCase()) return "";
        return `<option value="${esc(t)}">&lt;${esc(t)}&gt;${on ? `  (now ${esc(on)})` : "  — not linked"}${fresh.has(t) ? "  • new" : ""}</option>`;
      }).join("");
      const rows = files.map((f) => {
        const mine = filesFor(f);
        return `<div class="smap-row${mine.length ? "" : " unused"}">
          <img class="smap-thumb" loading="lazy" src="${thumb(d.icon_folder, f)}" alt="">
          <div class="smap-file"><div class="smap-name" title="${esc(f)}">${esc(f)}</div>
            <div class="smap-chips">${mine.map((t) => `<span class="chip smap-chip${M.auto.has(t) ? " auto" : ""}" title="${M.auto.has(t) ? "Matched by name — check it" : ""}">${tag(t)}<button data-unlink="${esc(t)}" title="Unlink">✕</button></span>`).join("")
              || `<span class="smap-none">not used by the Excel</span>`}</div></div>
          <select class="smap-add" data-file="${esc(f)}">${opts(f)}</select>
        </div>`;
      }).join("");
      const missing = unmapped.length ? `<div class="smap-missing"><b>${unmapped.length} symbol${unmapped.length === 1 ? "" : "s"} without a picture</b> — these will be left out of the PSD:
          <div class="smap-miss-list">${unmapped.map((t) => `<label class="smap-miss">${tag(t)}${fresh.has(t) ? `<span class="smap-new">new</span>` : ""}
            <select data-token="${esc(t)}"><option value="">choose picture…</option>${files.map((f) => `<option>${esc(f)}</option>`).join("")}</select></label>`).join("")}</div></div>` : "";
      body = missing + `<div class="smap-list">${rows}</div>`;
    }
    const linked = tokens.length - unmapped.length;
    M.ov.innerHTML = `<div class="gm-dialog smap">
      <div class="gm-dhead"><b>Match symbols to the Excel</b><button class="gm-x" data-act="close">✕</button></div>
      <div class="gm-dbody">
        <div class="smap-sum">${tokens.length ? `<span class="${unmapped.length ? "warn" : "ok"}">${linked} of ${tokens.length} Excel symbols linked</span>` : ""}
          ${unused.length ? `<span>${unused.length} picture${unused.length === 1 ? "" : "s"} not used</span>` : ""}
          ${fresh.size ? `<span class="warn">${fresh.size} new in the Excel</span>` : ""}
          ${M.auto.size ? `<span>${M.auto.size} matched by name — check the yellow ones</span>` : ""}</div>
        <div class="hint">Files keep their names. A picture can be used for several symbols.${d.icon_folder ? ` Folder: <code>${esc(d.icon_folder)}</code>` : ""}</div>
        ${body}
      </div>
      <div class="gm-dfoot">
        ${!d.folder_exists ? `<button class="btn secondary" data-act="folder">Select Symbols Folder</button><button class="btn secondary" data-act="psd">Import Symbols From PSD</button>` : ""}
        <span style="flex:1"></span>
        <button class="btn secondary" data-act="close">Cancel</button>
        <button class="btn primary" data-act="save" ${d.folder_exists && tokens.length ? "" : "disabled"}>Save links</button>
      </div></div>`;
    wire();
  }

  async function link(token, file) {
    const cur = M.links[token];
    if (cur && file && cur.toLowerCase() !== file.toLowerCase() && !M.auto.has(token)) {
      const ok = await App.choose("Symbol already linked",
        `${tag(token)} uses <b>${esc(cur)}</b>. Use <b>${esc(file)}</b> for it instead?`,
        [{ label: "Cancel", value: false }, { label: "Move it", value: true, primary: true }]);
      if (!ok) { render(); return; }
    }
    M.links[token] = file || "";
    M.auto.delete(token);
    M.dirty = true;
    render();
  }

  function wire() {
    M.ov.querySelectorAll("[data-act]").forEach((b) => b.addEventListener("click", () => {
      const a = b.dataset.act;
      if (a === "close") SymMap.close(false);
      else if (a === "save") save();
      else if (a === "folder") { M.ov.hidden = true; App.symbolsSelectFolder(() => SymMap.open({ onDone: M.onDone })); }
      else if (a === "psd") { M.ov.hidden = true; const X = window.SymAgr || window.SymExport; if (X) X.open({ onSaved: M.onDone }); }
    }));
    M.ov.querySelectorAll("select.smap-add").forEach((s) => s.addEventListener("change", () => {
      if (s.value) link(s.value, s.dataset.file);
    }));
    M.ov.querySelectorAll("select[data-token]").forEach((s) => s.addEventListener("change", () => {
      if (s.value) link(s.dataset.token, s.value);
    }));
    M.ov.querySelectorAll("[data-unlink]").forEach((b) => b.addEventListener("click", () => {
      M.links[b.dataset.unlink] = "";
      M.auto.delete(b.dataset.unlink);
      M.dirty = true;
      render();
    }));
  }

  async function save() {
    try {
      const tokens = (M.data.tokens || []).map((r) => r.token);
      const d = await api("/api/symbols/mapping", { method: "POST", body: { links: M.links, tokens } });
      if (d.config) App.state.config = d.config;
      M.dirty = false;
      const left = (d.unmapped || []).length;
      toast(left ? `Links saved — ${left} symbol${left === 1 ? "" : "s"} still without a picture.` : "Symbol links saved.", left ? "warn" : undefined);
      SymMap.close(true);
      if (App.scan) App.scan();
    } catch (e) {
      toast(e.message || "Saving failed.", "err");
    }
  }

  /* Browse for a symbols folder, copy it into this game's Working › Symbols
     (asking before overwriting), then call done(). */
  App.symbolsSelectFolder = (done) => {
    App.pickPath("dir", async (folder) => {
      if (!folder) { if (done) done(false); return; }
      try {
        const d = await App.saveSafely("/api/symbols/use_folder", { folder, copy: true });
        if (d.cancelled) { if (done) done(false); return; }
        if (d.config) App.state.config = d.config;
        toast(d.copied ? `Copied ${d.copied} symbols into ${d.icon_folder}.` : `Using ${d.icon_folder}.`);
        if (done) done(true);
      } catch (e) {
        toast(e.message, "err");
        if (done) done(false);
      }
    });
  };

  /* ---------------- pre-build check ---------------- */

  const MISSING = new Set(["no_folder", "empty_folder", "unreadable"]);

  async function check() {
    try {
      return await api("/api/symbols/check", { method: "POST", body: { config: App.state.config } });
    } catch (e) {
      return null;                                  // never block a build on a failed check
    }
  }

  function reason(c) {
    if (c.state === "empty_folder") return `The symbols folder <code>${esc(c.icon_folder)}</code> has no pictures in it.`;
    if (c.state === "unreadable") return `The pictures in <code>${esc(c.icon_folder)}</code> can't be read.`;
    return c.icon_folder ? `The symbols folder <code>${esc(c.icon_folder)}</code> doesn't exist.` : "No symbols folder is set for this game.";
  }

  /* resolves true = go on with the build, false = stop */
  SymMap.guard = async () => {
    for (let round = 0; round < 4; round++) {
      const c = await check();
      if (!c || c.state === "ok") return true;
      if (MISSING.has(c.state)) {
        const pick = await App.choose("Unable to build PSD: Symbols are missing",
          `<div>No usable symbols were found for this game. Please select an existing Symbols folder or provide a PSD containing the symbols so they can be exported before building the help screen.</div>
           <div class="hint" style="margin-top:8px">${reason(c)} The Excel uses ${c.tokens.length} symbol${c.tokens.length === 1 ? "" : "s"}.</div>`,
          [{ label: "Cancel", value: null }, { label: "Import Symbols From PSD", value: "psd" },
           { label: "Select Symbols Folder", value: "folder", primary: true }]);
        if (!pick) return false;
        const ok = await new Promise((resolve) => {
          if (pick === "folder") App.symbolsSelectFolder((done) => done ? SymMap.open({ onDone: () => resolve(true) }) : resolve(false));
          else if (window.SymAgr || window.SymExport) (window.SymAgr || window.SymExport).open({ onSaved: (saved) => resolve(saved !== false), onCancel: () => resolve(false) });
          else resolve(false);
        });
        if (!ok) return false;
        continue;                                    // revalidate
      }
      // unlinked symbols — a separate, softer prompt
      const list = c.unresolved.slice(0, 24).map((t) => `<span class="chip">${tag(t)}</span>`).join("");
      const pick = await App.choose("Some symbols are missing",
        `<div><b>${c.unresolved.length}</b> of the Excel's ${c.tokens.length} symbols have no picture in <code>${esc(c.icon_folder)}</code>.
           Built now, they show as their &lt;name&gt; instead of a picture:</div>
         <div class="sym-need-chips">${list}${c.unresolved.length > 24 ? `<span class="hint">+${c.unresolved.length - 24} more</span>` : ""}</div>
         <div class="hint" style="margin-top:8px"><b>Provide symbols</b>: pick a folder that has these pictures — the tool finds each one and puts it in place.
           <b>Map symbols</b>: link them by hand to pictures already in the folder.</div>`,
        [{ label: "Cancel", value: null }, { label: "Build anyway", value: "build" },
         { label: "Map symbols", value: "map" }, { label: "Provide symbols", value: "provide", primary: true }]);
      if (!pick) return false;
      if (pick === "build") return true;
      if (pick === "provide") {
        const folder = await new Promise((resolve) => App.pickPath("dir", (p) => resolve(p || "")));
        if (!folder) continue;                          // back to the list
        try {
          const r = await api("/api/symbols/provide", { method: "POST", body: { folder } });
          if (r.config) App.state.config = r.config;
          const got = (r.found || []).length, left = (r.missing || []).length;
          toast(got ? `Found ${got} symbol${got === 1 ? "" : "s"}${left ? ` — ${left} still missing` : " — all symbols in place"}.`
                    : "None of the missing symbols are in that folder.", got ? "" : "err");
          if (App.scan) App.scan();
        } catch (e) {
          toast(e.message || "Could not use that folder.", "err");
        }
        continue;                                       // check again: build, or the shorter list
      }
      const saved = await new Promise((resolve) => SymMap.open({ onDone: resolve }));
      if (!saved) return false;
    }
    return true;
  };

  const start = App.startBuild;
  if (typeof start === "function" && !start._symbolGuard) {
    App.startBuild = async function (mode, ...rest) {
      // the preflight dialog re-enters startBuild; the symbols were checked on the first pass
      if (!App._preflightCleared && !App._symbolsCleared) {
        if (!App.state.scan || !App.state.scan.excel) return start.call(this, mode, ...rest);
        if (!(await SymMap.guard())) return;
      }
      App._symbolsCleared = true;
      try {
        return await start.call(this, mode, ...rest);
      } finally {
        App._symbolsCleared = false;
      }
    };
    App.startBuild._symbolGuard = true;
  }
})();
