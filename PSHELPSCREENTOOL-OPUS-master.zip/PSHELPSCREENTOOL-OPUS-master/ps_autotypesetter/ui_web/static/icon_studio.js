/* Icon editing on the live page — in Typography (its top bar switches to Icon) and in Assets & Icons
   (the Typography canvas, AppTypoVis), and on the Visualiser's own canvas.

   Click an icon: a box with corner handles — drag a corner to make it bigger or smaller.
   "Apply to" picks which copies change: only this icon, every copy in this sheet or in the project,
   every icon in this sheet (all grow / shrink together, keeping their proportions), or every icon in
   the project (the heading / body icon heights themselves). Also the gap left / right of icons and
   "Change picture…". Click a <TOKEN> that has no picture: map one from the symbols folder or the PC.

   Sizes are written to dynamic_settings.icon_scales — [sheet] for one sheet, ["*"] for the project
   (icon_scales.py): the server tags the row's text (<WILD~140>) so the builds and this preview size
   every icon the same way. */
window.IconStudio = (() => {
  const S = { sel: null, scope: "projectall", gapLink: null };   // sel: {id, N, key}; gapLink: left = right
  const el = (id) => document.getElementById(id);
  const live = () => window.AppLive && AppLive.state && AppLive.state.data ? AppLive : null;
  const T = () => AppLive.iconTokens;
  // where it works: the Assets & Icons canvas, or the Visualiser's own canvas (the same editing there)
  const V = { vis: false };
  const on = () => !!live() && (V.vis ? App.route === "visualiser-live" : App.route === "assets" || App.route === "typography");
  // "Apply to": which copies a size change reaches — never across heading and body icons: a heading
  // icon's sizes are its own (icon_scales "H:" keys), so sizing one kind leaves the other as it is
  const SCOPES = (name, role) => {
    const kind = role === "heading" ? "heading" : "body";
    return [["one", "Only this icon"], ["sheet", `Every ${kind} ${name} in this sheet`], ["project", `Every ${kind} ${name} in the project`],
            ["sheetall", `Every ${kind} icon in this sheet`], ["projectall", `Every ${kind} icon in the project`]];
  };
  const scope = () => (SCOPES("").some(([v]) => v === S.scope) ? S.scope : (S.scope = "projectall"));
  const isHeading = (e) => e.role === "heading" || e.row === "heading";
  const PRE = (e) => (isHeading(e) ? "H:" : "");
  const sameKind = (k, pre) => (pre ? k.startsWith(pre) : !k.startsWith("H:"));

  function canvas() { return el(V.vis ? "visLiveCanvas" : "typoVisCanvas"); }
  function host() { return el(V.vis ? "visLiveHost" : "typoVisHost"); }
  function scaleK() { const c = canvas(); return c.getBoundingClientRect().width / AppLive.state.data.canvas_w; }
  function sheet() { return (!V.vis && window.AppTypoVis && AppTypoVis.state.sheet) || AppLive.state.data.sheet_name || ""; }

  /* which copy of an icon this is: Excel row + its count among the same token in that row */
  function rowKey(e) {
    if (e.role === "heading" || e.row === "heading") {
      const r = AppLive.state.data.heading && AppLive.state.data.heading.row;
      return r ? "row:" + r : null;
    }
    if (e.cell) return e.cell;                       // a Game / Bingo Rules icon: its Excel cell (icon_scales "WILD@B7#0")
    const r = String(e.row == null ? "" : e.row);
    return /^\d+$/.test(r) ? "row:" + r : null;
  }
  function occurrence(e) {
    const N = T().norm(e.token), rk = rowKey(e), pool = [];
    const pages = AppLive.state.pages || [];
    pages.forEach((pg) => {
      if (e.role === "heading" && pg.elements !== AppLive.state.elements) return;   // a heading repeats per page
      (pg.elements || []).forEach((x) => { if (x.kind === "icon" && rowKey(x) === rk && T().norm(x.token) === N) pool.push(x); });
    });
    return Math.max(0, pool.indexOf(e));
  }
  function keyOf(e) {
    const rk = rowKey(e);
    return rk ? T().norm(e.token) + "@" + rk + "#" + occurrence(e) : null;
  }
  const pctOf = (e) => Math.round(T().scale(e.token) * 100);
  // sizes are shown in px (the icon's height on the page); they are kept as % of the icon height
  const pxOf = (e) => Math.max(1, Math.round(Number(e.h) || 0));
  const pctForPx = (e, px) => pctOf(e) * Math.max(1, Number(px) || 0) / Math.max(1, Number(e.h) || 1);
  const label = (e) => T().untag(e.token);
  function selected() {
    if (!S.sel || !live()) return null;
    const els = AppLive.state.elements || [];
    return els.find((x) => x.id === S.sel.id && x.kind === "icon")
      || els.find((x) => x.kind === "icon" && T().norm(x.token) === S.sel.N && keyOf(x) === S.sel.key) || null;
  }
  function select(e) {
    S.sel = e ? { id: e.id, N: T().norm(e.token), key: keyOf(e) } : null;
    sync();
    panel();
    if (e && !V.vis && App.route === "typography" && window.TypoStudio) TypoStudio.setTarget("icon");   // the top bar edits it
  }
  function deselect() {                              // quietly: the page's own selection takes over
    if (!S.sel) return;
    S.sel = null;
    hideBox();
    hideMenu();
    if (!V.vis && App.route === "typography" && window.TypoStudio && TypoStudio.target === "icon") TypoStudio.paint();
  }

  /* ---------------------------- sizes ---------------------------- */
  async function setScale(e, pct, how) {
    const clamp = (v) => Math.max(10, Math.min(600, Math.round(v)));
    pct = clamp(pct);
    const ds = (App.state.config.dynamic_settings = App.state.config.dynamic_settings || {});
    const all = Object.assign({}, ds.icon_scales || {});
    const proj = Object.assign({}, all["*"] || {});
    const pre = PRE(e), kind = pre ? "heading" : "body";
    const N = pre + T().norm(e.token), f = pct / Math.max(1, pctOf(e) || 100);
    // a token's size on this sheet before any one-icon size: the sheet's, else the project's
    const tokenPct = (t, X) => (t[X] != null ? Number(t[X]) : proj[X] != null ? Number(proj[X]) : 100);
    const name = label(e), px = Math.max(1, Math.round((Number(e.h) || 0) * f));
    let msg;
    if (how === "projectall") {
      // every icon of this kind in the project the size this one is given — not "everything × the same
      // factor": an icon sized on its own before (150 px among 100 px ones) brought back to 100 px leaves
      // the rest at 100 px. This kind's icon height moves to it and the sizes set for single icons /
      // tokens / sheets of this kind go, so every one follows; the other kind is not touched.
      const hk = pre ? "h_icon_h" : "b_icon_h";
      const hh = Math.max(1, Math.min(400, Math.round((Number(App.get(hk)) || (pre ? 40 : 28)) * pct / 100)));
      App.set(hk, hh);
      Object.keys(all).forEach((sh) => {
        const t = Object.assign({}, all[sh]);
        Object.keys(t).forEach((k) => { if (sameKind(k, pre)) delete t[k]; });
        if (Object.keys(t).length) all[sh] = t; else delete all[sh];
      });
      if (Object.keys(all).length) ds.icon_scales = all; else delete ds.icon_scales;
      msg = `Every ${kind} icon in the project at ${px} px (${kind} icons ${hh} px tall) — ${pre ? "body" : "heading"} icons unchanged.`;
    } else {
      if (how === "project") {
        // one size for <N> everywhere: what any sheet said for <N> gives way to it
        Object.keys(all).forEach((sh) => {
          if (sh === "*") return;
          const t = Object.assign({}, all[sh]);
          Object.keys(t).forEach((k) => { if (k === N || k.startsWith(N + "@")) delete t[k]; });
          if (Object.keys(t).length) all[sh] = t; else delete all[sh];
        });
        if (pct === 100) delete proj[N]; else proj[N] = pct;
        msg = `Every ${kind} ${name} in the project at ${px} px.`;
      }
      const mine = Object.assign({}, all[sheet()] || {});
      if (how === "sheet") {
        Object.keys(mine).forEach((k) => { if (k.startsWith(N + "@")) delete mine[k]; });
        if (pct === (proj[N] != null ? Number(proj[N]) : 100)) delete mine[N]; else mine[N] = pct;
        msg = `Every ${kind} ${name} in this sheet at ${px} px.`;
      } else if (how === "sheetall") {
        // every icon of this kind on this sheet the size this one is given — not a factor on what each had:
        // sizes set for single icons of this kind here go, so every one follows
        const tokens = new Set();
        (AppLive.state.pages || []).forEach((pg) => (pg.elements || []).forEach((x) => {
          if (x.kind === "icon" && isHeading(x) === !!pre) tokens.add(pre + T().norm(x.token));
        }));
        Object.keys(mine).forEach((k) => { if (k.includes("@") && sameKind(k, pre)) delete mine[k]; });
        tokens.forEach((X) => {
          if (pct === (proj[X] != null ? Number(proj[X]) : 100)) delete mine[X]; else mine[X] = pct;
        });
        msg = `Every ${kind} icon in this sheet at ${px} px.`;
      } else if (how !== "project") {
        const key = keyOf(e);
        if (!key) return;
        if (pct === tokenPct(mine, N)) delete mine[pre + key]; else mine[pre + key] = pct;
        msg = `This ${name} at ${px} px.`;
      }
      if (Object.keys(mine).length) all[sheet()] = mine; else delete all[sheet()];
      if (Object.keys(proj).length) all["*"] = proj; else delete all["*"];
      ds.icon_scales = all;
    }
    S.sel = { id: e.id, N: T().norm(e.token), key: keyOf(e) };
    await save();
    toast(msg);
  }
  /* the gaps beside icons, for the copies in Apply to (icon_scales: dynamic_settings.icon_gaps, the same
     keys as sizes, [left, right] px): this icon, every copy of it in this sheet / the project, every icon of
     its kind in this sheet — or every icon of its kind in the project (the Icon spacing settings, the
     single gaps of that kind give way). lr null: back to the text's gaps */
  async function setIconGap(e, lr, how) {
    const ds = (App.state.config.dynamic_settings = App.state.config.dynamic_settings || {});
    const all = JSON.parse(JSON.stringify(ds.icon_gaps || {}));
    const pre = PRE(e), N = pre + T().norm(e.token), kind = pre ? "heading" : "body", name = label(e);
    const v = lr && lr.map((x) => Math.max(0, Math.min(400, Math.round(Number(x) || 0))));
    const tidy = () => { Object.keys(all).forEach((sh) => { if (!Object.keys(all[sh]).length) delete all[sh]; }); };
    const dropKind = (t, test) => Object.keys(t || {}).forEach((k) => { if (test(k)) delete t[k]; });
    let msg;
    if (how === "projectall") {
      Object.values(all).forEach((t) => dropKind(t, (k) => sameKind(k, pre)));
      if (v) {
        App.set(pre ? "heading_icon_gap_left" : "icon_gap_left", v[0]);
        App.set(pre ? "heading_icon_gap_right" : "icon_gap_right", v[1]);
      }
      msg = v ? `Every ${kind} icon in the project: ${v[0]} px left, ${v[1]} px right.` : `Every ${kind} icon: the text's gaps.`;
    } else if (how === "project") {
      Object.values(all).forEach((t) => dropKind(t, (k) => k === N || k.startsWith(N + "@")));
      all["*"] = all["*"] || {};
      if (v) all["*"][N] = v;
      msg = v ? `Every ${kind} ${name} in the project: ${v[0]} / ${v[1]} px.` : `Every ${kind} ${name}: the text's gaps.`;
    } else {
      const mine = (all[sheet()] = all[sheet()] || {});
      if (how === "sheet") {
        dropKind(mine, (k) => k === N || k.startsWith(N + "@"));
        if (v) mine[N] = v;
        msg = v ? `Every ${kind} ${name} in this sheet: ${v[0]} / ${v[1]} px.` : `Every ${kind} ${name} in this sheet: the text's gaps.`;
      } else if (how === "sheetall") {
        const tokens = new Set();
        (AppLive.state.pages || []).forEach((pg) => (pg.elements || []).forEach((x) => {
          if (x.kind === "icon" && isHeading(x) === !!pre) tokens.add(pre + T().norm(x.token));
        }));
        dropKind(mine, (k) => k.includes("@") && sameKind(k, pre));
        tokens.forEach((X) => { if (v) mine[X] = v; else delete mine[X]; });
        msg = v ? `Every ${kind} icon in this sheet: ${v[0]} / ${v[1]} px.` : `Every ${kind} icon in this sheet: the text's gaps.`;
      } else {
        const key = keyOf(e);
        if (!key) return;
        if (v) mine[pre + key] = v; else delete mine[pre + key];
        msg = v ? `This ${name}: ${v[0]} px left, ${v[1]} px right.` : `This ${name}: the text's gaps.`;
      }
    }
    tidy();
    if (Object.keys(all).length) ds.icon_gaps = all; else delete ds.icon_gaps;
    S.sel = { id: e.id, N: T().norm(e.token), key: keyOf(e) };
    await save();
    toast(msg);
  }
  async function save() {
    App.refreshUI();
    if (App.flushConfig) await App.flushConfig();
    if (V.vis) await AppLive.refreshData(true);
    else if (window.AppTypoVis && AppTypoVis.refreshPreview.now) await AppTypoVis.refreshPreview.now(true);
    V.rect = "";
    sync();
    panel();
    if (!V.vis && App.route === "typography" && window.TypoStudio && TypoStudio.target === "icon") TypoStudio.paint();   // its size there too
  }

  /* ------------------------ the selection box ------------------------ */
  function hideBox() { document.querySelectorAll(".ics-box").forEach((n) => n.remove()); }
  function sync() {
    hideBox();
    if (!on()) return;
    const e = selected(), h = host(), c = canvas();
    if (!e || !h || !c) return;
    const k = scaleK(), cr = c.getBoundingClientRect(), hr = h.getBoundingClientRect();
    const ov = e.ov || {};
    const x = e.base.x + (Number(ov.x) || 0), y = e.base.y;
    const box = document.createElement("div");
    box.className = "ics-box";
    Object.assign(box.style, { left: (cr.left - hr.left + x * k) + "px", top: (cr.top - hr.top + y * k) + "px", width: (e.w * k) + "px", height: (e.h * k) + "px" });
    box.innerHTML = `<span class="ics-tag">${esc(label(e))} · ${pxOf(e)} px</span>`
      + ["tl", "tr", "bl", "br"].map((cn) => `<div class="ics-h ${cn}" data-c="${cn}" title="Drag: bigger / smaller"></div>`).join("");
    ["mousedown", "click", "dblclick"].forEach((t) => box.addEventListener(t, (ev) => ev.stopPropagation()));    box.addEventListener("contextmenu", (ev) => { ev.preventDefault(); ev.stopPropagation(); menu(ev, e); });
    box.querySelectorAll(".ics-h").forEach((hd) => hd.addEventListener("pointerdown", (ev) => drag(ev, hd, box, e)));
    h.appendChild(box);
  }
  function drag(ev, hd, box, e) {
    if (ev.button !== 0) return;
    ev.preventDefault(); ev.stopPropagation();
    try { hd.setPointerCapture(ev.pointerId); } catch (_) { /* synthetic */ }
    const c = hd.dataset.c, sx = c.includes("l") ? -1 : 1, sy = c.includes("t") ? -1 : 1;
    const b0 = { l: parseFloat(box.style.left), t: parseFloat(box.style.top), w: parseFloat(box.style.width), h: parseFloat(box.style.height) };
    const D = { x: ev.clientX, y: ev.clientY, f: 1 };
    const tag = box.querySelector(".ics-tag"), pct0 = pctOf(e);
    const move = (mv) => {
      const dx = (mv.clientX - D.x) * sx, dy = (mv.clientY - D.y) * sy;
      D.f = Math.max(0.1, Math.min(6, ((b0.w + dx) / b0.w + (b0.h + dy) / b0.h) / 2));
      const w = b0.w * D.f, h = b0.h * D.f;
      Object.assign(box.style, { width: w + "px", height: h + "px", left: (sx < 0 ? b0.l + b0.w - w : b0.l) + "px", top: (sy < 0 ? b0.t + b0.h - h : b0.t) + "px" });
      tag.textContent = `${label(e)} · ${Math.round(pxOf(e) * D.f)} px`;
    };
    const up = () => {
      hd.removeEventListener("pointermove", move);
      hd.removeEventListener("pointerup", up);
      if (Math.abs(D.f - 1) < 0.02) { sync(); return; }
      setScale(e, pct0 * D.f, scope());
    };
    hd.addEventListener("pointermove", move);
    hd.addEventListener("pointerup", up);
  }

  /* ------------------ size / scope / gaps (menu and side panel) ------------------ */
  function controlsHtml(e) {
    const role = e.role === "heading" ? "heading" : "body";
    const own = T().gaps ? T().gaps(e.token) : null;
    const gl = own ? own.l : App.get(role === "heading" ? "heading_icon_gap_left" : "icon_gap_left");
    const gr = own ? own.r : App.get(role === "heading" ? "heading_icon_gap_right" : "icon_gap_right");
    const name = esc(label(e));
    return `<div class="ics-row"><span class="ics-lab">Size</span>
        <button class="pt-btn secondary small" data-ics="minus" title="Smaller (−2 px)">−</button>
        <input type="number" class="ics-num" data-ics="pct" min="4" max="1000" step="1" value="${pxOf(e)}" title="Height on the page (px)"><span class="ics-unit">px</span>
        <button class="pt-btn secondary small" data-ics="plus" title="Bigger (+2 px)">+</button></div>
      <div class="ics-scope" title="Which copies the size applies to">
        ${SCOPES(name, role).map(([v, t]) => `<button type="button" class="ics-opt ${scope() === v ? "on" : ""}" data-scope="${v}">${t}</button>`).join("")}</div>
      <div class="ics-row"><span class="ics-lab" title="Space between the icon and the words beside it — for the copies the size applies to">${role === "heading" ? "Heading gap" : "Icon gap"}</span>
        left <input type="number" class="ics-num" data-ics="gl" min="0" max="400" value="${esc(gl ?? "")}">
        <button type="button" class="ics-link ${linked(gl, gr) ? "on" : ""}" data-ics="link" title="${linked(gl, gr) ? "Linked: left and right stay the same — click to set them apart" : "Link left and right"}">🔗</button>
        right <input type="number" class="ics-num" data-ics="gr" min="0" max="400" value="${esc(gr ?? "")}"></div>
      <div class="ics-row">
        <button class="pt-btn secondary small" data-ics="reset">Back to normal size</button>
        <button class="pt-btn secondary small" data-ics="pic">Change picture…</button></div>`;
  }
  /* the same controls in one line: the Typography top bar in Icon mode */
  function barHtml(e) {
    const role = e.role === "heading" ? "heading" : "body";
    const own = T().gaps ? T().gaps(e.token) : null;
    const gl = own ? own.l : App.get(role === "heading" ? "heading_icon_gap_left" : "icon_gap_left");
    const gr = own ? own.r : App.get(role === "heading" ? "heading_icon_gap_right" : "icon_gap_right");
    const name = esc(label(e));
    return `<span class="ics-chip" title="${role === "heading" ? "Heading" : "Body"} icon">◆ ${name}</span>
      <span class="ts-sep"></span>
      <span class="ts-lbl">Size</span>
      <button class="ts-al" data-ics="minus" title="Smaller (−2 px)">−</button>
      <input class="ts-size" type="number" data-ics="pct" min="4" max="1000" step="1" value="${pxOf(e)}" title="Height on the page (px) — or drag a corner of the icon"><span class="ts-unit">px</span>
      <button class="ts-al" data-ics="plus" title="Bigger (+2 px)">+</button>
      <span class="ts-sep"></span>
      <span class="ts-lbl">Apply to</span>
      <select class="ts-style ics-scope-sel" data-ics="scope" title="Which copies a size change reaches — dragging a corner uses it too">
        ${SCOPES(name, role).map(([v, t]) => `<option value="${v}" ${scope() === v ? "selected" : ""}>${t}</option>`).join("")}</select>
      <span class="ts-sep"></span>
      <span class="ts-lbl" title="Space between the icon and the words beside it — for the copies in Apply to">Gap</span>
      <input class="ts-size" type="number" data-ics="gl" min="0" max="400" value="${esc(gl ?? "")}" title="Left of each ${role} icon (px)">
      <button type="button" class="ics-link ${linked(gl, gr) ? "on" : ""}" data-ics="link" title="${linked(gl, gr) ? "Linked: left and right stay the same — click to set them apart" : "Link left and right"}">🔗</button>
      <input class="ts-size" type="number" data-ics="gr" min="0" max="400" value="${esc(gr ?? "")}" title="Right of each ${role} icon (px)">
      ${own ? `<button class="ts-al" data-ics="gapreset" title="Back to the text's gaps (for the copies in Apply to)">↺</button>` : ""}
      <span class="ts-sep"></span>
      <button class="ts-tgt" data-ics="reset" title="Back to the normal icon height (for the copies in Apply to)">Normal size</button>
      <button class="ts-tgt" data-ics="pic">Change picture…</button>`;
  }
  function linked(gl, gr) {
    if (S.gapLink == null) S.gapLink = String(gl ?? "") === String(gr ?? "");
    return S.gapLink;
  }
  function wire(root, e, after) {
    const q = (a) => root.querySelector(`[data-ics="${a}"]`);
    root.querySelectorAll("[data-scope]").forEach((b) => b.addEventListener("click", () => {
      S.scope = b.dataset.scope;
      root.querySelectorAll("[data-scope]").forEach((x) => x.classList.toggle("on", x === b));   // the choice shows at once
      if (root.id !== "icsPanel") panel();
    }));
    q("scope")?.addEventListener("change", () => { S.scope = q("scope").value; panel(); });
    q("link").addEventListener("click", () => {
      S.gapLink = !S.gapLink;
      q("link").classList.toggle("on", S.gapLink);
      q("link").title = S.gapLink ? "Linked: left and right stay the same — click to set them apart" : "Link left and right";
    });
    const gap = (side) => {
      const v = q(side === "left" ? "gl" : "gr").value;
      if (after) after();
      if (S.gapLink) q(side === "left" ? "gr" : "gl").value = v;
      setIconGap(e, [q("gl").value, q("gr").value], scope());
    };
    q("gapreset")?.addEventListener("click", () => { if (after) after(); setIconGap(e, null, scope()); });
    const go = (pct) => { if (after) after(); setScale(e, pct, scope()); };
    q("minus").addEventListener("click", () => go(pctForPx(e, pxOf(e) - 2)));
    q("plus").addEventListener("click", () => go(pctForPx(e, pxOf(e) + 2)));
    q("pct").addEventListener("change", () => { const v = Number(q("pct").value); if (v > 0) go(pctForPx(e, v)); });
    q("gl").addEventListener("change", () => gap("left"));
    q("gr").addEventListener("change", () => gap("right"));
    q("reset").addEventListener("click", () => go(100));
    q("pic").addEventListener("click", () => { if (after) after(); mapDialog(label(e), true); });
  }
  function hideMenu() { el("icsMenu")?.remove(); }
  function menu(ev, e) {
    hideMenu();
    select(e);
    const h = host();
    if (!h) return;
    const m = document.createElement("div");
    m.id = "icsMenu";
    m.className = "tsel-menu ics-menu";
    m.innerHTML = `<div class="vpm-head">${esc(label(e))} icon</div>${controlsHtml(e)}`;
    ["mousedown", "pointerdown", "click", "dblclick", "contextmenu", "wheel"].forEach((t) => m.addEventListener(t, (e2) => e2.stopPropagation()));
    h.appendChild(m);
    const hr = h.getBoundingClientRect();
    m.style.left = Math.max(4, Math.min(h.clientWidth - m.offsetWidth - 4, ev.clientX - hr.left)) + "px";
    m.style.top = Math.max(4, Math.min(h.clientHeight - m.offsetHeight - 4, ev.clientY - hr.top)) + "px";
    wire(m, e, hideMenu);
    setTimeout(() => document.addEventListener("mousedown", hideMenu, { once: true }), 0);
  }
  function panel() {
    const p = el("icsPanel");
    if (!p) return;
    const e = on() ? selected() : null;
    if (!e) {
      p.innerHTML = `<div class="tbl-head">Selected icon</div><div class="hint">Click an icon on the page to size it (drag a corner) · right-click it for every copy on the page or in the sheet · click a &lt;TOKEN&gt; without a picture to map one.</div>`;
      return;
    }
    p.innerHTML = `<div class="tbl-head">${esc(label(e))} <span class="hint">${e.role === "heading" ? "heading icon" : "body icon"}</span></div>${controlsHtml(e)}`;
    wire(p, e);
  }

  /* ---------------- a <TOKEN> without a picture: map one ---------------- */
  function tokenAt(c, cssX, cssY) {
    const k = c.getBoundingClientRect().width / AppLive.state.data.canvas_w;
    const px = cssX / k, py = cssY / k;
    const e = AppLive.elementAt(c, cssX, cssY);
    if (!e || (e.kind !== "line" && e.kind !== "heading") || !AppLive.textRows) return null;
    for (const r of AppLive.textRows(e)) {
      if (py < r.top || py > r.top + r.h) continue;
      for (const run of r.runs || []) {
        const x0 = r.x + (run.x || 0);
        if (px < x0 || px > x0 + (run.w || 0)) continue;
        if (run.kind === "icon" && run.token && run.missing) return T().untag(run.token);
        const m = run.kind === "text" && /^<([^<>]+)>$/.exec(String(run.text || "").trim());
        if (m) return T().untag(m[1]);
      }
    }
    return null;
  }
  // opts.onPick(path): the picture chosen is handed back instead of mapped to the token (e.g. the
  // XTRAA REELS icon of the Game Rules page); opts.title / opts.hint word the dialog for it
  async function mapDialog(token, hasPicture, opts) {
    opts = opts || {};
    const cfg = App.state.config || {}, folder = cfg.icon_folder || "";
    let files = [];
    try { files = (await api("/api/icons")).files || []; } catch (e) { files = []; }
    const want = String(token).toLowerCase().replace(/[^a-z0-9]/g, "");
    const scored = files.map((f) => ({ ...f, score: App.ptmSymbolSimilarity ? App.ptmSymbolSimilarity(f.name, token) : 0 }))
      .sort((a, b) => b.score - a.score || a.name.localeCompare(b.name));
    const linked = cfg.icon_mappings || {};
    const linkKey = Object.keys(linked).find((k) => k.replace(/[<>\s_-]/g, "").toLowerCase() === want);
    const thumb = (f) => `/api/icon_file?folder=${encodeURIComponent(folder)}&name=${encodeURIComponent(f.name)}`;
    const ov = document.createElement("div");
    ov.className = "overlay";
    ov.innerHTML = `<div class="table-mapper-dialog" style="width:min(720px,94vw);max-height:88vh;height:auto;display:flex;flex-direction:column">
        <div class="panel-header" style="margin-bottom:8px"><span class="panel-title">${opts.title ? esc(opts.title) : `${hasPicture ? "Change the picture of" : "Map an icon to"} &lt;${esc(token)}&gt;`}</span></div>
        <div class="hint" style="margin-bottom:10px">${opts.hint ? esc(opts.hint) : `${hasPicture ? "Pick another picture" : "No picture for this token was found — pick one"} from your symbols folder, or open any image on this PC. It is used for &lt;${esc(token)}&gt; on every page and in the PSD.`}</div>
        <input type="text" class="tm-path" id="icsSearch" placeholder="Search your symbols folder…" style="margin-bottom:10px">
        <div id="icsGrid" class="ics-grid"></div>
        <div class="tm-footer">
          <button class="btn ghost" id="icsCancel">Cancel</button>
          ${linkKey && !opts.onPick ? `<button class="btn secondary" id="icsUnlink">Remove the mapping</button>` : ""}
          <button class="btn secondary" id="icsBrowse">Open from this PC…</button>
        </div></div>`;
    document.body.appendChild(ov);
    const $ = (id) => ov.querySelector("#" + id);
    const close = () => ov.remove();
    // a click outside never closes it (what was typed in it would be lost): its ✕ or Cancel do
    $("icsCancel").addEventListener("click", close);
    const render = (qy) => {
      const query = String(qy || "").toLowerCase();
      const list = scored.filter((f) => !query || f.name.toLowerCase().includes(query));
      $("icsGrid").innerHTML = list.length ? list.map((f, i) => `
        <button class="pt-btn secondary ics-tile" data-name="${esc(f.name)}" title="${esc(f.name)}">
          <img src="${thumb(f)}" alt="" loading="lazy"><span>${esc(f.name)}</span>
          ${!query && i < 3 && f.score >= 0.5 ? '<span class="pt-pill" style="font-size:10px">suggested</span>' : ""}</button>`).join("")
        : `<div class="hint">${files.length ? "No icon matches." : "Your symbols folder is empty or not set — use Open from this PC…"}</div>`;
    };
    render("");
    $("icsSearch").addEventListener("input", (e) => render(e.target.value));
    const write = async (path) => {
      if (opts.onPick) { close(); if (path) await opts.onPick(path); return; }
      const next = { ...(cfg.icon_mappings || {}) };
      if (linkKey) delete next[linkKey];
      if (path) next["<" + token + ">"] = path;
      const byExcel = { ...(cfg.icon_mappings_by_excel || {}) };
      const ek = App.ptmExcelKey ? App.ptmExcelKey() : "";
      if (ek) {
        byExcel[ek] = { ...(byExcel[ek] || {}) };
        if (linkKey) delete byExcel[ek][linkKey];
        if (path) byExcel[ek]["<" + token + ">"] = path;
      }
      try {
        const d = await api("/api/mappings", { method: "POST", body: { icon_mappings: next, icon_mappings_by_excel: byExcel } });
        if (d.config) App.state.config = d.config; else App.state.config.icon_mappings = next;
      } catch (e) { toast(e.message, "err"); return; }
      close();
      await save();
      toast(path ? `<${token}> now shows ${String(path).split(/[\\/]/).pop()} on every page.` : `<${token}> mapping removed.`, "ok");
    };
    $("icsGrid").addEventListener("click", (e) => {
      const b = e.target.closest("button[data-name]");
      if (b) write((folder ? folder.replace(/[\\/]$/, "") + "\\" : "") + b.dataset.name);
    });
    $("icsUnlink")?.addEventListener("click", () => write(""));
    $("icsBrowse").addEventListener("click", async () => {
      let p = "";
      const native = window.pywebview?.api;
      if (native && typeof native.browse_file === "function") {
        try { p = await native.browse_file("image"); } catch (e) { toast("File dialog failed (" + e.message + ").", "err"); return; }
      } else if (App.ptmPromptFilePath) {
        p = await App.ptmPromptFilePath({ title: "Icon image", label: "Image file path", placeholder: "C:\\\\path\\\\to\\\\icon.png", ok: "Use", hint: "PNG, JPG, GIF or BMP." });
      }
      if (p) write(p);
    });
    $("icsSearch").focus();
  }

  /* the icon under the pointer — icons first, so a strip, a line or a table behind never takes the click
     (a few px of slack around small icons) */
  function iconAt(c, cssX, cssY) {
    const k = c.getBoundingClientRect().width / AppLive.state.data.canvas_w;
    const px = cssX / k, py = cssY / k, slack = 6 / k;
    let best = null;
    for (const e of AppLive.state.elements || []) {
      if (e.kind !== "icon") continue;
      const x = e.base.x + (Number((e.ov || {}).x) || 0), y = e.base.y;
      if (px < x - slack || px > x + e.w + slack || py < y - slack || py > y + e.h + slack) continue;
      const d = Math.hypot(px - (x + e.w / 2), py - (y + e.h / 2));
      if (!best || d < best.d) best = { e, d };
    }
    return best ? best.e : null;
  }

  /* ---------------- events from the Typography canvas (Assets route) ---------------- */
  function click(ev) {
    if (!on()) return false;
    hideMenu();
    const c = canvas();
    if (!c) return false;
    const r = c.getBoundingClientRect();
    const e = iconAt(c, ev.clientX - r.left, ev.clientY - r.top);
    if (e) { select(e); return true; }
    const tok = tokenAt(c, ev.clientX - r.left, ev.clientY - r.top);
    if (tok) { mapDialog(tok, false); return true; }
    select(null);
    return true;
  }
  function contextMenu(ev) {
    if (!on()) return false;
    const c = canvas();
    if (!c) return false;
    const r = c.getBoundingClientRect();
    const e = iconAt(c, ev.clientX - r.left, ev.clientY - r.top);
    if (e) { ev.preventDefault(); menu(ev, e); return true; }
    const tok = tokenAt(c, ev.clientX - r.left, ev.clientY - r.top);
    if (tok) { ev.preventDefault(); mapDialog(tok, false); return true; }
    return false;
  }
  /* a click on the Typography page: an icon is selected (the top bar edits it), a <TOKEN> with no
     picture gets one; anything else leaves the click to the text (false) */
  function clickTypo(ev) {
    useVis(false);
    if (!on()) return false;
    hideMenu();
    const c = canvas();
    if (!c) return false;
    const r = c.getBoundingClientRect();
    const e = iconAt(c, ev.clientX - r.left, ev.clientY - r.top);
    if (e) { select(e); return true; }
    const tok = tokenAt(c, ev.clientX - r.left, ev.clientY - r.top);
    if (tok) { mapDialog(tok, false); return true; }
    deselect();
    return false;
  }
  function missingClick(token) { mapDialog(String(token).replace(/[<>]/g, ""), false); }

  /* ---------------- the Visualiser: the same icon editing on its canvas ---------------- */
  function useVis(yes) {
    if (V.vis !== !!yes) { S.sel = null; hideBox(); hideMenu(); }
    V.vis = !!yes;
  }
  function pickVis(e) {                              // an icon clicked in the Visualiser
    useVis(true);
    select(e);
  }
  function clickVis(ev) {                            // Icon Edit: a <TOKEN> without a picture → map one
    useVis(true);
    const c = canvas();
    if (!c || !on()) return false;
    const r = c.getBoundingClientRect();
    const tok = tokenAt(c, ev.clientX - r.left, ev.clientY - r.top);
    if (!tok) return false;
    mapDialog(tok, false);
    return true;
  }
  function contextMenuVis(ev) {
    useVis(true);
    return contextMenu(ev);
  }
  function clearVis() {
    if (V.vis) { S.sel = null; hideBox(); hideMenu(); }
  }
  function onVisDraw() {                             // the Visualiser panned / zoomed / redrew
    if (!V.vis || !S.sel) return;
    const c = canvas();
    if (!c) return;
    const r = c.getBoundingClientRect(), key = [r.left, r.top, r.width].map(Math.round).join(",");
    if (key === V.rect) return;
    V.rect = key;
    sync();
  }
  function useAssets() { useVis(false); }

  return { click, contextMenu, sync, panel, missingClick, mapDialog, state: S,
           pickVis, clickVis, contextMenuVis, clearVis, onVisDraw, useAssets,
           clickTypo, deselect, selected, barHtml, wireBar: (root, e) => wire(root, e) };
})();
