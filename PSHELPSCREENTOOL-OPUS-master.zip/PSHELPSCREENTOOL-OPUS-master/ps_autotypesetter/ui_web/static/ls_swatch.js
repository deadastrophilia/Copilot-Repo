/* Layer style swatches.
   Every layer-style dropdown in the app (Typography roles, text boxes in the paytable studio,
   the slot editor) becomes a button showing the chosen style on the word "Sample"; clicking it
   opens a grid of every style in the library, drawn by the same effects engine as the builds.
   The dropdown stays in the page (hidden): picking a swatch sets it and fires its change
   event, so everything already wired to the dropdown keeps working. */
window.LSSwatch = (() => {
  const SEL = "select[data-lsrole], select[data-k$='.fx'], select[data-lsswatch]";
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  let pop = null, owner = null;

  function library() {
    return ((window.App && App.state && App.state.config && App.state.config.dynamic_settings) || {}).layer_style_library || {};
  }
  function hash(v) {                              // a re-captured style gets a fresh picture
    const s = JSON.stringify(v || null);
    let h = 0;
    for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
    return (h >>> 0).toString(36);
  }
  function url(name) {
    return `/api/layer-styles/swatch?name=${encodeURIComponent(name)}&v=${hash(library()[name])}`;
  }
  function face(name) {
    return name
      ? `<span class="lsw-img"><img src="${url(name)}" alt="" loading="lazy"></span><span class="lsw-name">${esc(name)}</span>`
      : `<span class="lsw-img none">Aa</span><span class="lsw-name">None</span>`;
  }

  function enhance(root = document) {
    root.querySelectorAll(SEL).forEach((sel) => {
      if (sel.__lsw) return;
      sel.__lsw = true;
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "lsw-btn";
      btn.title = "Layer style — click to pick one by its look";
      btn.innerHTML = `${face(sel.value)}<span class="lsw-caret">▾</span>`;
      sel.classList.add("lsw-hidden");
      sel.insertAdjacentElement("afterend", btn);
      btn.addEventListener("pointerdown", (e) => e.stopPropagation());
      btn.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); open(sel, btn); });
      sel.addEventListener("change", () => { btn.innerHTML = `${face(sel.value)}<span class="lsw-caret">▾</span>`; });
    });
  }

  function close() {
    if (pop) pop.remove();
    pop = null; owner = null;
  }
  function open(sel, btn) {
    if (owner === sel) { close(); return; }
    close();
    owner = sel;
    const names = [...sel.options].map((o) => o.value);
    pop = document.createElement("div");
    pop.className = "lsw-pop";
    pop.innerHTML = `<div class="lsw-grid">${names.map((n) => `<button type="button" class="lsw-opt ${n === sel.value ? "on" : ""}" data-v="${esc(n)}" title="${esc(n || "No layer style")}">${face(n)}</button>`).join("")}</div>
      <div class="lsw-foot">Copy new styles from Photoshop in Canvas → Layer style.</div>`;
    document.body.appendChild(pop);
    const r = btn.getBoundingClientRect(), pw = pop.offsetWidth, ph = pop.offsetHeight;
    const left = Math.max(8, Math.min(window.innerWidth - pw - 8, r.left));
    const top = r.bottom + 6 + ph > window.innerHeight ? Math.max(8, r.top - ph - 6) : r.bottom + 6;
    Object.assign(pop.style, { left: `${left}px`, top: `${top}px` });
    pop.addEventListener("pointerdown", (e) => e.stopPropagation());
    pop.querySelectorAll(".lsw-opt").forEach((b) => b.addEventListener("click", (e) => {
      e.stopPropagation();
      sel.value = b.dataset.v;
      sel.dispatchEvent(new Event("input", { bubbles: true }));
      sel.dispatchEvent(new Event("change", { bubbles: true }));
      close();
    }));
  }

  document.addEventListener("pointerdown", (e) => { if (pop && !pop.contains(e.target)) close(); });
  document.addEventListener("keydown", (e) => { if (pop && e.key === "Escape") { e.stopPropagation(); close(); } }, true);
  window.addEventListener("resize", close);

  // screens re-render often: upgrade dropdowns as they appear
  let queued = false;
  new MutationObserver(() => {
    if (queued) return;
    queued = true;
    setTimeout(() => { queued = false; enhance(); if (owner && !document.body.contains(owner)) close(); }, 0);
  }).observe(document.documentElement, { childList: true, subtree: true });
  document.addEventListener("DOMContentLoaded", () => enhance());
  return { enhance, url };
})();
