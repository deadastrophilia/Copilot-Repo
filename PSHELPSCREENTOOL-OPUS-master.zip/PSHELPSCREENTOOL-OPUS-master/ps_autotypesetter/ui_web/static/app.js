/* ============================================================
   PsHelpScreenTool v47 — Web UI (Photoshop-inspired SPA)
   ============================================================ */

"use strict";

const App = {
  state: { config: null, presets: [], canvasPresets: [], scan: null, jobId: null, ptmUserPicked: false, ptmGlobalStyles: {} },
  route: "dashboard",
  _toastTimer: null,
  _jobTimer: null,
};

/* ------------------------------ utils ------------------------------ */

// Read requests already on their way are shared: the same GET (or read-only POST
// with the same body) asked twice while the first is running waits for that one
// answer instead of making the server do the work again. Each caller gets its own copy.
const _apiInflight = new Map();
const _API_READ_POSTS = ["/api/visualiser/sheets", "/api/visualiser/editor-data", "/api/layout/preview", "/api/scan"];

async function api(path, opts = {}) {
  const method = String(opts.method || "GET").toUpperCase();
  const shareable = !opts.signal && !(opts.body instanceof FormData) &&
    (method === "GET" || (method === "POST" && _API_READ_POSTS.includes(String(path).split("?")[0])));
  if (!shareable) return _apiFetch(path, opts);
  const key = method + " " + path + " " + (opts.body ? JSON.stringify(opts.body) : "");
  let p = _apiInflight.get(key);
  if (!p) {
    p = _apiFetch(path, opts).finally(() => _apiInflight.delete(key));
    _apiInflight.set(key, p);
  }
  const data = await p;
  return typeof structuredClone === "function" ? structuredClone(data) : JSON.parse(JSON.stringify(data));
}

async function _apiFetch(path, opts = {}) {
  const isForm = opts.body instanceof FormData;
  const timeout = opts.timeout || 0;
  const ctl = timeout > 0 ? new AbortController() : null;
  if (ctl) setTimeout(() => ctl.abort(), timeout);
  const res = await fetch(path, {
    headers: isForm ? {} : { "Content-Type": "application/json" },
    ...opts,
    signal: ctl ? ctl.signal : opts.signal,
    body: isForm ? opts.body : opts.body ? JSON.stringify(opts.body) : undefined,
  });
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error(data.error || `Request failed (${res.status})`);
  }
  return res.json();
}

// Page thumbnails come back at once: an older picture of the sheet when the settings changed
// since it was drawn, while the server draws the new one in the background. This watches
// every thumbnail on screen and swaps the new picture in when it is ready.
// A sheet is reported fresh once per version of the settings (until the next config save): pictures
// of it asked for after that are already the new ones, so they are neither fetched again nor reported
// again (reporting rebuilds the sheet's Continued pages, whose new pictures would loop forever).
const _thumbWatch = { timer: 0, until: 0, bump: 0, seen: new Set() };
function watchThumbs() {
  _thumbWatch.until = Date.now() + 180000;
  if (!_thumbWatch.timer) _thumbWatch.timer = setTimeout(_checkThumbs, 1200);
}
async function _checkThumbs() {
  _thumbWatch.timer = 0;
  const sheetOf = (img) => decodeURIComponent(new URL(img.src, location.href).pathname.split("/api/pages_thumb/")[1] || "");
  const seenKey = (img) => sheetOf(img) + "|" + (new URL(img.src, location.href).searchParams.get("v") || "");
  const imgs = [...document.querySelectorAll('img[src*="/api/pages_thumb/"]')].filter((i) => {
    if (i.dataset.fresh) return false;
    if (_thumbWatch.seen.has(seenKey(i))) { i.dataset.fresh = "1"; return false; }
    return true;
  });
  const sheets = [...new Set(imgs.map(sheetOf).filter(Boolean))];
  if (!sheets.length) return;
  let fresh = {};
  try { fresh = (await api("/api/pages_fresh", { method: "POST", body: { sheets } })).fresh || {}; } catch (e) { return; }
  const done = new Set(sheets.filter((s) => fresh[s]));
  imgs.forEach((img) => { if (done.has(sheetOf(img))) _thumbWatch.seen.add(seenKey(img)); });
  imgs.forEach((img) => {
    if (!done.has(sheetOf(img))) return;
    const u = new URL(img.src, location.href);
    if (img.complete && !u.searchParams.has("f")) {        // loaded before it was fresh: ask once more
      u.searchParams.set("f", String(++_thumbWatch.bump));
      if (window.AppTypoVis && AppTypoVis.swapImg) AppTypoVis.swapImg(img, u.pathname + u.search);   // no blank flash
      else img.src = u.pathname + u.search;
    }
    img.dataset.fresh = "1";
  });
  done.forEach((s) => window.dispatchEvent(new CustomEvent("psh:thumb-fresh", { detail: s })));
  if (done.size < sheets.length && Date.now() < _thumbWatch.until) _thumbWatch.timer = setTimeout(_checkThumbs, 1500);
}

function esc(s) {
  return String(s ?? "").replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[c]));
}

/* Escape a string for embedding inside a JS string literal that lives in an
   HTML attribute (inline onclick). Backslashes are JS escapes ("Z:\games"
   would become "Z:games"), and quotes must be escaped for the JS parser. */
function jsStr(s) {
  return esc(String(s ?? "").replace(/\\/g, "\\\\").replace(/'/g, "\\'").replace(/[\r\n]+/g, " "));
}

function toast(msg, type = "ok") {
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.className = "toast " + type;
  t.hidden = false;
  clearTimeout(App._toastTimer);
  App._toastTimer = setTimeout(() => (t.hidden = true), 3800);
}

function icon(name) {
  const icons = {
    play: '<svg viewBox="0 0 24 24"><path d="M7 4v16l13-8-13-8z" fill="currentColor"/></svg>',
    image: '<svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2" fill="currentColor"/><circle cx="8.5" cy="10" r="1.5" fill="var(--bg)"/><path d="M3 17l5-5 4 4 3-3 6 6v2a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-4z" fill="var(--bg)"/></svg>',
    file: '<svg viewBox="0 0 24 24"><path d="M6 2h8l4 4v16H6V2z" fill="currentColor"/><path d="M14 2v4h4" fill="var(--bg)"/></svg>',
    spark: '<svg viewBox="0 0 24 24" class="spark"><path d="M12 3l1.9 5.6L19.5 10.5l-5.6 1.9L12 18l-1.9-5.6L4.5 10.5l5.6-1.9L12 3z" fill="currentColor"/></svg>',
    check: '<svg viewBox="0 0 24 24"><path d="M9 16.2l-3.6-3.6L4 14l5 5 11-11-1.4-1.4L9 16.2z" fill="currentColor"/></svg>',
    plus: '<svg viewBox="0 0 24 24"><path d="M11 5h2v6h6v2h-6v6h-2v-6H5v-2h6V5z" fill="currentColor"/></svg>',
    chevron: '<svg viewBox="0 0 24 24" class="chev"><path d="M9 6l6 6-6 6" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    link: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>',
    grid: '<svg viewBox="0 0 24 24"><path d="M3 3h8v8H3V3zm10 0h8v8h-8V3zM3 13h8v8H3v-8zm10 0h8v8h-8v-8z" fill="currentColor"/></svg>',
  };
  return icons[name] || "";
}

function field(key, label, { type = "text", placeholder = "", hint = "", options = null, min = null, max = null, step = null, slider = false } = {}) {
  const val = App.get(key);
  let input;
  if (type === "select") {
    input = `<select data-key="${key}">${options.map((o) => `<option value="${esc(o.value)}" ${String(o.value) === String(val) ? "selected" : ""}>${esc(o.label)}</option>`).join("")}</select>`;
  } else if (type === "color") {
    input = `<input type="color" data-key="${key}" value="${esc(val)}" />`;
  } else if (type === "textarea") {
    input = `<textarea data-key="${key}" rows="4" placeholder="${esc(placeholder)}">${esc(typeof val === "object" ? JSON.stringify(val || {}, null, 1) : val)}</textarea>`;
  } else if (type === "number" && slider) {
    const mn = min != null ? min : 0;
    const mx = max != null ? max : Math.max(mn, 400);
    const st = step != null ? step : 1;
    const nv = parseFloat(val) || mn;
    input = `<div class="slider-field">
      <input type="number" data-key="${key}" value="${esc(val)}" min="${mn}" max="${mx}" step="${st}" ${placeholder ? `placeholder="${esc(placeholder)}"` : ""} class="slider-num" />
      <input type="range" data-range="${key}" value="${Math.min(mx, Math.max(mn, nv))}" min="${mn}" max="${mx}" step="${st}" class="slider-bar" />
    </div>`;
  } else {
    const attrs = [min != null ? `min="${min}"` : "", max != null ? `max="${max}"` : "", step != null ? `step="${step}"` : ""].join(" ");
    input = `<input type="${type}" data-key="${key}" value="${esc(val)}" placeholder="${esc(placeholder)}" ${attrs} />`;
  }
  return `<div class="field"><label>${label}</label>${input}${hint ? `<div class="hint">${hint}</div>` : ""}</div>`;
}

function fontField(key, label, placeholder = "ArialMT") {
  const val = App.get(key);
  const fonts = (App.state.fonts || []).slice();
  if (val && !fonts.some((f) => String(f).toLowerCase() === String(val).toLowerCase())) fonts.unshift(String(val));
  const opts = fonts.map((f) => `<option value="${esc(f)}" ${String(f).toLowerCase() === String(val).toLowerCase() ? "selected" : ""}>${esc(f)}</option>`).join("");
  return `<div class="field"><label>${label}</label>
    <select data-key="${key}" data-font>${opts}</select>
    <div class="hint">${fonts.length ? `${fonts.length} fonts installed. Click to pick one, or leave the current value.` : `No font list loaded — type the Post font name (e.g. ArialMT).`}</div>
  </div>`;
}

function toggleRow(key, label, hint = "") {
  const val = App.get(key);
  return `<div class="toggle-row"><div><div class="t-label">${label}</div>${hint ? `<div class="hint">${hint}</div>` : ""}</div>
    <label class="switch"><input type="checkbox" data-key="${key}" ${val ? "checked" : ""} /><span class="track"></span></label></div>`;
}

function colorField(key, label) {
  const val = App.get(key) || "#FFFFFF";
  return `<div class="field"><label>${label}</label><input type="color" data-key="${key}" value="${esc(val)}" /></div>`;
}

function selectField(key, label, options) {
  const val = App.get(key);
  return `<div class="field"><label>${label}</label><select data-key="${key}">${options.map((o) => `<option value="${esc(o.value)}" ${String(o.value) === String(val) ? "selected" : ""}>${esc(o.label)}</option>`).join("")}</select></div>`;
}

function layerStylePicker(role, label, opts = {}) {
  const ds = App.state.config.dynamic_settings || {};
  const library = ds.layer_style_library || {};
  const assignments = ds.style_assignments || {};
  const current = assignments[role] || "";
  const names = Object.keys(library).sort((a, b) => a.localeCompare(b));
  const mode = opts.mode || "copied";
  const labelText = label || "Layer style";
  const widthStyle = opts.width ? ` style="max-width:${esc(opts.width)}"` : "";
  return `<div class="field"><label>${labelText}</label>
    <div class="ls-select-wrap"${widthStyle}><select data-lsrole="${esc(role)}">
      <option value="">None (no styles)</option>
      ${names.map((n) => `<option value="${esc(n)}" ${n === current ? "selected" : ""}>${esc(n)}</option>`).join("")}
    </select></div>
    <div class="btn-row" style="margin-top:8px">
      <button class="btn secondary" onclick="App.captureLayerStyle('${esc(role)}', '${mode}')">Copy from Photoshop…</button>
      ${current ? `<button class="btn secondary small" onclick="App.verifyLayerStyle('${esc(role)}')" title="Optional check: render this style in the open Photoshop and compare it with the tool's preview">Verify in Photoshop</button>` : ""}
      ${current ? `<button class="btn danger small" onclick="App.deleteLayerStyle('${esc(role)}')">Delete “${esc(current)}”</button>` : ""}
    </div>
    <div class="hint">Pick a saved layer style, or copy a new one from Photoshop and save it to the tool. “None” renders the text without any style. The preview draws every effect itself; “Verify in Photoshop” is an optional side-by-side check.</div>
  </div>`;
}

/* ------------------------------ paytable workspace helpers ------------------------------ */

function ptCssColor(v, fallback = "#F5F7FA") {
  if (Array.isArray(v) && v.length >= 3) return `rgb(${v[0]},${v[1]},${v[2]})`;
  return typeof v === "string" && v.trim() ? v : fallback;
}

function ptSlider(key, label, opts = {}) {
  const { min = 0, max = 400, step = 1, unit = "px" } = opts;
  const val = parseFloat(App.get(key));
  const nv = isNaN(val) ? min : val;
  return `<div class="pt-ctl">
    <div class="pt-ctl-label"><span>${label}</span><span class="pt-ctl-val" data-val="${key}">${nv}${unit}</span></div>
    <div class="slider-field">
      <input type="number" data-key="${key}" value="${esc(nv)}" min="${min}" max="${max}" step="${step}" class="slider-num" />
      <input type="range" data-range="${key}" data-unit="${unit}" value="${Math.min(max, Math.max(min, nv))}" min="${min}" max="${max}" step="${step}" class="slider-bar" />
    </div>
  </div>`;
}

function ptColor(key, label) {
  const v = App.get(key) || "#FFFFFF";
  return `<div class="pt-ctl"><div class="pt-ctl-label"><span>${label}</span></div>
    <input type="color" data-key="${key}" value="${esc(v)}" /></div>`;
}

const PT_WEIGHTS = ["", "Regular", "Medium", "SemiBold", "Bold", "ExtraBold", "Black", "Light", "Italic"];

function ptWeightSelect(key, label) {
  const w = String(App.get(key + "_weight") || "");
  return `<div class="pt-ctl"><div class="pt-ctl-label"><span>${label}</span></div>
    <select data-ptweight="${key}" class="pt-select">${PT_WEIGHTS.map((o) => `<option value="${esc(o)}" ${o === w ? "selected" : ""}>${esc(o || "Default weight")}</option>`).join("")}</select>
    <div class="pt-hint">Weight merges into the font name (e.g. “ArialMT Bold”).</div></div>`;
}

function ptLayerStyleSelect(key, label) {
  const style = App.get(key) || null;
  const sel = style && style.shadow_enabled && style.stroke_enabled ? "both"
    : style && style.stroke_enabled ? "stroke"
    : style && style.shadow_enabled ? "shadow" : "none";
  return `<div class="pt-ctl"><div class="pt-ctl-label"><span>${label}</span></div>
    <select data-ptstyle="${key}" class="pt-select">${[["none", "None"], ["stroke", "Stroke"], ["shadow", "Shadow"], ["both", "Stroke + Shadow"]].map(([v, l]) => `<option value="${v}" ${v === sel ? "selected" : ""}>${l}</option>`).join("")}</select>
    <div class="pt-hint">Layer style baked onto the text layer when the PSD is built.</div></div>`;
}

function mergePtFontStyle(fontName, styleName) {
  fontName = String(fontName || "").trim();
  styleName = String(styleName || "").trim();
  if (!fontName) return "";
  if (!styleName || /^(regular|normal)$/i.test(styleName)) return fontName;
  if (fontName.toLowerCase().includes(styleName.toLowerCase())) return fontName;
  return fontName + " " + styleName;
}

function commitPtWeight(baseKey, weight) {
  const reqKey = baseKey + "_font_request";
  const existing = String(App.get(reqKey) || "").trim();
  if (weight && existing) {
    App.set(reqKey, mergePtFontStyle(existing, weight));
    App.set(baseKey + "_weight", "");
  } else {
    App.set(baseKey + "_weight", weight || "");
  }
  App.refreshUI();
}

function commitPtLayerStyle(key, value) {
  const base = {
    stroke_enabled: value === "stroke" || value === "both",
    shadow_enabled: value === "shadow" || value === "both",
  };
  App.set(key, value === "none"
    ? null
    : {
        ...base,
        stroke_rgb: [255, 255, 255],
        stroke_size: 3,
        stroke_opacity: 100,
        shadow_opacity: 60,
        shadow_distance: 8,
        shadow_size: 12,
        shadow_angle: 120,
      });
  App.refreshUI();
}

window.addEventListener("error", (e) => {
  try {
    console.error("GLOBAL JS ERROR:", e && (e.error || e.message));
    App._lastError = ((e && e.message) || (e && e.error && e.error.message) || "unknown") + " @ " + new Date().toLocaleTimeString();
    const t = document.getElementById("toast");
    if (t) {
      t.textContent = "JS error: " + ((e && e.message) || (e && e.error && e.error.message) || "unknown");
      t.className = "toast err";
      t.hidden = false;
    }
  } catch (_) { /* noop */ }
});
window.addEventListener("unhandledrejection", (e) => {
  try {
    console.error("UNHANDLED REJECTION:", e && e.reason);
  } catch (_) { /* noop */ }
});

/* every dialog and settings panel gets a ✕ in its corner (a click outside no longer closes them): it does
   what the panel's own close does — its ⚙ again, its Cancel / Close button, else the dialog goes */
(() => {
  const DIALOGS = ".overlay > .table-mapper-dialog, .overlay > .mapper-dialog, .gm-overlay > .gm-dialog, .mapper-editor, .ts-strippop";
  const HAS_X = ":scope > .dlg-x, .gm-x, [data-cx], [data-popx], .vsb-x";
  function closeOf(box) {
    if (box.classList.contains("ts-strippop")) {
      const gear = box.previousElementSibling && box.previousElementSibling.matches(".ts-gear, [data-tbgear], [data-stripgear]")
        ? box.previousElementSibling : document.querySelector("[data-tbgear].on, .ts-gear.on");
      return () => (gear ? gear.click() : box.remove());
    }
    const btn = box.querySelector("[data-closeeditor]") || [...box.querySelectorAll("button")].find((b) => /(Cancel|Close)$/i.test(b.id || ""))
      || [...box.querySelectorAll("button")].find((b) => /^(cancel|close|not now|skip)$/i.test((b.textContent || "").trim()));
    return () => (btn ? btn.click() : (box.closest(".overlay, .gm-overlay") || box).remove());
  }
  function addX() {
    document.querySelectorAll(DIALOGS).forEach((box) => {
      if (box.querySelector(HAS_X)) return;
      if (getComputedStyle(box).position === "static") box.style.position = "relative";
      const x = document.createElement("button");
      x.className = "dlg-x";
      x.type = "button";
      x.title = "Close";
      x.textContent = "✕";
      x.addEventListener("mousedown", (e) => e.stopPropagation());
      x.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); closeOf(box)(); });
      box.prepend(x);
    });
  }
  // the observer already hands over a batch of changes at a time (adding a ✕ is one more, which finds
  // every box done)
  new MutationObserver(addX).observe(document.documentElement, { childList: true, subtree: true });
})();

document.addEventListener("click", (e) => {
  if (App.route !== "paytable") return;
  const t = e.target && e.target.closest ? e.target.closest(".ptm-slot") : null;
  if (!t) return;
  const name = t.dataset && t.dataset.slot;
  if (name) App.ptmSelect(name);
});

function ptMockPreview() {
  return `<div class="pt-mock" id="ptMock">
    <div class="pt-mock-title">PAYTABLE</div>
    <div class="pt-mock-symbols">
      <div class="pt-mock-sym wild">★</div>
      <div class="pt-mock-sym scat">✪</div>
      <div class="pt-mock-sym">♠</div>
      <div class="pt-mock-sym">♥</div>
      <div class="pt-mock-sym">♣</div>
      <div class="pt-mock-sym">♦</div>
      <div class="pt-mock-sym">7</div>
      <div class="pt-mock-sym">A</div>
      <div class="pt-mock-sym">K</div>
    </div>
    <div class="pt-mock-line"><span class="pt-mock-label">Count</span><span class="pt-mock-count">5&nbsp;&nbsp;&nbsp;4&nbsp;&nbsp;&nbsp;3</span></div>
    <div class="pt-mock-line"><span class="pt-mock-label">Payout</span><span class="pt-mock-value">×&nbsp;250&nbsp;&nbsp;&nbsp;×&nbsp;50&nbsp;&nbsp;&nbsp;×&nbsp;10</span></div>
    <div class="pt-mock-notes">Scatters pay anywhere on the reels. Wilds substitute for all regular symbols.</div>
    <div class="pt-mock-bottom">All wins pay left to right from the leftmost reel. Malfunction voids all pays.</div>
  </div>`;
}

function ptStatsHtml() {
  const st = App.state.paytableStats;
  if (!st) {
    return `<div class="pt-stat"><span class="pt-stat-num">—</span><span class="pt-stat-label">Slots mapped</span></div>
      <div class="pt-stat"><span class="pt-stat-num">—</span><span class="pt-stat-label">Missing slots</span></div>
      <div class="pt-stat"><span class="pt-stat-num">—</span><span class="pt-stat-label">Last synced</span></div>`;
  }
  const t = st.total || 0;
  const m = st.mapped || 0;
  const missing = t - m;
  return `<div class="pt-stat"><span class="pt-stat-num ${t && m === t ? "ok" : ""}">${m}<span style="font-size:13px;color:var(--pt-text3)"> / ${t}</span></span><span class="pt-stat-label">Slots mapped</span></div>
    <div class="pt-stat"><span class="pt-stat-num ${missing ? "warn" : "ok"}">${missing}</span><span class="pt-stat-label">Missing slots</span></div>
    <div class="pt-stat"><span class="pt-stat-num" style="font-size:15px;line-height:1.4">${st.at ? new Date(st.at).toLocaleTimeString() : "—"}</span><span class="pt-stat-label">Last synced</span></div>`;
}

function card(title, body, cls = "", opts = {}) {
  if (opts.collapsible) {
    const open = opts.open !== false;
    return `<div class="card collapsible-card ${cls}"><details class="card-details" ${open ? "open" : ""}><summary><span class="chev">▼</span><span class="card-title">${title}</span></summary><div class="card-body">${body}</div></details></div>`;
  }
  return `<div class="card ${cls}"><div class="card-title">${title}</div>${body}</div>`;
}

function fileRow(key, label, accept, picker) {
  return `<div class="field">
    <label>${label}</label>
    <div class="field-row">
      <input type="text" data-key="${key}" value="${esc(App.get(key))}" placeholder="Paste the full path…" style="flex:1" />
      <button class="btn secondary" onclick="App.browse('${key}', '${picker}')" title="Browse">Browse…</button>
    </div>
  </div>`;
}

function assetField(key, label, { placeholder = "", hint = "", kind = "file" } = {}) {
  const val = App.get(key);
  return `<div class="field"><label>${label}</label>
    <div class="field-row">
      <input type="text" data-key="${key}" value="${esc(val)}" placeholder="${esc(placeholder)}" style="flex:1" spellcheck="false" />
      <button type="button" class="btn secondary" onclick="App.browse('${key}', '${kind}')" title="Browse">Browse…</button>
      ${val ? `<button type="button" class="btn danger small" onclick="App.clearKey('${key}')" title="Clear">✕</button>` : ""}
    </div>
    ${hint ? `<div class="hint">${hint}</div>` : ""}</div>`;
}

App.clearKey = (key) => {
  App.set(key, "");
  const el = document.querySelector(`[data-key="${key}"]`);
  if (el) {
    el.value = "";
    el.dispatchEvent(new Event("input", { bubbles: true }));
  } else {
    App.refreshUI();
  }
};

function previewCanvas() {
  if (window.AppTypoVis) return window.AppTypoVis.canvasHTML();
  return `<div class="preview-canvas" data-preview>
    <div class="ph-heading">HELP SCREEN</div>
    <div class="ph-rule"></div>
    <div class="ph-body">Place a bet and spin the reels to match 3 symbols on a line. Wilds substitute for all regular symbols.</div>
  </div>`;
}

function bindForms(root) {
  root.querySelectorAll("[data-key]").forEach((el) => {
    if (el.tagName !== "INPUT" && el.tagName !== "SELECT" && el.tagName !== "TEXTAREA") return;
    const key = el.dataset.key;
    const commit = () => {
      let val;
      if (el.type === "checkbox") val = el.checked;
      else if (el.type === "number") val = parseFloat(el.value) || 0;
      else if (el.tagName === "TEXTAREA") {
        val = el.value.trim();
        if (key === "keyword_colors" || key === "heading_style" || key === "table_style" || key === "dynamic_settings" || key === "icon_mappings" || key === "body_style" || key === "icon_style" || key === "alignment_settings.overrides") {
          try { val = val ? JSON.parse(val) : (key === "keyword_colors" || key === "icon_mappings" ? {} : null); }
          catch { toast("Invalid JSON in " + key, "err"); return; }
        }
      } else val = el.value;
      App.set(key, val);
      App.refreshUI();
      if (key === "excel_path" && val && /\.(xlsx|xlsm)$/i.test(val)) App.scan();
      if (key === "icon_folder" && val) App.loadIcons();
      if (key === "bg_source") renderRoute();
      if (key === "bg_path" && val) App.askBgMode();
      if (el.type === "checkbox" && (key === "performance_mode" || key === "update_mode" || key === "headless_mode")) renderRoute();
    };
    el.addEventListener("change", commit);
    if (el.tagName === "INPUT" && (el.type === "text" || el.type === "number")) {
      el.addEventListener("input", commit);
      el.addEventListener("focus", () => { App._focusedKey = key; });
    }
  });

  root.querySelectorAll("input[type='range'][data-range]").forEach((rng) => {
    const key = rng.dataset.range;
    const numInput = root.querySelector(`input[data-key="${cssSelect(key)}"]`);
    if (!numInput || numInput.type !== "number") return;
    const step = parseFloat(rng.step) || 1;
    const mn = parseFloat(rng.min) || 0;
    const mx = parseFloat(rng.max) || 100;
    const valEl = root.querySelector(`[data-val="${cssSelect(key)}"]`);
    const syncVal = () => {
      const v = parseFloat(numInput.value);
      if (valEl && !isNaN(v)) valEl.textContent = `${v}${rng.dataset.unit || "px"}`;
    };
    rng.addEventListener("input", () => {
      numInput.value = rng.value;
      syncVal();
      numInput.dispatchEvent(new Event("input", { bubbles: true }));
      numInput.dispatchEvent(new Event("change", { bubbles: true }));
    });
    numInput.addEventListener("input", () => {
      const v = parseFloat(numInput.value);
      syncVal();
      if (isNaN(v)) return;
      if (v >= mn && v <= mx) rng.value = v;
    });
    syncVal();
  });

  root.querySelectorAll("select[data-lsrole]").forEach((el) => {
    el.addEventListener("change", () => {
      App.assignLayerStyle(el.dataset.lsrole, el.value);
    });
  });

  root.querySelectorAll("[data-icon-link]").forEach((linkBtn) => {
    const row = linkBtn.closest(".linked-row");
    if (!row) return;
    const inputs = Array.from(row.querySelectorAll("input[data-key]"));
    if (inputs.length !== 2) return;
    const [left, right] = inputs;
    let mirroring = false;
    const sync = (src, dst) => {
      if (mirroring || !linkBtn.classList.contains("active")) return;
      mirroring = true;
      dst.value = src.value;
      dst.dispatchEvent(new Event("input", { bubbles: true }));
      dst.dispatchEvent(new Event("change", { bubbles: true }));
      setTimeout(() => { mirroring = false; }, 0);
    };
    left.addEventListener("change", () => sync(left, right));
    left.addEventListener("input", () => sync(left, right));
    right.addEventListener("change", () => sync(right, left));
    right.addEventListener("input", () => sync(right, left));
    linkBtn.addEventListener("click", () => {
      linkBtn.classList.toggle("active");
      linkBtn.title = linkBtn.classList.contains("active") ? "Constrain proportions" : "Link left/right values";
    });
    if (String(left.value) === String(right.value)) linkBtn.classList.add("active");
  });
}

function cssSelect(value) {
  return String(value).replace(/"/g, '\\"');
}

function debounce(fn, ms) {
  let t;
  return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}

/* the Canvas's right panel (All Pages, layers, more settings) folds to a thin bar, remembered */
App.typoSideMin = () => { try { return localStorage.getItem("psh.typoSideMin") !== "0"; } catch (e) { return true; } };
App.toggleTypoSide = () => {
  const studio = document.querySelector(".typo-studio");
  if (!studio) return;
  const min = !studio.classList.contains("side-min");
  studio.classList.toggle("side-min", min);
  try { localStorage.setItem("psh.typoSideMin", min ? "1" : "0"); } catch (e) { /* private window */ }
  window.dispatchEvent(new Event("resize"));
};

/* ------------------------------ fonts ------------------------------ */

/* Font styles like Photoshop's Font style menu: only the faces the font really has (read from the
   font files, /api/fonts faces). A saved PostScript name ("MyriadPro-Bold", read from a PSD) shows as
   its family + style. The older stored choices ("regular", "bold", lowercase) still mean what they
   did: the heading / a subheading drawn bold unless a face is picked. */
const _fcompact = (s) => String(s || "").toLowerCase().replace(/[^a-z0-9]+/g, "");
const LEGACY_STYLES = [["regular", "Regular"], ["bold", "Bold"], ["italic", "Italic"], ["bold italic", "Bold Italic"]];
App.fontFace = (name) => {
  const faces = App.state.fontFaces || {}, k = _fcompact(name);
  const fam = Object.keys(faces).find((f) => _fcompact(f) === k);
  if (fam) return { family: fam, style: "" };
  const a = (App.state.fontAliases || {})[k];
  return a ? { family: a[0], style: a[1] } : null;
};
// [[value, label]] for a font's style menu, and the value to show picked; forced = drawn bold by default
App.fontStyleChoices = (name, style, forced) => {
  const info = App.fontFace(name), styles = info && (App.state.fontFaces || {})[info.family];
  const cur = String(style || "");
  if (!styles || !styles.length) {
    const v = cur.toLowerCase() || "regular";
    return { opts: LEGACY_STYLES, value: LEGACY_STYLES.some(([o]) => o === v) ? v : "regular" };
  }
  const opts = styles.map((s) => [s, s]);
  const find = (want) => styles.find((s) => _fcompact(s) === _fcompact(want));
  let pick = "";
  if (cur && cur !== cur.toLowerCase()) pick = find(cur) || "";                 // a face picked from the menu
  if (!pick) {                                                                     // an older choice / a named face
    const legacy = cur.toLowerCase();
    let want = info.style && _fcompact(info.style) !== "regular" ? info.style
      : legacy === "bold italic" ? "Bold Italic" : legacy === "bold" ? "Bold" : legacy === "italic" ? "Italic"
        : forced ? "Bold" : "Regular";
    pick = find(want) || find("Regular") || styles[0];
  }
  return { opts, value: pick };
};
App.fontStyleHtml = (name, style, forced) => {
  const c = App.fontStyleChoices(name, style, forced);
  return c.opts.map(([v, l]) => `<option value="${esc(v)}" ${v === c.value ? "selected" : ""}>${esc(l)}</option>`).join("");
};
// a style menu (select[data-style-of="<font key>"]) refilled for its font; a style the new font lacks
// becomes the face it has (written back, so the Canvas and the build use it)
App.fillFontStyles = (sel) => {
  const fontKey = sel.dataset.styleOf, key = sel.dataset.key;
  if (!fontKey || !key) return;
  const forced = sel.dataset.forced === "1";
  const prev = App.get(key);
  sel.innerHTML = App.fontStyleHtml(App.get(fontKey), prev, forced);
  const c = App.fontStyleChoices(App.get(fontKey), prev, forced);
  if (String(prev || "") && String(prev) !== String(prev).toLowerCase() && c.value !== prev) { App.set(key, c.value); App.pushConfig(); }
};
document.addEventListener("change", (ev) => {
  const fsel = ev.target && ev.target.closest && ev.target.closest("select[data-font]");
  if (!fsel || !fsel.dataset.key) return;
  setTimeout(() => document.querySelectorAll(`select[data-style-of="${fsel.dataset.key}"]`).forEach((s) => App.fillFontStyles(s)), 0);
});

/* ------------------------------ config ------------------------------ */

App.get = (key) => {
  let v = App.state.config;
  for (const k of key.split(".")) v = v && v[k];
  return v ?? "";
};

App.set = (key, value) => {
  const parts = key.split(".");
  let v = App.state.config;
  for (let i = 0; i < parts.length - 1; i++) v = v[parts[i]] ?? (v[parts[i]] = {});
  v[parts.at(-1)] = value;
};

// Config saves are sent one after another (never out of order), and a preview can wait for
// the latest one with App.configSettled() instead of guessing with a longer delay.
App._cfgTimer = 0;
App._cfgChain = Promise.resolve();
App._saving = 0;
App._saveErr = "";
App.syncConfig = () => {
  clearTimeout(App._cfgTimer);
  App._cfgTimer = 0;
  _thumbWatch.seen.clear();                         // new settings: every sheet's picture may be redrawn
  App.histNote();
  App._saving++;
  App._cfgChain = App._cfgChain
    .then(() => api("/api/config", { method: "POST", body: App.state.config }))
    .then(() => { App._saveErr = ""; }, (e) => { App._saveErr = (e && e.message) || "error"; })
    .then(() => { App._saving--; App.histPaint(); });
  App.histPaint();
  return App._cfgChain;
};
App.pushConfig = () => {
  clearTimeout(App._cfgTimer);
  App._cfgTimer = setTimeout(App.syncConfig, 300);
  App.histPaint();
};
App.configSettled = () => (App._cfgTimer ? App.syncConfig() : App._cfgChain);

App.flushConfig = () => App.syncConfig();

/* Undo / redo for the Canvas. Every save is a step: the settings as they were at the save before.
   Where-you-are keys (files, game, picked sheets) are never part of a step, so an undo never takes
   you to another Excel or game. A change saved on another page drops the steps (undoing them
   would undo that change too). Loading other settings (a game, a scan) starts afresh. */
const HIST_KEEP = ["excel_path", "icon_folder", "output_dir", "output_name", "active_game", "active_market", "recent_projects",
  "ai_suggestions", "prev_psd_path", "selected_sheets", "symbol_tokens_known", "icon_mappings_by_excel"];
const HIST_ROUTES = ["typography", "assets", "tables", "visualiser-live"];
App.hist = { back: [], fwd: [], last: null, max: 80, restoring: false };
const histOf = (cfg) => {
  if (!cfg) return null;
  const c = Object.assign({}, cfg);
  HIST_KEEP.forEach((k) => delete c[k]);
  try { return JSON.stringify(c); } catch (e) { return null; }
};
App.histNote = () => {
  const H = App.hist, now = histOf(App.state.config);
  if (now === null || now === H.last) return;
  if (H.last !== null) {
    if (HIST_ROUTES.includes(App.route)) {
      H.back.push(H.last);
      if (H.back.length > H.max) H.back.shift();
    } else H.back = [];
    H.fwd = [];
  }
  H.last = now;
};
(() => {                                            // settings loaded from the server: a fresh start
  let cfg = App.state.config;
  Object.defineProperty(App.state, "config", {
    enumerable: true, configurable: true,
    get: () => cfg,
    set: (v) => {
      cfg = v;
      const H = App.hist;
      if (H.restoring) return;
      const now = histOf(v);
      if (now === H.last) return;
      H.back = []; H.fwd = []; H.last = now;
      App.histPaint();
    },
  });
})();
App.histGo = (dir) => {
  const H = App.hist;
  if (App._cfgTimer) App.syncConfig();              // the change still waiting to save is a step too
  else App.histNote();                             // and one changed without a save yet
  const from = dir < 0 ? H.back : H.fwd, to = dir < 0 ? H.fwd : H.back;
  if (!from.length || H.last === null) return false;
  const snap = from.pop();
  to.push(H.last);
  const cur = App.state.config || {}, next = JSON.parse(snap);
  HIST_KEEP.forEach((k) => { if (k in cur) next[k] = cur[k]; });
  H.restoring = true;
  App.state.config = next;
  H.restoring = false;
  H.last = snap;
  App.syncConfig();
  window.dispatchEvent(new CustomEvent("psh:history", { detail: { dir } }));
  return true;
};
App.undo = () => App.histGo(-1);
App.redo = () => App.histGo(1);

// the Canvas's ↶ ↷ buttons and its Saved / Saving… / Not saved mark
App.histPaint = () => {
  const H = App.hist;
  document.querySelectorAll("[data-hist]").forEach((b) => {
    const n = (b.dataset.hist === "undo" ? H.back : H.fwd).length;
    b.disabled = !n;
    b.title = (b.dataset.hist === "undo" ? "Undo (Ctrl+Z)" : "Redo (Ctrl+Shift+Z)") + (n ? ` — ${n} step${n > 1 ? "s" : ""}` : "");
  });
  const state = App._saveErr ? "error" : (App._cfgTimer || App._saving > 0) ? "saving" : "saved";
  document.querySelectorAll("[data-savemark]").forEach((m) => {
    m.dataset.state = state;
    m.textContent = state === "error" ? "⚠ Not saved — retry" : state === "saving" ? "Saving…" : "✓ Saved";
    m.title = state === "error" ? "Your last change did not reach the app: " + App._saveErr + ". Click to try again." : "";
  });
};
App.histBar = () => `
  <span class="hist-bar">
    <button class="pt-btn small" data-hist="undo" onclick="App.undo()" disabled>↶</button>
    <button class="pt-btn small" data-hist="redo" onclick="App.redo()" disabled>↷</button>
    <span class="save-mark" data-savemark data-state="saved" onclick="if (App._saveErr) App.syncConfig()">✓ Saved</span>
  </span>`;
document.addEventListener("keydown", (ev) => {
  if (!(ev.ctrlKey || ev.metaKey) || ev.altKey) return;
  const k = (ev.key || "").toLowerCase(), undo = k === "z" && !ev.shiftKey, redo = k === "y" || (k === "z" && ev.shiftKey);
  if (!undo && !redo) return;
  if (!["typography", "assets", "tables"].includes(App.route)) return;   // the Visualiser keeps its own keys
  const t = ev.target;
  const typing = t && (t.isContentEditable || t.tagName === "TEXTAREA"
    || (t.tagName === "INPUT" && !/^(checkbox|radio|range|color|button|submit)$/.test(t.type)));
  if (typing) return;                                                    // the field's own undo
  ev.preventDefault();
  App.histGo(undo ? -1 : 1);
});

App.refreshUI = () => {
  App.pushConfig();
  App._ptPreviewDirty = true;
  App.updatePreview();
};

App.updatePreview = () => {
  const c = App.state.config;
  document.querySelectorAll("[data-preview]").forEach((el) => {
    el.style.setProperty("--preview-hs", (c.h_size || 60) + "px");
    el.style.setProperty("--preview-bs", (c.b_size || 30) + "px");
    el.style.setProperty("--preview-ls", c.line_spacing || 1.1);
    el.style.setProperty("--preview-h", c.h_rgb || "#FFFFFF");
    el.style.setProperty("--preview-b", c.b_rgb || "#FFFFFF");
  });
  App.updateTablesPreview();
  App.updatePaytablePreview();
  if (window.AppTypoVis && (App.route === "typography" || App.route === "assets")) AppTypoVis.schedule();
  if (window.AppTblVis && App.route === "tables") AppTblVis.schedule();
  if (window.GRStudio && App.route === "gamerules") GRStudio.schedule();
  if (window.BRStudio && App.route === "bingorules") BRStudio.schedule();
  if (App._ptPreviewDirty) {
    App._ptPreviewDirty = false;
    App.ptmRefreshPreview();
  }
};

App.updatePaytablePreview = () => {
  const d = App.state.config.dynamic_settings || {};
  const mock = document.getElementById("ptMock");
  if (!mock) return;
  mock.style.setProperty("--pt-count-size", (parseFloat(d.count_size) || 38) + "px");
  mock.style.setProperty("--pt-count-color", ptCssColor(d.count_rgb, "#FFAF37"));
  mock.style.setProperty("--pt-value-size", (parseFloat(d.value_size) || 42) + "px");
  mock.style.setProperty("--pt-value-color", ptCssColor(d.value_rgb, "#F5F7FA"));
  mock.style.setProperty("--pt-notes-size", (parseFloat(d.notes_text_size) || 22) + "px");
  mock.style.setProperty("--pt-notes-color", ptCssColor(d.notes_text_rgb, "#9AA4B2"));
};

App.ptmRefreshPreview = debounce(async () => {
  const path = (App.get("dynamic_settings.template_json") || "").trim();
  if (!path || App.route !== "paytable" || App.state.config.dynamic_settings?.preview_suspended || App.state.ptmUserPicked) return;
  const badge = document.getElementById("ptRenderBadge");
  if (badge) badge.classList.add("on");
  try {
    const d = await api("/api/paytable_mapper/preview", { method: "POST", body: { path } });
    if (!d.ok) return;
    if (d.preview_token && d.preview_token !== App.state.paytablePreviewToken) {
      App.state.paytablePreviewToken = d.preview_token;
      const img = document.getElementById("ptPreviewImg");
      if (img) img.src = "/api/table_preview/" + encodeURIComponent(d.preview_token) + "?v=" + Date.now();
    }
    if (typeof d.slots_total === "number") {
      App.state.paytableStats = { total: d.slots_total, mapped: d.slots_mapped || 0, at: Date.now() };
      App.updatePaytableStats();
    }
  } catch (e) { /* non-fatal */ }
  if (badge) badge.classList.remove("on");
}, 450);

App.updatePaytableStats = () => {
  const el = document.getElementById("ptStats");
  if (!el) return;
  el.innerHTML = ptStatsHtml();
};

App.updateTablesPreview = () => {
  const el = document.querySelector("[data-tables-preview]");
  if (!el) return;
  const ts = App.state.config.table_style || {};
  const fmt = (v, fb) => {
    if (v == null) return fb;
    if (Array.isArray(v)) return `rgb(${v[0]}, ${v[1]}, ${v[2]})`;
    const s = String(v);
    if (/^#?[0-9a-fA-F]{6}$/.test(s)) return "#" + s.replace(/^#/, "");
    return fb;
  };
  const headerBg = fmt(ts.header_bg_rgb, "rgb(46, 54, 78)");
  const row1 = fmt(ts.row1_bg_rgb, "rgb(21, 26, 36)");
  const row2 = fmt(ts.row2_bg_rgb, "rgb(28, 34, 48)");
  const stroke = fmt(ts.stroke_rgb, "rgb(43, 51, 70)");
  const hText = fmt(ts.header_text_rgb, "#F5F7FA");
  const bText = fmt(ts.table_body_text_rgb, "#9AA4B2");
  const sw = Math.max(0, parseInt(ts.stroke_width, 10) || 0);
  const strokeW = sw + "px";
  const gapPx = Math.max(0, parseInt(ts.row_gap, 10) || 0);
  const gap = gapPx + "px";
  const hfs = (parseInt(ts.table_header_font_size, 10) || 24) + "px";
  const bfs = (parseInt(ts.table_body_font_size, 10) || 18) + "px";
  const rows = [
    { head: true, bg: headerBg, color: hText, size: hfs, cells: ["Symbol", "Payout", "Value"] },
    { bg: row1, color: bText, size: bfs, cells: ["🟡", "Major", "500"] },
    { bg: row2, color: bText, size: bfs, cells: ["🟢", "Minor", "100"] },
    { bg: row1, color: bText, size: bfs, cells: ["🔴", "Mini", "50"] },
  ];
  const lastRow = rows.length - 1;
  const cellBorder = (isLastCol, isLastRow) => {
    if (!sw) return "";
    const b = [];
    if (!isLastCol) b.push(`border-right:${strokeW} solid ${stroke}`);
    if (!isLastRow) b.push(`border-bottom:${strokeW} solid ${stroke}`);
    return b.join(";");
  };
  el.className = "tbl-preview" + (sw ? "" : " no-stroke");
  el.innerHTML = `
    <div class="tbl-preview-box" style="${sw ? `border:${strokeW} solid ${stroke};` : ""}">
      ${rows.map((r, ri) => {
        return `<div class="tbl-pv-row${r.head ? " tbl-pv-head" : ""}" style="background:${r.bg}; color:${r.color}; font-size:${r.size};${ri > 0 ? ` margin-top:${gap};` : ""}">
          ${r.cells.map((c, ci) => `<span class="tbl-pv-cell" style="${cellBorder(ci === r.cells.length - 1, ri === lastRow)}">${c}</span>`).join("")}
        </div>`;
      }).join("")}
    </div>`;
};

App.resetTables = () => {
  const d = {
    header_bg_rgb: [46, 54, 78], row1_bg_rgb: [21, 26, 36], row2_bg_rgb: [28, 34, 48],
    stroke_rgb: [43, 51, 70], header_text_rgb: [245, 247, 250], table_body_text_rgb: [154, 164, 178],
    stroke_width: 2, row_gap: 10, table_header_font_size: 24, table_body_font_size: 18,
    overlay_opacity: 100,
  };
  const cur = App.state.config.table_style || {};
  App.set("table_style", { ...cur, ...d });
  App.refreshUI();
  renderRoute();
  toast("Table style reset to defaults.");
};

/* ------------------------------ browse ------------------------------ */

App._focusedKey = "";

App.browse = async (key, kind) => {
  const native = window.pywebview?.api;
  if (native) {
    try {
      const path = kind === "dir"
        ? await native.browse_folder()
        : await native.browse_file(kind === "excel" ? "excel" : (kind === "json" ? "json" : (kind === "psd" ? "psd" : "file")));
      if (path) {
        App.set(key, path);
        if (key === "excel_path" || key === "icon_folder") {
          if (!document.getElementById("updateOverlay").hidden) App.renderUpdateDialog();
          App.scan();
          return;
        }
        App.refreshUI();
        renderRoute();
        toast("Path set: " + path);
        if (key === "bg_path") App.askBgMode();
        if (!document.getElementById("bgOverlay").hidden) App.renderBackgroundDialog();
        if (!document.getElementById("outputOverlay").hidden) App.renderOutputDialog();
        if (!document.getElementById("updateOverlay").hidden) App.renderUpdateDialog();
        return;
      }
      toast("No file selected — pick a file or close the dialog.", "err");
      return;
    } catch (e) { /* fall through to browser pickers */ }
  }
  {
    const picked = await App.serverPick(kind);
    if (picked) {
      App.set(key, picked);
      if (key === "excel_path" || key === "icon_folder") { App.scan(); return; }
      App.refreshUI();
      renderRoute();
      toast("Path set: " + picked);
      if (key === "bg_path") App.askBgMode();
      return;
    }
    if (picked === "") return;                 // dialog cancelled
  }
  try {
    if (kind === "excel") {
      const handle = await window.showOpenFilePicker({ types: [{ description: "Excel", accept: { "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": [".xlsx", ".xlsm"] } }] });
      App.set(key, handle[0].name);
    } else if (kind === "json") {
      const handle = await window.showOpenFilePicker({ types: [{ description: "JSON", accept: { "application/json": [".json"] } }] });
      App.set(key, handle[0].name);
    } else if (kind === "psd") {
      const handle = await window.showOpenFilePicker({ types: [{ description: "Photoshop", accept: { "image/vnd.adobe.photoshop": [".psd", ".psb"] } }] });
      App.set(key, handle[0].name);
    } else {
      const handle = await window.showOpenFilePicker();
      App.set(key, handle[0].name);
    }
    App.refreshUI();
    renderRoute();
    toast("Path selection limited in browser — please paste the full path into the field.", "err");
  } catch (e) {
    if (e.name !== "AbortError") {
      toast("Paste the full folder path into the field (browser path picker unavailable).", "err");
    }
  }
};

window.__nativeDrop = (paths) => {
  if (!paths || !paths.length) return;
  const target = App._focusedKey || "excel_path";
  App.set(target, paths[0]);
  if (target === "excel_path" || target === "icon_folder") { App.scan(); return; }
  App.refreshUI();
  renderRoute();
  toast("Dropped: " + paths[0]);
};

/* ------------------------------ router ------------------------------ */

const ROUTES = ["dashboard", "project", "typography", "assets", "render"];
// the old sections (Tables, Paytable & Layouts, Game / Bingo Rules, Paylines, Visualiser) are gone:
// every page is edited on the Canvas — an old link to one opens the Canvas
const OLD_ROUTES = ["tables", "paytable", "gamerules", "bingorules", "paylines", "visualiser-live"];

function parseHash() {
  const h = location.hash.replace(/^#\/?/, "") || "dashboard";
  if (OLD_ROUTES.includes(h)) { history.replaceState(null, "", "#/typography"); return "typography"; }
  return ROUTES.includes(h) ? h : "dashboard";
}

function navigate(route) {
  location.hash = "#/" + route;
}

window.addEventListener("hashchange", renderRoute);

function renderRoute() {
  const prevRoute = App.route;
  App.route = parseHash();
  document.querySelectorAll(".nav-item[data-route]").forEach((b) => {
    b.classList.toggle("active", b.dataset.route === App.route);
  });
  const ws = document.getElementById("workspace");
  const views = {
    dashboard: viewDashboard, wizard: viewWizard, project: viewProject, typography: viewTypography,
    assets: viewAssets, tables: viewTables,
    paytable: () => (window.PaytableCards && !App.state.ptAdvanced ? PaytableCards.view() : viewPaytable()),
        gamerules: viewGameRules, bingorules: viewBingoRules, render: viewRender,
    paylines: () => (window.Paylines ? Paylines.view() : `<div class="empty" style="padding:60px"><div class="empty-title">Paylines addon not loaded</div></div>`),
    "visualiser-live": () => (window.AppLive ? AppLive.view() : `<div class="empty" style="padding:60px"><div class="empty-icon">⚠</div><div class="empty-title">Visualiser addon not loaded</div></div>`),
  };
  ws.innerHTML = views[App.route]();
  const view = ws.querySelector(".view");
  if (view && App.route === prevRoute) view.classList.add("no-anim");
  bindForms(ws);
  watchThumbs();
  if (["paytable", "visualiser-live", "gamerules", "render", "typography"].includes(App.route)) {
    setTimeout(() => App.ensureGameName(), 400);
  }
  if (App.route === "wizard") {
    setTimeout(App.wizInit, 0);
  }
  if (App.route === "dashboard" && App.loadGames) {
    setTimeout(App.loadGames, 0);
  }
  if (App.route === "render") {
    setTimeout(App.renderPreflightCard, 0);
  }
  if (App.route === "gamerules") {
    if (window.GRStudio) setTimeout(GRStudio.init, 0);
    else { setTimeout(App.grInitStudio, 0); setTimeout(App.grRefreshPreview, 0); }
  }
  if (App.route === "bingorules") {
    if (window.BRStudio) setTimeout(BRStudio.init, 0);
    else { setTimeout(App.bgrInitStudio, 0); setTimeout(App.bgrRefreshPreview, 0); }
  }
  if (App.route === "paylines" && window.Paylines) {
    setTimeout(Paylines.init, 0);
  }
  if (App.route === "paytable" && window.PaytableCards && !App.state.ptAdvanced) {
    setTimeout(PaytableCards.init, 0);
  } else if (App.route === "paytable") {
    setTimeout(App.ptmSyncView, 0);
  }
  if (App.route === "visualiser-live") {
    setTimeout(() => { if (window.AppLive) AppLive.initRoute(); }, 0);
  }
  if (App.route === "typography" || App.route === "assets") {
    setTimeout(() => { if (window.AppTypoVis) AppTypoVis.init(); if (window.TypoStudio && App.route === "typography") TypoStudio.paint(); }, 0);
  }
  if (App.route === "tables") {
    setTimeout(() => { if (window.AppTblVis) AppTblVis.init(); if (window.TableDesigns) TableDesigns.load(); }, 0);
  }
  App.updatePreview();
  App.renderProperties();
  ws.scrollTop = 0;
}

/* ------------------------------ property panel ------------------------------ */

App.properties = [];

App.renderProperties = () => {
  const appEl = document.getElementById("app");
  const body = document.getElementById("propertiesBody");
  const titleEl = document.getElementById("propertiesTitle");
  // the slot drawer belongs to the Advanced slot editor, not the card studio
  if (App.route !== "paytable" || (window.PaytableCards && !App.state.ptAdvanced)) {
    if (appEl) appEl.classList.add("no-props");
    return;
  }
  if (appEl) appEl.classList.remove("no-props");
  if (titleEl) titleEl.textContent = "Slot Properties";
  const pm = App.paytableMapper;
  let html = "";
  if (pm && pm.template) {
    if (!App.properties.length) {
      html += `<div class="empty"><div class="empty-title">No slot selected</div><div class="empty-sub">Click a slot on the preview or in the list below.</div></div>`;
    } else {
      for (const p of App.properties) {
        if (p.type === "section") {
          html += `<div class="collapse ${p.open ? "open" : ""}">
            <button class="collapse-head" onclick="this.parentElement.classList.toggle('open')">${esc(p.title)} ${icon("chevron")}</button>
            <div class="collapse-body">${p.body}</div></div>`;
        } else {
          html += p.body;
        }
      }
    }
  } else {
    html += `<div class="empty"><div class="empty-icon">◫</div><div class="empty-title">Slot Properties</div><div class="empty-sub">Load the paytable to see per-slot controls — pick a slot on the preview or in the list to edit its Excel cell, symbol, font, color and fill.</div></div>`;
  }
  html += App.propsDataHTML();
  body.innerHTML = html;
  bindForms(body);
  App.propsInitResize();
  setTimeout(App.ptmRenderSheetData, 0);
  setTimeout(App.ptmSyncSheetDataFoot, 0);
  App.updatePreview();
};

App.propsDataHTML = () => `
  <div class="pt-props-data">
    <div class="pt-props-data-head">Excel data</div>
    <div class="ptm-data-tools">
      <input type="search" id="ptmDataFilter" placeholder="Filter rows…" oninput="App.ptmRenderSheetData()" />
    </div>
    <div class="ptm-data-list" id="ptmDataList"></div>
    <div class="ptm-data-foot">
      <div id="ptmDataStatus">Click a slot in the preview to select it, then pick rows.</div>
      <div style="display:flex;gap:6px;margin-top:8px">
        <button class="pt-btn primary small" id="ptmDataApply" onclick="App.ptmApplySheetData()">Pick a slot first</button>
        <button class="pt-btn secondary small" onclick="App.ptmClearSheetData()">Clear pick</button>
      </div>
    </div>
  </div>`;

App.propsInitResize = () => {
  const panel = document.getElementById("propertiesPanel");
  const handle = document.getElementById("propertiesResize");
  if (!panel || !handle || panel._propsResizeInit) return;
  panel._propsResizeInit = true;
  const clamp = (w) => Math.min(Math.max(w, 240), Math.round(window.innerWidth * 0.6));
  try {
    const saved = parseInt(localStorage.getItem("psh.propsW") || "", 10);
    if (saved > 0) document.documentElement.style.setProperty("--props-w", clamp(saved) + "px");
  } catch (e) { /* ignore */ }
  handle.addEventListener("pointerdown", (ev) => {
    ev.preventDefault();
    try { handle.setPointerCapture(ev.pointerId); } catch (e) { /* ignore */ }
    const startX = ev.clientX;
    const startW = panel.getBoundingClientRect().width;
    let raf = 0;
    const move = (e) => {
      const w = clamp(startW + startX - e.clientX);
      if (raf) cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        document.documentElement.style.setProperty("--props-w", w + "px");
      });
    };
    const up = () => {
      if (raf) cancelAnimationFrame(raf);
      handle.removeEventListener("pointermove", move);
      handle.removeEventListener("pointerup", up);
      handle.removeEventListener("pointercancel", up);
      try { handle.releasePointerCapture(ev.pointerId); } catch (err) { /* ignore */ }
      try {
        const w = clamp(panel.getBoundingClientRect().width);
        document.documentElement.style.setProperty("--props-w", w + "px");
        localStorage.setItem("psh.propsW", String(w));
      } catch (err) { /* ignore */ }
    };
    handle.addEventListener("pointermove", move);
    handle.addEventListener("pointerup", up);
    handle.addEventListener("pointercancel", up);
  });
};

function propsControls(spec) {
  let html = "";
  for (const item of spec) {
    if (item.type === "section") {
      html += `<div class="collapse ${item.open ? "open" : ""}">
        <button class="collapse-head" onclick="this.parentElement.classList.toggle('open')">${esc(item.title)} ${icon("chevron")}</button>
        <div class="collapse-body">${item.body}</div></div>`;
    } else {
      html += item.body;
    }
  }
  App.properties = [{ type: "raw", body: html }];
}

/* ------------------------------ views ------------------------------ */

function viewDashboard() {
  const recents = App.state.config.recent_projects || [];
  const recent = recents.length ? `
    <div class="db-recents">
      <div class="db-recents-label">Recent Projects</div>
      <div class="db-recents-row">${recents.map((r) => `
        <button class="db-recent" onclick="App.reopenProject('${jsStr(r.folder)}')">
          <span class="db-recent-name">${esc(r.name || "Project")}</span>
          <span class="db-recent-meta">${esc(r.opened_at || "")}</span>
        </button>`).join("")}
      </div>
    </div>` : "";
  // the things you start from (2 × 2), then the recent games (Guided Setup stays in the sidebar).
  // Updating a tool-made PSD starts from its market in Recent games (Update PSD shows when its Excel changed).
  return `
    <div class="view db-view">
      <div class="db-actions db-actions-grid">
        <button class="db-action" onclick="App.openProjectDialog('create')">
          <span class="db-action-icon">${icon("plus")}</span>
          <span class="db-action-title">Create New PSD</span>
          <span class="db-action-sub">Create a new Photoshop document from a game folder.</span>
        </button>
        <button class="db-action" onclick="App.openPsdProject()">
          <span class="db-action-icon">${icon("file")}</span>
          <span class="db-action-title">Open a PSD</span>
          <span class="db-action-sub">Pick any PSD made by this tool — its settings, templates, Excel and layer links are stored inside it, so everything comes back.</span>
        </button>
        <button class="db-action" onclick="MarketClone.open()">
          <span class="db-action-icon">${icon("file")}</span>
          <span class="db-action-title">Update Artist Made PSD</span>
          <span class="db-action-sub">The artist's PSD with an updated Excel, or another market's — only the text and icons that changed are touched, the design stays as the artist made it.</span>
        </button>
        <button class="db-action" onclick="SymExport.open()">
          <span class="db-action-icon">${icon("image")}</span>
          <span class="db-action-title">Export Symbols</span>
          <span class="db-action-sub">Pull icons out of a PSD — preview every layer and smart object, pick any, export trimmed transparent PNGs.</span>
        </button>
      </div>
      ${App.gamesSection ? App.gamesSection() : ""}
      ${recent}
    </div>`;
}

/* ------------------------------ guided wizard ------------------------------ */
/* Additive artist happy-path: pick a page type -> point at Excel -> auto-detect
   (zero-map) -> live preview + curated tweaks -> preflight + export. Every step
   reuses an existing endpoint; no engine/render code is duplicated here. */

const WIZ_TYPES = [
  { key: "paytable",    title: "Paytable",    icon: "image", sub: "Symbols and payouts — auto-mapped straight from your sheet, no manual wiring." },
  { key: "game_rules",  title: "Game Rules",  icon: "file",  sub: "Rules / legal text page, rendered with the real PNG engine." },
  { key: "bingo_rules", title: "Bingo Rules", icon: "file",  sub: "Bingo rules page, rendered with the real PNG engine." },
];

// Curated live-tweak sliders per page type — every key is one the renderers
// already consume (reused verbatim from the GR / Bingo studios), so no slider
// is a silent no-op.
const WIZ_TWEAKS = {
  game_rules: [
    { key: "dynamic_settings.game_rules_bottom_lr_margin", label: "Side margin",      min: 0, max: 800, step: 5 },
    { key: "dynamic_settings.game_rules_line_height",      label: "Line height",      min: 0, max: 160, step: 2 },
    { key: "dynamic_settings.game_rules_bottom_font_size", label: "Legal text size",  min: 8, max: 120, step: 1 },
    { key: "dynamic_settings.game_rules_separator_margin", label: "Separator margin", min: 0, max: 400, step: 5 },
  ],
  bingo_rules: [
    { key: "dynamic_settings.bingo_rules_body_size",     label: "Body size",     min: 0, max: 250, step: 1 },
    { key: "dynamic_settings.bingo_rules_left_margin",   label: "Side margin",   min: 0, max: 500, step: 5 },
    { key: "dynamic_settings.bingo_rules_line_spacing",  label: "Line spacing",  min: 0, max: 200, step: 2 },
    { key: "dynamic_settings.bingo_rules_bottom_margin", label: "Bottom margin", min: 0, max: 500, step: 5 },
  ],
};

App.wizard = { step: 1, maxStep: 1, pageType: "", sheet: "", previewToken: "", mapped: 0, unmapped: [], warnings: [] };

App.wizTypeLabel = () => (WIZ_TYPES.find((t) => t.key === App.wizard.pageType) || {}).title || "page";

App.wizMatchingSheets = () => {
  const sheets = App.state.scan?.excel?.sheets || [];
  const t = App.wizard.pageType;
  if (!t) return [];
  return sheets.filter((s) => (s.type || "page") === t).map((s) => s.name).filter(Boolean);
};

function viewWizard() {
  const w = App.wizard;
  const steps = ["Page type", "Point at Excel", "Detect & preview", "Export"];
  const strip = steps.map((label, i) => {
    const n = i + 1;
    const cls = n === w.step ? "active" : (n < w.step ? "done" : "");
    const disabled = n > (w.maxStep || 1) ? "disabled" : "";
    return `<button class="wiz-step ${cls}" ${disabled} onclick="App.wizGo(${n})">
      <span class="wiz-step-n">${n < w.step ? "✓" : n}</span><span class="wiz-step-label">${esc(label)}</span></button>`;
  }).join('<span class="wiz-step-sep"></span>');
  return `
    <div class="view wiz-view">
      <div class="view-header">
        <div class="view-title">Guided Setup</div>
        <div class="view-sub">Build a page in four steps — no manual mapping, with a live preview you can tweak before export.</div>
      </div>
      <div class="wiz-strip">${strip}</div>
      <div class="wiz-body" id="wizBody"></div>
    </div>`;
}

App.wizStepHTML = () => {
  const w = App.wizard;
  if (w.step === 1) {
    return `
      <div class="wiz-types">
        ${WIZ_TYPES.map((t) => `
          <button class="wiz-type ${w.pageType === t.key ? "sel" : ""}" onclick="App.wizPickType('${t.key}')">
            <span class="wiz-type-icon">${icon(t.icon)}</span>
            <span class="wiz-type-title">${esc(t.title)}</span>
            <span class="wiz-type-sub">${esc(t.sub)}</span>
          </button>`).join("")}
      </div>
      <div class="wiz-nav"><span></span>
        <button class="btn primary" ${w.pageType ? "" : "disabled"} onclick="App.wizGo(2)">Next →</button>
      </div>`;
  }
  if (w.step === 2) {
    const c = App.state.config;
    const has = !!c.excel_path;
    const scan = App.state.scan;
    const matches = App.wizMatchingSheets();
    const label = App.wizTypeLabel();
    let status;
    if (has && scan && scan.excel) {
      const total = (scan.excel.sheets || []).length;
      status = `<div class="wiz-scan-status ${matches.length ? "ok" : "warn"}">
        <span class="pf-mark">${matches.length ? "✓" : "⚠"}</span>
        <span>${total} sheet(s) in the workbook · <b>${matches.length}</b> ${esc(label)} sheet(s) detected${matches.length ? ": " + matches.map(esc).join(", ") : " — pick another page type, or any sheet on the next step"}.</span>
      </div>`;
    } else {
      status = `<div class="hint">Choose your workbook to continue — scanning happens automatically.</div>`;
    }
    return `
      <div class="wiz-panel">
        ${assetField("excel_path", "Excel workbook", { placeholder: "Paste the .xlsx path or Browse…", kind: "excel", hint: "We'll scan it and find your " + esc(label) + " sheets automatically." })}
        ${status}
      </div>
      <div class="wiz-nav">
        <button class="btn secondary" onclick="App.wizGo(1)">← Back</button>
        <button class="btn primary" ${matches.length ? "" : "disabled"} onclick="App.wizGo(3)">Next →</button>
      </div>`;
  }
  if (w.step === 3) {
    const isPt = w.pageType === "paytable";
    const tweaks = WIZ_TWEAKS[w.pageType] || [];
    const matches = App.wizMatchingSheets();
    const cur = w.sheet || matches[0] || "";
    return `
      <div class="wiz-detect-grid">
        <div class="wiz-controls">
          <div class="field"><label>Sheet</label>
            <select id="wizSheet" onchange="App.wizSheetChange(this.value)">
              ${matches.map((n) => `<option value="${esc(n)}" ${n === cur ? "selected" : ""}>${esc(n)}</option>`).join("") || `<option value="">No ${esc(App.wizTypeLabel())} sheet found</option>`}
            </select>
          </div>
          ${isPt
            ? `<div class="wiz-report" id="wizReport"><div class="hint">Auto-mapping…</div></div>`
            : `<div class="wiz-tweaks">
                <div class="wiz-tweaks-head">Quick tweaks</div>
                ${tweaks.map((t) => field(t.key, t.label, { type: "number", slider: true, min: t.min, max: t.max, step: t.step })).join("")}
                <div class="hint">Drag a slider — the preview re-renders live (Photoshop-free).</div>
              </div>`}
          <div style="margin-top:12px"><button class="pt-btn secondary small" onclick="App.wizRender(${isPt})">${icon("play")} Refresh preview</button></div>
        </div>
        <div class="wiz-preview">
          <div class="pt-card-title" style="margin-bottom:8px"><span class="pt-chip">${icon("image")}</span><span>Live Preview</span><span class="pt-pill idle" id="wizRenderBadge">Rendering…</span></div>
          <div class="pt-preview-wrap wiz-preview-wrap" id="wizPreviewCanvas">
            ${w.previewToken
              ? `<img id="wizPreviewImg" class="pt-preview-img" src="/api/table_preview/${encodeURIComponent(w.previewToken)}" alt="preview"/>`
              : `<div class="empty" style="padding:48px"><div class="empty-icon">▤</div><div class="empty-title">Preview pending</div><div class="empty-sub">Detecting your page…</div></div>`}
          </div>
        </div>
      </div>
      <div class="wiz-nav">
        <button class="btn secondary" onclick="App.wizGo(2)">← Back</button>
        <button class="btn primary" onclick="App.wizGo(4)">Next →</button>
      </div>`;
  }
  // step 4 — export
  return `
    <div class="wiz-panel">
      <div class="wiz-preflight" id="wizPreflight"><div class="hint">Running pre-build checks…</div></div>
      ${field("png_suffix", "PNG suffix (optional)", { type: "text", placeholder: "empty = sheet name (Paytable.png)" })}
      <div class="btn-row" style="margin-top:10px">
        <button class="btn secondary large" onclick="App.startBuild('psd')">${icon("file")} Build PSD</button>
        <button class="btn secondary large" onclick="App.startBuild('png')">${icon("image")} Build PNG</button>
        <button class="btn primary large" onclick="App.startBuild('both')">${icon("play")} Build Both</button>
      </div>
      <div class="hint" style="margin-top:10px">Photoshop must be open for PSD builds. PNG builds are pure Python (no Photoshop needed).</div>
    </div>
    <div class="wiz-nav"><button class="btn secondary" onclick="App.wizGo(3)">← Back</button><span></span></div>`;
};

App.wizGo = (step) => {
  const w = App.wizard;
  step = Math.max(1, Math.min(4, step));
  if (step > (w.maxStep || 1) && step > w.step + 0) { /* only advance one gate at a time via Next; clicks on disabled are no-ops */ }
  w.step = step;
  w.maxStep = Math.max(w.maxStep || 1, step);
  const ws = document.getElementById("workspace");
  ws.innerHTML = viewWizard();
  bindForms(ws);
  App.wizInit();
  ws.scrollTop = 0;
};

App.wizInit = () => {
  const w = App.wizard;
  const body = document.getElementById("wizBody");
  if (!body) return;
  body.innerHTML = App.wizStepHTML();
  bindForms(body);
  if (w.step === 3) {
    if (!w.sheet) {
      const matches = App.wizMatchingSheets();
      if (matches.length) {
        w.sheet = matches[0];
        App.state.config.selected_sheets = [w.sheet];
        App.pushConfig();
      }
    }
    // Mirror grInitStudio: tweak inputs live-refresh the preview (GR / Bingo).
    if (w.pageType !== "paytable") {
      body.querySelectorAll("[data-key]").forEach((el) => {
        if (!["INPUT", "SELECT", "TEXTAREA"].includes(el.tagName)) return;
        el.addEventListener("input", () => App.wizRender(false));
        el.addEventListener("change", () => App.wizRender(false));
      });
    }
    setTimeout(() => App.wizRender(w.pageType === "paytable"), 0);
  }
  if (w.step === 4) {
    setTimeout(() => App.renderPreflightInto("wizPreflight"), 0);
  }
};

App.wizPickType = (key) => {
  const w = App.wizard;
  if (w.pageType !== key) {
    w.pageType = key;
    w.sheet = "";
    w.previewToken = "";
    w.mapped = 0;
    w.unmapped = [];
    w.warnings = [];
  }
  App.wizGo(2);
};

App.wizSheetChange = (v) => {
  const w = App.wizard;
  w.sheet = v;
  w.previewToken = "";
  App.state.config.selected_sheets = v ? [v] : [];
  App.pushConfig();
  App.wizRender(w.pageType === "paytable");
};

App.wizRenderReport = () => {
  const el = document.getElementById("wizReport");
  if (!el) return;
  const w = App.wizard;
  const warn = w.warnings || [];
  el.innerHTML = `<div class="wiz-report-head">${w.mapped || 0} field(s) auto-mapped</div>` +
    (warn.length
      ? warn.map((x) => `<div class="pf-item warning"><span class="pf-mark">⚠</span><div class="pf-text"><div class="pf-msg">${esc(x)}</div></div></div>`).join("")
      : `<div class="pf-ok"><span class="pf-mark">✓</span> Everything matched.</div>`);
};

App.wizRender = debounce(async (remap) => {
  const w = App.wizard;
  const canvas = document.getElementById("wizPreviewCanvas");
  if (!canvas || !w.sheet) return;
  const badge = document.getElementById("wizRenderBadge");
  if (badge) badge.classList.remove("idle");
  try {
    let token = "";
    if (w.pageType === "paytable") {
      const d = await api("/api/auto_page", { method: "POST", body: { sheet_name: w.sheet, layout_name: "" } });
      token = d.preview_token || "";
      w.mapped = d.mapped || 0;
      w.unmapped = d.unmapped || [];
      w.warnings = d.warnings || [];
      if (d.config) App.state.config = d.config;
      App.wizRenderReport();
    } else if (w.pageType === "game_rules") {
      App.state.grSheetName = w.sheet;
      const d = await api("/api/game_rules/preview", { method: "POST", body: { sheet_name: w.sheet } });
      token = d.ok ? (d.preview_token || "") : "";
      if (!d.ok && d.error) toast(d.error, "warn");
    } else if (w.pageType === "bingo_rules") {
      App.state.bgrSheetName = w.sheet;
      const d = await api("/api/bingo_rules/preview", { method: "POST", body: { sheet_name: w.sheet } });
      token = d.ok ? (d.preview_token || "") : "";
      if (!d.ok && d.error) toast(d.error, "warn");
    }
    if (token) {
      w.previewToken = token;
      const img = document.getElementById("wizPreviewImg");
      if (img) img.src = "/api/table_preview/" + encodeURIComponent(token) + "?v=" + Date.now();
      else canvas.innerHTML = `<img id="wizPreviewImg" class="pt-preview-img" src="/api/table_preview/${encodeURIComponent(token)}" alt="preview"/>`;
    }
  } catch (e) {
    toast(e.message || "Preview failed", "err");
  }
  if (badge) badge.classList.add("idle");
}, 450);

/* ------------------------------ preflight ------------------------------ */

App.runPreflight = async () => {
  try {
    return await api("/api/preflight", { method: "POST", body: { config: App.state.config } });
  } catch (e) {
    return null;
  }
};

App.preflightItemHTML = (item, kind) => `
  <div class="pf-item ${kind}">
    <span class="pf-mark">${kind === "blocking" ? "✕" : "⚠"}</span>
    <div class="pf-text"><div class="pf-msg">${esc(item.message)}</div>${item.fix ? `<div class="pf-fix">${esc(item.fix)}</div>` : ""}</div>
  </div>`;

App.preflightGroupsHTML = (pf) => {
  const b = pf.blocking || [], w = pf.warnings || [];
  return (b.length ? `<div class="pf-group"><div class="pf-group-head err">Must fix (${b.length})</div>${b.map((i) => App.preflightItemHTML(i, "blocking")).join("")}</div>` : "") +
    (w.length ? `<div class="pf-group"><div class="pf-group-head warn">Warnings (${w.length})</div>${w.map((i) => App.preflightItemHTML(i, "warning")).join("")}</div>` : "");
};

App.renderPreflightInto = async (elId) => {
  const el = document.getElementById(elId);
  if (!el) return;
  const pf = await App.runPreflight();
  if (!pf) { el.innerHTML = `<div class="hint">Could not run pre-build checks.</div>`; return; }
  if (!(pf.blocking || []).length && !(pf.warnings || []).length) {
    el.innerHTML = `<div class="pf-ok"><span class="pf-mark">✓</span> All checks passed — ready to build.</div>`;
    return;
  }
  el.innerHTML = App.preflightGroupsHTML(pf);
};

App.renderPreflightCard = () => App.renderPreflightInto("preflightCard");

App.closePreflightDialog = () => {
  const o = document.getElementById("preflightOverlay");
  if (o) o.hidden = true;
};

App.showPreflightDialog = (pf, mode) => {
  const overlay = document.getElementById("preflightOverlay");
  const b = pf.blocking || [], w = pf.warnings || [];
  if (!overlay) {
    // Modal missing — fall back to safe behavior: block on errors, else proceed.
    if (b.length) { toast(b[0].message || "Build blocked by pre-build checks.", "err"); }
    else { App._preflightCleared = true; App.startBuild(mode); }
    return;
  }
  const titleEl = document.getElementById("pfTitle");
  if (titleEl) titleEl.textContent = b.length ? "Fix these before building" : "Before you build";
  document.getElementById("pfBody").innerHTML = App.preflightGroupsHTML(pf);
  const go = document.getElementById("pfProceed");
  if (go) {
    if (b.length) {
      go.style.display = "none";
    } else {
      go.style.display = "";
      go.textContent = "Build anyway";
      go.onclick = () => { App.closePreflightDialog(); App._preflightCleared = true; App.startBuild(mode); };
    }
  }
  overlay.hidden = false;
};

/* ------------------------------ project dialog ------------------------------ */

const PJ_MODES = {
  create: { title: "Create New PSD", sub: "Select a game folder to get started — we'll detect the Excel, icons, background and output automatically.", footer: "Continue" },
  update: { title: "Update PSD", sub: "Select a game folder — we'll find the project and its existing PSDs.", footer: "Continue" },
  export: { title: "Export PNGs", sub: "Select a game folder — we'll find its pages and output folder.", footer: "Export PNGs" },
};

App._pj = { mode: "create", folder: "", discovery: null, excelPick: "", psdPick: "", pages: [], projectFile: "" };
App._pjManifest = null;
App._pjInfo = null;

App.openProjectDialog = (mode) => {
  App._pj = { mode: PJ_MODES[mode] ? mode : "create", folder: "", discovery: null, excelPick: "", psdPick: "", pages: [], projectFile: "" };
  const overlay = document.getElementById("projectOverlay");
  overlay.hidden = false;
  App.renderProjectDialog();
};

App.closeProjectDialog = () => {
  document.getElementById("projectOverlay").hidden = true;
  App._pj = { mode: "create", folder: "", discovery: null, excelPick: "", psdPick: "", pages: [], projectFile: "" };
};

App.renderProjectDialog = () => {
  const pj = App._pj;
  const m = PJ_MODES[pj.mode] || PJ_MODES.create;
  document.getElementById("pjTitle").textContent = m.title;
  document.getElementById("pjSub").textContent = m.sub;
  const cont = document.getElementById("pjContinue");
  cont.textContent = m.footer;

  const d = pj.discovery;
  let status = "";
  if (d) {
    if (d.ok === false) {
      status = `<div class="pj-status err">${esc(d.error || "Couldn't scan this folder.")}</div>`;
      cont.disabled = true;
    } else {
      const rows = [
        ["Excel source", d.found.excel, d.excel_path, "excel_path"],
        ["Icons / Symbols", d.found.icons, d.icon_folder, "icon_folder"],
        ["Background", d.found.background, d.bg_path, "bg_path"],
        ["Output folder", d.found.output, d.output_dir, "output_dir"],
      ];
      const rowsHtml = rows.map(([label, ok, path, key]) => `
        <div class="pj-row ${ok ? "ok" : "warn"}">
          <span class="pj-mark">${ok ? "✓" : "⚠"}</span>
          <span class="pj-label">${label}</span>
          <span class="pj-path">${ok ? esc(path) : "not found"}</span>
          ${ok ? "" : `<button class="btn ghost sm" onclick="App.pjLocate('${key}')">Locate</button>`}
        </div>`).join("");

      const cands = d.excel_candidates || [];
      let excelCand = "";
      if (d.found.excel && cands.length > 1) {
        const pick = pj.excelPick || d.excel_path || cands[0];
        excelCand = `<div class="pj-section"><div class="pj-section-head"><span>Multiple Excel files found</span></div>
          ${cands.map((c) => `<label class="pj-opt"><input type="radio" name="pjExcel" value="${esc(c)}" ${c === pick ? "checked" : ""} onchange="App.pjExcelPick(this.value)" /> ${esc(c.split(/[\\/]/).pop())}</label>`).join("")}
        </div>`;
      }

      let psdCand = "";
      if (pj.mode === "update" && (d.psd_files || []).length > 1) {
        const pick = pj.psdPick || d.psd_files[0];
        psdCand = `<div class="pj-section"><div class="pj-section-head"><span>Existing PSDs — choose the project to update</span></div>
          ${(d.psd_files || []).map((c) => `<label class="pj-opt"><input type="radio" name="pjPsd" value="${esc(c)}" ${c === pick ? "checked" : ""} onchange="App.pjPsdPick(this.value)" /> ${esc(c.split(/[\\/]/).pop())}</label>`).join("")}
        </div>`;
      }

      let pages = "";
      if (pj.mode === "export") {
        const sheets = App.state.scan?.excel?.sheets || [];
        const sel = Array.isArray(pj.pages) ? pj.pages : sheets.map((s) => s.name);
        pages = `<div class="pj-section">
          <div class="pj-section-head"><span>Pages to export</span>
            <span><a onclick="App.pjPagesToggle(true)">Select all</a> · <a onclick="App.pjPagesToggle(false)">Clear</a></span>
          </div>
          ${sheets.length ? `<div class="pj-pages">${sheets.map((s) => `<label class="pj-opt"><input type="checkbox" name="pjPage" value="${esc(s.name)}" ${sel.includes(s.name) ? "checked" : ""} onchange="App.pjPageToggle(this.value, this.checked)" /> ${esc(s.name)}</label>`).join("")}</div>`
            : `<div class="pj-status warn">No pages detected yet — Export will scan the workbook first.</div>`}
        </div>`;
      }

      const canGo = !!(d.found.excel && d.found.output && (pj.mode !== "update" || (d.psd_files || []).length > 0));
      const projectPick = pj.mode === "export" ? `
        <div class="pj-section"><div class="pj-divider">or load a saved project package (no PSD needed)</div>
          <div class="field"><label>Project file</label>
            <div class="field-row">
              <input type="text" id="pjProjectFile" value="${esc(pj.projectFile || "")}" placeholder="MyGame.project.json path…" spellcheck="false" style="flex:1" />
              <button class="btn secondary" onclick="App.pjProjectFileBrowse()">Browse…</button>
            </div>
          </div>
          <div id="pjProjectFileStatus"></div>
        </div>` : "";
      status = `<div class="pj-status ${canGo ? "ok" : ""}">${canGo ? "Ready to " + (pj.mode === "export" ? "export." : "continue.") : "Some items need attention — use Locate to point at the missing ones."}</div>
        <div class="pj-rows">${rowsHtml}</div>${excelCand}${psdCand}${pages}${projectPick}`;
      cont.disabled = !canGo;
    }
  }

  document.getElementById("pjBody").innerHTML = `
    <div class="pj-folder">
      <label>Game Folder</label>
      <div class="pj-folder-row">
        <input type="text" id="pjFolder" value="${esc(pj.folder)}" placeholder="Paste path or Browse…" spellcheck="false" />
        <button class="btn secondary" onclick="App.pjBrowse()">Browse</button>
      </div>
    </div>
    ${pj.analyzing ? `<div class="pj-status">Analyzing project…</div>` : status}
    <div class="hint" style="margin-top:12px">We auto-detect the Excel workbook, icon folder, background and output — you only pick the game folder.</div>`;
  const input = document.getElementById("pjFolder");
  input.addEventListener("change", () => {
    const v = input.value.trim();
    if (v && v !== App._pj.folder) App.pjFolderSet(v);
  });
};

/* Browser version: the server opens the real Windows dialog and returns the full
   path (a browser picker only reveals the name). null = dialog unavailable. */
App.serverPick = async (kind) => {
  try {
    const d = await api("/api/native/browse", { method: "POST", body: { kind } });
    return d && d.path ? d.path : "";
  } catch (e) {
    return null;
  }
};

App.pickPath = async (kind, cb) => {
  const native = window.pywebview?.api;
  if (native) {
    try {
      const path = kind === "dir"
        ? await native.browse_folder()
        : await native.browse_file(kind === "excel" ? "excel" : (kind === "json" ? "json" : (kind === "psd" ? "psd" : "file")));
      cb(path || "");
      return;
    } catch (e) { /* fall through to browser pickers */ }
  }
  const picked = await App.serverPick(kind);
  if (picked !== null) { cb(picked); return; }
  try {
    if (kind === "excel") {
      const handle = await window.showOpenFilePicker({ types: [{ description: "Excel", accept: { "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": [".xlsx", ".xlsm"] } }] });
      cb(handle[0].name);
    } else if (kind === "dir") {
      const handle = await window.showDirectoryPicker();
      cb(handle.name);
    } else if (kind === "json") {
      const handle = await window.showOpenFilePicker({ types: [{ description: "JSON", accept: { "application/json": [".json"] } }] });
      cb(handle[0].name);
    } else {
      const handle = await window.showOpenFilePicker();
      cb(handle[0].name);
    }
    toast("Path selection limited in browser — please paste the full path into the field.", "err");
  } catch (e) {
    cb("");
  }
};

App.pjBrowse = () => {
  App.pickPath("dir", (p) => {
    if (p) App.pjFolderSet(p);
    else toast("No folder selected.", "err");
  });
};

App.pjProjectFileBrowse = () => {
  App.pickPath("json", (p) => {
    if (p) {
      App._pj.projectFile = p;
      const el = document.getElementById("pjProjectFile");
      if (el) el.value = p;
      const status = document.getElementById("pjProjectFileStatus");
      if (status) status.innerHTML = `<div class="pj-status ok">Project package selected — Export will restore its settings and render PNGs.</div>`;
      const cont = document.getElementById("pjContinue");
      if (cont) cont.disabled = false;
    } else {
      toast("No file selected — pick a file or close the dialog.", "err");
    }
  });
};

App.pjFolderSet = async (folder) => {
  const pj = App._pj;
  if (!folder) return;
  pj.folder = folder;
  pj.discovery = null;
  pj.excelPick = "";
  pj.psdPick = "";
  pj.pages = [];
  pj.analyzing = true;
  App.renderProjectDialog();
  try {
    const d = await api("/api/project/discover", { method: "POST", body: { folder } });
    pj.analyzing = false;
    pj.discovery = d;
    if (d && d.ok) {
      if (d.excel_candidates && d.excel_candidates.length) pj.excelPick = d.excel_path || d.excel_candidates[0];
      if (pj.mode === "update" && d.psd_files && d.psd_files.length) pj.psdPick = d.psd_files[0];
    }
    App.renderProjectDialog();
    if (pj.mode === "export" && d && d.ok && d.found.excel) App.pjExportScan();
  } catch (e) {
    pj.analyzing = false;
    pj.discovery = { ok: false, error: e.message };
    App.renderProjectDialog();
  }
};

App.pjExcelPick = (value) => {
  const pj = App._pj;
  pj.excelPick = value;
  if (pj.discovery) pj.discovery.excel_path = value;
  if (pj.mode === "export") App.pjExportScan();
  else App.renderProjectDialog();
};

App.pjPsdPick = (value) => {
  App._pj.psdPick = value;
  App.renderProjectDialog();
};

App.pjLocate = (key) => {
  const d = App._pj.discovery;
  if (!d) return;
  const kind = key === "icon_folder" || key === "output_dir" ? "dir" : key === "excel_path" ? "excel" : "file";
  App.pickPath(kind, (path) => {
    if (!path) return;
    if (key === "excel_path") { d.excel_path = path; d.found.excel = true; }
    if (key === "icon_folder") { d.icon_folder = path; d.found.icons = true; }
    if (key === "bg_path") { d.bg_path = path; d.found.background = true; }
    if (key === "output_dir") { d.output_dir = path; d.found.output = true; }
    App.renderProjectDialog();
    if (App._pj.mode === "export" && d.found.excel) App.pjExportScan();
  });
};

App.pjPagesToggle = (all) => {
  const sheets = App.state.scan?.excel?.sheets?.map((s) => s.name) || [];
  App._pj.pages = all ? null : [];
  App.renderProjectDialog();
};

App.pjPageToggle = (name, checked) => {
  const pj = App._pj;
  if (!Array.isArray(pj.pages)) {
    pj.pages = (App.state.scan?.excel?.sheets || []).map((s) => s.name);
  }
  if (checked) { if (!pj.pages.includes(name)) pj.pages.push(name); }
  else pj.pages = pj.pages.filter((n) => n !== name);
};

App.pjExportScan = async () => {
  const d = App._pj.discovery;
  if (!d || !d.ok) return;
  if (d.excel_path) App.set("excel_path", d.excel_path);
  if (d.icon_folder) App.set("icon_folder", d.icon_folder);
  await App.scan();
  App.renderProjectDialog();
};

App.pjContinue = async () => {
  const pj = App._pj;
  if (pj.mode === "export" && String(pj.projectFile || "").trim()) {
    App.closeProjectDialog();
    try {
      await App.loadProjectPackage(String(pj.projectFile).trim());
      await App.scan();
      const sheets = App.state.scan?.excel?.sheets || [];
      App.set("render_all_pages", true);
      App.set("selected_sheets", []);
      await App.flushConfig();
      App.startBuild("png");
    } catch (e) {
      toast(e.message, "err");
    }
    return;
  }
  const d = pj.discovery;
  if (!d || !d.ok) return;
  const cont = document.getElementById("pjContinue");
  cont.disabled = true;
  const applyDiscoveredPaths = () => {
    if (d.excel_path) App.set("excel_path", d.excel_path);
    if (d.icon_folder) App.set("icon_folder", d.icon_folder);
    if (d.bg_path) App.set("bg_path", d.bg_path);
    if (d.output_dir) App.set("output_dir", d.output_dir);
  };
  try {
    applyDiscoveredPaths();
    try {
      const data = await api("/api/project/open", { method: "POST", body: { folder: d.folder, name: d.name } });
      if (data && data.config) App.state.config = data.config;
      // /api/project/open returns the *persisted* config, which predates the
      // discovered paths above; re-apply them so the Project section always
      // shows the folder that was just selected.
      applyDiscoveredPaths();
    } catch (e) { /* recents are best-effort */ }
    await App.flushConfig();
    if (pj.mode === "export") {
      App.closeProjectDialog();
      await App.scan();
      const sheets = App.state.scan?.excel?.sheets || [];
      const all = !Array.isArray(pj.pages) || sheets.every((s) => pj.pages.includes(s.name));
      App.set("render_all_pages", all);
      App.set("selected_sheets", all ? [] : pj.pages.slice());
      await App.flushConfig();
      App.startBuild("png");
    } else {
      App.closeProjectDialog();
      await App.scan();
      navigate("project");
    }
  } catch (e) {
    toast(e.message, "err");
    cont.disabled = false;
  }
};

App.reopenProject = async (folder) => {
  const f = String(folder || "").trim();
  if (!f) return;
  App.openProjectDialog("create");
  await App.pjFolderSet(f);
  const d = App._pj.discovery;
  if (d && d.ok) App.pjContinue();
};

function viewProject() {
  const c = App.state.config;
  const sheets = App.state.scan?.excel?.sheets || [];
  const thumbOf = (name) =>
    `<img class="pg-thumb-img" src="/api/pages_thumb/${encodeURIComponent(name)}?v=2" alt="${esc(name)}" loading="lazy" />`;
  const sheetRows = sheets.map((s) => {
    const sel = c.selected_sheets.includes(s.name);
    return `<button class="pg-thumb ${sel ? "selected" : ""}" onclick="App.toggleSheet('${esc(s.name).replace(/'/g, "\\'")}')">
      ${thumbOf(s.name)}
      <span class="pg-thumb-foot">
        <span class="pg-thumb-name">${esc(s.name)}</span>
        <span class="chip ${s.type !== "page" ? "blue" : ""}">${esc((s.type || "page").replace("_", " "))}</span>
      </span>
    </button>`;
  }).join("");

  return `
    <div class="view">
      <div class="view-header"><div class="view-title">Project</div>
        <div class="view-sub">Files, canvas and pages — the foundation of your help screen.</div></div>

      <div class="grid grid-2">
        <div>
          ${card("Files", `
            ${fileRow("excel_path", "Excel workbook", ".xlsx", "excel")}
            ${fileRow("icon_folder", "Icon folder", "", "dir")}
            ${fileRow("bg_path", "Background image", "", "file")}
            ${fileRow("output_dir", "Output folder", "", "dir")}
            ${field("output_name", "PSD name (optional)", { type: "text", placeholder: "e.g. MyGame_HelpScreens" })}
            <div class="btn-row">
              <button class="btn primary" onclick="App.scan()">${icon("spark")} Scan Excel with AI</button>
            </div>
          `)}

          ${card("Canvas", `
            <button class="btn primary" onclick="App.openCanvasDialog()">${icon("image")} New Document…</button>
            <div class="hint" style="margin-top:8px">${esc(c.canvas_preset || "Custom")} · ${c.c_width}×${c.c_height} · ${c.c_resolution || 72} PPI</div>
            <div class="field-row" style="margin-top:14px">
              <div class="field" style="flex:1">${field("c_width", "Width", { type: "number", min: 100, max: 6000 })}
              </div>
              <div class="field" style="flex:1">${field("c_height", "Height", { type: "number", min: 100, max: 6000 })}
              </div>
            </div>
            <button class="btn secondary small" style="margin:-4px 0 10px" onclick="App.matchCanvasToImage()"
              title="Make the canvas the same size as the background image (e.g. 1000×1800), so it's neither trimmed nor stretched">${icon("image")} Match background dimensions</button>
            <div class="field-row">
              <div class="field" style="flex:1">${field("margin_x", "Safe side margin", { type: "number", min: 0, max: 2000 })}
              </div>
              <div class="field" style="flex:1">${field("max_col_limit", "Max columns", { type: "number", min: 3, max: 26 })}
              </div>
            </div>
            <div class="hint" style="margin-top:-6px">Safe margins keep text clear of screen edges and bezels.</div>
          `)}
        </div>

        <div>
          ${card("Pages", `
            ${toggleRow("render_all_pages", "Render all pages", "Off = render only the selected sheets below.")}
            <div class="pg-thumbs" style="margin-top:10px">
              ${sheetRows || `<div class="empty" style="padding:24px"><div class="empty-sub">Load the Excel and press “Scan Excel with AI” to list pages here.</div></div>`}
            </div>
          `)}

          ${card("Projects", `
            <div class="field-row">
              <div class="field" style="flex:1"><input type="text" id="presetName" placeholder="Preset name…" style="width:100%" /></div>
              <button class="btn secondary" onclick="App.savePreset()">Save</button>
            </div>
            <div class="field"><label>Saved presets</label>
              <select id="presetSelect" onchange="App.applyPreset(this.value)">${App.state.presets.map((p) => `<option value="${esc(p)}">${esc(p)}</option>`).join("") || '<option value="">No presets</option>'}</select>
            </div>
            <div class="btn-row">
              <button class="btn ghost" onclick="App.resetConfig()">Reset to defaults</button>
            </div>
          `)}

          ${App._pjInfo ? card("Project package", `
            <div class="pj-row ok"><span class="pj-mark">✓</span>
              <span class="pj-label">${esc(App._pjInfo.project_name || "Project")}</span>
              <span class="pj-path">${esc(App._pjInfo.project_id || "")}</span>
            </div>
            <div class="hint" style="margin-top:6px">Manifest<br>${esc(App._pjInfo.manifest || "")}<br>
              Links<br>${esc(App._pjInfo.links || "")}</div>
            <div class="btn-row">
              <button class="btn secondary" onclick="App.saveProjectPackageNow()">Save package now</button>
              <button class="btn ghost" onclick="App.reloadProjectPackage()">Reload</button>
            </div>
          `) : ""}
        </div>
      </div>
    </div>`;
}

function viewTypography() {
  const fonts = App.state.fonts || [];
  const hFontVal = App.get("h_font");
  const hFonts = fonts.slice();
  if (hFontVal && !hFonts.some((f) => String(f).toLowerCase() === String(hFontVal).toLowerCase())) hFonts.unshift(String(hFontVal));
  const fontStyles = [
    { value: "regular", label: "Regular" }, { value: "bold", label: "Bold" },
    { value: "italic", label: "Italic" }, { value: "bold italic", label: "Bold Italic" },
  ];
  const alignOpts = [
    { value: "left", label: "Left" }, { value: "center", label: "Center" }, { value: "right", label: "Right" },
  ];
  const bodyAlignOpts = [...alignOpts, { value: "justify", label: "Justify (last line left)" },
    { value: "justify_center", label: "Justify (last line centred)" }, { value: "justify_right", label: "Justify (last line right)" },
    { value: "justify_all", label: "Justify all lines" }];
  const alignSourceOpts = [
    { value: "tool", label: "Use tool alignment" },
    { value: "excel", label: "Use Excel alignment" },
    { value: "page_override", label: "Use page override if available, else global" },
  ];
  return `
    <div class="view typo-view">
      <div class="tbl-studio typo-studio ${App.typoSideMin() ? "side-min" : ""}">
        <div class="tbl-stage-col">
          <div class="tbl-card tbl-preview-card">
            <div id="typoStrip" class="typo-strip"></div>
            ${previewCanvas()}
          </div>
        </div>
        <div class="tbl-side">
          <button type="button" class="side-collapse" onclick="App.toggleTypoSide()" title="Pages of the help screen and the page's layers">
            <svg viewBox="0 0 24 24"><path d="M12 3 2 8l10 5 10-5-10-5z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><path d="m2 12 10 5 10-5M2 16l10 5 10-5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg></button>
          <div class="tbl-card typo-pages" id="typoPages"><div class="tbl-head">Pages</div><div class="hint">Loading…</div></div>
          <div class="tbl-card typo-layerlist" id="typoLayerList"></div>
          <div class="tbl-card" id="typoLayers"></div>
        </div>
      </div>
    </div>`;
}

function viewAssets() {
  const files = App.state.iconFiles || [];
  const missing = App.state.scan?.icons?.missing || [];
  const tokens = App.state.scan?.icons?.tokens || [];
  // linked (🔗 on): left and right keep the same value; click it to set them apart (bindForms: data-icon-link)
  const gapPair = (lk, rk, label, max) => `
    <div class="ics-gap-row linked-row"><span class="ics-lab">${label}</span>
      left <input type="number" class="ics-num" data-key="${lk}" value="${esc(App.get(lk) ?? "")}" min="0" max="${max}" />
      <button type="button" class="ics-link icon-link-btn" data-icon-link title="Link left and right">🔗</button>
      right <input type="number" class="ics-num" data-key="${rk}" value="${esc(App.get(rk) ?? "")}" min="0" max="${max}" /></div>`;
  return `
    <div class="view">
      <div class="view-header"><div class="view-title">Assets &amp; Icons</div>
        <div class="view-sub">Click an icon on the page to size it (drag a corner) · right-click it to size every copy on the page or in the sheet · click a &lt;TOKEN&gt; with no picture to map one.</div></div>

      <div class="tbl-studio typo-studio ics-studio">
        <div class="tbl-stage-col">
          <div class="tbl-card tbl-preview-card">
            ${previewCanvas()}
          </div>
        </div>
        <div class="tbl-side">
          <div class="tbl-card" id="icsPanel"><div class="tbl-head">Selected icon</div><div class="hint">Click an icon on the page.</div></div>
          <div class="tbl-card">
            <div class="tbl-head">All icons</div>
            <div class="ics-gap-row"><span class="ics-lab">Heading icon height</span>
              <input type="number" class="ics-num" data-key="h_icon_h" value="${esc(App.get("h_icon_h") ?? "")}" min="0" max="400" /> px</div>
            ${gapPair("heading_icon_gap_left", "heading_icon_gap_right", "Heading gap", 400)}
            <div class="ics-gap-row"><span class="ics-lab">Body icon height</span>
              <input type="number" class="ics-num" data-key="b_icon_h" value="${esc(App.get("b_icon_h") ?? "")}" min="0" max="400" /> px</div>
            ${gapPair("icon_gap_left", "icon_gap_right", "Icon gap", 200)}
            <label class="ics-check"><input type="checkbox" data-key="body_icons_use_original_size" ${App.get("body_icons_use_original_size") ? "checked" : ""} /> Body icons at their original size</label>
          </div>
          <div class="tbl-card">
            <div class="tbl-head">Icon library</div>
            <div class="field" style="margin-bottom:10px">${field("icon_folder", "Symbols folder", { type: "text" })}</div>
            <button class="btn secondary" style="width:100%;margin-bottom:10px" onclick="App.openMapper()">${icon("image")} Open Icon Mapper…</button>
            <div class="icon-count">${files.length} icons loaded · ${tokens.length || 0} tokens in Excel</div>
            <div class="card-sub" style="margin:12px 0 8px">Missing icons ${missing.length ? `<span class="hint">— click one to map a picture</span>` : ""}</div>
            ${missing.length
              ? missing.map((m) => `<button class="chip red ics-missing" data-token="${esc(m)}" onclick="IconStudio.missingClick(this.dataset.token)" title="Map a picture to ${esc(m)}">${esc(m)}</button>`).join("")
              : `<div class="hint">✓ All ${tokens.length} tokens have a picture.</div>`}
            <details class="tbl-more" style="margin-top:12px"><summary>Symbols folder (${files.length})</summary>
              <div class="icon-grid" style="margin-top:10px">
                ${files.slice(0, 60).map((f) => `<div class="icon-tile" data-letter="${esc((f.name[0] || "?").toUpperCase())}"><img class="icon-thumb" src="/api/icon_file?folder=${encodeURIComponent(App.state.config.icon_folder)}&name=${encodeURIComponent(f.name)}" onerror="this.parentNode.classList.add('no-thumb')" onload="this.parentNode.classList.add('show-thumb')" alt="" loading="lazy"><span class="tile-name">${esc(f.name)}</span></div>`).join("") || `<div class="hint">No icons loaded yet — set the symbols folder.</div>`}
              </div></details>
          </div>
        </div>
      </div>
    </div>`;
}

function colorCard(key, label, extra = "") {
  const val = App.get(key);
  let hex = "#FFFFFF";
  if (Array.isArray(val)) {
    const rgb = val.slice(0, 3).map((n) => Math.max(0, Math.min(255, Math.round(Number(n) || 0))));
    hex = "#" + rgb.map((n) => n.toString(16).padStart(2, "0")).join("");
  } else if (typeof val === "string") {
    hex = val;
  }
  if (/^#?[0-9a-fA-F]{6}$/.test(hex)) hex = "#" + hex.replace(/^#/, "");
  return `<div class="color-card" data-key="${key}">
    <span class="color-name">${label}</span>
    <label class="swatch-wrap"><input type="color" data-key="${key}" value="${esc(hex)}" /></label>
    ${extra}
  </div>`;
}

function colorSubInput(key, label, min, max) {
  const v = App.get(key);
  return `<span class="color-sub">
    <span class="color-sub-label">${label}</span>
    <input type="number" data-key="${key}" value="${esc(v ?? "")}" min="${min}" max="${max}" />
  </span>`;
}

function colorSubFont(key, label) {
  const val = App.get(key) || "";
  const fonts = (App.state.fonts || []).slice();
  if (val && !fonts.some((f) => String(f).toLowerCase() === String(val).toLowerCase())) fonts.unshift(val);
  const opts = [`<option value="" ${val ? "" : "selected"}>Default (use body font)</option>`].concat(
    fonts.map((f) => `<option value="${esc(f)}" ${String(f).toLowerCase() === String(val).toLowerCase() && val ? "selected" : ""}>${esc(f)}</option>`).join("")
  );
  return `<span class="color-sub">
    <span class="color-sub-label">${label}</span>
    <select data-key="${key}" class="color-sub-font">${opts.join("")}</select>
  </span>`;
}

function viewTables() {
  const renderModes = [
    { value: "both", label: "Fill + Stroke" }, { value: "fill", label: "Fill Only" }, { value: "stroke", label: "Stroke Only" },
  ];
  const followModes = [
    { value: "", label: "Follow Global" }, { value: "fill", label: "Fill Only" }, { value: "stroke", label: "Stroke Only" }, { value: "both", label: "Fill + Stroke" },
  ];
  const alignOpts = [
    { value: "left", label: "Left" }, { value: "center", label: "Center" }, { value: "right", label: "Right" },
  ];
  const enabled = !!App.get("enable_tables");
  return `
    <div class="view">
      <div class="view-header tbl-header">
        <div>
          <div class="view-title">Tables</div>
          <div class="view-sub">Detect and render Excel tables inside pages.</div>
        </div>
        <label class="switch tbl-switch">
          <input type="checkbox" data-key="enable_tables" ${enabled ? "checked" : ""} />
          <span class="track"></span>
        </label>
      </div>

      <div class="tbl-studio">
        <div class="tbl-stage-col">
          <div class="tbl-card tbl-preview-card">
            ${window.AppTblVis ? window.AppTblVis.canvasHTML() : `<div class="empty" style="padding:30px"><div class="empty-icon">▤</div><div class="empty-title">Live preview</div><div class="empty-sub">Preview module not loaded.</div></div>`}
          </div>
        </div>
        <div class="tbl-side">
          <div class="tbl-card" id="tblPagesCard"><div class="tbl-head">Pages</div><div class="tblp-grid" id="tblPagesGrid"><div class="hint">Drawing the pages…</div></div></div>
          <div class="tbl-card" id="tblDesigns"><div class="tbl-head">Table designs</div><div class="hint">Reading the Excel's tables…</div></div>
          <details class="tbl-more">
            <summary>More table settings</summary>
          <div class="tbl-card">
            <details class="tbl-adv" open>
              <summary>Render behavior</summary>
              <div class="form-grid">
                <div class="field">${selectField("table_style.render_mode", "Cell render mode", renderModes)}</div>
                <div class="field">${selectField("table_style.header_render_mode", "Header mode", followModes)}</div>
                <div class="field">${selectField("table_style.row1_render_mode", "Row 1 mode", followModes)}</div>
                <div class="field">${selectField("table_style.row2_render_mode", "Row 2 mode", followModes)}</div>
              </div>
              <div class="tbl-head tbl-sub-head">Colors</div>
              <div class="color-grid">
                ${colorCard("table_style.header_bg_rgb", "Header Fill")}
                ${colorCard("table_style.row1_bg_rgb", "Row 1 Fill")}
                ${colorCard("table_style.row2_bg_rgb", "Row 2 Fill")}
                ${colorCard("table_style.header_text_rgb", "Header Text", colorSubInput("table_style.table_header_font_size", "Font size", 6, 120) + colorSubFont("table_style.table_header_font_name", "Font"))}
                ${colorCard("table_style.table_body_text_rgb", "Body Text", colorSubInput("table_style.table_body_font_size", "Font size", 6, 120) + colorSubFont("table_style.table_body_font_name", "Font"))}
                ${colorCard("table_style.stroke_rgb", "Stroke", colorSubInput("table_style.stroke_width", "Width", 0, 50))}
              </div>
            </details>
          </div>

          <div class="tbl-card geom-card">
            <details class="tbl-adv" open>
              <summary>Geometry</summary>
              <div class="geom-fields">
                ${field("table_style.row_gap", "Row gap", { type: "number", min: 0, max: 200 })}
                ${field("table_style.overlay_opacity", "Border opacity", { type: "number", min: 0, max: 100 })}
                ${field("table_style.after_table_margin", "After-table margin", { type: "number", min: 0, max: 500 })}
                ${field("table_style.table_icon_height", "Icon height", { type: "number", min: 0, max: 200 })}
                ${field("table_style.table_icon_gap_left", "Icon gap left", { type: "number", min: 0, max: 200, hint: "Space between a table icon and the words before it (default 8)." })}
                ${field("table_style.table_icon_gap_right", "Icon gap right", { type: "number", min: 0, max: 200, hint: "Space between a table icon and the words after it (default 8)." })}
                ${field("table_style.table_target_width", "Target width (0 = auto)", { type: "number", min: 0, max: 4000 })}
                ${field("table_style.table_target_height", "Target height (0 = auto)", { type: "number", min: 0, max: 4000 })}
                ${selectField("table_style.table_alignment", "Table alignment", alignOpts)}
                ${selectField("table_style.table_header_alignment", "Header text align", alignOpts)}
                ${selectField("table_style.table_body_alignment", "Body text align", alignOpts)}
                ${toggleRow("table_style.merge_table_layers", "Merge table layers")}
              </div>
            </details>
          </div>

          <div class="tbl-card tbl-adv-card">
            <details class="tbl-adv">
              <summary>Advanced table settings</summary>
              <div class="form-grid adv">
                <div class="field" style="grid-column:1/-1">
                  <label>PSD template for Table Mapper</label>
                  <div style="display:flex;gap:8px">
                    ${field("table_style.mapped_template_psd", "", { type: "text", placeholder: "path\\to\\template.psd or .json — layers named @table.B7, @table.C33…" })}
                    <button class="btn secondary" style="flex:none" onclick="App.openTableMapper()">${icon("image")} Custom Layout Table</button>
                  </div>
                  <div class="hint">Scan a PSD for <b>@table.B7</b> slots — the mapper auto-places Excel data into the matching cells and lets you edit fonts, colors and fills per slot.</div>
                </div>
                <div class="field">${field("table_style.manual_table_ranges", "Manual ranges", { type: "textarea", hint: '{"SheetName":"A1:C10"}' })}</div>
                <div class="field">${field("table_style.table_excel_fill_ranges", "Excel fill ranges", { type: "textarea", hint: '{"SheetName":"B2:D10 #FF0000"}' })}</div>
              </div>
              <div class="hint" style="margin-top:10px">AI detects repeated structures across sheets and recommends one shared template.</div>
            </details>
          </div>
          </details>
          <button class="tbl-custom-btn" onclick="App.openTableMapper()">${icon("image")} Custom Layout Table</button>
        </div>
      </div>
    </div>`;
}

function viewPaytable() {
  const d = App.state.config.dynamic_settings || {};
  const templatePath = String(d.template_json || "").trim();
  const connected = !!templatePath;
  const token = App.state.paytablePreviewToken;
  const pm = App.paytableMapper;
  const sheets = (App.state.scan?.excel?.sheets || []).map((s) => s.name).filter(Boolean)
    .filter((n) => ptmSheetIsPaytable(n));
  const curSheet = (pm && pm.sheetName && sheets.includes(pm.sheetName)) ? pm.sheetName : (sheets[0] || "");
  const sheetOpts = sheets.map((n) => `<option value="${esc(n)}" ${n === curSheet ? "selected" : ""}>${esc(n)}</option>`).join("") ||
    `<option value="">No sheets scanned</option>`;
  const cw = pm?.template?.canvas?.width || 16;
  const ch = pm?.template?.canvas?.height || 9;
  const html = `
    <div class="view">
        <div style="display:flex;align-items:flex-end;gap:12px">
          <div style="flex:1"><div class="view-title">Paytable — Advanced slot editor</div>
          <div class="view-sub">Every box on its own: move, resize and map single slots. Most designs are easier in the card studio.</div></div>
          ${window.PaytableCards ? `<button class="btn secondary small" onclick="PaytableCards.simple()">← Back to the card studio</button>` : ""}
        </div>
      </div>
      <div class="pt-workspace">
        <div class="pt-grid">
          <div class="pt-card pt-card-flex" style="grid-column: span 12; min-width: 0">
            <div class="pt-card-head">
              <div class="pt-card-title"><span class="pt-chip">${icon("image")}</span><span>Live Preview</span>
                <span class="pt-pill ${connected ? "" : "idle"}">${connected ? "Default layout active" : "Loading default layout…"}</span></div>
              <div class="pt-card-sub">${token ? "Your mapped template with the current mappings — rendered server-side with real text and icons." : "The bundled SimplePaytable default layout is applied and auto-mapped to your Excel sheet."}</div>
            </div>
            <div class="pt-preview-head">
              <span class="pt-preview-name" title="${esc(templatePath)}">${connected ? esc(templatePath) : "No mapped template yet"}</span>
              <span style="flex:1"></span>
            </div>
            <div class="pt-mapper-row">
              <label>Sheet</label>
              <select id="ptmSheet" onchange="App.ptmSheetChanged()">${sheetOpts}</select>
              <label>Template name</label>
              <div style="display:flex;gap:6px;align-items:center">
                <select id="ptmTableName" style="width:400px" onchange="App.ptmTemplateSelected(this.value)"></select>
                <button class="pt-btn secondary small" title="Delete the selected template from the library (or right-click the dropdown)" onclick="App.ptmDeleteSelectedTemplate()">Delete</button>
              </div>
              <button class="pt-btn secondary small" onclick="App.ptmAddTemplate()">${icon("plus")} Add New template</button>
              <div style="margin-left:auto;display:flex;gap:8px">
                <button class="pt-btn secondary small" onclick="App.ptmAutoLayout()" title="Regenerate this sheet's layout — choose where the pays/values sit (right/left/below the symbol) and the grid shape (rows × columns)">${icon("grid")} Auto layouts</button>
                <button class="pt-btn auto-map small" onclick="App.ptmAutoMap()">${icon("spark")} Auto-map</button>
                <button class="pt-btn secondary small" onclick="App.ptmApply()">${icon("check")} Apply</button>
                <button class="pt-btn primary small" onclick="App.ptmSave()">${icon("file")} Save mapped</button>
              </div>
            </div>
            <div class="pt-preview-tools">
              <button class="pt-btn secondary small" onclick="App.ptPreviewZoom('out')" title="Zoom out">−</button>
              <button class="pt-btn secondary small" onclick="App.ptPreviewZoom('reset')" title="Fit preview to panel">Fit</button>
              <button class="pt-btn secondary small on" id="ptBlueprintBtn" onclick="App.ptmToggleBlueprint()" title="Toggle slot blueprint outlines/names">Blueprint</button>
              <span style="width:1px;height:22px;background:var(--pt-border2)"></span>
              <select class="pt-tool-sel" title="Align the selected slots to an edge or center of their group" onchange="App.ptmAlign(this.value);this.selectedIndex=0"><option value="">Align…</option><option value="left">Left</option><option value="center">Center H</option><option value="right">Right</option><option value="top">Top</option><option value="middle">Middle V</option><option value="bottom">Bottom</option></select>
              <select class="pt-tool-sel" title="Distribute the selected slots with even gaps" onchange="App.ptmDistribute(this.value);this.selectedIndex=0"><option value="">Distribute…</option><option value="h">Horizontally</option><option value="v">Vertically</option></select>
              <button class="pt-btn secondary small" onclick="App.ptmMatchSize()" title="Resize all selected slots to match the primary slot's width & height">Match size</button>
              <button class="pt-btn secondary small" onclick="App.ptmDuplicate()" title="Duplicate the selected slot (with its mapping) — Ctrl+D">Duplicate</button>
              <button class="pt-btn secondary small" onclick="App.ptmWrapSelection()" title="Wrap the selected slots into a grid master (rows × columns) — moving/scaling this box moves all its children together">Master</button>
              <button class="pt-btn secondary small" onclick="App.ptPreviewZoom('in')" title="Zoom in">+</button>
              <span class="pt-zoom-label" id="ptZoomLabel">Fit</span>
              <span class="pt-zoom-hint">click a card to edit it · drag empty space to marquee-select · drag a card to move it · drag the yellow corner anchors to scale · shift-click to multi-select · arrows nudge (Shift = 10px) · Align/Distribute/Match-size tools above · Ctrl+D duplicate · Ctrl+G group · select 2+ slots → Master wraps them in a move/scale grid (blue box) · Ctrl+U ungroup · Ctrl+Z undo · Ctrl+Shift+Z redo · right-click a card for copy/paste style</span>
            </div>
            <div class="pt-preview-wrap" id="ptPreviewWrap">
              <div class="pt-preview-canvas" id="ptPreviewCanvas">
                <div id="ptPreviewImgHost">${token ? "" : ptMockPreview()}</div>
                <div class="pt-slot-layer" id="ptPreviewSlots" style="aspect-ratio:${cw}/${ch}"></div>
              </div>
            </div>
            <details class="pt-global-settings" id="ptGlobalSettings">
              <summary><span class="pt-chip">+</span><span>Global settings</span></summary>
              <div class="pt-global-body" id="ptGlobalBody"></div>
            </details>
            <details class="pt-global-settings" id="ptSheetCheck" open ontoggle="if (this.open) App.ptmRenderSheetCheck()">
              <summary><span class="pt-chip">▤</span><span>Excel sheet check</span><span class="pt-sheetcheck-sum" id="ptSheetCheckSum"></span></summary>
              <div class="pt-global-body" id="ptSheetCheckBody"><div class="pt-g-hint">Load a paytable to compare it with the Excel sheet.</div></div>
            </details>
            <div style="display:flex;justify-content:center;gap:8px;margin-top:14px">
              <button class="pt-btn secondary small" onclick="App.ptmAddSlot()">${icon("spark")} Add Slot</button>
              <button class="pt-btn secondary small" onclick="App.ptmResetDefaults()">${icon("spark")} Reset Defaults</button>
              <button class="pt-btn secondary small" onclick="App.ptmAdvancedEdit()">${icon("spark")} Advanced Edit Mode</button>
            </div>
          </div>
        </div>
      </div>
    </div>`;
  setTimeout(App.ensurePaytableDefault, 0);
  setTimeout(App.ensurePaytablePreview, 0);
  setTimeout(App.ptmRefreshTemplateList, 0);
  setTimeout(App.ptAdoptPreview, 0);
  setTimeout(App.ptmRenderPreviewOverlay, 0);
  setTimeout(App.ptmLoadSheetData, 0);
  setTimeout(App.ptmRenderPanel, 0);
  setTimeout(App.ptPreviewInitTooltip, 0);
  setTimeout(App.ptmBindPreviewInteractions, 0);
  setTimeout(App.ptApplyPreviewZoom, 0);
  setTimeout(App.ptmInitSlotBar, 0);
  return html;
}

function grSheetKind(name) {
  const compact = String(name || "").toLowerCase().replace(/[^a-z0-9]+/g, "");
  return compact.startsWith("gamerules") ? "game_rules" : "";
}

function viewGameRules() {
  if (window.GRStudio) return GRStudio.view();           // the page itself, edited on the preview
  const sheets = (App.state.scan?.excel?.sheets || []).map((s) => s.name).filter(Boolean);
  const grSheets = sheets.filter((n) => grSheetKind(n) === "game_rules");
  const cur = App.state.grSheetName || grSheets[0] || "";
  const sheetOpts = grSheets.map((n) => `<option value="${esc(n)}" ${n === cur ? "selected" : ""}>${esc(n)}</option>`).join("") ||
    `<option value="">No Game Rules sheet scanned</option>`;
  const token = App.state.grPreviewToken || "";
  return `
    <div class="view">
      <div class="view-header">
        <div class="view-title">Game Rules Studio</div>
        <div class="view-sub">Live preview of the Game Rules page, rendered with the real PNG renderer — no Photoshop needed.</div>
      </div>
      <div class="pt-workspace">
        <div class="pt-grid">
          <div class="pt-card pt-c4 gr-settings">
            <div class="gr-header">
              <div class="gr-header-tg">
                <div class="gr-header-icon"></div>
                <div class="gr-header-title">Page Options</div>
              </div>
              <div class="gr-header-sub">Changes apply to the live preview instantly (auto-saved to the session config).</div>
            </div>
            <div class="gr-setting-item">
              ${toggleRow("render_game_rules", "Render Game Rules page", "Legal text rendered with safe margins.")}
            </div>
            <details class="gr-acc" open>
              <summary>
                <svg class="gr-chevron" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg>
                <span>Upper Body</span>
              </summary>
              <div class="gr-acc-body">
                ${field("dynamic_settings.game_rules_bottom_lr_margin", "Upper/body L/R margin", { type: "number", min: 0, max: 3000 })}
                ${field("dynamic_settings.game_rules_line_height", "Icon-safe line height", { type: "number", min: 0, max: 300, hint: "0 = auto" })}
                ${field("dynamic_settings.game_rules_dynamic_line_height", "Dynamic blank line height", { type: "number", min: 0, max: 300, hint: "0 = auto" })}
              </div>
            </details>
            <details class="gr-acc">
              <summary>
                <svg class="gr-chevron" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg>
                <span>Separator</span>
              </summary>
              <div class="gr-acc-body">
                <div class="gr-row">
                  ${field("dynamic_settings.game_rules_separator_width", "Separator width", { type: "number", min: 50, max: 3000 })}
                  ${field("dynamic_settings.game_rules_separator_height", "Stroke", { type: "number", min: 1, max: 20 })}
                </div>
                ${colorField("dynamic_settings.game_rules_separator_rgb", "Separator color")}
                ${field("dynamic_settings.game_rules_separator_margin", "Separator margin", { type: "number", min: 0, max: 3000 })}
              </div>
            </details>
            <details class="gr-acc">
              <summary>
                <svg class="gr-chevron" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg>
                <span>Bottom / Legal</span>
              </summary>
              <div class="gr-acc-body">
                <div class="gr-row">
                  ${fontField("dynamic_settings.game_rules_bottom_font", "Bottom-section font")}
                  ${field("dynamic_settings.game_rules_bottom_font_size", "Size", { type: "number", min: 8, max: 250 })}
                </div>
                <div class="gr-row">
                  ${field("dynamic_settings.game_rules_bottom_gap", "Gap before malfunction section", { type: "number", min: 0, max: 300 })}
                  ${field("dynamic_settings.game_rules_malfunction_lr_margin", "Malfunction L/R margin", { type: "number", min: 0, max: 3000 })}
                </div>
                ${field("dynamic_settings.game_rules_malfunction_line_height", "Malfunction paragraph line height", { type: "number", min: 0, max: 300, hint: "0 = auto" })}
                ${field("dynamic_settings.game_rules_legal_split_overrides", "Legal split overrides", { type: "textarea", placeholder: "GameRules=B12; GameRules($1+)=B16", hint: "Optional per sheet. From that cell onward, text uses the lower legal style and gets a separator before it." })}
                <div class="gr-data-picker">
                  <div class="pt-ctl-label" style="margin:10px 0 6px"><span>Excel data — Game Rules sheet</span></div>
                  <div style="display:flex;gap:8px;margin-bottom:6px">
                    <select id="grDataSheet" style="flex:1">${grSheets.map((n) => `<option value="${esc(n)}" ${n === cur ? "selected" : ""}>${esc(n)}</option>`).join("") || `<option value="">No Game Rules sheet scanned</option>`}</select>
                    <button class="btn secondary small" onclick="App.grDataLoad()" title="Reload rows from Excel">Reload</button>
                  </div>
                  <div class="ptm-data-tools">
                    <input type="search" id="grDataFilter" placeholder="Filter cells…" oninput="App.grDataRender()" />
                  </div>
                  <div class="ptm-data-list gr-data-list" id="grDataList"></div>
                  <div class="gr-data-foot" style="display:flex;align-items:center;gap:8px;margin-top:6px">
                    <span class="hint" style="flex:1" id="grDataStatus"></span>
                    <button class="btn btn-primary small" id="grDataAdd" onclick="App.grDataAddLegal()">Add to legal split</button>
                  </div>
                  <div class="hint" style="margin-top:6px">Every cell of the sheet is listed (same view as the Paytable Excel data). Click cells — Ctrl/Shift for multiple — then Add: each selected cell becomes its own “SheetName=CellRef” override line; the last line of a sheet decides the split.</div>
                </div>
              </div>
            </details>
            <div class="gr-setting-item">
              ${toggleRow("dynamic_settings.game_rules_xtra_reels_enabled", "XTRAA REELS side icons", "Same asset placed left and right of the rules text.")}
            </div>
            <details class="gr-acc">
              <summary>
                <svg class="gr-chevron" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg>
                <span>XTRAA REELS Side Icons</span>
              </summary>
              <div class="gr-acc-body">
                ${assetField("dynamic_settings.game_rules_xtra_reels_asset", "Icon asset", { placeholder: "path\\to\\asset.png", kind: "file", hint: "Browse, paste a path, or leave empty — if empty, the build auto-detects xtraa*.png / xtrareel(s)*.png (any case) in the project/icon/Excel folders." })}
                <div class="gr-row">
                  ${field("dynamic_settings.game_rules_xtra_reels_width", "Icon width", { type: "number", min: 10, max: 2000 })}
                  ${field("dynamic_settings.game_rules_xtra_reels_outer_margin", "Outer margin", { type: "number", min: 0, max: 1500 })}
                </div>
                <div class="gr-row">
                  ${field("dynamic_settings.game_rules_xtra_reels_text_gap", "Text clearance", { type: "number", min: 0, max: 1000 })}
                  ${field("dynamic_settings.game_rules_xtra_reels_y_offset", "Vertical offset", { type: "number", min: -1000, max: 1000, hint: "0 centers the icons" })}
                </div>
              </div>
            </details>
          </div>
          <div class="pt-card pt-c8">
            <div class="pt-card-head">
              <div class="pt-card-title"><span class="pt-chip">${icon("image")}</span><span>Live Preview</span>
                <span class="pt-pill idle" id="grRenderBadge">Rendering…</span></div>
              <div class="pt-card-sub">Rendered server-side with the exact page builder used by PNG builds.</div>
            </div>
            <div class="pt-preview-head">
              <span class="pt-preview-name" id="grPreviewName" title="Game Rules sheet">${cur ? esc(cur) : "No Game Rules sheet scanned"}</span>
              <span style="flex:1"></span>
              <label style="font-size:12px;color:var(--pt-text2)">Sheet</label>
              <select id="grSheet" style="max-width:300px">${sheetOpts}</select>
            </div>
            <div class="pt-preview-wrap">
              <div class="pt-preview-canvas" id="grPreviewCanvas">
                ${token ? `<img id="grPreviewImg" class="pt-preview-img" src="/api/table_preview/${encodeURIComponent(token)}" alt="Game Rules preview" />`
                        : `<div class="empty" style="padding:48px"><div class="empty-icon">▤</div><div class="empty-title">Preview pending</div><div class="empty-sub">Rendering the Game Rules sheet…</div></div>`}
              </div>
            </div>
            <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:12px">
              <button class="pt-btn secondary small" onclick="App.grRefreshPreview()">${icon("play")} Refresh preview</button>
            </div>
          </div>
        </div>
      </div>
    </div>`;
}

App.grInitStudio = () => {
  const root = document.getElementById("workspace");
  root.querySelectorAll("[data-key]").forEach((el) => {
    if (el.tagName !== "INPUT" && el.tagName !== "SELECT" && el.tagName !== "TEXTAREA") return;
    el.addEventListener("input", App.grRefreshPreview);
    el.addEventListener("change", App.grRefreshPreview);
  });
  const sel = document.getElementById("grSheet");
  if (sel) {
    sel.addEventListener("change", () => {
      App.state.grSheetName = sel.value;
      App.grRefreshPreview();
    });
  }
  const grSel = document.getElementById("grDataSheet");
  if (grSel) {
    grSel.onchange = App.grDataLoad;
    if (grSel.value && grSel.value !== App.grData.sheet) App.grDataLoad();
  }
};

App.grData = { rows: [], selected: new Set(), sheet: "" };

App.grDataRender = () => {
  const host = document.getElementById("grDataList");
  const status = document.getElementById("grDataStatus");
  const add = document.getElementById("grDataAdd");
  if (!host) return;
  const filter = String(document.getElementById("grDataFilter")?.value || "").trim().toLowerCase();
  const rows = App.grData.rows || [];
  const sel = App.grData.selected;
  const shown = rows.filter((r) => !filter || (r.ref + " " + r.text).toLowerCase().includes(filter));
  host.innerHTML = shown.length
    ? shown.map((r) => {
        const pick = sel.has(r.ref);
        return `<div class="ptm-data-row ${pick ? "picked" : ""}" data-ref="${esc(r.ref)}" onclick="App.grDataPick('${esc(r.ref)}', event)">` +
          `<span class="ptm-data-ref">${esc(r.ref)}</span><span class="ptm-data-text">${esc(r.text)}</span></div>`;
      }).join("")
    : `<div class="ptm-data-empty">${rows.length ? "No cells match the filter." : (App.grData.sheet ? "No data in this sheet." : "Pick a Game Rules sheet to see every cell.")}</div>`;
  if (status) status.textContent = sel.size
    ? `${sel.size} cell(s) selected — Add writes “${App.grData.sheet}=ref” lines into the override.`
    : "Every cell of the sheet — click cells to pick (Ctrl/Shift = multiple).";
  if (add) add.disabled = !sel.size;
};

App.grDataPick = (ref, ev) => {
  const host = document.getElementById("grDataList");
  const st = host ? host.scrollTop : 0;
  const sel = App.grData.selected;
  if (ev && (ev.shiftKey || ev.ctrlKey || ev.metaKey)) {
    if (sel.has(ref)) sel.delete(ref); else sel.add(ref);
  } else {
    sel.clear();
    sel.add(ref);
  }
  App.grDataRender();
  if (host) host.scrollTop = st;
};

App.grDataLoad = async () => {
  const selEl = document.getElementById("grDataSheet");
  const sheet = (selEl && selEl.value) || "";
  App.grData.sheet = sheet;
  App.grData.selected.clear();
  App.grData.rows = [];
  if (sheet && App.state.config.excel_path) {
    try {
      const d = await api("/api/paytable_mapper/sheet_data", { method: "POST", timeout: 25000, body: { excel_path: App.state.config.excel_path, sheet_name: sheet } });
      if (d.ok) {
        App.grData.rows = (d.rows || []).slice();
      } else if (d.error) { toast(d.error, "warn"); }
    } catch (e) { /* best-effort */ }
  }
  App.grDataRender();
};

App.grDataAddLegal = () => {
  const selEl = document.getElementById("grDataSheet");
  const sheet = (selEl && selEl.value) || "";
  if (!sheet) { toast("Pick a Game Rules sheet first.", "err"); return; }
  const additions = (App.grData.rows || []).filter((r) => App.grData.selected.has(r.ref)).map((r) => `${sheet}=${r.ref}`);
  if (!additions.length) { toast("Select cells first.", "err"); return; }
  const textarea = document.querySelector('[data-key="dynamic_settings.game_rules_legal_split_overrides"]');
  if (!textarea) { toast("Legal split field not found.", "err"); return; }
  const existing = new Set(String(textarea.value).split(/[\n;]+/).map((s) => s.trim().toLowerCase()).filter(Boolean));
  const fresh = additions.filter((l) => !existing.has(l.toLowerCase()));
  if (!fresh.length) { toast("All selected rows are already in the override.", "warn"); return; }
  textarea.value = (String(textarea.value).trim() ? String(textarea.value).trim() + "\n" : "") + fresh.join("\n");
  textarea.dispatchEvent(new Event("input", { bubbles: true }));
  App.grData.selected.clear();
  App.grDataRender();
  toast(`Added ${fresh.length} legal split override line${fresh.length === 1 ? "" : "s"}.`, "ok");
};

App.grRefreshPreview = debounce(async () => {
  const img = document.getElementById("grPreviewImg");
  const badge = document.getElementById("grRenderBadge");
  const canvas = document.getElementById("grPreviewCanvas");
  if (!canvas) return;
  if (badge) badge.classList.remove("idle");
  try {
    const d = await api("/api/game_rules/preview", { method: "POST", body: { sheet_name: App.state.grSheetName || "" } });
    if (d && d.ok && d.preview_token) {
      App.state.grPreviewToken = d.preview_token;
      if (!img) {
        canvas.innerHTML = `<img id="grPreviewImg" class="pt-preview-img" src="/api/table_preview/${encodeURIComponent(d.preview_token)}" alt="Game Rules preview" />`;
      } else {
        img.src = "/api/table_preview/" + encodeURIComponent(d.preview_token) + "?v=" + Date.now();
      }
      const nameEl = document.getElementById("grPreviewName");
      if (nameEl && d.sheet_name) nameEl.textContent = d.sheet_name;
    } else if (d && d.error) {
      toast(d.error, "warn");
    }
  } catch (e) { /* non-fatal */ }
  if (badge) badge.classList.add("idle");
}, 450);

function bgrSheetKind(name) {
  const compact = String(name || "").toLowerCase().replace(/[^a-z0-9]+/g, "");
  return compact.startsWith("bingorules") ? "bingo_rules" : "";
}

function viewBingoRules() {
  if (window.BRStudio) return BRStudio.view();           // the page itself, edited on the preview
  const sheets = (App.state.scan?.excel?.sheets || []).map((s) => s.name).filter(Boolean);
  const brSheets = sheets.filter((n) => bgrSheetKind(n) === "bingo_rules");
  const cur = App.state.bgrSheetName || brSheets[0] || "";
  const sheetOpts = brSheets.map((n) => `<option value="${esc(n)}" ${n === cur ? "selected" : ""}>${esc(n)}</option>`).join("") ||
    `<option value="">No Bingo Rules sheet scanned</option>`;
  const token = App.state.bgrPreviewToken || "";
  return `
    <div class="view">
      <div class="view-header">
        <div class="view-title">Bingo Rules Studio</div>
        <div class="view-sub">Live preview of the Bingo Rules page, rendered with the real PNG renderer — no Photoshop needed.</div>
      </div>
      <div class="pt-workspace">
        <div class="pt-grid">
          <div class="pt-card pt-c4">
            <div class="pt-card-head">
              <div class="pt-card-title"><span class="pt-chip">${icon("file")}</span><span>Page Options</span></div>
              <div class="pt-card-sub">Changes apply to the live preview instantly (auto-saved to the session config).</div>
            </div>
            ${toggleRow("render_bingo_rules", "Render Bingo Rules page")}
            ${toggleRow("dynamic_settings.bingo_rules_one_page", "Keep Bingo Rules on one page")}
            <div class="divider"></div>
            <div class="field-row">
              <div class="field" style="flex:1">${field("dynamic_settings.bingo_rules_body_size", "Bingo body size", { type: "number", min: 0, max: 250, hint: "0 = use normal body size" })}</div>
            </div>
            <div class="field">${field("dynamic_settings.bingo_rules_body_ranges", "Main paragraph cells", { type: "text", placeholder: "Bingo Rules=B5:H24; BingoRules=B3:H66.", hint: "Optional. Blank = auto." })}</div>
            <div class="divider"></div>
            <div class="pt-ctl-label" style="margin:6px 0 10px"><span>Footer cell alignment</span></div>
            <div class="field">${field("dynamic_settings.bingo_rules_left_align_cells", "Align left cells", { type: "text", placeholder: "B27, B28", hint: "Cell refs separated by commas — e.g. b5, c4. Blank = default B27, B28." })}</div>
            <div class="field">${field("dynamic_settings.bingo_rules_right_align_cells", "Align right cells", { type: "text", placeholder: "H27, H28", hint: "Cell refs separated by commas. Blank = default H27, H28." })}</div>
            <div class="divider"></div>
            <div class="pt-ctl-label" style="margin:6px 0 10px"><span>Excel data — Bingo Rules sheet</span></div>
            <div style="display:flex;gap:8px;margin-bottom:6px">
              <select id="bgrDataSheet" style="flex:1">${brSheets.map((n) => `<option value="${esc(n)}" ${n === cur ? "selected" : ""}>${esc(n)}</option>`).join("") || `<option value="">No Bingo Rules sheet scanned</option>`}</select>
              <button class="btn secondary small" onclick="App.bgrDataLoad()" title="Reload rows from Excel">Reload</button>
            </div>
            <div class="ptm-data-tools">
              <input type="search" id="bgrDataFilter" placeholder="Filter cells…" oninput="App.bgrDataRender()" />
            </div>
            <div class="ptm-data-list gr-data-list" id="bgrDataList"></div>
            <div class="gr-data-foot" style="display:flex;align-items:center;gap:8px;margin-top:6px">
              <span class="hint" style="flex:1" id="bgrDataStatus"></span>
            </div>
            <div class="field-row" style="margin-top:8px">
              <button class="btn secondary small" style="flex:1" onclick="App.bgrDataAdd('left')">← Add selected to Align left</button>
              <button class="btn secondary small" style="flex:1" onclick="App.bgrDataAdd('right')">Add selected to Align right →</button>
            </div>
            <div class="hint" style="margin-top:6px">Every cell of the sheet is listed (same view as the Paytable Excel data). Click cells — Ctrl/Shift for multiple — then a button: each selected cell is added to “Align left cells” or “Align right cells”.</div>
            <div class="divider"></div>
            <div class="pt-ctl-label" style="margin:6px 0 10px"><span>Bingo-specific overrides (0 = use global)</span></div>
            <div class="field-row">
              <div class="field" style="flex:1">${field("dynamic_settings.bingo_rules_left_margin", "L/R margin", { type: "number", min: 0, max: 500 })}</div>
              <div class="field" style="flex:1">${field("dynamic_settings.bingo_rules_line_spacing", "Line spacing", { type: "number", min: 0, max: 200 })}</div>
            </div>
            <div class="field-row">
              <div class="field" style="flex:1">${field("dynamic_settings.bingo_rules_para_spacing", "Para spacing", { type: "number", min: 0, max: 200 })}</div>
              <div class="field" style="flex:1">${field("dynamic_settings.bingo_rules_bottom_margin", "Bottom margin", { type: "number", min: 0, max: 500 })}</div>
            </div>
          </div>
          <div class="pt-card pt-c8">
            <div class="pt-card-head">
              <div class="pt-card-title"><span class="pt-chip">${icon("image")}</span><span>Live Preview</span>
                <span class="pt-pill idle" id="bgrRenderBadge">Rendering…</span></div>
              <div class="pt-card-sub">Rendered server-side with the exact page builder used by PNG builds.</div>
            </div>
            <div class="pt-preview-head">
              <span class="pt-preview-name" id="bgrPreviewName" title="Bingo Rules sheet">${cur ? esc(cur) : "No Bingo Rules sheet scanned"}</span>
              <span style="flex:1"></span>
              <label style="font-size:12px;color:var(--pt-text2)">Sheet</label>
              <select id="bgrSheet" style="max-width:300px">${sheetOpts}</select>
            </div>
            <div class="pt-preview-wrap">
              <div class="pt-preview-canvas" id="bgrPreviewCanvas">
                ${token ? `<img id="bgrPreviewImg" class="pt-preview-img" src="/api/table_preview/${encodeURIComponent(token)}" alt="Bingo Rules preview" />`
                        : `<div class="empty" style="padding:48px"><div class="empty-icon">▤</div><div class="empty-title">Preview pending</div><div class="empty-sub">Rendering the Bingo Rules sheet…</div></div>`}
              </div>
            </div>
            <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:12px">
              <button class="pt-btn secondary small" onclick="App.bgrRefreshPreview()">${icon("play")} Refresh preview</button>
            </div>
          </div>
        </div>
      </div>
    </div>`;
}

App.bgrInitStudio = () => {
  const root = document.getElementById("workspace");
  root.querySelectorAll("[data-key]").forEach((el) => {
    if (el.tagName !== "INPUT" && el.tagName !== "SELECT" && el.tagName !== "TEXTAREA") return;
    el.addEventListener("input", App.bgrRefreshPreview);
    el.addEventListener("change", App.bgrRefreshPreview);
  });
  const sel = document.getElementById("bgrSheet");
  if (sel) {
    sel.addEventListener("change", () => {
      App.state.bgrSheetName = sel.value;
      App.bgrRefreshPreview();
    });
  }
  const bgrSel = document.getElementById("bgrDataSheet");
  if (bgrSel) {
    bgrSel.onchange = App.bgrDataLoad;
    if (bgrSel.value && bgrSel.value !== App.bgrData.sheet) App.bgrDataLoad();
  }
};

App.bgrData = { rows: [], selected: new Set(), sheet: "" };

App.bgrDataRender = () => {
  const host = document.getElementById("bgrDataList");
  const status = document.getElementById("bgrDataStatus");
  if (!host) return;
  const filter = String(document.getElementById("bgrDataFilter")?.value || "").trim().toLowerCase();
  const rows = App.bgrData.rows || [];
  const sel = App.bgrData.selected;
  const shown = rows.filter((r) => !filter || (r.ref + " " + r.text).toLowerCase().includes(filter));
  host.innerHTML = shown.length
    ? shown.map((r) => {
        const pick = sel.has(r.ref);
        return `<div class="ptm-data-row ${pick ? "picked" : ""}" data-ref="${esc(r.ref)}" onclick="App.bgrDataPick('${esc(r.ref)}', event)">` +
          `<span class="ptm-data-ref">${esc(r.ref)}</span><span class="ptm-data-text">${esc(r.text)}</span></div>`;
      }).join("")
    : `<div class="ptm-data-empty">${rows.length ? "No cells match the filter." : (App.bgrData.sheet ? "No data in this sheet." : "Pick a Bingo Rules sheet to see every cell.")}</div>`;
  if (status) status.textContent = sel.size
    ? `${sel.size} cell(s) selected — use a button to add them to the Align fields.`
    : "Every cell of the sheet — click cells to pick (Ctrl/Shift = multiple).";
};

App.bgrDataPick = (ref, ev) => {
  const host = document.getElementById("bgrDataList");
  const st = host ? host.scrollTop : 0;
  const sel = App.bgrData.selected;
  if (ev && (ev.shiftKey || ev.ctrlKey || ev.metaKey)) {
    if (sel.has(ref)) sel.delete(ref); else sel.add(ref);
  } else {
    sel.clear();
    sel.add(ref);
  }
  App.bgrDataRender();
  if (host) host.scrollTop = st;
};

App.bgrDataLoad = async () => {
  const selEl = document.getElementById("bgrDataSheet");
  const sheet = (selEl && selEl.value) || "";
  App.bgrData.sheet = sheet;
  App.bgrData.selected.clear();
  App.bgrData.rows = [];
  if (sheet && App.state.config.excel_path) {
    try {
      const d = await api("/api/paytable_mapper/sheet_data", { method: "POST", timeout: 25000, body: { excel_path: App.state.config.excel_path, sheet_name: sheet } });
      if (d.ok) {
        App.bgrData.rows = (d.rows || []).slice();
      } else if (d.error) { toast(d.error, "warn"); }
    } catch (e) { /* best-effort */ }
  }
  App.bgrDataRender();
};

App.bgrDataAdd = (side) => {
  const selEl = document.getElementById("bgrDataSheet");
  const sheet = (selEl && selEl.value) || "";
  if (!sheet) { toast("Pick a Bingo Rules sheet first.", "err"); return; }
  const key = side === "left" ? "dynamic_settings.bingo_rules_left_align_cells" : "dynamic_settings.bingo_rules_right_align_cells";
  const input = document.querySelector(`[data-key="${key}"]`);
  if (!input) { toast("Alignment field not found.", "err"); return; }
  const refs = (App.bgrData.rows || []).filter((r) => App.bgrData.selected.has(r.ref)).map((r) => r.ref);
  if (!refs.length) { toast("Select cells first.", "err"); return; }
  const existing = new Set(String(input.value).toUpperCase().split(/[\s,;]+/).filter(Boolean));
  const fresh = refs.filter((r) => !existing.has(r.toUpperCase()));
  if (!fresh.length) { toast("All selected cells are already listed.", "warn"); return; }
  input.value = (String(input.value).trim() ? String(input.value).trim() + ", " : "") + fresh.join(", ");
  input.dispatchEvent(new Event("input", { bubbles: true }));
  App.bgrData.selected.clear();
  App.bgrDataRender();
  toast(`Added ${fresh.length} cell${fresh.length === 1 ? "" : "s"} to Align ${side === "left" ? "left" : "right"}.`, "ok");
};

App.bgrRefreshPreview = debounce(async () => {
  const img = document.getElementById("bgrPreviewImg");
  const badge = document.getElementById("bgrRenderBadge");
  const canvas = document.getElementById("bgrPreviewCanvas");
  if (!canvas) return;
  if (badge) badge.classList.remove("idle");
  try {
    const d = await api("/api/bingo_rules/preview", { method: "POST", body: { sheet_name: App.state.bgrSheetName || "" } });
    if (d && d.ok && d.preview_token) {
      App.state.bgrPreviewToken = d.preview_token;
      if (!img) {
        canvas.innerHTML = `<img id="bgrPreviewImg" class="pt-preview-img" src="/api/table_preview/${encodeURIComponent(d.preview_token)}" alt="Bingo Rules preview" />`;
      } else {
        img.src = "/api/table_preview/" + encodeURIComponent(d.preview_token) + "?v=" + Date.now();
      }
      const nameEl = document.getElementById("bgrPreviewName");
      if (nameEl && d.sheet_name) nameEl.textContent = d.sheet_name;
    } else if (d && d.error) {
      toast(d.error, "warn");
    }
  } catch (e) { /* non-fatal */ }
  if (badge) badge.classList.add("idle");
}, 450);

function viewRender() {
  return `
    <div class="view">
      <div class="view-header"><div class="view-title">Render &amp; Export</div>
        <div class="view-sub">Build PSD, PNG or both — with validation and a live render queue.</div></div>

      <div class="grid grid-2">
        <div>
          ${card("Build", `
            ${field("png_suffix", "PNG suffix (optional)", { type: "text", placeholder: "empty = sheet names (Paytable.png); filled = suffix_1.png…" })}
            <div class="btn-row">
              <button class="btn secondary large" onclick="App.startBuild('psd')">${icon("file")} Build PSD</button>
              <button class="btn secondary large" onclick="App.startBuild('png')">${icon("image")} Build PNG</button>
              <button class="btn primary large" onclick="App.startBuild('both')">${icon("play")} Build Both</button>
            </div>
            ${toggleRow("overwrite_existing", "Overwrite existing output")}
            ${toggleRow("write_links_folder", "Also write the _Links folder", "Every PSD already stores its own project (settings, templates, Excel, layer links). Turn on only if another tool needs the old MyGame_Links folder and .project.json file.")}
            ${toggleRow("headless_mode", "Headless mode (no Photoshop needed)", "Uses PSAPI to build PSD files entirely in Python — 2-5s per page. New builds only; update-mode always uses Photoshop.")}
            <div id="headlessInfo" ${App.state.config.headless_mode ? "" : "style='display:none'"} class="hint" style="margin-top:4px;margin-bottom:8px;color:#8af">Headless mode: PSD builds skip Photoshop. Faster but limited layer styles. Update-mode always falls back to Photoshop.</div>
            ${toggleRow("performance_mode", "Performance mode (diff-only re-render)", "Only re-renders changed pages when a previous Excel/PSD exists.")}
            <div id="perfWrap" ${App.state.config.performance_mode ? "" : "style='display:none'"}>
              ${field("prev_excel_path", "Previous Excel (diff source)", { type: "text", placeholder: "leave empty to use the current workbook" })}
              ${field("prev_psd_path", "Previous PSD (layers to reuse)", { type: "text", placeholder: "existing PSD with matching layer names" })}
            </div>
          `)}

          ${card("Pre-build checks", `
            <div id="preflightCard"><div class="hint">Running pre-build checks…</div></div>
            <div class="hint" style="margin-top:12px">${App.state.config.headless_mode ? "Headless mode active — Photoshop is not required for new PSD builds." : "Photoshop must be open for PSD builds. PNG builds are pure Python (no Photoshop needed)."}</div>
          `)}
        </div>
        <div>
          ${card("Render Queue", `
            <div id="queueList">
              <div class="empty" style="padding:24px"><div class="empty-icon">▤</div><div class="empty-title">Queue empty</div><div class="empty-sub">Started builds appear here with live progress.</div></div>
            </div>
          `)}
          ${card("Export JSON", `
            <div class="btn-row">
              <button class="btn secondary" onclick="App.exportPaytableJson('active')">Export paytable JSON</button>
            </div>
          `)}
          ${card("Batch Export (PSD → images)", `
            ${field("batch_format", "Format", { type: "select", options: [{ value: "PNG", label: "PNG" }, { value: "JPG", label: "JPG" }] })}
            ${field("batch_quality", "JPG quality", { type: "number", placeholder: "90" })}
            ${field("batch_suffix", "Suffix", { type: "text", placeholder: "MyExport" })}
            ${toggleRow("batch_groups", "Export visible groups")}
            ${toggleRow("batch_layers", "Export visible layers")}
            ${toggleRow("batch_transparent", "Transparent background")}
            ${toggleRow("batch_bottom_top", "Bottom to top order")}
            <div class="btn-row" style="margin-top:10px">
              <button class="btn primary" onclick="App.runBatchExport()">${icon("play")} Batch Export</button>
              <button class="btn secondary" onclick="App.runBackup()">${icon("file")} Backup PSD</button>
            </div>
          `)}
        </div>
      </div>
    </div>`;
}

App.iconMapperHTML = () => {
  const tokens = App.state.scan?.icons?.tokens || [];
  const mappings = App.state.config.icon_mappings || {};
  const sizes = App.state.config.icon_size_overrides || {};
  if (App.state.config.icon_simple_mode) {
    return `<div class="hint" style="margin-top:-6px">Auto-matching is on — icons are matched to tokens by file name (case-insensitive).</div>`;
  }
  if (!tokens.length) {
    return `<div class="hint" style="margin-top:-6px">No icon tokens yet — scan the Excel (Project view) to list tokens here.</div>`;
  }
  return `<div class="sheet-list" style="max-height:260px;overflow-y:auto">
    ${tokens.slice(0, 60).map((t) => `
      <div class="field-row" style="margin-bottom:6px">
        <span class="chip blue" style="min-width:90px;justify-content:center">${esc(t)}</span>
        <input type="text" data-map="${esc(t)}" placeholder="file name (auto if empty)" value="${esc(mappings[t] || "")}" style="flex:1" />
        <input type="number" data-size="${esc(t)}" placeholder="px" value="${esc(sizes[t] || "")}" style="width:64px" />
      </div>`).join("")}
    ${tokens.length > 60 ? `<div class="hint">Showing first 60 tokens — mapping works for all tokens automatically.</div>` : ""}
  </div>`;
};

App.loadMappings = async () => {
  try {
    const data = await api("/api/mappings");
    App.state.config.icon_mappings = data.mappings || {};
    App.state.config.icon_size_overrides = data.size_overrides || {};
    renderRoute();
  } catch (e) { toast(e.message, "err"); }
};

App.toggleSheet = (name) => {
  const c = App.state.config;
  const i = c.selected_sheets.indexOf(name);
  if (i >= 0) c.selected_sheets.splice(i, 1);
  else c.selected_sheets.push(name);
  App.pushConfig();
  renderRoute();
};

// Canvas views draw from their own data, not the scan: on start-up the scan waits for
// their first frame and only re-renders them when it actually changed the config.
const CANVAS_ROUTES = ["typography", "visualiser-live"];

App.canvasReady = (() => {
  let done;
  const p = new Promise((r) => { done = r; });
  window.addEventListener("psh:canvas-ready", () => done(), { once: true });
  return p;
})();

App.scan = async (opts = {}) => {
  const background = !!opts.background;
  if (background && CANVAS_ROUTES.includes(App.route)) {
    await Promise.race([App.canvasReady, new Promise((r) => setTimeout(r, 4000))]);
  }
  if (!background) toast("AI scanning your Excel…");
  try {
    const before = JSON.stringify(App.state.config);
    const data = await api("/api/scan", {
      method: "POST",
      body: { excel_path: App.state.config.excel_path, icon_folder: App.state.config.icon_folder },
    });
    App.state.config = data.config;
    App.state.scan = data;
    App.state.config.selected_sheets = App.state.config.selected_sheets || [];
    App.renderMiraSheets();
    const unchanged = JSON.stringify(App.state.config) === before;
    if (!(background && unchanged && CANVAS_ROUTES.includes(App.route))) renderRoute();
    if (!document.getElementById("missingOverlay").hidden) App.renderMissingDialog();
    if (data.excel?.pruned_selected_sheets > 0) {
      toast(`Dropped ${data.excel.pruned_selected_sheets} page selection(s) that don't exist in this workbook.`, "warn");
    }
    toast(`Scan complete — ${data.excel.sheets.length} sheets, ${data.icons?.missing?.length || 0} missing icons.`);
  } catch (e) {
    toast(e.message, "err");
  }
};

/* ------------------------------ background dialog ------------------------------ */

App.openBackgroundDialog = () => {
  App.renderBackgroundDialog();
  document.getElementById("bgOverlay").hidden = false;
};

App.closeBackgroundDialog = () => {
  document.getElementById("bgOverlay").hidden = true;
};

App.renderBackgroundDialog = () => {
  const c = App.state.config;
  const src = c.bg_source === "color" ? "color" : "image";
  const body = document.getElementById("bgBody");
  body.innerHTML = `
    ${selectField("bg_source", "Background source", [
      { value: "image", label: "Image" },
      { value: "color", label: "Solid color" },
    ])}
    ${src === "color" ? `
      ${colorField("bg_color", "Background color")}
      <div class="hint" style="margin-top:-6px">A solid color layer is created behind all content.</div>
    ` : `
      ${fileRow("bg_path", "Background image", "", "file")}
      <div class="field"><label>How the background sits</label><div id="bgModeBox">${App.bgModeHtml()}</div></div>
      <button class="btn secondary" onclick="App.matchCanvasToImage()">${icon("image")} Match background dimensions</button>
      <div class="hint" style="margin-top:8px">When the image's shape differs from the canvas, it can't fill the canvas AND show every pixel without stretching. “Fill canvas” keeps proportions and trims the overflow evenly; “Whole image” keeps every pixel and leaves empty bars. “Match background dimensions” makes the canvas the image's own size (e.g. 1000×1800), so nothing is trimmed or stretched.</div>
    `}`;
  bindForms(body);
  body.querySelector('[data-key="bg_source"]')?.addEventListener("change", () => App.renderBackgroundDialog());
};

/* Where the background picture sits — the same choices in this dialog, on the Canvas (🔒 BG) and when a
   picture is chosen. bg_mode: cover / stretch / fit / center / fit_width (+ bg_anchor) / place (+ bg_rect,
   canvas px: a PSD's background layer); bg_color shows where the picture doesn't cover the canvas. */
const BG_MODES = [
  ["cover", "Fill", "Covers the whole canvas, keeps its shape (trims the overflow)"],
  ["stretch", "Stretch", "Exactly the canvas, out of shape if need be"],
  ["fit", "Fit inside", "The whole picture, as big as fits, centred"],
  ["fit_width", "Fit width", "As wide as the canvas — at the top, middle or bottom"],
  ["place", "Placed", "Exactly where you put it (x, y, width, height) — a PSD's background"],
  ["center", "Own size", "Its own size, centred"],
];
App.bgModeHtml = () => {
  const c = App.state.config, mode = String(c.bg_mode || "cover").toLowerCase() === "fill" ? "cover" : String(c.bg_mode || "cover").toLowerCase();
  const anchor = String(c.bg_anchor || "center").toLowerCase();
  const r = Array.isArray(c.bg_rect) && c.bg_rect.length === 4 ? c.bg_rect : [0, 0, Number(c.c_width) || 1920, Number(c.c_height) || 1080];
  return `<div class="bgm-modes">${BG_MODES.map(([v, l, t]) => `<button class="pt-btn small ${v === mode ? "on" : ""}" onclick="App.setBg('bg_mode','${v}')" title="${esc(t)}">${l}</button>`).join("")}</div>
    ${mode === "fit_width" ? `<div class="bgm-row">${["top", "center", "bottom"].map((a) => `<button class="pt-btn small ${a === anchor ? "on" : ""}" onclick="App.setBg('bg_anchor','${a}')">${a === "top" ? "⬆ Top" : a === "bottom" ? "⬇ Bottom" : "↕ Middle"}</button>`).join("")}</div>` : ""}
    ${mode === "place" ? `<div class="bgm-row">${["x", "y", "width", "height"].map((n, i) => `<label class="bgm-num">${n}<input type="number" value="${Math.round(Number(r[i]) || 0)}" onchange="App.setBgRect(${i}, this.value)"></label>`).join("")}<span class="hint">px on the canvas</span></div>` : ""}
    <div class="bgm-row" title="Where the picture leaves the canvas uncovered (around it, or its own see-through parts): transparent, or a colour"><label class="bgm-num"><input type="checkbox" ${c.bg_behind_fill ? "checked" : ""} onchange="App.setBg('bg_behind_fill', this.checked)"> Colour behind</label>${c.bg_behind_fill ? `<input type="color" value="${esc(c.bg_color || "#000000")}" onchange="App.setBg('bg_color', this.value)">` : `<span class="hint">transparent</span>`}</div>`;
};
App.setBg = (key, value) => {
  App.set(key, value);
  if (key === "bg_mode" && value === "place" && !(Array.isArray(App.get("bg_rect")) && App.get("bg_rect").length === 4)) {
    App.set("bg_rect", [0, 0, Number(App.get("c_width")) || 1920, Number(App.get("c_height")) || 1080]);
  }
  if (key === "bg_mode" && value !== "color") App.set("bg_source", "image");
  App.pushConfig();
  App.bgRefresh();
};
App.setBgRect = (i, v) => {
  const r = (Array.isArray(App.get("bg_rect")) ? App.get("bg_rect") : [0, 0, Number(App.get("c_width")) || 1920, Number(App.get("c_height")) || 1080]).slice();
  r[i] = Math.round(Number(v) || 0);
  if (r[2] < 1) r[2] = 1;
  if (r[3] < 1) r[3] = 1;
  App.setBg("bg_rect", r);
};
// the background changed: drawn again at once (no layout changes), the controls show the new choice
App.bgRefresh = () => {
  document.querySelectorAll("#bgModeBox, .bgm-box").forEach((b) => { b.innerHTML = App.bgModeHtml(); });
  const c = document.getElementById("typoVisCanvas");
  if (window.PaytableCanvas && PaytableCanvas.on && PaytableCanvas.on()) PaytableCanvas.draw();   // a paytable page
  else if (c && window.AppLive && AppLive.redrawInto && AppLive.state.data) AppLive.redrawInto(c);
  if (window.AppTypoVis && AppTypoVis.renderRail) AppTypoVis.renderRail();
};
// a background picture was just chosen: how it should sit (a PSD's background keeps its own place)
App.askBgMode = () => {
  if (document.getElementById("bgAskOverlay")) return;
  const ov = document.createElement("div");
  ov.id = "bgAskOverlay";
  ov.className = "overlay";
  ov.innerHTML = `<div class="canvas-dialog" style="max-width:560px"><div class="canvas-dialog-title">How should this background sit?</div>
    <div class="canvas-sub">You can change it any time: Background settings, or 🔒 BG on the Canvas.</div>
    <div class="bgm-ask">${BG_MODES.filter(([v]) => v !== "center").map(([v, l, t]) => `<button class="btn ${v === "cover" ? "primary" : "secondary"}" data-bgask="${v}"><b>${l}</b><span>${esc(t)}</span></button>`).join("")}</div></div>`;
  document.body.appendChild(ov);
  ov.addEventListener("click", (ev) => {
    const b = ev.target.closest("[data-bgask]");
    if (!b) return;
    App.setBg("bg_mode", b.dataset.bgask);
    ov.remove();
    if (b.dataset.bgask === "fit_width" || b.dataset.bgask === "place") toast("Set where it sits: Background settings, or 🔒 BG on the Canvas.");
  });
};

App.matchCanvasToImage = async () => {
  const p = App.state.config.bg_path;
  if (!p) { toast("Choose a background image first.", "err"); return; }
  try {
    const d = await api(`/api/image_size?path=${encodeURIComponent(p)}`);
    if (!d.ok || !d.width) throw new Error(d.error || "Could not read the image size.");
    App.set("c_width", d.width);
    App.set("c_height", d.height);
    App.set("canvas_preset", "Custom");
    App.pushConfig();
    renderRoute();
    toast(`Canvas resized to image: ${d.width} × ${d.height}`);
  } catch (e) { toast(e.message, "err"); }
};

App.applyBackground = () => {
  App.closeBackgroundDialog();
  renderRoute();
  toast("Background updated.");
};

/* ------------------------------ output dialog ------------------------------ */

App.openOutputDialog = () => {
  App.renderOutputDialog();
  document.getElementById("outputOverlay").hidden = false;
};

App.closeOutputDialog = () => {
  document.getElementById("outputOverlay").hidden = true;
};

App.renderOutputDialog = () => {
  const body = document.getElementById("outputBody");
  body.innerHTML = `
    ${fileRow("output_dir", "Output folder", "", "dir")}
    <div class="hint" style="margin-top:-8px;margin-bottom:14px">Empty = saved next to the Excel file.</div>
    ${field("output_name", "Output name", { type: "text", placeholder: "empty = auto (from workbook name)" })}
    <div class="hint" style="margin-top:-8px">Used for the PSD/PNG file name — e.g. MyGame_HelpScreens.</div>
    ${field("png_suffix", "PNG suffix (optional)", { type: "text", placeholder: "empty = sheet names (Paytable.png); filled = suffix_1.png…" })}
    ${selectField("build_output", "Default build format", [
      { value: "both", label: "Both (PSD + PNG)" },
      { value: "psd", label: "PSD only" },
      { value: "png", label: "PNG only" },
    ])}
    ${toggleRow("overwrite_existing", "Overwrite existing output")}
  `;
  bindForms(body);
};

/* ------------------------------ update PSD dialog ------------------------------ */

App.openUpdateDialog = () => {
  App.renderUpdateDialog();
  document.getElementById("updateOverlay").hidden = false;
};

App.closeUpdateDialog = () => {
  document.getElementById("updateOverlay").hidden = true;
};

App.renderUpdateDialog = () => {
  const c = App.state.config;
  const saveMode = String(c.update_save_mode || "overwrite");
  const body = document.getElementById("updateBody");
  body.innerHTML = `
    ${fileRow("prev_psd_path", "Old PSD path", "", "psd")}
    <div class="hint" style="margin-top:-6px;margin-bottom:14px">The existing PSD to update — its layers are reused (needs matching layer names).</div>
    <div id="updateProjectStatus"></div>
    ${fileRow("prev_excel_path", "Old Excel (optional)", ".xlsx", "excel")}
    <div class="hint" style="margin-top:-6px;margin-bottom:14px">Only for PSDs without a saved baseline — otherwise the saved Excel baseline is used automatically.</div>
    ${fileRow("excel_path", "New Excel", ".xlsx", "excel")}
    <div class="hint" style="margin-top:-6px;margin-bottom:14px">Your updated workbook — only differences are re-rendered into the PSD.</div>
    <div class="btn-row">
      <button class="btn secondary" id="updatePreviewBtn" onclick="App.updatePreviewNow()">${icon("search")} Preview changes</button>
    </div>
    <div id="updateDiffResult"></div>
    <div style="margin-top:6px">
      ${selectField("update_save_mode", "Save as", [
        { value: "overwrite", label: "Overwrite the selected PSD in place" },
        { value: "new_copy", label: "Save as a new copy (old PSD untouched)" },
      ])}
    </div>
    <div id="updateNewCopyWrap" style="${saveMode === "new_copy" ? "" : "display:none"}">
      ${field("output_name", "Output name (new copy)", { type: "text", placeholder: "empty = auto (from workbook name)" })}
      ${selectField("output_format", "Output format", [
        { value: "PSD", label: "PSD" },
        { value: "PSB", label: "PSB (large document)" },
      ])}
      ${fileRow("output_dir", "Output folder (new copy)", "", "dir")}
      <div class="hint" style="margin-top:-6px;margin-bottom:12px">Empty = saved next to the Excel file.</div>
    </div>
    ${toggleRow("safe_backup", "Safe backup before update", "Copies the previous PSD to a timestamped backup before overwriting.")}
    ${field("safe_backup_folder", "Backup folder (optional)", { type: "text", placeholder: "empty = next to the PSD" })}
  `;
  bindForms(body);
  body.querySelector('[data-key="update_save_mode"]')?.addEventListener("change", () => App.renderUpdateDialog());
  const psdInput = body.querySelector('[data-key="prev_psd_path"]');
  if (psdInput) psdInput.addEventListener("change", () => App.ptCheckProject(psdInput.value));
  const existing = String(c.prev_psd_path || "").trim();
  if (existing) App.ptCheckProject(existing);
};

App.ptCheckProject = async (psd) => {
  const statusEl = document.getElementById("updateProjectStatus");
  if (!statusEl) return;
  const p = String(psd || "").trim();
  if (!p || !/\.(psd|psb)$/i.test(p)) { App._pjManifest = null; App._pjBaseline = null; statusEl.innerHTML = ""; return; }
  try {
    const d = await api("/api/project/detect", { method: "POST", body: { psd: p } });
    const b = d.baseline || {};
    App._pjBaseline = b.exists ? b : null;
    if (d.ok && d.exists && d.manifest) {
      App._pjManifest = d.manifest;
      // The package remembers the source workbook (manifest files.excel) and
      // the saved baseline removes the need for a user-provided Old Excel.
      const pkg = d.package || {};
      const pkgExcel = (pkg.files || {}).excel || {};
      const pkgExcelPath = String(pkgExcel.absolute || pkgExcel.relative || "").trim();
      if (pkgExcelPath && !String(App.state.config.excel_path || "").trim()) {
        App.state.config.excel_path = pkgExcelPath;
        const newExcelInput = document.querySelector('[data-key="excel_path"]');
        if (newExcelInput) newExcelInput.value = pkgExcelPath;
      }
      // Legacy recovery path: no baseline yet -> remember the Old Excel from
      // the package so the first update can store it as the new baseline.
      if (!b.exists && pkgExcelPath && !String(App.state.config.prev_excel_path || "").trim()) {
        App.state.config.prev_excel_path = pkgExcelPath;
        const oldExcelInput = document.querySelector('[data-key="prev_excel_path"]');
        if (oldExcelInput) oldExcelInput.value = pkgExcelPath;
      }
      const baselineTxt = b.exists
        ? `<div class="pj-status ok">Saved Excel baseline found — <b>V${b.version_number || 1}</b>${b.original_path ? ` &mdash; ${esc(b.original_path)}` : ""}. The Old Excel is not needed.</div>`
        : `<div class="pj-status warn">This PSD has no saved Excel baseline &mdash; provide the Old Excel for this first update (it is stored as the baseline).</div>`;
      statusEl.innerHTML = `<div class="pj-status ok">Project package found — <b>${esc(d.project_name || "")}</b> (${esc(d.project_id || "")}). Its settings will be restored when you run the update.</div>${baselineTxt}`;
    } else {
      App._pjManifest = null;
      App._pjBaseline = null;
      statusEl.innerHTML = `<div class="hint" style="margin-top:6px">No project package beside this PSD — the update will create one (and save a baseline) on save.</div>`;
    }
    const st = await api("/api/update/status", { method: "POST", body: { psd: p } });
    if (st.ok && st.current_excel && !String(App.state.config.excel_path || "").trim()) {
      App.state.config.excel_path = st.current_excel;
      const newExcelInput = document.querySelector('[data-key="excel_path"]');
      if (newExcelInput) newExcelInput.value = st.current_excel;
    }
  } catch (e) {
    App._pjManifest = null;
    App._pjBaseline = null;
    statusEl.innerHTML = `<div class="pj-status err">${esc(e.message)}</div>`;
  }
};

App.loadProjectPackage = async (path, opts = {}) => {
  const d = await api("/api/project/load", { method: "POST", body: { path } });
  if (!d.ok) throw new Error(d.error || "Could not load the project package.");
  App.state.config = d.config;
  App._pjManifest = d.manifest || path;
  App._pjInfo = d.project || null;
  App._ptPreviewDirty = true;
  await App.flushConfig();
  try { await App.scan(); } catch (e) { /* scan is best-effort */ }
  if (!opts.silent) {
    toast(`Project <b>${esc((d.project && d.project.project_name) || "package")}</b> loaded.`, "ok");
  }
  return d;
};

App.saveProjectPackageNow = async () => {
  const psd = String(App.state.config.prev_psd_path || "").trim();
  if (!psd) { toast("Open the PSD first (Open a PSD on the dashboard).", "err"); return; }
  try {
    const d = await api("/api/project/save", { method: "POST", body: { psd } });
    if (!d.ok) throw new Error(d.error || "Could not save the project package.");
    toast("Project package saved.", "ok");
  } catch (e) { toast(e.message, "err"); }
};

App.reloadProjectPackage = async () => {
  if (!App._pjManifest) { toast("No project package loaded.", "err"); return; }
  try {
    await App.loadProjectPackage(App._pjManifest);
    renderRoute();
  } catch (e) { toast(e.message, "err"); }
};

App.updatePreviewNow = async () => {
  const c = App.state.config;
  const resultEl = document.getElementById("updateDiffResult");
  const btn = document.getElementById("updatePreviewBtn");
  if (!resultEl) return;
  if (!c.prev_psd_path) {
    resultEl.innerHTML = `<div class="pj-status err">Set the Old PSD path first.</div>`;
    return;
  }
  if (!c.excel_path) {
    resultEl.innerHTML = `<div class="pj-status err">Set the New Excel first.</div>`;
    return;
  }
  if (btn) { btn.disabled = true; btn.textContent = "Scanning…"; }
  try {
    const d = await api("/api/update/preview", { method: "POST", body: {
      prev_psd_path: c.prev_psd_path, prev_excel_path: c.prev_excel_path,
      excel_path: c.excel_path, max_col_limit: c.max_col_limit,
    }});
    if (d.no_changes) {
      resultEl.innerHTML = `<div class="pj-status ok" style="margin-top:6px"><b>No changes detected in source Excel.</b> The PSD does not need an update.</div>`;
      return;
    }
    const diff = d.diff || {};
    const changed = (diff.changed || []).length;
    const added = (diff.added || []).length;
    const removed = (diff.removed || []).length;
    const unchanged = (diff.unchanged || []).length;
    const srcTxt = d.baseline_used
      ? ` diffing against the saved baseline <b>V${(d.baseline || {}).version_number || 1}</b>`
      : "";
    let html = `<div class="pj-status ${(changed + added + removed) ? "warn" : "ok"}" style="margin-top:6px">
      <b>${changed}</b> changed · <b>${added}</b> added · <b>${removed}</b> removed · <b>${unchanged}</b> unchanged${srcTxt}`;
    if (diff.details && diff.details.length) {
      html += `<div class="suggestion-list" style="margin-top:8px;max-height:150px;overflow-y:auto">${diff.details.slice(0, 40).map((l) => `<div class="suggestion"><span>${esc(l)}</span></div>`).join("")}</div>`;
    }
    html += `</div>`;
    resultEl.innerHTML = html;
  } catch (e) {
    resultEl.innerHTML = `<div class="pj-status err">${esc(e.message)}</div>`;
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = "Preview changes"; }
  }
};

App.runUpdate = async () => {
  // The package restore overwrites config with the OLD workbook, so remember
  // the user's chosen New Excel and put it back after loading.
  const newExcel = String(App.state.config.excel_path || "").trim();
  if (App._pjManifest) {
    try {
      const d = await App.loadProjectPackage(App._pjManifest, { silent: true });
      App._pjManifest = d ? (d.manifest || App._pjManifest) : App._pjManifest;
    } catch (e) { toast(e.message, "err"); return; }
  }
  const c = App.state.config;
  if (newExcel && newExcel !== String(c.excel_path || "").trim()) {
    App.state.config.excel_path = newExcel;
  }
  if (!c.excel_path) { toast("Choose the New Excel first.", "err"); return; }
  if (!c.prev_psd_path) { toast("Update needs the Old PSD path.", "err"); return; }
  // The Old Excel is optional: PSDs saved by this tool carry a baseline that
  // is diffed automatically. Only PSDs without a baseline need it once.
  const hasBaseline = !!(App._pjBaseline && App._pjBaseline.exists);
  const oldExcel = String(c.prev_excel_path || "").trim();
  if (!hasBaseline && !oldExcel) {
    toast("This PSD has no saved Excel baseline — provide the Old Excel once (it is stored as the new baseline).", "err");
    return;
  }
  // Validate that the Old PSD path points to a .psd or .psb file
  const psdPath = String(c.prev_psd_path || "").trim();
  if (psdPath && !/\.(psd|psb)$/i.test(psdPath)) {
    toast("The Old PSD path must point to a .psd or .psb file.", "err"); return;
  }
  App.closeUpdateDialog();
  App.startUpdate();
};

App.applyOutput = () => {
  App.closeOutputDialog();
  renderRoute();
  toast("Output settings saved.");
};

/* ------------------------------ canvas dialog ------------------------------ */

App._canvas = { w: 1920, h: 1080, orient: "landscape", res: 72, preset: null };

App.openCanvasDialog = () => {
  const c = App.state.config;
  const w = c.c_width || 1920, h = c.c_height || 1080;
  const match = App.state.canvasPresets.find((p) => p.name === c.canvas_preset)
    || App.state.canvasPresets.find((p) => p.width === w && p.height === h);
  App._canvas = {
    w, h,
    orient: w >= h ? "landscape" : "portrait",
    res: c.c_resolution || 72,
    preset: match ? match.name : null,
  };
  App.renderCanvasDialog();
  document.getElementById("canvasOverlay").hidden = false;
};

App.closeCanvasDialog = () => {
  document.getElementById("canvasOverlay").hidden = true;
};

App.renderCanvasDialog = () => {
  const s = App._canvas;
  const orientSize = (p, orient) => {
    const landscape = p.width >= p.height;
    const wantLandscape = orient === "landscape";
    return landscape === wantLandscape ? [p.width, p.height] : [p.height, p.width];
  };
  const presets = App.state.canvasPresets.map((p) => {
    const [pw, ph] = orientSize(p, s.orient);
    const active = s.preset === p.name || (s.w === pw && s.h === ph);
    return `<button class="canvas-preset ${active ? "active" : ""}" onclick="App.pickPreset('${esc(p.name).replace(/'/g, "\\'")}')">
      <span class="cp-name">${esc(p.name)}</span><span class="cp-size">${pw} × ${ph}</span>
    </button>`;
  }).join("");
  document.getElementById("canvasPresets").innerHTML = presets;

  document.querySelectorAll("#canvasOrient .seg-btn").forEach((b) => {
    b.classList.toggle("active", b.dataset.orient === s.orient);
  });

  const resList = [72, 96, 120, 150, 300];
  if (!resList.includes(s.res)) resList.push(s.res);
  resList.sort((a, b) => a - b);
  document.getElementById("canvasResolution").innerHTML = resList
    .map((r) => `<option value="${r}" ${r === s.res ? "selected" : ""}>${r} PPI</option>`).join("");

  document.getElementById("canvasSummary").innerHTML =
    `<span><b>${s.w} × ${s.h}</b> px</span><span>${s.orient === "portrait" ? "Portrait" : "Landscape"} · ${s.res} PPI</span>`;
};

App.pickPreset = (name) => {
  const p = App.state.canvasPresets.find((x) => x.name === name);
  if (!p) return;
  const s = App._canvas;
  s.preset = p.name;
  const landscape = p.width >= p.height;
  const wantLandscape = s.orient === "landscape";
  if (landscape === wantLandscape) { s.w = p.width; s.h = p.height; }
  else { s.w = p.height; s.h = p.width; }
  App.renderCanvasDialog();
};

App.setOrient = (orient) => {
  const s = App._canvas;
  s.orient = orient;
  [s.w, s.h] = [s.h, s.w];
  s.preset = null;
  const match = App.state.canvasPresets.find((p) => p.width === s.w && p.height === s.h);
  if (match) s.preset = match.name;
  App.renderCanvasDialog();
};

App.applyCanvas = () => {
  const s = App._canvas;
  const res = parseInt(document.getElementById("canvasResolution").value, 10) || 72;
  const p = App.state.canvasPresets.find((x) => x.name === s.preset);
  App.set("c_width", s.w);
  App.set("c_height", s.h);
  App.set("c_resolution", res);
  App.set("canvas_preset", p ? p.name : "Custom");
  App.pushConfig();
  App.closeCanvasDialog();
  renderRoute();
  toast(`Canvas set to ${s.w}×${s.h} @ ${res} PPI`);
};

/* ------------------------------ pages dialog ------------------------------ */

App._pagesGroup = "pages";

App.openPagesDialog = (group = "pages") => {
  App._pagesGroup = group;
  App.renderPagesDialog();
  document.getElementById("pagesOverlay").hidden = false;
  const el = document.querySelector(`.page-group[data-group="${group}"]`);
  if (el) el.scrollIntoView({ block: "start" });
};

App.closePagesDialog = () => {
  document.getElementById("pagesOverlay").hidden = true;
};

App.selectSheets = (mode) => {
  const c = App.state.config;
  const sheets = App.state.scan?.excel?.sheets || [];
  c.selected_sheets = mode === "all" ? sheets.map((s) => s.name) : [];
  App.pushConfig();
  renderRoute();
  App.renderPagesDialog();
};

App.renderPagesDialog = () => {
  const scan = App.state.scan;
  const c = App.state.config;
  const groups = [
    { key: "pages", label: "Pages" },
    { key: "paytables", label: "Paytables" },
    { key: "game_rules", label: "Game Rules" },
    { key: "bingo_rules", label: "Bingo Rules" },
  ];
  document.getElementById("pagesSub").innerHTML = c.excel_path
    ? `<b>${esc(c.excel_path.split(/[\\/]/).pop())}</b> — ${(scan?.excel?.sheets || []).length} sheet(s) total in the workbook.`
    : "No Excel loaded yet.";

  if (!scan?.excel?.ok || !(scan?.excel?.sheets || []).length) {
    document.getElementById("pagesBody").innerHTML = `<div class="empty" style="padding:28px">
      <div class="empty-icon">▦</div><div class="empty-title">No scan yet</div>
      <div class="empty-sub">Load your Excel from the dashboard Excel card or Project view — pages, paytables and legal sheets will appear here.</div></div>`;
    return;
  }

  const allOff = !c.render_all_pages;
  const selected = c.selected_sheets || [];
  const winRaw = (c.dynamic_settings || {}).page_render_window_overrides || "";
  const body = groups.map((g) => {
    const list = scan?.excel?.[g.key] || [];
    const rows = list.length
      ? list.map((s) => {
          const mb = s.master_border;
          const currentRange = App._sheetWindowRange(winRaw, s.name);
          const borderHint = mb
            ? `border R${mb.min_row}–${mb.max_row} · C${App._colIndexToLetter(mb.min_col)}–${App._colIndexToLetter(mb.max_col)}`
            : "";
          return `
        <div class="sheet-row ${allOff && selected.includes(s.name) ? "selected" : ""}" onclick="App.toggleSheet('${esc(s.name).replace(/'/g, "\\'")}');App.renderPagesDialog();">
          <span class="sheet-check"></span>
          <span class="sheet-name">${esc(s.name)}</span>
          <span class="chip ${s.type !== "page" ? "blue" : ""}">${esc((s.type || "page").replace(/_/g, " "))}</span>
          <span class="sheet-meta">${s.rows}×${s.cols}</span>
          <div class="pg-window" onclick="event.stopPropagation()" title="Data range: rows/columns to render from this sheet. Blank = auto (detected master border, else the default window). Examples: B2:BL30, A:L, 2:30."
            ><span class="pg-window-label">Data</span>
            <input type="text" class="pg-window-input" value="${esc(currentRange)}" placeholder="auto" data-sheet="${esc(s.name).replace(/"/g, "&quot;")}" spellcheck="false" />
            <span class="pg-window-hint">${borderHint ? esc(borderHint) : "no border detected"}</span>
          </div>
        </div>`; })
        .join("")
      : `<div class="page-group-empty">No ${g.label.toLowerCase()} sheets detected.</div>`;
    return `<div class="page-group" data-group="${g.key}">
      <div class="page-group-head">
        <span class="page-group-name">${g.label}<span class="page-group-count">${list.length}</span></span>
        ${allOff && list.length ? `<span class="hint">${list.filter((s) => selected.includes(s.name)).length} selected</span>` : ""}
      </div>
      <div class="sheet-list">${rows}</div>
    </div>`;
  }).join("");

  document.getElementById("pagesBody").innerHTML = `
    <div class="page-toolbar">
      <div class="toggle-row" style="flex:1">
        <div><div class="t-label">Render all pages</div><div class="hint">Turn off to render only the selected sheets below.</div></div>
        <label class="switch"><input type="checkbox" id="pagesRenderAll" ${!allOff ? "checked" : ""} /><span class="track"></span></label>
      </div>
      <div style="display:flex;gap:8px">
        <button class="btn secondary small" onclick="App.selectSheets('all')">Select all</button>
        <button class="btn secondary small" onclick="App.selectSheets('none')">Select none</button>
      </div>
    </div>
    ${body}`;
  document.getElementById("pagesRenderAll")?.addEventListener("change", (e) => {
    App.set("render_all_pages", e.target.checked);
    App.pushConfig();
    App.renderPagesDialog();
  });
  document.querySelectorAll(".pg-window-input").forEach((input) => {
    input.addEventListener("change", () => {
      const sheet = input.dataset.sheet;
      const value = input.value.trim();
      App.setSheetWindowRange(sheet, value);
      toast(value ? `Data range for ${sheet}: ${value}` : `Data range for ${sheet}: auto`);
    });
    input.addEventListener("focus", () => { App._focusedKey = null; });
  });
};

App._colIndexToLetter = (idx) => {
  let s = "";
  idx = parseInt(idx, 10) || 0;
  while (idx > 0) {
    const r = (idx - 1) % 26;
    s = String.fromCharCode(65 + r) + s;
    idx = Math.floor((idx - 1) / 26);
  }
  return s;
};

App._sheetWindowRange = (raw, sheetName) => {
  for (const line of String(raw || "").split(/\r?\n/)) {
    const m = line.match(/^\s*([^=|\n]+)\s*(?:=|:)\s*([^=\n]*?)\s*$/);
    if (m && m[1].trim() === sheetName) return m[2].trim();
  }
  return "";
};

App.setSheetWindowRange = (sheetName, value) => {
  const c = App.state.config;
  const ds = (c.dynamic_settings = c.dynamic_settings || {});
  const raw = String(ds.page_render_window_overrides || "");
  const lines = raw.split(/\r?\n/).filter((l) => l.trim());
  const key = sheetName;
  const out = [];
  let replaced = false;
  for (const line of lines) {
    const m = line.match(/^\s*([^=|\n]+)\s*(?:=|:)\s*(.*)$/);
    if (m && m[1].trim() === key) {
      if (value) out.push(`${key}=${value}`);
      replaced = true;
    } else {
      out.push(line);
    }
  }
  if (!replaced && value) out.push(`${key}=${value}`);
  const final = out.join("\n");
  if (final !== raw) {
    App.set("dynamic_settings.page_render_window_overrides", final);
    App.pushConfig();
  }
  App.renderPagesDialog();
};

/* ------------------------------ missing icons dialog ------------------------------ */

App.openMissingDialog = () => {
  App.renderMissingDialog();
  document.getElementById("missingOverlay").hidden = false;
};

App.closeMissingDialog = () => {
  document.getElementById("missingOverlay").hidden = true;
};

App.renderMissingDialog = () => {
  const scan = App.state.scan;
  const icons = scan?.icons;
  const c = App.state.config;
  const folderName = c.icon_folder ? c.icon_folder.split(/[\\/]/).filter(Boolean).pop() : "";
  document.getElementById("missingSub").innerHTML = c.excel_path
    ? `<b>${esc(c.excel_path.split(/[\\/]/).pop())}</b>${folderName ? ` — icons checked against <b>${esc(folderName)}</b>` : ""}`
    : "No Excel loaded yet.";

  if (!scan?.excel?.ok || !(scan?.excel?.sheets || []).length) {
    document.getElementById("missingBody").innerHTML = `<div class="empty" style="padding:28px">
      <div class="empty-icon">⚠</div><div class="empty-title">No scan yet</div>
      <div class="empty-sub">Load your Excel first — icon tokens are extracted from the workbook automatically.</div></div>`;
    return;
  }
  if (!icons?.ok) {
    document.getElementById("missingBody").innerHTML = `<div class="empty" style="padding:28px">
      <div class="empty-icon">📁</div><div class="empty-title">No icon folder</div>
      <div class="empty-sub">Set the icon folder below (or in Project view) to check which icons are missing.</div></div>`;
    return;
  }

  const missing = icons.missing || [];
  const matched = icons.matched || [];
  const tokens = icons.tokens || [];
  if (!missing.length) {
    document.getElementById("missingBody").innerHTML = `<div class="empty" style="padding:28px">
      <div class="empty-icon">✓</div><div class="empty-title">All icons matched</div>
      <div class="empty-sub">All ${tokens.length} icon token(s) in the Excel have a matching PNG in ${esc(folderName || "the icon folder")}.</div></div>`;
    return;
  }

  const rows = missing.map((m) => `<div class="sheet-row">
    <span class="chip warn">missing</span>
    <span class="sheet-name">${esc(m)}</span>
  </div>`).join("");
  document.getElementById("missingBody").innerHTML = `
    <div class="page-group-head">
      <span class="page-group-name">Missing PNGs<span class="page-group-count">${missing.length}</span></span>
      <span class="hint">${matched.length} of ${tokens.length} tokens matched</span>
    </div>
    <div class="sheet-list">${rows}</div>
    <div class="hint" style="margin-top:12px">Add a PNG with the exact token name in the icon folder and scan again — the icons list refreshes automatically.</div>`;
};

App.loadIcons = async () => {
  try {
    const data = await api(`/api/icons?folder=${encodeURIComponent(App.state.config.icon_folder)}`);
    App.state.iconFiles = data.files;
    renderRoute();
  } catch (e) { toast(e.message, "err"); }
};

/* ------------------------------ icon mapper ------------------------------ */

App.state.mapperTab = "tokens";
App.mapperOverride = {};
App.mapperSizes = {};

const mapperNorm = (t) => String(t || "").toLowerCase().replace(/[\s_-]+/g, " ").trim();

App.openMapper = async () => {
  document.getElementById("mapperOverlay").hidden = false;
  App.state.mapperTab = "tokens";
  await App.loadMapperData();
  App.renderMapper();
};

App.closeMapper = () => {
  document.getElementById("mapperOverlay").hidden = true;
  App.closeMapperPopup();
};

App.reloadMapper = async () => {
  await App.loadMapperData();
  App.renderMapper();
};

App.loadMapperData = async () => {
  try {
    const data = await api("/api/icons?folder=" + encodeURIComponent(App.state.config.icon_folder));
    App.state.iconFiles = data.files || [];
  } catch (e) { toast(e.message, "err"); }
  App.mapperOverride = App.state.config.icon_mappings || {};
  App.mapperSizes = App.state.config.icon_size_overrides || {};
};

App.switchMapperTab = (tab) => {
  App.state.mapperTab = tab;
  document.querySelectorAll(".mapper-tab").forEach((b) => b.classList.toggle("active", b.dataset.tab === tab));
  App.renderMapper();
};

App.renderMapper = () => {
  const q = (document.getElementById("mapperSearch")?.value || "").toLowerCase();
  const files = App.state.iconFiles || [];
  const tokens = App.state.scan?.icons?.tokens || [];
  const missing = App.state.scan?.icons?.missing || [];
  const sizes = App.mapperSizes || {};
  const maps = App.mapperOverride || {};
  const tab = App.state.mapperTab || "tokens";

  document.getElementById("mapperTokenCount").textContent = tokens.length;
  document.getElementById("mapperAllCount").textContent = files.length;

  let html = "";
  if (tab === "tokens") {
    const list = tokens.filter((t) => !q || mapperNorm(t).includes(q));
    const matched = list.filter((t) => !missing.includes(t));
    const missed = list.filter((t) => missing.includes(t));
    html = `
      <div class="mapper-section">
        <div class="mapper-section-head"><span>Matched tokens · ${matched.length}</span><span class="hint">Right-click to override size or relink the asset</span></div>
        <div class="mapper-grid">
          ${matched.map((t) => App.mapperTokenTileHTML(t)).join("") || `<div class="empty" style="padding:26px;grid-column:1/-1"><div class="empty-sub">No matched tokens.</div></div>`}
        </div>
      </div>
      <div class="mapper-section">
        <div class="mapper-section-head"><span>Missing tokens · ${missed.length}</span><span class="hint">Right-click to map a missing token to an existing asset</span></div>
        <div class="mapper-grid">
          ${missed.map((t) => App.mapperTokenTileHTML(t)).join("") || `<div class="empty" style="padding:26px;grid-column:1/-1"><div class="empty-sub">All tokens matched — nice.</div></div>`}
        </div>
      </div>`;
  } else {
    const list = files.filter((f) => f.name.toLowerCase().includes(q));
    html = `<div class="mapper-grid">
      ${list.map((f) => App.mapperFileTileHTML(f)).join("") || `<div class="empty" style="padding:26px;grid-column:1/-1"><div class="empty-sub">No icons with that name found.</div></div>`}
    </div>`;
  }
  document.getElementById("mapperBody").innerHTML = html;
  bindMapperContextMenus();
};

App.mapperTokenFile = (token) => {
  const maps = App.mapperOverride || {};
  const v = maps[token];
  return v ? String(v).split(/[\\/]/).pop() : "";
};

App.mapperPreviewFile = (token, overrideFile) => {
  if (overrideFile) return String(overrideFile).split(/[\\/]/).pop();
  const files = App.state.iconFiles || [];
  const compact = (s) => String(s || "").toLowerCase().replace(/[^a-z0-9]+/g, "");
  const spread = (s) => String(s || "").toLowerCase().replace(/[\s_-]+/g, " ");
  const want = compact(token);
  const wantSpread = spread(token);
  for (const f of files) {
    const stem = f.name.replace(/\.[^.]+$/, "");
    if (compact(stem) === want || spread(stem) === wantSpread) return f.name;
  }
  return "";
};

App.importMapperImage = (populateOverrideInput = true) => {
  App.closeMapperPopup();
  const input = document.createElement("input");
  input.type = "file";
  input.accept = "image/png,image/jpeg,image/gif,image/svg+xml,image/bmp";
  input.onchange = async () => {
    const file = input.files && input.files[0];
    if (!file) return;
    const key = App._mapperKey;
    const fd = new FormData();
    fd.append("file", file);
    if (key) fd.append("token", key);
    const folder = App.state.config.icon_folder || "";
    if (folder) fd.append("folder", folder);
    const btn = document.querySelector(".mapper-toolbar button.primary");
    if (btn) btn.disabled = true;
    try {
      const data = await api("/api/icon_upload", { method: "POST", body: fd });
      await App.loadMapperData();
      App.mapperOverride = App.mapperOverride || {};
      if (key) App.mapperOverride[key] = data.name;
      App.renderMapper();
      toast(`Imported <b>${esc(data.name)}</b> for <b>${esc(key || "library")}</b>. Save to keep.`, "ok");
      if (populateOverrideInput) App.openMapperEditor("override");
    } catch (e) {
      toast(e.message, "err");
    } finally {
      if (btn) btn.disabled = false;
    }
  };
  input.click();
};

App.mapperTokenTileHTML = (token) => {
  const maps = App.mapperOverride || {};
  const sizes = App.mapperSizes || {};
  const overrideFile = App.mapperTokenFile(token);
  const size = sizes[token];
  const missing = (App.state.scan?.icons?.missing || []).includes(token);
  const coverage = overrideFile ? "overridden" : missing ? "missing" : "matched";
  const previewName = App.mapperPreviewFile(token, overrideFile);
  const badges = [];
  badges.push(`<span class="m-badge ${coverage === "missing" ? "red" : coverage === "overridden" ? "blue" : ""}">${coverage}</span>`);
  if (size) badges.push(`<span class="m-badge">${esc(size)}px</span>`);
  if (overrideFile) badges.push(`<span class="m-badge blue">→ ${esc(String(overrideFile).split(/[\\/]/).pop())}</span>`);
  return `<div class="mapper-tile" data-token="${esc(token)}">
    ${previewName
      ? `<img class="m-thumb" src="/api/icon_file?folder=${encodeURIComponent(App.state.config.icon_folder)}&name=${encodeURIComponent(previewName)}" onerror="this.classList.add('missing')" alt="">`
      : `<div class="m-thumb missing" style="display:grid;place-items:center;width:64px;height:64px;border:1px dashed var(--border-strong);border-radius:10px;font-size:20px">?</div>`}
    <div class="m-name">${esc(token)}</div>
    <div class="m-badges">${badges.join("")}</div>
  </div>`;
};

App.mapperFileTileHTML = (file) => {
  const sizes = App.mapperSizes || {};
  const maps = App.mapperOverride || {};
  const stem = file.name.replace(/\.[^.]+$/, "");
  const size = sizes[stem];
  const mapped = maps[stem];
  const badges = [];
  if (size) badges.push(`<span class="m-badge">${esc(size)}px</span>`);
  if (mapped) badges.push(`<span class="m-badge blue">→ ${esc(String(mapped).split(/[\\/]/).pop())}</span>`);
  return `<div class="mapper-tile" data-token="${esc(stem)}" data-file="${esc(file.name)}">
    ${badges.length ? `<div class="m-badges">${badges.join("")}</div>` : ""}
    <img class="m-thumb" src="/api/icon_file?folder=${encodeURIComponent(App.state.config.icon_folder)}&name=${encodeURIComponent(file.name)}" alt="">
    <div class="m-name">${esc(file.name)}</div>
  </div>`;
};

App.closeMapperPopup = () => {
  document.getElementById("mapperCtx")?.remove();
  document.getElementById("mapperEditor")?.remove();
};

App.openMapperEditor = (mode) => {
  const key = App._mapperKey;
  if (!key) return;
  App.closeMapperPopup();
  const sizes = App.mapperSizes || {};
  const maps = App.mapperOverride || {};
  const currentSize = sizes[key] || "";
  const currentMap = maps[key] || "";
  const files = App.state.iconFiles || [];
  const el = document.createElement("div");
  el.id = "mapperEditor";
  el.className = "mapper-editor";
  el.innerHTML = `
    <div class="mapper-editor-title">${esc(key)}</div>
    ${mode === "size" || !mode ? `
    <div class="field"><label>Icon size (px, 0 or empty = auto)</label>
      <input type="number" min="0" max="1000" id="meSize" value="${esc(currentSize)}" class="slider-num" style="width:100%" />
    </div>` : ""}
    ${mode === "override" || !mode ? `
    <div class="field"><label>Override asset (file name in the icon folder, or full path)</label>
      <div class="mapper-io-row">
        <input type="text" id="meOverride" value="${esc(currentMap)}" placeholder="e.g. golden_scatter.png" list="mapperFiles" style="flex:1" />
        <button class="btn secondary" onclick="App.importMapperImage(true)">Import from PC</button>
      </div>
      <datalist id="mapperFiles">${files.map((f) => `<option value="${esc(f.name)}">`).join("")}</datalist>
      <div class="hint">Import a new image from your computer, or pick an existing asset from the list.</div>
    </div>` : ""}
    <div class="mapper-editor-row">
      <button class="btn primary" style="flex:1" onclick="App.applyMapperEditor()">Apply</button>
      <button class="btn ghost" onclick="App.closeMapperPopup()">Cancel</button>
    </div>`;
  const left = (event && typeof event.clientX === "number" ? event.clientX + 16 : window.innerWidth / 2);
  const top = (event && typeof event.clientY === "number" ? event.clientY - 10 : window.innerHeight / 3);
  el.style.left = `${Math.min(left, window.innerWidth - 340)}px`;
  el.style.top = `${Math.min(top, window.innerHeight - 260)}px`;
  document.body.appendChild(el);
  el.querySelector("#meSize")?.focus?.();
};

App.applyMapperEditor = () => {
  const key = App._mapperKey;
  const sizeEl = document.getElementById("meSize");
  const ovrEl = document.getElementById("meOverride");
  App.mapperSizes = App.mapperSizes || {};
  App.mapperOverride = App.mapperOverride || {};
  if (sizeEl) {
    const size = parseInt(sizeEl.value, 10);
    if (size && !isNaN(size)) App.mapperSizes[key] = size; else delete App.mapperSizes[key];
  }
  if (ovrEl) {
    const override = (ovrEl.value || "").trim();
    if (override) App.mapperOverride[key] = override; else delete App.mapperOverride[key];
  }
  document.getElementById("mapperEditor")?.remove();
  App.renderMapper();
  toast(`Updated <b>${esc(key)}</b> — remember to save.`, "ok");
};

App.clearMapper = (key) => {
  delete App.mapperOverride[key];
  delete App.mapperSizes[key];
  App.closeMapperPopup();
  App.renderMapper();
};

App.saveMapper = async () => {
  App.state.config.icon_mappings = App.mapperOverride || {};
  App.state.config.icon_size_overrides = App.mapperSizes || {};
  try {
    await api("/api/mappings", { method: "POST", body: {
      icon_mappings: App.mapperOverride,
      icon_size_overrides: App.mapperSizes,
    } });
    App.pushConfig();
    toast("Icon mappings saved.");
    renderRoute();
  } catch (e) { toast(e.message, "err"); }
};

function bindMapperContextMenus() {
  document.querySelectorAll("#mapperBody .mapper-tile").forEach((tile) => {
    tile.addEventListener("contextmenu", (e) => {
      e.preventDefault();
      const key = tile.dataset.token || tile.dataset.file || "";
      App._mapperKey = key;
      App.closeMapperPopup();
      const el = document.createElement("div");
      el.id = "mapperCtx";
      el.className = "mapper-ctx";
      el.innerHTML = `
        <div class="mapper-ctx-title">${esc(key)}</div>
        <button class="mapper-ctx-item" onclick="App.openMapperEditor('size')">Icon size…</button>
        <button class="mapper-ctx-item" onclick="App.openMapperEditor('override')">Relink / override…</button>
        <button class="mapper-ctx-item" onclick="App.importMapperImage(true)">Import image from PC…</button>
        <div class="mapper-ctx-sep"></div>
        <button class="mapper-ctx-item danger" onclick="App.clearMapper(App._mapperKey)">Reset mapping</button>`;
      el.style.left = `${Math.min(e.clientX, window.innerWidth - 240)}px`;
      el.style.top = `${Math.min(e.clientY - 8, window.innerHeight - 190)}px`;
      document.body.appendChild(el);
    });
  });
}

document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("mapperSearch")?.addEventListener("input", () => App.renderMapper());
  document.getElementById("mapperClose")?.addEventListener("click", App.closeMapper);
  document.querySelectorAll(".mapper-tab").forEach((b) => b.addEventListener("click", () => App.switchMapperTab(b.dataset.tab)));
  document.addEventListener("click", (e) => {
    if (!e.target.closest("#mapperCtx")) document.getElementById("mapperCtx")?.remove();   // the editor stays: ✕ / Cancel
  });
});

App.savePreset = async () => {
  const name = document.getElementById("presetName")?.value.trim();
  if (!name) { toast("Enter a preset name.", "err"); return; }
  try {
    await api("/api/presets/" + encodeURIComponent(name), { method: "POST", body: { config: App.state.config } });
    App.state.presets = (await api("/api/presets")).presets;
    toast(`Preset “${name}” saved.`);
    renderRoute();
  } catch (e) { toast(e.message, "err"); }
};

/* ------------------------------ table mapper ------------------------------ */

App.tableMapper = null;

function tmHex(v) {
  if (Array.isArray(v)) {
    const rgb = v.slice(0, 3).map((n) => Math.max(0, Math.min(255, Math.round(Number(n) || 0))));
    return "#" + rgb.map((n) => n.toString(16).padStart(2, "0")).join("");
  }
  const s = String(v ?? "").trim();
  if (/^#?[0-9a-fA-F]{6}$/.test(s)) return "#" + s.replace(/^#/, "");
  return "#FFFFFF";
}

function tmProp(key, label, kind, value, options = {}) {
  const k = esc(key);
  const val = value == null ? "" : value;
  if (kind === "color") {
    return `<div class="tm-prop"><label>${label}</label><input type="color" value="${tmHex(val)}" oninput="App.tmSet('${k}', this.value)" /></div>`;
  }
  if (kind === "select") {
    const opts = options.options.map((o) =>
      `<option value="${esc(o.value)}" ${String(o.value) === String(val) ? "selected" : ""}>${esc(o.label)}</option>`).join("");
    return `<div class="tm-prop"><label>${label}</label><select onchange="App.tmSet('${k}', this.value)">${opts}</select></div>`;
  }
  if (kind === "checkbox") {
    return `<div class="tm-prop tm-switch"><label>${label}</label><input type="checkbox" ${val ? "checked" : ""} onchange="App.tmSet('${k}', this.checked)" /></div>`;
  }
  if (kind === "number") {
    return `<div class="tm-prop"><label>${label}</label><input type="number" value="${esc(val)}" min="${options.min ?? 0}" max="${options.max ?? 9999}" step="${options.step ?? 1}" oninput="App.tmSet('${k}', parseFloat(this.value) || 0)" /></div>`;
  }
  return `<div class="tm-prop"><label>${label}</label><input type="text" value="${esc(val)}" placeholder="${esc(options.placeholder || "")}" oninput="App.tmSet('${k}', this.value)" /></div>`;
}

App.openTableMapper = async () => {
  document.getElementById("tableMapperOverlay").hidden = false;
  if (!App.tableMapper || !App.tableMapper.template) {
    App.tableMapper = {
      psdPath: "",
      template: null,
      mappings: {},
      sheetName: "",
      tableName: "",
      sourceRange: "",
      previewToken: "",
      iconInfo: {},
      selected: "",
      selectedSet: new Set(),
      zoom: 1,
    };
    const lastJson = (App.get("table_style.mapped_table_jsons") || "")
      .split(/[\n;]+/).map((s) => s.trim()).filter(Boolean).pop() || "";
    if (lastJson) {
      document.getElementById("tmPsdPath").value = lastJson;
      await App.tmLoadJson(lastJson);
    } else {
      const stored = App.get("table_style.mapped_template_psd");
      if (stored) {
        App.tableMapper.psdPath = stored;
        document.getElementById("tmPsdPath").value = stored;
      }
    }
  }
  App.tmRenderSheets();
  App.tmRenderBody();
};

App.tmClose = () => {
  App.tmCloseSlotEditor();
  App.tmCloseUnmapped();
  document.getElementById("tableMapperOverlay").hidden = true;
};

App.tmBrowsePsd = async () => {
  const native = window.pywebview?.api;
  if (native) {
    try {
      const path = await native.browse_file("template");
      if (path) {
        document.getElementById("tmPsdPath").value = path;
        App.tableMapper.psdPath = path;
        App.set("table_style.mapped_template_psd", path);
        App.pushConfig();
      }
      return;
    } catch (e) { /* fall through */ }
  }
  try {
    const [fh] = await window.showOpenFilePicker({
      types: [
        { description: "Photoshop files", accept: { "image/vnd.adobe.photoshop": [".psd", ".psb"] } },
        { description: "JSON files", accept: { "application/json": [".json"] } },
      ],
    });
    const file = await fh.getFile();
    const path = file.webkitRelativePath || file.name;
    document.getElementById("tmPsdPath").value = path;
    App.tableMapper.psdPath = path;
    toast("In browser mode paste the full PSD path into the field.", "err");
  } catch (e) {
    if (e && e.name !== "AbortError") toast(e.message, "err");
  }
};

App.tmLoadJson = async (path) => {
  try {
    const d = await api("/api/table_template/load", { method: "POST", body: { path } });
    if (!d.ok) { toast(d.error || "Load failed", "err"); return; }
    App.set("table_style.mapped_template_psd", path);
    App.pushConfig();
    App.tableMapper.template = d.template;
    App.tableMapper.mappings = {};
    (d.mappings || []).forEach((m) => { if (m && m.slot) App.tableMapper.mappings[m.slot] = m; });
    App.tableMapper.sheetName = d.sheet_name || "";
    App.tableMapper.tableName = d.table_name || "";
    App.tableMapper.sourceRange = d.source_range || "";
    App.tableMapper.spec = d.spec || null;
    App.tableMapper.previewToken = d.preview_token || "";
    App.tableMapper.iconInfo = {};
    App.tableMapper.selected = "";
    App.tableMapper.zoom = 1;
    document.getElementById("tmTableName").value = App.tableMapper.tableName;
    document.getElementById("tmSourceRange").value = App.tableMapper.sourceRange;
    App.tmRenderSheets();
    App.tmRenderBody();
    App.tmRefreshPreview();
    toast(`Loaded ${Object.keys(d.mappings || {}).length || (d.mappings || []).length} mapping(s) from JSON.`, "ok");
  } catch (e) { toast(e.message, "err"); }
};

App.tmScan = async () => {
  const psdPath = document.getElementById("tmPsdPath").value.trim();
  if (!psdPath) { toast("Enter a PSD template path first.", "err"); return; }
  if (!/\.(psd|psb)$/i.test(psdPath)) {
    if (/\.json$/i.test(psdPath)) { await App.tmLoadJson(psdPath); return; }
    toast("Select a .psd / .psb file (or a .json to edit an existing mapping).", "err");
    return;
  }
  App.tableMapper.psdPath = psdPath;
  App.set("table_style.mapped_template_psd", psdPath);
  App.pushConfig();
  toast("Scanning PSD slots in Photoshop…", "ok");
  try {
    const d = await api("/api/table_template/scan", { method: "POST", body: { psd_path: psdPath } });
    if (!d.ok) { toast(d.error || "Scan failed", "err"); return; }
    App.tableMapper.template = d.template;
    App.tableMapper.previewToken = d.preview_token || "";
    App.tableMapper.iconInfo = {};
    App.tableMapper.mappings = {};
    App.tableMapper.selected = "";
    App.tableMapper.zoom = 1;
    App.tableMapper.spec = null;
    App.tableMapper.tableName = d.template?.template_id || App.tableMapper.tableName;
    document.getElementById("tmTableName").value = App.tableMapper.tableName;
    App.tmRenderSheets();
    App.tmRenderBody();
    const n = Object.keys(d.template?.slots || {}).length;
    toast(`Scanned ${n} slot(s) from ${d.template?.source_psd || "PSD"}.`, "ok");
    const sheets = App.state.scan?.excel?.sheets || [];
    if (!sheets.length && App.state.config.excel_path) {
      try {
        const sc = await api("/api/scan", { method: "POST", body: { excel_path: App.state.config.excel_path, icon_folder: App.state.config.icon_folder || "" } });
        if (sc?.excel?.sheets?.length) {
          App.state.scan = sc;
          App.tmRenderSheets();
        }
      } catch (e) { /* non-fatal */ }
    }
    if (App.state.scan?.excel?.sheets?.length) await App.tmAutoMap();
  } catch (e) { toast(e.message, "err"); }
};

App.tmRenderSheets = () => {
  const sel = document.getElementById("tmSheet");
  if (!sel) return;
  const sheets = (App.state.scan?.excel?.sheets || []).map((s) => s.name).filter(Boolean);
  const cur = App.tableMapper?.sheetName || sheets[0] || "";
  sel.innerHTML = sheets.map((n) => `<option value="${esc(n)}" ${n === cur ? "selected" : ""}>${esc(n)}</option>`).join("") ||
    `<option value="">No sheets scanned — scan Excel first</option>`;
  if (App.tableMapper) App.tableMapper.sheetName = cur;
  App.tmSheetChanged();
};

App.tmSheetChanged = () => {
  const sel = document.getElementById("tmSheet");
  if (App.tableMapper && sel) App.tableMapper.sheetName = sel.value;
};

App.tmAutoMap = async () => {
  const tm = App.tableMapper;
  if (!tm || !tm.template) { toast("Scan a PSD template first.", "err"); return; }
  const sheet = document.getElementById("tmSheet")?.value || tm.sheetName;
  tm.sheetName = sheet;
  tm.tableName = document.getElementById("tmTableName")?.value.trim() || tm.tableName;
  if (!sheet) { toast("Select an Excel sheet first.", "err"); return; }
  if (!App.state.config.excel_path) { toast("Set the Excel file in Project first.", "err"); return; }
  try {
    const d = await api("/api/table_mapper/automap", {
      method: "POST",
      body: { template: tm.template, excel_path: App.state.config.excel_path, sheet_name: sheet },
    });
    if (!d.ok) { toast(d.error || "Auto-map failed", "err"); return; }
    let added = 0;
    (d.mappings || []).forEach((m) => {
      if (!m || !m.slot) return;
      if (!tm.mappings[m.slot]) { tm.mappings[m.slot] = m; added++; }
    });
    const src = document.getElementById("tmSourceRange")?.value.trim();
    if (!src) {
      tm.sourceRange = "";
      try {
        const r = await api("/api/table_mapper/source_range", { method: "POST", body: { mappings: d.mappings } });
        if (r && r.range) { tm.sourceRange = r.range; document.getElementById("tmSourceRange").value = r.range; }
      } catch (e) { /* optional */ }
    }
    App.tmRenderBody();
    if (added) {
      toast(`Auto-mapped ${added} slot(s) from cell references.`, "ok");
    } else {
      toast("No cell-reference slots found — select slots and set their Excel source manually.", "err");
    }
    const unmapped = (d.unmapped || []).filter((s) => !tm.mappings[s]);
    if (unmapped.length) App.tmShowUnmapped(unmapped);
    App.tmRefreshPreview();
  } catch (e) { toast(e.message, "err"); }
};

App.tmShowUnmapped = (slots) => {
  const list = (slots || []).slice();
  if (!list.length) return;
  const old = document.getElementById("tmUnmappedOverlay");
  if (old) old.remove();
  const el = document.createElement("div");
  el.id = "tmUnmappedOverlay";
  el.className = "tm-unmapped-overlay";
  el.innerHTML = `<div class="tm-unmapped-dialog">
      <div class="tm-slot-editor-head">
        <div class="tm-slot-editor-title">Not auto-mapped (${list.length})</div>
        <button class="btn ghost small" onclick="App.tmCloseUnmapped()" title="Close">X</button>
      </div>
      <div class="tm-unmapped-msg">These slots were not auto-mapped because their names don't point to any Excel cell. Assign them manually: right-click a slot in the preview or list, then set the Excel source in the popup.</div>
      <div class="tm-unmapped-list">${list.map((s) => `<div class="tm-unmapped-item">${esc(s)}</div>`).join("")}</div>
      <div class="tm-slot-editor-actions">
        <button class="btn primary" onclick="App.tmCloseUnmapped()">Close</button>
      </div>
    </div>`;
  document.body.appendChild(el);
};

App.tmCloseUnmapped = () => {
  document.getElementById("tmUnmappedOverlay")?.remove();
};

App.tmSet = (key, value) => {
  const tm = App.tableMapper;
  if (!tm || !tm.selected || !tm.mappings[tm.selected]) return;
  App.tmSelSet().forEach((name) => {
    const m = tm.mappings[name];
    if (!m) return;
    if (key === "kind") delete m.role;
    m[key] = value;
    if (key === "font_size") m.font_override = true;
  });
  App.tmRenderPreview();
  App.tmRefreshPreview();
};

App.tmEnsureMapping = (name) => {
  const tm = App.tableMapper;
  if (!tm) return null;
  if (!tm.mappings[name]) {
    const src = tmSlotRefSource(name);
    tm.mappings[name] = {
      kind: src ? "flow" : "background",
      source: src,
      slot: name,
      font_size: 30,
      font_override: false,
      icon_height: 48,
      color: "#FFFFFF",
      alignment: "center",
      vertical_align: "center",
      padding: [0, 0, 0, 0],
    };
  }
  return tm.mappings[name];
};

App.tmSelSet = () => {
  const tm = App.tableMapper;
  if (!tm) return new Set();
  if (!tm.selectedSet || typeof tm.selectedSet.has !== "function") {
    tm.selectedSet = new Set(tm.selected ? [tm.selected] : []);
  }
  return tm.selectedSet;
};

App.tmSelect = (name, e) => {
  const tm = App.tableMapper;
  if (!tm) return;
  const multi = !!(e && (e.ctrlKey || e.metaKey || e.shiftKey));
  if (multi) {
    const set = App.tmSelSet();
    if (set.has(name)) set.delete(name); else set.add(name);
    if (set.size === 0) set.add(name);
    tm.selected = name;
  } else {
    tm.selected = name;
    tm.selectedSet = new Set([name]);
  }
  App.tmEnsureMapping(name);
  App.tmRenderBody();
};

function tmColIndex(letters) {
  let idx = 0;
  for (const ch of String(letters || "").toUpperCase()) idx = idx * 26 + (ch.charCodeAt(0) - 64);
  return idx;
}

function tmActiveSheetDims() {
  const sheets = App.state.scan?.excel?.sheets || [];
  if (!sheets.length) return null;
  const want = App.paytableMapper?.sheetName || App.tableMapper?.sheetName ||
    (App.state.config?.selected_sheets || [])[0] || sheets[0].name;
  const s = sheets.find((x) => x.name === want) || sheets[0];
  return s && s.rows ? { rows: s.rows, cols: s.cols || 0 } : null;
}

function tmSlotRefSource(slotName) {
  const raw = String(slotName || "");
  let m = raw.match(/^(?:@table\.)?([A-Za-z]{1,3})(\d+)(?::([A-Za-z]{1,3})(\d+))?$/);
  if (!m) {
    const tail = raw.split(".").pop() || "";
    m = tail.match(/^([A-Za-z]{1,3})(\d+)(?::([A-Za-z]{1,3})(\d+))?$/);
  }
  if (!m) return "";
  const inBounds = (letter, row) => {
    const dims = tmActiveSheetDims();
    if (!dims) return false;
    const ci = tmColIndex(letter);
    return ci >= 1 && ci <= (dims.cols || 0) && row >= 1 && row <= (dims.rows || 0);
  };
  const r1 = parseInt(m[2], 10);
  const r2 = m[4] ? parseInt(m[4], 10) : null;
  if (!inBounds(m[1], r1)) return "";
  if (m[3] && !inBounds(m[3], r2)) return "";
  return m[3] ? `${m[1]}${m[2]}:${m[3]}${m[4]}` : `${m[1]}${m[2]}`;
}

function tmIsBoundsSlot(slotName) {
  const raw = String(slotName || "");
  const last = raw.split(".").pop().toLowerCase().replace(/[^a-z0-9]+/g, "");
  const full = raw.toLowerCase().replace(/[^a-z0-9]+/g, "");
  return ["bound", "bounds", "tablebound", "tablebounds", "container", "tablebox", "bg", "background", "textbg", "textbackground"].indexOf(last) !== -1
    || /bg\d*$/.test(full);
}

// Card-back boxes (topcardsbg.N / bottomcardsbg.N / cardbg.N) look like
// "bg" bounds slots but are real, user-movable paytable slots.
function ptmIsCardBackSlot(slotName) {
  return /^(?:@slot\.)?(?:topcardsbg|bottomcardsbg|cardbg)\./i.test(String(slotName || ""));
}

App.tmRemoveMapping = (name) => {
  const tm = App.tableMapper;
  if (!tm) return;
  delete tm.mappings[name];
  if (tm.selected === name) tm.selected = "";
  App.tmSelSet().delete(name);
  App.tmCloseSlotEditor();
  App.tmRenderBody();
  App.tmRefreshPreview();
};

App.tmRenderPreview = () => {
  const wrap = document.getElementById("tmPreview");
  if (!wrap) return;
  const tm = App.tableMapper;
  if (!tm || !tm.template) return;
  const cw = tm.template.canvas?.width || 1;
  const ch = tm.template.canvas?.height || 1;
  const slots = tm.template.slots || {};
  const mapped = new Set(Object.keys(tm.mappings || {}));
  wrap.querySelectorAll(".tm-slot").forEach((el) => {
    const name = el.dataset.slot;
    const isSel = App.tmSelSet().has(name);
    el.classList.toggle("mapped", mapped.has(name));
    el.classList.toggle("empty", !mapped.has(name));
    el.classList.toggle("selected", isSel);
    if (isSel) {
      const wrapRect = wrap.getBoundingClientRect();
      const img = wrap.querySelector("img");
      const imgRect = img ? img.getBoundingClientRect() : wrapRect;
      const box = slots[name] || {};
      el.style.top = ((box.y || 0) / ch) * 100 + "%";
      el.style.left = ((box.x || 0) / cw) * 100 + "%";
      el.style.width = ((box.w || 1) / cw) * 100 + "%";
      el.style.height = ((box.h || 1) / ch) * 100 + "%";
    }
  });
};

App.tmRefreshPreview = (() => {
  let timer = null;
  return async () => {
    const tm = App.tableMapper;
    if (!tm || !tm.template) return;
    if (timer) clearTimeout(timer);
    timer = setTimeout(async () => {
      timer = null;
      try {
        const sheet = document.getElementById("tmSheet")?.value || tm.sheetName || "";
        const d = await api("/api/table_mapper/preview", {
          method: "POST",
          body: {
            template: tm.template,
            mappings: Object.values(tm.mappings || {}),
            sheet_name: sheet,
          },
        });
        if (d.ok && d.preview_token) {
          tm.previewToken = d.preview_token;
          if (d.icons) tm.iconInfo = d.icons || {};
          const img = document.querySelector("#tmPreview img");
          if (img) img.src = "/api/table_preview/" + encodeURIComponent(d.preview_token) + "?v=" + Date.now();
        }
      } catch (e) { /* live preview refresh is best-effort */ }
    }, 350);
  };
})();

App.tmRenderBody = () => {
  const body = document.getElementById("tmBody");
  if (!body) return;
  const tm = App.tableMapper;
  if (!tm || !tm.template) {
    body.innerHTML = `<main class="workspace">
      <section class="panel">
        <div class="panel-header"><span class="panel-title">Template Preview</span><span class="panel-meta"></span></div>
        <div class="empty-container">Scan a PSD template — layers named <b>@table.B7</b>, <b>@table.C33</b>, <b>@table.D8:J22</b>… become slots and auto-map to matching Excel cells.</div>
      </section>
      <section class="panel">
        <div class="panel-header"><span class="panel-title">Properties</span><span class="panel-meta">none</span></div>
        <div class="empty-container" style="background-color:transparent">Click a slot to edit its properties — Shift+click to multi-select and edit together.</div>
      </section>
    </main>`;
    return;
  }
  const slots = tm.template.slots || {};
  const cw = tm.template.canvas?.width || 1;
  const ch = tm.template.canvas?.height || 1;
  const mapped = tm.mappings || {};
  const selSet = App.tmSelSet();

  const slotBoxes = Object.keys(slots).map((name) => {
    const b = slots[name] || {};
    const isSel = selSet.has(name);
    return `<div class="tm-slot ${mapped[name] ? "mapped" : "empty"} ${isSel ? "selected" : ""} ${tmIsBoundsSlot(name) ? "tm-bounds" : ""}"
      data-slot="${esc(name)}" style="top:${((b.y || 0) / ch) * 100}%;left:${((b.x || 0) / cw) * 100}%;width:${((b.w || 1) / cw) * 100}%;height:${((b.h || 1) / ch) * 100}%">
      <span class="tm-slot-name">${esc(name)}</span>
      ${mapped[name] && mapped[name].source ? `<span class="tm-slot-src">${esc(mapped[name].source)}</span>` : ""}
    </div>`;
  }).join("");

  const zoom = Math.max(0.25, Math.min(4, tm.zoom || 1));
  const previewHeaderRt = tm.previewToken
    ? `<span class="tm-panel-rt">
        <span class="tm-zoom-ctl">
          <button onclick="App.tmSetZoom(0.9)" title="Zoom out">−</button>
          <span id="tmZoomLabel">${Math.round(zoom * 100)}%</span>
          <button onclick="App.tmSetZoom(1.1)" title="Zoom in">+</button>
          <button onclick="App.tmResetZoom()" title="Reset zoom to 100%">100%</button>
        </span>
        <span class="panel-meta">${esc(tm.template.source_psd || "")}</span>
      </span>`
    : `<span class="panel-meta">${esc(tm.template.source_psd || "")}</span>`;

  const previewHtml = `<section class="panel">
      <div class="panel-header">
        <span class="panel-title">Template Preview</span>
        ${previewHeaderRt}
      </div>
      <div class="tm-preview-area">${tm.previewToken
        ? `<div class="tm-canvas-wrap" id="tmPreview" style="position:relative;width:${Math.min(cw, 820) * zoom}px;aspect-ratio:${cw}/${ch}">
            <img src="/api/table_preview/${encodeURIComponent(tm.previewToken)}" style="width:100%;height:100%;object-fit:fill" alt="template preview" />
            ${slotBoxes}
          </div>`
        : `<div class="empty-container">No preview available.</div>`}
      </div>
    </section>`;

  const selCount = selSet.size;
  const propsPanel = `<section class="panel">
      <div class="panel-header">
        <span class="panel-title">Properties</span>
        <span class="panel-meta">${selCount ? (selCount === 1 ? "1 selected" : `${selCount} selected`) : "none selected"}</span>
      </div>
      <div id="tmPropsPanel" class="tm-props-panel">${selCount && tm.selected
        ? App.tmSidebarHtml()
        : `<div class="empty-container" style="background-color:transparent">Click a slot to edit its properties — Shift+click to multi-select and edit together.</div>`}
      </div>
    </section>`;

  body.innerHTML = `<main class="workspace">${previewHtml}${propsPanel}</main>`;
  body.querySelectorAll("[data-slot]").forEach((el) => {
    el.addEventListener("click", (ev) => App.tmSelect(el.dataset.slot, ev));
  });
  const wrap = document.getElementById("tmPreview");
  if (wrap) {
    wrap.addEventListener("mousedown", (e) => App.tmMarqueeStart(e, wrap));
    wrap.addEventListener("wheel", (e) => {
      if (!e.ctrlKey) return;
      e.preventDefault();
      App.tmSetZoom(e.deltaY < 0 ? 1.1 : 0.9);
    }, { passive: false });
  }
};

App.tmSetZoom = (mult) => {
  const tm = App.tableMapper;
  if (!tm || !tm.template) return;
  tm.zoom = Math.max(0.25, Math.min(4, Math.round(((tm.zoom || 1) * mult) * 100) / 100));
  App.tmApplyZoom();
};

App.tmResetZoom = () => {
  const tm = App.tableMapper;
  if (!tm) return;
  tm.zoom = 1;
  App.tmApplyZoom();
};

App.tmApplyZoom = () => {
  const tm = App.tableMapper;
  if (!tm || !tm.template) return;
  const wrap = document.getElementById("tmPreview");
  if (wrap) {
    const cw = tm.template.canvas?.width || 1;
    wrap.style.width = Math.min(cw, 820) * (tm.zoom || 1) + "px";
  }
  const label = document.getElementById("tmZoomLabel");
  if (label) label.textContent = Math.round((tm.zoom || 1) * 100) + "%";
};

App.tmSetSelection = (names) => {
  const tm = App.tableMapper;
  if (!tm) return;
  tm.selectedSet = new Set(names || []);
  tm.selected = (names || []).length ? names[0] : "";
  (names || []).forEach((n) => App.tmEnsureMapping(n));
  App.tmRenderBody();
};

App.tmMarqueeStart = (e, wrap) => {
  if (e.button !== 0) return;
  if (e.target.closest(".tm-slot:not(.tm-bounds)")) return;
  e.preventDefault();
  const tm = App.tableMapper;
  if (!tm || !tm.template) return;
  const rect = wrap.getBoundingClientRect();
  const toPct = (clientX, clientY) => [
    ((clientX - rect.left) / rect.width) * 100,
    ((clientY - rect.top) / rect.height) * 100,
  ];
  const [sx, sy] = toPct(e.clientX, e.clientY);
  const box = document.createElement("div");
  box.className = "tm-marquee";
  wrap.appendChild(box);
  const move = (ev) => {
    const [cx, cy] = toPct(ev.clientX, ev.clientY);
    box.style.left = Math.min(sx, cx) + "%";
    box.style.top = Math.min(sy, cy) + "%";
    box.style.width = Math.abs(cx - sx) + "%";
    box.style.height = Math.abs(cy - sy) + "%";
  };
  const up = (ev) => {
    document.removeEventListener("mousemove", move);
    document.removeEventListener("mouseup", up);
    if (box.isConnected) box.remove();
    const [ex, ey] = toPct(ev.clientX, ev.clientY);
    if (Math.abs(ex - sx) < 0.4 && Math.abs(ey - sy) < 0.4) {
      App.tmSetSelection([]);
      return;
    }
    const sel = { left: Math.min(sx, ex), top: Math.min(sy, ey), right: Math.max(sx, ex), bottom: Math.max(sy, ey) };
    const slots = tm.template.slots || {};
    const cw = tm.template.canvas?.width || 1;
    const ch = tm.template.canvas?.height || 1;
    const hit = [];
    Object.keys(slots).forEach((name) => {
      if (tmIsBoundsSlot(name)) return;
      const b = slots[name] || {};
      const sl = ((b.x || 0) / cw) * 100;
      const st = ((b.y || 0) / ch) * 100;
      const sr = (((b.x || 0) + (b.w || 1)) / cw) * 100;
      const sb = (((b.y || 0) + (b.h || 1)) / ch) * 100;
      if (sl <= sel.right && sr >= sel.left && st <= sel.bottom && sb >= sel.top) hit.push(name);
    });
    if (!hit.length) {
      App.tmSetSelection([]);
      return;
    }
    let set = new Set(hit);
    if (ev.shiftKey || ev.ctrlKey || ev.metaKey) {
      const prev = App.tmSelSet();
      set.forEach((n) => prev.add(n));
      set = prev;
    }
    App.tmSetSelection([...set]);
  };
  document.addEventListener("mousemove", move);
  document.addEventListener("mouseup", up);
};

function tmPropsSectionsHtml(m, suffix) {
  const kind = String(m.kind || "flow").toLowerCase();
  const kindSel = kind === "heading" ? "heading" : kind === "icon" ? "icon" : kind === "dedicated_icon" ? "dedicated_icon" : "flow";
  const fonts = (App.state.fonts || []).slice();
  const fontOpts = fonts.map((f) => `<option value="${esc(f)}" ${String(f).toLowerCase() === String(m.font_name || m.font_family || "").toLowerCase() ? "selected" : ""}>${esc(f)}</option>`).join("");
  const align = m.alignment || "center";
  const fontListId = `tmSlotEditorFonts${suffix || ""}`;
  const iconInfo = (App.tableMapper && App.tableMapper.iconInfo) || {};
  const ico = iconInfo[m.slot] || {};
  const iconFolder = (App.get("icon_folder") || "").trim();
  const iconPreview = ico.file
    ? `<img src="/api/icon_file?folder=${encodeURIComponent(iconFolder)}&name=${encodeURIComponent(ico.file)}" alt="${esc(ico.token || "icon")}" onerror="this.classList.add('missing')" />`
    : `<span class="tm-icon-preview-empty">${esc(ico.token || "No icon found — check the Excel source or icon folder")}</span>`;
  const iconSection = kind === "icon" ? `
      <div class="config-section">
        <h4 class="section-title">Icon</h4>
        <div class="form-grid">
          <label class="form-label">Icon height</label>
          <input type="number" class="form-control" value="${esc(m.icon_height ?? 48)}" min="1" max="400" oninput="App.tmSet('icon_height', parseFloat(this.value) || 0)" />
          <label class="form-label">Token</label>
          <span class="form-control tm-icon-token">${esc(ico.token || "—")}</span>
        </div>
        <div class="tm-icon-preview">${iconPreview}</div>
      </div>` : "";
  const inlineIconSection = kind === "flow" ? `
      <div class="config-section">
        <h4 class="section-title">Inline icons</h4>
        <div class="form-grid">
          <label class="form-label">Icon height</label>
          <input type="number" class="form-control" value="${esc(m.icon_height ?? 48)}" min="1" max="400" oninput="App.tmSet('icon_height', parseFloat(this.value) || 0)" />
          <label class="form-label">Hint</label>
          <span class="form-control tm-icon-token">Icons inside this slot's text (&lt;token&gt;) render at this height.</span>
        </div>
      </div>` : "";
  const layerStyleLibrary = (App.state.config.dynamic_settings || {}).layer_style_library || {};
  const layerStyleSection = `
      <div class="config-section">
        <h4 class="section-title">Layer style</h4>
        <div class="form-grid">
          <label class="form-label">Style</label>
          <select class="form-control" data-lsswatch onchange="App.tmSet('layer_style', this.value)">
            <option value="" ${!m.layer_style ? "selected" : ""}>None (no styles)</option>
            ${Object.keys(layerStyleLibrary).sort((a, b) => a.localeCompare(b)).map((n) => `<option value="${esc(n)}" ${n === m.layer_style ? "selected" : ""}>${esc(n)}</option>`).join("")}
          </select>
          <label class="form-label">Hint</label>
          <span class="form-control tm-icon-token">Layer styles are captured in Dynamic Pages settings and are applied to this slot's text/icons when building in Photoshop.</span>
        </div>
      </div>`;
  return `<div class="modal-body">
      <div class="config-section">
        <h4 class="section-title">Content</h4>
        <div class="form-grid">
          <label class="form-label">Kind</label>
          <select class="form-control" onchange="App.tmSet('kind', this.value)">
            <option value="heading" ${kindSel === "heading" ? "selected" : ""}>Heading</option>
            <option value="flow" ${kindSel === "flow" ? "selected" : ""}>Normal text / icon</option>
            <option value="icon" ${kindSel === "icon" ? "selected" : ""}>Icon</option>
            <option value="dedicated_icon" ${kindSel === "dedicated_icon" ? "selected" : ""}>Image</option>
          </select>
          <label class="form-label">Excel source</label>
          <input type="text" class="form-control" value="${esc(m.source || "")}" placeholder="e.g. J9 or D8:J22" oninput="App.tmSet('source', this.value)" />
          <label class="form-label">Custom text</label>
          <input type="text" class="form-control" value="${esc(m.text || "")}" placeholder="leave empty to use Excel content" oninput="App.tmSet('text', this.value)" />
        </div>
      </div>
      ${inlineIconSection}
      ${iconSection}
      <div class="config-section">
        <h4 class="section-title">Typography</h4>
        <div class="form-grid">
          <label class="form-label">Font</label>
          <input type="text" class="form-control" list="${fontListId}" value="${esc(m.font_name || m.font_family || "")}" placeholder="Default font…" oninput="App.tmSet('font_name', this.value)" /><datalist id="${fontListId}">${fontOpts}</datalist>
          <label class="form-label">Font size</label>
          <input type="number" class="form-control" value="${esc(m.font_size ?? 30)}" min="4" max="400" oninput="App.tmSet('font_size', parseFloat(this.value) || 0)" />
          <label class="form-label">Fit content</label>
          <label class="checkbox-wrapper"><input type="checkbox" ${!m.font_override ? "checked" : ""} onchange="App.tmSet('font_override', !this.checked)" /><span>Auto-fit font to slot</span></label>
          <label class="form-label">Alignment</label>
          <select class="form-control" onchange="App.tmSet('alignment', this.value)">
            <option value="center" ${align === "center" ? "selected" : ""}>Center</option>
            <option value="left" ${align === "left" ? "selected" : ""}>Left</option>
            <option value="right" ${align === "right" ? "selected" : ""}>Right</option>
          </select>
          <label class="form-label">Text color</label>
          <input type="color" class="form-control" value="${tmHex(m.color || "#FFFFFF")}" oninput="App.tmSet('color', this.value)" />
        </div>
      </div>
      ${layerStyleSection}
      <div class="config-section">
        <h4 class="section-title">Background</h4>
        <div class="form-grid">
          <label class="form-label">Fill bg</label>
          <label class="checkbox-wrapper"><input type="checkbox" ${m.fill_enabled ? "checked" : ""} onchange="App.tmSet('fill_enabled', this.checked)" /><span>Enable</span></label>
          <label class="form-label">Bg color</label>
          <input type="color" class="form-control" value="${tmHex(m.background_color || "#000000")}" oninput="App.tmSet('background_color', this.value)" />
          <label class="form-label">Bg opacity %</label>
          <input type="number" class="form-control" value="${esc(m.opacity ?? 100)}" min="0" max="100" oninput="App.tmSet('opacity', parseFloat(this.value) || 0)" />
        </div>
      </div>
      <div class="config-section">
        <h4 class="section-title">Stroke</h4>
        <div class="form-grid">
          <label class="form-label">Stroke none</label>
          <label class="checkbox-wrapper"><input type="checkbox" ${m.stroke_enabled ? "" : "checked"} onchange="App.tmSet('stroke_enabled', !this.checked)" /><span>Disable stroke</span></label>
          <label class="form-label">Stroke width</label>
          <input type="number" class="form-control" value="${esc(m.stroke_width ?? 0)}" min="0" max="50" oninput="App.tmSet('stroke_width', parseFloat(this.value) || 0)" />
          <label class="form-label">Stroke color</label>
          <input type="color" class="form-control" value="${tmHex(m.stroke_color || "#FFFFFF")}" oninput="App.tmSet('stroke_color', this.value)" />
        </div>
      </div>
    </div>`;
}

App.tmSidebarHtml = () => {
  const tm = App.tableMapper;
  if (!tm || !tm.selected) return "";
  const m = tm.mappings[tm.selected] || {};
  const count = App.tmSelSet().size;
  return `<div class="tm-slot-editor tm-sidebar">
      <div class="tm-slot-editor-head">
        <div class="tm-slot-editor-title">Slot: <span>${esc(tm.selected)}</span>${count > 1 ? ` <span class="tm-sel-count">(${count} selected)</span>` : ""}</div>
      </div>
      ${tmPropsSectionsHtml(m, "Sb")}
      <div class="modal-footer">
        <div class="btn-group">
          <button class="btn btn-secondary" onclick="App.tmCopySlotProps()" title="Copy this slot's properties">Copy props</button>
          <button class="btn btn-secondary" onclick="App.tmPasteSlotProps()" title="Paste copied props into all selected slots">Paste props</button>
        </div>
        <button class="btn btn-primary" onclick="App.tmRemoveSelected()">Clear selected</button>
      </div>
    </div>`;
};

App.tmRefreshSidebar = () => {
  const panel = document.getElementById("tmPropsPanel");
  if (!panel) return;
  const tm = App.tableMapper;
  if (!tm || !tm.template) return;
  const selSet = App.tmSelSet();
  panel.innerHTML = selSet.size && tm.selected
    ? App.tmSidebarHtml()
    : `<div class="empty-container" style="background-color:transparent">Click a slot to edit its properties — Shift+click to multi-select and edit together.</div>`;
};

App.tmRemoveSelected = () => {
  const tm = App.tableMapper;
  if (!tm) return;
  let removed = 0;
  App.tmSelSet().forEach((name) => {
    if (tm.mappings[name]) { delete tm.mappings[name]; removed++; }
  });
  tm.selectedSet = new Set();
  tm.selected = "";
  App.tmCloseSlotEditor();
  App.tmRenderBody();
  App.tmRefreshPreview();
  if (removed) toast(`Cleared ${removed} mapping${removed > 1 ? "s" : ""}.`, "ok");
};

App.tmCloseSlotEditor = () => {
  const old = document.getElementById("tmSlotEditor");
  if (old) old.remove();
  App.tmSlotEditor = null;
};

App.tmCopySlotProps = () => {
  const tm = App.tableMapper;
  if (!tm || !tm.selected) { toast("Select a slot first.", "err"); return; }
  const m = tm.mappings[tm.selected] || {};
  const skip = new Set(["slot", "token", "token_index", "repeat_index"]);
  App._tmClipboard = {};
  Object.keys(m).forEach((k) => { if (!skip.has(k)) App._tmClipboard[k] = JSON.parse(JSON.stringify(m[k])); });
  toast(`Copied properties from ${tm.selected}.`, "ok");
};

App.tmPasteSlotProps = () => {
  const tm = App.tableMapper;
  if (!App._tmClipboard) { toast("Copy properties from a slot first.", "err"); return; }
  const targets = App.tmSelSet().size ? [...App.tmSelSet()] : (tm.selected ? [tm.selected] : []);
  if (!targets.length) { toast("Select a slot to paste into.", "err"); return; }
  const props = JSON.parse(JSON.stringify(App._tmClipboard));
  targets.forEach((name) => {
    const m = App.tmEnsureMapping(name);
    Object.assign(m, props);
    m.slot = name;
  });
  App.tmRenderPreview();
  App.tmRefreshSidebar();
  App.tmRefreshPreview();
  toast(`Pasted properties into ${targets.length} slot${targets.length > 1 ? "s" : ""}.`, "ok");
};

App.tmFinishSave = (d) => {
  if (d.config) App.state.config = d.config;
  App.pushConfig();
  renderRoute();
  let msg = "Saved mapped table JSON: " + d.path;
  if (d.removed && d.removed.length) msg += " - removed stale mapping(s) for this page: " + d.removed.join(", ");
  toast(msg, "ok");
  App.tmClose();
};

App.tmPromptSavePath = (defaultPath, body) => {
  const overlay = document.createElement("div");
  overlay.className = "overlay";
  overlay.innerHTML = `<div class="table-mapper-dialog" style="width:min(620px,92vw);max-height:unset;height:auto">
      <div class="panel-header" style="margin-bottom:14px"><span class="panel-title">Save mapped table JSON</span></div>
      <label class="tm-label" style="margin:0 0 6px">Output path</label>
      <input type="text" id="tmSavePathInput" class="tm-path" value="${esc(defaultPath || "")}" />
      <div class="tm-footer">
        <button class="btn ghost" id="tmSavePathCancel">Cancel</button>
        <button class="btn btn-primary tm-done-btn" id="tmSavePathOk">Save</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);
  const done = () => { if (overlay.isConnected) overlay.remove(); };
  // a click outside never closes it (what was typed in it would be lost): its ✕ or Cancel do
  document.getElementById("tmSavePathCancel").addEventListener("click", done);
  document.getElementById("tmSavePathOk").addEventListener("click", async () => {
    const path = document.getElementById("tmSavePathInput").value.trim();
    done();
    if (!path) { toast("Output path is required.", "err"); return; }
    try {
      const d = await api("/api/table_mapper/save", { method: "POST", body: { ...body, output_path: path } });
      if (!d.ok) { toast(d.error || "Save failed", "err"); return; }
      App.tmFinishSave(d);
    } catch (e) { toast("Save failed: " + e.message, "err"); }
  });
  document.getElementById("tmSavePathInput").focus();
};

App.tmSave = async (saveAs) => {
  const tm = App.tableMapper;
  if (!tm || !tm.template) { toast("Scan a PSD template first.", "err"); return; }
  const mappings = Object.values(tm.mappings).filter((m) => m && m.slot);
  if (!mappings.length) { toast("Map at least one slot before saving.", "err"); return; }
  const sheet = document.getElementById("tmSheet")?.value || tm.sheetName;
  const tableName = document.getElementById("tmTableName")?.value.trim() || tm.tableName || "table";
  const sourceRange = document.getElementById("tmSourceRange")?.value.trim() || tm.sourceRange || "";
  const body = {
    psd_path: tm.psdPath,
    sheet_name: sheet,
    table_name: tableName,
    source_range: sourceRange,
    template: tm.template,
    mappings,
    insert_mode: tm.spec?.insert_mode || "after_row",
    insert_after_row: tm.spec?.insert_after_row ?? 0,
    marker: tm.spec?.marker || "",
    absolute_x: tm.spec?.absolute_x ?? null,
    absolute_y: tm.spec?.absolute_y ?? null,
    margin_before: tm.spec?.margin_before ?? 30,
    margin_after: tm.spec?.margin_after ?? 30,
    fit_mode: tm.spec?.fit_mode || "scale",
    scale_if_needed: tm.spec?.scale_if_needed ?? true,
  };
  const finish = (d) => {
    if (!d.ok) { toast(d.error || "Save failed", "err"); return false; }
    App.tmFinishSave(d);
    return true;
  };
  if (saveAs) {
    const native = window.pywebview?.api;
    if (native && typeof native.save_file === "function") {
      try {
        const safeName = (tableName.replace(/[^A-Za-z0-9_\-]+/g, "_").replace(/^_+|_+$/g, "") || "table");
        const path = await native.save_file("Save mapped table JSON", safeName + "_mapped.json");
        if (!path) return;
        try {
          const d = await api("/api/table_mapper/save", { method: "POST", body: { ...body, output_path: path } });
          finish(d);
        } catch (e) { toast("Save failed: " + e.message, "err"); }
        return;
      } catch (e) {
        toast("Native save dialog failed (" + e.message + ") - falling back to server dialog.", "err");
      }
    }
  }
  try {
    const d = await api(saveAs ? "/api/table_mapper/save_as" : "/api/table_mapper/save", {
      method: "POST",
      body,
    });
    if (d.cancelled) {
      if (d.dialog_error) {
        toast("Windows save dialog unavailable (error " + d.dialog_error + ") - enter a path below.", "err");
        App.tmPromptSavePath(d.default_path || "", body);
      }
      return;
    }
    finish(d);
  } catch (e) {
    toast("Save failed: " + e.message + " - restart the server if the route is missing.", "err");
  }
};

/* ------------------------------ Paytable Mapper ------------------------------ */

App.ensurePaytableDefault = async () => {
  if (App.state.paytableDefaultReady) return;
  if (App.state.ptmUserPicked) { App.state.paytableDefaultReady = true; return; }
  const path = (App.get("dynamic_settings.template_json") || "").trim();
  let savedLoaded = false;
  if (path) {
    try {
      const ld = await api("/api/paytable_mapper/load", { method: "POST", body: { path } });
      if (ld.ok && ld.template) {
        if (App.state.ptmUserPicked) { App.state.paytableDefaultReady = true; return; }
        const mappings = {};
        Object.entries(ld.mappings || {}).forEach(([slot, m]) => {
          if (m && typeof m === "object") mappings[slot] = m;
        });
        App.ptmSanitizeMappings(mappings);
        App.ptmFillDefaults(mappings);
        App.paytableMapper = {
          psdPath: path,
          template: ld.template,
          mappings,
          sheetName: ld.sheet_name || "",
          tableName: ld.template_id || "",
          mappedPath: path,
          previewToken: ld.preview_token || "",
          iconIssues: [],
          overflowIssues: [],
          selected: "",
        };
        App.state.ptmGlobalStyles = ld.global_styles || App.state.ptmGlobalStyles || {};
        App.ptmApplyGlobalStyles();
        savedLoaded = true;
        // Only auto-map a SAVED session when it has no mappings yet. A file
        // that already carries saved mappings is the source of truth — the
        // user's per-slot choices (sizes, fonts) must never be re-assigned.
        const savedHasMappings = (ld.mappings && Object.keys(ld.mappings || {}).length > 0);
        if (!savedHasMappings && (ld.sheet_name || "") && App.state.config?.excel_path) {
          (async () => {
            try {
              const am = await api("/api/paytable_mapper/automap", {
                method: "POST",
                timeout: 25000,
                body: { template: ld.template, excel_path: App.state.config.excel_path, sheet_name: ld.sheet_name },
              });
              if (am && am.ok && App.paytableMapper && !App.state.ptmUserPicked) {
                const dims = am.sheet_dims?.rows ? am.sheet_dims : undefined;
                App.ptmApplyAutomap(am, App.paytableMapper.mappings, dims);
                if (App.route === "paytable") {
                  App.ptmSyncView();
                }
              }
            } catch (e) { /* automap optional — keep sanitized mappings */ }
          })();
        }
        try {
          const pv = await api("/api/paytable_mapper/preview", { method: "POST", body: { path, annotations: App._ptBlueprint !== false } });
          if (pv.ok && pv.preview_token && !App.state.ptmUserPicked) {
            App.state.paytablePreviewToken = pv.preview_token;
            App.state.paytableStats = { total: pv.slots_total || 0, mapped: pv.slots_mapped || 0, at: Date.now() };
          }
        } catch (e) { /* preview refresh is optional */ }
        if (App.state.ptmUserPicked) { App.state.paytableDefaultReady = true; return; }
        App.state.paytableDefaultReady = true;
        if (App.route === "paytable") {
          App.ptmSyncView();
        }
      }
    } catch (e) { /* configured template failed — fall back to the bundled default */ }
    if (savedLoaded) return;
  }
  let layouts = App.paytableLayouts;
  if (!layouts || !layouts.length) {
    try {
      const d = await api("/api/paytable_layouts", { method: "GET" });
      layouts = d.layouts || [];
      App.paytableLayouts = layouts;
    } catch (e) { return; }
  }
  const def = layouts.find((l) => l.default) || layouts.find((l) => l.name === "simple") || layouts[0];
  if (!def) return;
  try {
    const d = await api("/api/paytable_layouts/" + encodeURIComponent(def.name), { method: "GET" });
    const layout = d.layout || {};
    const template = layout.template || layout;
    const sheets = App.state.scan?.excel?.sheets || [];
    const paytables = App.state.scan?.excel?.paytables || [];
    const payName = (p) => String((p && p.name) || p || "").trim();
    const normPay = (p) => payName(p).toLowerCase().replace(/[^a-z0-9]/g, "");
    const sheet = paytables.find((p) => payName(p) && normPay(p).startsWith("paytable"))
      || paytables[0] || sheets[0];
    const sheetName = String((sheet && sheet.name) || sheet || "");
let mappings = {};
    if (sheet && App.state.config.excel_path) {
      try {
        const am = await api("/api/paytable_mapper/automap", {
          method: "POST",
          timeout: 25000,
          body: { template, excel_path: App.state.config.excel_path, sheet_name: sheetName },
        });
        (am.mappings || []).forEach((m) => { if (m && m.slot) mappings[m.slot] = m; });
      } catch (e) { /* automap optional — continue with empty mappings */ }
      if (App.state.ptmUserPicked) { App.state.paytableDefaultReady = true; return; }
    }
    App.ptmFillDefaults(mappings);
    const sv = await api("/api/paytable_mapper/save", {
      method: "POST",
      body: {
        psd_path: template.source_psd || "",
        sheet_name: sheetName,
        template_id: template.template_id || "SimplePaytable",
        template,
        mappings,
        slot_prefix: template.slot_prefix || "@slot",
      },
    });
    if (!sv.ok) throw new Error(sv.error || "Save failed");
    if (sv.config) { App.state.config = sv.config; App.pushConfig(); }
    if (sv.preview_token) { App.state.paytablePreviewToken = sv.preview_token; }
    App.state.paytableStats = {
      total: Object.keys(template.slots || {}).length,
      mapped: Object.keys(mappings).length,
      at: Date.now(),
    };
    App.paytableMapper = {
      psdPath: template.source_psd || "",
      template,
      mappings,
      sheetName: sheetName,
      tableName: template.template_id || "SimplePaytable",
      previewToken: sv.preview_token || "",
      selected: "",
    };
    App.state.paytableDefaultReady = true;
    if (App.route === "paytable") {
      App.ptmSyncView();
    }
    toast("Default paytable layout loaded" + (Object.keys(mappings).length ? ` and auto-mapped (${Object.keys(mappings).length} slots).` : "."), "ok");
  } catch (e) { /* non-fatal */ }
};

App.ensurePaytablePreview = async () => {
  if (App.state.ptmUserPicked) return;
  const path = (App.get("dynamic_settings.template_json") || "").trim();
  if (!path || App.state.paytablePreviewToken) return;
  try {
    const d = await api("/api/paytable_mapper/preview", { method: "POST", body: { path, annotations: App._ptBlueprint !== false } });
    if (d.ok && d.preview_token && d.preview_token !== App.state.paytablePreviewToken) {
      App.state.paytablePreviewToken = d.preview_token;
      if (typeof d.slots_total === "number") {
        App.state.paytableStats = { total: d.slots_total, mapped: d.slots_mapped || 0, at: Date.now() };
      }
      if (App.route === "paytable") App.ptmSyncView();
    }
  } catch (e) { /* non-fatal */ }
};

App.ptmValidate = async () => {
  const path = (App.get("dynamic_settings.template_json") || "").trim();
  if (!path) { toast("No mapped template configured — open the Paytable Mapper and save one first.", "err"); return; }
  const badge = document.getElementById("ptRenderBadge");
  if (badge) badge.classList.add("on");
  try {
    const d = await api("/api/paytable_mapper/preview", { method: "POST", body: { path, annotations: App._ptBlueprint !== false } });
    if (!d.ok) throw new Error(d.error || "Validation failed");
    const total = d.slots_total || 0;
    const mapped = d.slots_mapped || 0;
    const missing = total - mapped;
    App.state.paytableStats = { total, mapped, at: Date.now() };
    App.updatePaytableStats();
    toast(missing
      ? `Validation: ${mapped}/${total} slots mapped, ${missing} missing.`
      : `Validation passed — all ${total} slots mapped.`, missing ? "err" : "ok");
  } catch (e) { toast(e.message, "err"); }
  if (badge) badge.classList.remove("on");
};

App.ptmResetPreview = () => {
  App.state.paytablePreviewToken = "";
  App.state.paytableStats = null;
  if (App.paytableMapper) App.paytableMapper.previewToken = "";
  renderRoute();
};

App.ptmReplaceTemplate = () => {
  App.paytableMapper = null;
  App.state.ptmUserPicked = false;
  App.state.paytableDefaultReady = false;
  App.state.paytablePreviewToken = "";
  App.ensurePaytableDefault();
};

App.ptmDuplicate = async () => {
  const path = (App.get("dynamic_settings.template_json") || "").trim();
  if (!path) { toast("No mapped template configured yet.", "err"); return; }
  try {
    const d = await api("/api/paytable_mapper/duplicate", { method: "POST", body: { path } });
    if (!d.ok) { toast(d.error || "Duplicate failed", "err"); return; }
    App.set("dynamic_settings.template_json", d.path);
    if (d.preview_token) {
      App.state.paytablePreviewToken = d.preview_token;
      App.state.paytableStats = null;
    }
    App.paytableMapper = null;
    App.pushConfig();
    renderRoute();
    toast("Duplicated layout: " + d.path, "ok");
  } catch (e) { toast(e.message, "err"); }
};

function ptmProp(key, label, kind, value, options = {}) {
  const k = esc(key);
  const val = value == null ? "" : value;
  if (kind === "color") {
    return `<div class="tm-prop"><label>${label}</label><input type="color" value="${tmHex(val)}" oninput="App.ptmSet('${k}', this.value)" /></div>`;
  }
  if (kind === "select") {
    const opts = options.options.map((o) =>
      `<option value="${esc(o.value)}" ${String(o.value) === String(val) ? "selected" : ""}>${esc(o.label)}</option>`).join("");
    return `<div class="tm-prop"><label>${label}</label><select onchange="App.ptmSet('${k}', this.value)">${opts}</select></div>`;
  }
  if (kind === "checkbox") {
    return `<div class="tm-prop tm-switch"><label>${label}</label><input type="checkbox" ${val ? "checked" : ""} onchange="App.ptmSet('${k}', this.checked)" /></div>`;
  }
  if (kind === "number") {
    return `<div class="tm-prop"><label>${label}</label><input type="number" value="${esc(val)}" min="${options.min ?? 0}" max="${options.max ?? 9999}" step="${options.step ?? 1}" oninput="App.ptmSet('${k}', parseFloat(this.value) || 0)" /></div>`;
  }
  return `<div class="tm-prop"><label>${label}</label><input type="text" value="${esc(val)}" placeholder="${esc(options.placeholder || "")}" oninput="App.ptmSet('${k}', this.value)" /></div>`;
}

function ptmSheetIsPaytable(name) {
  return String(name || "").trim().toLowerCase().replace(/[^a-z0-9]/g, "").startsWith("paytable");
}

App.ptmRenderSheets = () => {
  const sel = document.getElementById("ptmSheet");
  if (!sel) return;
  const sheets = (App.state.scan?.excel?.sheets || []).map((s) => s.name).filter(Boolean)
    .filter(ptmSheetIsPaytable);
  // A sheet the user picked manually is sticky; otherwise prefer the first
  // paytable page (the dropdown only ever shows pages named paytable*).
  const picked = App.paytableMapper?.sheetName || "";
  let cur = !picked ? "" : (sheets.includes(picked) ? picked : "");
  if (!cur) cur = sheets[0] || "";
  sel.innerHTML = sheets.map((n) => `<option value="${esc(n)}" ${n === cur ? "selected" : ""}>${esc(n)}</option>`).join("") ||
    `<option value="">No paytable sheet scanned — scan Excel first</option>`;
  if (App.paytableMapper) App.paytableMapper.sheetName = cur;
};

App.ptmSheetChanged = () => {
  const sel = document.getElementById("ptmSheet");
  if (App.paytableMapper && sel) {
    App.paytableMapper.sheetName = sel.value;
  }
  App.ptmSheetData.selected.clear();
  App.ptmLoadSheetData();
};

App.ptmSheetData = { rows: [], selected: new Set(), filter: "" };

App.ptmLoadSheetData = async () => {
  const pm = App.paytableMapper;
  const sheet = document.getElementById("ptmSheet")?.value || (pm && pm.sheetName) || "";
  App.ptmSheetData.rows = [];
  if (sheet && App.state.config.excel_path) {
    try {
      const d = await api("/api/paytable_mapper/sheet_data", {
        method: "POST",
        timeout: 25000,
        body: { excel_path: App.state.config.excel_path, sheet_name: sheet },
      });
      if (d.ok) App.ptmSheetData.rows = d.rows || [];
    } catch (e) { /* sidebar is best-effort */ }
  }
  App.ptmRenderSheetData();
};

App.ptmRenderSheetData = () => {
  const host = document.getElementById("ptmDataList");
  if (!host) return;
  const filter = String(document.getElementById("ptmDataFilter")?.value || "").trim().toLowerCase();
  const rows = App.ptmSheetData.rows || [];
  const sel = App.ptmSheetData.selected;
  const shown = rows.filter((r) => !filter || (r.ref + " " + r.text).toLowerCase().includes(filter));
  host.innerHTML = shown.length
    ? shown.map((r) => {
        const pick = sel.has(r.ref);
        return `<div class="ptm-data-row ${pick ? "picked" : ""}" data-ref="${esc(r.ref)}" onclick="App.ptmPickSheetData('${esc(r.ref)}', event)">` +
          `<span class="ptm-data-ref">${esc(r.ref)}</span><span class="ptm-data-text">${esc(r.text)}</span></div>`;
      }).join("")
    : `<div class="ptm-data-empty">${rows.length ? "No rows match the filter." : "Load a sheet to see its data here."}</div>`;
  App.ptmSyncSheetDataFoot();
};

App.ptmSyncSheetDataFoot = () => {
  const pm = App.paytableMapper;
  const applyBtn = document.getElementById("ptmDataApply");
  const status = document.getElementById("ptmDataStatus");
  if (!applyBtn || !status) return;
  const n = App.ptmSheetData.selected.size;
  const slot = pm && pm.selected ? pm.selected : "";
  applyBtn.disabled = !n || !slot;
  applyBtn.textContent = slot ? `Apply to ${slot}${n ? ` (${n})` : ""}` : "Pick a slot first";
  status.textContent = !slot
    ? "Click a slot in the preview to select it, then pick rows."
    : (n ? `${n} row(s) picked — Apply writes them to ${slot} (multi-line).` : `Pick rows from the list, then hit Apply to ${slot}.`);
};

App.ptmMappedDataPreview = (m) => {
  if (!m || !m.text) return "";
  const line = String(m.text).split("\n").map((l) => l.trim()).find((l) => l) || "";
  const plain = line.replace(/<[^<>]+>/g, "").replace(/\s+/g, " ").trim();
  return plain.length > 48 ? plain.slice(0, 48) + "…" : plain;
};

App.ptmInitSlotBar = () => {
  const bar = document.getElementById("ptSlotBar");
  const body = document.getElementById("ptSlotBarBody");
  const handle = document.getElementById("ptSlotBarResize");
  if (!bar || !body || !handle || bar._ptBarInit) return;
  bar._ptBarInit = true;
  const clamp = (h) => Math.min(Math.max(h, 120), Math.round(window.innerHeight * 0.8));
  try {
    const saved = parseInt(localStorage.getItem("psh.ptSlotBarH") || "", 10);
    if (saved > 0) body.style.height = clamp(saved) + "px";
  } catch (e) { /* ignore */ }
  handle.addEventListener("pointerdown", (ev) => {
    ev.preventDefault();
    try { handle.setPointerCapture(ev.pointerId); } catch (e) { /* ignore */ }
    const startY = ev.clientY;
    const startH = body.getBoundingClientRect().height;
    let raf = 0;
    const move = (e) => {
      const h = clamp(startH + (startY - e.clientY));
      if (raf) cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => { body.style.height = h + "px"; });
    };
    const up = (e) => {
      if (raf) cancelAnimationFrame(raf);
      handle.removeEventListener("pointermove", move);
      handle.removeEventListener("pointerup", up);
      handle.removeEventListener("pointercancel", up);
      try { handle.releasePointerCapture(e.pointerId); } catch (err) { /* ignore */ }
      try {
        const h = clamp(body.getBoundingClientRect().height);
        body.style.height = h + "px";
        localStorage.setItem("psh.ptSlotBarH", String(h));
      } catch (err) { /* ignore */ }
      App.ptApplyPreviewZoom();
    };
    handle.addEventListener("pointermove", move);
    handle.addEventListener("pointerup", up);
    handle.addEventListener("pointercancel", up);
  });
};

App.ptmPickSheetData = (ref, ev) => {
  const host = document.getElementById("ptmDataList");
  const st = host ? host.scrollTop : 0;
  const sel = App.ptmSheetData.selected;
  if (ev && (ev.shiftKey || ev.ctrlKey || ev.metaKey)) {
    if (sel.has(ref)) sel.delete(ref); else sel.add(ref);
  } else {
    sel.clear();
    sel.add(ref);
  }
  App.ptmRenderSheetData();
  if (host) host.scrollTop = st;
};

App.ptmClearSheetData = () => {
  App.ptmSheetData.selected.clear();
  App.ptmRenderSheetData();
};

App.ptmApplySheetData = () => {
  const pm = App.paytableMapper;
  if (!pm || !pm.selected) { toast("Pick a slot first — click a slot in the preview.", "err"); return; }
  const picked = App.ptmSheetData.rows.filter((r) => App.ptmSheetData.selected.has(r.ref));
  if (!picked.length) { toast("Pick at least one row of data first.", "err"); return; }
  const source = picked.map((r) => r.ref).join(",");
  const text = picked.map((r) => r.text).join("\n");
  const name = pm.selected;
  App.ptmPushUndo();
  const existing = pm.mappings[name];
  const m = (existing && typeof existing === "object") ? { ...existing }
    : { slot: name, font_size: 30, icon_height: 48, color: "#FFFFFF", alignment: "center", vertical_align: "center", padding: [0, 0, 0, 0] };
  m.mode = "excel";
  m.source = source;
  m.text = text;
  m.source_pinned = true;  // artist's own pick: builds keep these cells, not the auto re-bind
  m.pinned_excel = App.ptmExcelKey();   // ...for this workbook only
  pm.mappings[name] = m;
  pm.userTouched = pm.userTouched || {};
  pm.userTouched[name] = true;
  App.ptmScheduleAutoSave();
  App.ptmRenderPanel();
  App.ptmRenderPreviewOverlay();
  App.ptmLiveRender();
  toast(`${name} ← ${source} (${text.split("\n").length} line(s)).`, "ok");
};

App.ptAdoptPreview = () => {
  const host = document.getElementById("ptPreviewImgHost");
  if (!host) return;
  let img = App._ptPreviewImg;
  if (!img) {
    img = App._ptPreviewImg = document.createElement("img");
    img.id = "ptPreviewImg";
    img.className = "pt-preview-img";
    img.alt = "mapped paytable preview";
  }
  if (img.parentNode !== host) {
    host.innerHTML = "";
    host.appendChild(img);
  }
  img.onload = () => App.ptApplyPreviewZoom();
  const token = App.state.paytablePreviewToken || App.paytableMapper?.previewToken || "";
  if (token) {
    const url = "/api/table_preview/" + encodeURIComponent(token);
    const cur = String(img.getAttribute("src") || "").split("?")[0];
    if (cur !== url) img.src = url;
  }
};

App.ptmSyncView = () => {
  if (App.route !== "paytable") return;
  App.ptmRenderSheets();
  const btn = document.getElementById("ptBlueprintBtn");
  if (btn) btn.classList.toggle("on", App._ptBlueprint !== false);
  const layer = document.getElementById("ptPreviewSlots");
  if (layer) layer.style.display = App._ptBlueprint === false ? "none" : "";
  App.ptAdoptPreview();
  App.ptmRenderPreviewOverlay();
  App.ptmRenderPanel();
  App.ptmLiveRender();
};

App.ptmRenderPreviewOverlay = () => {
  const layer = document.getElementById("ptPreviewSlots");
  const pm = App.paytableMapper;
  if (!layer || !pm || !pm.template) return;
  const slots = pm.template.slots || {};
  const cw = pm.template.canvas?.width || 1;
  const ch = pm.template.canvas?.height || 1;
  layer.style.aspectRatio = cw + "/" + ch;
  const mapped = pm.mappings || {};
  const missingIcons = new Set(pm.iconIssues || []);
  const overflow = new Set(pm.overflowIssues || []);
  const multi = pm.multiSelected || [];
  const masters = App.ptmMasters();
  const bandHidden = App.ptmBandHidden();
  const bandHtml = App.ptmBandHtml(cw, ch);
  const masterHtml = masters.map((m) => {
    const isSel = m.id === pm.selectedMaster;
    return `<div class="ptm-master ${isSel ? "selected" : ""}" data-master="${esc(m.id)}"
      onclick="App.ptmSelectMaster('${esc(m.id)}', event)"
      onpointerdown="App.ptmMasterPress('${esc(m.id)}', event)"
      title="${esc(m.name || m.id)} — grid ${m.cols}×${m.rows} · ${m.children.length} slots · drag to move, drag the blue corners to scale, right-click for options">
      <span class="ptm-master-label">${esc(m.name || m.id)} · ${m.cols}×${m.rows}</span>
    </div>`;
  }).join("");
  const slotHtml = Object.keys(slots).filter((name) => !bandHidden.has(name)).map((name) => {
    const b = slots[name] || {};
    const isSel = name === pm.selected;
    const noIcon = missingIcons.has(name);
    const tooBig = overflow.has(name);
    const isMulti = multi.includes(name);
    const group = App.ptmSlotGroup(name);
    const isGrouped = group.length > 1;
    const masterOf = App.ptmMasterOf(name);
    const gridLocked = !!masterOf;
    const tip = gridLocked
      ? `${name} — inside "${masterOf.name || masterOf.id}": position is grid-anchored, move/scale the master (blue box) instead, click to edit mapping`
      : isGrouped
        ? `${name} — part of a group: drag or scale it to move/transform all grouped slots together, click to edit`
        : `${name} — drag to move, click to edit`;
    return `<div class="tm-slot ptm-slot ${mapped[name] ? "mapped" : "empty"} ${isSel ? "selected" : ""} ${isMulti ? "multi" : ""} ${noIcon ? "icon-missing" : ""} ${tooBig ? "overflow" : ""} ${isGrouped ? "group-movable" : ""} ${gridLocked ? "grid-locked" : ""}" data-slot="${esc(name)}"
      onclick="App.ptmSlotClick('${esc(name)}', event)"
      onpointerdown="App.ptmSlotPress('${esc(name)}', event)"
      title="${esc(tip)}"
      style="top:${((b.y || 0) / ch) * 100}%;left:${((b.x || 0) / cw) * 100}%;width:${((b.w || 1) / cw) * 100}%;height:${((b.h || 1) / ch) * 100}%">
      <span class="tm-slot-name">${esc(name)}</span>
      ${noIcon ? `<span class="tm-slot-src no-icon">no icon found</span>` : ""}
      ${tooBig ? `<span class="tm-slot-src overflow-badge">text too big</span>` : ""}
      ${!noIcon && mapped[name] && (mapped[name].mode === "literal" || mapped[name].mode === "text" || mapped[name].mode === "excel_text") ? `<span class="tm-slot-src">text</span>`
        : !noIcon && mapped[name] && mapped[name].mode === "icon" ? `<span class="tm-slot-src">icon</span>`
        : !noIcon && mapped[name] && mapped[name].source ? `<span class="tm-slot-src">${esc(mapped[name].source)}${App.ptmMappedDataPreview(mapped[name]) ? " · " + esc(App.ptmMappedDataPreview(mapped[name])) : ""}</span>` : ""}
    </div>`;
  }).join("");
  let handles = "";
  const sel = pm.selected;
  if (!pm.selectedMaster && sel && slots[sel] && !bandHidden.has(sel)) {
    const gsel = App.ptmEffGroup(sel);
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    gsel.forEach((n) => {
      const b = slots[n];
      if (b) { x0 = Math.min(x0, b.x); y0 = Math.min(y0, b.y); x1 = Math.max(x1, b.x + b.w); y1 = Math.max(y1, b.y + b.h); }
    });
    if (x0 !== Infinity && x1 - x0 > 0 && y1 - y0 > 0) {
      const cur = { nw: "nwse-resize", n: "ns-resize", ne: "nesw-resize", e: "ew-resize", se: "nwse-resize", s: "ns-resize", sw: "nesw-resize", w: "ew-resize" };
      handles = ["nw", "n", "ne", "e", "se", "s", "sw", "w"].map((h) => {
        const hx = h.includes("e") ? x1 : h.includes("w") ? x0 : (x0 + x1) / 2;
        const hy = h.includes("s") ? y1 : h.includes("n") ? y0 : (y0 + y1) / 2;
        return `<div class="ptm-handle" data-h="${h}" style="left:${(hx / cw) * 100}%;top:${(hy / ch) * 100}%;cursor:${cur[h]}" title="Drag to scale the ${gsel.length > 1 ? "column group" : "slot"}" onpointerdown="App.ptmAnchorStart('${h}', event)"></div>`;
      }).join("");
    }
  } else if (pm.selectedMaster) {
    const m = App.ptmMaster(pm.selectedMaster);
    if (m) {
      const cur = { nw: "nwse-resize", n: "ns-resize", ne: "nesw-resize", e: "ew-resize", se: "nwse-resize", s: "ns-resize", sw: "nesw-resize", w: "ew-resize" };
      const x0 = m.x, y0 = m.y, x1 = m.x + m.w, y1 = m.y + m.h;
      handles = ["nw", "n", "ne", "e", "se", "s", "sw", "w"].map((h) => {
        const hx = h.includes("e") ? x1 : h.includes("w") ? x0 : (x0 + x1) / 2;
        const hy = h.includes("s") ? y1 : h.includes("n") ? y0 : (y0 + y1) / 2;
        return `<div class="ptm-handle" data-mh="${h}" style="left:${(hx / cw) * 100}%;top:${(hy / ch) * 100}%;cursor:${cur[h]}" title="Drag to scale the master — children follow their grid cells" onpointerdown="App.ptmMasterAnchorStart('${h}', event)"></div>`;
      }).join("");
    }
  }
  layer.innerHTML = bandHtml + masterHtml + slotHtml + (handles || App.ptmBandHandlesHtml(cw, ch));
  App.ptApplyPreviewZoom();
  App.ptmRenderSlotList();
  App.ptmSyncSheetDataFoot();
};

// User-defined groups: slots move/transform together ONLY when explicitly
// grouped (Ctrl+G), never by name/symbol heuristics. Groups live in
// pm.groups and persist through mapper_meta.groups on save.
App.ptmGroups = () => {
  const pm = App.paytableMapper;
  if (!pm) return [];
  if (!pm.groups) {
    const meta = pm.template && pm.template.mapper_meta;
    pm.groups = Array.isArray(meta && meta.groups)
      ? meta.groups.map((g) => (Array.isArray(g) ? g.slice() : [])).filter((g) => g.length)
      : [];
  }
  return pm.groups;
};

App.ptmSlotGroup = (name) => {
  const pm = App.paytableMapper;
  if (!pm || !pm.template) return [name];
  const grp = App.ptmGroups().find((g) => g.includes(name));
  return grp ? grp.slice() : [name];
};

// Effective drag/transform set: a live multi-selection (>=2 slots) wins over
// any saved group — same feel as Advanced Edit where the selection moves as
// one unit.
App.ptmEffGroup = (name) => {
  const pm = App.paytableMapper;
  const multi = (pm && pm.multiSelected) || [];
  if (multi.length >= 2 && multi.includes(name)) return multi.slice();
  return App.ptmSlotGroup(name);
};

App.ptmStampGroups = () => {
  const pm = App.paytableMapper;
  if (!pm || !pm.template) return;
  pm.template.mapper_meta = pm.template.mapper_meta || {};
  pm.template.mapper_meta.groups = App.ptmGroups().filter((g) => g.length > 1);
};

// ---- Master layouts ------------------------------------------------
// A one-level container (bounding box) holding an internal rows x cols grid.
// Child slots keep a `cell` {r, c, rs, cs} and their absolute x/y/w/h is
// DERIVED from the master's box — so moving, scaling or re-gridding the master
// automatically re-positions every child (symbol + its pay/value stay with
// their parent). Persisted via template.mapper_meta.masters; the backend still
// reads the flat child boxes because we re-lay-out children on every master
// transform.
App.ptmMasters = () => {
  const pm = App.paytableMapper;
  if (!pm) return [];
  if (!pm.masters) {
    const meta = pm.template && pm.template.mapper_meta;
    pm.masters = Array.isArray(meta && meta.masters) ? meta.masters.slice() : [];
  }
  return pm.masters;
};

App.ptmMaster = (id) => App.ptmMasters().find((m) => m.id === id) || null;

App.ptmMasterOf = (slotName) => {
  const m = App.ptmMasters().find((x) => (x.children || []).includes(slotName));
  return m || null;
};

App.ptmStampMasters = () => {
  const pm = App.paytableMapper;
  if (!pm || !pm.template) return;
  pm.template.mapper_meta = pm.template.mapper_meta || {};
  pm.template.mapper_meta.masters = App.ptmMasters();
};

App._ptmUniqueMasterId = () => {
  let n = 1;
  let id = "master." + n;
  while (App.ptmMasters().some((m) => m.id === id)) { n++; id = "master." + n; }
  return id;
};

App._ptmGridMetrics = (m) => {
  const rows = Math.max(1, Math.round(+m.rows || 1));
  const cols = Math.max(1, Math.round(+m.cols || 1));
  const pad = Math.max(0, Math.round(+m.padding || 0));
  const gapX = Math.max(0, Math.round(+m.gapX || 0));
  const gapY = Math.max(0, Math.round(+m.gapY || 0));
  const innerW = Math.max(1, (m.w || 100) - pad * 2);
  const innerH = Math.max(1, (m.h || 100) - pad * 2);
  return {
    rows, cols, pad, gapX, gapY,
    cellW: Math.max(1, (innerW - gapX * (cols - 1)) / cols),
    cellH: Math.max(1, (innerH - gapY * (rows - 1)) / rows),
  };
};

App._ptmLayoutChild = (m, name, slots) => {
  const b = slots[name];
  const cell = b && b.cell;
  if (!b || !cell) return;
  const g = App._ptmGridMetrics(m);
  const r = Math.min(Math.max(0, Math.round(cell.r || 0)), g.rows - 1);
  const c = Math.min(Math.max(0, Math.round(cell.c || 0)), g.cols - 1);
  const rs = Math.max(1, Math.round(cell.rs || 1));
  const cs = Math.max(1, Math.round(cell.cs || 1));
  const cellW = cs * g.cellW + (cs - 1) * g.gapX;
  const cellH = rs * g.cellH + (rs - 1) * g.gapY;
  b.x = Math.round(m.x + g.pad + c * (g.cellW + g.gapX) + (cellW - (b.w || cellW)) / 2);
  b.y = Math.round(m.y + g.pad + r * (g.cellH + g.gapY) + (cellH - (b.h || cellH)) / 2);
};

App._ptmLayoutMaster = (m, slots) => {
  if (!m || !slots) return;
  (m.children || []).forEach((name) => App._ptmLayoutChild(m, name, slots));
};

App.ptmLayoutMaster = (id) => {
  const pm = App.paytableMapper;
  const m = App.ptmMaster(id);
  if (!pm || !m) { toast("Master not found.", "err"); return; }
  App.ptmPushUndo();
  App._ptmLayoutMaster(m, pm.template.slots);
  App.ptmMasterCommit();
  toast(`Re-laid out "${m.name || m.id}" (${m.cols}×${m.rows}).`, "ok");
};

App._ptmDetectBands = (names, axis, dim) => {
  const pm = App.paytableMapper;
  const tol = 14;
  const bands = [];
  names.forEach((n) => {
    const b = pm.template.slots[n];
    if (!b) return;
    const start = b[axis] || 0, size = b[dim] || 0;
    const center = start + size / 2;
    let band = bands.find((x) => Math.abs(x.center - center) <= tol);
    if (!band) { band = { center, min: start, max: start + size, items: [] }; bands.push(band); }
    band.min = Math.min(band.min, start);
    band.max = Math.max(band.max, start + size);
    band.items.push(n);
  });
  return bands.sort((a, b) => a.center - b.center);
};

App.ptmWrapSelection = () => {
  const pm = App.paytableMapper;
  if (!pm || !pm.template) return;
  let names = App._ptmTransformTargets().filter((n) => pm.template.slots[n]);
  const locked = names.filter((n) => App.ptmMasterOf(n));
  if (locked.length) {
    if (locked.length === names.length) {
      toast("Those slots are already inside a master grid — select the blue master box to move/scale it instead.", "");
      return;
    }
    names = names.filter((n) => !App.ptmMasterOf(n));
    toast(`Skipped ${locked.length} already-grid-locked slot${locked.length > 1 ? "s" : ""}.`, "");
  }
  if (names.length < 2) { toast("Select at least 2 slots (shift-click or marquee) to wrap into a master.", ""); return; }
  const box = App._ptmSelectionBox(names);
  if (!box) return;
  const rows = App._ptmDetectBands(names, "y", "h");
  const cols = App._ptmDetectBands(names, "x", "w");
  const gapOf = (bands, axisAxis, axis, dim) => {
    let total = 0, n = 0;
    for (let i = 1; i < bands.length; i++) {
      const gap = bands[i].min - bands[i - 1].max;
      if (gap > 0) { total += gap; n++; }
    }
    return n ? Math.round(total / n) : 16;
  };
  const gapX = gapOf(cols), gapY = gapOf(rows);
  const id = App._ptmUniqueMasterId();
  const grid = { id, name: id, x: box.x0, y: box.y0, w: box.w, h: box.h, rows: rows.length, cols: cols.length, gapX, gapY, padding: 0, children: names.slice() };
  names.forEach((n) => {
    const b = pm.template.slots[n];
    const row = rows.reduce((best, x, i) => { const r = Math.abs(x.center - (b.y + b.h / 2)); return r < best.d ? { i, d: r } : best; }, { i: 0, d: Infinity }).i;
    const col = cols.reduce((best, x, i) => { const r = Math.abs(x.center - (b.x + b.w / 2)); return r < best.d ? { i, d: r } : best; }, { i: 0, d: Infinity }).i;
    b.cell = { r: row, c: col, rs: 1, cs: 1 };
  });
  App.ptmPushUndo();
  pm.masters = App.ptmMasters();
  pm.masters.push(grid);
  pm.selected = "";
  pm.multiSelected = [];
  pm.selectedMaster = id;
  App._ptmLayoutMaster(grid, pm.template.slots);
  App.ptmStampMasters();
  App.ptmMasterCommit();
  toast(`Wrapped ${names.length} slots into master "${id}" (${grid.cols}×${grid.rows}). Slot sizes are untouched — move the blue box to re-anchor them together.`, "ok");
};

App.ptmUnwrapMaster = (id) => {
  const pm = App.paytableMapper;
  const m = App.ptmMaster(id);
  if (!pm || !m) return;
  App.ptmPushUndo();
  const children = m.children.slice();
  const groups = App.ptmGroups().filter((g) => !g.some((n) => children.includes(n)));
  if (children.length > 1) groups.push(children);
  pm.groups = groups;
  pm.masters = App.ptmMasters().filter((x) => x.id !== id);
  children.forEach((n) => { if (pm.template.slots[n]) delete pm.template.slots[n].cell; });
  pm.selected = children[0] || "";
  pm.selectedMaster = null;
  pm.multiSelected = [];
  App.ptmStampGroups();
  App.ptmStampMasters();
  App.ptmMasterCommit();
  toast(`Unwrapped "${m.name || m.id}" — children kept their positions and were grouped together.`, "ok");
};

App.ptmSetMasterField = (id, key, v) => {
  const pm = App.paytableMapper;
  const m = App.ptmMaster(id);
  if (!pm || !m) return;
  const val = Math.max(key === "rows" || key === "cols" ? 1 : 0, Math.round(parseFloat(v) || 0));
  App.ptmPushUndo();
  m[key] = val;
  App._ptmLayoutMaster(m, pm.template.slots);
  App.ptmStampMasters();
  App.ptmMasterCommit();
  App.ptmRenderPanel();
};

/* Shared commit after any master/child geometry mutation: persist + redraw +
   live render the flat (re-laid-out) slot boxes. */
App.ptmMasterCommit = () => {
  App.ptmStampMasters();
  App.ptmScheduleAutoSave();
  App.ptmRenderPreviewOverlay();
  App.ptmRenderPanel();
  App.ptmLiveRender();
};

App.ptmMasterPropsHtml = (id) => {
  const m = App.ptmMaster(id);
  if (!m) return `<div class="tm-empty">Master not found.</div>`;
  const num = (key, label, min, max) => `<label class="form-label" style="display:flex;justify-content:space-between;align-items:center;gap:10px;padding:3px 0">${label}
    <input type="number" class="form-input" value="${esc(+m[key] || 0)}" min="${min}" max="${max}" onchange="App.ptmSetMasterField('${esc(m.id)}','${key}',this.value)"></label>`;
  return `<div class="pt-master-props">
    <div class="tm-prop-head"><span class="tm-panel-title">Master</span><span class="tm-prop-slot">${esc(m.id)}</span></div>
    <div class="tm-hint">Grid-driven box: every child keeps its own width/height — only each slot's position is anchored to its grid cell. Dragging the master re-anchors all children together, so symbols (with their pay/value) stay aligned.</div>
    <div class="pt-master-grid" style="margin-top:8px">
      ${num("rows", "Rows", 1, 12)}
      ${num("cols", "Columns", 1, 12)}
      ${num("gapX", "Gap X", 0, 200)}
      ${num("gapY", "Gap Y", 0, 200)}
      ${num("padding", "Padding", 0, 200)}
    </div>
    <div class="pt-master-actions" style="display:flex;gap:6px;margin-top:8px">
      <button class="pt-btn secondary small" onclick="App.ptmLayoutMaster('${esc(m.id)}')">Re-layout</button>
      <button class="pt-btn secondary small" onclick="App.ptmUnwrapMaster('${esc(m.id)}')">Unwrap</button>
    </div>
  </div>`;
};

/* ---- Master transform interactions (move + corner-scale) ---------- */
App.ptmSelectMaster = (id) => {
  const pm = App.paytableMapper;
  if (!pm) return;
  pm.selectedMaster = id;
  pm.selected = "";
  pm.multiSelected = [];
  App.ptmRenderPreviewOverlay();
  App.ptmRenderPanel();
};

App.ptmMasterPress = (id, ev) => {
  const pm = App.paytableMapper;
  const layer = document.getElementById("ptPreviewSlots");
  const m = App.ptmMaster(id);
  if (!pm || !layer || !m || ev.button !== 0) return;
  ev.preventDefault();
  ev.stopPropagation();
  App.ptmSelectMaster(id);
  const cw = pm.template.canvas?.width || 1, ch = pm.template.canvas?.height || 1;
  App._ptmMasterDrag = {
    id, cw, ch, scale: (layer.clientWidth || cw) / cw,
    startX: ev.clientX, startY: ev.clientY, ox: m.x, oy: m.y,
    pre: App.ptmSnap(), moved: false,
  };
  layer.classList.add("dragging");
  window.addEventListener("pointermove", App.ptmMasterDragMove);
  window.addEventListener("pointerup", App.ptmMasterDragEnd);
};

App.ptmMasterDragMove = (ev) => {
  const d = App._ptmMasterDrag;
  const pm = App.paytableMapper;
  const m = d && App.ptmMaster(d.id);
  if (!d || !pm || !m) return;
  if (!d.moved && Math.abs(ev.clientX - d.startX) + Math.abs(ev.clientY - d.startY) < 5) return;
  d.moved = true;
  m.x = Math.round(Math.min(Math.max(0, d.ox + (ev.clientX - d.startX) / d.scale), Math.max(0, d.cw - m.w)));
  m.y = Math.round(Math.min(Math.max(0, d.oy + (ev.clientY - d.startY) / d.scale), Math.max(0, d.ch - m.h)));
  App._ptmLayoutMaster(m, pm.template.slots);
  App.ptmMasterSyncDom(d.id);
  ev.preventDefault();
};

App.ptmMasterDragEnd = () => {
  const d = App._ptmMasterDrag;
  App._ptmMasterDrag = null;
  if (!d) return;
  window.removeEventListener("pointermove", App.ptmMasterDragMove);
  window.removeEventListener("pointerup", App.ptmMasterDragEnd);
  const layer = document.getElementById("ptPreviewSlots");
  if (layer) layer.classList.remove("dragging");
  if (d.moved) {
    if (d.pre) App.ptmPushUndoState(d.pre);
    App.ptmMasterCommit();
  }
};

App.ptmMasterAnchorStart = (h, ev) => {
  const pm = App.paytableMapper;
  const layer = document.getElementById("ptPreviewSlots");
  const m = App.ptmMaster(pm.selectedMaster);
  if (!pm || !layer || !m || ev.button !== 0) return;
  const cw = pm.template.canvas?.width || 1, ch = pm.template.canvas?.height || 1;
  App._ptmMasterAnchor = {
    h, id: m.id, x0: m.x, y0: m.y, x1: m.x + m.w, y1: m.y + m.h, cw, ch,
    scale: (layer.clientWidth || cw) / cw,
    startX: ev.clientX, startY: ev.clientY,
    pre: App.ptmSnap(), moved: false,
  };
  window.addEventListener("pointermove", App.ptmMasterAnchorMove);
  window.addEventListener("pointerup", App.ptmMasterAnchorEnd);
  ev.preventDefault();
  ev.stopPropagation();
};

App.ptmMasterAnchorMove = (ev) => {
  const a = App._ptmMasterAnchor;
  const pm = App.paytableMapper;
  const m = a && App.ptmMaster(a.id);
  if (!a || !pm || !m) return;
  const MIN = 40;
  const dx = (ev.clientX - a.startX) / a.scale;
  const dy = (ev.clientY - a.startY) / a.scale;
  if (Math.abs(dx) > 1 || Math.abs(dy) > 1) a.moved = true;
  const hasW = a.h.includes("w"), hasE = a.h.includes("e");
  const hasN = a.h.includes("n"), hasS = a.h.includes("s");
  let nx0 = a.x0, nx1 = a.x1, ny0 = a.y0, ny1 = a.y1;
  if (hasW) nx0 = Math.min(Math.max(0, a.x0 + dx), a.x1 - MIN);
  if (hasE) nx1 = Math.max(a.x0 + MIN, Math.min(a.cw, a.x1 + dx));
  if (hasN) ny0 = Math.min(Math.max(0, a.y0 + dy), a.y1 - MIN);
  if (hasS) ny1 = Math.max(a.y0 + MIN, Math.min(a.ch, a.y1 + dy));
  m.x = Math.round(nx0); m.y = Math.round(ny0);
  m.w = Math.round(nx1 - nx0); m.h = Math.round(ny1 - ny0);
  App._ptmLayoutMaster(m, pm.template.slots);
  App.ptmMasterSyncDom(a.id);
  ev.preventDefault();
};

App.ptmMasterAnchorEnd = () => {
  const a = App._ptmMasterAnchor;
  App._ptmMasterAnchor = null;
  if (!a) return;
  window.removeEventListener("pointermove", App.ptmMasterAnchorMove);
  window.removeEventListener("pointerup", App.ptmMasterAnchorEnd);
  if (a.moved) {
    if (a.pre) App.ptmPushUndoState(a.pre);
    App.ptmMasterCommit();
  }
};

/* Live-update the master box + all child slot DOM elements during a drag,
   without a full re-render. */
App.ptmMasterSyncDom = (id) => {
  const pm = App.paytableMapper;
  const m = App.ptmMaster(id);
  const layer = document.getElementById("ptPreviewSlots");
  if (!pm || !m || !layer) return;
  const cw = pm.template.canvas?.width || 1, ch = pm.template.canvas?.height || 1;
  const children = layer.children;
  for (let i = 0; i < children.length; i++) {
    const el = children[i];
    if (el.dataset.master === id) {
      el.style.left = ((m.x / cw) * 100) + "%";
      el.style.top = ((m.y / ch) * 100) + "%";
      el.style.width = ((m.w / cw) * 100) + "%";
      el.style.height = ((m.h / ch) * 100) + "%";
    } else if (el.dataset.slot && m.children.includes(el.dataset.slot)) {
      const b = pm.template.slots[el.dataset.slot];
      if (b) {
        el.style.left = ((b.x / cw) * 100) + "%";
        el.style.top = ((b.y / ch) * 100) + "%";
        el.style.width = ((b.w / cw) * 100) + "%";
        el.style.height = ((b.h / ch) * 100) + "%";
      }
    }
  }
};

// Undo / redo for the paytable mapper: JSON snapshots of template + mappings
// + groups taken BEFORE a mutation; Ctrl+Z / Ctrl+Shift+Z(+Ctrl+Y) restore.
App._ptmUndoStack = [];
App._ptmRedoStack = [];

App.ptmSnap = () => {
  const pm = App.paytableMapper;
  if (!pm || !pm.template) return null;
  App.ptmStampGroups();
  App.ptmStampMasters();
  return JSON.stringify({
    template: pm.template,
    mappings: pm.mappings || {},
    groups: pm.groups || [],
    masters: pm.masters || [],
    selected: pm.selected || "",
    selectedMaster: pm.selectedMaster || "",
    multiSelected: pm.multiSelected || [],
  });
};

App.ptmPushUndoState = (s) => {
  if (!s) return;
  App._ptmUndoStack.push(s);
  if (App._ptmUndoStack.length > 60) App._ptmUndoStack.shift();
  App._ptmRedoStack = [];
};

App.ptmPushUndo = () => App.ptmPushUndoState(App.ptmSnap());

App.ptmRestore = (s) => {
  const pm = App.paytableMapper;
  if (!s || !pm) return;
  const d = JSON.parse(s);
  pm.template = d.template;
  pm.mappings = d.mappings || {};
  pm.groups = d.groups || [];
  pm.masters = d.masters || [];
  pm.selected = d.selected || "";
  pm.selectedMaster = d.selectedMaster || "";
  pm.multiSelected = d.multiSelected || [];
  if (!pm.template.mapper_meta) pm.template.mapper_meta = {};
  App.ptmRenderPreviewOverlay();
  App.ptmRenderPanel();
  App.ptmScheduleAutoSave();
  App.ptmLiveRender();
};

App.ptmUndo = () => {
  const s = App._ptmUndoStack.pop();
  if (!s) { toast("Nothing to undo.", ""); return; }
  const cur = App.ptmSnap();
  if (cur) { App._ptmRedoStack.push(cur); if (App._ptmRedoStack.length > 60) App._ptmRedoStack.shift(); }
  App.ptmRestore(s);
};

App.ptmRedo = () => {
  const s = App._ptmRedoStack.pop();
  if (!s) { toast("Nothing to redo.", ""); return; }
  const cur = App.ptmSnap();
  if (cur) { App._ptmUndoStack.push(cur); if (App._ptmUndoStack.length > 60) App._ptmUndoStack.shift(); }
  App.ptmRestore(s);
};

App.ptmGroupSelection = () => {
  const pm = App.paytableMapper;
  if (!pm || !pm.template) return;
  const names = (pm.multiSelected && pm.multiSelected.length >= 2)
    ? pm.multiSelected.slice()
    : (pm.selected ? [pm.selected] : []);
  const valid = names.filter((n) => pm.template.slots[n] && !(tmIsBoundsSlot(n) && !ptmIsCardBackSlot(n)));
  if (valid.length < 2) { toast("Select at least two slots (drag a marquee or shift-click) then press Ctrl+G.", ""); return; }
  App.ptmPushUndo();
  const groups = App.ptmGroups().filter((g) => !g.some((n) => valid.includes(n)));
  groups.push(valid.slice());
  pm.groups = groups;
  pm.selected = valid[0];
  App.ptmStampGroups();
  App.ptmRenderPreviewOverlay();
  App.ptmRenderPanel();
  App.ptmScheduleAutoSave();
  toast(`Grouped ${valid.length} slots — drag or transform them together.`, "ok");
};

App.ptmUngroupSelection = (targets) => {
  const pm = App.paytableMapper;
  if (!pm) return;
  const names = (targets && targets.length) ? targets.slice()
    : (pm.multiSelected && pm.multiSelected.length) ? pm.multiSelected.slice()
    : (pm.selected ? [pm.selected] : []);
  const groups = App.ptmGroups();
  const kept = groups.filter((g) => !g.some((n) => names.includes(n)));
  if (kept.length === groups.length) { toast("Nothing grouped to ungroup.", ""); return; }
  App.ptmPushUndo();
  pm.groups = kept;
  App.ptmStampGroups();
  App.ptmRenderPreviewOverlay();
  App.ptmRenderPanel();
  App.ptmScheduleAutoSave();
  toast("Ungrouped.", "ok");
};

// Add / rename / delete slots on the main screen, mirroring Advanced Edit.
App.ptmAddSlot = () => {
  const pm = App.paytableMapper;
  if (!pm || !pm.template) return;
  const cw = pm.template.canvas?.width || 1920;
  const ch = pm.template.canvas?.height || 1080;
  let n = 1;
  let name = "@slot.slot." + n;
  while (pm.template.slots[name]) { n++; name = "@slot.slot." + n; }
  const w = Math.max(40, Math.round(cw * 0.05));
  const h = Math.max(40, Math.round(ch * 0.06));
  const x = Math.round((cw - w) / 2);
  const y = Math.round((ch - h) / 2);
  App.ptmPushUndo();
  pm.template.slots[name] = { x, y, w, h };
  pm.mappings = pm.mappings || {};
  pm.mappings[name] = App.ptmDefaultMapping(name);
  pm.multiSelected = [];
  pm.selected = name;
  App.ptmStampGroups();
  App.ptmRenderPreviewOverlay();
  App.ptmRenderPanel();
  App.ptmScheduleAutoSave();
  App.ptmLiveRender();
  toast(`Added slot "${name}" — drag it into place, scale it with the yellow anchors.`, "ok");
};

App.ptmRenameSlot = (oldName) => {
  const pm = App.paytableMapper;
  if (!pm || !pm.template || !pm.template.slots[oldName]) return;
  const raw = prompt("Rename slot:", oldName);
  if (raw == null) return;
  const newName = raw.trim();
  if (!newName || newName === oldName) return;
  if (pm.template.slots[newName]) { toast(`"${newName}" already exists — rename cancelled.`, "err"); return; }
  App.ptmPushUndo();
  pm.template.slots[newName] = pm.template.slots[oldName];
  delete pm.template.slots[oldName];
  const maps = pm.mappings || {};
  if (maps[oldName]) { maps[newName] = maps[oldName]; delete maps[oldName]; }
  pm.groups = App.ptmGroups().map((g) => g.map((nm) => (nm === oldName ? newName : nm)));
  pm.masters = App.ptmMasters().map((m) => {
    if (!(m.children || []).includes(oldName)) return m;
    m.children = m.children.map((nm) => (nm === oldName ? newName : nm));
    return m;
  });
  pm.multiSelected = (pm.multiSelected || []).map((nm) => (nm === oldName ? newName : nm));
  if (pm.selected === oldName) pm.selected = newName;
  App.ptmStampGroups();
  App.ptmStampMasters();
  App.ptmRenderPreviewOverlay();
  App.ptmRenderPanel();
  App.ptmScheduleAutoSave();
  App.ptmLiveRender();
  toast(`Renamed ${oldName} → ${newName}.`, "ok");
};

App.ptmDeleteSlots = (names, skipConfirm) => {
  const pm = App.paytableMapper;
  if (!pm || !pm.template) return;
  const list = (names || []).filter((n) => pm.template.slots[n]);
  if (!list.length) return;
  if (!skipConfirm && !confirm(`Delete ${list.length} slot(s)?`)) return;
  App.ptmPushUndo();
  list.forEach((n) => {
    delete pm.template.slots[n];
    delete (pm.mappings || {})[n];
  });
  pm.groups = App.ptmGroups().map((g) => g.filter((nm) => !list.includes(nm))).filter((g) => g.length > 1);
  pm.masters = App.ptmMasters()
    .map((m) => {
      m.children = (m.children || []).filter((nm) => !list.includes(nm));
      return m;
    })
    .filter((m) => m.children.length > 1);
  pm.multiSelected = (pm.multiSelected || []).filter((nm) => !list.includes(nm));
  if (list.includes(pm.selected)) pm.selected = pm.multiSelected.length ? pm.multiSelected[0] : "";
  App.ptmStampGroups();
  App.ptmStampMasters();
  App.ptmRenderPreviewOverlay();
  App.ptmRenderPanel();
  App.ptmScheduleAutoSave();
  App.ptmLiveRender();
};

App.ptmMarqueeNames = (rect, slots) => {
  const r0 = Math.min(rect.x0, rect.x1), r1 = Math.max(rect.x0, rect.x1);
  const t0 = Math.min(rect.y0, rect.y1), t1 = Math.max(rect.y0, rect.y1);
  return Object.keys(slots).filter((n) => {
    const b = slots[n];
    if (!b || (tmIsBoundsSlot(n) && !ptmIsCardBackSlot(n))) return false;
    return b.x < r1 && b.x + b.w > r0 && b.y < t1 && b.y + b.h > t0;
  });
};

// Marquee: press on empty preview space and drag — selects every slot the
// rectangle touches (shift keeps the current multi-selection). Same pointer
// flow as Advanced Edit: the canvas takes pointer capture so the drag keeps
// tracking even outside the preview, and the box element is recreated if the
// overlay re-render detached it.
App.ptmMarqueeStart = (ev) => {
  const pm = App.paytableMapper;
  const layer = document.getElementById("ptPreviewSlots");
  if (!pm || !layer) return;
  if (ev.button !== 0) return;
  if (ev.target && ev.target.closest && ev.target.closest(".tm-slot, .ptm-handle")) return;
  const cw = pm.template.canvas?.width || 1;
  const ch = pm.template.canvas?.height || 1;
  if (layer.clientWidth <= 0) return;
  const rect = layer.getBoundingClientRect();
  const scale = layer.clientWidth / cw;
  const sx = (ev.clientX - rect.left) / scale;
  const sy = (ev.clientY - rect.top) / scale;
  let el = layer._ptmMarqueeEl;
  if (!el || !el.isConnected) {
    el = layer._ptmMarqueeEl = document.createElement("div");
    el.className = "ptm-marquee";
    layer.appendChild(el);
  }
  const host = ev.currentTarget || layer.parentNode;
  App._ptmMarquee = { x0: sx, y0: sy, x1: sx, y1: sy, cw, ch, shift: !!ev.shiftKey };
  App._ptmMarqueeHost = host;
  el.style.left = "0%";
  el.style.top = "0%";
  el.style.width = "0%";
  el.style.height = "0%";
  el.style.display = "block";
  if (host && typeof host.setPointerCapture === "function") {
    try { host.setPointerCapture(ev.pointerId); } catch (e) { App._ptmMarqueeHost = null; }
    if (!host._ptmMarqueeBound) {
      host._ptmMarqueeBound = true;
      host.addEventListener("pointermove", (e) => { if (App._ptmMarquee) App.ptmMarqueeMove(e); });
      host.addEventListener("pointerup", App.ptmMarqueeEnd);
      host.addEventListener("pointercancel", App.ptmMarqueeEnd);
    }
    if (App._ptmMarqueeHost) {
      window.removeEventListener("pointermove", App.ptmMarqueeMove);
      window.removeEventListener("pointerup", App.ptmMarqueeEnd);
      ev.preventDefault();
      return;
    }
  }
  window.addEventListener("pointermove", App.ptmMarqueeMove);
  window.addEventListener("pointerup", App.ptmMarqueeEnd);
  ev.preventDefault();
};

App.ptmMarqueeMove = (ev) => {
  const m = App._ptmMarquee;
  const layer = document.getElementById("ptPreviewSlots");
  if (!m || !layer || layer.clientWidth <= 0) return;
  const rect = layer.getBoundingClientRect();
  const scale = layer.clientWidth / m.cw;
  m.x1 = Math.min(Math.max(0, (ev.clientX - rect.left) / scale), m.cw);
  m.y1 = Math.min(Math.max(0, (ev.clientY - rect.top) / scale), m.ch);
  let el = layer._ptmMarqueeEl;
  if (!el || !el.isConnected) {
    el = layer._ptmMarqueeEl = document.createElement("div");
    el.className = "ptm-marquee";
    layer.appendChild(el);
    el.style.display = "block";
  }
  el.style.left = ((Math.min(m.x0, m.x1) / m.cw) * 100) + "%";
  el.style.top = ((Math.min(m.y0, m.y1) / m.ch) * 100) + "%";
  el.style.width = ((Math.abs(m.x1 - m.x0) / m.cw) * 100) + "%";
  el.style.height = ((Math.abs(m.y1 - m.y0) / m.ch) * 100) + "%";
  ev.preventDefault();
};

App.ptmMarqueeEnd = () => {
  const m = App._ptmMarquee;
  App._ptmMarquee = null;
  App._ptmMarqueeHost = null;
  if (!m) return;
  window.removeEventListener("pointermove", App.ptmMarqueeMove);
  window.removeEventListener("pointerup", App.ptmMarqueeEnd);
  const layer = document.getElementById("ptPreviewSlots");
  if (layer && layer._ptmMarqueeEl && layer._ptmMarqueeEl.isConnected) layer._ptmMarqueeEl.style.display = "none";
  const pm = App.paytableMapper;
  if (!pm || !pm.template) return;
  const moved = Math.abs(m.x1 - m.x0) > 3 || Math.abs(m.y1 - m.y0) > 3;
  if (!moved) {
    if (!m.shift) { pm.selected = ""; pm.multiSelected = []; pm.selectedMaster = null; }
    App.ptmRenderPreviewOverlay();
    App.ptmRenderPanel();
    return;
  }
  const names = App.ptmMarqueeNames({ x0: m.x0, y0: m.y0, x1: m.x1, y1: m.y1 }, pm.template.slots);
  pm.selectedMaster = null;
  if (m.shift) {
    const cur = pm.multiSelected || (pm.multiSelected = []);
    names.forEach((n) => { if (!cur.includes(n)) cur.push(n); });
    if (names.length && !pm.selected) pm.selected = names[0];
  } else {
    pm.multiSelected = names.slice();
    pm.selected = names.length ? names[0] : "";
  }
  App._ptmDragMoved = true;
  setTimeout(() => { App._ptmDragMoved = false; }, 120);
  App.ptmRenderPreviewOverlay();
  App.ptmRenderPanel();
};

// Drag-to-move on the main preview: pressing a card column slot moves the
// whole column (icon + pay + value together), but click (no move) still
// selects only the pressed slot for editing.
App.ptmApplySelection = (name, multi) => {
  const pm = App.paytableMapper;
  if (!pm) return;
  pm.selectedMaster = null;
  if (multi) {
    const sel = pm.multiSelected || (pm.multiSelected = []);
    if (!sel.length && pm.selected && pm.selected !== name) sel.push(pm.selected);
    const i = sel.indexOf(name);
    if (i >= 0) sel.splice(i, 1);
    else sel.push(name);
  } else {
    pm.multiSelected = [];
  }
  pm.selected = name;
};

// Slot selection + drag start, handled on pointerdown like Advanced Edit —
// this never depends on the browser delivering the follow-up click event.
App.ptmSlotPress = (name, ev) => {
  const pm = App.paytableMapper;
  const layer = document.getElementById("ptPreviewSlots");
  if (!pm || !layer) return;
  if (ev.button !== 0) return;
  const box = pm.template.slots[name];
  if (!box || (tmIsBoundsSlot(name) && !ptmIsCardBackSlot(name))) return;
  if (ev.shiftKey || ev.ctrlKey) {
    App.ptmApplySelection(name, true);
    App.ptmRenderPreviewOverlay();
    App.ptmRenderPanel();
    ev.preventDefault();
    return;
  }
  App.ptmApplySelection(name, false);
  if (App.ptmMasterOf(name)) {
    ev.preventDefault();
    return;
  }
  const cw = pm.template.canvas?.width || 1;
  const ch = pm.template.canvas?.height || 1;
  const scale = (layer.clientWidth || cw) / cw;
  const names = App.ptmEffGroup(name);
  const orig = {};
  names.forEach((n) => {
    const b = pm.template.slots[n];
    if (b) orig[n] = { x: b.x || 0, y: b.y || 0 };
  });
  App._ptmDrag = { name, names, orig, cw, ch, scale, startX: ev.clientX, startY: ev.clientY, moved: false, pre: App.ptmSnap() };
  layer.classList.add("dragging");
  window.addEventListener("pointermove", App.ptmDragMove);
  window.addEventListener("pointerup", App.ptmDragEnd);
  ev.preventDefault();
};

// Follow-up click housekeeping: mapping defaults, pay/value fill. Selection
// state was already set by ptmSlotPress on pointerdown.
App.ptmSlotClick = (name, ev) => {
  const pm = App.paytableMapper;
  if (!pm) return;
  if (App._ptmDragMoved) { App._ptmDragMoved = false; return; }
  const existing = pm.mappings[name];
  if (!existing && !(tmIsBoundsSlot(name) && !ptmIsCardBackSlot(name))) {
    pm.mappings[name] = App.ptmDefaultMapping(name);
  } else if (existing && existing.mode === "excel" && existing.source) {
    const dims = tmActiveSheetDims();
    const ref = String(existing.source).trim().match(/^([A-Za-z]{1,3})(\d+)$/);
    const invalid = ref && dims && (tmColIndex(ref[1]) > (dims.cols || 0) || parseInt(ref[2], 10) > (dims.rows || 0));
    if (invalid) {
      pm.mappings[name] = App.ptmDefaultMapping(name);
      toast(`Fixed ${name}: "${existing.source}" is not a valid cell in this sheet.`, "");
    }
  }
  if (App.ptmIsSymbolSlot(name)) App.ptmScheduleFillPayValues();
  App.ptmScheduleAutoSave();
  App.ptmRenderPanel();
  App.ptmRenderPreviewOverlay();
};

App.ptmDragMove = (ev) => {
  const d = App._ptmDrag;
  const pm = App.paytableMapper;
  if (!d || !pm) return;
  const dxPx = ev.clientX - d.startX;
  const dyPx = ev.clientY - d.startY;
  if (!d.moved && Math.abs(dxPx) + Math.abs(dyPx) < 5) return;
  d.moved = true;
  const dx = dxPx / d.scale;
  const dy = dyPx / d.scale;
  const layer = document.getElementById("ptPreviewSlots");
  const slots = pm.template.slots;
  const children = layer ? layer.children : [];
  d.names.forEach((n) => {
    const b = slots[n];
    if (!b) return;
    const o = d.orig[n] || { x: b.x || 0, y: b.y || 0 };
    b.x = Math.round(Math.min(Math.max(0, o.x + dx), Math.max(0, d.cw - (b.w || 0))));
    b.y = Math.round(Math.min(Math.max(0, o.y + dy), Math.max(0, d.ch - (b.h || 0))));
    for (let i = 0; i < children.length; i++) {
      const el = children[i];
      if (el.dataset.slot === n) {
        el.style.left = ((b.x / d.cw) * 100) + "%";
        el.style.top = ((b.y / d.ch) * 100) + "%";
        el.classList.add("group-drag");
        break;
      }
    }
  });
  ev.preventDefault();
};

App.ptmDragEnd = () => {
  const d = App._ptmDrag;
  App._ptmDrag = null;
  if (!d) return;
  window.removeEventListener("pointermove", App.ptmDragMove);
  window.removeEventListener("pointerup", App.ptmDragEnd);
  const layer = document.getElementById("ptPreviewSlots");
  if (layer) {
    layer.classList.remove("dragging");
    Array.prototype.forEach.call(layer.children, (el) => el.classList.remove("group-drag"));
  }
  if (d.moved) {
    if (d.pre) App.ptmPushUndoState(d.pre);
    App._ptmDragMoved = true;
    setTimeout(() => { App._ptmDragMoved = false; }, 120);
    const pm = App.paytableMapper;
    if (pm) pm.selected = d.name;
    App.ptmRenderPreviewOverlay();
    App.ptmRenderPanel();
    App.ptmScheduleAutoSave();
    App.ptmLiveRender();
  }
};

App.ptmCancelMarquee = () => {
  window.removeEventListener("pointermove", App.ptmMarqueeMove);
  window.removeEventListener("pointerup", App.ptmMarqueeEnd);
  App._ptmMarquee = null;
  App._ptmMarqueeHost = null;
  const layer = document.getElementById("ptPreviewSlots");
  if (layer && layer._ptmMarqueeEl && layer._ptmMarqueeEl.isConnected) layer._ptmMarqueeEl.style.display = "none";
};

// Anchor-point transform on the main preview: the selected slot's column
// group shows 8 resize handles (drawn by ptmRenderPreviewOverlay); dragging
// a corner scales both axes around the opposite corner, an edge handle
// stretches one axis. Mapped font/icon sizes scale with the boxes.
App.ptmAnchorStart = (h, ev) => {
  const pm = App.paytableMapper;
  const layer = document.getElementById("ptPreviewSlots");
  if (!pm || !layer || !pm.selected) return;
  if (ev.button !== 0) return;
  const slots = pm.template.slots;
  const names = App.ptmEffGroup(pm.selected).filter((n) => slots[n] && slots[n].w && slots[n].h);
  if (!names.length) return;
  let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
  const orig = {};
  names.forEach((n) => {
    const b = slots[n];
    orig[n] = { x: b.x, y: b.y, w: b.w, h: b.h };
    x0 = Math.min(x0, b.x); y0 = Math.min(y0, b.y);
    x1 = Math.max(x1, b.x + b.w); y1 = Math.max(y1, b.y + b.h);
  });
  const cw = pm.template.canvas?.width || 1, ch = pm.template.canvas?.height || 1;
  App._ptmAnchor = {
    h, names, orig, x0, y0, x1, y1, cw, ch,
    scale: (layer.clientWidth || cw) / cw,
    startX: ev.clientX, startY: ev.clientY,
    pre: App.ptmSnap(),
    moved: false,
  };
  window.addEventListener("pointermove", App.ptmAnchorMove);
  window.addEventListener("pointerup", App.ptmAnchorEnd);
  ev.preventDefault();
  ev.stopPropagation();
};

App.ptmAnchorMove = (ev) => {
  const a = App._ptmAnchor;
  const pm = App.paytableMapper;
  if (!a || !pm) return;
  const MIN = 8;
  const dx = (ev.clientX - a.startX) / a.scale;
  const dy = (ev.clientY - a.startY) / a.scale;
  if (Math.abs(dx) > 1 || Math.abs(dy) > 1) a.moved = true;
  const hasW = a.h.includes("w"), hasE = a.h.includes("e");
  const hasN = a.h.includes("n"), hasS = a.h.includes("s");
  let nx0 = a.x0, nx1 = a.x1, ny0 = a.y0, ny1 = a.y1;
  if (hasW) nx0 = Math.min(Math.max(0, a.x0 + dx), a.x1 - MIN);
  if (hasE) nx1 = Math.max(a.x0 + MIN, Math.min(a.cw, a.x1 + dx));
  if (hasN) ny0 = Math.min(Math.max(0, a.y0 + dy), a.y1 - MIN);
  if (hasS) ny1 = Math.max(a.y0 + MIN, Math.min(a.ch, a.y1 + dy));
  const ax = hasW || hasE, ay = hasN || hasS;
  const sx = ax ? (nx1 - nx0) / (a.x1 - a.x0) : 1;
  const sy = ay ? (ny1 - ny0) / (a.y1 - a.y0) : 1;
  const fx = hasW ? a.x1 : a.x0;
  const fy = hasN ? a.y1 : a.y0;
  const slots = pm.template.slots;
  const layer = document.getElementById("ptPreviewSlots");
  const children = layer ? layer.children : [];
  a.names.forEach((n) => {
    const b = slots[n];
    const o = a.orig[n];
    if (!b || !o) return;
    b.x = Math.round(fx + (o.x - fx) * sx);
    b.y = Math.round(fy + (o.y - fy) * sy);
    b.w = Math.max(2, Math.round(o.w * sx));
    b.h = Math.max(2, Math.round(o.h * sy));
    for (let i = 0; i < children.length; i++) {
      const el = children[i];
      if (el.dataset.slot === n) {
        el.style.left = ((b.x / a.cw) * 100) + "%";
        el.style.top = ((b.y / a.ch) * 100) + "%";
        el.style.width = ((b.w / a.cw) * 100) + "%";
        el.style.height = ((b.h / a.ch) * 100) + "%";
        el.classList.add("group-drag");
        break;
      }
    }
  });
  ev.preventDefault();
};

App.ptmAnchorEnd = () => {
  const a = App._ptmAnchor;
  App._ptmAnchor = null;
  if (!a) return;
  window.removeEventListener("pointermove", App.ptmAnchorMove);
  window.removeEventListener("pointerup", App.ptmAnchorEnd);
  const layer = document.getElementById("ptPreviewSlots");
  if (layer) Array.prototype.forEach.call(layer.children, (el) => el.classList.remove("group-drag"));
  if (a.pre && a.moved) App.ptmPushUndoState(a.pre);
  App.ptmRenderPreviewOverlay();
  App.ptmRenderPanel();
  App.ptmScheduleAutoSave();
  App.ptmLiveRender();
};

App.ptmToggleBlueprint = () => {
  App._ptBlueprint = App._ptBlueprint === undefined ? false : !App._ptBlueprint;
  const btn = document.getElementById("ptBlueprintBtn");
  if (btn) btn.classList.toggle("on", !!App._ptBlueprint);
  const layer = document.getElementById("ptPreviewSlots");
  if (layer) layer.style.display = App._ptBlueprint ? "" : "none";
  App.ptmLiveRender();
};

// Fit scales the whole doc to the window width, so the layout always shows
// its true size relative to the doc: the same 100px icon fills the window's
// share that it fills of the doc, i.e. 2x smaller in a 4K doc than in a 1080p
// doc. Small docs are never upscaled beyond 100%.
App.ptFitZoom = (hostW, nw) => Math.min(1, (hostW || 600) / Math.max(1, nw || 1));

App.ptPreviewZoom = (op) => {
  const wrap = document.getElementById("ptPreviewWrap");
  const img = App._ptPreviewImg;
  const nw = img && img.naturalWidth > 0 ? img.naturalWidth : (App.paytableMapper?.template?.canvas?.width || 1);
  const hostW = wrap?.clientWidth || 600;
  if (op === "reset") { App._ptPreviewZoom = null; App.ptApplyPreviewZoom(); return; }
  let z = App._ptPreviewZoom;
  if (z == null) z = App.ptFitZoom(hostW, nw);
  z = op === "in" ? Math.min(4, +(z + 0.25).toFixed(2)) : Math.max(0.25, +(z - 0.25).toFixed(2));
  App._ptPreviewZoom = z;
  App.ptApplyPreviewZoom();
};

App.ptApplyPreviewZoom = () => {
  const wrap = document.getElementById("ptPreviewWrap");
  const canvas = document.getElementById("ptPreviewCanvas");
  const pm = App.paytableMapper;
  if (!wrap || !canvas || !pm || !pm.template) return;
  const img = App._ptPreviewImg;
  const nw = img && img.naturalWidth > 0 ? img.naturalWidth : (pm.template.canvas?.width || 1);
  const nh = img && img.naturalHeight > 0 ? img.naturalHeight : (pm.template.canvas?.height || 1);
  const hostW = wrap.clientWidth || 600;
  const isFit = App._ptPreviewZoom == null;
  const z = isFit ? App.ptFitZoom(hostW, nw) : App._ptPreviewZoom;
  const cw = Math.max(1, Math.round(nw * z));
  const ch = Math.max(1, Math.round(nh * z));
  const overflowX = cw > hostW ? "auto" : "hidden";
  if (canvas.style.width === cw + "px" && canvas.style.height === ch + "px" && wrap.style.overflowX === overflowX) return;
  canvas.style.width = cw + "px";
  canvas.style.height = ch + "px";
  canvas.style.transform = "none";
  wrap.style.overflowX = overflowX;
  const lbl = document.getElementById("ptZoomLabel");
  if (lbl) lbl.textContent = isFit ? "Fit" : Math.round(z * 100) + "%";
};

App.ptPreviewInitTooltip = () => {
  const canvas = document.getElementById("ptPreviewCanvas");
  if (!canvas || canvas._ptTooltipBound) return;
  canvas._ptTooltipBound = true;
  const wrap = document.getElementById("ptPreviewWrap");
  if (wrap && !wrap._ptResizeObserved) {
    wrap._ptResizeObserved = true;
    try {
      if (typeof ResizeObserver === "function") {
        const ro = new ResizeObserver(() => {
          if (wrap._ptResizeRaf) cancelAnimationFrame(wrap._ptResizeRaf);
          wrap._ptResizeRaf = requestAnimationFrame(App.ptApplyPreviewZoom);
        });
        ro.observe(wrap);
      }
    } catch (e) { /* ignore */ }
  }
  let tip = document.getElementById("ptPreviewTooltip");
  if (!tip) {
    tip = document.createElement("div");
    tip.id = "ptPreviewTooltip";
    document.body.appendChild(tip);
  }
  let timer = null;
  let curSlot = "";
  let lastX = 0;
  let lastY = 0;
  const hide = () => {
    if (timer) { clearTimeout(timer); timer = null; }
    tip.style.display = "none";
  };
  const showNow = () => {
    const pm = App.paytableMapper;
    const b = (pm?.template?.slots || {})[curSlot] || {};
    const m = (pm?.mappings || {})[curSlot];
    const src = m ? (m.source || m.token || (m.mode === "icon" ? "icon" : "") || "text") : "unmapped";
    tip.innerHTML = `<b>${esc(curSlot)}</b> &nbsp;${Math.round(b.w || 0)} × ${Math.round(b.h || 0)} px<br><span>${esc(src)}</span>`;
    tip.style.display = "block";
    let tx = lastX + 14;
    let ty = lastY + 14;
    if (tx + 240 > window.innerWidth) tx = lastX - 250;
    if (ty + 60 > window.innerHeight) ty = lastY - 60;
    tip.style.left = tx + "px";
    tip.style.top = ty + "px";
  };
  canvas.addEventListener("mouseover", (e) => {
    const el = e.target && e.target.closest ? e.target.closest(".tm-slot") : null;
    const name = el ? el.getAttribute("data-slot") || "" : "";
    if (name !== curSlot) {
      if (timer) { clearTimeout(timer); timer = null; }
      if (!name) { hide(); curSlot = ""; return; }
      curSlot = name;
      lastX = e.clientX;
      lastY = e.clientY;
      timer = setTimeout(showNow, 1000);
    } else if (tip.style.display === "block") {
      lastX = e.clientX;
      lastY = e.clientY;
      showNow();
    } else {
      lastX = e.clientX;
      lastY = e.clientY;
    }
  });
  canvas.addEventListener("mouseleave", () => { hide(); curSlot = ""; });
};

App.ptmCopyStyle = (name) => {
  const pm = App.paytableMapper;
  const m = (pm?.mappings || {})[name];
  if (!m) { toast("Nothing to copy — slot has no mapping yet.", "err"); return; }
  const keys = ["font_size", "font_name", "font_family", "font_override", "color", "alignment", "vertical_align", "padding", "line_height", "icon_height", "background_color", "fill_color", "fill_enabled", "opacity", "stroke_color", "stroke_width", "stroke_enabled", "stroke_opacity"];
  const style = {};
  keys.forEach((k) => { if (m[k] !== undefined) style[k] = m[k]; });
  App._ptmCopiedStyle = { slot: name, style };
  toast(`Copied style from ${name}. Right-click a slot to paste.`, "ok");
};

App.ptmPasteStyle = (names) => {
  const pm = App.paytableMapper;
  if (!pm || !App._ptmCopiedStyle) { toast("Copy a slot style first (right-click a slot → Copy style).", "err"); return; }
  const style = App._ptmCopiedStyle.style;
  const keys = Object.keys(style);
  App.ptmPushUndo();
  let n = 0;
  (names || []).forEach((slot) => {
    let m = pm.mappings[slot];
    if (!m || typeof m !== "object") m = pm.mappings[slot] = App.ptmDefaultMapping(slot);
    keys.forEach((k) => { m[k] = style[k]; });
    n++;
  });
  App.ptmScheduleAutoSave();
  App.ptmRenderPanel();
  App.ptmRenderPreviewOverlay();
  toast(`Pasted style from ${App._ptmCopiedStyle.slot} onto ${n} slot(s).`, "ok");
};

App.ptmHideContextMenu = () => {
  const m = document.getElementById("ptContextMenu");
  if (m) m.remove();
  App._ptmMenuItems = null;
};

App.ptmShowContextMenu = (x, y, slotName) => {
  App.ptmHideContextMenu();
  const pm = App.paytableMapper;
  const multi = pm?.multiSelected || [];
  const items = [];
  const cardSymbol = App.ptmCardSymbolSlot(slotName);
  if (cardSymbol) items.push({ label: "Replace symbol…", fn: () => App.ptmReplaceSymbolDialog(cardSymbol) });
  if (slotName) items.push({ label: "Copy style", fn: () => App.ptmCopyStyle(slotName) });
  const targets = slotName ? [slotName] : (multi.length ? multi.slice() : []);
  if (targets.length) {
    items.push({ label: `Paste style → ${targets.length} slot${targets.length > 1 ? "s" : ""}`, fn: () => App.ptmPasteStyle(targets), disabled: !App._ptmCopiedStyle });
  }
  if (slotName) {
    items.push({ label: "Rename slot…", fn: () => App.ptmRenameSlot(slotName) });
  }
  if (targets.length >= 2) {
    items.push({ label: `Group ${targets.length} slots (Ctrl+G)`, fn: () => App.ptmGroupSelection() });
    items.push({ label: `Wrap in Master (grid ${targets.length})…`, fn: () => App.ptmWrapSelection() });
  }
  if (slotName && ptgIcon(slotName)) {
    items.push({ label: "Slot size… (w × h)", fn: () => App.ptmSlotSizeDialog(slotName) });
  }
  if (slotName) {
    items.push({ label: "Duplicate (Ctrl+D)", fn: () => App.ptmDuplicate(slotName) });
  }
  if (targets.length >= 2) {
    items.push({ label: "Align selected…", fn: () => App.ptmShowAlignMenu() });
    items.push({ label: "Distribute selected…", fn: () => App.ptmShowDistributeMenu() });
  }
  if (targets.length >= 2) {
    items.push({ label: `Match size → all selected`, fn: () => App.ptmMatchSize() });
  }
  if (targets.length && targets.some((t) => App.ptmSlotGroup(t).length > 1)) {
    items.push({ label: "Ungroup (Ctrl+U)", fn: () => App.ptmUngroupSelection(targets) });
  }
  if (targets.length) {
    items.push({ label: `Delete ${targets.length > 1 ? targets.length + " slots" : "slot"} (Del)`, fn: () => App.ptmDeleteSlots(targets) });
  }
  if (multi.length) items.push({ label: "Clear multi-selection", fn: () => { pm.multiSelected = []; App.ptmRenderPreviewOverlay(); App.ptmRenderPanel(); } });
  if (!items.length) return;
  App._ptmMenuItems = items;
  const menu = document.createElement("div");
  menu.id = "ptContextMenu";
  menu.innerHTML = items.map((it, i) => `<button type="button" class="pt-ctx-item" ${it.disabled ? "disabled" : ""} onclick="App.ptmMenuClick(${i})">${esc(it.label)}</button>`).join("");
  menu.style.left = Math.min(x, window.innerWidth - 230) + "px";
  menu.style.top = Math.min(y, window.innerHeight - items.length * 34 - 12) + "px";
  document.body.appendChild(menu);
  document.addEventListener("click", App.ptmHideContextMenu, { once: true });
  document.addEventListener("keydown", (ev) => { if (ev.key === "Escape") App.ptmHideContextMenu(); }, { once: true });
};

App.ptmMenuClick = (i) => {
  const items = App._ptmMenuItems || [];
  App.ptmHideContextMenu();
  if (items[i] && typeof items[i].fn === "function") items[i].fn();
};

App.ptmShowMasterMenu = (x, y, id) => {
  App.ptmHideContextMenu();
  const m = App.ptmMaster(id);
  if (!m) return;
  const items = [
    { label: "Select master", fn: () => App.ptmSelectMaster(id) },
    { label: "Re-layout children", fn: () => App.ptmLayoutMaster(id) },
    { label: `Grid ${m.cols}×${m.rows} — edit in the properties panel below`, fn: () => App.ptmSelectMaster(id) },
    { label: "Unwrap (keep positions)", fn: () => App.ptmUnwrapMaster(id) },
  ];
  App._ptmMenuItems = items;
  const menu = document.createElement("div");
  menu.id = "ptContextMenu";
  menu.innerHTML = items.map((it, i) => `<button type="button" class="pt-ctx-item" onclick="App.ptmMenuClick(${i})">${esc(it.label)}</button>`).join("");
  menu.style.left = Math.min(x, window.innerWidth - 230) + "px";
  menu.style.top = Math.min(y, window.innerHeight - items.length * 34 - 12) + "px";
  document.body.appendChild(menu);
  document.addEventListener("click", App.ptmHideContextMenu, { once: true });
  document.addEventListener("keydown", (ev) => { if (ev.key === "Escape") App.ptmHideContextMenu(); }, { once: true });
};

App.ptmOpenModal = (title, sub, bodyHtml, footerHtml) => {
  App.ptmCloseModal();
  const mask = document.createElement("div");
  mask.className = "ptm-modal-mask";
  mask.id = "ptmModalMask";
  mask.addEventListener("click", (e) => { if (e.target === mask) App.ptmCloseModal(); });
  mask.innerHTML = `
    <div class="ptm-modal" style="width:min(430px,92vw)">
      <div class="ptm-modal-head">
        <div class="ptm-modal-title">${esc(title)}</div>
        <button type="button" class="ptm-modal-x" onclick="App.ptmCloseModal()">✕</button>
      </div>
      ${sub ? `<div class="ptm-modal-sub">${esc(sub)}</div>` : ""}
      ${bodyHtml}
      ${footerHtml ? `<div class="ptm-modal-foot" style="display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end;margin-top:8px">${footerHtml}</div>` : ""}
    </div>`;
  document.body.appendChild(mask);
};

App.ptmCloseModal = () => { const m = document.getElementById("ptmModalMask"); if (m) m.remove(); };

App.ptmSlotSizeDialog = (name) => {
  const pm = App.paytableMapper;
  const b = (pm?.template?.slots || {})[name] || {};
  const w = ptgSlotV(name, "w", b.w || 0);
  const h = ptgSlotV(name, "h", b.h || 0);
  App.ptmOpenModal(
    "Slot size",
    `Set the width & height of the "${name}" slot box. The mapped icon/text data stays untouched — it just re-centers inside the resized box.`,
    `<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
      <label class="form-label" style="display:flex;flex-direction:column;gap:4px">Width (px)
        <input id="ptSizeW" type="number" class="form-input" style="width:100%" value="${esc(w)}" min="8" max="2000">
      </label>
      <label class="form-label" style="display:flex;flex-direction:column;gap:4px">Height (px)
        <input id="ptSizeH" type="number" class="form-input" style="width:100%" value="${esc(h)}" min="8" max="2000">
      </label>
    </div>`,
    `<button type="button" class="pt-btn secondary" onclick="App.ptmApplySlotSize('${esc(name)}','all')">Apply to ALL symbol slots</button>
     <button type="button" class="pt-btn primary" onclick="App.ptmApplySlotSize('${esc(name)}','only')">Apply to this slot only</button>`
  );
  const wIn = document.getElementById("ptSizeW");
  setTimeout(() => { wIn && wIn.select(); }, 30);
};

App.ptmApplySlotSize = (name, scope) => {
  const pm = App.paytableMapper;
  if (!pm || !pm.template) return;
  const W = Math.max(8, Math.min(2000, Math.round(parseFloat(document.getElementById("ptSizeW")?.value) || 0)));
  const H = Math.max(8, Math.min(2000, Math.round(parseFloat(document.getElementById("ptSizeH")?.value) || 0)));
  if (!W || !H) { toast("Enter a valid width and height (min 8px).", "err"); return; }
  App.ptmPushUndo();
  const targets = [];
  Object.keys(pm.template.slots || {}).forEach((slot) => {
    if (scope === "all" ? !ptgIcon(slot) : slot !== name) return;
    const b = pm.template.slots[slot];
    if (!b || typeof b !== "object") return;
    b.w = W;
    b.h = H;
    targets.push(slot);
  });
  if (!targets.length) { toast("No matching symbol slots found.", "err"); return; }
  if (scope === "all") {
    App.ptmRememberGlobal("slotsize", "w", W);
    App.ptmRememberGlobal("slotsize", "h", H);
  }
  App.ptmCloseModal();
  App.ptmScheduleAutoSave();
  App.ptmRenderPreviewOverlay();
  App.ptmLiveRender();
  toast(`Resized ${targets.length > 1 ? targets.length + " symbol slots" : `"${targets[0]}"`} to ${W}×${H}.`, "ok");
};

/* ---- Layout toolkit: align / distribute / nudge / match size / duplicate ----
   Operates on the effective transform set — a live multi-selection (>=2)
   wins, otherwise the saved group of the selected slot, else the single slot.
   Same rule the drag/scale anchors use in ptmEffGroup. */
App._ptmTransformTargets = () => {
  const pm = App.paytableMapper;
  if (!pm || !pm.template) return [];
  const multi = (pm.multiSelected || []).filter((n) => pm.template.slots[n]);
  if (multi.length >= 2) return multi.slice();
  if (pm.selected && pm.template.slots[pm.selected]) {
    return App.ptmEffGroup(pm.selected).filter((n) => pm.template.slots[n]);
  }
  return [];
};

App._ptmSelectionBox = (names) => {
  const pm = App.paytableMapper;
  let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
  (names || []).forEach((n) => {
    const b = pm.template.slots[n];
    if (!b) return;
    x0 = Math.min(x0, b.x); y0 = Math.min(y0, b.y);
    x1 = Math.max(x1, b.x + b.w); y1 = Math.max(y1, b.y + b.h);
  });
  return x0 === Infinity ? null : { x0, y0, x1, y1, w: x1 - x0, h: y1 - y0 };
};

App._ptmCanvasDims = () => {
  const pm = App.paytableMapper;
  return { cw: pm.template.canvas?.width || 1920, ch: pm.template.canvas?.height || 1080 };
};

App.ptmFinishedLayout = (msg) => {
  App.ptmScheduleAutoSave();
  App.ptmRenderPreviewOverlay();
  App.ptmRenderPanel();
  App.ptmLiveRender();
  if (msg) toast(msg, "ok");
};

App.ptmAlign = (edge) => {
  const pm = App.paytableMapper;
  if (!pm || !pm.template) return;
  const t = App._ptmTransformTargets();
  if (t.length < 2) { toast("Select at least 2 slots to align (shift-click or marquee).", ""); return; }
  const box = App._ptmSelectionBox(t);
  if (!box) return;
  const { cw, ch } = App._ptmCanvasDims();
  App.ptmPushUndo();
  t.forEach((n) => {
    const b = pm.template.slots[n];
    if (!b) return;
    if (edge === "left") b.x = box.x0;
    else if (edge === "center") b.x = box.x0 + Math.round((box.w - b.w) / 2);
    else if (edge === "right") b.x = box.x1 - b.w;
    else if (edge === "top") b.y = box.y0;
    else if (edge === "middle") b.y = box.y0 + Math.round((box.h - b.h) / 2);
    else if (edge === "bottom") b.y = box.y1 - b.h;
    App._ptmClampBox(b, cw, ch);
  });
  App.ptmFinishedLayout(`Aligned ${t.length} slots ${edge}.`);
};

App.ptmDistribute = (axis) => {
  const pm = App.paytableMapper;
  if (!pm || !pm.template) return;
  const t = App._ptmTransformTargets();
  if (t.length < 3) { toast("Select at least 3 slots to distribute evenly.", ""); return; }
  const key = axis === "h" ? "x" : "y";
  const dim = axis === "h" ? "w" : "h";
  const sorted = t.slice().sort((a, b) => (pm.template.slots[a][key] || 0) - (pm.template.slots[b][key] || 0));
  const fb = pm.template.slots[sorted[0]];
  const lb = pm.template.slots[sorted[sorted.length - 1]];
  const span = lb[key] + lb[dim] - fb[key];
  let used = 0;
  sorted.forEach((n) => { used += pm.template.slots[n][dim]; });
  const gap = Math.max(0, (span - used) / (sorted.length - 1));
  App.ptmPushUndo();
  let cur = fb[key];
  sorted.forEach((n, i) => {
    const b = pm.template.slots[n];
    if (i > 0) b[key] = Math.round(cur);
    cur += b[dim] + gap;
  });
  App.ptmFinishedLayout(`Distributed ${t.length} slots ${axis === "h" ? "horizontally" : "vertically"}.`);
};

App._ptmClampBox = (b, cw, ch) => {
  b.x = Math.round(Math.min(Math.max(0, b.x), Math.max(0, cw - b.w)));
  b.y = Math.round(Math.min(Math.max(0, b.y), Math.max(0, ch - b.h)));
};

App.ptmNudge = (dx, dy) => {
  const pm = App.paytableMapper;
  if (!pm || !pm.template) return;
  const t = App._ptmTransformTargets();
  if (!t.length) return;
  const { cw, ch } = App._ptmCanvasDims();
  App.ptmPushUndo();
  t.forEach((n) => {
    const b = pm.template.slots[n];
    if (!b) return;
    b.x = Math.round(Math.min(Math.max(0, (b.x || 0) + dx), Math.max(0, cw - (b.w || 0))));
    b.y = Math.round(Math.min(Math.max(0, (b.y || 0) + dy), Math.max(0, ch - (b.h || 0))));
  });
  App.ptmFinishedLayout();
};

App.ptmMatchSize = () => {
  const pm = App.paytableMapper;
  if (!pm || !pm.template) return;
  const multi = (pm.multiSelected || []).filter((n) => pm.template.slots[n]);
  let ref = (multi.includes(pm.selected) && pm.selected) ? pm.selected : (multi[0] || "");
  let others = multi.filter((n) => n !== ref);
  if (!others.length && ref && pm.template.slots[ref]) {
    const g = App.ptmSlotGroup(ref);
    others = g.filter((n) => n !== ref);
    if (!others.length && !multi.length) ref = "";
  }
  if (!ref || !others.length) { toast("Select more than one slot (or a group) to match sizes.", ""); return; }
  const rb = pm.template.slots[ref];
  const { cw, ch } = App._ptmCanvasDims();
  App.ptmPushUndo();
  others.forEach((n) => {
    const b = pm.template.slots[n];
    if (!b) return;
    b.w = Math.min(Math.round(rb.w), Math.max(1, cw - b.x));
    b.h = Math.min(Math.round(rb.h), Math.max(1, ch - b.y));
  });
  App.ptmFinishedLayout(`Matched ${others.length} slot${others.length > 1 ? "s" : ""} to "${ref}" size.`);
};

App.ptmDuplicate = (name) => {
  const pm = App.paytableMapper;
  const src = (name || pm.selected || "");
  if (!pm || !pm.template || !src || !pm.template.slots[src]) { toast("Select a slot to duplicate first.", "err"); return; }
  const { cw, ch } = App._ptmCanvasDims();
  let n = 1;
  let newName = "@slot.slot." + n;
  while (pm.template.slots[newName]) { n++; newName = "@slot.slot." + n; }
  const b = pm.template.slots[src];
  const nb = { x: Math.max(0, Math.round(b.x) + 20), y: Math.max(0, Math.round(b.y) + 20), w: b.w, h: b.h };
  App.ptmPushUndo();
  pm.template.slots[newName] = nb;
  pm.mappings = pm.mappings || {};
  const m = pm.mappings[src];
  pm.mappings[newName] = m ? JSON.parse(JSON.stringify(m)) : App.ptmDefaultMapping(newName);
  pm.mappings[newName].slot = newName;
  pm.multiSelected = [];
  pm.selected = newName;
  App.ptmStampGroups();
  App.ptmRenderPreviewOverlay();
  App.ptmRenderPanel();
  App.ptmScheduleAutoSave();
  App.ptmLiveRender();
  toast(`Duplicated "${src}" → "${newName}" (Ctrl+D).`, "ok");
};

App.ptmShowAlignMenu = () => {
  const t = App._ptmTransformTargets();
  if (t.length < 2) { toast("Select at least 2 slots to align.", ""); return; }
  const opt = (val, label) => `<button type="button" class="pt-btn secondary" onclick="App.ptmAlign('${val}');App.ptmCloseModal()">${label}</button>`;
  App.ptmOpenModal("Align selected", `${t.length} slots selected — aligned relative to their combined bounding box.`, "",
    opt("left", "Left") + opt("center", "Center H") + opt("right", "Right") + opt("top", "Top") + opt("middle", "Middle V") + opt("bottom", "Bottom"));
};

App.ptmShowDistributeMenu = () => {
  const t = App._ptmTransformTargets();
  if (t.length < 3) { toast("Select at least 3 slots to distribute.", ""); return; }
  const opt = (val, label) => `<button type="button" class="pt-btn secondary" onclick="App.ptmDistribute('${val}');App.ptmCloseModal()">${label}</button>`;
  App.ptmOpenModal("Distribute selected", `${t.length} slots selected — evenly spaced with equal gaps (first & last stay put).`, "",
    opt("h", "Horizontally") + opt("v", "Vertically"));
};

App.ptmBindPreviewInteractions = () => {
  const canvas = document.getElementById("ptPreviewCanvas");
  if (!canvas || canvas._ptCtxBound) return;
  canvas._ptCtxBound = true;
  canvas.addEventListener("contextmenu", (e) => {
    e.preventDefault();
    const mEl = e.target && e.target.closest ? e.target.closest(".ptm-master") : null;
    if (mEl) {
      App.ptmShowMasterMenu(e.clientX, e.clientY, mEl.getAttribute("data-master") || "");
      return;
    }
    const bandEl = e.target && e.target.closest && !e.target.closest(".tm-slot") ? e.target.closest(".ptm-band") : null;
    if (bandEl) {
      const card = e.target.closest(".ptm-gen-card");
      App.ptmShowBandMenu(e.clientX, e.clientY, bandEl.getAttribute("data-band") || "", card ? card.getAttribute("data-card-slot") : "");
      return;
    }
    const el = e.target && e.target.closest ? e.target.closest(".tm-slot") : null;
    const name = el ? el.getAttribute("data-slot") || "" : "";
    App.ptmShowContextMenu(e.clientX, e.clientY, name);
  });
  canvas.addEventListener("pointerdown", (e) => {
    if (App.route !== "paytable") return;
    if (e.button !== 0) return;
    if (e.target && e.target.closest && e.target.closest(".tm-slot, .ptm-master, .ptm-handle")) return;
    App.ptmMarqueeStart(e);
  });
};

App.ptmRenderSlotList = () => {
  const el = document.getElementById("ptSlotList");
  const pm = App.paytableMapper;
  if (!el) return;
  if (!pm || !pm.template) { el.innerHTML = ""; return; }
  const slots = pm.template.slots || {};
  const mapped = pm.mappings || {};
  const multi = pm.multiSelected || [];
  const missingIcons = new Set(pm.iconIssues || []);
  const overflow = new Set(pm.overflowIssues || []);
  el.innerHTML = Object.keys(slots).map((name) => {
    const m = mapped[name];
    const noIcon = missingIcons.has(name);
    const tooBig = overflow.has(name);
    return `<button class="pt-slot-item ${m ? "mapped" : ""} ${noIcon || tooBig ? "warn" : ""} ${name === pm.selected ? "selected" : ""} ${multi.includes(name) ? "multi" : ""}" type="button"
      onclick="App.ptmSelect('${esc(name)}')" ondblclick="App.ptmRenameSlot('${esc(name)}')" title="Click to select · double-click to rename">
      <span class="pt-slot-dot"></span><span class="pt-slot-item-name">${esc(name)}</span>
      <span class="pt-slot-item-src">${m ? esc(m.source || m.token || (m.mode === "icon" ? "icon" : "")) : "unmapped"}${noIcon ? " · no icon" : ""}${tooBig ? " · too big" : ""}</span>
      <span class="pt-slot-del" title="Delete slot" onclick="event.stopPropagation();App.ptmDeleteSlots(['${esc(name)}'])">🗑</span>
    </button>`;
  }).join("");
};

App.ptmRenderPanel = () => {
  if (App.route !== "paytable") return;
  const pm = App.paytableMapper;
  if (!pm || !pm.template) {
    App.properties = [];
    App.renderProperties();
    App.ptmRenderGlobalSettings();
    return;
  }
  const propsHtml = pm.selectedMaster
    ? App.ptmMasterPropsHtml(pm.selectedMaster)
    : pm.selected
      ? App.ptmBandPartBanner() + App.ptmPropsHtml(pm.selected)
      : pm.selectedBand
        ? App.ptmBandPropsHtml(pm.selectedBand)
        : `<div class="tm-empty">Select a slot or a master (blue grid box) on the preview to edit its properties.</div>`;
  App.properties = [{ type: "raw", body: propsHtml }];
  App.renderProperties();
  App.ptmRenderSlotList();
  App.ptmRenderGlobalSettings();
};

const ptgPay = (s) => /(?:^|\.)pay\d*$/i.test(String(s));
const ptgValue = (s) => /(?:^|\.)value\d*$/i.test(String(s));
const ptgTop = (s) => /(?:^|\.)topcardsbg(\.\d+)?$/i.test(String(s));
const ptgBot = (s) => /(?:^|\.)bottomcardsbg(\.\d+)?$/i.test(String(s));
const ptgIcon = (s) => {
  if (tmIsBoundsSlot(s) || ptgPay(s) || ptgValue(s)) return false;
  const d = App.ptmDefaultMapping(s);
  return !!(d && d.mode === "icon");
};

function ptgFirstSlot(match) {
  const pm = App.paytableMapper;
  if (!pm || !pm.template) return null;
  return Object.keys(pm.template.slots || {}).find(match) || null;
}

function ptgMapping(slot) {
  const pm = App.paytableMapper;
  if (!slot) return null;
  if (pm.mappings[slot] && typeof pm.mappings[slot] === "object") return pm.mappings[slot];
  return App.ptmDefaultMapping(slot) || null;
}

function ptgV(slot, key, fb) {
  const m = ptgMapping(slot);
  return m && m[key] != null ? m[key] : fb;
}

function ptgSlotV(slot, key, fb) {
  const pm = App.paytableMapper;
  if (!slot || !pm || !pm.template) return fb;
  const b = pm.template.slots[slot];
  return b && b[key] != null ? b[key] : fb;
}

function ptgFontOpts(cur) {
  const fonts = (App.state.fonts || []).slice();
  if (cur && !fonts.some((f) => String(f).toLowerCase() === String(cur).toLowerCase())) fonts.unshift(String(cur));
  if (!fonts.length) return `<option value="">System default</option>`;
  return fonts.map((f) => `<option value="${esc(f)}" ${String(f).toLowerCase() === String(cur || "").toLowerCase() ? "selected" : ""}>${esc(f)}</option>`).join("");
}

App.ptmRenderGlobalSettings = () => {
  const body = document.getElementById("ptGlobalBody");
  if (!body) return;
  const pm = App.paytableMapper;
  if (!pm || !pm.template) { body.innerHTML = `<div class="pt-g-hint">Load a paytable template to edit global slot styles.</div>`; return; }
  const mem = (cat) => (App.state.ptmGlobalStyles || {})[cat] || {};
  const row = (label, control) => `<div class="form-row"><label class="form-label">${label}</label>${control}</div>`;
  const colorCtl = (cat, key, slot, fb) => { const g = mem(cat); return `<input type="color" class="form-input" value="${esc(ptgV(slot, key, g[key] ?? fb))}" oninput="App.ptmGlobalSet('${cat}','${key}',this.value)" />`; };
  const numCtl = (cat, key, slot, fb, min, max) => { const g = mem(cat); return `<input type="number" class="form-input" value="${esc(ptgV(slot, key, g[key] ?? fb))}" min="${min}" max="${max}" oninput="App.ptmGlobalSet('${cat}','${key}',parseFloat(this.value)||0)" />`; };
  const slotNumCtl = (key) => { const g = mem("slotsize"); const slot = ptgFirstSlot(ptgIcon); return `<input type="number" class="form-input" value="${esc(ptgSlotV(slot, key, g[key] ?? 0))}" min="8" max="2000" oninput="App.ptmSlotSizeSet('${key}',this.value)" />`; };
  const boolCtl = (cat, key, slot) => { const g = mem(cat); return `<label class="pt-g-switch"><input type="checkbox" ${ptgV(slot, key, g[key] ?? false) ? "checked" : ""} onchange="App.ptmGlobalSet('${cat}','${key}',this.checked)" /><span></span></label>`; };
  const fontCtl = (cat, slot) => { const g = mem(cat); return `<select class="form-input" onchange="App.ptmGlobalSet('${cat}','font_name',this.value)">${ptgFontOpts(ptgV(slot, "font_name", g.font_name || ""))}</select>`; };
  const card = (title, badge, inner) => `<div class="settings-card"><div class="card-header"><span class="card-title">${title}</span><span class="card-badge">${badge}</span></div>${inner}</div>`;
  const textGroup = (cat, title, badge, slot) => card(title, badge, [
      row("Text color", colorCtl(cat, "color", slot, "#FFFFFF")),
      row("Font size", numCtl(cat, "font_size", slot, 30, 4, 400)),
      row("Font name", fontCtl(cat, slot)),
      row("Stroke color", colorCtl(cat, "stroke_color", slot, "#FFFFFF")),
      row("Stroke width", numCtl(cat, "stroke_width", slot, 0, 0, 50)),
      row("Stroke on", boolCtl(cat, "stroke_enabled", slot)),
      row("Background color", colorCtl(cat, "background_color", slot, "#10141c")),
      row("Fill on", boolCtl(cat, "fill_enabled", slot)),
    ].join(""));
  const bgGroup = (cat, title, badge, slot) => card(title, badge, [
      row("Background color", colorCtl(cat, "background_color", slot, "#000000")),
      row("Fill on", boolCtl(cat, "fill_enabled", slot)),
      row("Stroke color", colorCtl(cat, "stroke_color", slot, "#FFFFFF")),
      row("Stroke width", numCtl(cat, "stroke_width", slot, 0, 0, 50)),
      row("Stroke on", boolCtl(cat, "stroke_enabled", slot)),
    ].join(""));
  body.innerHTML = `
    ${textGroup("pay", "Cards Pay", "@SLOT.*.PAY", ptgFirstSlot(ptgPay))}
    ${textGroup("value", "Cards Value", "@SLOT.*.VALUE", ptgFirstSlot(ptgValue))}
    <div class="pt-g-stack">
      ${bgGroup("topbg", "Top Cards Background", "@SLOT.TOPCARDSBG.*", ptgFirstSlot(ptgTop))}
      ${bgGroup("botbg", "Bottom Cards Background", "@SLOT.BOTTOMCARDSBG.*", ptgFirstSlot(ptgBot))}
      ${card("Cards Size (Icon Slots)", "Dimensions",
        row("Icon height", numCtl("cards", "icon_height", ptgFirstSlot(ptgIcon), 120, 8, 600))
        + row("Slot width", slotNumCtl("w"))
        + row("Slot height", slotNumCtl("h")))}
    </div>`;
};

App.ptmGlobalSet = (cat, key, value) => {
  const pm = App.paytableMapper;
  if (!pm || !pm.template) return;
  const match = cat === "pay" ? ptgPay : cat === "value" ? ptgValue : cat === "topbg" ? ptgTop : cat === "botbg" ? ptgBot : cat === "cards" ? ptgIcon : null;
  if (!match) return;
  App.ptmPushUndo();
  let n = 0;
  Object.keys(pm.template.slots || {}).forEach((slot) => {
    if (!match(slot)) return;
    let m = pm.mappings[slot];
    if (!m || typeof m !== "object") {
      m = pm.mappings[slot] = (cat === "topbg" || cat === "botbg")
        ? { mode: "text", source: "", slot, color: "#FFFFFF", font_size: 30, icon_height: 48, alignment: "center", vertical_align: "center", padding: [0, 0, 0, 0], stroke_color: "#FFFFFF", stroke_width: 0, stroke_enabled: false }
        : App.ptmDefaultMapping(slot);
    }
    if (key === "background_color") { m.background_color = value; m.fill_enabled = true; }
    else m[key] = value;
    if (key === "font_name" || key === "font_size") m.font_override = true;
    n++;
  });
  if (!n) { toast("No slots match that group in this layout.", "err"); return; }
  App.ptmRememberGlobal(cat, key, value);
  App.ptmScheduleAutoSave();
  App.ptmRenderSlotList();
  App.ptmRenderPreviewOverlay();
  App.ptmLiveRender();
};

/* Global "Slot width / Slot height": resizes the SLOT BOXES of every symbol
   slot (Pic1..5, Ace..9, Ten, etc.) — template.slots geometry only. The
   mapped data (icons/text) is NOT touched; it just re-centers in the resized
   box. */
App.ptmSlotSizeSet = (key, value) => {
  const pm = App.paytableMapper;
  if (!pm || !pm.template) return;
  const v = Math.max(8, Math.round(parseFloat(value) || 0));
  if (!v) return;
  App.ptmPushUndo();
  let n = 0;
  Object.keys(pm.template.slots).forEach((slot) => {
    if (!ptgIcon(slot)) return;
    const b = pm.template.slots[slot];
    if (!b || typeof b !== "object") return;
    b[key] = v;
    n++;
  });
  if (!n) { toast("No symbol slots match in this layout.", "err"); return; }
  App.ptmRememberGlobal("slotsize", key, v);
  App.ptmScheduleAutoSave();
  App.ptmRenderPreviewOverlay();
  App.ptmLiveRender();
  toast(`Resized ${n} symbol slot(s) — ${key === "w" ? "width" : "height"} ${v}px.`, "ok");
};

App.ptmRememberGlobal = (cat, key, value) => {
  const st = App.state.ptmGlobalStyles || (App.state.ptmGlobalStyles = {});
  const group = st[cat] || (st[cat] = {});
  if (key === "background_color") group.fill_enabled = true;
  if (key === "font_name" || key === "font_size") group.font_override = true;
  group[key] = value;
  App.ptmSaveGlobalStyles();
};

App.ptmSaveGlobalStyles = debounce(async () => {
  try {
    await api("/api/paytable_mapper/global_styles", { method: "POST", body: { styles: App.state.ptmGlobalStyles || {} } });
  } catch (e) { /* remembered settings are best-effort */ }
}, 800);

App.ptmAdvancedEdit = async () => {
  if (!window.PTEditor) { toast("Advanced Edit Mode failed to load (pt-editor.js missing — hard refresh the page).", "err"); return; }
  const ready = () => {
    const pm = App.paytableMapper;
    return !!(pm && pm.template && Object.keys(pm.template.slots || {}).length);
  };
  if (!ready()) {
    if (typeof App.ensurePaytableDefault === "function") {
      try { await App.ensurePaytableDefault(); } catch (e) { /* continue to direct load */ }
    }
    if (!ready()) {
      const path = (App.get("dynamic_settings.template_json") || "").trim();
      if (path) {
        try {
          const d = await api("/api/paytable_mapper/load", { method: "POST", body: { path } });
          if (d.ok && d.template && Object.keys(d.template.slots || {}).length) {
            const mappings = {};
            Object.entries(d.mappings || {}).forEach(([slot, m]) => { if (m && typeof m === "object") mappings[slot] = m; });
            App.state.ptmUserPicked = true;
            App.state.paytableDefaultReady = true;
            App.paytableMapper = {
              psdPath: d.template.source_psd || "",
              template: d.template,
              mappings,
              sheetName: d.sheet_name || "",
              tableName: d.template_id || d.template.template_id || "paytable",
              mappedPath: path,
              previewToken: d.preview_token || "",
              iconIssues: d.icon_issues || [],
              overflowIssues: d.overflow_issues || [],
              selected: "",
            };
            if (App.state.paytablePreviewToken && !App.paytableMapper.previewToken) {
              App.paytableMapper.previewToken = App.state.paytablePreviewToken;
            }
          }
        } catch (e) { /* fall through to error toast */ }
      }
    }
  }
  if (!ready()) {
    toast("No paytable template loaded — pick one from the template dropdown in the Paytable view first.", "err");
    return;
  }
  PTEditor.open();
};

App.ptmResetDefaults = async () => {
  const pm = App.paytableMapper;
  if (!pm || !pm.template) { toast("Load a paytable template first.", "err"); return; }
  const keep = ["slot", "mode", "source", "token", "repeat", "kind"];
  let n = 0;
  Object.keys(pm.mappings || {}).forEach((slot) => {
    if (tmIsBoundsSlot(slot)) return;
    const cur = pm.mappings[slot];
    if (!cur || typeof cur !== "object") return;
    const bgSlot = ptgTop(slot) || ptgBot(slot);
    const fresh = bgSlot
      ? { mode: "text", source: "", slot, color: "#FFFFFF", font_size: 30, icon_height: 48, alignment: "center", vertical_align: "center", padding: [0, 0, 0, 0] }
      : { ...App.ptmDefaultMapping(slot) };
    keep.forEach((k) => { if (cur[k] !== undefined) fresh[k] = cur[k]; });
    pm.mappings[slot] = fresh;
    n++;
  });
  App.state.ptmGlobalStyles = {};
  try {
    await api("/api/paytable_mapper/global_styles", { method: "POST", body: { clear: true } });
  } catch (e) { /* best-effort */ }
  App.ptmScheduleAutoSave();
  App.ptmRenderPanel();
  App.ptmRenderPreviewOverlay();
  App.ptmLiveRender();
  toast(`Reset ${n} slot(s) to default properties (mapped data kept).`, "ok");
};

// A layout learned from an artist PSD carries the artist's own per-slot styles
// and Excel bindings: global mapper styles and re-automapping must not touch it.
App.ptmIsArtistDesign = (template) => !!(template?.mapper_meta?.artist_design);

App.ptmApplyGlobalStyles = () => {
  const pm = App.paytableMapper;
  if (!pm || !pm.template) return;
  if (App.ptmIsArtistDesign(pm.template)) return;
  const st = App.state.ptmGlobalStyles || {};
  const defaults = { font_size: 30, stroke_width: 0, icon_height: 120 };
  const isDefault = (k, v) => v === undefined || v === null || v === "" || v === defaults[k]
    || (k === "color" && String(v).toLowerCase() === "#ffffff");
  const groups = [["pay", ptgPay], ["value", ptgValue], ["topbg", ptgTop], ["botbg", ptgBot], ["cards", ptgIcon]];
  Object.keys(pm.template.slots || {}).forEach((slot) => {
    if (pm.userTouched && pm.userTouched[slot]) return;
    groups.forEach(([cat, match]) => {
      if (!match(slot)) return;
      const remembered = st[cat];
      if (!remembered || typeof remembered !== "object") return;
      let m = pm.mappings[slot];
      if (!m || typeof m !== "object") {
        m = pm.mappings[slot] = (cat === "topbg" || cat === "botbg")
          ? { mode: "text", source: "", slot, color: "#FFFFFF", font_size: 30, icon_height: 48, alignment: "center", vertical_align: "center", padding: [0, 0, 0, 0] }
          : App.ptmDefaultMapping(slot);
      }
      Object.entries(remembered).forEach(([k, v]) => {
        if (isDefault(k, m[k])) {
          m[k] = v;
          if (k === "background_color") m.fill_enabled = true;
          if (k === "font_name" || k === "font_size") m.font_override = true;
        }
      });
    });
  });
  const slotSize = st.slotsize;
  if (slotSize && typeof slotSize === "object") {
    const wantsW = +slotSize.w > 0, wantsH = +slotSize.h > 0;
    if (wantsW || wantsH) {
      Object.keys(pm.template.slots || {}).forEach((slot) => {
        if (pm.userTouched && pm.userTouched[slot]) return;
        if (!ptgIcon(slot)) return;
        const b = pm.template.slots[slot];
        if (!b || typeof b !== "object") return;
        if (wantsW && !b.w) b.w = +slotSize.w;
        if (wantsH && !b.h) b.h = +slotSize.h;
      });
    }
  }
};

App.ptmScheduleAutoSave = debounce(async () => {
  const pm = App.paytableMapper;
  if (!pm || !pm.template || !pm.mappedPath) return;
  const mappings = Object.values(pm.mappings).filter((m) => m && m.slot);
  if (!mappings.length) return;
  const sheet = document.getElementById("ptmSheet")?.value || pm.sheetName || "";
  App.ptmStampGroups();
  try {
    const d = await api("/api/paytable_mapper/save", {
      method: "POST",
      body: {
        psd_path: pm.psdPath,
        sheet_name: sheet,
        template_id: pm.tableName || "paytable",
        template: pm.template,
        mappings,
        slot_prefix: "@slot",
        output_path: pm.mappedPath,
        annotations: App._ptBlueprint !== false,
      },
    });
    if (!d.ok) { toast("Auto-save failed: " + (d.error || "unknown error"), "err"); return; }
    if (d.preview_token) {
      pm.previewToken = d.preview_token;
      App.state.paytablePreviewToken = d.preview_token;
    }
  } catch (e) { toast("Auto-save failed: " + e.message, "err"); }
}, 1500);

// Live preview: renders ~60 ms after a change and keeps at most ONE request in
// flight — while one renders, newer edits queue a single follow-up, so dragging
// shows the latest state continuously instead of a backlog of stale frames.
App._ptmLive = { timer: null, busy: false, again: false };
App.ptmLiveRender = () => {
  const L = App._ptmLive;
  clearTimeout(L.timer);
  L.timer = setTimeout(App._ptmLiveRun, 60);
};
App._ptmLiveRun = async () => {
  const L = App._ptmLive;
  const pm = App.paytableMapper;
  if (!pm || !pm.template) return;
  if (L.busy) { L.again = true; return; }
  L.busy = true;
  try {
    const d = await api("/api/paytable_mapper/render_preview", {
      method: "POST",
      body: {
        template: pm.template,
        mappings: Object.values(pm.mappings || {}),
        sheet_name: pm.sheetName || "",
        annotations: App._ptBlueprint !== false,
      },
    });
    if (d.ok && d.preview_token && !L.again) {
      pm.previewToken = d.preview_token;
      pm.iconIssues = d.icon_issues || [];
      pm.overflowIssues = d.overflow_issues || [];
      pm.cardGrid = d.card_grid || {};
      App.state.paytablePreviewToken = d.preview_token;
      const img = document.getElementById("ptPreviewImg");
      if (img) img.src = "/api/table_preview/" + encodeURIComponent(d.preview_token) + "?v=" + Date.now();
      if (!App._ptmBandDrag && !App._ptmBandAnchor) App.ptmRenderPreviewOverlay();
      App.ptmRenderSheetCheck();
    }
  } catch (e) { toast("Live preview render failed: " + e.message, "err"); }
  finally {
    L.busy = false;
    if (L.again) { L.again = false; App._ptmLiveRun(); }
  }
};

App.ptmTemplateList = [];

App.ptmRefreshTemplateList = async () => {
  try {
    const d = await api("/api/paytable_templates", { method: "GET" });
    App.ptmTemplateList = d.templates || [];
  } catch (e) { App.ptmTemplateList = []; }
  const sel = document.getElementById("ptmTableName");
  if (!sel) return;
  const current = App.paytableMapper?.tableName || "";
  const opts = App.ptmTemplateList.map((t) => `<option value="${esc(t.path)}">${esc(t.name)}</option>`).join("");
  let currentOption = "";
  if (current && !App.ptmTemplateList.some((t) => t.name === current)) {
    currentOption = `<option value="">${esc(current)}</option>`;
  }
  sel.innerHTML = opts + currentOption;
  if (current) {
    const hit = App.ptmTemplateList.find((t) => t.name === current);
    sel.value = hit ? hit.path : "";
  }
};

App.ptmConfirmDelete = (name) => new Promise((resolve) => {
  const overlay = document.createElement("div");
  overlay.className = "overlay";
  overlay.style.zIndex = "10050";
  overlay.innerHTML = `<div class="table-mapper-dialog" style="width:min(460px,92vw);max-height:unset;height:auto">
    <div class="panel-header" style="margin-bottom:14px"><span class="panel-title">Delete template</span></div>
    <p class="tm-label" style="margin:0 0 16px">Delete "<b>${esc(name)}</b>" from the paytable template library? This cannot be undone.</p>
    <div class="tm-footer">
      <button class="btn ghost" id="ptmDelCancel">Cancel</button>
      <button class="btn btn-danger-outline" id="ptmDelOk">Delete</button>
    </div>
  </div>`;
  document.body.appendChild(overlay);
  const done = (result) => {
    if (!overlay.isConnected) return;
    overlay.remove();
    resolve(result);
  };
  // a click outside never closes it (what was typed in it would be lost): its ✕ or Cancel do
  document.getElementById("ptmDelCancel").addEventListener("click", () => done(false));
  document.getElementById("ptmDelOk").addEventListener("click", () => done(true));
});

App.ptmDeleteSelectedTemplate = async (name) => {
  const list = App.ptmTemplateList || [];
  let entry = null;
  if (name) {
    entry = list.find((t) => t.name === name) || null;
  } else {
    const sel = document.getElementById("ptmTableName");
    const path = sel ? sel.value : "";
    entry = list.find((t) => t.path === path) || null;
  }
  if (!entry) { toast("No template selected to delete.", "err"); return; }
  const ok = await App.ptmConfirmDelete(entry.name);
  if (!ok) return;
  try {
    const d = await api("/api/paytable_templates/delete", { method: "POST", body: { path: entry.path } });
    if (!d.ok) { toast(d.error || "Delete failed.", "err"); return; }
    toast(`Template "${entry.name}" deleted.`, "ok");
    App.ptmTemplateList = App.ptmTemplateList.filter((t) => t.path !== entry.path);
    const pm = App.paytableMapper;
    if (pm && pm.tableName === entry.name) { pm.tableName = ""; pm.mappedPath = ""; }
    await App.ptmRefreshTemplateList();
    if (App.ptmTemplateList.length) {
      await App.ptmTemplateSelected(App.ptmTemplateList[0].path);
    } else {
      const rr = window.renderRoute || (App && App.renderRoute);
      if (typeof rr === "function") { try { rr(); } catch (e) {} }
    }
  } catch (e) { toast("Delete failed: " + e.message, "err"); }
};

document.addEventListener("contextmenu", (e) => {
  const sel = e.target && e.target.closest ? e.target.closest("#ptmTableName") : null;
  if (!sel) return;
  e.preventDefault();
  const name = (sel.selectedOptions && sel.selectedOptions[0] ? sel.selectedOptions[0].text : "") || "";
  if (!name) return;
  document.querySelectorAll(".ptm-ctx-menu").forEach((n) => n.remove());
  const menu = document.createElement("div");
  menu.className = "ptm-ctx-menu";
  const item = document.createElement("div");
  item.className = "ptm-ctx-item danger";
  item.textContent = `Delete template \u201C${name}\u201D`;
  item.onclick = () => { menu.remove(); App.ptmDeleteSelectedTemplate(name); };
  menu.appendChild(item);
  const hint = document.createElement("div");
  hint.className = "ptm-ctx-hint";
  hint.textContent = "Removes the template from the library";
  menu.appendChild(hint);
  document.body.appendChild(menu);
  const mw = menu.offsetWidth || 230;
  const mh = menu.offsetHeight || 78;
  menu.style.left = Math.min(e.clientX, window.innerWidth - mw - 8) + "px";
  menu.style.top = Math.min(e.clientY, window.innerHeight - mh - 8) + "px";
  setTimeout(() => {
    const closeOutside = (ev) => {
      if (!menu.contains(ev.target)) menu.remove();
    };
    const closeKey = (ev) => { if (ev.key === "Escape") menu.remove(); };
    window.addEventListener("mousedown", closeOutside);
    window.addEventListener("scroll", closeOutside, { capture: true });
    window.addEventListener("keydown", closeKey);
    menu.addEventListener("DOMNodeRemoved", () => {
      window.removeEventListener("mousedown", closeOutside);
      window.removeEventListener("scroll", closeOutside, true);
      window.removeEventListener("keydown", closeKey);
    });
  }, 0);
});

App.ptmTemplateSelected = async (path) => {
  if (!path) { App.ptmRefreshTemplateList(); return; }
  const entry = App.ptmTemplateList.find((t) => t.path === path);
  try {
    const d = await api("/api/paytable_mapper/load", { method: "POST", body: { path } });
    if (!d.ok) { toast(d.error || "Load failed", "err"); App.ptmRefreshTemplateList(); return; }
    const template = d.template || {};
    const mappings = {};
    Object.entries(d.mappings || {}).forEach(([slot, m]) => { if (m && typeof m === "object") mappings[slot] = m; });
    let pm = App.paytableMapper;
    if (!pm) {
      pm = App.paytableMapper = { psdPath: "", template: {}, mappings: {}, sheetName: "", tableName: "", previewToken: "", selected: "" };
    }
    App.state.ptmUserPicked = true;
    App.state.paytableDefaultReady = true;
    pm.psdPath = template.source_psd || "";
    pm.template = template;
    pm.mappings = mappings;
    pm.sheetName = d.sheet_name || "";
    pm.tableName = entry?.name || d.template_id || template.template_id || "paytable";
    pm.mappedPath = d.path || "";
    pm.previewToken = d.preview_token || "";
    App.state.paytablePreviewToken = d.preview_token || "";
    // Auto-assign: the chosen template becomes the active build template
    // immediately (no manual Save needed) — builds render exactly this one.
    App.state.config.dynamic_settings = App.state.config.dynamic_settings || {};
    App.state.config.dynamic_settings.template_json = d.path;
    App.pushConfig();
    App.ptmScheduleAutoSave();
    App.state.ptmGlobalStyles = d.global_styles || App.state.ptmGlobalStyles || {};
    pm.iconIssues = d.icon_issues || [];
    pm.overflowIssues = d.overflow_issues || [];
    const img = document.getElementById("ptPreviewImg");
    if (img && d.preview_token) img.src = "/api/table_preview/" + encodeURIComponent(d.preview_token) + "?v=" + Date.now();
    App.ptmFillDefaults(pm.mappings);
    App.ptmApplyGlobalStyles();
    App.ptmAutoMapForTemplate();
    App.ptmRenderPanel();
    App.ptmRenderPreviewOverlay();
    App.ptmLiveRender();
    App.ptmRefreshTemplateList();
    toast(`Loaded template "${pm.tableName}" (${Object.keys(template.slots || {}).length} slots).`, "ok");
  } catch (e) { toast(e.message, "err"); }
};

// Auto map the just-chosen template to the active Excel sheet. Only fills
// slots that have no mapping (or stale excel refs) — anything the user set
// (icon sizes, fonts, colors) is never touched.
App.ptmAutoMapForTemplate = async () => {
  const pm = App.paytableMapper;
  if (!pm || !pm.template) return;
  if (App.ptmIsArtistDesign(pm.template)) return;
  if (!App.state.config?.excel_path) return;
  const sheet = document.getElementById("ptmSheet")?.value || pm.sheetName || "";
  if (!sheet) return;
  pm.sheetName = sheet;
  try {
    const d = await api("/api/paytable_mapper/automap", {
      method: "POST",
      timeout: 25000,
      body: { template: pm.template, excel_path: App.state.config.excel_path, sheet_name: sheet },
    });
    if (!d.ok) return;
    App.ptmApplyAutomap(d, pm.mappings, d.sheet_dims?.rows ? d.sheet_dims : undefined);
    App.ptmFillDefaults(pm.mappings);
    App.ptmScheduleAutoSave();
    App.ptmRenderPanel();
    App.ptmRenderPreviewOverlay();
    App.ptmLiveRender();
  } catch (e) { /* automap is best-effort */ }
};

App.ptmAddSourceDialog = () => new Promise((resolve) => {
  const overlay = document.createElement("div");
  overlay.className = "overlay";
  overlay.innerHTML = `<div class="table-mapper-dialog" style="width:min(480px,92vw);max-height:unset;height:auto">
      <div class="panel-header" style="margin-bottom:14px"><span class="panel-title">Add New Template</span></div>
      <p class="tm-label" style="margin:0 0 16px">Where should the new paytable template come from?</p>
      <div class="tm-footer" style="flex-direction:column;gap:12px">
        <div style="display:flex;gap:10px;width:100%">
          <button class="btn btn-primary tm-done-btn" style="flex:1;white-space:nowrap" id="ptmAddPc">${icon("file")} Add from PC</button>
          <button class="btn btn-primary tm-done-btn" style="flex:1;white-space:nowrap" id="ptmAddActive">${icon("spark")} Add from Active PSD</button>
        </div>
        <button class="btn secondary" style="width:100%;white-space:nowrap" id="ptmAddArtist" title="Learn the card layout, fonts, colours, effects and art from an artist's finished help-screen PSD. Numbers and text still come from Excel.">${icon("image")} Artist PSD (use its layout)</button>
        <div style="display:flex;justify-content:center;width:100%">
          <button class="btn btn-danger-outline" id="ptmAddCancel">Cancel</button>
        </div>
      </div>
    </div>`;
  document.body.appendChild(overlay);
  const done = (result) => {
    if (!overlay.isConnected) return;
    overlay.remove();
    resolve(result);
  };
  // a click outside never closes it (what was typed in it would be lost): its ✕ or Cancel do
  document.getElementById("ptmAddCancel").addEventListener("click", () => done(null));
  document.getElementById("ptmAddPc").addEventListener("click", () => done("pc"));
  document.getElementById("ptmAddActive").addEventListener("click", () => done("active"));
  document.getElementById("ptmAddArtist").addEventListener("click", () => done("artist"));
});

App.ptmPromptFilePath = (opts = {}) => new Promise((resolve) => {
  const overlay = document.createElement("div");
  overlay.className = "overlay";
  overlay.innerHTML = `<div class="table-mapper-dialog" style="width:min(620px,92vw);max-height:unset;height:auto">
      <div class="panel-header" style="margin-bottom:14px"><span class="panel-title">${esc(opts.title || "Add template from PC")}</span></div>
      <label class="tm-label" style="margin:0 0 6px">${esc(opts.label || "PSD / JSON file path")}</label>
      <input type="text" id="ptmImportPathInput" class="tm-path" placeholder="${esc(opts.placeholder || "C:\\path\\to\\template.psd or template.json")}" />
      <div class="hint" style="margin-top:8px">${esc(opts.hint || "PSD/PSB files are scanned for @slot.* layers through Photoshop; JSON files must be mapped-paytable designs (canvas + slots).")}</div>
      <div class="tm-footer">
        <button class="btn ghost" id="ptmImportPathCancel">Cancel</button>
        <button class="btn btn-primary tm-done-btn" id="ptmImportPathOk">${esc(opts.ok || "Import")}</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);
  const done = (result) => {
    if (!overlay.isConnected) return;
    overlay.remove();
    resolve(result);
  };
  // a click outside never closes it (what was typed in it would be lost): its ✕ or Cancel do
  document.getElementById("ptmImportPathCancel").addEventListener("click", () => done(null));
  document.getElementById("ptmImportPathOk").addEventListener("click", () => {
    const path = document.getElementById("ptmImportPathInput").value.trim();
    if (!path) { toast("File path is required.", "err"); return; }
    done(path);
  });
  document.getElementById("ptmImportPathInput").focus();
});

App.ptmAfterImport = async (d) => {
  await App.ptmRefreshTemplateList();
  if (d.path) App.ptmTemplateSelected(d.path);
  toast(`Imported template "${d.name}" (${d.slots} slots).`, "ok");
};

App.ptmAddTemplate = async () => {
  const pm = App.paytableMapper;
  if (!pm || !pm.template) { toast("Open the Paytable Mapper first.", "err"); return; }
  const choice = await App.ptmAddSourceDialog();
  if (!choice) return;
  if (choice === "artist") {
    let psdPath = "";
    const native = window.pywebview?.api;
    if (native && typeof native.browse_file === "function") {
      try { psdPath = await native.browse_file("psd"); } catch (e) { toast("Native file dialog failed (" + e.message + ").", "err"); return; }
    } else {
      psdPath = await App.ptmPromptFilePath({
        title: "Artist PSD (use its layout)", label: "Artist PSD / PSB file path",
        placeholder: "C:\\path\\to\\helpscreens.psd", ok: "Next",
        hint: "A finished help-screen PSD by an artist. Photoshop is not needed: the file is read directly.",
      });
    }
    if (psdPath) await App.ptmArtistDialog(psdPath);
    return;
  }
  if (choice === "pc") {
    let filePath = "";
    const native = window.pywebview?.api;
    if (native && typeof native.browse_file === "function") {
      try {
        filePath = await native.browse_file("template");
      } catch (e) { toast("Native file dialog failed (" + e.message + ").", "err"); return; }
    } else {
      filePath = await App.ptmPromptFilePath();
    }
    if (!filePath) return;
    try {
      const d = await api("/api/paytable_templates/import", { method: "POST", body: { path: filePath } });
      if (!d.ok) { toast(d.error || "Import failed", "err"); return; }
      await App.ptmAfterImport(d);
    } catch (e) { toast(e.message, "err"); }
    return;
  }
  try {
    const d = await api("/api/paytable_templates/import_active", { method: "POST", timeout: 30000 });
    if (!d.ok) { toast(d.error || "Import failed", "err"); return; }
    await App.ptmAfterImport(d);
  } catch (e) { toast(e.message, "err"); }
};

App.ptmApply = async () => {
  const pm = App.paytableMapper;
  if (!pm || !pm.template) { toast("Load a paytable template first.", "err"); return; }
  const mappings = Object.values(pm.mappings).filter((m) => m && m.slot);
  if (!mappings.length) { toast("Map at least one slot before applying.", "err"); return; }
  const sheet = document.getElementById("ptmSheet")?.value || pm.sheetName || "";
  App.ptmStampGroups();
  try {
    const d = await api("/api/paytable_mapper/save", {
      method: "POST",
      body: {
        psd_path: pm.psdPath,
        sheet_name: sheet,
        template_id: pm.tableName || "paytable",
        template: pm.template,
        mappings,
        slot_prefix: "@slot",
        output_path: pm.mappedPath || "",
        annotations: App._ptBlueprint !== false,
      },
    });
    if (!d.ok) { toast(d.error || "Apply failed", "err"); return; }
    if (d.path) pm.mappedPath = d.path;
    if (d.preview_token) {
      pm.previewToken = d.preview_token;
      App.state.paytablePreviewToken = d.preview_token;
    }
    if (d.config) App.state.config = d.config;
    App.pushConfig();
    App.ptmRenderPreviewOverlay();
    toast(`Applied — "${(pm.tableName || "paytable").trim()}" is now the active template for all paytable pages.`, "ok");
  } catch (e) { toast(e.message, "err"); }
};

App.ptmAutoMap = async () => {
  const pm = App.paytableMapper;
  if (!pm || !pm.template) { toast("Load or scan a template first.", "err"); return; }
  const sheet = document.getElementById("ptmSheet")?.value || pm.sheetName;
  pm.sheetName = sheet;
  const nameSel = document.getElementById("ptmTableName");
  pm.tableName = (nameSel?.selectedOptions?.[0]?.text || nameSel?.value || "").trim() || pm.tableName;
  if (!sheet) { toast("Select an Excel sheet first.", "err"); return; }
  if (!App.state.config.excel_path) { toast("Set the Excel file in Project first.", "err"); return; }
  try {
    const d = await api("/api/paytable_mapper/automap", {
      method: "POST",
      timeout: 25000,
      body: { template: pm.template, excel_path: App.state.config.excel_path, sheet_name: sheet },
    });
    if (!d.ok) { toast(d.error || "Auto-map failed", "err"); return; }
    const dims = d.sheet_dims?.rows ? d.sheet_dims : (App.state.scan?.excel?.sheets || []).find((s) => s.name === sheet);
    const res = App.ptmApplyAutomap(d, pm.mappings, dims);
    const icons = App.ptmFillDefaults(pm.mappings);
    const added = res.added;
    const fixed = res.fixed;
    App.ptmScheduleAutoSave();
    App.ptmRenderPanel();
    App.ptmRenderPreviewOverlay();
    App.ptmLiveRender();
    const un = (d.unmapped || []).length;
    toast(added
      ? `Auto-mapped ${added} slot(s)${fixed ? ` · filled ${fixed} slot(s)` : ""}${icons ? ` · ${icons} icon(s) by name` : ""}${un ? ` · ${un} unmapped` : ""}.`
      : (fixed ? `Filled ${fixed} slot mapping(s).`
        : (icons ? `${icons} icon slot(s) set by name (e.g. @slot.nigga → <nigga>).`
          : (un ? `${un} slot(s) need manual mapping — pick a slot and set its source.` : "No mappable slots found in this layout."))), added || fixed || icons ? "ok" : "err");
  } catch (e) { toast(e.message, "err"); }
};

App.ptmAutoLayoutDialog = () => new Promise((resolve) => {
  const overlay = document.createElement("div");
  overlay.className = "overlay";
  const placeOpts = [["right", "Right of symbol"], ["left", "Left of symbol"], ["below", "Below symbol"]];
  const rowOpts = [["", "Auto"], ["1", "1"], ["2", "2"], ["3", "3"], ["4", "4"]];
  const colOpts = [["", "Auto"], ["2", "2"], ["3", "3"], ["4", "4"], ["5", "5"], ["6", "6"]];
  const opt = (arr, sel) => arr.map(([v, l]) => `<option value="${v}" ${v === sel ? "selected" : ""}>${esc(l)}</option>`).join("");
  overlay.innerHTML = `<div class="table-mapper-dialog" style="width:min(520px,92vw);max-height:unset;height:auto">
      <div class="panel-header" style="margin-bottom:14px"><span class="panel-title">Auto layouts</span></div>
      <p class="tm-label" style="margin:0 0 16px">Regenerate this sheet's paytable layout. Pays &amp; values are vertically centered beside the symbol, or top-aligned when placed below it. Leave the grid on “Auto” to fit the sheet's own bands.</p>
      <div style="display:flex;flex-direction:column;gap:14px">
        <label class="tm-label" style="margin:0">Pays / values placement
          <select id="ptmAlPlacement" style="width:100%;margin-top:6px">${opt(placeOpts, "right")}</select>
        </label>
        <div style="display:flex;gap:12px">
          <label class="tm-label" style="margin:0;flex:1">Rows
            <select id="ptmAlRows" style="width:100%;margin-top:6px">${opt(rowOpts, "")}</select>
          </label>
          <label class="tm-label" style="margin:0;flex:1">Columns per row
            <select id="ptmAlCols" style="width:100%;margin-top:6px">${opt(colOpts, "")}</select>
          </label>
        </div>
        <div class="hint">Row-major fill: symbols flow left→right, top→bottom. If the grid can't hold every symbol, more rows are added automatically so none are dropped.</div>
      </div>
      <div class="tm-footer" style="margin-top:18px">
        <button class="btn ghost" id="ptmAlCancel">Cancel</button>
        <button class="btn btn-primary tm-done-btn" id="ptmAlApply">${icon("check")} Apply</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);
  const done = (result) => {
    if (!overlay.isConnected) return;
    overlay.remove();
    resolve(result);
  };
  // a click outside never closes it (what was typed in it would be lost): its ✕ or Cancel do
  document.getElementById("ptmAlCancel").addEventListener("click", () => done(null));
  document.getElementById("ptmAlApply").addEventListener("click", () => {
    const options = { placement: document.getElementById("ptmAlPlacement").value || "right" };
    const rowsRaw = document.getElementById("ptmAlRows").value;
    const colsRaw = document.getElementById("ptmAlCols").value;
    if (rowsRaw) options.rows = parseInt(rowsRaw, 10);
    if (colsRaw) options.cols = parseInt(colsRaw, 10);
    done(options);
  });
});

App.ptmAutoLayout = async () => {
  const pm = App.paytableMapper;
  if (!pm || !pm.template) { toast("Open the Paytable Mapper first.", "err"); return; }
  const sheet = document.getElementById("ptmSheet")?.value || pm.sheetName;
  if (!sheet) { toast("Select an Excel sheet first.", "err"); return; }
  if (!App.state.config.excel_path) { toast("Set the Excel file in Project first.", "err"); return; }
  const options = await App.ptmAutoLayoutDialog();
  if (!options) return;
  const prevName = (pm.tableName || "").trim();
  const prevId = (pm.template && pm.template.template_id) || "";
  try {
    const d = await api("/api/paytable_mapper/auto_layout", {
      method: "POST",
      timeout: 30000,
      body: { sheet_name: sheet, excel_path: App.state.config.excel_path, options, annotations: App._ptBlueprint !== false },
    });
    if (!d.ok) { toast(d.error || "Auto layout failed", "err"); return; }
    const template = d.template || {};
    if (prevId) template.template_id = prevId; // keep saving over the working template
    const mappings = {};
    (d.mappings || []).forEach((m) => { if (m && m.slot) mappings[m.slot] = m; });
    // Adopt the regenerated template BEFORE filling defaults — ptmFillDefaults
    // reads App.paytableMapper.template to know which slots to fill.
    App.paytableMapper = {
      psdPath: template.source_psd || "",
      template,
      mappings,
      sheetName: sheet,
      tableName: prevName || template.template_id || "AutoPaytable",
      previewToken: d.preview_token || "",
      selected: "",
    };
    App.ptmFillDefaults(mappings);
    // Persist as the active template (mirrors loading a built-in layout) and
    // get an authoritative preview render.
    const sv = await api("/api/paytable_mapper/save", {
      method: "POST",
      body: {
        psd_path: template.source_psd || "",
        sheet_name: sheet,
        template_id: template.template_id || "AutoPaytable",
        template,
        mappings,
        slot_prefix: template.slot_prefix || "@slot",
        annotations: App._ptBlueprint !== false,
      },
    });
    if (sv.ok) {
      if (sv.config) { App.state.config = sv.config; App.pushConfig(); }
      if (sv.preview_token) {
        App.paytableMapper.previewToken = sv.preview_token;
        App.state.paytablePreviewToken = sv.preview_token;
      }
    }
    App.state.paytableStats = {
      total: Object.keys(template.slots || {}).length,
      mapped: Object.keys(mappings).length,
      at: Date.now(),
    };
    App.ptmSyncView();
    const un = (d.unmapped || []).length;
    const placeLabel = { right: "right of", left: "left of", below: "below" }[options.placement] || "beside";
    const gridLabel = (options.rows || options.cols) ? ` · grid ${options.rows || "auto"}×${options.cols || "auto"}` : " · auto grid";
    toast(`Auto layout applied — pays/values ${placeLabel} the symbol${gridLabel}${un ? ` · ${un} unmapped` : ""}. Replaced the current layout's slots.`, "ok");
  } catch (e) { toast(e.message, "err"); }
};

App.ptmSet = (key, value) => {
  const pm = App.paytableMapper;
  if (!pm || !pm.selected || !pm.mappings[pm.selected]) return;
App.ptmPushUndo();
  pm.mappings[pm.selected][key] = value;
  pm.userTouched = pm.userTouched || {};
  pm.userTouched[pm.selected] = true;
  if (key === "source") {
    pm.mappings[pm.selected].source_pinned = true;  // artist's own cells win over auto re-bind
    pm.mappings[pm.selected].pinned_excel = App.ptmExcelKey();   // ...for this workbook only
  }
  if (key === "token") {
    // a typed symbol always draws — for this workbook; another Excel auto-maps again
    pm.mappings[pm.selected].symbol_pinned = !!String(value || "").trim();
    pm.mappings[pm.selected].pinned_excel = App.ptmExcelKey();
  }
  if (key === "font_size" || key === "font_name") pm.mappings[pm.selected].font_override = true;
  if (key === "source" && (pm.mappings[pm.selected].mode === "icon" || pm.mappings[pm.selected].mode === "text")) {
    // A cell reference (B7, B7:C9, b7,c9,a2) typed into a slot that defaults
    // to icon/text must read Excel — never render the ref itself as literal
    // text. This is how users re-assign cells (.text catch-all rows) to any
    // other slot and get the real cell content.
    const srcVal = String(value || "").trim();
    if (/^[A-Za-z]{1,3}\d+(?::[A-Za-z]{1,3}\d+)?(?:,[A-Za-z]{1,3}\d+)*$/.test(srcVal)) {
      pm.mappings[pm.selected].mode = "excel";
      App.ptmRenderPanel();
    }
  }
  if (key === "mode") App.ptmRenderPanel();
  App.ptmRenderPreviewOverlay();
  App.ptmLiveRender();
  App.ptmScheduleAutoSave();      // property edits are kept like moves and band changes
  if (["mode", "token", "source"].includes(key) && App.ptmIsSymbolSlot(pm.selected)) {
    App.ptmScheduleFillPayValues();
  }
};

App.ptmIsSymbolSlot = (name) => {
  return !!name && !tmIsBoundsSlot(name) && !/\.(pay|value)s?\d*$|^(pay|value)s?\d*$/i.test(name);
};

App.ptmFillPayValuesTimer = null;
App.ptmScheduleFillPayValues = (delay) => {
  clearTimeout(App.ptmFillPayValuesTimer);
  App.ptmFillPayValuesTimer = setTimeout(() => App.ptmFillPayValues(), delay == null ? 400 : delay);
};

App.ptmFillPayValues = async () => {
  const pm = App.paytableMapper;
  if (!pm || !pm.template) return;
  if (!App.state.config.excel_path) return;
  const sheet = document.getElementById("ptmSheet")?.value || pm.sheetName;
  if (!sheet) return;
  try {
    const d = await api("/api/paytable_mapper/fill_pay_values", {
      method: "POST",
      timeout: 25000,
      body: { template: pm.template, mappings: pm.mappings, excel_path: App.state.config.excel_path, sheet_name: sheet },
    });
    if (!d.ok || !d.mappings) return;
    let filled = 0;
    Object.entries(d.mappings).forEach(([slot, m]) => {
      const existing = pm.mappings[slot];
      if (!existing || (!existing.source && !existing.text)) {
        pm.mappings[slot] = m;
        filled++;
      }
    });
    if (!filled) return;
    App.ptmScheduleAutoSave();
    App.ptmRenderPanel();
    App.ptmRenderPreviewOverlay();
    App.ptmLiveRender();
  } catch (e) { /* background pay/value fill is best-effort */ }
};

App.ptmSetPadding = (index, value) => {
  const pm = App.paytableMapper;
  if (!pm || !pm.selected || !pm.mappings[pm.selected]) return;
  const m = pm.mappings[pm.selected];
  m.padding = m.padding ? [...m.padding] : [0, 0, 0, 0];
  while (m.padding.length < 4) m.padding.push(0);
  m.padding[index] = value;
  pm.userTouched = pm.userTouched || {};
  pm.userTouched[pm.selected] = true;
  App.ptmScheduleAutoSave();
  App.ptmRenderPreviewOverlay();
  App.ptmLiveRender();
};

App.ptmDefaultMapping = (name) => {
  const parts = String(name).split(".");
  const sym = (parts.pop() || "").trim();
  const base = (parts[0] || sym).trim();
  const isValueSlot = /^(pay|value)s?\d*$/i.test(sym);
  const isTextSlot = /^(title|count|payout|payouts|notes|text|note|label|description|subtitle|heading)$/i.test(sym)
    || /^(title|text|notes|note|count|payout|payouts|label|description|subtitle|heading)$/i.test(base);
  const tokenName = base === "wild" && /^\d+$/.test(sym) ? "wild" : sym.replace(/\s+/g, "");
  return isTextSlot || isValueSlot ? {
    mode: "text",
    source: "",
    slot: name,
    font_size: 30,
    icon_height: 48,
    color: "#FFFFFF",
    alignment: "center",
    vertical_align: isValueSlot ? "top" : "center",
    padding: [0, 0, 0, 0],
  } : {
    mode: "icon",
    token: "<" + tokenName + ">",
    slot: name,
    icon_height: 120,
    color: "#FFFFFF",
    alignment: "center",
    vertical_align: "center",
    padding: [0, 0, 0, 0],
  };
};

App.ptmFillDefaults = (mappings) => {
  const pm = App.paytableMapper;
  if (!pm || !pm.template || !mappings) return 0;
  let added = 0;
  Object.keys(pm.template.slots || {}).forEach((slot) => {
    if (tmIsBoundsSlot(slot)) return;
    if (mappings[slot] && typeof mappings[slot] === "object") return;
    const def = App.ptmDefaultMapping(slot);
    if (!def || def.mode !== "icon") return;
    mappings[slot] = def;
    added++;
  });
  return added;
};

App.ptmSanitizeMappings = (mappings) => {
  const dims = tmActiveSheetDims();
  let fixed = 0;
  Object.keys(mappings || {}).forEach((slot) => {
    const m = mappings[slot];
    if (!m || typeof m !== "object") return;
    const def = App.ptmDefaultMapping(slot);
    if (m.mode === "excel" && def && def.mode === "icon") {
      mappings[slot] = def;
      fixed++;
      return;
    }
    if (!dims || m.mode !== "excel" || !m.source) return;
    const ref = String(m.source).trim().match(/^([A-Za-z]{1,3})(\d+)$/);
    if (ref && (tmColIndex(ref[1]) > (dims.cols || 0) || parseInt(ref[2], 10) > (dims.rows || 0))) {
      mappings[slot] = App.ptmDefaultMapping(slot);
      fixed++;
    }
  });
  return fixed;
};

App.ptmApplyAutomap = (am, mappings, dims) => {
  const pm = App.paytableMapper;
  let added = 0;
  let fixed = 0;
  const validRef = (src) => {
    const m = String(src || "").trim().match(/^([A-Za-z]{1,3})(\d+)$/);
    if (!m) return false;
    if (!dims) return true;
    return tmColIndex(m[1]) <= (dims.cols || 0) && parseInt(m[2], 10) <= (dims.rows || 0);
  };
  const styleKeys = ["font_size", "font_name", "font_family", "font_override", "color",
    "background_color", "alignment", "vertical_align", "padding", "line_height",
    "letter_spacing", "opacity", "fill_enabled", "stroke_color", "stroke_width"];
  const preserveStyle = (fresh, existing) => {
    const merged = { ...fresh };
    if (existing && typeof existing === "object") {
      styleKeys.forEach((k) => { if (existing[k] !== undefined) merged[k] = existing[k]; });
    }
    return merged;
  };
  (am?.mappings || []).forEach((m) => {
    if (!m || !m.slot) return;
    if (pm.userCleared && pm.userCleared[m.slot]) return;
    if (pm.userTouched && pm.userTouched[m.slot]) return;
    const existing = mappings[m.slot];
    if (!existing) { mappings[m.slot] = m; added++; }
    else {
      const emptyDefault = !existing.source && !existing.text && !existing.token;
      const staleExcel = existing.mode === "excel" && existing.source && !validRef(existing.source);
      if (emptyDefault || staleExcel) {
        mappings[m.slot] = preserveStyle(m, existing);
        fixed++;
      }
    }
  });
  return { added, fixed };
};

App.ptmSelect = (name, ev) => {
  const pm = App.paytableMapper;
  if (!pm) return;
  if (App._ptmDragMoved) {
    App._ptmDragMoved = false;
    if (!(ev && (ev.shiftKey || ev.ctrlKey))) return;
  }
  App.ptmApplySelection(name, !!(ev && (ev.shiftKey || ev.ctrlKey)));
  App.ptmSlotClick(name, ev);
};

App.ptmRemoveMapping = (name) => {
  const pm = App.paytableMapper;
  if (!pm) return;
  delete pm.mappings[name];
  pm.userCleared = pm.userCleared || {};
  pm.userCleared[name] = true;
  if (pm.selected === name) pm.selected = "";
  App.ptmScheduleAutoSave();
  App.ptmRenderPanel();
  App.ptmRenderPreviewOverlay();
};

App.ptmPropsHtml = (name) => {
  const pm = App.paytableMapper;
  const m = pm.mappings[name] || {};
  const rawMode = String(m.mode || "excel").toLowerCase();
  const mode = rawMode === "symbol" ? "icon" : rawMode;
  const modes = [
    { value: "excel", label: "Excel Cell ref" },
    { value: "excel_text", label: "Excel Cell ref — text only (no icons)" },
    { value: "mixed", label: "Text and icon" },
    { value: "text", label: "Only text" },
    { value: "icon", label: "Only icon" },
  ];
  const aligns = [
    { value: "left", label: "Left" }, { value: "center", label: "Center" }, { value: "right", label: "Right" },
  ];
  const valigns = [
    { value: "top", label: "Top" }, { value: "center", label: "Center" }, { value: "bottom", label: "Bottom" },
  ];
  const fonts = (App.state.fonts || []).slice();
  const fontOpts = fonts.map((f) => `<option value="${esc(f)}" ${String(f).toLowerCase() === String(m.font_name || m.font_family || "").toLowerCase() ? "selected" : ""}>${esc(f)}</option>`).join("");
  const isIcon = mode === "icon";
  const isTextMode = mode === "text" || mode === "mixed";
  const isImage = !isIcon && isTextMode && /\.(png|jpg|jpeg|gif|bmp|svg)$/i.test(m.source || "");
  const modeHints = {
    excel: "Reads the content from an Excel cell or range. Tokens inside the cell (e.g. <pic1>) render as icons.",
    excel_text: "Reads the content from an Excel cell or range, strips all <tokens> — only the plain text renders, no icons.",
    mixed: "Renders the text with <token> icons drawn inline; tokens that don't resolve are hidden.",
    text: "Only text — <token> markers are stripped, no icons are ever rendered.",
    icon: "Dedicated icon — only the resolved <token> icon renders. Wild slots always use <wild> (WILD/Wild match too).",
  };
  const iconMissing = isIcon && (pm.iconIssues || []).includes(name);
  return `<div class="tm-panel">
    <div class="tm-prop-head">
      <span class="tm-prop-slot">${esc(name)}</span>
      <button class="btn ghost small" onclick="App.ptmRemoveMapping('${esc(name)}')">Clear</button>
    </div>
    <div class="tm-props">
      ${ptmProp("mode", "Content mode", "select", mode, { options: modes })}
      <div class="tm-hint">${modeHints[mode] || ""}</div>
      ${iconMissing ? `<div class="tm-hint tm-warn">No icon file found for ${esc(m.token || m.source || "")} — check your Icons Folder (e.g. ${esc((m.token || "icon").replace(/[<>]/g, "") + ".png")}).</div>` : ""}
      ${isIcon ? `<div class="tm-prop"><label>Symbol token (icon)</label>
        <input type="text" value="${esc(m.token || "")}" placeholder="e.g. &lt;pic1&gt; or &lt;wild&gt;" oninput="App.ptmSet('token', this.value)" />
        <div class="tm-hint">Renders the matching icon from your icon folder. Auto-map fills this from the Excel cell that holds &lt;pic1&gt; / &lt;wild&gt;.${m.asset_path ? ` Showing <b>${esc(String(m.asset_path).split(/[\\/]/).pop())}</b> (chosen by hand).` : ""}</div>
        <button class="btn secondary small" style="margin-top:6px" onclick="App.ptmReplaceSymbolDialog('${esc(name)}')">Replace symbol…</button></div>`
      : `<div class="tm-prop"><label>${mode === "excel" || mode === "excel_text" ? "Excel cell" : "Text (with &lt;icons&gt;)"}</label>
        <input type="text" value="${esc(m.source || "")}" placeholder="${mode === "excel" || mode === "excel_text" ? "e.g. C6 — comma-separated OK (b7,c9,a2)" : "type the text; &lt;pic1&gt; renders an icon"}" oninput="App.ptmSet('source', this.value)" />
        ${mode === "excel" || mode === "excel_text" ? `<div class="tm-hint">One cell (C6), a range (B7:C9) or several cells — values are joined: b7,c9,a2${mode === "excel_text" ? ". All &lt;tokens&gt; in the cell are stripped (text only)." : ""}</div>` : ""}</div>`}
      ${isIcon || isImage ? "" : `<div class="tm-prop"><label>Font</label><input type="text" list="ptmFontList" value="${esc(m.font_name || m.font_family || "")}" oninput="App.ptmSet('font_name', this.value)" /><datalist id="ptmFontList">${fontOpts}</datalist></div>`}
      ${isIcon || isImage ? "" : ptmProp("font_size", "Font size", "number", m.font_size ?? 30, { min: 4, max: 400 })}
      ${isIcon || isImage ? "" : ptmProp("color", "Text color", "color", m.color || "#FFFFFF")}
      ${isIcon || isImage ? "" : ptmProp("alignment", "Alignment", "select", m.alignment || "center", { options: aligns })}
      ${isIcon || isImage ? "" : ptmProp("vertical_align", "Vertical align", "select", m.vertical_align || "center", { options: valigns })}
      ${isIcon || isImage ? "" : `<div class="tm-prop"><label>Padding</label><div style="display:flex;gap:4px;align-items:center">
        ${["top", "right", "bottom", "left"].map((p, i) => `<input type="number" style="width:52px" value="${esc(m.padding?.[i] ?? 0)}" min="0" oninput="App.ptmSetPadding(${i}, parseFloat(this.value) || 0)" title="${p}" />`).join("")}
      </div></div>`}
      ${isIcon || isImage ? "" : ptmProp("line_height", "Line height", "number", m.line_height ?? 0, { min: 0, max: 400 })}
      ${mode === "text" || mode === "excel_text" ? "" : ptmProp("icon_height", "Icon height", "number", m.icon_height ?? 48, { min: 0, max: 400 })}
      ${ptmProp("background_color", "Slot background", "color", m.background_color || "#000000")}
      ${ptmProp("fill_enabled", "Fill background", "checkbox", !!m.fill_enabled)}
      ${ptmProp("stroke_color", "Stroke color", "color", m.stroke_color || "#FFFFFF")}
      ${ptmProp("stroke_width", "Stroke width", "number", m.stroke_width ?? 0, { min: 0, max: 50 })}
      ${ptmProp("stroke_enabled", "Enable stroke", "checkbox", !!m.stroke_enabled)}
      ${ptmProp("opacity", "Opacity %", "number", m.opacity ?? 100, { min: 0, max: 100 })}
      ${ptmProp("repeat", "Repeat per source row", "checkbox", !!m.repeat)}
    </div>
  </div>`;
};

App.ptmDoSave = async (body) => {
  try {
    const d = await api("/api/paytable_mapper/save", { method: "POST", body });
    if (!d.ok) { toast(d.error || "Save failed", "err"); return; }
    const pm = App.paytableMapper;
    if (d.path) pm.mappedPath = d.path;
    if (d.library_path) pm.tableName = (pm.tableName || "").trim() || d.library_path.split(/[\\/]/).pop().replace(/\.json$/i, "");
    if (d.preview_token) {
      pm.previewToken = d.preview_token;
      App.state.paytablePreviewToken = d.preview_token;
    }
    if (d.config) App.state.config = d.config;
    App.pushConfig();
    // The mirrored copy lives in PaytableTemplates — refresh the Template
    // name dropdown so the saved template is selectable right away.
    if (d.library_path) await App.ptmRefreshTemplateList();
    renderRoute();
    toast("Saved mapped paytable JSON: " + d.path + (d.root_path ? " · root copy: " + d.root_path : ""), "ok");
  } catch (e) { toast(e.message, "err"); }
};

App.ptmPromptSavePath = (defaultName, body) => new Promise((resolve) => {
  const overlay = document.createElement("div");
  overlay.className = "overlay";
  overlay.innerHTML = `<div class="table-mapper-dialog" style="width:min(620px,92vw);max-height:unset;height:auto">
      <div class="panel-header" style="margin-bottom:14px"><span class="panel-title">Save mapped paytable JSON</span></div>
      <label class="tm-label" style="margin:0 0 6px">Output path</label>
      <input type="text" id="ptmSavePathInput" class="tm-path" value="${esc(defaultName || "")}" />
      <div class="tm-footer">
        <button class="btn ghost" id="ptmSavePathCancel">Cancel</button>
        <button class="btn btn-primary tm-done-btn" id="ptmSavePathOk">Save</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);
  const done = (result) => {
    if (!overlay.isConnected) return;
    overlay.remove();
    resolve(result);
  };
  // a click outside never closes it (what was typed in it would be lost): its ✕ or Cancel do
  document.getElementById("ptmSavePathCancel").addEventListener("click", () => done(null));
  document.getElementById("ptmSavePathOk").addEventListener("click", () => {
    const path = document.getElementById("ptmSavePathInput").value.trim();
    if (!path) { toast("Output path is required.", "err"); return; }
    done(path);
  });
  document.getElementById("ptmSavePathInput").focus();
});

App.ptmSave = async () => {
  const pm = App.paytableMapper;
  if (!pm || !pm.template) { toast("Scan a PSD template first.", "err"); return; }
  const mappings = Object.values(pm.mappings).filter((m) => m && m.slot);
  if (!mappings.length) { toast("Map at least one slot before saving.", "err"); return; }
  const sheet = document.getElementById("ptmSheet")?.value || pm.sheetName;
  const nameSel = document.getElementById("ptmTableName");
  const tableName = (nameSel?.selectedOptions?.[0]?.text || nameSel?.value || "").trim() || pm.tableName || "paytable";
  pm.sheetName = sheet;
  pm.tableName = tableName;
  const safeName = (tableName.replace(/[^A-Za-z0-9_\-]+/g, "_").replace(/^_+|_+$/g, "") || "paytable");
  const body = {
    psd_path: pm.psdPath,
    sheet_name: sheet,
    template_id: tableName,
    template: pm.template,
    mappings,
    slot_prefix: "@slot",
    annotations: App._ptBlueprint !== false,
  };
  const native = window.pywebview?.api;
  if (native && typeof native.save_file === "function") {
    try {
      const path = await native.save_file("Save mapped paytable JSON", safeName + "_mapped.json");
      if (!path) return;
      body.output_path = path;
    } catch (e) { toast("Native save dialog failed (" + e.message + ") - saving to default folder.", "err"); }
  } else {
    const path = await App.ptmPromptSavePath(safeName + "_mapped.json", body);
    if (!path) return;
    body.output_path = path;
  }
  await App.ptmDoSave(body);
};

App.applyPreset = async (name) => {
  if (!name) return;
  try {
    const data = await api("/api/presets/" + encodeURIComponent(name));
    Object.assign(App.state.config, data.preset);
    App.pushConfig();
    toast(`Preset “${name}” applied.`);
    renderRoute();
  } catch (e) { toast(e.message, "err"); }
};

App.resetConfig = async () => {
  try {
    const data = await api("/api/config/reset", { method: "POST" });
    App.state.config = data.config;
    toast("Config reset to defaults.");
    renderRoute();
  } catch (e) { toast(e.message, "err"); }
};

App.clearSession = async () => {
  if (!confirm("Clear the session?\n\nAll fields — Excel, icons, background, output, and every setting — will be reset to their starting point.\n\nLayer styles, presets, and paytable page layout assignments will be preserved.")) return;
  // snapshot things that must survive the reset
  const savedDS = JSON.stringify(App.state.config.dynamic_settings || {});
  const savedPresets = App.state.presets || [];
  try {
    const data = await api("/api/config/reset", { method: "POST" });
    App.state.config = data.config;
    // restore the preserved categories
    App.state.config.dynamic_settings = JSON.parse(savedDS);
    App.state.presets = savedPresets;
    App.state.scan = null;
    App.state.iconFiles = [];
    App.state.ptmGlobalStyles = {};
    App.state.ptmUserPicked = false;
    App.state.paytableDefaultReady = false;
    App.state.paytablePreviewToken = "";
    App.state.paytableStats = null;
    App._pjManifest = null;
    App._pjInfo = null;
    App._ptPreviewDirty = true;
    toast("Session cleared — layer styles, presets, and paytable layout assignments preserved.");
    renderRoute();
  } catch (e) { toast(e.message, "err"); }
};

/* ------------------------------ Photoshop live actions ------------------------------ */

/* the copy also took the document's Global Light (server: capture-style): say so, once */
function lightNote(data) {
  const ch = data && data.light_changed;
  if (!ch || !ch.to) return "";
  return ` Global light ${Math.round(ch.to.angle)}° / ${Math.round(ch.to.altitude)}° taken from the Photoshop document`
    + (ch.from && ch.from.angle != null ? ` (was ${Math.round(ch.from.angle)}°).` : ".");
}

App.captureStyle = async (mode, target, name) => {
  try {
    const role = target === "heading" ? "Heading text" : target === "subheading" ? "Subheading text" : "Body text";
    const styleName = (name || "").trim() || prompt("Name this layer style:", `${role.replace(" text", "")} style`);
    if (!styleName) return;
    const data = await api("/api/ps/capture-style", { method: "POST", body: { mode, name: styleName, role } });
    if (!data.ok) { toast(data.error || "Capture failed.", "err"); return; }
    App.state.config = data.config;
    toast(`Layer style “${styleName}” captured and applied to ${role}.` + lightNote(data));
    App.refreshUI();
    renderRoute();
  } catch (e) { toast(e.message, "err"); }
};

App.captureLayerStyle = async (role, mode) => {
  const styleName = (prompt(`Name this layer style (copied from Photoshop):`, `${role.replace(" text", "")} style`) || "").trim();
  if (!styleName) return;
  try {
    const data = await api("/api/ps/capture-style", { method: "POST", body: { mode, name: styleName, role } });
    if (!data.ok) { toast(data.error || "Capture failed.", "err"); return; }
    App.state.config = data.config;
    toast(`Layer style “${styleName}” captured and assigned to ${role}.` + lightNote(data));
    App.refreshUI();
    renderRoute();
  } catch (e) { toast(e.message, "err"); }
};

App.assignLayerStyle = (role, name) => {
  const ds = (App.state.config.dynamic_settings = App.state.config.dynamic_settings || {});
  const assignments = (ds.style_assignments = ds.style_assignments || {});
  if (name) assignments[role] = name;
  else delete assignments[role];
  App.refreshUI();
};

App.deleteLayerStyle = async (role) => {
  const ds = App.state.config.dynamic_settings || {};
  const name = (ds.style_assignments || {})[role];
  if (!name) return;
  if (!confirm(`Delete layer style “${name}”?`)) return;
  try {
    const data = await api("/api/layer-styles/delete", { method: "POST", body: { name } });
    if (!data.ok) { toast(data.error || "Delete failed.", "err"); return; }
    App.state.config = data.config;
    toast(`Layer style “${name}” deleted.`);
    App.refreshUI();
    renderRoute();
  } catch (e) { toast(e.message, "err"); }
};

/* Optional "Verify in Photoshop": previews never need Photoshop; this renders
   the style in whichever Photoshop is open and shows it next to the tool's own
   render (same glyph pixels, so only the effects are compared). */
App.verifyLayerStyle = async (role) => {
  const ds = App.state.config.dynamic_settings || {};
  const name = (ds.style_assignments || {})[role];
  if (!name) { toast("Pick a saved layer style first.", "warn"); return; }
  toast(`Rendering “${name}” in Photoshop…`);
  let data;
  try {
    data = await api("/api/style-assets/verify", { method: "POST", body: { role, name } });
  } catch (e) { toast(e.message, "err"); return; }
  if (!data || !data.ok) { toast((data && data.error) || "Verify failed.", "err"); return; }
  const old = document.getElementById("fx-verify-modal");
  if (old) old.remove();
  const st = data.stats || {};
  const match = Math.max(0, 100 - (Number(st.bad_pct) || 0)).toFixed(1);
  const modal = document.createElement("div");
  modal.id = "fx-verify-modal";
  modal.style.cssText = "position:fixed;inset:0;background:rgba(0,0,0,.8);z-index:9999;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:20px;overflow:auto";
  const cell = (label, src) => `<figure style="margin:0;display:flex;flex-direction:column;gap:6px;align-items:center">
      <figcaption style="color:#e5e7eb;font-weight:600">${esc(label)}</figcaption>
      <img src="${src}" style="max-width:min(90vw,900px);image-rendering:auto;border:1px solid #444;border-radius:4px"/></figure>`;
  modal.innerHTML = `<div style="background:#1f2329;padding:18px 22px;border-radius:8px;max-width:95vw;display:flex;flex-direction:column;gap:14px">
      <h3 style="margin:0;color:#fff">Verify “${esc(name)}” in Photoshop</h3>
      <div style="color:#cbd5e1">${match}% of styled pixels match within tolerance · mean difference ${esc(st.mean_abs)} / 255</div>
      ${cell("Tool preview (no Photoshop)", data.tool_png)}
      ${cell("Photoshop", data.photoshop_png)}
      ${cell("Difference (brighter = further apart)", data.diff_png)}
      <div style="text-align:right"><button class="btn" id="fx-verify-close">Close</button></div>
    </div>`;
  modal.addEventListener("click", (ev) => { if (ev.target === modal) modal.remove(); });
  document.body.appendChild(modal);
  document.getElementById("fx-verify-close").onclick = () => modal.remove();
};

App.upgradeLayerStyles = async () => {
  if (!confirm("Upgrade saved styles for preview?\n\nThis re-reads every legacy (hex-only) saved style inside Photoshop so the LIVE preview can show the full layer effects. Requires an open Photoshop document.")) return;
  try {
    const data = await api("/api/layer-styles/upgrade", { method: "POST", body: {} });
    if (!data.ok) { toast(data.error || "Upgrade failed.", "err"); return; }
    App.state.config = data.config;
    toast(data.upgraded > 0 ? `Upgraded ${data.upgraded} saved style(s) for preview.` : (data.note || "No legacy styles to upgrade."));
    App.refreshUI();
    renderRoute();
  } catch (e) { toast(e.message, "err"); }
};

App.loadPsGroups = async () => {
  const psd = App.get("prev_psd_path") || App.get("output_dir");
  if (!psd) { toast("Set a PSD path first (prev PSD field on Render).", "err"); return []; }
  try {
    const data = await api("/api/ps/groups?psd_path=" + encodeURIComponent(psd));
    return data.groups || [];
  } catch (e) { toast(e.message, "err"); return []; }
};

App.exportPaytableJson = async (mode) => {
  const body = { mode };
  if (mode === "group") {
    const groups = await App.loadPsGroups();
    const pick = prompt("Pick a group path (from the open PSD):", groups[0] || "");
    if (!pick) return;
    body.group_path = pick;
  }
  try {
    const data = await api("/api/export/paytable-json", { method: "POST", body });
    if (!data.ok) { toast(data.error, "err"); return; }
    toast("JSON exported: " + (data.result || "done"));
  } catch (e) { toast(e.message, "err"); }
};

App.runBatchExport = async () => {
  const psd = App.get("prev_psd_path");
  const out = App.get("output_dir");
  if (!psd || !out) { toast("Set the PSD path and output folder (Render view).", "err"); return; }
  try {
    const data = await api("/api/export/batch", { method: "POST", body: {
      psd_path: psd, output_folder: out,
      image_format: App.get("batch_format") || "PNG",
      jpg_quality: App.get("batch_quality") || 90,
      transparent: App.get("batch_transparent") !== false,
      suffix: App.get("batch_suffix") || "MyExport",
      export_visible_groups: App.get("batch_groups") !== false,
      export_visible_layers: !!App.get("batch_layers"),
      bottom_to_top: !!App.get("batch_bottom_top"),
    }});
    App.startJobPoll(data.job_id, "Batch Export");
  } catch (e) { toast(e.message, "err"); }
};

App.runBackup = async () => {
  const psd = App.get("prev_psd_path");
  if (!psd) { toast("Set the PSD path first.", "err"); return; }
  try {
    const data = await api("/api/export/backup", { method: "POST", body: { psd_path: psd } });
    if (!data.ok) { toast(data.error, "err"); return; }
    toast("Backup created: " + data.path);
  } catch (e) { toast(e.message, "err"); }
};

App.loadTemplates = async () => {
  try {
    const data = await api("/api/templates");
    App.state.templates = data.templates || [];
    renderRoute();
  } catch (e) { toast(e.message, "err"); }
};

App.saveMappings = async () => {
  const mappings = {}, sizes = {};
  document.querySelectorAll("[data-map]").forEach((el) => {
    const t = el.dataset.map;
    if (el.value.trim()) mappings[t] = el.value.trim();
  });
  document.querySelectorAll("[data-size]").forEach((el) => {
    const t = el.dataset.size;
    const v = parseInt(el.value, 10);
    if (v && v > 0) sizes[t] = v;
  });
  try {
    await api("/api/mappings", { method: "POST", body: { icon_mappings: mappings, icon_size_overrides: sizes } });
    toast(`Saved ${Object.keys(mappings).length} mapping(s), ${Object.keys(sizes).length} size override(s).`);
    renderRoute();
  } catch (e) { toast(e.message, "err"); }
};

App.startJobPoll = (jobId, label = "Task") => {
  const overlay = document.getElementById("buildOverlay");
  overlay.hidden = false;
  document.getElementById("buildChip").hidden = true;
  document.getElementById("buildTitle").textContent = label + " — working…";
  document.getElementById("buildFill").classList.remove("done");
  document.getElementById("buildFill").style.width = "10%";
  document.getElementById("buildPct").textContent = "10%";
  document.getElementById("buildMode").textContent = label.toUpperCase();
  document.getElementById("buildLog").innerHTML = "";
  document.getElementById("buildClose").disabled = true;
  document.getElementById("buildCopyLog").disabled = false;
  document.getElementById("buildCancel").disabled = false;
  App.state.jobId = jobId;
  clearInterval(App._jobTimer);
  App._jobTimer = setInterval(() => App.pollJob(), 700);
};

App.startBuild = async (mode) => {
  if (!App.state.scan || !App.state.scan.excel) {
    toast("Scan an Excel workbook first.", "err");
    return;
  }
  await App.ensureGameName();
  // Preflight gate — surface blocking errors + warnings BEFORE the build runs
  // (not as mid-build popups). Cleared for one pass when the user picks
  // "Build anyway" on a warnings-only report.
  if (!App._preflightCleared) {
    const pf = await App.runPreflight();
    if (pf && ((pf.blocking || []).length || (pf.warnings || []).length)) {
      App.showPreflightDialog(pf, mode);
      return;
    }
  }
  App._preflightCleared = false;
  // update_mode is only for a build started from "Update PSD". A plain Build
  // must not inherit it from an earlier update — otherwise an unchanged Excel
  // hits the "nothing to update" fast path and no PSD is written.
  const isUpdate = !!App._updateRequested;
  App._updateRequested = false;
  if (!isUpdate && App.state.config.update_mode) {
    App.set("update_mode", false);
    App.pushConfig();
  }
  const pages = App.state.scan.excel.sheets || [];
  if (!pages.length) {
    if (!confirm("No pages detected — build all pages?")) return;
    mode += (mode ? " " : "") + "all";
  } else {
    const renderAll = confirm(`Render all ${pages.length} pages?`);
    if (renderAll) {
      // proceed with existing config
    } else {
      // show specific pages picker
      const selected = await App.selectPagesForBuild(pages);
      if (selected === null) return; // cancelled
      App.state.render_all_pages = false;
      App.state.selected_sheets = selected || [];
      App.pushConfig();
    }
  }
  const overlay = document.getElementById("buildOverlay");
  overlay.hidden = false;
  document.getElementById("buildChip").hidden = true;
  document.getElementById("buildTitle").textContent = "Building your project…";
  document.getElementById("buildFill").classList.remove("done");
  document.getElementById("buildFill").style.width = "0%";
  document.getElementById("buildPct").textContent = "0%";
  document.getElementById("buildMode").textContent = mode.toUpperCase();
  document.getElementById("buildLog").innerHTML = "";
  document.getElementById("buildClose").disabled = true;
  document.getElementById("buildCopyLog").disabled = false;
  document.getElementById("buildCancel").disabled = false;
  try {
    await App.flushConfig();
    const data = await api("/api/build", { method: "POST", body: { mode, config: App.state.config } });
    App.state.jobId = data.job_id;
    clearInterval(App._jobTimer);
    App._jobTimer = setInterval(() => App.pollJob(), 700);
  } catch (e) {
    toast(e.message, "err");
    overlay.hidden = true;
  }
};

App.selectPagesForBuild = async (pages) => {
  // show a modal with sheet thumbnails
  const existing = document.getElementById("pages-build-modal");
  if (existing) existing.remove();
  const modal = document.createElement("div");
  modal.id = "pages-build-modal";
  modal.style.position = "fixed";
  modal.style.top = "0";
  modal.style.left = "0";
  modal.style.width = "100%";
  modal.style.height = "100%";
  modal.style.background = "rgba(0,0,0,0.8)";
  modal.style.zIndex = "9999";
  modal.style.display = "flex";
  modal.style.flexDirection = "column";
  modal.style.alignItems = "center";
  modal.style.padding = "20px";
  const title = document.createElement("div");
  title.innerHTML = `<h3>Select pages to render</h3>`;
  title.style.marginBottom = "10px";
  modal.appendChild(title);
  const canvas = document.createElement("div");
  canvas.style.display = "grid";
  canvas.style.gridTemplateColumns = "repeat(auto-fit, minmax(100px, 1fr))";
  canvas.style.gap = "10px";
  canvas.style.width = "calc(100% - 40px)";
  canvas.style.maxWidth = "800px";
  canvas.style.height = "600px";
  canvas.style.overflow = "auto";
  const thumbnailSize = 120;
  const thumbRows = [];
  for (let i = 0; i < pages.length; i++) {
    const s = pages[i];
    const thumb = document.createElement("div");
    thumb.style.width = `${thumbnailSize}px`;
    thumb.style.height = `${thumbnailSize}px`;
    thumb.style.border = "2px solid #";
    thumb.style.borderRadius = "4px";
    thumb.style.position = "relative";
    thumb.style.cursor = "pointer";
    thumb.innerHTML = `<img class="pg-thumb-img" src="/api/pages_thumb/${encodeURIComponent(s.name)}?v=2" alt="${esc(s.name)}" style="width:100%;height:100%;object-fit:cover"/>`;
    thumb.dataset.sheet = s.name;
    thumb.style.background = "#";
    thumb.onclick = () => {
      thumb.style.border = thumb.dataset.selected ? "" : "2px solid #3b82f6";
      thumb.dataset.selected = !thumb.dataset.selected;
    };
    thumb.dataset.selected = "false";
    thumbRows.push(thumb);
  }
  canvas.appendChild(...thumbRows);
  modal.appendChild(canvas);
  const btnBar = document.createElement("div");
  btnBar.style.marginTop = "20px";
  btnBar.style.display = "flex";
  btnBar.style.gap = "10px";
  const btnAll = document.createElement("button");
  btnAll.innerHTML = "Select All";
  btnAll.onclick = () => {
    thumbRows.forEach(t => { t.dataset.selected = "true"; t.style.border = "2px solid #3b82f6"; });
  };
  const btnNone = document.createElement("button");
  btnNone.innerHTML = "Select None";
  btnNone.onclick = () => {
    thumbRows.forEach(t => { t.dataset.selected = "false"; t.style.border = ""; });
  };
  const btnOk = document.createElement("button");
  btnOk.innerHTML = "Render These Pages";
  btnOk.style.marginLeft = "auto";
  btnOk.onclick = () => {
    const selected = thumbRows.filter(t => t.dataset.selected === "true").map(t => t.dataset.sheet);
    document.getElementById("pages-build-modal").remove();
    modal.remove();
    return selected;
  };
  const btnCancel = document.createElement("button");
  btnCancel.innerHTML = "Cancel";
  btnCancel.onclick = () => {
    document.getElementById("pages-build-modal").remove();
    modal.remove();
    return null;
  };
  btnBar.appendChild(btnAll);
  btnBar.appendChild(btnNone);
  btnBar.appendChild(btnOk);
  btnBar.appendChild(btnCancel);
  modal.appendChild(btnBar);
  document.body.appendChild(modal);
};

App.startUpdate = async () => {
  const c = App.state.config;
  if (!c.excel_path) { toast("Choose a Current Excel file first (Project view).", "err"); return; }
  if (!c.prev_psd_path) { toast("Update mode needs the last PSD: open it with Open a PSD, or use Update PSD on its market in Recent games.", "err"); return; }
  App.set("update_mode", true);
  // update_save_mode decides whether we overwrite the Old PSD in place or
  // write a new copy; overwrite_existing only makes sense for the former.
  const saveMode = String(c.update_save_mode || "overwrite");
  App.set("overwrite_existing", saveMode === "overwrite");
  App.pushConfig();
  App._updateRequested = true;
  App.startBuild("psd");
};

App.pollJob = async () => {
  if (!App.state.jobId) return;
  try {
    const data = await api("/api/jobs/" + App.state.jobId);
    const job = data.job;
    const log = document.getElementById("buildLog");
    const seen = log.dataset.seen ? parseInt(log.dataset.seen) : 0;
    for (let i = seen; i < job.log.length; i++) {
      const line = document.createElement("div");
      const text = job.log[i];
      line.className = text.startsWith("ERROR") ? "err" : "";
      line.textContent = text;
      log.appendChild(line);
    }
    log.dataset.seen = String(job.log.length);
    log.scrollTop = log.scrollHeight;

    const fill = document.getElementById("buildFill");
    fill.style.width = job.progress + "%";
    document.getElementById("buildPct").textContent = job.progress + "%";
    const chip = document.getElementById("buildChip");
    if (!chip.hidden) {
      document.getElementById("buildChipText").textContent = "Build " + job.progress + "%";
    }

    if (job.status === "done" || job.status === "error" || job.status === "cancelled") {
      clearInterval(App._jobTimer);
      App.state.jobId = null;
      document.getElementById("buildTitle").textContent =
        job.status === "done" ? "Build Complete" : job.status === "error" ? "Build Failed" : "Build Cancelled";
      document.getElementById("buildTitle").style.color = job.status === "done" ? "var(--success)" : "var(--danger)";
      if (job.status === "done") fill.classList.add("done");
      document.getElementById("buildClose").disabled = false;
      if (job.status === "done") {
        chip.classList.add("done");
        chip.title = "Build complete — click to view";
      }
      const skipped = job.status === "done" && job.result && job.result.skipped === "unchanged";
      toast(skipped ? "No changes in the Excel since the last update — the PSD is already up to date."
        : job.status === "done" ? "Build finished — opening the output folder." : job.error || "Build did not complete.",
        job.status === "done" ? "ok" : "err");
      if (job.status === "done") {
        // After an update (or any PSD build) the newly saved PSD becomes the
        // reference for the next run; keep the Update PSD dialog in sync.
        const result = job.result || {};
        const savedPsd = result && result.psd_path ? String(result.psd_path).trim() : "";
        App.offerTextFinish(result.text_finished === false ? savedPsd : "");
        if (savedPsd && /\.(psd|psb)$/i.test(savedPsd)) {
          App.state.config.prev_psd_path = savedPsd;
          App.pushConfig();
          if (!document.getElementById("updateOverlay").hidden) App.renderUpdateDialog();
        }
        (job.output_folders || []).forEach((folder) => {
          if (folder) App.openFolder(folder);
        });
      }
    }
  } catch (e) { /* job may expire */ }
};

/* Built without Photoshop open: its text layers show Photoshop's "requires a
   layout change" warning until Photoshop adopts them. One click does that. */
App.offerTextFinish = (psdPath) => {
  let btn = document.getElementById("buildFinishText");
  if (!psdPath) { if (btn) btn.remove(); return; }
  const close = document.getElementById("buildClose");
  if (!close) return;
  if (!btn) {
    btn = document.createElement("button");
    btn.id = "buildFinishText";
    btn.className = "btn secondary";
    btn.title = "Photoshop wasn't open during the build, so its text layers show a 'requires a layout change' warning. This opens the PSD in Photoshop, updates the text layers (nothing moves) and saves it.";
    close.parentNode.insertBefore(btn, close);
  }
  btn.disabled = false;
  btn.textContent = "Fix text layers in Photoshop";
  btn.onclick = async () => {
    btn.disabled = true;
    btn.textContent = "Photoshop is updating text layers…";
    try {
      const d = await api("/api/psd/finish_text", { method: "POST", body: { path: psdPath } });
      toast(d.message || "Text layers updated.", d.ok ? "ok" : "err");
      if (d.ok) btn.remove(); else { btn.disabled = false; btn.textContent = "Fix text layers in Photoshop"; }
    } catch (e) {
      toast(e.message, "err");
      btn.disabled = false;
      btn.textContent = "Fix text layers in Photoshop";
    }
  };
};

App.minimizeBuild = () => {
  const overlay = document.getElementById("buildOverlay");
  if (overlay.hidden) return;
  overlay.hidden = true;
  const chip = document.getElementById("buildChip");
  if (chip.hidden) chip.hidden = false;
  const pct = document.getElementById("buildPct").textContent || "0%";
  document.getElementById("buildChipText").textContent = "Build " + pct;
};

App.restoreBuild = () => {
  document.getElementById("buildChip").hidden = true;
  document.getElementById("buildOverlay").hidden = false;
};

App.openFolder = async (folder) => {
  try {
    await api("/api/open-dir", { method: "POST", body: { path: folder } });
  } catch (e) { /* folder may be gone by the time we open it */ }
};

App.copyBuildLog = async () => {
  const log = document.getElementById("buildLog");
  const text = Array.from(log.children).map((el) => el.textContent).join("\n");
  if (!text) return;
  try {
    await navigator.clipboard.writeText(text);
    toast("Build log copied to clipboard.", "ok");
  } catch (e) {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    try {
      document.execCommand("copy");
      toast("Build log copied to clipboard.", "ok");
    } catch (e2) {
      toast("Could not copy the log — select it manually.", "err");
    } finally {
      document.body.removeChild(ta);
    }
  }
};

App.closeBuild = () => {
  document.getElementById("buildChip").hidden = true;
  document.getElementById("buildOverlay").hidden = true;
};

/* ------------------------------ AI panel ------------------------------ */

const AI_CHIPS = [
  "Make all headings larger",
  "Make headings bigger by 20px",
  "Reduce body text by 10%",
  "Create a 4K version",
  "Center all icons",
  "Fix text overflow",
  "Increase line spacing",
  "Generate a cleaner table layout",
  "Apply the same paytable layout to all matching pages",
  "How does this tool work?",
  "What does each setting do?",
];

App.toggleAI = (force) => {
  const panel = document.getElementById("aiPanel");
  if (force !== undefined) panel.hidden = !force;
  else panel.hidden = !panel.hidden;
  if (!panel.hidden && !document.getElementById("aiChat").children.length) {
    App.aiBot("Hi! I'm MIRA.AI — your local help-screen assistant. Change anything in plain words (\"switch the icon folder to D:\\icons\", \"make the body Georgia 28px\"), or ask me how the tool works — I know every setting.");
  }
};

App.aiBot = (msg) => {
  const chat = document.getElementById("aiChat");
  const el = document.createElement("div");
  el.className = "ai-msg bot";
  el.innerHTML = esc(msg).replace(/\n/g, "<br>");
  chat.appendChild(el);
  chat.scrollTop = chat.scrollHeight;
};

App.aiUser = (msg) => {
  const chat = document.getElementById("aiChat");
  const el = document.createElement("div");
  el.className = "ai-msg user";
  el.textContent = msg;
  chat.appendChild(el);
  chat.scrollTop = chat.scrollHeight;
};

App.aiSend = async (text) => {
  const cmd = (text || document.getElementById("aiInput").value).trim();
  if (!cmd) return;
  document.getElementById("aiInput").value = "";
  App.aiUser(cmd);
  try {
    const sheets = (App.state.scan?.excel?.sheets || []).map((s) => String(s.name || "").trim()).filter(Boolean);
    let data = null;
    let fallback = false;
    const status = await api("/api/mira/status").catch(() => ({ ok: false }));
    if (status.ok) {
      try {
        data = await api("/api/mira/chat", { method: "POST", body: { command: cmd, sheets } });
      } catch (e) {
        fallback = true;
      }
    } else {
      fallback = true;
    }
    if (fallback) {
      data = await api("/api/ai", { method: "POST", body: { command: cmd } });
      data.message = "[built-in assistant] " + data.message;
    }
    if (data.ok === false) {
      App.aiBot(data.message || data.error || "MIRA could not process that.");
      return;
    }
    if (data.pending) {
      App.aiBot(data.message || "MIRA found a project layout — see above.");
      const chat = document.getElementById("aiChat");
      const row = document.createElement("div");
      row.style.cssText = "display:flex;gap:8px;padding:0 16px 6px;flex-wrap:wrap";
      const applyBtn = document.createElement("button");
      applyBtn.className = "ai-chip";
      if (data.review) {
        applyBtn.textContent = "✓ Apply fixes";
        applyBtn.onclick = () => App.aiSend("yes, apply");
      } else if (data.batch) {
        applyBtn.textContent = "✓ Start batch build";
        applyBtn.onclick = () => App.aiSend("yes, start the batch build");
      } else {
        applyBtn.textContent = "✓ Apply project";
        applyBtn.onclick = () => App.aiSend("yes, apply");
      }
      row.appendChild(applyBtn);
      if (!data.review && !data.batch) {
        const buildBtn = document.createElement("button");
        buildBtn.className = "ai-chip";
        buildBtn.textContent = "✓ Apply and build";
        buildBtn.onclick = () => App.aiSend("yes, apply and build");
        row.appendChild(buildBtn);
      }
      chat.appendChild(row);
      chat.scrollTop = chat.scrollHeight;
      return;
    }
    App.state.config = data.config;
    App.pushConfig();
    if (data.reload) {
      App.renderMiraSheets();
      renderRoute();
    }
    const changes = data.changes || {};
    let msg = data.message;
    if (Object.keys(changes).length) {
      msg += "\nApplied: " + Object.keys(changes).map((k) => k.replace(/_/g, " ")).join(", ") + ".";
  App.updatePreview();
      App.renderMiraSheets();
      renderRoute();
    }
    if (data.action === "scan") {
      toast("MIRA scanned the workbook.", "ok");
      App.renderMiraSheets();
      renderRoute();
    }
    if (data.action === "build") {
      if (data.job_id) {
        msg += "\nBuild started — see the progress window.";
        App.startJobPoll(data.job_id, "MIRA Build");
      } else {
        msg += "\nI could not start the build (see note below).";
      }
    }
    App.aiBot(msg);
    if (data.mira_hint) App.miraRefreshStatus();
  } catch (e) {
    App.aiBot("Something went wrong: " + e.message);
  }
};

/* ---------------------- MIRA one-click AI setup ---------------------- */

App.miraRefreshStatus = async () => {
  let d = null;
  try { d = await api("/api/mira/status"); } catch (e) { d = null; }
  let setup = null;
  try { setup = await api("/api/mira/setup"); } catch (e) { setup = null; }
  const defaultModel = (setup && setup.model) || "qwen2.5:7b";
  const st = document.getElementById("miraStatus");
  const block = document.getElementById("aiSetup");
  const btn = document.getElementById("aiSetupBtn");
  const sText = document.getElementById("aiSetupStatus");
  if (!st) return;
  if (d && d.ok) {
    st.textContent = `MIRA on ${d.model}`;
    st.classList.add("on");
    st.classList.remove("off");
    if (block) {
      if (d.model_missing) {
        block.hidden = false;
        if (sText) sText.textContent = `“${d.model}” is running, but the default MIRA model (${defaultModel}) isn't downloaded yet — optional.`;
        if (btn) { btn.hidden = false; btn.disabled = false; btn.textContent = "Download AI model"; }
      } else {
        block.hidden = true;
      }
    }
    return;
  }
  st.textContent = "MIRA offline — using built-in assistant";
  st.classList.add("off");
  st.classList.remove("on");
  if (!block || !btn) return;
  if (d && d.can_setup) {
    block.hidden = false;
    if (sText) sText.textContent = d && d.ollama
      ? "Ollama is running but no MIRA model is downloaded yet (one-time download, about 4.7 GB)."
      : "Ollama isn't installed on this PC — one click installs it and downloads the MIRA model.";
    btn.hidden = false;
    btn.disabled = false;
    btn.textContent = d && d.ollama ? "Download MIRA model" : "Install & download AI model";
  } else {
    block.hidden = true;
  }
};

App.miraSetup = async () => {
  const btn = document.getElementById("aiSetupBtn");
  if (btn) btn.disabled = true;
  try {
    await api("/api/mira/setup", { method: "POST", body: {} });
  } catch (e) { /* keep polling — the worker may still be starting */ }
  App.miraSetupPoll(true);
};

App.miraSetupPoll = (force) => {
  if (App._miraPoll) return;
  App._miraPoll = true;
  const tick = async () => {
    let d = null;
    try { d = await api("/api/mira/setup"); } catch (e) { d = null; }
    const running = d && (d.state === "running" || d.state === "queued");
    if (running) {
      App.miraSetupUI(d);
      setTimeout(tick, 1500);
    } else {
      App._miraPoll = false;
      const block = document.getElementById("aiSetup");
      if (block) block.hidden = true;
      if (d && d.state === "done") {
        toast("AI setup complete — MIRA is ready!", "ok");
        const aiBtn = document.getElementById("aiSetupBtn");
        if (aiBtn) aiBtn.disabled = false;
        App.miraRefreshStatus();
      } else if (d && d.state === "error") {
        App.miraRefreshStatus();
        const sText = document.getElementById("aiSetupStatus");
        if (sText) sText.textContent = String(d.error || d.message || "Setup failed.").slice(0, 300);
        if (block) block.hidden = false;
        const st = document.getElementById("miraStatus");
        if (st) { st.textContent = "AI setup failed"; st.classList.add("off"); st.classList.remove("on"); }
        const aiBtn = document.getElementById("aiSetupBtn");
        if (aiBtn) { aiBtn.disabled = false; aiBtn.textContent = "Retry setup"; }
      }
    }
  };
  tick();
};

App.miraSetupUI = (d) => {
  const block = document.getElementById("aiSetup");
  if (!block) return;
  block.hidden = false;
  const st = document.getElementById("aiSetupStatus");
  const fill = document.getElementById("aiSetupFill");
  const btn = document.getElementById("aiSetupBtn");
  if (st) st.textContent = String(d.message || d.phase || "Working…");
  if (fill) fill.style.width = Math.max(0, Math.min(100, d.pct || 0)) + "%";
  if (btn) { btn.hidden = false; btn.disabled = true; btn.textContent = "Working…"; }
};

App.renderMiraSheets = () => {
  const box = document.getElementById("miraSheets");
  if (!box) return;
  const sheets = (App.state.scan?.excel?.sheets || []).map((s) => String(s.name || "").trim()).filter(Boolean);
  if (!sheets.length) {
    box.innerHTML = `<span class="hint">Load an Excel in Project to pick pages.</span>`;
    return;
  }
  const sel = (App.state.config.selected_sheets || []).map(String);
  const all = !sel.length || sel.length === sheets.length;
  box.innerHTML = sheets.map((n) => {
    const on = all || sel.includes(n);
    return `<label class="mira-sheet${on ? " on" : ""}"><input type="checkbox" value="${esc(n)}" ${on ? "checked" : ""} />${esc(n)}</label>`;
  }).join("");
  box.querySelectorAll("input").forEach((chk) => {
    chk.addEventListener("change", () => {
      const chosen = [...box.querySelectorAll("input:checked")].map((i) => i.value);
      const allOn = chosen.length === sheets.length;
      App.set("selected_sheets", allOn ? [] : chosen);
      box.querySelectorAll("label").forEach((l) => l.classList.toggle("on", allOn || chosen.includes(l.querySelector("input").value)));
    });
  });
};

/* ------------------------------ init ------------------------------ */

async function init() {
  try {
    const data = await api("/api/bootstrap");
    App.state.config = data.config;
    App.state.presets = data.presets || [];
    App.state.canvasPresets = data.canvas_presets || [];
    App.state.config.selected_sheets = App.state.config.selected_sheets || [];
    if (data.session_note) toast(data.session_note, "err");   // session file was unreadable and restored
  } catch (e) {
    document.getElementById("workspace").innerHTML = `<div class="empty"><div class="empty-icon">⚠</div><div class="empty-title">Server unreachable</div><div class="empty-sub">${esc(e.message)}</div></div>`;
    return;
  }

  const updateFontSelects = () => {
    const fonts = App.state.fonts || [];
    document.querySelectorAll("select[data-font]").forEach((sel) => {
      const key = sel.dataset.key;
      let val = App.get(key);
      const info = val && App.fontFace(val);
      if (info) val = info.family;                       // "MyriadPro-Bold" shows as its family
      const list = fonts.slice();
      if (val && !list.some((f) => String(f).toLowerCase() === String(val).toLowerCase())) list.unshift(String(val));
      const opts = list.map((f) => `<option value="${esc(f)}" ${String(f).toLowerCase() === String(val).toLowerCase() ? "selected" : ""}>${esc(f)}</option>`).join("");
      sel.innerHTML = opts;
    });
  };
  api("/api/fonts").then((d) => {
    App.state.fonts = (d && d.fonts) || [];
    App.state.fontFaces = (d && d.faces) || {};
    App.state.fontAliases = (d && d.aliases) || {};
    updateFontSelects();
    document.querySelectorAll("select[data-style-of]").forEach((sel) => App.fillFontStyles(sel));
    if (document.getElementById("ptGlobalBody")) App.ptmRenderGlobalSettings();
    const hints = document.querySelectorAll("select[data-font] + .hint");
    hints.forEach((h) => { h.textContent = App.state.fonts.length ? `${App.state.fonts.length} fonts installed. Click to pick one, or leave the current value.` : "No font list loaded — type the PostScript name (e.g. ArialMT)."; });
  }).catch(() => { App.state.fonts = []; updateFontSelects(); });

  document.getElementById("aiSuggestions").innerHTML = AI_CHIPS.map((c) => `<button class="ai-chip" onclick="App.aiSend('${esc(c.replace(/'/g, "\\'"))}')">${esc(c)}</button>`).join("");

  document.getElementById("aiForm").addEventListener("submit", (e) => { e.preventDefault(); App.aiSend(); });
  document.getElementById("aiButton").addEventListener("click", () => App.toggleAI());
  document.getElementById("aiClose").addEventListener("click", () => App.toggleAI(false));
  const aiPanelEl = document.getElementById("aiPanel");
  bindForms(aiPanelEl);
  App.renderMiraSheets();
  setTimeout(() => App.miraRefreshStatus(), 5000);   // AI status (slow: waits on Ollama) after the first frame
  document.getElementById("buildButton").addEventListener("click", () => App.startBuild(App.state.config.build_output || "both"));
  document.getElementById("clearSessionButton").addEventListener("click", () => App.clearSession());
  document.getElementById("buildClose").addEventListener("click", App.closeBuild);
  document.getElementById("buildMin").addEventListener("click", App.minimizeBuild);
  document.getElementById("buildChip").addEventListener("click", App.restoreBuild);
  document.getElementById("buildCopyLog").addEventListener("click", App.copyBuildLog);
  document.getElementById("buildCancel").addEventListener("click", async () => {
    if (App.state.jobId) {
      document.getElementById("buildCancel").disabled = true;
      await api(`/api/jobs/${App.state.jobId}/cancel`, { method: "POST" });
    }
  });
  document.getElementById("buildOverlay").addEventListener("click", (e) => { if (e.target.id === "buildOverlay") App.minimizeBuild(); });
  document.getElementById("canvasApply").addEventListener("click", App.applyCanvas);
  document.getElementById("canvasCancel").addEventListener("click", App.closeCanvasDialog);
  document.getElementById("canvasResolution").addEventListener("change", (e) => {
    App._canvas.res = parseInt(e.target.value, 10) || 72;
    App.renderCanvasDialog();
  });
  document.querySelectorAll("#canvasOrient .seg-btn").forEach((b) => {
    b.addEventListener("click", () => App.setOrient(b.dataset.orient));
  });
  document.getElementById("canvasOverlay").addEventListener("click", (e) => { if (e.target.id === "canvasOverlay") App.closeCanvasDialog(); });
  document.getElementById("pagesClose").addEventListener("click", App.closePagesDialog);
  document.getElementById("pagesOverlay").addEventListener("click", (e) => { if (e.target.id === "pagesOverlay") App.closePagesDialog(); });
  document.getElementById("missingClose").addEventListener("click", App.closeMissingDialog);
  document.getElementById("missingBrowse").addEventListener("click", () => App.browse("icon_folder", "dir"));
  document.getElementById("missingOverlay").addEventListener("click", (e) => { if (e.target.id === "missingOverlay") App.closeMissingDialog(); });
  document.getElementById("mapperOverlay").addEventListener("click", (e) => { if (e.target.id === "mapperOverlay") App.closeMapper(); });
  document.getElementById("bgCancel").addEventListener("click", App.closeBackgroundDialog);
  document.getElementById("bgApply").addEventListener("click", App.applyBackground);
  document.getElementById("bgOverlay").addEventListener("click", (e) => { if (e.target.id === "bgOverlay") App.closeBackgroundDialog(); });
  document.getElementById("outputCancel").addEventListener("click", App.closeOutputDialog);
  document.getElementById("outputApply").addEventListener("click", App.applyOutput);
  document.getElementById("outputOverlay").addEventListener("click", (e) => { if (e.target.id === "outputOverlay") App.closeOutputDialog(); });
  document.getElementById("updateCancel").addEventListener("click", App.closeUpdateDialog);
  document.getElementById("updateRun").addEventListener("click", App.runUpdate);
  document.getElementById("updateOverlay").addEventListener("click", (e) => { if (e.target.id === "updateOverlay") App.closeUpdateDialog(); });
  document.getElementById("pjCancel").addEventListener("click", App.closeProjectDialog);
  document.getElementById("pjContinue").addEventListener("click", App.pjContinue);
  document.getElementById("projectOverlay").addEventListener("click", (e) => { if (e.target.id === "projectOverlay") App.closeProjectDialog(); });
  document.getElementById("sidebarToggle").addEventListener("click", () => {
    document.getElementById("app").classList.toggle("sidebar-min");
    window.dispatchEvent(new Event("resize"));               // the Canvas fits the new width
  });
  document.getElementById("propertiesToggle").addEventListener("click", () => document.getElementById("app").classList.toggle("no-props"));
  document.querySelectorAll(".mode-btn").forEach((b) => {
    b.addEventListener("click", () => {
      document.querySelectorAll(".mode-btn").forEach((x) => x.classList.remove("active"));
      b.classList.add("active");
    });
  });
  document.querySelectorAll(".nav-item[data-route]").forEach((b) => {
    b.addEventListener("click", () => navigate(b.dataset.route));
  });

  document.addEventListener("change", (e) => {
    const wEl = e.target.closest("[data-ptweight]");
    if (wEl) { commitPtWeight(wEl.dataset.ptweight, wEl.value); return; }
    const sEl = e.target.closest("[data-ptstyle]");
    if (sEl) { commitPtLayerStyle(sEl.dataset.ptstyle, sEl.value); }
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      App.closeBuild();
      App.closeCanvasDialog();
      App.closePagesDialog();
      App.closeMissingDialog();
      App.closeMapper();
      App.tmClose();
App.closeBackgroundDialog();
      App.closeOutputDialog();
      App.closeUpdateDialog();
      App.closeProjectDialog();
      App.toggleAI(false);
      if (App.route === "paytable") App.ptmCancelMarquee();
    }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "b") {
      e.preventDefault();
      App.startBuild(App.state.config.build_output || "both");
    }
    if ((e.ctrlKey || e.metaKey) && App.route === "paytable") {
      const tag = (e.target.tagName || "").toLowerCase();
      const typing = tag === "input" || tag === "select" || tag === "textarea";
      const k = e.key.toLowerCase();
      if (!typing && k === "z") {
        e.preventDefault();
        if (e.shiftKey) App.ptmRedo(); else App.ptmUndo();
      } else if (!typing && k === "y") {
        e.preventDefault();
        App.ptmRedo();
      } else if (k === "g" && !typing) {
        e.preventDefault();
        App.ptmGroupSelection();
      } else if (k === "u" && !typing) {
        e.preventDefault();
        App.ptmUngroupSelection();
      } else if (k === "d" && !typing) {
        e.preventDefault();
        App.ptmDuplicate();
      }
    }
    if (App.route === "paytable") {
      const tag = (e.target.tagName || "").toLowerCase();
      const typing = tag === "input" || tag === "select" || tag === "textarea";
      if (!typing && String(e.key || "").slice(0, 5) === "Arrow") {
        const step = e.shiftKey ? 10 : 1;
        const dx = e.key === "ArrowLeft" ? -step : e.key === "ArrowRight" ? step : 0;
        const dy = e.key === "ArrowUp" ? -step : e.key === "ArrowDown" ? step : 0;
        if (dx || dy) { e.preventDefault(); App.ptmNudge(dx, dy); }
      }
    }
    if (App.route === "paytable" && (e.key === "Delete" || e.key === "Backspace")) {
      const tag = (e.target.tagName || "").toLowerCase();
      if (tag === "input" || tag === "select" || tag === "textarea") return;
      const pm = App.paytableMapper;
      if (pm && pm.selectedMaster) {
        e.preventDefault();
        App.ptmUnwrapMaster(pm.selectedMaster);
        return;
      }
      const targets = (pm && pm.multiSelected && pm.multiSelected.length >= 2)
        ? pm.multiSelected.slice()
        : (pm && pm.selected ? [pm.selected] : []);
      if (targets.length && pm.template.slots[targets[0]]) {
        e.preventDefault();
        App.ptmDeleteSlots(targets);
      }
    }
    if (e.key === "Enter" && !document.getElementById("projectOverlay").hidden) {
      const tag = (e.target.tagName || "").toLowerCase();
      if (tag === "input" || tag === "select" || tag === "textarea") return;
      const cont = document.getElementById("pjContinue");
      if (!cont.disabled) App.pjContinue();
    }
  });

  renderRoute();

  App.state.templates = [];
  App.loadTemplates();

  if (App.state.config.excel_path) App.scan({ background: true });
  if (App.state.config.icon_folder) App.loadIcons();

  fetch("/api/ps/status").then((r) => r.json()).then((d) => {
    const dot = document.getElementById("psDot");
    dot.classList.add(d.available ? "on" : "off");
    document.getElementById("psStatusText").textContent = d.available ? `PS ${d.version}` : "Photoshop offline";
  }).catch(() => {
    document.getElementById("psStatusText").textContent = "PS unknown";
  });
}

document.addEventListener("DOMContentLoaded", init);

// ── "Artist PSD (use its layout)": learn a paytable design from an artist file ──
App.ptmArtistDialog = async (psdPath) => {
  const pm = App.paytableMapper || {};
  if (!App.state.config.excel_path) { toast("Set the Excel file in Project first.", "err"); return; }
  const sheets = (App.state.scan?.excel?.sheets || []).map((s) => s.name);
  const defSheet = pm.sheetName || sheets.find((n) => /paytable/i.test(n)) || sheets[0] || "";
  const base = psdPath.split(/[\\/]/).pop().replace(/\.(psd|psb)$/i, "");
  const safeName = (g) => `${base}_${g}`.replace(/[^A-Za-z0-9_\-]+/g, "_");
  const overlay = document.createElement("div");
  overlay.className = "overlay";
  overlay.innerHTML = `<div class="table-mapper-dialog" style="width:min(760px,94vw);max-height:90vh;height:auto;overflow:auto">
      <div class="panel-header" style="margin-bottom:10px"><span class="panel-title">Paytable layout from an artist PSD</span></div>
      <div class="hint" style="margin-bottom:12px">${esc(psdPath)}<br>The layout, fonts, colours, effects and card art come from this file; every number and sentence still comes from Excel. Extra symbols get a cloned card, missing ones are dropped.</div>
      <div style="display:grid;grid-template-columns:140px 1fr;gap:8px 12px;align-items:center">
        <label class="tm-label">Paytable group</label><select class="pt-select" id="adGroup"><option>Reading PSD…</option></select>
        <label class="tm-label">Excel sheet</label><select class="pt-select" id="adSheet">${sheets.map((n) => `<option ${n === defSheet ? "selected" : ""}>${esc(n)}</option>`).join("")}</select>
        <label class="tm-label">Template name</label><input type="text" class="tm-path" id="adName" value="${esc(safeName("paytable"))}">
      </div>
      <div id="adStatus" class="hint" style="margin-top:12px">Reading the PSD…</div>
      <div id="adResult" style="margin-top:8px"></div>
      <div class="tm-footer">
        <button class="btn ghost" id="adClose">Cancel</button>
        <button class="btn secondary" id="adRelearn" style="display:none">Re-learn with my fixes</button>
        <button class="btn btn-primary tm-done-btn" id="adLearn" disabled>Learn layout</button>
        <button class="btn btn-primary tm-done-btn" id="adUse" style="display:none">Use this template</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);
  const $ = (id) => overlay.querySelector("#" + id);
  let result = null;
  let alive = true;
  const close = () => { alive = false; overlay.remove(); };
  $("adClose").addEventListener("click", close);

  try {
    const g = await api("/api/artist_design/groups", { method: "POST", timeout: 180000, body: { psd_path: psdPath } });
    if (!g.ok) throw new Error(g.error || "Could not read the PSD.");
    if (!g.groups.length) throw new Error("The PSD has no layer groups (pages).");
    $("adGroup").innerHTML = g.groups.map((x) =>
      `<option value="${esc(x.name)}" ${x.name === g.guess ? "selected" : ""}>${esc(x.name)} (${x.layers} layers)</option>`).join("");
    if (g.guess) $("adName").value = safeName(g.guess);
    $("adGroup").addEventListener("change", () => { $("adName").value = safeName($("adGroup").value); });
    $("adLearn").disabled = false;
    $("adStatus").textContent = `${g.groups.length} page groups, ${g.width}×${g.height}px. Pick the paytable page and click “Learn layout”.`;
  } catch (e) {
    if (alive) $("adStatus").textContent = e.message;
    return;
  }

  const overrides = () => {
    const out = {};
    overlay.querySelectorAll("select[data-layer-id]").forEach((sel) => {
      if (sel.value !== sel.dataset.orig) out[sel.dataset.layerId] = sel.value;
    });
    return out;
  };

  const learn = async (symbolOverrides) => {
    $("adLearn").disabled = true;
    $("adRelearn").disabled = true;
    $("adUse").disabled = true;
    $("adStatus").textContent = "Learning…";
    try {
      const d = await api("/api/artist_design/learn", {
        method: "POST",
        body: { psd_path: psdPath, group: $("adGroup").value, sheet_name: $("adSheet").value,
                excel_path: App.state.config.excel_path, name: $("adName").value.trim(),
                symbol_overrides: symbolOverrides || {} },
      });
      if (!d.ok) throw new Error(d.error || "Learning failed.");
      let job = null;
      while (alive) {
        await new Promise((r) => setTimeout(r, 500));
        job = (await api("/api/jobs/" + d.job_id)).job;
        if (!job) throw new Error("The learning job was lost.");
        $("adStatus").textContent = `${job.progress}% — ${job.log[job.log.length - 1] || ""}`;
        if (job.status !== "running") break;
      }
      if (!alive) return;
      if (job.status !== "done" || !job.result?.ok) throw new Error(job.error || job.result?.error || "Learning failed.");
      result = job.result;
      App.ptmArtistRenderResult(overlay, result);
      $("adStatus").textContent = `Saved template “${result.name}”: ${result.cards} cards, ${result.slots} slots.`;
      $("adUse").style.display = "";
      $("adRelearn").style.display = "";
      $("adLearn").textContent = "Learn again";
    } catch (e) {
      if (!alive) return;
      $("adStatus").textContent = e.message;
      toast(e.message, "err");
    } finally {
      if (alive) {
        $("adLearn").disabled = false;
        $("adRelearn").disabled = false;
        $("adUse").disabled = false;
      }
    }
  };
  $("adLearn").addEventListener("click", () => learn({}));
  $("adRelearn").addEventListener("click", () => learn(overrides()));
  $("adUse").addEventListener("click", async () => {
    if (!result) return;
    close();
    await App.ptmRefreshTemplateList();
    if (result.path) App.ptmTemplateSelected(result.path);
    toast(`Template “${result.name}” learned from the artist PSD — adjust anything in the mapper.`, "ok");
  });
};

App.ptmArtistRenderResult = (overlay, result) => {
  const rep = result.report || {};
  const choices = rep.symbol_choices || [];
  const pick = (layerId, current) => `<select class="pt-select" style="width:150px" data-layer-id="${layerId}" data-orig="${esc(current)}">
      <option value="" ${current ? "" : "selected"}>— not a symbol —</option>
      ${choices.map((c) => `<option value="${esc(c)}" ${c === current ? "selected" : ""}>${esc(c)}</option>`).join("")}</select>`;
  const thumb = (src) => (src ? `<img src="${src}" alt="" style="width:40px;height:40px;object-fit:contain;background:#0006;border-radius:4px">` : "");
  const row = (cells) => `<div style="display:flex;align-items:center;gap:10px;padding:3px 0">${cells}</div>`;
  const symbols = (rep.symbols || []).map((s) => row(`${thumb(s.thumb)}<span style="flex:1" class="hint">${esc(s.layer)}${s.card ? " · card" : ""}</span>${pick(s.layer_id, s.symbol)}`)).join("");
  const others = (rep.other_images || []).map((s) => row(`${thumb(s.thumb)}<span style="flex:1" class="hint">${esc(s.layer)}</span>${pick(s.layer_id, "")}`)).join("");
  const data = (rep.data || []).map((d) => row(`<span style="flex:1" class="hint">${esc(String(d.layer).trim().slice(0, 60))}</span><code>${esc(d.slot)}</code><span>← ${esc(d.source || "")}</span>`)).join("");
  const literal = (rep.literal_text || []).map((d) => row(`<span style="flex:1" class="hint">${esc(String(d.text || "").slice(0, 60))}</span><span>${d.slot === "(art)" ? "kept as artwork" : "design text"}</span>`)).join("");
  const warn = (rep.warnings || []).map((w) => `<div class="hint" style="color:var(--warn,#e0a030)">⚠ ${esc(w)}</div>`).join("");
  const section = (title, body, open) => (body ? `<details ${open ? "open" : ""} style="margin-top:8px"><summary class="tm-label" style="cursor:pointer">${title}</summary>${body}</details>` : "");
  overlay.querySelector("#adResult").innerHTML = warn
    + section(`Symbols found (${(rep.symbols || []).length}) — fix a wrong match, then “Re-learn with my fixes”`, symbols, true)
    + section(`Other images (${(rep.other_images || []).length}) — kept as design art unless you mark one as a symbol`, others, false)
    + section(`Text linked to Excel (${(rep.data || []).length})`, data, false)
    + section(`Design text (${(rep.literal_text || []).length})`, literal, false)
    + `<div class="hint" style="margin-top:8px">${rep.decor || 0} design layers kept as art · ${rep.inline_icons || 0} inline icons drawn from Excel tokens</div>`;
};

// ── Right-click a paytable card → "Replace symbol…" ─────────────────────────
// The card's image normally comes from its Excel token (<pic1>) found in the
// icons folder. The artist can override it here: for this card only (the
// mapping keeps the file in asset_path) or everywhere that token appears (the
// project's icon_mappings, used by every page and the PSD build).

App.ptmCardSymbolSlot = (slotName) => {
  // pic4.pay / pic4.value → pic4; the symbol slot itself stays as is
  const pm = App.paytableMapper;
  if (!pm || !slotName) return "";
  const base = String(slotName).replace(/\.(pay|value)s?$/i, "");
  const generated = App.ptmBands().some((b) => b.managed && (b.cards || []).some((c) => c.slot === base));
  if (generated) return base;
  const m = pm.mappings[base];
  if (pm.template?.slots?.[base] && (!m || String(m.mode || "icon") === "icon") && App.ptmIsSymbolSlot(base)) return base;
  return "";
};

App.ptmSymbolSimilarity = (a, b) => {
  const norm = (s) => String(s || "").toLowerCase().replace(/\.[a-z0-9]+$/, "").replace(/[^a-z0-9]/g, "");
  const x = norm(a), y = norm(b);
  if (!x || !y) return 0;
  if (x === y) return 1;
  // "pic4" ↔ "pic4_symbol" counts; a short word inside another ("ace" in "spaceship") does not
  const short = x.length <= y.length ? x : y, long = x.length <= y.length ? y : x;
  if (short.length >= 4 && (long.startsWith(short) || long.endsWith(short))) return 0.8;
  // bigram overlap (Dice)
  const grams = (s) => { const g = []; for (let i = 0; i < s.length - 1; i++) g.push(s.slice(i, i + 2)); return g; };
  const ga = grams(x), gb = grams(y);
  if (!ga.length || !gb.length) return 0;
  let hit = 0;
  const pool = gb.slice();
  ga.forEach((g) => { const k = pool.indexOf(g); if (k >= 0) { hit++; pool.splice(k, 1); } });
  return (2 * hit) / (ga.length + gb.length);
};

App.ptmReplaceSymbolDialog = async (slotName) => {
  const pm = App.paytableMapper;
  const slot = App.ptmCardSymbolSlot(slotName);
  if (!pm || !slot) return;
  const m = pm.mappings[slot] || (pm.mappings[slot] = App.ptmDefaultMapping(slot) || { slot, mode: "icon", token: `<${slot}>` });
  const cfg = App.state.config || {};
  const folder = cfg.icon_folder || "";

  // the symbol this card really shows (same re-bind as the preview: a stale
  // <pic4>, or a symbol box sitting over another card's pays, follows the sheet)
  let excelToken = m.token || `<${slot}>`;
  let shownImage = "";
  try {
    const sheet = document.getElementById("ptmSheet")?.value || pm.sheetName || "";
    const d = await api("/api/paytable_mapper/card_symbol", { method: "POST", timeout: 25000,
      body: { template: pm.template, mappings: pm.mappings, excel_path: cfg.excel_path, sheet_name: sheet, slot } });
    if (d.ok && d.token) excelToken = d.token;
    shownImage = d.image || "";
  } catch (e) { /* keep the mapping's own token */ }
  const tokenName = excelToken.replace(/[<>]/g, "");

  let files = [];
  try { files = (await api("/api/icons")).files || []; } catch (e) { files = []; }
  const scored = files.map((f) => ({ ...f, score: App.ptmSymbolSimilarity(f.name, tokenName) }))
    .sort((a, b) => b.score - a.score || a.name.localeCompare(b.name));
  const linked = (cfg.icon_mappings || {});
  const linkKey = Object.keys(linked).find((k) => k.replace(/[<>\s_-]/g, "").toLowerCase() === tokenName.replace(/[\s_-]/g, "").toLowerCase());
  // a pick made for another workbook (or before workbooks were recorded) no longer applies
  const ownPick = m.asset_path && String(m.pinned_excel || "").toLowerCase() === App.ptmExcelKey() ? m.asset_path : "";
  const current = ownPick || (linkKey ? linked[linkKey] : "") || "";
  const thumb = (f) => `/api/icon_file?folder=${encodeURIComponent(folder)}&name=${encodeURIComponent(f.name)}`;

  const overlay = document.createElement("div");
  overlay.className = "overlay";
  overlay.innerHTML = `<div class="table-mapper-dialog" style="width:min(720px,94vw);max-height:88vh;height:auto;display:flex;flex-direction:column">
      <div class="panel-header" style="margin-bottom:8px"><span class="panel-title">Replace symbol — ${esc(slot)}</span></div>
      <div class="hint" style="margin-bottom:10px">Excel puts <b>${esc(excelToken)}</b> on this card.
        ${current || shownImage ? `Now showing <b>${esc((current || shownImage).split(/[\\/]/).pop())}</b>.` : "No image for it was found in your icons folder — pick one below."}</div>
      <div style="display:flex;gap:16px;flex-wrap:wrap;margin-bottom:10px">
        <label class="tm-label" style="display:flex;gap:6px;align-items:center"><input type="radio" name="rsScope" value="card" checked> Only this card</label>
        <label class="tm-label" style="display:flex;gap:6px;align-items:center"><input type="radio" name="rsScope" value="all"> Everywhere ${esc(excelToken)} appears (all pages)</label>
      </div>
      <input type="text" class="tm-path" id="rsSearch" placeholder="Search your icons folder…" style="margin-bottom:10px">
      <div id="rsGrid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(96px,1fr));gap:8px;overflow:auto;min-height:160px;max-height:46vh;padding:2px"></div>
      <div class="tm-footer">
        <button class="btn ghost" id="rsCancel">Cancel</button>
        <button class="btn secondary" id="rsReset" ${current || m.symbol_pinned ? "" : "disabled"}>Use Excel symbol again</button>
        <button class="btn secondary" id="rsBrowse">Browse…</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);
  const $ = (id) => overlay.querySelector("#" + id);
  const close = () => overlay.remove();
  // a click outside never closes it (what was typed in it would be lost): its ✕ or Cancel do
  $("rsCancel").addEventListener("click", close);

  const render = (q) => {
    const query = String(q || "").toLowerCase();
    const list = scored.filter((f) => !query || f.name.toLowerCase().includes(query));
    $("rsGrid").innerHTML = list.length ? list.map((f, i) => `
      <button class="pt-btn secondary" data-name="${esc(f.name)}" title="${esc(f.name)}"
        style="display:flex;flex-direction:column;align-items:center;gap:4px;padding:6px;height:auto;${current && current.split(/[\\/]/).pop() === f.name ? "outline:2px solid var(--primary)" : ""}">
        <img src="${thumb(f)}" alt="" loading="lazy" style="width:64px;height:64px;object-fit:contain">
        <span style="font-size:11px;max-width:84px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(f.name)}</span>
        ${!query && i < 3 && f.score >= 0.5 ? '<span class="pt-pill" style="font-size:10px">suggested</span>' : ""}
      </button>`).join("")
      : `<div class="hint">${files.length ? "No icon matches." : "Your icons folder is empty or not set — use Browse…"}</div>`;
  };
  render("");
  $("rsSearch").addEventListener("input", (e) => render(e.target.value));

  const scope = () => overlay.querySelector('input[name="rsScope"]:checked')?.value || "card";
  const apply = async (path) => {
    if (!path) return;
    App.ptmPushUndo();
    if (scope() === "all") {
      // relink the token on every page of THIS workbook; the card follows it
      const next = { ...(cfg.icon_mappings || {}) };
      if (linkKey) delete next[linkKey];
      next[excelToken] = path;
      const byExcel = { ...(cfg.icon_mappings_by_excel || {}) };
      const ek = App.ptmExcelKey();
      if (ek) byExcel[ek] = { ...(byExcel[ek] || {}), [excelToken]: path };
      try {
        const d = await api("/api/mappings", { method: "POST", body: { icon_mappings: next, icon_mappings_by_excel: byExcel } });
        if (d.config) App.state.config = d.config; else App.state.config.icon_mappings = next;
      } catch (e) { toast(e.message, "err"); return; }
      delete m.asset_path;
      m.token = excelToken;
      m.symbol_pinned = true;
      m.pinned_excel = App.ptmExcelKey();
    } else {
      m.asset_path = path;
      m.symbol_pinned = true;
      m.pinned_excel = App.ptmExcelKey();     // only for this workbook
    }
    pm.userTouched = pm.userTouched || {};
    pm.userTouched[slot] = true;
    pm.iconIssues = (pm.iconIssues || []).filter((s) => s !== slot);
    close();
    App.ptmScheduleAutoSave();
    App.ptmRenderPanel();
    App.ptmRenderPreviewOverlay();
    App.ptmLiveRender();
    toast(scope() === "all" ? `${excelToken} now uses ${path.split(/[\\/]/).pop()} on every page.` : `${slot} now shows ${path.split(/[\\/]/).pop()}.`, "ok");
  };
  $("rsGrid").addEventListener("click", (e) => {
    const b = e.target.closest("button[data-name]");
    if (b) apply((folder ? folder.replace(/[\\/]$/, "") + "\\" : "") + b.dataset.name);
  });
  $("rsBrowse").addEventListener("click", async () => {
    let p = "";
    const native = window.pywebview?.api;
    if (native && typeof native.browse_file === "function") {
      try { p = await native.browse_file("image"); } catch (e) { toast("Native file dialog failed (" + e.message + ").", "err"); return; }
    } else {
      p = await App.ptmPromptFilePath({ title: "Symbol image", label: "Image file path", placeholder: "C:\\\\path\\\\to\\\\symbol.png", ok: "Use", hint: "PNG, JPG, GIF or BMP." });
    }
    if (p) apply(p);
  });
  $("rsReset").addEventListener("click", async () => {
    App.ptmPushUndo();
    delete m.asset_path;
    delete m.symbol_pinned;
    delete m.pinned_excel;
    if (linkKey && scope() === "all") {
      const next = { ...(cfg.icon_mappings || {}) };
      delete next[linkKey];
      const byExcel = { ...(cfg.icon_mappings_by_excel || {}) };
      const ek = App.ptmExcelKey();
      if (ek && byExcel[ek]) { byExcel[ek] = { ...byExcel[ek] }; delete byExcel[ek][linkKey]; }
      try {
        const d = await api("/api/mappings", { method: "POST", body: { icon_mappings: next, icon_mappings_by_excel: byExcel } });
        if (d.config) App.state.config = d.config; else App.state.config.icon_mappings = next;
      } catch (e) { /* keep going */ }
    }
    close();
    App.ptmScheduleAutoSave();
    App.ptmRenderPanel();
    App.ptmRenderPreviewOverlay();
    App.ptmLiveRender();
  });
  $("rsSearch").focus();
};

// ── Card bands: top / bottom card areas laid out from Excel (card_grid.py) ──
// The live render reports each band's box, the cards drawn there (one per
// Excel card) and the template slots they replace. Moving or scaling a band
// box stores it in mapper_meta.card_grid.bands.<band>.box; the server then
// lays the band's cards out inside it on every render (preview, PNG, PSD).

App.ptmBands = () => {
  const pm = App.paytableMapper;
  const info = (pm && pm.cardGrid) || {};
  return ["top", "bottom"].filter((b) => info[b] && Array.isArray(info[b].box)).map((b) => {
    const [x, y, w, h] = info[b].box;
    return { id: b, x, y, w, h, ...info[b] };
  });
};

App.ptmBandHidden = () => {
  const hidden = new Set();
  App.ptmBands().forEach((b) => { if (b.managed) (b.hidden || []).forEach((n) => hidden.add(n)); });
  return hidden;
};

App.ptmBandHtml = (cw, ch) => {
  const pm = App.paytableMapper;
  const pct = (v, d) => (v / d) * 100;
  return App.ptmBands().map((b) => {
    const sel = pm.selectedBand === b.id;
    const label = `${b.id === "top" ? "Top" : "Bottom"} cards · ${b.excel_cards} from Excel${b.managed ? "" : " · template layout"}`;
    const roleLabel = { symbol: "symbol", pay: "pays", value: "values", bg: "card" };
    const order = ["bg", "symbol", "pay", "value"];
    const cards = b.managed ? (b.cards || []).map((c) => {
      const [x, y, w, h] = c.box;
      const parts = order.filter((r) => c.parts && c.parts[r] && c.parts[r].box).map((r) => {
        const [px, py, pw, ph] = c.parts[r].box;
        const sp = pm.selectedPart;
        const on = sp && sp.band === b.id && sp.role === r && (sp.all || sp.cardSlot === c.parts[r].slot);
        return `<div class="ptm-gen-part ${r === "bg" ? "bg" : ""} ${on ? "selected" : ""} ${c.parts[r].override ? "own" : ""}" data-role="${r}" data-slot="${esc(c.parts[r].slot)}" title="${esc(c.key)} ${roleLabel[r]} — ${r === "pay" || r === "value" ? "click to edit all " + roleLabel[r] + ", Alt-click for this card only" : "click to edit this card"}, right-click to replace the symbol"
          style="left:${pct(px - x, w)}%;top:${pct(py - y, h)}%;width:${pct(pw, w)}%;height:${pct(ph, h)}%"></div>`;
      }).join("");
      return `<div class="ptm-gen-card" data-card-slot="${esc(c.slot)}" style="left:${pct(x - b.x, b.w)}%;top:${pct(y - b.y, b.h)}%;width:${pct(w, b.w)}%;height:${pct(h, b.h)}%">${parts}<span>${esc(c.key)}</span></div>`;
    }).join("") : "";
    return `<div class="ptm-band ${sel ? "selected" : ""} ${b.managed ? "managed" : ""}" data-band="${b.id}"
      onpointerdown="App.ptmBandPress('${b.id}', event)"
      title="${esc(label)} — drag to move, select and drag the corners to scale; the cards re-lay inside the box. Right-click for options."
      style="left:${pct(b.x, cw)}%;top:${pct(b.y, ch)}%;width:${pct(b.w, cw)}%;height:${pct(b.h, ch)}%">
      <span class="ptm-band-label">${esc(label)}</span>${cards}
    </div>`;
  }).join("");
};

App.ptmBandHandlesHtml = (cw, ch) => {
  const pm = App.paytableMapper;
  const b = App.ptmBands().find((x) => x.id === pm.selectedBand);
  if (!b || pm.selected || pm.selectedMaster) return "";
  const cur = { nw: "nwse-resize", n: "ns-resize", ne: "nesw-resize", e: "ew-resize", se: "nwse-resize", s: "ns-resize", sw: "nesw-resize", w: "ew-resize" };
  const x0 = b.x, y0 = b.y, x1 = b.x + b.w, y1 = b.y + b.h;
  return ["nw", "n", "ne", "e", "se", "s", "sw", "w"].map((h) => {
    const hx = h.includes("e") ? x1 : h.includes("w") ? x0 : (x0 + x1) / 2;
    const hy = h.includes("s") ? y1 : h.includes("n") ? y0 : (y0 + y1) / 2;
    return `<div class="ptm-handle ptm-band-handle" data-bh="${h}" style="left:${(hx / cw) * 100}%;top:${(hy / ch) * 100}%;cursor:${cur[h]}" title="Drag to scale the ${b.id} cards" onpointerdown="App.ptmBandAnchorStart('${h}', event)"></div>`;
  }).join("");
};

App.ptmBandSetBox = (band, box) => {
  // live-only during a drag: move the band and its card outlines on screen
  const pm = App.paytableMapper;
  const info = pm.cardGrid && pm.cardGrid[band];
  if (!info) return;
  const [ox, oy, ow, oh] = info.box;
  const sx = box[2] / (ow || 1), sy = box[3] / (oh || 1);
  (info.cards || []).forEach((c) => {
    const [x, y, w, h] = c.box;
    c.box = [box[0] + (x - ox) * sx, box[1] + (y - oy) * sy, w * sx, h * sy];
  });
  info.box = box;
};

App.ptmBandCommit = (band) => {
  const pm = App.paytableMapper;
  const info = pm.cardGrid && pm.cardGrid[band];
  if (!info) return;
  const [x, y, w, h] = info.box.map((v) => Math.round(v));
  const meta = (pm.template.mapper_meta = pm.template.mapper_meta || {});
  const grid = (meta.card_grid = meta.card_grid || {});
  grid.bands = grid.bands || {};
  grid.bands[band] = { ...(grid.bands[band] || {}), box: { x, y, w, h } };   // keep its layout options
  App.ptmScheduleAutoSave();
  App.ptmLiveRender();
};

App.ptmBandPress = (band, ev) => {
  const pm = App.paytableMapper;
  const layer = document.getElementById("ptPreviewSlots");
  const info = pm && pm.cardGrid && pm.cardGrid[band];
  if (!pm || !layer || !info || ev.button !== 0) return;
  if (ev.target.closest && ev.target.closest(".tm-slot, .ptm-handle")) return;
  ev.preventDefault();
  ev.stopPropagation();
  const partEl = ev.target.closest && ev.target.closest(".ptm-gen-part");
  pm.selectedBand = band;
  pm.selectedMaster = "";
  pm.multiSelected = [];
  if (!partEl) { pm.selected = ""; pm.selectedPart = null; }
  const cw = pm.template.canvas?.width || 1;
  App._ptmBandDrag = { band, scale: (layer.clientWidth || cw) / cw, startX: ev.clientX, startY: ev.clientY,
    box: info.box.slice(), pre: App.ptmSnap(), moved: false, part: partEl ? partEl.getAttribute("data-role") : "",
    partSlot: partEl ? partEl.getAttribute("data-slot") : "", single: !!(ev.altKey || ev.shiftKey) };
  App.ptmRenderPreviewOverlay();
  window.addEventListener("pointermove", App.ptmBandDragMove);
  window.addEventListener("pointerup", App.ptmBandDragEnd);
};

App.ptmBandDragMove = (ev) => {
  const d = App._ptmBandDrag;
  if (!d) return;
  if (!d.moved && Math.abs(ev.clientX - d.startX) + Math.abs(ev.clientY - d.startY) < 5) return;
  d.moved = true;
  const dx = (ev.clientX - d.startX) / d.scale, dy = (ev.clientY - d.startY) / d.scale;
  App.ptmBandSetBox(d.band, [d.box[0] + dx, d.box[1] + dy, d.box[2], d.box[3]]);
  App.ptmRenderPreviewOverlay();
  ev.preventDefault();
};

App.ptmBandDragEnd = () => {
  const d = App._ptmBandDrag;
  App._ptmBandDrag = null;
  window.removeEventListener("pointermove", App.ptmBandDragMove);
  window.removeEventListener("pointerup", App.ptmBandDragEnd);
  if (d && !d.moved) {
    if (d.part) {
      // pays / values: one click styles the whole column set (colour, stroke...) — Alt-click = this card only
      const all = (d.part === "pay" || d.part === "value") && !d.single;
      App.ptmSelectBandPart(d.band, d.part, all ? "" : d.partSlot, d.partSlot);
    }
    else App.ptmRenderPanel();
    return;
  }
  if (!d) return;
  if (d.pre) App.ptmPushUndoState(d.pre);
  App.ptmBandCommit(d.band);
};

App.ptmBandAnchorStart = (h, ev) => {
  const pm = App.paytableMapper;
  const layer = document.getElementById("ptPreviewSlots");
  const info = pm && pm.cardGrid && pm.cardGrid[pm.selectedBand];
  if (!pm || !layer || !info || ev.button !== 0) return;
  const cw = pm.template.canvas?.width || 1, ch = pm.template.canvas?.height || 1;
  const [x, y, w, hh] = info.box;
  App._ptmBandAnchor = { h, band: pm.selectedBand, x0: x, y0: y, x1: x + w, y1: y + hh, cw, ch,
    scale: (layer.clientWidth || cw) / cw, startX: ev.clientX, startY: ev.clientY, pre: App.ptmSnap(), moved: false };
  window.addEventListener("pointermove", App.ptmBandAnchorMove);
  window.addEventListener("pointerup", App.ptmBandAnchorEnd);
  ev.preventDefault();
  ev.stopPropagation();
};

App.ptmBandAnchorMove = (ev) => {
  const a = App._ptmBandAnchor;
  if (!a) return;
  const MIN = 60;
  const dx = (ev.clientX - a.startX) / a.scale, dy = (ev.clientY - a.startY) / a.scale;
  if (Math.abs(dx) > 1 || Math.abs(dy) > 1) a.moved = true;
  let nx0 = a.x0, nx1 = a.x1, ny0 = a.y0, ny1 = a.y1;
  if (a.h.includes("w")) nx0 = Math.min(Math.max(0, a.x0 + dx), a.x1 - MIN);
  if (a.h.includes("e")) nx1 = Math.max(a.x0 + MIN, Math.min(a.cw, a.x1 + dx));
  if (a.h.includes("n")) ny0 = Math.min(Math.max(0, a.y0 + dy), a.y1 - MIN);
  if (a.h.includes("s")) ny1 = Math.max(a.y0 + MIN, Math.min(a.ch, a.y1 + dy));
  App.ptmBandSetBox(a.band, [nx0, ny0, nx1 - nx0, ny1 - ny0]);
  App.ptmRenderPreviewOverlay();
  ev.preventDefault();
};

App.ptmBandAnchorEnd = () => {
  const a = App._ptmBandAnchor;
  App._ptmBandAnchor = null;
  window.removeEventListener("pointermove", App.ptmBandAnchorMove);
  window.removeEventListener("pointerup", App.ptmBandAnchorEnd);
  if (!a || !a.moved) return;
  if (a.pre) App.ptmPushUndoState(a.pre);
  App.ptmBandCommit(a.band);
};

App.ptmBandReset = (band) => {
  const pm = App.paytableMapper;
  const bands = pm?.template?.mapper_meta?.card_grid?.bands;
  if (!bands || !bands[band]) return;
  App.ptmPushUndo();
  delete bands[band];
  App.ptmScheduleAutoSave();
  App.ptmLiveRender();
};

App.ptmShowBandMenu = (x, y, band, cardSlot) => {
  App.ptmHideContextMenu();
  const pm = App.paytableMapper;
  const items = [];
  if (cardSlot) items.push({ label: "Replace symbol…", fn: () => App.ptmReplaceSymbolDialog(cardSlot) });
  const custom = !!pm?.template?.mapper_meta?.card_grid?.bands?.[band];
  items.push({ label: "Reset band to the template layout", fn: () => App.ptmBandReset(band), disabled: !custom });
  App.ptmOpenMenu(x, y, items);
};

App.ptmOpenMenu = (x, y, items) => {
  App._ptmMenuItems = items;
  const menu = document.createElement("div");
  menu.id = "ptContextMenu";
  menu.innerHTML = items.map((it, i) => `<button type="button" class="pt-ctx-item" ${it.disabled ? "disabled" : ""} onclick="App.ptmMenuClick(${i})">${esc(it.label)}</button>`).join("");
  menu.style.left = Math.min(x, window.innerWidth - 230) + "px";
  menu.style.top = Math.min(y, window.innerHeight - items.length * 34 - 12) + "px";
  document.body.appendChild(menu);
  document.addEventListener("click", App.ptmHideContextMenu, { once: true });
  document.addEventListener("keydown", (ev) => { if (ev.key === "Escape") App.ptmHideContextMenu(); }, { once: true });
};

// ── <GAME NAME> in headings: the game-name image from the icons folder, else
// the game name typed here (rendered as heading text with its layer style).
// Ask once per Excel file when a heading uses it and neither exists.
App.ensureGameName = async () => {
  const excel = App.state.config?.excel_path || "";
  if (!excel) return;
  App._gameNameAsked = App._gameNameAsked || {};
  if (App._gameNameAsked[excel]) return;
  let st;
  try { st = await api("/api/game_name/status"); } catch (e) { return; }
  if (!st || !st.needed) return;
  App._gameNameAsked[excel] = true;
  const name = await new Promise((resolve) => {
    const overlay = document.createElement("div");
    overlay.className = "overlay";
    overlay.innerHTML = `<div class="table-mapper-dialog" style="width:min(520px,92vw);max-height:unset;height:auto">
        <div class="panel-header" style="margin-bottom:10px"><span class="panel-title">What's the game called?</span></div>
        <div class="hint" style="margin-bottom:10px">A heading in your Excel uses <b>&lt;GAME NAME&gt;</b> and your icons folder has no GAME NAME image.
          Type the name and it will be rendered as heading text with your heading layer style. (Add a <b>GAME NAME.png</b> to the icons folder to use an image instead.)</div>
        <input type="text" class="tm-path" id="gnInput" placeholder="e.g. Crazy Chickens in Space">
        <div class="tm-footer">
          <button class="btn ghost" id="gnLater">Later</button>
          <button class="btn btn-primary tm-done-btn" id="gnOk">Use this name</button>
        </div>
      </div>`;
    document.body.appendChild(overlay);
    const done = (v) => { overlay.remove(); resolve(v); };
    overlay.querySelector("#gnLater").addEventListener("click", () => done(""));
    overlay.querySelector("#gnOk").addEventListener("click", () => done(overlay.querySelector("#gnInput").value.trim()));
    overlay.querySelector("#gnInput").addEventListener("keydown", (e) => { if (e.key === "Enter") done(e.target.value.trim()); });
    overlay.querySelector("#gnInput").focus();
  });
  if (!name) return;
  App.state.config.dynamic_settings = App.state.config.dynamic_settings || {};
  App.state.config.dynamic_settings.heading_game_name_text = name;
  try { await api("/api/config", { method: "POST", body: App.state.config }); } catch (e) { /* pushConfig retries */ }
  App.pushConfig();
  toast(`Headings will show “${name}” for <GAME NAME>.`, "ok");
  if (App.route === "paytable" && App.ptmLiveRender) App.ptmLiveRender();
};

// Workbook identity for remembered symbol choices (same rule as engine_api.excel_key)
App.ptmExcelKey = () => String(App.state.config?.excel_path || "").split(/[\\/]/).pop().trim().toLowerCase();

// Selecting a part of a generated card edits the band's prototype card
// (the template card the grid is drawn from), so every card in the band follows.
App.ptmSelectBandPart = (band, role, cardSlot, clickedSlot) => {
  const pm = App.paytableMapper;
  const info = pm.cardGrid && pm.cardGrid[band];
  if (!info) return;
  if (!cardSlot) {
    // the band's prototype: edits apply to every card in the band
    const slot = info.proto && info.proto[role];
    if (!slot) return;
    if (!pm.mappings[slot]) pm.mappings[slot] = App.ptmDefaultMapping(slot) || { slot };
    pm.selected = slot;
    pm.selectedPart = { band, role, all: true, clicked: clickedSlot || "" };
  } else {
    // one card: its own look, kept under "<slot>@card" (card 1 shares its slot name with the band's prototype)
    const card = (info.cards || []).find((c) => c.parts && c.parts[role] && c.parts[role].slot === cardSlot);
    const ownKey = cardSlot + "@card";
    if (!pm.mappings[ownKey]) {
      const proto = pm.mappings[(info.proto || {})[role]] || {};
      pm.mappings[ownKey] = { ...proto, ...((card && card.parts[role].spec) || {}), slot: ownKey };
      ["asset_path", "symbol_pinned", "pinned_excel", "source_pinned", "card_override"].forEach((k) => delete pm.mappings[ownKey][k]);
    }
    pm.selected = ownKey;
    pm.selectedPart = { band, role, slot: ownKey, cardSlot, key: card ? card.key : cardSlot };
  }
  pm.selectedBand = band;
  App.ptmRenderPreviewOverlay();
  App.ptmRenderPanel();
};

const PTM_STRUCTURAL = new Set(["slot", "mode", "role", "symbol", "source", "token", "text", "source_pinned",
  "card_override", "asset_path", "symbol_pinned", "pinned_excel"]);

App.ptmCardApplyToAll = () => {
  const pm = App.paytableMapper;
  const sp = pm.selectedPart;
  const info = sp && pm.cardGrid && pm.cardGrid[sp.band];
  const own = sp && pm.mappings[sp.slot];
  const protoSlot = info && info.proto && info.proto[sp.role];
  if (!own || !protoSlot) return;
  App.ptmPushUndo();
  const proto = (pm.mappings[protoSlot] = pm.mappings[protoSlot] || { slot: protoSlot });
  Object.entries(own).forEach(([k, v]) => { if (!PTM_STRUCTURAL.has(k)) proto[k] = v; });
  // every card of the band now follows the prototype again
  (info.cards || []).forEach((c) => {
    const ps = c.parts && c.parts[sp.role] && c.parts[sp.role].slot;
    if (ps) delete pm.mappings[ps + "@card"];
  });
  App.ptmSelectBandPart(sp.band, sp.role);
  App.ptmScheduleAutoSave();
  App.ptmLiveRender();
};

App.ptmCardResetOwn = () => {
  const pm = App.paytableMapper;
  const sp = pm.selectedPart;
  if (!sp || !sp.slot || !pm.mappings[sp.slot]) return;
  App.ptmPushUndo();
  delete pm.mappings[sp.slot];
  pm.selected = "";
  pm.selectedPart = null;
  App.ptmRenderPreviewOverlay();
  App.ptmRenderPanel();
  App.ptmScheduleAutoSave();
  App.ptmLiveRender();
};

App.ptmBandPartBanner = () => {
  const pm = App.paytableMapper;
  const sp = pm.selectedPart;
  if (!sp || !pm.cardGrid || !pm.cardGrid[sp.band]) return "";
  const info = pm.cardGrid[sp.band];
  const what = { symbol: "symbol", pay: "pays", value: "values", bg: "card background" }[sp.role] || sp.role;
  const box = (body) => `<div class="tm-hint" style="margin:0 0 8px;padding:6px 8px;border-radius:6px;background:rgba(64,214,140,0.12);color:#bff5d9">${body}</div>`;
  if (sp.all && info.proto && info.proto[sp.role] === pm.selected) {
    const clicked = sp.clicked ? (info.cards || []).find((c) => c.parts && c.parts[sp.role] && c.parts[sp.role].slot === sp.clicked) : null;
    return box(`Editing the <b>${what}</b> of all ${info.excel_cards} ${sp.band} cards — every card follows (cards with their own look keep it).
      ${clicked ? `<div style="margin-top:6px"><button class="btn small secondary" onclick="App.ptmSelectBandPart('${sp.band}', '${sp.role}', '${esc(sp.clicked)}')">Only ${esc(clicked.key)}</button>
      <span style="opacity:.75">· tip: Alt-click picks one card</span></div>` : ""}`);
  }
  if (sp.slot && sp.slot === pm.selected) {
    return box(`Editing the <b>${what}</b> of <b>${esc(sp.key || sp.slot)}</b> only.
      <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:6px">
        <button class="btn small secondary" onclick="App.ptmCardApplyToAll()">Apply to all ${sp.band} cards</button>
        <button class="btn small secondary" onclick="App.ptmSelectBandPart('${sp.band}', '${sp.role}')">Edit all ${sp.band} cards</button>
        <button class="btn small ghost" onclick="App.ptmCardResetOwn()">Reset this card</button>
      </div>`);
  }
  return "";
};

App.ptmBandPropsHtml = (band) => {
  const pm = App.paytableMapper;
  const info = (pm.cardGrid || {})[band] || {};
  const lay = pm.template?.mapper_meta?.card_grid?.bands?.[band]?.layout || {};
  const sides = [["below", "Below"], ["right", "Right"], ["left", "Left"], ["above", "Above"]];
  const num = (k, label, hint) => `<div class="tm-prop"><label>${label}</label>
      <input type="number" min="0" max="2000" value="${lay[k] ?? ""}" placeholder="${hint}" onchange="App.ptmBandSetLayout('${band}', '${k}', this.value)"></div>`;
  return `<div class="tm-panel">
    <div class="tm-prop-head"><span class="tm-prop-slot">${band === "top" ? "Top" : "Bottom"} cards</span>
      <button class="btn ghost small" onclick="App.ptmBandResetLayout('${band}')">Reset</button></div>
    <div class="tm-hint">${info.excel_cards || 0} cards from Excel. Each card keeps its own symbol, pays and values together — the layout below applies to every card in the band.</div>
    <div class="tm-props">
      <div class="tm-prop"><label>Pays & values</label>
        <div style="display:flex;gap:4px;flex-wrap:wrap">${sides.map(([v, l]) => `<button class="btn small ${lay.pays === v ? "btn-primary" : "secondary"}" onclick="App.ptmBandSetLayout('${band}', 'pays', '${v}')">${l}</button>`).join("")}</div>
        <div class="tm-hint">Where the pay and value columns sit relative to the symbol.</div></div>
      ${num("gap", "Gap symbol ↔ pays (px)", "as designed")}
      ${num("gutter", "Gutter between cards (px)", "as designed")}
      ${num("cols", "Cards per row", "auto")}
    </div></div>`;
};

App.ptmBandSetLayout = (band, key, value) => {
  const pm = App.paytableMapper;
  if (!pm || !pm.template) return;
  App.ptmPushUndo();
  const meta = (pm.template.mapper_meta = pm.template.mapper_meta || {});
  const grid = (meta.card_grid = meta.card_grid || {});
  grid.bands = grid.bands || {};
  const b = (grid.bands[band] = grid.bands[band] || {});
  const lay = (b.layout = b.layout || {});
  if (value === "" || value === null || value === undefined) delete lay[key];
  else lay[key] = key === "pays" ? value : Math.max(0, Number(value) || 0);
  if (key === "cols" && !lay.cols) delete lay.cols;
  App.ptmScheduleAutoSave();
  App.ptmRenderPanel();
  App.ptmLiveRender();
};

App.ptmBandResetLayout = (band) => {
  const pm = App.paytableMapper;
  const b = pm?.template?.mapper_meta?.card_grid?.bands?.[band];
  if (!b || !b.layout) return;
  App.ptmPushUndo();
  delete b.layout;
  App.ptmScheduleAutoSave();
  App.ptmRenderPanel();
  App.ptmLiveRender();
};

// ── Excel sheet check: every filled cell of the paytable sheet, marked green
// when the page renders it and amber when it is not on the page anywhere.
App.ptmRenderSheetCheck = debounce(async () => {
  const body = document.getElementById("ptSheetCheckBody");
  const sum = document.getElementById("ptSheetCheckSum");
  const pm = App.paytableMapper;
  if (!body || !pm || !pm.template) return;
  const sheet = document.getElementById("ptmSheet")?.value || pm.sheetName || "";
  if (!sheet) { body.innerHTML = `<div class="pt-g-hint">Pick the paytable sheet above.</div>`; return; }
  let d;
  try {
    d = await api("/api/paytable_mapper/sheet_coverage", { method: "POST", timeout: 30000,
      body: { template: pm.template, mappings: Object.values(pm.mappings || {}), sheet_name: sheet } });
  } catch (e) { body.innerHTML = `<div class="pt-g-hint">${esc(e.message)}</div>`; return; }
  if (!d.ok) { body.innerHTML = `<div class="pt-g-hint">${esc(d.error || "Could not read the sheet.")}</div>`; return; }
  const missing = d.unused || [];
  if (sum) {
    sum.textContent = missing.length ? ` · ${missing.length} cell${missing.length > 1 ? "s" : ""} not on the page` : ` · all ${d.used} filled cells are on the page`;
    sum.className = "pt-sheetcheck-sum " + (missing.length ? "warn" : "ok");
  }
  const colName = (c) => { let n = "", x = c; while (x > 0) { const m = (x - 1) % 26; n = String.fromCharCode(65 + m) + n; x = Math.floor((x - 1) / 26); } return n; };
  const cols = Math.max(1, d.cols || 1);
  const head = `<tr><th></th>${Array.from({ length: cols }, (_, i) => `<th>${colName(i + 1)}</th>`).join("")}</tr>`;
  const rows = (d.rows || []).map((row) => {
    const byCol = {};
    row.cells.forEach((c) => { byCol[c.c] = c; });
    return `<tr><th>${row.r}</th>${Array.from({ length: cols }, (_, i) => {
      const c = byCol[i + 1];
      if (!c) return "<td></td>";
      return `<td class="${c.used ? "used" : "unused"}" title="${esc(c.ref)}: ${esc(c.v)}${c.used ? " — shown by " + esc(c.slot || "the page") : " — NOT on the page"}">${esc(c.v.length > 28 ? c.v.slice(0, 27) + "…" : c.v)}</td>`;
    }).join("")}</tr>`;
  }).join("");
  const missingList = missing.length
    ? `<div class="pt-sheetcheck-missing"><b>Not on the page:</b> ${missing.slice(0, 12).map((m) => `<span title="${esc(m.v)}">${esc(m.ref)} “${esc(m.v.length > 40 ? m.v.slice(0, 39) + "…" : m.v)}”</span>`).join("")}${missing.length > 12 ? ` <span>+${missing.length - 12} more</span>` : ""}</div>`
    : `<div class="pt-sheetcheck-ok">Every filled cell of “${esc(sheet)}” is rendered on the page.</div>`;
  body.innerHTML = `${missingList}
    <div class="pt-sheetcheck-legend"><span class="used">on the page</span><span class="unused">not on the page</span></div>
    <div class="pt-sheetcheck-wrap"><table class="pt-sheetcheck">${head}${rows}</table></div>`;
}, 700);

// Drags re-render the preview as they move (the server render is ~0.1 s).
["ptmDragMove", "ptmAnchorMove", "ptmMasterDragMove", "ptmMasterAnchorMove"].forEach((name) => {
  const fn = App[name];
  if (typeof fn === "function") App[name] = (ev) => { fn(ev); App.ptmLiveRender(); };
});
["ptmBandDragMove", "ptmBandAnchorMove"].forEach((name) => {
  const fn = App[name];
  if (typeof fn !== "function") return;
  App[name] = (ev) => {
    fn(ev);
    const d = App._ptmBandDrag || App._ptmBandAnchor;
    const pm = App.paytableMapper;
    const info = d && pm && pm.cardGrid && pm.cardGrid[d.band];
    if (!info || !(d.moved)) return;
    const [x, y, w, h] = info.box.map((v) => Math.round(v));
    const grid = ((pm.template.mapper_meta = pm.template.mapper_meta || {}).card_grid = pm.template.mapper_meta.card_grid || {});
    grid.bands = grid.bands || {};
    grid.bands[d.band] = { ...(grid.bands[d.band] || {}), box: { x, y, w, h } };
    App.ptmLiveRender();
  };
});

/* Text the artist edits on a preview (line breaks, joined lines) — dynamic_settings.text_edits
   {sheet: {key: {from, to, joined?}}}, key "row:12" (normal pages) or a cell "B25" (Game Rules).
   An edit only applies while the Excel still says `from` (text_edits.py), so a changed document
   brings its own text back. Never written to the Excel. */
window.TextEdits = (() => {
  const norm = (t) => String(t || "").replace(/\s+/g, " ").trim();
  const all = () => {
    const ds = (App.state.config.dynamic_settings = App.state.config.dynamic_settings || {});
    return (ds.text_edits = ds.text_edits && typeof ds.text_edits === "object" ? ds.text_edits : {});
  };
  const get = (sheet, key) => (all()[sheet] || {})[key] || null;
  // `current` = the text shown now (the edit's own `to` when there is one)
  function put(sheet, key, current, to, extra) {
    const m = (all()[sheet] = all()[sheet] || {});
    const had = m[key];
    const from = had ? had.from : current;
    if (norm(from) === norm(to) && !String(to).includes("\n")) delete m[key];
    else m[key] = Object.assign({ from, to }, extra || {}, had && had.joined && !(extra && extra.joined) ? { joined: had.joined } : {});
  }
  function clear(sheet, keys) {
    const m = all()[sheet] || {};
    for (const k of keys) {
      const e = m[k];
      if (e && Array.isArray(e.joined)) e.joined.forEach((j) => delete m[j]);   // rows joined into it come back
      delete m[k];
    }
  }
  // replace one row's / cell's edit as a whole (null = no edit: the Excel text)
  function set(sheet, key, entry) {
    const m = (all()[sheet] = all()[sheet] || {});
    if (entry) m[key] = entry; else delete m[key];
  }
  async function save() {
    if (App.flushConfig) await App.flushConfig();
  }
  // insert a line break before word number `wordIndex` (words = what the preview lets you select:
  // text without its <symbols>); returns the new text, or null when it is the first word
  function breakBefore(text, wordIndex) {
    const parts = String(text || "").split(/(\s+)/);
    let n = 0;
    for (let i = 0; i < parts.length; i++) {
      if (!parts[i] || /^\s+$/.test(parts[i])) continue;
      const visible = parts[i].replace(/<[^<>]+>/g, "").trim();
      if (visible) {
        if (n === wordIndex) {
          if (i === 0) return null;
          const before = parts.slice(0, i).join("").replace(/\s+$/, "");
          return before ? before + "\n" + parts.slice(i).join("") : null;
        }
        n++;
      }
    }
    return null;
  }
  // a small text editor: Enter = a new line; returns the text, or null when cancelled
  function editor(title, text) {
    return new Promise((resolve) => {
      const ov = document.createElement("div");
      ov.className = "gm-overlay";
      ov.innerHTML = `<div class="gm-dialog" style="width:min(640px,94vw)">
          <div class="gm-dhead"><b>${esc(title)}</b><button class="gm-x" data-x>✕</button></div>
          <div class="gm-dbody"><textarea id="teArea" rows="8" style="width:100%;font:14px/1.5 system-ui,sans-serif;resize:vertical">${esc(text)}</textarea>
            <div class="hint" style="margin-top:6px">Enter starts a new line; delete a line break to join two lines. &lt;SYMBOLS&gt; stay as they are. The Excel file is never changed.</div></div>
          <div class="gm-dfoot"><span style="flex:1"></span><button class="btn secondary" data-x>Cancel</button><button class="btn primary" data-ok>Save</button></div>
        </div>`;
      document.body.appendChild(ov);
      const done = (v) => { ov.remove(); resolve(v); };
      ov.querySelectorAll("[data-x]").forEach((b) => b.addEventListener("click", () => done(null)));
      ov.querySelector("[data-ok]").addEventListener("click", () => done(ov.querySelector("#teArea").value));
      ov.addEventListener("keydown", (e) => { if (e.key === "Escape") done(null); e.stopPropagation(); });
      const ta = ov.querySelector("#teArea");
      ta.focus();
      ta.setSelectionRange(ta.value.length, ta.value.length);
    });
  }
  return { get, put, set, clear, save, breakBefore, editor, norm };
})();
