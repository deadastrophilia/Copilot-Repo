/* Table editing on the Typography page — like InDesign's table bar.

   Click a table: the top bar becomes its Table bar (preset, header, rows, lines, border, symbols).
   Shift+click adds more tables on the page. "Apply to" says which tables a change reaches: this
   table (or the selected ones), every table on this sheet, or every table in the project.
   Right-click a table (or Ctrl+C) copies its style; Paste style… (or Ctrl+V) puts it on other
   tables — only the groups you tick: colours & preset, header text, row text, lines & border, size,
   symbol size, cell styles.

   Everything goes where the Visualiser's table bar and the build already read it:
   table_style.designs[key] (its preset) and table_style.table_layouts[key] (its own look), the key
   being "sheet|header text" (table_designs.table_key) — so a table keeps its look through Excel
   revisions, and the PSD draws it exactly as the preview does. */
window.TableStudio = (() => {
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  // sel: design keys picked on the page; clip / cellClip: a copied table / box look; gear: its pop-over open
  const S = { sel: [], scope: "sel", clip: null, cellClip: null, cellScope: "cell", gear: false, info: null, infoAt: 0 };
  const el = (id) => document.getElementById(id);
  const ts = () => (App.state.config.table_style = App.state.config.table_style || {});
  const on = () => App.route === "typography" && !!(window.AppLive && AppLive.state && AppLive.state.data);
  const canvas = () => el("typoVisCanvas");
  const host = () => el("typoVisHost");
  const sheet = () => (window.AppTypoVis && AppTypoVis.state.sheet) || "";
  const hex = (v, fb) => {
    if (Array.isArray(v)) return "#" + v.slice(0, 3).map((n) => Math.max(0, Math.min(255, Number(n) || 0)).toString(16).padStart(2, "0")).join("");
    return /^#[0-9a-f]{6}$/i.test(String(v || "")) ? String(v) : fb;
  };

  /* what the server knows: the designs (with their colours) and every table of the Excel */
  async function info(force) {
    if (!force && S.info && Date.now() - S.infoAt < 60000) return S.info;
    try { S.info = await api("/api/tables/designs", { method: "POST", body: {} }); } catch (e) { S.info = S.info || { designs: [], tables: [] }; }
    S.infoAt = Date.now();
    return S.info;
  }
  const designs = () => (S.info && S.info.designs) || [];
  const tablesOf = (sh) => ((S.info && S.info.tables) || []).filter((t) => sh == null || t.sheet === sh);
  function nameOf(key) {
    const t = tablesOf().find((x) => x.key === key);
    const h = (t && t.header) || String(key).split("|").slice(1).join("|");
    return h ? (h.length > 34 ? h.slice(0, 34) + "…" : h) : "table";
  }

  /* ------------------------- a table's look, as it is drawn ------------------------- */
  const lay = (key) => JSON.parse(JSON.stringify((ts().table_layouts || {})[key] || {}));
  function designOf(key) {
    const t = ts(), ids = new Set(designs().map((d) => d.id));
    const own = (t.designs || {})[key];
    if (own && ids.has(own)) return own;
    const def = t.default_design || "current";
    return ids.has(def) ? def : "current";
  }
  const preset = (key) => designs().find((d) => d.id === designOf(key)) || {};
  // a colour / line setting: the table's own, else its preset's, else the Tables settings
  function styleVal(key, k) {
    const own = (lay(key).style || {})[k];
    if (own != null && own !== "") return own;
    const p = (preset(key).style || {})[k];
    if (p != null && p !== "") return p;
    return ts()[k];
  }
  function eff(key) {
    const l = lay(key), h = l.header || {}, b = l.body || {}, t = ts(), outer = l.outer || {};
    return {
      design: designOf(key), own: !!(t.designs || {})[key], excel: !!preset(key).excel,
      hFill: hex(styleVal(key, "header_bg_rgb"), "#333333"), hText: hex(h.color || styleVal(key, "header_text_rgb"), "#ffffff"),
      hFont: h.font || "", hSize: h.size || t.table_header_font_size || 28, hBold: h.bold !== false, hItalic: !!h.italic,
      r1: hex(styleVal(key, "row1_bg_rgb"), "#222222"), r2: hex(styleVal(key, "row2_bg_rgb"), "#2a2a2a"),
      bText: hex(b.color || styleVal(key, "table_body_text_rgb"), "#ffffff"),
      bFont: b.font || "", bSize: b.size || t.table_body_font_size || 24, bBold: !!b.bold, bItalic: !!b.italic,
      lines: l.lines || "design", lineColor: hex(l.line_color || styleVal(key, "stroke_rgb"), "#ffffff"),
      lineW: Number(l.line_width || styleVal(key, "stroke_width") || 1),
      border: !!outer.color, borderColor: hex(outer.color, "#c8952b"), borderW: Number(outer.width || 4),
      symbols: Math.round(Number(l.icon_px) || 0),
    };
  }

  /* ------------------------------ which tables ------------------------------ */
  const SCOPES = () => [["sel", S.sel.length > 1 ? `The ${S.sel.length} selected tables` : "This table"],
                        ["sheet", "Every table on this sheet"], ["project", "Every table in the project"]];
  const scope = () => (SCOPES().some(([v]) => v === S.scope) ? S.scope : (S.scope = "sel"));
  async function targets(how) {
    const sc = how || scope();
    if (sc === "sel") return S.sel.slice();
    await info();
    const keys = new Set(S.sel);
    tablesOf(sc === "sheet" ? sheet() : null).forEach((t) => keys.add(t.key));
    return [...keys];
  }
  const where = (how, n) => (how === "sheet" ? `every table on this sheet (${n})` : how === "project" ? `every table in the project (${n})`
    : n > 1 ? `the ${n} selected tables` : "this table");

  /* one change on every target table: fn(lay, key, designs) edits them in place */
  async function write(fn, what, how) {
    const sc = how || scope(), keys = await targets(sc);
    if (!keys.length) return;
    clearedBoxes = 0;
    const t = ts();
    const layouts = Object.assign({}, t.table_layouts || {}), own = Object.assign({}, t.designs || {});
    keys.forEach((k) => {
      const l = Object.assign({}, layouts[k] || {});
      fn(l, k, own);
      ["style", "header", "body", "outer", "cells", "boxes"].forEach((p) => { if (l[p] && typeof l[p] === "object" && !Object.keys(l[p]).length) delete l[p]; });
      if (Object.keys(l).length) layouts[k] = l; else delete layouts[k];
    });
    t.table_layouts = layouts;
    t.designs = own;
    await save();
    const boxes = clearedBoxes ? ` (${clearedBoxes} box${clearedBoxes === 1 ? "" : "es"} with ${clearedBoxes === 1 ? "its" : "their"} own setting now follow${clearedBoxes === 1 ? "s" : ""} too)` : "";
    toast(`${what} — ${where(sc, keys.length)}${boxes}.`);
  }
  /* a box edited on its own (double-click in the table: lay.cells["row,column"]) keeps its own font,
     size, colour… over the table's. A header / row change made here is meant for every box of that
     role, so the boxes' own value of that one setting goes (their other own settings stay).
     Header boxes: the table's first header_rows rows (from the page; 1 when it isn't drawn here). */
  function headerRowsOf(key) {
    for (const pg of AppLive.state.pages || []) {
      const t = (pg.elements || []).find((x) => x.kind === "table" && x.design_key === key && x.geo);
      if (t) return Math.max(0, Number(t.geo.header_rows) || 0);
    }
    return 1;
  }
  let clearedBoxes = 0;
  function clearOwn(l, key, role, props) {
    if (!l.cells || typeof l.cells !== "object") return;
    const nHead = headerRowsOf(key), cells = Object.assign({}, l.cells);
    Object.keys(cells).forEach((ck) => {
      const r = Number(String(ck).split(",")[0]);
      if ((role === "header") !== (r < nHead)) return;
      const spec = Object.assign({}, cells[ck]);
      let hit = false;
      props.forEach((p) => { if (spec[p] != null && spec[p] !== "") { delete spec[p]; hit = true; } });
      if (!hit) return;
      clearedBoxes++;
      if (Object.keys(spec).length) cells[ck] = spec; else delete cells[ck];
    });
    if (Object.keys(cells).length) l.cells = cells; else delete l.cells;
  }
  const TEXT_PROPS = ["font", "size", "color", "bold", "italic", "fx"];

  // "header.font", "style.row1_bg_rgb", "line_width", "outer.color": set, or remove when empty
  function setPath(l, path, v) {
    const [a, b] = path.split(".");
    if (!b) { if (v === "" || v == null) delete l[a]; else l[a] = v; return; }
    const o = Object.assign({}, l[a] || {});
    if (v === "" || v == null) delete o[b]; else o[b] = v;
    l[a] = o;
  }

  async function save() {
    const v = window.AppTblVis, kept = v && v.state.selKey === S.sel[0] ? (v.state.cells || []).slice() : [];
    App.refreshUI();
    if (App.flushConfig) await App.flushConfig();
    if (window.AppTypoVis && AppTypoVis.refreshPreview.now) await AppTypoVis.refreshPreview.now(true);
    // the change moved the table to another page (it grew, say): the page follows it, its boxes stay picked
    if (S.sel.length && window.AppTypoVis && !pageTables().some((x) => x.design_key === S.sel[0])) {
      const pi = (AppLive.state.pages || []).findIndex((pg) => (pg.elements || []).some((x) => x.kind === "table" && x.design_key === S.sel[0]));
      if (pi >= 0) {
        AppTypoVis.showPage(pi);
        const t = pageTables().find((x) => x.design_key === S.sel[0]);
        if (t && v && v.pickInTypo) { v.pickInTypo(t); if (kept.length && v.pickKeys) v.pickKeys(kept); }
      }
    }
    sync();
    if (window.TypoStudio && TypoStudio.target === "table") TypoStudio.paint();
  }

  /* --------------------------- copy / paste a table's style --------------------------- */
  // [group, label, what it carries, ticked when the pop-up opens]
  const GROUPS = [
    ["colors", "Colours & preset", "its preset, the header fill and the row fills", true],
    ["header", "Header text", "font, size, colour, bold / italic, layer style", true],
    ["rows", "Row text", "font, size, colour, bold / italic, layer style", true],
    ["lines", "Lines & border", "the lines between boxes, their colour and width, the border", true],
    ["size", "Size", "width, height and scale as drawn — and the column widths / row heights when the table has as many columns / rows", true],
    ["symbols", "Symbol size", "how big the symbols in its boxes are", true],
    ["cells", "Row & column styles", "rows, columns and boxes styled on their own (by their place; extra columns as its last one)", true],
  ];
  /* a table's columns and rows as drawn on the page (null when it isn't drawn here): what decides
     whether column widths / row heights / cell styles can be pasted box for box */
  function gridOf(key) {
    for (const pg of AppLive.state.pages || []) {
      const t = (pg.elements || []).find((x) => x.kind === "table" && x.design_key === key && x.geo);
      if (!t) continue;
      const g = t.geo, nCols = (g.cols || []).length;
      const nRows = t.cut ? (Number(t.cut.nHead) || 0) + (Number(t.cut.nBody) || 0) : (g.rows || []).length;
      return nCols && nRows ? { cols: nCols, rows: nRows } : null;
    }
    return null;
  }
  const copyOf = (v) => (v == null ? v : JSON.parse(JSON.stringify(v)));
  /* a table's size as drawn, at scale 1 (what width / row_h mean): its width, its header rows' and its
     body rows' height — so a table at its automatic size pastes its size too, onto any number of rows */
  function drawnSize(key, l) {
    for (const pg of AppLive.state.pages || []) {
      const t = (pg.elements || []).find((x) => x.kind === "table" && x.design_key === key && x.geo);
      if (!t) continue;
      // px as drawn: the paste puts the other table at scale 1, so these are the sizes it draws at
      const g = t.geo, k = 1, rows = g.rows || [], nh = Math.min(rows.length, Number(g.header_rows) || 0);
      const avg = (a) => (a.length ? a.reduce((x, y) => x + y, 0) / a.length : 0);
      const icon = ((g.icons || [])[0] || {}).rect;
      return { drawn_w: Math.round((g.cols || []).reduce((a, b) => a + b, 0) / k), head_h: Math.round(avg(rows.slice(0, nh)) / k),
               body_h: Math.round(avg(rows.slice(nh)) / k),
               // exactly as drawn (px): what a table with as many columns and rows gets box for box
               cols_px: (g.cols || []).slice(), rows_px: rows.slice(), row_gap: Number(g.row_gap) || 0,
               header_px: Number(g.header_size) || 0, body_px: Number(g.body_size) || 0,
               icon_px: icon ? icon[3] : Number(g.icon_h) || 0 };
    }
    return {};
  }
  function headRows(key) {
    for (const pg of AppLive.state.pages || []) {
      const t = (pg.elements || []).find((x) => x.kind === "table" && x.design_key === key && x.geo);
      if (t) return Number(t.cut ? t.cut.nHead : t.geo.header_rows) || 0;
    }
    return 0;
  }
  // the look as it is drawn (its preset's colours written out), so a pasted table looks the same
  function copy(key) {
    const l = lay(key), e = eff(key);
    S.clip = {
      from: nameOf(key),
      colors: { preset: (ts().designs || {})[key] || null,
                style: { header_bg_rgb: e.hFill, header_render_mode: styleVal(key, "header_render_mode") || "",
                         row1_bg_rgb: e.r1, row2_bg_rgb: e.r2, render_mode: styleVal(key, "render_mode") || "",
                         row1_render_mode: styleVal(key, "row1_render_mode") || "", row2_render_mode: styleVal(key, "row2_render_mode") || "" } },
      // a colour only when the table has one of its own (its preset / the Excel's colours aren't a choice
      // to carry over — written out, they'd turn the other table's text white)
      header: Object.assign({}, l.header || {}, { color: (l.header || {}).color || styleVal(key, "header_text_rgb") || undefined,
                                                   size: Number(e.hSize) || undefined, bold: e.hBold, italic: e.hItalic }),
      rows: Object.assign({}, l.body || {}, { color: (l.body || {}).color || styleVal(key, "table_body_text_rgb") || undefined,
                                               size: Number(e.bSize) || undefined, bold: e.bBold, italic: e.bItalic }),
      lines: { lines: l.lines || "", line_color: l.line_color || "", line_width: l.line_width || "", outer: l.outer || null, lines_fx: l.lines_fx || "",
               style: { stroke_rgb: hex(styleVal(key, "stroke_rgb"), ""), stroke_width: styleVal(key, "stroke_width") } },
      // the size as drawn: width / height (px at scale 1, as the side / bottom handles keep them) and the
      // scale (corner handles); column widths and row heights go only onto a table with as many
      size: Object.assign({ width: l.width || "", height: l.height || "", scale: l.scale || "", cols: copyOf(l.cols) || null,
              row_h: copyOf(l.row_h) || null, grid: gridOf(key) }, drawnSize(key, l)),
      symbols: { icon_scale: l.icon_scale || "", icon_px: Number(l.icon_px) || 0 },
      cells: { cells: copyOf(l.cells) || null, boxes: copyOf(l.boxes) || null, grid: gridOf(key) },
    };
    // its text and symbols as drawn (a table fitted to the page draws smaller than its nominal sizes)
    // the scale it is drawn at (its own × the page's fit): the paste puts the other table there, so its
    // padding, lines and text sizes come out the same
    const nominal = Number(S.clip.header.size) || Number(e.hSize) || 0;
    S.clip.size.eff = S.clip.size.header_px && nominal ? Math.round((S.clip.size.header_px / nominal) * 1000) / 1000 : (Number(l.scale) || 1);
    if (S.clip.size.header_px) S.clip.header.size = S.clip.size.header_px;
    if (S.clip.size.body_px) S.clip.rows.size = S.clip.size.body_px;
    if (!S.clip.symbols.icon_px && S.clip.size.icon_px) S.clip.symbols.icon_px = S.clip.size.icon_px;
    toast(`Copied the style of “${S.clip.from}” — Paste style… (or Ctrl+V) on other tables.`);
    if (window.TypoStudio && TypoStudio.target === "table") TypoStudio.paint();
  }
  let pasteNotes = [];
  function pasteInto(l, k, own, groups) {
    const c = S.clip, st = Object.assign({}, l.style || {}), grid = gridOf(k);
    const putStyle = (o) => Object.entries(o).forEach(([sk, v]) => { if (v === "" || v == null) delete st[sk]; else st[sk] = v; });
    const same = (src, what) => !!(src && grid && src[what] === grid[what]);
    if (groups.includes("colors")) { if (c.colors.preset) own[k] = c.colors.preset; else delete own[k]; putStyle(c.colors.style); }
    // its text: a colour only when the copied table has one of its own — else this table keeps its colours
    const text = (role, src) => {
      const was = l[role] || {}, next = copyOf(src);
      if (!src.color && was.color) next.color = was.color;
      l[role] = next;
      clearOwn(l, k, role, src.color ? TEXT_PROPS : TEXT_PROPS.filter((p) => p !== "color"));
    };
    if (groups.includes("lines")) {
      ["lines", "line_color", "line_width", "lines_fx"].forEach((f) => setPath(l, f, c.lines[f]));
      if (c.lines.outer) l.outer = Object.assign({}, c.lines.outer); else delete l.outer;
      putStyle(c.lines.style);
    }
    if (groups.includes("size")) {
      // at the copied table's drawn scale: its padding and lines the same; sizes below are px ÷ that scale
      const eff = Number(c.size.eff) || 1, at = (px) => Math.round((Number(px) / eff) * 1000) / 1000;
      if (Math.abs(eff - 1) > 0.001) l.scale = eff; else delete l.scale;
      delete l.height;
      const sameGrid = !!(grid && c.size.cols_px && c.size.cols_px.length === grid.cols && c.size.rows_px && c.size.rows_px.length === grid.rows);
      if (sameGrid) {
        // as many columns and rows: every column and row exactly as wide / tall as the copied table's
        l.width = at(c.size.cols_px.reduce((a, b) => a + b, 0));
        l.cols = c.size.cols_px.map((w) => Math.round(w * 1000) / 1000);
        l.row_h = c.size.rows_px.map(at);
      } else if (grid && c.size.cols_px && c.size.cols_px.length) {
        // another shape: its boxes as wide as the copied table's, column for column (a column the copied
        // table doesn't have: as wide as its last one), its header / body rows as tall as the copied table's
        const src = c.size.cols_px, colsPx = Array.from({ length: grid.cols }, (_v, i) => src[Math.min(i, src.length - 1)]);
        l.width = at(colsPx.reduce((a, b) => a + b, 0));
        l.cols = colsPx.map((w) => Math.round(w * 1000) / 1000);
        const nh = headRows(k);
        l.row_h = c.size.rows_px && c.size.rows_px.length === grid.rows
          ? c.size.rows_px.map(at)                                          // as many rows: row for row
          : Array.from({ length: grid.rows }, (_v, i) => at((i < nh ? c.size.head_h : c.size.body_h) || 0));
      } else {
        delete l.width; delete l.cols; delete l.row_h;
      }
    }
    if (!groups.includes("cells") && (groups.includes("header") || groups.includes("rows") || groups.includes("size"))) {
      ["cells", "boxes"].forEach((f) => {
        if (!l[f]) return;
        const kept = {};
        Object.entries(l[f]).forEach(([bk, v]) => { if (v && v.clear) kept[bk] = { clear: true }; });
        if (Object.keys(kept).length) l[f] = kept; else delete l[f];
      });
    }
    // the text in the copied table's sizes as drawn — on this table at its own scale, so it draws the same
    const k2 = Number(l.scale) || 1;
    const sized = (src) => Object.assign({}, src, src.size ? { size: Math.round((Number(src.size) / k2) * 1000) / 1000 } : {});
    if (groups.includes("header")) text("header", sized(c.header));
    if (groups.includes("rows")) text("body", sized(c.rows));
    if (groups.includes("symbols")) {                                  // its symbols as tall as the copied table's (px)
      if (c.symbols.icon_px) { l.icon_px = Math.round(c.symbols.icon_px); delete l.icon_scale; }
      else setPath(l, "icon_scale", c.symbols.icon_scale);
    }
    if (groups.includes("cells")) {
      // by their place in the table: the rows / columns / boxes this table has — a column the copied table
      // doesn't have takes its last column's style (as its width does); this table's deleted boxes stay deleted
      const srcCols = (c.cells.grid || {}).cols || 0, lastCol = srcCols - 1;
      const fits = (r, col) => !grid || ((r == null || r < grid.rows) && (col == null || col < grid.cols));
      const extra = grid && srcCols && grid.cols > srcCols ? Array.from({ length: grid.cols - srcCols }, (_v, i) => srcCols + i) : [];
      const wasClear = {};
      ["cells", "boxes"].forEach((f) => Object.entries(l[f] || {}).forEach(([bk, v]) => { if (v && v.clear) wasClear[f + "|" + bk] = true; }));
      const cells = {};
      Object.entries(c.cells.cells || {}).forEach(([ck, v]) => {
        const [r, col] = ck.split(",").map(Number);
        if (fits(r, col)) cells[ck] = copyOf(v);
        if (col === lastCol) extra.forEach((x) => { if (fits(r, x)) cells[`${r},${x}`] = copyOf(v); });
      });
      const boxes = {};
      Object.entries(c.cells.boxes || {}).forEach(([bk, v]) => {
        const m = /^(row|col):(\d+)$/.exec(bk);
        if (!m || fits(m[1] === "row" ? Number(m[2]) : null, m[1] === "col" ? Number(m[2]) : null)) boxes[bk] = copyOf(v);
        if (m && m[1] === "col" && Number(m[2]) === lastCol) extra.forEach((x) => { boxes[`col:${x}`] = copyOf(v); });
      });
      Object.keys(wasClear).forEach((fk) => {
        const [f, bk] = fk.split("|"), into = f === "cells" ? cells : boxes;
        into[bk] = Object.assign({}, into[bk] || {}, { clear: true });
      });
      if (Object.keys(cells).length) l.cells = cells; else delete l.cells;
      if (Object.keys(boxes).length) l.boxes = boxes; else delete l.boxes;
    }
    l.style = st;
  }
  function openPaste(anchor) {
    hideMenus();
    if (!S.clip) { toast("Copy a table's style first (right-click it → Copy table style, or Ctrl+C)."); return; }
    const h = host();
    if (!h) return;
    const sc = S.sel.length ? "sel" : "sheet";
    const m = document.createElement("div");
    m.className = "tsel-menu tbs-paste";
    m.innerHTML = `<div class="vpm-head">Paste the style of “${esc(S.clip.from)}”</div>
      ${GROUPS.map(([g, label, about, ticked]) => `<label class="tbs-check" title="${esc(about)}"><input type="checkbox" data-g="${g}" ${ticked ? "checked" : ""}> <b>${label}</b> <span>${esc(about)}</span></label>`).join("")}
      <div class="tsel-msep"></div>
      <div class="tbs-onto">Onto
        ${[["sel", S.sel.length > 1 ? `the ${S.sel.length} selected tables` : "the selected table"], ["sheet", "every table on this sheet"], ["project", "every table in the project"]]
          .map(([v, t]) => `<label><input type="radio" name="tbsOnto" value="${v}" ${v === sc ? "checked" : ""} ${v === "sel" && !S.sel.length ? "disabled" : ""}> ${t}</label>`).join("")}</div>
      <div class="tbs-actions"><button class="pt-btn secondary small" data-x>Cancel</button><button class="pt-btn small" data-go>Paste</button></div>`;
    ["mousedown", "pointerdown", "click", "dblclick", "contextmenu", "wheel"].forEach((t) => m.addEventListener(t, (ev) => ev.stopPropagation()));
    h.appendChild(m);
    const hr = h.getBoundingClientRect();
    const ax = anchor ? anchor.clientX - hr.left : 40, ay = anchor ? anchor.clientY - hr.top : 40;
    m.style.left = Math.max(4, Math.min(h.clientWidth - m.offsetWidth - 4, ax)) + "px";
    m.style.top = Math.max(4, Math.min(h.clientHeight - m.offsetHeight - 4, ay)) + "px";
    m.querySelector("[data-x]").addEventListener("click", hideMenus);
    m.querySelector("[data-go]").addEventListener("click", () => {
      const groups = [...m.querySelectorAll("[data-g]:checked")].map((x) => x.dataset.g);
      const how = (m.querySelector('input[name="tbsOnto"]:checked') || {}).value || "sheet";
      hideMenus();
      if (!groups.length) return;
      const names = groups.map((g) => GROUPS.find((x) => x[0] === g)[1].toLowerCase()).join(", ");
      pasteNotes = [];
      write((l, k, own) => pasteInto(l, k, own, groups), `Pasted ${names} from “${S.clip.from}”`, how).then(() => {
        const kept = [...new Set(pasteNotes)];
        if (kept.length) toast(`Not pasted onto every table: ${kept.join(", ")} — those tables size their columns by their own text.`);
      });
    });
  }

  /* -------------------------------- swatches -------------------------------- */
  /* Fill / Stroke / Text colour open a swatch list like Illustrator's: the colours used last, the ones
     on this page's tables and in the designs, any colour — and "None" where a box may have none */
  const RECENT_KEY = "psh.tableSwatches";
  function recent() {
    try { return (JSON.parse(localStorage.getItem(RECENT_KEY) || "[]") || []).filter((c) => /^#[0-9a-f]{6}$/.test(c)); } catch (e) { return []; }
  }
  function remember(c) {
    if (!c) return;
    const v = c.toLowerCase();
    try { localStorage.setItem(RECENT_KEY, JSON.stringify([v].concat(recent().filter((x) => x !== v)).slice(0, 14))); } catch (e) { /* private window */ }
  }
  function pageColours() {
    const out = new Set(), add = (v) => { const h = hex(v, ""); if (h) out.add(h.toLowerCase()); };
    const cfg = (App.state && App.state.config) || {}, ds = cfg.dynamic_settings || {};
    [cfg.h_rgb, cfg.b_rgb, ds.subheading_rgb, ds.continued_rgb].forEach(add);              // the page's own text colours
    try { pageTables().forEach((t) => Object.values((t.geo && t.geo.looks) || {}).forEach((lk) => { add(lk.fill); add(lk.color); add(lk.border); })); } catch (e) { /* no page drawn */ }
    designs().forEach((d) => ["header_bg_rgb", "row1_bg_rgb", "row2_bg_rgb", "header_text_rgb", "table_body_text_rgb", "stroke_rgb"].forEach((k) => add((d.style || {})[k])));
    add("#ffffff"); add("#000000");
    return [...out].slice(0, 42);
  }
  // a swatch on the bar: its colour (crossed out when none), ▾ for the list
  const sw = (attr, val, title, off) => `<button class="tbs-sw ${val ? "" : "none"}" ${attr} data-cur="${esc(val || "")}" title="${esc(title)}" ${off ? "disabled" : ""} style="--c:${esc(val || "transparent")}"><i></i><b>▾</b></button>`;
  function hidePops() { document.querySelectorAll(".tbs-pop2").forEach((n) => n.remove()); }
  function popUnder(anchor, html, cls) {
    hidePops();
    hideMenus();
    const p = document.createElement("div");
    p.className = "tbs-pop2 " + (cls || "");
    p.innerHTML = html;
    document.body.appendChild(p);
    const r = anchor ? anchor.getBoundingClientRect() : { bottom: 120, left: 200 };
    p.style.top = Math.max(8, Math.min(window.innerHeight - p.offsetHeight - 8, r.bottom + 6)) + "px";
    p.style.left = Math.max(8, Math.min(window.innerWidth - p.offsetWidth - 8, r.left - 8)) + "px";
    return p;
  }
  document.addEventListener("mousedown", (ev) => { if (!ev.target.closest(".tbs-pop2")) hidePops(); }, true);
  document.addEventListener("keydown", (ev) => {
    if (ev.key !== "Escape" || !document.querySelector(".tbs-pop2")) return;
    ev.stopPropagation();
    hidePops();
  }, true);
  const BASIC = ["#ffffff", "#d9d9d9", "#a6a6a6", "#595959", "#000000", "#ff0000", "#ff8000", "#ffd400", "#ffff00", "#80ff00",
                 "#00b050", "#00ffff", "#00b0f0", "#0070c0", "#002060", "#7030a0", "#ff00ff", "#ff4f9a", "#8b4513", "#c9a227"];
  function swatchPop(anchor, cur, onPick, none) {
    const c0 = String(cur || "").toLowerCase();
    const chips = (list) => `<div class="tbs-chips">${list.map((c) => `<button class="tbs-chip ${c === c0 ? "on" : ""}" data-c="${c}" style="--c:${c}" title="${c}"></button>`).join("")}</div>`;
    const rec = recent();
    const p = popUnder(anchor, `${none ? `<button class="tbs-none ${c0 ? "" : "on"}" data-c="">⊘ ${esc(none)}</button>` : ""}
      ${rec.length ? `<div class="tsp-h">Recent</div>${chips(rec)}` : ""}
      <div class="tsp-h">On this page and in the designs</div>${chips(pageColours())}
      <div class="tsp-h">Basic</div>${chips(BASIC)}
      <label class="tbs-any"><span class="ts-color"><input type="color" value="${esc(c0 || "#ffffff")}"></span> Any colour…</label>`);
    p.querySelectorAll("[data-c]").forEach((b) => b.addEventListener("click", () => { hidePops(); remember(b.dataset.c); onPick(b.dataset.c || null); }));
    const inp = p.querySelector("input[type=color]");
    inp.addEventListener("change", () => { hidePops(); remember(inp.value); onPick(inp.value); });
  }

  /* every colour field of the app opens this swatch list instead of the system's picker ("Any colour…"
     in the list is the system's); the field gets the colour and its own input / change handlers run */
  document.addEventListener("click", (ev) => {
    const inp = ev.target && ev.target.closest ? ev.target.closest('input[type="color"]') : null;
    if (!inp || inp.disabled || inp.closest(".tbs-pop2") || inp.hasAttribute("data-native")) return;
    ev.preventDefault();
    ev.stopPropagation();
    swatchPop(inp, inp.value, (c) => {
      if (!c) return;
      inp.value = c;
      inp.dispatchEvent(new Event("input", { bubbles: true }));
      inp.dispatchEvent(new Event("change", { bubbles: true }));
    });
  }, true);
  window.Swatches = { open: swatchPop };

  /* -------------------------------- designs -------------------------------- */
  function thumb(d) {
    const st = (d && d.style) || {};
    if (d && d.excel) return `<span class="tbs-thumb"><i style="background:#4f81bd"></i><i style="background:#c6efce"></i><i style="background:#ffeb9c"></i></span>`;
    const h = hex(st.header_bg_rgb, "#3a3a3a"), r1 = hex(st.row1_bg_rgb, "#222222"), r2 = hex(st.row2_bg_rgb, r1);
    return `<span class="tbs-thumb" style="--ln:${hex(st.stroke_rgb, "#777777")}"><i style="background:${h}"></i><i style="background:${r1}"></i><i style="background:${r2}"></i></span>`;
  }
  function designPop(anchor, key) {
    const e = eff(key), def = designs().find((d) => d.id === (ts().default_design || "current"));
    const p = popUnder(anchor, `<div class="tsp-h">This table's design</div>
      <div class="tbs-dgrid">${designs().map((d) => `<button class="tbs-d ${e.own && d.id === e.design ? "on" : ""}" data-d="${esc(d.id)}" title="${esc(d.about || d.name)}">${thumb(d)}<span>${esc(d.name)}</span></button>`).join("")}</div>
      <button class="tbs-d wide ${e.own ? "" : "on"}" data-d="">${thumb(def)}<span>Same as every table${def ? ` (${esc(def.name)})` : ""}</span></button>`, "tbs-designs");
    p.querySelectorAll("[data-d]").forEach((b) => b.addEventListener("click", () => {
      hidePops();
      const v = b.dataset.d;
      if (hasOwnLook(lay(key))) return confirmDesign(v, key);       // its own look goes: say so, offer what to keep
      applyDesign(v, []);
    }));
  }
  /* another design is the table's whole look: its fills and every box styled on its own go back to the
     design's. What the artist set may be kept (ticked) — the table's size and symbol size are, unless unticked */
  const LOOK_KEYS = ["style", "header", "body", "lines", "line_color", "line_width", "lines_fx", "outer", "cells", "boxes"];
  const KEEPS = [["fonts", "Fonts", false], ["sizes", "Text sizes", false], ["colors", "Text colours", false],
                 ["styles", "Bold / italic", false], ["fx", "Layer styles", false], ["lines", "Lines (stroke)", false],
                 ["border", "Border around the table", false], ["size", "Table size (width, height, columns, rows)", true],
                 ["symbols", "Symbol size", true]];
  const filled = (v) => v != null && v !== "" && !(typeof v === "object" && !Object.keys(v).length);
  const hasOwnLook = (l) => LOOK_KEYS.some((f) => filled(l[f]));
  // the layout with only what is kept of its own look (anything else it holds stays)
  function restyled(l, keep) {
    const out = {}, has = (x) => keep.includes(x);
    Object.keys(l).forEach((f) => { if (!LOOK_KEYS.includes(f) && !["width", "height", "scale", "cols", "row_h", "icon_scale"].includes(f)) out[f] = l[f]; });
    const text = [].concat(has("fonts") ? ["font"] : [], has("sizes") ? ["size"] : [], has("colors") ? ["color"] : [],
                           has("styles") ? ["bold", "italic"] : [], has("fx") ? ["fx"] : []);
    ["header", "body"].forEach((role) => {
      const o = {};
      text.forEach((pr) => { if (l[role] && filled(l[role][pr])) o[pr] = l[role][pr]; });
      if (Object.keys(o).length) out[role] = o;
    });
    if (has("fx") && l.lines_fx) out.lines_fx = l.lines_fx;
    if (has("lines")) ["lines", "line_color", "line_width"].forEach((f) => { if (filled(l[f])) out[f] = l[f]; });
    if (has("border") && l.outer) out.outer = l.outer;
    if (has("size")) ["width", "height", "scale", "cols", "row_h"].forEach((f) => { if (filled(l[f])) out[f] = l[f]; });
    if (has("symbols") && filled(l.icon_scale)) out.icon_scale = l.icon_scale;
    return out;
  }
  const designName = (v) => (v ? (designs().find((d) => d.id === v) || {}).name || v : "Same as every table");
  function applyDesign(v, keep) {
    write((l, k, own) => {
      const n = restyled(l, keep);
      Object.keys(l).forEach((f) => delete l[f]);
      Object.assign(l, n);
      if (v) own[k] = v; else delete own[k];
    }, v ? `Design ${designName(v)}` : "Same design as every table");
  }
  function confirmDesign(v, key) {
    const p = popUnder(document.querySelector("#typoStrip [data-tbdesign]"), `<div class="tsp-h">Switch to “${esc(designName(v))}”</div>
      <div class="tbs-warn">⚠ The table becomes the ${esc(designName(v))} design as a whole: its fills and every box, row or column styled on its own go back to the design's.</div>
      <div class="tsp-h">Keep of yours</div>
      <div class="tbs-keep">${KEEPS.map(([id, label, on]) => `<label class="tbs-check"><input type="checkbox" data-keep="${id}" ${on ? "checked" : ""}> ${label}</label>`).join("")}</div>
      <div class="tbs-actions"><button class="pt-btn secondary small" data-x>Cancel</button><button class="pt-btn small" data-go>Switch design</button></div>`, "tbs-special");
    p.querySelector("[data-x]").addEventListener("click", hidePops);
    p.querySelector("[data-go]").addEventListener("click", () => {
      const keep = [...p.querySelectorAll("[data-keep]:checked")].map((x) => x.dataset.keep);
      hidePops();
      applyDesign(v, keep);
    });
  }

  /* ------------------------------- the top bar ------------------------------- */
  /* like Illustrator's Control bar: the table's design, its fills, its text (header or rows), its lines;
     ⚙ for what is set less often (the border, the size, symbols, the lines' style, which tables
     change). Boxes picked in the table (double-click, a drag over them, → ↓ at its edges) turn it
     into the Cell bar. */
  const fontsSorted = () => (App.state.fonts || []).slice().sort((a, b) => String(a).localeCompare(String(b)));
  const fontSel = (attr, path, cur, def) => `<select class="ts-style tbs-font" ${attr}="${path}" title="Font">
      <option value="" ${cur ? "" : "selected"}>${esc(def ? `Tables font (${def})` : "Tables font")}</option>
      ${fontsSorted().map((f) => `<option value="${esc(f)}" ${String(f).toLowerCase() === String(cur).toLowerCase() ? "selected" : ""}>${esc(f)}</option>`).join("")}</select>`;
  // the table as drawn on the page: its width / height in px, its scale
  function drawnOf(key) {
    for (const pg of AppLive.state.pages || []) {
      const t = (pg.elements || []).find((x) => x.kind === "table" && x.design_key === key && x.geo);
      if (!t) continue;
      const g = t.geo, rows = (t.cut && t.cut.rows) || g.rows || [], gap = Number(g.row_gap) || 0;
      return { w: Math.round((g.cols || []).reduce((a, b) => a + b, 0)),
               h: Math.round(rows.reduce((a, b) => a + b, 0) + gap * Math.max(0, rows.length - 1)),
               scale: Number(g.scale) || 1, cols: (g.cols || []).length };
    }
    return null;
  }
  // how tall this table's icons are drawn (px): its first icon, else the table's icon height
  function tableIconPx(key) {
    for (const pg of AppLive.state.pages || []) {
      const x = (pg.elements || []).find((el) => el.kind === "table" && el.design_key === key && el.geo);
      if (x) return Math.round(((x.geo.icons || [])[0] || {}).rect ? x.geo.icons[0].rect[3] : Number(x.geo.icon_h) || 0);
    }
    return 0;
  }
  const fxBtn = (attr, fx, title) => `<button class="ts-fxbtn" ${attr} title="${esc(title)}">${fx ? `<span class="ts-fx-name">${esc(fx)}</span>` : `<span class="ts-fx-none">fx</span><span class="ts-fx-name">None</span>`}<span class="ts-fx-caret">▾</span></button>`;
  function barHtml() {
    const key = S.sel[0];
    if (!key) return "";
    if (cellsPicked()) return cellBarHtml();
    const e = eff(key), t = ts(), l = lay(key), role = S.trole === "body" ? "body" : "header";
    const R = role === "header"
      ? { font: e.hFont, size: e.hSize, bold: e.hBold, italic: e.hItalic, color: e.hText, def: t.table_header_font_name, fx: (l.header || {}).fx || "" }
      : { font: e.bFont, size: e.bSize, bold: e.bBold, italic: e.bItalic, color: e.bText, def: t.table_body_font_name, fx: (l.body || {}).fx || "" };
    const d0 = designs().find((d) => d.id === e.design);
    const textRows = rowsInfo(key).text;
    const xl = e.excel ? " — Like Excel: the fills come from the Excel" : "";
    return `<span class="ics-chip" title="${esc(nameOf(key))}">▦ ${S.sel.length > 1 ? `${S.sel.length} tables` : esc(nameOf(key))}</span>
      <button class="tbs-dbtn" data-tbdesign title="The table's design — the colours set next to it go on top">${thumb(d0)}<span>${esc(e.own ? (d0 || {}).name || "Design" : "Same as every table")}</span><b>▾</b></button>
      <span class="ts-sep"></span>
      <span class="ts-lbl">Fill</span>${sw('data-tbsw="style.header_bg_rgb"', e.hFill, "Header fill" + xl, e.excel)}${sw('data-tbsw="style.row1_bg_rgb"', e.r1, "Row fill" + xl, e.excel)}${sw('data-tbsw="style.row2_bg_rgb"', e.r2, "Every other row's fill" + xl, e.excel)}
      <span class="ts-sep"></span>
      <span class="ts-lbl">Stroke</span>${sw('data-tbstroke="color"', e.lines === "none" ? "" : e.lineColor, "The lines' colour (between and around every box) — ⊘ no lines")}
      <input class="ts-size ts-narrow" type="number" min="1" max="40" data-tbstroke="width" value="${esc(e.lineW)}" title="The lines' width (px) — exactly this, also between two boxes"><span class="ts-unit">px</span>
      <select class="ts-style ts-narrow" data-tb="lines" title="Which lines">
        <option value="design" ${e.lines === "design" ? "selected" : ""}>${e.excel ? "Excel's own" : "As the design"}</option>
        <option value="all" ${e.lines === "all" ? "selected" : ""}>Every box</option>
        <option value="none" ${e.lines === "none" ? "selected" : ""}>None</option></select>
      <span class="ts-sep"></span>
      <span class="ts-lbl" title="A border around the whole table — its outside edge only">Border Outside</span>${sw("data-tbouter", e.border ? e.borderColor : "", "Border Outside: its colour — ⊘ no border")}
      <input class="ts-size ts-narrow" type="number" min="1" max="40" data-tbouterw value="${esc(e.borderW)}" title="Border Outside: its width (px)"><span class="ts-unit">px</span>
      ${textRows.length ? `<button class="ts-tgt" data-tbtextrows title="Rows of this table drawn as normal text — put them back in the table">¶ ${textRows.length} row${textRows.length > 1 ? "s" : ""} as text ▾</button>` : ""}
      <span class="ts-sep"></span>
      <span class="tbs-seg" title="Which text the settings next to it change">${[["header", "Header"], ["body", "Rows"]].map(([v, n]) => `<button class="${v === role ? "on" : ""}" data-trole="${v}">${n}</button>`).join("")}</span>
      ${fontSel("data-tb", role + ".font", R.font, R.def)}
      <input class="ts-size ts-narrow" type="number" min="6" max="300" data-tb="${role}.size" value="${esc(R.size)}" title="Text size (px)"><span class="ts-unit">px</span>
      <button class="ts-al ${R.bold ? "on" : ""}" data-tbtog="${role}.bold" data-on="${R.bold ? 1 : 0}" title="Bold"><b>B</b></button><button class="ts-al ${R.italic ? "on" : ""}" data-tbtog="${role}.italic" data-on="${R.italic ? 1 : 0}" title="Italic"><i>I</i></button>
      ${sw(`data-tbsw="${role}.color"`, R.color, role === "header" ? "Header text colour" : "Row text colour")}
      ${fxBtn(`data-tbfx="${role}.fx"`, R.fx, `Layer style of the ${role === "header" ? "header" : "row"} text`)}

      <span class="tbs-gearwrap">${gearHtml(key, e)}</span>
      <span class="ts-sep"></span>
      <button class="ts-tgt" data-tbcopy title="Copy this table's style (Ctrl+C)">Copy</button>
      <button class="ts-tgt" data-tbpaste ${S.clip ? "" : "disabled"} title="${S.clip ? `Paste the style of “${esc(S.clip.from)}” (Ctrl+V)` : "Copy a table's style first"}">Paste ▾</button>
      <span class="ts-hint">double-click a box · drag over boxes · → ↓ at its edges: rows / columns</span>`;
  }
  // the gear and (open) its pop-over: what is set less often
  function gearHtml(key, e) {
    const gear = `<button class="ts-al ts-gear ${S.gear ? "on" : ""}" data-tbgear title="More: the size, symbols, the lines' style, which tables change">⚙</button>`;
    if (!S.gear) return gear;
    const tog = (path, onv, label, title) => `<button class="ts-al ${onv ? "on" : ""}" data-tbtog="${path}" data-on="${onv ? 1 : 0}" title="${title}">${label}</button>`;
    const d = drawnOf(key);
    return gear + `<div class="ts-strippop tbs-pop">
      <div class="tsp-h">Lines' layer style</div>
      <div class="tsp-row">${fxBtn('data-tbfx="lines_fx"', lay(key).lines_fx || "", "A layer style on the lines and the border")}</div>
      <div class="tsp-h">Size</div>
      <div class="tsp-row"><span class="tsp-l">Width</span><input class="ts-size ts-narrow" type="number" min="40" max="4000" data-tbsize="width" value="${d ? d.w : ""}" title="The table's width on the page (px) — its columns share it" ${d ? "" : "disabled"}><span class="ts-unit">px</span>
        <span class="tsp-l">Height</span><input class="ts-size ts-narrow" type="number" min="20" max="4000" data-tbsize="height" value="${d ? d.h : ""}" title="The table's height on the page (px) — at least what its rows need" ${d ? "" : "disabled"}><span class="ts-unit">px</span></div>
      <div class="tsp-row"><button class="ts-tgt" data-tbeven ${d && d.cols > 1 ? "" : "disabled"} title="Every column the same width">Even columns</button>
        <button class="ts-tgt" data-tbnatural title="Its own size again: no width, height, column or row sizes, scale 100 %">Natural size</button></div>
      <div class="tsp-row"><span class="tsp-l">Symbols</span><button class="ts-al" data-tbsym="-2" title="Smaller symbols (rows follow)">−</button>
        <input class="ts-size ts-narrow" type="number" min="4" max="1000" data-tbsympx value="${e.symbols || tableIconPx(key) || ""}" title="Every symbol in this table: its height (px, as drawn)"><span class="ts-unit">px</span>
        <button class="ts-al" data-tbsym="2" title="Bigger symbols (rows follow)">+</button></div>
      <div class="tsp-h">Changes go to</div>
      <div class="tsp-row"><select class="ts-style ics-scope-sel" data-tbscope title="Which tables a change reaches">
        ${SCOPES().map(([v, n]) => `<option value="${v}" ${scope() === v ? "selected" : ""}>${esc(n)}</option>`).join("")}</select></div>
    </div>`;
  }
  // the rows of this table drawn as normal text: each back in the table, or all
  function textRowsPop(anchor, key) {
    hideMenus();
    const info = rowsInfo(key), h = host();
    if (!info.text.length || !h) return;
    const m = document.createElement("div");
    m.className = "tsel-menu tbs-menu";
    m.innerHTML = `<div class="vpm-head">Rows drawn as normal text</div>` + info.text.map((t) =>
      `<button data-back="${t.off}" title="Excel row ${t.row}">↺ Back in the table: ${esc(String(t.text || "").slice(0, 48) || "row " + t.row)}</button>`).join("")
      + (info.text.length > 1 ? `<div class="vpm-sep"></div><button data-back="all">↺ All back in the table</button>` : "");
    ["mousedown", "pointerdown", "click", "dblclick", "contextmenu", "wheel"].forEach((t) => m.addEventListener(t, (x) => x.stopPropagation()));
    h.appendChild(m);
    const a = anchor.getBoundingClientRect(), hr = h.getBoundingClientRect();
    m.style.left = Math.max(4, Math.min(h.clientWidth - m.offsetWidth - 4, a.left - hr.left)) + "px";
    m.style.top = Math.max(4, a.bottom - hr.top + 4) + "px";
    m.querySelectorAll("[data-back]").forEach((b) => b.addEventListener("click", () => {
      m.remove();
      backInTable(info.rk, b.dataset.back === "all" ? info.text.map((t) => Number(t.off)) : [Number(b.dataset.back)]);
    }));
    setTimeout(() => document.addEventListener("mousedown", hideMenus, { once: true }), 0);
  }
  function placePop(root) {
    const pop = root.querySelector(".tbs-pop"), gear = root.querySelector("[data-tbgear]");
    if (!pop || !gear) return;
    const g = gear.getBoundingClientRect();
    pop.style.top = (g.bottom + 6) + "px";
    pop.style.left = Math.max(8, Math.min(window.innerWidth - pop.offsetWidth - 8, g.left - 12)) + "px";
  }
  document.addEventListener("keydown", (ev) => {
    if (ev.key !== "Escape" || !S.gear || document.querySelector(".ts-fxmenu, .tbs-pop2")) return;
    ev.stopPropagation();
    S.gear = false;
    if (window.TypoStudio) TypoStudio.paint();
  }, true);
  function wireBar(root) {
    const key = S.sel[0];
    if (!key) return;
    if (cellsPicked()) return wireCellBar(root);
    const labelOf = (path) => ({ "style.header_bg_rgb": "Header fill", "header.color": "Header text colour", "header.font": "Header font",
      "header.size": "Header size", "style.row1_bg_rgb": "Row fill", "style.row2_bg_rgb": "Other rows' fill", "body.color": "Row text colour",
      "body.font": "Row font", "body.size": "Row size", lines: "Lines", line_color: "Line colour", line_width: "Line width",
      "outer.color": "Border colour", "outer.width": "Border width", "header.fx": "Header layer style", "body.fx": "Row layer style",
      lines_fx: "Lines' layer style" }[path] || path);
    const setOne = (path, v) => write((l, k) => {
      setPath(l, path, v);
      if (path === "outer.width" || path === "outer.color") { const o = l.outer || {}; if (!o.color) delete l.outer; }
      const [role, prop] = path.split(".");
      if ((role === "header" || role === "body") && TEXT_PROPS.includes(prop)) clearOwn(l, k, role, [prop]);   // every box of that role
    }, labelOf(path));
    root.querySelectorAll("[data-tb]").forEach((n) => n.addEventListener("change", () => {
      let v = n.value;
      if (n.type === "number") v = Math.max(Number(n.min) || 0, Math.min(Number(n.max) || 999, Math.round(Number(v) || 0))) || "";
      if (n.dataset.tb === "lines" && v === "design") v = "";
      setOne(n.dataset.tb, v);
    }));
    root.querySelector("[data-tbdesign]")?.addEventListener("click", (ev) => designPop(ev.currentTarget, key));
    // Border Outside: a colour puts it on (at the width beside it), ⊘ takes it off
    root.querySelector("[data-tbouter]")?.addEventListener("click", (ev) => swatchPop(ev.currentTarget, ev.currentTarget.dataset.cur, (c) => write((l) => {
      if (c) l.outer = { color: c, width: Math.max(1, Number(root.querySelector("[data-tbouterw]").value) || 4) }; else delete l.outer;
    }, c ? "Border Outside" : "No Border Outside"), "No border"));
    root.querySelector("[data-tbouterw]")?.addEventListener("change", (ev) => {
      const v = Math.max(1, Math.min(40, Math.round(Number(ev.target.value) || 4)));
      write((l) => { l.outer = { color: (l.outer && l.outer.color) || eff(key).borderColor, width: v }; }, `Border Outside ${v} px`);
    });
    root.querySelector("[data-tbtextrows]")?.addEventListener("click", (ev) => textRowsPop(ev.currentTarget, key));
    // the stroke: a colour or a width draws every box's lines with it; ⊘ takes the lines off
    root.querySelector('[data-tbstroke="color"]')?.addEventListener("click", (ev) => swatchPop(ev.currentTarget, ev.currentTarget.dataset.cur, (c) => write((l) => {
      if (!c) { l.lines = "none"; return; }
      l.lines = "all";
      l.line_color = c;
      if (!l.line_width) l.line_width = Number(root.querySelector('[data-tbstroke="width"]').value) || 1;
    }, c ? "Stroke colour" : "No lines"), "No lines"));
    root.querySelector('[data-tbstroke="width"]')?.addEventListener("change", (ev) => {
      const v = Math.max(1, Math.min(40, Math.round(Number(ev.target.value) || 1)));
      write((l) => { l.lines = "all"; l.line_width = v; if (!l.line_color) l.line_color = eff(key).lineColor || "#ffffff"; }, `Stroke ${v} px`);
    });
    root.querySelectorAll("[data-tbsw]").forEach((b) => b.addEventListener("click", () =>
      swatchPop(b, b.dataset.cur, (c) => { if (c) setOne(b.dataset.tbsw, c); }, null)));
    root.querySelectorAll("[data-trole]").forEach((b) => b.addEventListener("click", () => { S.trole = b.dataset.trole; if (window.TypoStudio) TypoStudio.paint(); }));
    root.querySelectorAll("[data-tbfx]").forEach((b) => b.addEventListener("click", (ev) => {
      const path = b.dataset.tbfx, [a, c] = path.split("."), l = lay(key), cur = c ? (l[a] || {})[c] : l[a];
      if (window.TypoStudio) TypoStudio.fxPicker(ev.currentTarget, cur || "", (name) => setOne(path, name || ""), "None");
    }));
    root.querySelectorAll("[data-tbtog]").forEach((b) => b.addEventListener("click", () => {
      const path = b.dataset.tbtog, next = b.dataset.on !== "1";
      if (path === "outer.on") {
        const c = eff(key);
        return write((l) => { if (next) l.outer = { color: c.borderColor, width: c.borderW }; else delete l.outer; }, next ? "Border on" : "Border off");
      }
      write((l, k) => { setPath(l, path, next); const [role, prop] = path.split("."); clearOwn(l, k, role, [prop]); },
        `${labelOf(path).split(" ")[0]} ${path.endsWith("bold") ? "bold" : "italic"} ${next ? "on" : "off"}`);
    }));
    const symPx = (v) => write((l) => { setPath(l, "icon_px", Math.max(4, Math.min(1000, Math.round(v)))); delete l.icon_scale; }, `Symbols ${Math.round(v)} px`);
    root.querySelectorAll("[data-tbsym]").forEach((b) => b.addEventListener("click", () => {
      const now = Number(lay(key).icon_px) || tableIconPx(key) || 40;
      symPx(now + Number(b.dataset.tbsym));
    }));
    root.querySelector("[data-tbsympx]")?.addEventListener("change", (ev) => { const v = Number(ev.target.value) || 0; if (v > 0) symPx(v); });
    // the table's width / height on the page: kept at scale 1 (as the side / bottom handles keep them)
    root.querySelectorAll("[data-tbsize]").forEach((n) => n.addEventListener("change", () => {
      const what = n.dataset.tbsize, px = Math.max(Number(n.min) || 1, Math.min(Number(n.max) || 4000, Math.round(Number(n.value) || 0)));
      write((l, k) => {
        const sc = Number(l.scale) || 1, d = drawnOf(k);
        if (what === "width" && !l.cols && d && d.cols > 0) l.cols = Array.from({ length: d.cols }, () => 1);   // the columns keep their share
        l[what] = Math.round(px / sc);
      }, `${what === "width" ? "Width" : "Height"} ${px} px`);
    }));
    root.querySelector("[data-tbeven]")?.addEventListener("click", () => write((l, k) => {
      const d = drawnOf(k);
      if (!d || d.cols < 2) return;
      if (!l.width) l.width = Math.round(d.w / (Number(l.scale) || 1));
      l.cols = Array.from({ length: d.cols }, () => 1);
    }, "Even columns"));
    root.querySelector("[data-tbnatural]")?.addEventListener("click", () => write((l) => {
      ["width", "height", "cols", "row_h", "scale"].forEach((f) => delete l[f]);
    }, "Natural size"));
    root.querySelector("[data-tbgear]")?.addEventListener("click", () => { S.gear = !S.gear; if (window.TypoStudio) TypoStudio.paint(); });
    placePop(root);
    root.querySelector("[data-tbscope]")?.addEventListener("change", (ev) => { S.scope = ev.target.value; });
    root.querySelector("[data-tbcopy]")?.addEventListener("click", () => copy(key));
    root.querySelector("[data-tbpaste]")?.addEventListener("click", (ev) => openPaste(ev));
  }

  /* ------------------- rows / columns: header, normal, or normal text ------------------- */
  /* table_style.table_rows[rows key] (table_rows.py): text = rows drawn as normal text where they were,
     rows / cols = {offset | column: "header" | "body"} over what the tool decided. The rows key and each
     row's offset come from the page (geo.rows_key / geo.row_offs) — a lower piece of a table split by a
     text row writes to its table. Nothing is deleted from the Excel. */
  function rowsInfo(key, el) {
    const t = el || tableEl(key), g = (t && t.geo) || {};
    return { rk: g.rows_key || key, offs: g.row_offs || [], text: g.text_rows || [] };
  }
  const rowsSpec = (rk) => JSON.parse(JSON.stringify((ts().table_rows || {})[rk] || {}));
  async function writeRows(rk, fn, what) {
    const t = ts(), all = Object.assign({}, t.table_rows || {}), sp = rowsSpec(rk);
    fn(sp);
    ["rows", "cols"].forEach((f) => { if (sp[f] && !Object.keys(sp[f]).length) delete sp[f]; });
    if (sp.text) { sp.text = [...new Set(sp.text.map(Number))].sort((a, b) => a - b); if (!sp.text.length) delete sp.text; }
    if (Object.keys(sp).length) all[rk] = sp; else delete all[rk];
    t.table_rows = all;
    await save();
    toast(what);
  }
  // rows (whole-table indices) / columns of the table as "header" | "body" | "" (Auto)
  function setRole(key, what, idxs, role, el) {
    const info = rowsInfo(key, el), f = what === "row" ? "rows" : "cols";
    const ids = idxs.map((i) => (what === "row" ? info.offs[i] : i)).filter((v) => v != null);
    if (!ids.length) return;
    const name = role === "header" ? "Header" : role === "body" ? "Normal" : "Auto";
    writeRows(info.rk, (sp) => {
      sp[f] = Object.assign({}, sp[f] || {});
      ids.forEach((o) => { if (role) sp[f][o] = role; else delete sp[f][o]; });
    }, `${ids.length > 1 ? `${ids.length} ${what === "row" ? "rows" : "columns"}` : what === "row" ? "Row" : "Column"}: ${name}`);
  }
  function roleOf(key, what, idxs, el) {
    const info = rowsInfo(key, el), sp = (rowsSpec(info.rk)[what === "row" ? "rows" : "cols"]) || {};
    const vals = [...new Set(idxs.map((i) => sp[what === "row" ? info.offs[i] : i] || ""))];
    return vals.length === 1 ? vals[0] : null;
  }
  function rowsAsText(key, idxs, el) {
    const info = rowsInfo(key, el), offs = idxs.map((i) => info.offs[i]).filter((v) => v != null);
    if (!offs.length) return;
    if (tbv() && tbv().clearCells) tbv().clearCells();
    writeRows(info.rk, (sp) => { sp.text = (sp.text || []).concat(offs); },
      `${offs.length > 1 ? `${offs.length} rows are` : "The row is"} normal text now — "Back in the table" (right-click it, or the Table bar) undoes it`);
  }
  function backInTable(rk, offs) {
    writeRows(rk, (sp) => { sp.text = (sp.text || []).filter((o) => !offs.includes(Number(o))); },
      offs.length > 1 ? "Back in the table" : "The row is back in the table");
  }
  const roleSeg = (what, cur) => `<span class="tbs-seg" title="${what === "row" ? "Their rows" : "Their columns"}: the header look, or normal — Auto: as the tool found it">${[["", "Auto"], ["header", "Header"], ["body", "Normal"]]
    .map(([v, n]) => `<button class="${cur === v ? "on" : ""}" data-cbrole="${what}:${v}">${n}</button>`).join("")}</span>`;

  /* ------------------------------- the Cell bar ------------------------------- */
  /* boxes picked in the selected table (double-click one, drag over more, → ↓ at its edges, Shift /
     Ctrl add): their fill, text, alignment, stroke (and which sides), layer style, size — for just
     them, their row(s), their column(s), the header, every body row, or the whole table. Stored in
     the table's layout: cells["row,col"] for boxes one by one, boxes{all | header | body | row:N |
     col:N} for many at once (png_builder: all → header / body → column → row → the box's own). Row
     numbers are the whole table's (a part of a cut table too). */
  const CELL_SCOPES = [["cell", "These boxes"], ["row", "Their rows"], ["col", "Their columns"], ["header", "The header"],
                       ["body", "Every body row"], ["table", "The whole table"]];
  const CELL_PROPS = ["fill", "color", "font", "size", "bold", "italic", "align", "border", "border_width", "border_sides", "fx"];
  const tbv = () => window.AppTblVis;
  function cellsPicked() {
    const v = tbv();
    return v && v.typoActive && v.typoActive() && (v.state.cells || []).length && v.state.selKey === S.sel[0] ? v.state.cells.slice() : null;
  }
  const rc = (ck) => ck.split(",").map(Number);
  // where a scope's style goes: [["cells" | "boxes", key], …]
  function scopeSlots(sc, cells) {
    const uniq = (a) => [...new Set(a)];
    if (sc === "row") return uniq(cells.map((ck) => rc(ck)[0])).map((r) => ["boxes", `row:${r}`]);
    if (sc === "col") return uniq(cells.map((ck) => rc(ck)[1])).map((c) => ["boxes", `col:${c}`]);
    if (sc === "header") return [["boxes", "header"]];
    if (sc === "body") return [["boxes", "body"]];
    if (sc === "table") return [["boxes", "all"]];
    return cells.map((ck) => ["cells", ck]);
  }
  // a box's look from every level (what it shows): table → header / body → column → row → its own
  function boxLook(key, ck) {
    const l = lay(key), b = l.boxes || {}, [r, c] = rc(ck), role = r < headerRowsOf(key) ? "header" : "body";
    return Object.assign({}, b.all, b[role], b[`col:${c}`], b[`row:${r}`], (l.cells || {})[ck]);
  }
  // the table element the boxes are picked in (or, for another table, one that draws this box)
  function tableEl(key, ck) {
    const v = tbv(), id = v && v.state.selId, all = AppLive.state.elements || [];
    return all.find((x) => x.kind === "table" && x.id === id && x.design_key === key)
      || all.find((x) => x.kind === "table" && x.design_key === key && x.geo && (!ck || (x.geo.looks || {})[ck]));
  }
  /* a box as it is drawn — its fill and text from the Excel, the preset or set here (the page reports
     them: geo.looks) — with what is set here on top: what copying a box takes, what the Cell bar shows */
  function boxShown(key, ck, el) {
    const t = el || tableEl(key, ck);
    const drawn = (t && t.geo && t.geo.looks && t.geo.looks[ck]) || {};
    const own = boxLook(key, ck);
    return Object.assign({}, drawn, Object.fromEntries(Object.entries(own).filter(([, val]) => val != null && val !== "")));
  }
  /* the size of these boxes as drawn: their columns' width and rows' height (px on the page) —
     a box is as wide as its column and as tall as its row (InDesign's table cells too) */
  function boxSizes(cells, el) {
    const t = el || tableEl(S.sel[0]), g = t && t.geo;
    if (!g || !cells || !cells.length) return { w: "", h: "", cols: [], rows: [] };
    const local = (gr) => (g.rowMap ? g.rowMap.indexOf(gr) : gr);
    const cols = [...new Set(cells.map((ck) => rc(ck)[1]))].filter((c) => c < g.cols.length);
    const rows = [...new Set(cells.map((ck) => rc(ck)[0]))].filter((r) => local(r) >= 0 && local(r) < g.rows.length);
    return { w: cols.length ? Math.round(g.cols[cols[0]]) : "", h: rows.length ? Math.round(g.rows[local(rows[0])]) : "",
             cols, rows, colPx: (c) => g.cols[c], rowPx: (r) => g.rows[local(r)] };
  }
  // columns (index: px) and rows (whole-table row: px) of the selected table to these sizes on the page
  async function writeSizes(cols, rows, what) {
    const key = S.sel[0], t = tableEl(key), g = t && t.geo;
    if (!key || !g) return;
    const s = Number(g.scale) || 1, tsx = ts(), l = lay(key);
    if (cols && Object.keys(cols).length) {
      const ws = g.cols.slice();
      Object.entries(cols).forEach(([c, px]) => { if (Number(c) < ws.length) ws[Number(c)] = Math.max(16, Number(px) || 16); });
      const tot = ws.reduce((a, b) => a + b, 0);
      l.cols = ws.map((c) => Math.round(c / tot * 10000) / 10000);
      l.width = Math.round(tot / s);
    }
    if (rows && Object.keys(rows).length) {
      const rh = (l.row_h || []).slice();
      Object.entries(rows).forEach(([r, px]) => { while (rh.length <= Number(r)) rh.push(0); rh[Number(r)] = Math.round(Math.max(8, Number(px) || 8) / s); });
      l.row_h = rh;
    }
    tsx.table_layouts = Object.assign({}, tsx.table_layouts || {}, { [key]: l });
    await save();
    toast(`${what}.`);
  }
  /* a change made for many boxes reaches all of them: what the boxes inside it set for the same
     property on their own goes (a column given a fill: its boxes' own fills go) */
  function clearInside(l, key, sc, cells, props) {
    const nHead = headerRowsOf(key), rows = new Set(cells.map((ck) => rc(ck)[0])), cols = new Set(cells.map((ck) => rc(ck)[1]));
    const inside = (r, c) => sc === "table" || (sc === "row" && rows.has(r)) || (sc === "col" && cols.has(c))
      || (sc === "header" && r < nHead) || (sc === "body" && r >= nHead);
    const strip = (obj) => { const o = Object.assign({}, obj); props.forEach((p) => delete o[p]); return o; };
    const cellsObj = Object.assign({}, l.cells || {});
    Object.keys(cellsObj).forEach((ck) => { const [r, c] = rc(ck); if (inside(r, c)) { cellsObj[ck] = strip(cellsObj[ck]); if (!Object.keys(cellsObj[ck]).length) delete cellsObj[ck]; } });
    l.cells = cellsObj;
    const boxes = Object.assign({}, l.boxes || {});
    Object.keys(boxes).forEach((bk) => {
      const m = /^(row|col):(\d+)$/.exec(bk);
      let hit = false;
      if (sc === "table") hit = bk !== "all";
      else if ((sc === "header" || sc === "body") && m && m[1] === "row") hit = (Number(m[2]) < nHead) === (sc === "header");
      if (hit) { boxes[bk] = strip(boxes[bk]); if (!Object.keys(boxes[bk]).length) delete boxes[bk]; }
    });
    l.boxes = boxes;
  }
  // put `patch` (property: value, or null / "" to take it away) on the scope's slots of the selected table
  async function writeCells(patch, sc, what, replace, onto) {
    const key = S.sel[0], cells = onto || cellsPicked();
    if (!key || !cells) return;
    const t = ts(), l = lay(key);
    l.cells = Object.assign({}, l.cells || {});
    l.boxes = Object.assign({}, l.boxes || {});
    if (sc !== "cell") clearInside(l, key, sc, cells, Object.keys(patch));
    scopeSlots(sc, cells).forEach(([where, k]) => {
      const next = Object.assign({}, replace ? {} : l[where][k] || {}, patch);
      Object.keys(next).forEach((p) => { if (next[p] == null || next[p] === "") delete next[p]; });
      if (Object.keys(next).length) l[where][k] = next; else delete l[where][k];
    });
    ["cells", "boxes"].forEach((f) => { if (!Object.keys(l[f]).length) delete l[f]; });
    t.table_layouts = Object.assign({}, t.table_layouts || {}, { [key]: l });
    if (!Object.keys(l).length) delete t.table_layouts[key];
    await save();
    const label = (CELL_SCOPES.find(([v]) => v === sc) || [, ""])[1].toLowerCase();
    toast(`${what} — ${sc === "cell" ? (cells.length > 1 ? `these ${cells.length} boxes` : "this box") : label}.`);
  }
  const SIDES = [["t", "Top"], ["l", "Left"], ["r", "Right"], ["b", "Bottom"]];
  /* ---------- an icon in a table: its height in px (as drawn) in this box, this table, every table — or
     every icon of this table / of every table (table_style: table_layouts[key].cells[r,c].icons_px /
     .icons_px / .icon_px, table_icon_sizes_px / table_icon_px; the older % keys give way) ---------- */
  const REACH = [["cell", "This icon in this box"], ["table", "This icon in this table"], ["all", "This icon in every table"],
                 ["table_all", "Every icon in this table"], ["all_all", "Every icon in every table"]];
  const icKey = (tok) => String(tok || "").toUpperCase().replace(/[^A-Z0-9]+/g, "");
  // how tall the picked icon is drawn now (px)
  function drawnIconPx() {
    for (const pg of AppLive.state.pages || []) {
      for (const x of pg.elements || []) {
        if (x.kind !== "table" || x.design_key !== S.sel[0] || !x.geo) continue;
        const i = (x.geo.icons || []).find((ic) => ic.cell === S.icon.cell && ic.tok === S.icon.tok);
        if (i) return i.rect[3];
      }
    }
    return 40;
  }
  function iconPx(reach) {
    const key = S.sel[0], t = ts(), l = lay(key), K = icKey(S.icon.tok), cell = (l.cells || {})[S.icon.cell] || {};
    const at = { cell: (cell.icons_px || {})[K], table: (l.icons_px || {})[K], all: (t.table_icon_sizes_px || {})[K],
                 table_all: l.icon_px, all_all: t.table_icon_px };
    return Math.round(Number(at[reach]) || drawnIconPx());        // its own height there, else as drawn
  }
  async function setIconPx(v, clear) {
    const key = S.sel[0], t = ts(), reach = S.iconReach || "cell", K = icKey(S.icon.tok);
    v = Math.max(4, Math.min(1000, Math.round(Number(v) || 0)));
    const l = lay(key), dropTok = (o) => {
      ["icons", "icons_px"].forEach((f) => { if (o && o[f]) { delete o[f][K]; if (!Object.keys(o[f]).length) delete o[f]; } });
    };
    if (reach === "table_all") { if (clear) delete l.icon_px; else l.icon_px = v; delete l.icon_scale; }
    else if (reach === "all_all") { if (clear) delete t.table_icon_px; else t.table_icon_px = v; delete t.table_icon_scale; }
    else if (reach === "all") {
      t.table_icon_sizes_px = Object.assign({}, t.table_icon_sizes_px || {});
      if (clear) delete t.table_icon_sizes_px[K]; else t.table_icon_sizes_px[K] = v;
      if (t.table_icon_sizes) { t.table_icon_sizes = Object.assign({}, t.table_icon_sizes); delete t.table_icon_sizes[K]; }
      dropTok(l); Object.values(l.cells || {}).forEach(dropTok);       // this table's own sizes of it give way
    } else if (reach === "table") {
      l.icons_px = Object.assign({}, l.icons_px || {});
      if (clear) delete l.icons_px[K]; else l.icons_px[K] = v;
      if (!Object.keys(l.icons_px).length) delete l.icons_px;
      if (l.icons) { delete l.icons[K]; if (!Object.keys(l.icons).length) delete l.icons; }
      Object.values(l.cells || {}).forEach(dropTok);                    // its boxes' own sizes of it give way
    } else {
      l.cells = Object.assign({}, l.cells || {});
      const c = (l.cells[S.icon.cell] = Object.assign({}, l.cells[S.icon.cell] || {}));
      dropTok(c);
      if (!clear) c.icons_px = { [K]: v };
    }
    if (l.cells) {                                                     // nothing left of a box / of the boxes: gone
      Object.keys(l.cells).forEach((ck) => { if (!Object.keys(l.cells[ck] || {}).length) delete l.cells[ck]; });
      if (!Object.keys(l.cells).length) delete l.cells;
    }
    t.table_layouts = Object.assign({}, t.table_layouts || {}, { [key]: l });
    await save();
    toast(`${(REACH.find(([r]) => r === reach) || [, ""])[1]}: ${clear ? "as the table draws it" : v + " px"}.`);
  }
  function iconBarHtml() {
    const reach = S.iconReach || "cell", px = iconPx(reach), [r, c] = rc(S.icon.cell);
    return `<span class="ics-chip">◆ &lt;${esc(S.icon.name || S.icon.tok)}&gt;</span><span class="ts-hint">Row ${r + 1} · Column ${c + 1}</span>
      <button class="ts-tgt" data-ic="back" title="The box's own bar">◂ Box</button>
      <span class="ts-sep"></span>
      <select class="ts-style" data-ic="reach" title="What the size changes">${REACH.map(([v, n]) => `<option value="${v}" ${v === reach ? "selected" : ""}>${n}</option>`).join("")}</select>
      <span class="ts-lbl">Height</span><button class="ts-al" data-icstep="-2">−</button>
      <input class="ts-size ts-narrow" type="number" min="4" max="1000" data-ic="px" value="${px}" title="The icon's height (px, as drawn)"><span class="ts-unit">px</span>
      <button class="ts-al" data-icstep="2">+</button>
      <span class="ts-sep"></span>
      <button class="ts-tgt" data-ic="pic" title="Another picture for &lt;${esc(S.icon.name || S.icon.tok)}&gt; (every page)">🖼 Change picture</button>
      <button class="ts-tgt" data-ic="reset" title="No height of its own at this reach">Reset</button>
      <span class="ts-hint">drag its corner · the closest wins: this box › this table › every table</span>`;
  }
  function wireIconBar(root) {
    const q = (k) => root.querySelector(`[data-ic="${k}"]`);
    const repaint = () => { if (window.TypoStudio) TypoStudio.paint(); if (tbv() && tbv().pickKeys) tbv().pickKeys(cellsPicked() || []); };
    q("back").addEventListener("click", () => { S.icon = null; repaint(); });
    q("reach").addEventListener("change", () => { S.iconReach = q("reach").value; repaint(); });
    q("px").addEventListener("change", () => setIconPx(q("px").value));
    root.querySelectorAll("[data-icstep]").forEach((b) => b.addEventListener("click", () => setIconPx(iconPx(S.iconReach || "cell") + Number(b.dataset.icstep))));
    q("reset").addEventListener("click", () => setIconPx(0, true));
    q("pic").addEventListener("click", () => window.IconStudio && IconStudio.mapDialog && IconStudio.mapDialog(S.icon.name || S.icon.tok, true));
  }
  function cellBarHtml() {
    const key = S.sel[0], cells = cellsPicked(), look = boxShown(key, cells[0]);
    if (S.icon && cells.includes(S.icon.cell)) return iconBarHtml();
    const d = drawnOf(key) || { scale: 1 }, sc = S.cellScope || "cell", z = boxSizes(cells);
    const [r, c] = rc(cells[0]);
    const pickedRows = [...new Set(cells.map((ck) => rc(ck)[0]))], pickedCols = [...new Set(cells.map((ck) => rc(ck)[1]))];
    const size = look.size ? Math.round(Number(look.size) * d.scale) : "";
    const al = look.align || "", sides = String(look.border_sides || "tblr");
    return `<span class="ics-chip" title="${esc(nameOf(key))}">▦ ${cells.length > 1 ? `${cells.length} boxes` : `Row ${r + 1} · Column ${c + 1}`}</span>
      <select class="ts-style" data-cb="scope" title="Which boxes a change reaches">
        ${CELL_SCOPES.map(([v, n]) => `<option value="${v}" ${v === sc ? "selected" : ""}>${n === "These boxes" && cells.length === 1 ? "This box" : n}</option>`).join("")}</select>
      <button class="ts-tgt" data-cb="back" title="Back to the whole table's bar (Esc)">◂ Table</button>
      <span class="ts-sep"></span>
      <span class="ts-lbl">Fill</span>${sw('data-cbsw="fill"', hex(look.fill, ""), "Fill colour")}
      <span class="ts-sep"></span>
      ${fontSel("data-cb", "font", look.font || "", "")}
      <input class="ts-size ts-narrow" type="number" min="6" max="300" data-cb="size" value="${esc(size)}" placeholder="same" title="Text size (px)"><span class="ts-unit">px</span>
      <button class="ts-al ${look.bold ? "on" : ""}" data-cb="bold" title="Bold"><b>B</b></button><button class="ts-al ${look.italic ? "on" : ""}" data-cb="italic" title="Italic"><i>I</i></button>
      ${sw('data-cbsw="color"', hex(look.color, ""), "Text colour")}
      ${[["left", "⯇≡", "Align left"], ["center", "≡", "Centre"], ["right", "≡⯈", "Align right"]].map(([v, n, ti]) => `<button class="ts-al ${al === v ? "on" : ""}" data-cbalign="${v}" title="${ti}">${n}</button>`).join("")}
      ${fxBtn('data-cb="fx"', look.fx || "", "Layer style of the text")}
      <span class="ts-sep"></span>
      <span class="ts-lbl">Stroke</span>${sw('data-cbsw="border"', look.border ? hex(look.border, "") : "", "A border of its own — its colour")}
      <input class="ts-size ts-narrow" type="number" min="1" max="20" data-cb="bw" value="${esc(look.border_width || 3)}" title="Border width (px)"><span class="ts-unit">px</span>
      <span class="tbs-sides" title="Which sides get the border">${SIDES.map(([s2, n]) => `<button class="s-${s2} ${look.border && sides.includes(s2) ? "on" : ""}" data-cbside="${s2}" title="${n}"></button>`).join("")}</span>
      <span class="ts-sep"></span>
      <span class="ts-lbl" title="Width of their column(s)">W</span><input class="ts-size ts-narrow" type="number" min="16" max="4000" data-cbw value="${z.w}" title="Width of these boxes' column(s), px — a box is as wide as its column">
      <span class="ts-lbl" title="Height of their row(s)">H</span><input class="ts-size ts-narrow" type="number" min="8" max="4000" data-cbh value="${z.h}" title="Height of these boxes' row(s), px">
      <button class="ts-al" data-cbeven="w" ${z.cols.length > 1 ? "" : "disabled"} title="Even widths: their columns the same width">⇔</button><button class="ts-al" data-cbeven="h" ${z.rows.length > 1 ? "" : "disabled"} title="Even heights: their rows the same height">⇕</button>
      <span class="ts-sep"></span>
      <span class="ts-lbl">Row</span>${roleSeg("row", roleOf(key, "row", pickedRows))}
      <span class="ts-lbl">Column</span>${roleSeg("col", roleOf(key, "col", pickedCols))}
      <button class="ts-tgt" data-cb="astext" title="Take their row(s) out of the table: drawn as normal text where they were (nothing is deleted from the Excel)">¶ Treat as normal text</button>
      <span class="ts-sep"></span>
      <button class="ts-al ${S.drop ? "on" : ""}" data-cb="drop" title="Eyedropper: click a box in any table — these boxes get its look">💧</button>
      <button class="ts-tgt" data-cb="copy" title="Copy this box's look (Ctrl+C)">Copy</button>
      <button class="ts-tgt" data-cb="paste" ${S.cellClip ? "" : "disabled"} title="${S.cellClip ? "Paste: pick what (Ctrl+Shift+V) — Ctrl+V pastes the whole look" : "Copy a box's look first"}">Paste ▾</button>
      <button class="ts-tgt" data-cb="reset" title="These boxes (at the chosen reach) back to the table's look">Reset</button>
      <span class="ts-sep"></span>${look.clear
        ? `<button class="ts-tgt on" data-cb="clear" title="Show what the Excel has in these boxes again">↺ Restore</button>`
        : `<button class="ts-tgt" data-cb="clear" title="Delete what these boxes show (unwanted data) — the box stays, empty (Delete key)">🗑 Delete</button>`}`;
  }
  function wireCellBar(root) {
    const key = S.sel[0], cells = cellsPicked();
    if (S.icon && cells.includes(S.icon.cell)) return wireIconBar(root);
    const q = (k) => root.querySelector(`[data-cb="${k}"]`), sc = () => S.cellScope || "cell";
    const scale = () => (drawnOf(key) || { scale: 1 }).scale;
    q("back").addEventListener("click", () => { if (tbv().clearCells) tbv().clearCells(); });
    q("scope").addEventListener("change", () => { S.cellScope = q("scope").value; if (window.TypoStudio) TypoStudio.paint(); });
    const look = () => boxShown(key, cells[0]);
    root.querySelectorAll("[data-cbsw]").forEach((b) => b.addEventListener("click", () => {
      const what = b.dataset.cbsw;
      if (what === "border") {
        return swatchPop(b, b.dataset.cur, (c) => writeCells(c ? { border: c, border_width: Math.max(1, Number(q("bw").value) || 3) }
          : { border: null, border_width: null, border_sides: null }, sc(), c ? "Border" : "No border"), "No border");
      }
      swatchPop(b, b.dataset.cur, (c) => writeCells({ [what]: c }, sc(), what === "fill" ? (c ? "Fill" : "No fill of its own") : "Text colour"),
        what === "fill" ? "No fill of its own" : "The table's text colour");
    }));
    q("font").addEventListener("change", () => writeCells({ font: q("font").value || null }, sc(), "Font"));
    q("size").addEventListener("change", () => {
      const v = Number(q("size").value) || 0;
      // kept at scale 1, unrounded: shown again × the scale it is the number typed (15 stays 15)
      writeCells({ size: v > 0 ? Math.round((v / scale()) * 1000) / 1000 : null }, sc(), "Text size");
    });
    q("bold").addEventListener("click", () => writeCells({ bold: !q("bold").classList.contains("on") }, sc(), "Bold"));
    q("italic").addEventListener("click", () => writeCells({ italic: !q("italic").classList.contains("on") }, sc(), "Italic"));
    root.querySelectorAll("[data-cbalign]").forEach((b) => b.addEventListener("click", () =>
      writeCells({ align: b.classList.contains("on") ? null : b.dataset.cbalign }, sc(), "Alignment")));
    q("bw").addEventListener("change", () => { const lk = look(); if (lk.border) writeCells({ border: hex(lk.border, "#ffd54a"), border_width: Math.max(1, Number(q("bw").value) || 3) }, sc(), "Border width"); });
    // a side on / off; the first side switched on gives the boxes a border; none left: no border
    root.querySelectorAll("[data-cbside]").forEach((b) => b.addEventListener("click", () => {
      const lk = look(), s2 = b.dataset.cbside, now = lk.border ? String(lk.border_sides || "tblr") : "";
      const next = SIDES.map(([x]) => x).filter((x) => (x === s2 ? !now.includes(x) : now.includes(x))).join("");
      if (!next) return writeCells({ border: null, border_width: null, border_sides: null }, sc(), "No border");
      writeCells({ border: hex(lk.border, "#ffd54a"), border_width: Number(lk.border_width) || Math.max(1, Number(q("bw").value) || 3),
                   border_sides: next.length === 4 ? null : next }, sc(), "Border sides");
    }));
    q("fx").addEventListener("click", (ev) => {
      if (window.TypoStudio) TypoStudio.fxPicker(ev.currentTarget, boxLook(key, cells[0]).fx || "", (name) => writeCells({ fx: name || null }, sc(), "Layer style"), "None");
    });
    const z = boxSizes(cells);
    root.querySelector("[data-cbw]").addEventListener("change", (ev) => {
      const px = Number(ev.target.value) || 0;
      if (px > 0) writeSizes(Object.fromEntries(z.cols.map((c) => [c, px])), null, `Width ${px} px`);
    });
    root.querySelector("[data-cbh]").addEventListener("change", (ev) => {
      const px = Number(ev.target.value) || 0;
      if (px > 0) writeSizes(null, Object.fromEntries(z.rows.map((r) => [r, px])), `Height ${px} px`);
    });
    root.querySelectorAll("[data-cbeven]").forEach((b) => b.addEventListener("click", () => {
      if (b.dataset.cbeven === "w") {
        const avg = z.cols.reduce((a, c) => a + z.colPx(c), 0) / z.cols.length;
        writeSizes(Object.fromEntries(z.cols.map((c) => [c, avg])), null, "Even widths");
      } else {
        const avg = z.rows.reduce((a, r) => a + z.rowPx(r), 0) / z.rows.length;
        writeSizes(null, Object.fromEntries(z.rows.map((r) => [r, avg])), "Even heights");
      }
    }));
    q("drop").addEventListener("click", () => { S.drop = !S.drop; dropCursor(); if (window.TypoStudio) TypoStudio.paint(); });
    q("copy").addEventListener("click", () => copyCell());
    q("paste").addEventListener("click", (ev) => openPasteSpecial(ev.currentTarget));
    q("reset").addEventListener("click", () => writeCells(Object.fromEntries(CELL_PROPS.map((p) => [p, null])), sc(), "The table's look again"));
    q("clear").addEventListener("click", () => clearCells(!look().clear));
    const rowsOf = () => [...new Set(cells.map((ck) => rc(ck)[0]))], colsOf = () => [...new Set(cells.map((ck) => rc(ck)[1]))];
    root.querySelectorAll("[data-cbrole]").forEach((b) => b.addEventListener("click", () => {
      const [what, role] = b.dataset.cbrole.split(":");
      setRole(key, what, what === "row" ? rowsOf() : colsOf(), role);
    }));
    q("astext").addEventListener("click", () => rowsAsText(key, rowsOf()));
  }
  // what a box shows, deleted (the box stays, empty) or back from the Excel; Ctrl+Z undoes it
  function clearCells(on2) {
    writeCells({ clear: on2 ? true : null }, S.cellScope || "cell", on2 ? "Deleted" : "Restored from the Excel");
  }

  /* ------------------------------- the eyedropper ------------------------------- */
  // 💧 on: the next click on a box (any table on the page) gives the picked boxes its whole look
  function dropCursor() { const h = host(); if (h) h.classList.toggle("tbs-dropping", !!S.drop); }
  document.addEventListener("pointerdown", (ev) => {
    if (!S.drop || ev.button !== 0 || !on()) return;
    const h = host();
    if (!h || !h.contains(ev.target) || ev.target.closest(".tbs-pop2, .ts-strippop, .vis-guide")) return;
    const hit = tbv() && tbv().boxAt ? tbv().boxAt(ev) : null;
    ev.preventDefault();
    ev.stopPropagation();
    S.drop = false;
    dropCursor();
    if (!hit) { toast("No box there — the eyedropper is off."); if (window.TypoStudio) TypoStudio.paint(); return; }
    const lk = boxShown(hit.table.design_key, hit.key, hit.table);
    writeCells(Object.fromEntries(CELL_PROPS.map((p) => [p, lk[p] != null && lk[p] !== "" ? lk[p] : null])), S.cellScope || "cell", "The eyedropper's look", true);
  }, true);

  /* ----------------------------- select boxes that look the same ----------------------------- */
  function selectSame(ck, prop) {
    const key = S.sel[0], t = tableEl(key), looks = (t && t.geo && t.geo.looks) || {};
    const want = String(boxShown(key, ck, t)[prop] || "").toLowerCase();
    if (!want) { toast("That box has no " + (prop === "fill" ? "fill" : "text colour") + " to match."); return; }
    const keys = Object.keys(looks).filter((k) => String(boxShown(key, k, t)[prop] || "").toLowerCase() === want);
    if (tbv() && tbv().pickKeys) tbv().pickKeys(keys);
    toast(`${keys.length} box${keys.length === 1 ? "" : "es"} with the same ${prop === "fill" ? "fill" : "text colour"}.`);
  }

  /* ----------------------------- copy / paste a box's look ----------------------------- */
  // a box's look as it shows (its own over its row, column, header / body and the table's): the picked
  // box, or `ck` — the one right-clicked; its size (column width, row height) goes with it
  function copyCell(ck) {
    const key = S.sel[0], cells = ck ? [ck] : cellsPicked();
    if (!key || !cells) return;
    const look = boxShown(key, cells[0]);
    S.cellClip = Object.fromEntries(CELL_PROPS.filter((p) => look[p] != null && look[p] !== "").map((p) => [p, look[p]]));
    if (!Object.keys(S.cellClip).length) { S.cellClip = null; toast("This box has nothing to copy yet — its look isn't drawn here."); return; }
    const z = boxSizes([cells[0]]);
    S.cellSize = { w: z.w, h: z.h };
    toast("Copied this box's look — pick boxes in any table: Ctrl+V pastes it all, Ctrl+Shift+V lets you pick what.");
    if (window.TypoStudio) TypoStudio.paint();
  }
  // what Paste special offers: [id, label, the look's properties] — Width / Height are the box's size
  const PASTE_PARTS = [["fill", "Fill", ["fill"]], ["color", "Text colour", ["color"]], ["font", "Font", ["font"]], ["size", "Text size", ["size"]],
    ["style", "Bold / italic", ["bold", "italic"]], ["align", "Alignment", ["align"]], ["stroke", "Stroke", ["border", "border_width", "border_sides"]],
    ["fx", "Layer style", ["fx"]], ["w", "Width", []], ["h", "Height", []]];
  const PARTS_KEY = "psh.boxPasteParts";
  function partsChosen() {
    try { const v = JSON.parse(localStorage.getItem(PARTS_KEY) || "null"); if (Array.isArray(v)) return v; } catch (e) { /* private window */ }
    return PASTE_PARTS.map(([id]) => id).filter((id) => id !== "w" && id !== "h");
  }
  function openPasteSpecial(anchor) {
    if (!S.cellClip) { toast("Copy a box's look first (Copy in the Cell bar, or Ctrl+C)."); return; }
    const cells = cellsPicked();
    if (!cells) return;
    const chosen = partsChosen(), sc0 = S.cellScope || "cell";
    const chip = (id) => {
      const v = id === "w" ? (S.cellSize || {}).w : id === "h" ? (S.cellSize || {}).h : null;
      if (v) return `<span class="tbs-val">${v} px</span>`;
      const c = id === "fill" || id === "color" ? S.cellClip[id] : id === "stroke" ? S.cellClip.border : null;
      return c ? `<span class="tbs-chip mini" style="--c:${esc(hex(c, "transparent"))}"></span>` : "";
    };
    const p = popUnder(anchor || el("typoStrip"), `<div class="tsp-h">Paste the copied box — only what's ticked</div>
      <div class="tbs-parts">${PASTE_PARTS.map(([id, label]) => `<label class="tbs-check"><input type="checkbox" data-part="${id}" ${chosen.includes(id) ? "checked" : ""}> ${label} ${chip(id)}</label>`).join("")}</div>
      <div class="tsp-h">Onto</div>
      <select class="ts-style" data-onto>${CELL_SCOPES.map(([v, n]) => `<option value="${v}" ${v === sc0 ? "selected" : ""}>${n === "These boxes" ? (cells.length > 1 ? `The ${cells.length} picked boxes` : "The picked box") : n}</option>`).join("")}</select>
      <div class="tbs-actions"><button class="pt-btn secondary small" data-x>Cancel</button><button class="pt-btn small" data-go>Paste</button></div>`, "tbs-special");
    p.querySelector("[data-x]").addEventListener("click", hidePops);
    p.querySelector("[data-go]").addEventListener("click", () => {
      const parts = [...p.querySelectorAll("[data-part]:checked")].map((x) => x.dataset.part);
      const sc = p.querySelector("[data-onto]").value;
      hidePops();
      try { localStorage.setItem(PARTS_KEY, JSON.stringify(parts)); } catch (e) { /* private window */ }
      pasteParts(parts, sc);
    });
  }
  // the ticked parts of the copied look (exactly: what the copy doesn't set, those boxes don't keep)
  async function pasteParts(parts, sc) {
    const cells = cellsPicked();
    if (!S.cellClip || !cells || !parts.length) return;
    const props = PASTE_PARTS.filter(([id]) => parts.includes(id)).flatMap(([, , ps]) => ps);
    if (props.length) {
      const patch = Object.fromEntries(props.map((pr) => [pr, S.cellClip[pr] != null ? S.cellClip[pr] : null]));
      const names = PASTE_PARTS.filter(([id, , ps]) => parts.includes(id) && ps.length).map(([, n]) => n.toLowerCase()).join(", ");
      await writeCells(patch, sc, `Pasted ${names}`, false);
    }
    const z = boxSizes(cells), size = S.cellSize || {};
    const cols = parts.includes("w") && size.w ? Object.fromEntries(z.cols.map((c) => [c, size.w])) : null;
    const rows = parts.includes("h") && size.h ? Object.fromEntries(z.rows.map((r) => [r, size.h])) : null;
    if (cols || rows) await writeSizes(cols, rows, "Pasted the box size");
  }
  // the whole copied look onto the picked boxes (or `onto`: boxes given), their row(s), column(s)…
  function pasteCell(sc, onto) {
    if (!S.cellClip) { toast("Copy a box's look first (right-click a box → Copy this box's look, or Ctrl+C)."); return; }
    const patch = Object.fromEntries(CELL_PROPS.map((p) => [p, S.cellClip[p] != null ? S.cellClip[p] : null]));
    writeCells(patch, sc || "cell", "Pasted the box look", true, onto);
  }

  /* ------------------------------ on the page ------------------------------ */
  const pageTables = () => (AppLive.state.elements || []).filter((x) => x.kind === "table" && x.design_key);
  function hideBoxes() { document.querySelectorAll(".tbs-box").forEach((n) => n.remove()); }
  function hideMenus() { document.querySelectorAll(".tbs-menu, .tbs-paste, #visPartMenu").forEach((n) => n.remove()); }
  function sync() {
    hideBoxes();
    if (!on() || !S.sel.length) return;
    const h = host(), c = canvas();
    if (!h || !c) return;
    const k = c.getBoundingClientRect().width / AppLive.state.data.canvas_w, cr = c.getBoundingClientRect(), hr = h.getBoundingClientRect();
    // the one with the Tables editor's handles on it (✎ ✥ corners ✂) needs no frame of its own
    const handled = window.AppTblVis && AppTblVis.typoActive && AppTblVis.typoActive() ? AppTblVis.state.selId : null;
    pageTables().filter((e) => S.sel.includes(e.design_key) && e.id !== handled).forEach((e) => {
      const ov = e.ov || {}, x = e.x + (Number(ov.x) || 0), y = e.y + (Number(ov.y) || 0);
      const box = document.createElement("div");
      box.className = "tbs-box";
      Object.assign(box.style, { left: (cr.left - hr.left + x * k) + "px", top: (cr.top - hr.top + y * k) + "px", width: (e.w * k) + "px", height: (e.h * k) + "px" });
      box.innerHTML = `<span class="ics-tag">▦ ${esc(nameOf(e.design_key))}</span>`;
      h.appendChild(box);
    });
  }
  function select(keys, picked) {
    if (keys.join("\n") !== S.sel.join("\n")) S.gear = false;   // another table: its bar starts closed
    S.sel = keys.slice();
    if (S.scope === "sel" || !S.sel.length) S.scope = "sel";
    // the table (or part) clicked gets the Tables editor's handles: ✎ its bar, ✥ move, corners / sides
    // to size it, row and column lines, double-click a box, ✂ at its edges (table-preview.js)
    if (window.AppTblVis && AppTblVis.pickInTypo) {
      if (picked && S.sel.includes(picked.design_key)) AppTblVis.pickInTypo(picked);
      else if (!S.sel.includes(AppTblVis.state.selKey)) AppTblVis.clearTypo();
    }
    sync();
    if (S.sel.length && window.TypoStudio) TypoStudio.setTarget("table");
    info().then(() => { sync(); if (window.TypoStudio && TypoStudio.target === "table") TypoStudio.paint(); });
  }
  function deselect() {
    if (window.AppTblVis && AppTblVis.clearTypo) AppTblVis.clearTypo();
    S.drop = false;
    dropCursor();
    hidePops();
    if (!S.sel.length) return;
    S.sel = [];
    S.gear = false;
    hideBoxes();
    hideMenus();
    if (window.TypoStudio && TypoStudio.target === "table") TypoStudio.paint();
  }
  function tableUnder(ev) {
    const c = canvas();
    if (!c || !AppLive.tableAt) return null;
    const r = c.getBoundingClientRect();
    return AppLive.tableAt(c, ev.clientX - r.left, ev.clientY - r.top);
  }
  // a click on the Typography page: a table is selected (Shift+click: one more / one less)
  function clickTypo(ev) {
    if (!on()) return false;
    hideMenus();
    const e = tableUnder(ev);
    if (!e || !e.design_key) { deselect(); return false; }
    if (window.IconStudio) IconStudio.deselect();
    const k = e.design_key;
    if (ev.shiftKey && S.sel.length) select(S.sel.includes(k) ? S.sel.filter((x) => x !== k) : S.sel.concat([k]), e);
    else select([k], e);
    // an icon clicked: its box picked, the Icon bar (its size here, in the table, in every table…)
    const hit = !ev.shiftKey && tbv() && tbv().iconAt ? tbv().iconAt(ev) : null;
    S.icon = hit && hit.table.design_key === k ? { tok: hit.tok, name: hit.name, cell: hit.cell } : null;
    if (S.icon && tbv().pickInTypo && tbv().pickKeys) { tbv().pickInTypo(hit.table); tbv().pickKeys([hit.cell]); }
    return true;
  }
  /* right-click a table: the Tables part menu (next / previous page, join the parts, put back) with
     copy / paste style on top — one menu */
  function contextMenu(ev) {
    if (!on()) return false;
    const e = tableUnder(ev);
    if (!e || !e.design_key) return false;
    ev.preventDefault();
    if (!S.sel.includes(e.design_key)) select([e.design_key], e);
    hideMenus();
    const ck = tbv() && tbv().cellKeyAt ? tbv().cellKeyAt(ev) : null;     // the box right-clicked
    const h = host(), c = canvas();
    // after the change the page follows the table (or part): sent to the next page, it is shown there
    const refresh = async () => {
      if (!window.AppTypoVis) return;
      await AppTypoVis.refreshPreview.now(true);
      // by its table and part number (two tables side by side on the same Excel rows share an id)
      const part = (x) => (x.cut && x.cut.pi) || 0;
      const pi = (AppLive.state.pages || []).findIndex((pg) => (pg.elements || []).some((x) =>
        x.kind === "table" && x.design_key === e.design_key && part(x) === part(e)));
      if (pi >= 0 && pi !== AppTypoVis.state.page) AppTypoVis.showPage(pi);
    };
    let m = AppLive.tablePartMenu && AppLive.tablePartMenu(ev, h, c, refresh) ? el("visPartMenu") : null;
    const [ckR, ckC] = ck ? rc(ck) : [0, 0];
    const rRole = ck ? roleOf(e.design_key, "row", [ckR], e) : null, cRole = ck ? roleOf(e.design_key, "col", [ckC], e) : null;
    const boxItems = ck ? `<button data-m="ccopy">Copy this box's look</button>
      <button data-m="cpaste" ${S.cellClip ? "" : "disabled"}>Paste box look onto this box</button>
      <button data-m="cpasterow" ${S.cellClip ? "" : "disabled"}>… onto its whole row</button>
      <button data-m="cpastecol" ${S.cellClip ? "" : "disabled"}>… onto its whole column</button>
      ${boxLook(e.design_key, ck).clear
        ? `<button data-m="crestore">↺ Restore this box (the Excel's text)</button>`
        : `<button data-m="cdel">🗑 Delete this box <span class="tbs-key">Del</span></button>
           <button data-m="cdelrow">🗑 Delete its whole row</button>
           <button data-m="cdelcol">🗑 Delete its whole column</button>`}
      <div class="vpm-sep"></div>
      <button data-m="astext">¶ Treat its row as normal text</button>
      <div class="vpm-row"><span>Its row</span>${[["", "Auto"], ["header", "Header"], ["body", "Normal"]].map(([v, n]) =>
        `<button data-m="role:row:${v}" class="${rRole === v ? "vpm-on" : ""}">${n}</button>`).join("")}</div>
      <div class="vpm-row"><span>Its column</span>${[["", "Auto"], ["header", "Header"], ["body", "Normal"]].map(([v, n]) =>
        `<button data-m="role:col:${v}" class="${cRole === v ? "vpm-on" : ""}">${n}</button>`).join("")}</div>
      <div class="vpm-sep"></div>
      <button data-m="samefill">Select boxes with the same fill</button>
      <button data-m="samecolor">Select boxes with the same text colour</button>
      <div class="vpm-sep"></div>` : "";
    const ours = `${boxItems}<button data-m="copy">Copy table style <span class="tbs-key">Ctrl+C</span></button>
      <button data-m="paste" ${S.clip ? "" : "disabled"}>Paste table style… <span class="tbs-key">Ctrl+V</span></button>
      <button data-m="all">Select every table on this page</button>
      <div class="vpm-sep"></div>`;
    if (m) {
      const head = m.querySelector(".vpm-head");
      if (head) { head.textContent = "▦ " + nameOf(e.design_key) + (head.textContent.startsWith("Table part") ? " · " + head.textContent.replace(/^Table /, "") : ""); head.insertAdjacentHTML("afterend", ours); }
    } else {
      m = document.createElement("div");
      m.className = "tsel-menu tbs-menu";
      m.innerHTML = `<div class="vpm-head">▦ ${esc(nameOf(e.design_key))}</div>${ours.replace(/<div class="vpm-sep"><\/div>$/, "")}`;
      ["mousedown", "pointerdown", "click", "dblclick", "contextmenu", "wheel"].forEach((t) => m.addEventListener(t, (x) => x.stopPropagation()));
      h.appendChild(m);
      setTimeout(() => document.addEventListener("mousedown", hideMenus, { once: true }), 0);
    }
    m.classList.add("tbs-menu");
    const hr = h.getBoundingClientRect();
    m.style.left = Math.max(4, Math.min(h.clientWidth - m.offsetWidth - 4, ev.clientX - hr.left)) + "px";
    m.style.top = Math.max(4, Math.min(h.clientHeight - m.offsetHeight - 4, ev.clientY - hr.top)) + "px";
    m.querySelectorAll("[data-m]").forEach((b) => b.addEventListener("click", () => {
      const a = b.dataset.m;
      m.remove();
      if (a === "ccopy") copyCell(ck);
      else if (a === "cpaste") pasteCell("cell", [ck]);
      else if (a === "cpasterow") pasteCell("row", [ck]);
      else if (a === "cpastecol") pasteCell("col", [ck]);
      else if (a === "cdel" || a === "cdelrow" || a === "cdelcol" || a === "crestore") {
        // the picked boxes when it is one of them, else this box
        const picked = cellsPicked() || [], onto = picked.includes(ck) ? picked : [ck];
        const sc = a === "cdelrow" ? "row" : a === "cdelcol" ? "col" : "cell";
        writeCells({ clear: a === "crestore" ? null : true }, sc, a === "crestore" ? "Restored from the Excel" : "Deleted", false, onto);
      }
      else if (a === "astext") rowsAsText(e.design_key, [ckR], e);
      else if (a.startsWith("role:")) { const [, what, role] = a.split(":"); setRole(e.design_key, what, [what === "row" ? ckR : ckC], role, e); }
      else if (a === "samefill") selectSame(ck, "fill");
      else if (a === "samecolor") selectSame(ck, "color");
      else if (a === "copy") copy(e.design_key);
      else if (a === "paste") openPaste(ev);
      else if (a === "all") select([...new Set(pageTables().map((x) => x.design_key))], e);
    }));
    return true;
  }
  // Ctrl+C / Ctrl+V with tables selected (typo-preview.js passes the key presses on)
  function onKey(ev) {
    if (on() && S.sel.length && cellsPicked() && (ev.key === "Delete" || ev.key === "Backspace") && !ev.ctrlKey && !ev.metaKey) {
      clearCells(true);                                    // boxes picked: Delete empties them
      return true;
    }
    if (!on() || !S.sel.length || !(ev.ctrlKey || ev.metaKey)) return false;
    const k = ev.key.toLowerCase();
    if (cellsPicked()) {                                   // boxes picked: their look, straight onto them
      if (k === "c") { copyCell(); return true; }
      if (k === "v" && ev.shiftKey) { openPasteSpecial(document.querySelector('#typoStrip [data-cb="paste"]')); return true; }
      if (k === "v") { pasteCell("cell"); return true; }
      return false;
    }
    if (k === "c") { copy(S.sel[0]); return true; }
    if (k === "v") { openPaste(null); return true; }
    return false;
  }

  // the boxes picked in the selected table changed (table-preview.js): the top bar follows
  function showCells() {
    S.gear = false;
    S.drop = false;                                       // the eyedropper is for the boxes it was switched on for
    dropCursor();
    hidePops();                                       // the Table bar's pop-over goes with its bar
    if (window.TypoStudio && S.sel.length) { if (TypoStudio.target !== "table") TypoStudio.setTarget("table"); else TypoStudio.paint(); }
  }
  // the picked icon's corner dragged (table-preview.js): its size × f at the Icon bar's reach
  function iconScaleBy(f) { if (S.icon) setIconPx(drawnIconPx() * f); }
  return { clickTypo, contextMenu, onKey, deselect, sync, barHtml, wireBar, copy, openPaste, showCells, iconScaleBy,
           selected: () => S.sel.slice(), state: S };
})();
