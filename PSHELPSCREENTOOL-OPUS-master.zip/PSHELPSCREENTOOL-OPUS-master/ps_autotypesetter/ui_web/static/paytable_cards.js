/* Paytable card studio (the default Paytable view) — everything is edited ON the preview.

   Left: pick a design (5 built-ins that never change, or your copies), show/hide parts,
   Save as copy. Preview (sticky):
     Title       sits where every other page's heading is; ✎ plate look, ↔ plate width
     WILD / SCATTER boxes and text boxes
                 free: drag anywhere, resize from the edges/corner, ✎ look / text
                 (text boxes: move a line to another box, hide an icon in a line)
     Cards       the master bound — only the high + low cards. It fills the space
                 the other parts leave and never overlaps them. ✎ card look and
                 "Customise card" (symbol, counts, pays, extra text, card size),
                 ↔ / ↕ card size, − / + cards per row
     Page        dashed edges = margins
   When numbers don't fit their cards the studio asks: shrink the numbers or grow the cards.
   Changes apply to the game (dynamic_settings.paytable_card_template) and re-render
   with the real renderer; Ctrl+Z / Ctrl+Y undo and redo.
   Uses app.js globals (App, api, esc, toast, icon, debounce). */
(() => {
  "use strict";
  const PC = (window.PaytableCards = {});
  const S = { list: [], tpl: null, baseId: "", dirty: false, sheet: "", token: "", busy: false, error: "",
              blocks: {}, canvas: null, counts: {}, fit: 1, texts: [], wildText: {}, overflow: [],
              pop: "", editor: null, sel: 0, undo: [], redo: [], asked: "", splitting: "", textInfo: {}, editing: "", picked: [], symSel: "", isolated: "", iconEdit: "", iconIso: "", featSel: "", liveIcons: [] };
  // the design frame: the page's own shape, 1920 wide (the server's card_templates.design_frame)
  const DW = () => Number((S.canvas || {}).dw) || 1920, DH = () => Number((S.canvas || {}).dh) || 1080;

  const sheets = () => (App.state.scan?.excel?.sheets || []).map((s) => s.name).filter(Boolean)
    .filter((n) => /pay\s*table/i.test(n));
  const lib = () => Object.keys((App.state.config.dynamic_settings || {}).layer_style_library || {}).sort();
  const get = (path, o = S.tpl) => path.split(".").reduce((x, k) => (x == null ? undefined : x[k]), o);
  function put(path, v, o = S.tpl) {
    const keys = path.split(".");
    let x = o;
    keys.slice(0, -1).forEach((k) => { if (x[k] == null || typeof x[k] !== "object") x[k] = {}; x = x[k]; });
    x[keys[keys.length - 1]] = v;
  }
  const label = (k) => k === "high" ? "Top cards" : k === "low" ? "Bottom cards"
    : String(k).startsWith("band:") ? `${String(k).endsWith("1") ? "Bottom" : "Top"} cards look`
    : k === "title" ? "Title" : k === "wild" ? "WILD box" : k === "scatter" ? "SCATTER box"
    : k === "cards" ? "Cards" : k === "wildtext" ? "WILD text" : k === "numbers" ? "Pays & values" : k === "cardlook" ? "Card look" : k === "page" ? "Page" : k.startsWith("text:") ? "Text" : k;

  /* ---------- edits + undo ---------- */
  let lastKey = "", lastAt = 0;
  // a design from the old fixed 1920 x 1080 frame comes back moved to the page's frame (once): go on from that
  let framed = null;
  function adoptFrame(sent, d) {
    if (!d || !d.template || d.template.frame !== "page") return;
    framed = { from: sent, to: JSON.stringify(d.template) };
    if (S.tpl && S.tpl.frame !== "page" && JSON.stringify(S.tpl) === sent) S.tpl = JSON.parse(framed.to);
  }
  function edit(fn, key = "") {               // one undo step per action (typing one field = one step)
    if (S.tpl && S.tpl.frame !== "page" && framed && JSON.stringify(S.tpl) === framed.from) S.tpl = JSON.parse(framed.to);   // edits are page-frame px
    if (S.dragLive) {                           // mid-drag: a preview of the change, not a step yet
      fn();
      PC.live();
      return;
    }
    const now = Date.now();
    if (!(key && key === lastKey && now - lastAt < 900)) {
      S.undo.push(JSON.stringify(S.tpl));
      if (S.undo.length > 80) S.undo.shift();
      S.redo = [];
    }
    lastKey = key; lastAt = now;
    fn();
    S.dirty = true;
    S.tpl.edited = true;
    S.editSeq = (S.editSeq || 0) + 1;
    PC.live();
    PC.apply();
  }
  const set = (path, v) => edit(() => put(path, v), path);
  function step(from, to) {
    if (!from.length) return;
    to.push(JSON.stringify(S.tpl));
    S.tpl = JSON.parse(from.pop());
    S.dirty = true;
    lastKey = "";
    rerender();
    PC.apply();
  }
  PC.undo = () => step(S.undo, S.redo);
  PC.redo = () => step(S.redo, S.undo);

  /* the image's fractions <-> design px (the page-shaped design frame, contain-scaled into the canvas) */
  function toDesign(fx, fy) {
    const c = S.canvas || { width: DW(), height: DH(), scale: 1 };
    const ox = (c.width - DW() * c.scale) / 2, oy = (c.height - DH() * c.scale) / 2;
    return [(fx * c.width - ox) / c.scale, (fy * c.height - oy) / c.scale];
  }
  function rectOf(key) {                       // a block's box as [x, y, w, h] in design px
    const b = S.blocks[key];
    if (!b) return null;
    const [x0, y0] = toDesign(b[0], b[1]), [x1, y1] = toDesign(b[2], b[3]);
    return [Math.round(x0), Math.round(y0), Math.round(x1 - x0), Math.round(y1 - y0)];
  }
  /* free parts get explicit boxes the first time anything free is edited, so nothing jumps */
  function pinFree() {
    const tab = get("features.tab.enabled") !== false ? Number(get("features.tab_h") || 56) : 0;
    ["wild", "scatter"].forEach((b) => {
      const r = rectOf(b);
      if (r && !get(`features.${b}_box.rect`)) put(`features.${b}_box.rect`, [r[0], r[1] + tab / 2, r[2], r[3] - tab / 2]);
    });
    if (!(get("page.texts") || []).length && S.texts.length) {
      const notes = get("page.notes") || {};
      put("page.texts", S.texts.map((t, i) => ({ id: t.id, rect: rectOf(`text:${t.id}`), rest: i === 0,
        ...(i === 0 ? { font_size: notes.font_size, color: notes.color, align: notes.align } : {}) })));
    }
  }
  const textIndex = (id) => (get("page.texts") || []).findIndex((t) => String(t.id) === String(id));

  /* ---------- text boxes: edited like a document ---------- */
  const textOf = (id) => ((S.texts.find((t) => String(t.id) === String(id)) || {}).text) || "";
  // the text of every box, edited for THIS Excel text (another market's text gets its own edits)
  function textEdits() {
    const h = S.textInfo.hash || "none";
    const all = Object.assign({}, get("page.text_edits") || {});
    const mine = Object.assign({}, all[h] || Object.fromEntries(S.texts.map((t) => [String(t.id), t.text || ""])));
    return { all, mine, h };
  }
  function saveTexts(change) {
    edit(() => {
      pinFree();
      const { all, mine, h } = textEdits();
      change(mine);
      all[h] = mine;
      put("page.text_edits", all);
    });
  }
  function newBoxRect(fromId) {
    const r = (get("page.texts") || [])[textIndex(fromId)]?.rect || [100, 300, 600, 120];
    const w = Math.min(r[2], 700), hgt = 120;
    let y = r[1] + r[3] + 20;
    if (y + hgt > DH() - 20) y = Math.max(20, r[1] - hgt - 20);
    return [r[0], Math.round(y), Math.round(w), hgt];
  }
  /* the selected text and what's left, without the empty line or double space it would leave behind */
  function cutSelection(area) {
    const a = area.selectionStart, b = area.selectionEnd;
    const picked = area.value.slice(a, b).trim();
    let head = area.value.slice(0, a), tail = area.value.slice(b);
    if (/\n\s*$/.test(head) && /^\s*\n/.test(tail)) tail = tail.replace(/^\s*\n/, "");      // a whole line went
    else if (/ $/.test(head) && /^ /.test(tail)) tail = tail.slice(1);                      // part of a line went
    const rest = (head.replace(/[ \t]+$/, head.endsWith("\n") ? "" : head.match(/[ \t]+$/)?.[0] || "") + tail)
      .replace(/^\n+|\n+$/g, "");
    return { picked, rest };
  }
  function moveSelectionToNewBox(fromId, area) {
    const { picked, rest } = cutSelection(area);
    if (!picked) return;
    const id = `t${Date.now() % 1000000}`;
    saveTexts((mine) => {
      mine[fromId] = rest;
      mine[id] = picked;
      const src = (get("page.texts") || [])[textIndex(fromId)] || {};
      get("page.texts").push({ id, rect: newBoxRect(fromId), font_size: src.font_size, color: src.color, align: src.align || "center" });
    });
    S.editing = "";
    toast("Moved to a new text box — drag it where you want it.");
  }
  function mergeBoxes(keys) {
    const ids = keys.map((k) => k.slice(5)).filter((id) => textIndex(id) >= 0);
    if (ids.length < 2) return;
    const texts = () => get("page.texts");
    saveTexts((mine) => {
      // top-most box keeps the text, in reading order
      ids.sort((x, y) => (texts()[textIndex(x)].rect[1] - texts()[textIndex(y)].rect[1]) || (texts()[textIndex(x)].rect[0] - texts()[textIndex(y)].rect[0]));
      const keep = ids[0];
      mine[keep] = ids.map((id) => (mine[id] ?? textOf(id))).filter((t) => t && t.trim()).join("\n");
      const rs = ids.map((id) => texts()[textIndex(id)].rect);
      const x0 = Math.min(...rs.map((r) => r[0])), y0 = Math.min(...rs.map((r) => r[1]));
      const x1 = Math.max(...rs.map((r) => r[0] + r[2])), y1 = Math.max(...rs.map((r) => r[1] + r[3]));
      texts()[textIndex(keep)].rect = [x0, y0, x1 - x0, y1 - y0];
      ids.slice(1).forEach((id) => { delete mine[id]; texts().splice(textIndex(id), 1); });
    });
    S.picked = [];
    toast("Text boxes merged.");
  }
  function deleteBox(id) {
    saveTexts((mine) => {
      const first = String((get("page.texts")[0] || {}).id);
      if (first !== id) mine[first] = [mine[first] ?? textOf(first), mine[id] ?? textOf(id)].filter((t) => t && t.trim()).join("\n");
      delete mine[id];
      get("page.texts").splice(textIndex(id), 1);
    });
  }
  function showMenu(x, y, items) {
    const m = document.getElementById("pcMenu"), st = document.getElementById("pcStage").getBoundingClientRect();
    if (!m) return;
    m.innerHTML = items.map((it, i) => it ? `<button data-mi="${i}" ${it.disabled ? "disabled" : ""}>${esc(it.label)}</button>` : `<hr>`).join("");
    Object.assign(m.style, { left: `${Math.min(x - st.left, st.width - 230)}px`, top: `${y - st.top}px` });
    m.hidden = false;
    m.querySelectorAll("[data-mi]").forEach((b) => b.addEventListener("mousedown", (e) => {
      e.preventDefault();
      m.hidden = true;
      items[Number(b.dataset.mi)].run();
    }));
    const close = (e) => { if (!m.contains(e.target)) { m.hidden = true; document.removeEventListener("mousedown", close, true); } };
    setTimeout(() => document.addEventListener("mousedown", close, true), 0);
  }
  function openEditorFor(id) {
    S.pop = "";
    S.picked = [];
    S.editing = id;
    rerenderStage();
  }
  function wireTextEditor() {
    const ted = document.getElementById("pcTed"), area = document.getElementById("pcTedArea");
    if (!ted || !area) return;
    const owner = document.querySelector(`.pcb[data-b="text:${CSS.escape(S.editing)}"]`);
    if (owner) {
      Object.assign(ted.style, { left: owner.style.left, top: owner.style.top,
        width: `${Math.max(320, parseFloat(owner.style.width))}px` });
      area.style.minHeight = `${Math.max(110, parseFloat(owner.style.height) - 30)}px`;
    }
    area.focus();
    const done = () => {
      const id = S.editing, val = area.value.replace(/\s+$/g, "");
      S.editing = "";
      if (val !== textOf(id)) saveTexts((mine) => { mine[id] = val; });
      else rerenderStage();
    };
    document.getElementById("pcTedDone").addEventListener("click", done);
    area.addEventListener("keydown", (e) => { if (e.key === "Escape") { e.preventDefault(); done(); } });
    area.addEventListener("contextmenu", (e) => {
      const hasSel = area.selectionEnd > area.selectionStart && area.value.slice(area.selectionStart, area.selectionEnd).trim();
      e.preventDefault();
      const others = S.texts.filter((t) => String(t.id) !== S.editing);
      showMenu(e.clientX, e.clientY, [
        { label: "Move selection to a new text box", disabled: !hasSel, run: () => moveSelectionToNewBox(S.editing, area) },
        ...others.map((t, i) => ({ label: `Move selection to text box ${S.texts.indexOf(t) + 1}`, disabled: !hasSel, run: () => {
          const { picked, rest } = cutSelection(area);
          const from = S.editing;
          S.editing = "";
          saveTexts((mine) => { mine[from] = rest; mine[String(t.id)] = [mine[String(t.id)] ?? t.text, picked].filter(Boolean).join("\n"); });
        } })),
        null,
        { label: "Cut", disabled: !hasSel, run: () => { area.focus(); document.execCommand("cut"); } },
        { label: "Copy", disabled: !hasSel, run: () => { area.focus(); document.execCommand("copy"); } },
        { label: "Back to the Excel text", run: () => { S.editing = ""; resetTexts(); } },
      ]);
    });
    area.addEventListener("pointerdown", (e) => e.stopPropagation());
    ted.addEventListener("pointerdown", (e) => e.stopPropagation());
  }
  function resetTexts() {
    edit(() => {
      const all = Object.assign({}, get("page.text_edits") || {});
      delete all[S.textInfo.hash || "none"];
      put("page.text_edits", all);
    });
    toast("Back to the Excel text — all of it is in the first text box.");
  }

  /* ---------- rows: the top row (above ACE) and the bottom row are separate boxes ---------- */
  // a row's cards get wider / taller; what is inside them (symbol, numbers) keeps its size, centred.
  // (The card can't get smaller than its content: the layout grows it back to fit.)
  // the row as one picture: card size, the numbers' fonts and the spacing all × f (parts are
  // fractions of the card, so symbols and boxes follow by themselves); the opposite corner stays
  function scaleRow(i, f, corner, rect) {
    const ps = ownParts(i, true), b = get("bands")[i], [w, h] = cardSize(i);
    const fonts = (p) => {
      if (p.font_size) p.font_size = Math.max(4, Math.round(Number(p.font_size) * f * 10) / 10);
      if (p.line_height) p.line_height = Math.max(4, Math.round(Number(p.line_height) * f));
    };
    ps.forEach(fonts);
    const ov = get("card_overrides") || {};
    Object.keys(ov).forEach((name) => { if (cardBand(name) === i) ((ov[name] || {}).parts || []).forEach(fonts); });
    b.card_w = Math.max(30, Math.round(w * f));
    b.card_h = Math.max(20, Math.round(h * f));
    ["gap_x", "gap_y"].forEach((g) => { b[g] = Math.max(0, Math.round(Number(b[g] ?? get(`page.${g}`) ?? (g === "gap_x" ? 24 : 20)) * f)); });
    if (b.pos && rect) {                           // a placed row keeps the corner opposite the one dragged
      const nw = rect[2] * f, nh = rect[3] * f;
      b.pos = [Math.round(corner[1] === "l" ? rect[0] + rect[2] - nw : rect[0]), Math.round(corner[0] === "t" ? rect[1] + rect[3] - nh : rect[1])];
    }
  }
  function resizeRow(i, nw, nh) {
    const [w, h] = cardSize(i), b = get("bands")[i];
    const keep = (ps) => ps.forEach((p) => {
      if (nw != null) { p.w = r3((+p.w || 1) * w / nw); p.x = r3(((+p.x || 0) * w + (nw - w) / 2) / nw); }
      if (nh != null) { p.h = r3((+p.h || 1) * h / nh); p.y = r3(((+p.y || 0) * h + (nh - h) / 2) / nh); }
    });
    keep(ownParts(i, true));
    const ov = get("card_overrides") || {};
    Object.keys(ov).forEach((name) => { if (cardBand(name) === i && (ov[name] || {}).parts) keep(ov[name].parts); });   // cards with their own design too
    if (nw != null) b.card_w = nw;
    if (nh != null) b.card_h = nh;
  }
  const rowIdx = (k) => (k === "low" ? 1 : 0);
  const rowKey = (i) => (i ? "low" : "high");
  const bandFit = (i) => Number(((S.bandGeo || {})[rowKey(i)] || {}).fit) || S.fit || 1;
  function rowCount(k) {                        // cards in this row, as laid out
    const r = S.blocks[k];
    if (!r) return 0;
    return Object.keys(S.blocks).filter((c) => {
      if (!c.startsWith("card:")) return false;
      const b = S.blocks[c], cx = (b[0] + b[2]) / 2, cy = (b[1] + b[3]) / 2;
      return cx >= r[0] && cx <= r[2] && cy >= r[1] && cy <= r[3];
    }).length;
  }

  /* locks: locked cards keep their area whatever moves around them; locked boxes can't be moved by accident */
  function locked(k) {
    if (k === "cards") return !!get("page.cards_lock");
    if (k === "high" || k === "low") { const b = (get("bands") || [])[rowIdx(k)] || {}; return b.locked === true || (b.locked === undefined && !!b.lock_size); }
    if (k === "wild" || k === "scatter") return !!get(`features.${k}_box.locked`);
    if (k.startsWith("text:")) { const i = textIndex(k.slice(5)); return i >= 0 && !!get(`page.texts.${i}.locked`); }
    return false;
  }
  function toggleLock(k) {
    const on = !locked(k);
    edit(() => {
      pinFree();
      if (k === "high" || k === "low") {
        // a locked row keeps its place and size; its cards scale to stay inside
        const b = get("bands")[rowIdx(k)], r = rectOf(k);
        if (on && r) { b.pos = [r[0], r[1]]; b.lock_size = [r[2], r[3]]; } else delete b.lock_size;
        b.locked = on;
      } else if (k === "cards") {
        // the box you see is what locks (its drag offset is baked in); unlocking keeps it where it is
        const pg = get("page");
        if (on) { const r = rectOf("cards"); if (r) { put("page.cards_lock", r); delete pg.cards_offset; delete pg.cards_at; } }
        else { const r = pg.cards_lock; delete pg.cards_lock; if (r) put("page.cards_at", [r[0], r[1]]); }
      } else if (k === "wild" || k === "scatter") put(`features.${k}_box.locked`, on);
      else { const i = textIndex(k.slice(5)); if (i >= 0) put(`page.texts.${i}.locked`, on); }
    });
    const rowish = k === "cards" || k === "high" || k === "low";
    toast(on ? `${label(k)} locked — ${rowish ? "the box stays put and never grows: bigger content scales to fit inside it" : "it can't be moved until you unlock it"}.` : `${label(k)} unlocked.`);
  }
  const lockBtn = (k) => `<button class="pcb-lock ${locked(k) ? "on" : ""}" data-lock="${esc(k)}" title="${locked(k) ? "Locked — click to unlock" : "Lock position"}">${locked(k) ? "🔒" : "🔓"}</button>`;

  /* a band's look: its own style the first time it's edited if the other band shares it */
  function bandStyle(i) {
    const bands = get("bands") || [];
    const name = (bands[i] || {}).style || "card";
    if (!bands.some((b, j) => j !== i && (b.style || "card") === name)) return name;
    const own = i ? "low_card" : "high_card";
    const styles = get("styles");
    if (!styles[own]) styles[own] = JSON.parse(JSON.stringify(styles[name] || {}));
    bands[i].style = own;
    return own;
  }

  /* ---------- small controls ---------- */
  const row = (lbl, input) => `<label class="pcp-row"><span>${esc(lbl)}</span>${input}</label>`;
  const colorIn = (path, v) => `<input type="color" data-k="${path}" value="${esc(v || "#ffffff")}">`;
  const rangeIn = (path, v, min, max) => `<input type="range" data-k="${path}" data-num min="${min}" max="${max}" step="1" value="${esc(v ?? 0)}"><output>${esc(v ?? 0)}</output>`;
  const numIn = (path, v, min, max) => `<input type="number" data-k="${path}" data-num min="${min}" max="${max}" value="${esc(v ?? "")}" style="width:70px">`;
  const toggleIn = (path, v) => `<label class="switch small"><input type="checkbox" data-k="${path}" data-bool ${v ? "checked" : ""}><span class="track"></span></label>`;
  const selectIn = (path, v, opts) => `<select data-k="${path}">${opts.map(([o, t]) => `<option value="${esc(o)}" ${String(o) === String(v ?? "") ? "selected" : ""}>${esc(t)}</option>`).join("")}</select>`;

  function lookControls(styleName, title, band = -1) {
    const p = `styles.${styleName}`;
    const st = get(p) || {};
    const pill = String(st.radius) === "pill";
    const stroke = st.stroke || {};
    const b = band >= 0 ? ` data-band="${band}"` : "";
    const tag = (html) => html.replace(/data-k="/g, `${b} data-k="`);
    return tag(`<div class="pcp-sub">${esc(title)}</div>
      ${row("Fill", `${toggleIn(`${p}.fill_enabled`, st.fill_enabled !== false)} ${colorIn(`${p}.fill`, st.fill)}`)}
      ${row("Opacity", rangeIn(`${p}.fill_opacity`, st.fill_opacity ?? 100, 0, 100))}
      ${row("Corners", pill ? `<span class="pcp-note">fully round</span>` : rangeIn(`${p}.radius`, Number(st.radius) || 0, 0, 80))}
      ${row("Round ends", `<label class="switch small"><input type="checkbox" data-pill="${p}"${b} ${pill ? "checked" : ""}><span class="track"></span></label>`)}
      ${row("Border", `${toggleIn(`${p}.stroke.enabled`, !!stroke.enabled)} ${colorIn(`${p}.stroke.color`, stroke.color)}`)}
      ${stroke.enabled ? row("Border width", rangeIn(`${p}.stroke.width`, stroke.width || 2, 1, 20)) : ""}
      ${row("Layer style", selectIn(`${p}.fx`, st.fx || "", [["", "None"]].concat(lib().map((n) => [n, n]))))}`);
  }
  function textControls(p, title, withAlign = true) {
    const t = get(p) || {};
    return `<div class="pcp-sub">${esc(title)}</div>
      ${row("Size", rangeIn(`${p}.font_size`, t.font_size || 26, 8, 140))}
      ${row("Colour", colorIn(`${p}.color`, t.color))}
      ${withAlign ? row("Align", selectIn(`${p}.align`, t.align || "center", [["left", "Left"], ["center", "Centre"], ["right", "Right"]])) : ""}
      ${fontControls(p, t)}`;
  }
  // font, bold, italic and a layer style from the library — for any text the artist styles
  function fontControls(p, t = get(p) || {}) {
    const fonts = (App.state.fonts || []).slice().sort((a, b) => String(a).localeCompare(String(b)));
    if (t.font && !fonts.includes(t.font)) fonts.unshift(t.font);
    return `${row("Font", selectIn(`${p}.font`, t.font || "", [["", "Default (Canvas)"]].concat(fonts.map((f) => [f, f]))))}
      ${row("Bold", toggleIn(`${p}.bold`, !!t.bold))}
      ${row("Italic", toggleIn(`${p}.italic`, !!t.italic))}
      ${row("Layer style", selectIn(`${p}.fx`, t.fx || "", [["", "None"]].concat(lib().map((n) => [n, n]))))}`;
  }
  const iconKey = (tk) => String(tk || "").replace(/[<>]/g, "").trim().toUpperCase();
  function iconSizeControls(tokens, boxPath) {
    if (!(tokens || []).length) return "";
    const glob = get("text_icon_scale") || {}, own = get(`${boxPath}.icon_scale`) || {};
    return `<div class="pcp-sub">Icon sizes</div>${tokens.map((tk) => {
      const k = iconKey(tk), only = own[k] != null, v = Number(only ? own[k] : glob[k] ?? 100) || 100;
      return `<div class="pc-isz"><span class="pc-isz-name">${esc(tk)}</span>
        <input type="range" min="40" max="300" step="5" value="${v}" data-isz="${esc(k)}" data-box="${esc(boxPath)}"><output>${v}%</output>
        <label title="Only in this box — elsewhere it keeps the page-wide size"><input type="checkbox" data-iszonly="${esc(k)}" data-box="${esc(boxPath)}" ${only ? "checked" : ""}> here only</label></div>`;
    }).join("")}<div class="pcp-note">Sizes apply to that icon in every text box on every paytable page, unless "here only" is ticked.</div>`;
  }
  function tokenChips(tokens, hidden, attrs) {
    return `<span class="pc-toks">${tokens.map((tk) => {
      const off = (hidden || []).map((h) => h.toUpperCase()).includes(tk.toUpperCase());
      return `<button class="pc-tok ${off ? "off" : ""}" ${attrs} data-tok="${esc(tk)}" title="${off ? "Hidden — click to show" : "Click to leave this icon out"}">${off ? "⊘ " : ""}${esc(tk)}</button>`;
    }).join("")}</span>`;
  }

  function popover(k) {
    let body = "";
    if (String(k).startsWith("band:")) {         // one row's card look
      const i = Number(String(k).slice(5)) || 0, rk = rowKey(i), b = (get("bands") || [])[i] || {};
      body = `${lookControls(b.style || "card", "Card look", i)}
        ${row("When numbers don't fit", selectIn("card.overflow", get("card.overflow") || "", [["", "Ask me"], ["shrink", "Shrink the numbers"], ["grow", "Make cards bigger"]]))}
        ${row("Lock position", `<button class="pc-chip ${locked(rk) ? "on" : ""}" data-lock="${rk}">${locked(rk) ? "🔒 Locked" : "🔓 Free"}</button>`)}
        <div class="pcp-note">Only the ${i ? "bottom" : "top"} row changes. Locked: the row keeps its place and size, bigger content scales to fit inside.</div>
        ${b.pos && !locked(rk) ? `<button class="btn secondary small pcp-wide" data-rowauto="${i}">Put this row back in its automatic place</button>` : ""}`;
    } else if (k === "cards") {                   // symbol sizes (toolbar %)
      body = symbolControls();
    } else if (k === "numbers") {
      const parts = viewParts(), iC = partIdx("counts"), iP = partIdx("pays");
      const c = parts[iC] || parts[iP] || {}, pv = parts[iP] || {};
      const fonts = (App.state.fonts || []).map((f) => `<option value="${esc(f)}">`).join("");
      const both = (key, html) => html.replace("<input", `<input data-both="${key}"`);
      body = `${row("Font", both("font", `<input type="text" list="pcFonts" value="${esc(c.font || "")}" placeholder="Default font" style="width:150px">`))}<datalist id="pcFonts">${fonts}</datalist>
        ${row("Font size", both("font_size", `<input type="number" data-num min="6" max="300" step="1" value="${esc(Math.round(c.font_size || 30))}" style="width:80px">`))}
        ${row("Bold", `<label class="switch small">${both("bold", `<input type="checkbox" ${c.bold ? "checked" : ""}>`)}<span class="track"></span></label>`)}
        ${row("Italic", `<label class="switch small">${both("italic", `<input type="checkbox" ${c.italic ? "checked" : ""}>`)}<span class="track"></span></label>`)}
        ${iC >= 0 ? row("Counts colour", `<input type="color" data-pcol="${iC}" value="${esc(c.color || "#ffffff")}">`) : ""}
        ${iP >= 0 ? row("Pays colour", `<input type="color" data-pcol="${iP}" value="${esc(pv.color || "#ffffff")}">`) : ""}
        ${row("Line height", both("line_height", `<input type="range" data-num min="10" max="200" step="1" value="${esc(lineH())}"><output>${esc(lineH())}</output>`))}
        <div class="pcp-note">${isolating() ? `Only ${esc(String(S.symSel).toUpperCase())} changes.` : `Every ${cardBand(S.symSel) ? "bottom" : "top"} card follows.`} Drag the ↔ handle under the numbers for the space between them, ↕ on their right for line height.</div>`;
    } else if (k === "cardlook") {
      const bands = get("bands") || [], i = cardBand(S.symSel);
      body = `${lookControls(bands[i]?.style || "card", i ? "Bottom cards" : "Top cards", i)}
        <div class="pcp-note">Changes every ${i ? "bottom" : "top"} card.</div>`;
    } else if (k === "wildtext") {
      const tp = "features.wild_parts.text", t = get(tp) || {};
      body = `${row("Font size", numIn(`${tp}.font_size`, Math.round(t.font_size || 26), 6, 300))}
        ${row("Colour", colorIn(`${tp}.color`, t.color))}
        ${row("Align", selectIn(`${tp}.align`, t.align || "center", [["left", "Left"], ["center", "Centre"], ["right", "Right"]]))}
        ${fontControls(tp, t)}
        <div class="pcp-note">Double-click the WILD text to size the symbols in it.</div>`;
    } else if (k === "wild" || k === "scatter") {
      const wt = S.wildText || {};
      body = `${lookControls(get("features.style") || "feature", "Box look")}
        ${row("Label tab", toggleIn("features.tab.enabled", get("features.tab.enabled") !== false))}
        ${get("features.tab.enabled") !== false ? lookControls(get("features.tab.style") || "tab", "Tab look") + textControls("features.tab.text", "Tab text", false) : ""}
        ${k === "wild" && (wt.tokens || []).length ? `<div class="pcp-sub">Icons in the WILD text</div>${tokenChips(wt.tokens, wt.hidden, `data-wildtok="1"`)}
          <details class="pc-more"><summary>Icon sizes (or double-click the box)</summary>${iconSizeControls(wt.tokens, "features.wild_box")}</details>` : ""}
        ${row("Lock position", `<button class="pc-chip ${locked(k) ? "on" : ""}" data-lock="${k}">${locked(k) ? "🔒 Locked" : "🔓 Free"}</button>`)}
        <button class="btn primary small pcp-wide" data-customise="${k}">Customise ${k === "wild" ? "WILD" : "SCATTER"} box…</button>
        ${(S.requiredBoxes || []).includes(k)
          ? `<div class="pcp-note">This sheet has a ${k === "wild" ? "WILD" : "SCATTER"} symbol with its own pays, so it always keeps its own box. Customise it to move or style its heading and caption.</div>`
          : `<button class="btn secondary small pcp-wide" data-hide="${k}">Remove this box</button>`}`;
    } else if (k === "title") {
      const gname = ((App.state.config.dynamic_settings || {}).heading_game_name_text) || "";
      body = `${row("Game name", `<input type="text" data-gamename value="${esc(gname)}" placeholder="what &lt;GAME NAME&gt; becomes">`)}
        ${row("Plate", toggleIn("page.title.plate", get("page.title.plate") !== false))}
        ${get("page.title.plate") !== false ? lookControls(get("page.title.style") || "plate", "Plate look") : ""}
        <div class="pcp-note">The title uses the same place, font and style as every other page's heading (Canvas).</div>`;
    } else if (k.startsWith("text:")) {
      const id = k.slice(5), i = Math.max(0, textIndex(id));
      const tm = S.texts.find((t) => String(t.id) === String(id)) || {};
      const bg = get(`page.texts.${i}.bg`) || {}, bgOn = !!bg.on;
      body = `${textControls(`page.texts.${i}`, "Text")}
        <div class="pcp-sub">Background</div>
        ${row("Background", `<label class="switch small"><input type="checkbox" data-textbg="${esc(id)}" ${bgOn ? "checked" : ""}><span class="track"></span></label>`)}
        ${bgOn ? `${row("Shape", `<span class="pc-ins-btns" style="grid-column:auto">
            <button class="pc-chip ${(bg.mode || "box") === "box" ? "on" : ""}" data-textbgmode="box" data-id="${esc(id)}">Around the box</button>
            <button class="pc-chip ${bg.mode === "strip" ? "on" : ""}" data-textbgmode="strip" data-id="${esc(id)}">Strip across the page</button></span>`)}
          ${row("Padding", rangeIn(`page.texts.${i}.bg.pad`, bg.pad ?? 14, 0, 80))}
          ${lookControls(bg.style, "Background look")}` : ""}
        ${(tm.tokens || []).length ? `<div class="pcp-sub">Icons in this text</div>${tokenChips(tm.tokens, tm.hidden, `data-texttok="${esc(id)}"`)}
          <div class="pcp-note">Click an icon to leave it out (its comma or "and" goes with it). Icons with no picture show as their &lt;name&gt;.</div>
          <details class="pc-more"><summary>Icon sizes (or double-click the box)</summary>${iconSizeControls(tm.tokens, `page.texts.${i}`)}</details>` : ""}
        ${row("Lock position", `<button class="pc-chip ${locked(k) ? "on" : ""}" data-lock="${esc(k)}">${locked(k) ? "🔒 Locked" : "🔓 Free"}</button>`)}
        <button class="btn primary small pcp-wide" data-edittext="${esc(id)}">Edit the text</button>
        <div class="pcp-note">Enter starts a new line; select text and right-click to move it to its own box. Double-click the box to size its symbols.</div>`;
    } else if (k === "page") {
      body = `${row("Cards sit", selectIn("page.valign", get("page.valign") || "top", [["top", "At the top of their space"], ["center", "In the middle"]]))}
        ${row("Short rows", selectIn("page.align", get("page.align") || "center", [["left", "Left"], ["center", "Centre"], ["right", "Right"]]))}
        ${row("Gap around parts", rangeIn("page.band_gap", get("page.band_gap") ?? 18, 0, 120))}
        <div class="pcp-note">Drag the dashed page edges to change the margins.</div>`;
    }
    const anchor = String(k).startsWith("band:") ? rowKey(Number(String(k).slice(5)) || 0)
      : ["numbers", "cardlook", "cards"].includes(k) ? rowKey(cardBand(S.symSel)) : k === "wildtext" ? "wild" : k;
    return `<div class="pcp" id="pcPop" data-for="${esc(k)}" data-anchor="${esc(anchor)}">
      <div class="pcp-head"><b>${esc(label(k))}</b><button class="pcp-x" data-closepop>✕</button></div>${body}</div>`;
  }

  /* ---------- the customiser (card / WILD box / SCATTER box) ---------- */
  const ROLE = { symbol: "Symbol", counts: "Counts (5 4 3)", pays: "Pays (150 50 8)", text: "Wild text",
                 title: "Heading (from the Excel)", label: 'Caption ("pay any")' };
  function editorParts() {
    if (S.editor === "card") return (get("card.parts") || []).map((p, i) => ({ obj: p, label: p.role === "text" ? (p.label || "Text") : ROLE[p.role], id: i }));
    const d = get(S.editor === "wild" ? "features.wild_parts" : "features.scatter_parts") || {};
    return Object.keys(d).map((k) => ({ obj: d[k], label: S.editor === "wild" && k === "text" ? "Wild text" : (ROLE[k] || k), id: k }));
  }
  function cardSize(i) {                     // the card's size now (design px): explicit, or as laid out
    const geo = (S.bandGeo || {})[i ? "low" : "high"];
    if (geo && geo.size) return [Math.round(geo.size[0]), Math.round(geo.size[1])];
    const b = (get("bands") || [])[i] || {};
    const key = i ? "low" : "high";
    const blk = rectOf(key), count = S.counts[key] || 1, per = Math.min(Number(b.per_row) || count, count);
    const gap = Number(get("page.gap_x") || 24) * (S.fit || 1);
    const w = b.card_w ? Number(b.card_w) : blk ? Math.round((blk[2] - (per - 1) * gap) / per / (S.fit || 1)) : 300;
    return [w, Number(b.card_h) || 150];
  }
  function editorRatio() {
    if (S.editor === "card") { const [w, h] = cardSize(0); return w / h; }
    const r = rectOf(S.editor);
    return r ? r[2] / Math.max(1, r[3]) : 2;
  }
  function editorHtml() {
    const parts = editorParts();
    const sel = parts[S.sel] || parts[0];
    const look = S.editor === "card" ? (((get("bands") || [])[0] || {}).style || "card") : (get("features.style") || "feature");
    const st = get(`styles.${look}`) || {};
    const radius = String(st.radius) === "pill" ? "999px" : `${Math.round(Number(st.radius) || 0) / 2}px`;
    const title = S.editor === "card" ? "Customise card" : S.editor === "wild" ? "Customise WILD box" : "Customise SCATTER box";
    const path = sel ? (S.editor === "card" ? `card.parts.${sel.id}` : `features.${S.editor}_parts.${sel.id}`) : "";
    const role = sel ? (sel.obj.role || sel.id) : "";
    const bands = get("bands") || [];
    const two = bands.length > 1;
    const sizeRow = (i, name) => { const [w, h] = cardSize(i); return `<div class="pce-size"><b>${name}</b>
        <label>Width ${`<input type="number" data-cardsize="w" data-band="${i}" min="40" max="1900" value="${w}">`}</label>
        <label>Height ${`<input type="number" data-cardsize="h" data-band="${i}" min="30" max="1000" value="${h}">`}</label>
        ${bands[i] && bands[i].card_w ? `<button class="btn secondary small" data-cardauto="${i}" title="Let the cards fill their row again">Auto width</button>` : ""}</div>`; };
    return `<div class="gm-overlay pce-ov" id="pcEditor"><div class="gm-dialog pce">
      <div class="gm-dhead"><b>${esc(title)}</b><button class="gm-x" data-closeeditor>✕</button></div>
      <div class="gm-dbody">
        ${S.editor === "card" ? `<div class="pce-sizes">${sizeRow(0, two ? "High cards" : "Cards")}${two ? sizeRow(1, "Low cards") : ""}</div>` : ""}
        <div class="pce-card" id="pceCard" style="aspect-ratio:${editorRatio().toFixed(3)};background:${esc(st.fill || "#333")};border-radius:${radius};${(st.stroke || {}).enabled ? `border:3px solid ${esc(st.stroke.color)}` : ""}">
          ${parts.map((p, i) => `<div class="pce-part ${esc(p.obj.role || p.id)} ${p === sel ? "sel" : ""}" data-pi="${i}"
              style="left:${p.obj.x * 100}%;top:${p.obj.y * 100}%;width:${p.obj.w * 100}%;height:${p.obj.h * 100}%">
              <span>${esc(p.label)}</span><i class="pce-rs" data-rs="1"></i></div>`).join("")}
          ${S.editor === "card" ? `<div class="pce-edge r" data-cardedge="w" title="Drag to change the card width"></div><div class="pce-edge b" data-cardedge="h" title="Drag to change the card height"></div>` : ""}
        </div>
        <div class="pcp-note">Drag a box to move it, its corner to resize it${S.editor === "card" ? "; drag the card's right or bottom edge to change its size" : ""}. The preview updates when you let go.</div>
        ${sel && role !== "symbol" ? `<div class="pce-props">${textControls(path, sel.label)}
          ${role === "text" && S.editor === "card" ? `${row("Text", `<input type="text" data-k="${path}.text" value="${esc(sel.obj.text || "")}" placeholder="typed text">`)}
            ${row("…or Excel cell", `<input type="text" data-k="${path}.source" value="${esc(sel.obj.source || "")}" placeholder="e.g. B54">`)}
            <button class="btn secondary small" data-delpart="${sel.id}">Remove this text</button>` : ""}</div>` : ""}
      </div>
      <div class="gm-dfoot">${S.editor === "card" ? `<button class="btn secondary" data-addtext>+ Add text</button>` : ""}<span style="flex:1"></span>
        <button class="btn primary" data-closeeditor>Done</button></div>
    </div></div>`;
  }

  /* ---------- view ---------- */
  PC.view = () => {
    const shs = sheets();
    if (!S.sheet || !shs.includes(S.sheet)) {
      const had = S.sheet;
      S.sheet = shs[0] || "";
      // the Excel scan can arrive after init — preview once a sheet exists
      if (S.sheet && !had && S.tpl && !S.token) setTimeout(() => PC.apply(), 0);
    }
    const builtins = S.list.filter((t) => t.builtin), mine = S.list.filter((t) => !t.builtin);
    const cur = S.tpl;
    const tile = (t) => `<button class="pc-tile ${cur && S.baseId === t.id ? "on" : ""}" data-pick="${esc(t.id)}" title="${esc(t.description)}">
        <b>${esc(t.name)}</b>${t.builtin ? "" : `<span class="pc-badge mine">mine</span>`}</button>`;
    const chip = (k, on, txt) => `<button class="pc-chip ${on ? "on" : ""}" data-show="${k}">${on ? "✓ " : ""}${esc(txt)}</button>`;
    return `<div class="view pc-view">
      <div class="view-header" style="display:flex;align-items:flex-end;gap:12px">
        <div style="flex:1"><div class="view-title">Paytable</div>
          <div class="view-sub">Pick a design, then edit it right on the preview: drag boxes and text anywhere, drag edges to resize, ✎ for colours and borders. The cards fill the space that's left.</div></div>
        <button class="btn secondary small" onclick="PaytableCards.advanced()" title="The detailed slot-by-slot editor">Advanced slot editor</button>
      </div>
      <div class="pt-workspace"><div class="pt-grid">
        <div class="pt-card pt-c3 pc-left">
          <div class="pt-ctl-label" style="margin:0 0 8px"><span>Design</span></div>
          <div class="pc-tiles">${builtins.map(tile).join("")}</div>
          ${mine.length ? `<div class="pt-ctl-label" style="margin:12px 0 6px"><span>My designs</span></div><div class="pc-tiles">${mine.map(tile).join("")}</div>` : ""}
          ${cur ? `<div class="pc-state">${esc(cur.name || "")}${S.dirty ? " · <b>edited</b>" : ""}</div>
            <div class="pc-actions"><button class="btn primary small" onclick="PaytableCards.saveCopy()">Save as copy…</button>
              ${S.dirty ? `<button class="btn secondary small" onclick="PaytableCards.revert()">Start over</button>` : ""}
              ${S.list.some((t) => t.id === S.baseId && !t.builtin) ? `<button class="btn secondary small" onclick="PaytableCards.del()">Delete</button>` : ""}</div>
            <div class="pt-ctl-label" style="margin:14px 0 6px"><span>Show</span></div>
            <div class="pc-show">${chip("title", get("page.title.enabled") !== false, "Title")}
              ${chip("features", !!get("features.enabled"), "WILD / SCATTER boxes")}
              ${chip("notes", get("page.notes.enabled") !== false, "Text")}
</div>
            <button class="btn secondary small" style="margin-top:8px" onclick="PaytableCards.addText()">+ Text box</button>` : ""}
          <div class="pcp-note" style="margin-top:14px">Every paytable sheet (Base, Free Games…) is built with this design and its own Excel data. The built-in designs never change — Save as copy keeps yours.</div>
        </div>
        <div class="pt-card pt-c9 pc-preview">
          <div class="pt-preview-head">
            <span class="pt-preview-name" id="pcStatus">${S.busy ? "Rendering…" : esc(S.sheet || "No paytable sheet scanned")}</span><span style="flex:1"></span>
            <button class="pl-tb-btn" id="pcUndo" title="Undo (Ctrl+Z)" ${S.undo.length ? "" : "disabled"}>↶</button>
            <button class="pl-tb-btn" id="pcRedo" title="Redo (Ctrl+Y)" ${S.redo.length ? "" : "disabled"}>↷</button>
            <button class="pl-tb-btn pc-check" id="pcCheck" title="Read the paytable back from the Excel and check every pay is on the page" ${S.sheet ? "" : "disabled"}>✓ Pay check</button>
            <label style="font-size:12px;color:var(--pt-text2)">Sheet</label>
            <select id="pcSheet">${shs.map((n) => `<option ${n === S.sheet ? "selected" : ""}>${esc(n)}</option>`).join("") || "<option>—</option>"}</select>
          </div>
          <div class="pc-stage" id="pcStage">${S.token ? stage()
            : `<div class="empty" style="padding:48px"><div class="empty-icon">▦</div><div class="empty-title">${S.error ? "No preview" : cur ? "Rendering…" : "Pick a design"}</div><div class="empty-sub">${esc(S.error || "")}</div></div>`}</div>
        </div>
      </div></div></div>${S.editor ? editorHtml() : ""}`;
  };

  function stage() {
    const ids = ["page", "title", "wild", "scatter", ...Object.keys(S.blocks).filter((k) => k.startsWith("text:")), "high", "low"]
      .filter((k) => S.blocks[k]);
    return `<img class="pt-preview-img" id="pcImg" src="/api/table_preview/${encodeURIComponent(S.token)}" alt="Paytable preview" draggable="false">
      <canvas class="pc-live" id="pcLive" ${S.liveOn && S.live ? "" : "hidden"}></canvas>
      ${ids.map(blockHtml).join("")}
      ${S.pop ? popover(S.pop) : ""}
      ${S.editing ? `<div class="pc-ted" id="pcTed"><div class="pc-ted-bar"><b>Editing text</b><span>Enter = new line · select text, right-click → its own box</span>
          <button class="btn primary small" id="pcTedDone">Done</button></div>
        <textarea id="pcTedArea" spellcheck="false">${esc(textOf(S.editing))}</textarea></div>` : ""}
      ${S.picked.length > 1 ? `<div class="pc-merge" id="pcMerge"><b>${S.picked.length} text boxes selected</b>
          <button class="btn primary small" id="pcMergeGo">Merge them</button><button class="btn secondary small" id="pcMergeNo">Cancel</button></div>` : ""}
      <div class="pc-menu" id="pcMenu" hidden></div>`;
  }

  function blockHtml(k) {
    if (k === "page") {
      return `<div class="pcb page" data-b="page">
        ${["top", "bottom", "left", "right"].map((e) => `<div class="pcb-edge ${e}" data-h="m-${e}" title="Drag to change the ${e} margin"></div>`).join("")}
        <button class="pcb-edit page" data-edit="page" title="Page settings">✎</button></div>`;
    }
    if (k === "title") {
      return `<div class="pcb title fixed" data-b="title" title="The title sits where every page heading is">
        <span class="pcb-tag"><span class="pcb-label">Title</span></span>
        <button class="pcb-edit" data-edit="title" title="Plate look">✎</button>
        ${get("page.title.plate") !== false ? `<div class="pcb-h side l" data-h="w-l" title="Plate width">↔</div><div class="pcb-h side r" data-h="w-r" title="Plate width">↔</div>` : ""}</div>`;
    }
    if (k === "high" || k === "low") {             // a row of cards: its own box and tools
      const i = rowIdx(k), b = (get("bands") || [])[i] || {}, lk = locked(k), n = rowCount(k);
      const per = Math.min(Number(b.per_row) || n, n || 1);
      const selHere = S.symSel && S.blocks[`card:${S.symSel}`] && rowKey(cardBand(S.symSel)) === k;
      return `<div class="pcb cards row-box ${lk ? "locked-cards" : ""}" data-b="${k}" title="${lk ? "Locked — click a card to edit it" : "Drag to move this row · click a card to edit it · double-click: just that card"}">
        <span class="pcb-tag"><span class="pcb-label">${lk ? "🔒 " : ""}${label(k)}</span><span class="pcb-band">${per}/row<button class="pcb-step" data-per="-1" data-band="${i}" title="Fewer per row">−</button><button class="pcb-step" data-per="1" data-band="${i}" title="More per row">+</button></span></span>
        <button class="pcb-edit" data-edit="band:${i}" title="This row's card look">✎</button>${lockBtn(k)}
        ${lk ? "" : `<div class="pcb-h side l" data-h="w-l" title="Card width (this row)">↔</div><div class="pcb-h side r" data-h="w-r" title="Card width (this row)">↔</div>
        <div class="pcb-h bottom" data-h="h" title="Card height (this row)">↕</div>
        ${["tl", "tr", "bl", "br"].map((c) => `<div class="pcb-h scl ${c}" data-h="sc-${c}" title="Scale this row and everything in it (proportional)"></div>`).join("")}`}
        ${gutterHtml(i)}
        ${selHere ? cardOverlay() : ""}</div>`;
    }
    // free parts: WILD / SCATTER boxes and text boxes
    const lk = locked(k);
    const extra = iconHandlesHtml(k) + (k === "wild" && S.featSel === "wild" && !S.iconEdit ? featOverlayHtml() : "");
    return `<div class="pcb free ${k.startsWith("text:") ? "text" : "feature"} ${lk ? "locked" : ""} ${S.picked.includes(k) ? "picked" : ""}" data-b="${esc(k)}" title="${lk ? "Locked — unlock to move it" : "Drag to move · edges and corner to resize"}">
      <span class="pcb-tag"><span class="pcb-label">${lk ? "🔒 " : ""}${esc(label(k))}</span></span>
      <button class="pcb-edit" data-edit="${esc(k)}" title="Edit">✎</button>${lockBtn(k)}
      ${lk ? "" : `<div class="pcb-h side r" data-h="r" title="Width">↔</div><div class="pcb-h bottom" data-h="b" title="Height">↕</div>
      <div class="pcb-h corner" data-h="rb" title="Size"></div>`}${extra}</div>`;
  }

  /* ---------- icons inside text: double-click a text box (or the WILD box) for a size handle on each ---------- */
  function textSlotOf(k) {                       // the slot whose text this box shows
    if (k === "wild") return "@slot.wildbox.text";
    const t = S.texts.find((x) => `text:${x.id}` === k);
    return t ? t.slot : "";
  }
  const boxPathOf = (k) => (k === "wild" ? "features.wild_box" : `page.texts.${Math.max(0, textIndex(k.slice(5)))}`);
  function iconPct(k, tok) {                     // the size this icon has in this box now (percent)
    const key = iconKey(tok), own = get(`${boxPathOf(k)}.icon_scale`) || {}, glob = get("text_icon_scale") || {};
    const v = own[key] ?? glob[key] ?? glob["*"] ?? 100;
    return Number(v) || 100;
  }
  // Four corners on every symbol, like Photoshop. Dragging any corner scales ALL the symbols in this
  // paytable's text together (every text box, every paytable page) and the text reflows. Right-click a
  // symbol to isolate it: then only that symbol changes (everywhere it appears).
  const CORNERS = { tl: [-1, -1], tr: [1, -1], bl: [-1, 1], br: [1, 1] };
  function iconHandlesHtml(k) {
    if (S.iconEdit !== k) return "";
    const slot = textSlotOf(k);
    Object.keys(S.blocks).filter((b) => b.startsWith("ico:")).forEach((b) => delete S.blocks[b]);
    const icons = (S.liveIcons || []).filter((i) => i.slot === slot);
    icons.forEach((ic, n) => { S.blocks[`ico:${n}`] = ic.rect; });
    const iso = S.iconIso;
    const tip = !icons.length ? "No symbols in this text"
      : iso ? `Only ${esc(iso)} changes — drag a corner · right-click: back to all symbols`
      : "Drag a corner: all the symbols in this box scale together · right-click a symbol: size only that one";
    return `<div class="pci-tip">${tip}<button class="pco-al" data-iconedit-off title="Done">✕</button></div>
      ${icons.map((ic, n) => {
        const off = iso && iconKey(ic.tok) !== iconKey(iso);
        return `<div class="pcb-inner pci ${off ? "off" : ""} ${iso && !off ? "iso" : ""}" data-inner="ico:${n}" data-tok="${esc(ic.tok)}" title="${esc(ic.tok)} — ${iconPct(k, ic.tok)}%">
          ${off ? "" : Object.keys(CORNERS).map((c) => `<div class="pci-h ${c}" data-ic="${c}"></div>`).join("")}</div>`;
      }).join("")}`;
  }
  function refreshIconHandles() {
    if (!S.iconEdit || S.dragging) return;
    const el = document.querySelector(`.pcb[data-b="${CSS.escape(S.iconEdit)}"]`);
    if (!el) return;
    el.querySelectorAll(".pci, .pci-tip").forEach((x) => x.remove());
    el.insertAdjacentHTML("beforeend", iconHandlesHtml(S.iconEdit));
    wireIconHandles();
    placeBlocks();
  }
  // every icon size in the paytable's text, multiplied by f (page-wide, "*" and the boxes' own)
  // every symbol in THIS text box × f: written as the box's own sizes, so no other box changes
  function scaleBoxIcons(k, f) {
    const path = `${boxPathOf(k)}.icon_scale`, own = Object.assign({}, get(path) || {});
    const glob = get("text_icon_scale") || {};
    const clamp = (v) => Math.max(10, Math.min(600, Math.round(v)));
    const slot = textSlotOf(k);
    const toks = [...new Set((S.liveIcons || []).filter((i) => i.slot === slot).map((i) => iconKey(i.tok)))];
    toks.forEach((key) => { own[key] = clamp(iconPct(k, `<${key}>`) * f); });
    own["*"] = clamp(Number(own["*"] ?? glob["*"] ?? 100) * f);        // symbols that arrive later in this box
    put(path, own);
  }
  function wireIconHandles() {
    const fresh = (sel, tag) => [...document.querySelectorAll(sel)].filter((x) => !x[`__w${tag}`] && (x[`__w${tag}`] = true));   // wired once each
    fresh("[data-iconedit-off]", "c").forEach((b) => b.addEventListener("click", (e) => { e.stopPropagation(); S.iconEdit = ""; S.iconIso = ""; rerenderStage(); }));
    fresh("[data-iconedit-off], .pci-tip, .pci", "d").forEach((b) => b.addEventListener("pointerdown", (e) => { if (e.button === 0) e.stopPropagation(); }));
    // right-click a symbol: isolate it (only it changes) / back to all
    fresh(".pci", "m").forEach((box) => box.addEventListener("contextmenu", (e) => {
      e.preventDefault(); e.stopPropagation();
      const tok = box.dataset.tok, k = S.iconEdit, key = iconKey(tok);
      const own = (get(`${boxPathOf(k)}.icon_scale`) || {})[key] != null;
      showMenu(e.clientX, e.clientY, [
        S.iconIso && iconKey(S.iconIso) === key
          ? { label: "Size all symbols together again", run: () => { S.iconIso = ""; refreshIconHandles(); } }
          : { label: `Size only ${tok}`, run: () => { S.iconIso = tok; refreshIconHandles(); } },
        ...(own ? [{ label: `${tok}: back to the size of the box's other symbols`, run: () => edit(() => {
          const o = Object.assign({}, get(`${boxPathOf(k)}.icon_scale`) || {}); delete o[key]; put(`${boxPathOf(k)}.icon_scale`, o);
        }) }] : []),
        { label: "Done", run: () => { S.iconEdit = ""; S.iconIso = ""; rerenderStage(); } },
      ]);
      void k;
    }));
    fresh(".pci-h", "p").forEach((h) => h.addEventListener("pointerdown", (e) => {
      if (e.button !== 0) return;
      e.stopPropagation(); e.preventDefault();
      const k = S.iconEdit, box = h.closest(".pci"), tok = box.dataset.tok, key = iconKey(tok);
      const [sx, sy] = CORNERS[h.dataset.ic] || [1, 1];
      const w0 = box.offsetWidth, h0 = box.offsetHeight, l0 = box.offsetLeft, t0 = box.offsetTop;
      const iso = S.iconIso && iconKey(S.iconIso) === key, base = iconPct(k, tok);
      const D = { x: e.clientX, y: e.clientY, dx: 0, dy: 0 };
      try { h.setPointerCapture(e.pointerId); } catch (_) { /* synthetic events */ }
      const snap = JSON.stringify(S.tpl);
      S.dragging = true;
      S.icoSynced = false;
      let timer = 0;
      const fNow = () => Math.max(0.1, Math.min(6, 1 + (sx * D.dx + sy * D.dy) / Math.max(1, w0 + h0)));   // outward = bigger
      const apply = () => {
        pinFree();
        const f = fNow();
        // only this text box changes (its own sizes); other boxes keep theirs
        if (iso) put(`${boxPathOf(k)}.icon_scale`, Object.assign({}, get(`${boxPathOf(k)}.icon_scale`) || {}, { [key]: Math.max(10, Math.min(600, Math.round(base * f))) }));
        else scaleBoxIcons(k, f);
      };
      const move = (ev) => {
        D.dx = ev.clientX - D.x; D.dy = ev.clientY - D.y;
        const f = fNow(), w = w0 * f, hh = h0 * f;       // the opposite corner stays put (until the redraw places it)
        if (!S.icoSynced) Object.assign(box.style, { width: `${w}px`, height: `${hh}px`, left: `${sx < 0 ? l0 + w0 - w : l0}px`, top: `${sy < 0 ? t0 + h0 - hh : t0}px` });
        if (!timer) timer = setTimeout(() => {        // the text redraws with the new sizes as you drag
          timer = 0;
          S.tpl = JSON.parse(snap);
          S.dragLive = true;
          try { edit(apply); } finally { S.dragLive = false; }
        }, 24);
      };
      const up = () => {
        h.removeEventListener("pointermove", move);
        h.removeEventListener("pointerup", up);
        if (timer) clearTimeout(timer);
        S.tpl = JSON.parse(snap);
        S.dragging = false;
        if (Math.abs(D.dx) + Math.abs(D.dy) < 2) { placeBlocks(); return; }
        const pct = Math.round(fNow() * 100);
        edit(apply);
        toast(iso ? `${tok} is now ${Math.round(base * fNow())}% in this box.` : `Symbols in this box: ${pct}% of their size — other boxes unchanged.`);
      };
      h.addEventListener("pointermove", move);
      h.addEventListener("pointerup", up);
    }));
  }

  /* ---------- the WILD box's own parts: click it, then move / size its symbol and its text ---------- */
  function featBoxFrac(k) {                      // the WILD box itself (its block includes half the tab)
    const b = S.blocks[k];
    if (!b) return null;
    const c = S.canvas || { height: DH(), scale: 1 }, ch = Number(c.height) || DH();
    const tab = get("features.tab.enabled") !== false ? Number(get("features.tab_h") || 56) : 0;
    return [b[0], b[1] + (tab / 2) * (Number(c.scale) || 1) / ch, b[2], b[3]];
  }
  function featOverlayHtml() {
    const B = featBoxFrac("wild"), parts = get("features.wild_parts") || {};
    if (!B) return "";
    const W = B[2] - B[0], H = B[3] - B[1];
    const at = (p) => [B[0] + (+p.x || 0) * W, B[1] + (+p.y || 0) * H, B[0] + ((+p.x || 0) + (+p.w || 1)) * W, B[1] + ((+p.y || 0) + (+p.h || 1)) * H];
    if (parts.symbol) S.blocks["wpart:symbol"] = (S.drawn || {})["@slot.wild"] || at(parts.symbol);
    if (parts.text) S.blocks["wpart:text"] = at(parts.text);
    return `${parts.symbol ? `<div class="pcb-inner pco-part sym wpart" data-inner="wpart:symbol" data-fh="sym-move" title="Drag to move the WILD symbol">
        <div class="pco-h tr" data-fh="sym-scale" title="Drag to size the symbol (keeps its shape)">⤢</div></div>` : ""}
      ${parts.text ? `<div class="pcb-inner pco-part num wpart" data-inner="wpart:text" data-fh="txt-move" title="Drag to move the WILD text · double-click: size its symbols">
        <button class="pco-edit" data-wildtext title="Font size, colour">✎</button>
        <div class="pco-h br" data-fh="txt-size" title="Drag to resize the text area">⤡</div></div>` : ""}`;
  }
  function wireFeatOverlay() {
    document.querySelector("[data-wildtext]")?.addEventListener("click", (e) => { e.stopPropagation(); S.pop = "wildtext"; rerenderStage(); });
    document.querySelectorAll("[data-wildtext]").forEach((b) => b.addEventListener("pointerdown", (e) => e.stopPropagation()));
    document.querySelectorAll(".wpart[data-fh], .wpart [data-fh]").forEach((el) => el.addEventListener("pointerdown", (e) => {
      if (e.button !== 0 || e.target.closest("[data-wildtext]")) return;
      const kind = e.target.closest("[data-fh]").dataset.fh;
      if (kind !== el.dataset.fh) return;
      e.stopPropagation(); e.preventDefault();
      const g = geo(), B = featBoxFrac("wild");
      if (!g || !B) return;
      const part = kind.startsWith("sym") ? "symbol" : "text";
      const target = el.closest(".wpart") || el;
      const t0 = { l: target.offsetLeft, t: target.offsetTop, w: target.offsetWidth, h: target.offsetHeight };
      const bw = (B[2] - B[0]) * g.w, bh = (B[3] - B[1]) * g.h;
      const D = { x: e.clientX, y: e.clientY, dx: 0, dy: 0 };
      try { el.setPointerCapture(e.pointerId); } catch (_) { /* synthetic events */ }
      const snap = JSON.stringify(S.tpl);
      S.dragging = true;
      let timer = 0;
      const symF = () => Math.max(0.15, 1 + (D.dx - D.dy) / Math.max(1, t0.w + t0.h));
      const apply = () => {
        pinFree();
        const p = get(`features.wild_parts.${part}`);
        if (!p) return;
        const fx = D.dx / Math.max(1, bw), fy = D.dy / Math.max(1, bh);
        if (kind === "sym-move" || kind === "txt-move") { p.x = r3((+p.x || 0) + fx); p.y = r3((+p.y || 0) + fy); }
        else if (kind === "sym-scale") { const f = symF(), h1 = (+p.h || 1) * f; p.y = r3((+p.y || 0) + (+p.h || 1) - h1); p.w = r3((+p.w || 1) * f); p.h = r3(h1); }
        else if (kind === "txt-size") { p.w = r3(Math.max(0.08, (+p.w || 1) + fx)); p.h = r3(Math.max(0.08, (+p.h || 1) + fy)); }
      };
      const move = (ev) => {
        D.dx = ev.clientX - D.x; D.dy = ev.clientY - D.y;
        if (kind.endsWith("move")) Object.assign(target.style, { left: `${t0.l + D.dx}px`, top: `${t0.t + D.dy}px` });
        else if (kind === "sym-scale") { const f = symF(); Object.assign(target.style, { width: `${t0.w * f}px`, height: `${t0.h * f}px`, top: `${t0.t + t0.h - t0.h * f}px` }); }
        else Object.assign(target.style, { width: `${Math.max(20, t0.w + D.dx)}px`, height: `${Math.max(16, t0.h + D.dy)}px` });
        if (!timer) timer = setTimeout(() => {
          timer = 0;
          S.tpl = JSON.parse(snap);
          S.dragLive = true;
          try { edit(apply); } finally { S.dragLive = false; }
        }, 24);
      };
      const up = () => {
        el.removeEventListener("pointermove", move);
        el.removeEventListener("pointerup", up);
        if (timer) clearTimeout(timer);
        S.tpl = JSON.parse(snap);
        S.dragging = false;
        if (Math.abs(D.dx) + Math.abs(D.dy) < 2) { placeBlocks(); return; }
        edit(apply);
      };
      el.addEventListener("pointermove", move);
      el.addEventListener("pointerup", up);
    }));
    // double-click the WILD text: size the symbols inside it
    document.querySelector('.wpart[data-inner="wpart:text"]')?.addEventListener("dblclick", (e) => {
      e.stopPropagation();
      S.iconEdit = "wild";
      rerenderStage();
    });
  }

  function geo() {
    const img = document.getElementById("pcImg");
    if (!img || !img.clientWidth) return null;
    const c = S.canvas || { width: DW(), height: DH(), scale: 1 };
    return { img, w: img.clientWidth, h: img.clientHeight, ox: img.offsetLeft, oy: img.offsetTop,
             k: (c.width / c.scale) / img.clientWidth };       // design px per displayed px
  }
  function place(el, b, pad, g) {
    Object.assign(el.style, { left: `${g.ox + b[0] * g.w - pad}px`, top: `${g.oy + b[1] * g.h - pad}px`,
      width: `${(b[2] - b[0]) * g.w + 2 * pad}px`, height: `${(b[3] - b[1]) * g.h + 2 * pad}px` });
  }
  function placeBlocks() {
    const g = geo();
    if (!g) return;
    const lc = document.getElementById("pcLive");
    if (lc) Object.assign(lc.style, { left: `${g.ox}px`, top: `${g.oy}px`, width: `${g.w}px`, height: `${g.h}px` });
    document.querySelectorAll(".pcb").forEach((el) => {
      const b = S.blocks[el.dataset.b];
      if (b) place(el, b, el.dataset.b === "page" ? 0 : 4, g);
    });
    document.querySelectorAll(".pcb .pcb-inner").forEach((el) => {
      const b = S.blocks[el.dataset.inner], c = S.blocks[el.closest(".pcb").dataset.b];
      if (!b || !c) return;
      let l = (b[0] - c[0]) * g.w + 4, t = (b[1] - c[1]) * g.h + 4, w = (b[2] - b[0]) * g.w, h = (b[3] - b[1]) * g.h;
      if (el.classList.contains("pcg")) {                 // thin gaps still get a hover strip
        if (el.classList.contains("v") && w < 14) { l -= (14 - w) / 2; w = 14; }
        if (el.classList.contains("h") && h < 14) { t -= (14 - h) / 2; h = 14; }
      }
      Object.assign(el.style, { left: `${l}px`, top: `${t}px`, width: `${w}px`, height: `${h}px` });
    });
    const pop = document.getElementById("pcPop");
    const owner = pop && document.querySelector(`.pcb[data-b="${CSS.escape(pop.dataset.anchor || pop.dataset.for)}"]`);
    if (pop && owner) {
      const st = document.getElementById("pcStage");
      const ol = parseFloat(owner.style.left), ot = parseFloat(owner.style.top);
      const ow = parseFloat(owner.style.width), oh = parseFloat(owner.style.height);
      const left = Math.min(st.clientWidth - 316, Math.max(0, ol + ow - 310));
      let top = ot + oh + 8;
      if (top + pop.offsetHeight > st.clientHeight) top = Math.max(0, ot - pop.offsetHeight - 8);
      Object.assign(pop.style, { left: `${left}px`, top: `${top}px` });
    }
  }

  function rerender() {
    const ws = document.getElementById("workspace");
    if (!ws || App.route !== "paytable" || App.state.ptAdvanced) return;
    const scroll = ws.scrollTop;
    ws.innerHTML = PC.view();
    ws.querySelector(".view")?.classList.add("no-anim");
    ws.scrollTop = scroll;
    wire(ws);
  }
  function rerenderStage() {
    const st = document.getElementById("pcStage");
    if (!st || !S.token) { rerender(); return; }
    st.innerHTML = stage();
    wireStage();
  }
  function updateStatus() {
    const s = document.getElementById("pcStatus");
    if (s) s.textContent = S.busy ? "Rendering…" : S.sheet;
    const u = document.getElementById("pcUndo"), r = document.getElementById("pcRedo");
    if (u) u.disabled = !S.undo.length;
    if (r) r.disabled = !S.redo.length;
  }

  /* ---------- wiring ---------- */
  function wireInputs(root) {
    root.querySelectorAll("[data-k]").forEach((el) => {
      const path = el.dataset.k;
      const ev = el.type === "checkbox" || el.tagName === "SELECT" ? "change" : "input";
      el.addEventListener(ev, () => {
        let v = el.value;
        if (el.dataset.bool !== undefined) v = el.checked;
        else if (el.dataset.num !== undefined) { v = Number(el.value); if (!Number.isFinite(v)) return; }
        const out = el.nextElementSibling;
        if (out && out.tagName === "OUTPUT") out.textContent = el.value;
        const m = /^styles\.([^.]+)\.(.+)$/.exec(path);
        if (m && el.dataset.band !== undefined) {         // a card band's look belongs to that band only
          edit(() => put(`styles.${bandStyle(Number(el.dataset.band))}.${m[2]}`, v), path);
        } else if (path.startsWith("page.texts.")) {
          edit(() => { pinFree(); put(path, v); }, path);
        } else set(path, v);
        if (el.type === "checkbox" || el.tagName === "SELECT") refreshPopover();
      });
    });
    root.querySelectorAll("[data-pill]").forEach((el) => el.addEventListener("change", () => {
      edit(() => {
        const p = el.dataset.band !== undefined ? `styles.${bandStyle(Number(el.dataset.band))}` : el.dataset.pill;
        put(`${p}.radius`, el.checked ? "pill" : 12);
      });
      refreshPopover();
    }));
  }

  function refreshPopover() {
    const pop = document.getElementById("pcPop");
    if (!pop) return;
    const tmp = document.createElement("div");
    tmp.innerHTML = popover(S.pop);
    pop.replaceWith(tmp.firstElementChild);
    wirePopover();
    placeBlocks();
  }

  function wirePopover() {
    const pop = document.getElementById("pcPop");
    if (!pop) return;
    wireInputs(pop);
    pop.querySelector("[data-closepop]")?.addEventListener("click", () => { S.pop = ""; rerenderStage(); });
    pop.querySelector("[data-edittext]")?.addEventListener("click", (e) => openEditorFor(e.target.dataset.edittext));
    pop.querySelectorAll("[data-both]").forEach((el) => {
      const key = el.dataset.both, ev = el.type === "checkbox" || el.type === "text" ? "change" : "input";
      el.addEventListener(ev, () => {
        let v = el.type === "checkbox" ? el.checked : el.value;
        if (el.dataset.num !== undefined) { v = Number(v); if (!Number.isFinite(v)) return; }
        const out = el.nextElementSibling;
        if (out && out.tagName === "OUTPUT") out.textContent = el.value;
        const idx = [partIdx("counts"), partIdx("pays")];
        edit(() => {
          const parts = ownParts();
          idx.forEach((i) => {
            if (i < 0 || !parts[i]) return;
            if (v === "" || v === false) delete parts[i][key]; else parts[i][key] = v;
          });
        }, `both:${key}`);
      });
    });
    pop.querySelectorAll("[data-pcol]").forEach((el) => el.addEventListener("input", () => {
      const i = Number(el.dataset.pcol);
      edit(() => { const parts = ownParts(); if (parts[i]) parts[i].color = el.value; }, `pcol:${i}`);
    }));
    const symIn = pop.querySelector("[data-sym]");
    symIn?.addEventListener("input", () => {
      symIn.nextElementSibling.textContent = `${symIn.value}%`;
      setSym(S.symSel, Number(symIn.value));
    });
    symIn?.addEventListener("change", refreshPopover);
    pop.querySelectorAll("[data-symstep]").forEach((b) => b.addEventListener("click", () => {
      setSym(S.symSel, symPct(S.symSel) + Number(b.dataset.symstep));
      refreshPopover();
    }));
    pop.querySelector("[data-symall]")?.addEventListener("click", (e) => {
      symAll(Number(e.target.dataset.symall));
      toast("Every symbol now uses this size.");
      refreshPopover();
    });
    pop.querySelector("[data-symreset]")?.addEventListener("click", () => { edit(() => delete get("card").symbol_size); refreshPopover(); });
    pop.querySelectorAll("[data-symsel]").forEach((b) => b.addEventListener("click", () => { S.symSel = b.dataset.symsel; rerenderStage(); }));
    pop.querySelector("[data-rowauto]")?.addEventListener("click", (e) => {
      const i = Number(e.target.dataset.rowauto) || 0;
      edit(() => { delete get("bands")[i].pos; });
      refreshPopover();
    });
    pop.querySelector("[data-cardsauto]")?.addEventListener("click", () => { edit(() => { const pg = get("page"); delete pg.cards_offset; delete pg.cards_at; }); refreshPopover(); });
    pop.querySelectorAll("[data-customise]").forEach((b) => b.addEventListener("click", () => openEditor(b.dataset.customise)));
    // the game's name, wherever the Excel writes <GAME NAME> (every page's heading, not only this one)
    pop.querySelector("[data-gamename]")?.addEventListener("change", async (e) => {
      const ds = (App.state.config.dynamic_settings = App.state.config.dynamic_settings || {});
      ds.heading_game_name_text = e.target.value.trim();
      await App.flushConfig();
      toast(ds.heading_game_name_text ? `<GAME NAME> is now “${ds.heading_game_name_text}”.` : "<GAME NAME> has no name now.");
      PC.apply();
      PC.live();
    });
    pop.querySelector("[data-hide]")?.addEventListener("click", (e) => {
      const which = e.target.dataset.hide, other = which === "wild" ? "scatter" : "wild";
      edit(() => { pinFree(); put(`features.${which}`, false); if (get(`features.${other}`) === false) put("features.enabled", false); });
      S.pop = "";
    });
    // icons in the WILD text
    pop.querySelectorAll("[data-wildtok]").forEach((b) => b.addEventListener("click", () => {
      edit(() => {
        pinFree();
        const hide = (get("features.wild_box.hide") || []).slice();
        const i = hide.findIndex((h) => h.toUpperCase() === b.dataset.tok.toUpperCase());
        if (i >= 0) hide.splice(i, 1); else hide.push(b.dataset.tok);
        put("features.wild_box.hide", hide);
      });
    }));
    // a text box's background: on / off, around the box or a strip across the page
    pop.querySelectorAll("[data-textbg]").forEach((el) => el.addEventListener("change", () => {
      const id = el.dataset.textbg;
      edit(() => {
        pinFree();
        const i = textIndex(id);
        if (i < 0) return;
        const t = get("page.texts")[i], name = `textbg_${String(id).replace(/[^A-Za-z0-9_]/g, "_")}`;
        if (!get(`styles.${name}`)) {               // its own look, starting as a soft rounded panel
          put(`styles.${name}`, { radius: 16, fill_enabled: true, fill: "#0B1230", fill_opacity: 70,
            stroke: { enabled: false, width: 3, color: "#FFD23A", align: "inside" }, fx: "" });
        }
        t.bg = Object.assign({ mode: "box", pad: 14 }, t.bg || {}, { on: el.checked, style: name });
      });
      refreshPopover();
    }));
    pop.querySelectorAll("[data-textbgmode]").forEach((b) => b.addEventListener("click", () => {
      edit(() => { const i = textIndex(b.dataset.id); if (i >= 0) put(`page.texts.${i}.bg.mode`, b.dataset.textbgmode); });
      refreshPopover();
    }));
    // icon sizes inside text
    pop.querySelectorAll("[data-isz]").forEach((el) => el.addEventListener("input", () => {
      const k = el.dataset.isz, box = el.dataset.box, v = Number(el.value);
      el.nextElementSibling.textContent = `${v}%`;
      const only = pop.querySelector(`[data-iszonly="${CSS.escape(k)}"][data-box="${CSS.escape(box)}"]`)?.checked;
      edit(() => {
        pinFree();
        if (only) put(`${box}.icon_scale`, Object.assign({}, get(`${box}.icon_scale`) || {}, { [k]: v }));
        else put("text_icon_scale", Object.assign({}, get("text_icon_scale") || {}, { [k]: v }));
      }, `isz:${box}:${k}`);
    }));
    pop.querySelectorAll("[data-iszonly]").forEach((el) => el.addEventListener("change", () => {
      const k = el.dataset.iszonly, box = el.dataset.box;
      edit(() => {
        pinFree();
        const own = Object.assign({}, get(`${box}.icon_scale`) || {});
        if (el.checked) own[k] = Number((get("text_icon_scale") || {})[k] ?? 100);   // starts from the page-wide size
        else delete own[k];
        put(`${box}.icon_scale`, own);
      });
      refreshPopover();
    }));
    // icons left out of a text box
    pop.querySelectorAll("[data-texttok]").forEach((b) => b.addEventListener("click", () => {
      edit(() => {
        pinFree();
        const i = textIndex(b.dataset.texttok);
        if (i < 0) return;
        const hide = (get(`page.texts.${i}.hide_icons`) || []).slice();
        const j = hide.findIndex((h) => h.toUpperCase() === b.dataset.tok.toUpperCase());
        if (j >= 0) hide.splice(j, 1); else hide.push(b.dataset.tok);
        put(`page.texts.${i}.hide_icons`, hide);
      });
    }));
    // icons in a text line
    pop.querySelectorAll("[data-linetok]").forEach((b) => b.addEventListener("click", () => {
      edit(() => {
        pinFree();
        const i = textIndex(b.dataset.box);
        const hide = Object.assign({}, get(`page.texts.${i}.hide`) || {});
        const cur = (hide[b.dataset.linetok] || []).slice();
        const j = cur.findIndex((h) => h.toUpperCase() === b.dataset.tok.toUpperCase());
        if (j >= 0) cur.splice(j, 1); else cur.push(b.dataset.tok);
        hide[b.dataset.linetok] = cur;
        put(`page.texts.${i}.hide`, hide);
      });
    }));
    // split a line at a word / join a part back
    pop.querySelectorAll("[data-splitline]").forEach((b) => b.addEventListener("click", () => {
      S.splitting = S.splitting === b.dataset.splitline ? "" : b.dataset.splitline;
      refreshPopover();
    }));
    pop.querySelectorAll("[data-splitat]").forEach((b) => b.addEventListener("click", () => {
      const src = b.dataset.src, at = Number(b.dataset.splitat);
      edit(() => {
        pinFree();
        const splits = Object.assign({}, get("page.splits") || {});
        splits[src] = [...new Set([...(splits[src] || []), at])].sort((a, c) => a - c);
        put("page.splits", splits);
      });
      S.splitting = "";
      toast("Line split — move the new part to another text box with its box menu.");
    }));
    pop.querySelectorAll("[data-join]").forEach((b) => b.addEventListener("click", () => {
      const src = b.dataset.src, at = Number(b.dataset.join);
      edit(() => {
        pinFree();
        const splits = Object.assign({}, get("page.splits") || {});
        splits[src] = (splits[src] || []).filter((x) => Number(x) !== at);
        if (!splits[src].length) delete splits[src];
        put("page.splits", splits);
        // the joined parts keep the box the first part was in
        get("page.texts").forEach((t) => { t.cells = (t.cells || []).filter((c) => !c.toUpperCase().startsWith(`${src.toUpperCase()}#`)); });
      });
    }));
    // move a line (or a part of one) to another text box (or a new one)
    pop.querySelectorAll("[data-moveline]").forEach((sel) => sel.addEventListener("change", () => {
      const cell = sel.dataset.moveline, from = sel.dataset.from, src = sel.dataset.src || cell;
      edit(() => {
        pinFree();
        const texts = get("page.texts");
        if (cell !== src) {
          // a box that holds the whole line keeps its other parts, explicitly
          const parts = [...new Set(S.texts.flatMap((t) => t.lines).filter((l) => l.source_cell === src).map((l) => l.cell))];
          texts.forEach((t) => {
            if ((t.cells || []).some((c) => c.toUpperCase() === src.toUpperCase())) {
              t.cells = t.cells.filter((c) => c.toUpperCase() !== src.toUpperCase()).concat(parts.filter((p) => p !== cell));
            }
          });
        }
        texts.forEach((t) => { t.cells = (t.cells || []).filter((c) => c.toUpperCase() !== cell.toUpperCase()); });
        let target = sel.value;
        if (target === "__new") {
          const src = texts[Math.max(0, textIndex(from))] || {};
          const r = src.rect || [100, 300, 600, 120];
          target = `t${Date.now() % 100000}`;
          texts.push({ id: target, rect: [r[0], Math.max(0, r[1] - 140), Math.min(r[2], 700), 120], cells: [cell],
                       font_size: src.font_size, color: src.color, align: "left" });
        } else {
          const t = texts[textIndex(target)];
          if (t && !t.rest) t.cells = (t.cells || []).concat([cell]);
        }
        // a line moved out of the "rest" box must be claimed by its new box, never fall back
      });
      S.pop = "";
    }));
    pop.querySelector("[data-deltext]")?.addEventListener("click", (e) => {
      const id = e.target.dataset.deltext;
      edit(() => { pinFree(); const texts = get("page.texts"); texts.splice(textIndex(id), 1); });
      S.pop = "";
    });
    pop.addEventListener("pointerdown", (e) => e.stopPropagation());
  }

  function wire(root) {
    root.querySelectorAll("[data-pick]").forEach((b) => b.addEventListener("click", () => PC.pick(b.dataset.pick)));
    root.querySelectorAll("[data-show]").forEach((b) => b.addEventListener("click", () => {
      const k = b.dataset.show;
      edit(() => {
        if (k === "title") put("page.title.enabled", get("page.title.enabled") === false);
        else if (k === "features") { const on = !get("features.enabled"); put("features.enabled", on); if (on) { put("features.wild", true); put("features.scatter", true); } }
        else if (k === "notes") put("page.notes.enabled", get("page.notes.enabled") === false);
      });
      rerender();
    }));
    root.querySelector("#pcSheet")?.addEventListener("change", (e) => { S.sheet = e.target.value; S.asked = ""; PC.apply(); });
    root.querySelector("#pcUndo")?.addEventListener("click", PC.undo);
    root.querySelector("#pcCheck")?.addEventListener("click", () => PC.payCheck());
    root.querySelector("#pcRedo")?.addEventListener("click", PC.redo);
    wireStage();
    wireEditor();
  }

  function wireStage() {
    drawLive();
    const img = document.getElementById("pcImg");
    if (img) { if (img.complete) placeBlocks(); else img.addEventListener("load", placeBlocks, { once: true }); }
    document.querySelectorAll(".pcb").forEach((el) => el.addEventListener("pointerdown", startDrag));
    document.querySelectorAll("[data-edit]").forEach((b) => b.addEventListener("click", (e) => {
      e.stopPropagation();
      S.pop = S.pop === b.dataset.edit ? "" : b.dataset.edit;
      rerenderStage();
    }));
    document.querySelectorAll("[data-per]").forEach((b) => b.addEventListener("click", (e) => {
      e.stopPropagation();
      const i = Number(b.dataset.band), count = rowCount(rowKey(i)) || 20;
      const cur = Math.min(Number((get("bands") || [])[i]?.per_row) || count, count);
      const next = Math.max(1, Math.min(count, cur + Number(b.dataset.per)));
      if (next !== cur) edit(() => { const bb = get("bands")[i]; bb.per_row = next; delete bb.card_w; });
    }));
    document.querySelectorAll("[data-lock]").forEach((b) => b.addEventListener("click", (e) => { e.stopPropagation(); toggleLock(b.dataset.lock); }));
    document.querySelectorAll(".pcb.text").forEach((el) => {
      const k = el.dataset.b, id = k.slice(5);
      el.addEventListener("dblclick", (e) => {   // double-click: a size handle on every symbol in the text
        e.stopPropagation();
        if (e.target.closest(".pci, .pci-tip")) return;
        S.iconEdit = S.iconEdit === k ? "" : k;
        S.featSel = "";
        rerenderStage();
      });
      el.addEventListener("click", (e) => {
        if (!e.shiftKey && !e.ctrlKey && !e.metaKey) return;
        S.picked = S.picked.includes(k) ? S.picked.filter((x) => x !== k) : S.picked.concat([k]);
        rerenderStage();
      });
      el.addEventListener("contextmenu", (e) => {
        e.preventDefault();
        const others = S.texts.filter((t) => String(t.id) !== id);
        const n = textIndex(id);
        showMenu(e.clientX, e.clientY, [
          { label: "Edit text", run: () => openEditorFor(id) },
          ...(((S.texts.find((t) => String(t.id) === id) || {}).tokens || []).length ? [{ label: "Show / hide icons…", run: () => { S.pop = k; rerenderStage(); } }] : []),
          ...(S.picked.length > 1 && S.picked.includes(k) ? [{ label: `Merge the ${S.picked.length} selected boxes`, run: () => mergeBoxes(S.picked) }] : []),
          ...others.map((t) => ({ label: `Merge with text box ${S.texts.indexOf(t) + 1}`, run: () => mergeBoxes([k, `text:${t.id}`]) })),
          null,
          { label: locked(k) ? "Unlock position" : "Lock position", run: () => toggleLock(k) },
          ...(n > 0 ? [{ label: "Delete this box (its text goes to box 1)", run: () => deleteBox(id) }] : []),
        ]);
      });
    });
    document.getElementById("pcMergeGo")?.addEventListener("click", () => mergeBoxes(S.picked));
    document.getElementById("pcMergeNo")?.addEventListener("click", () => { S.picked = []; rerenderStage(); });
    document.querySelectorAll("#pcMerge, #pcMenu").forEach((x) => x.addEventListener("pointerdown", (e) => e.stopPropagation()));
    wireTextEditor();
    wireOverlay();
    wireGutters();
    wireIconHandles();
    wireFeatOverlay();
    document.querySelector('.pcb[data-b="wild"]')?.addEventListener("dblclick", (e) => {
      if (e.target.closest(".pci, .pci-tip, [data-fh]")) return;
      e.stopPropagation();
      S.iconEdit = S.iconEdit === "wild" ? "" : "wild";
      rerenderStage();
    });
    document.querySelectorAll(".pcb.row-box").forEach((rowEl) => rowEl.addEventListener("dblclick", (e) => {
      if (e.target.closest(".pco-bar, .pcg, [data-oh] .pco-h")) return;
      const img = document.getElementById("pcImg"), box = img && img.getBoundingClientRect();
      if (!box) return;
      const fx = (e.clientX - box.left) / box.width, fy = (e.clientY - box.top) / box.height;
      const hit = Object.keys(S.blocks).find((k) => k.startsWith("card:") && fx >= S.blocks[k][0] && fx <= S.blocks[k][2] && fy >= S.blocks[k][1] && fy <= S.blocks[k][3]);
      if (hit) isolate(hit.slice(5));
    }));
    document.querySelectorAll(".pcb-step, .pcb-edit, .pcb-lock").forEach((b) => b.addEventListener("pointerdown", (e) => e.stopPropagation()));
    wirePopover();
  }

  /* ---------- dragging on the preview ---------- */
  function startDrag(e) {
    if (e.button !== 0) return;
    const el = e.currentTarget, k = el.dataset.b, g = geo();
    if (!g) return;
    let h = (e.target.closest("[data-h]") || {}).dataset?.h || "";
    if (el.classList.contains("text") && (e.shiftKey || e.ctrlKey || e.metaKey)) return;
    // a locked box can't move or resize, but a click still reaches what is inside it
    if (el.classList.contains("locked")) h = "click";
    if (!h && el.classList.contains("free")) h = "move";
    if (!h && (k === "high" || k === "low")) h = locked(k) ? "click" : "move";
    if (!h) return;
    e.preventDefault();
    try { el.setPointerCapture(e.pointerId); } catch (_) { /* synthetic events */ }
    const r0 = { left: parseFloat(el.style.left), top: parseFloat(el.style.top), width: parseFloat(el.style.width), height: parseFloat(el.style.height) };
    const D = { x: e.clientX, y: e.clientY, dx: 0, dy: 0 };
    el.classList.add("dragging");
    const move = (ev) => {
      D.dx = ev.clientX - D.x; D.dy = ev.clientY - D.y;
      const r = { ...r0 };
      if (h === "click") return;
      if (h === "move") { r.left += D.dx; r.top += D.dy; }
      else if (h === "r") r.width = Math.max(30, r0.width + D.dx);
      else if (h === "b") r.height = Math.max(20, r0.height + D.dy);
      else if (h === "rb") { r.width = Math.max(30, r0.width + D.dx); r.height = Math.max(20, r0.height + D.dy); }
      else if (h === "w-l" || h === "w-r") { const grow = (h === "w-r" ? D.dx : -D.dx) * 2; r.width = Math.max(30, r0.width + grow); r.left = r0.left - (r.width - r0.width) / 2; }
      else if (h === "h") r.height = Math.max(20, r0.height + D.dy);
      else if (h.startsWith("sc-")) {
        const c = h.slice(3), sx = c[1] === "r" ? 1 : -1, sy = c[0] === "b" ? 1 : -1;
        const f = Math.max(0.2, Math.min(5, 1 + (sx * D.dx + sy * D.dy) / Math.max(1, r0.width + r0.height)));
        el.dataset.f = f;
        r.width = r0.width * f; r.height = r0.height * f;
        if (sx < 0) r.left = r0.left + r0.width - r.width;
        if (sy < 0) r.top = r0.top + r0.height - r.height;
      }
      else if (h.startsWith("m-")) {
        const side = h.slice(2);
        if (side === "top") { r.top = r0.top + D.dy; r.height = r0.height - D.dy; }
        if (side === "bottom") r.height = r0.height + D.dy;
        if (side === "left") { r.left = r0.left + D.dx; r.width = r0.width - 2 * D.dx; }
        if (side === "right") { r.width = r0.width + 2 * D.dx; r.left = r0.left - D.dx; }
      }
      Object.assign(el.style, { left: `${r.left}px`, top: `${r.top}px`, width: `${r.width}px`, height: `${r.height}px` });
    };
    const up = () => {
      el.removeEventListener("pointermove", move);
      el.removeEventListener("pointerup", up);
      el.classList.remove("dragging");
      if (Math.abs(D.dx) < 3 && Math.abs(D.dy) < 3) {
        if ((k === "high" || k === "low") && (h === "move" || h === "click")) pickCard(D.x, D.y, g);
        else if (k === "wild" && (h === "move" || h === "click") && S.featSel !== "wild") { S.featSel = "wild"; S.iconEdit = ""; S.symSel = ""; rerenderStage(); }
        else placeBlocks();
        return;
      }
      if (h === "click") { placeBlocks(); return; }
      finishDrag(k, h, D, g, el);
    };
    el.addEventListener("pointermove", move);
    el.addEventListener("pointerup", up);
  }

  /* ---------- symbol sizes: one symbol, or all of them ---------- */
  function pickCard(cx, cy, g) {
    const box = g.img.getBoundingClientRect();
    const fx = (cx - box.left) / box.width, fy = (cy - box.top) / box.height;
    const hit = Object.keys(S.blocks).find((k) => {
      if (!k.startsWith("card:")) return false;
      const b = S.blocks[k];
      return fx >= b[0] && fx <= b[2] && fy >= b[1] && fy <= b[3];
    });
    S.symSel = hit ? hit.slice(5) : "";
    if (S.isolated && S.isolated !== S.symSel) S.isolated = "";
    S.pop = "";
    rerenderStage();
    if (hit) toast("Card picked — drag the symbol or the numbers, use the bar above it to align. Every card follows.");
  }
  function isolate(name) {
    if (!name) return;
    S.symSel = name; S.isolated = name; S.pop = "";
    rerenderStage();
    toast(`Editing only ${String(name).toUpperCase()} — nothing else moves or resizes. "All" goes back to the whole row.`);
  }
  const symSizes = () => get("card.symbol_size") || {};
  function symPct(name) {
    const z = symSizes();
    const v = name && z[name] != null ? z[name] : z["*"];
    return Number.isFinite(Number(v)) ? Number(v) : 100;
  }
  function setSym(name, v) {
    v = Math.max(20, Math.min(300, Math.round(v)));
    edit(() => put(`card.symbol_size.${name || "*"}`, v), `sym:${name}`);
  }
  function symAll(v) {                           // one size for every symbol
    edit(() => put("card.symbol_size", { "*": Math.max(20, Math.min(300, Math.round(v))) }));
  }
  function symbolControls() {
    const name = S.symSel, pct = symPct(name), own = name && symSizes()[name] != null;
    const nice = (n) => String(n).toUpperCase();
    return `<div class="pcp-sub">Symbol size</div>
      <div class="pc-symsel">${name ? `<b>${esc(nice(name))}</b>${own ? "" : ` <span class="pcp-note">(same as all)</span>`}` : "<b>All symbols</b>"}
        ${name ? `<button class="pc-chip" data-symsel="">All symbols</button>` : ""}</div>
      <div class="pc-symrow"><button class="pcb-step" data-symstep="-10" title="Smaller">−</button>
        <input type="range" data-sym min="20" max="300" step="5" value="${pct}"><output>${pct}%</output>
        <button class="pcb-step" data-symstep="10" title="Bigger">+</button></div>
      ${name ? `<button class="btn secondary small pcp-wide" data-symall="${pct}">Apply ${pct}% to all symbols</button>` : ""}
      ${Object.keys(symSizes()).length ? `<button class="btn secondary small pcp-wide" data-symreset>Reset all symbols to 100%</button>` : ""}
      <div class="pcp-note">${name ? "Only this symbol changes." : "Click a card on the preview to size just its symbol."}</div>`;
  }

  /* ---------- the picked card: edit its parts right on it (every card follows) ---------- */
  const bandKey = (i) => (i ? "low" : "high");
  // what the picked card's band shows: its parts as laid out (the card may have grown around them)
  const isolating = () => !!S.isolated && S.isolated === S.symSel;
  const lc = (n) => String(n || "").toLowerCase();
  function viewParts(i = cardBand(S.symSel)) {
    if (isolating()) {
      const own = (S.cardGeo || {})[lc(S.isolated)] || ((get("card_overrides") || {})[lc(S.isolated)] || {}).parts;
      if (own) return own;
    }
    const g = (S.bandGeo || {})[bandKey(i)];
    return (g && g.parts) || get(`bands.${i}.parts`) || get("card.parts") || [];
  }
  // inside edit(): the band takes its own copy of its parts as drawn, with the card size they were drawn at
  function ownParts(i = cardBand(S.symSel), rowOnly = false) {
    if (isolating() && !rowOnly) {                        // only this card: its own copy, the grid untouched
      const key = lc(S.isolated), ov = get("card_overrides") || {};
      if (!ov[key]) ov[key] = { parts: JSON.parse(JSON.stringify(viewParts(i))) };
      put("card_overrides", ov);
      return ov[key].parts;
    }
    const b = (get("bands") || [])[i], g = (S.bandGeo || {})[bandKey(i)];
    if (!b) return get("card.parts") || [];
    if (g && g.parts) {
      b.parts = JSON.parse(JSON.stringify(g.parts));
      if (g.size) { b.card_w = Math.round(g.size[0]); b.card_h = Math.round(g.size[1]); }
    } else if (!b.parts) b.parts = JSON.parse(JSON.stringify(get("card.parts") || []));
    return b.parts;
  }
  const partIdx = (role) => viewParts().findIndex((p) => p.role === role);
  const r3 = (v) => Math.round(v * 1000) / 1000;
  function numbersBox(parts) {
    const ps = [parts[partIdx("counts")], parts[partIdx("pays")]].filter(Boolean);
    if (!ps.length) return null;
    const x0 = Math.min(...ps.map((p) => +p.x || 0)), y0 = Math.min(...ps.map((p) => +p.y || 0));
    const x1 = Math.max(...ps.map((p) => (+p.x || 0) + (+p.w || 0))), y1 = Math.max(...ps.map((p) => (+p.y || 0) + (+p.h || 0)));
    return { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
  }
  function cardBand(name) {
    const b = S.blocks[`card:${name}`], lo = S.blocks.low;
    if (!b || !lo) return 0;
    const cy = (b[1] + b[3]) / 2;
    return cy >= lo[1] && cy <= lo[3] ? 1 : 0;
  }
  function lineH() {
    const parts = viewParts(), c = parts[partIdx("counts")] || parts[partIdx("pays")] || {};
    return Math.round(Number(c.line_height) || Number(c.font_size || 30) * 1.25);
  }
  const ALIGN_ICONS = {
    left: '<path d="M3 2v16"/><rect x="6" y="5" width="10" height="4"/><rect x="6" y="11" width="6" height="4"/>',
    hcenter: '<path d="M10 2v16"/><rect x="4" y="5" width="12" height="4"/><rect x="6" y="11" width="8" height="4"/>',
    right: '<path d="M17 2v16"/><rect x="4" y="5" width="10" height="4"/><rect x="8" y="11" width="6" height="4"/>',
    top: '<path d="M2 3h16"/><rect x="5" y="6" width="4" height="10"/><rect x="11" y="6" width="4" height="6"/>',
    vcenter: '<path d="M2 10h16"/><rect x="5" y="4" width="4" height="12"/><rect x="11" y="6" width="4" height="8"/>',
    bottom: '<path d="M2 17h16"/><rect x="5" y="4" width="4" height="10"/><rect x="11" y="8" width="4" height="6"/>',
  };
  const ALIGN_TIPS = { left: "Align left", hcenter: "Centre horizontally", right: "Align right",
                       top: "Align top", vcenter: "Centre vertically", bottom: "Align bottom" };
  // a drawn box (image fractions) as a box of the card (card fractions)
  function inCard(name, keys) {
    const c = S.blocks[`card:${name}`], ds = keys.map((k) => (S.drawn || {})[k]).filter(Boolean);
    if (!c || !ds.length) return null;
    const cw = Math.max(1e-6, c[2] - c[0]), ch = Math.max(1e-6, c[3] - c[1]);
    const x0 = Math.min(...ds.map((d) => d[0])), y0 = Math.min(...ds.map((d) => d[1]));
    const x1 = Math.max(...ds.map((d) => d[2])), y1 = Math.max(...ds.map((d) => d[3]));
    return { x: (x0 - c[0]) / cw, y: (y0 - c[1]) / ch, w: (x1 - x0) / cw, h: (y1 - y0) / ch };
  }
  const symDrawn = (name) => inCard(name, [`@slot.${name}`]);
  function symBox(p) {
    const name = S.symSel, d = symDrawn(name), c = S.blocks[`card:${name}`];
    if (!d || !c) return { x: +p.x || 0, y: +p.y || 0, w: +p.w || 1, h: +p.h || 1 };
    const cw = (S.canvas && S.canvas.width) || 1920, ch = (S.canvas && S.canvas.height) || 1080;
    const px = 2 / Math.max(1, cw * (c[2] - c[0])), py = 2 / Math.max(1, ch * (c[3] - c[1]));   // the renderer's 2px inset
    const own = symPct(name) / 100 || 1;                     // this symbol's own size is not everyone's
    const w = (d.w + 2 * px) / own, h = (d.h + 2 * py) / own;
    const mx = d.x + d.w / 2, my = d.y + d.h / 2;
    return { x: mx - w / 2, y: my - h / 2, w, h };
  }
  function cardOverlay() {
    const name = S.symSel, parts = viewParts();
    const pct = (v) => `${(v * 100).toFixed(3)}%`;
    const at = (r) => `left:${pct(+r.x || 0)};top:${pct(+r.y || 0)};width:${pct(+r.w || 1)};height:${pct(+r.h || 1)}`;
    const sym = partIdx("symbol") >= 0 ? (symDrawn(name) || parts[partIdx("symbol")]) : null;
    const nb = numbersBox(parts) ? (inCard(name, [`@slot.${name}.pay`, `@slot.${name}.value`]) || numbersBox(parts)) : null;
    const ab = (k) => `<button class="pco-al" data-oa="al-${k}" title="${ALIGN_TIPS[k]} (symbol and numbers together)"><svg viewBox="0 0 20 20">${ALIGN_ICONS[k]}</svg></button>`;
    return `<div class="pcb-inner pco ${isolating() ? "iso" : ""}" data-inner="card:${esc(name)}">
      <div class="pco-bar">${isolating()
        ? `<span class="pco-band iso">Only ${esc(String(name).toUpperCase())}</span><button class="pco-al txt wide" data-oa="isooff" title="Back to editing every ${cardBand(name) ? "bottom" : "top"} card">All</button>${(get("card_overrides") || {})[lc(name)] ? `<button class="pco-al txt wide" data-oa="isoreset" title="This card goes back to the ${cardBand(name) ? "bottom" : "top"} cards' design">Reset</button>` : ""}`
        : `<span class="pco-band">${cardBand(name) ? "Bottom cards" : "Top cards"}</span><button class="pco-al txt" data-oa="ison" title="Edit only this card (or double-click it)">1</button>${(get("card_overrides") || {})[lc(name)]
          ? `<span class="pco-band iso" title="This card was edited on its own: row changes don't move it">Own design</span><button class="pco-al txt wide" data-oa="isoreset" title="Drop its own design and follow the row again">Follow row</button>` : ""}`}${locked(rowKey(cardBand(name))) ? `<span class="pco-lock" title="This row's box is locked: bigger content scales down to stay inside it. Unlock to let the box grow.">🔒 Box locked</span>` : ""}<span class="pco-grp">${["left", "hcenter", "right"].map(ab).join("")}</span><span class="pco-grp">${["top", "vcenter", "bottom"].map(ab).join("")}</span>
        ${isolating() ? "" : `<button class="pco-al" data-oa="look" title="Card look: colour, corners, border, layer style">✎</button>`}
        <button class="pco-al txt" data-oa="symsize" title="Size of ${esc(String(name).toUpperCase())} only, or all symbols">%</button>
        <span class="pco-grp">${[["left", "Numbers on the left", "◧"], ["below", "Numbers under the symbol", "⬓"], ["right", "Numbers on the right", "◨"]]
          .map(([w, tip, ic]) => `<button class="pco-al txt" data-oa="num-${w}" title="${tip}">${ic}</button>`).join("")}</span>
        <button class="pco-al" data-oa="close" title="Done with this card">✕</button></div>
      ${sym ? `<div class="pco-part sym" data-oh="sym-move" style="${at(sym)}" title="Drag to move the symbol">
          <div class="pco-h tr" data-oh="sym-scale" title="Drag to resize the symbol (keeps its shape)">⤢</div></div>` : ""}
      ${nb ? `<div class="pco-part num" data-oh="num-move" style="${at(nb)}" title="Pays and values: drag to move · corner to scale both together">
          <button class="pco-edit" data-oa="numbers" title="Font, colours, bold, italic">✎</button>
          <div class="pco-h br" data-oh="num-scale" title="Drag to scale the pays and values together">⤡</div>
          <div class="pco-h r" data-oh="lh" title="Drag up / down: line height">↕</div>
          <div class="pco-h b" data-oh="gap" title="Drag left / right: space between counts and pays">↔</div></div>` : ""}
      ${isolating() ? "" : `<div class="pco-h cr" data-oh="cw" title="Card width">↔</div>
      <div class="pco-h cb" data-oh="ch" title="Card height">↕</div>`}
    </div>`;
  }
  // symbol and numbers side by side (numbers left / right) or stacked (numbers below); sizes kept,
  // the pair centred on the card (the card keeps its size: a pair wider than the card reaches past its edges)
  function numbersWhere() {                     // where the numbers sit now: "left", "below" or "right"
    const parts = viewParts(), s = parts[partIdx("symbol")], n = [parts[partIdx("counts")], parts[partIdx("pays")]].filter(Boolean);
    if (!s || !n.length) return "right";
    const ny = Math.min(...n.map((p) => +p.y || 0)), nx = Math.min(...n.map((p) => +p.x || 0));
    if (ny >= (+s.y || 0) + (+s.h || 0) * 0.6) return "below";
    return nx < (+s.x || 0) ? "left" : "right";
  }
  function arrangeNumbers(where, gapPx, quiet) {
    const i = cardBand(S.symSel), [W, H] = cardSize(i);
    const iS = partIdx("symbol"), iC = partIdx("counts"), iP = partIdx("pays");
    if (iS < 0 || (iC < 0 && iP < 0)) return;
    edit(() => {
      const ps = ownParts(i), sym = ps[iS];
      const sb = symBox(sym), s = { x: sb.x * W, y: sb.y * H, w: sb.w * W, h: sb.h * H };
      const nums = [ps[iC], ps[iP]].filter(Boolean);
      const n0 = { x: Math.min(...nums.map((p) => p.x * W)), y: Math.min(...nums.map((p) => p.y * H)) };
      const n = { w: Math.max(...nums.map((p) => (p.x + p.w) * W)) - n0.x, h: Math.max(...nums.map((p) => (p.y + p.h) * H)) - n0.y };
      const gap = gapPx != null ? Math.max(0, gapPx) : Math.max(8, W * 0.04);
      let sx, sy, nx, ny;
      if (where === "below") {
        const tot = s.h + gap + n.h, y0 = (H - tot) / 2;
        sx = (W - s.w) / 2; sy = y0; nx = (W - n.w) / 2; ny = y0 + s.h + gap;
      } else {
        const tot = s.w + gap + n.w, x0 = (W - tot) / 2;
        sy = (H - s.h) / 2; ny = (H - n.h) / 2;
        if (where === "left") { nx = x0; sx = x0 + n.w + gap; } else { sx = x0; nx = x0 + s.w + gap; }
      }
      Object.assign(sym, { x: r3(sx / W), y: r3(sy / H), w: r3(s.w / W), h: r3(s.h / H) });
      nums.forEach((p) => { p.x = r3((p.x * W - n0.x + nx) / W); p.y = r3((p.y * H - n0.y + ny) / H); });
    }, quiet ? "insp:gap" : "");
    if (!quiet) toast(where === "below" ? "Numbers under the symbol." : `Numbers on the ${where}.`);
  }
  function alignParts(how) {
    const parts = viewParts();
    if (!parts.length) return;
    const x0 = Math.min(...parts.map((p) => +p.x || 0)), x1 = Math.max(...parts.map((p) => (+p.x || 0) + (+p.w || 1)));
    const y0 = Math.min(...parts.map((p) => +p.y || 0)), y1 = Math.max(...parts.map((p) => (+p.y || 0) + (+p.h || 1)));
    const m = 0.04;
    const dx = { left: m - x0, hcenter: 0.5 - (x0 + x1) / 2, right: 1 - m - x1 }[how] || 0;
    const dy = { top: m - y0, vcenter: 0.5 - (y0 + y1) / 2, bottom: 1 - m - y1 }[how] || 0;
    edit(() => ownParts().forEach((p) => { p.x = r3((+p.x || 0) + dx); p.y = r3((+p.y || 0) + dy); }));
  }
  function wireOverlay() {
    const ov = document.querySelector(".pco");
    if (!ov) return;
    ov.querySelectorAll("[data-oa]").forEach((b) => {
      b.addEventListener("pointerdown", (e) => e.stopPropagation());
      b.addEventListener("click", (e) => {
        e.stopPropagation();
        const a = b.dataset.oa;
        if (a.startsWith("al-")) { alignParts(a.slice(3)); return; }
        if (a.startsWith("num-")) { arrangeNumbers(a.slice(4)); return; }
        if (a === "close") { S.symSel = ""; S.isolated = ""; S.pop = ""; rerenderStage(); return; }
        if (a === "ison") { isolate(S.symSel); return; }
        if (a === "isooff") { S.isolated = ""; S.pop = ""; rerenderStage(); return; }
        if (a === "isoreset") {
          const key = lc(S.isolated || S.symSel);
          edit(() => { const ov = get("card_overrides") || {}; delete ov[key]; });
          toast("This card follows its row's design again.");
          return;
        }
        const pop = { look: "cardlook", numbers: "numbers", symsize: "cards" }[a];
        S.pop = S.pop === pop ? "" : pop;
        rerenderStage();
      });
    });
    ov.querySelectorAll("[data-oh]").forEach((el) => el.addEventListener("pointerdown", (e) => overlayDrag(e, el)));
    // double-click the pays & values: type their font size, colours, bold / italic
    ov.querySelector(".pco-part.num")?.addEventListener("dblclick", (e) => {
      e.stopPropagation();
      S.pop = "numbers";
      rerenderStage();
      setTimeout(() => document.querySelector('#pcPop [data-both="font_size"]')?.select(), 0);
    });
  }
  function overlayDrag(e, el) {
    if (e.button !== 0 || e.target.closest("[data-oa]")) return;
    const kind = e.target.closest("[data-oh]").dataset.oh;
    if (kind !== el.dataset.oh) return;                // a handle inside a part box handles itself
    e.stopPropagation();
    e.preventDefault();
    const ov = el.closest(".pco"), g = geo();
    if (!ov || !g) return;
    try { el.setPointerCapture(e.pointerId); } catch (_) { /* synthetic events */ }
    const target = kind.startsWith("sym") ? ov.querySelector(".pco-part.sym") : ["num-move", "num-scale", "gap", "lh"].includes(kind) ? ov.querySelector(".pco-part.num") : null;
    const t0 = target && { l: target.offsetLeft, t: target.offsetTop, w: target.offsetWidth, h: target.offsetHeight };
    const D = { x: e.clientX, y: e.clientY, dx: 0, dy: 0 };
    const scaleF = () => kind === "num-scale"
      ? Math.max(0.2, 1 + (D.dx + D.dy) / Math.max(1, t0.w + t0.h))    // bottom-right corner: out = bigger
      : Math.max(0.15, 1 + (D.dx - D.dy) / Math.max(1, t0.w + t0.h));  // the symbol's top-right corner
    const img = document.getElementById("pcImg");
    let ghost = null;
    const snap = JSON.stringify(S.tpl);
    let frame = 0;
    S.dragging = true;
    const preview = () => {                      // the design as it would be if you let go now
      frame = 0;
      S.tpl = JSON.parse(snap);
      S.dragLive = true;
      try { commitOverlay(kind, D, ov, g, t0 ? scaleF() : 1); } finally { S.dragLive = false; }
    };
    if (!window.PCLive && target && img && ["sym-move", "num-move", "sym-scale"].includes(kind)) {
      const tr = target.getBoundingClientRect(), ir = img.getBoundingClientRect();
      ghost = { x: tr.left - ir.left, y: tr.top - ir.top, w: ir.width, h: ir.height };
      Object.assign(target.style, { backgroundImage: `url("${img.src}")`, backgroundRepeat: "no-repeat",
        backgroundSize: `${ghost.w}px ${ghost.h}px`, backgroundPosition: `${-ghost.x}px ${-ghost.y}px` });
      target.classList.add("ghost");
    }
    ov.classList.add("dragging");
    const move = (ev) => {
      D.dx = ev.clientX - D.x; D.dy = ev.clientY - D.y;
      if (kind === "sym-move" || kind === "num-move") Object.assign(target.style, { left: `${t0.l + D.dx}px`, top: `${t0.t + D.dy}px` });
      else if (kind === "sym-scale") {
        const f = scaleF();
        Object.assign(target.style, { width: `${t0.w * f}px`, height: `${t0.h * f}px`, top: `${t0.t + t0.h - t0.h * f}px` });
        if (ghost) Object.assign(target.style, { backgroundSize: `${ghost.w * f}px ${ghost.h * f}px`, backgroundPosition: `${-ghost.x * f}px ${-ghost.y * f}px` });
      }
      else if (kind === "num-scale") { const f = scaleF(); Object.assign(target.style, { width: `${t0.w * f}px`, height: `${t0.h * f}px` }); }
      else if (kind === "gap" || kind === "cw") el.style.transform = `translateX(${D.dx}px)`;
      else if (kind === "lh" || kind === "ch") el.style.transform = `translateY(${D.dy}px)`;
      else if (kind === "gutter") el.style.transform = `translate(${D.dx}px, ${D.dy}px)`;
      if (window.PCLive && !frame) frame = setTimeout(preview, 24);      // ~40 updates a second, never queued up
    };
    const up = () => {
      el.removeEventListener("pointermove", move);
      el.removeEventListener("pointerup", up);
      ov.classList.remove("dragging");
      if (frame) clearTimeout(frame);
      S.tpl = JSON.parse(snap);
      if (Math.abs(D.dx) < 2 && Math.abs(D.dy) < 2) { S.dragging = false; el.style.transform = ""; PC.live(); return; }
      commitOverlay(kind, D, ov, g, t0 ? scaleF() : 1);   // one undo step, measured from where the drag began
      S.dragging = false;
    };
    el.addEventListener("pointermove", move);
    el.addEventListener("pointerup", up);
  }
  function commitOverlay(kind, D, ov, g, f) {
    const iS = partIdx("symbol"), iC = partIdx("counts"), iP = partIdx("pays");
    const fx = D.dx / Math.max(1, ov.clientWidth), fy = D.dy / Math.max(1, ov.clientHeight);
    let parts = null;
    const own = () => (parts = parts || ownParts());          // only this card's band (top or bottom) changes
    const shift = (i, dx, dy) => { const p = own()[i]; if (p) { p.x = r3((+p.x || 0) + dx); p.y = r3((+p.y || 0) + dy); } };
    const design = (px) => px * g.k / bandFit(cardBand(S.symSel));   // displayed px -> design px of an unshrunk card
    if (kind === "sym-move") edit(() => { const p = own()[iS]; if (p) { Object.assign(p, symBox(p)); shift(iS, fx, fy); } });
    else if (kind === "num-move") edit(() => { shift(iC, fx, fy); shift(iP, fx, fy); });
    else if (kind === "sym-scale") edit(() => {
      const p = own()[iS];
      if (!p) return;
      const b = symBox(p), bottom = b.y + b.h;                 // the symbol as you see it
      p.w = r3(b.w * f); p.h = r3(b.h * f);                    // any size, same shape: only the symbol changes
      p.x = r3(b.x); p.y = r3(bottom - p.h);                     // (the card and the numbers stay as they are)
    });
    else if (kind === "num-scale") edit(() => {         // pays and values as one group: boxes, font and spacing
      const nums = [own()[iC], own()[iP]].filter(Boolean);
      if (!nums.length) return;
      const gx = Math.min(...nums.map((p) => +p.x || 0)), gy = Math.min(...nums.map((p) => +p.y || 0));
      nums.forEach((p) => {
        p.x = r3(gx + ((+p.x || 0) - gx) * f); p.y = r3(gy + ((+p.y || 0) - gy) * f);
        p.w = r3((+p.w || 1) * f); p.h = r3((+p.h || 1) * f);
        p.font_size = Math.max(6, Math.round((Number(p.font_size) || 30) * f * 10) / 10);
        if (p.line_height) p.line_height = Math.max(6, Math.round(p.line_height * f));
      });
    });
    else if (kind === "gap") edit(() => {
      const c = own()[iC], p = own()[iP];
      if (c && p && c.align === "right" && (p.align || "left") === "left") {
        // the space between the counts' right edge and the pays' left edge, never below nothing (else
        // the columns cross and swap sides), both moving about their middle
        const cR = (+c.x || 0) + (+c.w || 1), gap = Math.max(0, (+p.x || 0) - cR + fx), mid = ((+p.x || 0) + cR) / 2;
        c.x = r3(mid - gap / 2 - (+c.w || 1)); p.x = r3(mid + gap / 2);
        return;
      }
      shift(iC, -fx / 2, 0); shift(iP, fx / 2, 0);
    });
    else if (kind === "lh") {
      const v = Math.max(10, Math.round(lineH() + D.dy * g.k * ((S.canvas && S.canvas.scale) || 1)));
      edit(() => [iC, iP].forEach((i) => { if (own()[i]) own()[i].line_height = v; }));
    } else if (kind === "cw" || kind === "ch") {
      // the card resizes, its content keeps its size (centred); it can't get smaller than the content
      const i = cardBand(S.symSel);
      edit(() => {
        const ps = own(), b = get("bands")[i], [w, h] = cardSize(i);
        if (kind === "cw") {
          const nw = Math.max(60, Math.round(w + design(D.dx))), k = w / nw;
          ps.forEach((p) => { p.w = r3((+p.w || 1) * k); p.x = r3(((+p.x || 0) * w + (nw - w) / 2) / nw); });
          b.card_w = nw;
        } else {
          const nh = Math.max(40, Math.round(h + design(D.dy))), k = h / nh;
          ps.forEach((p) => { p.h = r3((+p.h || 1) * k); p.y = r3(((+p.y || 0) * h + (nh - h) / 2) / nh); });
          b.card_h = nh;
        }
      });
    }
  }

  /* ---------- gutters: hover any gap between cards or rows ---------- */
  function computeGutters() {
    Object.keys(S.blocks).filter((k) => k.startsWith("gut:")).forEach((k) => delete S.blocks[k]);
    const cards = Object.keys(S.blocks).filter((k) => k.startsWith("card:")).map((k) => S.blocks[k]);
    if (!cards.length) return;
    const rows = [];
    cards.slice().sort((a, b) => a[1] - b[1] || a[0] - b[0]).forEach((b) => {
      const r = rows.find((r) => Math.abs(r.y0 - b[1]) < 0.004);
      if (r) { r.cards.push(b); r.y1 = Math.max(r.y1, b[3]); } else rows.push({ y0: b[1], y1: b[3], cards: [b] });
    });
    const hi = S.blocks.high, band = (r) => (hi && r.y0 < hi[3] - 0.002 ? 0 : 1);
    let n = 0;
    rows.forEach((r) => {
      r.cards.sort((a, b) => a[0] - b[0]);
      for (let i = 1; i < r.cards.length; i++) {
        const a = r.cards[i - 1], b = r.cards[i];
        S.blocks[`gut:${n++}:v:${band(r)}`] = [a[2], Math.min(a[1], b[1]), b[0], Math.max(a[3], b[3])];
      }
    });
    rows.sort((a, b) => a.y0 - b.y0);
    for (let i = 1; i < rows.length; i++) {
      const a = rows[i - 1], b = rows[i];
      const x0 = Math.min(...a.cards.concat(b.cards).map((c) => c[0])), x1 = Math.max(...a.cards.concat(b.cards).map((c) => c[2]));
      S.blocks[`gut:${n++}:h:${band(a) !== band(b) ? "b" : band(a)}`] = [x0, a.y1, x1, b.y0];
    }
  }
  function gutterHtml(row) {
    return Object.keys(S.blocks).filter((k) => k.startsWith("gut:") && k.split(":")[3] === String(row)).map((k) => {
      const between = k.endsWith(":b");
      return `<div class="pcb-inner pcg ${k.split(":")[2]}" data-inner="${k}">
        <button class="pcg-h" data-gut="x" data-row="${k.split(":")[3]}" title="Space between cards (this row): drag left / right">↔</button>
        <button class="pcg-h" data-gut="${between ? "band" : "y"}" data-row="${k.split(":")[3]}" title="${between ? "Gap between the high and low cards" : "Space between lines of cards (this row)"}: drag up / down">↕</button></div>`;
    }).join("");
  }
  function wireGutters() {
    document.querySelectorAll(".pcg-h").forEach((el) => el.addEventListener("pointerdown", (e) => {
      if (e.button !== 0) return;
      e.stopPropagation();
      e.preventDefault();
      const g = geo();
      if (!g) return;
      try { el.setPointerCapture(e.pointerId); } catch (_) { /* synthetic events */ }
      const which = el.dataset.gut, D = { x: e.clientX, y: e.clientY, dx: 0, dy: 0 };
      el.closest(".pcg").classList.add("active");
      const move = (ev) => {
        D.dx = ev.clientX - D.x; D.dy = ev.clientY - D.y;
        el.style.transform = which === "x" ? `translateX(${D.dx}px)` : `translateY(${D.dy}px)`;
      };
      const up = () => {
        el.removeEventListener("pointermove", move);
        el.removeEventListener("pointerup", up);
        el.closest(".pcg")?.classList.remove("active");
        const ri = Number(el.dataset.row) || 0;
        const d = (which === "x" ? D.dx : D.dy) * g.k / bandFit(ri);
        if (Math.abs(which === "x" ? D.dx : D.dy) < 2) { el.style.transform = ""; return; }
        if (which === "band") { edit(() => put("page.band_gap", Math.max(0, Math.round(Number(get("page.band_gap") ?? get("page.gap_y") ?? 20) + d)))); return; }
        const pk = which === "x" ? "gap_x" : "gap_y";
        edit(() => {
          const b = get("bands")[ri];
          b[pk] = Math.max(0, Math.round(Number(b[pk] ?? get(`page.${pk}`) ?? (pk === "gap_x" ? 24 : 20)) + d));
        });
      };
      el.addEventListener("pointermove", move);
      el.addEventListener("pointerup", up);
    }));
  }

  function finishDrag(k, h, D, g, el) {
    const dxd = D.dx * g.k, dyd = D.dy * g.k;      // design px
    if (el.classList.contains("free")) {           // WILD / SCATTER / text box: its new box, as shown
      const pad = 4;
      const fx = (parseFloat(el.style.left) + pad - g.ox) / g.w, fy = (parseFloat(el.style.top) + pad - g.oy) / g.h;
      const fx1 = fx + (parseFloat(el.style.width) - 2 * pad) / g.w, fy1 = fy + (parseFloat(el.style.height) - 2 * pad) / g.h;
      const [x0, y0] = toDesign(fx, fy), [x1, y1] = toDesign(fx1, fy1);
      const rect = [Math.round(x0), Math.round(y0), Math.round(x1 - x0), Math.round(y1 - y0)];
      edit(() => {
        pinFree();
        if (k === "wild" || k === "scatter") {
          const tab = get("features.tab.enabled") !== false ? Number(get("features.tab_h") || 56) : 0;
          put(`features.${k}_box.rect`, [rect[0], rect[1] + tab / 2, rect[2], Math.max(40, rect[3] - tab / 2)]);
        } else {
          const i = textIndex(k.slice(5));
          if (i >= 0) put(`page.texts.${i}.rect`, rect);
        }
      });
      return;
    }
    if (k === "title") {
      edit(() => put("page.title.w", Math.max(120, Math.round(Number(get("page.title.w") || 900) + (h === "w-r" ? dxd : -dxd) * 2))));
      return;
    }
    if (k === "high" || k === "low") {             // only this row changes
      const i = rowIdx(k), r = rectOf(k);
      if (!r) return;
      if (h === "move") {
        edit(() => { get("bands")[i].pos = [Math.round(Math.max(0, Math.min(DW() - r[2], r[0] + dxd))), Math.round(Math.max(0, Math.min(DH() - r[3], r[1] + dyd)))]; });
        return;
      }
      if (h.startsWith("sc-")) {                    // the whole row scales: cards, their content, spacing
        const f = Number(el.dataset.f) || 1, c = h.slice(3);
        edit(() => scaleRow(i, f, c, r));
        toast(`${label(k)}: ${Math.round(f * 100)}% — cards, symbols, numbers and spacing together.`);
        return;
      }
      if (h === "w-l" || h === "w-r") {
        const grow = (h === "w-r" ? dxd : -dxd) * 2, f = Math.max(0.3, (r[2] + grow) / Math.max(1, r[2]));
        edit(() => resizeRow(i, Math.max(60, Math.round(cardSize(i)[0] * f)), null));
      } else if (h === "h") {
        const f = Math.max(0.3, (r[3] + dyd) / Math.max(1, r[3]));
        edit(() => resizeRow(i, null, Math.max(40, Math.round(cardSize(i)[1] * f))));
      }
      return;
    }
    if (k === "page" && h.startsWith("m-")) {
      const side = h.slice(2);
      const key = { top: "page.top", bottom: "page.bottom", left: "page.left", right: "page.right" }[side];
      const delta = { top: dyd, bottom: -dyd, left: dxd, right: -dxd }[side];
      edit(() => {
        const v = Math.max(0, Math.round(Number(get(key) || 0) + delta));
        put(key, v);
        if (side === "left" || side === "right") { put("page.left", v); put("page.right", v); }   // side margins stay even
      });
    }
  }

  PC.addText = () => {
    edit(() => {
      pinFree();
      const texts = get("page.texts") || [];
      if (!texts.length) put("page.texts", texts);
      texts.push({ id: `t${Date.now() % 100000}`, rect: [120, 300, 500, 120], font_size: 24, color: "#FFFFFF", align: "left" });
      put("page.notes.enabled", true);
    });
    toast("New text box added — drag it into place, then double-click it to type, or move text into it.");
  };

  /* WILD / SCATTER boxes the sheet has: what they hold, which were added for this sheet, which stay */
  function featureInfo(d) {
    return { featureParts: d.feature_parts || {}, autoBoxes: d.auto_boxes || [], requiredBoxes: d.required_boxes || [] };
  }
  const noted = new Set();
  function noteAutoBoxes() {                  // once per sheet + design: say which boxes were added
    const add = (S.autoBoxes || []).filter((b) => !noted.has(`${S.sheet}|${S.baseId}|${b}`));
    if (!add.length) return;
    add.forEach((b) => noted.add(`${S.sheet}|${S.baseId}|${b}`));
    const names = add.map((b) => (b === "wild" ? "WILD" : "SCATTER")).join(" and ");
    toast(`This sheet has a ${names} symbol with its own pays, so a ${names} box was added in this design's style — ` +
      `drag it anywhere; ✎ → Customise to move or style its heading and caption.`);
  }

  /* ---------- the customiser ---------- */
  function openEditor(kind) {
    S.editor = kind;
    S.sel = 0;
    S.pop = "";
    if (kind !== "card") edit(() => {
      pinFree();
      // the parts the box really holds (a box the design didn't have, or the sheet's heading /
      // "pay any" caption the design had no part for) become the design's own, ready to edit
      const path = `features.${kind}_parts`, have = get(path) || {}, real = (S.featureParts || {})[kind] || {};
      const missing = Object.keys(real).filter((p) => !have[p]);
      if (missing.length) put(path, Object.assign({}, JSON.parse(JSON.stringify(real)), have));
    });
    rerender();
  }
  function wireEditor() {
    const ov = document.getElementById("pcEditor");
    if (!ov) return;
    wireInputs(ov);
    ov.querySelectorAll("[data-closeeditor]").forEach((b) => b.addEventListener("click", () => { S.editor = null; rerender(); }));
    // a click outside never closes it (what was typed in it would be lost): its ✕ or Cancel do
    ov.querySelectorAll("[data-cardsize]").forEach((el) => el.addEventListener("change", () => {
      const i = Number(el.dataset.band), v = Number(el.value);
      if (!Number.isFinite(v) || v <= 0) return;
      edit(() => { const b = get("bands")[i]; if (el.dataset.cardsize === "w") b.card_w = Math.round(v); else b.card_h = Math.round(v); });
      rerender();
    }));
    ov.querySelectorAll("[data-cardauto]").forEach((b) => b.addEventListener("click", () => {
      edit(() => { delete get("bands")[Number(b.dataset.cardauto)].card_w; });
      rerender();
    }));
    ov.querySelector("[data-addtext]")?.addEventListener("click", () => {
      edit(() => {
        const parts = get("card.parts") || [];
        const n = parts.filter((p) => p.role === "text").length + 1;
        parts.push({ role: "text", id: `t${n}`, label: `Text ${n}`, x: 0.05, y: 0.78, w: 0.9, h: 0.18, text: "Text",
                     source: "", font_size: 22, color: "#FFFFFF", align: "center", valign: "center" });
        put("card.parts", parts);
        S.sel = parts.length - 1;
      });
      rerender();
    });
    ov.querySelector("[data-delpart]")?.addEventListener("click", (e) => {
      edit(() => { const parts = get("card.parts"); parts.splice(Number(e.target.dataset.delpart), 1); });
      S.sel = 0;
      rerender();
    });
    const card = document.getElementById("pceCard");
    // the card's own size: drag its right / bottom edge
    card?.querySelectorAll("[data-cardedge]").forEach((edge) => edge.addEventListener("pointerdown", (e) => {
      e.preventDefault();
      e.stopPropagation();
      const r = card.getBoundingClientRect(), h0 = cardSize(0)[1], dim = edge.dataset.cardedge, x0 = e.clientX, y0 = e.clientY;
      try { edge.setPointerCapture(e.pointerId); } catch (_) { /* synthetic */ }
      const move = (ev) => {
        if (dim === "w") card.style.width = `${Math.max(80, r.width + ev.clientX - x0)}px`;
        else card.style.height = `${Math.max(40, r.height + ev.clientY - y0)}px`;
        card.style.aspectRatio = "auto";
      };
      const up = (ev) => {
        edge.removeEventListener("pointermove", move);
        edge.removeEventListener("pointerup", up);
        const f = dim === "w" ? (r.width + ev.clientX - x0) / r.width : (r.height + ev.clientY - y0) / r.height;
        if (Math.abs(f - 1) > 0.01) edit(() => get("bands").forEach((b, i) => {
          if (dim === "w") b.card_w = Math.max(60, Math.round(cardSize(i)[0] * f));
          else b.card_h = Math.max(30, Math.round((Number(b.card_h) || h0) * f));
        }));
        rerender();
      };
      edge.addEventListener("pointermove", move);
      edge.addEventListener("pointerup", up);
    }));
    card?.querySelectorAll(".pce-part").forEach((el) => el.addEventListener("pointerdown", (e) => {
      e.preventDefault();
      const i = Number(el.dataset.pi), part = editorParts()[i].obj, r = card.getBoundingClientRect();
      const resize = !!e.target.dataset.rs, s0 = { ...part }, x0 = e.clientX, y0 = e.clientY;
      S.sel = i;
      card.querySelectorAll(".pce-part").forEach((x) => x.classList.toggle("sel", x === el));
      try { el.setPointerCapture(e.pointerId); } catch (_) { /* synthetic */ }
      const q = (v) => Math.round(v * 100) / 100;
      let moved = false;
      const move = (ev) => {
        const dx = (ev.clientX - x0) / r.width, dy = (ev.clientY - y0) / r.height;
        if (Math.abs(ev.clientX - x0) + Math.abs(ev.clientY - y0) > 2) moved = true;
        if (resize) { part.w = q(Math.max(0.05, Math.min(1 - part.x, s0.w + dx))); part.h = q(Math.max(0.05, Math.min(1 - part.y, s0.h + dy))); }
        else { part.x = q(Math.max(0, Math.min(1 - part.w, s0.x + dx))); part.y = q(Math.max(0, Math.min(1 - part.h, s0.y + dy))); }
        Object.assign(el.style, { left: `${part.x * 100}%`, top: `${part.y * 100}%`, width: `${part.w * 100}%`, height: `${part.h * 100}%` });
      };
      const up = () => {
        el.removeEventListener("pointermove", move);
        el.removeEventListener("pointerup", up);
        if (moved) {
          const after = { ...part };
          Object.assign(part, s0);                // record the undo step from the old position
          edit(() => Object.assign(part, after));
        }
        rerender();
      };
      el.addEventListener("pointermove", move);
      el.addEventListener("pointerup", up);
    }));
  }

  /* numbers that don't fit: ask once (per design) whether to shrink them or grow the cards */
  async function askOverflow() {
    if (!S.overflow.length || get("card.overflow") || S.asked === S.baseId + S.sheet) return;
    S.asked = S.baseId + S.sheet;
    const worst = S.overflow.slice().sort((a, b) => b.ratio - a.ratio)[0];
    const cards = [...new Set(S.overflow.map((o) => o.card))];
    const pick = await App.choose("Numbers don't fit their cards",
      `<div>The ${worst.part} of <b>${esc(cards.slice(0, 4).join(", "))}${cards.length > 4 ? "…" : ""}</b> need more room than the card gives
        (${worst.need_w}×${worst.need_h}px in a ${worst.have_w}×${worst.have_h}px space).</div>
       <div class="pcp-note" style="margin-top:6px">Your choice is kept with the design — change it later under ✎ on the cards.</div>`,
      [{ label: "Decide later", value: "" }, { label: "Make cards bigger", value: "grow" }, { label: "Shrink the numbers", value: "shrink", primary: true }]);
    if (pick) set("card.overflow", pick);
  }

  /* ---------- live view: drawn in the browser from the layout (no PNG round trip) ---------- */
  function drawLive() {
    const c = document.getElementById("pcLive");
    if (!c || !S.live || !window.PCLive) return;
    c.hidden = !S.liveOn;
    if (!S.liveOn) {                             // the PNG is on screen: its handles sit where the PNG drew each icon
      if (S.pngIcons) { if (!S.dragging) syncIconHandles(S.pngIcons); return; }
      drawLive.off = drawLive.off || document.createElement("canvas");
      const d = PCLive.draw(drawLive.off, S.live, drawLive);
      if (!S.dragging) syncIconHandles(d.__icons || []);
      return;
    }
    const drawn = PCLive.draw(c, S.live, drawLive);
    if (!S.dragging) S.drawn = drawn;              // frozen mid-drag
    syncIconHandles(drawn.__icons || []);          // the symbol handles ride with their symbols, even mid-drag
  }
  // every symbol's handles sit on that symbol: moved in place after each redraw (the text reflows as
  // symbols load or are sized), rebuilt when the symbols themselves change
  function syncIconHandles(icons) {
    const was = S.liveIcons;
    S.liveIcons = icons;
    if (!S.iconEdit) return;
    const slot = textSlotOf(S.iconEdit);
    const mine = icons.filter((i) => i.slot === slot);
    const els = document.querySelectorAll(`.pcb[data-b="${CSS.escape(S.iconEdit)}"] .pci`);
    const same = els.length === mine.length && [...els].every((el, n) => el.dataset.tok === mine[n].tok);
    if (!same) { if (!S.dragging && was !== icons) refreshIconHandles(); return; }
    mine.forEach((ic, n) => { S.blocks[`ico:${n}`] = ic.rect; });
    if (S.dragging) S.icoSynced = true;
    placeBlocks();
  }
  function refreshOverlay() {                   // the picked card's boxes, without rebuilding the stage
    const old = document.querySelector(".pco");
    if (!old || !S.symSel || !S.blocks[`card:${S.symSel}`]) return;
    const tmp = document.createElement("div");
    tmp.innerHTML = cardOverlay();
    if (tmp.firstElementChild) { old.replaceWith(tmp.firstElementChild); wireOverlay(); }
  }
  let liveBusy = false, liveAgain = false;
  PC.live = async () => {
    if (!S.tpl || !S.sheet || !window.PCLive) return;
    if (liveBusy) { liveAgain = true; return; }
    liveBusy = true;
    try {
      const sent = JSON.stringify(S.tpl);
      const d = await api("/api/card_templates/layout", { method: "POST", body: { template: S.tpl, sheet_name: S.sheet } });
      adoptFrame(sent, d);
      S.live = d;
      S.liveOn = S.dragging || S.pngAt !== (S.editSeq || 0);   // the exact PNG stays on screen while it is current
      if (!S.dragging) {
        Object.assign(S, { blocks: d.blocks || S.blocks, canvas: d.canvas || S.canvas, fit: d.fit || 1, counts: d.counts || S.counts,
                           texts: d.texts || S.texts, wildText: d.wild_text || {}, textInfo: d.text_info || {},
                           bandGeo: d.band_geo || {}, cardGeo: d.card_geo || {}, ...featureInfo(d) });
        computeGutters();
      }
      const st = document.getElementById("pcStage");
      if (!document.getElementById("pcLive") && st && S.token) rerenderStage();
      drawLive();
      if (!S.dragging) {
        const busyInput = document.activeElement && document.activeElement.closest && document.activeElement.closest("#pcPop");
        if (busyInput) placeBlocks(); else { refreshOverlay(); placeBlocks(); }
      }
    } catch (_) {
      /* the PNG render reports errors */
    } finally {
      liveBusy = false;
      if (liveAgain) { liveAgain = false; PC.live(); }
    }
  };

  /* ---------- server ---------- */
  let applySeq = 0, inFlight = false, again = false;
  PC.apply = debounce(async () => {
    if (!S.tpl || !S.sheet) return;           // no paytable sheet yet (scan still loading)
    if (inFlight) { again = true; return; }   // one at a time, so the newest design is always the one saved
    inFlight = true;
    S.busy = true;
    updateStatus();
    const seq = ++applySeq, editAt = S.editSeq || 0;
    try {
      const sent = JSON.stringify(S.tpl);
      const d = await api("/api/card_templates/apply", { method: "POST", body: { template: S.tpl, sheet_name: S.sheet } });
      adoptFrame(sent, d);
      if (seq !== applySeq) return;           // a newer edit is already on its way: only the latest preview shows
      if (d.config) App.state.config = d.config;
      const first = !S.token;
      if (!S.live) setTimeout(() => PC.live(), 0);
      Object.assign(S, { token: d.preview_token || S.token, blocks: d.blocks || {}, canvas: d.canvas || S.canvas, fit: d.fit || 1,
                         counts: d.counts || S.counts, texts: d.texts || [], wildText: d.wild_text || {}, overflow: d.overflow || [],
                         textInfo: d.text_info || {}, drawn: d.drawn || {}, bandGeo: d.band_geo || {}, cardGeo: d.card_geo || {},
                         pngIcons: d.drawn_icons || null, error: "", busy: false, ...featureInfo(d) });
      computeGutters();
      noteAutoBoxes();
      const img = document.getElementById("pcImg");
      if (first || !img) { if (editAt === (S.editSeq || 0)) { S.liveOn = false; S.pngAt = editAt; } rerender(); }
      else {
        img.addEventListener("load", () => {
          if (editAt === (S.editSeq || 0) && !S.dragging) { S.liveOn = false; S.pngAt = editAt; }   // the exact render is up to date
          if (document.querySelector(".pcb.dragging") || S.dragging) return;
          const busyInput = document.activeElement && document.activeElement.closest && document.activeElement.closest("#pcPop");
          if (busyInput) { drawLive(); placeBlocks(); } else rerenderStage();
        }, { once: true });
        img.src = `/api/table_preview/${encodeURIComponent(S.token)}`;
      }
      askOverflow();
    } catch (e) {
      S.error = e.message || "Could not apply the design.";
      S.busy = false;
      rerender();
    } finally {
      inFlight = false;
      if (again) { again = false; PC.apply(); }
    }
    updateStatus();
    const st = document.querySelector(".pc-state");
    if (st && S.tpl) st.innerHTML = `${esc(S.tpl.name || "")}${S.dirty ? " · <b>edited</b>" : ""}`;
  }, 450);

  /* the paytable read back from the Excel (one row per symbol: its counts and pays, the cells they
     come from, anything doubtful) and checked against the page this design makes: every pay on it,
     the same numbers, nothing cut off (/api/paytable/check — pay_reader.py) */
  PC.payCheck = async (tpl, sheet) => {                // the Canvas passes the design and the sheet it shows
    let d;
    try { d = await api("/api/paytable/check", { method: "POST", body: { template: tpl || S.tpl, sheet_name: sheet || S.sheet } }); }
    catch (e) { toast(e.message || "The pay check failed.", "err"); return; }
    const one = (d.sheets || [])[0];
    if (!one) { toast("No paytable found on this sheet."); return; }
    const rd = one.read, ck = one.check;
    const errs = ck ? ck.problems.filter((p) => p.level === "error") : [];
    const warns = (ck ? ck.problems.filter((p) => p.level !== "error") : []).concat((rd.problems || []).filter((p) => p.level !== "error"));
    const verdict = !ck ? `<div class="pcc-verdict warn">⚠ ${esc(one.check_error || "Pick a design to check the page against.")}</div>`
      : errs.length ? `<div class="pcc-verdict bad">✕ ${errs.length} problem${errs.length > 1 ? "s" : ""} — the page doesn't match the Excel</div>`
      : `<div class="pcc-verdict ok">✓ All ${ck.checked} symbols' pays are on the page, the same as the Excel</div>`;
    const list = (ps, cls) => ps.length ? `<ul class="pcc-list ${cls}">${ps.map((p) => `<li>${esc(p.text)}</li>`).join("")}</ul>` : "";
    const roleTag = (r) => (r ? `<span class="pcc-role ${r}">${r}</span>` : "");
    const rows = (rd.symbols || []).map((sy) => `<tr class="${sy.flags.length ? "flag" : ""}">
        <td><b>${esc(sy.label)}</b>${sy.group ? ` <span class="pcc-dim">(shared)</span>` : ""} ${roleTag(sy.role)}</td>
        <td class="pcc-pays">${sy.pays.map((p) => `<span><i>${esc(p.count)}</i> ${p.pay == null ? "<em>?</em>" : esc(p.pay)}</span>`).join("")}</td>
        <td class="pcc-dim">${esc(sy.cell)} · ${esc(sy.pays[0].pay_cell)}:${esc(sy.pays[sy.pays.length - 1].pay_cell)}</td>
        <td class="pcc-dim">${sy.flags.map(esc).join("<br>")}</td></tr>`).join("");
    App.ptmOpenModal(`Pay check — ${rd.sheet}`, `What the tool read from ${d.excel || "the Excel"}, and whether the page shows it.`,
      `${verdict}${list(errs, "bad")}${list(warns, "warn")}
       <div class="pcc-h">Read from the Excel</div>
       <div class="pcc-wrap"><table class="pcc-table"><thead><tr><th>Symbol</th><th>Count → pay</th><th>Cells</th><th>Check</th></tr></thead><tbody>${rows || `<tr><td colspan="4">No symbols with pays found on this sheet.</td></tr>`}</tbody></table></div>`,
      `<button class="btn secondary small" onclick="App.ptmCloseModal()">Close</button><button class="btn primary small" id="pccAgain">Check again</button>`);
    const m = document.querySelector("#ptmModalMask .ptm-modal");
    if (m) m.style.width = "min(860px, 94vw)";
    document.getElementById("pccAgain")?.addEventListener("click", () => PC.payCheck(tpl, sheet));
  };

  PC.pick = async (id) => {
    if (S.dirty && S.tpl) {
      const ok = await App.choose("Switch design?", "Your edits to this design are not saved as a design of your own. Switching replaces them (Save as copy keeps them).",
        [{ label: "Cancel", value: false }, { label: "Switch", value: true, primary: true }]);
      if (!ok) return;
    }
    try {
      const d = await api(`/api/card_templates/${encodeURIComponent(id)}`);
      Object.assign(S, { tpl: d.template, baseId: id, dirty: false, undo: [], redo: [], pop: "", editor: null, asked: "" });
      S.tpl.edited = false;
      rerender();
      PC.apply();
    } catch (e) {
      toast(e.message, "err");
    }
  };
  PC.revert = () => PC.pick(S.baseId);

  PC.saveCopy = async () => {
    const base = S.list.find((t) => t.id === S.baseId);
    const name = window.prompt("Name for your design:", `${(base && !base.builtin) ? base.name : "My " + (S.tpl.name || "design")}`);
    if (!name) return;
    try {
      const d = await api("/api/card_templates/save_copy", { method: "POST", body: { template: S.tpl, name } });
      Object.assign(S, { list: d.templates || S.list, tpl: d.template, baseId: d.id, dirty: false });
      if (d.config) App.state.config = d.config;
      toast(`Saved "${name}" to your designs.`);
      rerender();
    } catch (e) {
      toast(e.message, "err");
    }
  };

  PC.del = async () => {
    const t = S.list.find((x) => x.id === S.baseId);
    if (!t || t.builtin) return;
    const ok = await App.choose("Delete design?", `"${esc(t.name)}" is removed from your designs. The game keeps its current look.`,
      [{ label: "Cancel", value: false }, { label: "Delete", value: true, primary: true }]);
    if (!ok) return;
    try {
      const d = await api("/api/card_templates/delete", { method: "POST", body: { id: t.id } });
      S.list = d.templates || [];
      S.baseId = "";
      rerender();
    } catch (e) {
      toast(e.message, "err");
    }
  };

  PC.advanced = () => { App.state.ptAdvanced = true; if (typeof renderRoute === "function") renderRoute(); };
  PC.simple = () => { App.state.ptAdvanced = false; if (typeof renderRoute === "function") renderRoute(); };

  window.addEventListener("resize", () => { if (App.route === "paytable" && !App.state.ptAdvanced) placeBlocks(); });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && App.route === "paytable" && (S.iconEdit || S.featSel)) { S.iconEdit = ""; S.iconIso = ""; S.featSel = ""; rerenderStage(); return; }
    if (App.route !== "paytable" || App.state.ptAdvanced || !(e.ctrlKey || e.metaKey)) return;
    if (e.target.closest && e.target.closest("input[type=text], input[type=number], textarea")) return;
    const k = e.key.toLowerCase();
    if (k === "z" && !e.shiftKey) { e.preventDefault(); PC.undo(); }
    else if (k === "y" || (k === "z" && e.shiftKey)) { e.preventDefault(); PC.redo(); }
  });

  PC.init = async () => {
    try {
      const d = await api("/api/card_templates");
      S.list = d.templates || [];
      if (!S.tpl && d.current) {
        S.tpl = d.current;
        S.baseId = d.current.id || "";
        S.dirty = !!d.current.edited;
      }
    } catch (e) {
      S.error = e.message;
    }
    rerender();
    if (S.tpl) PC.apply();
  };
})();
