/* "Symbols needed" prompt.
   After an Excel is scanned (opening a market, picking an Excel, rescanning),
   if the Excel uses symbols the tool can't find, offer to pull them from a PSD
   (Symbols from a PSD) or from a folder the user already has. Shown once per
   Excel + missing set per session (no nagging); re-checked after symbols are
   saved, and closes itself when everything is found.
   Uses app.js globals (App, esc, toast) and SymExport (symbol_exporter.js). */
(function () {
  "use strict";

  const SEEN_KEY = "pshelp.symbolsPrompt.dismissed";

  function dismissed() {
    try { return JSON.parse(sessionStorage.getItem(SEEN_KEY) || "{}"); } catch (e) { return {}; }
  }
  function remember(key) {
    try {
      const d = dismissed();
      d[key] = 1;
      sessionStorage.setItem(SEEN_KEY, JSON.stringify(d));
    } catch (e) { /* private mode: just don't remember */ }
  }

  function overlay() {
    let ov = document.getElementById("symNeedOverlay");
    if (!ov) {
      ov = document.createElement("div");
      ov.id = "symNeedOverlay";
      ov.className = "gm-overlay";
      ov.hidden = true;
      // a click outside never closes it (what was typed in it would be lost): its ✕ or Cancel do
      document.body.appendChild(ov);
    }
    return ov;
  }

  App.symbolsPromptClose = (remembered) => {
    const ov = document.getElementById("symNeedOverlay");
    if (!ov || ov.hidden) return;
    if (remembered && ov.dataset.key) remember(ov.dataset.key);
    ov.hidden = true;
  };

  /* Called after every Excel scan. force=true ignores an earlier "Not now". */
  App.checkMissingSymbols = (force) => {
    const icons = (App.state.scan && App.state.scan.icons) || {};
    // <GAME NAME>, <dynamic Text>… are text placeholders, not symbols
    const isSymbol = (t) => !/\s/.test(String(t || ""));
    const tokens = (icons.tokens || []).filter(isSymbol);
    const missing = (icons.missing || []).filter(isSymbol);
    const ov = overlay();
    if (!tokens.length) return;
    // a new game made from a PSD's settings, its symbols wanted from that PSD: the review, not this prompt
    if (App._symbolsFromPsd && window.SymAgr) {
      const want = App._symbolsFromPsd;
      App._symbolsFromPsd = null;
      ov.hidden = true;
      SymAgr.open({ psd: want.psd, agr: want.agr, auto: true });
      return;
    }
    if (!missing.length) {
      if (!ov.hidden) {
        ov.hidden = true;
        toast(`All ${tokens.length} symbols found.`);
      }
      return;
    }
    const c = App.state.config || {};
    const key = [c.excel_path || "", c.icon_folder || "", missing.join(",")].join("|");
    if (!force && dismissed()[key]) return;
    ov.dataset.key = key;
    const all = missing.length === tokens.length;
    const shown = missing.slice(0, 30);
    ov.innerHTML = `<div class="gm-dialog sym-need">
      <div class="gm-dhead"><b>${icons.no_folder ? "No symbols folder found" : all ? "This Excel needs symbols" : "Some symbols are missing"}</b>
        <button class="gm-x" onclick="App.symbolsPromptClose(true)">✕</button></div>
      <div class="gm-dbody">
        <div>${icons.no_folder ? "<b>No symbols folder was found for this game. How would you like to provide the symbols?</b><br>" : ""}
          This Excel uses <b>${tokens.length}</b> symbol${tokens.length === 1 ? "" : "s"}${icons.no_folder ? "."
            : `; I couldn't find <b>${missing.length}</b> of them${c.icon_folder ? " in " + esc(c.icon_folder) : ""}.`}</div>
        <div class="sym-need-chips">${shown.map((t) => `<span class="chip">&lt;${esc(t)}&gt;</span>`).join("")}${missing.length > shown.length ? `<span class="hint">+${missing.length - shown.length} more</span>` : ""}</div>
        <div class="sym-need-choices">
          <button class="sym-need-opt" onclick="App.symbolsPromptFolder()">
            <b>Select an existing symbols folder</b><span>Browse to a folder of symbol PNGs — it's copied into Working › Symbols and used straight away.</span></button>
          <button class="sym-need-opt" onclick="App.symbolsPromptPsd()">
            <b>Select a symbol PSD</b><span>Pick a Photoshop file that has this game's symbols (and the AGR it was made from, to name each picture) — review, then one PNG per symbol in the game's Symbols folder.</span></button>
          ${!all ? `<button class="sym-need-opt" onclick="App.symbolsPromptMapper()">
            <b>Match them by hand</b><span>The files may just be named differently — link each symbol to its picture (files are not renamed).</span></button>` : ""}
        </div>
      </div>
      <div class="gm-dfoot"><button class="btn secondary" onclick="App.symbolsPromptClose(true)">Not now</button></div>
    </div>`;
    ov.hidden = false;
  };

  /* A small choice dialog: resolves to the picked option's value (or null). */
  App.choose = (title, html, options) => new Promise((resolve) => {
    const ov = document.createElement("div");
    ov.className = "gm-overlay";
    ov.style.zIndex = "10100";
    ov.innerHTML = `<div class="gm-dialog sym-need"><div class="gm-dhead"><b>${esc(title)}</b></div>
      <div class="gm-dbody">${html}</div>
      <div class="gm-dfoot">${options.map((o, i) => `<button class="btn ${o.primary ? "primary" : "secondary"}" data-i="${i}">${esc(o.label)}</button>`).join("")}</div></div>`;
    document.body.appendChild(ov);
    ov.querySelectorAll("button[data-i]").forEach((b) => b.addEventListener("click", () => {
      ov.remove();
      resolve(options[Number(b.dataset.i)].value);
    }));
  });

  /* POST that never overwrites user files silently: on "already exists" the
     user chooses Replace / Keep both / Cancel and the request is sent again. */
  App.saveSafely = async (path, body) => {
    const post = async (b) => {
      const res = await fetch(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(b) });
      const data = await res.json().catch(() => ({}));
      return { status: res.status, data };
    };
    let r = await post(Object.assign({ on_conflict: "ask" }, body));
    if (r.status === 409 && r.data.needs_choice) {
      const list = (r.data.conflicts || []).slice(0, 12).map((p) => `<li>${esc(String(p).split(/[\\/]/).pop())}</li>`).join("");
      const more = (r.data.conflicts || []).length > 12 ? `<li>…and ${r.data.conflicts.length - 12} more</li>` : "";
      const pick = await App.choose("These files already exist",
        `<div>${esc(r.data.error)}</div><ul class="sym-clash">${list}${more}</ul>
         <div class="hint">Replace overwrites them. Keep both saves the new ones as <i>name_2.png</i>.</div>`,
        [{ label: "Cancel", value: null }, { label: "Keep both", value: "keep_both" }, { label: "Replace", value: "replace", primary: true }]);
      if (!pick) return { ok: false, cancelled: true };
      r = await post(Object.assign({}, body, { on_conflict: pick }));
    }
    if (r.status >= 400 || !r.data.ok) throw new Error(r.data.error || `Request failed (${r.status})`);
    return r.data;
  };

  App.symbolsPromptPsd = () => {
    App.symbolsPromptClose(false);
    if (window.SymAgr) SymAgr.open();                 // named from the AGR, reviewed (symbol_agr.js)
    else if (window.SymExport) SymExport.open();
  };

  App.symbolsPromptFolder = () => {
    App.symbolsPromptClose(false);
    App.symbolsSelectFolder((ok) => {
      if (!ok) return;
      if (App.scan) App.scan();
      if (window.SymMap) SymMap.open();
    });
  };

  App.symbolsPromptMapper = () => {
    App.symbolsPromptClose(false);
    if (window.SymMap) SymMap.open();
    else if (App.openMapper) App.openMapper();
  };

  // run the check after every Excel scan
  const scan = App.scan;
  if (typeof scan === "function" && !scan._symbolsPrompt) {
    App.scan = async function (...args) {
      const out = await scan.apply(this, args);
      try { App.checkMissingSymbols(false); } catch (e) { /* never break a scan */ }
      return out;
    };
    App.scan._symbolsPrompt = true;
  }
})();
