/* Paytable pages on the Canvas — the card studio's page, edited like every other page.

   A paytable sheet picked on the Canvas is drawn by the card studio's live view (PCLive, from
   /api/card_templates/layout). Its parts are frames: click a card (its Card bar), a row of cards (the
   Row bar), the WILD / SCATTER boxes (the Box bar), a text box or the title; nothing picked is the
   Page bar. Esc steps back: card → its row → the page.

   Every change goes into dynamic_settings.paytable_card_template — the design every paytable sheet of
   the game is built with (engine_api reads it) — through the app's normal save, so Ctrl+Z, the Saved
   mark and the swatch lists work here as on any Canvas page. */
window.PaytableCanvas = (() => {
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const el = (id) => document.getElementById(id);
  // sheets: the paytable sheets; data: the layout drawn; sel: what is picked; bad: symbols the pay check flagged
  const S = { sheets: new Set(), data: null, sel: null, hover: "", designs: null, preview: null, seq: 0, timer: 0, bad: new Set() };

  const isPay = (sheet) => S.sheets.has(sheet);
  // the card rows: bands[i] is ROWS[i] (bands[2], when the design has one, is the middle row)
  const ROWS = ["high", "low", "mid"];
  const ROWNAME = { high: "high", low: "low", mid: "middle" };
  const rowI = (key) => Math.max(0, ROWS.indexOf(key));
  // a WILD / SCATTER box's own words (picked on their own, styled and typed like any text): slot -> its style's key
  const BOX_TEXT = {
    "@slot.scatsec.title": ["scatter_section.title", "SCATTER heading"], "@slot.scatsec.caption": ["scatter_section.caption", "SCATTER caption"],
    "@slot.scatbox.title": ["features.scatter_parts.title", "SCATTER heading"], "@slot.scatbox.label": ["features.scatter_parts.label", "SCATTER caption"],
    "@slot.scatbox.tab": ["features.tab.text", "Tab title"], "@slot.wildbox.tab": ["features.tab.text", "Tab title"],
    "@slot.wildbox.title": ["features.wild_parts.title", "WILD heading"], "@slot.wildbox.label": ["features.wild_parts.label", "WILD caption"],
    "@slot.wildbox.text": ["features.wild_parts.text", "WILD text"],
  };
  const on = () => App.route === "typography" && !!window.AppTypoVis && isPay(AppTypoVis.state.sheet);
  const saved = () => { const t = ((App.state.config || {}).dynamic_settings || {}).paytable_card_template; return t && t.kind === "card_template" ? t : null; };
  const tpl = () => saved() || S.preview;
  const get = (path, o) => path.split(".").reduce((v, k) => (v == null ? v : v[k]), o || tpl());
  function put(o, path, v) {
    const ks = path.split(".");
    let cur = o;
    ks.slice(0, -1).forEach((k, i) => { if (cur[k] == null || typeof cur[k] !== "object") cur[k] = /^\d+$/.test(ks[i + 1]) ? [] : {}; cur = cur[k]; });
    if (v === undefined) delete cur[ks.at(-1)]; else cur[ks.at(-1)] = v;
  }

  /* ------------------------------ the design ------------------------------ */
  async function designs() {
    if (!S.designs) { try { S.designs = (await api("/api/card_templates")).templates || []; } catch (e) { S.designs = []; } }
    return S.designs;
  }
  // nothing chosen for the game yet: drawn with the default design (FoMo Mummy Paytable; saved once
  // anything is changed)
  async function ensure() {
    if (saved()) return saved();
    const xl = String((App.state.config || {}).excel_path || "");
    if (S.previewFor !== xl) { S.preview = null; S.previewFor = xl; }   // another game: the default again, fit to its page
    if (!S.preview) {
      const list = await designs(), first = list.find((d) => d.default) || list[0];
      if (first) { try { S.preview = (await api("/api/card_templates/" + encodeURIComponent(first.id))).template; } catch (e) { /* none */ } }
    }
    return S.preview;
  }
  /* one change: fn(template) edits a copy; it is the game's design from now on (saved like every edit) */
  function edit(fn, force) {
    if (!force && selLocked()) { toast("🔒 Locked — unlock it to edit it."); paintFrames(); return; }
    const ds = (App.state.config.dynamic_settings = App.state.config.dynamic_settings || {});
    let base = tpl() || {};
    if (base.frame !== "page" && S.framed && S.framed.from === JSON.stringify(base)) base = S.framed.to;   // edits are page-frame px
    const t = JSON.parse(JSON.stringify(base));
    fn(t);
    // an unlocked row is exactly its cards: a box left from when it was locked would hold it to that size
    // (a server from before this knows no better) — gone with the row's first edit
    (t.bands || []).forEach((b) => { if (b && b.locked === false) delete b.lock_size; });
    t.edited = true;
    ds.paytable_card_template = t;
    App.refreshUI();
    redrawSoon();
  }
  const set = (path, v) => edit((t) => put(t, path, v));
  async function pickDesign(id) {
    let t;
    try { t = (await api("/api/card_templates/" + encodeURIComponent(id))).template; } catch (e) { toast(e.message || "That design could not be loaded.", "err"); return; }
    const ds = (App.state.config.dynamic_settings = App.state.config.dynamic_settings || {});
    ds.paytable_card_template = t;
    App.refreshUI();
    S.sel = null;
    redrawSoon(0);
    toast(`Design: ${t.name || id} — Ctrl+Z puts the one before back.`);
  }
  // a row's own look: its style is copied the first time it is changed on its own (the other row keeps its)
  function rowStyle(t, i) {
    const b = t.bands[i], st = b.style || "card", name = `${ROWS[i]}_card`;
    const shared = (t.bands || []).some((x, j) => j !== i && (x.style || "card") === st);
    if (!shared) return st;
    t.styles = t.styles || {};
    t.styles[name] = JSON.parse(JSON.stringify((t.styles || {})[st] || {}));
    b.style = name;
    return name;
  }
  // a row's card parts (its symbol, counts, pays): its own copy, from what is drawn
  function rowParts(t, i) {
    const b = t.bands[i];
    if (!Array.isArray(b.parts) || !b.parts.length) {
      const drawn = (((S.data || {}).band_geo || {})[ROWS[i]] || {}).parts;
      b.parts = JSON.parse(JSON.stringify(drawn && drawn.length ? drawn : ((t.card || {}).parts || [])));
    }
    return b.parts;
  }

  /* ------------------------------ drawing ------------------------------ */
  async function render(canvas, sheet) {
    const t = await ensure();
    if (!t || !window.PCLive) return null;
    const seq = ++S.seq;
    let d;
    const sent = JSON.stringify(t);
    try { d = await api("/api/card_templates/layout", { method: "POST", body: { template: t, sheet_name: sheet } }); }
    catch (e) { toast(e.message || "The paytable could not be laid out.", "err"); return null; }
    if (d.template && d.template.frame === "page") {
      // a design from the old fixed 1920 x 1080 frame, moved once to the page's frame: the design from now on
      S.framed = { from: sent, to: d.template };
      if (tpl() === t) { if (saved() === t) App.state.config.dynamic_settings.paytable_card_template = d.template; else S.preview = d.template; }
    }
    if (seq !== S.seq) return S.geo;
    S.data = d;
    S.liveXf = null;                                          // the new layout: the drag's preview is done
    S.sheet = sheet;
    const W0 = (d.canvas_px || {}).width || 1, H0 = (d.canvas_px || {}).height || 1;
    (d.items || []).forEach((it) => {
      if (BOX_TEXT[it.slot] && it.text && it.rect) d.blocks["btext:" + it.slot] = [it.rect[0] / W0, it.rect[1] / H0, (it.rect[0] + it.rect[2]) / W0, (it.rect[1] + it.rect[3]) / H0];
    });
    S.canvas = canvas;
    draw();
    const w = d.canvas_px.width, h = d.canvas_px.height;
    S.geo = { canvas_w: w, canvas_h: h, heading_top: 0, heading_bottom: 0, body_top: 0, body_bottom: h, safe_left: 0, safe_right: w, inner_canvas_width: w };
    return S.geo;
  }
  function draw() {
    const c = S.canvas, d = S.data;
    if (!c || !d || !on()) return;
    let items = d.items || [];
    if (S.tedSlot) items = items.filter((x) => x.slot !== S.tedSlot);
    if (S.liveXf) items = items.map(S.liveXf);
    const shown = items === d.items ? d : Object.assign({}, d, { items });
    S.drawn = PCLive.draw(c, shown, draw);
    if (!S.dragLive) paintFrames();                           // mid-drag the handles stay with the mouse
  }
  // live dragging: xf(item) moves / stretches the dragged part's items; drawn on the next frame
  function liveSet(xf) {
    S.liveXf = xf;
    if (S.liveRaf) return;
    S.liveRaf = requestAnimationFrame(() => { S.liveRaf = 0; draw(); });
  }
  function liveEnd(changed) {
    S.dragLive = false;
    if (!changed) { S.liveXf = null; draw(); }                // nothing changed: as it was (else until the new layout)
  }
  // the page's items drawn inside a block (image fractions)
  function itemsIn(b) {
    const d = S.data, W = d.canvas_px.width, H = d.canvas_px.height;
    return new Set((d.items || []).filter((it) => {
      const cx = (it.rect[0] + it.rect[2] / 2) / W, cy = (it.rect[1] + it.rect[3] / 2) / H;
      return cx >= b[0] - 1e-4 && cx <= b[2] + 1e-4 && cy >= b[1] - 1e-4 && cy <= b[3] + 1e-4;
    }));
  }
  const pxOf = (b) => { const d = S.data; return [b[0] * d.canvas_px.width, b[1] * d.canvas_px.height, (b[2] - b[0]) * d.canvas_px.width, (b[3] - b[1]) * d.canvas_px.height]; };
  // items of a part from box A to box B (canvas px); fonts follow when the part scales as a picture
  function boxXf(set, A, B, fonts) {
    const sx = B[2] / Math.max(1, A[2]), sy = B[3] / Math.max(1, A[3]);
    return (it) => {
      if (!set.has(it)) return it;
      const r = it.rect, n = Object.assign({}, it, { rect: [B[0] + (r[0] - A[0]) * sx, B[1] + (r[1] - A[1]) * sy, r[2] * sx, r[3] * sy] });
      if (fonts && it.style) n.style = Object.assign({}, it.style, { size: (Number(it.style.size) || 30) * Math.min(sx, sy) });
      return n;
    };
  }
  function redrawSoon(ms) {
    clearTimeout(S.timer);
    S.timer = setTimeout(async () => {
      if (!on()) return;
      const c = el("typoVisCanvas");
      if (c && await render(c, AppTypoVis.state.sheet)) { paint(); if (window.AppTypoVis && AppTypoVis.renderRail) AppTypoVis.renderRail(); }
    }, ms == null ? 120 : ms);
  }
  // a small picture of the page for the pages rail
  function thumb() {
    const c = S.canvas;
    if (!c || !c.width) return "";
    const t = document.createElement("canvas");
    t.width = 240;
    t.height = Math.round(240 * c.height / c.width);
    t.getContext("2d").drawImage(c, 0, 0, t.width, t.height);
    try { return t.toDataURL("image/jpeg", 0.8); } catch (e) { return ""; }
  }

  /* ------------------------------ frames ------------------------------ */
  // what a block key is: card:<sym> | high | low | wild | scatter | text:<id> | title | scard:<key>
  function kindOf(k) {
    if (k.startsWith("card:")) return { kind: "card", key: k.slice(5) };
    if (ROWS.includes(k)) return { kind: "band", key: k };
    if (k === "wild" || k === "scatter") return { kind: "box", key: k };
    if (k.startsWith("text:")) return { kind: "text", key: k.slice(5) };
    if (k === "title") return { kind: "title", key: "title" };
    if (k.startsWith("scard:")) return { kind: "scard", key: k.slice(6) };
    if (k.startsWith("zone:")) return { kind: "zone", key: k.slice(5) };
    if (k.startsWith("btext:")) return { kind: "btext", key: k.slice(6) };
    return null;
  }
  // the title's frame: what is drawn — its fit plate, else its text when it has no plate (not its whole slot)
  const blocks = () => {
    const b = ((S.data || {}).blocks) || {}, d = S.drawn || {};
    if (!b.title) return b;
    const plate = get("page.title.plate") !== false, fit = d["@slot.title#plate"], ink = d["@slot.title"];
    const t = plate ? fit : ink;
    const out = t ? Object.assign({}, b, { title: t }) : Object.assign({}, b);
    // a text box's frame: as wide as its words (left / right at the text's own edges), as tall as its box
    // (top / bottom where they were dropped — the words fill it in whole lines, so their own bottom would
    // jump away from the handle); a drag changes its box
    ((S.data || {}).texts || []).forEach((tm) => {
      const k = "text:" + tm.id, ink2 = d[tm.slot];
      if (out[k] && ink2 && ink2[2] > ink2[0]) out[k] = [ink2[0], out[k][1], ink2[2], out[k][3]];
    });
    return out;
  };
  const selKey = () => (!S.sel ? "" : S.sel.kind === "card" ? "card:" + S.sel.key : S.sel.kind === "text" ? "text:" + S.sel.key
    : S.sel.kind === "zone" ? "zone:" + S.sel.key : S.sel.kind === "scard" ? "scard:" + S.sel.key : S.sel.kind === "btext" ? "btext:" + S.sel.key
    : S.sel.kind === "picon" ? "" : S.sel.key);
  // the smallest block under a point (image fractions): a card before its row, its row before the page
  function blockAt(fx, fy) {
    let best = null, area = Infinity;
    const raw = (S.data || {}).blocks || {};
    Object.entries(blocks()).forEach(([k, b]) => {
      // a text box is hit anywhere in its box (its frame hugs the words); a zone only where nothing in it is
      if (k.startsWith("text:") && raw[k]) b = raw[k];
      if (!kindOf(k) || !b || fx < b[0] || fx > b[2] || fy < b[1] || fy > b[3]) return;
      const a = (b[2] - b[0]) * (b[3] - b[1]) + (k.startsWith("zone:") ? 1e6 : 0);
      if (a < area) { area = a; best = k; }
    });
    return best;
  }
  function frac(ev) {
    const c = el("typoVisCanvas");
    if (!c) return null;
    const r = c.getBoundingClientRect();
    return [(ev.clientX - r.left) / r.width, (ev.clientY - r.top) / r.height];
  }
  function paintFrames() {
    document.querySelectorAll(".ptc-frames").forEach((n) => n.remove());
    const host = el("typoVisHost"), c = el("typoVisCanvas");
    if (!on() || !host || !c || !S.data) return;
    const cr = c.getBoundingClientRect(), hr = host.getBoundingClientRect();
    const layer = document.createElement("div");
    layer.className = "ptc-frames" + (selLocked() ? " ptc-locked" : "");
    const sk = selKey(), hk = S.hover;
    const box = (k, cls, tag) => {
      const b = blocks()[k];
      if (!b) return "";
      return `<div class="ptc-f ${cls}" style="left:${cr.left - hr.left + b[0] * cr.width}px;top:${cr.top - hr.top + b[1] * cr.height}px;width:${(b[2] - b[0]) * cr.width}px;height:${(b[3] - b[1]) * cr.height}px">${tag ? `<span class="ptc-tag">${esc(tag)}</span>` : ""}</div>`;
    };
    let html = "";
    (S.multi || []).forEach((n) => { if (n !== (S.sel || {}).key) html += box("card:" + n, "on", ""); });   // Shift+click picks
    Object.keys(blocks()).forEach((k) => {                       // the pay check's problems: red frames on those cards
      if (k.startsWith("card:") && S.bad.has(k.slice(5).toUpperCase())) html += box(k, "bad", "");
    });
    if (!S.drag && S.sel && S.sel.kind === "picon") {
      const [slot, tok] = S.sel.key.split("|"), scope = S.iconScope || "one";
      const all = ((S.drawn || {}).__icons || []).filter((i) => i.slot === slot);
      const mine = all.filter((i) => ikey(i.tok) === ikey(tok)), me = mine[picNth()] || mine[0];
      (scope === "box" ? all : scope === "one" ? [me].filter(Boolean) : mine).forEach((i, n) => {
        html += `<div class="ptc-f on" style="left:${cr.left - hr.left + i.rect[0] * cr.width}px;top:${cr.top - hr.top + i.rect[1] * cr.height}px;width:${(i.rect[2] - i.rect[0]) * cr.width}px;height:${(i.rect[3] - i.rect[1]) * cr.height}px"></div>`;
      });
      const i0 = me;
      if (i0) html += `<div class="ptc-h rs h-se" data-ic="1" style="left:${cr.left - hr.left + i0.rect[2] * cr.width - 6}px;top:${cr.top - hr.top + i0.rect[3] * cr.height - 6}px" title="Drag: its size"></div>`;
    }
    // <TOKEN>s with no picture: marked, click one to pick its picture
    ((S.drawn || {}).__missing || []).forEach((m) => {
      html += `<div class="ptc-f miss" style="left:${cr.left - hr.left + m.rect[0] * cr.width}px;top:${cr.top - hr.top + m.rect[1] * cr.height}px;width:${(m.rect[2] - m.rect[0]) * cr.width}px;height:${(m.rect[3] - m.rect[1]) * cr.height}px" title="No picture for ${esc(m.tok)} — click to pick one"></div>`;
    });
    if (hk && hk !== sk) html += box(hk, "hover", "");
    if (sk) html += box(sk, "on", labelOf(S.sel));
    if (S.sel && S.sel.kind === "card") html += box(rowOfCard(S.sel.key), "row", "");   // its row, lightly
    const dr = S.drag;
    if (dr) {
      html += box("card:" + dr.name, "dragging", "");
      const t = dr.target, b = t && (t.at ? blocks()["card:" + t.at] : blocks()[t.row]);
      if (b) {
        const x = t.at ? (t.after ? b[2] : b[0]) : b[2];
        html += `<div class="ptc-drop" style="left:${cr.left - hr.left + x * cr.width - 2}px;top:${cr.top - hr.top + b[1] * cr.height}px;height:${(b[3] - b[1]) * cr.height}px"></div>`;
      }
    }
    // numbers left of / under / right of the symbol
    const numBtns = (what) => [["left", "◧", "on the left"], ["below", "⬓", "under the symbol"], ["right", "◨", "on the right"]]
      .map(([w, ic, tip]) => `<button data-cnum="${w}" title="${what}: numbers ${tip}">${ic}</button>`).join("");
    const one = S.sel && ((S.sel.kind === "card" && (isFree(S.sel.key) || S.iso === S.sel.key)) || S.sel.kind === "scard");
    const rowK = S.sel && !one && (S.sel.kind === "band" ? S.sel.key : S.sel.kind === "card" ? rowOfCard(S.sel.key) : null);
    if (rowK && !dr) {
      const b = blocks()[rowK], i = rowI(rowK), lk = locked(rowK);
      if (b) html += `<div class="ptc-chips" data-crow="${rowK}" style="left:${cr.left - hr.left + b[2] * cr.width}px;top:${cr.top - hr.top + b[1] * cr.height}px">
        ${lk ? "" : `<button data-pchip="-1" title="Fewer cards in a row">−</button><span>${across(i)}</span><button data-pchip="1" title="More cards in a row">+</button><i></i>${numBtns(`Every ${ROWNAME[rowK]} card`)}<i></i>`}
        <button data-plock title="${lk ? "Unlock the row" : "Lock the row: it keeps its place and size"}">${lk ? "🔒" : "🔓"}</button></div>`;
    }
    if (one && !dr && blocks()[selKey()]) {
      const b = blocks()[selKey()];
      html += `<div class="ptc-chips" style="left:${cr.left - hr.left + b[2] * cr.width}px;top:${cr.top - hr.top + b[1] * cr.height}px">${numBtns(S.sel.kind === "scard" ? "Every SCATTER card" : "Only " + S.sel.key.toUpperCase())}</div>`;
    }
    const off = { x: (f) => cr.left - hr.left + f * cr.width, y: (f) => cr.top - hr.top + f * cr.height, w: (f) => f * cr.width, h: (f) => f * cr.height };
    const at = (b) => `left:${off.x(b[0])}px;top:${off.y(b[1])}px;width:${off.w(b[2] - b[0])}px;height:${off.h(b[3] - b[1])}px`;
    if (!dr && S.sel && (S.sel.kind === "card" || S.sel.kind === "scard") && blocks()[selKey()]) html += cardOverlayHtml(S.sel.key, at(blocks()[selKey()]));
    if (!dr && S.iso && S.sel && S.sel.kind === "card" && blocks()[selKey()]) {          // isolation: the rest of the page dimmed
      html = `<div class="ptc-iso" style="${at(blocks()[selKey()])}"><span>Only ${esc(S.iso.toUpperCase())} — Esc: back to the row</span></div>` + html;
    }
    if (!dr && S.sel && S.sel.kind === "band") html += guttersHtml(rowI(S.sel.key), off);
    if (!dr && S.sel && S.sel.kind === "box") html += boxOverlayHtml(off, S.sel.key);
    Object.keys(blocks()).filter((k) => k.startsWith("zone:")).forEach((k) => { if (!S.sel || sk !== k) html += box(k, "zone", S.sel ? "" : "▤ " + k.slice(5)); });
    if (!dr && S.sel && S.sel.kind === "zone" && blocks()[sk]) {
      const b = blocks()[sk], z = zones().find((x) => x.id === S.sel.key), y = z && z.pos === "bottom" ? b[1] : b[3];
      html += `<div class="ptc-mg h" data-zh="1" style="left:${off.x((b[0] + b[2]) / 2)}px;top:${off.y(y)}px" title="Drag: the row's height"></div>`;
    }
    if (!dr && !S.sel && blocks().page) {                            // the page's margins: drag its dashed edges
      const p = blocks().page, my = (p[1] + p[3]) / 2, mx = (p[0] + p[2]) / 2;
      html += `<div class="ptc-f page" style="${at(p)}"></div>
        <div class="ptc-mg h" data-mg="top" style="left:${off.x(mx)}px;top:${off.y(p[1])}px" title="Drag: top margin"></div>
        <div class="ptc-mg h" data-mg="bottom" style="left:${off.x(mx)}px;top:${off.y(p[3])}px" title="Drag: bottom margin"></div>
        <div class="ptc-mg v" data-mg="left" style="left:${off.x(p[0])}px;top:${off.y(my)}px" title="Drag: side margins (both sides)"></div>
        <div class="ptc-mg v" data-mg="right" style="left:${off.x(p[2])}px;top:${off.y(my)}px" title="Drag: side margins (both sides)"></div>`;
    }
    if (!dr && S.sel && S.sel.kind === "title" && get("page.title.plate") !== false && blocks().title) {
      const b = blocks().title, my = (b[1] + b[3]) / 2, mx = (b[0] + b[2]) / 2;
      html += `<div class="ptc-mg v" data-tw="l" style="left:${off.x(b[0])}px;top:${off.y(my)}px" title="Drag: plate width"></div>
        <div class="ptc-mg v" data-tw="r" style="left:${off.x(b[2])}px;top:${off.y(my)}px" title="Drag: plate width"></div>
        <div class="ptc-mg h" data-tw="t" style="left:${off.x(mx)}px;top:${off.y(b[1])}px" title="Drag: plate height"></div>
        <div class="ptc-mg h" data-tw="b" style="left:${off.x(mx)}px;top:${off.y(b[3])}px" title="Drag: plate height"></div>`;
    }
    if (!dr && S.sel && S.sel.kind === "title" && blocks().title) {
      // the title moves anywhere (✥); its top margin and the gap to the cards are guides, like the heading's
      const b = blocks().title, pg = blocks().page || [0, 0, 1, 1], under = titleGapPx();
      const cardsTop = b[3] + under / Math.max(1, ((S.data || {}).canvas || {}).height || 1080) * (Number(((S.data || {}).canvas || {}).scale) || 1);
      html += `<div class="ptc-h mv" data-tmove style="left:${off.x(b[0]) - 12}px;top:${off.y(b[1]) - 12}px" title="Drag: move the title">✥</div>
        <div class="ptc-tg" data-tguide="top" style="left:${off.x(pg[0])}px;width:${off.w(pg[2] - pg[0])}px;top:${off.y(b[1])}px" title="Drag: the title's top margin"><span>Title top</span></div>
        ${(get("bands") || []).some((x) => !x.pos) ? `<div class="ptc-tg" data-tguide="gap" style="left:${off.x(pg[0])}px;width:${off.w(pg[2] - pg[0])}px;top:${off.y(cardsTop)}px" title="Drag: the space between the title and the cards"><span>Title → cards · ${Math.round(under)} px</span></div>` : ""}`;   // rows placed by hand don't follow the title
    }
    const movable = S.sel && !dr && (["text", "box", "band", "scard"].includes(S.sel.kind) || (S.sel.kind === "card" && isFree(S.sel.key)))
      && (S.sel.kind === "text" || !zoneOfBlock(selKey())) ? blocks()[selKey()] : null;      // a zone's text box too
    if (movable) {
      const L = cr.left - hr.left + movable[0] * cr.width, T = cr.top - hr.top + movable[1] * cr.height;
      const R = cr.left - hr.left + movable[2] * cr.width, B = cr.top - hr.top + movable[3] * cr.height;
      const band = S.sel.kind === "band" || S.sel.kind === "scard";
      if (!band) html += `<div class="ptc-h mv" data-ph="move" style="left:${L - 12}px;top:${T - 12}px" title="Drag: move it">✥</div>`;
      (S.sel.kind === "scard" ? ["se"] : ["n", "e", "s", "w", "se"]).forEach((hd) => {
        const x = hd.includes("w") ? L : hd.includes("e") ? R : (L + R) / 2, y = hd.includes("n") ? T : hd.includes("s") ? B : (T + B) / 2;
        html += `<div class="ptc-h rs h-${hd}" data-ph="${hd}" style="left:${x - 6}px;top:${y - 6}px" title="${S.sel.kind === "scard" ? "Drag: every SCATTER card bigger / smaller" : band && hd === "se" ? "Drag: scale the row (cards, numbers and spacing together)" : band ? "Drag: only this side of the row moves (the cards take the room, their content keeps its size)" : "Drag: only this side moves"}"></div>`;
      });
    }
    // every row's handle, always there: drag it to move the whole row, click it to pick the row
    if (!dr) ROWS.forEach((rk) => {
      const b = blocks()[rk];
      if (!b || zoneOfBlock(rk)) return;
      html += `<div class="ptc-rowh ${S.sel && S.sel.kind === "band" && S.sel.key === rk ? "on" : ""}" data-rowh="${rk}" style="left:${off.x(b[0])}px;top:${off.y(b[1])}px" title="Drag: move the whole ${ROWNAME[rk]} row · click: pick the row">✥ ${ROWNAME[rk]}</div>`;
    });
    layer.innerHTML = html;
    host.appendChild(layer);
    layer.querySelectorAll("[data-ph]").forEach((h) => {
      ["click", "dblclick"].forEach((ty) => h.addEventListener(ty, (e2) => e2.stopPropagation()));
      h.addEventListener("mousedown", (e2) => { e2.stopPropagation(); e2.preventDefault(); startFrameEdit(h.dataset.ph, e2); });
    });
    layer.querySelectorAll("[data-ic]").forEach((h) => {
      ["click", "dblclick", "pointerdown"].forEach((ty) => h.addEventListener(ty, (e2) => e2.stopPropagation()));
      h.addEventListener("mousedown", (e2) => {
        if (e2.button !== 0) return;
        const h0 = iconPx(), box0 = h.getBoundingClientRect(), shown = Math.max(6, h0 / scales().px);   // its height on screen
        dragOn(e2, (dx, dy) => { h.style.transform = `translate(${dx}px, ${dy}px)`; }, (dx, dy) => {
          setIconPx(h0 * Math.max(0.1, 1 + (dx + dy) / (2 * shown)));   // the corner moved: as much taller
        });
        void box0;
      });
    });
    layer.querySelectorAll("[data-rowh]").forEach((h) => {
      ["click", "dblclick", "pointerdown"].forEach((ty) => h.addEventListener(ty, (e2) => e2.stopPropagation()));
      h.addEventListener("mousedown", (e2) => {
        if (e2.button !== 0) return;
        e2.stopPropagation(); e2.preventDefault();
        pick({ kind: "band", key: h.dataset.rowh });
        startFrameEdit("move", e2);
      });
    });
    layer.querySelector("[data-tmove]")?.addEventListener("mousedown", (e2) => { if (e2.button === 0) titleMove(e2, e2.currentTarget); });
    layer.querySelectorAll("[data-tguide]").forEach((g) => {
      ["click", "dblclick"].forEach((ty) => g.addEventListener(ty, (e2) => e2.stopPropagation()));
      g.addEventListener("mousedown", (e2) => { if (e2.button === 0) titleGuide(g.dataset.tguide, e2, g); });
    });
    layer.querySelectorAll("[data-oh], [data-fh], [data-gut], [data-mg], [data-tw], [data-zh], [data-dv]").forEach((h) => {
      ["click", "pointerdown"].forEach((ty) => h.addEventListener(ty, (e2) => e2.stopPropagation()));
      h.addEventListener("dblclick", (e2) => {
        e2.stopPropagation();
        if (h.dataset.oh && S.sel && S.sel.kind === "card" && S.iso !== S.sel.key) {
          S.iso = S.sel.key;
          pick(S.sel);
          toast(`Only ${S.iso.toUpperCase()} — what you change now changes this card alone. Esc: back to its row.`);
        }
      });
      h.addEventListener("mousedown", (e2) => {
        if (e2.button !== 0) return;
        const own = e2.target.closest("[data-oh], [data-fh], [data-gut], [data-mg], [data-tw], [data-zh], [data-dv]");
        if (own !== h) return;                                   // a handle inside a part handles itself
        if (h.dataset.dv) dividerDrag(h.dataset.dv, e2, h);
        else if (h.dataset.oh) overlayDrag(h.dataset.oh, e2, h);
        else if (h.dataset.fh) wildDrag(h.dataset.fh, e2, h);
        else if (h.dataset.gut) gutterDrag(h.dataset.gut, e2, h);
        else if (h.dataset.zh) zoneHeightDrag(e2, h);
        else if (h.dataset.mg) marginDrag(h.dataset.mg, e2, h);
        else titleDrag(h.dataset.tw, e2, h);
      });
    });
    layer.querySelectorAll(".ptc-chips").forEach((ch) => ["mousedown", "pointerdown", "click", "dblclick"].forEach((ty) => ch.addEventListener(ty, (e2) => e2.stopPropagation())));
    layer.querySelectorAll("[data-cnum]").forEach((b) => b.addEventListener("click", () => {
      const rk = (b.closest("[data-crow]") || {}).dataset;
      if (rk && rk.crow) arrangeNumbers(b.dataset.cnum, null, rowI(rk.crow));    // every card of the row
      else arrangeNumbers(b.dataset.cnum);                                         // this card alone
    }));
    layer.querySelectorAll("[data-pchip]").forEach((b) => b.addEventListener("click", () => {
      const i = rowI(b.closest("[data-crow]").dataset.crow), d = Number(b.dataset.pchip);
      edit((t) => { const band = t.bands[i]; if (!band) return; band.per_row = Math.max(1, Math.min(10, (Number(band.per_row) || across(i) || 4) + d)); delete band.card_w; });
    }));
    layer.querySelector("[data-plock]")?.addEventListener("click", (e2) => toggleLock(e2.currentTarget.closest("[data-crow]").dataset.crow));
  }
  // cards in a row: the design's per_row, else as many as are drawn on the row's first line
  function across(i) {
    const n = Number(get(`bands.${i}.per_row`));
    if (n > 0) return n;
    const row = blocks()[ROWS[i]];
    if (!row) return 0;
    const cards = Object.entries(blocks()).filter(([k, b]) => k.startsWith("card:") && b[1] >= row[1] - 0.001 && b[3] <= row[3] + 0.001);
    if (!cards.length) return 0;
    const top = Math.min(...cards.map(([, b]) => b[1]));
    return cards.filter(([, b]) => Math.abs(b[1] - top) < 0.01).length;
  }
  function rowOfCard(name) {
    const fr = ((S.data || {}).free_cards || {})[name];
    if (fr) return fr;                              // broken out of its row: still that row's card
    const b = blocks()["card:" + name];
    if (!b) return "high";
    const cy = (b[1] + b[3]) / 2;
    return ["low", "mid"].find((r) => blocks()[r] && cy >= blocks()[r][1] && cy <= blocks()[r][3]) || "high";
  }
  function labelOf(sel) {
    if (!sel) return "";
    if (sel.kind === "card") return "▦ " + sel.key.toUpperCase();
    if (sel.kind === "band") return `▦ ${ROWNAME[sel.key][0].toUpperCase()}${ROWNAME[sel.key].slice(1)} cards`;
    if (sel.kind === "box") return sel.key === "wild" ? "▣ WILD box" : "▣ SCATTER box";
    if (sel.kind === "text") return "T Text box";
    if (sel.kind === "zone") return "▤ Zone " + sel.key;
    if (sel.kind === "scard") return "▦ SCATTER card";
    if (sel.kind === "btext") return "T " + ((BOX_TEXT[sel.key] || [])[1] || "Text");
    if (sel.kind === "picon") return "◆ " + sel.key.split("|")[1];
    return "Title";
  }
  function pick(sel) {
    if (!sel || sel.kind !== "card" || sel.key !== S.iso) S.iso = "";      // "Only this card" ends with another pick
    if (S.ted && !(sel && sel.kind === "text" && sel.key === S.ted)) closeTextEditor();
    if (sel && sel.kind === "btext") {
      const m = String((BOX_TEXT[sel.key] || [])[0] || "").match(/^features\.(wild|scatter)_parts\./);
      const real = m && ((S.data || {}).feature_parts || {})[m[1]];
      if (m && real && !get(`features.${m[1]}_parts`)) edit((t) => put(t, `features.${m[1]}_parts`, clone(real)));
    }
    S.sel = sel;
    paintFrames();
    paint();
  }
  // a symbol inside a paytable text under the pointer (as drawn): {slot, tok, rect} or null
  function iconAt(f) {
    return ((S.drawn || {}).__icons || []).find((i) => f[0] >= i.rect[0] && f[0] <= i.rect[2] && f[1] >= i.rect[1] && f[1] <= i.rect[3]) || null;
  }
  // a <TOKEN> with no picture under the pointer (drawn as its name): {tok, rect} or null
  function missingAt(f) {
    return ((S.drawn || {}).__missing || []).find((m) => f[0] >= m.rect[0] - 0.002 && f[0] <= m.rect[2] + 0.002 && f[1] >= m.rect[1] - 0.004 && f[1] <= m.rect[3] + 0.004) || null;
  }
  function click(ev) {
    if (S.noClick) return;
    const f = frac(ev);
    if (!f) return;
    const ic = iconAt(f);
    if (ic) {                                                   // which copy of its symbol in its text
      const same = ((S.drawn || {}).__icons || []).filter((i) => i.slot === ic.slot && ikey(i.tok) === ikey(ic.tok));
      pick({ kind: "picon", key: ic.slot + "|" + ic.tok + "|" + Math.max(0, same.indexOf(ic)) });
      return;
    }
    const miss = missingAt(f);
    if (miss && window.IconStudio && IconStudio.mapDialog) {   // as on every page: pick its picture
      IconStudio.mapDialog(String(miss.tok).replace(/[<>]/g, "").trim(), false);
      const wait = setInterval(() => { if (!document.querySelector(".overlay .table-mapper-dialog")) { clearInterval(wait); redrawSoon(0); } }, 400);
      return;
    }
    const k = blockAt(f[0], f[1]), to = k ? kindOf(k) : null;
    if (ev.shiftKey && to && to.kind === "card" && S.sel && S.sel.kind === "card") {
      // Shift+click: more cards picked with this one (right-click: a caption on all of them)
      const set = new Set(S.multi || [S.sel.key]);
      if (set.has(to.key) && to.key !== S.sel.key) set.delete(to.key); else set.add(to.key);
      S.multi = [...set];
      paintFrames();
      return;
    }
    S.multi = null;
    S.cpart = to && to.kind === "card" && partAt(to.key, f) ? { key: to.key, part: partAt(to.key, f) } : null;
    pick(to);
  }
  function hover(ev) {
    if (S.drag || S.busy || S.ted || (ev.target.closest && ev.target.closest(".ptc-chips, .ptc-menu, .ptc-h, .ptc-co, .ptc-gut, .ptc-mg, .ptc-ted, .ptc-ied, .ptc-rowh"))) return;   // its buttons stay put
    const f = frac(ev), k = f ? blockAt(f[0], f[1]) || "" : "";
    if (k !== S.hover) { S.hover = k; paintFrames(); }
  }
  /* a part of the picked card: "sym" (its symbol), "num" (its pays & values) or "" (the card) — the
     selection stays the card (its frames, handles, Only this card); only the bar shows that part's tools */
  const partOf = () => (S.sel && S.sel.kind === "card" && S.cpart && S.cpart.key === S.sel.key ? S.cpart.part : "");
  function setPart(part) {
    if (!S.sel || S.sel.kind !== "card") return;
    S.cpart = part ? { key: S.sel.key, part } : null;
    paint();
  }
  // a click on a card: on its symbol or on its numbers, that part (as drawn)
  function partAt(name, f) {
    const d = S.data, W = ((d || {}).canvas_px || {}).width || 1, H = ((d || {}).canvas_px || {}).height || 1;
    const hit = (slots) => ((d || {}).items || []).some((it) => slots.includes(it.slot) && it.rect
      && f[0] >= it.rect[0] / W && f[0] <= (it.rect[0] + it.rect[2]) / W && f[1] >= it.rect[1] / H && f[1] <= (it.rect[1] + it.rect[3]) / H);
    return hit([`@slot.${name}.pay`, `@slot.${name}.value`]) ? "num" : hit([`@slot.${name}`]) ? "sym" : "";
  }
  // Esc: a card's part → the card → its row → the page
  function escape() {
    if (S.ted) { closeTextEditor(); return true; }
    if (document.querySelector(".ptc-pop")) { closePop(); return true; }
    if (partOf()) { setPart(""); return true; }
    if (S.sel && S.sel.kind === "card" && S.iso) { S.iso = ""; pick(S.sel); return true; }
    if (!S.sel) return false;
    pick(S.sel.kind === "card" ? { kind: "band", key: rowOfCard(S.sel.key) } : null);
    return true;
  }

  /* ------------------------------ the top bar ------------------------------ */
  const sw = (attr, val, title, off) => `<button class="tbs-sw ${val ? "" : "none"}" ${attr} data-cur="${esc(val || "")}" title="${esc(title)}" ${off ? "disabled" : ""} style="--c:${esc(val || "transparent")}"><i></i><b>▾</b></button>`;
  const num = (attr, v, title, min, max, unit) => `<input class="ts-size ts-narrow" type="number" ${attr} value="${esc(v ?? "")}" min="${min}" max="${max}" title="${esc(title)}">${unit ? `<span class="ts-unit">${unit}</span>` : ""}`;
  const fxBtn = (attr, fx, title) => `<button class="ts-fxbtn" ${attr} title="${esc(title)}">${fx ? `<span class="ts-fx-name">${esc(typeof fx === "object" ? "Design's own" : fx)}</span>` : `<span class="ts-fx-none">fx</span><span class="ts-fx-name">None</span>`}<span class="ts-fx-caret">▾</span></button>`;
  const sep = `<span class="ts-sep"></span>`;
  // a gradient's directions (the fill colour first: top / left / top-left / centre)
  const GRAD_DIRS = [["vertical", "↓ Top to bottom"], ["horizontal", "→ Left to right"], ["diagonal", "↘ Diagonal"], ["radial", "◎ Radial"]];
  // a style's look (styles.<name>): fill, stroke, corners, layer style
  function lookHtml(st, what) {
    const s = get("styles." + st) || {}, k = (p) => `data-pl="${st}|${p}"`;
    const fill = s.fill_enabled === false ? "" : s.fill || "";
    const stroke = (s.stroke || {}).enabled ? (s.stroke || {}).color || "#ffffff" : "";
    const al = (s.stroke || {}).align || "inside", pill = s.radius === "pill";
    const grad = fill && s.fill_to && s.gradient_dir !== "none" ? s.fill_to : "";
    return `<span class="ts-lbl">${what}</span>${sw(k("fill"), fill, "Fill")}${num(k("fill_opacity"), s.fill_opacity ?? 100, "Fill opacity (%)", 0, 100, "%")}
      <span class="ts-lbl" title="Gradient: the fill fades into a second colour">Gradient</span>${sw(k("fill_to"), grad, "Gradient: the colour the fill fades into (None = a flat fill)", !fill)}${grad ? `<select class="ts-style ts-narrow" ${k("gradient_dir")} title="The gradient's direction">${GRAD_DIRS.map(([v, l]) => `<option value="${v}" ${(s.gradient_dir || "vertical") === v ? "selected" : ""}>${l}</option>`).join("")}</select>${num(k("gradient_amount"), s.gradient_amount ?? 100, "Gradient strength (%): 0 = a flat fill, 100 = all the way to the second colour", 0, 100, "%")}` : ""}
      <span class="ts-lbl">Stroke</span>${sw(k("stroke"), stroke, "Stroke colour")}${num(k("stroke.width"), (s.stroke || {}).width ?? 2, "Stroke width (px)", 0, 40, "px")}
      <select class="ts-style ts-narrow" ${k("stroke.align")} title="Stroke position">${[["inside", "Inside"], ["center", "Centre"], ["outside", "Outside"]].map(([v, l]) => `<option value="${v}" ${al === v ? "selected" : ""}>${l}</option>`).join("")}</select>
      <span class="ts-lbl" title="Corner radius">◜</span>${pill ? "" : num(k("radius"), s.radius ?? 0, "Corner radius (px)", 0, 999, "")}
      <button class="ts-al ${pill ? "on" : ""}" ${k("pill")} title="Round ends (pill shape)">◖◗</button>
      <select class="ts-style ts-narrow" ${k("corner")} title="The corners: round, cut, notched or stepped">${[["round", "◜ Round"], ["cut", "◸ Cut"], ["notch", "◟ Notched"], ["step", "⌐ Stepped"]].map(([v, l]) => `<option value="${v}" ${(s.corner || (Array.isArray(s.corners) ? "" : "round")) === v ? "selected" : ""}>${l}</option>`).join("")}${Array.isArray(s.corners) ? `<option value="" selected>Mixed</option>` : ""}</select>
      <button class="ts-tgt" data-looks title="Ready-made card looks: shapes, colours, glows — every card or the picked ones">🎴 Looks…</button>
      ${glowShadowHtml(st, s)}
      ${fxBtn(k("fx"), s.fx || "", "Layer style")}${s.fx ? `<select class="ts-style ts-narrow" ${k("fx_on")} title="What the layer style is on">${[["", "On all"], ["fill", "Fill only"], ["stroke", "Stroke only"]].map(([v, l]) => `<option value="${v}" ${(s.fx_on || "") === v ? "selected" : ""}>${l}</option>`).join("")}</select>` : ""}`;
  }
  // a look's layer style as glow + shadow numbers: its own (an inline style), a card look's (copied into the
  // look on its first change, so the other looks keep theirs), else none yet
  const libFx = (name) => ((((App.state.config || {}).dynamic_settings || {}).layer_style_library) || {})[name];
  function fxView(s) {
    const f = s.fx && typeof s.fx === "object" ? s.fx : s.fx ? libFx(s.fx) : null;
    return { f: f || {}, editable: !s.fx || typeof s.fx === "object" || !!(f && f.captured_params) };
  }
  function glowShadowHtml(st, s) {
    const k = (p) => `data-pl="${st}|${p}"`, { f, editable } = fxView(s), cp = f.captured_params || {};
    const g = cp.outer_glow || {}, d = cp.drop_shadow || (f.shadow_enabled ? { enabled: true, color: f.shadow_rgb, opacity: f.shadow_opacity, distance: f.shadow_distance, size: f.shadow_size } : {});
    const gOn = g.enabled !== false && !!g.color, dOn = d.enabled !== false && !!d.color;
    const inner = editable ? `<span class="ts-lbl" title="A glow around the shape">Glow</span>${sw(k("glow"), gOn ? g.color : "", "Glow colour (None = no glow)")}
        ${gOn ? `${num(k("glow.size"), g.size ?? 16, "Glow size (px)", 0, 250, "px")}${num(k("glow.opacity"), g.opacity ?? 60, "Glow opacity (%)", 0, 100, "%")}` : ""}
        ${sep}<span class="ts-lbl" title="A shadow under the shape">Shadow</span>${sw(k("shadow"), dOn ? d.color : "", "Shadow colour (None = no shadow)")}
        ${dOn ? `${num(k("shadow.size"), d.size ?? 12, "Shadow softness (px)", 0, 250, "px")}${num(k("shadow.distance"), d.distance ?? 6, "Shadow distance (px)", 0, 250, "px")}${num(k("shadow.opacity"), d.opacity ?? 60, "Shadow opacity (%)", 0, 100, "%")}` : ""}`
      : `<span class="ts-hint">Its layer style “${esc(String(s.fx))}” is edited in the Layer style menu (fx) — or pick None there to give it a glow and shadow here</span>`;
    return group("lookfx_" + st, "✨ Glow & shadow", "The look's glow and shadow: colour, size, opacity", inner);
  }
  // the look's own glow / shadow to change (an inline layer style)
  function editFx(s) {
    if (!(s.fx && typeof s.fx === "object")) {
      const lib = s.fx ? libFx(s.fx) : null;
      s.fx = lib && typeof lib === "object" ? clone(lib) : {};
    }
    s.fx.captured_params = s.fx.captured_params || {};
    return s.fx;
  }
  // the drop shadow also as the flat shadow_* keys (what the PSD's layer style reads)
  function syncShadow(f) {
    const d = (f.captured_params || {}).drop_shadow || {};
    Object.assign(f, { shadow_enabled: d.enabled !== false && !!d.color, shadow_rgb: d.color || "#000000", shadow_opacity: d.opacity ?? 60,
      shadow_distance: d.distance ?? 6, shadow_size: d.size ?? 12, shadow_angle: d.angle ?? 120 });
  }
  // a row's counts and pays: colour and size
  // the counts and pays of a row — or, i = "@NAME", of one card on its own (out of its row, only this card)
  function numbersHtml(i) {
    const parts = String(i).startsWith("@") ? viewParts(String(i).slice(1))
      : (((S.data || {}).band_geo || {})[ROWS[i]] || {}).parts || get(`bands.${i}.parts`) || get("card.parts") || [];
    const p = (role) => parts.find((x) => x.role === role) || {};
    const c = p("counts"), y = p("pays");
    return `<span class="ts-lbl">Counts</span>${sw(`data-pn="${i}|counts"`, c.color || "#ffffff", "Counts colour")}${num(`data-pz="${i}|counts"`, c.font_size || 30, "Counts size", 6, 300, "")}
      <span class="ts-lbl">Pays</span>${sw(`data-pn="${i}|pays"`, y.color || "#ffffff", "Pays colour")}${num(`data-pz="${i}|pays"`, y.font_size || 30, "Pays size", 6, 300, "")}`;
  }
  // dividers: the lines between the symbol, the counts and the pays — every card's, or one card's own
  function dividersHtml(path, d, own) {
    const on = !!d.enabled;
    return `<span class="ts-lbl" title="Lines between the symbol, the counts and the pays${own ? " (this card)" : " (every card)"}">Dividers</span>
      <button class="ts-tgt ${on ? "on" : ""}" data-dvon="${path}" data-on="${on ? 1 : 0}">${on ? "On" : "Off"}</button>
      ${on ? `${sw(`data-dvc="${path}"`, d.color || "#ffffff", "Divider colour")}${num(`data-dvw="${path}"`, d.width || 2, "Divider width (px)", 1, 30, "px")}
        <button class="ts-al ${d.symbol !== false ? "on" : ""}" data-dvk="${path}|symbol" title="The line between the symbol and the counts">▏▯</button>
        <button class="ts-al ${d.numbers !== false ? "on" : ""}" data-dvk="${path}|numbers" title="The line between the counts and the pays">▯▕</button>` : ""}`;
  }
  /* the paytable title's own text look (page.title: font, size, bold, italic, colour, layer style) — this
     design's title only; empty: the page heading's (Heading tab). ↺ takes it back to the heading's look */
  function titleTextHtml() {
    const x = get("page.title") || {}, own = ["font", "font_size", "color", "bold", "italic", "fx"].some((k) => x[k] != null && x[k] !== "");
    const fonts = (App.state.fonts || []).slice().sort((a, b) => String(a).localeCompare(String(b)));
    if (x.font && !fonts.includes(x.font)) fonts.unshift(x.font);
    const hs = Math.round(Number(App.get("h_size")) || 60), hc = App.get("h_rgb");
    const hcol = Array.isArray(hc) ? "#" + hc.slice(0, 3).map((n) => Math.max(0, Math.min(255, Number(n) || 0)).toString(16).padStart(2, "0")).join("") : String(hc || "#ffffff");
    return `<select class="ts-style tbs-font" data-tfont="page.title" title="The title's font — empty: the heading's"><option value="">Heading font</option>${fonts.map((f) => `<option value="${esc(f)}" ${String(f).toLowerCase() === String(x.font || "").toLowerCase() ? "selected" : ""}>${esc(f)}</option>`).join("")}</select>
      ${num('data-tz="page.title.font_size"', x.font_size || hs, "The title's size (px) — only the paytable's title", 6, 600, "px")}
      <button class="ts-al ${x.bold !== false ? "on" : ""}" data-tog="page.title.bold" title="Bold"><b>B</b></button><button class="ts-al ${x.italic ? "on" : ""}" data-tog="page.title.italic" title="Italic"><i>I</i></button>
      ${sw('data-tc="page.title.color"', x.color || hcol, "The title's colour")}
      ${fxBtn('data-tfx="page.title.fx"', x.fx || "", "The title's layer style — None: the heading's")}
      ${own ? `<button class="ts-tgt" data-titlereset title="The page heading's look again (Heading tab)">↺ Heading's look</button>` : `<span class="ts-hint">now: the heading's look</span>`}`;
  }
  /* a dropdown group of the bar: its button, and a panel with the controls (in the bar's DOM, so
     wireBar wires them as before). S.grp: the open one, kept open while the bar is drawn again */
  const joinedTo = (name) => ((S.data || {}).joined || {})[String(name || "").toLowerCase()] || null;
  const followBtn = () => `<button class="ts-tgt ${S.joinFollow !== false ? "on" : ""}" data-joinfollow title="On: it takes the row's look. Off: it keeps its own look">Follow row style</button>`;
  const addToRowHtml = (what) => group("addrow", "⤓ Add to row", `Put ${what} in the top or bottom row as a card`,
    `${followBtn()}<span class="ts-lbl">into</span><button class="ts-al" data-joinrow="high" title="Into the top row">Top</button><button class="ts-al" data-joinrow="low" title="Into the bottom row">Bottom</button>`);
  function group(id, label, title, inner) {
    return `<span class="ptc-grp ${S.grp === id ? "open" : ""}" data-grp="${id}"><button class="ts-tgt ptc-grp-btn ${S.grp === id ? "on" : ""}" data-grpbtn="${id}" title="${esc(title)}">${label} ▾</button>
      <span class="ptc-grp-panel"><span class="ptc-grp-head">${label}<button class="ptc-grp-x" data-grpx title="Close">✕</button></span><span class="ptc-grp-body">${inner}</span></span></span>`;
  }
  /* a card's part picked on the card: only its tools. "num": the pays & values — font, size, bold, italic,
     colours, line height, where they sit, the divider between them; "sym": the symbol — its height, its
     picture. What they change follows the card: Only this card / a card on its own → that card, else its
     row (as the numbers' handles on the card do) */
  function cardPartBarHtml(head, sel, part) {
    const key = sel.key, free = isFree(key), iso = S.iso === key, i = rowI(rowOfCard(key)), one = free || iso;
    const crumbs = `${head}<button class="ts-tgt ptc-crumb" data-back title="Back (Esc)">${free ? "Page" : `${ROWNAME[ROWS[i]][0].toUpperCase()}${ROWNAME[ROWS[i]].slice(1)} row`}</button><span class="ptc-crumb-sep">›</span><button class="ts-tgt ptc-crumb" data-cpart="" title="The card's tools">${labelOf(sel)}</button><span class="ptc-crumb-sep">›</span><span class="ics-chip">${part === "num" ? "Pays & values" : "◆ Symbol"}</span>`;
    const isoBtn = free ? "" : `${sep}<button class="ts-tgt ${iso ? "on" : ""}" data-iso title="${iso ? "Back to editing every card of the row" : "Change only this card's — nothing else moves"}">${iso ? "Only this card ✓" : "Only this card"}</button>
      <span class="ts-lbl" title="What these tools change">${iso ? "this card" : `every ${ROWNAME[ROWS[i]]} card`}</span>`;
    if (part === "sym") {                           // a symbol's height is its own (card.symbol_px[name]) — never the row's
      return `${crumbs}
        ${sep}<span class="ts-lbl">Height</span><button class="ts-al" data-sym="-4" title="Smaller symbol (this card)">−</button>${num("data-sympx", symPx(key), "This symbol's height (px, as drawn)", 8, 2000, "px")}<button class="ts-al" data-sym="4" title="Bigger symbol (this card)">+</button><button class="ts-al" data-pop="symbol" title="Every symbol this height, reset">▾</button>
        ${sep}<button class="ts-tgt" data-pic title="Another picture for this symbol (every page)">🖼 Change picture</button>
        ${sep}${partsTools(false)}`;
    }
    const ps = viewParts(key), c = ps.find((p) => p.role === "counts") || {}, y = ps.find((p) => p.role === "pays") || {};
    const fonts = (App.state.fonts || []).slice().sort((a, b) => String(a).localeCompare(String(b)));
    [c.font, y.font].forEach((f) => { if (f && !fonts.includes(f)) fonts.unshift(f); });
    // the counts (5 4 3) and the pays (1500 750 …): each its own font, bold, italic
    const fontOf = (role, p, lab) => `<span class="ts-lbl" title="The ${lab} column">${lab}</span><select class="ts-style tbs-font" data-nf2="${role}" title="Font of the ${lab.toLowerCase()}"><option value="">Default font</option>${fonts.map((f) => `<option value="${esc(f)}" ${f === (p.font || "") ? "selected" : ""}>${esc(f)}</option>`).join("")}</select>
      <button class="ts-al ${p.bold ? "on" : ""}" data-nb2="${role}|bold" title="Bold ${lab.toLowerCase()}"><b>B</b></button><button class="ts-al ${p.italic ? "on" : ""}" data-nb2="${role}|italic" title="Italic ${lab.toLowerCase()}"><i>I</i></button>`;
    const own = Object.keys(get(`card_overrides.${key}.dividers`) || {}).length > 0;
    const dvPathNow = one || own ? `card_overrides.${key}.dividers` : "card.dividers";
    const dv = one || own ? Object.assign({}, get("card.dividers") || {}, get(`card_overrides.${key}.dividers`) || {}) : (get("card.dividers") || {});
    return `${crumbs}${isoBtn}
      ${sep}${fontOf("counts", c, "Counts")}${sep}${fontOf("pays", y, "Pays")}
      ${sep}${numbersHtml(one ? "@" + key : i)}
      <span class="ts-lbl" title="Line height">↕</span>${num("data-nl2", lineH(ps), "Line height (px)", 6, 400, "")}
      ${sep}<span class="ts-lbl" title="Where the pays and values sit beside the symbol">Place</span><button class="ts-al" data-narr="left" title="Left of the symbol">⯇</button><button class="ts-al" data-narr="below" title="Under the symbol">⯆</button><button class="ts-al" data-narr="right" title="Right of the symbol">⯈</button>
      ${sep}${dividersHtml(dvPathNow, dv, dvPathNow !== "card.dividers")}`;
  }
  // a row's tools: across in the bar, the rest grouped (the Card bar's "Whole row" and the Row bar)
  function rowGroups(i) {
    const b = get(`bands.${i}`) || {}, g = (((S.data || {}).band_geo || {})[ROWS[i]] || {}).size || [];
    return `<span class="ts-lbl">Across</span><button class="ts-al" data-across="${i}|-1" title="Fewer cards in a row">−</button><span class="tbs-val">${across(i) || "?"}</span><button class="ts-al" data-across="${i}|1" title="More cards in a row">+</button>
      ${sep}${group("rcards", "Cards", "The cards' size, scale and spacing", `<span class="ts-lbl">W</span>${num(`data-cw="${i}|card_w"`, b.card_w || Math.round(g[0] || 0) || "", "Card width (px) — empty: the cards fill the row", 40, 2000, "")}
        <span class="ts-lbl">H</span>${num(`data-cw="${i}|card_h"`, b.card_h || Math.round(g[1] || 0) || "", "Card height (px)", 30, 1200, "")}
        <span class="ts-lbl" title="The whole row bigger / smaller: cards, numbers and spacing together">Scale</span><button class="ts-al" data-rscale="${i}|0.9">−</button><button class="ts-al" data-rscale="${i}|1.1">+</button>
        <span class="ts-lbl" title="Space between the cards of this row">↔</span>${num(`data-rgap="${i}|gap_x"`, b.gap_x ?? "", "Space between cards (px) — empty: the page's", 0, 400, "")}
        <span class="ts-lbl" title="Space between the lines of cards of this row">↕</span>${num(`data-rgap="${i}|gap_y"`, b.gap_y ?? "", "Space between lines of cards (px) — empty: the page's", 0, 400, "")}
        ${b.pos && !b.lock_size ? `<button class="ts-tgt" data-rauto="${i}" title="Put this row back in its automatic place">Auto place</button>` : ""}
        ${i === 0 && (get("bands") || []).length > 2 ? `<span class="ts-lbl" title="How many cards stay on top — the rest go to the middle row (empty: split at the biggest drop in pay)">On top</span>${num(`data-rcount="0"`, b.count || "", "Cards on top (empty: automatic)", 1, 20, "")}` : ""}
        ${sep}<button class="ts-tgt ${b.tile && b.tile.enabled ? "on" : ""}" data-tile="${i}" title="A framed square behind each symbol of this row">Tile</button>${b.tile && b.tile.enabled ? `<button class="ts-al" data-pop="tile" title="The tile's look and padding">▾</button>` : ""}`)}
      ${group("rlook", "Look", "The row's cards: fill, stroke, corners, layer style — copy / paste a look", lookHtml(b.style || "card", "Card") + clipHtml())}
      ${group("rnum", "Numbers", "The row's counts and pays: colours, sizes, font", `${numbersHtml(i)}<button class="ts-tgt" data-pop="numbers" title="Font, bold, italic, line height of the pays and values">Aa ▾</button>`)}
      ${((S.data || {}).overflow || []).length && !get("card.overflow") ? `<select class="ts-style ts-warn" data-k="card.overflow" title="Some numbers don't fit their cards"><option value="">⚠ Numbers don't fit…</option><option value="shrink">Shrink the numbers</option><option value="grow">Make the cards bigger</option></select>` : ""}
      ${group("rdiv", "Dividers", "Lines between the symbol, the counts and the pays (every card)", dividersHtml("card.dividers", get("card.dividers") || {}, false))}
      <button class="ts-tgt" data-cust="card|${i}" title="Move and size the symbol, the numbers and extra texts on a big card">Customise card…</button>`;
  }
  const lockBtn = (k) => `<button class="ts-al ${locked(k) ? "on" : ""}" data-lockk="${esc(k)}" title="${locked(k) ? "Locked — click to unlock" : "Lock it where it is"}">${locked(k) ? "🔒" : "🔓"}</button>`;
  const clipHtml = () => `${`<span class="ts-sep"></span>`}<button class="ts-tgt" data-copylook title="Copy this look (Ctrl+C)">⧉ Copy look</button>
    <button class="ts-tgt" data-pastelook ${anyClip() ? "" : "disabled"} title="${anyClip() ? `Paste the look of ${esc(anyClip().from)} (Ctrl+V)` : "Copy a look first"}">Paste</button>`;
  // the look to paste: the last one copied anywhere (here, or a text page's heading plate / row strip)
  const anyClip = () => { const g = window.PshLook && PshLook.clip; return g && (!S.clip || g.look !== S.clip.look) ? g : S.clip; };
  async function barHtml() {
    const list = await designs();
    const t = tpl() || {}, sel = S.sel;
    const head = `<span class="ics-chip">▦ Paytable</span>`;
    if (sel && selLocked(sel)) {
      return `${head}<span class="ics-chip">${labelOf(sel)}</span><button class="ts-tgt" data-back>◂ Page</button>${sep}${lockBtn(lockKeyOf(sel))}
        <span class="ts-hint">Locked — nothing in it can be edited. Unlock it to edit; it stays exactly as it is.</span>`;
    }
    if (!sel) {
      const cur = saved();
      // what a reset goes back to: the design as saved (a design of your own), else the one it came from
      const orig = cur && [cur.id, cur.based_on].find((id) => id && list.some((d) => d.id === id));
      const show = (path, on2, label) => `<button class="ts-tgt ${on2 ? "on" : ""}" data-show="${path}" data-on="${on2 ? 1 : 0}">${on2 ? "✓ " : ""}${label}</button>`;
      return `${head}
        <select class="ts-style" data-design title="The paytable design every paytable sheet of the game is built with">
          ${cur ? "" : `<option value="" selected>Pick a design (preview: ${esc(t.name || "")})</option>`}
          ${list.map((d) => `<option value="${esc(d.id)}" ${cur && (cur.id === d.id || cur.based_on === d.id) ? "selected" : ""}>${esc(d.name)}${d.builtin ? "" : " (mine)"}</option>`).join("")}</select>
        ${cur && cur.edited ? `<span class="ts-hint">edited</span>` : ""}
        <button class="ts-tgt" data-templates title="Every design drawn with this sheet's own Excel — pick one, or add a blueprint PSD">▦ Templates ▾</button>
        ${sep}<span class="ts-lbl">High cards</span><button class="ts-al" data-across="0|-1">−</button><span class="tbs-val">${across(0) || "?"}</span><button class="ts-al" data-across="0|1">+</button>
        ${(get("bands") || []).length > 2 ? `<span class="ts-lbl">Middle</span><button class="ts-al" data-across="2|-1">−</button><span class="tbs-val">${across(2) || "?"}</span><button class="ts-al" data-across="2|1">+</button>` : ""}
        <span class="ts-lbl">Low cards</span><button class="ts-al" data-across="1|-1">−</button><span class="tbs-val">${across(1) || "?"}</span><button class="ts-al" data-across="1|1">+</button>
        <button class="ts-tgt ${(get("bands") || []).length > 2 ? "on" : ""}" data-tiers title="A third row of cards between the high and the low cards (the high row's lesser symbols)">3 tiers</button>
        <button class="ts-tgt ${get("page.cards_panel.enabled") ? "on" : ""}" data-panel title="A framed panel behind all the cards">Panel</button>${get("page.cards_panel.enabled") ? `<button class="ts-al" data-pop="panel" title="The panel's look and padding">▾</button>` : ""}
        ${sep}${show("page.title.enabled", get("page.title.enabled") !== false, "Title")}${show("features.enabled", !!get("features.enabled"), "WILD / SCATTER")}${show("page.notes.enabled", get("page.notes.enabled") !== false, "Text")}
        ${sep}${["left", "center", "right"].map((a) => `<button class="ts-al ${(get("page.align") || "center") === a ? "on" : ""}" data-palign="${a}" title="Short rows: ${a}">${a === "left" ? "⯇≡" : a === "right" ? "≡⯈" : "≡"}</button>`).join("")}
        ${sep}<button class="ts-tgt" data-pop="page" title="Margins, gaps, where the cards sit, the game name">⚙ Page ▾</button>
        <button class="ts-tgt ${(get("zones") || []).length ? "on" : ""}" data-pop="zones" title="Rows for the WILD / SCATTER boxes and the rules text, each shown only when the Excel has it">▤ Zones ▾</button>
        <button class="ts-tgt" data-addtext title="A new text box on the page">+ Text box</button>
        ${sep}<button class="ts-tgt" data-saveas title="Keep this design among your designs (every game can use it)">💾 Save as…</button>
        ${cur && list.some((d) => d.id === cur.id && !d.builtin) ? `<button class="ts-al" data-deldesign="${esc(cur.id)}" title="Delete “${esc(cur.name || "")}” from your designs">🗑</button>` : ""}
        ${cur && orig ? `<button class="ts-tgt" data-startover="${esc(orig)}" ${cur.edited ? "" : "disabled"} title="${cur.edited ? "The paytable as its design was, without the edits made here (Ctrl+Z undoes)" : "Nothing to reset: the paytable is as its design"}">↺ Reset paytable</button>` : ""}
        ${sep}<button class="ts-tgt" data-learn title="Read the artist's paytable page from their PSD as an editable design">🎨 Learn from PSD…</button>
        <button class="ts-tgt" data-suggest title="Three arrangements of this page, laid out and scored: yours first">✨ Suggest layouts</button>
        <button class="ts-tgt pc-check" data-check>✓ Pay check</button>

        <span class="ts-hint">click a card, a row, a box · Esc steps back</span>`;
    }
    if (sel.kind === "zone") return zoneBarHtml(head, sel);
    if (sel.kind === "picon") return iconBarHtml(head, sel);
    if (sel.kind === "btext") {
      const [p, what] = BOX_TEXT[sel.key] || [], x = get(p) || {}, box = sel.key.startsWith("@slot.wild") ? "wild" : "scatter";
      const fonts = (App.state.fonts || []).slice().sort((a, b) => String(a).localeCompare(String(b)));
      if (x.font && !fonts.includes(x.font)) fonts.unshift(x.font);
      const drawn = ((S.data || {}).items || []).find((it) => it.slot === sel.key) || {}, st = drawn.style || {};
      return `${head}<span class="ics-chip">T ${esc(what)}</span><button class="ts-tgt" data-btback="${box}" title="Its box">◂ ${box.toUpperCase()} box</button>
        ${sep}<select class="ts-style tbs-font" data-tfont="${p}" title="Font"><option value="">Default font</option>${fonts.map((f) => `<option value="${esc(f)}" ${String(f).toLowerCase() === String(x.font || "").toLowerCase() ? "selected" : ""}>${esc(f)}</option>`).join("")}</select>
        ${num(`data-tz="${p}.font_size"`, Math.round(x.font_size || st.size || 30), "Text size (px)", 6, 400, "px")}
        <button class="ts-al ${x.bold ? "on" : ""}" data-tog="${p}.bold"><b>B</b></button><button class="ts-al ${x.italic ? "on" : ""}" data-tog="${p}.italic"><i>I</i></button>
        ${sw(`data-tc="${p}.color"`, x.color || st.color || "#ffffff", "Text colour")}
        ${["left", "center", "right"].map((a) => `<button class="ts-al ${(x.align || "center") === a ? "on" : ""}" data-talign="${p}|${a}">${a === "left" ? "⯇≡" : a === "right" ? "≡⯈" : "≡"}</button>`).join("")}
        ${fxBtn(`data-tfx="${p}.fx"`, x.fx || "", "Layer style")}
        ${sep}<button class="ts-tgt" data-btype title="Type its words where they are (or double-click them)">✎ Edit text</button>
        ${get(`text_overrides.${(((S.data || {}).box_texts || {})[sel.key] || {}).hash}`) != null ? `<button class="ts-tgt" data-btreset title="The Excel's words again">Back to the Excel text</button>` : ""}
        <span class="ts-hint">double-click it to type</span>`;
    }
    if (sel.kind === "scard") {
      return `${head}<span class="ics-chip">▦ SCATTER card</span><button class="ts-tgt" data-scback title="The SCATTER box">◂ SCATTER box</button>
        ${sep}${partsTools()}
        ${sep}${lookHtml(get("scatter_section.card.style") || "scatter_card", "Card")}
        ${sep}<button class="ts-tgt" data-pic title="Another picture for this symbol (every page)">🖼 Change picture</button>
        <button class="ts-tgt" data-cust="scard" title="Move and size the symbol and the numbers on a big card">Customise card…</button>
        ${sep}${addToRowHtml("this card")}
        <span class="ts-hint">on the card: drag the symbol, the numbers · every SCATTER card follows</span>`;
    }
    if (sel.kind === "band") {
      const i = rowI(sel.key);
      return `${head}<button class="ts-tgt ptc-crumb" data-back title="The page (Esc)">Page</button><span class="ptc-crumb-sep">›</span><span class="ics-chip">${labelOf(sel)}</span>${lockBtn(sel.key)}${sep}${rowGroups(i)}`;
    }
    if (sel.kind === "card" && partOf()) return cardPartBarHtml(head, sel, partOf());
    if (sel.kind === "card") {
      const i = rowI(rowOfCard(sel.key)), key = sel.key, free = isFree(key);
      const iso = S.iso === key, own = !!((get("card_overrides") || {})[lc(key)] || {}).parts, alone = free || iso || own;
      const tab = free ? "card" : S.cardTab || "card", ownStyle = get(`card_overrides.${key}.style`);
      const crumbs = `${head}<button class="ts-tgt ptc-crumb" data-back title="Its row (Esc)">${free ? "Page" : `${ROWNAME[ROWS[i]][0].toUpperCase()}${ROWNAME[ROWS[i]].slice(1)} row`}</button><span class="ptc-crumb-sep">›</span><span class="ics-chip" title="On the card: drag the symbol, the numbers, their handles · drag the card to move it · right-click: share a card">${labelOf(sel)}</span>`;
      const tabs = free ? "" : `${sep}<span class="tbs-seg" title="What the tools change"><button class="${tab === "card" ? "on" : ""}" data-ctab="card" title="This card's symbol, size, look">This card</button><button class="${tab === "row" ? "on" : ""}" data-ctab="row" title="Every card of its row (${ROWNAME[ROWS[i]]} cards)">Whole row</button></span>`;
      const actions = `${sep}<button class="ts-tgt" data-cpart="sym" title="The symbol: its size, its picture (or click it on the card)">◆ Symbol ›</button><button class="ts-tgt" data-cpart="num" title="The pays & values: font, size, colours, arrangement, divider (or click them on the card)">Pays & values ›</button>
        ${alone ? `<button class="ts-tgt" data-cust="cardown|${esc(key)}" title="Move and size this card's symbol, numbers and texts — only this card (add a text only to it)">Customise…</button>` : ""}
        ${free ? group("join", "⤓ Join row", "Back into a row", `<button class="ts-tgt on" data-join title="Back into its row, in its place">⤓ Back in its place</button>
            ${followBtn()}<span class="ts-lbl" title="Put it in a row of your choice">into</span><button class="ts-al" data-joinrow="high" title="Into the top row">Top</button><button class="ts-al" data-joinrow="low" title="Into the bottom row">Bottom</button>`)
          : joinedTo(key) ? `<button class="ts-tgt" data-unjoin title="Out of the row: back in its SCATTER box">⤴ Back to its box</button>`
          : `<button class="ts-tgt" data-break title="Take this card out of its row: move and size it anywhere (its content scales with it)">⤴ Break out</button>`}`;
      if (tab === "row") return `${crumbs}${tabs}${sep}${rowGroups(i)}${actions}`;
      return `${crumbs}${tabs}
        ${free ? "" : `${sep}<button class="ts-tgt ${iso ? "on" : ""}" data-iso title="${iso ? "Back to editing every card of the row" : "Edit only this card: nothing else moves"}">${iso ? "Only this card ✓" : "Only this card"}</button>`}
        ${own && !free ? `<button class="ts-tgt" data-follow title="Drop this card's own design: it follows its row again">Follow row</button>` : ""}
        ${sep}<span class="ts-lbl" title="This card bigger or smaller than the others in its row">Size</span><button class="ts-al" data-csize="-10">−</button><span class="tbs-val">${Math.round(Number(get(`card_overrides.${key}.size`) || 100))}%</span><button class="ts-al" data-csize="10">+</button>
        ${sep}${lookHtml(ownStyle || (get(`bands.${i}.style`) || "card"), ownStyle ? "This card" : free || iso ? "This card" : `Every ${ROWNAME[ROWS[i]]} card`)}
        <button class="ts-tgt ${ownStyle ? "on" : ""}" data-ownlook title="${ownStyle ? "This card has its own look — click: it takes the row's look again" : "Give this card its own look (the others keep the row's)"}">${ownStyle ? "Own look ✓" : "Own look"}</button>
        ${alone ? group("rowlook", "Design of", "This card takes a row's design: its parts and its look", `<button class="ts-al" data-rowlook="0" title="The top row's cards">Top row</button>${(get("bands") || []).length > 1 ? `<button class="ts-al" data-rowlook="1" title="The bottom row's cards">Bottom row</button>` : ""}`) : ""}${clipHtml()}
        ${members(key).length > 1 ? group("kind", "Of a kind", "A caption on every shared card, e.g. OF A KIND", `<button class="ts-tgt ${get("card.kind_caption.enabled") ? "on" : ""}" data-kind title="A caption on every shared card, e.g. OF A KIND">Of a kind</button>
          ${get("card.kind_caption.enabled") ? `<input type="text" class="ts-style ptc-ztitle" data-k="card.kind_caption.text" value="${esc(get("card.kind_caption.text") || "OF A KIND")}" title="The caption's text"><button class="ts-al" data-pop="kind" title="The caption's font, size, colour, place">▾</button>` : ""}`) : ""}
        ${actions}`;
    }
    if (sel.kind === "box") {
      const b = sel.key, parts = boxParts(b), tx = parts.text || {};
      return `${head}<span class="ics-chip">${labelOf(sel)}</span><button class="ts-tgt" data-back>◂ Page</button>${zoneOfBlock(b) ? zoneChipHtml(b) : lockBtn(b)}
        ${sep}${lookHtml(b === "scatter" && Object.keys(blocks()).some((k) => k.startsWith("scard:")) ? (get("scatter_section.style") || "scatter_frame") : (get("features.style") || "feature"), "Box")}
        ${b === "scatter" && Object.keys(blocks()).some((k) => k.startsWith("scard:")) ? `${sep}<span class="ts-hint">click its heading or caption to style or type them</span>` : `${sep}<button class="ts-tgt ${get("features.tab.enabled") !== false ? "on" : ""}" data-show="features.tab.enabled" data-on="${get("features.tab.enabled") !== false ? 1 : 0}">Tab</button>
        ${get("features.tab.enabled") !== false ? `<button class="ts-tgt" data-pop="tab" title="The label tab's look and its text">Tab ▾</button>` : ""}`}
        ${b === "wild" ? `${sep}<span class="ts-lbl">Text</span>${sw('data-tc="features.wild_parts.text.color"', tx.color || "#ffffff", "Text colour")}${num('data-tz="features.wild_parts.text.font_size"', tx.font_size || 30, "Text size", 6, 200, "")}
          <button class="ts-tgt" data-pop="wildtext" title="The WILD text: font, align, bold, italic, layer style">Aa ▾</button>
          ${(((S.data || {}).wild_text || {}).tokens || []).length ? `<button class="ts-tgt" data-pop="wildicons" title="Leave icons out of the WILD text, size them">Icons ▾</button>` : ""}` : ""}
        <button class="ts-tgt" data-pop="boxtexts" title="Font, size, colour, layer style of the box's heading, caption, text and numbers">Texts ▾</button>
        ${["panel", "title", "label"].some((r) => (parts[r] || {}).style) ? `<button class="ts-tgt" data-pop="boxshapes" title="The look of the panel inside the box and the bands behind its heading and caption">Panel & bands ▾</button>` : ""}
        ${sep}<button class="ts-tgt" data-cust="${b}" title="Move and size the box's symbol, heading, caption and text">Customise box…</button>
        ${((S.data || {}).required_boxes || []).includes(b) ? `<span class="ts-hint" title="The sheet has a ${b.toUpperCase()} symbol with its own pays">always shown</span>` : `<button class="ts-tgt" data-hidebox="${b}" title="No ${b.toUpperCase()} box on the page">Remove box</button>`}${clipHtml()}
        ${b === "scatter" && (S.data || {}).scatter_key ? `${sep}${addToRowHtml("the SCATTER")}` : ""}
        ${b === "wild" ? `<span class="ts-hint">on the box: drag its symbol and its text</span>` : ""}`;
    }
    if (sel.kind === "text") {
      const i = (get("page.texts") || []).findIndex((x) => x.id === sel.key), base = `page.texts.${i}`, x = get(base) || {};
      if (i < 0) return `${head}<span class="ics-chip">T Text</span><button class="ts-tgt" data-back>◂ Page</button>
        ${sep}<button class="ts-tgt" data-tedit="${esc(sel.key)}" title="Type in it like a document">✎ Edit text</button>
        <button class="ts-tgt" data-pintext title="Give the page's text boxes their own font, size, colour, place and background">Style this text box</button>`;
      const tm = texts().find((y) => String(y.id) === String(sel.key)) || {};
      const auto = x.size_mode !== "own" && !x.font_size_set;
      const fill = x.fill_space !== undefined ? !!x.fill_space : (!x.locked && !x.rect);
      const fonts = (App.state.fonts || []).slice().sort((a, b) => String(a).localeCompare(String(b)));
      return `${head}<span class="ics-chip">T Text box</span><button class="ts-tgt" data-back>◂ Page</button>${zoneOfBlock("text:" + sel.key) ? zoneChipHtml("text:" + sel.key) : lockBtn("text:" + sel.key)}
        ${sep}<select class="ts-style tbs-font" data-tfont="${base}" title="Font"><option value="">Paragraph font</option>${fonts.map((f) => `<option value="${esc(f)}" ${String(f).toLowerCase() === String(x.font || "").toLowerCase() ? "selected" : ""}>${esc(f)}</option>`).join("")}</select>
        <button class="ts-tgt ${auto ? "on" : ""}" data-tauto="${base}" title="The paragraph size of the other pages (shrinks only when the text doesn't fit)">Auto size</button>
        ${num(`data-tsize="${base}"`, auto ? "" : (x.font_size || ""), "Text size (px) — empty: Auto", 6, 400, "px")}
        <button class="ts-al ${x.bold ? "on" : ""}" data-tog="${base}.bold"><b>B</b></button><button class="ts-al ${x.italic ? "on" : ""}" data-tog="${base}.italic"><i>I</i></button>
        ${sw(`data-tc="${base}.color"`, x.color || "#ffffff", "Text colour")}
        ${["left", "center", "right"].map((a) => `<button class="ts-al ${(x.align || "center") === a ? "on" : ""}" data-talign="${base}|${a}">${a === "left" ? "⯇≡" : a === "right" ? "≡⯈" : "≡"}</button>`).join("")}
        <button class="ts-al ${x.keep_breaks ? "on" : ""}" data-tog="${base}.keep_breaks" title="Keep line breaks: each Excel line on its own line. Off: the lines join and wrap to the box — widen it for fewer lines (a blank line still starts a new paragraph)">¶</button>
        <span class="ts-lbl" title="Line height">↕</span>${num(`data-tz="${base}.line_height"`, x.line_height || "", "Line height (px) — empty: as the font", 0, 600, "")}
        <span class="ts-lbl" title="The height of every symbol in this text (px, as drawn)">Icons</span><button class="ts-al" data-ticon="${base}|-2">−</button><span class="tbs-val">${Math.round(Number((x.icon_px || {})["*"]) || (((S.drawn || {}).__icons || []).find((ic) => ic.slot === tm.slot) ? iconPx(tm.slot, ((S.drawn || {}).__icons || []).find((ic) => ic.slot === tm.slot).tok) : 0) || 0)} px</span><button class="ts-al" data-ticon="${base}|2">+</button>
        ${fxBtn(`data-tfx="${base}.fx"`, x.fx || "", "Layer style")}
        ${sep}<button class="ts-tgt ${fill ? "on" : ""}" data-tfill="${base}" data-on="${fill ? 1 : 0}" title="The text takes the biggest free space on the page (above or below the cards)">Fill the free space</button>
        ${sep}<button class="ts-tgt" data-tedit="${esc(sel.key)}" title="Type in it like a document (Enter: new line)">✎ Edit text</button>
        <button class="ts-tgt ${(x.bg || {}).on ? "on" : ""}" data-pop="textbg" title="A panel behind the text, or a strip across the page">Background ▾</button>
        ${(tm.tokens || []).length ? `<button class="ts-tgt" data-pop="texticons" title="Leave icons out of this text, size them">Icons ▾</button>` : ""}
        ${get(`page.text_edits.${((S.data || {}).text_info || {}).hash || "none"}`) ? `<button class="ts-tgt" data-tback title="Undo every text edit: the Excel's text again">Back to the Excel text</button>` : ""}
        ${(get("page.texts") || []).length > 1 ? `<button class="ts-tgt" data-tdel="${esc(sel.key)}" title="Remove this box (its text goes to the first box)">Delete box</button>` : ""}
        <span class="ts-hint">right-click: merge with another box</span>`;
    }
    const plate = get("page.title.plate") !== false;
    const gname = ((App.state.config.dynamic_settings || {}).heading_game_name_text) || "";
    return `${head}<span class="ics-chip">Title</span><button class="ts-tgt" data-back>◂ Page</button>
      ${sep}<span class="ts-lbl" title="What <GAME NAME> becomes on every page">Game name</span><input type="text" class="ts-style" data-gname value="${esc(gname)}" placeholder="&lt;GAME NAME&gt;" style="width:150px">
      ${sep}${titleTextHtml()}
      ${get("page.title.dx") || get("page.title.dy") ? `<button class="ts-tgt" data-titleplace title="Back where the other pages' headings are">↺ Place</button>` : ""}
      ${get("page.title.gap") != null ? `<button class="ts-tgt" data-titlegap title="The rows' gap under the title again">↺ Gap</button>` : ""}
      ${sep}<button class="ts-tgt ${plate ? "on" : ""}" data-show="page.title.plate" data-on="${plate ? 1 : 0}">Plate</button>
      ${plate ? `<button class="ts-tgt ${get("page.title.fit") && !Array.isArray(get("page.title.plate_pads")) ? "on" : ""}" data-titlefit title="${Array.isArray(get("page.title.plate_pads")) ? "The plate is sized by hand (its handles) — click: it hugs the title's text again" : "The plate hugs the title's text (else the plate width below)"}">Fit to text</button>
        ${get("page.title.fit") ? num('data-tz="page.title.fit_pad"', get("page.title.fit_pad") ?? 40, "Room each side of the text (px)", 0, 1000, "px") : ""}` : ""}
      <button class="ts-tgt" data-titlelikeheads title="This plate takes the look of the other pages' heading plate (Heading › ▭ Plate) and fits to the text">▭ Like the headings</button>
      ${plate ? group("tplate", "Plate ▸", "The plate behind the title: width, fill, stroke, corners, layer style", `<span class="ts-lbl">W</span>${num('data-tz="page.title.w"', get("page.title.w") || 900, "Plate width (px) — or drag its sides", 120, Number(((S.data || {}).canvas || {}).dw) || 1920, "")}` + lookHtml(get("page.title.style") || "plate", "Plate") + clipHtml()) : ""}`;
  }
  function wireBar(root) {
    const q = (s) => root.querySelectorAll(s);
    q("[data-ctab]").forEach((b) => b.addEventListener("click", () => { S.cardTab = b.dataset.ctab; S.grp = ""; paint(); }));
    root.querySelector("[data-titlefit]")?.addEventListener("click", () => edit((t) => {
      const sized = Array.isArray(get("page.title.plate_pads", t));
      if (sized) { delete t.page.title.plate_pads; put(t, "page.title.fit", true); }      // sized by hand → hugs the text again
      else put(t, "page.title.fit", !get("page.title.fit", t));
    }));
    root.querySelector("[data-titlelikeheads]")?.addEventListener("click", () => {
      const p = (App.state.config.dynamic_settings || {}).heading_plate;
      if (!p) { toast("No heading plate yet — set one on a text page: Heading › ▭ Plate."); return; }
      edit((t) => {
        const name = get("page.title.style", t) || "plate", bd = p.border || {};
        t.styles = t.styles || {};
        t.styles[name] = Object.assign({}, t.styles[name] || {}, {
          fill: p.color || "#1e3a8a", fill_enabled: true, fill_opacity: Math.round((p.opacity == null ? 0.85 : Number(p.opacity)) * 100),
          radius: Number(p.radius) || 0, fx: p.fx || "",
          stroke: Number(bd.width) > 0 ? { enabled: true, color: bd.color || "#ffffff", width: Number(bd.width), align: bd.align || "inside" } : { enabled: false } });
        put(t, "page.title.plate", true);
        put(t, "page.title.fit", true);
        delete t.page.title.plate_pads;
        put(t, "page.title.fit_pad", Number(p.pad_x) || 40);
      });
      toast("The title's plate looks like the headings' and fits its text.");
    });
    root.querySelector("[data-titleplace]")?.addEventListener("click", () => edit((t) => { const x = (t.page || {}).title; if (x) { delete x.dx; delete x.dy; } }));
    root.querySelector("[data-titlegap]")?.addEventListener("click", () => edit((t) => { const x = (t.page || {}).title; if (x) delete x.gap; }));
    root.querySelector("[data-titlereset]")?.addEventListener("click", () => edit((t) => {
      const x = (t.page || {}).title;
      if (x) ["font", "font_size", "color", "bold", "italic", "fx"].forEach((k) => delete x[k]);
    }));
    q("[data-cpart]").forEach((b) => b.addEventListener("click", () => setPart(b.dataset.cpart)));
    const numWrite = (fn, role) => edit((t) => editSets(t, S.sel.key).flat().forEach((p) => { if (role ? p.role === role : (p.role === "counts" || p.role === "pays")) fn(p); }));
    q("[data-nf2]").forEach((n) => n.addEventListener("change", (e) => numWrite((p) => { if (e.target.value) p.font = e.target.value; else delete p.font; }, n.dataset.nf2 || null)));
    q("[data-nb2]").forEach((b) => b.addEventListener("click", () => {
      const [role, k] = b.dataset.nb2.includes("|") ? b.dataset.nb2.split("|") : [null, b.dataset.nb2], on2 = !b.classList.contains("on");
      numWrite((p) => { p[k] = on2; }, role);
    }));
    root.querySelector("[data-nl2]")?.addEventListener("change", (e) => { const v = Math.max(6, Number(e.target.value) || 0); numWrite((p) => { p.line_height = v; }); });
    q("[data-narr]").forEach((b) => b.addEventListener("click", () => arrangeNumbers(b.dataset.narr)));
    q("[data-grpbtn]").forEach((b) => b.addEventListener("click", () => { S.grp = S.grp === b.dataset.grpbtn ? "" : b.dataset.grpbtn; paint(); }));
    q("[data-grpx]").forEach((b) => b.addEventListener("click", (ev) => { ev.stopPropagation(); S.grp = ""; paint(); }));
    placeGroup(root);
    root.querySelector("[data-design]")?.addEventListener("change", (ev) => { if (ev.target.value) pickDesign(ev.target.value); });
    root.querySelector("[data-back]")?.addEventListener("click", () => escape());
    root.querySelector("[data-lockk]")?.addEventListener("click", (ev) => toggleLock(ev.currentTarget.dataset.lockk));
    root.querySelector("[data-copylook]")?.addEventListener("click", () => copyLook());
    root.querySelector("[data-pastelook]")?.addEventListener("click", () => pasteLook());
    root.querySelector("[data-check]")?.addEventListener("click", () => payCheck());
    root.querySelector("[data-suggest]")?.addEventListener("click", (ev) => suggestPop(ev.currentTarget));
    root.querySelector("[data-learn]")?.addEventListener("click", (ev) => learnPop(ev.currentTarget));
    root.querySelector("[data-templates]")?.addEventListener("click", (ev) => templatesPop(ev.currentTarget));
    q("[data-across]").forEach((b) => b.addEventListener("click", () => {
      const [i, d] = b.dataset.across.split("|").map(Number);
      edit((t) => { const band = t.bands[i]; if (!band) return; band.per_row = Math.max(1, Math.min(10, (Number(band.per_row) || across(i) || 4) + d)); delete band.card_w; });
    }));
    q("[data-show]").forEach((b) => b.addEventListener("click", () => {
      const path = b.dataset.show, next = b.dataset.on !== "1";
      edit((t) => { put(t, path, next); if (path === "features.enabled" && next) { put(t, "features.wild", true); put(t, "features.scatter", true); } });
    }));
    q("[data-palign]").forEach((b) => b.addEventListener("click", () => set("page.align", b.dataset.palign)));
    // a style's look: fill / stroke colour (swatches), stroke width, radius, layer style
    q("[data-pl]").forEach((n) => {
      const [st0, prop] = n.dataset.pl.split("|");
      const write = (fn) => edit((t) => {
        let st = st0;
        const row = S.sel && (S.sel.kind === "band" || S.sel.kind === "card") ? (S.sel.kind === "band" ? (rowI(S.sel.key)) : (rowI(rowOfCard(S.sel.key)))) : null;
        let ownSt = S.sel && S.sel.kind === "card" && get(`card_overrides.${S.sel.key}.style`, t) === st0;
        if (S.sel && S.sel.kind === "card" && !ownSt && (S.iso === S.sel.key || isFree(S.sel.key))) {
          // a card on its own (Only this card / out of its row): its look is its own from the first change
          const key = lc(S.sel.key), o = ((t.card_overrides = t.card_overrides || {})[key] = t.card_overrides[key] || {});
          st = `card_${key.replace(/[^a-z0-9_]/g, "_")}`;
          t.styles = t.styles || {};
          t.styles[st] = clone(t.styles[st0] || {});
          o.style = st;
          ownSt = true;
        }
        if (row != null && t.bands && t.bands[row] && !ownSt) st = rowStyle(t, row);       // this row only
        t.styles = t.styles || {};
        if (!t.styles[st] && st === "scatter_frame") { t.styles[st] = clone(t.styles.feature || t.styles.card || {}); put(t, "scatter_section.style", st); }
        if (!t.styles[st] && st === "scatter_card") { t.styles[st] = clone(t.styles.card || {}); put(t, "scatter_section.card.style", st); }
        t.styles[st] = t.styles[st] || {};
        fn(t.styles[st]);
      });
      if (prop === "glow" || prop === "shadow") {
        n.addEventListener("click", () => window.Swatches && Swatches.open(n, n.dataset.cur, (c) => write((s) => {
          const f = editFx(s), cp = f.captured_params, key = prop === "glow" ? "outer_glow" : "drop_shadow";
          const dflt = prop === "glow" ? { size: 16, opacity: 60, spread: 0, blend: "screen" } : { size: 12, opacity: 60, distance: 6, angle: 120 };
          cp[key] = Object.assign(dflt, cp[key] || {}, c ? { enabled: true, color: c } : { enabled: false });
          if (prop === "shadow") syncShadow(f);
        }), prop === "glow" ? "No glow" : "No shadow"));
      } else if (/^(glow|shadow)\./.test(prop)) {
        n.addEventListener("change", () => write((s) => {
          const [what, field] = prop.split("."), f = editFx(s), key = what === "glow" ? "outer_glow" : "drop_shadow";
          const v = Math.max(0, Number(n.value) || 0);
          f.captured_params[key] = Object.assign({}, f.captured_params[key] || {}, { [field]: field === "opacity" ? Math.min(100, v) : v });
          if (what === "shadow") syncShadow(f);
        }));
      } else if (prop === "gradient_amount") {
        n.addEventListener("change", () => write((s) => { s.gradient_amount = Math.max(0, Math.min(100, Number(n.value) || 0)); }));
      } else if (prop === "fill_to") {
        n.addEventListener("click", () => window.Swatches && Swatches.open(n, n.dataset.cur, (c) => write((s) => {
          if (!c) { delete s.fill_to; delete s.gradient_dir; return; }
          s.fill_to = c;
          if (!s.gradient_dir || s.gradient_dir === "none") s.gradient_dir = "vertical";
        }), "None (flat fill)"));
      } else if (prop === "gradient_dir") {
        n.addEventListener("change", () => write((s) => { s.gradient_dir = n.value; }));
      } else if (prop === "fill" || prop === "stroke") {
        n.addEventListener("click", () => window.Swatches && Swatches.open(n, n.dataset.cur, (c) => write((s) => {
          if (prop === "fill") { s.fill_enabled = !!c; if (c) { s.fill = c; if (!(Number(s.fill_opacity ?? 100) > 4)) s.fill_opacity = 100; } }
          else { s.stroke = Object.assign({ width: 2, align: "inside" }, s.stroke || {}, { enabled: !!c }); if (c) s.stroke.color = c; }
        }), prop === "fill" ? "No fill" : "No stroke"));
      } else if (prop === "fx") {
        n.addEventListener("click", (ev) => window.TypoStudio && TypoStudio.fxPicker(ev.currentTarget, get(`styles.${st0}.fx`) || "", (name) => write((s) => { s.fx = name || ""; }), "None"));
      } else if (prop === "pill") {
        n.addEventListener("click", () => write((s) => { s.radius = s.radius === "pill" ? 12 : "pill"; }));
      } else if (prop === "fx_on") {
        n.addEventListener("change", () => write((s) => { if (n.value) s.fx_on = n.value; else delete s.fx_on; }));
      } else if (prop === "corner") {
        n.addEventListener("change", () => write((s) => {
          if (!n.value) return;
          delete s.corners;
          if (n.value === "round") delete s.corner; else s.corner = n.value;
          if (s.radius === "pill" || !(Number(s.radius) > 0)) s.radius = Array.isArray(s.radii) ? s.radius : 18;
        }));
      } else if (prop === "stroke.align") {
        n.addEventListener("change", () => write((s) => { s.stroke = Object.assign({ enabled: true, color: "#ffffff", width: 2 }, s.stroke || {}, { align: n.value }); }));
      } else {
        n.addEventListener("change", () => write((s) => {
          const v = Math.max(0, Number(n.value) || 0);
          if (prop === "fill_opacity") s.fill_opacity = Math.min(100, v);
          else if (prop === "radius") s.radius = v >= 999 ? "pill" : v;
          else s.stroke = Object.assign({ enabled: true, color: "#ffffff", align: "inside" }, s.stroke || {}, { width: v });
        }));
      }
    });
    // a row's counts / pays colour and size
    q("[data-pn]").forEach((n) => n.addEventListener("click", () => {
      const [i, role] = n.dataset.pn.split("|");
      window.Swatches && Swatches.open(n, n.dataset.cur, (c) => { if (c) edit((t) => numSets(t, i).flat().filter((p) => p.role === role).forEach((p) => { p.color = c; })); });
    }));
    q("[data-pz]").forEach((n) => n.addEventListener("change", () => {
      const [i, role] = n.dataset.pz.split("|"), v = Math.max(6, Number(n.value) || 0);
      edit((t) => numSets(t, i).flat().filter((p) => p.role === role).forEach((p) => { p.font_size = v; }));
    }));
    q("[data-cw]").forEach((n) => n.addEventListener("change", () => {
      const [i, key] = n.dataset.cw.split("|"), v = Math.round(Number(n.value) || 0);
      // the cards resize, what is inside them keeps its size (empty width: the cards fill the row again)
      edit((t) => {
        const b = t.bands[Number(i)];
        if (!b) return;
        if (!(v > 0)) { delete b[key]; return; }
        if (key === "card_w") resizeRow(t, Number(i), v, null); else resizeRow(t, Number(i), null, v);
      });
    }));
    q("[data-sym]").forEach((b) => b.addEventListener("click", () => setSymPx(S.sel.key, symPx(S.sel.key) + Number(b.dataset.sym))));
    root.querySelector("[data-sympx]")?.addEventListener("change", (e) => { const v = Number(e.target.value) || 0; if (v > 0) setSymPx(S.sel.key, v); });
    q("[data-tc]").forEach((n) => n.addEventListener("click", () => window.Swatches && Swatches.open(n, n.dataset.cur, (c) => { if (c) set(n.dataset.tc, c); })));
    q("[data-tz]").forEach((n) => n.addEventListener("change", () => set(n.dataset.tz, Math.max(6, Number(n.value) || 0))));
    q("[data-tog]").forEach((b) => b.addEventListener("click", () => set(b.dataset.tog, !b.classList.contains("on"))));
    q("[data-talign]").forEach((b) => b.addEventListener("click", () => { const [base, a] = b.dataset.talign.split("|"); set(base + ".align", a); }));
    q("[data-tfx]").forEach((b) => b.addEventListener("click", (ev) => window.TypoStudio && TypoStudio.fxPicker(ev.currentTarget, get(b.dataset.tfx) || "", (name) => set(b.dataset.tfx, name || ""), "None")));
    // text: font, Auto size / a size of its own, icons in it, the free space
    q("[data-tfont]").forEach((n) => n.addEventListener("change", () => set(n.dataset.tfont + ".font", n.value || undefined)));
    q("[data-tauto]").forEach((b) => b.addEventListener("click", () => edit((t) => { const x = get(b.dataset.tauto, t); if (!x) return; delete x.font_size_set; x.size_mode = "body"; })));
    q("[data-tsize]").forEach((n) => n.addEventListener("change", () => edit((t) => {
      const x = get(n.dataset.tsize, t), v = Number(n.value) || 0;
      if (!x) return;
      if (v > 0) { x.font_size = v; x.font_size_set = true; x.size_mode = "own"; } else { delete x.font_size_set; x.size_mode = "body"; }
    })));
    q("[data-ticon]").forEach((b) => b.addEventListener("click", () => {
      const [base, d] = b.dataset.ticon.split("|"), tm = texts().find((y) => String(y.id) === String(S.sel.key)) || {};
      const first = ((S.drawn || {}).__icons || []).find((ic) => ic.slot === tm.slot);
      const now = Number((get(`${base}.icon_px`) || {})["*"]) || (first ? iconPx(tm.slot, first.tok) : 40);
      const v = Math.max(4, Math.round(now + Number(d)));
      const toks = [...new Set(((S.drawn || {}).__icons || []).filter((ic) => ic.slot === tm.slot).map((ic) => ikey(ic.tok)))];
      edit((t) => { const x = get(base, t); if (!x) return; delete x.icon_scale; x.icon_px = Object.fromEntries(toks.map((kk) => [kk, v]).concat([["*", v]])); });
    }));
    q("[data-tfill]").forEach((b) => b.addEventListener("click", () => edit((t) => { const x = get(b.dataset.tfill, t); if (x) x.fill_space = b.dataset.on !== "1"; })));
    // dividers
    q("[data-dvon]").forEach((b) => b.addEventListener("click", () => edit((t) => {
      const d = get(b.dataset.dvon, t) || {};
      d.enabled = b.dataset.on !== "1";
      if (d.enabled && !d.color) { d.color = "#ffd200"; d.width = d.width || 2; }
      put(t, b.dataset.dvon, d);
    })));
    q("[data-dvc]").forEach((n) => n.addEventListener("click", () => window.Swatches && Swatches.open(n, n.dataset.cur, (c) => { if (c) edit((t) => put(t, n.dataset.dvc, Object.assign({}, get(n.dataset.dvc, t) || {}, { enabled: true, color: c }))); })));
    q("[data-dvw]").forEach((n) => n.addEventListener("change", () => edit((t) => put(t, n.dataset.dvw, Object.assign({}, get(n.dataset.dvw, t) || {}, { enabled: true, width: Math.max(1, Number(n.value) || 2) })))));
    q("[data-dvk]").forEach((b) => b.addEventListener("click", () => {
      const [path, k] = b.dataset.dvk.split("|");
      edit((t) => put(t, path, Object.assign({}, get(path, t) || {}, { enabled: true, [k]: !b.classList.contains("on") })));
    }));
    // a card's own size in its row
    q("[data-csize]").forEach((b) => b.addEventListener("click", () => {
      const name = S.sel.key, d = Number(b.dataset.csize);
      edit((t) => {
        const o = ((t.card_overrides = t.card_overrides || {})[name] = t.card_overrides[name] || {});
        const v = Math.max(50, Math.min(200, Number(o.size || 100) + d));
        if (v === 100) delete o.size; else o.size = v;
      });
    }));
    q("[data-hidebox]").forEach((b) => b.addEventListener("click", () => removeBox(b.dataset.hidebox)));
    wireK(root);
    wireZoneBar(root);
    wireIconBar(root);
    root.querySelector("[data-break]")?.addEventListener("click", () => {
      const name = S.sel.key, r = rectOf("card:" + name);
      if (r) { edit((t) => breakOut(t, name)); toast(`${name.toUpperCase()} is out of its row — drag ✥ to move it, the corner to size it; nothing you do to it changes the row (or the row to it). “Join row” puts it back.`); }
    });
    root.querySelector("[data-join]")?.addEventListener("click", () => {
      const key = lc(S.sel.key);
      edit((t) => joinRow(t, S.sel.key)); void key;
    });
    q("[data-joinrow]").forEach((b) => b.addEventListener("click", () => {
      const sel = S.sel, row = b.dataset.joinrow, follow = S.joinFollow !== false;
      let name = sel.key;
      if (sel.kind === "card") edit((t) => joinRow(t, name, row, follow));
      else {                                         // a SCATTER card / the lone SCATTER box: a card of the row
        name = sel.kind === "scard" ? sel.key : (S.data || {}).scatter_key;
        if (!name) return;
        edit((t) => joinIndep(t, name, row, follow, sel.kind));
        S.sel = null;
      }
      toast(`${String(name).toUpperCase()} is a card of the ${ROWNAME[row] || row} row now${follow ? ", with the row's look" : ", with its own look"}.`);
    }));
    root.querySelector("[data-joinfollow]")?.addEventListener("click", () => { S.joinFollow = S.joinFollow === false; paint(); });
    q("[data-looks]").forEach((b) => b.addEventListener("click", (ev) => looksPop(ev.currentTarget, S.sel && S.sel.kind === "card" ? "picked" : "all")));
    root.querySelector("[data-unjoin]")?.addEventListener("click", () => {
      const name = S.sel.key;
      edit((t) => unjoin(t, name));
      S.sel = null; S.iso = "";
      toast(`${String(name).toUpperCase()} is back in its box.`);
    });
    q("[data-rowlook]").forEach((b) => b.addEventListener("click", () => {
      const name = S.sel.key, i = Number(b.dataset.rowlook);
      edit((t) => copyRowLook(t, name, i));
      toast(`${name.toUpperCase()} has the ${i ? "bottom" : "top"} row's design — change it as you like, the row stays as it is.`);
    }));
    root.querySelector("[data-pic]")?.addEventListener("click", () => changePicture(S.sel.key));
    root.querySelector("[data-scback]")?.addEventListener("click", () => pick({ kind: "box", key: "scatter" }));
    root.querySelector("[data-btback]")?.addEventListener("click", (e) => pick({ kind: "box", key: e.currentTarget.dataset.btback }));
    root.querySelector("[data-btype]")?.addEventListener("click", () => editBoxText(S.sel.key));
    root.querySelector("[data-btreset]")?.addEventListener("click", () => { const h = (((S.data || {}).box_texts || {})[S.sel.key] || {}).hash; if (h) set(`text_overrides.${h}`, undefined); });
    // card variants: three tiers, the panel, a row's tile and numbers, a card's own look, "of a kind"
    root.querySelector("[data-tiers]")?.addEventListener("click", () => edit((t) => {
      if ((t.bands || []).length > 2) { t.bands.splice(2); Object.keys(t.row_of || {}).forEach((k) => { if (t.row_of[k] === "mid") delete t.row_of[k]; }); return; }
      const mid = clone(t.bands[0] || {});
      ["pos", "lock_size", "count"].forEach((k) => delete mid[k]);
      mid.name = "mid";
      t.bands[2] = mid;
    }));
    root.querySelector("[data-panel]")?.addEventListener("click", () => edit((t) => {
      const on2 = !get("page.cards_panel.enabled", t);
      put(t, "page.cards_panel.enabled", on2);
      if (on2 && !get("styles.panel", t)) put(t, "styles.panel", clone(DEFAULT_PANEL));
    }));
    root.querySelectorAll("[data-tile]").forEach((b) => b.addEventListener("click", () => edit((t) => {
      const i = Number(b.dataset.tile), band = t.bands[i];
      if (!band) return;
      band.tile = Object.assign({ pad: 0.08 }, band.tile || {}, { enabled: !(band.tile && band.tile.enabled) });
      if (band.tile.enabled && !get("styles.tile", t)) put(t, "styles.tile", clone(DEFAULT_TILE));
    })));
    root.querySelector("[data-rcount]")?.addEventListener("change", (e) => { const v = Math.round(Number(e.target.value) || 0); edit((t) => { if (v > 0) t.bands[0].count = v; else delete t.bands[0].count; }); });
    root.querySelector("[data-ownlook]")?.addEventListener("click", () => {
      const name = S.sel.key, key = lc(name), row = cardRow(name);
      edit((t) => {
        const o = ((t.card_overrides = t.card_overrides || {})[key] = t.card_overrides[key] || {});
        if (o.style) { delete o.style; if (!Object.keys(o).length) delete t.card_overrides[key]; return; }
        const st = `card_${key.replace(/[^a-z0-9_]/g, "_")}`;
        t.styles = t.styles || {};
        t.styles[st] = clone(t.styles[(t.bands[row] || {}).style || "card"] || {});
        o.style = st;
      });
    });
    root.querySelector("[data-kind]")?.addEventListener("click", () => edit((t) => {
      const on2 = !get("card.kind_caption.enabled", t);
      put(t, "card.kind_caption", Object.assign({ text: "OF A KIND", font_size: 24, color: "#FFFFFF" }, get("card.kind_caption", t) || {}, { enabled: on2 }));
    }));
    // the page: its panel, a new text box, the design library
    root.querySelector("[data-addtext]")?.addEventListener("click", () => addTextBox());
    root.querySelector("[data-saveas]")?.addEventListener("click", () => saveAs());
    root.querySelector("[data-deldesign]")?.addEventListener("click", (ev) => deleteDesign(ev.currentTarget.dataset.deldesign));
    root.querySelector("[data-startover]")?.addEventListener("click", (ev) => {
      const id = ev.currentTarget.dataset.startover;
      if (confirm("Reset the paytable to its design as it was? Every edit made here goes (Ctrl+Z brings them back).")) pickDesign(id);
    });
    root.querySelector("[data-gname]")?.addEventListener("change", (ev) => setGameName(ev.target.value));
    // popovers
    q("[data-pop]").forEach((b) => b.addEventListener("click", () => {
      const k = b.dataset.pop, sel = S.sel;
      if (document.querySelector(`.ptc-pop[data-for="${k}"]`)) { closePop(); return; }
      let pop = null;
      if (k === "page") pop = pagePop(b);
      else if (k === "zones") pop = zonesPop(b);
      else if (k === "boxtexts") pop = boxTextsPop(b, S.sel.key);
      else if (k === "panel") pop = popup(b, "Panel behind the cards", () => `${prow("Padding", kNum("page.cards_panel.pad", get("page.cards_panel.pad") ?? 24, 0, 200))}${lookFields(get("page.cards_panel.style") || "panel")}`);
      else if (k === "tile") { const i = rowI(S.sel.kind === "band" ? S.sel.key : rowOfCard(S.sel.key)); pop = popup(b, "Symbol tile", () => `${prow("Padding", kNum(`bands.${i}.tile.pad`, get(`bands.${i}.tile.pad`) ?? 0.08, 0, 0.4), "Space between the tile's edge and the symbol (a share of the tile)")}${lookFields(get(`bands.${i}.tile.style`) || "tile")}`); }
      else if (k === "kind") pop = popup(b, "“Of a kind” caption", () => `${textFields("card.kind_caption")}
        ${prow("Place", kSel("card.kind_caption.y", get("card.kind_caption.y") ?? 0.8, [[0.8, "At the bottom"], [0.02, "At the top"]]))}`);
      else if (k === "numbers") pop = numbersPop(b);
      else if (k === "symbol") pop = symbolPop(b);
      else if (k === "boxshapes") {
        const bp = `features.${S.sel.key}_parts`, names = { panel: "Panel inside the box", title: "Band behind the heading", label: "Band behind the caption" };
        pop = popup(b, "Panel & bands", () => ["panel", "title", "label"].filter((r) => (get(`${bp}.${r}`) || {}).style)
          .map((r) => `<div class="ptc-sub">${names[r]}</div>${lookFields(get(`${bp}.${r}.style`))}`).join(""));
      }
      else if (k === "tab") pop = popup(b, "Label tab", () => `${lookFields(get("features.tab.style") || "tab")}<div class="ptc-sub">Tab text</div>${textFields("features.tab.text", false)}`);
      else if (k === "wildtext") pop = popup(b, "WILD text", () => textFields("features.wild_parts.text"));
      else if (k === "wildicons") { const w = (S.data || {}).wild_text || {}; pop = iconsPop(b, "features.wild_box", w.tokens || [], w.hidden || [], "features.wild_box.hide", "Icons in the WILD text"); }
      else if (k === "textbg") pop = textBgPop(b, sel.key);
      else if (k === "texticons") {
        const tm = texts().find((y) => String(y.id) === String(sel.key)) || {}, i = tIdx(null, sel.key);
        pop = iconsPop(b, `page.texts.${i}`, tm.tokens || [], tm.hidden || [], `page.texts.${i}.hide_icons`, "Icons in this text");
      }
      if (pop) pop.dataset.for = k;
    }));
    // a row: scale, gaps, back to its automatic place
    q("[data-rscale]").forEach((b) => b.addEventListener("click", () => { const [i, f] = b.dataset.rscale.split("|").map(Number); edit((t) => scaleRow(t, i, f)); }));
    q("[data-rgap]").forEach((n) => n.addEventListener("change", () => {
      const [i, k] = n.dataset.rgap.split("|"), v = n.value === "" ? undefined : Math.max(0, Math.round(Number(n.value) || 0));
      edit((t) => { const b = t.bands[Number(i)]; if (!b) return; if (v == null) delete b[k]; else b[k] = v; });
    }));
    q("[data-rauto]").forEach((b) => b.addEventListener("click", () => edit((t) => { delete (t.bands[Number(b.dataset.rauto)] || {}).pos; })));
    q("[data-cust]").forEach((b) => b.addEventListener("click", () => {
      const [k, i] = b.dataset.cust.split("|");
      if (k === "cardown") openCustomise("card", rowI(rowOfCard(i)), i);   // only this card's own parts
      else openCustomise(k, Number(i) || 0);
    }));
    // a card: only this card, follow its row, align its parts, where its numbers sit
    root.querySelector("[data-iso]")?.addEventListener("click", () => {
      S.iso = S.iso === S.sel.key ? "" : S.sel.key;
      if (S.iso) toast(`Editing only ${S.iso.toUpperCase()} — nothing else moves. Esc or “Only this card” again: back to the row.`);
      pick(S.sel);
    });
    root.querySelector("[data-follow]")?.addEventListener("click", () => {
      const key = lc(S.sel.key);
      edit((t) => { const o = (t.card_overrides || {})[key]; if (o) { delete o.parts; if (!Object.keys(o).length) delete t.card_overrides[key]; } });
      S.iso = "";
      toast("This card follows its row's design again.");
    });
    q("[data-palg]").forEach((b) => b.addEventListener("click", () => alignParts(b.dataset.palg)));
    // a text box: type in it, style it, delete it
    q("[data-tedit]").forEach((b) => b.addEventListener("click", () => editText(b.dataset.tedit)));
    root.querySelector("[data-pintext]")?.addEventListener("click", () => edit((t) => pinTexts(t)));
    root.querySelector("[data-tback]")?.addEventListener("click", () => resetTexts());
    root.querySelector("[data-tdel]")?.addEventListener("click", (ev) => deleteText(ev.currentTarget.dataset.tdel));
  }
  // the open group's panel under its button (fixed: the bar's strip scrolls and would cut it off)
  function placeGroup(root) {
    const g = root.querySelector(".ptc-grp.open");
    if (!g) return;
    const r = g.querySelector(".ptc-grp-btn").getBoundingClientRect(), p = g.querySelector(".ptc-grp-panel");
    p.style.top = Math.round(r.bottom + 4) + "px";
    p.style.left = Math.round(Math.max(8, Math.min(r.left, window.innerWidth - p.offsetWidth - 8))) + "px";
  }
  // the top bar: TypoStudio asks for it while a paytable sheet is shown
  async function paint() {
    const strip = el("typoStrip");
    if (!strip || !on()) return;
    const now = JSON.stringify(S.sel || null);
    if (now !== S.grpSel) { S.grp = ""; S.grpSel = now; }            // another pick: the open dropdown closes
    const html = await barHtml();
    if (!on()) return;
    strip.innerHTML = `<div class="ptc-bar">${html}</div>`;
    wireBar(strip);
  }

  /* ------------------------------ arranging the cards ------------------------------ */
  // the cards as drawn: each row's card names in reading order (a shared card by its first symbol)
  function rows() {
    const out = { high: [], mid: [], low: [] };
    Object.entries(blocks()).filter(([k]) => k.startsWith("card:")).forEach(([k, b]) => {
      out[rowOfCard(k.slice(5))].push({ name: k.slice(5), b });
    });
    Object.values(out).forEach((r) => r.sort((a, c) => (Math.abs(a.b[1] - c.b[1]) > 0.01 ? a.b[1] - c.b[1] : a.b[0] - c.b[0])));
    return { high: out.high.map((x) => x.name), mid: out.mid.map((x) => x.name), low: out.low.map((x) => x.name) };
  }
  // the symbols drawn on a card: one, or several on a shared card (their pictures inside it)
  function members(name) {
    const b = blocks()["card:" + name], d = S.data;
    if (!b || !d) return [name];
    const W = d.canvas_px.width, H = d.canvas_px.height;
    const inside = (d.items || []).filter((it) => it.icon && /^@slot\.[^.]+$/.test(it.slot)).filter((it) => {
      const cx = (it.rect[0] + it.rect[2] / 2) / W, cy = (it.rect[1] + it.rect[3] / 2) / H;
      return cx >= b[0] && cx <= b[2] && cy >= b[1] && cy <= b[3];
    }).map((it) => it.slot.slice(6));
    return inside.length ? inside : [name];
  }
  // the pays read from the sheet: which symbols pay the same (only they may share a card)
  async function readPays() {
    const sheet = AppTypoVis.state.sheet;
    if (S.read && S.readSheet === sheet) return S.read;
    try { S.read = (await api("/api/paytable/read", { method: "POST", body: { sheet_name: sheet } })).read; } catch (e) { S.read = null; }
    S.readSheet = sheet;
    return S.read;
  }
  const RANK = { ace: "a", king: "k", queen: "q", jack: "j", ten: "10", nine: "9" };
  const keyOf = (n) => { const k = String(n || "").toLowerCase().replace(/[^a-z0-9]/g, ""); return RANK[k] || k; };
  function paysOf(name) {
    const s = ((S.read || {}).symbols || []).find((x) => keyOf(x.symbol) === keyOf(name));
    return s ? JSON.stringify(s.pays.map((p) => [p.count, p.pay])) : null;
  }

  /* drag a card: drop it before / after another card (its row re-flows), or on the other row */
  function pointerDown(ev) {
    if (ev.button !== 0 || !on()) return false;
    const f = frac(ev), k = f && blockAt(f[0], f[1]);
    if (!k || !k.startsWith("card:")) return false;
    if (isFree(k.slice(5))) { pick({ kind: "card", key: k.slice(5) }); startFrameEdit("move", ev); ev.preventDefault(); return true; }
    if (locked(rowOfCard(k.slice(5)))) return false;            // a locked row's cards don't move
    const D = { name: k.slice(5), x: ev.clientX, y: ev.clientY, moved: false, target: null };
    const host = el("typoVisHost");
    const move = (mv) => {
      if (!D.moved && Math.hypot(mv.clientX - D.x, mv.clientY - D.y) < 6) return;
      if (!D.moved) {
        D.moved = true;
        D.ghost = document.createElement("div");
        D.ghost.className = "ptc-ghost";
        D.ghost.textContent = "▦ " + D.name.toUpperCase();
        host.appendChild(D.ghost);
      }
      const hr = host.getBoundingClientRect();
      Object.assign(D.ghost.style, { left: (mv.clientX - hr.left + 12) + "px", top: (mv.clientY - hr.top + 12) + "px" });
      D.target = dropAt(frac(mv), D.name);
      S.drag = D;
      paintFrames();
    };
    const up = () => {
      document.removeEventListener("mousemove", move);
      document.removeEventListener("mouseup", up);
      if (D.ghost) D.ghost.remove();
      S.drag = null;
      if (!D.moved) return;
      S.noClick = true;                                     // the mouse-up after a drag picks nothing
      setTimeout(() => { S.noClick = false; }, 0);
      if (D.target) dropCard(D.name, D.target); else paintFrames();
    };
    document.addEventListener("mousemove", move);
    document.addEventListener("mouseup", up);
    ev.preventDefault();
    return true;
  }
  // where a dragged card would go: {row, before: name | null (the row's end)}
  function dropAt(f, self) {
    if (!f) return null;
    const card = Object.entries(blocks()).find(([k, b]) => k.startsWith("card:") && k.slice(5) !== self && f[0] >= b[0] && f[0] <= b[2] && f[1] >= b[1] && f[1] <= b[3]);
    if (card) {
      const name = card[0].slice(5), b = card[1], row = rowOfCard(name), list = rows()[row];
      const after = f[0] > (b[0] + b[2]) / 2;
      const rest = list.filter((n) => n !== self), i = rest.indexOf(name) + (after ? 1 : 0);
      return { row, before: rest[i] || null, at: name, after };
    }
    for (const row of ["high", "mid", "low"]) {
      const b = blocks()[row];
      if (b && f[0] >= b[0] - 0.02 && f[0] <= b[2] + 0.02 && f[1] >= b[1] - 0.03 && f[1] <= b[3] + 0.03) return { row, before: null };
    }
    return null;
  }
  function dropCard(name, target) {
    const r = rows(), from = rowOfCard(name);
    r[from] = r[from].filter((n) => n !== name);
    const list = r[target.row], i = target.before ? list.indexOf(target.before) : list.length;
    list.splice(i < 0 ? list.length : i, 0, name);
    const moved = members(name);
    edit((t) => {
      // the order of every card (a shared card's other symbols right after its first)
      t.card_order = [].concat(...[...r.high, ...r.mid, ...r.low].map((n) => (n === name ? moved : members(n)))).map((n) => n.toLowerCase());
      if (target.row !== from) {
        t.row_of = Object.assign({}, t.row_of || {});
        moved.forEach((n) => { t.row_of[n.toLowerCase()] = target.row; });
      }
    });
    toast(target.row !== from ? `${name.toUpperCase()} moved to the ${ROWNAME[target.row]} row.` : `${name.toUpperCase()} moved.`);
  }

  /* move / resize the picked text box, WILD / SCATTER box or row (✥ and the corner handle) — what the
     card studio's drags write: a text box's rect, a box's rect, a row's place (pos) and card size */
  // a box [x, y, w, h] pulled by its kind of handle ("n", "se", ...) by dx, dy: the opposite side stays
  function grow(x, y, w, h, dx, dy, min) {
    const k = startFrameEdit.kind === "size" ? "se" : startFrameEdit.kind;
    if (k.includes("e")) w = Math.max(min, w + dx);
    if (k.includes("w")) { const nw = Math.max(min, w - dx); x += w - nw; w = nw; }
    if (k.includes("s")) h = Math.max(min, h + dy);
    if (k.includes("n")) { const nh = Math.max(min, h - dy); y += h - nh; h = nh; }
    return [x, y, w, h];
  }
  function startFrameEdit(kind, ev) {
    if (selLocked()) { paintFrames(); toast("🔒 Locked — unlock it to move or size it."); return; }
    startFrameEdit.kind = kind;
    const k = selKey(), b0 = blocks()[k], c = el("typoVisCanvas");
    if (!b0 || !c) return;
    const cr = c.getBoundingClientRect(), D = { x: ev.clientX, y: ev.clientY, dx: 0, dy: 0 };
    const frame = document.querySelector(".ptc-f.on");
    const f0 = frame && { l: parseFloat(frame.style.left), t: parseFloat(frame.style.top), w: parseFloat(frame.style.width), h: parseFloat(frame.style.height) };
    // the part itself follows the mouse (every frame), not only its outline
    const set0 = itemsIn(b0), A = pxOf(b0), kpx = S.data.canvas_px.width / cr.width;
    const asPicture = S.sel.kind === "band" || S.sel.kind === "card" || S.sel.kind === "scard";
    const handles = [...document.querySelectorAll(".ptc-frames .ptc-h, .ptc-frames .ptc-rowh.on, .ptc-frames .ptc-tag")];
    S.dragLive = true;
    // where it starts (design px), taken now: the live drag redraws the part, and a text's frame (its words)
    // follows it — read at the drop it would already hold the drag, and the drop would add it twice
    // a text: moved, its box goes along; sized, its box is the frame as dragged (the words it shows, a
    // little room around them) — the text then fills it and re-wraps to its width
    const r0 = S.sel.kind === "text" ? (kind === "move" ? rawRectOf(k) : edgesFrom(rawRectOf(k), padRect(rectOf(k), 4, 0), kind)) : rectOf(k);
    const move = (mv) => {
      D.dx = mv.clientX - D.x; D.dy = mv.clientY - D.y;
      handles.forEach((h) => { h.style.visibility = "hidden"; });
      let B;
      if (kind === "move") B = [A[0] + D.dx * kpx, A[1] + D.dy * kpx, A[2], A[3]];
      else if (S.sel.kind === "scard" || (S.sel.kind === "band" && kind === "se")) { const f = Math.max(0.2, 1 + (D.dx + D.dy) * kpx / Math.max(1, A[2] + A[3])); B = [A[0], A[1], A[2] * f, A[3] * f]; }
      else B = grow(A[0], A[1], A[2], A[3], D.dx * kpx, D.dy * kpx, 20);
      liveSet(boxXf(set0, A, B, asPicture && kind !== "move"));
      if (!frame) return;
      Object.assign(frame.style, { left: (f0.l + (B[0] - A[0]) / kpx) + "px", top: (f0.t + (B[1] - A[1]) / kpx) + "px", width: B[2] / kpx + "px", height: B[3] / kpx + "px" });
    };
    const up = () => {
      document.removeEventListener("mousemove", move);
      document.removeEventListener("mouseup", up);
      if (Math.abs(D.dx) + Math.abs(D.dy) < 3) { liveEnd(false); paintFrames(); return; }
      liveEnd(true);
      const r = r0, dsg = (S.data && S.data.canvas) || { width: 1920, height: 1080, scale: 1 };
      const kx = dsg.width / dsg.scale / cr.width, ky = dsg.height / dsg.scale / cr.height;
      const dx = Math.round(D.dx * kx), dy = Math.round(D.dy * ky);
      const nr = kind === "move" ? [r[0] + dx, r[1] + dy, r[2], r[3]] : grow(r[0], r[1], r[2], r[3], dx, dy, 30).map(Math.round);
      edit((t) => {
        if (S.sel.kind === "scard") {                      // every SCATTER card bigger / smaller, its numbers too
          const f = Math.max(0.2, (nr[2] / Math.max(1, r[2]) + nr[3] / Math.max(1, r[3])) / 2);
          put(t, "scatter_section.card_w", Math.round(r[2] * f));
          put(t, "scatter_section.card_h", Math.round(r[3] * f));
          if (!Array.isArray(get("scatter_section.card.parts", t))) put(t, "scatter_section.card.parts", clone(scardParts()));
          get("scatter_section.card.parts", t).forEach((p) => { if (p.font_size) p.font_size = Math.max(6, Math.round(p.font_size * f * 10) / 10); });
        } else if (S.sel.kind === "card") {                // a card broken out of its row: its own place and size
          put(t, `card_overrides.${lc(S.sel.key)}.free`, nr);
        } else if (S.sel.kind === "text") {
          let i = (t.page.texts || []).findIndex((x) => String(x.id) === String(S.sel.key));
          if (i < 0) {                                       // the page's own rules text (no box of its own yet)
            const n = get("page.notes", t) || {};
            t.page.texts = (t.page.texts || []).concat([{ id: S.sel.key, font_size: n.font_size, color: n.color, align: n.align }]);
            i = t.page.texts.length - 1;
          }
          // out of its zone: placed by hand from now on (the zone gives its room back)
          (t.zones || []).forEach((z) => { z.items = (z.items || []).filter((it) => !(it.kind === "text" && String(it.id || "notes") === String(S.sel.key))); });
          t.zones = (t.zones || []).filter((z) => (z.items || []).length);
          t.page.texts[i].rect = nr;
          t.page.texts[i].fill_space = false;                 // placed by hand: it stays where it was put
          delete t.page.texts[i].grow_into;                   // …at its size (no longer grows over a missing box)
          delete t.page.texts[i].dock;                        // …and no longer docked to a side of the page
        } else if (S.sel.kind === "box") {
          const tab = tabH(t), bx = ((t.features = t.features || {})[`${S.sel.key}_box`] = t.features[`${S.sel.key}_box`] || {});
          bx.rect = [nr[0], nr[1] + tab / 2, nr[2], nr[3] - tab / 2];
        } else {
          const i = rowI(S.sel.key), band = t.bands[i];
          if (!band) return;
          band.pos = [nr[0], nr[1]];
          if (["n", "e", "s", "w"].includes(kind)) {
            // one edge: only that side of the row moves — its cards take the new room (gaps kept), what is
            // in them keeps its size
            const per = Math.max(1, across(i) || 1), lines = Math.max(1, rowLines(i));
            const gx = Number(band.gap_x ?? get("page.gap_x", t) ?? DEF.gap_x), gy = Number(band.gap_y ?? get("page.gap_y", t) ?? DEF.gap_y);
            const nw = "ew".includes(kind) ? Math.max(40, Math.round((nr[2] - (per - 1) * gx) / per)) : null;
            const nh = "ns".includes(kind) ? Math.max(30, Math.round((nr[3] - (lines - 1) * gy) / lines)) : null;
            resizeRow(t, i, nw, nh);
            if (band.lock_size) band.lock_size = [nr[2], nr[3]];
          } else if (kind !== "move") scaleRow(t, i, Math.max(0.2, (nr[2] / Math.max(1, r[2]) + nr[3] / Math.max(1, r[3])) / 2));   // the corner: the row as one picture
          else if (!band.card_w) {                           // moved: its cards keep the size they have now
            const g = (geoOf(i) || {}).size;
            if (g) { band.card_w = Math.round(g[0]); band.card_h = Math.round(g[1]); }
          }
        }
      });
    };
    document.addEventListener("mousemove", move);
    document.addEventListener("mouseup", up);
  }

  /* ------------------------------ lock ------------------------------ */
  function toDesign(fx, fy) {
    const c = (S.data && S.data.canvas) || { width: 1920, height: 1080, scale: 1 };
    const ox = (c.width - (Number(c.dw) || 1920) * c.scale) / 2, oy = (c.height - (Number(c.dh) || 1080) * c.scale) / 2;
    return [(fx * c.width - ox) / c.scale, (fy * c.height - oy) / c.scale];
  }
  // a block's own box on the page (design px) — not its frame (a text's frame is the words it draws)
  function rawRectOf(k) {
    const b = ((S.data || {}).blocks || {})[k];
    if (!b) return rectOf(k);
    const [x0, y0] = toDesign(b[0], b[1]), [x1, y1] = toDesign(b[2], b[3]);
    return [Math.round(x0), Math.round(y0), Math.round(x1 - x0), Math.round(y1 - y0)];
  }
  const padRect = (r, p, py = p) => (r ? [r[0] - p, r[1] - py, r[2] + 2 * p, r[3] + 2 * py] : r);
  // box r with the edges being dragged ("n", "se", …) where frame f has them; the other edges stay put
  function edgesFrom(r, f, kind) {
    if (!r || !f) return r || f;
    let [x0, y0, x1, y1] = [r[0], r[1], r[0] + r[2], r[1] + r[3]];
    if (kind.includes("w")) x0 = f[0];
    if (kind.includes("e")) x1 = f[0] + f[2];
    if (kind.includes("n")) y0 = f[1];
    if (kind.includes("s")) y1 = f[1] + f[3];
    return [x0, y0, Math.max(30, x1 - x0), Math.max(30, y1 - y0)];
  }
  function rectOf(k) {
    const b = blocks()[k];
    if (!b) return null;
    const [x0, y0] = toDesign(b[0], b[1]), [x1, y1] = toDesign(b[2], b[3]);
    return [Math.round(x0), Math.round(y0), Math.round(x1 - x0), Math.round(y1 - y0)];
  }
  function locked(k) {
    if (ROWS.includes(k)) { const b = get(`bands.${rowI(k)}`) || {}; return b.locked === true || (b.locked === undefined && !!b.lock_size); }
    if (k === "wild" || k === "scatter") return !!get(`features.${k}_box.locked`);
    const i = (get("page.texts") || []).findIndex((x) => "text:" + x.id === k);
    return i >= 0 && !!get(`page.texts.${i}.locked`);
  }
  // a locked row / card / box / text box can't be edited at all until it is unlocked
  function selLocked(sel = S.sel) {
    if (!sel) return false;
    if (sel.kind === "band") return locked(sel.key);
    if (sel.kind === "card") return !isFree(sel.key) && locked(rowOfCard(sel.key));
    if (sel.kind === "box") return locked(sel.key);
    if (sel.kind === "text") return locked("text:" + sel.key);
    return false;
  }
  const lockKeyOf = (sel) => (sel.kind === "band" || sel.kind === "box" ? sel.key : sel.kind === "card" ? rowOfCard(sel.key) : "text:" + sel.key);
  // locked: it stays exactly as it is and nothing in it can be edited. Unlocking changes nothing on the
  // page either: the row keeps its place and box, its cards their size, gaps and text sizes as drawn
  function toggleLock(k) {
    const lock = !locked(k), r = rectOf(k);
    edit((t) => {
      if (ROWS.includes(k)) {
        const i = rowI(k), b = t.bands[i];
        if (r) { b.pos = [r[0], r[1]]; b.lock_size = [r[2], r[3]]; }
        if (!lock) {                                   // the box's fit made the row's own: nothing moves or resizes
          const g = geoOf(i) || {}, f = Number(g.fit) || 1, r1 = (v) => Math.round(v * 10) / 10;
          if (g.size) { b.card_w = r1(g.size[0] * f); b.card_h = r1(g.size[1] * f); }
          if (Math.abs(f - 1) > 0.001) {
            const sc = (p) => { if (p.font_size) p.font_size = r1(p.font_size * f); if (p.line_height) p.line_height = Math.max(6, Math.round(p.line_height * f)); };
            b.parts = clone(g.parts && g.parts.length ? g.parts : rowParts(t, i)); b.parts.forEach(sc);
            b.gap_x = r1(Number(b.gap_x ?? get("page.gap_x", t) ?? 24) * f);
            b.gap_y = r1(Number(b.gap_y ?? get("page.gap_y", t) ?? 20) * f);
            Object.entries(t.card_overrides || {}).forEach(([nm, o]) => { if (o && Array.isArray(o.parts) && !o.free && rowOfCard(nm) === k) o.parts.forEach(sc); });
          }
        }
        b.locked = lock;
        if (!lock) delete b.lock_size;
      } else if (k === "wild" || k === "scatter") {
        const box = (t.features[`${k}_box`] = t.features[`${k}_box`] || {});
        const tab = Number((t.features || {}).tab_h || 0);
        if (r && !box.rect) box.rect = [r[0], r[1] + tab / 2, r[2], r[3] - tab / 2];
        box.locked = lock;
      } else {
        const i = (t.page.texts || []).findIndex((x) => "text:" + x.id === k);
        if (i < 0) return;
        if (r && !t.page.texts[i].rect) t.page.texts[i].rect = r;
        t.page.texts[i].locked = lock;
      }
    }, true);
    toast(lock ? "Locked — it stays exactly as it is and can't be edited until you unlock it." : "Unlocked — it stays as it is; edit it as you like.");
  }

  /* ------------------------------ copy / paste a look ------------------------------ */
  // the look a pick shows: a card's own (else its row's), a row's, a box's, the title's plate, a text box's
  // background (when it has one)
  function styleNameOf(sel, t) {
    if (!sel) return null;
    if (sel.kind === "card") return ((t.card_overrides || {})[lc(sel.key)] || {}).style || (t.bands[rowIdx(sel)] || {}).style || "card";
    if (sel.kind === "band") return (t.bands[rowIdx(sel)] || {}).style || "card";
    if (sel.kind === "box") return (t.features || {}).style || "feature";
    if (sel.kind === "title") return (t.page.title || {}).style || "plate";
    if (sel.kind === "text") {
      const x = ((t.page || {}).texts || []).find((y) => String(y.id) === String(sel.key)) || {};
      return x.bg && x.bg.on && x.bg.style ? x.bg.style : null;
    }
    return null;
  }
  const canPaste = (sel) => !!sel && ["card", "band", "box", "title", "text"].includes(sel.kind);
  const rowIdx = (sel) => rowI(sel.kind === "band" ? sel.key : rowOfCard(sel.key));
  function copyLook(sel) {
    const t = tpl() || {}, st = styleNameOf(sel || S.sel, t);
    if (!st) { toast((sel || S.sel || {}).kind === "text" ? "This text box has no background to copy — give it one (Background ▾) first." : "Pick a card, a row, a box, the title or a text box with a background to copy its look."); return; }
    const s = sel || S.sel, clip = { from: labelOf(s).replace(/^\W+/, ""), look: JSON.parse(JSON.stringify((t.styles || {})[st] || {})) };
    if (s.kind === "text") {                           // a text box's background: its panel / strip and padding too
      const x = (t.page.texts || []).find((y) => String(y.id) === String(s.key)) || {};
      clip.bg = { mode: (x.bg || {}).mode || "box", pad: (x.bg || {}).pad ?? 14 };
    }
    if (s.kind === "band") {
      const parts = (((S.data || {}).band_geo || {})[ROWS[rowIdx(s)]] || {}).parts || [];
      clip.numbers = {};
      ["counts", "pays"].forEach((role) => {
        const p = parts.find((x) => x.role === role);
        if (p) clip.numbers[role] = Object.fromEntries(["color", "font_size", "font", "bold", "italic"].filter((k) => p[k] != null).map((k) => [k, p[k]]));
      });
    }
    S.clip = clip;
    if (window.PshLook) PshLook.clip = { from: clip.from, look: clip.look, at: Date.now() };     // pasted on a text page's plate / strip too
    toast(`Copied the look of ${clip.from} — pick a card, a row, a box, the title or a text box (or a heading plate / row strip on a text page), then Paste (Ctrl+V).`);
    paint();
  }
  // paste: onto a card → that card only (or every Shift+picked card), its own look; a row → the row; a text
  // box → its background panel; a box / the title → its look
  function pasteLook(sel) {
    // the last look copied anywhere: here, or a text page's heading plate / row strip (window.PshLook)
    const g = window.PshLook && PshLook.clip;
    if (g && (!S.clip || g.look !== S.clip.look)) S.clip = { from: g.from, look: g.look };
    const s = sel || S.sel, c = S.clip;
    if (!c) { toast("Copy a look first (Ctrl+C on a card, row, box, the title or a text box's background)."); return; }
    if (!canPaste(s)) { toast("Pick a card, a row, a box, the title or a text box to paste onto."); return; }
    const look = () => JSON.parse(JSON.stringify(c.look));
    const cards = s.kind === "card" ? capCards(s.key) : [];
    edit((t) => {
      t.styles = t.styles || {};
      if (s.kind === "card") {
        cards.forEach((n) => {
          const key = lc(n), st = `card_${key.replace(/[^a-z0-9_]/g, "_")}`;
          t.styles[st] = look();
          ((t.card_overrides = t.card_overrides || {})[key] = t.card_overrides[key] || {}).style = st;
        });
        return;
      }
      if (s.kind === "text") {
        pinTexts(t);
        const x = t.page.texts[tIdx(t, s.key)];
        if (!x) return;
        const st = `textbg_${String(s.key).replace(/[^A-Za-z0-9_]/g, "_")}`;
        t.styles[st] = look();
        x.bg = Object.assign({ mode: "box", pad: 14 }, x.bg || {}, c.bg || {}, { on: true, style: st });
        return;
      }
      let st = styleNameOf(s, t);
      if (s.kind === "band") {
        st = rowStyle(t, rowIdx(s));
        if (c.numbers) rowParts(t, rowIdx(s)).forEach((p) => { if (c.numbers[p.role]) Object.assign(p, c.numbers[p.role]); });
      }
      t.styles[st] = look();
    });
    toast(`Pasted the look of ${c.from} onto ${cards.length > 1 ? `the ${cards.length} picked cards` : labelOf(s).replace(/^\W+/, "")}.`);
  }
  function onKey(ev) {
    if (!on() || !(ev.ctrlKey || ev.metaKey) || ev.shiftKey) return false;
    const k = ev.key.toLowerCase();
    if (k === "c" && S.sel) { copyLook(); return true; }
    if (k === "v" && S.sel && anyClip()) { pasteLook(); return true; }
    return false;
  }

  /* ------------------------------ right-click ------------------------------ */
  async function contextMenu(ev) {
    if (!on()) return false;
    ev.preventDefault();
    const f = frac(ev), k = f && blockAt(f[0], f[1]);
    document.querySelectorAll(".ptc-menu").forEach((n) => n.remove());
    if (k) pick(kindOf(k));
    const sel = S.sel, host = el("typoVisHost");
    let items = "";
    if (sel && sel.kind === "card") {
      await readPays();
      const r = rows()[rowOfCard(sel.key)], i = r.indexOf(sel.key), mine = members(sel.key);
      const near = [r[i - 1], r[i + 1]].filter(Boolean).filter((n) => members(n).length === 1 && mine.length === 1 && paysOf(n) && paysOf(n) === paysOf(sel.key));
      near.forEach((n) => { items += `<button data-m="share" data-with="${esc(n)}">Share a card with ${esc(n.toUpperCase())} <span class="tbs-key">same pays</span></button>`; });
      if (mine.length > 1) items += `<button data-m="unshare">Show ${esc(mine.map((m) => m.toUpperCase()).join(", "))} on their own cards</button>`;
      if (!near.length && mine.length === 1) items += `<button disabled>Share a card — no neighbour pays the same</button>`;
      items += `<div class="tsel-msep"></div>
        <button data-m="iso">${S.iso === sel.key ? "Back to editing the whole row" : `Edit only ${esc(sel.key.toUpperCase())} <span class="tbs-key">double-click</span>`}</button>
        <button data-m="${isFree(sel.key) ? "join" : "break"}">${isFree(sel.key) ? "Join its row again" : "Break out of its row (move / size freely)"}</button>
        <button data-m="pic">Change picture…</button><div class="tsel-msep"></div>`;
      items += `<button data-m="looks">🎴 Card look for ${capCards(sel.key).length > 1 ? `the ${capCards(sel.key).length} picked cards` : "this card"}…</button><div class="tsel-msep"></div>`;
      const picked = capCards(sel.key), hasCap = capShown(sel.key), g = get("card.kind_caption") || {};
      items += `<div class="vpm-head">Caption (e.g. OF A KIND)</div>
        <button data-m="capadd">${hasCap ? "Caption on" : "Add a caption to"} ${picked.length > 1 ? `the ${picked.length} picked cards` : `this card`}…</button>
        ${hasCap ? `<button data-m="caprm">Remove the caption from ${picked.length > 1 ? `the ${picked.length} picked cards` : "this card"}</button>` : ""}
        <button data-m="capall">${g.enabled && g.on === "all" ? "✓ " : ""}A caption on every card</button>
        <button data-m="capshared">${g.enabled && g.on !== "all" ? "✓ " : ""}A caption on every shared card</button>
        ${g.enabled ? `<button data-m="capnone">No caption on every card</button>` : ""}
        <div class="ts-hint" style="padding:2px 8px">Shift+click: pick more cards</div><div class="tsel-msep"></div>`;
    }
    if (sel && sel.kind === "text") {
      items += `<button data-m="tedit">Edit the text</button>`;
      texts().filter((x) => String(x.id) !== String(sel.key)).forEach((x) => { items += `<button data-m="merge" data-with="${esc(x.id)}">Merge into text box ${texts().indexOf(x) + 1}</button>`; });
      if ((get("page.texts") || []).length > 1) items += `<button data-m="tdel">Delete this text box</button>`;
      items += `<button data-m="lock">${locked(selKey()) ? "Unlock" : "Lock"} this text box</button><div class="tsel-msep"></div>`;
    }
    if (sel && sel.kind === "box" && !((S.data || {}).required_boxes || []).includes(sel.key)) items += `<button data-m="rmbox">Remove the ${esc(sel.key.toUpperCase())} box</button>`;
    if (!sel) items += `<button data-m="addtext">Add a text box</button><button data-m="savecopy">Save as my design…</button>`;
    if (sel && ["high", "mid", "low", "wild", "scatter"].includes(selKey())) items += `<button data-m="lock">${locked(selKey()) ? "Unlock" : "Lock"} ${esc(labelOf(sel).replace(/^\W+/, ""))}</button>`;
    if (sel && sel.kind === "text") {
      const hasBg = !!styleNameOf(sel, tpl() || {});
      items += `<button data-m="copy" ${hasBg ? "" : "disabled"} title="${hasBg ? "" : "This text box has no background"}">Copy background style <span class="tbs-key">Ctrl+C</span></button>
        <button data-m="paste" ${anyClip() ? "" : "disabled"}>Paste background style${anyClip() ? ` of ${esc(anyClip().from)}` : ""} <span class="tbs-key">Ctrl+V</span></button>`;
    } else if (sel && canPaste(sel)) {
      items += `<button data-m="copy">Copy look <span class="tbs-key">Ctrl+C</span></button>
        <button data-m="paste" ${anyClip() ? "" : "disabled"}>Paste look${anyClip() ? ` of ${esc(anyClip().from)}` : ""}${sel.kind === "card" ? (capCards(sel.key).length > 1 ? ` on the ${capCards(sel.key).length} picked cards` : " on this card") : ""} <span class="tbs-key">Ctrl+V</span></button>`;
    }
    if (!items) return true;
    const m = document.createElement("div");
    m.className = "tsel-menu ptc-menu";
    m.innerHTML = `<div class="vpm-head">${esc(labelOf(sel))}</div>${items}`;
    ["mousedown", "pointerdown", "click", "contextmenu"].forEach((ty) => m.addEventListener(ty, (e2) => e2.stopPropagation()));
    host.appendChild(m);
    const hr = host.getBoundingClientRect();
    m.style.left = Math.max(4, Math.min(host.clientWidth - m.offsetWidth - 4, ev.clientX - hr.left)) + "px";
    m.style.top = Math.max(4, Math.min(host.clientHeight - m.offsetHeight - 4, ev.clientY - hr.top)) + "px";
    setTimeout(() => document.addEventListener("mousedown", () => m.remove(), { once: true }), 0);
    m.querySelectorAll("[data-m]").forEach((b) => b.addEventListener("click", () => {
      m.remove();
      const a = b.dataset.m;
      if (a === "share") {
        const other = b.dataset.with, group = rows()[rowOfCard(sel.key)].filter((n) => n === other || n === sel.key);
        edit((t) => {
          const c = (t.card = t.card || {});
          c.shared = (c.shared || []).filter((g) => !g.some((x) => group.includes(String(x).toLowerCase()))).concat([group.map((n) => n.toLowerCase())]);
          c.unshared = (c.unshared || []).filter((x) => !group.includes(String(x).toLowerCase()));
        });
        toast(`${group.map((n) => n.toUpperCase()).join(" and ")} share one card now (they pay the same).`);
      } else if (a === "unshare") {
        const ms = members(sel.key).map((n) => n.toLowerCase());
        edit((t) => {
          const c = (t.card = t.card || {});
          c.shared = (c.shared || []).filter((g) => !g.some((x) => ms.includes(String(x).toLowerCase())));
          c.unshared = [...new Set((c.unshared || []).concat(ms))];
        });
      } else if (a === "looks") looksPop(null, "picked");
      else if (a === "capadd") captionPop(capCards(sel.key));
      else if (a === "caprm") { const ns = capCards(sel.key); edit((t) => ns.forEach((n) => { put(t, `card_overrides.${lc(n)}.caption.enabled`, false); })); }
      else if (a === "capall" || a === "capshared") {
        edit((t) => {
          put(t, "card.kind_caption", Object.assign({ text: "OF A KIND", font_size: 24, color: "#FFFFFF" }, get("card.kind_caption", t) || {}, { enabled: true, on: a === "capall" ? "all" : "shared" }));
          Object.values(t.card_overrides || {}).forEach((o) => { if (o && o.caption) delete o.caption.enabled; });   // every card follows
        });
        captionPop(null);
      } else if (a === "capnone") edit((t) => {
        put(t, "card.kind_caption.enabled", false);
        Object.values(t.card_overrides || {}).forEach((o) => { if (o && o.caption) delete o.caption.enabled; });
      });
      else if (a === "iso") { S.iso = S.iso === sel.key ? "" : sel.key; pick(sel); }
      else if (a === "break") edit((t) => breakOut(t, sel.key));
      else if (a === "join") edit((t) => joinRow(t, sel.key));
      else if (a === "pic") changePicture(sel.key);
      else if (a === "tedit") editText(sel.key);
      else if (a === "merge") mergeText(sel.key, b.dataset.with);
      else if (a === "tdel") deleteText(sel.key);
      else if (a === "rmbox") removeBox(sel.key);
      else if (a === "addtext") addTextBox();
      else if (a === "savecopy") saveAs();
      else if (a === "lock") toggleLock(selKey());
      else if (a === "copy") copyLook(sel);
      else if (a === "paste") pasteLook(sel);
    }));
    return true;
  }

  /* ============ the card studio's tools on the Canvas: a card's parts, gaps, margins, text, boxes ============ */
  const DEF = { top: 30, bottom: 30, left: 60, right: 60, gap_x: 24, gap_y: 20 };
  // the looks a new tile / panel starts from (card_templates.py DEFAULT_TILE_STYLE / DEFAULT_PANEL_STYLE)
  const DEFAULT_TILE = { radius: 14, fill_enabled: true, fill: "#1B1030", fill_opacity: 100, stroke: { enabled: true, width: 3, color: "#FFD23A", align: "inside" }, fx: "" };
  const DEFAULT_PANEL = { radius: 28, fill_enabled: true, fill: "#120A24", fill_opacity: 75, stroke: { enabled: true, width: 3, color: "#8A5CFF", align: "inside" }, fx: "" };
  const r3 = (v) => Math.round(v * 1000) / 1000;
  const lc = (n) => String(n || "").toLowerCase();
  const clone = (o) => JSON.parse(JSON.stringify(o));
  const cardRow = (name) => rowI(rowOfCard(name));
  const geoOf = (i) => ((S.data || {}).band_geo || {})[ROWS[i]] || null;
  const bandFit = (i) => Number((geoOf(i) || {}).fit) || Number((S.data || {}).fit) || 1;
  const tabH = (t) => (get("features.tab.enabled", t) !== false ? Number(get("features.tab_h", t) || 56) : 0);
  // screen px of the Canvas picture → canvas px (fonts) and → design px (the page-shaped design frame)
  function scales() {
    const c = el("typoVisCanvas"), d = (S.data && S.data.canvas) || { width: 1920, height: 1080, scale: 1 };
    const px = d.width / Math.max(1, c ? c.getBoundingClientRect().width : d.width);
    return { px, k: px / (Number(d.scale) || 1) };
  }
  // a drag on the Canvas: move(dx, dy) while dragging, up(dx, dy) once let go (nothing when barely moved)
  function dragOn(ev, move, up, live, tap) {
    ev.preventDefault(); ev.stopPropagation();
    if (selLocked()) { toast("🔒 Locked — unlock it to move or size it."); return; }
    const x0 = ev.clientX, y0 = ev.clientY;
    S.busy = true;
    if (live) S.dragLive = true;
    const mv = (e) => { move(e.clientX - x0, e.clientY - y0); if (live) live(e.clientX - x0, e.clientY - y0); };
    const done = (e) => {
      document.removeEventListener("mousemove", mv);
      document.removeEventListener("mouseup", done);
      S.busy = false;
      S.noClick = true;
      setTimeout(() => { S.noClick = false; }, 0);
      const dx = e.clientX - x0, dy = e.clientY - y0;
      if (Math.abs(dx) + Math.abs(dy) < 3) { if (live) liveEnd(false); paintFrames(); if (tap) tap(); return; }
      if (live) liveEnd(true);
      up(dx, dy);
    };
    document.addEventListener("mousemove", mv);
    document.addEventListener("mouseup", done);
  }
  const stopAll = (n) => ["mousedown", "pointerdown", "click", "dblclick"].forEach((ty) => n.addEventListener(ty, (e) => e.stopPropagation()));

  /* ---------- popovers: small panels under a bar button (the swatch list and fx menu open over them) ---------- */
  function closePop() { document.querySelectorAll(".ptc-pop").forEach((n) => n.remove()); }
  function popup(anchor, title, render, wire) {
    closePop();
    const pop = document.createElement("div");
    pop.className = "ptc-pop";
    document.body.appendChild(pop);
    const fill = () => {
      pop.innerHTML = `<div class="ptc-pop-h"><b>${esc(title)}</b><button data-popx title="Close (Esc)">✕</button></div>${render()}`;
      pop.querySelector("[data-popx]").addEventListener("click", closePop);
      wireK(pop, fill);
      if (wire) wire(pop, fill);
    };
    fill();
    const r = anchor.getBoundingClientRect();
    pop.style.top = Math.max(8, Math.min(window.innerHeight - pop.offsetHeight - 8, r.bottom + 6)) + "px";
    pop.style.left = Math.max(8, Math.min(window.innerWidth - pop.offsetWidth - 8, r.left - 8)) + "px";
    return pop;
  }
  // fields that write one template key: data-k (input / select / checkbox), data-kc (colour), data-kfx (layer style)
  const prow = (label, html, tip) => `<label class="ptc-prow" ${tip ? `title="${esc(tip)}"` : ""}><span>${esc(label)}</span>${html}</label>`;
  const kNum = (path, v, min, max, ph) => `<input type="number" class="ts-size ts-narrow" data-k="${path}" data-num min="${min}" max="${max}" value="${esc(v ?? "")}" placeholder="${esc(ph ?? "")}">`;
  const kRange = (path, v, min, max) => `<input type="range" data-k="${path}" data-num min="${min}" max="${max}" step="1" value="${esc(v ?? 0)}"><output>${esc(v ?? 0)}</output>`;
  const kBool = (path, v) => `<input type="checkbox" data-k="${path}" ${v ? "checked" : ""}>`;
  const kSel = (path, v, opts) => `<select class="ts-style" data-k="${path}">${opts.map(([o, l]) => `<option value="${esc(o)}" ${String(o) === String(v ?? "") ? "selected" : ""}>${esc(l)}</option>`).join("")}</select>`;
  const kCol = (path, v, title) => sw(`data-kc="${path}"`, v || "", title || "Colour");
  const kFx = (path, v) => fxBtn(`data-kfx="${path}"`, v || "", "Layer style");
  function kFont(path, v, none) {
    const fonts = (App.state.fonts || []).slice().sort((a, b) => String(a).localeCompare(String(b)));
    if (v && !fonts.includes(v)) fonts.unshift(v);
    return kSel(path, v || "", [["", none || "Default font"]].concat(fonts.map((f) => [f, f])));
  }
  // a text's look: size, colour, align, font, bold, italic, layer style
  function textFields(p, withAlign = true) {
    const x = get(p) || {};
    return `${prow("Size", kNum(`${p}.font_size`, x.font_size ? Math.round(x.font_size) : "", 6, 400))}
      ${prow("Colour", kCol(`${p}.color`, x.color || "#ffffff"))}
      ${withAlign ? prow("Align", kSel(`${p}.align`, x.align || "center", [["left", "Left"], ["center", "Centre"], ["right", "Right"]])) : ""}
      ${prow("Font", kFont(`${p}.font`, x.font))}
      ${prow("Bold", kBool(`${p}.bold`, !!x.bold))}${prow("Italic", kBool(`${p}.italic`, !!x.italic))}
      ${prow("Layer style", kFx(`${p}.fx`, x.fx))}`;
  }
  function wireK(root, again) {
    const after = () => { if (again) again(); };
    root.querySelectorAll("[data-k]").forEach((n) => {
      if (n.type === "range") n.addEventListener("input", () => { const o = n.nextElementSibling; if (o && o.tagName === "OUTPUT") o.textContent = n.value; });
      n.addEventListener("change", () => {
        let v = n.type === "checkbox" ? n.checked : n.value;
        if (n.dataset.num !== undefined) v = v === "" ? undefined : Number(v);
        else if (v === "") v = undefined;
        set(n.dataset.k, v);
        after();
      });
    });
    root.querySelectorAll("[data-kc]").forEach((b) => b.addEventListener("click", () => window.Swatches && Swatches.open(b, b.dataset.cur, (c) => {
      if (!c) return;
      const path = b.dataset.kc;
      edit((t) => {
        put(t, path, c);
        if (/\.fill$/.test(path)) {                           // a fill: on, and visible (a PSD's look can be 0% fill)
          const base = path.slice(0, -5);
          put(t, base + ".fill_enabled", true);
          if (!(Number(get(base + ".fill_opacity", t) ?? 100) > 4)) put(t, base + ".fill_opacity", 100);
        }
      });
      after();
    })));
    root.querySelectorAll("[data-kfx]").forEach((b) => b.addEventListener("click", (ev) => window.TypoStudio && TypoStudio.fxPicker(ev.currentTarget, get(b.dataset.kfx) || "", (name) => { set(b.dataset.kfx, name || ""); after(); }, "None")));
  }

  /* ---------- the picked card: its parts, as drawn ---------- */
  // a SCATTER card of the scatter section (picked as "scard"): every SCATTER card shares its parts
  const isScard = (name) => !!(S.sel && S.sel.kind === "scard" && S.sel.key === name);
  const blkOf = (name) => (isScard(name) ? "scard:" : "card:") + name;
  const scardParts = () => get("scatter_section.card.parts") || (S.data || {}).scatter_card_parts || [];
  const autoFree = (name) => ((S.data || {}).auto_free || []).includes(lc(name)) && !get(`card_overrides.${lc(name)}.in_row`);
  const isFree = (name) => !!get(`card_overrides.${lc(name)}.free`) || autoFree(name);
  // a card drawn from its own parts (edited on its own before, or out of its row): edits go to them —
  // its row's parts would change nothing on it
  const ownsParts = (name) => S.iso === name || isFree(name) || Array.isArray(get(`card_overrides.${lc(name)}.parts`));
  function sizeOf(name) {                         // the card's size (design px) its parts are fractions of
    if (isScard(name) || isFree(name)) { const r = rectOf(blkOf(name)); return r ? [r[2], r[3]] : [300, 150]; }
    return cardSize(cardRow(name));
  }
  function viewParts(name) {
    if (isScard(name)) return scardParts();
    const i = cardRow(name);
    if (ownsParts(name)) {
      const own = ((S.data || {}).card_geo || {})[lc(name)] || ((get("card_overrides") || {})[lc(name)] || {}).parts;
      if (own) return own;
    }
    return ((geoOf(i) || {}).parts) || get(`bands.${i}.parts`) || get("card.parts") || [];
  }
  // inside edit(): the parts the change goes to — this card's own copy ("Only this card") or its row's
  function ownParts(t, name, rowOnly) {
    if (isScard(name)) {
      if (!Array.isArray(get("scatter_section.card.parts", t))) put(t, "scatter_section.card.parts", clone(scardParts()));
      return get("scatter_section.card.parts", t);
    }
    if (ownsParts(name) && !rowOnly) {                     // only this card (isolated, its own design, or out of its row)
      const key = lc(name), ov = (t.card_overrides = t.card_overrides || {});
      ov[key] = ov[key] || {};
      if (!Array.isArray(ov[key].parts)) ov[key].parts = clone(viewParts(name));
      return ov[key].parts;
    }
    return rowParts(t, cardRow(name));
  }
  // inside edit(): every parts list a change to this card goes to. "Only this card", a card out of its row
  // and a SCATTER card: that card alone; a card in its row: the row and each of its cards with a design of
  // their own (they all change alike — else those cards stay as they were and the row seems stuck)
  function rowSets(t, i) {
    const sets = [rowParts(t, i)];
    Object.entries(t.card_overrides || {}).forEach(([n, o]) => {
      if (o && Array.isArray(o.parts) && !o.free && !autoFree(n) && blocks()["card:" + n] && cardRow(n) === i) sets.push(o.parts);
    });
    return sets;
  }
  const numSets = (t, i) => (String(i).startsWith("@") ? editSets(t, String(i).slice(1)) : rowSets(t, Number(i)));
  function editSets(t, name) {
    if (isScard(name) || S.iso === name || isFree(name)) return [ownParts(t, name)];
    return rowSets(t, cardRow(name));
  }
  function cardSize(i, t) {
    const g = geoOf(i);
    if (g && g.size) return [Math.round(g.size[0]), Math.round(g.size[1])];
    const b = (get("bands", t) || [])[i] || {};
    return [Number(b.card_w) || 300, Number(b.card_h) || 150];
  }
  const symSizes = () => get("card.symbol_size") || {};
  const symPct = (name) => { const z = symSizes(), v = name && z[name] != null ? z[name] : z["*"]; return Number.isFinite(Number(v)) ? Number(v) : 100; };
  // a card symbol's height in px (canvas px, as drawn): its own, else every symbol's, else as drawn now
  const symPxSet = (name) => { const z = get("card.symbol_px") || {}; return Number(name && z[name] != null ? z[name] : z["*"]) || 0; };
  function symPx(name) {
    const it = ((S.data || {}).items || []).find((x) => x.slot === `@slot.${name}`);
    return Math.round(symPxSet(name) || (it ? it.rect[3] : 0) || 100);
  }
  function setSymPx(name, v, all) {
    v = Math.max(8, Math.min(2000, Math.round(v)));
    edit((t) => {
      const c = (t.card = t.card || {});
      if (all) { c.symbol_px = { "*": v }; delete c.symbol_size; return; }
      c.symbol_px = Object.assign({}, c.symbol_px || {}, { [name]: v });
      if (c.symbol_size) delete c.symbol_size[name];
    });
  }
  // a drawn box (image fractions) as a box of the card (card fractions)
  function inCard(name, keys) {
    const c = blocks()[blkOf(name)], ds = keys.map((k) => (S.drawn || {})[k]).filter(Boolean);
    if (!c || !ds.length) return null;
    const cw = Math.max(1e-6, c[2] - c[0]), ch = Math.max(1e-6, c[3] - c[1]);
    const x0 = Math.min(...ds.map((d) => d[0])), y0 = Math.min(...ds.map((d) => d[1]));
    const x1 = Math.max(...ds.map((d) => d[2])), y1 = Math.max(...ds.map((d) => d[3]));
    return { x: (x0 - c[0]) / cw, y: (y0 - c[1]) / ch, w: (x1 - x0) / cw, h: (y1 - y0) / ch };
  }
  function numbersBox(parts) {
    const ps = parts.filter((p) => p.role === "counts" || p.role === "pays");
    if (!ps.length) return null;
    const x0 = Math.min(...ps.map((p) => +p.x || 0)), y0 = Math.min(...ps.map((p) => +p.y || 0));
    return { x: x0, y: y0, w: Math.max(...ps.map((p) => (+p.x || 0) + (+p.w || 0))) - x0, h: Math.max(...ps.map((p) => (+p.y || 0) + (+p.h || 0))) - y0 };
  }
  // the symbol's box as the card's part (the drawn picture, before its own size %)
  // a card's symbol pictures: one, or every symbol of a shared card (side by side in the symbol's box)
  const symKeys = (name) => (isScard(name) ? [name] : members(name)).map((m) => `@slot.${m}`);
  function symBox(name, p) {
    // a shared card: all its symbols together are the box (measured from the first only, each drag would
    // halve them — the layout splits the box between them again)
    const keys = symKeys(name), d = inCard(name, keys), c = blocks()[blkOf(name)], cv = (S.data && S.data.canvas) || { width: 1920, height: 1080 };
    const pic = ((S.data || {}).items || []).some((it) => keys.includes(it.slot) && it.icon);   // a <NAME> with no picture: its text isn't its box
    if (!d || !c || !pic) return { x: +p.x || 0, y: +p.y || 0, w: +p.w || 1, h: +p.h || 1 };
    const px = 2 / Math.max(1, cv.width * (c[2] - c[0])), py = 2 / Math.max(1, cv.height * (c[3] - c[1]));
    if (symPxSet(name)) return { x: +p.x || 0, y: +p.y || 0, w: +p.w || 1, h: +p.h || 1 };   // sized in px: its box stays the part's
    const own = symPct(name) / 100 || 1, w = (d.w + 2 * px) / own, h = (d.h + 2 * py) / own;
    return { x: d.x + d.w / 2 - w / 2, y: d.y + d.h / 2 - h / 2, w, h };
  }
  const lineH = (parts) => { const c = parts.find((p) => p.role === "counts") || parts.find((p) => p.role === "pays") || {}; return Math.round(Number(c.line_height) || Number(c.font_size || 30) * 1.25); };
  function cardOverlayHtml(name, at) {
    const parts = viewParts(name), pct = (v) => `${(v * 100).toFixed(3)}%`;
    const box = (r) => `left:${pct(+r.x || 0)};top:${pct(+r.y || 0)};width:${pct(+r.w || 1)};height:${pct(+r.h || 1)}`;
    const keys = symKeys(name), sp = parts.find((p) => p.role === "symbol"), pic = ((S.data || {}).items || []).some((it) => keys.includes(it.slot) && it.icon);
    const sym = sp ? ((pic && inCard(name, keys)) || sp) : null;
    const nb = numbersBox(parts) ? (inCard(name, [`@slot.${name}.pay`, `@slot.${name}.value`]) || numbersBox(parts)) : null;
    return `<div class="ptc-co ${S.iso === name ? "iso" : ""}" style="${at}">
      ${sym ? `<div class="ptc-cp sym" data-oh="sym-move" style="${box(sym)}" title="Drag: move the symbol"><div class="ptc-ch tr" data-oh="sym-scale" title="Drag: size the symbol (keeps its shape)">⤢</div></div>` : ""}
      ${nb ? `<div class="ptc-cp num" data-oh="num-move" style="${box(nb)}" title="Pays and values: drag to move">
        <div class="ptc-ch br" data-oh="num-scale" title="Drag: scale the pays and values together">⤡</div>
        <div class="ptc-ch r" data-oh="lh" title="Drag up / down: line height">↕</div>
        <div class="ptc-ch b" data-oh="gap" title="Drag left / right: space between counts and pays">↔</div></div>` : ""}
      ${S.iso === name || isScard(name) || isFree(name) ? "" : `<div class="ptc-ch cr" data-oh="cw" title="Card width (its content keeps its size)">↔</div><div class="ptc-ch cb" data-oh="ch" title="Card height">↕</div>`}
      ${dividerHandles(name)}</div>`;
  }
  function overlayDrag(kind, ev, h) {
    const ov = h.closest(".ptc-co");
    if (!ov) return;
    const target = kind.startsWith("sym") ? ov.querySelector(".ptc-cp.sym") : ["num-move", "num-scale", "gap", "lh"].includes(kind) ? ov.querySelector(".ptc-cp.num") : null;
    const t0 = target && { l: target.offsetLeft, t: target.offsetTop, w: target.offsetWidth, h: target.offsetHeight };
    const f = (dx, dy) => (kind === "num-scale" ? Math.max(0.2, 1 + (dx + dy) / Math.max(1, t0.w + t0.h)) : Math.max(0.15, 1 + (dx - dy) / Math.max(1, t0.w + t0.h)));
    // the symbol's box as it is now — read before the live drag moves what is drawn (else the move counts twice)
    const sp0 = kind.startsWith("sym") ? viewParts(S.sel.key).find((p) => p.role === "symbol") : null;
    const sb0 = sp0 ? symBox(S.sel.key, sp0) : null;
    // the numbers' gap as drawn now — the live drag moves what is drawn, so read it before (else on
    // release the room left looks like none and the gap snaps back)
    const gap0 = kind === "gap" ? numbersGap(S.sel.key) : null;
    dragOn(ev, (dx, dy) => {
      if (kind === "sym-move" || kind === "num-move") Object.assign(target.style, { left: `${t0.l + dx}px`, top: `${t0.t + dy}px` });
      else if (kind === "sym-scale") { const k = f(dx, dy); Object.assign(target.style, { width: `${t0.w * k}px`, height: `${t0.h * k}px`, top: `${t0.t + t0.h - t0.h * k}px` }); }
      else if (kind === "num-scale") { const k = f(dx, dy); Object.assign(target.style, { width: `${t0.w * k}px`, height: `${t0.h * k}px` }); }
      else if (kind === "gap" || kind === "cw") h.style.transform = `translateX(${dx}px)`;
      else h.style.transform = `translateY(${dy}px)`;
    }, (dx, dy) => commitOverlay(kind, dx, dy, ov, t0 ? f(dx, dy) : 1, sb0, gap0), (() => {
      // the symbol / the numbers themselves follow the mouse
      if (kind === "gap") return gapLive(S.sel.key);
      const name = S.sel.key, slots = kind.startsWith("sym") ? [`@slot.${name}`] : kind === "num-move" || kind === "num-scale" ? [`@slot.${name}.pay`, `@slot.${name}.value`] : null;
      if (!slots) return null;
      const set0 = new Set((S.data.items || []).filter((it) => slots.includes(it.slot) || (kind.startsWith("sym") && it.slot === `@slot.${name}.tile`)));
      if (!set0.size) return null;
      const xs = [...set0].map((it) => it.rect), A = [Math.min(...xs.map((r) => r[0])), Math.min(...xs.map((r) => r[1]))];
      A.push(Math.max(...xs.map((r) => r[0] + r[2])) - A[0], Math.max(...xs.map((r) => r[1] + r[3])) - A[1]);
      const kpx = S.data.canvas_px.width / el("typoVisCanvas").getBoundingClientRect().width;
      return (dx, dy) => {
        let B;
        if (kind.endsWith("move")) B = [A[0] + dx * kpx, A[1] + dy * kpx, A[2], A[3]];
        else { const k = t0 ? f(dx, dy) : 1; B = kind === "sym-scale" ? [A[0], A[1] + A[3] - A[3] * k, A[2] * k, A[3] * k] : [A[0], A[1], A[2] * k, A[3] * k]; }
        liveSet(boxXf(set0, A, B, kind === "num-scale"));
      };
    })(), kind === "sym-move" ? () => setPart("sym") : kind === "num-move" ? () => setPart("num") : null);
  }
  // the gap handle, live: on each card it changes, the left column of numbers moves left, the right one right
  function gapLive(name) {
    const names = isScard(name) || S.iso === name || isFree(name) ? [name]
      : Object.keys(blocks()).filter((k) => k.startsWith("card:")).map((k) => k.slice(5)).filter((n) => !isFree(n) && cardRow(n) === cardRow(name));
    const items = S.data.items || [], moves = new Map();
    names.forEach((n) => {
      const a = items.filter((it) => it.slot === `@slot.${n}.pay`), b = items.filter((it) => it.slot === `@slot.${n}.value`);
      if (!a.length || !b.length) return;
      const mx = (xs) => Math.min(...xs.map((it) => it.rect[0])), [L, R] = mx(a) <= mx(b) ? [a, b] : [b, a];
      const room = mx(R) - Math.max(...L.map((it) => it.rect[0] + it.rect[2]));   // their space now (px)
      L.forEach((it) => moves.set(it, [-1, room])); R.forEach((it) => moves.set(it, [1, room]));
    });
    if (!moves.size) return null;
    const kpx = S.data.canvas_px.width / el("typoVisCanvas").getBoundingClientRect().width;
    return (dx) => {
      liveSet((it) => {
        const m = moves.get(it);
        if (!m) return it;
        const d = Math.max(dx * kpx, -Math.max(0, m[1]));
        return Object.assign({}, it, { rect: [it.rect[0] + m[0] * d / 2, it.rect[1], it.rect[2], it.rect[3]] });
      });
    };
  }
  // the space between a card's two columns of numbers as drawn (a share of the card), and which is left
  function numbersGap(name) {
    const pa = inCard(name, [`@slot.${name}.pay`]), va = inCard(name, [`@slot.${name}.value`]);   // counts = the .pay slot
    if (!pa || !va) return null;
    const countsLeft = pa.x <= va.x;
    return { countsLeft, room: Math.max(0, countsLeft ? va.x - (pa.x + pa.w) : pa.x - (va.x + va.w)) };
  }
  function commitOverlay(kind, dx, dy, ov, f, sb0, gap0) {
    const name = S.sel.key, i = isScard(name) ? 0 : cardRow(name), vp = viewParts(name), sc = scales();
    const idx = (role) => vp.findIndex((p) => p.role === role), iS = idx("symbol"), iC = idx("counts"), iP = idx("pays");
    const fx = dx / Math.max(1, ov.clientWidth), fy = dy / Math.max(1, ov.clientHeight);
    const design = (d) => d * sc.k / bandFit(i);
    const [w, h] = sizeOf(name);
    edit((t) => {
      if (kind === "sym-scale" && symPxSet(name)) {
        const c = (t.card = t.card || {});
        c.symbol_px = Object.assign({}, c.symbol_px || {}, { [name]: Math.max(8, Math.round(symPx(name) * f)) });
        return;
      }
      const mine = kind === "cw" || kind === "ch" ? null : ownParts(t, name);
      // the gap: the space between the two columns of numbers as drawn when the drag began (a share of the card)
      const g0 = gap0 || (kind === "gap" ? numbersGap(name) : null);
      const room = g0 ? g0.room : 1;
      if (mine) editSets(t, name).forEach((ps) => {
        // this card's parts start from what is drawn; the row's other cards take the same change
        const own = ps === mine, at = (role) => ps.findIndex((p) => p.role === role);
        const jS = at("symbol"), jC = at("counts"), jP = at("pays");
        // kept on its card: its middle never leaves it (a big box may still reach past the card's edge)
        const cl = (v, sz) => Math.min(1 - sz / 2, Math.max(-sz / 2, v));
        const shift = (j, ddx, ddy) => { const p = ps[j]; if (p) { p.x = r3(cl((+p.x || 0) + ddx, +p.w || 1)); p.y = r3(cl((+p.y || 0) + ddy, +p.h || 1)); } };
        if (kind === "sym-move") { const p = ps[jS]; if (p) { if (own) Object.assign(p, sb0 || symBox(name, p)); shift(jS, fx, fy); } }
        else if (kind === "num-move") { shift(jC, fx, fy); shift(jP, fx, fy); }
        else if (kind === "sym-scale") {
          const p = ps[jS];
          if (!p) return;
          const b = own ? sb0 || symBox(name, p) : { x: +p.x || 0, y: +p.y || 0, w: +p.w || 1, h: +p.h || 1 }, bottom = b.y + b.h;
          p.w = r3(Math.max(0.05, b.w * f)); p.h = r3(Math.max(0.05, b.h * f)); p.x = r3(b.x); p.y = r3(bottom - p.h);
        } else if (kind === "num-scale") {
          const nums = [ps[jC], ps[jP]].filter(Boolean);
          if (!nums.length) return;
          const gx = Math.min(...nums.map((p) => +p.x || 0)), gy = Math.min(...nums.map((p) => +p.y || 0));
          nums.forEach((p) => {
            p.x = r3(gx + ((+p.x || 0) - gx) * f); p.y = r3(gy + ((+p.y || 0) - gy) * f);
            p.w = r3((+p.w || 1) * f); p.h = r3((+p.h || 1) * f);
            p.font_size = Math.max(6, Math.round((Number(p.font_size) || 30) * f * 10) / 10);
            if (p.line_height) p.line_height = Math.max(6, Math.round(p.line_height * f));
          });
        } else if (kind === "gap") {
          const c = ps[jC], p = ps[jP];
          if (!c || !p) return;
          if (c.align === "right" && (p.align || "left") === "left") {
            // counts end at their box's right side, pays start at their box's left side: the gap is the
            // space between those two edges — the same on every card whatever its numbers, never below
            // nothing (else the columns cross and swap sides), both moving about their middle
            const cR = (+c.x || 0) + (+c.w || 1), g = Math.max(0, (+p.x || 0) - cR + fx), mid = ((+p.x || 0) + cR) / 2;
            c.x = r3(mid - g / 2 - (+c.w || 1)); p.x = r3(mid + g / 2);
            return;
          }
          // which column is on the left: where its numbers are drawn on this card (counts = the .pay
          // slot), not its box's left side — a right-aligned box starts far left of its numbers, so after
          // a big stretch the boxes' order and the numbers' order differ and the gap could never close again
          const countsLeft = g0 ? g0.countsLeft : (+c.x || 0) <= (+p.x || 0);
          const [L, R] = countsLeft ? [c, p] : [p, c];
          const d = Math.max(fx, -room);                 // closer: until the numbers drawn touch
          L.x = r3((+L.x || 0) - d / 2); R.x = r3((+R.x || 0) + d / 2);
        }
        else if (kind === "lh") { const v = Math.max(10, Math.round(lineH(vp) + dy * sc.px)); [jC, jP].forEach((j) => { if (ps[j]) ps[j].line_height = v; }); }
      });
      else {
        const band = t.bands[i], rr = rectOf(ROWS[i]);
        if (band && rr && !band.pos) band.pos = [rr[0], rr[1]];          // pinned where it starts: only its right / bottom moves
        if (kind === "cw") resizeRow(t, i, Math.max(60, Math.round(w + design(dx))), null);
        else resizeRow(t, i, null, Math.max(40, Math.round(h + design(dy))));
        if (band && band.lock_size) {
          const per = Math.max(1, across(i) || 1), lines = Math.max(1, rowLines(i));
          const gx = Number(band.gap_x ?? get("page.gap_x", t) ?? DEF.gap_x), gy = Number(band.gap_y ?? get("page.gap_y", t) ?? DEF.gap_y);
          band.lock_size = [Math.round(per * band.card_w + (per - 1) * gx), Math.round(lines * band.card_h + (lines - 1) * gy)];
        }
      }
    });
  }
  // a row's cards wider / taller; what is inside them keeps its size, centred
  function rowLines(i) {
    const ys = new Set(Object.entries(blocks()).filter(([k]) => k.startsWith("card:") && !isFree(k.slice(5)) && cardRow(k.slice(5)) === i).map(([, b]) => Math.round(b[1] * 1000)));
    return ys.size;
  }
  function resizeRow(t, i, nw, nh) {
    const [w, h] = cardSize(i, t), b = t.bands[i];
    if (!b) return;
    const keep = (ps) => ps.forEach((p) => {
      if (nw != null) { p.w = r3((+p.w || 1) * w / nw); p.x = r3(((+p.x || 0) * w + (nw - w) / 2) / nw); }
      if (nh != null) { p.h = r3((+p.h || 1) * h / nh); p.y = r3(((+p.y || 0) * h + (nh - h) / 2) / nh); }
    });
    keep(rowParts(t, i));
    Object.entries(t.card_overrides || {}).forEach(([n, o]) => { if (o && o.parts && !o.free && blocks()["card:" + n] && cardRow(n) === i) keep(o.parts); });
    if (nw != null) b.card_w = nw;
    if (nh != null) b.card_h = nh;
  }
  // the row as one picture × f: card size, the numbers' fonts and the spacing together
  function scaleRow(t, i, f) {
    const b = t.bands[i], [w, h] = cardSize(i, t);
    if (!b) return;
    const fonts = (p) => {
      if (p.font_size) p.font_size = Math.max(4, Math.round(Number(p.font_size) * f * 10) / 10);
      if (p.line_height) p.line_height = Math.max(4, Math.round(Number(p.line_height) * f));
    };
    rowParts(t, i).forEach(fonts);
    Object.entries(t.card_overrides || {}).forEach(([n, o]) => { if (o && o.parts && !o.free && blocks()["card:" + n] && cardRow(n) === i) o.parts.forEach(fonts); });
    b.card_w = Math.max(30, Math.round(w * f));
    b.card_h = Math.max(20, Math.round(h * f));
    ["gap_x", "gap_y"].forEach((g) => { b[g] = Math.max(0, Math.round(Number(b[g] ?? get(`page.${g}`, t) ?? DEF[g]) * f)); });
    delete b.lock_size;
  }
  // the symbol and the numbers together, to an edge or the middle of the card
  function alignParts(how) {
    const name = S.sel.key, parts = viewParts(name);
    if (!parts.length) return;
    // what is drawn on the card (part boxes can reach past the text in them)
    const d = inCard(name, [`@slot.${name}`, `@slot.${name}.pay`, `@slot.${name}.value`]);
    const x0 = d ? d.x : Math.min(...parts.map((p) => +p.x || 0)), x1 = d ? d.x + d.w : Math.max(...parts.map((p) => (+p.x || 0) + (+p.w || 1)));
    const y0 = d ? d.y : Math.min(...parts.map((p) => +p.y || 0)), y1 = d ? d.y + d.h : Math.max(...parts.map((p) => (+p.y || 0) + (+p.h || 1)));
    const m = 0.04;
    const dx = { left: m - x0, hcenter: 0.5 - (x0 + x1) / 2, right: 1 - m - x1 }[how] || 0;
    const dy = { top: m - y0, vcenter: 0.5 - (y0 + y1) / 2, bottom: 1 - m - y1 }[how] || 0;
    edit((t) => editSets(t, name).forEach((ps) => ps.forEach((p) => { p.x = r3((+p.x || 0) + dx); p.y = r3((+p.y || 0) + dy); })));
  }
  // the numbers left / right of the symbol or under it; sizes kept, the pair centred on the card
  // the numbers left of / right of / under the symbol. A card picked: every card of its row (cards with
  // a design of their own too); "Only this card" or a card out of its row: that card alone; a row: its cards
  function arrangeNumbers(where, card, row) {
    const sel = S.sel || {};
    const one = row != null ? null : card || ((sel.kind === "card" && (S.iso === sel.key || isFree(sel.key))) || sel.kind === "scard" ? sel.key : null);
    const i = row != null ? row : sel.kind === "band" ? rowI(sel.key) : cardRow(card || sel.key);
    const names = one ? [one] : Object.keys(blocks()).filter((k) => k.startsWith("card:")).map((k) => k.slice(5))
      .filter((n) => !isFree(n) && cardRow(n) === i);
    if (!names.length) return;
    if (!one) { arrangeRow(where, i, names); return; }
    let n = 0;
    edit((t) => { if (arrangeParts(one, ownParts(t, one), where)) n++; });
    if (n) toast(where === "below" ? "Numbers under the symbol." : `Numbers on the ${where}.`);
  }
  // a whole row: its cards take the size the new arrangement needs (taller and narrower with the numbers
  // under the symbol, wider beside it) and every card the same places — the numbers start at the same x
  // on each card, sized for the row's widest numbers and biggest symbol
  function arrangeRow(where, i, names) {
    const [W, H] = cardSize(i);
    const m = names.map((name) => {
      const vp = viewParts(name), sym = vp.find((p) => p.role === "symbol");
      const nd = inCard(name, [`@slot.${name}.pay`, `@slot.${name}.value`]);
      if (!sym || !nd) return null;
      const sb = symBox(name, sym);
      return { name, s: { w: sb.w * W, h: sb.h * H }, n: { x: nd.x * W, y: nd.y * H, w: nd.w * W, h: nd.h * H } };
    }).filter(Boolean);
    if (!m.length) return;
    const Sw = Math.max(...m.map((c) => c.s.w)), Sh = Math.max(...m.map((c) => c.s.h));
    const ref = m.reduce((a, c) => (c.n.w > a.n.w ? c : a)), Nw = ref.n.w, Nh = Math.max(...m.map((c) => c.n.h));
    const gap = Math.max(10, Math.min(W, H) * 0.06), pad = gap;
    let nw, nh, sx, sy, nx, ny;
    if (where === "below") {
      nw = Math.max(Sw, Nw) + 2 * pad; nh = pad + Sh + gap + Nh + pad;
      sx = (nw - Sw) / 2; sy = pad; nx = (nw - Nw) / 2; ny = pad + Sh + gap;
    } else {
      nw = pad + Sw + gap + Nw + pad; nh = Math.max(Sh, Nh) + 2 * pad;
      sy = (nh - Sh) / 2; ny = (nh - Nh) / 2;
      if (where === "left") { nx = pad; sx = pad + Nw + gap; } else { sx = pad; nx = pad + Sw + gap; }
    }
    nw = Math.round(nw); nh = Math.round(nh);
    edit((t) => {
      const band = t.bands[i];
      if (!band) return;
      // the numbers' parts: the widest card's, moved so its drawn numbers start at (nx, ny)
      const refParts = clone(ownParts(t, ref.name)), dx = nx - ref.n.x, dy = ny - ref.n.y;
      const place = (ps) => ps.forEach((p) => {
        if (p.role === "symbol") Object.assign(p, { x: r3(sx / nw), y: r3(sy / nh), w: r3(Sw / nw), h: r3(Sh / nh) });
        else if (p.role === "counts" || p.role === "pays") {
          const q = refParts.find((x) => x.role === p.role) || p;
          Object.assign(p, { x: r3(((+q.x || 0) * W + dx) / nw), y: r3(((+q.y || 0) * H + dy) / nh), w: r3((+q.w || 1) * W / nw), h: r3((+q.h || 1) * H / nh) });
        }
      });
      const done = new Set();
      names.forEach((name) => { const ps = ownParts(t, name); if (!done.has(ps)) { done.add(ps); place(ps); } });
      band.card_w = nw;
      band.card_h = nh;
      if (band.lock_size) {
        const per = Math.max(1, across(i) || 1), lines = Math.max(1, rowLines(i));
        const gx = Number(band.gap_x ?? get("page.gap_x", t) ?? DEF.gap_x), gy = Number(band.gap_y ?? get("page.gap_y", t) ?? DEF.gap_y);
        band.lock_size = [Math.round(per * nw + (per - 1) * gx), Math.round(lines * nh + (lines - 1) * gy)];
      }
    });
    toast((where === "below" ? "Numbers under the symbol" : `Numbers on the ${where}`) + ` — the cards ${nw} × ${nh} px to fit.`);
  }
  function arrangeParts(name, ps, where) {
    const [W, H] = sizeOf(name);
    const sym = ps.find((p) => p.role === "symbol"), nums = ps.filter((p) => p.role === "counts" || p.role === "pays");
    if (!sym || !nums.length) return false;
    const sb = symBox(name, sym), s = { x: sb.x * W, y: sb.y * H, w: sb.w * W, h: sb.h * H };
    // the numbers as drawn (their boxes can be far bigger than the text in them)
    const nd = inCard(name, [`@slot.${name}.pay`, `@slot.${name}.value`]);
    const n0 = nd ? { x: nd.x * W, y: nd.y * H } : { x: Math.min(...nums.map((p) => p.x * W)), y: Math.min(...nums.map((p) => p.y * H)) };
    const n = nd ? { w: nd.w * W, h: nd.h * H } : { w: Math.max(...nums.map((p) => (p.x + p.w) * W)) - n0.x, h: Math.max(...nums.map((p) => (p.y + p.h) * H)) - n0.y };
    const gap = Math.max(8, W * 0.04);
    let sx, sy, nx, ny;
    if (where === "below") { const y0 = (H - (s.h + gap + n.h)) / 2; sx = (W - s.w) / 2; sy = y0; nx = (W - n.w) / 2; ny = y0 + s.h + gap; }
    else {
      const x0 = (W - (s.w + gap + n.w)) / 2;
      sy = (H - s.h) / 2; ny = (H - n.h) / 2;
      if (where === "left") { nx = x0; sx = x0 + n.w + gap; } else { sx = x0; nx = x0 + s.w + gap; }
    }
    Object.assign(sym, { x: r3(sx / W), y: r3(sy / H), w: r3(s.w / W), h: r3(s.h / H) });
    nums.forEach((p) => { p.x = r3((p.x * W - n0.x + nx) / W); p.y = r3((p.y * H - n0.y + ny) / H); });
    return true;
  }
  // the counts and pays of a row (or of one card): font, bold, italic, colours, line height
  function numbersPop(anchor) {
    const name = S.sel.kind === "card" || S.sel.kind === "scard" ? S.sel.key : null, i = name ? (isScard(name) ? 0 : cardRow(name)) : (rowI(S.sel.key));
    const parts = () => (name ? viewParts(name) : ((geoOf(i) || {}).parts || get(`bands.${i}.parts`) || get("card.parts") || []));
    const write = (fn) => edit((t) => (name ? editSets(t, name) : rowSets(t, i)).flat().forEach((p) => { if (p.role === "counts" || p.role === "pays") fn(p); }));
    return popup(anchor, name && isScard(name) ? "Pays & values — SCATTER cards" : name && S.iso === name ? `Pays & values — only ${name.toUpperCase()}` : `Pays & values — ${ROWS[i]} cards`, () => {
      const ps = parts(), c = ps.find((p) => p.role === "counts") || {}, y = ps.find((p) => p.role === "pays") || {};
      const fontSel = (role, p) => `<select class="ts-style" data-nf="${role}">${[["", "Default font"]].concat((App.state.fonts || []).slice().sort().map((f) => [f, f])).map(([o, l]) => `<option value="${esc(o)}" ${o === (p.font || "") ? "selected" : ""}>${esc(l)}</option>`).join("")}</select>`;
      return `${prow("Counts font", fontSel("counts", c), "The font of the counts (5 4 3)")}
        ${prow("Counts bold", `<input type="checkbox" data-nb="counts|bold" ${c.bold ? "checked" : ""}>`)}${prow("Counts italic", `<input type="checkbox" data-nb="counts|italic" ${c.italic ? "checked" : ""}>`)}
        ${prow("Pays font", fontSel("pays", y), "The font of the pays (1500 750 …)")}
        ${prow("Pays bold", `<input type="checkbox" data-nb="pays|bold" ${y.bold ? "checked" : ""}>`)}${prow("Pays italic", `<input type="checkbox" data-nb="pays|italic" ${y.italic ? "checked" : ""}>`)}
        ${prow("Size", `<input type="number" class="ts-size ts-narrow" data-nz value="${Math.round(c.font_size || 30)}" min="6" max="300">`)}
        ${prow("Counts colour", sw('data-nc="counts"', c.color || "#ffffff", "Counts colour"))}${prow("Pays colour", sw('data-nc="pays"', y.color || "#ffffff", "Pays colour"))}
        ${prow("Line height", `<input type="number" class="ts-size ts-narrow" data-nl value="${lineH(ps)}" min="6" max="400">`)}
        <div class="ptc-note">On the card: drag ↕ for line height, ↔ for the space between counts and pays, the corner to scale them.</div>`;
    }, (pop, again) => {
      pop.querySelectorAll("[data-nf]").forEach((n) => n.addEventListener("change", (e) => {
        write((p) => { if (p.role !== n.dataset.nf) return; if (e.target.value) p.font = e.target.value; else delete p.font; }); again();
      }));
      pop.querySelector("[data-nz]").addEventListener("change", (e) => { const v = Math.max(6, Number(e.target.value) || 30); write((p) => { p.font_size = v; }); again(); });
      pop.querySelector("[data-nl]").addEventListener("change", (e) => { const v = Math.max(6, Number(e.target.value) || 0); write((p) => { p.line_height = v; }); again(); });
      pop.querySelectorAll("[data-nb]").forEach((n) => n.addEventListener("change", () => {
        const [role, k] = n.dataset.nb.split("|");
        write((p) => { if (p.role === role) p[k] = n.checked; }); again();
      }));
      pop.querySelectorAll("[data-nc]").forEach((n) => n.addEventListener("click", () => window.Swatches && Swatches.open(n, n.dataset.cur, (col) => {
        if (!col) return;
        edit((t) => (name ? ownParts(t, name) : rowParts(t, i)).forEach((p) => { if (p.role === n.dataset.nc) p.color = col; }));
        again();
      })));
    });
  }
  function symbolPop(anchor) {
    const name = S.sel.key;
    return popup(anchor, "Symbol height", () => {
      const px = symPx(name), own = (get("card.symbol_px") || {})[name] != null;
      return `<div class="ptc-note"><b>${esc(name.toUpperCase())}</b>${own ? "" : " (as every symbol)"}</div>
        ${prow("Height", `<input type="number" class="ts-size ts-narrow" data-ss min="8" max="2000" value="${px}"><span class="ts-unit">px</span>`)}
        <button class="ts-tgt" data-ssall>Every symbol ${px} px</button>
        ${Object.keys(get("card.symbol_px") || {}).length || Object.keys(symSizes()).length ? `<button class="ts-tgt" data-ssreset>Every symbol as the card is designed</button>` : ""}`;
    }, (pop, again) => {
      const r = pop.querySelector("[data-ss]");
      r.addEventListener("change", () => { setSymPx(name, Number(r.value) || symPx(name)); again(); });
      pop.querySelector("[data-ssall]").addEventListener("click", () => { setSymPx(name, symPx(name), true); toast("Every symbol is this height now."); again(); });
      pop.querySelector("[data-ssreset]")?.addEventListener("click", () => { edit((t) => { delete (t.card || {}).symbol_size; delete (t.card || {}).symbol_px; }); again(); });
    });
  }

  /* ---------- gaps between cards and rows, the page margins, the title plate's width ---------- */
  function guttersHtml(i, off) {
    const lines = [];
    Object.entries(blocks()).filter(([k]) => k.startsWith("card:") && cardRow(k.slice(5)) === i).map(([, b]) => b)
      .sort((a, b) => a[1] - b[1] || a[0] - b[0]).forEach((b) => {
        const l = lines.find((x) => Math.abs(x.y0 - b[1]) < 0.01);
        if (l) { l.cards.push(b); l.y1 = Math.max(l.y1, b[3]); } else lines.push({ y0: b[1], y1: b[3], cards: [b] });
      });
    let html = "";
    const at = (fx, fy, which, tip) => { html += `<button class="ptc-gut" data-gut="${which}" style="left:${off.x(fx)}px;top:${off.y(fy)}px" title="${tip}">${which === "x" ? "↔" : "↕"}</button>`; };
    lines.forEach((l) => {
      l.cards.sort((a, b) => a[0] - b[0]);
      for (let j = 1; j < l.cards.length; j++) at((l.cards[j - 1][2] + l.cards[j][0]) / 2, (l.y0 + l.y1) / 2, "x", "Drag left / right: space between the cards (this row)");
    });
    lines.sort((a, b) => a.y0 - b.y0);
    for (let j = 1; j < lines.length; j++) at((lines[j].cards[0][0] + lines[j].cards.at(-1)[2]) / 2, (lines[j - 1].y1 + lines[j].y0) / 2, "y", "Drag up / down: space between the lines of cards (this row)");
    const hi = blocks().high, lo = blocks().low;
    if (hi && lo) at((Math.max(hi[0], lo[0]) + Math.min(hi[2], lo[2])) / 2, (hi[3] + lo[1]) / 2, "band", "Drag up / down: the gap between the rows (and around the page's parts)");
    return html;
  }
  function gutterDrag(which, ev, h) {
    const i = rowI(S.sel.key), sc = scales();
    dragOn(ev, (dx, dy) => { h.style.transform = which === "x" ? `translateX(${dx}px)` : `translateY(${dy}px)`; }, (dx, dy) => {
      const d = (which === "x" ? dx : dy) * sc.k / bandFit(i);
      edit((t) => {
        if (which === "band") { put(t, "page.band_gap", Math.max(0, Math.round(Number(get("page.band_gap", t) ?? get("page.gap_y", t) ?? DEF.gap_y) + d))); return; }
        const pk = which === "x" ? "gap_x" : "gap_y", b = t.bands[i];
        if (b) b[pk] = Math.max(0, Math.round(Number(b[pk] ?? get(`page.${pk}`, t) ?? DEF[pk]) + d));
      });
    });
  }
  function marginDrag(side, ev, h) {
    const sc = scales();
    dragOn(ev, (dx, dy) => { h.style.transform = side === "left" || side === "right" ? `translateX(${dx}px)` : `translateY(${dy}px)`; }, (dx, dy) => {
      const delta = { top: dy, bottom: -dy, left: dx, right: -dx }[side] * sc.k;
      edit((t) => {
        const v = Math.max(0, Math.round(Number(get(`page.${side}`, t) ?? DEF[side]) + delta));
        if (side === "left" || side === "right") { put(t, "page.left", v); put(t, "page.right", v); } else put(t, `page.${side}`, v);
      });
    });
  }
  // the space under the title (design px): its own, else the rows' gap (= card_templates)
  function titleGapPx() {
    const own = get("page.title.gap");
    if (own != null && own !== "") return Number(own) || 0;
    const gy = get("page.gap_y");
    return Number(get("page.band_gap") ?? (gy != null ? gy : 20)) || 0;
  }
  // ✥: the title anywhere on the page (page.title dx / dy, design px)
  function titleMove(ev, h) {
    const sc = scales();
    dragOn(ev, (dx, dy) => { h.style.transform = `translate(${dx}px, ${dy}px)`; }, (dx, dy) => {
      edit((t) => {
        put(t, "page.title.dx", Math.round(Number(get("page.title.dx", t) || 0) + dx * sc.k));
        put(t, "page.title.dy", Math.round(Number(get("page.title.dy", t) || 0) + dy * sc.k));
      });
    });
  }
  // a title guide: its top margin (moves the title up / down) or the gap under it to the cards
  function titleGuide(kind, ev, g) {
    const sc = scales();
    dragOn(ev, (dx, dy) => { g.style.transform = `translateY(${dy}px)`; }, (dx, dy) => {
      edit((t) => {
        if (kind === "top") put(t, "page.title.dy", Math.round(Number(get("page.title.dy", t) || 0) + dy * sc.k));
        else put(t, "page.title.gap", Math.round(titleGapPx() + dy * sc.k));      // may go below 0: the cards overlap it
      });
    });
  }
  // the title's plate: each handle moves its own edge, as far as it is dragged — any width or height, a
  // side inside the text too. Kept as the plate's margin on each side of the title's text
  // (page.title.plate_pads, design px), so it stays with the title when its words change; "Fit to text"
  // makes it hug the text again
  function titleDrag(side, ev, h) {
    const sc = scales(), tall = side === "t" || side === "b";
    dragOn(ev, (dx, dy) => { h.style.transform = tall ? `translateY(${dy}px)` : `translateX(${dx}px)`; }, (dx, dy) => {
      const it = ((S.data || {}).items || []).find((x) => x.slot === "@slot.title");
      const d = Number(((S.data || {}).canvas || {}).scale) || 1;
      if (!it || !it.plate_rect || !it.text_rect) { toast("The title's plate isn't drawn yet — try again in a moment."); return; }
      const [px, py, pw, ph] = it.plate_rect.map((v) => v / d), [tx, ty, tw, th] = it.text_rect.map((v) => v / d);
      // the title stays in the middle of its plate: the margin dragged on one side is the other side's too
      let mx = ((tx - px) + (px + pw - tx - tw)) / 2, my = ((ty - py) + (py + ph - ty - th)) / 2;
      if (side === "l") mx = Math.max(2 - tw / 2, tx - (px + dx * sc.k));
      if (side === "r") mx = Math.max(2 - tw / 2, px + pw + dx * sc.k - tx - tw);
      if (side === "t") my = Math.max(1 - th / 2, ty - (py + dy * sc.k));
      if (side === "b") my = Math.max(1 - th / 2, py + ph + dy * sc.k - ty - th);
      const pads = [mx, my, mx, my].map((v) => Math.round(v));
      const l = tx - mx, t0 = ty - my, r = tx + tw + mx, b = ty + th + my;
      edit((t) => put(t, "page.title.plate_pads", pads));
      toast(`The title's plate: ${Math.round(r - l)} × ${Math.round(b - t0)} px — “Fit to text” makes it hug the title again.`);
    });
  }

  /* ---------- a WILD / SCATTER box's own parts (symbol, numbers, heading, caption, text, panel): move / size them on the box ---------- */
  const BOXPART = { symbol: "the symbol", counts: "the counts", pays: "the pays", title: "the heading", label: "the caption", text: "the text", panel: "the panel" };
  function boxParts(b) { return get(`features.${b}_parts`) || ((S.data || {}).feature_parts || {})[b] || {}; }
  function wildParts() { return boxParts("wild"); }
  function boxFrac(b) {
    const r = blocks()[b];
    if (!r) return null;
    const c = (S.data && S.data.canvas) || { height: 1080, scale: 1 };
    return [r[0], r[1] + (tabH() / 2) * (Number(c.scale) || 1) / (Number(c.height) || 1080), r[2], r[3]];
  }
  function boxOverlayHtml(off, b) {
    const B = boxFrac(b), parts = boxParts(b);
    if (!B || Object.keys(blocks()).some((k) => k.startsWith("scard:")) && b === "scatter") return "";
    const W = B[2] - B[0], H = B[3] - B[1], pct = (v) => `${(v * 100).toFixed(3)}%`;
    const fr = (p) => `left:${pct(+p.x || 0)};top:${pct(+p.y || 0)};width:${pct(+p.w || 1)};height:${pct(+p.h || 1)}`;
    const order = ["panel", "title", "label", "text", "counts", "pays", "symbol"].filter((k) => parts[k] && typeof parts[k] === "object");
    return `<div class="ptc-co box" style="left:${off.x(B[0])}px;top:${off.y(B[1])}px;width:${off.w(W)}px;height:${off.h(H)}px">
      ${order.map((k) => `<div class="ptc-cp ${k === "symbol" ? "sym" : k === "panel" ? "pnl" : "num"}" data-fh="move:${k}" style="${fr(parts[k])}" title="Drag: move ${BOXPART[k]}">
        ${k === "symbol" ? `<div class="ptc-ch tr" data-fh="scale:${k}" title="Drag: size the symbol">⤢</div>` : `<div class="ptc-ch br" data-fh="size:${k}" title="Drag: the size of ${BOXPART[k]}">⤡</div>`}</div>`).join("")}</div>`;
  }
  function wildDrag(kind, ev, h) {
    const ov = h.closest(".ptc-co"), target = h.closest(".ptc-cp"), b = (S.sel || {}).key;
    if (!ov || !target || !b) return;
    const [mode, key] = kind.split(":");
    const t0 = { l: target.offsetLeft, t: target.offsetTop, w: target.offsetWidth, h: target.offsetHeight };
    const symF = (dx, dy) => Math.max(0.15, 1 + (dx - dy) / Math.max(1, t0.w + t0.h));
    // a click (no drag) on the heading / caption / text picks it: font, colour, layer style, typing
    const slotOf = { title: `@slot.${b === "wild" ? "wildbox" : "scatbox"}.title`, label: `@slot.${b === "wild" ? "wildbox" : "scatbox"}.label`, text: "@slot.wildbox.text" }[key];
    if (mode === "move" && slotOf) {
      const x0 = ev.clientX, y0 = ev.clientY;
      document.addEventListener("mouseup", (e) => { if (Math.abs(e.clientX - x0) + Math.abs(e.clientY - y0) < 3) pick({ kind: "btext", key: slotOf }); }, { once: true });
    }
    dragOn(ev, (dx, dy) => {
      if (mode === "move") Object.assign(target.style, { left: `${t0.l + dx}px`, top: `${t0.t + dy}px` });
      else if (mode === "scale") { const f = symF(dx, dy); Object.assign(target.style, { width: `${t0.w * f}px`, height: `${t0.h * f}px`, top: `${t0.t + t0.h - t0.h * f}px` }); }
      else Object.assign(target.style, { width: `${Math.max(20, t0.w + dx)}px`, height: `${Math.max(16, t0.h + dy)}px` });
    }, (dx, dy) => edit((t) => {
      if (!get(`features.${b}_parts`, t)) put(t, `features.${b}_parts`, clone(boxParts(b)));
      const p = get(`features.${b}_parts.${key}`, t);
      if (!p) return;
      const fx = dx / Math.max(1, ov.clientWidth), fy = dy / Math.max(1, ov.clientHeight);
      const cl = (v, sz) => Math.min(1 - sz / 2, Math.max(-sz / 2, v));   // kept on the box: its middle never leaves it
      if (mode === "move") { p.x = r3(cl((+p.x || 0) + fx, +p.w || 1)); p.y = r3(cl((+p.y || 0) + fy, +p.h || 1)); }
      else if (mode === "scale") { const f = symF(dx, dy), h1 = Math.max(0.05, (+p.h || 1) * f); p.y = r3((+p.y || 0) + (+p.h || 1) - h1); p.w = r3(Math.max(0.05, (+p.w || 1) * f)); p.h = r3(h1); }
      else { p.w = r3(Math.max(0.05, (+p.w || 1) + fx)); p.h = r3(Math.max(0.05, (+p.h || 1) + fy)); }
    }));
  }
  function removeBox(b) {
    if (((S.data || {}).required_boxes || []).includes(b)) { toast(`This sheet has a ${b.toUpperCase()} symbol with its own pays, so it keeps its box.`); return; }
    const zz = zoneOfBlock(b);
    S.sel = null;
    if (zz) { set(`zones.${zz.zi}.items.${zz.ii}.show`, "never"); return; }        // in a zone: its rule says never
    const other = b === "wild" ? "scatter" : "wild";
    edit((t) => { put(t, `features.${b}`, false); if (get(`features.${other}`, t) === false) put(t, "features.enabled", false); });
  }
  // the icons in a text (WILD text or a text box): leave one out, size them (everywhere / here only)
  const iconKey = (tk) => String(tk || "").replace(/[<>]/g, "").trim().toUpperCase();
  function iconsPop(anchor, boxPath, tokens, hidden, hidePath, title) {
    return popup(anchor, title, () => {
      const glob = get("text_icon_px") || {}, own = get(`${boxPath}.icon_px`) || {}, hid = (get(hidePath) || hidden || []).map((h) => String(h).toUpperCase());
      const slot = boxPath === "features.wild_box" ? "@slot.wildbox.text" : ((texts().find((x) => `page.texts.${tIdx(null, x.id)}` === boxPath) || {}).slot || "");
      return `<div class="ptc-toks">${tokens.map((tk) => { const off = hid.includes(String(tk).toUpperCase());
          return `<button class="ts-tgt ${off ? "" : "on"}" data-tok="${esc(tk)}" title="${off ? "Left out — click to show" : "Click to leave this icon out (its comma or “and” goes with it)"}">${off ? "⊘ " : ""}${esc(tk)}</button>`; }).join("")}</div>
        <div class="ptc-note">Heights (px, as drawn) apply to that icon in every paytable text unless “here only” is ticked — other pages never change.</div>
        ${tokens.map((tk) => { const k = iconKey(tk), only = own[k] != null, v = Math.round(Number(only ? own[k] : glob[k]) || iconPx(slot, tk));
          return `<div class="ptc-isz"><span>${esc(tk)}</span><input type="number" class="ts-size ts-narrow" min="4" max="1000" value="${v}" data-isz="${esc(k)}"><span class="ts-unit">px</span>
            <label title="Only in this box"><input type="checkbox" data-iszonly="${esc(k)}" ${only ? "checked" : ""}> here only</label></div>`; }).join("")}
        ${prow("Every icon here", `<input type="number" class="ts-size ts-narrow" min="4" max="1000" data-iall value="${Math.round(Number(own["*"]) || (tokens[0] ? iconPx(slot, tokens[0]) : 40))}"><span class="ts-unit">px</span>`)}`;
    }, (pop, again) => {
      pop.querySelectorAll("[data-tok]").forEach((b) => b.addEventListener("click", () => {
        edit((t) => {
          if (hidePath.startsWith("page.texts")) pinTexts(t);
          const hide = (get(hidePath, t) || hidden || []).slice(), j = hide.findIndex((h) => String(h).toUpperCase() === b.dataset.tok.toUpperCase());
          if (j >= 0) hide.splice(j, 1); else hide.push(b.dataset.tok);
          put(t, hidePath, hide);
        });
        again();
      }));
      const pin = (t) => { if (boxPath.startsWith("page.texts")) pinTexts(t); };
      pop.querySelectorAll("[data-isz]").forEach((r) => r.addEventListener("change", () => {
        const k = r.dataset.isz, v = Math.max(4, Math.round(Number(r.value) || 0)), only = pop.querySelector(`[data-iszonly="${CSS.escape(k)}"]`).checked;
        if (!v) return;
        edit((t) => {
          pin(t);
          put(t, `${boxPath}.icon_scale.${k}`, undefined);
          if (only) put(t, `${boxPath}.icon_px.${k}`, v); else { put(t, `text_icon_px.${k}`, v); put(t, `text_icon_scale.${k}`, undefined); put(t, `${boxPath}.icon_px.${k}`, undefined); }
        });
      }));
      pop.querySelectorAll("[data-iszonly]").forEach((c) => c.addEventListener("change", () => {
        const k = c.dataset.iszonly, v = Number(pop.querySelector(`[data-isz="${CSS.escape(k)}"]`).value) || 40;
        edit((t) => { pin(t); put(t, `${boxPath}.icon_scale.${k}`, undefined); put(t, `${boxPath}.icon_px.${k}`, c.checked ? v : undefined); });
        again();
      }));
      pop.querySelector("[data-iall]")?.addEventListener("change", (e) => {
        const v = Math.max(4, Math.round(Number(e.target.value) || 0));
        if (!v) return;
        edit((t) => { pin(t); put(t, `${boxPath}.icon_scale`, undefined); put(t, `${boxPath}.icon_px`, Object.fromEntries(tokens.map((tk) => [iconKey(tk), v]).concat([["*", v]]))); });
        again();
      });
    });
  }

  /* ---------- text boxes: typed like a document, merged, deleted, given a background ---------- */
  const texts = () => (S.data || {}).texts || [];
  const textOf = (id) => ((texts().find((x) => String(x.id) === String(id)) || {}).text) || "";
  const tIdx = (t, id) => (get("page.texts", t) || []).findIndex((x) => String(x.id) === String(id));
  // the boxes the design has none of yet get their own entries (where they are drawn), so they can be edited
  function pinTexts(t) {
    if ((get("page.texts", t) || []).length || !texts().length) return;
    const notes = get("page.notes", t) || {};
    put(t, "page.texts", texts().map((x, i) => ({ id: x.id, rect: rectOf(`text:${x.id}`), rest: i === 0,
      ...(i === 0 ? { font_size: notes.font_size, color: notes.color, align: notes.align, fill_space: true } : {}) })));
  }
  // every box's text, edited for THIS Excel text (another market's text keeps its own edits)
  function saveTexts(change) {
    edit((t) => {
      pinTexts(t);
      const h = ((S.data || {}).text_info || {}).hash || "none", all = Object.assign({}, get("page.text_edits", t) || {});
      const mine = Object.assign({}, all[h] || Object.fromEntries(texts().map((x) => [String(x.id), x.text || ""])));
      change(mine, t);
      all[h] = mine;
      put(t, "page.text_edits", all);
    });
  }
  function resetTexts() {
    const h = ((S.data || {}).text_info || {}).hash || "none";
    edit((t) => { const all = Object.assign({}, get("page.text_edits", t) || {}); delete all[h]; put(t, "page.text_edits", all); });
    toast("Back to the Excel text — all of it is in the first text box.");
  }
  function newBoxRect(t, fromId) {
    const r = ((get("page.texts", t) || [])[tIdx(t, fromId)] || {}).rect || rectOf("text:" + fromId) || [100, 300, 600, 120];
    let y = r[1] + r[3] + 20;
    if (y + 120 > 1060) y = Math.max(20, r[1] - 140);
    return [r[0], Math.round(y), Math.round(Math.min(r[2], 700)), 120];
  }
  function addTextBox() {
    edit((t) => {
      pinTexts(t);
      const list = get("page.texts", t) || [];
      list.push({ id: `t${Date.now() % 100000}`, rect: [120, 300, 500, 120], color: "#FFFFFF", align: "left" });
      put(t, "page.texts", list);
      put(t, "page.notes.enabled", true);
    });
    toast("New text box — drag ✥ to place it, then ✎ Edit text to type in it, or move text into it.");
  }
  function mergeText(id, into) {
    saveTexts((mine, t) => {
      const list = get("page.texts", t), a = list[tIdx(t, into)], b = list[tIdx(t, id)];
      if (!a || !b) return;
      mine[into] = [mine[into] ?? textOf(into), mine[id] ?? textOf(id)].filter((x) => x && x.trim()).join("\n");
      if (a.rect && b.rect && !a.fill_space) {               // a box that fills the free space keeps doing so
        const x0 = Math.min(a.rect[0], b.rect[0]), y0 = Math.min(a.rect[1], b.rect[1]);
        a.rect = [x0, y0, Math.max(a.rect[0] + a.rect[2], b.rect[0] + b.rect[2]) - x0, Math.max(a.rect[1] + a.rect[3], b.rect[1] + b.rect[3]) - y0];
      }
      delete mine[id];
      list.splice(tIdx(t, id), 1);
    });
    S.sel = { kind: "text", key: into };
    toast("Text boxes merged.");
  }
  function deleteText(id) {
    saveTexts((mine, t) => {
      const list = get("page.texts", t), first = String((list[0] || {}).id);
      if (first !== String(id)) mine[first] = [mine[first] ?? textOf(first), mine[id] ?? textOf(id)].filter((x) => x && x.trim()).join("\n");
      delete mine[id];
      list.splice(tIdx(t, id), 1);
    });
    S.sel = null;
    toast("Text box removed — its text went to the first box.");
  }
  function closeTextEditor() {
    document.querySelectorAll(".ptc-ted, .ptc-ied, .ptc-ied-tip").forEach((n) => n.remove());
    const was = S.tedSlot;
    S.ted = "";
    S.tedSlot = "";
    if (was) draw();                                          // the text back on the page
  }
  function menuAt(ev, items) {
    document.querySelectorAll(".ptc-menu").forEach((n) => n.remove());
    const host = el("typoVisHost"), m = document.createElement("div");
    m.className = "tsel-menu ptc-menu";
    m.innerHTML = items.map((it, n) => (it ? `<button data-mi="${n}" ${it.off ? "disabled" : ""}>${esc(it.label)}</button>` : `<div class="tsel-msep"></div>`)).join("");
    ["mousedown", "pointerdown", "click", "contextmenu"].forEach((ty) => m.addEventListener(ty, (e2) => e2.stopPropagation()));
    host.appendChild(m);
    const hr = host.getBoundingClientRect();
    m.style.left = Math.max(4, Math.min(host.clientWidth - m.offsetWidth - 4, ev.clientX - hr.left)) + "px";
    m.style.top = Math.max(4, Math.min(host.clientHeight - m.offsetHeight - 4, ev.clientY - hr.top)) + "px";
    setTimeout(() => document.addEventListener("mousedown", () => m.remove(), { once: true }), 0);
    m.querySelectorAll("[data-mi]").forEach((b) => b.addEventListener("click", () => { m.remove(); items[Number(b.dataset.mi)].run(); }));
  }
  function textBgPop(anchor, id) {
    return popup(anchor, "Text background", () => {
      const i = tIdx(null, id), bg = get(`page.texts.${i}.bg`) || {};
      return `${prow("Background", `<input type="checkbox" data-tbg ${bg.on ? "checked" : ""}>`)}
        ${bg.on ? `${prow("Shape", `<span class="tbs-seg"><button class="${(bg.mode || "box") === "box" ? "on" : ""}" data-tbgm="box">Around the box</button><button class="${bg.mode === "strip" ? "on" : ""}" data-tbgm="strip">Strip across</button></span>`)}
          ${prow("Padding", kRange(`page.texts.${i}.bg.pad`, bg.pad ?? 14, 0, 80))}
          ${lookFields(bg.style)}` : ""}`;
    }, (pop, again) => {
      pop.querySelector("[data-tbg]").addEventListener("change", (e) => {
        edit((t) => {
          pinTexts(t);
          const x = t.page.texts[tIdx(t, id)], name = `textbg_${String(id).replace(/[^A-Za-z0-9_]/g, "_")}`;
          if (!x) return;
          if (!get(`styles.${name}`, t)) put(t, `styles.${name}`, { radius: 16, fill_enabled: true, fill: "#0B1230", fill_opacity: 70, stroke: { enabled: false, width: 3, color: "#FFD23A", align: "inside" }, fx: "" });
          x.bg = Object.assign({ mode: "box", pad: 14 }, x.bg || {}, { on: e.target.checked, style: name });
        });
        again();
      });
      pop.querySelectorAll("[data-tbgm]").forEach((b) => b.addEventListener("click", () => { edit((t) => put(t, `page.texts.${tIdx(t, id)}.bg.mode`, b.dataset.tbgm)); again(); }));
    });
  }
  // a style's look as popover fields (fill, opacity, corners, border, layer style)
  function lookFields(st) {
    const p = `styles.${st}`, s = get(p) || {}, k = s.stroke || {};
    const gOn = s.gradient_dir ? s.gradient_dir !== "none" : !!s.fill_to;     // a gradient: pick its direction, then its colour
    return `${prow("Fill", `${kBool(`${p}.fill_enabled`, s.fill_enabled !== false)} ${kCol(`${p}.fill`, s.fill || "#333333", "Fill")}`)}
      ${prow("Opacity", kRange(`${p}.fill_opacity`, s.fill_opacity ?? 100, 0, 100))}
      ${prow("Gradient", `${kSel(`${p}.gradient_dir`, gOn ? s.gradient_dir || "vertical" : "none", [["none", "None (flat)"]].concat(GRAD_DIRS))} ${gOn ? kCol(`${p}.fill_to`, s.fill_to || "", "Fades into this colour") : ""}`, "The fill fades into a second colour")}
      ${prow("Corners", kNum(`${p}.radius`, s.radius === "pill" ? 999 : s.radius ?? 0, 0, 999))}
      ${prow("Border", `${kBool(`${p}.stroke.enabled`, !!k.enabled)} ${kCol(`${p}.stroke.color`, k.color || "#ffffff", "Border colour")} ${kNum(`${p}.stroke.width`, k.width ?? 2, 0, 40)}`)}
      ${prow("Layer style", kFx(`${p}.fx`, s.fx))}
      ${s.fx ? prow("Style on", kSel(`${p}.fx_on`, s.fx_on || "", [["", "All of it"], ["fill", "Fill only"], ["stroke", "Stroke only"]])) : ""}`;
  }

  /* ---------- Customise card / WILD box / SCATTER box: its parts on a big card ---------- */
  const ROLE = { symbol: "Symbol", counts: "Counts (5 4 3)", pays: "Pays (150 50 8)", text: "Text", title: "Heading (from the Excel)", label: "Caption (“pay any”)" };
  const M = { kind: "", sel: 0, row: 0 };
  function custPath() {
    if (M.kind === "card" && M.card) return `card_overrides.${lc(M.card)}.parts`;
    if (M.kind === "scard") return "scatter_section.card.parts";
    if (M.kind !== "card") return `features.${M.kind}_parts`;
    return Array.isArray(get(`bands.${M.row}.parts`)) ? `bands.${M.row}.parts` : "card.parts";
  }
  function custParts() {
    const d = get(custPath()) || (M.kind === "card" ? [] : {});
    return Array.isArray(d) ? d.map((p, i) => ({ obj: p, id: i, label: p.role === "text" ? (p.label || "Text") : ROLE[p.role] || p.role }))
      : Object.keys(d).map((k) => ({ obj: d[k], id: k, label: M.kind === "wild" && k === "text" ? "Wild text" : ROLE[k] || k }));
  }
  function openCustomise(kind, row, card) {
    Object.assign(M, { kind, sel: 0, row: row || 0, card: card || "" });
    if (kind === "card" && card && !Array.isArray(get(`card_overrides.${lc(card)}.parts`))) {
      // its own parts from now on (as it is drawn): what is added or moved here is on this card only
      edit((t) => put(t, `card_overrides.${lc(card)}.parts`, clone(viewParts(card))));
    }
    if (kind === "scard") {
      if (!get("scatter_section.card.parts")) edit((t) => put(t, "scatter_section.card.parts", clone(scardParts())));
    } else if (kind !== "card") {
      // the parts the box really holds (incl. the sheet's heading / caption) become the design's own
      const real = ((S.data || {}).feature_parts || {})[kind] || {}, have = get(`features.${kind}_parts`) || {};
      if (Object.keys(real).some((p) => !have[p])) edit((t) => put(t, `features.${kind}_parts`, Object.assign({}, clone(real), have)));
    }
    paintCustomise();
  }
  function paintCustomise() {
    document.getElementById("ptcCust")?.remove();
    if (!M.kind) return;
    const parts = custParts(), sel = parts[M.sel] || parts[0];
    const look = M.kind === "card" ? ((get(`bands.${M.row}`) || {}).style || "card") : M.kind === "scard" ? (get("scatter_section.card.style") || "card") : (get("features.style") || "feature");
    const st = get(`styles.${look}`) || {}, radius = String(st.radius) === "pill" ? "999px" : `${Math.round(Number(st.radius) || 0) / 2}px`;
    const scardKey = Object.keys(blocks()).find((k2) => k2.startsWith("scard:"));
    const ratio = M.kind === "card" ? (() => { const [w, h] = M.card ? sizeOf(M.card) : cardSize(M.row); return w / Math.max(1, h); })()
      : (() => { const r = rectOf(M.kind === "scard" ? scardKey : M.kind); return r ? r[2] / Math.max(1, r[3]) : 2; })();
    const path = sel ? `${custPath()}.${sel.id}` : "", role = sel ? (sel.obj.role || sel.id) : "";
    const ov = document.createElement("div");
    ov.className = "gm-overlay pce-ov";
    ov.id = "ptcCust";
    ov.innerHTML = `<div class="gm-dialog pce"><div class="gm-dhead"><b>${M.kind === "card" && M.card ? `Customise ${esc(String(M.card).toUpperCase())} — this card only` : M.kind === "card" ? `Customise card — ${ROWNAME[ROWS[M.row]]} cards` : M.kind === "scard" ? "Customise SCATTER cards" : M.kind === "wild" ? "Customise WILD box" : "Customise SCATTER box"}</b><button class="gm-x" data-cx>✕</button></div>
      <div class="gm-dbody">
        ${M.kind === "card" && !M.card && (get("bands") || []).length > 1 ? `<div class="tbs-seg">${(get("bands") || []).slice(0, 3).map((_b, i) => `<button class="${M.row === i ? "on" : ""}" data-crow="${i}">${ROWNAME[ROWS[i]]} cards</button>`).join("")}</div>` : ""}
        <div class="pce-card" id="ptcCustCard" style="aspect-ratio:${ratio.toFixed(3)};background:${esc(st.fill || "#333")};border-radius:${radius};${(st.stroke || {}).enabled ? `border:3px solid ${esc(st.stroke.color)}` : ""}">
          ${parts.map((p, i) => `<div class="pce-part ${esc(p.obj.role || p.id)} ${p === sel ? "sel" : ""}" data-pi="${i}" style="left:${p.obj.x * 100}%;top:${p.obj.y * 100}%;width:${p.obj.w * 100}%;height:${p.obj.h * 100}%"><span>${esc(p.label)}</span><i class="pce-rs" data-rs="1"></i></div>`).join("")}
        </div>
        ${parts.length ? "" : `<div class="ptc-note">This box has no parts of its own in this design (it shows the sheet's ${esc(M.kind.toUpperCase())} cards) — style it with the Box bar.</div>`}
        <div class="ptc-note">Drag a part to move it, its corner to size it. ${M.kind === "card" && M.card ? "Only this card changes — its row stays as it is." : `Every ${M.kind === "card" ? ROWNAME[ROWS[M.row]] + " card" : "page's box"} follows.`}</div>
        ${sel && role !== "symbol" ? `<div class="pce-props ptc-props">${textFields(path)}
          ${role === "text" && M.kind === "card" ? `${prow("Text", `<input type="text" data-k="${path}.text" value="${esc(sel.obj.text || "")}" placeholder="typed text">`)}
            ${prow("…or Excel cell", `<input type="text" data-k="${path}.source" value="${esc(sel.obj.source || "")}" placeholder="e.g. B54">`)}
            <button class="ts-tgt" data-cdel="${sel.id}">Remove this text</button>` : ""}</div>` : ""}
      </div>
      <div class="gm-dfoot">${M.kind === "card" ? `<button class="btn secondary" data-cadd>+ Add text</button>` : ""}<span style="flex:1"></span><button class="btn primary" data-cx>Done</button></div></div>`;
    document.body.appendChild(ov);
    wireK(ov, paintCustomise);
    const close = () => { M.kind = ""; ov.remove(); };
    ov.querySelectorAll("[data-cx]").forEach((b) => b.addEventListener("click", close));
    // a click outside never closes it (what was typed in it would be lost): its ✕ or Cancel do
    ov.querySelectorAll("[data-crow]").forEach((b) => b.addEventListener("click", () => { M.row = Number(b.dataset.crow); M.sel = 0; paintCustomise(); }));
    ov.querySelector("[data-cadd]")?.addEventListener("click", () => {
      const p = custPath();
      edit((t) => {
        const list = get(p, t) || [];
        const n = list.filter((x) => x.role === "text").length + 1;
        list.push({ role: "text", id: `t${n}`, label: `Text ${n}`, x: 0.05, y: 0.78, w: 0.9, h: 0.18, text: "Text", source: "", font_size: 22, color: "#FFFFFF", align: "center", valign: "center" });
        put(t, p, list);
        M.sel = list.length - 1;
      });
      paintCustomise();
    });
    ov.querySelector("[data-cdel]")?.addEventListener("click", (e) => { const p = custPath(), j = Number(e.target.dataset.cdel); edit((t) => { (get(p, t) || []).splice(j, 1); }); M.sel = 0; paintCustomise(); });
    const card = ov.querySelector("#ptcCustCard");
    card.querySelectorAll(".pce-part").forEach((n) => n.addEventListener("pointerdown", (e) => {
      e.preventDefault();
      const i = Number(n.dataset.pi), part = parts[i], r = card.getBoundingClientRect(), resize = !!e.target.dataset.rs;
      const s0 = { x: +part.obj.x || 0, y: +part.obj.y || 0, w: +part.obj.w || 1, h: +part.obj.h || 1 }, x0 = e.clientX, y0 = e.clientY, now = { ...s0 };
      M.sel = i;
      card.querySelectorAll(".pce-part").forEach((x) => x.classList.toggle("sel", x === n));
      try { n.setPointerCapture(e.pointerId); } catch (_) { /* synthetic */ }
      const q = (v) => Math.round(v * 1000) / 1000;
      const move = (ev) => {
        const dx = (ev.clientX - x0) / r.width, dy = (ev.clientY - y0) / r.height;
        if (resize) { now.w = q(Math.max(0.05, Math.min(1 - s0.x, s0.w + dx))); now.h = q(Math.max(0.05, Math.min(1 - s0.y, s0.h + dy))); }
        else { now.x = q(Math.max(0, Math.min(1 - s0.w, s0.x + dx))); now.y = q(Math.max(0, Math.min(1 - s0.h, s0.y + dy))); }
        Object.assign(n.style, { left: `${now.x * 100}%`, top: `${now.y * 100}%`, width: `${now.w * 100}%`, height: `${now.h * 100}%` });
      };
      const up = (ev) => {
        n.removeEventListener("pointermove", move);
        n.removeEventListener("pointerup", up);
        if (Math.abs(ev.clientX - x0) + Math.abs(ev.clientY - y0) > 2) edit((t) => Object.assign(get(`${custPath()}.${part.id}`, t) || {}, now));
        paintCustomise();
      };
      n.addEventListener("pointermove", move);
      n.addEventListener("pointerup", up);
    }));
  }

  /* ---------- the design library: save as my design, delete mine, start over ---------- */
  async function saveAs() {
    const cur = tpl() || {}, mine = (await designs()).find((d) => d.id === cur.id && !d.builtin);
    const name = window.prompt("Name for your design:", mine ? mine.name : `My ${cur.name || "design"}`);
    if (!name) return;
    try {
      const d = await api("/api/card_templates/save_copy", { method: "POST", body: { template: cur, name } });
      S.designs = d.templates || null;
      App.state.config.dynamic_settings = App.state.config.dynamic_settings || {};
      App.state.config.dynamic_settings.paytable_card_template = d.template;
      App.refreshUI();
      redrawSoon(0);
      toast(`Saved “${name}” to your designs — every game can use it.`);
    } catch (e) { toast(e.message || "The design could not be saved.", "err"); }
  }
  async function deleteDesign(id) {
    const d0 = (await designs()).find((d) => d.id === id);
    if (!d0 || d0.builtin) return;
    const ok = await App.choose("Delete design?", `“${esc(d0.name)}” is removed from your designs. This game keeps its current look.`,
      [{ label: "Cancel", value: false }, { label: "Delete", value: true, primary: true }]);
    if (!ok) return;
    try { S.designs = (await api("/api/card_templates/delete", { method: "POST", body: { id } })).templates || null; paint(); toast("Design deleted."); }
    catch (e) { toast(e.message || "The design could not be deleted.", "err"); }
  }
  function pagePop(anchor) {
    return popup(anchor, "Page", () => {
      const gname = ((App.state.config.dynamic_settings || {}).heading_game_name_text) || "";
      return `${prow("Top margin", kNum("page.top", get("page.top") ?? DEF.top, 0, 600))}
        ${prow("Bottom margin", kNum("page.bottom", get("page.bottom") ?? DEF.bottom, 0, 600))}
        ${prow("Side margins", `<input type="number" class="ts-size ts-narrow" data-sides value="${esc(get("page.left") ?? DEF.left)}" min="0" max="800">`)}
        ${prow("Cards sit", kSel("page.valign", get("page.valign") || "top", [["top", "At the top of their space"], ["center", "In the middle"]]))}
        ${prow("Gap around parts", kRange("page.band_gap", get("page.band_gap") ?? get("page.gap_y") ?? DEF.gap_y, 0, 120), "The space between the title, the rows, the boxes and the text")}
        ${prow("Between cards ↔", kNum("page.gap_x", get("page.gap_x") ?? DEF.gap_x, 0, 300))}
        ${prow("Between lines ↕", kNum("page.gap_y", get("page.gap_y") ?? DEF.gap_y, 0, 300))}
        ${prow("Numbers that don't fit", kSel("card.overflow", get("card.overflow") || "", [["", "Ask me"], ["shrink", "Shrink the numbers"], ["grow", "Make the cards bigger"]]))}
        ${prow("Game name", `<input type="text" data-gname value="${esc(gname)}" placeholder="what &lt;GAME NAME&gt; becomes">`)}
        <div class="ptc-note">Or drag the dashed page edges on the Canvas.</div>`;
    }, (pop) => {
      pop.querySelector("[data-sides]").addEventListener("change", (e) => { const v = Math.max(0, Number(e.target.value) || 0); edit((t) => { put(t, "page.left", v); put(t, "page.right", v); }); });
      pop.querySelector("[data-gname]").addEventListener("change", (e) => setGameName(e.target.value));
    });
  }
  async function setGameName(v) {
    const ds = (App.state.config.dynamic_settings = App.state.config.dynamic_settings || {});
    ds.heading_game_name_text = String(v || "").trim();
    App.refreshUI();
    // saved first: the page is drawn by the server from the saved settings (else it showed the name before)
    if (App.flushConfig) await App.flushConfig();
    redrawSoon(0);
    if (window.AppTypoVis && AppTypoVis.renderRail) AppTypoVis.renderRail();     // every page's <GAME NAME>
    toast(ds.heading_game_name_text ? `<GAME NAME> is now “${ds.heading_game_name_text}”.` : "<GAME NAME> has no name now.");
  }


  /* ---------- dividers: drag a line to move it, its end for its length, its side for its thickness ---------- */
  const dvPath = (name) => (S.iso === name ? `card_overrides.${lc(name)}.dividers` : "card.dividers");
  function dividerHandles(name) {
    const c = blocks()[blkOf(name)], d0 = S.data || {};
    if (isScard(name) || !c || !d0.canvas_px) return "";
    const cw = c[2] - c[0], ch = c[3] - c[1], pct = (v) => `${(v * 100).toFixed(3)}%`;
    return ["div1", "div2"].map((key) => {
      const it = (d0.items || []).find((x) => x.slot === `@slot.${name}.${key}`);   // a shape: where the layout put it
      if (!it) return "";
      const W = d0.canvas_px.width, H = d0.canvas_px.height;
      const d = [it.rect[0] / W, it.rect[1] / H, (it.rect[0] + it.rect[2]) / W, (it.rect[1] + it.rect[3]) / H];
      const up = (d[3] - d[1]) * d0.canvas_px.height >= (d[2] - d[0]) * d0.canvas_px.width;
      return `<div class="ptc-dv ${up ? "up" : "across"}" data-dv="${key}|move" style="left:${pct((d[0] - c[0]) / cw)};top:${pct((d[1] - c[1]) / ch)};width:${pct((d[2] - d[0]) / cw)};height:${pct((d[3] - d[1]) / ch)}" title="Divider: drag to move it">
        <div class="ptc-ch dvl" data-dv="${key}|len" title="Drag: its length">${up ? "↕" : "↔"}</div>
        <div class="ptc-ch dvw" data-dv="${key}|width" title="Drag: its thickness">${up ? "↔" : "↕"}</div></div>`;
    }).join("");
  }
  function dividerDrag(spec, ev, h) {
    const [key, what] = spec.split("|"), name = S.sel.key, line = h.closest(".ptc-dv"), ov = h.closest(".ptc-co"), sc = scales();
    if (!line || !ov) return;
    const up = line.classList.contains("up"), L0 = up ? line.offsetHeight : line.offsetWidth, dim = up ? ov.clientHeight : ov.clientWidth;
    dragOn(ev, (dx, dy) => {
      const along = up ? dy : dx, across = up ? dx : dy;
      if (what === "move") line.style.transform = up ? `translateX(${dx}px)` : `translateY(${dy}px)`;
      else h.style.transform = what === "len" ? (up ? `translateY(${along}px)` : `translateX(${along}px)`) : (up ? `translateX(${across}px)` : `translateY(${across}px)`);
    }, (dx, dy) => {
      const path = dvPath(name), eff = (k2, t) => get(`${path}.${k2}`, t) ?? get(`card.dividers.${k2}`, t);
      edit((t) => {
        if (what === "move") {
          const off0 = Number(eff(`lines.${key}.off`, t) || 0);
          put(t, `${path}.lines.${key}.off`, r3(off0 + (up ? dx / Math.max(1, ov.clientWidth) : dy / Math.max(1, ov.clientHeight))));
        } else if (what === "len") {
          put(t, `${path}.lines.${key}.len`, r3(Math.max(0.05, Math.min(1, (L0 + 2 * (up ? dy : dx)) / Math.max(1, dim)))));
        } else {
          put(t, `${path}.width`, Math.max(1, Math.round(Number(eff("width", t) || 2) + (up ? dx : dy) * sc.k)));
        }
        if (S.iso === name) put(t, `${path}.enabled`, true);
      });
    });
  }

  /* ---------- double-click: a text is typed where it is, a card is edited on its own ---------- */
  function dblclick(ev) {
    if (ev.target && ev.target.closest && ev.target.closest(".ptc-ied, .ptc-pop, .ptc-menu, .ptc-chips")) return;
    if (selLocked()) { toast("🔒 Locked — unlock it to edit it."); return; }
    const f = frac(ev), k = f && blockAt(f[0], f[1]);
    if (!k) return;
    if (k.startsWith("text:")) { pick(kindOf(k)); editText(k.slice(5)); return; }
    if (k.startsWith("btext:")) { pick(kindOf(k)); editBoxText(k.slice(6)); return; }
    if (k === "wild" && (S.data.items || []).some((x) => x.slot === "@slot.wildbox.text")) { pick({ kind: "box", key: "wild" }); editWildText(); return; }
    if (k.startsWith("card:")) {
      const name = k.slice(5);
      S.iso = name;
      pick({ kind: "card", key: name });
      toast(`Only ${name.toUpperCase()} — what you change now changes this card alone. Esc: back to its row.`);
    }
  }

  /* ---------- a text typed in place: the page draws everything else, the text is edited where it sits,
     in its own font, size and colour, its <icons> as their pictures (Enter: a new line, Esc: done) ---------- */
  function iconUrl(tok) { return ((S.data || {}).icons || {})[String(tok).replace(/[<>]/g, "").trim().replace(/[ .;,!-]+$/, "").toUpperCase()] || ""; }
  function toHtml(text) {
    return String(text || "").split(/(<[^<>\n]+>)/).map((part) => {
      if (/^<[^<>\n]+>$/.test(part)) {
        const url = iconUrl(part);
        return url ? `<img class="ptc-tokimg" src="${esc(url)}" data-tok="${esc(part)}" alt="${esc(part)}" contenteditable="false">`
          : `<span class="ptc-tok" data-tok="${esc(part)}" contenteditable="false">${esc(part)}</span>`;
      }
      return esc(part).replace(/\n/g, "<br>");
    }).join("");
  }
  function plainOf(root) {
    let out = "";
    const walk = (n) => n.childNodes.forEach((x) => {
      if (x.nodeType === 3) out += x.nodeValue.replace(/ /g, " ");
      else if (x.dataset && x.dataset.tok) out += x.dataset.tok;
      else if (x.nodeName === "BR") out += "\n";
      else if (x.nodeType === 1) {
        if (/^(DIV|P)$/.test(x.nodeName) && out && !out.endsWith("\n")) out += "\n";
        walk(x);
      }
    });
    walk(root);
    return out.replace(/\n$/, "");
  }
  function editInPlace(slot, text, save, menuItems) {
    closeTextEditor();
    const host = el("typoVisHost"), c = el("typoVisCanvas"), d = S.data;
    const it = ((d || {}).items || []).find((x) => x.slot === slot);
    if (!host || !c || !it) return false;
    const cr = c.getBoundingClientRect(), hr = host.getBoundingClientRect(), k = cr.width / d.canvas_px.width, st = it.style || {};
    S.tedSlot = slot;
    draw();                                                   // the page without this text: it is typed here
    const box = document.createElement("div");
    box.className = "ptc-ied";
    box.contentEditable = "true";
    box.spellcheck = false;
    Object.assign(box.style, {
      left: (cr.left - hr.left + it.rect[0] * k) + "px", top: (cr.top - hr.top + it.rect[1] * k) + "px",
      width: Math.max(60, it.rect[2] * k) + "px", minHeight: Math.max(24, it.rect[3] * k) + "px",
      fontFamily: `"${st.font || "Arial"}", Arial, sans-serif`, fontSize: (Number(st.size) || 30) * k + "px", color: st.color || "#fff",
      textAlign: st.align || "center", lineHeight: st.line_height ? st.line_height * k + "px" : "1.25",
      fontWeight: st.bold ? "700" : "400", fontStyle: st.italic ? "italic" : "normal",
    });
    box.innerHTML = toHtml(text);
    host.appendChild(box);
    const tip = document.createElement("div");
    tip.className = "ptc-ied-tip";
    tip.textContent = "Typing in place — Enter: new line · Esc or click away: done · right-click: move the selection";
    Object.assign(tip.style, { left: box.style.left, top: (parseFloat(box.style.top) - 22) + "px" });
    host.appendChild(tip);
    S.ted = slot;
    ["mousedown", "pointerdown", "click", "dblclick"].forEach((ty) => box.addEventListener(ty, (e) => e.stopPropagation()));
    const done = (keep = true) => {
      const val = plainOf(box).replace(/\s+$/g, "");
      closeTextEditor();
      if (keep && val !== text) save(val);
    };
    box.addEventListener("keydown", (e) => {
      e.stopPropagation();
      if (e.key === "Escape" || (e.key === "Enter" && (e.ctrlKey || e.metaKey))) { e.preventDefault(); done(); return; }
      if (e.key === "Enter") { e.preventDefault(); document.execCommand("insertLineBreak"); }
    });
    const outside = (e) => { if (!box.contains(e.target) && !(e.target.closest && e.target.closest(".ptc-menu"))) { document.removeEventListener("mousedown", outside, true); if (S.ted === slot) done(); } };
    setTimeout(() => document.addEventListener("mousedown", outside, true), 0);
    box.addEventListener("contextmenu", (e) => {
      e.preventDefault(); e.stopPropagation();
      const sel = window.getSelection(), range = sel && sel.rangeCount && box.contains(sel.anchorNode) ? sel.getRangeAt(0) : null;
      let picked = "";
      if (range && !range.collapsed) { const tmp = document.createElement("div"); tmp.appendChild(range.cloneContents()); picked = plainOf(tmp).trim(); }
      const cut = () => { range.deleteContents(); return plainOf(box).replace(/\n{3,}/g, "\n\n").replace(/^\n+|\n+$/g, ""); };
      menuAt(e, (menuItems ? menuItems(picked, cut, () => closeTextEditor()) : []).concat([null, { label: "Cancel the changes", run: () => done(false) }]));
    });
    box.focus();
    const r = document.createRange();
    r.selectNodeContents(box);
    r.collapse(false);
    window.getSelection().removeAllRanges();
    window.getSelection().addRange(r);
    return true;
  }
  function editText(id) {
    const tm = texts().find((x) => String(x.id) === String(id));
    if (!tm) return;
    editInPlace(tm.slot, tm.text || "", (val) => saveTexts((mine) => { mine[id] = val; }), (picked, cut, close) => {
      const others = texts().filter((x) => String(x.id) !== String(id));
      return [
        { label: "Move the selection to a new text box", off: !picked, run: () => {
          const left = cut(), nid = `t${Date.now() % 1000000}`;
          close();
          saveTexts((mine, t) => {
            mine[id] = left; mine[nid] = picked;
            const src = (get("page.texts", t) || [])[tIdx(t, id)] || {};
            t.page.texts.push({ id: nid, rect: newBoxRect(t, id), font_size: src.font_size, color: src.color, align: src.align || "center" });
          });
          toast("Moved to a new text box — drag ✥ to place it.");
        } },
        ...others.map((x) => ({ label: `Move the selection to text box ${texts().indexOf(x) + 1}`, off: !picked, run: () => {
          const left = cut();
          close();
          saveTexts((mine) => { mine[id] = left; mine[String(x.id)] = [mine[String(x.id)] ?? x.text, picked].filter(Boolean).join("\n"); });
        } })),
        { label: "Back to the Excel text", run: () => { close(); resetTexts(); } },
      ];
    });
  }
  // the WILD box's text: typed in place, kept for this Excel's words (another market keeps its own)
  function editWildText() {
    const w = (S.data || {}).wild_text || {}, it = (S.data.items || []).find((x) => x.slot === "@slot.wildbox.text");
    if (!it || !w.hash) return;
    editInPlace("@slot.wildbox.text", it.text || w.text || "", (val) => set(`features.wild_box.edits.${w.hash}`, val),
      (picked, cut, close) => [{ label: "Back to the Excel text", run: () => { close(); set(`features.wild_box.edits.${w.hash}`, undefined); } }]);
  }

  // a WILD / SCATTER box's heading, caption or tab: typed in place, kept for this Excel's words
  function editBoxText(slot) {
    if (slot === "@slot.wildbox.text") { editWildText(); return; }
    const bt = ((S.data || {}).box_texts || {})[slot], it = ((S.data || {}).items || []).find((x) => x.slot === slot);
    if (!bt || !it) return;
    editInPlace(slot, it.text || bt.original || "", (val) => set(`text_overrides.${bt.hash}`, val),
      (picked, cut, close) => [{ label: "Back to the Excel text", run: () => { close(); set(`text_overrides.${bt.hash}`, undefined); } }]);
  }

  /* ---------- a symbol inside a paytable text: its size here, every symbol of the text, or this symbol in
     every paytable text — paytable sizes only (the template's), never another page's ---------- */
  const ikey = (tok) => String(tok || "").replace(/[<>]/g, "").trim().toUpperCase();
  function iconBoxPath(slot, t) {
    if (/^@slot\.wildbox\./.test(slot)) return "features.wild_box";
    if (/^@slot\.scatbox\./.test(slot)) return "features.scatter_box";
    const tm = texts().find((x) => x.slot === slot);
    if (!tm) return null;
    const i = tIdx(t, tm.id);
    return i >= 0 ? `page.texts.${i}` : null;
  }
  // a symbol in a text: how tall it is drawn (canvas px)
  // which copy of its symbol in its text the picked icon is (0 = the first)
  const picNth = () => Math.max(0, Number(String((S.sel || {}).key || "").split("|")[2]) || 0);
  function iconPx(slot0, tok0) {
    const [slot, tok] = slot0 ? [slot0, tok0] : S.sel.key.split("|");
    const same = ((S.drawn || {}).__icons || []).filter((x) => x.slot === slot && ikey(x.tok) === ikey(tok));
    const i = (slot0 ? null : same[picNth()]) || same[0];
    return Math.round(i ? (i.rect[3] - i.rect[1]) * (((S.data || {}).canvas_px || {}).height || 1080) : 40);
  }
  // sizes in px, as a normal page's Apply to: only this icon (this text's icon_px "TOKEN#n"), every copy
  // of it in this text, every symbol of the text, or this symbol in every paytable text (text_icon_px)
  // — the sizes at a smaller reach give way, the older % sizes too
  function setIconPx(v, clear) {
    const [slot, tok] = S.sel.key.split("|"), k = ikey(tok), scope = S.iconScope || "one", nth = picNth();
    v = Math.max(4, Math.min(1000, Math.round(v)));
    edit((t) => {
      if (!/^@slot\.(wild|scat)box\./.test(slot)) pinTexts(t);
      const path = iconBoxPath(slot, t), drop = (base, kk) => { put(t, `${base}.icon_px.${kk}`, undefined); put(t, `${base}.icon_scale.${kk}`, undefined); };
      const dropCopies = (base) => Object.keys(get(`${base}.icon_px`, t) || {}).filter((kk) => ikey(kk).startsWith(k + "#")).forEach((kk) => drop(base, kk));
      if (scope === "all") {
        put(t, `text_icon_px.${k}`, clear ? undefined : v);
        put(t, `text_icon_scale.${k}`, undefined);
        if (path) { drop(path, k); dropCopies(path); }    // this text's own sizes of it give way
        return;
      }
      if (!path) return;
      if (scope === "one") { drop(path, `${k}#${nth}`); if (!clear) put(t, `${path}.icon_px.${k}#${nth}`, v); return; }
      if (scope === "tok") { drop(path, k); dropCopies(path); if (!clear) put(t, `${path}.icon_px.${k}`, v); return; }
      // every symbol of this text this tall (those drawn in it, and any that arrive later)
      const toks = [...new Set(((S.drawn || {}).__icons || []).filter((i) => i.slot === slot).map((i) => ikey(i.tok)))];
      toks.concat(["*"]).forEach((kk) => { drop(path, kk); if (!clear) put(t, `${path}.icon_px.${kk}`, v); });
    });
  }
  function iconBarHtml(head, sel) {
    const [slot, tok] = sel.key.split("|"), px = iconPx(), scope = S.iconScope || "one";
    const where = slot === "@slot.wildbox.text" ? "the WILD text" : /^@slot\.(wild|scat)box\./.test(slot) ? "this box" : "this text box";
    return `${head}<span class="ics-chip">◆ ${esc(tok)}</span><button class="ts-tgt" data-icback title="Its text">◂ Text</button>
      ${sep}<span class="ts-lbl">Height</span><button class="ts-al" data-icstep="-2">−</button>${num("data-icpx", px, "Its height (px, as drawn)", 4, 1000, "px")}<button class="ts-al" data-icstep="2">+</button>
      ${sep}<span class="ts-lbl">Apply to</span><select class="ts-style" data-icscope title="What the size changes">
        ${[["one", "Only this icon"], ["tok", `Every ${tok} in ${where}`], ["box", `Every icon in ${where}`], ["all", `Every ${tok} on every paytable`]]
          .map(([v, l]) => `<option value="${v}" ${scope === v ? "selected" : ""}>${esc(l)}</option>`).join("")}</select>
      ${sep}<button class="ts-tgt" data-icpic title="Another picture for ${esc(tok)}">🖼 Change picture</button>
      <button class="ts-tgt" data-icreset title="Back to the size of the text's other symbols">Reset</button>
      <span class="ts-hint">drag its corner · paytable sizes never change other pages</span>`;
  }
  function wireIconBar(root) {
    if (!S.sel || S.sel.kind !== "picon") return;
    const [slot, tok] = S.sel.key.split("|");
    root.querySelector("[data-icback]")?.addEventListener("click", () => {
      const tm = texts().find((x) => x.slot === slot);
      pick(tm ? { kind: "text", key: String(tm.id) } : BOX_TEXT[slot] ? { kind: "btext", key: slot } : null);
    });
    root.querySelectorAll("[data-icstep]").forEach((b) => b.addEventListener("click", () => setIconPx(iconPx() + Number(b.dataset.icstep))));
    root.querySelector("[data-icpx]")?.addEventListener("change", (e) => { const v = Number(e.target.value) || 0; if (v > 0) setIconPx(v); });
    root.querySelector("[data-icscope]")?.addEventListener("change", (e) => { S.iconScope = e.target.value; pick(S.sel); });
    root.querySelector("[data-icpic]")?.addEventListener("click", () => {
      IconStudio.mapDialog(ikey(tok), true);
      const wait = setInterval(() => { if (!document.querySelector(".overlay .table-mapper-dialog")) { clearInterval(wait); redrawSoon(0); } }, 400);
    });
    root.querySelector("[data-icreset]")?.addEventListener("click", () => setIconPx(0, true));   // no height of its own at this reach
  }

  /* ---------- a card's symbol: another picture for its <TOKEN> (every page), as on normal pages ---------- */
function breakOut(t, name) {
    const key = lc(name), r = rectOf("card:" + name);
    if (!r) return;
    const o = ((t.card_overrides = t.card_overrides || {})[key] = t.card_overrides[key] || {});
    o.free = r;
    delete o.in_row;
    if (!Array.isArray(o.parts)) o.parts = clone(viewParts(name));           // its own: the row's edits never move it
    o.free_base = Math.round(cardSize(cardRow(name))[0]);                    // its fonts as they are now: the row's card width before any fit
  }
  function joinRow(t, name, row, follow = true) {
    const key = lc(name), auto = ((S.data || {}).auto_free || []).includes(key);
    t.card_overrides = t.card_overrides || {};
    const o = t.card_overrides[key] || (auto ? (t.card_overrides[key] = {}) : null);
    if (!o) return;
    delete o.free; delete o.free_base;
    if (follow) { delete o.parts; delete o.style; delete o.dividers; }      // the row's design again (else its own look)
    if (auto) o.in_row = true;                                               // (the layout would break it out again)
    if (!Object.keys(o).length) delete t.card_overrides[key];
    if (row) {                                                               // the top or the bottom row, picked
      t.row_of = Object.assign({}, t.row_of || {});
      t.row_of[key] = row;
    }
  }
  /* 🎴 Card looks (dynamic_pages/paytable/card_looks.json): one card's shape, colours and layer style. Click
     one: every card takes it, or only this card / the Shift+clicked cards. Its glow / shadow joins the game's
     layer styles ("Card look · <name>") so it can be changed there like any other. */
  let LOOKS = null;
  async function looksPop(anchor, scope0) {
    if (!LOOKS) { try { LOOKS = (await api("/api/card_looks")).looks || []; } catch (e) { LOOKS = []; } }
    const sel = S.sel && S.sel.kind === "card" ? S.sel.key : null;
    const picked = sel ? capCards(sel) : [];
    let scope = scope0 || (sel ? "picked" : "all");
    const at = anchor || document.querySelector("#typoStrip .ptc-bar") || el("typoVisHost");
    const shapeOf = (st) => ({ radius: st.radius ?? 0, fill: st.fill_enabled === false ? null : st.fill, fill_to: st.fill_to || null, gradient_dir: st.gradient_dir || "vertical", fill_opacity: st.fill_opacity ?? 100,
      stroke: st.stroke || {}, radii: st.radii, corners: st.corners, corner: st.corner });
    const pop = popup(at, "Card looks", () => `
      <div class="tbs-seg" style="margin-bottom:8px;display:flex;gap:6px;align-items:center">
        <button class="${scope === "all" ? "on" : ""}" data-lscope="all" title="Every card of the page">Every card</button>
        ${sel ? `<button class="${scope === "picked" ? "on" : ""}" data-lscope="picked" title="${picked.length > 1 ? "The cards picked with Shift+click" : "Only this card"}">${picked.length > 1 ? `${picked.length} picked cards` : `Only ${esc(sel.toUpperCase())}`}</button>` : ""}
        <button class="pt-btn secondary small" data-autopall="1" style="margin-left:auto" title="Extract dark surface & vibrant accent colours from the game background">🎨 Auto-palette</button>
      </div>
      <div class="ptc-looks" style="display:grid;grid-template-columns:repeat(3,128px);gap:8px">
        ${LOOKS.map((l) => `<button class="ptc-look" data-look="${esc(l.id)}" title="${esc(l.note || l.name)}${l.fx && l.fx.captured_params && l.fx.captured_params.outer_glow ? " · its glow shows in the preview and PNG (the PSD keeps the shape, border and shadow)" : ""}" style="padding:4px;background:#222;border:1px solid #444;border-radius:6px;cursor:pointer">
          <canvas width="120" height="74" data-lookc="${esc(l.id)}" style="display:block;width:120px;height:74px"></canvas>
          <span style="display:block;font-size:11px;color:#ddd;margin-top:3px">${esc(l.name)}</span></button>`).join("") || `<span class="ts-hint">No card looks found.</span>`}
      </div>
      <div class="ptc-note">${scope === "all" ? "Every card of the page takes the look (a card with a look of its own too)." : "Only these cards: the others keep theirs. Shift+click more cards to pick them."}</div>`,
    (p, again) => {
      p.querySelectorAll("[data-lookc]").forEach((cv) => {
        const l = LOOKS.find((x) => x.id === cv.dataset.lookc), ctx = cv.getContext("2d");
        ctx.fillStyle = "#3a0d0d"; ctx.fillRect(0, 0, cv.width, cv.height);
        if (l && window.PCLive && PCLive.drawShape) PCLive.drawShape(ctx, shapeOf(l.style), [12, 8, 96, 58]);
      });
      p.querySelectorAll("[data-lscope]").forEach((b) => b.addEventListener("click", () => { scope = b.dataset.lscope; again(); }));
      const autoBtn = p.querySelector("[data-autopall]");
      if (autoBtn) autoBtn.addEventListener("click", async () => {
        try {
          const r = await api("/api/card_looks/auto_palette", { method: "POST", body: "{}" });
          if (!r || !r.ok || !r.palette) return;
          const pal = r.palette;
          applyLook({
            id: "auto_bg",
            name: "Auto Background Palette",
            style: { radius: 16, fill_enabled: true, fill: pal.fill, fill_to: pal.fill_to, fill_opacity: 92, stroke: { enabled: true, width: 4, color: pal.stroke, align: "inside" } },
            low_style: { radius: 12, fill_enabled: true, fill: pal.low_fill, fill_to: pal.fill_to, fill_opacity: 88, stroke: { enabled: true, width: 3, color: pal.low_stroke, align: "inside" } },
            fx: { captured_params: { outer_glow: { enabled: true, color: pal.glow, opacity: 50, size: 15, spread: 0, blend: "screen" }, drop_shadow: { enabled: true, color: "#000000", opacity: 65, distance: 6, size: 12, angle: 120 } } }
          }, scope === "all" ? null : picked);
          toast("Applied Auto-Palette from " + (r.source || "game assets") + ".");
        } catch (e) { toast(String(e), "err"); }
      });
      p.querySelectorAll("[data-look]").forEach((b) => b.addEventListener("click", () => {
        const l = LOOKS.find((x) => x.id === b.dataset.look);
        if (!l) return;
        applyLook(l, scope === "all" ? null : picked);
        toast(`“${l.name}” on ${scope === "all" ? "every card" : picked.length > 1 ? `${picked.length} cards` : sel.toUpperCase()}.`);
      }));
    });
    pop.style.width = "440px";                     // three thumbnails across
    pop.style.left = Math.max(8, Math.min(window.innerWidth - 448, parseFloat(pop.style.left) || 8)) + "px";
    return pop;
  }
  function applyLook(l, names) {
    const ds = (App.state.config.dynamic_settings = App.state.config.dynamic_settings || {});
    let fxName = "";
    if (l.fx) {                                     // its glow / shadow: a layer style of the game
      fxName = "Card look · " + l.name;
      ds.layer_style_library = Object.assign({}, ds.layer_style_library || {});
      if (!ds.layer_style_library[fxName]) ds.layer_style_library[fxName] = clone(l.fx);
    }
    edit((t) => {
      const name = "look_" + l.id;
      t.styles = t.styles || {};
      t.styles[name] = Object.assign(clone(l.style), fxName ? { fx: fxName } : {});
      if (!names) {
        if (l.low_style && (t.bands || []).length >= 2) {
          const lowName = name + "_low";
          t.styles[lowName] = clone(l.low_style);
          t.bands[0].style = name;
          t.bands.slice(1).forEach((b) => { if (b) b.style = lowName; });
        } else {
          (t.bands || []).forEach((b) => { if (b) b.style = name; });
        }
        Object.values(t.card_overrides || {}).forEach((o) => { if (o && o.style) delete o.style; });
      } else {
        names.forEach((n) => { ((t.card_overrides = t.card_overrides || {})[lc(n)] = t.card_overrides[lc(n)] || {}).style = name; });
      }
    });
  }
  /* a card's caption ("OF A KIND", "PAYS ANY", anything): every card's (card.kind_caption) or the picked
     cards' own (card_overrides[name].caption) — text, size, colour, font, place */
  const capCards = (name) => (S.multi && S.multi.length > 1 && S.multi.includes(name) ? S.multi : [name]);
  function capShown(name) {
    return ((S.data || {}).items || []).some((it) => it.slot === `@slot.${name}.kind`);
  }
  function captionPop(names) {
    const own = !!(names && names.length);
    const base = own ? `card_overrides.${lc(names[0])}.caption` : "card.kind_caption";
    if (own) edit((t) => names.forEach((n) => {
      const o = ((t.card_overrides = t.card_overrides || {})[lc(n)] = t.card_overrides[lc(n)] || {});
      o.caption = Object.assign({}, o.caption || {}, { enabled: true });
      if (!o.caption.text) o.caption.text = get("card.kind_caption.text", t) || "OF A KIND";
    }));
    const anchor = document.querySelector("#typoStrip .ptc-bar") || el("typoVisHost");
    // one card's fields write its own; the other picked cards copy them (wireK writes the first)
    const copyToRest = () => {
      if (!own || names.length < 2) return;
      edit((t) => { const src = get(base, t) || {}; names.slice(1).forEach((n) => put(t, `card_overrides.${lc(n)}.caption`, clone(src))); });
    };
    return popup(anchor, own ? (names.length > 1 ? `Caption — ${names.length} cards` : `Caption — ${names[0].toUpperCase()}`) : "Caption — every card", () => {
      const x = get(base) || {};
      return `${prow("Text", `<input type="text" class="ts-style" data-k="${base}.text" value="${esc(x.text || "OF A KIND")}">`, "The caption's words")}
        ${textFields(base)}
        ${prow("Place", kSel(`${base}.y`, x.y ?? 0.8, [[0.8, "At the bottom"], [0.02, "At the top"]]))}
        ${own ? `<div class="ptc-note">Only ${names.length > 1 ? "these cards" : "this card"} — every card's caption: right-click › A caption on every card.</div>` : ""}`;
    }, (() => {
      let n = 0;                                     // each write re-draws the popup: the other cards take it
      return () => { if (n++) setTimeout(copyToRest, 0); };
    })());
  }
  /* ⤓ Add to row: a card that isn't in a row — a SCATTER card, a coin, the lone SCATTER box — joins the top or
     the bottom row (card_overrides[key].in_row). Follow row style: it takes the row's look; off: it keeps its
     own (its parts and colours as they are now, its words sized to the row's cards) */
  function joinIndep(t, name, row, follow, kind) {
    const key = lc(name), o = ((t.card_overrides = t.card_overrides || {})[key] = t.card_overrides[key] || {});
    o.in_row = row;
    t.row_of = Object.assign({}, t.row_of || {}, { [key]: row });
    delete o.parts; delete o.style; delete o.own_look;
    if (follow) return;
    let parts = [], style = "", r = null;
    if (kind === "scard") {
      parts = clone(scardParts());
      style = get("scatter_section.card.style", t) || "";
      r = rectOf("scard:" + name);
    } else {
      const fp = boxParts("scatter") || {};
      parts = ["symbol", "counts", "pays"].filter((p) => fp[p]).map((p) => Object.assign({ role: p }, clone(fp[p])));
      style = get("features.style", t) || "feature";
      r = rectOf("scatter");
    }
    // its words sized to the row's cards: by the side that shrinks most (a wide, low row card)
    const [rw, rh] = cardSize(rowI(row), t) || [0, 0];
    const f = r && r[2] && r[3] && rw && rh ? Math.min(rw / r[2], rh / r[3]) : 1;
    parts.forEach((p) => { if (p.font_size) p.font_size = Math.max(6, Math.round(p.font_size * f * 10) / 10); });
    if (parts.length) o.parts = parts;
    if (style && (t.styles || {})[style]) o.style = style;
    o.own_look = true;
  }
  function unjoin(t, name) {
    const key = lc(name), o = (t.card_overrides || {})[key];
    if (o) { ["in_row", "parts", "style", "own_look", "dividers", "size"].forEach((k) => delete o[k]); if (!Object.keys(o).length) delete t.card_overrides[key]; }
    if (t.row_of) { delete t.row_of[key]; if (!Object.keys(t.row_of).length) delete t.row_of; }
  }
  /* a card on its own (broken out / only this card) takes a row's design: its parts and its look */
  function copyRowLook(t, name, i) {
    const key = lc(name), band = (t.bands || [])[i] || {};
    const o = ((t.card_overrides = t.card_overrides || {})[key] = t.card_overrides[key] || {});
    const parts = band.parts || (t.card || {}).parts;
    if (Array.isArray(parts)) o.parts = clone(parts);
    const st = band.style || "card";
    if (o.style && o.style !== st && t.styles && String(o.style).startsWith("card_")) delete t.styles[o.style];
    if (st === "card") delete o.style; else o.style = st;
  }
  function changePicture(name) {
    const it = (S.data.items || []).find((x) => x.slot === `@slot.${name}`) || {};
    const tok = it.token || String(name).toUpperCase();
    if (!window.IconStudio || !IconStudio.mapDialog) { toast("The symbol picker isn't loaded.", "err"); return; }
    IconStudio.mapDialog(tok, !!it.icon);
    const wait = setInterval(() => { if (!document.querySelector(".overlay .table-mapper-dialog")) { clearInterval(wait); redrawSoon(0); } }, 400);
  }

  /* ---------- the WILD / SCATTER box's texts: heading, caption, text, counts, pays ---------- */
  function boxTextsPop(anchor, b) {
    const section = Object.keys(blocks()).some((k) => k.startsWith("scard:")) && b === "scatter";
    if (!section && !get(`features.${b}_parts`)) {
      const real = ((S.data || {}).feature_parts || {})[b];
      if (real) edit((t) => put(t, `features.${b}_parts`, clone(real)));
    }
    const NAMES = { title: "Heading", label: "Caption", text: "Text", counts: "Counts", pays: "Pays" };
    return popup(anchor, `${b.toUpperCase()} box — its texts`, () => {
      if (section) return `<div class="ptc-sub">Heading</div>${textFields("scatter_section.title")}<div class="ptc-sub">Caption</div>${textFields("scatter_section.caption")}
        <div class="ptc-note">The SCATTER cards' numbers: pick a SCATTER card, then Aa ▾.</div>`;
      const parts = get(`features.${b}_parts`) || {};
      const keys = Object.keys(parts).filter((k2) => k2 !== "symbol");
      return keys.length ? keys.map((k2) => `<div class="ptc-sub">${esc(NAMES[k2] || k2)}</div>${textFields(`features.${b}_parts.${k2}`, !["counts", "pays"].includes(k2) || true)}`).join("")
        : `<div class="ptc-note">This box has no texts of its own.</div>`;
    });
  }
  function partsTools(aa = true) {
    const AL = { left: "⇤", hcenter: "↔", right: "⇥", top: "⤒", vcenter: "↕", bottom: "⤓" };
    const TIP = { left: "Align left", hcenter: "Centre across", right: "Align right", top: "Align top", vcenter: "Centre up and down", bottom: "Align bottom" };
    return `<span class="ts-lbl" title="The symbol and the numbers together">Parts</span>${Object.keys(AL).map((k2) => `<button class="ts-al" data-palg="${k2}" title="${TIP[k2]} (symbol and numbers together)">${AL[k2]}</button>`).join("")}
      ${aa ? `<button class="ts-tgt" data-pop="numbers" title="Font, bold, italic, colours and line height of the pays and values">Aa ▾</button>` : ""}`;
  }

  /* ---------- zones: rows like [SCATTER box | rules text | WILD box], each item shown by its rule ---------- */
  const zones = () => (S.data || {}).zones || [];
  const ZLABEL = { wild: "WILD box", scatter: "SCATTER box", text: "Rules text" };
  const SHOW = [["auto", "When the Excel has it"], ["always", "Always"], ["never", "Never"]];
  // the zone item a block is (wild / scatter / text:<id>): {zi, ii, z} or null
  function zoneOfBlock(k) {
    const first = (texts()[0] || {}).id;
    for (const z of zones()) {
      const ii = z.items.findIndex((it) => it.key === k || (it.key === "text:notes" && k === "text:" + first));
      if (ii >= 0) return { zi: z.index, ii, z };
    }
    return null;
  }
  const ZONE_PRESETS = [
    { label: "Feature row — SCATTER | rules | WILD, cards below", zones: [{ id: "top", pos: "top", h: 300, items: [{ kind: "scatter", w: 1 }, { kind: "text", id: "notes", w: 2 }, { kind: "wild", w: 1, title: "SUBSTITUTES" }] }] },
    { label: "Rules on top — cards — WILD | SCATTER at the bottom", zones: [{ id: "top", pos: "top", h: 200, items: [{ kind: "text", id: "notes" }] }, { id: "bottom", pos: "bottom", h: 240, items: [{ kind: "wild" }, { kind: "scatter" }] }] },
    { label: "Rules | WILD box on top, cards below", zones: [{ id: "top", pos: "top", h: 260, items: [{ kind: "text", id: "notes", w: 2 }, { kind: "wild", w: 1, title: "SUBSTITUTES" }] }] },
    { label: "Cards on top — WILD | rules | SCATTER at the bottom", zones: [{ id: "bottom", pos: "bottom", h: 280, items: [{ kind: "wild", w: 1 }, { kind: "text", id: "notes", w: 2 }, { kind: "scatter", w: 1 }] }] },
  ];
  function zonesPop(anchor) {
    return popup(anchor, "Zones", () => {
      const list = get("zones") || [];
      return `<div class="ptc-note">Rows across the page for the WILD / SCATTER boxes and the rules text; the cards take what is left.
          A box set to “When the Excel has it” is only there when the sheet has a WILD / SCATTER — otherwise its neighbours take its room.</div>
        <div class="ptc-sub">Start from</div>
        ${ZONE_PRESETS.map((p, i) => `<button class="ts-tgt ptc-wide" data-zpre="${i}">${esc(p.label)}</button>`).join("")}
        ${list.length ? `<div class="ptc-sub">This design's rows</div>
          ${list.map((z, i) => `<button class="ts-tgt ptc-wide" data-zedit="${esc(z.id || "zone" + i)}">▤ ${esc(z.id || "zone" + i)} — ${z.pos === "bottom" ? "bottom" : "top"}: ${(z.items || []).map((it) => ZLABEL[it.kind] || it.kind).join(" | ") || "empty"}</button>`).join("")}
          <button class="ts-tgt ptc-wide" data-znone>No zones (boxes and text placed freely)</button>` : ""}
        <button class="ts-tgt ptc-wide" data-zadd2="top">+ An empty row on top</button><button class="ts-tgt ptc-wide" data-zadd2="bottom">+ An empty row at the bottom</button>`;
    }, (pop, again) => {
      pop.querySelectorAll("[data-zpre]").forEach((b) => b.addEventListener("click", () => {
        const p = ZONE_PRESETS[Number(b.dataset.zpre)];
        const placed = (get("bands") || []).some((b) => b.pos || b.lock_size) || get("page.cards_lock") || get("page.cards_at");
        edit((t) => {
          t.zones = clone(p.zones);
          // the cards flow into what the rows leave: rows placed / locked by hand go back to automatic
          (t.bands || []).forEach((b) => { delete b.pos; delete b.lock_size; });
          ["cards_lock", "cards_at", "cards_offset"].forEach((k) => { if (t.page) delete t.page[k]; });
        });
        closePop();
        toast(`Zones set${placed ? " — the card rows you had placed by hand are automatic again, under the zones" : ""}. Click a row on the page to change what shows in it (Ctrl+Z undoes).`);
      }));
      pop.querySelectorAll("[data-zedit]").forEach((b) => b.addEventListener("click", () => { closePop(); pick({ kind: "zone", key: b.dataset.zedit }); }));
      pop.querySelector("[data-znone]")?.addEventListener("click", () => { edit((t) => { delete t.zones; }); closePop(); });
      pop.querySelectorAll("[data-zadd2]").forEach((b) => b.addEventListener("click", () => {
        edit((t) => { const l = (t.zones = t.zones || []); l.push({ id: `${b.dataset.zadd2}${l.length + 1}`, pos: b.dataset.zadd2, h: 260, items: [] }); });
        again();
      }));
    });
  }
  function zoneBarHtml(head, sel) {
    const z = zones().find((x) => x.id === sel.key);
    if (!z) return `${head}<span class="ics-chip">▤ Zone</span><button class="ts-tgt" data-back>◂ Page</button><span class="ts-hint">This row is gone.</span>`;
    const p = `zones.${z.index}`, items = get(`${p}.items`) || [];
    const missing = ["scatter", "text", "wild"].filter((k) => !items.some((it) => it.kind === k));
    return `${head}<span class="ics-chip">▤ Zone ${esc(z.id)}</span><button class="ts-tgt" data-back>◂ Page</button>
      ${sep}<span class="tbs-seg"><button class="${z.pos === "top" ? "on" : ""}" data-zpos="top" title="Under the title, above the cards">Top</button><button class="${z.pos === "bottom" ? "on" : ""}" data-zpos="bottom" title="Above the bottom margin, under the cards">Bottom</button></span>
      <span class="ts-lbl">H</span>${kNum(`${p}.h`, Math.round(z.h), 40, 1000)}<span class="ts-lbl" title="Space between its items">Gap</span>${kNum(`${p}.gap`, get(`${p}.gap`) ?? "", 0, 200, "page")}
      ${sep}${z.items.map((it, j) => `<span class="ptc-zi ${it.visible ? "" : "off"}" title="${it.visible ? "" : it.kind !== "text" && blocks()[it.kind] ? "Its symbol pays on this sheet, so it keeps a box of its own — outside the row" : it.show === "never" ? "Set to never show" : "This Excel has no " + (ZLABEL[it.kind] || "").replace(" box", "") + " — its neighbours take its room"}">
          ${j ? `<button class="ts-al" data-zmv="${j}|-1" title="Move left">◂</button>` : ""}<b>${esc(ZLABEL[it.kind] || it.kind)}${it.visible ? "" : " ⊘"}</b>
          <select class="ts-style ts-narrow" data-k="${p}.items.${j}.show" title="When it shows">${SHOW.map(([v, l]) => `<option value="${v}" ${it.show === v ? "selected" : ""}>${l}</option>`).join("")}</select>
          <input type="number" class="ts-size ts-narrow" data-k="${p}.items.${j}.w" data-num min="0.1" max="10" step="0.1" value="${esc(it.w)}" title="Its share of the row's width">
          ${it.kind !== "text" ? `<input type="text" class="ts-style ptc-ztitle" data-k="${p}.items.${j}.title" value="${esc(it.title || "")}" placeholder="${it.kind === "wild" ? "WILD" : "SCATTER"}" title="Its tab's title (empty: the Excel's word)">` : ""}
          ${j < z.items.length - 1 ? `<button class="ts-al" data-zmv="${j}|1" title="Move right">▸</button>` : ""}<button class="ts-al" data-zrm="${j}" title="Take it out of the row">✕</button></span>`).join("")}
      ${missing.length ? `<select class="ts-style" data-zadd><option value="">+ Add…</option>${missing.map((k) => `<option value="${k}">${ZLABEL[k]}</option>`).join("")}</select>` : ""}
      ${sep}<button class="ts-tgt" data-zdel title="Remove this row (its items go back to their own places)">Delete row</button>
      <span class="ts-hint">drag the row's edge for its height</span>`;
  }
  function wireZoneBar(root) {
    const z = S.sel && S.sel.kind === "zone" ? zones().find((x) => x.id === S.sel.key) : null;
    if (z) {
      const p = `zones.${z.index}`;
      root.querySelectorAll("[data-zpos]").forEach((b) => b.addEventListener("click", () => set(`${p}.pos`, b.dataset.zpos)));
      root.querySelectorAll("[data-zmv]").forEach((b) => b.addEventListener("click", () => {
        const [j, d] = b.dataset.zmv.split("|").map(Number);
        edit((t) => { const l = get(`${p}.items`, t); if (l && l[j + d]) [l[j], l[j + d]] = [l[j + d], l[j]]; });
      }));
      root.querySelectorAll("[data-zrm]").forEach((b) => b.addEventListener("click", () => edit((t) => { (get(`${p}.items`, t) || []).splice(Number(b.dataset.zrm), 1); })));
      root.querySelector("[data-zadd]")?.addEventListener("change", (e) => {
        const k = e.target.value;
        if (k) edit((t) => { const l = get(`${p}.items`, t) || []; l.push(k === "text" ? { kind: "text", id: "notes", w: 2 } : { kind: k, w: 1 }); put(t, `${p}.items`, l); });
      });
      root.querySelector("[data-zdel]")?.addEventListener("click", () => { S.sel = null; edit((t) => { (t.zones || []).splice(z.index, 1); if (!t.zones.length) delete t.zones; }); });
    }
    root.querySelectorAll("[data-zpick]").forEach((b) => b.addEventListener("click", () => pick({ kind: "zone", key: b.dataset.zpick })));
    root.querySelectorAll("[data-zout]").forEach((b) => b.addEventListener("click", () => {
      const [zi, ii] = b.dataset.zout.split("|").map(Number);
      edit((t) => { (get(`zones.${zi}.items`, t) || []).splice(ii, 1); });
      toast("Out of the zone — it is placed on its own again.");
    }));
  }
  // a box or text box in a zone: which row, when it shows, out of the row
  function zoneChipHtml(k) {
    const zz = zoneOfBlock(k);
    if (!zz) return "";
    const it = zz.z.items[zz.ii];
    return `${sep}<button class="ts-tgt" data-zpick="${esc(zz.z.id)}" title="The row it is in">▤ In zone ${esc(zz.z.id)}</button>
      <select class="ts-style ts-narrow" data-k="zones.${zz.zi}.items.${zz.ii}.show" title="When it shows">${SHOW.map(([v, l]) => `<option value="${v}" ${it.show === v ? "selected" : ""}>${l}</option>`).join("")}</select>
      <button class="ts-tgt" data-zout="${zz.zi}|${zz.ii}" title="Take it out of the row: placed on its own">Out of zone</button>`;
  }
  function zoneHeightDrag(ev, h) {
    const z = zones().find((x) => x.id === S.sel.key), sc = scales();
    if (!z) return;
    dragOn(ev, (dx, dy) => { h.style.transform = `translateY(${dy}px)`; }, (dx, dy) => {
      set(`zones.${z.index}.h`, Math.max(40, Math.round(z.h + (z.pos === "bottom" ? -dy : dy) * sc.k)));
    });
  }

  /* ------------------------------ suggested layouts ------------------------------ */
  /* the page arranged three ways (/api/paytable/suggest): the game's own design first, then the best
     rule-made arrangements — premium cards above, card ranks below, cards across, same pays sharing a
     card — each drawn small and scored; Use makes it the game's design (Ctrl+Z puts the old one back) */
  async function suggestPop(anchor) {
    document.querySelectorAll(".tbs-pop2").forEach((n) => n.remove());
    const pop = document.createElement("div");
    pop.className = "tbs-pop2 ptc-suggest";
    pop.innerHTML = `<div class="tsp-h">Suggested layouts</div><div class="ptc-sg-wait">Laying the page out a few ways…</div>`;
    document.body.appendChild(pop);
    const place = () => {
      const r = anchor.getBoundingClientRect();
      pop.style.top = (r.bottom + 6) + "px";
      pop.style.left = Math.max(8, Math.min(window.innerWidth - pop.offsetWidth - 8, r.left - 200)) + "px";
    };
    place();
    let d;
    try { d = await api("/api/paytable/suggest", { method: "POST", body: { sheet_name: AppTypoVis.state.sheet } }); }
    catch (e) { pop.querySelector(".ptc-sg-wait").textContent = e.message || "No suggestions."; return; }
    const list = d.suggestions || [];
    pop.innerHTML = `<div class="tsp-h">Suggested layouts</div>
      <div class="ptc-sg">${list.map((c, i) => `<div class="ptc-sg-card ${c.own ? "own" : ""}">
          <canvas data-sgc="${i}"></canvas>
          <div class="ptc-sg-label"><b>${esc(c.label)}</b><span class="ptc-sg-score" title="How well it fits: card size, full rows, premium cards bigger">${Math.round(c.score * 100)}</span></div>
          <div class="ptc-sg-why">${esc(c.why)}</div>
          ${c.own ? `<span class="ptc-sg-cur">current</span>` : `<button class="pt-btn small" data-sguse="${i}">Use</button>`}</div>`).join("")}</div>
      <div class="ptc-sg-note">Only how the cards are arranged changes — colours, fonts and boxes stay the design's.</div>`;
    place();
    pop.querySelectorAll("[data-sguse]").forEach((b) => b.addEventListener("click", () => {
      const c = list[Number(b.dataset.sguse)];
      pop.remove();
      edit((t) => { Object.keys(t).forEach((k) => delete t[k]); Object.assign(t, JSON.parse(JSON.stringify(c.template))); });
      toast(`Layout: ${c.label} — Ctrl+Z puts the one before back.`);
    }));
    // each drawn small, as it would look
    list.forEach(async (c, i) => {
      const cv = pop.querySelector(`[data-sgc="${i}"]`);
      try {
        const lay = await api("/api/card_templates/layout", { method: "POST", body: { template: c.template, sheet_name: AppTypoVis.state.sheet } });
        const draw1 = () => { if (cv.isConnected) PCLive.draw(cv, lay, draw1); };
        draw1();
      } catch (e) { /* no picture */ }
    });
  }

  /* ------------------------------ the templates: every design, drawn with this sheet ------------------------------ */
  async function templatesPop(anchor) {
    document.querySelectorAll(".tbs-pop2").forEach((n) => n.remove());
    const list = await designs(), cur = saved() || {};
    const pop = document.createElement("div");
    pop.className = "tbs-pop2 ptc-suggest";
    pop.innerHTML = `<div class="tsp-h">Templates <span class="ptc-sg-note">— drawn with this sheet's own Excel</span>
        <button class="pt-btn secondary small" data-x="bp" title="A PSD of named shapes (cards, “pays and values”, “Scatter box”, “Text Box”) read as a new template">+ From a blueprint PSD…</button></div>
      <div class="ptc-sg">${list.map((d, i) => {
        const own = cur.id === d.id || cur.based_on === d.id;
        return `<div class="ptc-sg-card ${own ? "own" : ""}"><canvas data-tpc="${i}"></canvas>
          <div class="ptc-sg-label"><b>${esc(d.name)}${d.builtin ? "" : " (mine)"}</b></div>
          <div class="ptc-sg-why">${esc(d.description || "")}</div>
          ${own ? `<span class="ptc-sg-cur">current</span>` : `<button class="pt-btn small" data-tpuse="${esc(d.id)}">Use</button>`}</div>`;
      }).join("")}</div>`;
    document.body.appendChild(pop);
    const r = anchor.getBoundingClientRect();
    pop.style.top = (r.bottom + 6) + "px";
    pop.style.left = Math.max(8, Math.min(window.innerWidth - pop.offsetWidth - 8, r.left - 200)) + "px";
    pop.querySelector('[data-x="bp"]').addEventListener("click", () => learnPop(anchor));
    pop.querySelectorAll("[data-tpuse]").forEach((b) => b.addEventListener("click", () => { pop.remove(); pickDesign(b.dataset.tpuse); }));
    const sheet = AppTypoVis.state.sheet;
    for (let i = 0; i < list.length; i++) {           // one at a time: the page stays responsive
      const cv = pop.querySelector(`[data-tpc="${i}"]`);
      if (!cv || !cv.isConnected) return;
      try {
        const t = (await api("/api/card_templates/" + encodeURIComponent(list[i].id))).template;
        const lay = await api("/api/card_templates/layout", { method: "POST", body: { template: t, sheet_name: sheet } });
        const draw1 = () => { if (cv.isConnected) PCLive.draw(cv, lay, draw1); };
        draw1();
      } catch (e) { /* no picture */ }
    }
  }

  /* ------------------------------ learn from the artist's PSD ------------------------------ */
  /* the artist's paytable page read as an editable card design (artist_design/learn_cards.py): pick the
     PSD and its page, see what was learned, drawn with this sheet; Use makes it the game's design */
  const LEARN_KEY = "psh.learnPsd";
  async function pickPsd() {
    const native = window.pywebview && window.pywebview.api;
    try { if (native) return await native.browse_file("psd"); } catch (e) { /* the browser's picker */ }
    return App.serverPick ? App.serverPick("psd") : "";
  }
  function learnPop(anchor) {
    document.querySelectorAll(".tbs-pop2").forEach((n) => n.remove());
    let last = "";
    try { last = localStorage.getItem(LEARN_KEY) || ""; } catch (e) { /* private window */ }
    const pop = document.createElement("div");
    pop.className = "tbs-pop2 ptc-learn";
    pop.innerHTML = `<div class="tsp-h">Learn the paytable design from the artist's PSD</div>
      <div class="ptc-lr-row"><input class="ptc-lr-path" placeholder="The artist's help-screen PSD" value="${esc(last || App.get("prev_psd_path") || "")}">
        <button class="pt-btn secondary small" data-x="browse">Browse…</button><button class="pt-btn small" data-x="pages">Find pages</button></div>
      <div class="ptc-lr-pages"></div><div class="ptc-lr-out"></div>`;
    document.body.appendChild(pop);
    const r = anchor.getBoundingClientRect();
    pop.style.top = (r.bottom + 6) + "px";
    pop.style.left = Math.max(8, Math.min(window.innerWidth - pop.offsetWidth - 8, r.left - 240)) + "px";
    const pathEl = pop.querySelector(".ptc-lr-path"), pagesEl = pop.querySelector(".ptc-lr-pages"), out = pop.querySelector(".ptc-lr-out");
    const learnPage = async (path, group) => {
      out.innerHTML = `<div class="ptc-sg-wait">Reading the cards on “${esc(group)}”…</div>`;
      let d;
      try { d = await api("/api/paytable/learn", { method: "POST", body: { psd_path: path, group } }); }
      catch (e) { out.innerHTML = `<div class="ptc-sg-wait">${esc(e.message || "Nothing learned.")}</div>`; return; }
      const rep = d.report, lk = rep.look, num = (role) => (rep.parts || []).find((p) => p.role === role) || {};
      const chip = (c) => `<span class="tbs-chip mini" style="--c:${esc(c)}"></span>`;
      out.innerHTML = `<div class="ptc-lr-res">
          <canvas class="ptc-lr-cv"></canvas>
          <div class="ptc-lr-facts">
            <div><b>${rep.cards} cards</b> · rows of ${rep.rows.join(" + ")}</div>
            <div>Card: ${lk.fill_enabled ? `${chip(lk.fill)} ${esc(lk.fill)} ${lk.fill_opacity < 100 ? `at ${lk.fill_opacity}%` : ""}` : "no fill"}${lk.stroke.enabled ? ` · stroke ${chip(lk.stroke.color)} ${lk.stroke.width}px ${esc(lk.stroke.align)}` : ""}${lk.radius ? ` · corners ${lk.radius}px` : ""}</div>
            ${num("counts").font ? `<div>Counts: ${esc(num("counts").font)} ${num("counts").font_size}px ${chip(num("counts").color)}</div>` : ""}
            ${num("pays").font ? `<div>Pays: ${esc(num("pays").font)} ${num("pays").font_size}px ${chip(num("pays").color)}</div>` : ""}
            ${(rep.notes || []).map((n) => `<div class="ptc-lr-note">${esc(n)}</div>`).join("")}
            <div class="ptc-lr-act"><button class="pt-btn small" data-x="use">Use this design</button>
              <button class="pt-btn secondary small" data-x="keep" title="Keep it among the templates — every game can use it">💾 Save to my templates</button>
              <span class="ptc-sg-note">This sheet's own Excel fills it; Ctrl+Z puts the old design back.</span></div>
          </div></div>`;
      out.querySelector('[data-x="use"]').addEventListener("click", () => {
        pop.remove();
        edit((t) => { Object.keys(t).forEach((k) => delete t[k]); Object.assign(t, JSON.parse(JSON.stringify(d.template))); });
        toast(`Design learned from “${group}” — edit it like any design.`);
      });
      out.querySelector('[data-x="keep"]')?.addEventListener("click", async () => {
        const name = window.prompt("Name for the template:", d.template.name || "My blueprint");
        if (!name) return;
        try {
          const s2 = await api("/api/card_templates/save_copy", { method: "POST", body: { template: d.template, name } });
          S.designs = s2.templates || null;
          pop.remove();
          edit((t) => { Object.keys(t).forEach((k) => delete t[k]); Object.assign(t, JSON.parse(JSON.stringify(s2.template))); });
          toast(`“${name}” is in the templates now — and this game uses it (Ctrl+Z puts the old design back).`);
        } catch (e) { toast(e.message || "The template could not be saved.", "err"); }
      });
      try {
        const lay = await api("/api/card_templates/layout", { method: "POST", body: { template: d.template, sheet_name: AppTypoVis.state.sheet } });
        const cv = out.querySelector(".ptc-lr-cv"), draw1 = () => { if (cv && cv.isConnected) PCLive.draw(cv, lay, draw1); };
        draw1();
      } catch (e) { /* no picture */ }
    };
    const findPages = async () => {
      const path = pathEl.value.trim();
      if (!path) return;
      try { localStorage.setItem(LEARN_KEY, path); } catch (e) { /* private window */ }
      pagesEl.innerHTML = `<div class="ptc-sg-wait">Reading the PSD…</div>`;
      let d;
      try { d = await api("/api/paytable/psd_pages", { method: "POST", body: { psd_path: path } }); }
      catch (e) { pagesEl.innerHTML = `<div class="ptc-sg-wait">${esc(e.message || "The PSD could not be read.")}</div>`; return; }
      const pages = d.pages || [];
      if (!pages.length) { pagesEl.innerHTML = `<div class="ptc-sg-wait">No paytable page found in this PSD.</div>`; return; }
      pagesEl.innerHTML = `<div class="ptc-lr-row"><select class="ts-style ptc-lr-page">${pages.map((pg) => `<option value="${esc(pg.path)}">${esc(pg.path)}${pg.visible ? "" : " (hidden)"}${pg.blueprint ? "" : ` — ${pg.numbers} numbers`}</option>`).join("")}</select>
        <button class="pt-btn small" data-x="learn">Learn</button></div>`;
      pagesEl.querySelector('[data-x="learn"]').addEventListener("click", () => learnPage(path, pagesEl.querySelector(".ptc-lr-page").value));
      learnPage(path, pages[0].path);
    };
    pop.querySelector('[data-x="browse"]').addEventListener("click", async () => { const p = await pickPsd(); if (p) { pathEl.value = p; findPages(); } });
    pop.querySelector('[data-x="pages"]').addEventListener("click", findPages);
    pathEl.addEventListener("keydown", (ev) => { if (ev.key === "Enter") findPages(); });
  }

  /* ------------------------------ the pay check ------------------------------ */
  async function payCheck() {
    const sheet = AppTypoVis.state.sheet;
    if (window.PaytableCards && PaytableCards.payCheck) await PaytableCards.payCheck(tpl(), sheet);
    // its problems: red frames on those cards
    try {
      const d = await api("/api/paytable/check", { method: "POST", body: { template: tpl(), sheet_name: sheet } });
      const ck = (((d.sheets || [])[0]) || {}).check;
      S.bad = new Set(((ck && ck.problems) || []).filter((p) => p.level === "error" && p.symbol).map((p) => String(p.symbol).toUpperCase()));
      paintFrames();
    } catch (e) { /* the panel said it */ }
  }

  // an undo / redo: draw the design it put back
  window.addEventListener("psh:history", () => { if (on()) redrawSoon(0); });

  return { setSheets, isPay: (s) => isPay(s), on, render, draw, redraw: draw, paint, paintFrames, click, dblclick, hover, escape, thumb,
    // the Layers panel (layers_panel.js): the picked part's block key, and picking one by its key
    selKey: () => selKey(), pickKey: (k) => { const to = kindOf(k); if (to) pick(to); },
           pointerDown, contextMenu, onKey,
           deselect: () => { S.sel = null; S.hover = ""; paintFrames(); }, state: S };
  function setSheets(list) { S.sheets = new Set(list || []); }
})();
