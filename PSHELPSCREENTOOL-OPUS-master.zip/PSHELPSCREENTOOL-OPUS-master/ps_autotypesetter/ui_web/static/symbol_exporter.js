/* Symbols from a PSD.
   Pick a reference PSD -> the tool finds its symbols (one per symbol, even when
   it is used on many pages), its backgrounds and pay-line pictures, with real
   previews -> rename to the Excel's symbol names -> save into the market's
   Working/Symbols and Working/BG, and the project uses them straight away.
   Or: "I already have a symbols folder".
   Server: /api/symbols/scan, /thumb, /export_picked, /use_folder (symbol_scan.py). */

(() => {
  const SymExport = (window.SymExport = {});
  const S = { overlay: null, psdPath: "", scan: null, names: {}, custom: new Set(), picked: new Set(), bg: "", busy: false, open: {} };
  // the Excel's tokens; a symbol named after one is saved as "<that token>.png" and matched to the Excel
  const tokens = () => (S.scan && S.scan.tokens) || [];
  const tokenOf = (key) => tokens().find((t) => t.toLowerCase() === String(S.names[key] || "").toLowerCase()) || "";

  const $ = (id) => document.getElementById(id);
  const escH = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const thumb = (key) => `/api/symbols/thumb?psd_path=${encodeURIComponent(S.psdPath)}&key=${encodeURIComponent(key)}`;

  /* opts.onSaved(true) after the symbols are saved and matched to the Excel,
     opts.onCancel() when the dialog is closed without saving. */
  SymExport.open = (opts = {}) => {
    S.onSaved = opts.onSaved || null;
    S.onCancel = opts.onCancel || null;
    if (S.overlay) { S.overlay.hidden = false; return; }
    const cfg = App.state.config || {};
    S.psdPath = S.psdPath || "";
    const ov = document.createElement("div");
    ov.className = "overlay";
    ov.style.zIndex = "10050";
    ov.innerHTML = `
      <div class="mapper-dialog sym-dialog">
        <div class="canvas-dialog-title">Symbols from a PSD</div>
        <div class="canvas-sub">Pick a PSD that has this game's symbols. The tool finds each symbol once (even if it's used on every page),
          the backgrounds and the pay-line pictures — you choose what to keep and they're saved into the market's <b>Working › Symbols</b> and <b>Working › BG</b>.</div>
        <div class="sym-body">
          <div class="sym-toolbar">
            <input type="text" id="symPsdPath" class="mapper-search" placeholder="Path to a .psd / .psb file…" spellcheck="false" />
            <button class="btn secondary" id="symPsdBrowse">Browse…</button>
            <button class="btn primary" id="symPsdLoad">Find symbols</button>
          </div>
          <div class="sym-alt">No PSD? <a href="#" id="symUseFolder">Use a symbols folder I already have</a></div>
          <div id="symStatus" class="sym-status" hidden></div>
          <div id="symSections" class="sym-sections"></div>
        </div>
        <div class="build-actions sym-actions">
          <span id="symResult" class="sym-result"></span>
          <button class="btn ghost" id="symCancel">Close</button>
          <button class="btn primary" id="symExport" disabled>Save</button>
        </div>
      </div>`;
    document.body.appendChild(ov);
    // a click outside never closes it (what was typed in it would be lost): its ✕ or Cancel do
    ov._onKey = (e) => { if (e.key === "Escape") SymExport.close(); };
    document.addEventListener("keydown", ov._onKey);
    S.overlay = ov;
    $("symPsdPath").value = S.psdPath;
    $("symPsdBrowse").addEventListener("click", SymExport.browsePsd);
    $("symPsdLoad").addEventListener("click", SymExport.load);
    $("symPsdPath").addEventListener("keydown", (e) => { if (e.key === "Enter") SymExport.load(); });
    $("symUseFolder").addEventListener("click", (e) => { e.preventDefault(); SymExport.useFolder(); });
    $("symExport").addEventListener("click", SymExport.export);
    $("symCancel").addEventListener("click", SymExport.close);
    SymExport.render();
  };

  /* after saving: link the saved pictures to the Excel's symbols */
  // only when the Excel still has symbols without a picture: matched by hand already, nothing is asked again
  SymExport.matchToExcel = async () => {
    if (!window.SymMap) return;
    const saved = S.onSaved;
    S.onSaved = S.onCancel = null;               // saved: closing the exporter is no longer a cancel
    let left = null;
    try { left = ((await api("/api/symbols/check", { method: "POST", body: {} })) || {}).unresolved || []; } catch (e) { left = null; }
    SymExport.close();
    if (left && !left.length) {
      toast("Every symbol of the Excel has its picture.");
      if (saved) saved(true);
      return;
    }
    SymMap.open({ onDone: () => { if (saved) saved(true); } });
  };

  SymExport.close = () => {
    if (!S.overlay) return;
    const cancel = S.onCancel;
    S.onSaved = S.onCancel = null;
    if (cancel) cancel();
    document.removeEventListener("keydown", S.overlay._onKey);
    S.overlay.remove();
    S.overlay = null;
  };

  SymExport.browsePsd = () => {
    App.pickPath("psd", async (p) => {
      if (!p) return;
      S.psdPath = p;
      $("symPsdPath").value = p;
      await SymExport.load();
    });
  };

  function status(msg, kind) {
    const st = $("symStatus");
    if (!st) return;
    st.hidden = !msg;
    st.textContent = msg || "";
    st.className = "sym-status " + (kind || "");
  }

  SymExport.load = async () => {
    if (S.busy) return;
    S.psdPath = $("symPsdPath").value.trim().replace(/^"|"$/g, "");
    if (!S.psdPath) { toast("Pick a PSD first.", "err"); return; }
    S.busy = true;
    S.scan = null;
    SymExport.render();
    status("Reading the PSD — finding symbols, backgrounds and pay lines…", "busy");
    const t0 = performance.now();
    try {
      const d = await api("/api/symbols/scan", { method: "POST", body: { psd_path: S.psdPath } });
      if (!d || !d.ok) throw new Error((d && d.error) || "Could not read the PSD.");
      S.scan = d;
      S.names = {};
      S.picked = new Set(d.symbols.map((e) => e.key));          // every symbol picked by default
      S.custom = new Set();
      d.symbols.forEach((e) => { S.names[e.key] = (d.suggested || {})[e.name] || e.name; });
      d.backgrounds.forEach((e) => { S.names[e.key] = e.name || "background"; });
      (d.paylines || []).forEach((e) => { S.names[e.key] = e.name; });
      (d.others || []).forEach((e) => { S.names[e.key] = e.name; });
      S.bg = d.backgrounds.length ? d.backgrounds[0].key : "";
      const c = d.counts;
      status(`Found ${c.symbols} symbols, ${c.backgrounds} background${c.backgrounds === 1 ? "" : "s"} and ${c.paylines} pay-line pictures in ${((performance.now() - t0) / 1000).toFixed(1)}s.`, "ok");
    } catch (e) {
      status(e.message, "err");
    }
    S.busy = false;
    SymExport.render();
  };

  function tile(e, opts) {
    const on = opts.radio ? S.bg === e.key : S.picked.has(e.key);
    const uses = e.count > 1 ? `used ${e.count}×` : "";
    const sizes = (e.sizes || []).length > 1 ? ` · ${e.sizes.length} sizes` : "";
    return `<div class="sym-tile ${on ? "sel" : ""} ${e.hidden ? "hid" : ""}" data-key="${escH(e.key)}" data-radio="${opts.radio ? 1 : ""}"
        title="${escH(e.name)} — ${e.w}×${e.h}${e.pages && e.pages.length ? " — pages: " + escH(e.pages.join(", ")) : ""}">
      <div class="sym-check">${on ? "✓" : ""}</div>
      <img class="sym-thumb" alt="" loading="lazy" src="${thumb(e.key)}" onerror="this.style.visibility='hidden'" />
      ${opts.rename ? nameControl(e) : `<div class="sym-name">${escH(e.name)}</div>`}
      <div class="sym-meta"><span>${e.w}×${e.h}</span><span>${uses}${sizes}</span></div>
    </div>`;
  }

  function nameControl(e) {
    const tok = tokenOf(e.key), custom = S.custom.has(e.key) || (!tok && S.names[e.key] !== layerName(e));
    const dup = tok && (S.scan.symbols || []).some((o) => o.key !== e.key && S.picked.has(o.key) && tokenOf(o.key) === tok);
    return `<div class="sym-layer" title="Layer in the PSD">${escH(e.name)}</div>
      <select class="sym-token ${tok ? "on" : ""} ${dup ? "dup" : ""}" data-key="${escH(e.key)}" title="Saved as this name in the Symbols folder">
        <option value="__layer" ${!tok && !custom ? "selected" : ""}>Keep the layer name</option>
        ${tokens().length ? `<optgroup label="The Excel's tokens">${tokens().map((t) => `<option value="${escH(t)}" ${t === tok ? "selected" : ""}>&lt;${escH(t)}&gt;</option>`).join("")}</optgroup>` : ""}
        <option value="__custom" ${custom && !tok ? "selected" : ""}>Type a name…</option>
      </select>
      ${custom && !tok ? `<input class="sym-name-in" value="${escH(S.names[e.key])}" data-key="${escH(e.key)}" placeholder="File name">` : ""}
      ${dup ? `<div class="sym-dup">Another symbol has this token too</div>` : ""}`;
  }
  const layerName = (e) => e.name;

  function section(id, title, items, opts) {
    if (!items || !items.length) return "";
    const open = S.open[id] !== undefined ? S.open[id] : !opts.collapsed;
    const n = opts.radio ? (S.bg ? 1 : 0) : items.filter((e) => S.picked.has(e.key)).length;
    return `<div class="sym-sec">
      <div class="sym-sec-head" data-sec="${id}">
        <span class="sym-caret">${open ? "▾" : "▸"}</span><b>${title}</b>
        <span class="hint">${items.length} found · ${n} picked</span>
        <span style="flex:1"></span>
        ${opts.radio ? `<a href="#" data-none="1">none</a>` : `<a href="#" data-all="${id}">all</a> · <a href="#" data-clear="${id}">none</a>`}
      </div>
      ${open ? `<div class="sym-grid">${items.map((e) => tile(e, opts)).join("")}</div>` : ""}
      ${open && opts.note ? `<div class="hint sym-note">${opts.note}</div>` : ""}
    </div>`;
  }

  SymExport.render = () => {
    const box = $("symSections");
    if (!box) return;
    const d = S.scan;
    if (!d) {
      box.innerHTML = S.busy ? "" : `<div class="empty" style="padding:28px"><div class="empty-icon">◫</div>
        <div class="empty-title">No PSD read yet</div>
        <div class="empty-sub">Pick a PSD with this game's symbols and press <b>Find symbols</b>.</div></div>`;
      SymExport.updateFooter();
      return;
    }
    const named = d.symbols.filter((e) => S.picked.has(e.key) && tokenOf(e.key)).length;
    const picked = d.symbols.filter((e) => S.picked.has(e.key)).length;
    box.innerHTML =
      (tokens().length ? `<div class="sym-tokbar"><b>${named}</b> of ${picked} picked symbols have an Excel token —
        pick each one's token under its picture; it is saved under that name (not the layer name) and matched to the Excel.</div>`
        : `<div class="sym-tokbar">No Excel tokens found — set the project's Excel to name symbols after its tokens.</div>`) +
      section("symbols", "Symbols", d.symbols, { rename: true }) +
      section("bg", "Background", d.backgrounds, { radio: true, note: "Pick the help-screen background (saved into BG)." }) +
      section("paylines", "Pay-line pictures", d.paylines, { rename: true, collapsed: true }) +
      section("others", "Other pictures (strips, frames, panels)", d.others, { rename: true, collapsed: true });
    box.querySelectorAll(".sym-tile").forEach((el) => el.addEventListener("click", (ev) => {
      if (ev.target.tagName === "INPUT") return;
      const key = el.dataset.key;
      if (el.dataset.radio) S.bg = S.bg === key ? "" : key;
      else if (S.picked.has(key)) S.picked.delete(key);
      else S.picked.add(key);
      SymExport.render();
    }));
    box.querySelectorAll(".sym-name-in").forEach((inp) => inp.addEventListener("input", () => { S.names[inp.dataset.key] = inp.value; }));
    box.querySelectorAll(".sym-token").forEach((sel) => {
      sel.addEventListener("click", (ev) => ev.stopPropagation());
      sel.addEventListener("change", () => {
        const key = sel.dataset.key, v = sel.value;
        const e = [...d.symbols, ...(d.paylines || []), ...(d.others || [])].find((x) => x.key === key);
        if (v === "__layer") { S.custom.delete(key); S.names[key] = e ? layerName(e) : key; }
        else if (v === "__custom") { S.custom.add(key); }
        else { S.custom.delete(key); S.names[key] = v; S.picked.add(key); }
        SymExport.render();
        if (v === "__custom") box.querySelector(`.sym-name-in[data-key="${CSS.escape(key)}"]`)?.focus();
      });
    });
    box.querySelectorAll(".sym-sec-head").forEach((h) => h.addEventListener("click", (ev) => {
      const a = ev.target.closest("a");
      const lists = { symbols: d.symbols, paylines: d.paylines, others: d.others };
      if (a) {
        ev.preventDefault();
        if (a.dataset.none) S.bg = "";
        if (a.dataset.all) lists[a.dataset.all].forEach((e) => S.picked.add(e.key));
        if (a.dataset.clear) lists[a.dataset.clear].forEach((e) => S.picked.delete(e.key));
      } else {
        const id = h.dataset.sec;
        const cur = S.open[id] !== undefined ? S.open[id] : !(id === "paylines" || id === "others");
        S.open[id] = !cur;
      }
      SymExport.render();
    }));
    SymExport.updateFooter();
  };

  SymExport.updateFooter = () => {
    const btn = $("symExport");
    if (!btn) return;
    const n = S.picked.size;
    const parts = [];
    if (n) parts.push(`${n} picture${n === 1 ? "" : "s"}`);
    if (S.bg) parts.push("background");
    btn.textContent = parts.length ? `Save ${parts.join(" + ")}` : "Save";
    btn.disabled = S.busy || !S.scan || (!n && !S.bg);
    const res = $("symResult");
    if (res && S.scan && !res.dataset.done) {
      res.innerHTML = S.scan.symbols_dir ? `<span class="hint">Saves to ${escH(S.scan.symbols_dir)}</span>` : "";
    }
  };

  SymExport.export = async () => {
    if (S.busy || !S.scan) return;
    const items = [...S.picked].map((key) => ({ key, name: S.names[key] || key }));
    if (S.bg) items.push({ key: S.bg, name: S.names[S.bg] || "background" });
    S.busy = true;
    SymExport.updateFooter();
    status("Saving…", "busy");
    try {
      const body = { psd_path: S.psdPath, items, symbols_dir: S.scan.symbols_dir, bg_dir: S.scan.bg_dir };
      const d = App.saveSafely ? await App.saveSafely("/api/symbols/export_picked", body)
        : await api("/api/symbols/export_picked", { method: "POST", body });
      if (d.cancelled) { status("Nothing was saved.", ""); S.busy = false; SymExport.updateFooter(); return; }
      if (!d || !d.ok) throw new Error((d && d.error) || "Saving failed.");
      if (d.config) App.state.config = d.config;
      const syms = d.files.filter((f) => f.kind === "symbol").length;
      const bgs = d.files.filter((f) => f.kind === "background").length;
      status(`Saved ${syms} symbol${syms === 1 ? "" : "s"} to ${d.symbols_dir}${bgs ? ` and the background to ${d.bg_dir}` : ""}. The project now uses them.`, "ok");
      const res = $("symResult");
      if (res) {
        res.dataset.done = "1";
        res.innerHTML = `<a href="#" id="symOpenOut">Open the Symbols folder</a>`;
        $("symOpenOut").addEventListener("click", (ev) => {
          ev.preventDefault();
          api("/api/open-dir", { method: "POST", body: { path: d.symbols_dir } }).catch(() => {});
        });
      }
      toast("Symbols saved and in use.");
      if (App.scan) App.scan();
      SymExport.matchToExcel();
    } catch (e) {
      status(e.message, "err");
    }
    S.busy = false;
    SymExport.updateFooter();
  };

  SymExport.useFolder = () => {
    App.pickPath("dir", async (folder) => {
      if (!folder) return;
      try {
        const d = App.saveSafely ? await App.saveSafely("/api/symbols/use_folder", { folder, copy: true })
          : await api("/api/symbols/use_folder", { method: "POST", body: { folder, copy: true } });
        if (d.cancelled) return;
        if (!d || !d.ok) throw new Error((d && d.error) || "Could not use that folder.");
        if (d.config) App.state.config = d.config;
        status(d.copied ? `Copied ${d.copied} symbols into ${d.icon_folder}; the project uses them.` : `The project now uses ${d.icon_folder}.`, "ok");
        toast("Symbols folder set.");
        if (App.scan) App.scan();
        SymExport.matchToExcel();
      } catch (e) {
        status(e.message, "err");
      }
    });
  };
})();
