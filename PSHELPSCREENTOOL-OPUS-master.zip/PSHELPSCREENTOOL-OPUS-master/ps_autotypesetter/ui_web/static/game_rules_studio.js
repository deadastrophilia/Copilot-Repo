/* Game Rules studio: the page itself, full width, edited right on the preview.

   The server renders the page with the real PNG renderer (/api/game_rules/preview) and says where
   everything landed (heading, each text line with its Excel cell, the separator, the XTRAA REELS
   spots, the margins). On top of the picture:
     · margin guides (drag): heading top, heading–body gap, bottom, text sides, legal sides,
       XTRAA REELS distance from the page edge
     · click the heading / the rules text / the legal text / the separator / an XTRAA REELS icon
       → a bar with its look (font, size, colour, layer style; separator width / thickness)
     · the separator's ends and bottom edge drag its width and thickness; an icon's corner its size
       (both icons are always the same size)
     · a tick above each XTRAA REELS spot shows / hides that side
     · double-click the text → select it like in a document → right-click: put it under the
       separator (from there on) or move it back above
   Uses app.js globals: App, api, esc, toast, debounce. */
window.GRStudio = (() => {
  const S = { sheet: "", token: "", layout: null, sel: "", drag: null, textMode: false };
  const ROLE = { rules: "Game Rules text", legal: "Malfunction/legal text", heading: "Heading text" };
  const el = (id) => document.getElementById(id);
  const ds = () => (App.state.config.dynamic_settings = App.state.config.dynamic_settings || {});

  function sheets() {
    return (App.state.scan?.excel?.sheets || []).map((s) => s.name).filter(Boolean)
      .filter((n) => String(n).toLowerCase().replace(/[^a-z0-9]+/g, "").startsWith("gamerules"));
  }

  /* ---------- view ---------- */
  function view() {
    const shs = sheets();
    if (!S.sheet || !shs.includes(S.sheet)) S.sheet = App.state.grSheetName && shs.includes(App.state.grSheetName) ? App.state.grSheetName : (shs[0] || "");
    const on = App.get("render_game_rules") !== false;
    return `<div class="view grs-view">
      <div class="view-header" style="display:flex;align-items:flex-end;gap:12px">
        <div style="flex:1"><div class="view-title">Game Rules</div>
          <div class="view-sub">Click the heading, the text, the separator or an XTRAA REELS icon to change it · drag the guides for margins · double-click the text to select it, then right-click to put it under the separator.</div></div>
      </div>
      <div class="grs-bar">
        <label class="grs-lab">Sheet</label>
        <select id="grsSheet">${shs.map((n) => `<option ${n === S.sheet ? "selected" : ""}>${esc(n)}</option>`).join("") || `<option value="">No Game Rules sheet scanned</option>`}</select>
        <label class="grs-check" title="Build the Game Rules page"><input type="checkbox" id="grsOn" ${on ? "checked" : ""}> Build this page</label>
        <span class="grs-sep"></span>
        <span class="grs-lab">XTRAA REELS</span>
        <label class="grs-check" title="Show the XTRAA REELS icon left of the rules"><input type="checkbox" data-xrbar="left"> left</label>
        <label class="grs-check" title="Show the XTRAA REELS icon right of the rules"><input type="checkbox" data-xrbar="right"> right</label>
        <button class="pt-btn secondary small" id="grsXrPick" title="The picture to use (else xtraa*.png / xtrareel*.png in the symbols folder)">Choose icon…</button>
        <span class="grs-info" id="grsInfo"></span>
        <span style="flex:1"></span>
        <span class="pt-pill idle" id="grsBadge">Ready</span>
        <button class="pt-btn secondary small" id="grsRefresh">⟳ Render</button>
      </div>
      <div class="grs-stage" id="grsStage">
        ${S.token ? stageHtml() : `<div class="empty" style="padding:48px"><div class="empty-icon">▤</div><div class="empty-title">${shs.length ? "Rendering…" : "No Game Rules sheet"}</div><div class="empty-sub">${shs.length ? "" : "Load an Excel with a Game Rules sheet in the Project view."}</div></div>`}
      </div>
    </div>`;
  }

  function stageHtml() {
    return `<div class="grs-page" id="grsPage">
        <img id="grsImg" src="/api/table_preview/${encodeURIComponent(S.token)}?v=${Date.now()}" alt="Game Rules" draggable="false">
        <div class="grs-ov" id="grsOv"></div>
      </div>`;
  }

  /* ---------- server ---------- */
  async function refresh() {
    if (!S.sheet) return;
    const badge = el("grsBadge");
    if (badge) { badge.classList.remove("idle"); badge.textContent = "Rendering…"; }
    try {
      await App.flushConfig();
      const d = await api("/api/game_rules/preview", { method: "POST", body: { sheet_name: S.sheet } });
      if (!d || !d.ok) { if (d && d.error) toast(d.error, "warn"); return; }
      S.token = d.preview_token;
      S.layout = d.layout || null;
      const stage = el("grsStage");
      if (!stage) return;
      const img = el("grsImg");
      if (!img) { stage.innerHTML = stageHtml(); el("grsImg").addEventListener("load", draw); }
      else { img.onload = draw; img.src = "/api/table_preview/" + encodeURIComponent(S.token) + "?v=" + Date.now(); }
      info();
    } catch (e) {
      toast("Game Rules preview failed: " + ((e && e.message) || e), "err");
    } finally {
      if (badge) { badge.classList.add("idle"); badge.textContent = "Ready"; }
    }
  }
  const schedule = debounce(refresh, 350);

  function save(key, value, now) {
    App.set(key, value);
    App.pushConfig();
    if (now) refresh(); else schedule();
  }

  function info() {
    const box = el("grsInfo"), L = S.layout || {};
    if (!box) return;
    const x = L.xtra || {}, sz = L.sizes || {};
    document.querySelectorAll("[data-xrbar]").forEach((c) => { c.checked = !!x["want_" + c.dataset.xrbar]; });
    const xr = !x.asset ? ((x.want_left || x.want_right) ? "no XTRAA REELS picture yet — Choose icon… (or put xtraa.png in the symbols folder)" : "")
      : (x.left || x.right) ? "" : x.mentioned ? "" : "this page doesn't mention XTRAA REELS — tick a side to show it anyway";
    const fit = L.fit && L.fit < 0.995 ? ` · text drawn at ${sz.body}px (set ${sz.body_set}px) to fit one page` : "";
    box.textContent = (xr + fit).replace(/^ · /, "");
  }

  /* ---------- overlay ---------- */
  function geo() {
    const img = el("grsImg"), L = S.layout;
    if (!img || !L || !L.canvas) return null;
    const r = img.getBoundingClientRect();
    return { r, cw: L.canvas[0], ch: L.canvas[1], k: r.width / L.canvas[0] };
  }
  const pct = (v, of) => (v / of * 100).toFixed(4) + "%";
  const boxCss = (rc, g, pad = 0) => `left:${pct(rc[0] - pad, g.cw)};top:${pct(rc[1] - pad, g.ch)};width:${pct(rc[2] + 2 * pad, g.cw)};height:${pct(rc[3] + 2 * pad, g.ch)}`;

  function guides(L) {
    const G = L.guides || {}, cw = L.canvas[0], ch = L.canvas[1], x = L.xtra || {};
    const out = [
      { id: "top", o: "h", at: G.heading_top, label: "Header Top Margin" },
      { id: "gap", o: "h", at: G.body_top, label: "Heading–Body Gap" },
      { id: "bottom", o: "h", at: G.safe_bottom, label: "Bottom Margin" },
      { id: "text", o: "v", at: G.upper_margin, mirror: true, label: (x.left || x.right) ? "Text ↔ XTRAA REELS" : "Inner Canvas Width" },
    ];
    if ((L.lines || []).some((l) => l.part === "legal")) out.push({ id: "legal", o: "v", at: G.legal_margin, mirror: true, label: "Legal Text Width" });
    if (x.asset && (x.left || x.right)) out.push({ id: "xouter", o: "v", at: x.outer, mirror: true, label: "XTRAA REELS Margin" });
    let n = 0;
    return out.filter((g) => g.at != null && isFinite(g.at)).map((g) => Object.assign(g, { cw, ch, n: g.o === "v" ? n++ : 0 }));
  }

  function draw() {
    const ov = el("grsOv"), L = S.layout, g = geo();
    if (!ov || !L || !g) return;
    let html = "";
    // guides — the same lines, tags and shaded areas as the Typography preview
    const G = L.guides || {};
    if (G.heading_top != null) {
      html += `<div class="vis-rect vis-rect-head" style="left:${pct(G.margin_x, g.cw)};top:${pct(G.heading_top, g.ch)};width:${pct(g.cw - 2 * G.margin_x, g.cw)};height:${pct(G.heading_bottom - G.heading_top, g.ch)}"></div>`;
      html += `<div class="vis-rect vis-rect-safe" style="left:${pct(G.upper_margin, g.cw)};top:${pct(G.body_top, g.ch)};width:${pct(g.cw - 2 * G.upper_margin, g.cw)};height:${pct(G.safe_bottom - G.body_top, g.ch)}"></div>`;
    }
    for (const gd of guides(L)) {
      if (gd.o === "h") html += `<div class="grs-guide vis-guide vis-guide-h" data-g="${gd.id}" style="top:${pct(gd.at, g.ch)}"><span class="vis-guide-tag">${esc(gd.label)}</span></div>`;
      else {
        html += `<div class="grs-guide vis-guide vis-guide-v" data-g="${gd.id}" data-side="l" style="left:${pct(gd.at, g.cw)}"><span class="vis-guide-tag" style="top:${8 + 20 * gd.n}px">${esc(gd.label)}</span></div>`;
        html += `<div class="grs-guide vis-guide vis-guide-v" data-g="${gd.id}" data-side="r" style="left:${pct(g.cw - gd.at, g.cw)}"><span class="vis-guide-tag" style="top:${8 + 20 * gd.n}px;left:auto;right:5px">${esc(gd.label)}</span></div>`;
      }
    }
    // heading, text lines
    if (L.heading) html += `<div class="grs-hit head ${S.sel === "heading" ? "sel" : ""}" data-k="heading" style="${boxCss(L.heading, g, 4)}"></div>`;
    (L.lines || []).forEach((ln, i) => {
      html += `<div class="grs-hit line ${ln.part} ${S.sel === ln.part ? "sel" : ""}" data-k="${ln.part}" data-i="${i}" style="${boxCss(ln.rect, g, 3)}"></div>`;
    });
    // separator, with its handles
    if (L.separator) {
      const s = L.separator;
      html += `<div class="grs-hit sep ${S.sel === "separator" ? "sel" : ""}" data-k="separator" style="left:${pct(s[0], g.cw)};top:calc(${pct(s[1], g.ch)} - 7px);width:${pct(s[2], g.cw)};height:calc(${pct(s[3], g.ch)} + 14px)">
          ${S.sel === "separator" ? `<i class="grs-h ew l" data-h="sepw" data-side="l" title="Width"></i><i class="grs-h ew r" data-h="sepw" data-side="r" title="Width"></i><i class="grs-h ns b" data-h="seph" title="Thickness"></i>` : ""}
        </div>`;
    }
    // XTRAA REELS spots: the icon (or an empty dashed spot) and a tick above it
    const x = L.xtra || {};
    for (const side of ["left", "right"]) {
      const rc = (x.rects || {})[side];
      if (!rc) continue;
      const shown = !!x[side], wanted = !!x["want_" + side];
      html += `<div class="grs-hit xr ${shown ? "on" : "off"} ${S.sel === "xtra" ? "sel" : ""}" data-k="xtra" data-side="${side}" style="${boxCss(rc, g, 2)}">
          ${shown ? "" : `<span class="grs-xr-empty">XTRAA REELS${wanted && !x.asset ? "<br>choose an icon" : ""}</span>`}
          ${S.sel === "xtra" && shown ? `<i class="grs-h corner ${side === "left" ? "rb" : "lb"}" data-h="xrsize" data-side="${side}" title="Size (both icons)"></i>` : ""}
        </div>
        <label class="grs-xr-tick" style="left:${pct(rc[0] + rc[2] / 2, g.cw)};top:${pct(rc[1], g.ch)}" title="Show the XTRAA REELS icon on this side">
          <input type="checkbox" data-xrside="${side}" ${wanted ? "checked" : ""}> show</label>`;
    }
    ov.innerHTML = html + (S.sel ? `<div class="vis-style-bar grs-pop" id="grsPop">${popHtml()}</div>` : "");
    wire(ov, g);
    placePop(g);
  }

  /* ---------- the bar of the selected thing ---------- */
  function fontSelect(key, cur, label) {
    const fonts = (App.state.fonts || []).slice().sort((a, b) => String(a).localeCompare(String(b)));
    if (cur && !fonts.some((f) => String(f).toLowerCase() === String(cur).toLowerCase())) fonts.unshift(cur);
    return `<select class="vsb-font" data-set="${key}" title="${esc(label)}">${[["", label]].concat(fonts.map((f) => [f, f]))
      .map(([v, t]) => `<option value="${esc(v)}" ${String(v).toLowerCase() === String(cur || "").toLowerCase() ? "selected" : ""}>${esc(t)}</option>`).join("")}</select>`;
  }
  function fxSelect(role) {
    const lib = Object.keys(ds().layer_style_library || {}).sort((a, b) => a.localeCompare(b));
    const cur = (ds().style_assignments || {})[role] || "";
    return `<select data-role="${esc(role)}" data-lsswatch title="Layer style">${[["", "None"]].concat(lib.map((n) => [n, n]))
      .map(([v, t]) => `<option value="${esc(v)}" ${v === cur ? "selected" : ""}>${esc(t)}</option>`).join("")}</select>`;
  }
  const num = (key, val, min, max, title) => `<input type="number" class="vsb-num" data-set="${key}" value="${esc(val)}" min="${min}" max="${max}" title="${esc(title)}">`;
  const color = (key, val, title) => `<input type="color" data-set="${key}" value="${esc(val || "#ffffff")}" title="${esc(title)}">`;

  function popHtml() {
    const L = S.layout || {}, sz = L.sizes || {}, d = ds();
    const head = (title, hint) => `<div class="vsb-head"><b>${title}</b>${hint ? `<span class="vsb-hint">${hint}</span>` : ""}<button class="vsb-x" data-close title="Close">✕</button></div>`;
    if (S.sel === "heading") {
      return head("Heading", "same as every page's heading (Canvas)") +
        `<div class="vsb-row">${fontSelect("h_font", App.get("h_font"), "Font")} ${num("h_size", App.get("h_size"), 8, 400, "Size (px)")}<span class="vsb-lab">px</span> ${color("h_rgb", App.get("h_rgb"), "Colour")}</div>
         <div class="vsb-row"><span class="vsb-lab">Layer style</span>${fxSelect(ROLE.heading)}</div>`;
    }
    if (S.sel === "rules") {
      return head("Rules text", L.fit < 0.995 ? `drawn at ${sz.body}px to fit one page` : "the page's paragraph text") +
        `<div class="vsb-row">${fontSelect("b_font", App.get("b_font"), "Font")} ${num("b_size", App.get("b_size"), 6, 300, "Size (px) — same as every page's paragraphs")}<span class="vsb-lab">px</span> ${color("b_rgb", App.get("b_rgb"), "Colour")}</div>
         <div class="vsb-row"><span class="vsb-lab">Layer style</span>${fxSelect(ROLE.rules)}</div>
         <div class="pcp-note">Font, size and colour are the paragraph text of every page (Canvas). Double-click the text to select some, then right-click to put it under the separator.</div>`;
    }
    if (S.sel === "legal") {
      const leg = L.legal || {};
      return head("Legal text", leg.manual ? (leg.off ? "nothing under the separator (your choice)" : `from ${esc(leg.split)} (your choice)`) : `found at “Malfunction…” (${esc(leg.first || "")})`) +
        `<div class="vsb-row">${fontSelect("dynamic_settings.game_rules_bottom_font", d.game_rules_bottom_font || "", "Same font as the rules")} ${num("dynamic_settings.game_rules_bottom_font_size", d.game_rules_bottom_font_size || sz.legal_set || 18, 6, 250, "Size (px)")}<span class="vsb-lab">px</span></div>
         <div class="vsb-row"><span class="vsb-lab">Layer style</span>${fxSelect(ROLE.legal)}</div>
         ${leg.manual ? `<div class="vsb-row"><button class="pt-btn secondary small" data-legalauto>Back to automatic (from “Malfunction…”)</button></div>` : ""}`;
    }
    if (S.sel === "separator") {
      const s = L.separator || [0, 0, 0, 0];
      return head("Separator", "drag its ends for width, its bottom edge for thickness") +
        `<div class="vsb-row">${color("dynamic_settings.game_rules_separator_rgb", d.game_rules_separator_rgb || "#ffffff", "Colour")}
           <span class="vsb-lab">Width</span>${num("dynamic_settings.game_rules_separator_width", Math.round(s[2]), 10, 3000, "Width (px)")}
           <span class="vsb-lab">Thickness</span>${num("dynamic_settings.game_rules_separator_height", Math.round(s[3]), 1, 60, "Thickness (px)")}</div>
         <div class="vsb-row"><span class="vsb-lab">Layer style</span>${fxSelectKey("dynamic_settings.game_rules_separator_fx", d.game_rules_separator_fx || "")}</div>`;
    }
    if (S.sel === "xtra") {
      const x = L.xtra || {};
      return head("XTRAA REELS icons", "both sides are always the same size") +
        `<div class="vsb-row"><span class="vsb-lab">Size</span>${num("dynamic_settings.game_rules_xtra_reels_width", x.width || 100, 10, 2000, "Width of each icon (px)")}<span class="vsb-lab">px</span>
           <span class="vsb-lab">Up / down</span>${num("dynamic_settings.game_rules_xtra_reels_y_offset", d.game_rules_xtra_reels_y_offset || 0, -1000, 1000, "Move both icons up (−) or down (+)")}</div>
         <div class="vsb-row"><label class="vsb-scope"><input type="checkbox" data-xrside="left" ${x.left ? "checked" : ""}> left</label>
           <label class="vsb-scope"><input type="checkbox" data-xrside="right" ${x.right ? "checked" : ""}> right</label>
           <button class="pt-btn secondary small" data-xrauto title="Show them when this page mentions XTRAA REELS">Automatic</button></div>`;
    }
    return "";
  }
  function fxSelectKey(key, cur) {
    const lib = Object.keys(ds().layer_style_library || {}).sort((a, b) => a.localeCompare(b));
    return `<select data-set="${key}" data-lsswatch title="Layer style">${[["", "None"]].concat(lib.map((n) => [n, n]))
      .map(([v, t]) => `<option value="${esc(v)}" ${v === cur ? "selected" : ""}>${esc(t)}</option>`).join("")}</select>`;
  }

  function placePop(g) {
    const pop = el("grsPop"), L = S.layout, page = el("grsPage");
    if (!pop || !L || !page) return;
    let rc = null;
    if (S.sel === "heading") rc = L.heading;
    else if (S.sel === "separator") rc = L.separator;
    else if (S.sel === "xtra") rc = ((L.xtra || {}).rects || {}).left;
    else {
      const ls = (L.lines || []).filter((l) => l.part === S.sel).map((l) => l.rect);
      if (ls.length) rc = [Math.min(...ls.map((r) => r[0])), Math.min(...ls.map((r) => r[1])),
        Math.max(...ls.map((r) => r[0] + r[2])) - Math.min(...ls.map((r) => r[0])), Math.max(...ls.map((r) => r[1] + r[3])) - Math.min(...ls.map((r) => r[1]))];
    }
    if (!rc) return;
    const pw = page.clientWidth, ph = page.clientHeight, h = pop.offsetHeight || 120, w = pop.offsetWidth || 420;
    const top = rc[1] * g.k, bottom = (rc[1] + rc[3]) * g.k;
    pop.style.top = (top - h - 10 >= 4 ? top - h - 10 : Math.min(bottom + 10, Math.max(4, ph - h - 4))) + "px";
    pop.style.left = Math.max(4, Math.min(pw - w - 4, (rc[0] + rc[2] / 2) * g.k - w / 2)) + "px";
  }

  /* ---------- interaction ---------- */
  function wire(ov, g) {
    ov.querySelectorAll(".grs-hit").forEach((n) => n.addEventListener("click", (ev) => {
      if (S.drag && S.drag.moved) return;
      ev.stopPropagation();
      S.sel = n.dataset.k;
      draw();
    }));
    ov.querySelectorAll(".grs-hit.line").forEach((n) => n.addEventListener("dblclick", (ev) => { ev.stopPropagation(); enterTextMode(ev); }));
    ov.querySelectorAll("[data-xrside]").forEach((c) => {
      c.addEventListener("click", (ev) => ev.stopPropagation());
      c.addEventListener("change", () => save(`dynamic_settings.game_rules_xtra_reels_${c.dataset.xrside}`, c.checked, true));
    });
    const pop = el("grsPop");
    if (pop) {
      ["pointerdown", "mousedown", "click", "dblclick"].forEach((t) => pop.addEventListener(t, (ev) => ev.stopPropagation()));
      if (typeof bindForms === "function") { /* plain inputs below, written on change */ }
      pop.querySelector("[data-close]")?.addEventListener("click", () => { S.sel = ""; draw(); });
      pop.querySelectorAll("[data-set]").forEach((c) => c.addEventListener("change", () => {
        const v = c.type === "number" ? Number(c.value) : c.value;
        save(c.dataset.set, v);
      }));
      pop.querySelectorAll("[data-role]").forEach((c) => c.addEventListener("change", () => { App.assignLayerStyle(c.dataset.role, c.value); schedule(); }));
      pop.querySelector("[data-legalauto]")?.addEventListener("click", () => setLegal(null));
      pop.querySelector("[data-xrauto]")?.addEventListener("click", () => {
        delete ds().game_rules_xtra_reels_left;
        delete ds().game_rules_xtra_reels_right;
        App.pushConfig();
        refresh();
      });
      if (window.LSSwatch && LSSwatch.enhance) LSSwatch.enhance(pop);
    }
    ov.querySelectorAll(".grs-guide, .grs-h").forEach((n) => n.addEventListener("pointerdown", (ev) => startDrag(ev, n, g)));
  }

  function toCanvas(ev, g) {
    const r = el("grsImg").getBoundingClientRect();
    return [(ev.clientX - r.left) / r.width * g.cw, (ev.clientY - r.top) / r.height * g.ch];
  }

  function startDrag(ev, n, g) {
    ev.preventDefault();
    ev.stopPropagation();
    const L = S.layout, G = L.guides || {}, x = L.xtra || {};
    const d = { n, g, moved: false, kind: n.dataset.g || n.dataset.h, side: n.dataset.side, start: toCanvas(ev, g), sep: (L.separator || []).slice() };
    S.drag = d;
    try { n.setPointerCapture(ev.pointerId); } catch (_) { /* a pointer that can't be captured: moves still reach it */ }
    const move = (e) => {
      const [px, py] = toCanvas(e, g);
      d.moved = d.moved || Math.abs(px - d.start[0]) + Math.abs(py - d.start[1]) > 2;
      const m = d.side === "r" ? g.cw - px : px;                       // distance from its own page edge
      let show = null;
      switch (d.kind) {
        case "top": d.val = Math.max(0, Math.round(py)); show = d.val; break;
        case "gap": d.val = Math.max(0, Math.round(py - G.heading_bottom)); show = G.heading_bottom + d.val; break;
        case "bottom": d.val = Math.max(0, Math.round(g.ch - py)); show = g.ch - d.val; break;
        case "text": d.val = Math.max(G.margin_x || 0, Math.round(m)); show = d.val; break;
        case "legal": d.val = Math.max(0, Math.round(m)); show = d.val; break;
        case "xouter": d.val = Math.max(0, Math.round(m)); show = d.val; break;
        case "sepw": d.val = Math.max(20, Math.round(d.sep[2] + 2 * (d.side === "l" ? d.start[0] - px : px - d.start[0]))); break;
        case "seph": d.val = Math.max(1, Math.round(d.sep[3] + (py - d.start[1]))); break;
        case "xrsize": d.val = Math.max(10, Math.round((x.width || 100) + (d.side === "left" ? px - d.start[0] : d.start[0] - px))); break;
      }
      if (show != null && n.classList.contains("grs-guide")) {
        // move both lines of a mirrored pair together
        el("grsOv").querySelectorAll(`.grs-guide[data-g="${d.kind}"]`).forEach((line) => {
          if (line.classList.contains("vis-guide-h")) line.style.top = pct(show, g.ch);
          else line.style.left = pct(line.dataset.side === "r" ? g.cw - show : show, g.cw);
        });
      }
      if (d.kind === "sepw" || d.kind === "seph") showSize(n, d.kind === "sepw" ? `${d.val}px wide` : `${d.val}px thick`);
      if (d.kind === "xrsize") showSize(n, `${d.val}px`);
    };
    const up = () => {
      n.removeEventListener("pointermove", move);
      n.removeEventListener("pointerup", up);
      setTimeout(() => { S.drag = null; }, 0);
      if (!d.moved || d.val == null) return;
      const key = {
        top: "heading_top_margin", gap: "heading_to_body_gap", bottom: "bottom_margin",
        legal: "dynamic_settings.game_rules_malfunction_lr_margin", xouter: "dynamic_settings.game_rules_xtra_reels_outer_margin",
        sepw: "dynamic_settings.game_rules_separator_width", seph: "dynamic_settings.game_rules_separator_height",
        xrsize: "dynamic_settings.game_rules_xtra_reels_width",
      }[d.kind];
      if (d.kind === "text") {
        // with XTRAA REELS the text edge is the icons' clearance, else the text's own side margin
        if (x.left || x.right) save("dynamic_settings.game_rules_xtra_reels_text_gap", Math.max(0, d.val - (x.outer || 0) - (x.width || 0)), true);
        else save("dynamic_settings.game_rules_bottom_lr_margin", d.val, true);
        return;
      }
      if (key) save(key, d.val, true);
    };
    n.addEventListener("pointermove", move);
    n.addEventListener("pointerup", up);
  }

  function showSize(n, text) {
    let t = n.querySelector(".grs-size");
    if (!t) { t = document.createElement("span"); t.className = "grs-size"; n.appendChild(t); }
    t.textContent = text;
  }

  /* ---------- the legal text: where it starts ---------- */
  // overrides are lines "Sheet=Cell" (the last line of a sheet wins); "Sheet=none" = nothing under it
  function setLegal(value) {
    const d = ds();
    const mine = (line) => {
      const i = line.search(/[=|]/);
      return i > 0 && line.slice(0, i).trim().toLowerCase() === S.sheet.toLowerCase();
    };
    const lines = String(d.game_rules_legal_split_overrides || "").split(/[\n;]+/).map((l) => l.trim()).filter((l) => l && !mine(l));
    if (value) lines.push(`${S.sheet}=${value}`);
    d.game_rules_legal_split_overrides = lines.join("\n");
    App.pushConfig();
    refresh();
  }

  /* ---------- text mode: select the text like a document ---------- */
  function enterTextMode() {
    exitTextMode();
    const L = S.layout, g = geo(), page = el("grsPage");
    if (!L || !g || !page) return;
    S.textMode = true;
    const layer = document.createElement("div");
    layer.className = "tsel-layer grs-tsel";
    Object.assign(layer.style, { left: "0", top: "0", width: "100%", height: "100%" });
    layer.innerHTML = (L.lines || []).map((ln, i) => {
      const r = ln.rect;
      return `<div class="tsel-line" data-i="${i}"><span class="tsel-w grs-tw" data-i="${i}" style="${boxCss(r, g)};font-size:${Math.max(6, r[3] * g.k * 0.8)}px;line-height:${r[3] * g.k}px">${esc(ln.text.replace(/<[^<>]+>/g, "▢"))}</span><span class="tsel-gap">\n</span></div>`;
    }).join("") + `<div class="tsel-hint">Select text · right-click it to put it under the separator · Esc to finish</div>`;
    page.appendChild(layer);
    ["mousedown", "pointerdown", "click", "dblclick"].forEach((t) => layer.addEventListener(t, (ev) => ev.stopPropagation()));
    layer.addEventListener("contextmenu", (ev) => { ev.preventDefault(); ev.stopPropagation(); textMenu(ev); });
  }
  function exitTextMode() {
    S.textMode = false;
    document.querySelectorAll(".grs-tsel, .grs-menu").forEach((n) => n.remove());
  }
  function selectedLines() {
    const sel = window.getSelection();
    if (!sel || sel.isCollapsed) return [];
    return [...document.querySelectorAll(".grs-tsel .grs-tw")].filter((w) => sel.containsNode(w, true)).map((w) => Number(w.dataset.i));
  }
  function textMenu(ev) {
    document.querySelectorAll(".grs-menu").forEach((n) => n.remove());
    const L = S.layout, picked = selectedLines(), lines = L.lines || [];
    const page = el("grsPage"), pr = page.getBoundingClientRect();
    const rules = picked.filter((i) => lines[i].part === "rules"), legal = picked.filter((i) => lines[i].part === "legal");
    // the Excel cells the selection is in, in page order; the first selected line starts its cell?
    const cells = [...new Set(picked.slice().sort((a, b) => a - b).map((i) => lines[i].cell))];
    const firstOfCell = picked.length && lines.findIndex((l) => l.cell === lines[Math.min(...picked)].cell) === Math.min(...picked);
    const menu = document.createElement("div");
    menu.className = "tsel-menu grs-menu";
    menu.innerHTML = !picked.length ? `<div class="tsel-mnote">Select some text first</div><button data-m="done">Finish (Esc)</button>`
      : `${rules.length ? `<button data-m="under">Put under the separator (from here on)</button>` : ""}
         ${legal.length ? `<button data-m="above">Move back above the separator</button>` : ""}
         ${(L.legal || {}).manual ? `<button data-m="auto">Automatic (from “Malfunction…”)</button>` : ""}
         <div class="tsel-msep"></div>
         ${cells.length === 1 && !firstOfCell ? `<button data-m="break">Start a new line here</button>` : ""}
         ${cells.length > 1 || /\n/.test(cellText(cells[0])) ? `<button data-m="join">Join ${cells.length > 1 ? "these lines" : "the lines of this text"}</button>` : ""}
         <button data-m="edit">Edit text…</button>
         ${cells.some((c) => TextEdits.get(S.sheet, c)) ? `<button data-m="excel">Back to the Excel text</button>` : ""}
         <div class="tsel-msep"></div><button data-m="done">Finish (Esc)</button>`;
    page.appendChild(menu);
    Object.assign(menu.style, { left: Math.min(pr.width - menu.offsetWidth - 6, ev.clientX - pr.left) + "px",
                                top: Math.min(pr.height - menu.offsetHeight - 6, ev.clientY - pr.top) + "px" });
    ["mousedown", "pointerdown", "click"].forEach((t) => menu.addEventListener(t, (e2) => e2.stopPropagation()));
    menu.querySelectorAll("[data-m]").forEach((b) => b.addEventListener("click", () => {
      const m = b.dataset.m;
      exitTextMode();
      if (m === "under") {
        // the legal text starts at the first selected line's cell: it and everything after it
        setLegal(lines[Math.min(...rules)].cell);
        toast(`From “${lines[Math.min(...rules)].text.slice(0, 40)}…” on, the text sits under the separator.`);
      } else if (m === "above") {
        // the legal text now starts after the last selected line (nothing left: none under it)
        const last = Math.max(...legal);
        const cellOf = lines[last].cell;
        const next = lines.slice(last + 1).find((l) => l.part === "legal" && l.cell !== cellOf);
        setLegal(next ? next.cell : "none");
        toast(next ? `The legal text now starts at “${next.text.slice(0, 40)}…”.` : "Nothing sits under the separator now.");
      } else if (m === "auto") setLegal(null);
      else editCells(m, cells, picked);
    }));
  }

  const cellText = (cell) => String(((S.layout || {}).cells || {})[cell] || "");

  /* line breaks / joins / retyping, kept per Excel cell (TextEdits; never written to the Excel) */
  async function editCells(m, cells, picked) {
    const lines = (S.layout || {}).lines || [], first = cells[0];
    if (!first) return;
    const text = cellText(first);
    if (m === "break") {
      // a new line where the first selected (wrapped) line starts
      const i = Math.min(...picked);
      let pos = 0;
      for (const l of lines) {
        if (l === lines[i]) break;
        if (l.cell !== first) continue;
        const at = text.indexOf(l.text.trim(), pos);
        if (at >= 0) pos = at + l.text.trim().length;
      }
      const at = text.indexOf(lines[i].text.trim(), pos);
      if (at <= 0) { toast("That is already the start of the line."); return; }
      TextEdits.put(S.sheet, first, text, text.slice(0, at).replace(/\s+$/, "") + "\n" + text.slice(at));
    } else if (m === "join") {
      if (cells.length === 1) TextEdits.put(S.sheet, first, text, text.replace(/\s*\n\s*/g, " "));
      else {
        TextEdits.put(S.sheet, first, text, cells.map((c) => cellText(c).replace(/\s*\n\s*/g, " ").trim()).join(" "), { joined: cells.slice(1) });
        cells.slice(1).forEach((c) => TextEdits.put(S.sheet, c, cellText(c), ""));
      }
    } else if (m === "edit") {
      const next = await TextEdits.editor("Edit the text", text);
      if (next == null) return;
      TextEdits.put(S.sheet, first, text, next.replace(/\r/g, ""));
    } else if (m === "excel") {
      TextEdits.clear(S.sheet, cells);
    } else return;
    await TextEdits.save();
    refresh();
  }

  /* ---------- wiring ---------- */
  function init() {
    el("grsSheet")?.addEventListener("change", (e) => { S.sheet = e.target.value; App.state.grSheetName = S.sheet; S.sel = ""; refresh(); });
    el("grsOn")?.addEventListener("change", (e) => { App.set("render_game_rules", e.target.checked); App.pushConfig(); });
    el("grsRefresh")?.addEventListener("click", () => refresh());
    document.querySelectorAll("[data-xrbar]").forEach((c) => c.addEventListener("change", () =>
      save(`dynamic_settings.game_rules_xtra_reels_${c.dataset.xrbar}`, c.checked, true)));
    el("grsXrPick")?.addEventListener("click", () => App.browse("dynamic_settings.game_rules_xtra_reels_asset", "file"));
    const stage = el("grsStage");
    stage?.addEventListener("click", () => { if (S.sel) { S.sel = ""; draw(); } });
    const img = el("grsImg");
    if (img) img.addEventListener("load", draw);
    refresh();
  }

  document.addEventListener("keydown", (ev) => {
    if (App.route !== "gamerules" || ev.key !== "Escape") return;
    if (S.textMode) exitTextMode();
    else if (S.sel) { S.sel = ""; draw(); }
  });
  window.addEventListener("resize", () => { if (App.route === "gamerules") draw(); });

  return { view, init, refresh, schedule, get state() { return S; } };
})();
