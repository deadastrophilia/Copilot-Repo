/*
 * ps_fx_canvas.js — Photoshop layer styles for the LIVE canvas, no Photoshop.
 *
 * 1:1 port of ps_autotypesetter/ps_fx_png.py (same pipeline, same math:
 * windowed exact distance field, 3-pass box blur, W3C blend formulas), so the
 * live window, the PNG output and the Photoshop "verify" render agree. Keep
 * the two files in step: every function here has a same-named twin there.
 *
 * Paint order (bottom -> top):
 *   drop shadows -> outer glows -> outside strokes -> layer fill ->
 *   gradient overlays -> colour overlays -> satin -> inner glows ->
 *   inner shadows -> centre / inside strokes -> bevel & emboss
 * Each effect kind may be a list; index 0 is top-most (painted last).
 *
 * The descriptor bytes (captured_effects_hex) are decoded on the server
 * (fx_descriptor.enrich_style) into captured_params before they get here.
 *
 *   PsFx.normalize(raw)                       -> normalized params
 *   PsFx.effectPad(N)                         -> px the effects reach
 *   PsFx.renderImageData(imageData, raw, bounds?, backdropImageData?) -> ImageData
 */
(function (root) {
  "use strict";

  const EFFECT_LISTS = [
    "drop_shadows", "outer_glows", "inner_shadows", "inner_glows", "strokes",
    "color_overlays", "gradient_overlays", "satins", "bevels", "pattern_overlays",
  ];

  /* ------------------------------------------------------------ normalize */

  function num(v, fb) {
    if (v === null || v === undefined || v === "" || typeof v === "boolean" || typeof v === "object") return fb;
    const n = Number(v);
    return isFinite(n) ? n : fb;
  }
  function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }
  function rgb(v, fb) {
    if (Array.isArray(v) && v.length >= 3) return v.slice(0, 3).map((c) => clamp(Math.round(num(c, 0)), 0, 255));
    if (typeof v === "string") {
      const m = /^#?([0-9a-f]{6})$/i.exec(v.trim());
      if (m) { const n = parseInt(m[1], 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
    }
    return fb.slice();
  }

  const BLEND_SHORT = {
    NRML: "normal", NORM: "normal", MLTP: "multiply", MULT: "multiply",
    SCRN: "screen", SCRE: "screen", OVRL: "overlay", OVER: "overlay",
    SFTL: "soft-light", SOFT: "soft-light", HRDL: "hard-light", HARD: "hard-light",
    CDDG: "color-dodge", DODG: "color-dodge", CBRN: "color-burn", BURN: "color-burn",
    LNRD: "linear-dodge", LIGH: "linear-dodge", LNRB: "linear-burn",
    DFRN: "difference", DIFF: "difference", XCLU: "exclusion", EXCL: "exclusion",
    DRKN: "darken", LGHN: "lighten",
  };
  const BLEND_LONG = {
    normal: "normal", "source-over": "normal", dissolve: "normal",
    multiply: "multiply", screen: "screen", overlay: "overlay",
    "soft light": "soft-light", "soft-light": "soft-light",
    "hard light": "hard-light", "hard-light": "hard-light",
    "color dodge": "color-dodge", "color-dodge": "color-dodge",
    "color burn": "color-burn", "color-burn": "color-burn",
    "linear dodge": "linear-dodge", "linear-dodge": "linear-dodge", lighter: "linear-dodge",
    add: "linear-dodge", "linear burn": "linear-burn", "linear-burn": "linear-burn",
    darken: "darken", lighten: "lighten", difference: "difference",
    exclusion: "exclusion", "vivid light": "vivid-light", "vivid-light": "vivid-light",
    "linear light": "linear-light", "linear-light": "linear-light",
    "pin light": "pin-light", "pin-light": "pin-light", "hard mix": "hard-mix",
    "hard-mix": "hard-mix", subtract: "subtract", divide: "divide",
  };
  function blendCode(v) {
    if (typeof v !== "string") return "normal";
    const up = v.trim().toUpperCase();
    if (BLEND_SHORT[up]) return BLEND_SHORT[up];
    return BLEND_LONG[v.trim().toLowerCase()] || "normal";
  }
  function enabled(e) { return !!(e && e.enabled); }
  function strokePos(v) {
    const s = String(v || "outside").trim().toLowerCase();
    if (s === "center" || s === "cntf" || s === "ctrf" || s === "centre") return "center";
    if (s === "inside" || s === "insf") return "inside";
    return "outside";
  }
  function asList(v) {
    if (Array.isArray(v)) return v.filter((x) => x && typeof x === "object" && !Array.isArray(x));
    if (v && typeof v === "object") return [v];
    return [];
  }
  function op01(v, fb) { return clamp(num(v, fb), 0, 100) / 100; }
  function contour(v) {
    if (!Array.isArray(v) || v.length < 2) return null;
    const pts = [];
    for (const p of v) if (Array.isArray(p) && p.length >= 2) pts.push([clamp(num(p[0], 0), 0, 255), clamp(num(p[1], 0), 0, 255)]);
    pts.sort((a, b) => a[0] - b[0]);
    return pts.length >= 2 ? pts : null;
  }
  function stops(colors) {
    const out = [];
    for (const s of colors || []) {
      if (Array.isArray(s) && s.length >= 2) {
        const mid = s.length >= 3 ? num(s[2], 50) : 50;
        out.push([rgb(s[0], [255, 0, 0]), clamp(num(s[1], 0), 0, 100) / 100, clamp(mid, 1, 99) / 100]);
      }
    }
    out.sort((a, b) => a[1] - b[1]);
    return out.length ? out : [[[0, 0, 0], 0, 0.5], [[255, 255, 255], 1, 0.5]];
  }
  function transStops(trans) {
    const out = [];
    for (const s of trans || []) {
      if (Array.isArray(s) && s.length >= 2) {
        const mid = s.length >= 3 ? num(s[2], 50) : 50;
        out.push([clamp(num(s[0], 100), 0, 100) / 100, clamp(num(s[1], 0), 0, 100) / 100, clamp(mid, 1, 99) / 100]);
      }
    }
    out.sort((a, b) => a[1] - b[1]);
    if (!out.length || out.every((s) => Math.abs(s[0] - 1) < 1e-6)) return null;
    return out;
  }
  function normGradient(g, defAngle) {
    if (defAngle === undefined) defAngle = 90;
    let type = String(g.type || "linear").trim().toLowerCase().replace(/ /g, "_");
    if (["linear", "radial", "angle", "reflected", "diamond", "shape_burst"].indexOf(type) < 0) type = "linear";
    const off = Array.isArray(g.offset) ? g.offset : [0, 0];
    return {
      stops: stops(g.colors), trans: transStops(g.transparency), type: type,
      angle: num(g.angle !== undefined ? g.angle : defAngle, defAngle),
      scale: Math.max(0.01, num(g.scale !== undefined ? g.scale : 100, 100) / 100),
      reverse: !!g.reverse,
      offset: [num(off.length > 0 ? off[0] : 0, 0), num(off.length > 1 ? off[1] : 0, 0)],
      smooth: clamp(num(pick(g, "smoothness", null, 0), 0), 0, 100) / 100,
    };
  }
  function pick(e, key, alt, fb) { return e[key] !== undefined ? e[key] : (alt && e[alt] !== undefined ? e[alt] : fb); }
  function normShadow(e, inner) {
    return {
      enabled: enabled(e), color: rgb(e.color, [0, 0, 0]),
      opacity: op01(pick(e, "opacity", null, inner ? 50 : 75), inner ? 50 : 75),
      angle: num(pick(e, "angle", null, 120), 120),
      distance: num(pick(e, "distance", null, inner ? 5 : 8), inner ? 5 : 8),
      size: Math.max(0, num(pick(e, "size", null, inner ? 5 : 12), inner ? 5 : 12)),
      spread: clamp(num(pick(e, "spread", "choke", 0), 0), 0, 100),
      blend: blendCode(e.blend), contour: contour(e.contour), knockout: e.knockout !== false,
    };
  }
  function normGlow(e, inner) {
    return {
      enabled: enabled(e), color: rgb(e.color, inner ? [255, 255, 255] : [255, 255, 190]),
      opacity: op01(pick(e, "opacity", null, inner ? 50 : 66), inner ? 50 : 66),
      size: Math.max(0, num(pick(e, "size", null, inner ? 8 : 18), inner ? 8 : 18)),
      spread: clamp(num(pick(e, "spread", "choke", 0), 0), 0, 100),
      blend: blendCode(e.blend), contour: contour(e.contour),
      range: clamp(num(pick(e, "range", null, 50), 50), 1, 100) / 100,
      source: String(e.source || "").toLowerCase() === "center" ? "center" : "edge",
    };
  }
  function normStroke(e) {
    const out = {
      enabled: enabled(e), color: rgb(e.color, [255, 255, 255]),
      opacity: op01(pick(e, "opacity", null, 100), 100),
      size: Math.max(0, num(pick(e, "size", null, 3), 3)), position: strokePos(e.position),
      blend: blendCode(e.blend), gradient: null,
    };
    if (String(e.fill_type || "").toLowerCase() === "gradient" && e.gradient && typeof e.gradient === "object") {
      out.gradient = normGradient(e.gradient);
    }
    return out;
  }
  function normBevel(e) {
    let style = String(e.style || "inner").toLowerCase();
    if (["inner", "outer", "emboss", "pillow", "stroke"].indexOf(style) < 0) style = "inner";
    let tech = String(e.technique || "smooth").toLowerCase();
    if (["smooth", "chisel_hard", "chisel_soft"].indexOf(tech) < 0) tech = "smooth";
    return {
      enabled: enabled(e), style: style, technique: tech,
      depth: clamp(num(pick(e, "depth", null, 100), 100), 1, 1000) / 100,
      direction: String(e.direction || "").toLowerCase() === "down" ? "down" : "up",
      size: Math.max(0, num(pick(e, "size", null, 5), 5)), soften: Math.max(0, num(pick(e, "soften", null, 0), 0)),
      angle: num(pick(e, "angle", null, 120), 120), altitude: clamp(num(pick(e, "altitude", null, 30), 30), 0, 90),
      highlight_color: rgb(e.highlight_color, [255, 255, 255]),
      highlight_opacity: op01(pick(e, "highlight_opacity", null, 75), 75),
      highlight_blend: blendCode(pick(e, "highlight_blend", null, "screen")),
      shadow_color: rgb(e.shadow_color, [0, 0, 0]),
      shadow_opacity: op01(pick(e, "shadow_opacity", null, 75), 75),
      shadow_blend: blendCode(pick(e, "shadow_blend", null, "multiply")),
      contour: contour(e.gloss_contour),
    };
  }
  function normSatin(e) {
    return {
      enabled: enabled(e), color: rgb(e.color, [0, 0, 0]),
      opacity: op01(pick(e, "opacity", null, 50), 50), blend: blendCode(pick(e, "blend", null, "multiply")),
      angle: num(pick(e, "angle", null, 19), 19), distance: num(pick(e, "distance", null, 11), 11),
      size: Math.max(0, num(pick(e, "size", null, 14), 14)), invert: e.invert !== false,
      contour: contour(e.contour),
    };
  }
  function sourceParams(raw) {
    if (!raw || typeof raw !== "object") return {};
    if (raw.captured_params && typeof raw.captured_params === "object") return Object.assign({}, raw, raw.captured_params);
    return raw;
  }

  /* the project's Global Light (global_light.py): drop / inner shadows and bevels with "Use Global
     Light" take its angle (a bevel its altitude too) — as Photoshop draws them in the document */
  let globalLight = null;
  function setGlobalLight(l) { globalLight = l || null; }
  function cleanLight(v) {
    if (!v || typeof v !== "object" || !isFinite(Number(v.angle)) || v.angle === null || v.angle === "") return null;
    const a = ((Number(v.angle) + 180) % 360 + 360) % 360 - 180;
    const alt = isFinite(Number(v.altitude)) && v.altitude !== null && v.altitude !== "" ? clamp(Number(v.altitude), 0, 90) : 30;
    return { angle: a, altitude: alt };
  }
  function currentLight() {
    if (globalLight) return cleanLight(globalLight);
    // app.js's App is a top-level const (not a window property); none under Node
    const app = typeof App !== "undefined" ? App : root.App;   // eslint-disable-line no-undef
    const ds = app && app.state && app.state.config && app.state.config.dynamic_settings;
    return ds ? cleanLight(ds.fx_global_light) : null;
  }
  const LIGHT_KINDS = { drop_shadow: ["angle"], inner_shadow: ["angle"], bevel: ["angle", "altitude"] };
  function applyGlobalLight(src, light) {
    light = light === undefined ? currentLight() : cleanLight(light);
    if (!light || !src || typeof src !== "object") return src;
    let out = null;
    for (const kind of Object.keys(LIGHT_KINDS)) {
      const eff = src[kind], items = Array.isArray(eff) ? eff : [eff];
      if (!items.some((e) => e && typeof e === "object" && e.use_global_light)) continue;
      const fixed = items.map((e) => {
        if (!(e && typeof e === "object" && e.use_global_light)) return e;
        const c = Object.assign({}, e);
        LIGHT_KINDS[kind].forEach((k) => { c[k] = light[k]; });
        return c;
      });
      out = out || Object.assign({}, src);
      out[kind] = Array.isArray(eff) ? fixed : fixed[0];
    }
    return out || src;
  }

  /* fx_scale.py, 1:1: a style's lengths follow the text size. fx_base_size = the text size (px) it
     was copied at; fx_scale_mode "proportional" (× size ÷ base) / "original" / "custom" (× pct / 100).
     Lengths only (stroke, shadow / glow / satin distance & size, bevel size & soften), whole px half up,
     above 0 stays ≥ 1; the copy is marked "original" so it is never scaled twice. */
  const SCALE_LENGTHS = {
    drop_shadow: ["distance", "size"], inner_shadow: ["distance", "size"],
    outer_glow: ["size"], inner_glow: ["size"], stroke: ["size"],
    bevel: ["size", "soften"], satin: ["distance", "size"],
  };
  const SCALE_FLAT = ["stroke_size", "shadow_distance", "shadow_size"];
  const SCALE_MODES = ["proportional", "original", "custom"];
  function finiteNum(v) {
    if (v === null || v === undefined || v === "" || typeof v === "object") return null;
    const f = Number(v);
    return isFinite(f) ? f : null;
  }
  function scaleBase(cfg) {
    const b = cfg && typeof cfg === "object" ? finiteNum(cfg.fx_base_size) : null;
    return b && b > 0 ? b : null;
  }
  function scaleMode(cfg) {
    if (!cfg || typeof cfg !== "object") return "original";
    const m = String(cfg.fx_scale_mode || "").trim().toLowerCase();
    if (SCALE_MODES.indexOf(m) >= 0) return m;
    return scaleBase(cfg) ? "proportional" : "original";
  }
  function scaleFactor(cfg, size) {
    const m = scaleMode(cfg);
    if (m === "custom") {
      const pct = finiteNum(cfg.fx_scale_pct);
      return pct !== null && pct > 0 ? pct / 100 : 1;
    }
    if (m === "proportional") {
      const b = scaleBase(cfg), s = finiteNum(size);
      if (b && s && s > 0) return s / b;
    }
    return 1;
  }
  function scaleLength(v, f) {
    const n = finiteNum(v);
    if (n === null) return v;
    let out = Math.floor(n * f + 0.5);
    if (n > 0 && out < 1) out = 1;
    return out;
  }
  function scaleEffect(e, keys, f) {
    if (!e || typeof e !== "object" || Array.isArray(e)) return e;
    const out = Object.assign({}, e);
    keys.forEach((k) => { if (k in out) out[k] = scaleLength(out[k], f); });
    return out;
  }
  function scaleParams(params, f) {
    if (!params || typeof params !== "object" || f === 1) return params;
    const out = Object.assign({}, params);
    for (const kind of Object.keys(SCALE_LENGTHS)) {
      const eff = out[kind];
      if (Array.isArray(eff)) out[kind] = eff.map((e) => scaleEffect(e, SCALE_LENGTHS[kind], f));
      else if (eff && typeof eff === "object") out[kind] = scaleEffect(eff, SCALE_LENGTHS[kind], f);
    }
    SCALE_FLAT.forEach((k) => { if (k in out) out[k] = scaleLength(out[k], f); });
    return out;
  }
  function scaleFor(cfg, size) {
    if (!cfg || typeof cfg !== "object") return cfg;
    const f = scaleFactor(cfg, size);
    if (Math.abs(f - 1) < 1e-9) return cfg;
    const out = Object.assign({}, cfg);
    if (out.captured_params && typeof out.captured_params === "object") out.captured_params = scaleParams(out.captured_params, f);
    SCALE_FLAT.forEach((k) => { if (k in out) out[k] = scaleLength(out[k], f); });
    out.fx_scale_mode = "original";
    out.fx_applied_scale = f;
    return out;
  }

  function normalize(raw) {
    const N = { opacity: 1, fill_opacity: 1, fill_enabled: true, has_fx: false };
    for (const k of EFFECT_LISTS) N[k] = [];
    const src = applyGlobalLight(sourceParams(raw));
    if (Object.keys(src).length) {
      N.opacity = op01(pick(src, "opacity", null, 100), 100);
      N.fill_opacity = op01(pick(src, "fill_opacity", null, 100), 100);
      N.fill_enabled = src.is_fill_enabled !== false;
      N.drop_shadows = asList(src.drop_shadow).map((e) => normShadow(e, false));
      N.inner_shadows = asList(src.inner_shadow).map((e) => normShadow(e, true));
      N.outer_glows = asList(src.outer_glow).map((e) => normGlow(e, false));
      N.inner_glows = asList(src.inner_glow).map((e) => normGlow(e, true));
      N.strokes = asList(src.stroke).map(normStroke);
      N.color_overlays = asList(src.color_overlay).map((e) => ({
        enabled: enabled(e), color: rgb(e.color, [255, 0, 0]),
        opacity: op01(pick(e, "opacity", null, 100), 100), blend: blendCode(e.blend),
      }));
      N.gradient_overlays = asList(src.gradient_overlay).map((e) => Object.assign(normGradient(e), {
        enabled: enabled(e), opacity: op01(pick(e, "opacity", null, 100), 100), blend: blendCode(e.blend),
      }));
      N.satins = asList(src.satin).map(normSatin);
      N.bevels = asList(src.bevel).map(normBevel);
      if (!N.drop_shadows.length && src.shadow_enabled !== undefined && src.shadow_enabled !== null) {
        N.drop_shadows = [{
          enabled: !!src.shadow_enabled, color: rgb(src.shadow_rgb, [0, 0, 0]),
          opacity: op01(pick(src, "shadow_opacity", null, 60), 60),
          angle: num(pick(src, "shadow_angle", null, 120), 120),
          distance: num(pick(src, "shadow_distance", null, 8), 8),
          size: Math.max(0, num(pick(src, "shadow_size", null, 12), 12)),
          spread: clamp(num(pick(src, "shadow_spread", null, 0), 0), 0, 100),
          blend: blendCode(src.shadow_blend_mode), contour: null, knockout: true,
        }];
      }
      if (!N.strokes.length && src.stroke_enabled !== undefined && src.stroke_enabled !== null) {
        N.strokes = [{
          enabled: !!src.stroke_enabled, color: rgb(src.stroke_rgb, [255, 255, 255]),
          opacity: op01(pick(src, "stroke_opacity", null, 100), 100),
          size: Math.max(0, num(pick(src, "stroke_size", null, 3), 3)), position: "outside",
          blend: "normal", gradient: null,
        }];
      }
    }
    for (const k of EFFECT_LISTS) N[k] = N[k].filter(enabled);
    N.has_fx = EFFECT_LISTS.some((k) => k !== "pattern_overlays" && N[k].length > 0);
    return N;
  }

  function effectPad(N) {
    let pad = 2;
    for (const e of N.drop_shadows) pad = Math.max(pad, Math.abs(e.distance) + e.size + 2);
    for (const e of N.outer_glows) pad = Math.max(pad, e.size + 2);
    for (const e of N.strokes) if (e.position !== "inside") pad = Math.max(pad, e.size + 2);
    for (const e of N.bevels) if (e.style !== "inner") pad = Math.max(pad, e.size + 2);
    return Math.ceil(Math.min(pad, 400));
  }

  function distanceReach(N) {
    let r = 0;
    for (const e of N.drop_shadows.concat(N.outer_glows, N.inner_shadows, N.inner_glows)) r = Math.max(r, e.size * e.spread / 100);
    for (const e of N.strokes) r = Math.max(r, e.size);
    for (const e of N.bevels) r = Math.max(r, e.size);
    return r > 0 ? Math.ceil(Math.min(r, 400)) + 2 : 0;
  }

  /* ------------------------------------------------------------ primitives */

  // Calibration against Photoshop (tools/fx_fidelity_harness.py) — same
  // numbers as ps_fx_png.py.
  const BEVEL_SLOPE = 1.0, BEVEL_HI_GAIN = 1.0, BEVEL_LO_GAIN = 1.0;
  const SMOOTH_SIGMA = 0.35, CHISEL_SLOPE = 0.5, CHISEL_BLUR = 1.0;
  const EMBOSS_REACH = 0.5, EMBOSS_SLOPE = 0.5, GRADIENT_TANGENT = 0.5;

  function round(x) { return Math.floor(x + 0.5); }
  function sizeSigma(size) { return size > 0 ? 0.4 * size + 0.3 : 0; }

  function boxRadii(sigma, n) {
    n = n || 3;
    const wIdeal = Math.sqrt(12 * sigma * sigma / n + 1);
    let wl = Math.floor(wIdeal);
    if (wl % 2 === 0) wl -= 1;
    const wu = wl + 2;
    const m = round((12 * sigma * sigma - n * wl * wl - 4 * n * wl - 3 * n) / (-4 * wl - 4));
    const out = [];
    for (let i = 0; i < n; i++) out.push(((i < m ? wl : wu) - 1) >> 1);
    return out;
  }

  function boxH(a, w, h, r) {
    const out = new Float32Array(w * h);
    const k = 2 * r + 1;
    for (let y = 0; y < h; y++) {
      const row = y * w;
      let s = 0;
      for (let x = 0; x <= r && x < w; x++) s += a[row + x];
      for (let x = 0; x < w; x++) {
        out[row + x] = s / k;
        const add = x + r + 1, sub = x - r;
        if (add < w) s += a[row + add];
        if (sub >= 0) s -= a[row + sub];
      }
    }
    return out;
  }
  function boxV(a, w, h, r) {
    const out = new Float32Array(w * h);
    const k = 2 * r + 1;
    for (let x = 0; x < w; x++) {
      let s = 0;
      for (let y = 0; y <= r && y < h; y++) s += a[y * w + x];
      for (let y = 0; y < h; y++) {
        out[y * w + x] = s / k;
        const add = y + r + 1, sub = y - r;
        if (add < h) s += a[add * w + x];
        if (sub >= 0) s -= a[sub * w + x];
      }
    }
    return out;
  }
  function blur(a, w, h, sigma) {
    if (sigma < 0.3) return a;
    let out = a;
    for (const r of boxRadii(sigma)) {
      if (r > 0) { out = boxH(out, w, h, r); out = boxV(out, w, h, r); }
    }
    return out;
  }

  function shift(a, w, h, dx, dy, fill) {
    if (dx === 0 && dy === 0) return a;
    const out = new Float32Array(w * h).fill(fill);
    if (Math.abs(dx) >= w || Math.abs(dy) >= h) return out;
    for (let y = 0; y < h; y++) {
      const sy = y - dy;
      if (sy < 0 || sy >= h) continue;
      const x0 = Math.max(0, dx), x1 = Math.min(w, w + dx);
      for (let x = x0; x < x1; x++) out[y * w + x] = a[sy * w + x - dx];
    }
    return out;
  }

  /* Exact Euclidean distance to the nearest seed (capped at R + 1); with
     `value`, also the value of that seed. Pass order and strict "<" tie
     handling match ps_fx_png._edt exactly. */
  function edt(seed, w, h, R, value) {
    const big = (R + 1) * (R + 1), n = w * h;
    const f = new Float32Array(n), fv = value ? new Float32Array(n) : null;
    for (let i = 0; i < n; i++) { f[i] = seed[i] ? 0 : big; if (fv) fv[i] = seed[i] ? value[i] : 0; }
    const g = Float32Array.from(f), gv = fv ? Float32Array.from(fv) : null;
    for (let d = 1; d <= R; d++) {
      const dd = d * d;
      for (let y = 0; y < h; y++) {
        const row = y * w;
        for (let x = d; x < w; x++) {
          const c = f[row + x - d] + dd;
          if (c < g[row + x]) { g[row + x] = c; if (gv) gv[row + x] = fv[row + x - d]; }
        }
        for (let x = 0; x < w - d; x++) {
          const c = f[row + x + d] + dd;
          if (c < g[row + x]) { g[row + x] = c; if (gv) gv[row + x] = fv[row + x + d]; }
        }
      }
    }
    const hh = Float32Array.from(g), hv = gv ? Float32Array.from(gv) : null;
    for (let d = 1; d <= R; d++) {
      const dd = d * d;
      for (let y = d; y < h; y++) {
        const row = y * w, src = (y - d) * w;
        for (let x = 0; x < w; x++) {
          const c = g[src + x] + dd;
          if (c < hh[row + x]) { hh[row + x] = c; if (hv) hv[row + x] = gv[src + x]; }
        }
      }
      for (let y = 0; y < h - d; y++) {
        const row = y * w, src = (y + d) * w;
        for (let x = 0; x < w; x++) {
          const c = g[src + x] + dd;
          if (c < hh[row + x]) { hh[row + x] = c; if (hv) hv[row + x] = gv[src + x]; }
        }
      }
    }
    const dist = new Float32Array(n);
    for (let i = 0; i < n; i++) dist[i] = Math.sqrt(Math.min(hh[i], big));
    return value ? [dist, hv] : dist;
  }

  /* Layer alpha + signed distance (px, negative inside) to the anti-aliased
     50 % contour: seeds carry their sub-pixel offset (0.5 - alpha). */
  function Shape(A, w, h, reach) {
    this.A = A; this.w = w; this.h = h; this.R = reach | 0; this._S = null;
  }
  Shape.prototype.S = function () {
    if (!this._S) {
      const A = this.A, n = A.length, R = Math.max(1, this.R);
      const segOut = new Uint8Array(n), segIn = new Uint8Array(n);
      const offOut = new Float32Array(n), offIn = new Float32Array(n);
      for (let i = 0; i < n; i++) {
        segOut[i] = A[i] > 0 ? 1 : 0; segIn[i] = A[i] < 1 ? 1 : 0;
        offOut[i] = 0.5 - A[i]; offIn[i] = A[i] - 0.5;
      }
      const o = edt(segOut, this.w, this.h, R, offOut);
      const q = edt(segIn, this.w, this.h, R, offIn);
      const S = new Float32Array(n);
      for (let i = 0; i < n; i++) S[i] = A[i] >= 0.5 ? -(q[0][i] + q[1][i]) : o[0][i] + o[1][i];
      this._S = S;
    }
    return this._S;
  };
  Shape.prototype.grow = function (r) {
    if (r <= 0) return Float32Array.from(this.A);
    const S = this.S(), out = new Float32Array(S.length);
    for (let i = 0; i < S.length; i++) out[i] = clamp(r - S[i] + 0.5, 0, 1);
    return out;
  };
  Shape.prototype.shrink = function (r) {
    if (r <= 0) return Float32Array.from(this.A);
    const S = this.S(), out = new Float32Array(S.length);
    for (let i = 0; i < S.length; i++) out[i] = clamp(-S[i] - r + 0.5, 0, 1);
    return out;
  };
  Shape.prototype.outsideGrown = function (r) {
    const out = new Float32Array(this.A.length);
    if (r <= 0) { for (let i = 0; i < out.length; i++) out[i] = 1 - this.A[i]; return out; }
    const S = this.S();
    for (let i = 0; i < S.length; i++) out[i] = clamp(S[i] + r + 0.5, 0, 1);
    return out;
  };

  function interp1(x, xs, ys) {           // numpy.interp
    if (x <= xs[0]) return ys[0];
    const n = xs.length;
    if (x >= xs[n - 1]) return ys[n - 1];
    for (let i = 0; i < n - 1; i++) {
      if (x <= xs[i + 1]) {
        const span = xs[i + 1] - xs[i];
        return span > 0 ? ys[i] + (ys[i + 1] - ys[i]) * (x - xs[i]) / span : ys[i + 1];
      }
    }
    return ys[n - 1];
  }
  function applyContour(m, ct) {
    if (!ct) return m;
    const xs = ct.map((p) => p[0] / 255), ys = ct.map((p) => p[1] / 255);
    const out = new Float32Array(m.length);
    for (let i = 0; i < m.length; i++) out[i] = interp1(m[i], xs, ys);
    return out;
  }

  /* per-stop slopes for smooth (Catmull-Rom) gradients — ps_fx_png._stop_tangents */
  function stopTangents(st, smooth) {
    const n = st.length, k = GRADIENT_TANGENT * smooth, out = [];
    for (let i = 0; i < n; i++) {
      const ch = st[i][0].length, t = new Array(ch).fill(0);
      if (k > 0 && n >= 2) {
        const a = Math.max(0, i - 1), b = Math.min(n - 1, i + 1);
        const span = st[b][1] - st[a][1];
        if (span > 1e-6) for (let c = 0; c < ch; c++) t[c] = (st[b][0][c] - st[a][0][c]) / span * k;
      }
      out.push(t);
    }
    return out;
  }

  function interpStop(t, st, tans, ch, out, o, hi) {
    const last = st[st.length - 1];
    if (t > last[1]) { for (let c = 0; c < ch; c++) out[o + c] = last[0][c]; return; }
    for (let i = 0; i < st.length - 1; i++) {
      const loc0 = st[i][1], loc1 = st[i + 1][1], mid = st[i + 1][2];
      if (loc1 <= loc0) continue;
      if (t > loc0 && t <= loc1) {
        const h = loc1 - loc0;
        let u = (t - loc0) / h;
        if (Math.abs(mid - 0.5) > 1e-6) u = u < mid ? 0.5 * u / mid : 0.5 + 0.5 * (u - mid) / (1 - mid);
        const u2 = u * u, u3 = u2 * u;
        const h00 = 2 * u3 - 3 * u2 + 1, h10 = u3 - 2 * u2 + u, h01 = 3 * u2 - 2 * u3, h11 = u3 - u2;
        for (let c = 0; c < ch; c++) {
          const v = h00 * st[i][0][c] + h10 * (h * tans[i][c]) + h01 * st[i + 1][0][c] + h11 * (h * tans[i + 1][c]);
          out[o + c] = clamp(v, 0, hi);
        }
        return;
      }
    }
    for (let c = 0; c < ch; c++) out[o + c] = st[0][0][c];
  }

  function gradientT(g, w, h, bounds, S, strokeSize, position) {
    const bw = Math.max(1, bounds[2] - bounds[0]), bh = Math.max(1, bounds[3] - bounds[1]);
    const cx = (bounds[0] + bounds[2]) / 2 + g.offset[0] / 100 * bw;
    const cy = (bounds[1] + bounds[3]) / 2 + g.offset[1] / 100 * bh;
    const a = g.angle * Math.PI / 180;
    const dx = Math.cos(a), dy = -Math.sin(a);
    const sc = g.scale;
    const span = Math.abs(bw * dx) + Math.abs(bh * dy);
    const out = new Float32Array(w * h);
    const burst = g.type === "shape_burst" && S;
    const size = Math.max(1e-3, strokeSize || 0);
    for (let y = 0; y < h; y++) {
      const Y = y + 0.5 - cy;
      for (let x = 0; x < w; x++) {
        const X = x + 0.5 - cx, i = y * w + x;
        let t;
        if (burst) {
          if (position === "inside") t = -S[i] / size;
          else if (position === "center") t = (S[i] + size / 2) / size;
          else t = S[i] / size;
        } else if (g.type === "radial") {
          t = Math.sqrt(X * X + Y * Y) / Math.max(1e-3, Math.hypot(bw, bh) / 2 * sc);
        } else if (g.type === "angle") {
          const q = (Math.atan2(-Y, X) - a) / (2 * Math.PI);
          t = ((q % 1) + 1) % 1;
        } else if (g.type === "reflected") {
          t = Math.abs(X * dx + Y * dy) / Math.max(1e-3, span / 2 * sc);
        } else if (g.type === "diamond") {
          const u = X * dx + Y * dy, v = -X * dy + Y * dx;
          t = (Math.abs(u) + Math.abs(v)) / Math.max(1e-3, span / 2 * sc);
        } else {
          t = 0.5 + (X * dx + Y * dy) / Math.max(1e-3, span * sc);
        }
        if (g.reverse) t = 1 - t;
        out[i] = clamp(t, 0, 1);
      }
    }
    return out;
  }

  function gradientFill(g, w, h, bounds, S, strokeSize, position) {
    const t = gradientT(g, w, h, bounds, S, strokeSize, position);
    const rgbArr = new Float32Array(w * h * 3);
    const tans = stopTangents(g.stops, g.smooth);
    const tmp = [0, 0, 0];
    for (let i = 0; i < t.length; i++) {
      interpStop(t[i], g.stops, tans, 3, tmp, 0, 255);
      rgbArr[i * 3] = tmp[0] / 255; rgbArr[i * 3 + 1] = tmp[1] / 255; rgbArr[i * 3 + 2] = tmp[2] / 255;
    }
    let alpha = null;
    if (g.trans) {
      const ts = g.trans.map((s) => [[s[0]], s[1], s[2]]);
      const ttans = stopTangents(ts, g.smooth);
      alpha = new Float32Array(w * h);
      const one = [0];
      for (let i = 0; i < t.length; i++) { interpStop(t[i], ts, ttans, 1, one, 0, 1); alpha[i] = one[0]; }
    }
    return { rgb: rgbArr, alpha: alpha };
  }

  /* ------------------------------------------------------------ blending */

  function blendC(b, l, mode) {
    switch (mode) {
      case "multiply": return b * l;
      case "screen": return b + l - b * l;
      case "overlay": return b <= 0.5 ? 2 * b * l : 1 - 2 * (1 - b) * (1 - l);
      case "hard-light": return l <= 0.5 ? 2 * b * l : 1 - 2 * (1 - b) * (1 - l);
      case "soft-light": {
        const d = b <= 0.25 ? ((16 * b - 12) * b + 4) * b : Math.sqrt(Math.max(b, 0));
        return l <= 0.5 ? b - (1 - 2 * l) * b * (1 - b) : b + (2 * l - 1) * (d - b);
      }
      case "color-dodge": return b <= 0 ? 0 : (l >= 1 ? 1 : Math.min(1, b / Math.max(1e-6, 1 - l)));
      case "color-burn": return b >= 1 ? 1 : (l <= 0 ? 0 : 1 - Math.min(1, (1 - b) / Math.max(1e-6, l)));
      case "linear-dodge": return Math.min(1, b + l);
      case "linear-burn": return Math.max(0, b + l - 1);
      case "darken": return Math.min(b, l);
      case "lighten": return Math.max(b, l);
      case "difference": return Math.abs(b - l);
      case "exclusion": return b + l - 2 * b * l;
      case "subtract": return Math.max(0, b - l);
      case "divide": return l <= 0 ? 1 : Math.min(1, b / Math.max(1e-6, l));
      case "linear-light": return clamp(b + 2 * l - 1, 0, 1);
      case "vivid-light":
        return l <= 0.5
          ? (l <= 0 ? 0 : 1 - Math.min(1, (1 - b) / Math.max(1e-6, 2 * l)))
          : (l >= 1 ? 1 : Math.min(1, b / Math.max(1e-6, 2 * (1 - l))));
      case "pin-light": return l <= 0.5 ? Math.min(b, 2 * l) : Math.max(b, 2 * l - 1);
      case "hard-mix": return b + l >= 1 ? 1 : 0;
      default: return l;
    }
  }

  /* out: Float32Array w*h*4 straight RGBA; color: [r,g,b] 0..1 or Float32Array w*h*3;
     alpha: Float32Array coverage; mul: scalar multiplier. */
  function composite(out, color, alpha, mul, mode) {
    const n = alpha.length, perPixel = color.length === n * 3;
    for (let i = 0; i < n; i++) {
      const as = clamp(alpha[i] * mul, 0, 1);
      if (!(as > 0)) continue;
      const o = i * 4, ab = out[o + 3];
      const ao = as + ab * (1 - as);
      for (let c = 0; c < 3; c++) {
        const cs = perPixel ? color[i * 3 + c] : color[c];
        const cb = out[o + c];
        const mixed = mode === "normal" ? cs : (1 - ab) * cs + ab * blendC(cb, cs, mode);
        const co = as * mixed + (1 - as) * ab * cb;
        out[o + c] = ao > 1e-6 ? co / Math.max(ao, 1e-6) : 0;
      }
      out[o + 3] = ao;
    }
  }

  function rgb01(c) { return [c[0] / 255, c[1] / 255, c[2] / 255]; }

  /* ------------------------------------------------------------ pipeline */

  function inkBounds(A, w, h) {
    let x0 = w, y0 = h, x1 = -1, y1 = -1;
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      if (A[y * w + x] > 0.004) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
    }
    return x1 < 0 ? [0, 0, w, h] : [x0, y0, x1 + 1, y1 + 1];
  }

  function offset(angle, distance) {
    const a = angle * Math.PI / 180;
    return [round(-Math.cos(a) * distance), round(Math.sin(a) * distance)];
  }

  function mulArr(a, b) { const o = new Float32Array(a.length); for (let i = 0; i < a.length; i++) o[i] = a[i] * b[i]; return o; }

  /* [highlight, shadow, outside region | null, lights the inside] — ps_fx_png._bevel_layers */
  function bevelLayers(e, shape) {
    const size = Math.max(1, e.size), w = shape.w, h = shape.h, A = shape.A, S = shape.S();
    const n = A.length, style = e.style, reach = size * EMBOSS_REACH;
    const lin = new Float32Array(n);
    let outside = null, inside = true, smoothSrc = A, smoothR = size;
    if (style === "outer") {
      outside = shape.grow(size); inside = false;
      for (let i = 0; i < n; i++) lin[i] = clamp(1 - S[i] / size, 0, 1);
    } else if (style === "emboss" || style === "stroke") {
      outside = shape.grow(reach);
      for (let i = 0; i < n; i++) lin[i] = clamp(0.5 - S[i] / (2 * reach), 0, 1);
      smoothR = reach;
    } else if (style === "pillow") {
      outside = shape.grow(reach);
      for (let i = 0; i < n; i++) lin[i] = clamp(Math.abs(S[i]) / (2 * reach), 0, 1);
      smoothSrc = null; smoothR = reach;
    } else {
      for (let i = 0; i < n; i++) lin[i] = clamp(-S[i] / size, 0, 1);
    }
    const smoothSigma = SMOOTH_SIGMA * smoothR + 0.3;
    let slope = BEVEL_SLOPE, height;
    if (e.technique === "smooth" && smoothSrc) height = blur(smoothSrc, w, h, smoothSigma);
    else if (e.technique === "smooth") {
      const b = blur(A, w, h, smoothSigma);
      height = new Float32Array(n);
      for (let i = 0; i < n; i++) height[i] = Math.abs(b[i] - 0.5);
    } else if (e.technique === "chisel_soft") { height = blur(lin, w, h, CHISEL_BLUR * 2); slope = BEVEL_SLOPE * CHISEL_SLOPE; }
    else { height = blur(lin, w, h, CHISEL_BLUR); slope = BEVEL_SLOPE * CHISEL_SLOPE; }
    if (style === "emboss" || style === "stroke" || style === "pillow") slope *= EMBOSS_SLOPE;
    if (e.soften > 0) height = blur(height, w, h, sizeSigma(e.soften));
    const k = size * e.depth * slope;
    const z = new Float32Array(n);
    for (let i = 0; i < n; i++) z[i] = (e.direction === "down" ? 1 - height[i] : height[i]) * k;
    const a = e.angle * Math.PI / 180, alt = e.altitude * Math.PI / 180;
    const lx = Math.cos(alt) * Math.cos(a), ly = -Math.cos(alt) * Math.sin(a), lz = Math.sin(alt);
    const hi = new Float32Array(n), lo = new Float32Array(n);
    const ct = e.contour ? [e.contour.map((p) => p[0] / 255), e.contour.map((p) => p[1] / 255)] : null;
    const Z = (x, y) => z[clamp(y, 0, h - 1) * w + clamp(x, 0, w - 1)];
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const i = y * w + x;
      const gx = ((Z(x + 1, y - 1) + 2 * Z(x + 1, y) + Z(x + 1, y + 1)) - (Z(x - 1, y - 1) + 2 * Z(x - 1, y) + Z(x - 1, y + 1))) / 8;
      const gy = ((Z(x - 1, y + 1) + 2 * Z(x, y + 1) + Z(x + 1, y + 1)) - (Z(x - 1, y - 1) + 2 * Z(x, y - 1) + Z(x + 1, y - 1))) / 8;
      let shade = (-gx * lx - gy * ly + lz) / Math.sqrt(gx * gx + gy * gy + 1);
      if (ct) shade = interp1(clamp(shade, 0, 1), ct[0], ct[1]);
      hi[i] = clamp((shade - lz) / Math.max(1e-3, 1 - lz) * BEVEL_HI_GAIN, 0, 1);
      lo[i] = clamp((lz - shade) / Math.max(1e-3, lz) * BEVEL_LO_GAIN, 0, 1);
    }
    return [hi, lo, outside, inside];
  }

  function glowRange(m, e) {
    const r = Math.max(0.01, e.range), out = new Float32Array(m.length);
    for (let i = 0; i < m.length; i++) out[i] = clamp(m[i] / r, 0, 1);
    return out;
  }

  /* pixel = A of the layer interior (part) + (1 - A) of what lies around it */
  function merge(under, part, A) {
    const n = A.length, out = new Float32Array(n * 4);
    for (let i = 0; i < n; i++) {
      const o = i * 4, pa = part[o + 3] * A[i], ua = under[o + 3] * (1 - A[i]), ao = pa + ua;
      for (let c = 0; c < 3; c++) out[o + c] = ao > 1e-6 ? (part[o + c] * pa + under[o + c] * ua) / Math.max(ao, 1e-6) : under[o + c];
      out[o + 3] = ao;
    }
    return out;
  }

  function filled(n, v) { return new Float32Array(n).fill(v); }

  function renderEffects(content, w, h, raw, backdrop, bounds) {
    const N = raw && raw.strokes && raw.has_fx !== undefined ? raw : normalize(raw);
    const n = w * h;
    const A = new Float32Array(n), C = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) {
      A[i] = clamp(content[i * 4 + 3], 0, 1);
      C[i * 3] = content[i * 4]; C[i * 3 + 1] = content[i * 4 + 1]; C[i * 3 + 2] = content[i * 4 + 2];
    }
    const under = backdrop ? Float32Array.from(backdrop) : new Float32Array(n * 4);
    const shape = new Shape(A, w, h, distanceReach(N));
    const layerA = N.opacity;
    if (!bounds) bounds = inkBounds(A, w, h);
    let knock = null;
    if (N.fill_opacity < 1 || !N.fill_enabled) { knock = new Float32Array(n); for (let i = 0; i < n; i++) knock[i] = 1 - A[i]; }

    /* ---- below the layer */
    for (const e of N.drop_shadows.slice().reverse()) {
      const spreadR = e.size * e.spread / 100;
      let m = blur(shape.grow(spreadR), w, h, sizeSigma(e.size - spreadR));
      const d = offset(e.angle, e.distance);
      m = applyContour(shift(m, w, h, d[0], d[1], 0), e.contour);
      if (knock && e.knockout) m = mulArr(m, knock);
      composite(under, rgb01(e.color), m, e.opacity * layerA, e.blend);
    }
    for (const e of N.outer_glows.slice().reverse()) {
      const spreadR = e.size * e.spread / 100;
      let m = applyContour(glowRange(blur(shape.grow(spreadR), w, h, sizeSigma(e.size - spreadR)), e), e.contour);
      if (knock) m = mulArr(m, knock);
      composite(under, rgb01(e.color), m, e.opacity * layerA, e.blend);
    }

    /* the layer interior starts from what lies beneath it */
    const part = Float32Array.from(under);

    const strokeColor = (e) => {
      if (!e.gradient) return { color: rgb01(e.color), alpha: null };
      const gr = e.position === "outside" ? e.size : (e.position === "center" ? e.size / 2 : 0);
      const sb = [bounds[0] - gr, bounds[1] - gr, bounds[2] + gr, bounds[3] + gr];
      const gf = gradientFill(e.gradient, w, h, sb, e.gradient.type === "shape_burst" ? shape.S() : null, e.size, e.position);
      return { color: gf.rgb, alpha: gf.alpha };
    };

    /* ---- around the layer: outside strokes, outer half of centre strokes */
    for (const e of N.strokes.slice().reverse()) {
      if (e.position === "inside") continue;
      let m = shape.grow(e.position === "outside" ? e.size : e.size / 2);
      const sc = strokeColor(e);
      if (sc.alpha) m = mulArr(m, sc.alpha);
      composite(under, sc.color, m, e.opacity * layerA, e.blend);
    }

    /* ---- the layer interior */
    if (N.fill_enabled) composite(part, C, filled(n, 1), N.fill_opacity * layerA, "normal");
    for (const e of N.gradient_overlays.slice().reverse()) {
      const gf = gradientFill(e, w, h, bounds, null, 0, "outside");
      composite(part, gf.rgb, gf.alpha || filled(n, 1), e.opacity * layerA, e.blend);
    }
    for (const e of N.color_overlays.slice().reverse()) composite(part, rgb01(e.color), filled(n, 1), e.opacity * layerA, e.blend);

    for (const e of N.satins.slice().reverse()) {
      const a = e.angle * Math.PI / 180;
      const ox = round(Math.cos(a) * e.distance), oy = round(-Math.sin(a) * e.distance);
      // worked out on a canvas big enough for the whole blur and both shifts (= ps_fx_png._satin_mask):
      // a satin's blur / distance is often far bigger than the layer, and cutting the blur off at the
      // layer's edge made the effect almost vanish where Photoshop brightens the whole card
      const sig = sizeSigma(e.size);
      const P = Math.ceil(Math.min(1600, Math.max(Math.abs(ox), Math.abs(oy)) + 3 * sig + 2));
      const W2 = w + 2 * P, H2 = h + 2 * P;
      const big = new Float32Array(W2 * H2);
      for (let yy = 0; yy < h; yy++) big.set(A.subarray(yy * w, yy * w + w), (yy + P) * W2 + P);
      const soft = blur(big, W2, H2, sig);
      const s1 = shift(soft, W2, H2, ox, oy, 0), s2 = shift(soft, W2, H2, -ox, -oy, 0);
      let m = new Float32Array(n);
      for (let yy = 0; yy < h; yy++) {
        for (let xx = 0; xx < w; xx++) {
          const j = (yy + P) * W2 + xx + P, v = Math.abs(s1[j] - s2[j]);
          m[yy * w + xx] = clamp(e.invert ? 1 - v : v, 0, 1);
        }
      }
      m = applyContour(m, e.contour);
      composite(part, rgb01(e.color), m, e.opacity * layerA, e.blend);
    }
    for (const e of N.inner_glows.slice().reverse()) {
      const chokeR = e.size * e.spread / 100;
      const b = blur(shape.outsideGrown(chokeR), w, h, sizeSigma(e.size - chokeR));
      const mm = new Float32Array(n);
      for (let i = 0; i < n; i++) mm[i] = clamp(e.source === "center" ? 1 - b[i] : b[i], 0, 1);
      composite(part, rgb01(e.color), applyContour(glowRange(mm, e), e.contour), e.opacity * layerA, e.blend);
    }
    for (const e of N.inner_shadows.slice().reverse()) {
      const chokeR = e.size * e.spread / 100;
      let m = blur(shape.outsideGrown(chokeR), w, h, sizeSigma(e.size - chokeR));
      const d = offset(e.angle, e.distance);
      m = applyContour(shift(m, w, h, d[0], d[1], 1), e.contour);
      composite(part, rgb01(e.color), m, e.opacity * layerA, e.blend);
    }
    for (const e of N.strokes.slice().reverse()) {
      if (e.position === "outside") continue;
      const s = shape.shrink(e.position === "inside" ? e.size : e.size / 2);
      let m = new Float32Array(n);
      for (let i = 0; i < n; i++) m[i] = 1 - s[i];
      const sc = strokeColor(e);
      if (sc.alpha) m = mulArr(m, sc.alpha);
      composite(part, sc.color, m, e.opacity * layerA, e.blend);
    }

    for (const e of N.bevels.slice().reverse()) {
      const bl = bevelLayers(e, shape);
      const targets = [];
      if (bl[3]) targets.push([part, null]);
      if (bl[2]) targets.push([under, bl[2]]);
      for (const tr of targets) {
        const lo = tr[1] ? mulArr(bl[1], tr[1]) : bl[1], hi = tr[1] ? mulArr(bl[0], tr[1]) : bl[0];
        composite(tr[0], rgb01(e.shadow_color), lo, e.shadow_opacity * layerA, e.shadow_blend);
        composite(tr[0], rgb01(e.highlight_color), hi, e.highlight_opacity * layerA, e.highlight_blend);
      }
    }
    return merge(under, part, A);
  }

  /* ------------------------------------------------------------ front end */

  function toFloat(data) {
    const f = new Float32Array(data.length);
    for (let i = 0; i < data.length; i++) f[i] = data[i] / 255;
    return f;
  }

  function renderImageData(imageData, raw, bounds, backdropImageData) {
    const N = raw && raw.strokes && raw.has_fx !== undefined ? raw : normalize(raw);
    const w = imageData.width, h = imageData.height;
    const out = renderEffects(toFloat(imageData.data), w, h, N,
      backdropImageData ? toFloat(backdropImageData.data) : null, bounds || null);
    const res = new ImageData(w, h);
    for (let i = 0; i < out.length; i++) res.data[i] = out[i] * 255;   // Uint8Clamped: round half even
    return res;
  }

  const api = { normalize, setGlobalLight, applyGlobalLight, scaleFor, scaleFactor, scaleMode, scaleParams, effectPad, renderEffects, renderImageData, sizeSigma, boxRadii, blur, edt };
  root.PsFx = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);
