/* Paytable card studio — the live view.
   Draws the card layout in the browser from /api/card_templates/layout (shapes, symbols,
   numbers and text in canvas px), so every drag and slider shows at once. The exact PNG
   (layer styles, Photoshop text) replaces it as soon as the server has rendered it.
   draw() returns where each symbol / text actually landed (image fractions) — the studio's
   tight boxes. */
window.PCLive = (() => {
  const images = {};
  function image(url, redraw) {
    if (!url) return null;
    let im = images[url];
    if (!im) {
      im = new Image();
      im.onload = () => redraw && redraw();
      im.src = url;
      images[url] = im;
    }
    return im.complete && im.naturalWidth ? im : null;
  }

  function roundRect(ctx, x, y, w, h, r) {
    r = Math.max(0, Math.min(r, w / 2, h / 2));
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }
  function rgba(hex, a) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ""));
    if (!m) return `rgba(255,255,255,${a})`;
    const n = parseInt(m[1], 16);
    return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
  }
  /* any corner kinds (psd_writer/shapes.knots, 1:1): round, cut (a chamfer), notch (a quarter circle cut
     in), step (a square cut in) — each corner its own size (radii) and kind (corners) */
  const KAPPA = 0.5522847498;
  function shapePath(ctx, sh, x, y, w, h, inset, more) {
    const lim = Math.max(0, Math.min(w, h) / 2 - inset);
    const r0 = String(sh.radius) === "pill" ? h / 2 : Number(sh.radius) || 0;
    const rad = Array.isArray(sh.radii) && sh.radii.length === 4 ? sh.radii.map(Number) : [r0, r0, r0, r0];
    const kinds = Array.isArray(sh.corners) && sh.corners.length === 4 ? sh.corners : [sh.corner || "round", sh.corner || "round", sh.corner || "round", sh.corner || "round"];
    const l = x + inset, t = y + inset, r = x + w - inset, b = y + h - inset;
    const cs = [[l, t, 0, 1, 1, 0], [r, t, -1, 0, 0, 1], [r, b, 0, -1, -1, 0], [l, b, 1, 0, 0, -1]];
    if (!more) ctx.beginPath();
    cs.forEach(([cx, cy, sx, sy, ex, ey], i) => {
      const kind = kinds[i] || "round";
      let rr = Math.min(rad[i], Math.min(w, h) / 2);
      rr = kind === "round" ? rr - inset : kind === "notch" || kind === "step" ? rr + inset : rr;
      rr = Math.max(0, Math.min(lim, rr));
      if (rr <= 1e-6) { if (i === 0) ctx.moveTo(cx, cy); else ctx.lineTo(cx, cy); return; }
      const S = [cx + sx * rr, cy + sy * rr], E = [cx + ex * rr, cy + ey * rr], O = [S[0] + E[0] - cx, S[1] + E[1] - cy];
      if (i === 0) ctx.moveTo(S[0], S[1]); else ctx.lineTo(S[0], S[1]);
      if (kind === "round") ctx.bezierCurveTo(S[0] + KAPPA * (cx - S[0]), S[1] + KAPPA * (cy - S[1]), E[0] + KAPPA * (cx - E[0]), E[1] + KAPPA * (cy - E[1]), E[0], E[1]);
      else if (kind === "notch") ctx.bezierCurveTo(S[0] + KAPPA * (O[0] - S[0]), S[1] + KAPPA * (O[1] - S[1]), E[0] + KAPPA * (O[0] - E[0]), E[1] + KAPPA * (O[1] - E[1]), E[0], E[1]);
      else if (kind === "step") { ctx.lineTo(O[0], O[1]); ctx.lineTo(E[0], E[1]); }
      else ctx.lineTo(E[0], E[1]);
    });
    ctx.closePath();
  }
  // a shape's fill: its colour, or a gradient into fill_to (the PNG's and the PSD's ramps: top / left /
  // top-left / centre first)
  function fillOf(ctx, sh, x, y, w, h) {
    const alpha = (Number(sh.fill_opacity ?? 100)) / 100, dir = String(sh.gradient_dir || "vertical").toLowerCase();
    if (!sh.fill_to || dir === "none") return rgba(sh.fill, alpha);
    const g = dir === "horizontal" ? ctx.createLinearGradient(x, y, x + w, y)
      : dir === "diagonal" ? ctx.createLinearGradient(x, y, x + w, y + h)
      : dir === "radial" ? ctx.createRadialGradient(x + w / 2, y + h / 2, 0, x + w / 2, y + h / 2, Math.hypot(w, h) / 2)
      : ctx.createLinearGradient(x, y, x, y + h);
    g.addColorStop(0, rgba(sh.fill, alpha));
    g.addColorStop(1, rgba(sh.fill_to, alpha));
    return g;
  }
  const plainShape = (sh) => !(Array.isArray(sh.radii) || Array.isArray(sh.corners) || (sh.corner && sh.corner !== "round"));
  function drawShape(ctx, sh, [x, y, w, h]) {
    const r = String(sh.radius) === "pill" ? h / 2 : Number(sh.radius) || 0;
    if (!plainShape(sh)) {                         // own corners: the shared outline
      const st = sh.stroke || {}, sw = st.enabled ? Number(st.width) || 2 : 0;
      const grow = st.align === "outside" ? sw : st.align === "center" ? sw / 2 : 0;
      const X = x - grow, Y = y - grow, W = w + 2 * grow, H = h + 2 * grow;
      if (sw) {                                    // the border: a ring (outer outline, inner outline, even-odd)
        ctx.fillStyle = rgba(st.color || "#FFFFFF", Number(st.opacity ?? 100) / 100);
        shapePath(ctx, sh, X, Y, W, H, 0); shapePath(ctx, sh, X, Y, W, H, sw, true); ctx.fill("evenodd");
      }
      if (sh.fill_enabled !== false && sh.fill) {
        ctx.fillStyle = fillOf(ctx, sh, X, Y, W, H);
        shapePath(ctx, sh, X, Y, W, H, sw);
        ctx.fill();
      }
      return;
    }
    if (sh.fill_enabled !== false && sh.fill) {
      ctx.fillStyle = fillOf(ctx, sh, x, y, w, h);
      roundRect(ctx, x, y, w, h, r);
      ctx.fill();
    }
    const st = sh.stroke || {};
    if (st.enabled) {
      const sw = Number(st.width) || 2;
      const grow = st.align === "outside" ? sw / 2 : st.align === "center" ? 0 : -sw / 2;
      ctx.strokeStyle = st.color || "#FFFFFF";
      ctx.lineWidth = sw;
      roundRect(ctx, x - grow, y - grow, w + 2 * grow, h + 2 * grow, Math.max(0, r + grow));
      ctx.stroke();
    }
  }

  function fitRect(iw, ih, [x, y, w, h], align = "center", valign = "center", pad = 2) {
    const bw = Math.max(1, w - 2 * pad), bh = Math.max(1, h - 2 * pad);
    const k = Math.min(bw / iw, bh / ih);
    const dw = iw * k, dh = ih * k;
    const dx = align === "left" ? x + pad : align === "right" ? x + w - pad - dw : x + (w - dw) / 2;
    const dy = valign === "top" ? y + pad : valign === "bottom" ? y + h - pad - dh : y + (h - dh) / 2;
    return [dx, dy, dw, dh];
  }

  const fontOf = (st, size) => `${st.italic ? "italic " : ""}${st.bold ? "bold " : ""}${size}px ${st.font ? `"${st.font}", ` : ""}Arial, sans-serif`;
  function iconScale(scales, token) {
    const key = String(token).replace(/[<>]/g, "").replace(/^[\s.;,\-!]+|[\s.;,\-!]+$/g, "").toUpperCase();
    const norm = {};
    Object.entries(scales || {}).forEach(([k, v]) => { norm[String(k).replace(/[<>]/g, "").trim().toUpperCase()] = v; });
    const v = norm[key] ?? norm["*"];
    return v == null || /px$/i.test(String(v)) ? 1 : Math.max(0.2, Math.min(4, Number(v) / 100 || 1));
  }
  // an inline icon's height: its own px ("40px") when it has one, else the line's icon height × its %
  // nth: which copy of the token in its text (0 = the first) — "TOKEN#1" sizes only the second (= ps_actions)
  function iconHeight(scales, token, base, nth) {
    const key = String(token).replace(/[<>]/g, "").replace(/^[\s.;,\-!]+|[\s.;,\-!]+$/g, "").toUpperCase();
    const norm = {};
    Object.entries(scales || {}).forEach(([k, v]) => { norm[String(k).replace(/[<>]/g, "").trim().toUpperCase()] = v; });
    const one = nth != null ? norm[`${key}#${nth}`] : undefined;
    if (one != null) return iconHeight({ [key]: one }, token, base);
    const v = norm[key] ?? norm["*"];
    if (v != null && /px$/i.test(String(v))) return Math.max(4, parseFloat(v) || base);
    return base * iconScale(scales, token);
  }

  // the build's own layout of a text (server: ps_actions.slot_text_layout — what the PSD's text layer gets):
  // its size, its lines, every word's and icon's width, each line's height and baseline. Drawn as it is,
  // so the Canvas shows the PSD's line breaks and places (moved with its box: a styled text's sprite, a box
  // dragged along); undefined while the box is being sized (its own wrap then, until the server's comes)
  function drawLaidOut(ctx, it, data, redraw, icons, missing) {
    const L = it.layout, st = it.style || {};
    if (!L || !Array.isArray(L.lines) || !L.rect || Math.abs(L.rect[2] - it.rect[2]) > 0.6 || Math.abs(L.rect[3] - it.rect[3]) > 0.6) return undefined;
    const dx = it.rect[0] - L.rect[0], dy = it.rect[1] - L.rect[1];
    const size = L.size;
    ctx.font = fontOf(st, size);
    ctx.fillStyle = st.color || "#FFFFFF";
    ctx.textBaseline = "alphabetic";
    const ext = [Infinity, Infinity, -Infinity, -Infinity];
    let ty = L.y + L.top + dy;
    L.lines.forEach((ln, i) => {
      const lh = L.lh[i] || size * 1.25;
      const total = ln.reduce((a, itm, j) => a + itm.w + (j < ln.length - 1 ? (itm.i != null ? L.gap : L.space) : 0), 0);
      const bx = L.box_x + dx;
      let cx = L.align === "left" ? bx : L.align === "right" ? bx + Math.max(0, L.box_w - total) : bx + Math.max(0, Math.floor((L.box_w - total) / 2));
      const base = L.base[i] != null ? ty + L.base[i] : ty + lh / 2 + size * 0.35;
      ln.forEach((itm, j) => {
        if (itm.i != null) {
          const key = String(itm.i).replace(/[<>]/g, "").replace(/^[\s.;,\-!]+|[\s.;,\-!]+$/g, "").toUpperCase();
          const url = (data.icons || {})[key], im = url ? image(url, redraw) : null;
          const iy = ty + Math.max(0, Math.floor((lh - itm.h) / 2));
          if (im) ctx.drawImage(im, cx, iy, itm.w, itm.h);
          if (icons) icons.push({ slot: it.slot, tok: itm.i, loaded: !!im, rect: [cx, iy, cx + itm.w, iy + itm.h] });
        } else {
          ctx.fillText(itm.t, cx, base);
          if (missing && /^<[^<>]+>$/.test(itm.t)) missing.push({ slot: it.slot, tok: itm.t, rect: [cx, base - size, cx + itm.w, base] });
        }
        cx += itm.w + (j < ln.length - 1 ? (itm.i != null ? L.gap : L.space) : 0);
      });
      if (ln.length) {
        ext[0] = Math.min(ext[0], cx - total); ext[2] = Math.max(ext[2], cx);
        ext[1] = Math.min(ext[1], base - size * 0.8); ext[3] = Math.max(ext[3], base + size * 0.2);
      }
      ty += lh;
    });
    return ext[0] < Infinity ? ext : null;
  }

  // text with inline <icons>: the build's layout when the server sent it, else (a box being dragged) wrapped
  // here like the server renderer (close, not pixel-exact)
  function drawText(ctx, it, data, redraw, icons, missing) {
    const laid = drawLaidOut(ctx, it, data, redraw, icons, missing);
    if (laid !== undefined) return laid;
    const st = it.style || {}, [x, y, w, h] = it.rect;
    const parts = String(it.text).split(/(<[^<>]+>|\n)/).filter((p) => p !== "");
    const layout = (size) => {
      ctx.font = fontOf(st, size);
      const space = ctx.measureText(" ").width;
      // icons follow the text's size (ps_actions._scaled_icon_h): smaller with it, bigger only in a filled box
      const k = size / Math.max(1, st.size || size);
      const baseIcon = st.icon_h > 0 ? Math.min(st.fit ? st.icon_h * k : Math.min(st.icon_h, st.icon_h * k), Math.max(4, h - 4)) : Math.min(size, Math.max(4, h - 4));
      const items = [], seen = {};
      parts.forEach((p) => {
        if (p === "\n") { items.push({ type: "br" }); return; }
        const tok = /^<[^<>]+>$/.test(p);
        if (tok) {
          const key = p.replace(/[<>]/g, "").replace(/^[\s.;,\-!]+|[\s.;,\-!]+$/g, "").toUpperCase();
          const nth = seen[key] = (seen[key] ?? -1) + 1;
          const url = (data.icons || {})[key];
          const im = url ? image(url, redraw) : null;
          if (im) {
            const ih = iconHeight(st.icon_scales, p, baseIcon, nth);
            items.push({ type: "icon", im, tok: p, h: ih, w: ih * im.naturalWidth / im.naturalHeight });
            return;
          }
          if (url) { items.push({ type: "icon", im: null, tok: p, url, h: baseIcon, w: baseIcon }); return; }   // still loading
        }
        p.split(" ").forEach((word) => { if (word) items.push({ type: "text", val: word, w: ctx.measureText(word).width, miss: tok ? p : "" }); });
      });
      const lines = [[]];
      let cur = 0;
      items.forEach((itm) => {
        if (itm.type === "br") { lines.push([]); cur = 0; return; }
        const line = lines[lines.length - 1], sep = line.length ? space : 0;
        if (line.length && cur + sep + itm.w > w - 6) { lines.push([itm]); cur = itm.w; return; }
        line.push(itm); cur += sep + itm.w;
      });
      const lh = lines.map((ln) => {
        const ic = Math.max(0, ...ln.filter((i) => i.type === "icon").map((i) => i.h));
        return Math.max(size * 1.25, ic ? ic + 8 : 0, st.line_height || 0);
      });
      const wide = lines.some((ln) => ln.reduce((a, i2, j) => a + i2.w + (j ? space : 0), 0) > w - 6);
      return { lines: lines.filter((ln, i) => ln.length || i < lines.length - 1), lh, space, wide, total: lh.reduce((a, b) => a + b, 0) };
    };
    let size = Math.max(6, st.size || 30), L = layout(size);
    const fitsIn = (Lx) => Lx.total <= h - 4 && !Lx.wide;
    if (st.fit && String(it.text).trim()) {
      // Auto size: the biggest size whose lines fit the box (wrapped to its width), up to 3x the design's
      let lo = 8, hi = Math.max(9, Math.min(h, (st.size || 30) * 3));
      if (fitsIn(layout(hi))) lo = hi;
      else for (let n = 0; n < 14; n++) { const mid = (lo + hi) / 2; if (fitsIn(layout(mid))) lo = mid; else hi = mid; }
      size = lo; L = layout(size);
    }
    for (let n = 0; st.shrink && L.total > h && size > 8 && n < 30; n++) { size *= 0.93; L = layout(size); }
    let ty = st.valign === "top" ? y + 3 : st.valign === "bottom" ? y + h - L.total - 3 : y + (h - L.total) / 2;
    ctx.fillStyle = st.color || "#FFFFFF";
    ctx.textBaseline = "middle";
    ctx.font = fontOf(st, size);
    const ext = [Infinity, Infinity, -Infinity, -Infinity];
    L.lines.forEach((ln, i) => {
      const lw = ln.reduce((a, itm, j) => a + itm.w + (j ? L.space : 0), 0);
      let cx = st.align === "left" ? x + 3 : st.align === "right" ? x + w - 3 - lw : x + (w - lw) / 2;
      const mid = ty + L.lh[i] / 2;
      ln.forEach((itm, j) => {
        if (j) cx += L.space;
        if (itm.type === "icon") {
          if (itm.im) ctx.drawImage(itm.im, cx, mid - itm.h / 2, itm.w, itm.h);
          if (icons) icons.push({ slot: it.slot, tok: itm.tok, loaded: !!itm.im, rect: [cx, mid - itm.h / 2, cx + itm.w, mid + itm.h / 2] });
        }
        else {
          ctx.fillText(itm.val, cx, mid);
          // a <TOKEN> with no picture, drawn as its name: where it is (click it to pick its picture)
          if (itm.miss && missing) missing.push({ slot: it.slot, tok: itm.miss, rect: [cx, mid - size / 2, cx + itm.w, mid + size / 2] });
        }
        cx += itm.w;
      });
      if (ln.length) {
        const x0 = cx - lw;
        ext[0] = Math.min(ext[0], x0); ext[2] = Math.max(ext[2], cx);
        ext[1] = Math.min(ext[1], mid - size / 2); ext[3] = Math.max(ext[3], mid + size / 2);
      }
      ty += L.lh[i];
    });
    return ext[0] < Infinity ? ext : null;
  }

  /* layer styles (the page heading's on the title, a text's or a shape's own), drawn like the build:
     the part is painted into a padded sprite and window.PsFx (ps_fx_canvas.js, the 1:1 port of
     ps_fx_png.py) styles its pixels. Sprites are kept by size and content, not place, so a part
     dragged across the page is drawn from its sprite every frame. */
  const sprites = new Map();
  function fxSprite(key, fx, w, h, paint) {
    if (!window.PsFx || !fx) return null;
    // the project's Global Light turns "Use Global Light" shadows: a sprite per light
    key += "|" + JSON.stringify(((App.state.config || {}).dynamic_settings || {}).fx_global_light || null);
    let s = sprites.get(key);
    if (s) return s;
    const N = window.PsFx.normalize(fx);
    if (!N.has_fx) return null;
    const pad = Math.ceil(window.PsFx.effectPad(N));
    const cv = document.createElement("canvas");
    cv.width = Math.max(1, Math.ceil(w + 2 * pad));
    cv.height = Math.max(1, Math.ceil(h + 2 * pad));
    const c = cv.getContext("2d", { willReadFrequently: true });
    const meta = paint(c, pad);
    if (meta === false) return null;                     // not ready (an icon still loading): plain this time
    c.putImageData(window.PsFx.renderImageData(c.getImageData(0, 0, cv.width, cv.height), N), 0, 0);
    s = { cv, pad, meta };
    if (sprites.size > 300) sprites.delete(sprites.keys().next().value);
    sprites.set(key, s);
    return s;
  }
  // a styled part is drawn at the page's full size, then shrunk to the zoom: the browser's default
  // "low" smoothing makes thin strokes and soft glows ragged when zoomed out — "high" keeps them
  function smoothShrink(ctx) { ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = "high"; }
  function drawStyledShape(ctx, it) {
    const [x, y, w, h] = it.rect;
    // Photoshop's Fill opacity (as the build: paytable_box → ps_fx_png): the shape is drawn whole and its
    // effects take its full outline — a glow stays outside the card; only the shape itself is faded. Faded
    // first, the glow would show through a 90 % card and tint it
    const sh = Object.assign({}, it.shape, { fill_opacity: 100 });
    const fx = it.shape_fx ? Object.assign({}, it.shape_fx, { fill_opacity: Number(it.shape.fill_opacity ?? 100) }) : it.shape_fx;
    const s = fxSprite(JSON.stringify(["s", w, h, it.shape, it.shape_fx]), fx, w, h, (c, pad) => drawShape(c, sh, [pad, pad, w, h]));
    if (!s) { drawShape(ctx, it.shape, it.rect); return; }
    smoothShrink(ctx);
    ctx.drawImage(s.cv, x - s.pad, y - s.pad);
  }
  function drawStyledText(ctx, it, data, redraw, icons) {
    const [x, y, w, h] = it.rect;
    const key = JSON.stringify(["t", w, h, it.text, it.style, it.fx]);
    // the effects at the text's size (fx_scale.py), as the build draws them
    const fx = window.PsFx && window.PsFx.scaleFor ? window.PsFx.scaleFor(it.fx, (it.style || {}).size) : it.fx;
    const s = fxSprite(key, fx, w, h, (c, pad) => {
      const local = Object.assign({}, it, { rect: [pad, pad, w, h] }), ic = [];
      const ext = drawText(c, local, data, redraw, ic);
      if (ic.some((i) => !i.loaded)) return false;
      return { ext: ext && [ext[0] - pad, ext[1] - pad, ext[2] - pad, ext[3] - pad], icons: ic.map((i) => ({ tok: i.tok, rect: [i.rect[0] - pad, i.rect[1] - pad, i.rect[2] - pad, i.rect[3] - pad] })) };
    });
    if (!s) return drawText(ctx, it, data, redraw, icons);
    smoothShrink(ctx);
    ctx.drawImage(s.cv, x - s.pad, y - s.pad);
    if (icons) s.meta.icons.forEach((i) => icons.push({ slot: it.slot, tok: i.tok, rect: [x + i.rect[0], y + i.rect[1], x + i.rect[2], y + i.rect[3]] }));
    return s.meta.ext && [x + s.meta.ext[0], y + s.meta.ext[1], x + s.meta.ext[2], y + s.meta.ext[3]];
  }

  function draw(canvas, data, redraw) {
    if (canvas._view) canvas._view.style.display = "none";   // a text page's zoomed-in window (visualiser_live)
    const W = data.canvas_px.width, H = data.canvas_px.height;
    if (canvas.width !== W || canvas.height !== H) { canvas.width = W; canvas.height = H; }
    const ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, W, H);
    const cfg = (typeof App !== "undefined" && App.state && App.state.config) || null;
    const behind = !cfg ? data.bg_color : String(cfg.bg_source || "image") === "color" ? cfg.bg_color || "#FFFFFF"
      : cfg.bg_behind_fill ? cfg.bg_color || "#000000" : "";
    if (behind) {                                       // else transparent where the picture leaves it (bg_place.behind)
      ctx.fillStyle = behind;
      ctx.fillRect(0, 0, W, H);
    }
    const bg = image(data.background, redraw);
    const color = typeof App !== "undefined" && App.get && App.get("bg_source") === "color";
    if (bg && !color) {                                 // placed like the build (bg_place: fill, fit width, a PSD's place)
      const L = window.AppLive;
      const [dx, dy, dw, dh] = L && L.bgDest ? L.bgDest(L.bgSpec({}), W, H, bg.naturalWidth, bg.naturalHeight)
        : (() => { const k = Math.max(W / bg.naturalWidth, H / bg.naturalHeight); return [(W - bg.naturalWidth * k) / 2, (H - bg.naturalHeight * k) / 2, bg.naturalWidth * k, bg.naturalHeight * k]; })();
      ctx.drawImage(bg, dx, dy, dw, dh);
    }
    const drawn = {}, icons = [], missing = [];
    const frac = (r) => [r[0] / W, r[1] / H, r[2] / W, r[3] / H];
    (data.items || []).forEach((it) => {
      if (it.shape && it.plate_rect && it.layout && it.text && Math.abs(it.layout.rect[2] - it.rect[2]) < 0.6 && Math.abs(it.layout.rect[3] - it.rect[3]) < 0.6) {
        // the build's own plate (ps_actions.plate_rect): fit to the text, or sized by hand around it
        const dx = it.rect[0] - it.layout.rect[0], dy = it.rect[1] - it.layout.rect[1];
        const r = [it.plate_rect[0] + dx, it.plate_rect[1] + dy, it.plate_rect[2], it.plate_rect[3]];
        const pl = Object.assign({}, it, { rect: r });
        if (it.shape_fx) drawStyledShape(ctx, pl); else drawShape(ctx, it.shape, r);
        drawn[it.slot + "#plate"] = frac([r[0], r[1], r[0] + r[2], r[1] + r[3]]);
      } else if (it.shape && it.shape.fit != null && it.text) {
        // a plate fit to its text (the paytable title): its widest line + the padding, centred in the slot
        const st = it.style || {}, [x, y, w, h] = it.rect;
        ctx.font = fontOf(st, Number(st.size) || 30);
        const tw = Math.max(...String(it.text).split("\n").map((ln) => ctx.measureText(ln.replace(/<[^<>]+>/g, "  ")).width));
        const fw = Math.min(w, tw + 2 * (Number(it.shape.fit) || 0));
        const fit = Object.assign({}, it, { rect: [x + (w - fw) / 2, y, fw, h] });
        if (it.shape_fx) drawStyledShape(ctx, fit); else drawShape(ctx, it.shape, fit.rect);
        drawn[it.slot + "#plate"] = frac([fit.rect[0], y, fit.rect[0] + fw, y + h]);
      } else if (it.shape) { if (it.shape_fx) drawStyledShape(ctx, it); else drawShape(ctx, it.shape, it.rect); }
      if (it.icon) {
        const im = image(it.icon, redraw);
        if (im) {
          const [dx, dy, dw, dh] = fitRect(im.naturalWidth, im.naturalHeight, it.rect, it.align, it.valign);
          ctx.drawImage(im, dx, dy, dw, dh);
          drawn[it.slot] = frac([dx, dy, dx + dw, dy + dh]);
        }
      } else if (it.text) {
        const ext = it.fx ? drawStyledText(ctx, it, data, redraw, icons) : drawText(ctx, it, data, redraw, icons, missing);
        if (ext) drawn[it.slot] = frac(ext);
      }
    });
    // every icon inside text, where it landed (image fractions): the studio's per-icon size handles
    Object.defineProperty(drawn, "__icons", { value: icons.map((i) => ({ slot: i.slot, tok: i.tok, rect: frac(i.rect) })), enumerable: false });
    // <TOKEN>s with no picture (drawn as their names), merged per token: the Canvas maps a picture on click
    const miss = [];
    missing.forEach((m) => {
      const last = miss[miss.length - 1];
      if (last && last.slot === m.slot && last.tok === m.tok && Math.abs(last.rect[1] - m.rect[1]) < 1 && m.rect[0] - last.rect[2] < 30) last.rect[2] = m.rect[2];
      else miss.push({ slot: m.slot, tok: m.tok, rect: m.rect.slice() });
    });
    Object.defineProperty(drawn, "__missing", { value: miss.map((i) => ({ slot: i.slot, tok: i.tok, rect: frac(i.rect) })), enumerable: false });
    return drawn;
  }
  /* one clipboard for looks across the Canvas (window.PshLook): a paytable card / row / box / title plate,
     a text page's heading plate or row strip — copied as a card style ({fill, fill_opacity, fill_to,
     gradient_dir, radius, radii, corner(s), stroke, fx}) and pasted onto any of them */
  window.PshLook = window.PshLook || {
    clip: null,
    // a card style → a strip / plate rule's look (text_styles.strip_look reads it)
    cardToStrip(st) {
      st = st || {};
      const out = { color: st.fill || "#1e3a8a", opacity: Math.max(0, Math.min(1, Number(st.fill_enabled === false ? 0 : st.fill_opacity ?? 100) / 100)),
        radius: st.radius === "pill" ? 999 : Number(st.radius) || 0, radii: Array.isArray(st.radii) ? st.radii.slice() : null,
        corner: st.corner || null, corners: Array.isArray(st.corners) ? st.corners.slice() : null,
        fill_to: st.fill_to || null, gradient_dir: st.fill_to ? st.gradient_dir || "vertical" : null,
        gradient_amount: st.gradient_amount ?? null, fx: st.fx || null };
      const sk = st.stroke || {};
      out.border = sk.enabled && Number(sk.width) > 0 ? { width: Number(sk.width), color: sk.color || "#ffffff", opacity: Number(sk.opacity ?? 100), align: sk.align || "inside" } : null;
      return out;
    },
    // a strip / plate rule → a card style
    stripToCard(r) {
      r = r || {};
      const bd = r.border && Number(r.border.width) > 0 ? r.border : null;
      const out = { fill: r.color || "#1e3a8a", fill_enabled: true, fill_opacity: Math.round((r.opacity == null ? 0.85 : Number(r.opacity)) * 100),
        radius: Number(r.radius) || 0, stroke: bd ? { enabled: true, width: Number(bd.width), color: bd.color || "#ffffff", opacity: Number(bd.opacity ?? 100), align: bd.align || "inside" } : { enabled: false },
        fx: r.fx || "" };
      ["radii", "corner", "corners", "fill_to", "gradient_dir", "gradient_amount"].forEach((k) => { if (r[k] != null) out[k] = r[k]; });
      return out;
    },
    /* the card-look settings of a strip / plate rule, as a paytable card's bar has them: a gradient (its
       direction, second colour, strength), the corner shape, glow and shadow. editorHtml(rule) draws them
       in a pop-over (.tsp-row rows), wireEditor(root, rule, save) calls save({field: value | null}) */
    editorHtml(r) {
      r = r || {};
      const esc = (v) => String(v ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
      const dir = r.fill_to ? r.gradient_dir || "vertical" : "none";
      const cp = (this.fxOf(r).captured_params) || {}, g = cp.outer_glow || {}, d = cp.drop_shadow || {};
      const gOn = g.enabled !== false && !!g.color, dOn = d.enabled !== false && !!d.color;
      const corner = Array.isArray(r.corners) ? "" : r.corner || "round";
      const num = (k, v, min, max, tip, unit) => `<input class="ts-size ts-narrow" type="number" data-lk="${k}" min="${min}" max="${max}" value="${esc(v)}" title="${esc(tip)}">${unit ? `<span class="ts-unit">${unit}</span>` : ""}`;
      return `<div class="tsp-h">Gradient</div>
        <div class="tsp-row"><span class="tsp-l">Direction</span><select class="ts-style" data-lk="gdir" title="The fill fades into a second colour">${[["none", "None (flat)"], ["vertical", "↓ Top to bottom"], ["horizontal", "→ Left to right"], ["diagonal", "↘ Diagonal"], ["radial", "◎ Radial"]].map(([v, l]) => `<option value="${v}" ${dir === v ? "selected" : ""}>${l}</option>`).join("")}</select></div>
        ${dir !== "none" ? `<div class="tsp-row"><span class="tsp-l">Into</span><label class="ts-color" title="The colour it fades into"><input type="color" data-lk="gto" value="${esc(r.fill_to || "#000000")}"></label>
          ${num("gamt", r.gradient_amount ?? 100, 0, 100, "Strength (%): 0 = flat, 100 = all the way to the second colour", "%")}</div>` : ""}
        <div class="tsp-h">Corner shape</div>
        <div class="tsp-row"><span class="tsp-l">Corners</span><select class="ts-style" data-lk="corner" title="Round, cut, notched or stepped corners">${[["round", "◜ Round"], ["cut", "◸ Cut"], ["notch", "◟ Notched"], ["step", "⌐ Stepped"]].map(([v, l]) => `<option value="${v}" ${corner === v ? "selected" : ""}>${l}</option>`).join("")}${corner ? "" : `<option value="" selected>Mixed</option>`}</select></div>
        <div class="tsp-h">Glow &amp; shadow</div>
        <div class="tsp-row"><span class="tsp-l">Glow</span><input type="checkbox" data-lk="gon" ${gOn ? "checked" : ""} title="A glow around it">
          ${gOn ? `<label class="ts-color" title="Glow colour"><input type="color" data-lk="gc" value="${esc(g.color)}"></label>${num("gs", g.size ?? 16, 0, 250, "Glow size (px)", "px")}${num("go", g.opacity ?? 60, 0, 100, "Glow opacity (%)", "%")}` : ""}</div>
        <div class="tsp-row"><span class="tsp-l">Shadow</span><input type="checkbox" data-lk="don" ${dOn ? "checked" : ""} title="A shadow under it">
          ${dOn ? `<label class="ts-color" title="Shadow colour"><input type="color" data-lk="dc" value="${esc(d.color)}"></label>${num("ds", d.size ?? 12, 0, 250, "Shadow softness (px)", "px")}${num("dd", d.distance ?? 6, 0, 250, "Shadow distance (px)", "px")}${num("do", d.opacity ?? 60, 0, 100, "Shadow opacity (%)", "%")}` : ""}</div>`;
    },
    // the rule's layer style as an editable object (its own, or a copy of the library's)
    fxOf(r) {
      const fx = r && r.fx;
      if (fx && typeof fx === "object") return JSON.parse(JSON.stringify(fx));
      const lib = fx ? ((((window.App || {}).state || {}).config || {}).dynamic_settings || {}).layer_style_library || {} : {};
      return fx && lib[fx] && typeof lib[fx] === "object" ? JSON.parse(JSON.stringify(lib[fx])) : {};
    },
    wireEditor(root, r, save) {
      r = r || {};
      const x = (k) => root.querySelector(`[data-lk="${k}"]`), n = (k, d) => { const v = Number(x(k) && x(k).value); return isFinite(v) ? v : d; };
      const darker = (hex) => { const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || "")); if (!m) return "#000000"; const v = parseInt(m[1], 16); return "#" + [16, 8, 0].map((s) => Math.round(((v >> s) & 255) * 0.35).toString(16).padStart(2, "0")).join(""); };
      x("gdir")?.addEventListener("change", () => {
        const v = x("gdir").value;
        save(v === "none" ? { fill_to: null, gradient_dir: null, gradient_amount: null } : { gradient_dir: v, fill_to: r.fill_to || darker(r.color) });
      });
      x("gto")?.addEventListener("change", () => save({ fill_to: x("gto").value }));
      x("gamt")?.addEventListener("change", () => save({ gradient_amount: Math.max(0, Math.min(100, n("gamt", 100))) }));
      x("corner")?.addEventListener("change", () => { if (x("corner").value) save({ corner: x("corner").value === "round" ? null : x("corner").value, corners: null }); });
      // glow / shadow: the rule's own layer style from now on (a library style is copied, the library kept)
      const fxSave = (fn) => {
        const f = this.fxOf(r);
        f.captured_params = f.captured_params || {};
        fn(f.captured_params);
        const d = f.captured_params.drop_shadow || {};
        Object.assign(f, { shadow_enabled: d.enabled !== false && !!d.color, shadow_rgb: d.color || "#000000", shadow_opacity: d.opacity ?? 60,
          shadow_distance: d.distance ?? 6, shadow_size: d.size ?? 12, shadow_angle: d.angle ?? 120 });
        save({ fx: f });
      };
      x("gon")?.addEventListener("change", () => fxSave((cp) => {
        cp.outer_glow = Object.assign({ color: "#FFD24A", size: 16, opacity: 60, spread: 0, blend: "screen" }, cp.outer_glow || {}, { enabled: x("gon").checked });
      }));
      x("don")?.addEventListener("change", () => fxSave((cp) => {
        cp.drop_shadow = Object.assign({ color: "#000000", size: 12, distance: 6, opacity: 60, angle: 120 }, cp.drop_shadow || {}, { enabled: x("don").checked });
      }));
      [["gc", "outer_glow", "color"], ["gs", "outer_glow", "size"], ["go", "outer_glow", "opacity"],
       ["dc", "drop_shadow", "color"], ["ds", "drop_shadow", "size"], ["dd", "drop_shadow", "distance"], ["do", "drop_shadow", "opacity"]].forEach(([k, e, f]) => {
        x(k)?.addEventListener("change", () => fxSave((cp) => {
          const v = f === "color" ? x(k).value : Math.max(0, f === "opacity" ? Math.min(100, n(k, 0)) : n(k, 0));
          cp[e] = Object.assign({}, cp[e] || {}, { enabled: true, [f]: v });
        }));
      });
    },
    // a rule with the look applied (null fields taken away), its own place / size / text settings kept
    applyToRule(rule, st) {
      const out = Object.assign({}, rule || {});
      Object.entries(this.cardToStrip(st)).forEach(([k, v]) => { if (v == null) delete out[k]; else out[k] = v; });
      return out;
    },
  };

  return { draw, drawShape };
})();
