/* Workspace guard: a game's workspace only takes that game's Excel.
   While a game is open, a new Excel path (typed, pasted or browsed, anywhere in the app) is
   checked against the game's fingerprint (its own symbols and sheet names) before it is used.
   An Excel from another game asks the user: switch to that game, make a new workspace,
   confirm it really is this game (a much-changed revision), or keep the current Excel. */
(() => {
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const realSet = App.set;
  let bypass = false, busy = false;

  App.set = (key, value) => {
    const c = App.state.config || {};
    if (key === "excel_path" && !bypass && c.active_game && value && value !== c.excel_path
        && /\.(xlsx|xlsm|xls)"?$/i.test(String(value).trim())) {
      App.guardExcel(String(value).trim().replace(/^"|"$/g, ""));
      return undefined;                          // used once it passes (or the user says so)
    }
    return realSet(key, value);
  };

  function use(path) {
    bypass = true;
    try { realSet("excel_path", path); } finally { bypass = false; }
    App.refreshUI();
    if (App.scan) App.scan();
    renderRoute();
  }
  const folderOf = (p) => String(p).replace(/[\\/][^\\/]*$/, "");
  const fileOf = (p) => String(p).split(/[\\/]/).pop();

  App.guardExcel = async (path) => {
    if (busy) return;
    busy = true;
    try {
      let r;
      try { r = await api("/api/games/check_excel", { method: "POST", body: { excel_path: path } }); }
      catch (_) { r = { same: true }; }          // can't tell: never block the user's work
      if (!r || r.same) { use(path); return; }
      const other = (r.other || [])[0];
      const options = [{ label: "Keep the current Excel", value: null }];
      options.push({ label: `It is ${r.game}`, value: "accept" });
      if (other) options.push({ label: `Switch to ${other.name}`, value: "switch", primary: true });
      options.push({ label: "New workspace", value: "new", primary: !other });
      const pick = await App.choose(`This Excel isn't from ${r.game}`,
        `<div>You're working in the <b>${esc(r.game)}</b> workspace${r.market ? ` (market <b>${esc(r.market)}</b>)` : ""}.</div>
         <div style="margin-top:8px"><code>${esc(fileOf(path))}</code> doesn't look like ${esc(r.game)}: it has different symbols and sheets.
           Using it here would build ${esc(r.game)}'s PSDs from another game's text.</div>
         ${other ? `<div style="margin-top:8px">It looks like <b>${esc(other.name)}</b> — switch to that workspace?</div>`
                 : `<div style="margin-top:8px">To avoid mixing games up, make a <b>new workspace</b> for it (its folder is scanned for markets, symbols and background).</div>`}
         <div class="hint" style="margin-top:8px"><b>It is ${esc(r.game)}</b>: only when this really is a new revision of this game's AGR.</div>`,
        options);
      if (pick === "accept") {
        await api("/api/games/accept_excel", { method: "POST", body: { excel_path: path } });
        use(path);
        toast(`Remembered: this Excel belongs to ${r.game}.`);
      } else if (pick === "switch" && other) {
        await App.gameOpen(other.id, other.market);
      } else if (pick === "new") {
        navigate("dashboard");
        setTimeout(() => App.gameAddFrom && App.gameAddFrom(folderOf(path)), 50);
      } else {
        renderRoute();                           // the fields show the Excel still in use
        toast(`Still using ${fileOf(App.state.config.excel_path || "") || "the current Excel"}.`);
      }
    } finally {
      busy = false;
    }
  };
})();
