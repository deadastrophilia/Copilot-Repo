/* ---------------------------------------------------------------------------
 * Visualiser addon — visual layout editor for NORMAL pages.
 *
 * Self-contained module (mirrors pt-editor.js style). Hooked into the app by
 * app.js (route "visualiser"). It only edits the existing settings through
 * App.set + POST /api/config and reuses the real PNG renderer for the
 * preview, so it never touches the rendering pipeline, the PSD, or the
 * existing Preview panel.
 * ------------------------------------------------------------------------- */
(function () {
  "use strict";
  if (window.AppVis) return;

  const V = {
    _bound: false,
    state: {
      sheets: [],
      sheet: "",
      meta: null,
      geometry: null,
      guides: [],
      scale: 1,
      tx: 0,
      ty: 0,
      fitted: false,
      undo: [],
      redo: [],
      drag: null,
      pan: null,
      mode: "static",
    },
  };

  const MIN_SCALE = 0.02;
  const MAX_SCALE = 8;

  function el(id) {
    return document.getElementById(id);
  }

  function rgbToHex(rgb) {
    if (Array.isArray(rgb) && rgb.length >= 3) {
      return "#" + rgb.slice(0, 3).map((c) => Math.max(0, Math.min(255, Math.round(Number(c) || 0))).toString(16).padStart(2, "0")).join("").toUpperCase();
    }
    return typeof rgb === "string" && /^#/.test(rgb) ? rgb : "#FFFFFF";
  }

  function hexToRgb(hex) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || "").trim());
    if (!m) return [255, 255, 255];
    const n = parseInt(m[1], 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }

  function snapConfig() {
    try {
      return JSON.parse(JSON.stringify(App.state.config));
    } catch (e) {
      return null;
    }
  }

  function pushUndo() {
    const s = snapConfig();
    if (!s) return;
    V.state.undo.push(s);
    if (V.state.undo.length > 60) V.state.undo.shift();
    V.state.redo = [];
  }

  function applyConfig(cfg) {
    App.state.config = cfg;
    App.pushConfig();
    renderRoute();
  }

  function setBadge(mode, text) {
    const badge = el("visBadge");
    if (!badge) return;
    badge.classList.toggle("idle", mode === "idle");
    badge.textContent = text || (mode === "busy" ? "Rendering…" : "Ready");
  }

  /* ------------------------------ views ------------------------------ */

  function controlsHTML(meta) {
    const sections = meta.controls || [];
    return sections.map((sec) => {
      let body = "";
      if (sec.styles) {
        body = sec.styles.map((st) => {
          const head = st.name
            ? `${esc(st.title)} <span class="vis-style-src">· “${esc(st.name)}”</span>`
            : esc(st.title) + " <span class=\"vis-style-src\">· default</span>";
          return `<div class="vis-style-block"><div class="vis-style-title">${head}</div>${st.fields.map((f) => ctlField(st.path.concat([f.field]).join("."), f)).join("")}</div>`;
        }).join("");
      } else {
        body = (sec.items || []).map((f) => ctlField(f.key, f)).join("");
      }
      return `<div class="collapse"><button class="collapse-head" onclick="this.parentElement.classList.toggle('open')">${esc(sec.title)} ${icon("chevron")}</button><div class="collapse-body">${body || `<div class="hint" style="padding:8px 2px">No controls in this section.</div>`}</div></div>`;
    }).join("");
  }

  function ctlField(key, f) {
    const val = App.get(key);
    switch (f.type) {
      case "font":
        return fontField(key, f.label, f.placeholder || "ArialMT");
      case "color":
        if (f.tuple) {
          return `<div class="pt-ctl"><div class="pt-ctl-label"><span>${esc(f.label)}</span></div><input type="color" data-viscolor="${esc(key)}" value="${esc(rgbToHex(val))}" /></div>`;
        }
        return colorField(key, f.label);
      case "toggle":
        return toggleRow(key, f.label, f.hint || "");
      case "select": {
        const opts = (f.options || []).map((o) => ({ value: String(o), label: String(o) }));
        return selectField(key, f.label, opts);
      }
      case "slider":
        return ptSlider(key, f.label, { min: f.min || 0, max: f.max || 400, step: f.step || 1, unit: f.unit || "px", hint: f.hint || "" });
      case "info":
        return `<div class="hint vis-info">${esc(f.text || "")}</div>`;
      default:
        return field(key, f.label, { type: f.type || "number", hint: f.hint || "" });
    }
  }

  V.view = function () {
    const cfg = App.state.config || {};
    const meta = V.state.meta;
    const sheets = meta && meta.sheets ? meta.sheets : V.state.sheets;
    const current = V.state.sheet || (sheets && sheets[0]) || "";
    const sheetOpts = sheets && sheets.length
      ? sheets.map((n) => `<option value="${esc(n)}" ${n === current ? "selected" : ""}>${esc(n)}</option>`).join("")
      : "";
    const excelOk = !cfg.excel_path ? false : true;
    const excelBlock = excelOk
      ? ""
      : `<div class="empty" style="margin:14px"><div class="empty-icon">▤</div><div class="empty-title">No workbook configured</div><div class="empty-sub">Set the Excel file in the Project view, then open the Visualiser again.</div></div>`;
    return `<div class="view">
      <div class="view-header">
        <div class="view-title">Visualiser</div>
        <div class="view-sub">Visual layout editor for normal pages — drag guides and edit controls; everything writes the real renderer settings. Non-destructive.</div>
      </div>
      <div class="pt-workspace">
        <div class="pt-grid">
          <div class="pt-card vis-canvas-card" style="grid-column: span 8; min-width: 0;">
            <div class="pt-card-head">
              <div class="pt-card-title"><span class="pt-chip">▦</span><span>Canvas</span><span class="pt-pill idle" id="visBadge">Ready</span></div>
              <div class="pt-card-sub">Real Excel heading + body + icons rendered by the actual PNG page renderer — what you see is the output.</div>
            </div>
            <div class="pt-preview-head">
              <span class="pt-preview-name" id="visSheetName" title="Current sheet">${current ? esc(current) : "No normal page"}</span>
              <span style="flex:1"></span>
              <label style="font-size:12px;color:var(--pt-text2)">Sheet</label>
              <select id="visSheet" style="max-width:280px" ${sheetOpts ? "" : "disabled"}>${sheetOpts}</select>
            </div>
            <div class="vis-toolbar">
              <div class="vis-mode">
                <button class="pt-btn small on" id="visModeStatic" onclick="AppVis.setMode('static')">Static</button>
                <button class="pt-btn small" id="visModeLive" onclick="AppVis.setMode('live')">LIVE renderer</button>
              </div>
              <button class="pt-btn small" onclick="AppVis.fit()" title="Fit page to window">⛶ Fit</button>
              <button class="pt-btn small" onclick="AppVis.setZoom(1)" title="Actual size">100%</button>
              <button class="pt-btn small" onclick="AppVis.center()" title="Center page">⌖ Center</button>
              <button class="pt-btn small" onclick="AppVis.zoomBy(1.25)" title="Zoom in">+</button>
              <button class="pt-btn small" onclick="AppVis.zoomBy(0.8)" title="Zoom out">−</button>
              <span style="flex:1"></span>
              <span class="vis-zoom-label" id="visZoomLabel">fit</span>
              <button class="pt-btn small" onclick="AppVis.undo()" title="Ctrl+Z">↶ Undo</button>
              <button class="pt-btn small" onclick="AppVis.redo()" title="Ctrl+Y">↷ Redo</button>
              <button class="pt-btn secondary small" onclick="AppVis.refreshPreview(true)">⟳ Render</button>
            </div>
            <div class="vis-live-bar" id="visLiveBar" style="display:none">
              <button class="pt-btn small" id="visLiveVerify" onclick="AppLive.verify()">Verify WYSIWYG</button>
              <button class="pt-btn small" onclick="AppLive.toggleDiff()">Show diff</button>
              <span id="visLiveVerifyNote" class="vis-live-note"></span>
              <span id="visLiveNote" class="vis-live-note"></span>
              <span style="flex:1"></span>
              <span class="vis-live-hint">click select · drag move · corner scale · top handle rotate · ⇧ arrows nudge</span>
            </div>
            <div class="vis-host" id="visHost">
              <div class="vis-stage" id="visStage">
                <img id="visPageImg" class="vis-img" alt="Page preview" draggable="false" />
                <canvas id="visLiveCanvas" class="vis-live-canvas" style="display:none"></canvas>
                <div class="vis-guides" id="visGuides"></div>
                <div class="vis-diff" id="visLiveDiff" style="display:none"><img id="visLiveDiffImg" alt="diff" /></div>
              </div>
            </div>
            <div class="vis-hint-row"><span>Scroll to zoom · drag the shaded guides to edit margins · drag empty space to pan</span></div>
            ${excelBlock}
          </div>
          <div class="pt-card vis-controls-card" style="grid-column: span 4; min-width: 0;">
            <div class="pt-card-head">
              <div class="pt-card-title"><span class="pt-chip">⚙</span><span>Controls</span></div>
              <div class="pt-card-sub">Every control edits the current settings and re-renders the page live.</div>
            </div>
            <div id="visControls"><div class="hint" style="padding:12px">Loading…</div></div>
          </div>
        </div>
      </div>
    </div>`;
  };

  /* ------------------------------ canvas ------------------------------ */

  function layout() {
    const host = el("visHost");
    const stage = el("visStage");
    if (!host || !stage || !V.state.geometry) return;
    const g = V.state.geometry;
    const s = V.state.scale;
    stage.style.width = (g.canvas_w * s) + "px";
    stage.style.height = (g.canvas_h * s) + "px";
    stage.style.transform = "translate(" + V.state.tx + "px," + V.state.ty + "px)";
    const zl = el("visZoomLabel");
    if (zl) zl.textContent = Math.round(s * 100) + "%";
    renderGuides();
    if (V.state.mode === "live" && window.AppLive) AppLive.resize();
  }

  function posForValue(gd, geometry, value) {
    if (gd.edge === "top") return value;
    if (gd.edge === "gap") return geometry.heading_bottom + value;
    if (gd.edge === "bottom") return geometry.canvas_h - value;
    if (gd.edge === "left") return (geometry.canvas_w - value) / 2;
    return (geometry.canvas_w + value) / 2; // right
  }

  function renderGuides() {
    const hostEl = el("visGuides");
    if (!hostEl || !V.state.geometry) return;
    const g = V.state.geometry;
    const s = V.state.scale;
    const rects = [
      { cls: "vis-rect-safe", l: g.safe_left * s, t: g.body_top * s, w: (g.safe_right - g.safe_left) * s, h: (g.body_bottom - g.body_top) * s },
      { cls: "vis-rect-head", l: g.safe_left * s, t: g.heading_top * s, w: (g.safe_right - g.safe_left) * s, h: (g.heading_bottom - g.heading_top) * s },
    ];
    const rectHTML = rects.filter((r) => r.w > 0 && r.h > 0 && isFinite(r.w) && isFinite(r.h))
      .map((r) => `<div class="vis-rect ${r.cls}" style="left:${r.l}px;top:${r.t}px;width:${r.w}px;height:${r.h}px"></div>`).join("");
    const lineHTML = (V.state.guides || []).map((gd) => {
      if (gd.orientation === "h") {
        return `<div class="vis-guide vis-guide-h" data-gid="${gd.id}" data-edge="${gd.edge}" style="top:${gd.y0 * s}px"><span class="vis-guide-tag">${esc(gd.label)}</span></div>`;
      }
      return `<div class="vis-guide vis-guide-v" data-gid="${gd.id}" data-edge="${gd.edge}" style="left:${gd.x0 * s}px"><span class="vis-guide-tag">${esc(gd.label)}</span></div>`;
    }).join("");
    hostEl.innerHTML = rectHTML + lineHTML;
  }

  function fit() {
    const host = el("visHost");
    if (!host || !V.state.geometry) return;
    const rect = host.getBoundingClientRect();
    const g = V.state.geometry;
    const s = Math.max(MIN_SCALE, Math.min((rect.width - 40) / g.canvas_w, (rect.height - 40) / g.canvas_h));
    V.state.scale = s;
    V.state.tx = Math.max(0, (rect.width - g.canvas_w * s) / 2);
    V.state.ty = Math.max(0, (rect.height - g.canvas_h * s) / 2);
    V.state.fitted = true;
    layout();
  }

  function centerOnly() {
    const host = el("visHost");
    if (!host || !V.state.geometry) return;
    const rect = host.getBoundingClientRect();
    const g = V.state.geometry;
    V.state.tx = Math.max(0, (rect.width - g.canvas_w * V.state.scale) / 2);
    V.state.ty = Math.max(0, (rect.height - g.canvas_h * V.state.scale) / 2);
    layout();
  }

  V.fit = fit;
  V.center = centerOnly;
  V.setZoom = function (z) {
    V.state.scale = Math.max(MIN_SCALE, Math.min(MAX_SCALE, z));
    centerOnly();
  };
  V.zoomBy = function (f) {
    V.setZoom(V.state.scale * f);
  };

  /* ----------------------- LIVE renderer mode ----------------------- */

  V.setMode = function (mode) {
    V.state.mode = mode === "live" ? "live" : "static";
    const st = el("visModeStatic");
    const lv = el("visModeLive");
    const img = el("visPageImg");
    const cv = el("visLiveCanvas");
    const bar = el("visLiveBar");
    if (st) st.classList.toggle("on", V.state.mode === "static");
    if (lv) lv.classList.toggle("on", V.state.mode === "live");
    if (img) img.style.display = V.state.mode === "static" ? "" : "none";
    if (cv) cv.style.display = V.state.mode === "live" ? "" : "none";
    if (bar) bar.style.display = V.state.mode === "live" ? "" : "none";
    if (!window.AppLive) {
      toast("LIVE renderer module not loaded", "warn");
      return;
    }
    if (V.state.mode === "live") {
      if (V.state.sheet) {
        AppLive.init(V.state.sheet);
        if (!V.state.geometry) V.refreshPreview(true);
      } else {
        AppLive.destroy();
      }
    } else {
      AppLive.destroy();
      V.refreshPreview(true);
    }
  };

  V.pushUndo = pushUndo;

  /* --------------------------- drag / pan / zoom --------------------------- */

  function bindCanvasEvents() {
    const host = el("visHost");
    if (!host) return;
    // Host-level listeners are re-bound on every route mount (the element is
    // rebuilt each time so old listeners die with the old node).
    host.addEventListener("wheel", (ev) => {
      ev.preventDefault();
      if (!V.state.geometry) return;
      const rect = host.getBoundingClientRect();
      const mx = ev.clientX - rect.left;
      const my = ev.clientY - rect.top;
      const prev = V.state.scale;
      const next = Math.max(MIN_SCALE, Math.min(MAX_SCALE, prev * (ev.deltaY < 0 ? 1.12 : 1 / 1.12)));
      const ratio = next / prev;
      V.state.tx = mx - (mx - V.state.tx) * ratio;
      V.state.ty = my - (my - V.state.ty) * ratio;
      V.state.scale = next;
      V.state.fitted = false;
      layout();
    }, { passive: false });

    host.addEventListener("mousedown", (ev) => {
      if (ev.button !== 0) return;
      const guideEl = ev.target.closest(".vis-guide");
      if (guideEl) {
        dragGuideStart(guideEl.dataset.gid, ev);
        return;
      }
      V.state.pan = { x: ev.clientX, y: ev.clientY, tx: V.state.tx, ty: V.state.ty };
      host.classList.add("vis-panning");
      ev.preventDefault();
    });

    if (V._bound) return;
    V._bound = true;

    document.addEventListener("mousemove", (ev) => {
      const d = V.state.drag;
      if (d) {
        dragGuideMove(ev);
        return;
      }
      const p = V.state.pan;
      if (p) {
        V.state.tx = p.tx + (ev.clientX - p.x);
        V.state.ty = p.ty + (ev.clientY - p.y);
        layout();
      }
    });

    document.addEventListener("mouseup", () => {
      if (V.state.drag) dragGuideEnd();
      V.state.pan = null;
      host.classList.remove("vis-panning");
    });

    window.addEventListener("resize", () => {
      if (App.route === "visualiser" && V.state.geometry) {
        if (V.state.fitted) fit();
        else centerOnly();
      }
    });

    document.addEventListener("keydown", (ev) => {
      if (App.route !== "visualiser") return;
      const k = ev.key.toLowerCase();
      if ((ev.ctrlKey || ev.metaKey) && k === "z" && !ev.shiftKey) {
        ev.preventDefault();
        V.undo();
      } else if ((ev.ctrlKey || ev.metaKey) && (k === "y" || (k === "z" && ev.shiftKey))) {
        ev.preventDefault();
        V.redo();
      } else if (ev.key === "Escape") {
        V.state.drag = null;
        V.state.pan = null;
      }
    }, true);
  }

  function dragGuideStart(gid, ev) {
    const gd = (V.state.guides || []).find((x) => x.id === gid);
    if (!gd || !V.state.geometry) return;
    pushUndo();
    V.state.drag = { gd, startX: ev.clientX, startY: ev.clientY };
    ev.preventDefault();
  }

  function dragGuideMove(ev) {
    const d = V.state.drag;
    const delta = (d.gd.orientation === "h" ? ev.clientY - d.startY : ev.clientX - d.startX) / V.state.scale;
    let value;
    if (d.gd.edge === "left") value = d.gd.value - 2 * delta;
    else if (d.gd.edge === "right") value = d.gd.value + 2 * delta;
    else if (d.gd.edge === "bottom") value = d.gd.value - delta;
    else value = d.gd.value + delta;
    value = Math.round(value);
    // as far as the canvas goes, whatever its size (a 4K portrait page is 3840 px tall): a guide's own max is for 1080p
    const geo = V.state.geometry, maxAllowed = geo ? (d.gd.orientation === "h" ? geo.canvas_h : geo.canvas_w - 40) : d.gd.max;
    value = Math.max(d.gd.min, Math.min(maxAllowed, value));
    d.value = value;
    const pos = posForValue(d.gd, V.state.geometry, value);
    const line = document.querySelector(`.vis-guide[data-gid="${d.gd.id}"]`);
    if (line) {
      const px = pos * V.state.scale;
      if (d.gd.orientation === "h") line.style.top = px + "px";
      else line.style.left = px + "px";
    }
  }

  function dragGuideEnd() {
    const d = V.state.drag;
    if (d && typeof d.value === "number") {
      App.set(d.gd.key, d.value);
      App.pushConfig();
      V.refreshPreview();
    }
    V.state.drag = null;
  }

  /* --------------------------- undo / redo --------------------------- */

  V.undo = function () {
    const s = V.state.undo.pop();
    if (!s) return;
    V.state.redo.push(snapConfig());
    applyConfig(s);
  };

  V.redo = function () {
    const s = V.state.redo.pop();
    if (!s) return;
    V.state.undo.push(snapConfig());
    applyConfig(s);
  };

  /* --------------------------- preview --------------------------- */

  V.refreshPreview = debounce(async function (force) {
    if (V.state.mode === "live" && window.AppLive) {
      AppLive.sync();
      if (!V.state.geometry) {
        // first open in live mode: still fetch geometry/guides from the server
        force = true;
      }
      if (!force && V.state.geometry) return;
    }
    const host = el("visHost");
    if (!host) return;
    if (!V.state.sheet) {
      setBadge("idle");
      return;
    }
    setBadge("busy");
    try {
      const d = await api("/api/visualiser/preview", { method: "POST", body: { sheet_name: V.state.sheet, force: !!force } });
      if (d && d.ok && d.preview_token) {
        const sameCanvas = V.state.geometry && V.state.geometry.canvas_w === d.canvas_width && V.state.geometry.canvas_h === d.canvas_height;
        V.state.geometry = d.geometry;
        V.state.guides = d.guides || [];
        V.state.sheet = d.sheet_name || V.state.sheet;
        const img = el("visPageImg");
        if (img) img.src = "/api/table_preview/" + encodeURIComponent(d.preview_token) + "?v=" + Date.now();
        const nameEl = el("visSheetName");
        if (nameEl) nameEl.textContent = V.state.sheet;
        if (!sameCanvas || !V.state.fitted) {
          V.state.fitted = false;
          fit();
        } else {
          layout();
        }
      } else if (d && d.error) {
        toast(d.error, "warn");
      }
    } catch (e) {
      setBadge("idle", "Preview failed: " + (e && e.message ? e.message : e));
      return;
    }
    setBadge("idle");
  }, 450);

  /* --------------------------- controls --------------------------- */

  function bindControls(root) {
    bindForms(root);
    root.querySelectorAll("input[data-viscolor]").forEach((inp) => {
      inp.addEventListener("input", () => {
        pushUndo();
        App.set(inp.dataset.viscolor, hexToRgb(inp.value));
        App.pushConfig();
        V.refreshPreview();
      });
    });
    root.querySelectorAll("[data-key]").forEach((ctl) => {
      if (ctl.tagName !== "INPUT" && ctl.tagName !== "SELECT" && ctl.tagName !== "TEXTAREA") return;
      ctl.addEventListener("input", () => { if (ctl.dataset.key) V.refreshPreview(); });
      ctl.addEventListener("change", () => { if (ctl.dataset.key) V.refreshPreview(); });
    });
    root.addEventListener("input", (ev) => {
      const key = ev.target && ev.target.dataset ? ev.target.dataset.key : null;
      if (!key) return;
      const tag = root.querySelector(`[data-val="${key}"]`);
      if (tag) tag.textContent = (parseFloat(ev.target.value) || 0) + (ev.target.dataset.unit || "px");
    });
    root.addEventListener("change", (ev) => {
      const key = ev.target && ev.target.dataset ? ev.target.dataset.key : null;
      if (key) pushUndo();
    }, true);
  }

  function fillSheetSelect() {
    const sel = el("visSheet");
    if (!sel) return;
    if (!V.state.sheets.length) {
      sel.innerHTML = `<option value="">No normal pages</option>`;
      return;
    }
    const current = V.state.sheet || V.state.sheets[0];
    sel.innerHTML = V.state.sheets.map((n) => `<option value="${esc(n)}" ${n === current ? "selected" : ""}>${esc(n)}</option>`).join("");
    sel.disabled = false;
    sel.addEventListener("change", () => {
      V.state.sheet = sel.value;
      const nameEl = el("visSheetName");
      if (nameEl) nameEl.textContent = sel.value;
      if (V.state.mode === "live" && window.AppLive) {
        AppLive.setSheet(sel.value);
      } else {
        V.refreshPreview(true);
      }
    });
  }

  V.init = async function (root) {
    bindCanvasEvents();
    const ctl = el("visControls");
    if (!ctl) return;
    try {
      const meta = await api("/api/visualiser/sheets", { method: "POST", body: {} });
      V.state.meta = meta;
      V.state.sheets = meta.sheets || [];
      if (!V.state.sheet || V.state.sheets.indexOf(V.state.sheet) === -1) {
        V.state.sheet = V.state.sheets[0] || "";
      }
      if (!meta.excel_ok) {
        ctl.innerHTML = `<div class="hint" style="padding:12px">${esc(meta.excel_error || "Excel workbook not configured.")}</div>`;
      } else {
        ctl.innerHTML = controlsHTML(meta);
        bindControls(ctl);
      }
      fillSheetSelect();
      const nameEl = el("visSheetName");
      if (nameEl) nameEl.textContent = V.state.sheet || "No normal page";
      if (V.state.sheet) V.refreshPreview();
    } catch (e) {
      ctl.innerHTML = `<div class="hint" style="padding:12px">Visualiser failed to load: ${esc(e.message)}</div>`;
    }
  };

  window.AppVis = V;
})();