/* Bingo Rules studio: the page itself, full width, edited right on the preview.

   The page is always ONE page (the renderer shrinks the text to fit). On the picture:
     · margin guides (drag): header top, heading–body gap, bottom
     · click a line of text to select it (Shift / Ctrl: several) → Left / Centre / Right / Default in
       the bar above, or right-click the selection (also: Edit text…)
     · the text size (− / +), as set — the page shows what it had to shrink it to
   Alignment lists: dynamic_settings.bingo_rules_{left,right,center}_align_cells ("B27, B28").
   Uses app.js globals: App, api, esc, toast, debounce, TextEdits. */
window.BRStudio = (() => {
  const S = { sheet: "", token: "", layout: null, sel: new Set() };
  const ALIGN_KEYS = { left: "bingo_rules_left_align_cells", right: "bingo_rules_right_align_cells", center: "bingo_rules_center_align_cells" };
  const el = (id) => document.getElementById(id);
  const ds = () => (App.state.config.dynamic_settings = App.state.config.dynamic_settings || {});

  function sheets() {
    return (App.state.scan?.excel?.sheets || []).map((s) => s.name).filter(Boolean)
      .filter((n) => String(n).toLowerCase().replace(/[^a-z0-9]+/g, "").startsWith("bingorules"));
  }

  function view() {
    const shs = sheets();
    if (!S.sheet || !shs.includes(S.sheet)) S.sheet = App.state.bgrSheetName && shs.includes(App.state.bgrSheetName) ? App.state.bgrSheetName : (shs[0] || "");
    const on = App.get("render_bingo_rules") !== false;
    return `<div class="view grs-view">
      <div class="view-header"><div class="view-title">Bingo Rules</div>
        <div class="view-sub">Always one page. Click a line of text (Shift / Ctrl for several), then align it left, centre or right — or right-click it · drag the guides for margins.</div></div>
      <div class="grs-bar">
        <label class="grs-lab">Sheet</label>
        <select id="brsSheet">${shs.map((n) => `<option ${n === S.sheet ? "selected" : ""}>${esc(n)}</option>`).join("") || `<option value="">No Bingo Rules sheet scanned</option>`}</select>
        <label class="grs-check"><input type="checkbox" id="brsOn" ${on ? "checked" : ""}> Build this page</label>
        <span class="grs-sep"></span>
        <span class="grs-lab">Text size</span>
        <button class="pt-btn secondary small" data-size="-2" title="Smaller">−</button>
        <input type="number" id="brsSize" class="vsb-num" min="8" max="200" style="width:64px">
        <button class="pt-btn secondary small" data-size="2" title="Bigger">+</button>
        <span class="grs-sep"></span>
        <span class="grs-lab">Align selected</span>
        <button class="ts-al" data-align="left" title="Align left">⯇≡</button>
        <button class="ts-al" data-align="center" title="Centre">≡</button>
        <button class="ts-al" data-align="right" title="Align right">≡⯈</button>
        <button class="pt-btn secondary small" data-align="default" title="Back to the page's alignment">Default</button>
        <span class="grs-info" id="brsInfo"></span>
        <span style="flex:1"></span>
        <span class="pt-pill idle" id="brsBadge">Ready</span>
        <button class="pt-btn secondary small" id="brsRefresh">⟳ Render</button>
      </div>
      <div class="grs-stage" id="brsStage">${S.token ? stageHtml() : `<div class="empty" style="padding:48px"><div class="empty-icon">▤</div><div class="empty-title">${shs.length ? "Rendering…" : "No Bingo Rules sheet"}</div></div>`}</div>
    </div>`;
  }
  const stageHtml = () => `<div class="grs-page" id="brsPage"><img id="brsImg" src="/api/table_preview/${encodeURIComponent(S.token)}?v=${Date.now()}" alt="Bingo Rules" draggable="false"><div class="grs-ov" id="brsOv"></div></div>`;

  async function refresh() {
    if (!S.sheet) return;
    const badge = el("brsBadge");
    if (badge) { badge.classList.remove("idle"); badge.textContent = "Rendering…"; }
    try {
      await App.flushConfig();
      const d = await api("/api/bingo_rules/preview", { method: "POST", body: { sheet_name: S.sheet } });
      if (!d || !d.ok) { if (d && d.error) toast(d.error, "warn"); return; }
      S.token = d.preview_token;
      S.layout = d.layout || null;
      const stage = el("brsStage");
      if (!stage) return;
      const img = el("brsImg");
      if (!img) { stage.innerHTML = stageHtml(); el("brsImg").addEventListener("load", draw); }
      else { img.onload = draw; img.src = "/api/table_preview/" + encodeURIComponent(S.token) + "?v=" + Date.now(); }
      const sz = (S.layout || {}).sizes || {};
      const size = el("brsSize");
      if (size && document.activeElement !== size) size.value = sz.body_set || "";
      const info = el("brsInfo");
      if (info) info.textContent = sz.body && sz.body < sz.body_set ? `drawn at ${sz.body}px to stay on one page` : "";
    } catch (e) {
      toast("Bingo Rules preview failed: " + ((e && e.message) || e), "err");
    } finally {
      if (badge) { badge.classList.add("idle"); badge.textContent = "Ready"; }
    }
  }
  const schedule = debounce(refresh, 350);

  function geo() {
    const img = el("brsImg"), L = S.layout;
    if (!img || !L || !L.canvas) return null;
    return { cw: L.canvas[0], ch: L.canvas[1] };
  }
  const pct = (v, of) => (v / of * 100).toFixed(4) + "%";

  function draw() {
    const ov = el("brsOv"), L = S.layout, g = geo();
    if (!ov || !L || !g) return;
    const G = L.guides || {};
    let html = "";
    if (G.heading_top != null) {
      html += `<div class="vis-rect vis-rect-head" style="left:${pct(G.margin_x, g.cw)};top:${pct(G.heading_top, g.ch)};width:${pct(g.cw - 2 * G.margin_x, g.cw)};height:${pct(G.heading_bottom - G.heading_top, g.ch)}"></div>`;
      html += `<div class="vis-rect vis-rect-safe" style="left:${pct(G.margin_x, g.cw)};top:${pct(G.body_top, g.ch)};width:${pct(g.cw - 2 * G.margin_x, g.cw)};height:${pct(G.safe_bottom - G.body_top, g.ch)}"></div>`;
      for (const [id, at, label] of [["top", G.heading_top, "Header Top Margin"], ["gap", G.body_top, "Heading–Body Gap"], ["bottom", G.safe_bottom, "Bottom Margin"]]) {
        html += `<div class="vis-guide vis-guide-h brs-guide" data-g="${id}" style="top:${pct(at, g.ch)}"><span class="vis-guide-tag">${label}</span></div>`;
      }
      // left / right margin: this page's own (both sides together)
      html += `<div class="vis-guide vis-guide-v brs-guide" data-g="side" data-side="l" style="left:${pct(G.margin_x, g.cw)}"><span class="vis-guide-tag" style="top:auto;bottom:40px">Left Margin</span></div>`;
      html += `<div class="vis-guide vis-guide-v brs-guide" data-g="side" data-side="r" style="left:${pct(g.cw - G.margin_x, g.cw)}"><span class="vis-guide-tag" style="top:auto;bottom:40px;left:auto;right:5px">Right Margin</span></div>`;
    }
    (L.cells || []).forEach((c, i) => {
      const r = c.rect;
      html += `<div class="grs-hit line brs-cell ${S.sel.has(c.cell) ? "sel" : ""}" data-i="${i}" data-cell="${esc(c.cell)}" title="${esc(c.cell)} · ${esc(c.align)}"
        style="left:${pct(r[0] - 3, g.cw)};top:${pct(r[1] - 3, g.ch)};width:${pct(r[2] + 6, g.cw)};height:${pct(r[3] + 6, g.ch)}">
        <span class="brs-al">${c.align === "left" ? "⯇" : c.align === "right" ? "⯈" : ""}</span></div>`;
    });
    ov.innerHTML = html;
    ov.querySelectorAll(".brs-cell").forEach((n) => {
      n.addEventListener("click", (ev) => {
        ev.stopPropagation();
        const cell = n.dataset.cell;
        if (ev.shiftKey || ev.ctrlKey || ev.metaKey) { if (S.sel.has(cell)) S.sel.delete(cell); else S.sel.add(cell); }
        else { S.sel = new Set([cell]); }
        draw();
      });
      n.addEventListener("contextmenu", (ev) => {
        ev.preventDefault();
        ev.stopPropagation();
        if (!S.sel.has(n.dataset.cell)) S.sel = new Set([n.dataset.cell]);
        draw();
        menu(ev);
      });
    });
    ov.querySelectorAll(".brs-guide").forEach((n) => n.addEventListener("pointerdown", (ev) => dragGuide(ev, n, g)));
  }

  function dragGuide(ev, n, g) {
    ev.preventDefault();
    ev.stopPropagation();
    const G = S.layout.guides || {};
    try { n.setPointerCapture(ev.pointerId); } catch (_) { /* moves still reach it */ }
    let val = null;
    const move = (e) => {
      const r = el("brsImg").getBoundingClientRect();
      const y = (e.clientY - r.top) / r.height * g.ch, x = (e.clientX - r.left) / r.width * g.cw;
      const id = n.dataset.g;
      if (id === "side") {                       // both sides move together, from their own edge
        val = Math.max(0, Math.min(Math.round(g.cw * 0.45), Math.round(n.dataset.side === "r" ? g.cw - x : x)));
        el("brsOv").querySelectorAll('.brs-guide[data-g="side"]').forEach((line) => {
          line.style.left = pct(line.dataset.side === "r" ? g.cw - val : val, g.cw);
        });
        return;
      }
      val = id === "top" ? Math.max(0, Math.round(y)) : id === "gap" ? Math.max(0, Math.round(y - G.heading_bottom)) : Math.max(0, Math.round(g.ch - y));
      n.style.top = pct(id === "gap" ? G.heading_bottom + val : id === "bottom" ? g.ch - val : val, g.ch);
    };
    const up = () => {
      n.removeEventListener("pointermove", move);
      n.removeEventListener("pointerup", up);
      if (val == null) return;
      if (n.dataset.g === "side") ds().bingo_rules_side_margin = val;     // this page only
      else App.set({ top: "heading_top_margin", gap: "heading_to_body_gap", bottom: "bottom_margin" }[n.dataset.g], val);
      App.pushConfig();
      refresh();
    };
    n.addEventListener("pointermove", move);
    n.addEventListener("pointerup", up);
  }

  /* the cells' alignment: each cell in at most one of the three lists; "default" = in none */
  function setAlign(al) {
    const cells = [...S.sel];
    if (!cells.length) { toast("Click a line of text first (Shift / Ctrl for several)."); return; }
    const d = ds();
    for (const [k, key] of Object.entries(ALIGN_KEYS)) {
      const list = String(d[key] || "").split(/[\s,;]+/).map((c) => c.trim().toUpperCase()).filter(Boolean).filter((c) => !cells.includes(c));
      if (al === k) list.push(...cells);
      d[key] = list.join(", ");
    }
    if (al === "default") {
      // the built-in defaults (B27/B28 left, H27/H28 right) don't apply to a cell put back on purpose
      const keep = String(d[ALIGN_KEYS.center] || "").split(/[\s,;]+/).filter(Boolean);
      const builtIn = ["B27", "B28", "H27", "H28"].filter((c) => cells.includes(c));
      if (builtIn.length && (S.layout.default_align || "center") === "center") d[ALIGN_KEYS.center] = keep.concat(builtIn).join(", ");
    }
    App.pushConfig();
    toast(al === "default" ? "Back to the page's alignment." : `Aligned ${al === "center" ? "centre" : al}: ${cells.join(", ")}`);
    refresh();
  }

  function menu(ev) {
    document.querySelectorAll(".brs-menu").forEach((m) => m.remove());
    const page = el("brsPage"), pr = page.getBoundingClientRect();
    const m = document.createElement("div");
    m.className = "tsel-menu brs-menu";
    const cells = [...S.sel];
    const edited = cells.some((c) => TextEdits.get(S.sheet, c));
    m.innerHTML = `<button data-a="left">Align left</button><button data-a="center">Align centre</button><button data-a="right">Align right</button>
      <button data-a="default">Page's alignment</button><div class="tsel-msep"></div>
      <button data-e="edit">Edit text…</button>${edited ? `<button data-e="excel">Back to the Excel text</button>` : ""}`;
    page.appendChild(m);
    Object.assign(m.style, { left: Math.min(pr.width - m.offsetWidth - 6, ev.clientX - pr.left) + "px", top: Math.min(pr.height - m.offsetHeight - 6, ev.clientY - pr.top) + "px" });
    ["mousedown", "pointerdown", "click"].forEach((t) => m.addEventListener(t, (e) => e.stopPropagation()));
    m.querySelectorAll("[data-a]").forEach((b) => b.addEventListener("click", () => { m.remove(); setAlign(b.dataset.a); }));
    m.querySelectorAll("[data-e]").forEach((b) => b.addEventListener("click", async () => {
      m.remove();
      if (b.dataset.e === "excel") TextEdits.clear(S.sheet, cells);
      else {
        const c = (S.layout.cells || []).find((x) => x.cell === cells[0]);
        const next = await TextEdits.editor("Edit the text", c ? c.text : "");
        if (next == null) return;
        TextEdits.put(S.sheet, cells[0], c ? c.text : "", next.replace(/\r/g, ""));
      }
      await TextEdits.save();
      refresh();
    }));
  }

  function init() {
    el("brsSheet")?.addEventListener("change", (e) => { S.sheet = e.target.value; App.state.bgrSheetName = S.sheet; S.sel.clear(); refresh(); });
    el("brsOn")?.addEventListener("change", (e) => { App.set("render_bingo_rules", e.target.checked); App.pushConfig(); });
    el("brsRefresh")?.addEventListener("click", () => refresh());
    document.querySelectorAll("[data-align]").forEach((b) => b.addEventListener("click", () => setAlign(b.dataset.align)));
    document.querySelectorAll("[data-size]").forEach((b) => b.addEventListener("click", () => {
      const cur = Number(ds().bingo_rules_body_size) || ((S.layout || {}).sizes || {}).body_set || 24;
      ds().bingo_rules_body_size = Math.max(8, Math.min(200, cur + Number(b.dataset.size)));
      App.pushConfig();
      refresh();
    }));
    el("brsSize")?.addEventListener("change", (e) => {
      ds().bingo_rules_body_size = Math.max(8, Math.min(200, Number(e.target.value) || 24));
      App.pushConfig();
      refresh();
    });
    el("brsStage")?.addEventListener("click", () => { if (S.sel.size) { S.sel.clear(); draw(); } });
    document.addEventListener("click", () => document.querySelectorAll(".brs-menu").forEach((m) => m.remove()));
    refresh();
  }

  window.addEventListener("resize", () => { if (App.route === "bingorules") draw(); });
  return { view, init, refresh, schedule, get state() { return S; } };
})();
