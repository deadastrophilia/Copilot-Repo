/* ---------------------------------------------------------------------------
 * Typography live preview — a copy of the Visualiser canvas (real PNG render
 * + heading/body guideline overlay) embedded in the Typography view.
 *
 * Deliberately window-only: no controls panel, no undo — just the live
 * preview and the guidelines. Settings changes made anywhere on the Typography
 * view re-render it automatically (AppTypoVis.schedule() is called from
 * App.updatePreview). The margin guides are draggable (same as the Visualiser)
 * and write the real renderer settings through App.set/App.pushConfig.
 * ------------------------------------------------------------------------- */
(function () {
  "use strict";
  const esc = window.esc || ((v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])));
  if (window.AppTypoVis) return;

  const V = {
    state: {
      sheets: [],
      sheet: "",
      geometry: null,
      guides: [],
      scale: 1,
      tx: 0,
      ty: 0,
      fitted: false,
      pan: null,
      drag: null,
    },
  };

  const MIN_SCALE = 0.02;
  const MAX_SCALE = 2;                    // 200 %: further in, the page picture gets so big that drawing lags

  /* Same guide definitions the server computes for the Visualiser view
     (visualiser_state.GUIDE_DEFS) — the typography preview derives them
     client-side from the live-renderer geometry. */
  const TYPO_GUIDE_DEFS = [
    { id: "header_top", label: "Header Top Margin", key: "heading_top_margin", orientation: "h", edge: "top", min: 0, max: 800 },
    // (pulled up as far as wanted — over the heading too: the text then overlaps it)
    { id: "heading_gap", label: "Heading–Body Gap", key: "heading_to_body_gap", orientation: "h", edge: "gap", min: -5000, max: 2000 },
    { id: "body_bottom", label: "Bottom Margin", key: "bottom_margin", orientation: "h", edge: "bottom", min: 0, max: 1000 },
    { id: "safe_left", label: "Inner Canvas Width", key: "inner_canvas_width", orientation: "v", edge: "left", min: 100, max: 5000 },
    { id: "safe_right", label: "Inner Canvas Width", key: "inner_canvas_width", orientation: "v", edge: "right", min: 100, max: 5000 },
  ];

  // a page with the "(Continued)" line: its own two gaps (Typography › Continued), dragged like the others;
  // the Heading–Body Gap guide is page 1's (a page without that line)
  const CONT_GUIDE_DEFS = [
    { id: "cont_gap", label: "Heading–Continued Gap", key: "continued_gap", orientation: "h", edge: "cgap", min: 2, max: 400 },
    { id: "cont_body", label: "Continued–Body Gap", key: "dynamic_settings.continued_body_gap", orientation: "h", edge: "cbody", min: 0, max: 600 },
  ];

  function continuedGuides(g) {
    const pg = ((window.AppLive && AppLive.state.pages) || [])[V.state.page] || {};
    const ce = (pg.elements || []).find((e) => e.role === "continued");
    if (!ce) return null;
    const top = Number(ce.y) || 0, bottom = top + (Number(ce.h) || 0);
    const set = App.get("dynamic_settings.continued_body_gap");
    const cg = Math.max(0, Number(App.get("continued_gap")) || 15);
    const floor = g.heading_bottom + Math.max(0, Number(App.get("heading_to_body_gap")) || 0) - bottom;
    const body = set !== "" && set != null ? Math.max(0, Number(set) || 0) : Math.max(cg, Math.round(floor));
    return CONT_GUIDE_DEFS.map((gd) => {
      const base = gd.edge === "cgap" ? g.heading_bottom : bottom;
      const value = gd.edge === "cgap" ? Math.max(0, Math.round(top - g.heading_bottom)) : body;
      return Object.assign({}, gd, { x0: 0, x1: g.canvas_w, y0: base + value, y1: base + value, value, base });
    });
  }

  function computeTypoGuides(g) {
    const cw = g.canvas_w, ch = g.canvas_h;
    const cont = continuedGuides(g);
    return TYPO_GUIDE_DEFS.filter((gd) => !(cont && gd.edge === "gap")).map((gd) => {
      let x0 = 0, y0 = 0, x1 = cw, y1 = ch, value = 0;
      if (gd.edge === "top") { y0 = y1 = g.heading_top; value = g.heading_top; }
      else if (gd.edge === "gap") { y0 = y1 = g.body_top; value = g.body_top - g.heading_bottom; }
      else if (gd.edge === "bottom") { y0 = y1 = g.body_bottom; value = Math.max(0, ch - g.body_bottom); }
      else if (gd.edge === "left") { x0 = x1 = g.safe_left; value = Math.max(0, cw - 2 * g.safe_left); }
      else { x0 = x1 = g.safe_right; value = Math.max(0, 2 * g.safe_right - cw); }
      return Object.assign({}, gd, { x0, y0, x1, y1, value });
    }).concat(cont || []);
  }

  function redrawCanvas() {
    if (SP()) { SP().redraw(); return; }   // a paytable page: the card view
    const c = el("typoVisCanvas");
    if (c && window.AppLive && window.AppLive.redrawInto) window.AppLive.redrawInto(c);
  }

  function el(id) {
    return document.getElementById(id);
  }

  /* ------------------------------ markup ------------------------------ */

  V.canvasHTML = function () {
    return `
      <div class="typo-vis">
        <div class="pt-preview-head">
          <span class="pt-preview-name">Live Preview</span>
          <span style="flex:1"></span>
          <label style="font-size:12px;color:var(--pt-text2)">Sheet</label>
          <select id="typoVisSheet" style="max-width:260px" disabled></select>
          <span class="pt-pill idle" id="typoVisBadge">Ready</span>
        </div>
        <div class="vis-toolbar">
          ${App.histBar ? App.histBar() : ""}
          <button class="pt-btn small" onclick="AppTypoVis.fit()" title="Fit page to window">⛶ Fit</button>
          <button class="pt-btn small ${bgLocked() ? "" : "on"}" id="typoVisBg" onclick="AppTypoVis.toggleBgLock()" title="The background is locked — click to unlock it, then click it on the page to change how it sits (fill, fit, fit width, placed)">${bgLocked() ? "🔒" : "🔓"} BG</button>
          <button class="pt-btn small ${V.state.clean ? "on" : ""}" id="typoVisClean" onclick="AppTypoVis.toggleClean()" title="The page as it renders — no guides, frames or handles (Ctrl+H; again: back)">👁 Preview</button>
          <button class="pt-btn small" onclick="AppTypoVis.setZoom(1)" title="Actual size">100%</button>
          <button class="pt-btn small" onclick="AppTypoVis.center()" title="Center page">⌖ Center</button>
          <button class="pt-btn small" onclick="AppTypoVis.zoomBy(1.25)" title="Zoom in">+</button>
          <button class="pt-btn small" onclick="AppTypoVis.zoomBy(0.8)" title="Zoom out">−</button>
          <span class="tblv-pages" title="Pages of this sheet">
            <button class="pt-btn small" id="typoVisPrev" title="Previous page">◀</button>
            <span id="typoVisPage">Page 1</span>
            <button class="pt-btn small" id="typoVisNext" title="Next page">▶</button></span>
          <span style="flex:1"></span>
          <span class="vis-zoom-label" id="typoVisZoom">fit</span>
          <button class="pt-btn secondary small" onclick="AppTypoVis.refreshPreview(true)">⟳ Render</button>
        </div>
        <div class="vis-host typo-vis-host" id="typoVisHost">
          <div class="vis-stage" id="typoVisStage">
            <canvas id="typoVisCanvas" class="vis-img" draggable="false"></canvas>
            <div class="vis-guides" id="typoVisGuides"></div>
          </div>
        </div>
      </div>`;
  };

  /* ------------------------------ canvas ------------------------------ */

  function setBadge(mode, text) {
    const badge = el("typoVisBadge");
    if (!badge) return;
    badge.classList.toggle("idle", mode === "idle");
    badge.textContent = text || (mode === "busy" ? "Rendering…" : "Ready");
  }

  /* The background: locked (not picked by a click) until 🔒 BG unlocks it; unlocked, a click on the page
     where there is no text / icon / table opens its bar — how it sits: fill, stretch, fit, fit width
     (top / middle / bottom), placed (x, y, w, h), and the colour behind it. It is never dragged. */
  function bgLocked() { return App.get("bg_locked") !== false; }
  V.toggleBgLock = function () {
    App.set("bg_locked", !bgLocked());
    App.pushConfig();
    const b = el("typoVisBg");
    if (b) { b.textContent = (bgLocked() ? "🔒" : "🔓") + " BG"; b.classList.toggle("on", !bgLocked()); }
    if (bgLocked()) hideBgBar();
    else { showBgBar(); toast("Background unlocked — click it on the page to change how it sits."); }
  };
  function showBgBar() {
    const host = el("typoVisHost");
    if (!host) return;
    let bar = host.querySelector(".bgm-bar");
    if (!bar) {
      bar = document.createElement("div");
      bar.className = "bgm-bar";
      ["mousedown", "pointerdown", "click", "dblclick", "wheel"].forEach((ty) => bar.addEventListener(ty, (ev) => ev.stopPropagation()));
      host.appendChild(bar);
    }
    bar.innerHTML = `<div class="bgm-title"><b>Background · how it sits</b><span><button class="pt-btn small" onclick="AppTypoVis.toggleBgLock()" title="Lock the background again">🔒 Lock</button> <button class="pt-btn small" onclick="this.closest('.bgm-bar').remove()" title="Close">✕</button></span></div>
      ${App.get("bg_source") === "color" ? `<div class="hint">A solid colour — pick a picture in Background settings.</div>` : `<div class="bgm-box">${App.bgModeHtml()}</div>`}`;
  }
  function hideBgBar() { const b = document.querySelector("#typoVisHost .bgm-bar"); if (b) b.remove(); }
  V.showBgBar = showBgBar;

  /* Ctrl+H: the page alone, as it renders — the guides, frames, handles and overlays hidden (CSS
     .typo-clean); again: all back. Zoom, pan and the page stay as they are */
  V.state.clean = false;
  V.toggleClean = function (on) {
    V.state.clean = on == null ? !V.state.clean : !!on;
    el("typoVisHost")?.classList.toggle("typo-clean", V.state.clean);
    el("typoVisClean")?.classList.toggle("on", V.state.clean);
    toast(V.state.clean ? "Preview: the page as it renders — Ctrl+H brings the guides back." : "Guides and handles back.");
  };
  document.addEventListener("keydown", (ev) => {
    if (!(ev.ctrlKey || ev.metaKey) || ev.altKey || ev.shiftKey || String(ev.key).toLowerCase() !== "h") return;
    if (App.route !== "typography" || !el("typoVisHost")) return;
    const a = document.activeElement, host = el("typoVisHost");
    // a field of the bars or a dialog keeps its keys (typing in the page's own text is on the Canvas)
    if (a && a !== document.body && !host.contains(a) && (a.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName))) return;
    ev.preventDefault();
    ev.stopPropagation();
    V.toggleClean();
  }, true);

  function layout() {
    const host = el("typoVisHost");
    const stage = el("typoVisStage");
    if (!host || !stage || !V.state.geometry) return;
    host.classList.toggle("typo-clean", !!V.state.clean);          // a host drawn again keeps the preview
    const g = V.state.geometry;
    const s = V.state.scale;
    host.style.setProperty("--typo-vis-ar", g.canvas_w + " / " + g.canvas_h);
    stage.style.width = (g.canvas_w * s) + "px";
    stage.style.height = (g.canvas_h * s) + "px";
    stage.style.transform = "translate(" + V.state.tx + "px," + V.state.ty + "px)";
    const zl = el("typoVisZoom");
    if (zl) zl.textContent = Math.round(s * 100) + "%";
    renderGuides();
    redrawCanvas();
    V.showTarget(V.state.target);
    if (V.state.textMode) {
      // the words lie over the page: drawn again at the new zoom, the picked ones picked again
      const t = TS, ph = V.state.wordSel, again = typoText();
      exitTextMode(again);
      if (again) { enterTextMode(null, null, t); V.state.wordSel = ph; reselect(ph); }
    }
    if (ED) placeEditor();                                   // the Notepad box follows zoom / pan
    if (window.IconStudio) IconStudio.sync();
    if (window.TableStudio) TableStudio.sync();
    if (window.AppTblVis && AppTblVis.onTypoDraw) AppTblVis.onTypoDraw();
    if (window.PaytableCanvas) PaytableCanvas.paintFrames();
    if (window.RulesCanvas) RulesCanvas.paintFrames();
    if (window.PaylinesCanvas) PaylinesCanvas.paintFrames();
  }

  /* pages of the sheet (Continued pages too) */
  function showPage(n) {
    const pages = (window.AppLive && AppLive.state && AppLive.state.pages) || [];
    if (!pages.length) return;
    V.state.page = Math.max(0, Math.min(pages.length - 1, n || 0));
    if (AppLive.state.page !== V.state.page) AppLive.setPage(V.state.page);
    redrawCanvas();
    if (V.state.geometry) { V.state.guides = computeTypoGuides(V.state.geometry); renderGuides(); }   // a Continued page has its own
    const lab = el("typoVisPage"), prev = el("typoVisPrev"), next = el("typoVisNext");
    if (lab) lab.textContent = `Page ${V.state.page + 1} of ${pages.length}`;
    if (prev) prev.disabled = V.state.page <= 0;
    if (next) next.disabled = V.state.page >= pages.length - 1;
    document.querySelectorAll("#typoPages .tp-page").forEach((b) => b.classList.toggle("on", b.dataset.sheet === V.state.sheet && Number(b.dataset.p) === V.state.page));
    if (window.IconStudio) IconStudio.sync();
    if (window.TableStudio) TableStudio.sync();
  }
  V.showPage = showPage;

  /* the All Pages rail (right): every sheet — its first page, and its Continued pages linked under
     it. The sheet being edited is drawn live (what you see, at once); the others are the build's own
     pictures (page_thumbs.py, cached), their Continued pages looked up when they scroll into view.
     Click any page: that sheet opens on that page, ready to edit. ⟳ draws the other sheets again. */
  let railTimer = 0;
  const RAIL = { stamp: "", sheet: "", counts: {} };
  function configStamp() {
    const s = JSON.stringify(App.state.config || {});
    let h = 0;
    for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
    return (h >>> 0).toString(36);
  }
  const railLabel = (p) => (p ? `Continued ${p}` : "");
  function railPage(sheet, p, src) {
    const on = sheet === V.state.sheet && p === (V.state.page || 0);
    return `<button type="button" class="tp-page ${p ? "cont" : "main"} ${on ? "on" : ""}" data-sheet="${esc(sheet)}" data-p="${p}"
        title="${esc(sheet)} — ${p ? `page ${p + 1} (Continued)` : "page 1"}">
        ${src ? `<img src="${src}" alt="" ${sheet === V.state.sheet ? "" : 'loading="lazy"'}>` : `<span class="tp-empty">…</span>`}
        <span class="tp-lab">${p ? railLabel(p) : esc(sheet)}</span></button>`;
  }
  const railSrc = (sheet, p) => `/api/pages_thumb/${encodeURIComponent(sheet)}?page=${p + 1}&v=${RAIL.stamp}`;
  function railGroup(sheet, pageHtml, known) {
    const [main, ...conts] = pageHtml;
    return `<div class="tp-group ${sheet === V.state.sheet ? "current" : ""}" data-group="${esc(sheet)}" ${known ? "" : 'data-count="?"'}>
        ${main}${conts.length ? `<div class="tp-conts">${conts.join("")}</div>` : ""}</div>`;
  }
  function openPage(sheet, p) {
    if (sheet === V.state.sheet) { showPage(p); return; }
    V.state.sheet = sheet;
    V.state.page = p;                                   // shown once the sheet is drawn (refreshPreview)
    fillSheetSelect();
    V.refreshPreview.at_once(true);
  }
  function bindRail(root) {
    root.querySelectorAll(".tp-page").forEach((b) => {
      if (b.__bound) return;
      b.__bound = true;
      b.addEventListener("click", () => openPage(b.dataset.sheet, Number(b.dataset.p)));
    });
  }
  // a sheet's Continued pages, once its group is on screen
  async function railCount(group) {
    const sheet = group.dataset.group, key = sheet + "@" + RAIL.stamp;
    group.removeAttribute("data-count");
    if (RAIL.counts[key] == null) {
      try {
        const d = await api("/api/pages_count/" + encodeURIComponent(sheet));
        RAIL.counts[key] = d && d.ok ? Math.max(1, Number(d.pages) || 1) : 1;
      } catch (e) { RAIL.counts[key] = 1; }
    }
    const n = RAIL.counts[key];
    if (!group.isConnected) return;
    // patched like the rail (patchRail): pages already there keep their pictures until new ones are decoded
    const pages = [];
    for (let p = 0; p < n; p++) pages.push(railPage(sheet, p, railSrc(sheet, p)));
    const box = document.createElement("div");
    box.innerHTML = railGroup(sheet, pages, true);
    patchGroup(group, box.firstElementChild);
    bindRail(group);
  }
  function renderRail(ms) {
    clearTimeout(railTimer);
    railTimer = setTimeout(() => {
      const host = el("typoPages");
      if (!host || !window.AppLive || !AppLive.state.data || !AppLive.renderThumb) return;
      // the other sheets are drawn again when you switch sheets (or press ⟳), not on every edit
      if (RAIL.sheet !== V.state.sheet || !RAIL.stamp) { RAIL.sheet = V.state.sheet; RAIL.stamp = configStamp(); }
      const live = SP() ? [SP().thumb()]
        : (AppLive.state.pages || []).map((_, p) => { try { return AppLive.renderThumb(p); } catch (e) { return ""; } });
      const groups = (V.state.sheets || []).map((name) => {
        if (name === V.state.sheet) return railGroup(name, live.map((u, p) => railPage(name, p, u)), true);
        const n = RAIL.counts[name + "@" + RAIL.stamp];
        const pages = [];
        for (let p = 0; p < (n || 1); p++) pages.push(railPage(name, p, railSrc(name, p)));
        return railGroup(name, pages, n != null);
      });
      let tree = host.querySelector(".tp-tree");
      const scroll = tree ? tree.scrollTop : null;
      if (!tree) {
        host.innerHTML = `<div class="tp-head"><span class="tbl-head">All Pages</span>
            <button type="button" class="tp-refresh" title="Draw the other sheets again (after changes that reach them)">⟳</button></div>
          <div class="tp-tree"></div>`;
        tree = host.querySelector(".tp-tree");
        host.querySelector(".tp-refresh").addEventListener("click", () => { RAIL.stamp = configStamp() + "." + Date.now().toString(36); renderRail(0); });
        tree.addEventListener("scroll", () => { clearTimeout(RAIL.scrollTimer); RAIL.scrollTimer = setTimeout(() => { railInView(tree); watchThumbs(); }, 120); });
      }
      patchRail(tree, groups.join(""));
      bindRail(tree);
      if (scroll != null && RAIL.lastSheet === V.state.sheet) tree.scrollTop = scroll;
      else host.querySelector(".tp-group.current")?.scrollIntoView({ block: "nearest" });
      RAIL.lastSheet = V.state.sheet;
      railInView(tree);
      watchThumbs();
    }, ms == null ? 250 : ms);
  }
  /* The rail is updated in place, never rebuilt: a page whose picture is the same keeps its <img>
     (already decoded), and a changed picture is swapped in only once the new one is decoded. Rebuilding
     it on every redraw made every thumbnail blank and decode again — the flicker. */
  function swapImg(img, src) {
    if (img.getAttribute("src") === src) return;
    delete img.dataset.fresh;
    const pre = new Image();
    pre.src = src;
    const put = () => { if (img.dataset.want === src) img.src = src; };
    img.dataset.want = src;
    (pre.decode ? pre.decode() : Promise.resolve()).then(put, put);
  }
  V.swapImg = swapImg;
  // one sheet's group `og` (on screen) made like `ng` (just built): its page buttons are reused
  function patchGroup(og, ng) {
    og.className = ng.className;
    if (ng.hasAttribute("data-count")) og.setAttribute("data-count", ng.getAttribute("data-count"));
    else og.removeAttribute("data-count");
    const oldPages = new Map([...og.querySelectorAll(".tp-page")].map((b) => [b.dataset.p, b]));
    const pages = [...ng.querySelectorAll(".tp-page")].map((nb) => {
      const ob = oldPages.get(nb.dataset.p), oi = ob && ob.querySelector("img"), ni = nb.querySelector("img");
      if (!ob || !oi || !ni) return nb;
      ob.className = nb.className;
      ob.title = nb.title;
      swapImg(oi, ni.getAttribute("src"));
      return ob;
    });
    // while its page count is being looked up again ("?"), the Continued pages it showed stay
    const lookingUp = og.dataset.count === "?" && pages.length === 1;
    const [main, ...conts] = lookingUp ? [pages[0], ...[...og.querySelectorAll(".tp-conts > .tp-page")]] : pages;
    if (og.firstElementChild !== main) og.prepend(main);
    let wrap = og.querySelector(".tp-conts");
    if (conts.length) {
      if (!wrap) { wrap = document.createElement("div"); wrap.className = "tp-conts"; og.append(wrap); }
      conts.forEach((b, i) => { if (wrap.children[i] !== b) wrap.insertBefore(b, wrap.children[i] || null); });
      while (wrap.children.length > conts.length) wrap.lastElementChild.remove();
    } else if (wrap) {
      wrap.remove();
      wrap = null;
    }
    [...og.children].forEach((c) => { if (c !== main && c !== wrap) c.remove(); });
  }
  function patchRail(tree, html) {
    const box = document.createElement("div");
    box.innerHTML = html;
    const old = new Map([...tree.children].map((g) => [g.dataset.group, g]));
    const keep = [...box.children].map((ng) => {
      const og = old.get(ng.dataset.group);
      if (!og) return ng;
      patchGroup(og, ng);
      return og;
    });
    keep.forEach((g, i) => { if (tree.children[i] !== g) tree.insertBefore(g, tree.children[i] || null); });
    while (tree.children.length > keep.length) tree.lastElementChild.remove();
  }
  // the sheets on screen in the rail (and a little beyond) look up their Continued pages
  function railInView(tree) {
    const tr = tree.getBoundingClientRect();
    tree.querySelectorAll('[data-count="?"]').forEach((g) => {
      const r = g.getBoundingClientRect();
      if (r.bottom >= tr.top - 300 && r.top <= tr.bottom + 300) railCount(g);
    });
  }
  V.renderRail = renderRail;
  // a sheet's up-to-date preview is ready (it was shown from an older picture): its page count may differ
  window.addEventListener("psh:thumb-fresh", (ev) => {
    const tree = el("typoPages")?.querySelector(".tp-tree");
    const group = tree && [...tree.querySelectorAll(".tp-group")].find((g) => g.dataset.group === ev.detail);
    if (!group || ev.detail === V.state.sheet) return;
    delete RAIL.counts[ev.detail + "@" + RAIL.stamp];
    railCount(group);                                   // (patched: its pictures stay until the new ones are ready)
  });
  // the live renderer found another page (an icon picture arrived): the page count and the rail follow
  V.onPagesChanged = function () {
    if (App.route !== "typography" && App.route !== "assets") return;
    const pages = (AppLive.state.pages || []).length;
    if (!pages) return;
    const lab = el("typoVisPage"), next = el("typoVisNext");
    if (lab) lab.textContent = `Page ${(V.state.page || 0) + 1} of ${pages}`;
    if (next) next.disabled = (V.state.page || 0) >= pages - 1;
    if (!ED) renderRail(300);
  };

  // the top bar of a picked icon / table follows the page once it is drawn again (its size, its look)
  function repaintPicked() {
    if (window.TypoStudio && (TypoStudio.target === "icon" || TypoStudio.target === "table")) TypoStudio.paint();
  }

  /* the selected box: one clicked row (with its strip bar), else the heading, or every body
     line of the page together */
  V.showTarget = function (t) {
    const shown = showTarget(t);
    if (shown) idleFrames(shown);
  };
  // the selection's frame; returns what it drew ({para, box}) — or null when nothing can be drawn
  function showTarget(t) {
    V.state.target = t || null;
    if (t !== "box") V.state.box = null;
    const host = el("typoVisHost"), canvas = el("typoVisCanvas");
    if (!host) return null;
    host.querySelectorAll(".typo-sel, .typo-reset, .typo-boxmenu").forEach((n) => n.remove());
    if (SP()) return null;     // a paytable / rules page: its own frames
    if (!t) V.state.row = null;
    if (!canvas || !window.AppLive || !AppLive.state || !AppLive.state.data) { hideRowBar(); return null; }
    if (!t) { hideRowBar(); return {}; }
    if (t === "box") {                               // a text box: its frame, moved and sized like Photoshop's
      const f = boxFrame(V.state.box);
      if (f) boxHandles(selBox(f.x, f.y, f.x + f.w, f.y + f.h, "Text box", true), f);
      return { box: V.state.box };
    }
    const row = rowElement();
    if (row) {
      selBox(row.x, row.y, row.x + row.w, row.y + row.h, row.kind === "heading" ? "Heading row" : "Row", true);
      showRowBar(row);
      if (rowRoleOf(row) === "heading") rowGapGuides(row);
      return {};
    }
    V.state.row = null;
    hideRowBar();
    if (t === "continued") {                         // the "(Continued)" line of this page
      const b = continuedBox();
      if (b) selBox(b.x, b.y, b.x + b.w, b.y + b.h, "Continued", false);
      return {};
    }
    const els = (AppLive.state.elements || []).filter((e) => t === "heading"
      ? (e.kind === "heading" || e.role === "heading") : rulesOn() ? e.kind === "line" && rulesTarget(e) === t : (e.kind === "line" || e.role === "body"));
    if (!els.length) return {};
    const x0 = Math.min(...els.map((e) => e.x)), y0 = Math.min(...els.map((e) => e.y));
    const x1 = Math.max(...els.map((e) => e.x + e.w)), y1 = Math.max(...els.map((e) => e.y + e.h));
    // the paragraph of a text page: its own box, with Photoshop's handles (page_boxes.body_boxes)
    const pb = t !== "heading" && !rulesOn() ? paragraphFrame(els) : null;
    const label = { gr_rules: "Rules text", gr_legal: "Legal text" }[t] || (t === "heading" ? "Heading" : "Paragraph");
    const box = pb ? selBox(pb.left, pb.top, pb.right, pb.bottom, "Paragraph", false)
      : selBox(x0, y0, x1, y1, label, false);
    if (t === "heading") plateHandles();
    if (!rulesOn()) spacingHandles(box, t);
    if (pb) paragraphHandles(box, pb);
    return { para: !!pb };
  }
  /* the paragraph's box and every text box of a text page keep their handles on screen, selected or
     not (lighter when not): clicks go through their frames to the text, only the handles catch them */
  function idleFrames(shown) {
    if (App.route !== "typography" || ED || V.state.textMode || !canonPage()) return;
    if (!shown.para) {
      const pb = paragraphFrame((AppLive.state.elements || []).filter((e) => e.kind === "line" || e.role === "body"));
      if (pb && isFinite(pb.top) && pb.bottom > pb.top) {
        const box = selBox(pb.left, pb.top, pb.right, pb.bottom, "Paragraph", false);
        box.classList.add("typo-idle");
        paragraphHandles(box, pb);
      }
    }
    const ids = new Set((AppLive.state.elements || []).filter((e) => e.boxId != null).map((e) => e.boxId));
    for (const id of ids) {
      const f = id !== shown.box && boxFrame(id);
      if (!f) continue;
      const box = selBox(f.x, f.y, f.x + f.w, f.y + f.h, "▣ Text box", false);
      box.classList.add("typo-idle");
      boxResize(box, id, f);
      boxTab(box, id, f);
    }
  }

  /* ------- the paragraph's box, a heading row's gaps, text boxes (page_boxes.py) -------
     Only on text pages (the server lays them out: AppLive.state.canon); everything is kept in
     dynamic_settings per sheet and every renderer (this canvas, the PNG and PSD builds) reads it. */
  const dsx = () => (App.state.config.dynamic_settings = App.state.config.dynamic_settings || {});
  const canonPage = () => {
    const c = window.AppLive && AppLive.state && AppLive.state.canon;
    return c && c.layouts ? c.layouts[Math.min(c.layouts.length - 1, AppLive.state.page || 0)] : null;
  };
  const pageK = () => { const c = el("typoVisCanvas"); return c ? c.getBoundingClientRect().width / AppLive.state.data.canvas_w : 1; };
  async function saveBoxes(msg) {
    App.refreshUI();
    if (App.flushConfig) await App.flushConfig();
    await V.refreshPreview.now(true);
    if (window.TypoStudio) TypoStudio.paint();
    refocus();                                          // typing in the text: the caret stays
    if (msg) toast(msg);
  }

  /* A drag shows the real page while it moves: the dragged values ({settings key: value}) go to the
     server's layout unsaved, one request at a time, the latest value next; each answer is drawn at once.
     On release saveLive() keeps what is on screen and saves in the background — no second fetch. */
  const LIVE = { run: null, next: null, sending: "", done: "" };
  function liveStart() {
    LIVE.done = "";
    if (App.configSettled) App.configSettled();         // an earlier edit is on the server before the first draft
  }
  function liveDraft(patch) {
    LIVE.next = patch;
    if (!LIVE.run) LIVE.run = (async () => {
      try {
        while (LIVE.next) {
          const p = LIVE.next;
          LIVE.next = null;
          LIVE.sending = JSON.stringify(p);
          if (App.configSettled) await App.configSettled();
          const geo = window.AppLive && AppLive.draftSettings
            ? await AppLive.draftSettings(el("typoVisCanvas"), V.state.sheet, p) : null;
          if (geo) { LIVE.done = LIVE.sending; liveGeometry(geo); }
          LIVE.sending = "";
        }
      } finally { LIVE.run = null; }
    })();
    return LIVE.run;
  }
  function liveGeometry(geo) {
    V.state.geometry = geo;
    V.state.guides = computeTypoGuides(geo);
    renderGuides();
    const d = V.state.drag;                              // the guide being dragged stays under the mouse
    if (d && typeof d.value === "number") placeGuideLine(d.gd, posForValue(d.gd, geo, d.value));
  }
  // the page drawn with exactly these values? (the last draft answered for them)
  async function liveSettle(patch) {
    const want = JSON.stringify(patch);
    if (LIVE.done !== want && LIVE.sending !== want) LIVE.next = patch;
    if (LIVE.next && !LIVE.run) liveDraft(LIVE.next);
    while (LIVE.run) await LIVE.run;
    return LIVE.done === want;
  }
  // a drag let go: saved in the background; what is on screen stays when it is that layout already
  async function saveLive(patch, msg) {
    V.state.liveHold = true;                             // App.refreshUI's "draw the page again": not for this edit
    try { App.refreshUI(); } finally { V.state.liveHold = false; }
    const shown = await liveSettle(patch);
    if (!shown) return saveBoxes(msg);                   // no live layout (an older page kind): as before
    if (App._cfgTimer && App.flushConfig) App.flushConfig();
    V.state.guides = computeTypoGuides(V.state.geometry);
    layout();
    showPage(V.state.page || 0);
    if (ED) relayout();
    else renderRail();
    repaintPicked();
    if (window.TypoStudio) TypoStudio.paint();
    refocus();
    if (msg) toast(msg);
  }
  V.liveDraft = liveDraft;
  V.saveLive = saveLive;

  // drag a handle: onMove(dx, dy) in page px while dragging, onUp(dx, dy) once at the end
  function dragHandle(node, ev, onMove, onUp) {
    ev.preventDefault();
    ev.stopPropagation();
    try { node.setPointerCapture(ev.pointerId); } catch (_) { /* moves still reach it */ }
    const k = pageK(), x0 = ev.clientX, y0 = ev.clientY;
    let dx = 0, dy = 0;
    const move = (e) => { dx = (e.clientX - x0) / k; dy = (e.clientY - y0) / k; onMove(dx, dy, e); };
    const up = () => {
      node.removeEventListener("pointermove", move);
      node.removeEventListener("pointerup", up);
      if (Math.abs(dx) + Math.abs(dy) >= 1) onUp(dx, dy);
    };
    node.addEventListener("pointermove", move);
    node.addEventListener("pointerup", up);
  }
  const HANDLES = ["tl", "t", "tr", "r", "br", "b", "bl", "l"];
  // eight handles on a frame `box` (page px f = {left, top, right, bottom}); edges(f2) gets the new frame
  function resizeHandles(box, f, edges, tipOf, live, mins) {
    const [minW, minH] = mins || [40, 20];
    box.classList.add("boxed");
    const k = pageK(), place = (g) => Object.assign(box.style, {
      left: (parseFloat(box.dataset.l) + (g.left - f.left) * k) + "px", top: (parseFloat(box.dataset.t) + (g.top - f.top) * k) + "px",
      width: ((g.right - g.left) * k + 8) + "px", height: ((g.bottom - g.top) * k + 8) + "px" });
    box.dataset.l = parseFloat(box.style.left);
    box.dataset.t = parseFloat(box.style.top);
    for (const h of HANDLES) {
      const n = document.createElement("i");
      n.className = "typo-rs " + h;
      box.appendChild(n);
      ["mousedown", "click", "dblclick"].forEach((ty) => n.addEventListener(ty, (ev) => ev.stopPropagation()));
      n.addEventListener("pointerdown", (ev) => {
        const tip = document.createElement("span");
        tip.className = "typo-h-tip";
        n.appendChild(tip);
        const frame = (dx, dy) => {
          const g = Object.assign({}, f);
          if (h.includes("l")) g.left = Math.min(f.right - minW, f.left + dx);
          if (h.includes("r")) g.right = Math.max(f.left + minW, f.right + dx);
          if (h.startsWith("t")) g.top = Math.min(f.bottom - minH, f.top + dy);
          if (h.startsWith("b")) g.bottom = Math.max(f.top + minH, f.bottom + dy);
          return g;
        };
        if (live) liveStart();
        dragHandle(n, ev, (dx, dy) => { const g = frame(dx, dy); place(g); tip.textContent = tipOf(g); if (live) live(g, h); },
          (dx, dy) => { tip.remove(); edges(frame(dx, dy), h); });
      });
    }
  }

  /* the paragraph's frame on this page: its sides, where its text starts, where it moves on */
  function paragraphFrame(els) {
    const lay = canonPage(), b = lay && lay.safe_area && lay.safe_area.body;
    if (!b) return null;
    const body = els.filter((e) => e.boxId == null);
    const top = ((AppLive.state.page || 0) === 0 || b.cont) && b.top != null ? b.top : Math.min(...body.map((e) => e.y));
    return { left: b.left, right: b.left + b.width, top: isFinite(top) ? top : lay.safe_area.top, bottom: b.bottom, set: b.set || [] };
  }
  /* the heading's plate (page_boxes.heading_plate): a frame with eight handles — any width or height, a side
     inside the text too. Saved as its margin on each side of the heading's text (pads), on the rule it
     comes from: this page's own plate, else every heading's */
  function plateHandles() {
    const p = (AppLive.state.elements || []).find((e) => e.meta && e.meta.plate === "heading" && e.meta.text_box);
    if (!p) return;
    const sheet = V.state.sheet || "", ds = dsx(), tb = p.meta.text_box;
    const ownKey = Object.keys(ds.heading_plates || {}).find((x) => x.toLowerCase() === String(sheet).toLowerCase());
    const f = { left: p.x, top: p.y, right: p.x + p.w, bottom: p.y + p.h };
    const box = selBox(f.left, f.top, f.right, f.bottom, "Plate", false);
    box.classList.add("typo-plate");
    const ruleFor = (g, h) => {
      // the heading stays in the middle of its plate: the margin dragged on one side is the other side's too
      h = h || "";
      const sx = h.includes("l") ? tb[0] - g.left : h.includes("r") ? g.right - tb[2] : ((tb[0] - f.left) + (f.right - tb[2])) / 2;
      const sy = h.startsWith("t") ? tb[1] - g.top : h.startsWith("b") ? g.bottom - tb[3] : ((tb[1] - f.top) + (f.bottom - tb[3])) / 2;
      const pads = [sx, sy, sx, sy].map((v) => Math.round(v));
      if (ownKey) return { "dynamic_settings.heading_plates": Object.assign({}, ds.heading_plates, { [ownKey]: Object.assign({}, ds.heading_plates[ownKey], { pads }) }) };
      return { "dynamic_settings.heading_plate": Object.assign({}, ds.heading_plate || {}, { pads }) };
    };
    resizeHandles(box, f, (g, h) => {
      const patch = ruleFor(g, h);
      Object.entries(patch).forEach(([k, v]) => { ds[k.split(".")[1]] = v; });
      saveLive(patch, `${ownKey ? "This page's" : "Every heading's"} plate: ${Math.round(g.right - g.left)} × ${Math.round(g.bottom - g.top)} px.`);
    }, (g) => `${Math.round(g.right - g.left)} × ${Math.round(g.bottom - g.top)} px`, (g, h) => liveDraft(ruleFor(g, h)), [4, 2]);
  }
  function paragraphHandles(box, f) {
    const sheet = V.state.sheet || "", page0 = (AppLive.state.page || 0) === 0;
    // page 1: the paragraph's box; a Continued page: the Continued pages' own box (body_boxes[sheet].cont)
    const boxesFor = (g, h) => {
      const all = Object.assign({}, dsx().body_boxes || {}), page = Object.assign({}, all[sheet] || {});
      const mine = page0 ? page : Object.assign({}, page.cont || {});
      if (h.includes("l")) mine.left = Math.round(g.left);
      if (h.includes("r")) mine.right = Math.round(g.right);
      if (h.startsWith("b")) mine.bottom = Math.round(g.bottom);
      if (h.startsWith("t")) mine.top = Math.round(g.top);
      if (!page0) page.cont = mine;
      all[sheet] = page;
      return all;
    };
    resizeHandles(box, f, (g, h) => {
      const all = boxesFor(g, h);
      dsx().body_boxes = all;
      saveLive({ "dynamic_settings.body_boxes": all }, `Paragraph box of ${sheet}: ${Math.round(g.right - g.left)} px wide.`);
    }, (g) => `${Math.round(g.right - g.left)} × ${Math.round(g.bottom - g.top)} px`,
    (g, h) => liveDraft({ "dynamic_settings.body_boxes": boxesFor(g, h) }));
    if ((f.set || []).length) {                      // back to the page's margins
      const r = document.createElement("button");
      r.className = "typo-reset";
      r.textContent = "↺";
      r.title = "Back to the page's margins";
      box.appendChild(r);
      ["mousedown", "pointerdown", "dblclick"].forEach((ty) => r.addEventListener(ty, (ev) => ev.stopPropagation()));
      r.addEventListener("click", (ev) => {
        ev.stopPropagation();
        const all = Object.assign({}, dsx().body_boxes || {});
        if (page0) { const keep = (all[sheet] || {}).cont; delete all[sheet]; if (keep) all[sheet] = { cont: keep }; }
        else if (all[sheet]) { all[sheet] = Object.assign({}, all[sheet]); delete all[sheet].cont; if (!Object.keys(all[sheet]).length) delete all[sheet]; }
        dsx().body_boxes = all;
        saveBoxes(page0 ? "The paragraph follows the page's margins again." : "The Continued pages follow the first page's margins again.");
      });
    }
  }

  /* a row made a heading: the gap above it and below it, as guides to drag (page_boxes.row_gaps) */
  function rowGapGuides(row) {
    const lines = rowLines(row).filter((e) => e.meta && e.meta.gaps);
    if (!lines.length) return;
    const gaps = lines[0].meta.gaps, sheet = V.state.sheet || "", key = rowKeyOf(row);
    const inkTop = Math.min(...lines.map((e) => e.meta.ink_top)), inkBottom = Math.max(...lines.map((e) => e.meta.ink_bottom));
    const left = Math.min(...lines.map((e) => e.x)), right = Math.max(...lines.map((e) => e.x + e.w));
    const host = el("typoVisHost"), canvas = el("typoVisCanvas");
    const cr = canvas.getBoundingClientRect(), hr = host.getBoundingClientRect(), k = pageK();
    const own = ((dsx().row_gaps || {})[sheet] || {})[key] || {}, custom = own.above != null || own.below != null;
    for (const side of ["above", "below"]) {
      const y = side === "above" ? inkTop - gaps.above : inkBottom + gaps.below;
      const g = document.createElement("div");
      g.className = "typo-sel typo-gap " + side;
      Object.assign(g.style, { left: (cr.left - hr.left + left * k) + "px", width: ((right - left) * k) + "px",
                               top: (cr.top - hr.top + y * k) + "px" });
      g.innerHTML = `<span>${side === "above" ? "Gap above" : "Gap below"} · ${Math.round(gaps[side])} px</span>`;
      g.title = `Drag: the space ${side} this heading row (the page heading's is ${Math.round(gaps.default)} px)`;
      host.appendChild(g);
      ["mousedown", "click", "dblclick"].forEach((ty) => g.addEventListener(ty, (ev) => ev.stopPropagation()));
      g.addEventListener("pointerdown", (ev) => {
        const y0 = parseFloat(g.style.top), lab = g.querySelector("span");
        const ch = (V.state.geometry || {}).canvas_h || 1080;           // up to the canvas's height, whatever its size
        const val = (dy) => Math.max(0, Math.min(ch, Math.round(gaps[side] + (side === "above" ? -dy : dy))));
        const gapsFor = (dy) => {
          const all = Object.assign({}, dsx().row_gaps || {}), mine = Object.assign({}, all[sheet] || {});
          mine[key] = Object.assign({ above: gaps.above, below: gaps.below }, mine[key] || {}, { [side]: val(dy) });
          all[sheet] = mine;
          return all;
        };
        liveStart();
        dragHandle(g, ev, (dx, dy) => {
          g.style.top = (y0 + dy * k) + "px";
          lab.textContent = `${side === "above" ? "Gap above" : "Gap below"} · ${val(dy)} px`;
          liveDraft({ "dynamic_settings.row_gaps": gapsFor(dy) });
        },
          (dx, dy) => {
            const all = gapsFor(dy);
            dsx().row_gaps = all;
            saveLive({ "dynamic_settings.row_gaps": all }, `Row ${row.row}: ${val(dy)} px ${side} it.`);
          });
      });
    }
    if (custom) {
      const r = document.createElement("button");
      r.className = "typo-reset typo-gap-reset";
      r.textContent = "↺";
      r.title = "The page heading's gaps again";
      Object.assign(r.style, { left: (cr.left - hr.left + right * k + 6) + "px", top: (cr.top - hr.top + inkTop * k) + "px" });
      host.appendChild(r);
      ["mousedown", "pointerdown", "dblclick"].forEach((ty) => r.addEventListener(ty, (ev) => ev.stopPropagation()));
      r.addEventListener("click", (ev) => {
        ev.stopPropagation();
        const all = Object.assign({}, dsx().row_gaps || {}), mine = Object.assign({}, all[sheet] || {});
        const g = Object.assign({}, mine[key] || {});
        delete g.above;
        delete g.below;
        if (Object.keys(g).length) mine[key] = g; else delete mine[key];
        if (Object.keys(mine).length) all[sheet] = mine; else delete all[sheet];
        dsx().row_gaps = all;
        saveBoxes(`Row ${row.row} has the page heading's gaps again.`);
      });
    }
  }

  /* a line's settings key: "row:N" for an Excel row of the paragraph, "box:<id>" for a text box — a box
     is laid out like a row of the paragraph, so roles, line heights and gaps are kept for it the same way */
  const rowKeyOf = (e) => (e && ((e.meta && e.meta.key) || (/^\d+$/.test(String(e.row)) ? "row:" + e.row : ""))) || "";
  const keyName = (key, row) => (String(key).startsWith("box:") ? "this text box" : `row ${row}`);

  /* line height of a row / of some of its drawn lines (page_boxes.line_gap): the gap above each line.
     targets: [{key, line}] (line = the row's drawn line, 1-based; null = every line of the row) */
  async function setLineHeight(targets, px) {
    await flushTyping();
    const sheet = V.state.sheet || "", all = Object.assign({}, dsx().row_gaps || {}), mine = Object.assign({}, all[sheet] || {});
    for (const t of targets) {
      const key = t.key || "row:" + t.row, g = Object.assign({}, mine[key] || {});
      if (t.line == null) {                             // the whole row: one line height, the single lines go
        delete g.lines;
        if (px == null) delete g.line; else g.line = Math.max(0, Math.round(px));
      } else {
        const lines = Object.assign({}, g.lines || {});
        if (px == null) delete lines[t.line]; else lines[t.line] = Math.max(0, Math.round(px));
        if (Object.keys(lines).length) g.lines = lines; else delete g.lines;
      }
      if (Object.keys(g).length) mine[key] = g; else delete mine[key];
    }
    if (Object.keys(mine).length) all[sheet] = mine; else delete all[sheet];
    dsx().row_gaps = all;
    await saveBoxes(px == null ? "Line height: the paragraph's again." : `Line height ${Math.round(px)} px on ${targets.length === 1 && targets[0].line == null ? "this row" : targets.length + (targets.length === 1 ? " line" : " lines")}.`);
  }
  V.setLineHeight = setLineHeight;
  // the drawn lines the editor's selection touches: [{key, line, el}] (text pages, text boxes too)
  function selectedLines() {
    if (!ED || !ED.map) return [];
    const s = sel(), seen = new Map();
    for (let i = s.a; i <= Math.max(s.a, s.b - 1); i++) {
      const p = ED.map.pts[i], e = p && p.ln && p.ln.el;
      if (!e || !e.meta || !e.meta.row_line || !rowKeyOf(e)) continue;
      seen.set(rowKeyOf(e) + "|" + e.meta.row_line, { key: rowKeyOf(e), line: e.meta.row_line, el: e });
    }
    return [...seen.values()];
  }
  const lhHtml = (attr, px, set, what) => `<span class="ts-ico" title="Line height — the space above ${what}">A<span class="ts-lh">↕</span>A</span>
      <input class="ts-size" type="number" min="0" max="600" ${attr}="lh" value="${Math.round(px)}" title="Line height of ${what} (px above each line)"><span class="ts-unit">px</span>
      ${set ? `<button class="ts-al" ${attr}="lhreset" title="The paragraph's line height again">↺</button>` : ""}`;
  // the heading's line height in px (the "line_spacing" setting: a factor ≤ 3, else px), as its ↕ handle has it
  function headingLH() {
    const size = Number(App.get("h_size")) || 60, ls0 = Number(App.get("line_spacing"));
    return isFinite(ls0) && App.get("line_spacing") !== "" ? (ls0 <= 3 ? Math.round(size * Math.max(0, ls0 - 1)) : ls0) : Math.round(size * 0.1);
  }
  function setPageSetting(key, val, msg) {
    App.set(key, val);
    App.refreshUI();
    if (V.refreshPreview) V.refreshPreview(true);
    toast(msg);
  }
  /* the line height the selection's text has — always one: its drawn lines (rows), its text box, the
     page heading, else the paragraph's. {px, set, what, apply(px | null = back to the paragraph's)} */
  function selLineHeight() {
    const ph = V.state.wordSel || [], e = (ph[0] && ph[0].el) || {};
    if (e.kind === "heading") {
      return { px: headingLH(), set: false, what: "the heading",
               apply: (px) => px != null && setPageSetting("line_spacing", Math.round(px) > 3 ? Math.round(px) : Math.round((1 + Math.round(px) / (Number(App.get("h_size")) || 60)) * 100) / 100, `Heading line height: ${Math.round(px)}px`) };
    }
    let ls = selectedLines();
    if (!ls.length) {                                    // not typing: the selected pieces' own lines
      const seen = new Map();
      for (const x of ph) {
        const el2 = x.el;
        if (el2 && el2.meta && el2.meta.row_line && rowKeyOf(el2)) {
          seen.set(rowKeyOf(el2) + "|" + el2.meta.row_line, { key: rowKeyOf(el2), line: el2.meta.row_line, el: el2 });
        }
      }
      ls = [...seen.values()];
    }
    if (ls.length) {
      return { px: Number(ls[0].el.meta.line_height) || 0, set: ls.some((l) => l.el.meta.line_height_set),
               what: ls.length === 1 ? "the selected line" : `the ${ls.length} selected lines`,
               apply: (px) => setLineHeight(ls.map((l) => ({ key: l.key, line: l.line })), px) };
    }
    const gap = App.get("line_gap") === "" || App.get("line_gap") == null ? 30 : Number(App.get("line_gap")) || 0;
    return { px: gap, set: false, what: "the paragraph",
             apply: (px) => px != null && setPageSetting("line_gap", Math.max(0, Math.round(px)), `Paragraph line height: ${Math.round(px)}px`) };
  }

  /* text boxes: words split off a paragraph (right-click › Split while editing) — their own place,
     width, height, font, size, colour and layer style; their words stay linked to their Excel row */
  const boxesOf = (sheet) => ((dsx().text_boxes || {})[sheet || V.state.sheet || ""] || []);
  const boxConf = (id) => boxesOf().find((b) => b.id === id) || null;
  function boxFrame(id) {
    const ls = (AppLive.state.elements || []).filter((e) => e.boxId != null && e.boxId === id);
    const b = boxConf(id);
    if (!ls.length || !b) return null;
    const f = ls[0].boxFrame;
    return { x: f.x, y: f.y, w: f.w, h: Math.max(f.h, Math.max(...ls.map((e) => e.y + e.h)) - f.y) };
  }
  function updateBox(id, changes, msg) {
    const sheet = V.state.sheet || "", all = Object.assign({}, dsx().text_boxes || {});
    all[sheet] = (all[sheet] || []).map((b) => (b.id === id ? Object.assign({}, b, changes) : b));
    dsx().text_boxes = all;
    return saveBoxes(msg);
  }
  async function putBoxBack(id) {
    const sheet = V.state.sheet || "", all = Object.assign({}, dsx().text_boxes || {});
    all[sheet] = (all[sheet] || []).filter((b) => b.id !== id);
    if (!all[sheet].length) delete all[sheet];
    dsx().text_boxes = all;
    V.state.box = null;
    if (window.TypoStudio) TypoStudio.setTarget("body");
    await saveBoxes("The box's words are back in the paragraph.");
  }
  const boxResize = (box, id, f) => resizeHandles(box, { left: f.x, top: f.y, right: f.x + f.w, bottom: f.y + f.h },
    (g) => updateBox(id, { x: Math.round(g.left), y: Math.round(g.top), w: Math.round(g.right - g.left), h: Math.round(g.bottom - g.top) }),
    (g) => `${Math.round(g.right - g.left)} × ${Math.round(g.bottom - g.top)} px`);
  function boxHandles(box, f) {
    const id = V.state.box;
    box.classList.add("typo-boxsel");
    boxResize(box, id, f);
    // drag inside the frame: the box moves
    box.addEventListener("pointerdown", (ev) => {
      if (ev.button !== 0 || ev.target !== box) return;
      const l0 = parseFloat(box.style.left), t0 = parseFloat(box.style.top), k = pageK();
      dragHandle(box, ev, (dx, dy) => { box.style.left = (l0 + dx * k) + "px"; box.style.top = (t0 + dy * k) + "px"; },
        (dx, dy) => updateBox(id, { x: Math.round(f.x + dx), y: Math.round(f.y + dy) }));
    });
    ["mousedown", "click"].forEach((ty) => box.addEventListener(ty, (ev) => ev.stopPropagation()));
    box.addEventListener("contextmenu", (ev) => { ev.preventDefault(); ev.stopPropagation(); boxMenu(ev, id); });
  }
  function boxTab(box, id, f) {
    const tag = box.querySelector("span");
    tag.classList.add("typo-boxtag");
    tag.title = "Click: this box's own settings · drag: move it · right-click: more";
    ["mousedown", "click", "dblclick"].forEach((ty) => tag.addEventListener(ty, (ev) => ev.stopPropagation()));
    tag.addEventListener("contextmenu", (ev) => { ev.preventDefault(); ev.stopPropagation(); boxMenu(ev, id); });
    tag.addEventListener("pointerdown", (ev) => {
      if (ev.button !== 0) return;
      const l0 = parseFloat(box.style.left), t0 = parseFloat(box.style.top), k = pageK();
      let moved = false;
      tag.addEventListener("pointerup", () => { if (!moved) V.selectBox(id); }, { once: true });
      dragHandle(tag, ev, (dx, dy) => {
        moved = moved || Math.abs(dx) + Math.abs(dy) >= 1;
        box.style.left = (l0 + dx * k) + "px";
        box.style.top = (t0 + dy * k) + "px";
      }, (dx, dy) => updateBox(id, { x: Math.round(f.x + dx), y: Math.round(f.y + dy) }));
    });
  }
  function boxMenu(ev, id) {
    document.querySelectorAll(".typo-boxmenu").forEach((n) => n.remove());
    const host = el("typoVisHost"), hr = host.getBoundingClientRect();
    const menu = document.createElement("div");
    menu.className = "tsel-menu typo-boxmenu";
    menu.innerHTML = `<div class="vpm-head">Text box</div><button data-m="back">Put the words back into the paragraph</button>`;
    host.appendChild(menu);
    Object.assign(menu.style, { left: Math.min(hr.width - menu.offsetWidth - 6, ev.clientX - hr.left) + "px",
                                top: Math.min(hr.height - menu.offsetHeight - 6, ev.clientY - hr.top) + "px" });
    ["mousedown", "pointerdown", "click"].forEach((ty) => menu.addEventListener(ty, (e2) => e2.stopPropagation()));
    menu.querySelector('[data-m="back"]').addEventListener("click", () => { menu.remove(); putBoxBack(id); });
    setTimeout(() => document.addEventListener("mousedown", () => menu.remove(), { once: true }), 0);
  }
  V.boxSelected = () => !!(V.state.box && boxConf(V.state.box));
  /* the Layers panel picks a part of the page (layers_panel.js): as a click on it picks it — the heading
     (its plate too), a text box, a row (its Row bar, its frame) */
  V.pickElement = function (e) {
    if (!e) return;
    if (e.kind === "heading") { V.selectRow(null); if (window.TypoStudio) TypoStudio.setTarget("heading"); else V.showTarget("heading"); return; }
    if (e.boxId != null) { V.selectBox(e.boxId); return; }
    if (e.kind === "line") { V.selectRow(e); V.showTarget(rulesTarget(e) || "body"); }
  };
  V.selectBox = function (id) {
    V.state.box = id;
    V.selectRow(null);
    if (window.TypoStudio) TypoStudio.setTarget("box"); else V.showTarget("box");
  };
  V.boxBarHtml = function () {
    const b = boxConf(V.state.box);
    if (!b) return `<span class="ts-hint">Click a text box on the page</span>`;
    const fonts = (App.state.fonts || []).slice().sort((a, c) => String(a).localeCompare(String(c)));
    const font = String(b.font || App.get("b_font") || "");
    if (font && !fonts.some((x) => String(x).toLowerCase() === font.toLowerCase())) fonts.unshift(font);
    const style = (b.bold ? "bold" : "") + (b.bold && b.italic ? " " : "") + (b.italic ? "italic" : "") || "regular";
    const size = Number(b.size) || Number(App.get("b_size")) || 30;
    const color = b.rgb || (Array.isArray(App.get("b_rgb")) ? "#ffffff" : App.get("b_rgb")) || "#ffffff";
    const align = b.align || String(App.get("alignment_settings.global.body") || "center");
    const words = b.parts.map((p) => p.text).join(" ");
    const ICONS = { left: "⯇≡", center: "≡", right: "≡⯈" };
    return `<span class="ics-chip ts-selchip" title="${esc(words)}">▣ ${esc(words.length > 22 ? words.slice(0, 22) + "…" : words)}</span>
      <span class="ts-sep"></span>
      <select class="ts-font" data-bx="font" title="Font">${fonts.map((x) => `<option value="${esc(x)}" ${String(x).toLowerCase() === font.toLowerCase() ? "selected" : ""}>${esc(x)}</option>`).join("")}</select>
      <select class="ts-style" data-bx="style" title="Style">${[["regular", "Regular"], ["bold", "Bold"], ["italic", "Italic"], ["bold italic", "Bold Italic"]].map(([v, l]) => `<option value="${v}" ${v === style ? "selected" : ""}>${l}</option>`).join("")}</select>
      <input class="ts-size" type="number" min="6" max="400" data-bx="size" value="${size}" title="Font size (px)"><span class="ts-unit">px</span>
      ${(() => { const e = boxLines()[0], set = b.line != null && b.line !== "";
        return lhHtml("data-bx", set ? Number(b.line) : Number(e && e.meta && e.meta.line_height) || 0, set, "this text box"); })()}
      <span class="ts-ico" title="Letter spacing (1/1000 em)">V<span class="ts-lh">↔</span>A</span>
      <input class="ts-size" type="number" min="-200" max="1000" step="10" data-bx="tracking" value="${b.tracking != null && b.tracking !== "" ? Number(b.tracking) : Number(dsx().body_tracking) || 0}" title="Letter spacing (1/1000 em)">
      <span class="ts-sep"></span>
      ${["left", "center", "right"].map((a) => `<button class="ts-al ${a === align ? "on" : ""}" data-bxalign="${a}" title="Align ${a}">${ICONS[a]}</button>`).join("")}
      <span class="ts-sep"></span>
      <label class="ts-color" title="Colour"><input type="color" data-bx="rgb" value="${esc(color)}"></label>
      <button class="ts-fxbtn" data-bxfx title="Layer style of this box"><span class="ts-fx-none">fx</span><span class="ts-fx-name">${esc(b.style || "The paragraph's style")}</span><span class="ts-fx-caret">▾</span></button>
      <span class="ts-sep"></span>
      ${boxStripHtml(b)}
      <span class="ts-sep"></span>
      <button class="ts-tgt" data-bxback title="Its words go back into the paragraph">Put back</button>
      <span class="ts-hint">drag the box to move it · its handles size it · right-click for more</span>`;
  };
  V.wireBoxBar = function (root) {
    const id = V.state.box, q = (k) => root.querySelector(`[data-bx="${k}"]`);
    q("font")?.addEventListener("change", () => updateBox(id, { font: q("font").value }));
    q("style")?.addEventListener("change", () => { const v = q("style").value; updateBox(id, { bold: v.includes("bold"), italic: v.includes("italic") }); });
    q("size")?.addEventListener("change", () => updateBox(id, { size: Math.max(6, Math.min(400, Math.round(Number(q("size").value) || 30))) }));
    q("tracking")?.addEventListener("change", () => updateBox(id, { tracking: Math.max(-200, Math.min(1000, Math.round(Number(q("tracking").value) || 0))) }));
    q("lh")?.addEventListener("change", () => updateBox(id, { line: Math.max(0, Math.min(600, Math.round(Number(q("lh").value) || 0))) }, `Text box line height ${Math.max(0, Math.round(Number(q("lh").value) || 0))} px.`));
    q("lhreset")?.addEventListener("click", () => updateBox(id, { line: null }, "Text box: the paragraph's line height again."));
    q("rgb")?.addEventListener("change", () => updateBox(id, { rgb: q("rgb").value }));
    root.querySelectorAll("[data-bxalign]").forEach((b) => b.addEventListener("click", () => updateBox(id, { align: b.dataset.bxalign })));
    root.querySelector("[data-bxback]")?.addEventListener("click", () => putBoxBack(id));
    const qs = (k) => root.querySelector(`[data-bs="${k}"]`);
    qs("on")?.addEventListener("click", () => saveBoxStrip(root, !!boxStrip()));
    ["color", "opacity", "text_color", "width_pct", "fit", "height"].forEach((k) => qs(k)?.addEventListener("change", () => saveBoxStrip(root, false)));
    qs("notext")?.addEventListener("click", () => saveBoxStrip(root, false, { text_color: "" }));
    if (boxStrip()) wireStripPop(root, "box", ruleLook(boxStrip()), (ch) => patchStripRule(boxText(), ch));
    root.querySelector("[data-bxfx]")?.addEventListener("click", (ev) => {
      const b = boxConf(id);
      if (window.TypoStudio) TypoStudio.fxPicker(ev.currentTarget, (b && b.style) || "", (name) => updateBox(id, { style: name || "" }), "The paragraph's style");
    });
  };
  /* Split: a row's "just this text" styles were made on the row as it read; the words now in the box
     take theirs to the box, the rest follow the row's new text (followEdit's counting) */
  function moveRulesForSplit(sheet, rows, boxText) {
    const { skel, occurrences } = wt();
    const rules = styleRules();
    for (const r of rows) {
      for (const rule of rules) {
        if (!isExact(rule) || rule.sheet !== sheet || !sameText(rule.row_text, r.before)) continue;
        const inRow = occurrences(skel(r.after).s, skel(rule.text).s), inBox = occurrences(skel(boxText).s, skel(rule.text).s);
        if (!inRow.length && inBox.length) { rule.row_text = boxText; rule.nth = 0; }
        else if (inRow.length) { rule.row_text = r.after; rule.nth = Math.min(Number(rule.nth) || 0, inRow.length - 1); }
      }
    }
    App.refreshUI();
  }
  /* the strip behind a whole text box: a strip rule on the box's text (layout_engine draws it in the box) */
  const boxLines = () => (AppLive.state.elements || []).filter((e) => e.boxId != null && e.boxId === V.state.box).sort((a, b) => a.y - b.y);
  const boxText = () => { const ls = boxLines(); return ls.length ? String(ls[0].rowText || "") : ""; };
  const boxStrip = () => (boxText() ? stripFor(boxText()) : null);
  const boxTextH = () => { const ls = boxLines(); return ls.length ? Math.round(Math.max(...ls.map((e) => e.y + e.h)) - Math.min(...ls.map((e) => e.y))) : 40; };
  function boxStripHtml() {
    const st = boxStrip(), h = boxTextH(), pad = st && st.pad_y != null ? Number(st.pad_y) : 6;
    return `<button class="ts-al ${st ? "on" : ""}" data-bs="on" title="A strip behind the box">▭</button>
      ${st ? `<label class="ts-color" title="Strip colour"><input type="color" data-bs="color" value="${esc(st.color || "#1e5aa8")}"></label>
        ${stripGear("box", `<div class="tsp-row"><span class="tsp-l">Opacity</span><input class="ts-size ts-narrow" type="number" min="10" max="100" step="5" data-bs="opacity" value="${Math.round((st.opacity == null ? 0.85 : Number(st.opacity)) * 100)}" title="Strip opacity (%)"><span class="ts-unit">%</span></div>
        <div class="tsp-row"><span class="tsp-l">Height</span><input class="ts-size ts-narrow" type="number" min="0" max="${h + 400}" data-bs="height" value="${Math.max(0, Math.round(h + 2 * pad))}" title="Strip height (px)"><span class="ts-unit">px</span></div>
        <div class="tsp-row"><span class="tsp-l">Width</span><input class="ts-size ts-narrow" type="number" min="5" max="100" step="5" data-bs="width_pct" value="${Math.round(st.width_pct || 100)}" ${st.full_width === false ? "disabled" : ""} title="Strip width (% of the box)"><span class="ts-unit">%</span>
          <label class="ts-check" title="Hug the words instead of the box"><input type="checkbox" data-bs="fit" ${st.full_width === false ? "checked" : ""}> fit</label></div>
        <div class="tsp-row"><span class="tsp-l">Text</span><label class="ts-color ${st.text_color ? "" : "ts-off"}" title="Text colour on the strip"><input type="color" data-bs="text_color" value="${esc(st.text_color || "#ffffff")}"></label>
          ${st.text_color ? `<button class="ts-al" data-bs="notext" title="Keep the text's own colour">⊘</button>` : ""}</div>`, ruleLook(st))}` : ""}`;
  }
  async function saveBoxStrip(root, remove, extra) {
    const text = boxText();
    if (!text) return;
    const old = stripFor(text), sheet = V.state.sheet || "", q = (k) => root.querySelector(`[data-bs="${k}"]`);
    const h = boxTextH(), height = q("height") ? Number(q("height").value) : h + 12;
    const rule = { kind: "strip", match: "exact", text: text.replace(/\s+/g, " ").trim(),
      color: q("color") ? q("color").value : "#1e5aa8", opacity: q("opacity") ? Math.max(0.1, Math.min(1, Number(q("opacity").value) / 100)) : 0.85,
      pad_x: 24, pad_y: Math.round((Math.max(0, height) - h) / 2), full_width: q("fit") ? !q("fit").checked : false,
      width_pct: q("width_pct") ? Math.max(5, Math.min(100, Number(q("width_pct").value) || 100)) : 100, radius: 6,
      text_color: old && old.text_color && q("text_color") ? q("text_color").value : "", scope: "page", sheet };
    if (q("text_color") && old && !old.text_color && q("text_color").value.toLowerCase() !== "#ffffff") rule.text_color = q("text_color").value;
    if (old) keepClosed(rule, old, q);
    for (const k of KEEP_LOOK) if (old && old[k] != null) rule[k] = old[k];
    Object.assign(rule, extra || {});
    const all = styleRules().slice(), i = old ? all.indexOf(old) : -1;
    if (remove) { if (i >= 0) all.splice(i, 1); } else if (i >= 0) all[i] = rule; else all.push(rule);
    dsx().text_style_rules = all;
    await saveBoxes();
  }
  // right-click › Split while editing: the selected words (whole words) go to a new box where they were
  async function splitToBox() {
    if (!ED || !ED.map) return;
    const v = ED.ta.value, s = sel();
    let a = s.a, b = s.b;
    while (a > 0 && /\S/.test(v[a - 1]) && /\S/.test(v[a])) a--;            // whole words
    while (b < v.length && /\S/.test(v[b]) && /\S/.test(v[b - 1])) b++;
    const parts = [];
    ED.starts.forEach((st, i) => {
      const end = i + 1 < ED.starts.length ? ED.starts[i + 1].pos - 1 : v.length;
      const text = v.slice(Math.max(a, st.pos), Math.min(b, end)).replace(/\s+/g, " ").trim();
      if (text) parts.push({ row: st.n, text });
    });
    if (!parts.length) { toast("Select some words first."); return; }
    // where the words are drawn now: the new box starts there
    const pts = ED.map.pts.slice(a, b + 1).filter(Boolean);
    const lines = [...new Set(pts.map((p) => p.ln))];
    const x0 = Math.min(...pts.map((p) => p.x)), x1 = Math.max(...pts.map((p) => p.x));
    const y0 = Math.min(...lines.map((l) => l.top)), y1 = Math.max(...lines.map((l) => l.top + l.h));
    const sheet = ED.sheet;
    // each row's text without the moved words (as page_boxes.take_out does), and the box's text
    const rowsAfter = ED.starts.map((st, i) => {
      const end = i + 1 < ED.starts.length ? ED.starts[i + 1].pos - 1 : v.length;
      const seg = v.slice(st.pos, end), cut = (v.slice(st.pos, Math.max(st.pos, Math.min(a, end))) + " " + v.slice(Math.min(end, Math.max(b, st.pos)), end));
      return { n: st.n, before: seg.trim(), after: cut.replace(/[ \t]{2,}/g, " ").replace(/[ \t]+\n/g, "\n").replace(/\n[ \t]+/g, "\n").trim() };
    });
    const boxText = parts.map((p) => p.text).join("\n");
    await closeEditor(true);                                                    // what was typed is kept first
    moveRulesForSplit(sheet, rowsAfter.filter((r) => parts.some((p) => p.row === r.n)), boxText);
    const id = "b" + Date.now().toString(36);
    const all = Object.assign({}, dsx().text_boxes || {});
    all[sheet] = (all[sheet] || []).concat([{ id, parts, page: AppLive.state.page || 0,
      x: Math.round(x0), y: Math.round(y0), w: Math.max(120, Math.round(x1 - x0 + 12)), h: Math.round(y1 - y0) }]);
    dsx().text_boxes = all;
    await saveBoxes("Split into a text box — drag it, size it, and style it in the bar above.");
    V.selectBox(id);
  }

  /* where the "(Continued)" line is on a page 2+ (page px), or null on page 1 */
  function continuedBox() {
    const st = AppLive.state, s = st.settings, d = st.data;
    if (!st || !d || !s || !(st.page > 0)) return null;
    const ce = (st.elements || []).find((e) => e.role === "continued");
    if (ce) return { x: ce.x, y: ce.y, w: ce.w, h: ce.h };
    const top = s.heading_top_margin + (st.headingH || 0) + Math.max(2, Number(s.continued_gap) || 0, 8);
    const sf = st.safe || { left: 0, width: d.canvas_w };
    return { x: sf.left, y: top, w: sf.width, h: Math.max(8, st.continuedH || 20) };
  }

  /* drag handles on the selected heading / paragraph, like the paytable's pays and values:
     ↕ (right edge) = line height (the paragraph's row spacing), ↔ (bottom edge) = letter spacing */
  function spacingHandles(box, t) {
    const ds = () => (App.state.config.dynamic_settings = App.state.config.dynamic_settings || {});
    const tkey = t === "heading" ? "heading_tracking" : "body_tracking";
    const handles = [{ cls: "ls", label: "↔", title: "Letter spacing — drag left / right" }];
    handles.push({ cls: "lh", label: "↕", title: "Line height — drag up / down" });
    for (const h of handles) {
      const el2 = document.createElement("i");
      el2.className = "typo-h " + h.cls;
      el2.textContent = h.label;
      el2.title = h.title;
      box.appendChild(el2);
      ["mousedown", "click", "dblclick"].forEach((ty) => el2.addEventListener(ty, (ev) => ev.stopPropagation()));
      el2.addEventListener("pointerdown", (ev) => {
        ev.preventDefault();
        ev.stopPropagation();
        try { el2.setPointerCapture(ev.pointerId); } catch (_) { /* moves still reach it */ }
        const k = V.state.scale || 1;
        const start = h.cls === "ls" ? ev.clientX : ev.clientY;
        const size = Number(App.get("h_size")) || 60, ls0 = Number(App.get("line_spacing"));
        const from = h.cls === "ls" ? Number(ds()[tkey]) || 0
          : t === "heading" ? (isFinite(ls0) && App.get("line_spacing") !== "" ? (ls0 <= 3 ? Math.round(size * Math.max(0, ls0 - 1)) : ls0) : Math.round(size * 0.1))
            : (App.get("line_gap") === "" || App.get("line_gap") == null ? 30 : Number(App.get("line_gap")) || 0);
        let val = from;
        const tip = document.createElement("span");
        tip.className = "typo-h-tip";
        el2.appendChild(tip);
        const show = () => { tip.textContent = h.cls === "ls" ? `letter spacing ${Math.round(val)}` : `line height ${Math.round(val)}px`; };
        show();
        // the setting this drag writes, as {key: value} (sent live while dragging, saved on release)
        const patch = () => {
          const v = Math.round(val);
          if (h.cls === "ls") return { ["dynamic_settings." + tkey]: v };
          if (t === "heading") return { line_spacing: v > 3 ? v : Math.round((1 + v / size) * 100) / 100 };
          return { line_gap: v };
        };
        liveStart();
        const move = (e) => {
          const d = ((h.cls === "ls" ? e.clientX : e.clientY) - start) / k;   // page px
          const was = Math.round(val);
          val = h.cls === "ls" ? Math.max(-100, Math.min(800, from + d * 2)) : Math.max(0, Math.min(400, from + d));
          show();
          if (Math.round(val) !== was) liveDraft(patch());
        };
        const up = () => {
          el2.removeEventListener("pointermove", move);
          el2.removeEventListener("pointerup", up);
          tip.remove();
          if (Math.round(val) === Math.round(from)) { if (LIVE.done) saveLive(patch()); return; }   // dragged back: the page as it was
          const p = patch();
          for (const key in p) App.set(key, p[key]);
          App.pushConfig();
          saveLive(p, `${t === "heading" ? "Heading" : "Paragraph"} ${h.cls === "ls" ? "letter spacing" : "line height"}: ${Math.round(val)}${h.cls === "ls" ? "" : "px"}`);
        };
        el2.addEventListener("pointermove", move);
        el2.addEventListener("pointerup", up);
      });
    }
  }

  function selBox(x0, y0, x1, y1, label, isRow) {
    const host = el("typoVisHost"), canvas = el("typoVisCanvas");
    const cr = canvas.getBoundingClientRect(), hr = host.getBoundingClientRect(), k = cr.width / AppLive.state.data.canvas_w;
    const box = document.createElement("div");
    box.className = "typo-sel" + (isRow ? " row" : "");
    box.innerHTML = `<span>${label}</span>`;
    Object.assign(box.style, { left: (cr.left - hr.left + x0 * k - 4) + "px", top: (cr.top - hr.top + y0 * k - 4) + "px",
                               width: ((x1 - x0) * k + 8) + "px", height: ((y1 - y0) * k + 8) + "px" });
    host.appendChild(box);
    return box;
  }

  /* ----------------- one row: a click selects it, and it can get a strip behind ----------------- */
  const rowTextOf = (e) => String(e.rowText || e.text || (e.lines || []).join(" ") || "");
  // the drawn lines of a row (an Excel row wrapped over several lines), top to bottom
  function rowLines(e) {
    if (!e || e.kind !== "line") return e ? [e] : [];
    return (AppLive.state.elements || []).filter((x) => x.kind === "line" && String(x.row) === String(e.row) && sameText(rowTextOf(x), rowTextOf(e)))
      .sort((a, b) => (a.y - b.y) || ((Number(a.lineIdx) || 0) - (Number(b.lineIdx) || 0)));
  }
  const lineNo = (e) => Math.max(0, rowLines(e).indexOf(e));

  V.selectRow = function (e) {
    V.state.row = e && e.kind === "line" ? { id: e.id, text: rowTextOf(e), line: lineNo(e) } : null;
  };

  /* styles the heading got while it could be picked as a row (whole-row rules on its text): they won
     over the Heading's own settings. A change made in the Heading bar takes that property back from
     them; "Clear" in the bar removes them. Words styled inside the heading (a selection) stay. */
  const RULE_PROPS = { h_font: ["font"], h_font_style: ["bold", "italic"], h_size: ["size"], h_rgb: ["color"],
                       heading_tracking: ["tracking"], fx: ["fx"] };
  function headingText() {
    const h = (AppLive.state.elements || []).find((e) => e.kind === "heading");
    return h ? rowTextOf(h) : "";
  }
  V.headingRowRules = function () {
    const text = headingText();
    return text ? styleRules().filter((r) => r.kind === "word" && r.scope === "row" && sameText(r.row_text, text) && sameText(r.text, text)) : [];
  };
  V.dropHeadingRowRules = async function (key) {
    const own = V.headingRowRules();
    if (!own.length) return false;
    const props = key ? RULE_PROPS[key] || [] : null;
    if (props && !props.length) return false;
    const ds = (App.state.config.dynamic_settings = App.state.config.dynamic_settings || {});
    ds.text_style_rules = styleRules().map((r) => {
      if (!own.includes(r)) return r;
      if (!props) return null;
      const c = Object.assign({}, r);
      props.forEach((k) => delete c[k]);
      return STYLE_KEYS.some((k) => c[k] != null && c[k] !== "" && c[k] !== false) ? c : null;
    }).filter(Boolean);
    App.refreshUI();
    if (App.flushConfig) await App.flushConfig();
    await V.refreshPreview.now(true);
    return true;
  };

  // the text row under a click — an inline icon gives the row it sits in
  function rowAround(e, canvas, cssX, cssY) {
    if (e && (e.kind === "line" || e.kind === "heading")) return e;
    const k = canvas.getBoundingClientRect().width / AppLive.state.data.canvas_w, x = cssX / k, y = cssY / k;
    const rows = (AppLive.state.elements || []).filter((r) => (r.kind === "line" || r.kind === "heading") && y >= r.y && y <= r.y + r.h);
    // a rules line: its drawn text (Bingo cells side by side share the row's full width)
    const near = (r) => (r.cell != null && r.cbox ? Math.abs(x - Math.max(r.cbox.x, Math.min(r.cbox.x + r.cbox.w, x))) : x >= r.x && x <= r.x + r.w ? 0 : Infinity);
    if (rows.some((r) => r.cell != null)) return rows.slice().sort((a, b) => near(a) - near(b))[0] || null;
    return rows.find((r) => x >= r.x && x <= r.x + r.w) || rows[0] || null;
  }

  // the selected row in the current render (ids can change after a re-render, the text doesn't)
  function rowElement() {
    const r = V.state.row;
    if (!r || !window.AppLive || !AppLive.state) return null;
    const rows = (AppLive.state.elements || []).filter((e) => e.kind === "line" || e.kind === "heading");
    return rows.find((e) => e.id === r.id && sameText(rowTextOf(e), r.text))
      || rows.find((e) => sameText(rowTextOf(e), r.text) && lineNo(e) === r.line)     // the same line of that row
      || rows.find((e) => sameText(rowTextOf(e), r.text)) || null;
  }

  // the strip rule that paints behind this row text (same matching as the Visualiser's bar)
  /* a strip's height: the row's text height + 2 × pad_y (text_styles.strip_geometry), never below 0 */
  function stripRowH(e) {
    return Math.max(1, Math.round((e && ((e.cbox && e.cbox.h) || (e.base && e.base.h) || e.h)) || 40));
  }
  function stripTall(e, pad) {
    return Math.max(0, Math.round(stripRowH(e) + 2 * Number(pad || 0))) + " px tall";
  }

  function stripFor(text) {
    const sheet = V.state.sheet || "";
    return styleRules().find((r) => r.kind === "strip" && (r.scope !== "page" || sameText(r.sheet, sheet)) &&
      (r.match === "exact" ? sameText(text, r.text) : r.match === "contains" ? norm(text).includes(norm(r.text))
        : norm(text).startsWith(norm(r.text)))) || null;
  }

  /* the selected row's settings live in the top bar (TypoStudio "row" target), not a pop-up */
  let rowBarKey = "";
  function hideRowBar() {
    el("typoRowBar")?.remove();
    rowBarKey = "";
    if (window.TypoStudio && TypoStudio.target === "row" && !V.state.row) TypoStudio.endRow();
  }

  function showRowBar(e) {
    el("typoRowBar")?.remove();
    if (!window.TypoStudio) return;
    const text = rowTextOf(e);
    // only when the row (or what's set on it) changed — layout() calls this at every zoom / pan
    const key = e.id + "|" + text + "|" + JSON.stringify(styleRules()) + "|" + rowRoleOf(e) + "|" + JSON.stringify((App.state.config.dynamic_settings || {}).row_roles || {});
    if (TypoStudio.target === "row" && key === rowBarKey) return;
    rowBarKey = key;
    const rt = rulesTarget(e);
    if (rt && rt !== "bingo") { if (TypoStudio.target !== rt) TypoStudio.setTarget(rt); return; }
    const role = e.kind === "heading" ? "heading" : rt || rowRoleOf(e) || "body";
    if (TypoStudio.target === "row") TypoStudio.paint(); else TypoStudio.showRow(role);
  }

  /* what a row is: normal text, a heading or a subheading (row_roles.py — every renderer reads it) */
  function rowRoleOf(e) {
    // a text page: what the server drew this line as (one of its lines can be a heading on its own)
    if (e && e.meta && e.meta.role != null && e.canonical) return String(e.meta.role || "");
    const sheet = V.state.sheet || "", ds = App.state.config.dynamic_settings || {};
    return ((ds.row_roles || {})[sheet] || {})[rowKeyOf(e)] || "";
  }
  /* a row's roles kept tidy after a line's role changed: line settings whose text the row no longer
     holds go (they never apply again, and the row's own role would show through once the text is
     edited); when every drawn line now has the same role, that is the row's role and the line
     settings go — a heading row whose lines were all set back to normal is a normal row */
  function tidyRowRoles(mine, key, e) {
    const pre = key + "|", rowText = norm(rowTextOf(e));
    Object.keys(mine).forEach((k) => { if (k.startsWith(pre) && !rowText.includes(norm(k.slice(pre.length)))) delete mine[k]; });
    const lineKeys = Object.keys(mine).filter((k) => k.startsWith(pre));
    if (!lineKeys.length) return;
    const roleOf = (x) => {
      const t = norm((x.meta && x.meta.part) || x.text), k = lineKeys.find((lk) => norm(lk.slice(pre.length)) === t);
      return k ? (mine[k] === "body" ? "" : mine[k]) : (mine[key] || "");
    };
    const roles = new Set(rowLines(e).map(roleOf));
    if (roles.size !== 1) return;
    const r = [...roles][0];
    lineKeys.forEach((k) => delete mine[k]);
    if (r) mine[key] = r; else delete mine[key];
  }
  /* `line`: only the clicked drawn line ("row:N|<its text>", row_roles.segments) — the rest of the
     row keeps its own role; else the whole row (and any line set on its own goes) */
  async function setRowRole(e, v, line) {
    await flushTyping();
    const sheet = V.state.sheet || "", key = rowKeyOf(e), who = keyName(key, e.row);
    const ds = (App.state.config.dynamic_settings = App.state.config.dynamic_settings || {});
    const all = Object.assign({}, ds.row_roles || {}), mine = Object.assign({}, all[sheet] || {});
    if (line) {
      const text = String((e.meta && e.meta.part) || e.text || "").replace(/<([^<>]*?)(?:~\d+(?:\.\d+)?(?:\^[\d.]+,[\d.]+)?|\^[\d.]+,[\d.]+)\s*>/g, "<$1>").replace(/\s+/g, " ").trim();
      Object.keys(mine).forEach((k) => { if (k.startsWith(key + "|") && sameText(k.slice(key.length + 1), text)) delete mine[k]; });
      const rowRole = mine[key] || "";
      if ((v || "") !== rowRole) mine[key + "|" + text] = v || "body";
      tidyRowRoles(mine, key, e);
    } else {
      Object.keys(mine).forEach((k) => { if (k.startsWith(key + "|")) delete mine[k]; });
      if (v) mine[key] = v; else delete mine[key];
    }
    if (Object.keys(mine).length) all[sheet] = mine; else delete all[sheet];
    ds.row_roles = all;
    App.refreshUI();
    if (App.flushConfig) await App.flushConfig();
    await V.refreshPreview.now(true);
    if (window.TypoStudio) TypoStudio.paint();                     // the Row bar shows its new look
    refocus();
    toast(line ? (v ? `This line is a ${v} now — the rest of ${who} stays as it was.` : `This line is normal text again.`)
      : v ? `${who[0].toUpperCase() + who.slice(1)} is a ${v} now — every ${v} shares the ${v === "heading" ? "Heading" : "Subheading"} look.`
        : `${who[0].toUpperCase() + who.slice(1)} is normal text again.`);
  }

  function renderGuides() {
    const hostEl = el("typoVisGuides");
    if (!hostEl || !V.state.geometry) return;
    if (SP() || rulesOn() || plOn()) { hostEl.innerHTML = ""; return; }   // the design sets its margins (a rules / paylines page: its own guides)
    const g = V.state.geometry;
    const s = V.state.scale;
    const cb = (V.state.guides || []).find((gd) => gd.edge === "cbody"), bodyTop = cb ? cb.y0 : g.body_top;   // a Continued page's text
    const rects = [
      { cls: "vis-rect-safe", l: g.safe_left * s, t: bodyTop * s, w: (g.safe_right - g.safe_left) * s, h: (g.body_bottom - bodyTop) * s },
      { cls: "vis-rect-head", l: g.safe_left * s, t: g.heading_top * s, w: (g.safe_right - g.safe_left) * s, h: (g.heading_bottom - g.heading_top) * s },
    ];
    const rectHTML = rects.filter((r) => r.w > 0 && r.h > 0 && isFinite(r.w) && isFinite(r.h))
      .map((r) => `<div class="vis-rect ${r.cls}" style="left:${r.l}px;top:${r.t}px;width:${r.w}px;height:${r.h}px"></div>`).join("");
    const lineHTML = (V.state.guides || []).map((gd) => {
      if (gd.orientation === "h") {
        return `<div class="vis-guide vis-guide-h" data-gid="${gd.id}" data-edge="${gd.edge}" style="top:${gd.y0 * s}px"><span class="vis-guide-tag">${esc(gd.label)}</span></div>`;
      }
      return `<div class="vis-guide vis-guide-v" data-gid="${gd.id}" data-edge="${gd.edge}" style="left:${gd.x0 * s}px"><span class="vis-guide-tag">${esc(gd.label)}</span></div>`;
    }).join("");
    hostEl.innerHTML = rectHTML + lineHTML;
  }

  function fit() {
    const host = el("typoVisHost");
    if (!host || !V.state.geometry) return;
    const rect = host.getBoundingClientRect();
    const g = V.state.geometry;
    const s = Math.max(MIN_SCALE, Math.min(MAX_SCALE, (rect.width - 40) / g.canvas_w, (rect.height - 40) / g.canvas_h));
    V.state.scale = s;
    V.state.tx = Math.max(0, (rect.width - g.canvas_w * s) / 2);
    V.state.ty = Math.max(0, (rect.height - g.canvas_h * s) / 2);
    V.state.fitted = true;
    V.state.userView = false;
    layout();
  }

  function centerOnly() {
    const host = el("typoVisHost");
    if (!host || !V.state.geometry) return;
    const rect = host.getBoundingClientRect();
    const g = V.state.geometry;
    V.state.tx = Math.max(0, (rect.width - g.canvas_w * V.state.scale) / 2);
    V.state.ty = Math.max(0, (rect.height - g.canvas_h * V.state.scale) / 2);
    layout();
  }

  V.fit = fit;
  V.center = centerOnly;
  V.setZoom = function (z) {
    V.state.scale = Math.max(MIN_SCALE, Math.min(MAX_SCALE, z));
    V.state.fitted = false;
    V.state.userView = true;               // zoomed by the artist: kept
    centerOnly();
  };
  V.zoomBy = function (f) {
    V.setZoom(V.state.scale * f);
  };

  /* --------------------------- pan / zoom --------------------------- */

  function bindCanvasEvents() {
    const host = el("typoVisHost");
    if (!host) return;
    host.addEventListener("wheel", (ev) => {
      ev.preventDefault();
      if (!V.state.geometry) return;
      const rect = host.getBoundingClientRect();
      const mx = ev.clientX - rect.left;
      const my = ev.clientY - rect.top;
      const prev = V.state.scale;
      const next = Math.max(MIN_SCALE, Math.min(MAX_SCALE, prev * (ev.deltaY < 0 ? 1.12 : 1 / 1.12)));
      const ratio = next / prev;
      V.state.tx = mx - (mx - V.state.tx) * ratio;
      V.state.ty = my - (my - V.state.ty) * ratio;
      V.state.scale = next;
      V.state.fitted = false;
      V.state.userView = true;             // zoomed by the artist: kept
      layout();
    }, { passive: false });

    host.addEventListener("mousedown", (ev) => {
      if (ev.button !== 0) return;
      const guideEl = ev.target.closest(".vis-guide");
      if (guideEl) {
        dragGuideStart(guideEl.dataset.gid, ev);
        return;
      }
      if (ev.target.closest("#visStyleBar, #typoRowBar, .lsw-pop, .tsel-layer, .tsel-menu, .tsel-pop, .tedit, .tblh, .vis-cut, #visPartMenu, #visTableBar, #tblCellPop, .tbs-paste, .tbs-menu, .ptc-chips, .ptc-menu")) return;
      if (SP() && SP().pointerDown(ev)) return;   // a paytable card: dragged, not the page panned
      if (V.state.textMode) { exitTextMode(); }       // a press outside the text: back to normal
      V.state.pan = { x: ev.clientX, y: ev.clientY, tx: V.state.tx, ty: V.state.ty, moved: false };
      host.classList.add("vis-panning");
      ev.preventDefault();
    });
    /* text works like Adobe's text frames: a click picks the paragraph's frame (a text box's frame
       for its text) and its bar; a double-click goes into the text — the caret where it was, that
       row picked (the Row bar); in there a double-click picks a word, a triple-click a drawn line, a
       drag any text (the Selection bar). Esc steps back out one level at a time. */
    host.addEventListener("click", (ev) => {
      if (V.state.clickWasPan || ev.target.closest("#visStyleBar, #typoRowBar, .lsw-pop, .vis-guide, .tsel-layer, .tsel-menu, .tsel-pop, .tedit, .tblh, .vis-cut, #visPartMenu, #visTableBar, #tblCellPop, .tbs-paste, .tbs-menu, .bgm-bar")) return;
      if (App.route === "assets" && window.IconStudio) { IconStudio.useAssets(); IconStudio.click(ev); return; }   // icons, not rows
      if (SP()) { SP().click(ev); return; }          // a card, a row, a box: its bar
      if (rulesOn()) RulesCanvas.deselect(true);      // the separator / XTRAA REELS let go (picked rows: below)
      if (plOn()) PaylinesCanvas.deselect();          // the payline lines let go (a click on them never gets here)
      // Typography: an icon is picked first (the top bar becomes its Icon bar); else the text under the click
      if (App.route === "typography" && window.IconStudio && IconStudio.clickTypo(ev)) { if (window.TableStudio) TableStudio.deselect(); return; }
      if (App.route === "typography" && window.TableStudio && TableStudio.clickTypo(ev)) return;      // a table: its Table bar
      const canvas = el("typoVisCanvas");
      if (!canvas || !window.AppLive || !AppLive.elementAt) return;
      const r = canvas.getBoundingClientRect();
      const e = AppLive.elementAt(canvas, ev.clientX - r.left, ev.clientY - r.top);
      const cb = continuedBox(), py = (ev.clientY - r.top) / (r.width / AppLive.state.data.canvas_w);
      const onCont = (e && e.role === "continued") || (!e && cb && py >= cb.y - 4 && py <= cb.y + cb.h + 4);
      if (onCont) { V.selectRow(null); if (window.TypoStudio) TypoStudio.setTarget("continued"); else V.showTarget("continued"); return; }
      const rowEl = rowAround(e, canvas, ev.clientX - r.left, ev.clientY - r.top);
      if (rowEl && rowEl.kind === "heading") {          // the page heading: always the Heading (one set of settings)
        V.selectRow(null);
        if (window.TypoStudio) TypoStudio.setTarget("heading"); else V.showTarget("heading");
        return;
      }
      if (rowEl && rowEl.kind === "line") { pickFrame(rowEl, ev.shiftKey || ev.ctrlKey || ev.metaKey); return; }
      const t = e && (e.kind === "heading" || e.role === "heading") ? "heading" : e && (e.kind === "line" || e.role === "body") ? rulesTarget(e) || "body" : null;
      if (!t && !bgLocked()) { V.showTarget(null); showBgBar(); return; }        // the unlocked background: its bar
      if (!t) { if ((rulesOn() || plOn()) && window.TypoStudio) { V.selectRow(null); TypoStudio.setTarget("rules_page"); return; } V.showTarget(null); return; }
      V.selectRow(null);
      if (window.TypoStudio) TypoStudio.setTarget(t); else V.showTarget(t);
    });
    // double-click text: text mode — select it like in a document, right-click to style it
    host.addEventListener("contextmenu", (ev) => {
      if (ev.target.closest(".tsel-layer, .tsel-menu, .tsel-pop, #typoRowBar, #visStyleBar, .tedit")) return;
      if (SP()) { SP().contextMenu(ev); return; }   // share a card, lock, copy / paste a look
      if (App.route === "assets" && window.IconStudio) { IconStudio.useAssets(); IconStudio.contextMenu(ev); return; }
      // right-click an icon: its size and copies; right-click a row: heading / subheading / normal text
      if (App.route === "typography" && window.IconStudio && !V.state.textMode) {
        IconStudio.useAssets();
        if (IconStudio.contextMenu(ev)) return;
        if (window.TableStudio && TableStudio.contextMenu(ev)) return;          // a table: copy / paste its style
      }
      const canvas = el("typoVisCanvas");
      if (canvas && window.AppLive && AppLive.elementAt && !V.state.textMode) {
        const r = canvas.getBoundingClientRect(), hit = AppLive.elementAt(canvas, ev.clientX - r.left, ev.clientY - r.top);
      }
      if (plOn()) return;                            // a paylines page: no rows to make headings
      if (canvas && rulesOn() && !V.state.textMode) {
        const r = canvas.getBoundingClientRect(), hit = rowAround(AppLive.elementAt(canvas, ev.clientX - r.left, ev.clientY - r.top), canvas, ev.clientX - r.left, ev.clientY - r.top);
        if (hit && hit.cell) { ev.preventDefault(); RulesCanvas.lineMenu(ev, hit); }
        return;
      }
      if (canvas && window.AppLive && AppLive.rowRoleMenu && !V.state.textMode) {
        AppLive.rowRoleMenu(ev, host, canvas, () => V.refreshPreview.now(true));
      }
    });
    host.addEventListener("dblclick", (ev) => {
      if (SP()) { SP().dblclick(ev); return; }   // a text: typed in place · a card: only it
      if (App.route === "assets") return;
      if (ev.target.closest("#visStyleBar, #typoRowBar, .lsw-pop, .vis-guide, .tsel-layer, .tsel-menu, .tsel-pop, .tedit, #visTableBar, #tblCellPop, .vis-cut")) return;
      // a table: double-click one of its boxes to edit just that box (Shift adds more) — table-preview.js
      if (App.route === "typography" && window.AppTblVis && AppTblVis.cellInTypo && AppTblVis.cellInTypo(ev)) return;
      const canvas = el("typoVisCanvas");
      if (!canvas || !window.AppLive || !AppLive.elementAt) return;
      const r = canvas.getBoundingClientRect();
      // an icon in a line counts as its line
      const e = rowAround(AppLive.elementAt(canvas, ev.clientX - r.left, ev.clientY - r.top), canvas, ev.clientX - r.left, ev.clientY - r.top);
      if (!e || (e.kind !== "line" && e.kind !== "heading")) return;
      V.showTarget(null);
      // body text (a text box's too): the caret where the double-click was, its row picked (the Row bar);
      // the page heading: select words to style them
      if (e.kind === "line" && openEditor(e, ev.clientX, ev.clientY)) { pickRow(e, ev.shiftKey); return; }
      enterTextMode(ev.clientX, ev.clientY);
    });
    // ✂ at a table's left / right edge: cut it at a row line; ⇡ at a part's top: join (Tables' own tools)
    host.addEventListener("pointermove", (ev) => {
      if (SP()) { if (!V.state.pan) SP().hover(ev); return; }   // the part under the pointer, outlined
      if (App.route !== "typography" || ED || V.state.pan || V.state.textMode || !window.AppLive || !AppLive.cutHover) return;
      const canvas = el("typoVisCanvas");
      if (canvas) AppLive.cutHover(ev, host, canvas, () => V.refreshPreview.now(true));
    });
    host.addEventListener("pointerleave", () => { if (window.AppLive && AppLive.hideCutButtons) AppLive.hideCutButtons(); });

    if (V._bound) return;
    V._bound = true;

    document.addEventListener("mousemove", (ev) => {
      const d = V.state.drag;
      if (d) {
        dragGuideMove(ev);
        return;
      }
      const p = V.state.pan;
      if (!p) return;
      if (Math.abs(ev.clientX - p.x) + Math.abs(ev.clientY - p.y) > 3) { p.moved = true; V.state.userView = true; }
      V.state.tx = p.tx + (ev.clientX - p.x);
      V.state.ty = p.ty + (ev.clientY - p.y);
      layout();
    });

    document.addEventListener("mouseup", () => {
      if (V.state.drag) dragGuideEnd();
      V.state.clickWasPan = !!(V.state.pan && V.state.pan.moved);
      V.state.pan = null;
      const h = el("typoVisHost");
      if (h) h.classList.remove("vis-panning");
    });

    window.addEventListener("resize", () => {
      if ((App.route === "typography" || App.route === "assets") && V.state.geometry) {
        if (V.state.fitted) fit();
        else centerOnly();
      }
    });
  }

  /* --------------------------- guide drag --------------------------- */

  function posForValue(gd, geometry, value) {
    if (gd.base != null) return gd.base + value;            // the Continued line's gaps
    if (gd.edge === "top") return value;
    if (gd.edge === "gap") return geometry.heading_bottom + value;
    if (gd.edge === "bottom") return geometry.canvas_h - value;
    if (gd.edge === "left") return (geometry.canvas_w - value) / 2;
    return (geometry.canvas_w + value) / 2; // right
  }

  function dragGuideStart(gid, ev) {
    const gd = (V.state.guides || []).find((x) => x.id === gid);
    if (!gd || !V.state.geometry) return;
    V.state.drag = { gd, startX: ev.clientX, startY: ev.clientY, m0: App.get("margin_x") };
    liveStart();
    ev.preventDefault();
  }

  // a side guide pulled wider than the side margins allow (the text never goes past Margin X on either
  // side): Margin X comes in with it, so the guide reaches the page's edge — never moved out again here
  function sideMargin(gd, value, m0, cw) {
    if (gd.edge !== "left" && gd.edge !== "right") return {};
    const m = Math.max(0, Math.round(Number(m0) || 0));
    return value > cw - 2 * m ? { margin_x: Math.max(0, Math.floor((cw - value) / 2)) } : (m !== Math.round(Number(App.get("margin_x")) || 0) ? { margin_x: m } : {});
  }

  function placeGuideLine(gd, pos) {
    const line = document.querySelector(`.vis-guide[data-gid="${gd.id}"]`);
    if (!line) return;
    const px = pos * V.state.scale;
    if (gd.orientation === "h") line.style.top = px + "px";
    else line.style.left = px + "px";
  }

  function dragGuideMove(ev) {
    const d = V.state.drag;
    const delta = (d.gd.orientation === "h" ? ev.clientY - d.startY : ev.clientX - d.startX) / V.state.scale;
    let value;
    if (d.gd.edge === "left") value = d.gd.value - 2 * delta;
    else if (d.gd.edge === "right") value = d.gd.value + 2 * delta;
    else if (d.gd.edge === "bottom") value = d.gd.value - delta;
    else value = d.gd.value + delta;
    value = Math.round(value);
    // as far as the canvas goes, whatever its size (a 4K portrait page is 3840 px tall): a guide's own max is for 1080p
    const geo = V.state.geometry, maxAllowed = geo ? (d.gd.orientation === "h" ? geo.canvas_h : geo.canvas_w - 40) : d.gd.max;
    value = Math.max(d.gd.min, Math.min(maxAllowed, value));
    if (d.value === value) return;
    d.value = value;
    d.extra = geo ? sideMargin(d.gd, value, d.m0, geo.canvas_w) : {};
    placeGuideLine(d.gd, posForValue(d.gd, V.state.geometry, value));
    App.set(d.gd.key, value);                          // the guides drawn after each draft read it (not saved yet)
    Object.entries(d.extra).forEach(([k, v]) => App.set(k, v));
    liveDraft(Object.assign({ [d.gd.key]: value }, d.extra));
  }

  function dragGuideEnd() {
    const d = V.state.drag;
    V.state.drag = null;
    if (d && typeof d.value === "number") {
      App.set(d.gd.key, d.value);
      Object.entries(d.extra || {}).forEach(([k, v]) => App.set(k, v));
      App.pushConfig();
      saveLive(Object.assign({ [d.gd.key]: d.value }, d.extra || {}));
    }
  }

  /* ------------------------------ preview ------------------------------ */

  async function refreshPreview(force) {
    if (!el("typoVisHost")) return;
    if (!V.state.sheet) {
      setBadge("idle");
      return;
    }
    if (studioOf(V.state.sheet)) return paytablePreview();
    setBadge("busy");
    try {
      const canvas = el("typoVisCanvas");
      if (!canvas) {
        setBadge("idle", "Preview unavailable");
        return;
      }
      if (!window.AppLive || !window.AppLive.renderInto) {
        setBadge("idle", "Live renderer not loaded");
        return;
      }
      if (App.configSettled) await App.configSettled();   // the server draws the edit just made
      const geo = await window.AppLive.renderInto(canvas, V.state.sheet, !!force);
      if (!geo) {
        setBadge("idle", "Preview failed");
        return;
      }
      const sameCanvas = V.state.geometry && V.state.geometry.canvas_w === geo.canvas_w && V.state.geometry.canvas_h === geo.canvas_h;
      V.state.geometry = geo;
      V.state.guides = computeTypoGuides(geo);
      const hostEl = el("typoVisHost");
      if (hostEl) hostEl.style.setProperty("--typo-vis-ar", geo.canvas_w + " / " + geo.canvas_h);
      // the view the artist zoomed / panned to stays through every edit: only a new canvas size (or ⛶ Fit) fits again
      if (!sameCanvas || (!V.state.fitted && !V.state.userView)) {
        V.state.fitted = false;
        fit();
      } else {
        layout();
      }
      redrawCanvas();
      window.dispatchEvent(new Event("psh:canvas-ready"));   // start-up work queued behind the first frame
      const lost = ((((AppLive.state.canon || {}).layouts || [])[0] || {}).source || {}).missing_boxes || [];
      const lostKey = V.state.sheet + "|" + lost.join(",");
      if (lost.length && V.state.lostKey !== lostKey) {
        toast(`${lost.length === 1 ? "A text box's words are" : lost.length + " text boxes' words are"} no longer in the Excel — the text is back in the paragraph.`, "warn");
      }
      V.state.lostKey = lostKey;
      showPage(V.state.page || 0);
      if (window.TypoStudio && document.querySelector("#typoStrip .ptc-bar")) TypoStudio.paint();   // back from a paytable page: its bar goes
      else if (window.TypoStudio && TypoStudio.syncPage) TypoStudio.syncPage();               // a rules page: its own targets
      if (ED) relayout();                                  // a re-render while typing keeps the typed text
      else renderRail();
      repaintPicked();
      if (window.IconStudio) IconStudio.panel();
    } catch (e) {
      setBadge("idle", "Preview failed");
      return;
    }
    setBadge("idle");
  }
  // edits wait 120 ms for the next keystroke; opening another page draws at once
  V.refreshPreview = debounce(refreshPreview, 120);
  V.refreshPreview.at_once = refreshPreview;

  V.refreshPreview.now = async function (force) {      // undebounced: the word-style bar waits for it
    if (studioOf(V.state.sheet)) return paytablePreview();
    const canvas = el("typoVisCanvas");
    if (!canvas || !V.state.sheet || !window.AppLive) return;
    setBadge("busy");
    if (App.configSettled) await App.configSettled();
    const geo = await window.AppLive.renderInto(canvas, V.state.sheet, !!force);
    if (geo) { V.state.geometry = geo; V.state.guides = computeTypoGuides(geo); layout(); showPage(V.state.page || 0); }
    if (ED) relayout();
    else renderRail();
    repaintPicked();
    setBadge("idle");
  };

  // an undo / redo (App.hist) put other settings back: draw them, and drop a picked text box that is gone
  window.addEventListener("psh:history", () => {
    if (!el("typoVisHost") || !V.state.sheet) return;
    if (V.state.box && !boxConf(V.state.box)) {
      V.state.box = null;
      if (window.TypoStudio && TypoStudio.target === "box") TypoStudio.setTarget("body");
    }
    V.refreshPreview.at_once(true);
    if (window.TypoStudio) TypoStudio.paint();
  });

  // the page's own editor when it isn't a normal page: the paytable (paytable_canvas.js); SP() is the
  // one active on the Canvas now. The Game / Bingo Rules pages are edited like normal pages (their
  // layout from their own renderer, rules_layout.py); rules_canvas.js adds what they have beyond that.
  function studioOf(sheet) {
    if (window.PaytableCanvas && PaytableCanvas.isPay(sheet)) return PaytableCanvas;
    return null;
  }
  function SP() {
    if (window.PaytableCanvas && PaytableCanvas.on()) return PaytableCanvas;
    return null;
  }
  const rulesOn = () => !!(window.RulesCanvas && RulesCanvas.on());
  const plOn = () => !!(window.PaylinesCanvas && PaylinesCanvas.on());    // a Paylines page (paylines_canvas.js)
  /* a Game / Bingo Rules line's paragraph: the TypoStudio target with its own keys (null: not one) */
  function rulesTarget(e) {
    const m = (e && e.meta) || {};
    if (!e || !m.rules) return null;
    return m.rules === "bingo_rules" ? "bingo" : m.part === "legal" ? "gr_legal" : "gr_rules";
  }
  V.rulesTarget = rulesTarget;

  /* a paytable / rules sheet: its own editor's page — no rows, tables or guides here */
  async function paytablePreview() {
    const canvas = el("typoVisCanvas"), hostEl = el("typoVisHost");
    if (!canvas || !hostEl) return;
    setBadge("busy");
    if (window.TableStudio) TableStudio.deselect();
    if (window.IconStudio) IconStudio.deselect();
    if (window.AppTblVis && AppTblVis.clearTypo) AppTblVis.clearTypo();
    V.state.row = null;
    // the last text page: its parts can't be hit, it no longer draws into this canvas, its frames go
    if (window.AppLive && AppLive.state) { AppLive.state.elements = []; AppLive.state.pages = []; AppLive.state.renderTarget = null; }
    hostEl.querySelectorAll(".typo-sel, .typo-reset, .typo-boxmenu, .tblh, .tblh-ghost, .tbs-box").forEach((n) => n.remove());
    const geo = await studioOf(V.state.sheet).render(canvas, V.state.sheet);
    if (!geo) { setBadge("idle", "Preview failed"); return; }
    const same = V.state.geometry && V.state.geometry.canvas_w === geo.canvas_w && V.state.geometry.canvas_h === geo.canvas_h;
    V.state.geometry = geo;
    V.state.guides = [];
    hostEl.style.setProperty("--typo-vis-ar", geo.canvas_w + " / " + geo.canvas_h);
    if (!same || (!V.state.fitted && !V.state.userView)) { V.state.fitted = false; fit(); } else layout();
    V.state.page = 0;
    const lab = el("typoVisPage");
    if (lab) lab.textContent = "Page 1 of 1";
    ["typoVisPrev", "typoVisNext"].forEach((id) => { const b = el(id); if (b) b.disabled = true; });
    renderRail();
    if (window.TypoStudio) TypoStudio.paint();
    setBadge("idle");
  }

  V.schedule = function () {
    if (App.route !== "typography" && App.route !== "assets") return;
    if (!el("typoVisHost") || V.state.liveHold) return;
    V.refreshPreview();
  };

  /* ------------------------------ init ------------------------------ */

  function fillSheetSelect() {
    const sel = el("typoVisSheet");
    if (!sel) return;
    if (!V.state.sheets.length) {
      sel.innerHTML = `<option value="">No normal pages</option>`;
      sel.disabled = true;
      return;
    }
    const current = V.state.sheet || V.state.sheets[0];
    const pay = (n) => window.PaytableCanvas && PaytableCanvas.isPay(n) && !/pay\s*table/i.test(n);   // "· Paytable" unless it says so
    const rk = (n) => (window.RulesCanvas && RulesCanvas.state.kinds[n]) || "";
    const pl = (n) => window.PaylinesCanvas && PaylinesCanvas.isPl(n) && !/(pay|win)\s*lines?/i.test(n);
    const tag = (n) => (pay(n) ? " · Paytable" : rk(n) === "game_rules" && !/game\s*rules/i.test(n) ? " · Game Rules" : rk(n) === "bingo_rules" && !/bingo/i.test(n) ? " · Bingo Rules" : pl(n) ? " · Paylines" : "");
    sel.innerHTML = V.state.sheets.map((n) => `<option value="${esc(n)}" ${n === current ? "selected" : ""}>${esc(n)}${tag(n)}</option>`).join("");
    sel.disabled = false;
    sel.onchange = () => {
      V.state.sheet = sel.value;
      V.state.page = 0;
      V.refreshPreview.at_once(true);
    };
  }

  V.init = async function () {
    V.state.fitted = false;
    const host = el("typoVisHost");
    if (!host) return;
    if (App.histPaint) App.histPaint();
    bindCanvasEvents();
    el("typoVisPrev")?.addEventListener("click", () => showPage((V.state.page || 0) - 1));
    el("typoVisNext")?.addEventListener("click", () => showPage((V.state.page || 0) + 1));
    try {
      const meta = await api("/api/visualiser/sheets", { method: "POST", body: {} });
      const normal = (meta && meta.sheets) || [], studio = (meta && meta.studio_sheets) || {};
      const pays = Object.keys(studio).filter((n) => studio[n] === "paytable");
      if (window.PaytableCanvas) PaytableCanvas.setSheets(pays);     // paytable pages: drawn by paytable_canvas.js
      // Game Rules / Bingo Rules pages: drawn by their own renderer, edited by rules_canvas.js
      const rules = {};
      Object.keys(studio).filter((n) => studio[n] === "game_rules" || studio[n] === "bingo_rules").forEach((n) => { rules[n] = studio[n]; });
      if (window.RulesCanvas) RulesCanvas.setSheets(rules);
      // Paylines / Win Lines pages: drawn by their own renderer, their lines edited by paylines_canvas.js
      if (window.PaylinesCanvas) PaylinesCanvas.setSheets((meta && meta.payline_sheets) || []);
      const order = (meta && meta.all_sheets) || normal.concat(pays, Object.keys(rules));
      V.state.sheets = order.filter((n) => normal.includes(n) || pays.includes(n) || rules[n]);
      if (V.state.sheet && V.state.sheets.indexOf(V.state.sheet) === -1) V.state.sheet = "";
      if (!V.state.sheet && V.state.sheets.length) V.state.sheet = V.state.sheets[0];
      fillSheetSelect();
      if (!meta || meta.excel_ok === false) {
        host.innerHTML = `<div class="empty" style="margin:14px"><div class="empty-icon">▤</div><div class="empty-title">No workbook configured</div><div class="empty-sub">${esc((meta && meta.excel_error) || "Set the Excel file in the Project view to preview pages.")}</div></div>`;
        return;
      }
      if (!V.state.sheet) {
        host.innerHTML = `<div class="empty" style="margin:14px"><div class="empty-icon">▤</div><div class="empty-title">No normal pages</div><div class="empty-sub">The preview shows normal pages (the Visualiser renderer). Paytable / Game / Bingo Rules pages use their own editors.</div></div>`;
        return;
      }
      if (V.state.sheet) V.refreshPreview(true);
    } catch (e) {
      host.innerHTML = `<div class="empty" style="margin:14px"><div class="empty-icon">⚠</div><div class="empty-title">Preview unavailable</div><div class="empty-sub">${esc(e && e.message ? e.message : String(e))}</div></div>`;
    }
  };

  /* ---------------------- text mode: select text like in a document ----------------------
     Invisible words lie exactly over the drawn ones, so the browser's own selection works:
     drag across words and lines, double-click a word, triple-click a line, Shift+click to extend.
     Right-click the selection → style it (a word-style rule: it matches the text, so it survives
     Excel revisions and every market of the game). */
  const measureCtx = document.createElement("canvas").getContext("2d");
  const TOKEN = /^<[^<>]+>$/;

  function textLines() {
    const out = [];
    for (const e of (window.AppLive && AppLive.state.elements) || []) {
      const heading = e.kind === "heading";
      if (!(heading && e.role !== "continued") && e.kind !== "line") continue;
      const dx = Number(e.ov && e.ov.x) || 0, dy = Number(e.ov && e.ov.y) || 0;   // a row moved in the Visualiser
      const row = heading ? (e.lines || []).join(" ") : (e.rowText || e.text || "");
      AppLive.textRows(e).forEach((r, li) => out.push({ e, li, row, x: r.x + dx, top: r.top + dy, h: r.h,
                                                        runs: r.runs, size: e.size, family: e.family, heading }));
    }
    return out;
  }

  function wordsOf(line) {
    // each word with its x and width (canvas px), from the server's run positions
    const words = [];
    for (const r of line.runs) {
      if (r.kind === "icon" || !String(r.text || "").trim()) continue;
      const text = String(r.text);
      if (TOKEN.test(text.trim())) continue;                      // a symbol written as <name>
      measureCtx.font = `${line.size}px ${line.family}, Arial, sans-serif`;
      const full = measureCtx.measureText(text).width || 1;
      const k = (Number(r.w) || full) / full;
      let pos = 0;
      for (const part of text.split(/(\s+)/)) {
        const w = measureCtx.measureText(part).width * k;
        if (part.trim()) words.push({ text: part, x: line.x + (Number(r.x) || 0) + pos, w });
        pos += w;
      }
    }
    return words;
  }

  /* where text mode runs: the Typography preview, or any other live canvas (the Visualiser
     passes its own host, canvas, sheet and refresh through TextSelect.enter) */
  let TS = null;
  function typoTarget() {
    return { host: el("typoVisHost"), canvas: el("typoVisCanvas"), sheet: () => V.state.sheet || "",
             refresh: () => V.refreshPreview.now(true) };
  }

  function enterTextMode(clientX, clientY, target) {
    exitTextMode();
    const t = target || typoTarget();
    const host = t.host, canvas = t.canvas;
    if (!host || !canvas || !AppLive.state.data) return;
    TS = t;
    V.state.textMode = true;
    const cr = canvas.getBoundingClientRect(), hr = host.getBoundingClientRect();
    const k = cr.width / AppLive.state.data.canvas_w;
    const layer = document.createElement("div");
    layer.className = "tsel-layer";
    Object.assign(layer.style, { left: (cr.left - hr.left) + "px", top: (cr.top - hr.top) + "px", width: cr.width + "px", height: cr.height + "px" });
    let html = "";
    textLines().forEach((line, n) => {
      const words = wordsOf(line);
      if (!words.length) return;
      html += `<div class="tsel-line" data-n="${n}" data-row="${esc(line.row)}">` + words.map((w, i) => {
        const span = `<span class="tsel-w" data-i="${i}" style="left:${w.x * k}px;top:${line.top * k}px;width:${w.w * k}px;height:${line.h * k}px;font-size:${line.size * k}px;line-height:${line.h * k}px">${esc(w.text)}</span>`;
        return span + (i < words.length - 1 ? `<span class="tsel-gap"> </span>` : "");
      }).join("") + `<span class="tsel-gap">\n</span></div>`;
    });
    const inTypo = host === el("typoVisHost");
    layer.innerHTML = html + `<div class="tsel-hint">${inTypo ? "Select words · style them from the top bar · right-click for line breaks · Esc to finish"
      : "Select text like in a document · right-click it to style · Esc to finish"}</div>`;
    host.appendChild(layer);
    V.state.textLines = textLines();
    ["mousedown", "pointerdown", "click", "dblclick", "wheel"].forEach((t) => layer.addEventListener(t, (ev) => ev.stopPropagation()));
    layer.addEventListener("contextmenu", (ev) => { ev.preventDefault(); ev.stopPropagation(); openMenu(ev); });
    // start with the double-clicked word selected
    const hit = clientX == null ? null : document.elementFromPoint(clientX, clientY);
    if (hit && hit.classList && hit.classList.contains("tsel-w")) {
      const rg = document.createRange();
      rg.selectNodeContents(hit);
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(rg);
    }
  }

  function exitTextMode(keepWords) {
    V.state.textMode = false;
    TS = null;
    document.querySelectorAll(".tsel-layer, .tsel-menu, .tsel-pop").forEach((n) => n.remove());
    if (!keepWords && V.state.wordSel) {               // done with these words: the top bar goes back to text
      V.state.wordSel = null;
      if (window.TypoStudio && TypoStudio.target === "words") TypoStudio.paint();
    }
  }

  /* ------------- Selection: the top bar styles exactly the selected text (like Photoshop) -------------
     Select text while editing a paragraph (double-click it), or words of a heading: the top bar then
     shows and changes THAT text — font, style, size, letter spacing, colour, layer style, a strip
     behind it. Nothing selected: the bar is the heading's / paragraph's again. "Just this text" saves a
     rule for that exact occurrence in its row ("nth", text_styles.py); a rule holds only what was
     changed, so overlapping selections add up (bigger phrase + one red word). */
  V.state.wordSel = null;
  const typoText = () => !!(V.state.textMode && TS && TS.host === el("typoVisHost"));
  const STYLE_KEYS = ["color", "bold", "italic", "font", "size", "fx", "tracking", "bg", "bg_opacity", "bg_pad_x", "bg_pad_y",
    "bg_radius", "bg_radii", "bg_border", "bg_fx"];
  const BG_OFF = { bg: null, bg_opacity: null, bg_pad_x: null, bg_pad_y: null, bg_radius: null, bg_radii: null, bg_border: null, bg_fx: null };
  const wt = () => AppLive.wordText;
  let wordSelTimer = 0;
  // words picked in text mode (a heading): the bar follows them
  document.addEventListener("selectionchange", () => {
    if (!typoText()) return;
    clearTimeout(wordSelTimer);
    wordSelTimer = setTimeout(() => {
      if (!typoText()) return;
      const ph = selectedPhrases();
      if (!ph.length) return;
      showSelection(ph.map(tselEntry).filter(Boolean));
    }, 120);
  });
  // level 1: the paragraph's frame, or the text box's when the text is in one
  function pickFrame(e, add) {
    if (rulesTarget(e) === "bingo") { pickRow(e, add); return; }   // a Bingo row: its own align / size / colour
    // a row made a heading is picked like the page heading: at once, with its gap guides
    if (e && e.kind === "line" && !add && !rulesTarget(e) && rowRoleOf(e) === "heading") { pickRow(e); return; }
    V.selectRow(null);
    if (e && e.boxId != null) { V.selectBox(e.boxId); return; }
    if (rulesTarget(e)) { if (window.TypoStudio) TypoStudio.setTarget(rulesTarget(e)); else V.showTarget(rulesTarget(e)); return; }
    if (window.TypoStudio) TypoStudio.setTarget("body"); else V.showTarget("body");
  }
  // level 2: one row (the Row bar) — the one the caret is in while typing
  function pickRow(e, add) {
    if (!e || e.kind !== "line") return;
    if (rulesTarget(e) === "bingo") RulesCanvas.pickCells([e.cell], add);      // the Bingo row bar is this row's
    V.selectRow(e);
    const t = rulesTarget(e) || rowRoleOf(e) || "body";
    if (window.TypoStudio) TypoStudio.setTarget(t); else V.showTarget(t);
  }
  // the caret moved to another drawn line: the Row bar follows it
  function followCaret() {
    if (!ED || !ED.map) return;
    const p = ED.map.pts[Math.min(sel().focus, ED.map.pts.length - 1)], e = p && p.ln && p.ln.el;
    if (e && e.kind === "line" && (!V.state.row || V.state.row.id !== e.id)) pickRow(e);
  }
  // Esc: text selected -> just the caret; the caret -> out of the text, its frame picked; a frame -> nothing
  function stepBack() {
    if (ED) {
      const s = sel();
      if (s.a !== s.b) { setSel(s.focus, s.focus); return; }
      const e = rowElement() || {}, boxId = e.boxId, rt = rulesTarget(e);
      // a rules row: back to its paragraph (a Bingo row: the Paragraph, its rows let go)
      closeEditor(true, () => (rt ? (V.selectRow(null), RulesCanvas.deselect(), TypoStudio.setTarget(rt)) : pickFrame(boxId != null ? { boxId } : {})));
      return;
    }
    if (App.route !== "typography") return;
    V.selectRow(null);
    if (window.TypoStudio && TypoStudio.target === "box") TypoStudio.setTarget("body");
    V.showTarget(null);
  }
  // a Row bar change while typing: what was typed is the row's text first
  async function flushTyping() {
    if (ED && writeRows(ED)) await TextEdits.save();
  }
  const refocus = () => { if (ED) ED.ta.focus({ preventScroll: true }); };

  function showSelection(entries) {
    const same = JSON.stringify((entries || []).map(entryKey)) === JSON.stringify((V.state.wordSel || []).map(entryKey));
    V.state.wordSel = entries && entries.length ? entries : null;
    if (!window.TypoStudio) return;
    if (V.state.wordSel) {
      // when the selection ends the bar goes back to that text (the paragraph edited, the heading…)
      const e = V.state.wordSel[0].el || {};
      const role = e.kind === "heading" ? "heading" : String(e.rowRole || "") === "subheading" ? "subheading" : "body";
      if (!same || TypoStudio.target !== "words") TypoStudio.showSelection(role);
    }
    else if (TypoStudio.target === "words") TypoStudio.endSelection();
  }
  const entryKey = (e) => [e.row, e.text, e.nth];

  /* the selection of a heading's words (text mode) as an exact place in its row */
  function tselEntry(p) {
    const lines = V.state.textLines || [], ln = lines[p.n];
    if (!ln) return null;
    let before = "";
    document.querySelectorAll(".tsel-line").forEach((lineEl) => {
      const n = Number(lineEl.dataset.n), other = lines[n];
      if (!other || other.e !== ln.e) return;
      const ws = [...lineEl.querySelectorAll(".tsel-w")].map((w) => w.textContent);
      if (n < p.n) before += ws.join("");
      else if (n === p.n) before += ws.slice(0, p.first).join("");
    });
    const { skel, occurrences } = wt();
    const at = skel(before).s.length;
    const nth = occurrences(skel(p.row).s, skel(p.phrase).s).filter((i) => i < at).length;
    return { src: "text", n: p.n, first: p.first, row: p.row, text: p.phrase, nth, phrase: p.phrase, words: p.words, el: ln.e };
  }
  /* the editor's selection, one entry per Excel row it touches (spaces at its ends left out) */
  function editorEntries() {
    if (!ED) return [];
    const s = sel(), v = ED.ta.value, out = [];
    if (s.a === s.b) return out;
    const { skel, occurrences } = wt();
    ED.starts.forEach((st, si) => {
      const end = si + 1 < ED.starts.length ? ED.starts[si + 1].pos - 1 : v.length;
      let a = Math.max(s.a, st.pos) - st.pos, b = Math.min(s.b, end) - st.pos;
      const seg = v.slice(st.pos, end);
      while (a < b && /\s/.test(seg[a])) a++;
      while (b > a && /\s/.test(seg[b - 1])) b--;
      if (b <= a) return;
      const text = seg.slice(a, b), want = skel(text).s;
      if (!want) return;                                            // only icons / spaces
      const rowSk = skel(seg), first = rowSk.ix.findIndex((i) => i >= a);
      const nth = occurrences(rowSk.s, want).filter((i) => i < (first < 0 ? rowSk.s.length : first)).length;
      const row = ED.rows.find((r) => r.n === st.n);
      out.push({ src: "editor", n: st.n, row: seg, text, nth, phrase: text.replace(/\s+/g, " ").trim(),
                 words: text.split(/\s+/).filter((w) => w && !/^<[^<>]+>$/.test(w)), el: row && row.els[0] });
    });
    return out;
  }
  let edSelTimer = 0;
  function editorSelectionChanged() {
    clearTimeout(edSelTimer);
    edSelTimer = setTimeout(() => {
      if (!ED) return;
      const entries = editorEntries();
      if (!entries.length) followCaret();                             // just the caret: its row's bar
      showSelection(entries);
    }, 120);
  }

  // where an exact rule / selection sits in its row's skeleton: [start, end) or null
  function rangeOf(rowText, text, nth) {
    const { skel, occurrences } = wt(), want = skel(text).s, hits = occurrences(skel(rowText).s, want);
    return want && nth >= 0 && nth < hits.length ? [hits[nth], hits[nth] + want.length] : null;
  }
  const isExact = (r) => r && r.kind === "word" && r.nth != null && r.nth !== "";
  // the heading's / paragraph's own look under the selection (what "no change" means)
  function selBase(entry) {
    const e = (entry && entry.el) || {}, ds = App.state.config.dynamic_settings || {};
    const heading = e.kind === "heading", sub = !heading && String(e.rowRole || "") === "subheading";
    const role = heading ? "Heading text" : sub ? "Subheading text" : "Body text";
    const hex = (v) => Array.isArray(v) ? "#" + v.slice(0, 3).map((n) => Math.max(0, Math.min(255, Number(n) || 0)).toString(16).padStart(2, "0")).join("") : String(v || "#ffffff");
    const style = String(App.get(heading ? "h_font_style" : sub ? "dynamic_settings.subheading_font_style" : "b_font_style") || "regular").toLowerCase();
    return {
      font: String((sub && ds.subheading_font_request) || App.get(heading || sub ? "h_font" : "b_font") || ""),
      size: Number(e.size) || Number(App.get(heading ? "h_size" : "b_size")) || 30,
      color: hex(e.rgb || App.get(heading ? "h_rgb" : "b_rgb")).toLowerCase(),
      tracking: Number(ds[heading ? "heading_tracking" : "body_tracking"]) || 0,
      fx: ((ds.style_assignments || {})[role]) || "", bold: style.includes("bold"), italic: style.includes("italic"),
    };
  }
  // what the rules already give the selection (the first entry): rules covering it, in order
  function selProps(entry) {
    const out = {}, sheet = (TS || typoTarget()).sheet(), here = rangeOf(entry.row, entry.text, entry.nth);
    for (const r of styleRules()) {
      if (r.kind !== "word") continue;
      let covers;
      if (isExact(r)) {
        const rr = sameText(r.row_text, entry.row) && r.sheet === sheet ? rangeOf(entry.row, r.text, Number(r.nth)) : null;
        covers = !!(rr && here && rr[0] <= here[0] && rr[1] >= here[1]);
      } else if (r.scope === "starts") {
        covers = startsWith(entry.row, r.starts) && (r.whole_row ? wholeRow(entry) : sameText(r.text, entry.phrase));
      } else covers = sameText(r.text, entry.phrase) && ((r.scope || "game") === "game" || r.sheet === sheet)
        && (r.scope !== "row" || sameText(r.row_text, entry.row));
      if (covers) for (const k of STYLE_KEYS) if (r[k] != null && r[k] !== "" && r[k] !== false) out[k] = r[k];
    }
    return out;
  }
  function selScope() {
    return V.state.wordScope || "row";
  }
  /* "Rows starting with …": the first N words of the selection's row (a number stands for any number,
     like text_styles.starts_with) — every row on every page that starts with them gets the style */
  const rowWords = (row) => String(row || "").replace(/<([^<>]*?)(?:~\d+(?:\.\d+)?(?:\^[\d.]+,[\d.]+)?|\^[\d.]+,[\d.]+)\s*>/g, "<$1>").split(/\s+/).filter(Boolean);
  const NUMBER = /^[$€£]?\d[\d,.]*[%x]?[,.:;]?$/i;
  function startsWith(row, starts) {
    const want = String(starts || "").toLowerCase().split(/\s+/).filter(Boolean), have = rowWords(row).slice(0, want.length).map((w) => w.toLowerCase());
    return want.length > 0 && have.length === want.length && have.every((w, i) => w === want[i] || (NUMBER.test(w) && NUMBER.test(want[i])));
  }
  const startsN = (row) => Math.max(1, Math.min(rowWords(row).length, Number(V.state.startsN) || 5));
  const startsOf = (row) => rowWords(row).slice(0, startsN(row)).join(" ");
  const wholeRow = (en) => { const { skel } = wt(); return skel(en.text).s === skel(en.row).s; };
  // how wide the selected text is drawn (page px): its first drawn line
  function selWidth(en) {
    if (ED && ED.map) {
      const s = sel(), pts = ED.map.pts.slice(s.a, s.b + 1).filter(Boolean);
      if (pts.length) { const ln = pts[0].ln, xs = pts.filter((p) => p.ln === ln).map((p) => p.x); return Math.max(1, Math.max(...xs) - Math.min(...xs)); }
    }
    if (en && en.src === "line" && en.el) return Math.max(1, Number(en.el.lineW) || 1);
    const ws = [...document.querySelectorAll(".tsel-w")].filter((w) => { const r = window.getSelection(); return r && r.rangeCount && r.containsNode(w, true); });
    if (ws.length) {
      const k = pageK(), rs = ws.map((w) => w.getBoundingClientRect()), top = rs[0].top;
      const line = rs.filter((r) => Math.abs(r.top - top) < 2);
      return Math.max(1, (Math.max(...line.map((r) => r.right)) - Math.min(...line.map((r) => r.left))) / k);
    }
    return 100;
  }
  /* the strip behind selected text / one line: colour, opacity, height, width — or fit (hugs the words) */
  function wordStripHtml(p, en, attr) {
    if (!p.bg) return "";
    const b = selBase(en), size = Math.max(4, Math.round(b.size * (Number(p.size) || 100) / 100));
    const pad = p.bg_pad_y != null ? Number(p.bg_pad_y) : 2, padX = p.bg_pad_x != null ? Number(p.bg_pad_x) : 6, w = selWidth(en);
    return `<label class="ts-color" title="Strip colour"><input type="color" ${attr}="bg" value="${esc(p.bg)}"></label>
      ${stripGear(attr, `<div class="tsp-row"><span class="tsp-l">Opacity</span><input class="ts-size ts-narrow" type="number" min="0" max="100" step="5" ${attr}="bg_opacity" value="${Math.round((p.bg_opacity == null ? 1 : Number(p.bg_opacity)) * 100)}" title="Strip opacity (%)"><span class="ts-unit">%</span></div>
      <div class="tsp-row"><span class="tsp-l">Height</span><input class="ts-size ts-narrow" type="number" min="0" max="${size * 4}" ${attr}="height" data-size="${size}" value="${Math.max(0, Math.round(1.1 * size + 2 * pad))}" title="Strip height (px)"><span class="ts-unit">px</span></div>
      <div class="tsp-row"><span class="tsp-l">Width</span><input class="ts-size ts-narrow" type="number" min="1" max="4000" ${attr}="width" data-w="${Math.round(w)}" value="${Math.round(w + 2 * padX)}" title="Strip width (px)"><span class="ts-unit">px</span>
        <button class="ts-al ${p.bg_pad_x == null ? "on" : ""}" ${attr}="fit" title="Fit: the strip hugs the words">fit</button></div>`,
        { radius: p.bg_radius != null ? Number(p.bg_radius) : 4, radii: p.bg_radii, border: p.bg_border, fx: p.bg_fx })}`;
  }
  /* ----- the strip pop-over (a gear beside a strip's colour): its size, corners, border and layer style.
     Drawn inside the bar (the bar's own inputs keep their wiring) and placed under its gear; it stays
     open while the strip changes, until a click elsewhere or Esc. `key` names the strip it is for. ----- */
  const BORDER_ALIGN = [["inside", "Inside"], ["center", "Centre"], ["outside", "Outside"]];
  function stripGear(key, sizeHtml, look) {
    const open = V.state.stripPop === key, radii = Array.isArray(look.radii) && look.radii.length === 4 ? look.radii : null;
    const bd = look.border && Number(look.border.width) > 0 ? look.border : null, fx = look.fx || "";
    const gear = `<button class="ts-al ts-gear ${open ? "on" : ""}" data-stripgear="${esc(key)}" title="Strip settings: size, corners, border, layer style">⚙</button>`;
    if (!open) return gear;
    return gear + `<div class="ts-strippop" data-pop="${esc(key)}">
      <div class="tsp-h">Size</div>${sizeHtml}
      <div class="tsp-h">Corners</div>
      <div class="tsp-row"><span class="tsp-l">Radius</span><input class="ts-size ts-narrow" type="number" min="0" max="2000" data-x="radius" value="${Math.round(Number(look.radius) || 0)}" title="Corner radius (px)"><span class="ts-unit">px</span>
        <label class="ts-check" title="Give each corner its own radius"><input type="checkbox" data-x="each" ${radii ? "checked" : ""}> each corner</label></div>
      ${radii ? `<div class="tsp-corners">${[0, 1, 3, 2].map((i) => `<span class="tsp-l" title="${["Top left", "Top right", "Bottom right", "Bottom left"][i]}">${["↖", "↗", "↘", "↙"][i]}</span><input class="ts-size ts-narrow" type="number" min="0" max="2000" data-x="r${i}" value="${Math.round(Number(radii[i]) || 0)}">`).join("")}</div>` : ""}
      <div class="tsp-h">Border</div>
      <div class="tsp-row"><span class="tsp-l">Width</span><input class="ts-size ts-narrow" type="number" min="0" max="200" data-x="bw" value="${bd ? Math.round(Number(bd.width)) : 0}" title="Border width (px) — 0: no border"><span class="ts-unit">px</span>
        <label class="ts-color ${bd ? "" : "ts-off"}" title="Border colour"><input type="color" data-x="bc" value="${esc((bd && bd.color) || "#ffffff")}"></label>
        <input class="ts-size ts-narrow" type="number" min="0" max="100" step="5" data-x="bo" value="${bd && bd.opacity != null ? Math.round(Number(bd.opacity)) : 100}" title="Border opacity (%)"><span class="ts-unit">%</span></div>
      <div class="tsp-row"><span class="tsp-l">Position</span><select class="ts-style" data-x="balign" title="Where the border sits on the strip's edge">${BORDER_ALIGN.map(([v, t]) => `<option value="${v}" ${(bd ? bd.align || "inside" : "inside") === v ? "selected" : ""}>${t}</option>`).join("")}</select></div>
      ${window.PshLook ? PshLook.editorHtml(look) : ""}
      <div class="tsp-h">Layer style</div>
      <div class="tsp-row"><button class="ts-fxbtn" data-x="fx" title="A layer style from the game's library on the strip">${fx && typeof fx === "string" ? `<img src="${swatchUrl(fx)}" alt="">` : `<span class="ts-fx-none">fx</span>`}<span class="ts-fx-name">${esc(typeof fx === "object" ? "Its own (glow / shadow above)" : fx || "None")}</span><span class="ts-fx-caret">▾</span></button></div>
    </div>`;
  }
  // wire a strip's gear and its pop-over; save({radius, radii, border, fx}) — null takes one away
  function wireStripPop(root, key, look, save) {
    const gear = root.querySelector(`[data-stripgear="${CSS.escape(key)}"]`);
    if (!gear) return;
    gear.addEventListener("click", () => { V.state.stripPop = V.state.stripPop === key ? null : key; if (window.TypoStudio) TypoStudio.paint(); });
    const pop = root.querySelector(`.ts-strippop[data-pop="${CSS.escape(key)}"]`);
    if (!pop) return;
    const g = gear.getBoundingClientRect();
    pop.style.top = (g.bottom + 6) + "px";
    pop.style.left = Math.max(8, Math.min(window.innerWidth - pop.offsetWidth - 8, g.left - 12)) + "px";
    const x = (k) => pop.querySelector(`[data-x="${k}"]`), n = (k, d) => { const v = Number(x(k) && x(k).value); return isFinite(v) ? v : d; };
    x("radius").addEventListener("change", () => {
      const r = Math.max(0, Math.round(n("radius", 0)));
      save({ radius: r, radii: Array.isArray(look.radii) ? [r, r, r, r] : null });
    });
    x("each").addEventListener("change", () => { const r = Math.max(0, Math.round(n("radius", 0))); save({ radii: x("each").checked ? [r, r, r, r] : null }); });
    [0, 1, 2, 3].forEach((i) => x("r" + i)?.addEventListener("change", () => save({ radii: [0, 1, 2, 3].map((j) => Math.max(0, Math.round(n("r" + j, 0)))) })));
    const border = () => {
      const w = Math.max(0, Math.min(200, Math.round(n("bw", 0))));
      save({ border: w > 0 ? { width: w, color: x("bc").value, opacity: Math.max(0, Math.min(100, n("bo", 100))), align: x("balign").value } : null });
    };
    ["bw", "bc", "bo", "balign"].forEach((k) => x(k).addEventListener("change", () => {
      if (k !== "bw" && !(n("bw", 0) > 0)) x("bw").value = 2;            // a colour or position picked: the border shows
      border();
    }));
    x("fx").addEventListener("click", (ev) => {
      if (window.TypoStudio) TypoStudio.fxPicker(ev.currentTarget, typeof look.fx === "string" ? look.fx : "", (name) => save({ fx: name || null }), "None");
    });
    if (window.PshLook) PshLook.wireEditor(pop, look, save);     // gradient, corner shape, glow & shadow
  }
  // its ✕, ⚙ again or Esc close it — a click outside never does (what was set in it stays on screen)
  document.addEventListener("keydown", (ev) => {
    if (ev.key !== "Escape" || !V.state.stripPop || document.querySelector(".ts-fxmenu")) return;
    ev.stopPropagation();
    V.state.stripPop = null;
    if (window.TypoStudio) TypoStudio.paint();
  }, true);
  // a strip rule's look changed from its pop-over (row and box strips): kept in the rule itself
  async function patchStripRule(text, changes) {
    const old = text ? stripFor(text) : null;
    if (!old) return;
    await flushTyping();
    const all = styleRules().slice(), r = Object.assign({}, old);
    for (const [k, v] of Object.entries(changes)) { if (v == null) delete r[k]; else r[k] = v; }
    all[all.indexOf(old)] = r;
    dsx().text_style_rules = all;
    await saveBoxes();
  }
  const ruleLook = (r) => ({ radius: r && r.radius != null ? Number(r.radius) : 6, radii: r && r.radii, border: r && r.border, fx: r && r.fx,
    color: r && r.color, corner: r && r.corner, corners: r && r.corners, fill_to: r && r.fill_to, gradient_dir: r && r.gradient_dir,
    gradient_amount: r && r.gradient_amount });
  // rebuilding a strip rule keeps its look (corners, border, layer style, a card look's gradient and corner shape)
  const KEEP_LOOK = ["radius", "radii", "border", "fx", "corner", "corners", "fill_to", "gradient_dir", "gradient_amount"];
  /* a strip rule rebuilt from the bar (its colour changed, say) while the gear pop-over is closed: the
     settings the pop-over holds are not on screen, so they stay as they are instead of going back to
     their defaults */
  function keepClosed(rule, old, q) {
    const inputs = { opacity: "opacity", pad_y: "height", full_width: "fit", width_pct: "width_pct", text_color: "text_color" };
    for (const [k, input] of Object.entries(inputs)) if (!q(input) && old[k] != null) rule[k] = old[k];
    if (old.pad_x != null) rule.pad_x = old.pad_x;
  }
  function wireWordStrip(root, attr, entry, apply) {
    const q = (k) => root.querySelector(`[${attr}="${k}"]`);
    q("bg")?.addEventListener("change", () => apply({ bg: q("bg").value }));
    q("bg_opacity")?.addEventListener("change", () => apply({ bg_opacity: Math.max(0, Math.min(100, Number(q("bg_opacity").value) || 0)) / 100 }));
    q("height")?.addEventListener("change", () => {
      const size = Number(q("height").dataset.size) || 30;
      apply({ bg_pad_y: Math.round((Math.max(0, Number(q("height").value) || 0) - 1.1 * size) / 2) });
    });
    q("width")?.addEventListener("change", () => apply({ bg_pad_x: Math.max(0, Math.round(((Number(q("width").value) || 0) - (Number(q("width").dataset.w) || 0)) / 2)) }));
    q("fit")?.addEventListener("click", () => apply({ bg_pad_x: null }));
    const p = selProps(typeof entry === "function" ? entry() : entry);
    wireStripPop(root, attr, { radius: p.bg_radius != null ? Number(p.bg_radius) : 4, radii: p.bg_radii, border: p.bg_border, fx: p.bg_fx },
      (ch) => apply(Object.fromEntries(Object.entries(ch).map(([k, v]) => ["bg_" + k, v]))));
  }

  /* the text controls the Selection bar and the Row bar share: font, style, size, letter spacing,
     colour, layer style — showing what the text looks like now, changing just that text */
  const swatchUrl = (fx) => `/api/layer-styles/swatch?name=${encodeURIComponent(fx)}&v=${JSON.stringify(((App.state.config.dynamic_settings || {}).layer_style_library || {})[fx] || "").length}`;
  function textControlsHtml(e0, what, lhPart = "") {
    const b = selBase(e0), p = selProps(e0);
    const font = p.font || b.font, size = Math.round(b.size * (Number(p.size) || 100) / 100);
    const bold = !!p.bold || b.bold, italic = !!p.italic || b.italic;
    const style = bold && italic ? "bold italic" : bold ? "bold" : italic ? "italic" : "regular";
    const fonts = (App.state.fonts || []).slice().sort((a, c) => String(a).localeCompare(String(c)));
    if (font && !fonts.some((f) => String(f).toLowerCase() === font.toLowerCase())) fonts.unshift(font);
    const fx = p.fx || "";
    return `<span class="ts-ico" title="Font">𝐓</span>
      <select class="ts-font" data-s="font" title="Font of ${what}">${fonts.map((f) => `<option value="${esc(f)}" ${String(f).toLowerCase() === String(font).toLowerCase() ? "selected" : ""}>${esc(f)}</option>`).join("")}</select>
      <select class="ts-style" data-s="style" title="Style of ${what}">${[["regular", "Regular"], ["bold", "Bold"], ["italic", "Italic"], ["bold italic", "Bold Italic"]]
        .map(([v, l]) => `<option value="${v}" ${v === style ? "selected" : ""}>${l}</option>`).join("")}</select>
      <span class="ts-ico" title="Font size"><small>t</small>T</span>
      <input class="ts-size" type="number" min="4" max="600" data-s="size" value="${size}" title="Size of ${what} (px)"><span class="ts-unit">px</span>
      ${lhPart}
      <span class="ts-ico" title="Letter spacing (tracking, 1/1000 em — like Photoshop)">V<span class="ts-lh">↔</span>A</span>
      <input class="ts-size" type="number" min="-200" max="1000" step="10" data-s="tracking" value="${esc(p.tracking != null ? p.tracking : b.tracking)}" title="Letter spacing of ${what} (1/1000 em)">
      <span class="ts-sep"></span>
      <label class="ts-color" title="Colour of ${what}"><input type="color" data-s="color" value="${esc(p.color || b.color)}"></label>
      <span class="ts-sep"></span>
      <button class="ts-fxbtn" data-s="fx" title="Layer style of ${what}">${fx ? `<img src="${swatchUrl(fx)}" alt="">` : `<span class="ts-fx-none">fx</span>`}<span class="ts-fx-name">${esc(fx || "Same as the text")}</span><span class="ts-fx-caret">▾</span></button>`;
  }
  function wireTextControls(root, first, apply) {
    const q = (k) => root.querySelector(`[data-s="${k}"]`);
    if (!q("font")) return;
    q("font").addEventListener("change", () => { const b = selBase(first()); apply({ font: q("font").value === b.font ? null : q("font").value }); });
    q("style").addEventListener("change", () => {
      const v = q("style").value, b = selBase(first());
      apply({ bold: v.includes("bold") && !b.bold ? true : null, italic: v.includes("italic") && !b.italic ? true : null });
    });
    q("size").addEventListener("change", () => {
      const b = selBase(first()), pct = Math.round(Math.max(4, Number(q("size").value) || b.size) / b.size * 1000) / 10;
      apply({ size: Math.abs(pct - 100) > 0.5 ? pct : null });
    });
    q("tracking").addEventListener("change", () => {
      const b = selBase(first()), v = Math.max(-200, Math.min(1000, Math.round(Number(q("tracking").value) || 0)));
      apply({ tracking: v === b.tracking ? null : v });
    });
    q("color").addEventListener("change", () => { const b = selBase(first()); apply({ color: q("color").value.toLowerCase() === b.color ? null : q("color").value }); });
    q("fx").addEventListener("click", (ev) => {
      if (!window.TypoStudio) return;
      TypoStudio.fxPicker(ev.currentTarget, selProps(first()).fx || "", (name) => apply({ fx: name || null }), "Same as the text");
    });
    q("clear")?.addEventListener("click", () => apply(Object.fromEntries(STYLE_KEYS.map((k) => [k, null]))));
  }

  V.selectionBarHtml = function () {
    const ph = V.state.wordSel || [];
    if (!ph.length) return `<span class="ts-hint">Select text on the page to style it</span>`;
    const e0 = ph[0], p = selProps(e0);
    const label = ph.length === 1 ? `“${e0.phrase.length > 24 ? e0.phrase.slice(0, 24) + "…" : e0.phrase}”` : `${ph.length} pieces of text`;
    const scope = selScope(), styled = Object.keys(p).length > 0;
    return `<span class="ics-chip ts-selchip" title="${esc(ph.map((x) => x.phrase).join(" · "))}">Aa ${esc(label)}</span>
      <span class="ts-sep"></span>
      ${(() => { const lh = selLineHeight(); return textControlsHtml(e0, "the selection", lhHtml("data-s", lh.px, lh.set, lh.what)); })()}
      <span class="ts-sep"></span>
      <button class="ts-al ${p.bg ? "on" : ""}" data-s="bgon" title="A strip behind the selection">▭</button>
      ${wordStripHtml(p, e0, "data-s")}
      <span class="ts-sep"></span>
      <select class="ts-style" data-s="scope" title="Which text changes">
        <option value="row" ${scope === "row" ? "selected" : ""}>Just this text</option>
        <option value="page" ${scope === "page" ? "selected" : ""}>Same words on this page</option>
        <option value="game" ${scope === "game" ? "selected" : ""}>Same words in the game</option>
        <option value="starts" ${scope === "starts" ? "selected" : ""}>Rows starting with…</option></select>
      ${scope === "starts" ? `<select class="ts-style ts-narrow" data-s="startsn" title="How many of the row's first words must be the same (a number counts as any number)">
        ${Array.from({ length: Math.min(12, rowWords(e0.row).length) }, (_, i) => i + 1).map((n) => `<option value="${n}" ${n === startsN(e0.row) ? "selected" : ""}>${n}</option>`).join("")}</select>
        <span class="ts-hint" title="${esc(startsOf(e0.row))}">“${esc(startsOf(e0.row).slice(0, 40))}${startsOf(e0.row).length > 40 ? "…" : ""}”</span>` : ""}
      ${styled ? `<button class="ts-tgt" data-s="clear" title="Back to the text's own look">Clear</button>` : ""}
      <span class="ts-hint">${ED ? "typing · Esc = done · right-click for more" : "Esc = done"}</span>`;
  };
  V.wireSelectionBar = function (root) {
    const q = (k) => root.querySelector(`[data-s="${k}"]`);
    if (!q("scope")) return;
    const e0 = () => (V.state.wordSel || [])[0];
    wireTextControls(root, e0, (changes) => applySelection(changes));
    q("bgon").addEventListener("click", () => {
      const on = !!selProps(e0()).bg;
      applySelection(on ? BG_OFF : { bg: "#1e3a8a", bg_opacity: 0.85 });
    });
    wireWordStrip(root, "data-s", e0, (changes) => applySelection(changes));
    const lh = selLineHeight();
    const keep = async (px) => {                         // the editor stays open on its selection
      if (ED && writeRows(ED)) await TextEdits.save();
      await lh.apply(px);
      if (ED) ED.ta.focus({ preventScroll: true });
    };
    q("lh")?.addEventListener("change", () => keep(Math.max(0, Number(q("lh").value) || 0)));
    q("lhreset")?.addEventListener("click", () => keep(null));
    q("scope").addEventListener("change", () => { V.state.wordScope = q("scope").value; if (window.TypoStudio) TypoStudio.paint(); });
    q("startsn")?.addEventListener("change", () => { V.state.startsN = Number(q("startsn").value) || 5; if (window.TypoStudio) TypoStudio.paint(); });
  };

  /* ----- Row bar: click a line and the top bar is that row's — what it is (normal text / heading /
     subheading), its whole text's look, and the strip behind it (was a pop-up on the page) ----- */
  function rowEntry(e) {
    const text = rowTextOf(e);
    return { src: "row", n: e.row, row: text, text, nth: 0, phrase: text, words: text.split(/\s+/).filter(Boolean), el: e };
  }
  /* just the clicked line of a row wrapped over several lines: its characters as an exact place
     in the row (the same rule a selection of exactly that line would make) */
  function lineEntry(e) {
    const { skel, occurrences } = wt(), row = rowTextOf(e), rowSk = skel(row);
    let cur = 0, hit = null;
    for (const x of rowLines(e)) {
      const sk = skel(AppLive.textRows(x).map((tr) => (tr.runs || []).filter((r) => r.kind !== "icon").map((r) => r.text || "").join(" ")).join(" ")).s;
      if (!sk) continue;
      const at = rowSk.s.indexOf(sk, cur);
      if (at < 0) return null;
      if (x === e) hit = [at, at + sk.length];
      cur = at + sk.length;
    }
    if (!hit) return null;
    const text = row.slice(rowSk.ix[hit[0]], rowSk.ix[hit[1] - 1] + 1);
    const nth = occurrences(rowSk.s, skel(text).s).filter((i) => i < hit[0]).length;
    return { src: "line", n: e.row, row, text, nth, phrase: text, words: text.split(/\s+/).filter(Boolean), el: e };
  }
  // the Row bar works on the clicked line; "Whole row" when the artist picks it (a wrapped row)
  function rowTarget(e) {
    const many = rowLines(e).length > 1;
    const line = many && V.state.rowScope !== "row" ? lineEntry(e) : null;
    return { entry: line || rowEntry(e), line: !!line, many };
  }
  V.rowSelected = () => !!rowElement();
  V.rowBarHtml = function () {
    const e = rowElement();
    if (!e) return `<span class="ts-hint">Click a line on the page</span>`;
    if (rulesTarget(e) === "bingo") return RulesCanvas.rowBarHtml();     // a Bingo row: its alignment, size, colour
    const tg = rowTarget(e), en = tg.entry, text = rowTextOf(e), p = selProps(en);
    const canRole = e.kind === "line" && !!rowKeyOf(e);
    const role = canRole ? rowRoleOf(e) : "";
    const short = en.text.replace(/<([^<>]*?)(?:~\d+(?:\.\d+)?(?:\^[\d.]+,[\d.]+)?|\^[\d.]+,[\d.]+)\s*>/g, "<$1>");
    const what = tg.line ? "this line" : "this row";
    let strip;
    if (tg.line) {                                       // a strip behind just this line's words
      strip = `<button class="ts-al ${p.bg ? "on" : ""}" data-l="bgon" title="A strip behind this line">▭</button>
        ${wordStripHtml(p, en, "data-l")}`;
    } else {                                             // the row's strip (all its lines, the text area wide)
      const s = stripFor(text), lead = text.split(/\s+/).filter(Boolean).slice(0, 2).join(" ");
      const rowH = stripRowH(e), pad = s && s.pad_y != null ? Number(s.pad_y) : 6;
      strip = `<button class="ts-al ${s ? "on" : ""}" data-r="stripon" title="A strip behind the row">▭</button>
      ${s ? `<label class="ts-color" title="Strip colour"><input type="color" data-r="color" value="${esc(s.color || "#1e5aa8")}"></label>
        ${stripGear("row", `<div class="tsp-row"><span class="tsp-l">Opacity</span><input class="ts-size ts-narrow" type="number" min="10" max="100" step="5" data-r="opacity" value="${Math.round((s.opacity == null ? 0.85 : Number(s.opacity)) * 100)}" title="Strip opacity (%)"><span class="ts-unit">%</span></div>
        <div class="tsp-row"><span class="tsp-l">Height</span><input class="ts-size ts-narrow" type="number" min="0" max="${rowH + 160}" data-r="height" value="${Math.max(0, Math.round(rowH + 2 * pad))}" title="Strip height (px)"><span class="ts-unit">px</span></div>
        <div class="tsp-row"><span class="tsp-l">Width</span><input class="ts-size ts-narrow" type="number" min="5" max="100" step="5" data-r="width_pct" value="${Math.round(s.width_pct || 100)}" ${s.full_width === false ? "disabled" : ""} title="Strip width (% of the text area)"><span class="ts-unit">%</span>
          <label class="ts-check" title="Hug the words instead of the text area"><input type="checkbox" data-r="fit" ${s.full_width === false ? "checked" : ""}> fit</label></div>
        <div class="tsp-row"><span class="tsp-l">Text</span><label class="ts-color ${s.text_color ? "" : "ts-off"}" title="Text colour on the strip (⊘ keeps the text's own)"><input type="color" data-r="text_color" value="${esc(s.text_color || "#ffffff")}"></label>
          ${s.text_color ? `<button class="ts-al" data-r="notext" title="Keep the text's own colour">⊘</button>` : ""}</div>
        <div class="tsp-row"><span class="tsp-l">Rows</span><select class="ts-style" data-r="match" title="Which rows get this strip">
          <option value="exact" ${s.match === "exact" ? "selected" : ""}>This row</option>
          <option value="starts" ${s.match !== "exact" ? "selected" : ""}>Rows starting “${esc((s.match !== "exact" ? s.text : lead).slice(0, 18))}”</option></select></div>`, ruleLook(s))}` : ""}
      <button class="ts-al" data-r="stripcopy" title="Copy this row's design: its text's font, size, colour, layer style, its icons' size and its strip (colour, height, corners, border, layer style)">⧉</button><button class="ts-al" data-r="strippaste" ${V.state.stripClip || V.state.rowClip || (window.PshLook && PshLook.clip) ? "" : "disabled"} title="${V.state.rowClip ? `Give this row the copied row's design (${esc(V.state.rowClip.from)})` : window.PshLook && PshLook.clip ? `Put the look of ${esc(PshLook.clip.from)} on this row's strip` : "Copy a row's design (⧉) or a paytable card's look first"}">📋</button>`;
    }
    return `<span class="ics-chip ts-selchip" title="${esc(short)}">▤ ${esc(short.length > 22 ? short.slice(0, 22) + "…" : short)}</span>
      ${tg.many ? `<select class="ts-style" data-r="scope" title="This Excel row is drawn as ${rowLines(e).length} lines: change just the clicked line, or all of them">
        <option value="line" ${tg.line ? "selected" : ""}>This line</option>
        <option value="row" ${tg.line ? "" : "selected"}>Whole row (${rowLines(e).length} lines)</option></select>` : ""}
      ${canRole ? `<span class="ts-sep"></span><span class="ts-lbl">${tg.many ? (tg.line ? "This line is" : "Its row is") : "This row is"}</span><span class="ts-target">${[["", "Normal"], ["heading", "Heading"], ["subheading", "Subheading"]].map(([v, t]) =>
        `<button class="ts-tgt ${role === v ? "on" : ""}" data-r="role" data-v="${v}" title="Draw this Excel row as ${t.toLowerCase()} text">${t}</button>`).join("")}</span>` : ""}
      ${canRole && /^row:\d+$/.test(rowKeyOf(e)) ? `<button class="ts-tgt ${pageBreakOn(e) ? "on" : ""}" data-r="brk" title="${pageBreakOn(e) ? "Back where the page puts it (the automatic Continued flow)" : "Start a new (Continued) page with this row — the rest flows on from it"}">${pageBreakOn(e) ? "⤵ New page ✓" : "⤵ New page"}</button>` : ""}
      <span class="ts-sep"></span>
      ${textControlsHtml(en, what, e.meta && e.meta.row_line ? lhHtml("data-r", Number(e.meta.line_height) || 0, !!e.meta.line_height_set, what) : "")}
      <span class="ts-sep"></span>
      ${strip}
      ${Object.keys(p).length ? `<span class="ts-sep"></span><button class="ts-tgt" data-s="clear" title="The text back to its own look">Clear</button>` : ""}
      ${e.boxId != null ? `<span class="ts-sep"></span><button class="ts-tgt" data-r="tobox" title="This text box's own settings: its font, size, place and width — or put its words back">▣ Text box</button>` : ""}
      <span class="ts-hint">typing here · double-click a word · triple-click a line · Esc = back to its frame</span>`;
  };
  V.wireRowBar = function (root) {
    const e = rowElement();
    if (!e) return;
    if (rulesTarget(e) === "bingo") { RulesCanvas.wireBar(root); return; }
    const q = (k) => root.querySelector(`[data-r="${k}"]`), l = (k) => root.querySelector(`[data-l="${k}"]`);
    const entry = () => rowTarget(rowElement() || e).entry;
    root.querySelectorAll('[data-r="role"]').forEach((b) => b.addEventListener("click", () => setRowRole(e, b.dataset.v, rowTarget(e).line)));
    q("scope")?.addEventListener("change", () => { V.state.rowScope = q("scope").value; if (window.TypoStudio) TypoStudio.paint(); });
    const lhTarget = () => { const x = rowElement() || e; return [{ key: rowKeyOf(x), line: rowTarget(x).line ? x.meta.row_line : null }]; };
    q("tobox")?.addEventListener("click", () => V.selectBox(e.boxId));
    q("lh")?.addEventListener("change", () => setLineHeight(lhTarget(), Math.max(0, Number(q("lh").value) || 0)));
    q("lhreset")?.addEventListener("click", () => setLineHeight(lhTarget(), null));
    wireTextControls(root, entry, (changes) => applySelection(changes, [entry()], "row"));
    // the clicked line's strip: the words' strip (text_styles.bg_of) over exactly its characters
    l("bgon")?.addEventListener("click", () => applySelection(selProps(entry()).bg
      ? BG_OFF : { bg: "#1e5aa8", bg_opacity: 0.85, bg_pad_x: 12, bg_pad_y: 6 }, [entry()], "row"));
    wireWordStrip(root, "data-l", entry(), (changes) => applySelection(changes, [entry()], "row"));
    // the row's strip (all its lines)
    q("stripon")?.addEventListener("click", () => saveRowStrip(root, !!stripFor(rowTextOf(e))));
    ["color", "opacity", "text_color", "width_pct", "fit", "height", "match"].forEach((k) => q(k)?.addEventListener("change", () => saveRowStrip(root, false)));
    q("notext")?.addEventListener("click", () => saveRowStrip(root, false, { text_color: "" }));
    q("stripcopy")?.addEventListener("click", () => {
      const x = rowElement() || e, s = stripFor(rowTextOf(x));
      const c = s ? JSON.parse(JSON.stringify(s)) : null;
      if (c) ["text", "match", "sheet", "scope"].forEach((k) => delete c[k]);
      V.state.stripClip = c;
      // the row's design: its text's look (font, size, colour, layer style…), its icons' size, its strip
      const look = {};
      Object.entries(selProps(rowEntry(x))).forEach(([k, v]) => { if (!/^bg/.test(k)) look[k] = v; });
      const at = Date.now();
      V.state.rowClip = { from: `row ${x.row}`, look, strip: c, icons: rowIconScale(x), at };
      if (c && window.PshLook) PshLook.clip = { from: `the strip of row ${x.row}`, look: PshLook.stripToCard(c), at };
      if (window.TypoStudio) TypoStudio.paint();
      toast(`Row ${x.row}'s design copied${c ? " (with its strip)" : ""} — click another row, then 📋 to paste it.`);
    });
    q("strippaste")?.addEventListener("click", () => pasteRowDesign());
    q("brk")?.addEventListener("click", () => togglePageBreak(rowElement() || e));
    const s0 = stripFor(rowTextOf(e));
    if (s0) wireStripPop(root, "row", ruleLook(s0), (ch) => patchStripRule(rowTextOf(rowElement() || e), ch));
  };
  /* a row that starts a new (Continued) page: page_boxes.page_breaks[sheet] = ["row:12", …] */
  const pageBreakOn = (e) => ((dsx().page_breaks || {})[V.state.sheet || ""] || []).includes(rowKeyOf(e));
  async function togglePageBreak(e) {
    await flushTyping();
    const sheet = V.state.sheet || "", key = rowKeyOf(e), all = Object.assign({}, dsx().page_breaks || {});
    const mine = (all[sheet] || []).filter((k) => k !== key), on = !pageBreakOn(e);
    if (on) mine.push(key);
    if (mine.length) all[sheet] = mine; else delete all[sheet];
    dsx().page_breaks = all;
    await saveBoxes(on ? `Row ${e.row} starts a new page now.` : `Row ${e.row} flows with the page again.`);
  }
  /* a row's icons' size (%): one value for the row (icon_scales[sheet] "TOKEN@row:N#k" copies, else
     the token's own size on the sheet) — null when its icons have none of their own */
  function rowIconScale(e) {
    const sheet = V.state.sheet || "", sc = ((dsx().icon_scales || {})[sheet]) || {}, key = rowKeyOf(e);
    const toks = (rowTextOf(e).match(/<([^<>~]+)/g) || []).map((t) => t.slice(1).trim().toUpperCase());
    const vals = toks.map((t, i) => sc[`${t}@${key}#${toks.slice(0, i).filter((x) => x === t).length}`] ?? sc[t]).filter((v) => v != null);
    return vals.length ? Number(vals[0]) : null;
  }
  /* 📋 on a row: the copied row's design (its text's look, its icons' size, its strip) — or, copied from
     a paytable card / a heading plate, that look on this row's strip */
  async function pasteRowDesign() {
    const e = rowElement(), rc = V.state.rowClip, g = window.PshLook && PshLook.clip;
    if (!e) return;
    // a look copied from a card / plate after the row was copied: the strip takes that look
    if (g && (!rc || (g.at || 0) > (rc.at || 0))) {
      const old = stripFor(rowTextOf(e));
      V.state.stripClip = Object.assign(PshLook.applyToRule(old ? Object.assign({}, old) : { pad_x: 24, pad_y: 6, full_width: false, width_pct: 100 }, g.look), {});
      ["text", "match", "sheet", "scope"].forEach((k) => delete V.state.stripClip[k]);
      await pasteRowStrip();
      return;
    }
    if (!rc) { await pasteRowStrip(); return; }
    await flushTyping();
    if (Object.keys(rc.look).length) await applySelection(Object.assign({}, rc.look), [rowEntry(e)], "row");
    if (rc.icons != null) {                          // its icons the copied row's size (each copy in this row)
      const sheet = V.state.sheet || "", key = rowKeyOf(e), ds = dsx(), all = Object.assign({}, ds.icon_scales || {});
      const mine = Object.assign({}, all[sheet] || {}), seen = {};
      (rowTextOf(e).match(/<([^<>~]+)/g) || []).forEach((t) => {
        const k = t.slice(1).trim().toUpperCase(), n = seen[k] = (seen[k] ?? -1) + 1;
        mine[`${k}@${key}#${n}`] = rc.icons;
      });
      all[sheet] = mine;
      ds.icon_scales = all;
    }
    if (rc.strip) { V.state.stripClip = rc.strip; await pasteRowStrip(); }
    else { App.refreshUI(); if (App.flushConfig) await App.flushConfig(); await V.refreshPreview.now(true); if (window.TypoStudio) TypoStudio.paint(); }
    toast(`This row has ${rc.from}'s design now.`);
  }
  /* the copied strip (⧉) behind this row: the same look, this row's own rule (replaces its strip) */
  async function pasteRowStrip() {
    const e = rowElement(), clip = V.state.stripClip;
    if (!e || !clip) return;
    await flushTyping();
    const text = rowTextOf(e), old = stripFor(text), sheet = V.state.sheet || "";
    const rule = Object.assign(JSON.parse(JSON.stringify(clip)), { kind: "strip", match: "exact", text: text.replace(/\s+/g, " ").trim(), scope: "page", sheet });
    const ds = (App.state.config.dynamic_settings = App.state.config.dynamic_settings || {});
    const all = styleRules().slice(), i = old && old.match === "exact" ? all.indexOf(old) : -1;
    if (i >= 0) all[i] = rule; else all.push(rule);
    ds.text_style_rules = all;
    App.refreshUI();
    if (App.flushConfig) await App.flushConfig();
    await V.refreshPreview.now(true);
    if (window.TypoStudio) TypoStudio.paint();
    toast("Strip pasted behind this row.");
  }
  /* the row's strip rule from the Row bar (a "strip" rule, text_styles.strip_for): on / off / changed */
  async function saveRowStrip(root, remove, extra) {
    const e = rowElement();
    if (!e) return;
    await flushTyping();
    const text = rowTextOf(e), old = stripFor(text), sheet = V.state.sheet || "";
    const q = (k) => root.querySelector(`[data-r="${k}"]`);
    const how = q("match") ? q("match").value : (old && old.match) || "exact";
    const rowH = stripRowH(e), height = q("height") ? Number(q("height").value) : rowH + 12;
    const rule = { kind: "strip", match: how,
      text: how === "exact" ? text.replace(/\s+/g, " ").trim() : (old && old.match !== "exact" ? old.text : text.split(/\s+/).filter(Boolean).slice(0, 2).join(" ")),
      color: q("color") ? q("color").value : "#1e5aa8", opacity: q("opacity") ? Math.max(0.1, Math.min(1, Number(q("opacity").value) / 100)) : 0.85,
      pad_x: 24, pad_y: Math.round((Math.max(0, height) - rowH) / 2), full_width: q("fit") ? !q("fit").checked : false,
      width_pct: q("width_pct") ? Math.max(5, Math.min(100, Number(q("width_pct").value) || 100)) : 100, radius: 6,
      text_color: old && old.text_color && q("text_color") ? q("text_color").value : "", scope: "page", sheet };
    if (q("text_color") && old && !old.text_color && q("text_color").value.toLowerCase() !== "#ffffff") rule.text_color = q("text_color").value;
    if (old) keepClosed(rule, old, q);
    for (const k of KEEP_LOOK) if (old && old[k] != null) rule[k] = old[k];
    Object.assign(rule, extra || {});
    const ds = (App.state.config.dynamic_settings = App.state.config.dynamic_settings || {});
    const all = styleRules().slice(), i = old ? all.indexOf(old) : -1;
    if (remove) { if (i >= 0) all.splice(i, 1); } else if (i >= 0) all[i] = rule; else all.push(rule);
    ds.text_style_rules = all;
    App.refreshUI();
    if (App.flushConfig) await App.flushConfig();
    await V.refreshPreview.now(true);
    if (window.TypoStudio) TypoStudio.paint();
  }

  // an exact rule for skeleton characters [s0, s1) of `rowText` (no style yet), or null when empty
  function partRule(rowText, s0, s1, sheet) {
    if (s1 <= s0) return null;
    const { skel, occurrences } = wt(), sk = skel(rowText);
    const text = rowText.slice(sk.ix[s0], sk.ix[s1 - 1] + 1);
    const nth = occurrences(sk.s, skel(text).s).filter((i) => i < s0).length;
    return { kind: "word", scope: "row", sheet, row_text: rowText, text, nth, whole_word: false };
  }
  /* change the selection: `changes` = {rule field: value, or null to take it away} */
  function changeRules(all, entries, changes, sheet, scope) {
    const set = (r) => {
      for (const [k, v] of Object.entries(changes)) { if (v == null || v === "" || v === false) delete r[k]; else r[k] = v; }
    };
    for (const en of entries) {
      if (scope === "row") {
        const here = rangeOf(en.row, en.text, en.nth);
        if (!here) continue;
        let mine = null;
        const cleared = Object.keys(changes).filter((k) => changes[k] == null || changes[k] === "" || changes[k] === false);
        for (const r of all.slice()) {
          if (!isExact(r) || !sameText(r.row_text, en.row) || r.sheet !== sheet) continue;
          const rr = rangeOf(en.row, r.text, Number(r.nth));
          if (!rr) continue;
          if (rr[0] === here[0] && rr[1] === here[1]) mine = r;
          // a change to the whole selection replaces that property inside it (like Photoshop)
          else if (rr[0] >= here[0] && rr[1] <= here[1]) for (const k of Object.keys(changes)) delete r[k];
          // taking a property away from text inside a bigger styled phrase: the phrase keeps it
          // before and after the selection only (split, like Photoshop)
          else if (rr[0] <= here[0] && rr[1] >= here[1]) {
            const keys = cleared.filter((k) => r[k] != null && r[k] !== "" && r[k] !== false);
            if (!keys.length) continue;
            for (const [s0, s1] of [[rr[0], here[0]], [here[1], rr[1]]]) {
              const part = partRule(en.row, s0, s1, sheet);
              if (part) { for (const k of keys) part[k] = r[k]; all.push(part); }
            }
            for (const k of keys) delete r[k];
          }
        }
        if (!mine) { mine = { kind: "word", scope: "row", sheet, row_text: en.row, text: en.text, nth: en.nth, whole_word: false }; all.push(mine); }
        set(mine);
      } else if (scope === "starts") {
        const starts = startsOf(en.row), whole = wholeRow(en);
        let mine = all.find((r) => r.kind === "word" && r.scope === "starts" && sameText(r.starts, starts)
          && (whole ? !!r.whole_row : !r.whole_row && sameText(r.text, en.phrase)));
        if (!mine) { mine = { kind: "word", scope: "starts", starts, text: en.phrase, whole_word: false }; if (whole) mine.whole_row = true; all.push(mine); }
        set(mine);
      } else {
        let mine = all.find((r) => r.kind === "word" && !isExact(r) && sameText(r.text, en.phrase) && (r.scope || "game") === scope
          && (scope === "game" || r.sheet === sheet));
        if (!mine) { mine = { kind: "word", text: en.phrase, whole_word: true, scope }; if (scope !== "game") mine.sheet = sheet; all.push(mine); }
        set(mine);
      }
    }
    // rules with nothing left to them go
    return all.filter((r) => r.kind !== "word" || STYLE_KEYS.some((k) => r[k] != null && r[k] !== "" && r[k] !== false));
  }
  async function applySelection(changes, forEntries, forScope) {
    const entries = forEntries || V.state.wordSel || [];
    if (!entries.length) return;
    const t = TS || typoTarget(), sheet = t.sheet(), scope = forScope || selScope();
    const rowBar = !!forEntries;                              // the Row bar: the whole row, no selection
    // a style is for the text as it reads now: what was typed is saved first (its row's text)
    if (ED && writeRows(ED)) await TextEdits.save();
    const ds = (App.state.config.dynamic_settings = App.state.config.dynamic_settings || {});
    ds.text_style_rules = changeRules(styleRules().slice(), entries, changes, sheet, scope);
    App.refreshUI();
    if (App.flushConfig) await App.flushConfig();
    if (rowBar || (!ED && !TS)) {
      await V.refreshPreview.now(true);
    } else if (ED) {
      await V.refreshPreview.now(true);                     // the editor stays open, the selection too
      if (ED) ED.ta.focus({ preventScroll: true });
    } else if (TS) {
      exitTextMode(true);
      await t.refresh();
      enterTextMode(null, null, t);                         // the same words picked again, drawn with their new look
      V.state.wordSel = entries;
      reselect(entries);
    }
    if (window.TypoStudio) TypoStudio.paint();
  }
  V.applySelection = applySelection;

  function reselect(ph) {
    if (!ph || !ph.length) return;
    const p = ph[0];
    const lines = [...document.querySelectorAll(".tsel-line")].filter((l) => sameText(l.dataset.row, p.row));
    for (const l of lines) {
      const ws = [...l.querySelectorAll(".tsel-w")];
      for (let i = 0; i + p.words.length <= ws.length; i++) {
        if (p.words.every((w, j) => ws[i + j].textContent === w)) {
          const rg = document.createRange();
          rg.setStartBefore(ws[i]);
          rg.setEndAfter(ws[i + p.words.length - 1]);
          const sel = window.getSelection();
          sel.removeAllRanges();
          sel.addRange(rg);
          return;
        }
      }
    }
  }

  /* a word is picked when the selection covers some of it — a selection that only ends right before it
     (or starts right after it) doesn't (Chrome's containsNode(…, true) counts that next word too) */
  function wordPicked(sel, w) {
    const parent = w.parentNode, idx = Array.prototype.indexOf.call(parent.childNodes, w);
    for (let i = 0; i < sel.rangeCount; i++) {
      const r = sel.getRangeAt(i);
      if (r.comparePoint(parent, idx) === 1 || r.comparePoint(parent, idx + 1) === -1) continue;   // all after / before it
      if (r.endContainer === parent && r.endOffset === idx) continue;                             // ends at its start
      if (r.startContainer === parent && r.startOffset === idx + 1) continue;                     // starts at its end
      if (r.collapsed) continue;
      return true;
    }
    return false;
  }

  /* the selection, line by line: [{line, phrase}] — whole words (a part of a word takes the word) */
  function selectedPhrases() {
    const sel = window.getSelection();
    if (!sel || sel.isCollapsed) return [];
    const out = [];
    document.querySelectorAll(".tsel-line").forEach((lineEl) => {
      const words = [...lineEl.querySelectorAll(".tsel-w")].filter((w) => wordPicked(sel, w));
      if (!words.length) return;
      // contiguous runs of picked words in this line
      let group = [];
      const flush = () => {
        if (group.length) out.push({ n: Number(lineEl.dataset.n), row: lineEl.dataset.row || "", first: Number(group[0].dataset.i),
                                     words: group.map((g) => g.textContent), phrase: group.map((g) => g.textContent).join(" ") });
        group = [];
      };
      let last = -2;
      words.forEach((w) => { const i = Number(w.dataset.i); if (i !== last + 1) flush(); group.push(w); last = i; });
      flush();
    });
    return out;
  }

  function openMenu(ev) {
    document.querySelectorAll(".tsel-menu, .tsel-pop").forEach((n) => n.remove());
    const phrases = selectedPhrases();
    const host = TS.host, hr = host.getBoundingClientRect();
    const menu = document.createElement("div");
    menu.className = "tsel-menu";
    const rules = styleRules(), sheet = TS.sheet();
    const styled = phrases.some((p) => rules.some((r) => r.kind === "word" && (r.scope === "row"
      ? sameText(r.row_text, p.row) && p.words.some((w) => sameText(w, r.text)) : sameText(r.text, p.phrase))));
    // the Excel rows the selection is in (body text): line breaks / joins are kept per row
    const rowsOf = rowsInSelection(phrases);
    const edited = rowsOf.some((r) => TextEdits.get(sheet, r.key));
    const textItems = rowsOf.length ? `<div class="tsel-msep"></div>
         ${rowsOf.length === 1 && phrases[0] ? `<button data-m="break">Start a new line here</button>` : ""}
         ${rowsOf.length > 1 || /\n/.test(rowsOf[0].text) ? `<button data-m="join">Join ${rowsOf.length > 1 ? "these lines" : "the lines of this text"}</button>` : ""}
         <button data-m="edit">Edit text…</button>
         ${edited ? `<button data-m="excel">Back to the Excel text</button>` : ""}` : "";
    const viaBar = host === el("typoVisHost");          // Typography: words are styled from the top bar
    menu.innerHTML = phrases.length
      ? `${viaBar ? `<div class="tsel-mnote">Style the selection from the top bar</div>`
          : `<button data-m="style">Style selection…</button>${styled ? `<button data-m="clear">Remove styles from selection</button>` : ""}`}
         <button data-m="copy">Copy</button>${textItems}<div class="tsel-msep"></div><button data-m="done">Finish (Esc)</button>`
      : `<div class="tsel-mnote">Select some text first</div><button data-m="done">Finish (Esc)</button>`;
    host.appendChild(menu);
    Object.assign(menu.style, { left: Math.min(hr.width - menu.offsetWidth - 6, ev.clientX - hr.left) + "px",
                                top: Math.min(hr.height - menu.offsetHeight - 6, ev.clientY - hr.top) + "px" });
    ["mousedown", "pointerdown", "click"].forEach((t) => menu.addEventListener(t, (e2) => e2.stopPropagation()));
    menu.querySelectorAll("[data-m]").forEach((b) => b.addEventListener("click", () => {
      const m = b.dataset.m;
      menu.remove();
      if (m === "style") openStylePop(phrases, ev);
      else if (m === "clear") saveRules((all) => all.filter((r) => !(r.kind === "word" && phrases.some((p) =>
        (r.scope === "row" ? (sameText(r.row_text, p.row) && p.words.some((w) => sameText(w, r.text))) : sameText(r.text, p.phrase))
        && ((r.scope || "game") === "game" || r.sheet === sheet)))));
      else if (m === "copy") { try { navigator.clipboard.writeText(phrases.map((p) => p.phrase).join("\n")); } catch (_) { /* no clipboard */ } }
      else if (m === "done") exitTextMode();
      else editText(m, rowsOf, phrases, sheet);
    }));
  }

  /* [{key: "row:12", row, text}] — the body rows (Excel rows) the selection touches, in order */
  function rowsInSelection(phrases) {
    const lines = V.state.textLines || [];
    const seen = new Map();
    for (const p of phrases) {
      const ln = lines[p.n];
      if (!ln || ln.heading) continue;
      const row = rowOf(ln.e);
      if (row == null) continue;
      if (!seen.has(row)) seen.set(row, { key: typeof row === "string" ? row.replace(/^cell:/, "") : "row:" + row, row, text: String(ln.e.rowText || ln.e.text || "") });
    }
    return [...seen.values()].sort((a, b) => (typeof a.row === "number" && typeof b.row === "number" ? a.row - b.row : 0));
  }
  function rowOf(e) {
    if (!e) return null;
    if (e.cell) return "cell:" + e.cell;                         // a Game / Bingo Rules cell (text_edits "B7")
    if (e.boxId != null) return "box:" + e.boxId;               // a text box: its own text (text_edits "box:<id>")
    if (e.row != null && isFinite(Number(e.row))) return Number(e.row);
    const m = String(e.id || "").match(/^line\.(\d+)\./);
    return m ? Number(m[1]) : null;
  }

  /* line breaks / joins / retyping, kept per Excel row (TextEdits; never written to the Excel) */
  async function editText(m, rowsOf, phrases, sheet) {
    const refresh = (TS || typoTarget()).refresh;
    const first = rowsOf[0];
    if (!first) return;
    if (m === "break") {
      // the first selected word, counted from the start of its row (across its wrapped lines)
      const p = phrases[0], lines = V.state.textLines || [];
      let before = 0;
      document.querySelectorAll(".tsel-line").forEach((lineEl) => {
        const n = Number(lineEl.dataset.n);
        if (n < p.n && lines[n] && !lines[n].heading && rowOf(lines[n].e) === first.row) before += lineEl.querySelectorAll(".tsel-w").length;
      });
      const next = TextEdits.breakBefore(first.text, before + p.first);
      if (next == null) { toast("That is already the start of the line."); return; }
      TextEdits.put(sheet, first.key, first.text, next);
    } else if (m === "join") {
      if (rowsOf.length === 1) TextEdits.put(sheet, first.key, first.text, first.text.replace(/\s*\n\s*/g, " "));
      else {
        const joined = rowsOf.map((r) => r.text.replace(/\s*\n\s*/g, " ").trim()).join(" ");
        TextEdits.put(sheet, first.key, first.text, joined, { joined: rowsOf.slice(1).map((r) => r.key) });
        rowsOf.slice(1).forEach((r) => TextEdits.put(sheet, r.key, r.text, ""));
      }
    } else if (m === "edit") {
      const next = await TextEdits.editor("Edit the text", first.text);
      if (next == null) return;
      TextEdits.put(sheet, first.key, first.text, next.replace(/\r/g, ""));
    } else if (m === "excel") {
      TextEdits.clear(sheet, rowsOf.map((r) => r.key));
    } else return;
    exitTextMode();
    await TextEdits.save();
    await refresh();
  }

  /* ---------------- live text editing on the page: double-click a paragraph ----------------
     The page itself is the editor (like InDesign): a caret and selection are drawn over the canvas,
     the keys go to a hidden textarea, and every change lays the page out again with the typed text
     (AppLive.draftText — nothing saved until Done / Esc / a click away). Enter starts a new line,
     Backspace at the start of a line joins it onto the line above — also when the two lines are
     different Excel rows. Each Excel row keeps its own edit (TextEdits, never written to the Excel);
     a row joined into the one above is hidden. starts[] follows where each row begins while you
     type, so Ctrl+Z undoes a join exactly. */
  let ED = null;

  function hiddenRow(sheet, n) {
    const ed = TextEdits.get(sheet, "row:" + n);
    return !!(ed && ed.to === "");
  }

  /* the clicked body row and its neighbours on this page that read as one paragraph: body rows of
     the same row role with nothing else (a heading, a table…) drawn between them — blank Excel rows
     don't count, the page draws the rows one after another anyway; rows already joined away come
     along (they're hidden). [{n, key, live, from, shown, els}] in Excel order */
  function paragraphRows(e0, sheet) {
    if (e0 && e0.cell) return cellRows(e0, sheet);
    if (e0 && e0.boxId != null) {                                  // a text box: its own paragraph
      const key = "box:" + e0.boxId, ed = TextEdits.get(sheet, key);
      const els = (AppLive.state.elements || []).filter((e) => e.kind === "line" && e.boxId === e0.boxId).sort((a, b) => a.y - b.y);
      const shown = String(els[0].rowText || els[0].text || "").replace(/<([^<>]*?)(?:~\d+(?:\.\d+)?(?:\^[\d.]+,[\d.]+)?|\^[\d.]+,[\d.]+)\s*>/g, "<$1>");
      return [{ n: key, key, live: true, els, shown, from: ed ? String(ed.from || "") : shown }];
    }
    const byRow = new Map(), others = [];
    for (const e of AppLive.state.elements || []) {
      if (e.boxId != null) continue;                                // text boxes are not the page's rows
      const n = e.kind === "line" ? rowOf(e) : null;
      if (n != null) {
        if (!byRow.has(n)) byRow.set(n, []);
        byRow.get(n).push(e);
      } else if (e.kind !== "icon") others.push(e);
    }
    const n0 = rowOf(e0);
    if (n0 == null || !byRow.has(n0)) return null;
    const role = rowRoleOf(e0);
    const sameRole = (n) => rowRoleOf(byRow.get(n)[0]) === role;
    const bottom = (n) => Math.max(...byRow.get(n).map((e) => e.y + e.h)), top = (n) => Math.min(...byRow.get(n).map((e) => e.y));
    const near = (a, b) => !others.some((o) => o.y + o.h / 2 > bottom(a) - 1 && o.y + o.h / 2 < top(b) + 1);
    const live = [...byRow.keys()].sort((a, b) => a - b);
    let i0 = live.indexOf(n0), i1 = i0;
    while (i0 > 0 && near(live[i0 - 1], live[i0]) && sameRole(live[i0 - 1])) i0--;
    while (i1 < live.length - 1 && near(live[i1], live[i1 + 1]) && sameRole(live[i1 + 1])) i1++;
    const keep = new Set(live.slice(i0, i1 + 1));
    // hidden rows: between two of its rows, or joined into one of them earlier
    for (let k = live[i0] + 1; k < live[i1]; k++) if (hiddenRow(sheet, k)) keep.add(k);
    for (const n of live.slice(i0, i1 + 1)) {
      const ed = TextEdits.get(sheet, "row:" + n);
      for (const j of (ed && ed.joined) || []) { const m = /^row:(\d+)$/.exec(j); if (m && hiddenRow(sheet, +m[1])) keep.add(+m[1]); }
    }
    return [...keep].sort((a, b) => a - b).map((k) => {
      const els = byRow.get(k), ed = TextEdits.get(sheet, "row:" + k);
      if (!els) return { n: k, key: "row:" + k, live: false, els: [], shown: "", from: String((ed && ed.from) || "") };
      // icon size tags (<WILD~140>) are added back by the icon sizes, an edit never holds them
      const shown = String(els[0].rowText || els[0].text || "").replace(/<([^<>]*?)(?:~\d+(?:\.\d+)?(?:\^[\d.]+,[\d.]+)?|\^[\d.]+,[\d.]+)\s*>/g, "<$1>");
      return { n: k, key: "row:" + k, live: true, els, shown, from: ed ? String(ed.from || "") : shown };
    });
  }

  /* a Game / Bingo Rules line's paragraph, one entry per Excel cell (text_edits key "B7"): the Game Rules
     text above the separator, or the legal text under it; a Bingo cell on its own (the page is a grid).
     Cells joined into one above (to: "") come along, hidden. */
  function cellRows(e0, sheet) {
    const part = rulesTarget(e0), byCell = new Map();
    for (const e of AppLive.state.elements || []) {
      if (e.kind !== "line" || !e.cell || rulesTarget(e) !== part || (part === "bingo" && e.cell !== e0.cell)) continue;
      if (!byCell.has(e.cell)) byCell.set(e.cell, []);
      byCell.get(e.cell).push(e);
    }
    const order = [...byCell.keys()].sort((a, b) => {
      const ea = byCell.get(a)[0], eb = byCell.get(b)[0];
      return ea.y - eb.y || ea.x - eb.x;
    });
    const out = [];
    for (const c of order) {
      const els = byCell.get(c), ed = TextEdits.get(sheet, c);
      const shown = String(els[0].rowText || els[0].text || "").replace(/<([^<>]*?)(?:~\d+(?:\.\d+)?(?:\^[\d.]+,[\d.]+)?|\^[\d.]+,[\d.]+)\s*>/g, "<$1>");
      out.push({ n: "cell:" + c, key: c, live: true, els, shown, from: ed ? String(ed.from || "") : shown });
      for (const j of (ed && ed.joined) || []) {
        const je = TextEdits.get(sheet, j);
        if (je && je.to === "" && !byCell.has(j)) out.push({ n: "cell:" + j, key: j, live: false, els: [], shown: "", from: String(je.from || "") });
      }
    }
    return out;
  }

  const ox = (e) => Number(e.ov && e.ov.x) || 0, oy = (e) => Number(e.ov && e.ov.y) || 0;
  // text without spaces or icon size tags: what must survive an edit untouched
  const inked = (s) => String(s || "").replace(/<([^<>]*?)(?:~\d+(?:\.\d+)?(?:\^[\d.]+,[\d.]+)?|\^[\d.]+,[\d.]+)\s*>/g, "<$1>").replace(/\s+/g, "");
  const TOKEN_AT = /<[^<>\n]+>/g;
  // a row's text without spaces at its ends — its empty lines (Enter pressed twice) stay
  const edgeTrim = (s) => String(s || "").replace(/^[ \t]+|[ \t]+$/g, "");

  function openEditor(e0, clientX, clientY) {
    closeEditor(false);
    exitTextMode();
    if (window.IconStudio) IconStudio.deselect();          // typing now, not sizing an icon
    const t = typoTarget(), sheet = t.sheet();
    if (!t.host || !t.canvas || !AppLive.state.data) return false;
    const rows = paragraphRows(e0, sheet);
    if (!rows || !rows.length) return false;
    const live = rows.filter((r) => r.live);
    // never edit a row whose whole text isn't known: every line drawn for it must be part of it
    // (a Game Rules cell: its <dynamic text> placeholders are not drawn, its other tokens may not be either)
    const untok = (t) => inked(t).replace(/<[^<>]*>/g, "");
    const bad = live.find((r) => (String(r.n).startsWith("cell:")
      ? !untok(r.shown).includes(untok(r.els.map((e) => e.text).join("")))
      : !inked(r.shown).includes(inked(r.els.map((e) => e.text).join("")))));
    if (bad) {
      toast(`The text of Excel ${String(bad.n).startsWith("cell:") ? "cell " + bad.n.slice(5) : "row " + bad.n} could not be read in full, so it can't be edited here — nothing was changed.`);
      return false;
    }
    // the text: one line per Excel row (its own line breaks kept); starts[] = where each row begins
    let text = "";
    const starts = live.map((r, i) => { if (i) text += "\n"; const s = { n: r.n, pos: text.length }; text += r.shown; return s; });

    const node = document.createElement("div");
    node.className = "tedit";
    // no bar of its own: select text and the top bar styles it; Esc / a click away = done;
    // right-click = Back to the Excel text, Cancel… (like a text layer in Photoshop)
    node.innerHTML = `<div class="tedit-box"></div><div class="tedit-sels"></div><div class="tedit-caret"></div>
      <textarea class="tedit-input" spellcheck="false" autocomplete="off" aria-label="Edit the paragraph"></textarea>`;
    const ta = node.querySelector("textarea");
    ta.value = text;
    t.host.appendChild(node);
    ED = { t, sheet, rows, node, ta, starts, pre: null, hist: [], hi: -1, map: null, seq: 0, timer: 0,
           typed: false, goalX: null, drag: false, click: [clientX, clientY] };
    snapshot();
    ED.map = buildMap();

    node.addEventListener("mousedown", onEditorMouse);
    node.addEventListener("dblclick", (ev) => {
      ev.stopPropagation();
      const i = pointIndex(ev);
      if (i == null) return;
      const [a, b] = wordAround(ED.ta.value, i);
      setSel(a, b);
    });
    ["click", "pointerdown"].forEach((ty) => node.addEventListener(ty, (ev) => ev.stopPropagation()));
    node.addEventListener("contextmenu", (ev) => { ev.preventDefault(); ev.stopPropagation(); editorMenu(ev); });
    // a click away is "done" — but not on the top bar styling the selection (or its menus)
    ED.outside = (ev) => {
      if (!ED || ED.node.contains(ev.target)) return;
      if (ev.target.closest && ev.target.closest("#typoStrip, .ts-fxmenu, .tedit-menu, .tbs-pop2")) return;   // the swatch list too
      closeEditor(true);
    };
    ED.move = (ev) => { if (ED && ED.drag) { const i = pointIndex(ev, true); if (i != null) setSel(ED.dragFrom, i); } };
    ED.up = () => { if (ED) ED.drag = false; };
    ED.selch = () => { if (ED && document.activeElement === ED.ta) drawCaret(); };
    document.addEventListener("mousedown", ED.outside, true);
    document.addEventListener("mousemove", ED.move);
    document.addEventListener("mouseup", ED.up);
    document.addEventListener("selectionchange", ED.selch);
    ta.addEventListener("beforeinput", () => { if (ED) ED.pre = { v: ta.value, a: ta.selectionStart, b: ta.selectionEnd }; });
    ta.addEventListener("input", onEditorInput);
    ta.addEventListener("keydown", onEditorKey);
    ta.addEventListener("blur", () => { if (ED) ED.node.classList.add("idle"); });
    ta.addEventListener("focus", () => { if (ED) ED.node.classList.remove("idle"); });

    // the caret where the double-click was (else at the end of that row)
    let at = pointIndex({ clientX, clientY });
    if (at == null) {
      const r0 = starts.findIndex((s) => s.n === rowOf(e0));
      at = r0 >= 0 && r0 + 1 < starts.length ? starts[r0 + 1].pos - 1 : text.length;
    }
    ta.focus({ preventScroll: true });
    setSel(at, at);
    return true;
  }

  /* where every caret position of the text is drawn on the page, read from the page as it is laid
     out now: pts[i] = {x, ln} (page px) for the gap before character i; lines in reading order */
  function buildMap() {
    const ed = ED, v = ed.ta.value;
    const pts = new Array(v.length + 1).fill(null), strong = new Array(v.length + 1).fill(false), lines = [];
    const put = (i, x, ln, isStrong) => {
      if (i < 0 || i > v.length || (pts[i] && (strong[i] || !isStrong))) return;
      pts[i] = { x, ln };
      strong[i] = isStrong;
    };
    const all = (AppLive.state.elements || []).filter((e) => e.kind === "line");
    ed.starts.forEach((s, si) => {
      const seg = v.slice(s.pos, si + 1 < ed.starts.length ? ed.starts[si + 1].pos - 1 : v.length);
      const els = all.filter((e) => rowOf(e) === s.n).sort((a, b) => (a.y + oy(a)) - (b.y + oy(b)));
      let j = 0;                                                       // where in the row's text we are
      // its empty lines (Enter pressed twice): the layout leaves a blank line for each; the caret sits
      // there at the line's start, x as the paragraph aligns it
      const empties = [];
      seg.split("\n").reduce((off, l) => { if (!l.trim()) empties.push(off); return off + l.length + 1; }, 0);
      let k = 0;
      const blank = (e, b) => {
        const al = e.align || "center", x = (al === "right" ? e.x + e.w : al === "center" ? e.x + e.w / 2 : e.x) + ox(e);
        const ln = { top: Number(b.top) + oy(e), h: Number(b.h) || 1, l: x, r: x, n: lines.length, el: e, blank: true };
        lines.push(ln);
        if (k < empties.length) { put(s.pos + empties[k], x, ln, true); j = Math.max(j, empties[k] + 1); }
        k++;
      };
      for (const e of els) {
        for (const b of (e.meta && e.meta.blank_above) || []) blank(e, b);
        for (const tr of AppLive.textRows(e)) {
          const ln = { top: tr.top + oy(e), h: tr.h, l: Infinity, r: -Infinity, n: lines.length, el: e };
          lines.push(ln);
          measureCtx.font = `${e.size}px ${e.family}, Arial, sans-serif`;
          for (const run of tr.runs || []) {
            const rx = tr.x + ox(e) + (Number(run.x) || 0), rw = Number(run.w) || 0;
            ln.l = Math.min(ln.l, rx);
            ln.r = Math.max(ln.r, rx + rw);
            if (run.kind === "icon") {                                  // an icon is its <TOKEN>, as a whole
              const a = seg.indexOf("<", j), b = a >= 0 ? seg.indexOf(">", a) : -1;
              if (b < 0) continue;
              put(s.pos + a, rx, ln, true);
              put(s.pos + b + 1, rx + rw, ln, false);
              j = b + 1;
              continue;
            }
            const txt = String(run.text || "");
            if (!txt) continue;
            const full = measureCtx.measureText(txt).width || 1, kx = rw ? rw / full : 1;
            for (let c = 0; c < txt.length; c++) {
              const x0 = rx + measureCtx.measureText(txt.slice(0, c)).width * kx;
              const x1 = rx + measureCtx.measureText(txt.slice(0, c + 1)).width * kx;
              if (/\s/.test(txt[c])) {
                if (/\s/.test(seg[j] || "")) { put(s.pos + j, x0, ln, true); put(s.pos + j + 1, x1, ln, false); j++; }
                continue;
              }
              let k = j, skipped = 0;                                   // skip what isn't drawn (a space at a wrap,
              while (k < seg.length && seg[k] !== txt[c] && skipped < 12) {     // a <dynamic text> the page leaves out)
                const te = seg[k] === "<" && txt[c] !== "<" ? seg.indexOf(">", k) : -1;
                if (te > k) { k = te + 1; continue; }
                k++;
                skipped++;
              }
              if (seg[k] !== txt[c]) continue;
              j = k;
              put(s.pos + j, x0, ln, true);
              put(s.pos + j + 1, x1, ln, false);
              j++;
            }
          }
          if (!isFinite(ln.l)) { ln.l = tr.x + ox(e); ln.r = ln.l; }
        }
        for (const b of (e.meta && e.meta.blank_below) || []) blank(e, b);
      }
    });
    // a position with no place of its own (a space where a line wrapped, inside a <TOKEN>) sits on the one before
    let last = null;
    for (let i = 0; i <= v.length; i++) { if (pts[i]) last = pts[i]; else pts[i] = last; }
    const first = pts.find(Boolean) || null;
    for (let i = 0; i <= v.length && !pts[i]; i++) pts[i] = first;
    let box = null;
    if (lines.length) {
      const l = Math.min(...lines.map((x) => x.l)), r = Math.max(...lines.map((x) => x.r));
      const t0 = Math.min(...lines.map((x) => x.top)), b0 = Math.max(...lines.map((x) => x.top + x.h));
      box = { x: l, y: t0, w: Math.max(4, r - l), h: b0 - t0 };
    }
    return { pts, lines, box };
  }

  function scaleK() {
    return ED.t.canvas.getBoundingClientRect().width / AppLive.state.data.canvas_w;
  }

  /* the caret position nearest a mouse point; null when it is away from the paragraph (unless `loose`) */
  function pointIndex(ev, loose) {
    if (!ED || !ED.map || !ED.map.lines.length) return null;
    const cr = ED.t.canvas.getBoundingClientRect(), k = scaleK();
    const px = (ev.clientX - cr.left) / k, py = (ev.clientY - cr.top) / k;
    const b = ED.map.box, pad = 14 / k;
    if (!loose && (!b || px < b.x - pad || px > b.x + b.w + pad || py < b.y - pad || py > b.y + b.h + pad)) return null;
    const ln = ED.map.lines.find((x) => py >= x.top && py <= x.top + x.h)
      || ED.map.lines.reduce((best, x) => (Math.abs(x.top + x.h / 2 - py) < Math.abs(best.top + best.h / 2 - py) ? x : best));
    return nearestOn(ln, px);
  }
  function nearestOn(ln, x) {
    let best = null, d = Infinity;
    ED.map.pts.forEach((p, i) => { if (p && p.ln === ln && Math.abs(p.x - x) < d) { d = Math.abs(p.x - x); best = i; } });
    return best;
  }
  function lineEdge(ln, end) {
    let at = null;
    ED.map.pts.forEach((p, i) => { if (p && p.ln === ln && (at == null || end)) at = i; });
    return at;
  }
  function wordAround(v, i) {
    TOKEN_AT.lastIndex = 0;
    let m;
    while ((m = TOKEN_AT.exec(v))) if (i >= m.index && i < m.index + m[0].length) return [m.index, m.index + m[0].length];
    let a = i, b = i;
    while (a > 0 && /[^\s<>]/.test(v[a - 1])) a--;
    while (b < v.length && /[^\s<>]/.test(v[b])) b++;
    return [a, b];
  }

  function sel() {
    const ta = ED.ta, back = ta.selectionDirection === "backward";
    return { a: ta.selectionStart, b: ta.selectionEnd, focus: back ? ta.selectionStart : ta.selectionEnd, anchor: back ? ta.selectionEnd : ta.selectionStart };
  }
  function setSel(anchor, focus) {
    ED.ta.setSelectionRange(Math.min(anchor, focus), Math.max(anchor, focus), focus < anchor ? "backward" : "forward");
    drawCaret();
  }

  function onEditorMouse(ev) {
    if (ev.button !== 0 || ev.target.closest(".tedit-bar")) return;
    const i = pointIndex(ev);
    if (i == null) { closeEditor(true); return; }                     // a press away from the paragraph: done
    ev.preventDefault();
    ev.stopPropagation();
    ED.ta.focus({ preventScroll: true });
    if (ev.detail === 3) { selectDrawnLine(i); return; }             // a triple-click: the drawn line
    if (ev.detail >= 2) return;                                       // the double-click selects a word
    const s = sel();
    ED.dragFrom = ev.shiftKey ? s.anchor : i;
    ED.drag = true;
    ED.goalX = null;
    setSel(ED.dragFrom, i);
  }

  // the drawn line around caret position i, from its first character to its last
  function selectDrawnLine(i) {
    const pts = ED.map.pts, ln = pts[i] && pts[i].ln;
    if (!ln) return;
    let a = i, b = i;
    while (a > 0 && pts[a - 1] && pts[a - 1].ln === ln) a--;
    while (b < pts.length - 1 && pts[b + 1] && pts[b + 1].ln === ln) b++;
    const v = ED.ta.value;
    while (b > a && /\s/.test(v[b - 1] || "")) b--;                   // not the space it wraps at
    setSel(a, b);
  }

  /* the caret, the selection and the paragraph's frame over the canvas (page px × zoom) */
  function drawCaret() {
    if (!ED || !ED.map) return;
    const { canvas, host } = ED.t, node = ED.node;
    const cr = canvas.getBoundingClientRect(), hr = host.getBoundingClientRect(), k = scaleK();
    Object.assign(node.style, { left: (cr.left - hr.left) + "px", top: (cr.top - hr.top) + "px", width: cr.width + "px", height: cr.height + "px" });
    const m = ED.map, s = sel();
    const caret = node.querySelector(".tedit-caret"), p = m.pts[Math.min(s.focus, m.pts.length - 1)];
    if (p && s.a === s.b) {
      Object.assign(caret.style, { display: "block", left: (p.x * k - 1) + "px", top: (p.ln.top * k) + "px", height: Math.max(8, p.ln.h * k) + "px" });
      caret.style.animation = "none";
      void caret.offsetWidth;                                         // the blink starts over at each move
      caret.style.animation = "";
    } else caret.style.display = "none";
    // the selection: per drawn line, from its first to its last selected position
    let html = "";
    if (s.a !== s.b) {
      for (const ln of m.lines) {
        let l = Infinity, r = -Infinity;
        for (let i = s.a; i <= s.b; i++) { const q = m.pts[i]; if (q && q.ln === ln) { l = Math.min(l, q.x); r = Math.max(r, q.x); } }
        if (r > l) html += `<div class="tedit-sel" style="left:${l * k}px;top:${ln.top * k}px;width:${(r - l) * k}px;height:${ln.h * k}px"></div>`;
      }
    }
    node.querySelector(".tedit-sels").innerHTML = html;
    const box = node.querySelector(".tedit-box");
    if (m.box) {
      const pad = 8;
      Object.assign(box.style, { display: "block", left: (m.box.x * k - pad) + "px", top: (m.box.y * k - pad) + "px",
                                 width: (m.box.w * k + 2 * pad) + "px", height: (m.box.h * k + 2 * pad) + "px" });
    } else box.style.display = "none";
    if (p) Object.assign(ED.ta.style, { left: (p.x * k) + "px", top: (p.ln.top * k) + "px" });   // typing popups (IME) near the caret
    editorSelectionChanged();                                         // the top bar follows the selection
  }

  /* right-click while editing: what the old floating bar had, out of the way */
  function editorMenu(ev) {
    document.querySelectorAll(".tedit-menu").forEach((n) => n.remove());
    if (!ED) return;
    const host = ED.t.host, hr = host.getBoundingClientRect(), s = sel();
    const edited = ED.rows.some((r) => TextEdits.get(ED.sheet, r.key));
    const styled = (V.state.wordSel || []).some((en) => Object.keys(selProps(en)).length);
    const menu = document.createElement("div");
    menu.className = "tsel-menu tedit-menu";
    menu.innerHTML = `${s.a !== s.b ? `<button data-m="copy">Copy</button>` : ""}
      ${s.a !== s.b && AppLive.state.canon && ED.rows.every((r) => typeof r.n === "number") ? `<button data-m="split">Split into a new text box</button>` : ""}
      ${styled ? `<button data-m="clear">Clear the selection's style</button>` : ""}
      ${edited || ED.typed ? `<button data-m="excel">Back to the Excel text</button>` : ""}
      <div class="tsel-msep"></div>
      <button data-m="cancel">Cancel typing</button><button data-m="done">Done (Esc)</button>`;
    host.appendChild(menu);
    Object.assign(menu.style, { left: Math.min(hr.width - menu.offsetWidth - 6, ev.clientX - hr.left) + "px",
                                top: Math.min(hr.height - menu.offsetHeight - 6, ev.clientY - hr.top) + "px" });
    const close = () => { menu.remove(); document.removeEventListener("mousedown", away, true); };
    const away = (e2) => { if (!menu.contains(e2.target)) close(); };
    setTimeout(() => document.addEventListener("mousedown", away, true), 0);
    menu.querySelectorAll("[data-m]").forEach((b) => {
      b.addEventListener("mousedown", (e2) => { e2.preventDefault(); e2.stopPropagation(); });   // the typing keeps its focus
      b.addEventListener("click", (e2) => {
        e2.stopPropagation();
        close();
        const m = b.dataset.m;
        if (m === "copy") { try { navigator.clipboard.writeText(ED.ta.value.slice(s.a, s.b)); } catch (_) { /* no clipboard */ } }
        else if (m === "split") splitToBox();
        else if (m === "clear") applySelection(Object.fromEntries(STYLE_KEYS.map((k) => [k, null])));
        else editorAction(m);
      });
    });
  }
  function placeEditor() {
    drawCaret();
  }

  /* the page laid out again with the text as typed (nothing saved yet) */
  function draftEdits(ed) {
    const v = ed.ta.value, out = {};
    const seg = new Map(ed.starts.map((s, i) => [s.n, v.slice(s.pos, i + 1 < ed.starts.length ? ed.starts[i + 1].pos - 1 : v.length)]));
    for (const r of ed.rows) out[r.key] = { from: r.from, to: seg.has(r.n) ? edgeTrim(seg.get(r.n)) : "" };
    return out;
  }
  function relayout() {
    const ed = ED;
    if (!ed) return;
    const seq = ++ed.seq;
    clearTimeout(ed.timer);
    const run = async () => {
      await AppLive.draftText(ed.t.canvas, ed.sheet, draftEdits(ed));
      if (ED !== ed || seq !== ed.seq) return;
      ed.map = buildMap();
      drawCaret();
    };
    // the server lays out its own pages: one layout on its way at a time, always with the text as typed
    // when it leaves, and every answer drawn — while typing fast the page keeps up (requests that
    // overlapped cancelled each other, so it showed nothing new until the typing stopped)
    if (AppLive.state.canon && AppLive.state.canon.mode === "canonical") {
      ed.dirty = true;
      const pump = async () => {
        if (ED !== ed || ed.busy || !ed.dirty) return;
        ed.busy = true;
        ed.dirty = false;
        try { await AppLive.draftText(ed.t.canvas, ed.sheet, draftEdits(ed)); } finally { ed.busy = false; }
        if (ED !== ed) return;
        ed.map = buildMap();
        drawCaret();
        if (ed.dirty) pump();
      };
      if (!ed.busy) ed.timer = setTimeout(pump, 30);
    } else run();
    drawCaret();
  }

  /* what one input changed: old text [a, b) became `ins` */
  function inputDiff(o, n, pre, caret) {
    if (pre && pre.v === o) {
      let a, b, ins;
      if (pre.a !== pre.b) { a = pre.a; b = pre.b; ins = n.slice(a, caret); }
      else if (caret < pre.a) { a = caret; b = pre.a; ins = ""; }                      // Backspace
      else if (caret === pre.a) { a = pre.a; b = pre.a + (o.length - n.length); ins = ""; }   // Delete
      else { a = b = pre.a; ins = n.slice(a, caret); }                                // typing / Enter / paste
      if (o.slice(0, a) + ins + o.slice(b) === n) return { a, b, ins };
    }
    let p = 0, s = 0;
    while (p < o.length && p < n.length && o[p] === n[p]) p++;
    while (s < o.length - p && s < n.length - p && o[o.length - 1 - s] === n[n.length - 1 - s]) s++;
    return { a: p, b: o.length - s, ins: n.slice(p, n.length - s) };
  }

  function onEditorInput() {
    if (!ED) return;
    const ta = ED.ta, old = ED.hist[ED.hi].v;
    const d = inputDiff(old, ta.value, ED.pre, ta.selectionEnd);
    ED.pre = null;
    ED.typed = true;
    ED.goalX = null;
    const shift = d.ins.length - (d.b - d.a);
    // a row whose line break (just before it) was deleted is joined into the row above
    ED.starts = ED.starts.filter((s, i) => i === 0 || s.pos - 1 < d.a || s.pos - 1 >= d.b)
      .map((s, i) => (i && s.pos - 1 >= d.b ? { n: s.n, pos: s.pos + shift } : s));
    snapshot();
    relayout();
  }

  function snapshot() {
    ED.hist = ED.hist.slice(0, ED.hi + 1);
    ED.hist.push({ v: ED.ta.value, starts: ED.starts.map((s) => Object.assign({}, s)), a: ED.ta.selectionStart, b: ED.ta.selectionEnd });
    if (ED.hist.length > 400) ED.hist.shift();
    ED.hi = ED.hist.length - 1;
  }
  function restore(i) {
    const h = ED.hist[i];
    if (!h) return;
    ED.hi = i;
    ED.ta.value = h.v;
    ED.starts = h.starts.map((s) => Object.assign({}, s));
    ED.ta.setSelectionRange(h.a, h.b);
    ED.typed = true;
    relayout();
  }

  function onEditorKey(ev) {
    ev.stopPropagation();                                                            // no page shortcuts while typing
    const ta = ED.ta, ctrl = ev.ctrlKey || ev.metaKey, key = ev.key.toLowerCase();
    if (ev.key === "Escape") { ev.preventDefault(); stepBack(); return; }
    if (ev.key === "Enter" && ctrl) { ev.preventDefault(); closeEditor(true); return; }
    if (ctrl && key === "z" && !ev.shiftKey) { ev.preventDefault(); restore(ED.hi - 1); return; }
    if (ctrl && (key === "y" || (key === "z" && ev.shiftKey))) { ev.preventDefault(); restore(ED.hi + 1); return; }
    const v = ta.value, s = sel();
    // moving the caret over the page as drawn: up / down a drawn line, to its start / end,
    // and over an icon in one step
    if (!ctrl && ED.map && ["ArrowUp", "ArrowDown", "Home", "End", "ArrowLeft", "ArrowRight"].includes(ev.key)) {
      const p = ED.map.pts[s.focus];
      let to = null;
      if (ev.key === "ArrowLeft" || ev.key === "ArrowRight") {
        if (s.a !== s.b && !ev.shiftKey) to = ev.key === "ArrowLeft" ? s.a : s.b;
        else {
          TOKEN_AT.lastIndex = 0;
          let m;
          while ((m = TOKEN_AT.exec(v))) {
            if (ev.key === "ArrowRight" && m.index === s.focus) to = m.index + m[0].length;
            if (ev.key === "ArrowLeft" && m.index + m[0].length === s.focus) to = m.index;
          }
          if (to == null) { ED.goalX = null; setTimeout(drawCaret, 0); return; }   // a letter: the textarea moves it
        }
        ED.goalX = null;
      } else if (p) {
        if (ev.key === "Home" || ev.key === "End") { to = lineEdge(p.ln, ev.key === "End"); ED.goalX = null; }
        else {
          if (ED.goalX == null) ED.goalX = p.x;
          const ln = ED.map.lines[p.ln.n + (ev.key === "ArrowUp" ? -1 : 1)];
          to = ln ? nearestOn(ln, ED.goalX) : (ev.key === "ArrowUp" ? 0 : v.length);
        }
      }
      if (to != null) {
        ev.preventDefault();
        setSel(ev.shiftKey ? s.anchor : to, to);
      }
      return;
    }
    if (s.a !== s.b) return;
    const a = s.a;
    // joining two lines: the words get a space between them, not glued together
    let nl = ev.key === "Backspace" && v[a - 1] === "\n" ? a - 1 : ev.key === "Delete" && v[a] === "\n" ? a : -1;
    // the break between two Excel rows with an empty line next to it: the empty line goes, the rows
    // stay two rows (Backspace / Delete takes away space typed with Enter, nothing else)
    if (nl >= 0 && ED.starts.some((st, i) => i && st.pos - 1 === nl)) {
      if (v[nl - 1] === "\n") nl -= 1;
      else if (v[nl + 1] === "\n") nl += 1;
    }
    if (nl >= 0 && !ctrl) {
      ev.preventDefault();
      const gap = /\S/.test(v[nl - 1] || "") && /\S/.test(v[nl + 1] || "") ? " " : "";
      ED.pre = { v, a: nl, b: nl + 1 };
      ta.setRangeText(gap, nl, nl + 1, "end");
      onEditorInput();
      return;
    }
    // a <SYMBOL> goes as a whole: Backspace / Delete next to one selects it, then deletes the selection
    if (ev.key === "Backspace" && v[a - 1] === ">") {
      const st = v.lastIndexOf("<", a - 1);
      const p = ED.map && ED.map.pts[a], pt = ED.map && ED.map.pts[st];
      if (s.a === s.b && p && pt && p.ln !== pt.ln && /[ \t]/.test(v[a] || "")) {
        // the caret starts a drawn line and the icon ends the one above (the space between them is
        // where the row wrapped): Backspace takes that space away, never the icon
        ev.preventDefault();
        ED.pre = { v, a, b: a + 1 };
        ta.setRangeText("", a, a + 1, "start");
        onEditorInput();
        return;
      }
      if (st >= 0 && /^<[^<>\n]+>$/.test(v.slice(st, a))) ta.setSelectionRange(st, a);
    } else if (ev.key === "Delete" && v[a] === "<") {
      const e = v.indexOf(">", a);
      if (e >= 0 && /^<[^<>\n]+>$/.test(v.slice(a, e + 1))) ta.setSelectionRange(a, e + 1);
    }
  }

  async function editorAction(a) {
    if (!ED) return;
    if (a === "done") return closeEditor(true);
    if (a === "cancel") return closeEditor(false);
    if (a === "excel") {
      const ed = ED;
      await closeEditor(false, null, true);
      TextEdits.clear(ed.sheet, ed.rows.map((r) => r.key));
      await TextEdits.save();
      await ed.t.refresh();
    }
  }

  /* a row's text was edited: its "just this text" styles move with the words they were on (the
     rule's row text becomes the new text, its occurrence is counted again). Styles on words that
     were retyped stay on the same place only when those words are still there. */
  function followEdit(sheet, oldText, newText) {
    const { skel, occurrences } = wt();
    const a = skel(oldText).s, b = skel(newText).s;
    let pre = 0;
    while (pre < a.length && pre < b.length && a[pre] === b[pre]) pre++;
    let suf = 0;
    while (suf < a.length - pre && suf < b.length - pre && a[a.length - 1 - suf] === b[b.length - 1 - suf]) suf++;
    const ds = App.state.config.dynamic_settings || {};
    let moved = false;
    for (const r of Array.isArray(ds.text_style_rules) ? ds.text_style_rules : []) {
      if (!isExact(r) || r.sheet !== sheet || !sameText(r.row_text, oldText)) continue;
      const rr = rangeOf(oldText, r.text, Number(r.nth));
      const want = skel(r.text).s, hits = occurrences(b, want);
      let at = null;
      if (rr && rr[1] <= pre) at = rr[0];                                   // before the change: same place
      else if (rr && rr[0] >= a.length - suf) at = rr[0] + (b.length - a.length);   // after it: shifted
      else if (rr && hits.length) at = hits.reduce((best, h) => (Math.abs(h - rr[0]) < Math.abs(best - rr[0]) ? h : best));
      const nth = at == null ? -1 : hits.indexOf(at);
      r.row_text = newText;
      r.nth = nth >= 0 ? nth : hits.length;                                  // gone: matches nothing, kept to undo
      moved = true;
    }
    if (moved) App.refreshUI();
  }

  /* the typed text back into one edit per Excel row; true when anything changed. Refuses (and says
     so) when the rows' texts wouldn't add up to exactly what was typed — nothing may go missing. */
  function writeRows(ed) {
    const v = ed.ta.value, sheet = ed.sheet;
    // empty lines stay: space typed with Enter, like in Notepad (the page draws them as blank lines)
    const tidy = (s) => edgeTrim(s.replace(/[ \t]+\n/g, "\n").replace(/\n[ \t]+/g, "\n"));
    const lines = (s) => String(s || "").split("\n").map((l) => l.replace(/\s+/g, " ").trim()).join("\n");
    const seg = new Map(ed.starts.map((s, i) => [s.n, v.slice(s.pos, i + 1 < ed.starts.length ? ed.starts[i + 1].pos - 1 : v.length)]));
    const owners = [];
    for (const r of ed.rows) {
      if (seg.has(r.n) || !owners.length) owners.push({ r, text: tidy(seg.get(r.n) || ""), joined: [] });
      else owners[owners.length - 1].joined.push(r);
    }
    if (inked(owners.map((o) => o.text).join("")) !== inked(v)) {
      toast("The edit could not be matched to its Excel rows, so it was not saved — nothing was changed.");
      return false;
    }
    const before = JSON.stringify(ed.rows.map((r) => TextEdits.get(sheet, r.key)));
    for (const o of owners) if (o.r.live && o.text && !sameText(o.r.shown, o.text)) followEdit(sheet, o.r.shown, o.text);
    for (const o of owners) {
      const r = o.r;
      if (!o.text.trim()) TextEdits.set(sheet, r.key, { from: r.from, to: "" });        // all its text deleted: hidden
      else if (!o.joined.length && lines(o.text) === lines(r.from)) TextEdits.set(sheet, r.key, null);
      else TextEdits.set(sheet, r.key, Object.assign({ from: r.from, to: o.text }, o.joined.length ? { joined: o.joined.map((j) => j.key) } : {}));
      o.joined.forEach((j) => TextEdits.set(sheet, j.key, { from: j.from, to: "" }));
    }
    return JSON.stringify(ed.rows.map((r) => TextEdits.get(sheet, r.key))) !== before;
  }

  async function closeEditor(save, then, noRefresh) {
    if (!ED) return;
    const ed = ED;
    ED = null;
    clearTimeout(ed.timer);
    document.removeEventListener("mousedown", ed.outside, true);
    document.removeEventListener("mousemove", ed.move);
    document.removeEventListener("mouseup", ed.up);
    document.removeEventListener("selectionchange", ed.selch);
    document.querySelectorAll(".tedit-menu").forEach((n) => n.remove());
    ed.node.remove();
    clearTimeout(edSelTimer);
    showSelection(null);                                            // the top bar is the paragraph's again
    const changed = !!save && writeRows(ed);
    if (changed) await TextEdits.save();
    // the page from the saved text again (a cancelled draft goes away)
    if (!noRefresh && (changed || ed.typed)) await ed.t.refresh();
    if (then) then();
  }

  const norm = (t) => String(t || "").replace(/<([^<>]*?)(?:~\d+(?:\.\d+)?(?:\^[\d.]+,[\d.]+)?|\^[\d.]+,[\d.]+)\s*>/g, "<$1>").replace(/\s+/g, " ").trim().toLowerCase();
  const sameText = (a, b) => norm(a) === norm(b);
  function styleRules() {
    const ds = (App.state.config.dynamic_settings = App.state.config.dynamic_settings || {});
    ds.text_style_rules = Array.isArray(ds.text_style_rules) ? ds.text_style_rules : [];
    return ds.text_style_rules;
  }
  async function saveRules(change) {
    const refresh = (TS || typoTarget()).refresh;
    const ds = (App.state.config.dynamic_settings = App.state.config.dynamic_settings || {});
    ds.text_style_rules = change(styleRules().slice());
    App.refreshUI();
    if (App.flushConfig) await App.flushConfig();
    exitTextMode();
    await refresh();
  }

  function openStylePop(phrases, ev) {
    const host = TS.host, hr = host.getBoundingClientRect();
    const rules = styleRules();
    const cur = rules.find((r) => r.kind === "word" && (r.scope === "row"
      ? sameText(r.row_text, phrases[0].row) && sameText(r.text, phrases[0].words[0]) : sameText(r.text, phrases[0].phrase))) || {};
    const fonts = (App.state.fonts || []).slice().sort((a, b) => String(a).localeCompare(String(b)));
    const lib = Object.keys(((App.state.config.dynamic_settings || {}).layer_style_library) || {}).sort();
    const pop = document.createElement("div");
    pop.className = "tsel-pop vis-style-bar";
    const label = phrases.length === 1 ? `“${esc(phrases[0].phrase)}”` : `${phrases.length} pieces of text`;
    pop.innerHTML = `<div class="vsb-head"><b>Style ${label}</b><button class="vsb-x" data-x title="Cancel">✕</button></div>
      <div class="vsb-row"><select id="tpFont" class="vsb-font">${[["", "Same font"]].concat(fonts.map((f) => [f, f])).map(([v, t]) => `<option value="${esc(v)}" ${v === (cur.font || "") ? "selected" : ""}>${esc(t)}</option>`).join("")}</select>
        <label class="vsb-lab">Size <input type="number" id="tpSize" class="vsb-num" min="30" max="400" step="5" value="${Math.round(cur.size || 100)}">%</label></div>
      <div class="vsb-row"><label class="vsb-scope"><input type="checkbox" id="tpColorOn" ${cur.color ? "checked" : ""}> colour <input type="color" id="tpColor" value="${esc(cur.color || "#ffd54a")}"></label>
        <button class="vsb-tog ${cur.bold ? "on" : ""}" id="tpBold" title="Bold"><b>B</b></button>
        <button class="vsb-tog ${cur.italic ? "on" : ""}" id="tpItalic" title="Italic"><i>I</i></button></div>
      <div class="vsb-row"><span class="vsb-lab">Layer style</span>
        <select id="tpFx" data-lsswatch>${[["", "None"]].concat(lib.map((n) => [n, n])).map(([v, t]) => `<option value="${esc(v)}" ${v === (cur.fx || "") ? "selected" : ""}>${esc(t)}</option>`).join("")}</select></div>
      <div class="vsb-row tp-scopes"><span class="vsb-lab">Change</span>
        <label class="vsb-scope" title="Only the text you selected"><input type="radio" name="tpScope" value="row" ${!cur.scope || cur.scope === "row" ? "checked" : ""}> just this text</label>
        <label class="vsb-scope" title="This text wherever it appears on this page"><input type="radio" name="tpScope" value="page" ${cur.scope === "page" ? "checked" : ""}> every match on this page</label>
        <label class="vsb-scope" title="This text wherever it appears in the game (all pages, all markets)"><input type="radio" name="tpScope" value="game" ${cur.scope === "game" ? "checked" : ""}> everywhere in the game</label></div>
      <div class="vsb-row"><span style="flex:1"></span><button class="pt-btn primary small" data-apply>Apply</button></div>`;
    host.appendChild(pop);
    ["mousedown", "pointerdown", "click", "dblclick"].forEach((t) => pop.addEventListener(t, (e2) => e2.stopPropagation()));
    const w = pop.offsetWidth, h = pop.offsetHeight;
    pop.style.left = Math.max(6, Math.min(hr.width - w - 6, ev.clientX - hr.left + 10)) + "px";
    pop.style.top = Math.max(6, Math.min(hr.height - h - 6, ev.clientY - hr.top)) + "px";
    const q = (id) => pop.querySelector("#" + id);
    q("tpBold").addEventListener("click", () => q("tpBold").classList.toggle("on"));
    q("tpItalic").addEventListener("click", () => q("tpItalic").classList.toggle("on"));
    q("tpColor").addEventListener("input", () => { q("tpColorOn").checked = true; });
    pop.querySelector("[data-x]").addEventListener("click", () => pop.remove());
    pop.querySelector("[data-apply]").addEventListener("click", () => {
      const scope = pop.querySelector('input[name="tpScope"]:checked').value, sheet = TS.sheet();
      const size = Number(q("tpSize").value) || 100;
      saveRules((all) => {
        for (const p of phrases) {
          // "just this text": each word on its own, for this line of text only — it keeps its
          // style when the line wraps differently; the others: the phrase wherever it appears
          const pieces = scope === "row" ? p.words : [p.phrase];
          for (const text of pieces) {
            const rule = { kind: "word", text, whole_word: true, bold: q("tpBold").classList.contains("on"),
                           italic: q("tpItalic").classList.contains("on"), font: q("tpFont").value || "", scope };
            if (q("tpColorOn").checked) rule.color = q("tpColor").value;
            if (Math.abs(size - 100) > 0.5) rule.size = size;
            if (q("tpFx").value) rule.fx = q("tpFx").value;
            if (scope !== "game") rule.sheet = sheet;
            if (scope === "row") rule.row_text = p.row;
            const i = all.findIndex((r) => r.kind === "word" && sameText(r.text, text) && (r.scope || "game") === scope
              && (scope === "game" || r.sheet === sheet) && (scope !== "row" || sameText(r.row_text, p.row)));
            if (i >= 0) all[i] = rule; else all.push(rule);
          }
        }
        return all;
      });
    });
  }

  document.addEventListener("keydown", (ev) => {
    // Ctrl+C / Ctrl+V on selected tables (not while typing in a field or editing text)
    const inField = ev.target && ev.target.closest && ev.target.closest("input, textarea, select, [contenteditable]");
    if (App.route === "typography" && !ED && !inField && SP() && SP().onKey(ev)) { ev.preventDefault(); return; }   // copy / paste a card look
    if (App.route === "typography" && !ED && window.TableStudio && !inField && TableStudio.onKey(ev)) { ev.preventDefault(); return; }
    if (ev.key !== "Escape") return;
    if (SP() && SP().escape()) return;     // a card → its row → the page
    if (ED) { stepBack(); return; }                     // focus on the top bar while editing: Esc still steps back
    if (V.state.textMode) exitTextMode();
    else if (App.route === "typography" && window.IconStudio && IconStudio.selected()) IconStudio.deselect();
    else if (App.route === "typography" && window.AppTblVis && AppTblVis.typoActive && AppTblVis.typoActive() && AppTblVis.clearCells()) return;
    else if (App.route === "typography" && window.TableStudio && TableStudio.selected().length) TableStudio.deselect();
    else if (V.state.row && App.route === "assets") { V.state.row = null; V.showTarget(V.state.target); }
    else stepBack();                                    // a row / the paragraph's or a box's frame: nothing picked
  });

  window.AppTypoVis = V;
  window.TextSelect = {
    enter: (clientX, clientY, target) => enterTextMode(clientX, clientY, target),
    exit: exitTextMode,
    get active() { return !!V.state.textMode; },
  };
})();