/* Game Rules and Bingo Rules pages on the Canvas: what they have beyond a normal page.

   Their text is drawn and edited like every other page's (visualiser_live.js draws the layout
   rules_layout.py makes from their own renderer; the row editor, the top bar and the icon handles work
   on it). Each paragraph keeps its own settings (TypoStudio targets "gr_rules", "gr_legal", "bingo").
   This adds, over the page:
     Game Rules · the separator (click: colour, width, thickness, layer style; drag its ends / bottom
                  edge) · the XTRAA REELS icons (drag one: both move — in / out together, up / down
                  together; its corner: the size) · the margin guides · right-click a line: put it
                  under / above the separator · the Page bar: build it, XTRAA REELS ticks, its picture
     Bingo Rules · a row picked (double-click it): left / centre / right, its own size and colour ·
                  its side margins · always one page
   Where things are comes from the renderer's report (AppLive.state.canon.rules.report).
   Uses app.js globals: App, api, esc, toast, debounce, TextEdits. */
window.RulesCanvas = (() => {
  const S = { kinds: {}, sel: null, rows: new Set(), dragged: false };
  const ALIGN_KEYS = { left: "bingo_rules_left_align_cells", right: "bingo_rules_right_align_cells", center: "bingo_rules_center_align_cells" };
  const el = (id) => document.getElementById(id);
  const ds = () => (App.state.config.dynamic_settings = App.state.config.dynamic_settings || {});
  const sheet = () => (window.AppTypoVis && AppTypoVis.state.sheet) || "";
  const kindOf = (name) => S.kinds[name] || "";
  const isRules = (name) => !!kindOf(name);
  const on = () => App.route === "typography" && !!window.AppTypoVis && isRules(sheet());
  const kind = () => (on() ? kindOf(sheet()) : "");
  const gr = () => kind() === "game_rules";
  function setSheets(map) { S.kinds = Object.assign({}, map || {}); }
  // the renderer's report for the page on the Canvas now (null while another sheet is drawn)
  function report() {
    const c = window.AppLive && AppLive.state && AppLive.state.canon;
    return c && c.rules && c.sheet_name === sheet() ? c.rules.report || {} : null;
  }
  // a change: the page laid out again (the Canvas keeps its zoom)
  const redrawSoon = debounce(() => { if (on() && AppTypoVis.refreshPreview) AppTypoVis.refreshPreview(); }, 200);
  function save(key, value) {
    App.set(key, value);
    App.pushConfig();
    redrawSoon();
  }

  /* ------------------------------ the frames over the page ------------------------------ */
  function view() {
    const c = el("typoVisCanvas"), host = el("typoVisHost"), L = report();
    if (!c || !host || !L || !L.canvas) return null;
    const cr = c.getBoundingClientRect(), hr = host.getBoundingClientRect(), [cw, ch] = L.canvas;
    const k = cr.width / cw;
    return { k, cw, ch, x: (v) => cr.left - hr.left + v * k, y: (v) => cr.top - hr.top + v * (cr.height / ch), host };
  }
  const box = (V, r, pad = 0) => `left:${V.x(r[0] - pad)}px;top:${V.y(r[1] - pad)}px;width:${(r[2] + 2 * pad) * V.k}px;height:${(r[3] + 2 * pad) * V.k}px`;
  // drawn once per frame: the Canvas's layout (zoom, pan, every page draw) asks for it many times
  let framesQueued = 0;
  function paintFrames() {
    if (framesQueued) return;
    framesQueued = requestAnimationFrame(() => { framesQueued = 0; paintFramesNow(); });
  }
  function paintFramesNow() {
    document.querySelectorAll(".rlc-frames").forEach((n) => n.remove());
    if (!on()) return;
    const V = view(), L = report();
    if (!V) return;
    const layer = document.createElement("div");
    layer.className = "ptc-frames rlc-frames";
    let html = "";
    if (gr()) {
      if (L.separator) {
        const s = L.separator, picked = S.sel === "separator";
        html += `<div class="rlc-hit sep ${picked ? "sel" : ""}" data-k="separator" style="left:${V.x(s[0])}px;top:${V.y(s[1]) - 7}px;width:${s[2] * V.k}px;height:${s[3] * V.k + 14}px">
          ${picked ? `<i class="rlc-h ew l" data-h="sepw" data-side="l" title="Width"></i><i class="rlc-h ew r" data-h="sepw" data-side="r" title="Width"></i><i class="rlc-h ns b" data-h="seph" title="Thickness"></i><span class="rlc-tag">Separator</span>` : ""}</div>`;
      }
      const x = L.xtra || {};
      ["left", "right"].forEach((side) => {
        const rc = (x.rects || {})[side];
        if (!rc) return;
        if (!x[side]) {
          if (x["want_" + side]) {
            html += `<div class="rlc-hit xr empty" data-k="xtrapick" data-side="${side}" style="${box(V, rc, 2)}" title="Choose the XTRAA REELS picture"><span>XTRAA REELS<br>${x.asset ? "" : "choose its picture"}</span></div>`;
          }
          return;
        }
        const picked = S.sel === "xtra";
        html += `<div class="rlc-hit xr ${picked ? "sel" : ""}" data-k="xtra" data-h="xrmove" data-side="${side}" style="${box(V, rc, 2)}" title="Drag: both icons move (in / out, up / down together)">
          ${picked ? `<i class="rlc-h corner ${side === "left" ? "rb" : "lb"}" data-h="xrsize" data-side="${side}" title="Size (both icons)"></i>` : ""}</div>`;
      });
    } else {
      // the Bingo rows picked (their own alignment, size, colour)
      (L.cells || []).filter((c) => S.rows.has(c.cell)).forEach((c) => {
        html += `<div class="rlc-para sel" style="${box(V, c.rect, 3)}"><span class="rlc-al">${c.align === "left" ? "⯇" : c.align === "right" ? "⯈" : ""}</span></div>`;
      });
    }
    html += guidesHtml(V);
    layer.innerHTML = html;
    V.host.appendChild(layer);
    wireFrames(layer, V);
    layer.querySelectorAll(".rlc-guide").forEach((g) => g.addEventListener("mousedown", (ev) => dragGuide(ev, g, V)));
  }

  /* the margin guides (drag): heading top, heading–body gap, the text–separator gap, the separator–legal
     gap, the bottom; the sides of the text, the legal text and the XTRAA REELS icons; Bingo: its sides */
  function guides() {
    const L = report() || {}, G = L.guides || {}, out = [];
    if (G.heading_top == null) return out;
    out.push({ id: "top", at: G.heading_top, label: "Header Top Margin" }, { id: "gap", at: G.body_top, label: "Heading–Body Gap" });
    if (gr() && L.separator) {
      const rb = ((L.blocks || {}).rules || [])[3], lb = ((L.blocks || {}).legal || [])[1];
      if (rb != null) out.push({ id: "sepabove", at: L.separator[1], from: rb, label: "Text–Separator Gap" });
      if (lb != null) out.push({ id: "legal", at: lb, from: L.separator[1] + L.separator[3], label: "Separator–Legal Gap" });
    }
    out.push({ id: "bottom", at: G.safe_bottom, label: "Bottom Margin" });
    return out.filter((g) => g.at != null && isFinite(g.at));
  }
  function guidesHtml(V) {
    const L = report() || {}, G = L.guides || {};
    let html = guides().map((g) => `<div class="rlc-guide h" data-g="${g.id}" style="top:${V.y(g.at)}px;left:${V.x(0)}px;width:${V.cw * V.k}px"><span>${esc(g.label)}</span></div>`).join("");
    if (gr()) {
      const x = L.xtra || {}, vs = [];
      if (G.upper_margin != null) vs.push(["text", G.upper_margin, (x.left || x.right) ? "Text ↔ XTRAA REELS" : "Text Margin"]);
      if (G.legal_margin != null && (L.lines || []).some((l) => l.part === "legal")) vs.push(["legalside", G.legal_margin, "Legal Text Margin"]);
      if (x.asset && (x.left || x.right) && x.outer != null) vs.push(["xouter", x.outer, "XTRAA REELS Margin"]);
      vs.forEach(([id, at, label], n) => {
        html += ["l", "r"].map((sd) => `<div class="rlc-guide v" data-g="${id}" data-side="${sd}" style="left:${V.x(sd === "l" ? at : V.cw - at)}px;top:${V.y(0)}px;height:${V.ch * V.k}px"><span style="top:${6 + 18 * n}px">${label}</span></div>`).join("");
      });
    }
    if (!gr() && G.margin_x != null) {
      html += ["l", "r"].map((sd) => `<div class="rlc-guide v" data-g="side" data-side="${sd}" style="left:${V.x(sd === "l" ? G.margin_x : V.cw - G.margin_x)}px;top:${V.y(0)}px;height:${V.ch * V.k}px"><span>${sd === "l" ? "Left" : "Right"} Margin</span></div>`).join("");
    }
    return html;
  }
  function dragGuide(ev, n, V) {
    if (ev.button !== 0) return;
    ev.preventDefault();
    ev.stopPropagation();
    const G = (report() || {}).guides || {}, id = n.dataset.g, g = guides().find((x) => x.id === id) || {};
    const host = V.host.getBoundingClientRect();
    let val = null;
    const move = (e) => {
      const y = (e.clientY - host.top - V.y(0)) / V.k, x = (e.clientX - host.left - V.x(0)) / V.k;
      if (n.classList.contains("v")) {               // a side guide: both sides together, from their own edge
        val = Math.max(0, Math.min(Math.round(V.cw * 0.45), Math.round(n.dataset.side === "r" ? V.cw - x : x)));
        document.querySelectorAll(`.rlc-guide[data-g="${id}"]`).forEach((l) => { l.style.left = V.x(l.dataset.side === "r" ? V.cw - val : val) + "px"; });
        return;
      }
      const at = Math.max(0, Math.min(V.ch, y));
      val = Math.max(0, Math.round(id === "top" ? at : id === "gap" ? at - G.heading_bottom : id === "bottom" ? V.ch - at : at - g.from));
      n.style.top = V.y(id === "gap" ? G.heading_bottom + val : id === "bottom" ? V.ch - val : id === "top" ? val : g.from + val) + "px";
    };
    const up = () => {
      document.removeEventListener("mousemove", move);
      document.removeEventListener("mouseup", up);
      if (val == null) return;
      if (id === "text") {
        // with XTRAA REELS the text's edge is the icons' clearance, else the text's own side margin
        const x = (report() || {}).xtra || {};
        if (x.left || x.right) save("dynamic_settings.game_rules_xtra_reels_text_gap", Math.max(0, val - (x.outer || 0) - (x.width || 0)));
        else save("dynamic_settings.game_rules_bottom_lr_margin", val);
        return;
      }
      if (id === "legalside") { save("dynamic_settings.game_rules_malfunction_lr_margin", val); return; }
      if (id === "xouter") { save("dynamic_settings.game_rules_xtra_reels_outer_margin", val); return; }
      const key = { top: "heading_top_margin", gap: "heading_to_body_gap", bottom: "bottom_margin", side: "dynamic_settings.bingo_rules_side_margin",
                    sepabove: "dynamic_settings.game_rules_bottom_gap", legal: "dynamic_settings.game_rules_separator_after_gap" }[id];
      if (key) save(key, val);
    };
    document.addEventListener("mousemove", move);
    document.addEventListener("mouseup", up);
  }

  // the separator / the XTRAA REELS icons picked: their bar is the top bar
  function pick(sel) {
    S.sel = sel;
    S.rows = new Set();
    if (window.IconStudio) IconStudio.deselect();
    if (window.AppTypoVis) AppTypoVis.selectRow(null);
    paintFrames();
    if (window.TypoStudio) TypoStudio.setTarget(sel ? "rules_part" : "rules_page");
  }
  function wireFrames(layer, V) {
    layer.querySelectorAll(".rlc-hit[data-k]").forEach((n) => {
      n.addEventListener("mousedown", (ev) => {
        if (ev.button !== 0) return;
        const h = ev.target.closest("[data-h]");
        if (h && (S.sel === n.dataset.k || h.dataset.h === "xrmove")) { dragHandle(ev, h, V, n); return; }
        ev.stopPropagation();
      });
      n.addEventListener("click", (ev) => { ev.stopPropagation(); if (S.dragged) return; if (n.dataset.k === "xtrapick") { pickXtra(); return; } pick(n.dataset.k); });
      ["dblclick", "contextmenu"].forEach((t) => n.addEventListener(t, (ev) => { ev.preventDefault(); ev.stopPropagation(); }));
    });
  }

  /* ------------------------------ handles ------------------------------ */
  function dragHandle(ev, h, V, frame) {
    ev.preventDefault();
    ev.stopPropagation();
    const L = report() || {}, x = L.xtra || {}, kind2 = h.dataset.h, side = h.dataset.side;
    const x0 = ev.clientX, y0 = ev.clientY, sep = (L.separator || [0, 0, 0, 0]).slice();
    let dxC = 0, dyC = 0;
    S.dragged = false;
    const frames = kind2 === "xrmove" ? [...document.querySelectorAll('.rlc-hit[data-k="xtra"]')] : [frame];
    const start = frames.map((f) => ({ l: f.offsetLeft, t: f.offsetTop, w: f.offsetWidth, h: f.offsetHeight }));
    const move = (e) => {
      dxC = (e.clientX - x0) / V.k;
      dyC = (e.clientY - y0) / V.k;
      if (Math.abs(e.clientX - x0) + Math.abs(e.clientY - y0) > 2) S.dragged = true;
      frames.forEach((f, i) => {
        const s0 = start[i], fs = f.dataset.side;
        if (kind2 === "xrmove") {                    // the two icons mirror each other across the page
          const dx = (e.clientX - x0) * (fs === side ? 1 : -1);
          Object.assign(f.style, { left: s0.l + dx + "px", top: s0.t + (e.clientY - y0) + "px" });
        } else if (kind2 === "xrsize") {
          const g = (side === "left" ? 1 : -1) * (e.clientX - x0);
          Object.assign(f.style, { width: Math.max(10, s0.w + g) + "px", height: Math.max(10, s0.h * (s0.w + g) / Math.max(1, s0.w)) + "px", left: (side === "left" ? s0.l : s0.l - g) + "px" });
        } else if (kind2 === "sepw") {
          const g = (side === "l" ? -1 : 1) * (e.clientX - x0);
          Object.assign(f.style, { width: Math.max(10, s0.w + 2 * g) + "px", left: s0.l - g + "px" });
        } else if (kind2 === "seph") Object.assign(f.style, { height: Math.max(8, s0.h + (e.clientY - y0)) + "px" });
      });
    };
    const up = () => {
      document.removeEventListener("mousemove", move);
      document.removeEventListener("mouseup", up);
      setTimeout(() => { S.dragged = false; }, 0);
      if (!S.dragged) return;
      const d = ds();
      if (kind2 === "xrmove") {
        // dragged in: further from the page edge (both sides); up / down: both together
        const inward = side === "left" ? dxC : -dxC;
        d.game_rules_xtra_reels_outer_margin = Math.max(0, Math.round((x.outer || 0) + inward));
        d.game_rules_xtra_reels_y_offset = Math.round(Number(d.game_rules_xtra_reels_y_offset || 0) + dyC);
      } else if (kind2 === "xrsize") {
        d.game_rules_xtra_reels_width = Math.max(10, Math.round((x.width || 100) + (side === "left" ? dxC : -dxC)));
      } else if (kind2 === "sepw") {
        d.game_rules_separator_width = Math.max(20, Math.round(sep[2] + 2 * (side === "l" ? -dxC : dxC)));
      } else if (kind2 === "seph") {
        d.game_rules_separator_height = Math.max(1, Math.round(sep[3] + dyC));
      }
      App.pushConfig();
      redrawSoon();
    };
    document.addEventListener("mousemove", move);
    document.addEventListener("mouseup", up);
  }

  /* ------------------------------ the legal split (right-click a line) ------------------------------ */
  // overrides are lines "Sheet=Cell" (the last line of a sheet wins); "Sheet=none" = nothing under it
  function setLegal(value) {
    const d = ds(), name = sheet();
    const mine = (line) => { const i = line.search(/[=|]/); return i > 0 && line.slice(0, i).trim().toLowerCase() === name.toLowerCase(); };
    const lines = String(d.game_rules_legal_split_overrides || "").split(/[\n;]+/).map((l) => l.trim()).filter((l) => l && !mine(l));
    if (value) lines.push(`${name}=${value}`);
    d.game_rules_legal_split_overrides = lines.join("\n");
    App.pushConfig();
    redrawSoon();
  }
  /* a Game Rules line right-clicked (e: its line element): under / above the separator, its Excel text */
  function lineMenu(ev, e) {
    document.querySelectorAll(".rlc-menu").forEach((n) => n.remove());
    const L = report() || {}, lines = L.lines || [], cell = e && e.cell;
    if (!gr() || !cell) return false;
    const part = (e.meta && e.meta.part) || "rules";
    const i = lines.findIndex((l) => l.cell === cell);
    const m = document.createElement("div");
    m.className = "tsel-menu rlc-menu";
    m.innerHTML = `${part === "rules" ? `<button data-m="under">Put under the separator (from this line on)</button>` : `<button data-m="above">Move back above the separator (up to this line)</button>`}
      ${(L.legal || {}).manual ? `<button data-m="auto">Automatic (from “Malfunction…”)</button>` : ""}
      ${TextEdits.get(sheet(), cell) ? `<div class="tsel-msep"></div><button data-m="excel">Back to the Excel text</button>` : ""}`;
    document.body.appendChild(m);
    Object.assign(m.style, { position: "fixed", left: Math.min(innerWidth - m.offsetWidth - 6, ev.clientX) + "px", top: Math.min(innerHeight - m.offsetHeight - 6, ev.clientY) + "px", zIndex: 999 });
    ["mousedown", "pointerdown", "click"].forEach((t) => m.addEventListener(t, (x) => x.stopPropagation()));
    setTimeout(() => document.addEventListener("click", () => m.remove(), { once: true }), 0);
    m.querySelectorAll("[data-m]").forEach((b) => b.addEventListener("click", async () => {
      m.remove();
      const k = b.dataset.m;
      if (k === "under") setLegal(cell);
      else if (k === "above") {
        const next = lines.slice(i + 1).find((l) => l.part === "legal" && l.cell !== cell);
        setLegal(next ? next.cell : "none");
      } else if (k === "auto") setLegal(null);
      else if (k === "excel") { TextEdits.clear(sheet(), [cell]); await TextEdits.save(); redrawSoon(); }
    }));
    return true;
  }

  /* ------------------------------ bars (sections of the top bar) ------------------------------ */
  const sep = `<span class="ts-sep"></span>`;
  const num = (key, v, title, min, max, unit) => `<input class="ts-size ts-narrow" type="number" data-set="${key}" value="${esc(v ?? "")}" min="${min}" max="${max}" title="${esc(title)}">${unit ? `<span class="ts-unit">${unit}</span>` : ""}`;
  const col = (key, v, title) => `<input type="color" class="rlc-col" data-set="${key}" value="${esc(hex(v) || "#ffffff")}" title="${esc(title)}">`;
  function hex(v) {
    if (Array.isArray(v)) return "#" + v.slice(0, 3).map((n) => Math.max(0, Math.min(255, Number(n) || 0)).toString(16).padStart(2, "0")).join("");
    return /^#[0-9a-f]{6}$/i.test(String(v || "")) ? String(v) : "";
  }
  function fxSel(attr, cur) {
    const lib = Object.keys(ds().layer_style_library || {}).sort((a, b) => a.localeCompare(b));
    return `<span class="ts-lbl">Layer style</span><select class="ts-style" ${attr} data-lsswatch title="Layer style">${[["", "None"]].concat(lib.map((n) => [n, n]))
      .map(([v, t]) => `<option value="${esc(v)}" ${v === (cur || "") ? "selected" : ""}>${esc(t)}</option>`).join("")}</select>`;
  }
  // a paragraph's background strip (dynamic_settings.<key>: on, fill, fill_opacity, pad, radius)
  function stripCtl(key) {
    const s = ds()[key] || {}, p = `dynamic_settings.${key}`;
    return `${sep}<button class="ts-tgt ${s.on ? "on" : ""}" data-strip="${key}" title="A background strip behind this text">${s.on ? "✓ " : ""}Strip</button>
      ${s.on ? `${col(p + ".fill", s.fill || "#000000", "Strip colour")}${num(p + ".fill_opacity", s.fill_opacity ?? 60, "Strip opacity (%)", 0, 100, "%")}
        <span class="ts-lbl">Pad</span>${num(p + ".pad", s.pad ?? 12, "Space around the text (px)", 0, 300, "")}<span class="ts-lbl">◜</span>${num(p + ".radius", s.radius ?? 0, "Corner radius (px)", 0, 500, "")}` : ""}`;
  }
  const xtraTicks = (x) => ["left", "right"].map((s) => `<label class="ts-lbl rlc-check" title="Show the XTRAA REELS icon on the ${s}"><input type="checkbox" data-xrside="${s}" ${x["want_" + s] ? "checked" : ""}> ${s}</label>`).join("")
    + `<button class="ts-tgt" data-xrauto title="Show them when this page mentions XTRAA REELS">Auto</button>`;
  // the drawn size when the page had to shrink to stay one page
  function fitHint(part) {
    const L = report() || {}, sz = L.sizes || {};
    if (gr()) {
      const now = part === "gr_legal" ? sz.legal : sz.body, set = part === "gr_legal" ? sz.legal_set : sz.body_set;
      return L.fit && L.fit < 0.995 && now ? `<span class="ts-hint">drawn at ${now}px to stay on one page</span>` : "";
    }
    return sz.body && sz.body_set && sz.body < sz.body_set ? `<span class="ts-hint">drawn at ${sz.body}px to stay on one page</span>` : "";
  }
  /* what a paragraph has beyond the normal text bar (after it in the top bar) */
  function extraHtml(target) {
    if (!on()) return "";
    const d = ds();
    if (target === "gr_rules") return `${stripCtl("game_rules_rules_bg")}${fitHint(target)}<span class="ts-hint">right-click a line: put it under the separator</span>`;
    if (target === "gr_legal") {
      return `${stripCtl("game_rules_legal_bg")}${((report() || {}).legal || {}).manual ? `${sep}<button class="ts-tgt" data-legalauto>Automatic split</button>` : ""}${fitHint(target)}
        <span class="ts-hint">right-click a line: move it back above the separator</span>`;
    }
    if (target === "bingo") {
      return `${sep}<button class="ts-tgt ${d.bingo_rules_clean_spaces ? "on" : ""}" data-cleansp title="Two or more spaces in a row become one">${d.bingo_rules_clean_spaces ? "✓ " : ""}Single spaces</button>${fitHint(target)}
        <span class="ts-hint">double-click a row: type in it, its alignment, size and colour</span>`;
    }
    return "";
  }
  /* the page itself (nothing picked): build it; Game Rules: the XTRAA REELS icons */
  function pageBarHtml() {
    const L = report() || {};
    if (gr()) {
      return `<label class="ts-lbl rlc-check"><input type="checkbox" data-build="render_game_rules" ${App.get("render_game_rules") !== false ? "checked" : ""}> Build this page</label>
        ${sep}<span class="ts-lbl">XTRAA REELS</span>${xtraTicks(L.xtra || {})}<button class="ts-tgt" data-xrpick title="The picture to use (else xtraa*.png / xtrareel*.png in the symbols folder)">Choose icon…</button>
        <span class="ts-hint">click the separator or an icon to change it · always one page</span>`;
    }
    return `<label class="ts-lbl rlc-check"><input type="checkbox" data-build="render_bingo_rules" ${App.get("render_bingo_rules") !== false ? "checked" : ""}> Build this page</label>
      <span class="ts-hint">always one page</span>`;
  }
  /* the separator or the XTRAA REELS icons, picked on the page */
  function partBarHtml() {
    const L = report() || {}, d = ds();
    if (S.sel === "separator") {
      const s = L.separator || [0, 0, 0, 0];
      return `<span class="ics-chip">Separator</span>${col("dynamic_settings.game_rules_separator_rgb", d.game_rules_separator_rgb || "#ffffff", "Colour")}
        <span class="ts-lbl">Width</span>${num("dynamic_settings.game_rules_separator_width", Math.round(s[2]), "Width (px)", 10, 4000, "px")}
        <span class="ts-lbl">Height</span>${num("dynamic_settings.game_rules_separator_height", Math.round(s[3]), "Thickness (px)", 1, 200, "px")}
        ${sep}${fxSel('data-set="dynamic_settings.game_rules_separator_fx"', d.game_rules_separator_fx || "")}<span class="ts-hint">drag its ends: width · its bottom edge: thickness</span>`;
    }
    if (S.sel === "xtra") {
      const x = L.xtra || {};
      return `<span class="ics-chip">XTRAA REELS icons</span><span class="ts-lbl">Size</span>${num("dynamic_settings.game_rules_xtra_reels_width", x.width || 100, "Width of each icon (px)", 10, 2000, "px")}
        <span class="ts-lbl">In from the edge</span>${num("dynamic_settings.game_rules_xtra_reels_outer_margin", Math.round(x.outer || 0), "Both icons' distance from their page edge (px)", 0, 2000, "px")}
        <span class="ts-lbl">Up / down</span>${num("dynamic_settings.game_rules_xtra_reels_y_offset", d.game_rules_xtra_reels_y_offset || 0, "Both icons up (−) / down (+)", -2000, 2000, "px")}
        ${xtraTicks(x)}<button class="ts-tgt" data-xrpick>Choose icon…</button><span class="ts-hint">drag an icon: both move together · its corner: the size</span>`;
    }
    return "";
  }
  /* a Bingo row picked (double-click it; Shift: more): its alignment, size, colour */
  function rowBarHtml() {
    const L = report() || {}, d = ds(), cells = [...S.rows];
    if (!cells.length) return `<span class="ts-hint">Double-click a row on the page</span>`;
    const st = (d.bingo_rules_line_styles || {})[cells[0]] || {}, c0 = (L.cells || []).find((c) => c.cell === cells[0]) || {};
    const al = new Set(cells.map(cellAlign)), on = al.size === 1 ? [...al][0] : "";   // several rows aligned differently: none lit
    return `<span class="ics-chip">${cells.length > 1 ? `${cells.length} rows` : `Row ${esc(cells[0])}`}</span>
      ${[["left", "⯇≡", "Left"], ["center", "≡", "Centre"], ["right", "≡⯈", "Right"]].map(([a, ic, t]) => `<button class="ts-al ${on === a ? "on" : ""}" data-align="${a}" title="${t}">${ic}</button>`).join("")}
      <button class="ts-tgt" data-align="default" title="Back to the paragraph's alignment">Default</button>${sep}
      <span class="ts-lbl">Size</span><input class="ts-size ts-narrow" type="number" data-rowset="size" value="${esc(st.size || c0.size || "")}" min="6" max="300" title="This row's size (px)"><span class="ts-unit">px</span>
      <input type="color" class="rlc-col" data-rowset="rgb" value="${esc(hex(st.rgb || c0.rgb) || hex(d.bingo_rules_rgb) || "#ffffff")}" title="This row's colour">
      <button class="ts-tgt" data-rowreset title="The paragraph's size and colour again">Reset</button>
      <span class="ts-hint">typing here · Shift+double-click: more rows · Esc = back to the paragraph</span>`;
  }
  // a Bingo cell's alignment now: its own (the three lists, as png_builder._bingo_merged_alignments reads
  // them: centre wins over right over left) — else as the page drew it, else the paragraph's
  const inList = (key, cell) => String(ds()[key] || "").split(/[\s,;]+/).some((c) => c.trim().toUpperCase() === cell);
  function cellAlign(cell) {
    for (const a of ["center", "right", "left"]) if (inList(ALIGN_KEYS[a], cell)) return a;
    const c = ((report() || {}).cells || []).find((x) => x.cell === cell);
    return (c && c.align) || paraAlign("bingo");
  }
  /* a paragraph's alignment as drawn: its own setting, else what its lines show (all the same), else
     the page's default — the top bar lights that one */
  function paraAlign(target) {
    const d = ds(), own = { gr_rules: d.game_rules_body_align, gr_legal: d.game_rules_legal_align, bingo: d.bingo_rules_align }[target];
    if (own) return String(own);
    if (target === "bingo") return String((report() || {}).default_align || "center");
    const els = ((window.AppLive && AppLive.state.elements) || []).filter((e) => e.kind === "line" && e.cell
      && ((e.meta || {}).part === "legal") === (target === "gr_legal"));
    const al = new Set(els.map((e) => (e.align === "justify" ? "left" : e.align)));
    return al.size === 1 ? [...al][0] : "center";
  }
  function pickCells(cells, add) {
    if (!add) S.rows = new Set();
    (cells || []).forEach((c) => S.rows.add(c));
    S.sel = null;
    paintFrames();
  }
  function wireBar(root) {
    root.querySelectorAll("[data-set]").forEach((c) => c.addEventListener("change", () => save(c.dataset.set, c.type === "number" ? Number(c.value) : c.value)));
    root.querySelectorAll("[data-build]").forEach((c) => c.addEventListener("change", () => { App.set(c.dataset.build, c.checked); App.pushConfig(); }));
    root.querySelectorAll("[data-xrside]").forEach((c) => c.addEventListener("change", () => {
      save(`dynamic_settings.game_rules_xtra_reels_${c.dataset.xrside}`, c.checked);
      if (c.checked && !((report() || {}).xtra || {}).asset) { toast("No XTRAA REELS picture found yet — choose one."); pickXtra(); }
    }));
    root.querySelector("[data-xrauto]")?.addEventListener("click", () => { delete ds().game_rules_xtra_reels_left; delete ds().game_rules_xtra_reels_right; App.pushConfig(); redrawSoon(); });
    root.querySelectorAll("[data-xrpick]").forEach((b) => b.addEventListener("click", () => pickXtra()));
    root.querySelector("[data-cleansp]")?.addEventListener("click", () => { save("dynamic_settings.bingo_rules_clean_spaces", !ds().bingo_rules_clean_spaces); repaintBar(); });
    root.querySelector("[data-legalauto]")?.addEventListener("click", () => setLegal(null));
    root.querySelectorAll("[data-strip]").forEach((b) => b.addEventListener("click", () => {
      const k = b.dataset.strip, s = Object.assign({ fill: "#000000", fill_opacity: 60, pad: 12, radius: 0 }, ds()[k] || {});
      s.on = !s.on;
      ds()[k] = s;
      App.pushConfig();
      repaintBar();
      redrawSoon();
    }));
    root.querySelectorAll("[data-align]").forEach((b) => b.addEventListener("click", () => setAlign(b.dataset.align)));
    root.querySelectorAll("[data-rowset]").forEach((c) => c.addEventListener("change", () => {
      const all = (ds().bingo_rules_line_styles = Object.assign({}, ds().bingo_rules_line_styles || {}));
      S.rows.forEach((cell) => { all[cell] = Object.assign({}, all[cell] || {}, { [c.dataset.rowset]: c.dataset.rowset === "size" ? Math.max(6, Number(c.value) || 0) : c.value }); });
      App.pushConfig();
      redrawSoon();
    }));
    root.querySelector("[data-rowreset]")?.addEventListener("click", () => {
      const all = Object.assign({}, ds().bingo_rules_line_styles || {});
      S.rows.forEach((cell) => { delete all[cell]; });
      ds().bingo_rules_line_styles = all;
      App.pushConfig();
      redrawSoon();
    });
    if (window.LSSwatch && LSSwatch.enhance) LSSwatch.enhance(root);
  }
  const repaintBar = () => { if (window.TypoStudio) TypoStudio.paint(); };
  // the XTRAA REELS picture: from the symbols folder (or this PC), like any other symbol's
  function pickXtra() {
    if (!window.IconStudio || !IconStudio.mapDialog) { App.browse("dynamic_settings.game_rules_xtra_reels_asset", "file"); return; }
    IconStudio.mapDialog("XTRAA REELS", !!((report() || {}).xtra || {}).asset, {
      title: "The XTRAA REELS icon", hint: "Pick its picture from your symbols folder, or open any image on this PC. It shows left / right of the Game Rules text.",
      onPick: async (path) => { save("dynamic_settings.game_rules_xtra_reels_asset", path); toast("XTRAA REELS: " + String(path).split(/[\\/]/).pop()); },
    });
  }
  // the rows' alignment: each cell in at most one of the three lists; "default" = in none
  function setAlign(al) {
    const cells = [...S.rows], d = ds();
    if (!cells.length) return;
    for (const [k, key] of Object.entries(ALIGN_KEYS)) {
      const list = String(d[key] || "").split(/[\s,;]+/).map((c) => c.trim().toUpperCase()).filter(Boolean).filter((c) => !cells.includes(c));
      if (al === k) list.push(...cells);
      d[key] = list.join(", ");
    }
    if (al === "default") {
      // the built-in defaults (B27/B28 left, H27/H28 right) don't apply to a cell put back on purpose
      const keep = String(d[ALIGN_KEYS.center] || "").split(/[\s,;]+/).filter(Boolean);
      const builtIn = ["B27", "B28", "H27", "H28"].filter((c) => cells.includes(c));
      if (builtIn.length && ((report() || {}).default_align || "center") === "center") d[ALIGN_KEYS.center] = keep.concat(builtIn).join(", ");
    }
    App.pushConfig();
    repaintBar();                                      // the buttons show it at once
    redrawSoon();
  }

  function deselect(partOnly) {
    if (!S.sel && (partOnly || !S.rows.size)) return false;
    S.sel = null;
    if (!partOnly) S.rows = new Set();
    paintFrames();
    return true;
  }
  return { setSheets, isRules, on, kind, report, paintFrames, paraAlign, lineMenu, extraHtml, pageBarHtml, partBarHtml, rowBarHtml,
           pickCells, wireBar, deselect, state: S };
})();
