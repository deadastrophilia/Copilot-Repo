/* Symbols from a PSD + the AGR it was made from (symbol_match.py).
   Pick the symbol PSD and, optionally, the AGR that PSD was made from. The tool names each picture the
   way Clone a Market does (the text rows, the pay cards, the layer names) and matches it to this game's
   symbols. The review: every symbol of this game with its picture, how sure the tool is and why, a
   picture to swap, the pictures nobody took. "Good to go" saves one PNG per symbol, named after it, into
   the game's Symbols folder (asked, pre-filled) and links them: the Canvas shows them at once.
   Uses app.js globals (App, esc, toast, api). */
window.SymAgr = (() => {
  "use strict";
  const S = { psd: "", agr: "", busy: false, error: "", res: null, folder: "", pick: {}, open: false };

  function overlay() {
    let ov = document.getElementById("symAgrOverlay");
    if (!ov) {
      ov = document.createElement("div");
      ov.id = "symAgrOverlay";
      ov.className = "gm-overlay";
      ov.hidden = true;
      document.body.appendChild(ov);          // a click outside never closes it: its ✕ / Cancel do
    }
    return ov;
  }
  const thumb = (key) => key ? `/api/symbols/thumb?psd_path=${encodeURIComponent(S.psd)}&key=${encodeURIComponent(key)}` : "";
  const CONF = { high: ["sure", "#2e7d32"], medium: ["likely", "#b26a00"], low: ["guess", "#b26a00"], none: ["none", "#9e2a2a"] };

  // opts: {onSaved(saved), onCancel()} — the symbol mapper / the build's check wait on it
  function open(opts) {
    opts = opts || {};
    const c = App.state.config || {};
    S.onSaved = opts.onSaved || null;
    S.onCancel = opts.onCancel || null;
    S.psd = opts.psd || S.psd || "";
    if (opts.agr != null) S.agr = opts.agr;
    S.agr = S.agr || "";
    S.res = null; S.error = ""; S.pick = {}; S.folder = "";
    S.open = true;
    S.excel = c.excel_path || "";
    paint();
    if (opts.auto && S.psd) match();                  // opened with the PSD (and AGR) given: match at once
  }
  function close(saved) {
    const was = S.open;
    S.open = false;
    overlay().hidden = true;
    if (!was) return;
    const cb = saved ? S.onSaved : S.onCancel;
    S.onSaved = S.onCancel = null;
    if (cb) { try { cb(saved ? true : undefined); } catch (e) { /* the caller's */ } }
  }

  function pickRow(r) {
    const key = r.token in S.pick ? S.pick[r.token] : r.key;
    const pics = (S.res.symbols || []);
    const conf = r.token in S.pick && S.pick[r.token] !== r.key ? ["your pick", "#1565c0"] : CONF[r.confidence] || CONF.none;
    const why = r.token in S.pick && S.pick[r.token] !== r.key ? "picked by you" : r.why + (r.agr_token && r.agr_token !== r.token ? ` (the AGR's <${r.agr_token}>)` : "")
      + (r.others && r.others.length ? ` — the same picture is also <${r.others.join(">, <")}>` : "");
    const exists = (S.res.existing || {})[r.token];
    return `<tr>
      <td class="sa-img">${key ? `<img src="${thumb(key)}" alt="">` : `<span class="sa-none">—</span>`}</td>
      <td><b>&lt;${esc(r.token)}&gt;</b>${exists ? ` <span class="hint" title="A file with this symbol's name is already in the folder: the same picture is reused, a different one asks replace / keep">file there</span>` : ""}</td>
      <td><span class="sa-conf" style="background:${conf[1]}">${conf[0]}</span> <span class="hint">${esc(why)}</span></td>
      <td><select class="form-control sa-pick" data-tok="${esc(r.token)}">
        <option value="">— no picture —</option>
        ${pics.map((p) => `<option value="${esc(p.key)}" ${p.key === key ? "selected" : ""}>${esc(p.name || p.key)} (${p.w}×${p.h})</option>`).join("")}
      </select></td></tr>`;
  }

  // what needs a look first: no picture, guessed, likely, then the sure ones
  const RANK = { none: 0, low: 1, medium: 2, high: 3 };
  const ordered = (rows) => rows.slice().sort((a, b) => (RANK[a.confidence] ?? 0) - (RANK[b.confidence] ?? 0)
    || String(a.token).localeCompare(String(b.token)));

  function paint() {
    const ov = overlay();
    if (!S.open) { ov.hidden = true; return; }
    const r = S.res;
    const used = r ? new Set(r.rows.map((x) => (x.token in S.pick ? S.pick[x.token] : x.key)).filter(Boolean)) : new Set();
    const unused = r ? (r.symbols || []).filter((p) => !used.has(p.key)) : [];
    const counts = r ? r.rows.reduce((o, x) => { const k = x.token in S.pick ? (S.pick[x.token] ? "picked" : "none") : x.confidence; o[k] = (o[k] || 0) + 1; return o; }, {}) : {};
    ov.innerHTML = `<div class="gm-dialog sym-need sa-dialog">
      <div class="gm-dhead"><b>Symbols from a PSD</b><button class="gm-x" data-x>✕</button></div>
      <div class="gm-dbody">
        <div class="sa-row"><span class="sa-lab">Symbol PSD</span>
          <input class="form-control" data-f="psd" value="${esc(S.psd)}" placeholder="The Photoshop file that has this game's symbols">
          <button class="btn secondary" data-browse="psd">Browse…</button></div>
        <div class="sa-row"><span class="sa-lab">AGR it was made from</span>
          <input class="form-control" data-f="agr" value="${esc(S.agr)}" placeholder="Optional — the Excel this PSD was made from: each picture is named from its text">
          <button class="btn secondary" data-browse="agr">Browse…</button>
          ${S.excel ? `<button class="btn secondary" data-same title="${esc(S.excel)}">This game's</button>` : ""}</div>
        <div class="sa-row"><span class="sa-lab"></span><button class="btn primary" data-match ${S.busy ? "disabled" : ""}>${S.busy ? "Reading the PSD…" : r ? "Match again" : "Find the symbols"}</button>
          <span class="hint">Without the AGR only the layer names can tell which picture is which.</span></div>
        ${S.error ? `<div class="gm-error">${esc(S.error)}</div>` : ""}
        ${r ? `
          <div class="sa-sum">${r.rows.length} symbols in this game ·
            ${["high", "medium", "low", "picked", "none"].filter((k) => counts[k]).map((k) => `<b>${counts[k]}</b> ${({ high: "sure", medium: "likely", low: "guessed", picked: "picked by you", none: "without a picture" })[k]}`).join(" · ")}
            ${r.not_in_game && r.not_in_game.length ? ` · the AGR also has ${r.not_in_game.length} this game doesn't use` : ""}</div>
          <div class="sa-table-wrap"><table class="sa-table"><thead><tr><th></th><th>Symbol</th><th>How sure</th><th>Picture</th></tr></thead>
            <tbody>${ordered(r.rows).map(pickRow).join("")}</tbody></table></div>
          ${unused.length ? `<div class="sa-lab2">Pictures no symbol took (${unused.length})</div>
            <div class="sa-unused">${unused.map((p) => `<span class="sa-u" title="${esc(p.name)} — ${p.w}×${p.h}${p.pages && p.pages.length ? " · " + esc(p.pages.join(", ")) : ""}"><img src="${thumb(p.key)}" alt=""><i>${esc(p.name || p.key)}</i></span>`).join("")}</div>` : ""}
          <div class="sa-row sa-save"><span class="sa-lab">Save into</span>
            <input class="form-control" data-f="folder" value="${esc(S.folder || r.symbols_dir || "")}" placeholder="The game's Symbols folder (one for every market)">
            <button class="btn secondary" data-browse="folder">Browse…</button></div>
          <div class="hint">One PNG per symbol, named after it (&lt;OVERLAYx1&gt; and &lt;OVERLAYx2&gt; are two files even with the same picture). A file already there with the same picture is reused; a different one asks.</div>` : ""}
      </div>
      <div class="gm-dfoot">
        <button class="btn secondary" data-byhand title="Pick and name the pictures yourself (the earlier picker)">Pick by hand instead</button>
        <span style="flex:1"></span>
        <button class="btn secondary" data-x>Cancel</button>
        ${r ? `<button class="btn primary" data-go ${S.busy ? "disabled" : ""}>Good to go</button>` : ""}
      </div></div>`;
    ov.hidden = false;
    wire(ov);
  }

  function wire(ov) {
    ov.querySelectorAll("[data-x]").forEach((b) => b.addEventListener("click", () => close(false)));
    ov.querySelectorAll("[data-f]").forEach((i) => i.addEventListener("input", () => {
      S[i.dataset.f] = i.value.trim().replace(/^"|"$/g, "");
    }));
    ov.querySelectorAll("[data-browse]").forEach((b) => b.addEventListener("click", () => {
      const f = b.dataset.browse;
      App.pickPath(f === "psd" ? "psd" : f === "agr" ? "excel" : "dir", (p) => {
        if (!p) return;
        S[f] = p;
        paint();
      });
    }));
    ov.querySelector("[data-same]")?.addEventListener("click", () => { S.agr = S.excel; paint(); });
    ov.querySelector("[data-match]")?.addEventListener("click", match);
    ov.querySelector("[data-go]")?.addEventListener("click", () => save({}));
    ov.querySelector("[data-byhand]")?.addEventListener("click", () => {
      const cbs = { onSaved: S.onSaved || undefined, onCancel: S.onCancel || undefined };
      S.onSaved = S.onCancel = null;                     // handed on to the hand picker
      close(false);
      if (window.SymExport) SymExport.open(cbs);
    });
    ov.querySelectorAll(".sa-pick").forEach((sel) => sel.addEventListener("change", () => {
      S.pick[sel.dataset.tok] = sel.value;
      paint();
    }));
  }

  async function match() {
    if (!S.psd) { S.error = "Choose the symbol PSD first."; paint(); return; }
    S.busy = true; S.error = ""; paint();
    try {
      S.res = await api("/api/symbols/agr_match", { method: "POST", body: { psd_path: S.psd, agr_path: S.agr } });
      S.pick = {};
      S.folder = S.res.symbols_dir || "";
    } catch (e) {
      S.error = e.message || "Could not read the PSD.";
    }
    S.busy = false;
    paint();
  }

  async function save(choices) {
    const picks = S.res.rows.map((r) => ({ token: r.token, key: r.token in S.pick ? S.pick[r.token] : r.key })).filter((p) => p.key);
    if (!picks.length) { S.error = "No symbol has a picture yet."; paint(); return; }
    if (!S.folder) { S.error = "Choose the folder to save the symbols in."; paint(); return; }
    S.busy = true; S.error = ""; paint();
    const res = await fetch("/api/symbols/agr_save", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ psd_path: S.psd, picks, folder: S.folder, choices }) });
    const d = await res.json().catch(() => ({}));
    S.busy = false;
    if (res.status === 409 && d.needs_choice) {
      const got = await askChoices(d.ask || [], choices);
      if (!got) { paint(); return; }
      return save(got);
    }
    if (!res.ok || !d.ok) { S.error = d.error || `Saving failed (${res.status})`; paint(); return; }
    if (d.config) App.state.config = d.config;
    close(true);
    const n = (d.saved || []).length, same = (d.reused || []).length, kept = (d.kept || []).length;
    toast(`Symbols ready: ${n} saved${same ? `, ${same} already there` : ""}${kept ? `, ${kept} kept as they were` : ""} — in ${d.folder}.`);
    try { if (App.scan) await App.scan(); } catch (e) { /* the toast says enough */ }
    try { if (window.AppTypoVis && AppTypoVis.refreshPreview) AppTypoVis.refreshPreview(true); } catch (e) { /* not on the Canvas */ }
    try { if (window.AppLive && AppLive.refreshData) AppLive.refreshData(true); } catch (e) { /* not drawn */ }
  }

  // a different picture already has a symbol's file name: replace it or keep it, symbol by symbol
  function askChoices(ask, prev) {
    return new Promise((resolve) => {
      const ov = document.createElement("div");
      ov.className = "gm-overlay";
      ov.style.zIndex = "10100";
      ov.innerHTML = `<div class="gm-dialog sym-need"><div class="gm-dhead"><b>Another picture has these names</b></div>
        <div class="gm-dbody"><div>These files are already in the folder with a different picture. For each: replace it with the PSD's, or keep the one that is there.</div>
          <table class="sa-table">${ask.map((a, i) => `<tr><td><b>${esc(a.file)}</b></td>
            <td><label><input type="radio" name="sa${i}" value="replace" checked> Replace</label>
                <label><input type="radio" name="sa${i}" value="keep"> Keep</label></td></tr>`).join("")}</table></div>
        <div class="gm-dfoot"><button class="btn secondary" data-c>Cancel</button><button class="btn primary" data-ok>Save</button></div></div>`;
      document.body.appendChild(ov);
      ov.querySelector("[data-c]").addEventListener("click", () => { ov.remove(); resolve(null); });
      ov.querySelector("[data-ok]").addEventListener("click", () => {
        const out = Object.assign({}, prev || {});
        ask.forEach((a, i) => { out[a.token] = (ov.querySelector(`input[name="sa${i}"]:checked`) || {}).value || "keep"; });
        ov.remove();
        resolve(out);
      });
    });
  }

  return { open, close };
})();
