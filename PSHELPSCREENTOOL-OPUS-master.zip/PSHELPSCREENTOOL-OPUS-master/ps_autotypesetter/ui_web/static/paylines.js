/* Paylines / Win Lines studio.
   The pages are generated from the Excel's "Line | Reel1 … Reel5" table, one
   page per payline count of the Denom / Paylines table (50, 25, 5… — whatever
   the Excel lists). The user ticks which pages are built ("pages_off").

   Left card: Excel status, pages to build, the look (grid, colours, badge).
   Preview (sticky): everything about layout is edited ON the box drawn around
   the paylines —
     drag inside        move the block (snaps to the page centre, guide lines)
     ↔ side handles     paylines per row (snaps to whole columns)
     ↕ bottom handle    row spacing
     corner handles     resize everything (cells, badges, spacing) together
     toolbar            align, per row, Fit to page, undo/redo, ⋯ exact numbers
   Undo/redo (Ctrl+Z / Ctrl+Y) covers every change made in this view.
   Everything saves into dynamic_settings.paylines (per game) and re-renders
   with the real renderer (/api/paylines/preview).
   Uses app.js globals (App, api, esc, toast, icon, debounce). */
(() => {
  "use strict";
  const Paylines = (window.Paylines = {});
  const P = { info: null, page: 0, sheet: "", pop: false, undo: [], redo: [], lastRec: 0, lastKey: "" };

  // scaled together by the corner handles / Fit to page
  const SIZE_KEYS = ["cell_w", "cell_h", "cell_gap", "outline", "cell_radius", "pitch_x", "pitch_y", "badge_w", "badge_h",
                     "badge_dx", "badge_dy", "badge_radius", "badge_stroke", "badge_font_size", "badge_text_dy"];
  const SNAP_PX = 10;            // screen px

  // exact numbers, in the ⋯ popover on the box
  const LAYOUT = [
    ["columns", "Paylines per row", "number", 1, 50],
    ["pitch_x", "Horizontal spacing", "number", 1, 2000, "Grid to grid, left to right"],
    ["pitch_y", "Vertical spacing", "number", 1, 2000, "Row to row"],
    ["last_row", "Short last row", "select", [["left", "Left aligned"], ["center", "Centred"]]],
    ["offset_x", "Move sideways", "number", -2000, 2000, "Pixels; + moves right"],
    ["top", "Top of first row", "number", 0, 5000, "Where the first row starts"],
    ["bottom", "Lowest bottom", "number", 0, 5000, "Tall blocks move up to stay above this"],
  ];

  // the look: left card
  const LOOK = [
    ["Page", [
      ["heading_text", "Heading text", "text"],
      ["page_name", "Page name", "text", null, null, "{sheet}, {count}, {denoms}"],
    ]],
    ["Grid", [
      ["rows", "Rows per reel", "number", 1, 8],
      ["cell_w", "Cell width", "number", 1, 400],
      ["cell_h", "Cell height", "number", 1, 400],
      ["cell_gap", "Line between cells", "number", 0, 50],
      ["outline", "Outer edge", "number", 0, 20],
      ["cell_radius", "Cell corners", "number", 0, 100],
      ["cell_rgb", "Cell colour", "color"],
      ["gap_rgb", "Grid line colour", "color"],
      ["outline_rgb", "Edge colour", "color"],
      ["highlight_mode", "Highlight colour", "select", [["line", "Per line (palette)"], ["fixed", "One colour"]]],
      ["highlight_rgb", "Highlight (one colour)", "color"],
    ]],
    ["Badge", [
      ["badge_w", "Width", "number", 1, 400],
      ["badge_h", "Height", "number", 1, 400],
      ["badge_dx", "From grid left", "number", -400, 400],
      ["badge_dy", "From grid top", "number", -400, 400],
      ["badge_radius", "Corners", "number", 0, 200],
      ["badge_stroke", "Outline", "number", 0, 30],
      ["badge_stroke_rgb", "Outline colour", "color"],
      ["badge_color_mode", "Badge colour", "select", [["line", "Same as the line"], ["fixed", "One colour"]]],
      ["badge_rgb", "Badge (one colour)", "color"],
      ["badge_gloss", "Glossy shine", "check"],
      ["badge_font", "Number font", "text"],
      ["badge_font_size", "Number size", "number", 4, 300],
      ["badge_text_rgb", "Number colour", "color"],
      ["badge_text_dy", "Number up/down", "number", -100, 100],
      ["badge_shadow", "Number outline + shadow", "check"],
    ]],
  ];

  const saved = () => ((App.state.config.dynamic_settings || {}).paylines) || {};
  const value = (k) => {
    const s = saved();
    if (s[k] !== undefined && s[k] !== "") return s[k];
    return P.info && P.info.settings ? P.info.settings[k] : "";
  };
  const num = (k) => Number(value(k)) || 0;
  const pages = () => (P.info && P.info.pages) || [];
  const L = () => (P.info && P.info.layout) || null;

  /* ---------------- settings + undo ---------------- */
  function record(key) {
    const now = Date.now();
    if (key && key === P.lastKey && now - P.lastRec < 800) return;     // typing into one field = one step
    P.undo.push(JSON.stringify(saved()));
    if (P.undo.length > 100) P.undo.shift();
    P.redo = [];
    P.lastRec = now;
    P.lastKey = key || "";
  }

  function store(obj) {
    const ds = App.state.config.dynamic_settings || (App.state.config.dynamic_settings = {});
    ds.paylines = obj;
    App.pushConfig();
  }

  function setKeys(obj, { refresh = true, key = "" } = {}) {
    record(key);
    store(Object.assign({}, saved(), obj));
    if (refresh) Paylines.refresh();
  }
  const setKey = (k, v) => setKeys({ [k]: v }, { key: k });

  function step(from, to) {
    if (!from.length) { toast("Nothing to " + (from === P.undo ? "undo" : "redo") + ".", "warn"); return; }
    to.push(JSON.stringify(saved()));
    store(JSON.parse(from.pop()));
    P.lastKey = "";
    Paylines.refresh(true);
  }
  Paylines.undo = () => step(P.undo, P.redo);
  Paylines.redo = () => step(P.redo, P.undo);

  /* ---------------- left card ---------------- */
  function control(f) {
    const [k, label, type, a, b, hint] = f;
    const v = value(k);
    const changed = saved()[k] !== undefined;
    let input;
    if (type === "select") {
      input = `<select data-pl="${k}">${a.map(([o, t]) => `<option value="${o}" ${String(o) === String(v) ? "selected" : ""}>${esc(t)}</option>`).join("")}</select>`;
    } else if (type === "color") {
      input = `<input type="color" data-pl="${k}" value="${esc(v || "#ffffff")}">`;
    } else if (type === "check") {
      input = `<label class="switch"><input type="checkbox" data-pl="${k}" ${v ? "checked" : ""}><span class="track"></span></label>`;
    } else {
      input = `<input type="${type}" data-pl="${k}" value="${esc(v)}" ${type === "number" ? `min="${a}" max="${b}" step="1"` : ""}>`;
    }
    return `<div class="field pl-field${changed ? " changed" : ""}" title="${esc(hint || (changed ? "Changed for this game" : "Default"))}"><label>${esc(label)}</label>${input}</div>`;
  }

  function palette() {
    const pal = value("palette") || [];
    return `<div class="pl-palette">${pal.map((c, i) => `<input type="color" data-pal="${i}" value="${esc(c)}" title="Line ${i + 1}">`).join("")}
      <button class="btn secondary small" onclick="Paylines.palAdd()" title="Add a colour">+</button>
      <button class="btn secondary small" onclick="Paylines.palDel()" title="Remove the last colour" ${pal.length > 1 ? "" : "disabled"}>−</button></div>
      <div class="hint">Line 1 uses the first colour, line 2 the second…; the list repeats when there are more lines.</div>`;
  }

  function pagePicker() {
    const ps = pages();
    if (!ps.length) return "";
    const on = ps.filter((p) => p.on).length;
    return `<div class="pt-ctl-label" style="margin:10px 0 6px"><span>Pages to build (${on} of ${ps.length})</span></div>
      <div class="pl-pages">${ps.map((p, i) => `<label class="pl-page${i === P.page ? " shown" : ""}">
          <input type="checkbox" data-plpage="${esc(p.key || p.count)}" data-plcount="${p.count}" ${p.on ? "checked" : ""}>
          <span class="pl-page-name">${esc(p.name)}</span>
          <span class="pl-page-meta">lines ${p.first || 1}–${p.last || p.count}${p.denoms ? ` · denom ${esc(p.denoms)}` : ""}</span>
          <button class="btn secondary small" data-plshow="${i}" title="Show this page in the preview">${i === P.page ? "Shown" : "Preview"}</button>
        </label>`).join("")}</div>
      <div class="pl-page-tools">
        <button class="btn secondary small" onclick="Paylines.allPages(true)">All</button>
        <button class="btn secondary small" onclick="Paylines.allPages(false)">None</button>
        <span class="hint">From the Excel (its Denom / Paylines table, or one page per payline sheet). Unticked pages are left out of PSD and PNG builds.</span>
      </div>`;
  }

  function status() {
    const d = P.info;
    if (!d) return `<div class="hint">Reading the Excel…</div>`;
    const errs = (d.errors || []).map((e) => `<li>${esc(e)}</li>`).join("");
    const warns = (d.warnings || []).map((e) => `<li>${esc(e)}</li>`).join("");
    return `${d.ok ? `<div class="pl-ok">✓ <b>${d.lines}</b> paylines (${d.reels} reels × ${d.rows || value("rows")} rows${d.form === "grid" ? ", read from the line grids" : ""}) in “${esc(d.sheet_name)}”.</div>` : `<div class="gm-error">${esc(d.error || "Can't build the payline pages.")}</div>`}
      ${errs ? `<ul class="pl-errs">${errs}</ul>` : ""}
      ${warns ? `<ul class="pl-warns">${warns}</ul>` : ""}`;
  }

  /* ---------------- preview stage ---------------- */
  function toolbar() {
    const l = L(), align = value("align") || "center";
    const max = Math.min(50, (l && l.max_count) || 10);
    const cols = Number(value("columns")) || 10;
    const al = (v, t, s) => `<button class="pl-tb-btn${align === v ? " on" : ""}" data-align="${v}" title="${t}">${s}</button>`;
    return `<div class="pl-toolbar" id="plToolbar">
        ${al("left", "Align left", "⇤")}${al("center", "Centre", "↔")}${al("right", "Align right", "⇥")}
        <span class="pl-tb-sep"></span>
        <label class="pl-tb-cols" title="Paylines per row">
          <select id="plCols">${Array.from({ length: max }, (_, i) => i + 1).map((n) => `<option value="${n}" ${n === cols ? "selected" : ""}>${n}</option>`).join("")}</select> per row</label>
        <span class="pl-tb-sep"></span>
        <button class="pl-tb-btn wide" id="plFit" title="Best paylines per row and size for the page">Fit to page</button>
        <span class="pl-tb-sep"></span>
        <button class="pl-tb-btn" id="plUndo" title="Undo (Ctrl+Z)" ${P.undo.length ? "" : "disabled"}>↶</button>
        <button class="pl-tb-btn" id="plRedo" title="Redo (Ctrl+Y)" ${P.redo.length ? "" : "disabled"}>↷</button>
        <button class="pl-tb-btn${P.pop ? " on" : ""}" id="plMore" title="Exact numbers">⋯</button>
      </div>`;
  }

  function stage() {
    const d = P.info;
    if (!(d && d.preview_token)) {
      return `<div class="empty" style="padding:48px"><div class="empty-icon">▦</div><div class="empty-title">${d && !d.ok ? "No preview" : "Preview pending"}</div><div class="empty-sub">${d && !d.ok ? esc(d.error || "") : "Rendering…"}</div></div>`;
    }
    return `<div class="pl-stage" id="plStage">
        <img class="pt-preview-img" id="plImg" src="/api/table_preview/${encodeURIComponent(d.preview_token)}" alt="Paylines preview" draggable="false">
        <div class="pl-guide v" id="plGuideV"></div><div class="pl-guide h" id="plGuideH"></div>
        <div class="pl-safe" id="plSafe"></div>
        <div class="pl-box" id="plBox" title="Drag to move · edges: per row · bottom: row spacing · corners: size">
          ${toolbar()}
          <span class="pl-box-tag" id="plTag"></span>
          <div class="pl-h side l" data-h="cols-l" title="Drag to change paylines per row">↔</div>
          <div class="pl-h side r" data-h="cols-r" title="Drag to change paylines per row">↔</div>
          <div class="pl-h bottom" data-h="rows" title="Drag to change row spacing">↕</div>
          <div class="pl-h corner tl" data-h="size-tl" title="Drag to resize"></div>
          <div class="pl-h corner tr" data-h="size-tr" title="Drag to resize"></div>
          <div class="pl-h corner bl" data-h="size-bl" title="Drag to resize"></div>
          <div class="pl-h corner br" data-h="size-br" title="Drag to resize"></div>
          <div class="pl-readout" id="plReadout"></div>
        </div>
        ${P.pop ? `<div class="pl-pop" id="plPop">
          <div class="pl-pop-head"><b>Exact numbers</b><button class="pl-tb-btn" id="plPopClose" title="Close">✕</button></div>
          <div class="pl-fields">${LAYOUT.map(control).join("")}</div>
          <div class="hint">Shared by every payline page of this game (each page shows at most its own number of lines per row).</div>
        </div>` : ""}
      </div>`;
  }

  /* canvas px <-> displayed px */
  function scale() {
    const d = P.info, img = document.getElementById("plImg");
    if (!d || !img || !img.clientWidth) return null;
    return { k: img.clientWidth / (d.canvas_width || img.naturalWidth || 1), ox: img.offsetLeft, oy: img.offsetTop, img };
  }

  const PAD = 6;
  function boxRect() {                       // displayed rect of the block (with padding)
    const sc = scale(), b = P.info && P.info.block;
    if (!sc || !b) return null;
    return { left: sc.ox + b[0] * sc.k - PAD, top: sc.oy + b[1] * sc.k - PAD,
             width: (b[2] - b[0]) * sc.k + 2 * PAD, height: (b[3] - b[1]) * sc.k + 2 * PAD };
  }

  function setRect(box, r) {
    box.style.left = `${r.left}px`;
    box.style.top = `${r.top}px`;
    box.style.width = `${Math.max(12, r.width)}px`;
    box.style.height = `${Math.max(12, r.height)}px`;
  }

  /* is the block inside the page's safe area (margins, below the heading)? */
  function unsafe(b) {
    const d = P.info, l = L();
    if (!d || !l || !b) return "";
    const W = d.canvas_width, H = d.canvas_height, m = l.margin_x || 0;
    if (b[0] < m - 1 || b[2] > W - m + 1) return "Outside the side margins";
    if (b[1] < (l.heading_bottom || 0)) return "Overlaps the heading";
    if (b[3] > H) return "Runs off the page";
    return "";
  }

  function updateBox() {
    const box = document.getElementById("plBox"), r = boxRect(), l = L();
    if (!box || !r || !l) return;
    setRect(box, r);
    placeToolbar(box, r);
    const bad = unsafe(P.info.block) || (l.fit_warning ? "Doesn't fit the page" : "");
    box.classList.toggle("unsafe", !!bad);
    const p = pages()[P.page];
    const tag = document.getElementById("plTag");
    if (tag) tag.textContent = `${l.cols} per row · ${l.nrows} row${l.nrows === 1 ? "" : "s"}${p && !p.on ? " · not built" : ""}${bad ? " · " + bad : ""}`;
    box.querySelector('[data-h="rows"]').style.display = l.nrows > 1 ? "" : "none";
    const sel = document.getElementById("plCols");
    if (sel) sel.value = String(Number(value("columns")) || l.cols);
    document.querySelectorAll("[data-align]").forEach((b) => b.classList.toggle("on", b.dataset.align === (value("align") || "center")));
    const u = document.getElementById("plUndo"), rd = document.getElementById("plRedo");
    if (u) u.disabled = !P.undo.length;
    if (rd) rd.disabled = !P.redo.length;
    // safe area outline (shown while dragging)
    const sc = scale(), safe = document.getElementById("plSafe");
    if (sc && safe) {
      const m = l.margin_x || 0, top = l.heading_bottom || 0;
      safe.style.left = `${sc.ox + m * sc.k}px`;
      safe.style.top = `${sc.oy + top * sc.k}px`;
      safe.style.width = `${(P.info.canvas_width - 2 * m) * sc.k}px`;
      safe.style.height = `${(P.info.canvas_height - top) * sc.k}px`;
    }
  }

  /* the toolbar never covers the heading: above the box, else below, else inside */
  function placeToolbar(box, r) {
    const sc = scale(), l = L();
    if (!sc || !l) return;
    const headingBottom = sc.oy + (l.heading_bottom || 0) * sc.k;
    const roomAbove = r.top - 40 >= Math.max(headingBottom, sc.oy - 34);
    const roomBelow = r.top + r.height + 44 <= sc.oy + sc.img.clientHeight + 34;
    box.classList.toggle("tb-below", !roomAbove && roomBelow);
    box.classList.toggle("tb-inside", !roomAbove && !roomBelow);
  }

  function readout(text) {
    const el = document.getElementById("plReadout");
    if (!el) return;
    el.textContent = text || "";
    el.style.display = text ? "block" : "none";
  }

  function guides(v, h) {
    const sc = scale(), gv = document.getElementById("plGuideV"), gh = document.getElementById("plGuideH");
    if (!sc || !gv || !gh) return;
    gv.style.display = v != null ? "block" : "none";
    gh.style.display = h != null ? "block" : "none";
    if (v != null) { gv.style.left = `${sc.ox + v * sc.k}px`; gv.style.top = `${sc.oy}px`; gv.style.height = `${sc.img.clientHeight}px`; }
    if (h != null) { gh.style.top = `${sc.oy + h * sc.k}px`; gh.style.left = `${sc.ox}px`; gh.style.width = `${sc.img.clientWidth}px`; }
  }

  /* ---------------- drag handling ---------------- */
  function startDrag(e) {
    if (e.button !== 0 || e.target.closest(".pl-toolbar")) return;
    const sc = scale(), l = L(), box = document.getElementById("plBox"), r = boxRect();
    if (!sc || !l || !box || !r) return;
    const mode = (e.target.closest("[data-h]") || {}).dataset?.h || "move";
    e.preventDefault();
    try { box.setPointerCapture(e.pointerId); } catch (_) { /* synthetic events */ }
    box.classList.add("dragging");
    document.getElementById("plStage").classList.add("dragging");
    const D = { mode, x: e.clientX, y: e.clientY, r, k: 1 / sc.k, l, result: null };
    const move = (ev) => { D.result = dragMove(D, ev.clientX - D.x, ev.clientY - D.y, box); };
    const up = (ev) => {
      box.removeEventListener("pointermove", move);
      box.removeEventListener("pointerup", up);
      box.removeEventListener("pointercancel", up);
      box.classList.remove("dragging");
      document.getElementById("plStage")?.classList.remove("dragging");
      if (ev.type === "pointerup") D.result = dragMove(D, ev.clientX - D.x, ev.clientY - D.y, box);
      guides(null, null);
      readout("");
      if (D.result && Object.keys(D.result).length) setKeys(D.result);
      else updateBox();
    };
    box.addEventListener("pointermove", move);
    box.addEventListener("pointerup", up);
    box.addEventListener("pointercancel", up);
  }

  /* live feedback; returns the settings to save on release (or null) */
  function dragMove(D, dxs, dys, box) {
    const d = P.info, l = D.l, k = D.k, b = d.block, r = D.r;
    const dx = dxs * k, dy = dys * k;                                   // canvas px
    const align = value("align") || "center";
    const px = num("pitch_x"), py = num("pitch_y");
    if (D.mode === "move") {
      if (Math.abs(dxs) < 2 && Math.abs(dys) < 2) { setRect(box, r); return null; }
      const W = d.canvas_width, cx = (b[0] + b[2]) / 2 + dx, cy = (b[1] + b[3]) / 2 + dy;
      const areaTop = l.heading_bottom || 0, areaBot = Math.min(d.canvas_height, num("bottom") || d.canvas_height);
      const midY = (areaTop + areaBot) / 2;
      const snapX = Math.abs(cx - W / 2) * (1 / k) < SNAP_PX, snapY = Math.abs(cy - midY) * (1 / k) < SNAP_PX;
      const fx = snapX ? W / 2 - (b[0] + b[2]) / 2 : dx, fy = snapY ? midY - (b[1] + b[3]) / 2 : dy;
      setRect(box, { left: r.left + fx / k, top: r.top + fy / k, width: r.width, height: r.height });
      guides(snapX ? W / 2 : null, snapY ? midY : null);
      const moved = [b[0] + fx, b[1] + fy, b[2] + fx, b[3] + fy];
      const bad = unsafe(moved);
      box.classList.toggle("unsafe", !!bad);
      readout(`${snapX ? "centred" : (fx >= 0 ? "+" : "") + Math.round(fx) + " px"} · ${snapY ? "middle" : (fy >= 0 ? "+" : "") + Math.round(fy) + " px"}${bad ? " · " + bad : ""}`);
      const gridTop = b[1] + Math.max(0, -num("badge_dy"));
      const top = Math.max(0, Math.round(gridTop + fy));
      const out = { top };
      if (snapX) { out.align = "center"; out.offset_x = 0; }
      else out.offset_x = Math.round(num("offset_x") + fx);
      const lowest = top + (b[3] - gridTop);
      if (lowest > num("bottom")) out.bottom = Math.round(lowest);          // keep it from snapping back up
      return out;
    }
    if (D.mode === "cols-l" || D.mode === "cols-r") {
      const sign = D.mode === "cols-r" ? 1 : -1;
      const grow = align === "center" ? 2 * sign * dx : (align === "left" ? (sign > 0 ? dx : 0) : (sign < 0 ? -dx : 0));
      const extra = (b[2] - b[0]) - ((l.cols - 1) * px + l.grid_w);         // badge overhang etc.
      const want = (b[2] - b[0]) + grow - extra;
      const cols = Math.max(1, Math.min(l.max_count || 50, Math.round((want - l.grid_w) / px) + 1));
      const shown = Math.min(cols, l.count);
      const w = ((shown - 1) * px + l.grid_w + extra) / k + 2 * PAD;
      const left = align === "center" ? r.left + (r.width - w) / 2 : (align === "left" ? r.left : r.left + r.width - w);
      const nrows = Math.ceil(l.count / shown);
      setRect(box, { left, top: r.top, width: w, height: ((nrows - 1) * py + (b[3] - b[1] - (l.nrows - 1) * py)) / k + 2 * PAD });
      readout(`${cols} per row · ${nrows} row${nrows === 1 ? "" : "s"}${cols > l.count ? ` (this page has ${l.count})` : ""}`);
      return cols !== (Number(value("columns")) || l.cols) ? { columns: cols } : null;
    }
    if (D.mode === "rows") {
      if (l.nrows < 2) return null;
      const pitch = Math.max(Math.round(l.grid_h * 0.6), Math.round(py + dy / (l.nrows - 1)));
      const h = (b[3] - b[1] + (pitch - py) * (l.nrows - 1)) / k + 2 * PAD;
      setRect(box, { left: r.left, top: r.top, width: r.width, height: h });
      readout(`row spacing ${pitch} px (gap ${pitch - l.grid_h} px)`);
      return pitch !== py ? { pitch_y: pitch } : null;
    }
    if (D.mode.startsWith("size-")) {
      const c = D.mode.slice(5), sx = c.includes("r") ? 1 : -1, sy = c.includes("b") ? 1 : -1;
      const bw = b[2] - b[0], bh = b[3] - b[1];
      let s = ((bw + sx * dx * (align === "center" ? 2 : 1)) / bw + (bh + sy * dy) / bh) / 2;
      s = Math.max(0.3, Math.min(3, s));
      const w = bw * s / k + 2 * PAD, h = bh * s / k + 2 * PAD;
      const left = align === "center" ? r.left + (r.width - w) / 2 : (sx > 0 ? r.left : r.left + r.width - w);
      const top = sy > 0 ? r.top : r.top + r.height - h;
      setRect(box, { left, top, width: w, height: h });
      readout(`size ${Math.round(s * 100)}%`);
      if (Math.abs(s - 1) < 0.01) return null;
      const out = scaled(s);
      if (sy < 0) out.top = Math.max(0, Math.round(num("top") + bh * (1 - s)));   // top corners keep the bottom edge
      return out;
    }
    return null;
  }

  function scaled(s) {
    const out = {};
    SIZE_KEYS.forEach((key) => {
      const v = num(key);
      let n = Math.round(v * s);
      if (v > 0 && n < 1) n = 1;                     // a 1px line stays visible
      if (v < 0 && n > -1) n = -1;
      out[key] = n;
    });
    return out;
  }

  /* best per-row count (and size, if needed) for the biggest page */
  Paylines.fit = () => {
    const d = P.info, l = L();
    if (!d || !l) return;
    const W = d.canvas_width, H = d.canvas_height, m = l.margin_x || 0;
    const above = Math.max(0, -num("badge_dy")), px = num("pitch_x"), py = num("pitch_y");
    const n = l.max_count || l.count;
    const y0 = (l.heading_bottom || 0) + 24, y1 = H - Math.max(40, Math.round(H * 0.07));
    const aw = W - 2 * m, ah = y1 - y0;
    let best = null;
    for (let cols = 1; cols <= n; cols++) {
      const rows = Math.ceil(n / cols);
      const bw = (cols - 1) * px + l.grid_w, bh = (rows - 1) * py + l.grid_h + above;
      const s = Math.min(1, aw / bw, ah / bh);
      const shape = Math.abs(Math.log((bw / bh) / (aw / ah)));
      if (!best || s > best.s + 1e-6 || (Math.abs(s - best.s) < 1e-6 && shape < best.shape)) best = { cols, rows, s, bw, bh, shape };
    }
    if (!best) return;
    const out = best.s < 0.999 ? scaled(best.s) : {};
    const s = best.s < 0.999 ? best.s : 1;
    const bh = best.bh * s, aboveS = above * s;
    const top = Math.round(y0 + (ah - bh) / 2 + aboveS);
    Object.assign(out, { columns: best.cols, align: "center", offset_x: 0, top, bottom: Math.round(top - aboveS + bh) + 1 });
    setKeys(out);
    toast(`Fitted for ${n} lines: ${best.cols} per row, ${best.rows} row${best.rows === 1 ? "" : "s"}${s < 1 ? `, ${Math.round(s * 100)}% size` : ""}.`);
  };

  /* ---------------- view ---------------- */
  Paylines.view = () => `
    <div class="view pl-view">
      <div class="view-header">
        <div class="view-title">Paylines</div>
        <div class="view-sub">Win line pages drawn from the Excel's payline table — one page per payline count. Every line is its own editable group in the PSD.</div>
      </div>
      <div class="pt-workspace"><div class="pt-grid">
        <div class="pt-card pt-c4 pl-settings-card">
          <div class="pt-card-head"><div class="pt-card-title"><span class="pt-chip">${icon("file")}</span><span>Excel</span></div></div>
          <div id="plStatus">${status()}</div>
          <div id="plPagePick">${pagePicker()}</div>
          <div class="divider"></div>
          ${LOOK.map(([title, fs]) => `<div class="pt-ctl-label" style="margin:6px 0 8px"><span>${title}</span></div>
            <div class="pl-fields">${fs.map(control).join("")}</div>
            ${title === "Grid" ? `<div class="pt-ctl-label" style="margin:10px 0 6px"><span>Line colours</span></div>${palette()}` : ""}
            <div class="divider"></div>`).join("")}
          <div class="hint" style="margin-bottom:8px">Layout is edited on the preview: drag the box to move it, its edges for paylines per row, the bottom for row spacing, the corners for size.</div>
          <div style="display:flex;gap:8px;align-items:center">
            <button class="btn secondary small" onclick="Paylines.reset()" title="Back to the reference look for this game">Reset to defaults</button>
            <span class="hint" style="flex:1">Saved for this game only. Blue labels = changed here.</span>
          </div>
        </div>
        <div class="pt-card pt-c8 pl-preview-card">
          <div class="pt-card-head">
            <div class="pt-card-title"><span class="pt-chip">${icon("image")}</span><span>Live Preview</span>
              <span class="pt-pill idle" id="plBadge">Rendering…</span></div>
            <div class="pt-card-sub">Same page builder as PNG and PSD builds. Heading font and style come from Canvas; background from Assets.</div>
          </div>
          <div class="pt-preview-head">
            <span class="pt-preview-name">${esc((pages()[P.page] || {}).name || "")}</span>
            <span style="flex:1"></span>
            ${((P.info && P.info.sheets) || []).length > 1 ? `<label style="font-size:12px;color:var(--pt-text2)">Sheet</label>
            <select id="plSheet" style="max-width:260px">${P.info.sheets.map((n) => `<option value="${esc(n)}" ${n === P.info.sheet_name ? "selected" : ""}>${esc(n)}</option>`).join("")}</select>` : ""}
            <label style="font-size:12px;color:var(--pt-text2)">Page</label>
            <select id="plPage" style="max-width:300px">${pages().map((p, i) => `<option value="${i}" ${i === P.page ? "selected" : ""}>${esc(p.name)}${p.on ? "" : " (not built)"}</option>`).join("") || `<option>—</option>`}</select>
          </div>
          <div class="pt-preview-wrap"><div class="pt-preview-canvas pl-canvas" id="plCanvas">${stage()}</div></div>
          ${firstTip()}
        </div>
      </div></div>
    </div>`;

  const TIP_KEY = "pshelp.paylines.tipSeen";
  function firstTip() {
    let seen = false;
    try { seen = !!localStorage.getItem(TIP_KEY); } catch (_) { /* private mode */ }
    if (seen) return "";
    return `<div class="pl-tip" id="plTip"><b>Edit right on the preview</b>
      <span>Drag inside the box to move · drag its <b>↔</b> edges for paylines per row · <b>↕</b> for row spacing · corners to resize · Ctrl+Z to undo.</span>
      <button class="btn secondary small" onclick="Paylines.tipDone()">Got it</button></div>`;
  }
  Paylines.tipDone = () => {
    try { localStorage.setItem(TIP_KEY, "1"); } catch (_) { /* private mode */ }
    document.getElementById("plTip")?.remove();
  };

  function rerender() {
    const ws = document.getElementById("workspace");
    if (!ws || App.route !== "paylines") return;
    const scroll = ws.scrollTop;
    ws.innerHTML = Paylines.view();
    ws.querySelector(".view")?.classList.add("no-anim");
    ws.scrollTop = scroll;
    wire(ws);
    wireStage();
  }

  function rebuildStage() {
    const canvas = document.getElementById("plCanvas");
    if (!canvas) return;
    canvas.innerHTML = stage();
    wire(canvas);
    wireStage();
  }

  function wire(root) {
    root.querySelectorAll("[data-pl]").forEach((el) => {
      if (el._plWired) return;
      el._plWired = true;
      const k = el.dataset.pl;
      const ev = el.type === "color" || el.type === "text" || el.type === "number" ? "input" : "change";
      el.addEventListener(ev, () => {
        let v = el.type === "checkbox" ? el.checked : el.value;
        if (el.type === "number") {
          if (el.value === "") return;
          v = Number(el.value);
          if (!Number.isFinite(v)) return;
        }
        setKey(k, v);
      });
    });
    root.querySelectorAll("[data-pal]").forEach((el) => el.addEventListener("input", () => {
      const pal = (value("palette") || []).slice();
      pal[Number(el.dataset.pal)] = el.value;
      setKeys({ palette: pal }, { key: "palette" + el.dataset.pal });
    }));
    root.querySelectorAll("[data-plpage]").forEach((el) => el.addEventListener("change", () => {
      // this sheet's page only ("Sheet|count"); an old switch by count alone covered every sheet
      const off = new Set((value("pages_off") || []).map(String));
      const key = el.dataset.plpage, n = String(el.dataset.plcount);
      if (el.checked) { off.delete(key); off.delete(n); } else off.add(key);
      setKeys({ pages_off: [...off] }, { refresh: false });
      pages().forEach((p) => { if ((p.key || String(p.count)) === key) p.on = el.checked; });
      rerender();
    }));
    root.querySelectorAll("[data-plshow]").forEach((el) => el.addEventListener("click", (e) => {
      e.preventDefault();
      P.page = Number(el.dataset.plshow) || 0;
      Paylines.refresh(true);
    }));
    const pg = root.querySelector("#plPage");
    if (pg) pg.addEventListener("change", () => { P.page = Number(pg.value) || 0; Paylines.refresh(true); });
    const sh = root.querySelector("#plSheet");
    if (sh) sh.addEventListener("change", () => { P.sheet = sh.value; P.page = 0; Paylines.refresh(true); });
  }

  function wireStage() {
    const img = document.getElementById("plImg");
    if (img) {
      if (img.complete) updateBox(); else img.addEventListener("load", updateBox, { once: true });
    }
    const box = document.getElementById("plBox");
    if (box) box.addEventListener("pointerdown", startDrag);
    document.querySelectorAll("[data-align]").forEach((b) => b.addEventListener("click", () => setKeys({ align: b.dataset.align, offset_x: 0 })));
    const cols = document.getElementById("plCols");
    if (cols) cols.addEventListener("change", () => setKeys({ columns: Number(cols.value) }));
    document.getElementById("plFit")?.addEventListener("click", Paylines.fit);
    document.getElementById("plUndo")?.addEventListener("click", Paylines.undo);
    document.getElementById("plRedo")?.addEventListener("click", Paylines.redo);
    document.getElementById("plMore")?.addEventListener("click", () => { P.pop = !P.pop; rebuildStage(); });
    document.getElementById("plPopClose")?.addEventListener("click", () => { P.pop = false; rebuildStage(); });
  }

  Paylines.allPages = (on) => {
    // this sheet's pages; the other payline sheets keep theirs
    const mine = new Set(pages().map((p) => p.key || String(p.count)));
    const off = (value("pages_off") || []).map(String).filter((k) => !mine.has(k) && !pages().some((p) => String(p.count) === k));
    setKeys({ pages_off: on ? off : off.concat([...mine]) }, { refresh: false });
    pages().forEach((p) => { p.on = on; });
    rerender();
  };
  Paylines.palAdd = () => { const pal = (value("palette") || []).slice(); pal.push("#ffffff"); setKeys({ palette: pal }); rerender(); };
  Paylines.palDel = () => { const pal = (value("palette") || []).slice(); if (pal.length > 1) pal.pop(); setKeys({ palette: pal }); rerender(); };
  Paylines.reset = async () => {
    const ok = await App.choose("Reset paylines settings?", "This game's paylines go back to the default look, and every page is built again. (Undo can bring your settings back.)",
      [{ label: "Cancel", value: false }, { label: "Reset", value: true, primary: true }]);
    if (!ok) return;
    record("");
    store({});
    await load();
    rerender();
  };

  async function load() {
    const badge = document.getElementById("plBadge");
    if (badge) badge.classList.remove("idle");
    try {
      P.info = await api("/api/paylines/preview", { method: "POST", body: { page: P.page, sheet_name: P.sheet, settings: saved() } });
    } catch (e) {
      P.info = { ok: false, error: e.message };
    }
    if (P.info && P.info.page !== undefined) P.page = P.info.page;
    if (P.info && P.info.sheet_name) P.sheet = P.info.sheet_name;
    if (badge) badge.classList.add("idle");
  }

  /* settings changed: refresh preview, box and status; inputs keep focus */
  Paylines.refresh = debounce(async (full) => {
    const before = JSON.stringify(pages().map((p) => [p.name, p.count]));
    await load();
    if (full || before !== JSON.stringify(pages().map((p) => [p.name, p.count]))) { rerender(); return; }
    const st = document.getElementById("plStatus");
    if (st) st.innerHTML = status();
    // numbers changed elsewhere (drag, toolbar) show up in the open popover / left card
    document.querySelectorAll("[data-pl]").forEach((el) => {
      if (el === document.activeElement || el.type === "checkbox") return;
      const v = value(el.dataset.pl);
      if (String(el.value) !== String(v)) el.value = v;
    });
    const img = document.getElementById("plImg");
    if (img && P.info.preview_token) {
      img.addEventListener("load", updateBox, { once: true });
      img.src = `/api/table_preview/${encodeURIComponent(P.info.preview_token)}`;
    } else {
      rebuildStage();
    }
  }, 300);

  window.addEventListener("resize", () => { if (App.route === "paylines") updateBox(); });
  document.addEventListener("keydown", (e) => {
    if (App.route !== "paylines" || !(e.ctrlKey || e.metaKey)) return;
    if (e.target.closest && e.target.closest("input, textarea, select")) return;
    const key = e.key.toLowerCase();
    if (key === "z" && !e.shiftKey) { e.preventDefault(); Paylines.undo(); }
    else if (key === "y" || (key === "z" && e.shiftKey)) { e.preventDefault(); Paylines.redo(); }
  });

  Paylines.init = async () => {
    await load();
    rerender();
  };
})();
