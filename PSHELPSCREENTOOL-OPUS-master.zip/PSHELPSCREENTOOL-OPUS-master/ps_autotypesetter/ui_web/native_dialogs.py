"""Native Windows open dialogs for the browser version of the tool.

A browser can't hand a page the full path of a picked folder or file (only its
name), so "Browse…" did nothing useful outside the desktop window. The server
runs on the user's own machine, so it opens the real dialog itself (tkinter,
always on top) and returns the full path. Paths picked here are trusted the
same way as the desktop window's dialogs (path_policy.grant).
"""
import threading

_FILETYPES = {
    "excel": [("Excel workbooks", "*.xlsx *.xlsm *.xls"), ("All files", "*.*")],
    "image": [("Images", "*.png *.jpg *.jpeg *.bmp *.webp"), ("All files", "*.*")],
    "file": [("Images", "*.png *.jpg *.jpeg *.bmp *.webp"), ("All files", "*.*")],
    "psd": [("Photoshop documents", "*.psd *.psb"), ("All files", "*.*")],
    "json": [("JSON files", "*.json"), ("All files", "*.*")],
}
_lock = threading.Lock()          # one dialog at a time


def pick(kind="dir", title="", initial=""):
    """Show the dialog and return the chosen path, or "" (cancelled / unavailable)."""
    result = {"path": ""}

    def run():
        try:
            import tkinter as tk
            from tkinter import filedialog

            root = tk.Tk()
            root.withdraw()
            root.attributes("-topmost", True)       # above the browser window
            root.update()
            opts = {"parent": root, "title": title or ("Choose a folder" if kind == "dir" else "Choose a file")}
            if initial:
                opts["initialdir"] = initial
            if kind == "dir":
                path = filedialog.askdirectory(mustexist=True, **opts)
            else:
                path = filedialog.askopenfilename(filetypes=_FILETYPES.get(kind, [("All files", "*.*")]), **opts)
            root.destroy()
            result["path"] = str(path or "").replace("/", "\\")
        except Exception:
            result["path"] = ""

    with _lock:
        t = threading.Thread(target=run, daemon=True)     # Tk lives in its own thread
        t.start()
        t.join(timeout=600)
    return result["path"]
