"""PaytableTemplates folder: saved paytable designs (template + mappings JSON).

The folder holds the tool's default paytable designs as plain mapped-paytable
JSONs (``canvas`` + ``slots`` + optional ``mappings``). It lives in the tool
root for dev runs; frozen builds keep it next to the EXE, seeded on first run
from the bundled ``paytable_layouts`` JSONs so the dropdown is never empty.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import sys

_BUNDLED_LAYOUTS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "paytable_layouts")
_FROZEN_SEED_NAME = "SimplePaytable.json"


def templates_dir() -> str:
    """Return the PaytableTemplates folder, creating + seeding it if needed."""
    if getattr(sys, "frozen", False):
        exe_dir = os.path.dirname(os.path.abspath(sys.executable))
        folder = os.path.join(exe_dir, "PaytableTemplates")
        os.makedirs(folder, exist_ok=True)
        if not os.listdir(folder):
            _seed_from_bundled(folder)
        return folder
    root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    folder = os.path.join(root, "PaytableTemplates")
    os.makedirs(folder, exist_ok=True)
    if not os.listdir(folder) and os.path.isdir(_BUNDLED_LAYOUTS):
        _seed_from_bundled(folder)
    return folder


def _seed_from_bundled(folder: str) -> None:
    bundled = (
        os.path.join(getattr(sys, "_MEIPASS", ""), "ui_web", "paytable_layouts")
        if getattr(sys, "frozen", False)
        else _BUNDLED_LAYOUTS
    )
    if not os.path.isdir(bundled):
        return
    for fname in sorted(os.listdir(bundled)):
        if not fname.casefold().endswith(".json"):
            continue
        src = os.path.join(bundled, fname)
        dest_name = _FROZEN_SEED_NAME if fname == "SimplePaytable-JSON_Default_Template.json" else fname
        try:
            shutil.copy2(src, os.path.join(folder, dest_name))
        except OSError:
            pass


def list_templates():
    """Return metadata for every JSON design in PaytableTemplates (sorted)."""
    folder = templates_dir()
    out = []
    for fname in sorted(os.listdir(folder)):
        if not fname.casefold().endswith(".json"):
            continue
        path = os.path.join(folder, fname)
        name = os.path.splitext(fname)[0]
        try:
            with open(path, "r", encoding="utf-8") as handle:
                doc = json.load(handle)
        except Exception:
            continue
        if not isinstance(doc, dict):
            continue
        slots = doc.get("slots") or {}
        raw_mappings = doc.get("mappings") or {}
        mapping_count = len(raw_mappings) if isinstance(raw_mappings, (dict, list)) else 0
        out.append({
            "name": name,
            "path": path,
            "template_id": str(doc.get("template_id") or name),
            "slot_count": len(slots) if isinstance(slots, dict) else 0,
            "mappings": mapping_count,
        })
    return out


def resolve_template_path(path_or_name):
    """Normalize a template path or name to an absolute path inside
    PaytableTemplates (rejects anything that would escape the folder)."""
    raw = str(path_or_name or "").strip()
    if not raw:
        raise ValueError("No template specified.")
    base = os.path.basename(str(raw).replace("\\", "/"))
    if not base.casefold().endswith(".json"):
        base += ".json"
    folder = os.path.normcase(os.path.abspath(templates_dir()))
    cand = os.path.normcase(os.path.abspath(os.path.join(folder, base)))
    if not cand.startswith(folder + os.sep):
        raise ValueError("Template path must point inside the PaytableTemplates folder.")
    return cand


def delete_template(path_or_name):
    """Delete a mapped-paytable design from PaytableTemplates.

    Accepts the full path or a bare name. Returns ``{"name", "path"}``.
    """
    path = resolve_template_path(path_or_name)
    if not os.path.isfile(path):
        raise FileNotFoundError(f"Template not found: {os.path.basename(path)}")
    os.remove(path)
    return {
        "name": os.path.splitext(os.path.basename(path))[0],
        "path": path,
    }


def save_template(template, name=None):
    """Persist a mapped-paytable design into PaytableTemplates. Returns path."""
    if not isinstance(template, dict) or not (template.get("slots") or {}):
        raise ValueError("Missing template slots.")
    name = str(name or template.get("template_id") or "paytable").strip()
    safe_name = re.sub(r"[^A-Za-z0-9_\-]+", "_", name).strip("_") or "paytable"
    folder = templates_dir()
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, f"{safe_name}.json")
    doc = dict(template)
    doc["template_id"] = name
    doc.setdefault("slot_prefix", "@slot")
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(doc, handle, indent=2, ensure_ascii=False)
    return path


def _normalize_imported(doc):
    """Make an imported template doc look like a mapped-paytable design."""
    if not isinstance(doc, dict) or not isinstance(doc.get("slots"), dict) or not doc["slots"]:
        raise ValueError("Template must contain a 'slots' dict with at least one slot.")
    template = dict(doc)
    template.setdefault("slot_prefix", "@slot")
    template.setdefault("mappings", {})
    canvas = template.get("canvas") or {}
    try:
        cw = int(float(canvas.get("width") or 0))
        ch = int(float(canvas.get("height") or 0))
    except Exception:
        cw = ch = 0
    if cw <= 0 or ch <= 0:
        raise ValueError("Template must contain a valid 'canvas' (width/height).")
    template["canvas"] = {"width": cw, "height": ch}
    template["template_id"] = str(
        template.get("template_id") or template.get("name") or "paytable"
    ).strip() or "paytable"
    return template


def import_from_file(file_path):
    """Import a PSD/PSB (scan @slot layers) or a mapped-paytable JSON.

    PSDs are scanned through Photoshop's automation (it must be running); the
    resulting template is saved into PaytableTemplates. Returns a dict with
    ``name``, ``path``, ``template`` and ``slots``. Raises on failure.
    """
    file_path = str(file_path or "")
    if not file_path or not os.path.isfile(file_path):
        raise FileNotFoundError("File not found.")
    ext = os.path.splitext(file_path)[1].lower()
    if ext in (".psd", ".psb"):
        from ps_autotypesetter.custom_layout_exporter import export_table_slots_json

        template = _normalize_imported(export_table_slots_json(file_path, preview_path="", slot_prefix="@slot"))
    elif ext == ".json":
        try:
            with open(file_path, "r", encoding="utf-8") as handle:
                doc = json.load(handle)
        except Exception as exc:
            raise ValueError(f"Invalid JSON file: {exc}") from exc
        template = _normalize_imported(doc)
    else:
        raise ValueError("Only .psd/.psb or .json files are supported.")
    name = str(template.get("template_id") or os.path.splitext(os.path.basename(file_path))[0]).strip()
    path = save_template(template, name)
    return {
        "name": os.path.splitext(os.path.basename(path))[0],
        "path": path,
        "template": template,
        "slots": len(template.get("slots") or {}),
    }


def import_from_active_psd():
    """Scan the PSD currently open in Photoshop for @slot.* layers and save it
    into PaytableTemplates. Returns the same dict as :func:`import_from_file`."""
    from ps_autotypesetter.custom_layout_exporter import export_paytable_slots_from_active_document

    template = _normalize_imported(export_paytable_slots_from_active_document(slot_prefix="@slot"))
    name = str(template.get("template_id") or "ActivePSD").strip() or "ActivePSD"
    path = save_template(template, name)
    return {
        "name": os.path.splitext(os.path.basename(path))[0],
        "path": path,
        "template": template,
        "slots": len(template.get("slots") or {}),
    }
