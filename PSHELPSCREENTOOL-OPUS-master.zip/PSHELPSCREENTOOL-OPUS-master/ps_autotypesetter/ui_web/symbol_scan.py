"""Find the symbols and backgrounds in an artist PSD — fast, de-duplicated.

The old picker composited every layer (992 in a real help-screen PSD) the way
it appears in the document: layers on hidden pages came out empty, gradient
fills needed scipy, and opening took ~57 s. Here:

  * the PSD opens with the lazy reader (text engine parsed on demand, ~1-3 s);
  * only picture layers and smart objects are considered (no text, no groups,
    except a group named like a background);
  * each layer's OWN pixels are used (hidden pages included);
  * layers are sorted into symbols / backgrounds / other images by size;
  * a symbol placed on many pages appears once (same pixels -> one entry,
    with how many times and on which pages it is used);
  * thumbnails are made during the scan, so the grid shows real previews.
"""
import hashlib
import io
import os
import re
import threading

_LOCK = threading.Lock()
_CACHE = {}                    # file key -> scan result (with PIL images, not returned to the UI)

_GENERIC = re.compile(r"^(layer|copy|group|shape|rectangle|ellipse)\s*\d*(\s+copy(\s*\d+)?)*$", re.I)
_BG_NAME = re.compile(r"^(bg|back\s*ground|backgrounds?)\b", re.I)


def _file_key(path):
    st = os.stat(path)
    return (os.path.normcase(os.path.abspath(path)), st.st_size, st.st_mtime_ns)


def _page_of(layer, root):
    """Name of the top-level group (the help-screen page) a layer sits in."""
    node, top = layer, None
    while getattr(node, "parent", None) is not None and node.parent is not root:
        node = node.parent
        top = node
    return str(getattr(top, "name", "") or "") if top is not None else ""


def _pixels(layer):
    """The layer's own RGBA pixels, cropped to what is actually painted (or None)."""
    try:
        img = layer.topil()
    except Exception:
        img = None
    if img is None and getattr(layer, "kind", "") in ("group", "smartobject"):
        try:
            img = layer.composite(force=True)
        except Exception:
            img = None
    if img is None:
        return None
    img = img.convert("RGBA")
    box = img.getchannel("A").getbbox()
    return img.crop(box) if box else None


def _signature(img):
    """(aspect, bits) — a 16x16 average hash of the picture over its alpha, so the
    same art at another size (or re-saved) still matches."""
    from PIL import Image

    small = img.resize((16, 16), Image.BILINEAR)
    px = small.load()
    vals = []
    for y in range(16):
        for x in range(16):
            r, g, b, a = px[x, y]
            vals.append(((r * 299 + g * 587 + b * 114) // 1000) * a // 255)
    mean = sum(vals) / len(vals)
    bits = 0
    for v in vals:
        bits = (bits << 1) | (1 if v > mean else 0)
    alpha = 0
    rgb, n = [0, 0, 0], 0
    for y in range(16):
        for x in range(16):
            r, g, b, a = px[x, y]
            alpha = (alpha << 1) | (1 if a > 127 else 0)
            if a > 127:
                rgb[0] += r
                rgb[1] += g
                rgb[2] += b
                n += 1
    colour = tuple(c / max(1, n) for c in rgb)        # purple vs red vs green scatter: same shape
    return img.width / max(1, img.height), bits, alpha, colour


def _same_art(a, b):
    """Same symbol? aspect within 6 %, picture and silhouette nearly identical."""
    if abs(a[0] - b[0]) > 0.06 * max(a[0], b[0]):
        return False
    if max(abs(x - y) for x, y in zip(a[3], b[3])) > 22:
        return False                                   # same shape, different colour = different symbol
    return bin(a[1] ^ b[1]).count("1") <= 14 and bin(a[2] ^ b[2]).count("1") <= 10


def pixel_difference(a, b):
    """Share (0–1) of the two pictures' pixels that clearly differ, compared at 64 x 64: a mummy with a 3 x 3
    grid against one with a 2 x 2 grid ~7 %, two copies of one picture 0 %."""
    import numpy as np
    from PIL import Image

    def lum(img):
        x = np.asarray(img.convert("RGBA").resize((64, 64), Image.LANCZOS), np.float32)
        return (x[..., :3] * x[..., 3:] / 255.0).mean(-1)
    return float((np.abs(lum(a) - lum(b)) > 40).mean())


_SAME_PIXELS = 0.03                                   # under 3 % of the pixels different: the same picture


def same_picture(a_img, a_sig, b_img, b_sig):
    """The same symbol: alike at a glance (_same_art) and in its pixels (pixel_difference)."""
    if not _same_art(a_sig, b_sig):
        return False
    try:
        return pixel_difference(a_img, b_img) <= _SAME_PIXELS
    except Exception:
        return True


def art_distance(a, b):
    """How far apart two signatures are (smaller = more alike; picture bits + silhouette bits + colour)."""
    return (bin(a[1] ^ b[1]).count("1") + bin(a[2] ^ b[2]).count("1")
            + max(abs(x - y) for x, y in zip(a[3], b[3])) / 8.0 + abs(a[0] - b[0]) * 20)


def closest(entries, sig, img=None, images=None):
    """The entry whose art is the same as `sig` and nearest it (look-alikes — a mummy marked 3x3 or 4x4 —
    go to their own entry, not the first similar one), or None. With the picture (`img`) and the entries'
    pictures (`images`: key -> image), nearest by its pixels."""
    hits = [e for e in entries if _same_art(e["_sig"], sig)]
    if not hits:
        return None
    if img is not None and images:
        scored = [(pixel_difference(img, images[e["key"]]), e) for e in hits if e["key"] in images]
        if scored:
            d, e = min(scored, key=lambda x: x[0])
            return e if d <= _SAME_PIXELS * 2 else None
    return min(hits, key=lambda e: art_distance(e["_sig"], sig))


def _plain(img):
    """A flat block of one colour (clipping base, mask, panel) — not a symbol."""
    from PIL import ImageStat

    rgb = img.convert("RGB")
    st = ImageStat.Stat(rgb, mask=img.getchannel("A").point(lambda a: 255 if a > 127 else 0))
    return max(st.stddev or [0]) < 6


def _thumb(img, size=160):
    t = img.copy()
    t.thumbnail((size, size))
    buf = io.BytesIO()
    t.save(buf, "PNG")
    return buf.getvalue()


def _better_name(a, b):
    """Prefer a descriptive name over "Layer 735 copy 3"."""
    if not a:
        return b
    if _GENERIC.match(a.strip()) and not _GENERIC.match(b.strip()):
        return b
    return a


def scan(psd_path):
    """{"width", "height", "symbols": [...], "backgrounds": [...], "others": [...]}.

    Each entry: key, name, kind, w, h (painted size), count (times used),
    pages (where), hidden (all copies hidden). Images stay server-side.
    """
    key = _file_key(psd_path)
    with _LOCK:
        hit = _CACHE.get(key)
        if hit:
            return hit
    from ..artist_design.psd_reader import open_psd

    psd = open_psd(psd_path)
    W, H = int(psd.width), int(psd.height)
    groups = {"symbols": {}, "backgrounds": {}, "paylines": {}, "others": []}
    images = {}
    for layer in psd.descendants():
        kind = getattr(layer, "kind", "") or ""
        name = str(layer.name or "").replace("\x00", "").strip()
        from ..psd_style_import import bg_name_strength

        bg_named = bool(_BG_NAME.match(name)) or bg_name_strength(name, layer) == 2   # "Help BG group" too
        if kind == "group" and not bg_named:
            continue
        if kind not in ("pixel", "smartobject", "group"):
            continue                                  # text, shapes, adjustments, fills
        try:
            l, t, r, b = layer.bbox
        except Exception:
            continue
        w, h = r - l, b - t
        if w < 8 or h < 8:
            continue
        if (w >= 0.8 * W and h >= 0.8 * H) or bg_named:
            cat = "backgrounds"
        elif 16 <= w <= 0.5 * W and 16 <= h <= 0.6 * H and 0.3 <= w / max(1, h) <= 3.3:
            cat = "symbols"
        else:
            cat = "others"
        page = _page_of(layer, psd)
        visible = bool(getattr(layer, "visible", True))
        if cat == "others":                          # strips, frames, panels: listed, decoded on demand
            k = f"o{len(groups['others'])}"
            groups["others"].append({"key": k, "name": name, "kind": kind, "w": w, "h": h, "count": 1,
                                     "pages": [page] if page else [], "hidden": not visible, "_layer": layer})
            continue
        img = _pixels(layer)
        if img is None:
            continue
        if cat == "backgrounds" and not bg_named and not (img.width >= 0.8 * W and img.height >= 0.8 * H):
            # an untrimmed layer: judge it by what is actually painted
            pw, ph = img.width, img.height
            if 16 <= pw <= 0.5 * W and 16 <= ph <= 0.6 * H and 0.3 <= pw / max(1, ph) <= 3.3:
                cat = "symbols"
            else:
                k = f"o{len(groups['others'])}"
                groups["others"].append({"key": k, "name": name, "kind": kind, "w": pw, "h": ph, "count": 1,
                                         "pages": [page] if page else [], "hidden": not visible, "_layer": layer})
                continue
        if cat == "symbols" and _plain(img):
            cat = "others"                             # flat colour block: a mask/clipping base
            k = f"o{len(groups['others'])}"
            groups["others"].append({"key": k, "name": name, "kind": kind, "w": w, "h": h, "count": 1,
                                     "pages": [page] if page else [], "hidden": not visible, "_layer": layer})
            continue
        if cat == "symbols" and re.search(r"pay\s*lines?|^lines?\b", page + " " + name, re.I):
            cat = "paylines"                           # payline diagrams: their own section
        sig = _signature(img)
        bucket = groups[cat]
        # the same symbol again (another page, another size): same art AND same pixels — look-alikes such as
        # mummies marked 2x2 / 3x3 (thin grid lines) are their own symbols
        entry = next((e for e in bucket.values() if same_picture(images[e["key"]], e["_sig"], img, sig)), None)
        if entry is None:
            k = {"symbols": "s", "backgrounds": "b", "paylines": "p"}[cat] + str(len(bucket))
            entry = bucket[k] = {"key": k, "name": name, "kind": kind, "w": img.width, "h": img.height,
                                 "count": 0, "pages": [], "hidden": True, "sizes": [], "_sig": sig}
            images[k] = img
        elif img.width * img.height > entry["w"] * entry["h"]:
            images[entry["key"]] = img                 # keep the biggest copy: it exports best
            entry["w"], entry["h"] = img.width, img.height
        size = f"{img.width}x{img.height}"
        if size not in entry["sizes"]:
            entry["sizes"].append(size)
        entry["count"] += 1
        entry["name"] = _better_name(entry["name"], name)
        entry["hidden"] = entry["hidden"] and not visible
        if page and page not in entry["pages"]:
            entry["pages"].append(page)
    result = {
        "ok": True, "psd_path": os.path.abspath(psd_path), "width": W, "height": H,
        "symbols": sorted(groups["symbols"].values(), key=lambda e: (-e["count"], e["name"].lower())),
        "backgrounds": sorted(groups["backgrounds"].values(), key=lambda e: -(e["w"] * e["h"])),
        "paylines": sorted(groups["paylines"].values(), key=lambda e: e["name"].lower()),
        "others": groups["others"],
        "_images": images,
        "_thumbs": {k: _thumb(v) for k, v in images.items()},
    }
    with _LOCK:
        _CACHE.clear()                                 # one PSD at a time (they can be huge)
        _CACHE[key] = result
    return result


def public(result):
    """The scan without server-side images/layers (for JSON)."""
    out = {k: v for k, v in result.items() if not k.startswith("_")}
    for cat in ("symbols", "backgrounds", "paylines", "others"):
        out[cat] = [{k: v for k, v in e.items() if not k.startswith("_")} for e in result[cat]]
    out["counts"] = {cat: len(result[cat]) for cat in ("symbols", "backgrounds", "paylines", "others")}
    return out


def _image(result, key):
    if key in result["_images"]:
        return result["_images"][key]
    for e in result["others"]:
        if e["key"] == key:
            img = _pixels(e["_layer"])
            if img is not None:
                result["_images"][key] = img
            return img
    return None


def thumbnail(psd_path, key):
    """PNG bytes of an entry's preview (or None)."""
    result = scan(psd_path)
    if key in result["_thumbs"]:
        return result["_thumbs"][key]
    img = _image(result, key)
    if img is None:
        return None
    result["_thumbs"][key] = _thumb(img)
    return result["_thumbs"][key]


def _safe(name):
    name = re.sub(r'[\\/:*?"<>|\r\n\t]+', "_", str(name or "")).strip(" ._")
    return name[:100] or "symbol"


def planned_paths(items, symbols_dir, bg_dir=""):
    """Where each picked entry would be saved ([(item, path)]), before writing."""
    out, used = [], set()
    for item in items or []:
        key, name = str(item.get("key") or ""), str(item.get("name") or "")
        folder = bg_dir if key.startswith("b") and bg_dir else symbols_dir
        base = _safe(name or key)
        stem, n = base, 2
        while (folder, stem.lower()) in used:
            stem, n = f"{base}_{n}", n + 1
        used.add((folder, stem.lower()))
        out.append((item, os.path.join(folder, stem + ".png")))
    return out


def conflicts(items, symbols_dir, bg_dir=""):
    """Files the export would overwrite (existing user assets)."""
    return [p for _i, p in planned_paths(items, symbols_dir, bg_dir) if os.path.exists(p)]


def _free(path):
    stem, ext = os.path.splitext(path)
    n = 2
    while os.path.exists(f"{stem}_{n}{ext}"):
        n += 1
    return f"{stem}_{n}{ext}"


def export(psd_path, items, symbols_dir, bg_dir="", on_conflict="keep_both"):
    """Save picked entries at their size in the PSD: symbols -> symbols_dir,
    backgrounds -> bg_dir. items: [{"key", "name"}]. Existing files are never
    replaced unless on_conflict="replace" ("keep_both" saves as name_2.png).
    Returns {"files", "skipped"}."""
    result = scan(psd_path)
    files, skipped = [], []
    for item, path in planned_paths(items, symbols_dir, bg_dir):
        key, name = str(item.get("key") or ""), str(item.get("name") or "")
        img = _image(result, key)
        if img is None:
            skipped.append({"key": key, "name": name, "reason": "Nothing to export."})
            continue
        folder = os.path.dirname(path)
        os.makedirs(folder, exist_ok=True)
        if os.path.exists(path) and on_conflict != "replace":
            path = _free(path)
        img.save(path, "PNG")
        files.append({"key": key, "name": os.path.basename(path), "path": path, "w": img.width, "h": img.height,
                      "kind": "background" if folder == bg_dir and bg_dir else "symbol"})
    return {"files": files, "skipped": skipped}


_ROYALS = {"ace": "a", "king": "k", "queen": "q", "jack": "j", "ten": "10", "nine": "9"}


def suggest_names(names, tokens):
    """Map layer names to Excel symbol tokens where they clearly match
    ("WILD symbol" -> "wild", "ace symbol" -> "A", "gold_scat #144" -> "gold_scat"); returns {name: token}."""
    def norm(s):
        return re.sub(r"[^a-z0-9]+", "", str(s or "").lower())

    def base(s):                          # the layer's own name: no "#144" copy count, no "symbol" / "icon"
        s = re.sub(r"#\s*\d+\s*$", "", str(s or ""))
        s = re.sub(r"\b(symbol|symbols|icon|layer)\b", "", s, flags=re.I)
        return norm(s)

    toks = {norm(t): t for t in tokens or [] if norm(t)}
    alias = {}
    for long, short in _ROYALS.items():   # ACE <-> A, TEN <-> 10 ...
        if long in toks and short not in toks:
            alias[short] = toks[long]
        if short in toks and long not in toks:
            alias[long] = toks[short]
    out = {}
    for n in names:
        nn = base(n)
        if not nn:
            continue
        if nn in toks:
            out[n] = toks[nn]
            continue
        if nn in alias:
            out[n] = alias[nn]
            continue
        hits = [t for k, t in toks.items() if len(k) >= 3 and k in nn]   # the token inside the layer name, never the reverse
        if len(hits) == 1:
            out[n] = hits[0]
    return out
