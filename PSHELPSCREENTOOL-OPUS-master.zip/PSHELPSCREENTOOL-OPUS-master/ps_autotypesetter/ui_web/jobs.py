"""Background build jobs for the web UI: thread + progress + log lines."""

from __future__ import annotations

import os
import threading
import time
import uuid

from . import engine_api

_PHASE_PCT = {
    "build_start": 2,
    "photoshop_connected": 8,
    "excel_loaded": 15,
    "preimport_icons": 20,
    "background_applied": 25,
    "page_started": 30,
    "page_done": 55,
    "tables_started": 60,
    "tables_done": 70,
    "paytable_started": 75,
    "paytable_done": 85,
    "psd_saved": 90,
    "png_saved": 90,
    "build_done": 100,
}

_LABELS = {
    "build_start": "Build started",
    "photoshop_connected": "Connected to Photoshop",
    "excel_loaded": "Excel data loaded",
    "preimport_icons": "Pre-importing icons",
    "background_applied": "Background applied",
    "page_started": "Rendering page",
    "page_done": "Page rendered",
    "tables_started": "Rendering tables",
    "tables_done": "Tables rendered",
    "paytable_started": "Building paytable",
    "paytable_done": "Paytable built",
    "psd_saved": "PSD saved",
    "png_saved": "PNG saved",
    "build_done": "Build complete",
    "cancelled": "Build cancelled",
    "error": "Build failed",
}

_KEEP_JOBS = 20

_PS_BUSY_RETRY_SECONDS = 3


def _is_photoshop_busy_error(exc) -> bool:
    """True for COM failures where Photoshop refused the call without a message
    (the 'did not answer / busy' family, e.g. (-2147212704, None, (None, None, None, 0, None))).
    Those are transient — a full re-run almost always succeeds on the second pass.
    Errors that carry a real Photoshop message are NOT retried automatically."""
    mod = getattr(type(exc), "__module__", "") or ""
    if mod not in ("comtypes", "_ctypes", "pythoncom", "win32com", "pywintypes"):
        return False
    args = getattr(exc, "args", None)
    if not args or not isinstance(args, tuple) or not args:
        return False
    hr = args[0] if isinstance(args[0], int) else None
    if hr is None or hr >= 0:
        return False
    if ((hr >> 16) & 0x1FFF) != 4:  # FACILITY_ITF = interface-specific
        return False
    excepinfo = args[2] if len(args) > 2 else None
    if isinstance(excepinfo, tuple) and len(excepinfo) >= 1 and excepinfo[0]:
        return False  # real message from Photoshop — don't auto-retry
    return True


class JobManager:
    def __init__(self):
        self._jobs = {}
        self._cancel_events = {}
        self._lock = threading.Lock()

    def _prune(self):
        with self._lock:
            if len(self._jobs) > _KEEP_JOBS:
                for jid in sorted(self._jobs.keys())[: len(self._jobs) - _KEEP_JOBS]:
                    self._jobs.pop(jid, None)
                    self._cancel_events.pop(jid, None)

    def _register(self, job_id: str, job: dict):
        event = threading.Event()
        with self._lock:
            self._jobs[job_id] = job
            self._cancel_events[job_id] = event
        return event

    def _cancel_event(self, job_id: str):
        with self._lock:
            return self._cancel_events.get(job_id)

    def _output_folders(self, result) -> list:
        """Distinct output folders from a run_build result dict."""
        folders = []
        if not isinstance(result, dict):
            return folders
        psd_path = result.get("psd_path") or ""
        if psd_path:
            folder = os.path.dirname(psd_path)
            if folder and os.path.isdir(folder) and folder not in folders:
                folders.append(folder)
        png_dir = result.get("png_dir") or ""
        if png_dir and os.path.isdir(png_dir) and png_dir not in folders:
            folders.append(png_dir)
        return folders

    def start(self, config: dict, mode: str) -> str:
        job_id = uuid.uuid4().hex[:12]
        job = {
            "id": job_id,
            "mode": mode,
            "status": "running",
            "progress": 0,
            "log": [],
            "started": time.time(),
            "finished": None,
            "error": "",
            "result": None,
            "output_folders": [],
        }
        cancel_event = self._register(job_id, job)

        def _progress(data):
            event = data.get("event", "step")
            label = _LABELS.get(event, event.replace("_", " ").title())
            pct = _PHASE_PCT.get(event, 0)
            with self._lock:
                job["progress"] = max(job["progress"], pct)
                job["log"].append(f"[{event}] {label}")
                if event == "page_started":
                    job["log"].append(f"   -> {data.get('page_name') or data.get('sheet') or ''}")

        def _worker():
            try:
                from . import ps_actions

                ps_actions.ensure_com_initialized()
                result = engine_api.run_build(config, mode, progress_callback=_progress, cancel_event=cancel_event)
                with self._lock:
                    job["result"] = result
                    job["output_folders"] = self._output_folders(result)
                    if cancel_event.is_set():
                        job["status"] = "cancelled"
                        job["log"].append("Build cancelled by user.")
                    else:
                        job["status"] = "done"
                        job["progress"] = 100
                        job["log"].append("Build finished successfully.")
            except Exception as e:
                if cancel_event.is_set():
                    with self._lock:
                        job["status"] = "cancelled"
                        job["log"].append("Build cancelled by user.")
                    return
                if mode in ("psd", "both") and _is_photoshop_busy_error(e):
                    with self._lock:
                        job["log"].append("[retry] Photoshop did not answer — retrying the build once…")
                    time.sleep(_PS_BUSY_RETRY_SECONDS)
                    if cancel_event.is_set():
                        with self._lock:
                            job["status"] = "cancelled"
                            job["log"].append("Build cancelled by user.")
                        return
                    try:
                        from . import ps_actions

                        ps_actions.ensure_com_initialized()
                        result = engine_api.run_build(config, mode, progress_callback=_progress, cancel_event=cancel_event)
                        with self._lock:
                            job["result"] = result
                            job["output_folders"] = self._output_folders(result)
                            if cancel_event.is_set():
                                job["status"] = "cancelled"
                                job["log"].append("Build cancelled by user.")
                            else:
                                job["status"] = "done"
                                job["progress"] = 100
                                job["log"].append("Build finished successfully (after one automatic retry).")
                        return
                    except Exception as retry_exc:
                        e = retry_exc
                import traceback as _tb

                with self._lock:
                    job["status"] = "error"
                    job["error"] = str(e)
                    job["log"].append(f"ERROR: {e}")
                    job["log"].append(_tb.format_exc().strip())
            finally:
                with self._lock:
                    job["finished"] = time.time()

        threading.Thread(target=_worker, daemon=True).start()
        self._prune()
        return job_id

    def start_task(self, fn, label: str, with_progress: bool = False) -> str:
        """Generic background task. fn() must return a serializable result.

        With ``with_progress`` fn is called as fn(progress) where
        progress(message, percent=None) adds a log line / raises the bar.
        """
        job_id = uuid.uuid4().hex[:12]
        job = {
            "id": job_id,
            "mode": label,
            "status": "running",
            "progress": 10,
            "log": [f"[start] {label} started"],
            "started": time.time(),
            "finished": None,
            "error": "",
            "result": None,
            "output_folders": [],
        }
        cancel_event = self._register(job_id, job)

        def _progress(message, percent=None):
            with self._lock:
                job["log"].append(str(message))
                if percent is not None:
                    job["progress"] = max(job["progress"], int(percent))

        def _worker():
            try:
                from . import ps_actions

                ps_actions.ensure_com_initialized()
                result = fn(_progress) if with_progress else fn()
                with self._lock:
                    job["result"] = result
                    if isinstance(result, dict) and result.get("ok") is False:
                        job["status"] = "error"
                        job["error"] = str(result.get("error", "Task failed."))
                        job["log"].append(f"ERROR: {job['error']}")
                    else:
                        job["status"] = "done"
                        job["progress"] = 100
                        job["log"].append("[done] Task finished.")
            except Exception as e:
                with self._lock:
                    job["status"] = "error"
                    job["error"] = str(e)
                    job["log"].append(f"ERROR: {e}")
            finally:
                with self._lock:
                    job["finished"] = time.time()

        threading.Thread(target=_worker, daemon=True).start()
        self._prune()
        return job_id

    def start_batch(self, projects: list, base_config: dict, mode: str) -> str:
        """Build several projects sequentially in one background job.
        projects: list of {name, excel_path, icon_folder, bg_path, output_dir}."""
        job_id = uuid.uuid4().hex[:12]
        job = {
            "id": job_id,
            "mode": "batch",
            "status": "running",
            "progress": 0,
            "log": [f"[start] Batch build of {len(projects)} project(s) started"],
            "started": time.time(),
            "finished": None,
            "error": "",
            "result": None,
        }
        cancel_event = self._register(job_id, job)

        def _worker():
            done, failed = 0, []
            total = max(1, len(projects))
            try:
                from . import ps_actions

                ps_actions.ensure_com_initialized()
                for idx, proj in enumerate(projects, start=1):
                    if cancel_event.is_set() or (self.get(job_id) or {}).get("status") == "cancelled":
                        with self._lock:
                            job["log"].append("Batch cancelled.")
                        break
                    name = proj.get("name") or "?"
                    with self._lock:
                        job["log"].append(f"[batch] ({idx}/{total}) Building {name}")
                    cfg = dict(base_config)
                    for key in ("excel_path", "icon_folder", "bg_path", "output_dir"):
                        if proj.get(key):
                            cfg[key] = proj[key]
                    cfg["selected_sheets"] = None
                    cfg["render_all_pages"] = True

                    def _progress(data, _name=name):
                        event = data.get("event", "step")
                        label = _LABELS.get(event, event.replace("_", " ").title())
                        with self._lock:
                            job["log"].append(f"[{_name}] {label}")
                            if event == "page_started":
                                job["log"].append(f"   -> {data.get('page_name') or data.get('sheet') or ''}")
                    try:
                        engine_api.run_build(cfg, mode, progress_callback=_progress, cancel_event=cancel_event)
                        done += 1
                        with self._lock:
                            job["log"].append(f"[batch] {name} finished ({done}/{total}).")
                    except Exception as e:
                        import traceback as _tb

                        failed.append((name, str(e)))
                        with self._lock:
                            job["log"].append(f"ERROR in {name}: {e}")
                            job["log"].append(_tb.format_exc().strip())
                    with self._lock:
                        job["progress"] = int(70 + 30 * idx / total) if failed else int(100 * idx / total)
                with self._lock:
                    job["progress"] = 100
                    if failed:
                        job["status"] = "error"
                        job["error"] = f"{len(failed)} of {total} project(s) failed"
                        job["log"].append(f"[batch] {len(failed)} project(s) failed.")
                    else:
                        job["status"] = "done"
                        job["log"].append(f"[batch] All {total} project(s) built successfully.")
            except Exception as e:
                import traceback as _tb

                with self._lock:
                    job["status"] = "error"
                    job["error"] = str(e)
                    job["log"].append(f"ERROR: {e}")
                    job["log"].append(_tb.format_exc().strip())
            finally:
                with self._lock:
                    job["finished"] = time.time()

        threading.Thread(target=_worker, daemon=True).start()
        self._prune()
        return job_id

    def get(self, job_id: str):
        with self._lock:
            job = self._jobs.get(job_id)
            return dict(job) if job else None

    def cancel(self, job_id: str) -> bool:
        with self._lock:
            job = self._jobs.get(job_id)
            if job and job["status"] == "running":
                job["status"] = "cancelled"
                job["log"].append("Cancelling...")
        event = self._cancel_event(job_id)
        if event is not None:
            event.set()
            return True
        return False


job_manager = JobManager()
