"""Flask web server for the PsHelpScreenTool Web UI.

Run with:  python -m ps_autotypesetter.ui_web.server
"""

from __future__ import annotations

import io
import itertools
import json
import copy
import os
import re
import sys
import tempfile
import threading
import uuid
import webbrowser

from urllib.parse import urlsplit

from flask import Flask, Response, g, jsonify, request, send_file, send_from_directory

from . import engine_api
from . import path_policy
from . import symbol_exporter
from .jobs import job_manager

_STATIC_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")



def _raw_sheet(value):
    """A sheet name as the workbook has it (Excel allows a trailing space: "BONUS 1 " — trimmed, it is
    a sheet that doesn't exist); a blank name is "none"."""
    raw = str(value or "")
    return raw if raw.strip() else ""

def _resource_dir() -> str:
    base = getattr(sys, "_MEIPASS", None)
    if base:
        return os.path.join(base, "ui_web", "static")
    return _STATIC_DIR


def create_app(session_file: str = "") -> Flask:
    app = Flask(__name__, static_folder=None)
    app.config["JSON_SORT_KEYS"] = False

    local_hosts = {"127.0.0.1", "localhost", "::1"}

    @app.before_request
    def _enforce_local_origin():
        host = (request.host or "").rsplit(":", 1)[0].strip("[]").lower()
        if host not in local_hosts:
            return jsonify({"ok": False, "error": f"forbidden host: {host}"}), 403
        origin = request.headers.get("Origin")
        if origin and origin != "null":
            try:
                parts = urlsplit(origin)
            except ValueError:
                return jsonify({"ok": False, "error": "malformed Origin header"}), 403
            origin_host = (parts.hostname or "").lower()
            if origin_host not in local_hosts:
                return jsonify({"ok": False, "error": f"forbidden origin: {origin_host}"}), 403
        return None

    if session_file:
        engine_api.set_session_file(session_file)
        from .. import games as _games_mod

        _games_mod.set_registry(os.path.join(os.path.dirname(os.path.abspath(session_file)), "PsHelpScreenTool_Games.json"))

    _cfg_lock = threading.Lock()

    def _borrow_wb(path, data_only=False):
        """The parsed workbook from workbook_cache, held until this request ends (read it, never edit it)."""
        from .. import workbook_cache

        loan = workbook_cache.borrow(path, data_only=data_only)
        wb = loan.__enter__()
        g.setdefault("_wb_loans", []).append(loan)
        return wb

    @app.teardown_request
    def _return_wb_loans(_exc):
        for loan in g.pop("_wb_loans", []):
            loan.__exit__(None, None, None)
    _state = {"config": engine_api._load_config(), "scan": None}
    from .. import text_edits as _text_edits_boot

    _text_edits_boot.set_all((_state["config"].get("dynamic_settings") or {}).get("text_edits"))
    from .. import global_light as _global_light_boot

    _global_light_boot.set_all(_state["config"].get("dynamic_settings") or {})   # previews before any save
    path_policy.seed_defaults()
    path_policy.grant_config_paths(_state["config"])
    try:                                               # registered game folders stay usable
        from .. import games as _games

        for _g in _games.list_games():
            if _g.get("folder"):
                path_policy.grant_tree(_g["folder"])
    except Exception:
        pass

    def _config():
        with _cfg_lock:
            return _state["config"]

    def _set_config(cfg):
        with _cfg_lock:
            _state["config"] = cfg
        _load_live_settings(cfg)
        engine_api._save_config(cfg)
        path_policy.grant_config_paths(cfg)
        if cfg.get("active_game"):
            # working on a game's market: the look goes to the game (all its markets),
            # market fields to the market (games.py)
            try:
                from .. import games

                games.sync_from_session(cfg)
            except Exception:
                pass

    def _load_live_settings(cfg):
        """The settings every preview reads from shared state: text edits, icon sizes, row roles, boxes."""
        from .. import text_edits as _text_edits

        _text_edits.set_all((cfg.get("dynamic_settings") or {}).get("text_edits"))   # every preview shows them
        from .. import icon_scales as _icon_scales

        _icon_scales.set_all((cfg.get("dynamic_settings") or {}).get("icon_scales"),    # icons sized on a preview
                             (cfg.get("dynamic_settings") or {}).get("icon_gaps"))      # ... and their own gaps
        from .. import row_roles as _row_roles

        try:                                       # the build's settings (defaults filled in), so both agree
            _row_roles.set_all(engine_api._merged_dynamic_settings(cfg))
        except Exception:
            _row_roles.set_all(cfg.get("dynamic_settings") or {})                  # rows made headings / subheadings
        from .. import page_boxes as _page_boxes

        _page_boxes.set_all(cfg.get("dynamic_settings") or {})     # paragraph boxes, heading-row gaps, text boxes
        from .. import global_light as _global_light

        _global_light.set_all(cfg.get("dynamic_settings") or {})   # "Use Global Light" layer styles' angle

    def _with_settings_draft(cfg, draft):
        """A copy of cfg with draft's dotted keys set; only the dicts on each path are copied."""
        out = dict(cfg)
        for path, value in draft.items():
            parts = [p for p in str(path).split(".") if p]
            if not parts:
                continue
            node = out
            for p in parts[:-1]:
                node[p] = dict(node.get(p) or {}) if isinstance(node.get(p), dict) or node.get(p) is None else {}
                node = node[p]
            node[parts[-1]] = value
        return out

    def _reject_unallowed_path(raw):
        value = str(raw or "").strip()
        if value and not path_policy.is_allowed(value):
            return jsonify({
                "ok": False,
                "error": "Path is outside the allowed folders. Re-pick it via Browse so the app can grant access.",
            }), 403
        return None

    def _preview_render_settings(cfg: dict) -> dict:
        """Dynamic-page settings plus the project canvas (c_width/c_height),
        mirroring build_engine.dynamic_runtime so the live preview scales the
        blueprint to the SAME document size as the PSD renderer."""
        s = dict(cfg.get("dynamic_settings") or {})
        from .. import bg_place

        s["bg_mode"] = bg_place.spec(cfg)                  # the preview places the background like the build
        s["bg_color"] = bg_place.behind(cfg)               # behind a picture: transparent unless switched on
        if cfg.get("page_overrides"):
            s["page_overrides"] = cfg.get("page_overrides")    # a page's own heading (ps_actions.page_heading_settings)
        cw = cfg.get("c_width")
        ch = cfg.get("c_height")
        if cw:
            s["canvas_width"] = int(cw)
        if ch:
            s["canvas_height"] = int(ch)
        hrgb = engine_api._hex_to_rgb(cfg.get("h_rgb"))
        if hrgb:
            s["title_rgb"] = hrgb
            s["heading_rgb"] = hrgb
        hsize = cfg.get("h_size")
        if hsize:
            s["title_size"] = int(hsize)
            s["heading_size"] = int(hsize)
        hfont = str(cfg.get("h_font") or "").strip()
        if hfont:
            s["heading_font"] = hfont
        hm = cfg.get("heading_top_margin")
        if hm:
            try:
                s["heading_top_margin"] = int(hm)
            except Exception:
                pass
        for key in ("margin_x", "h_icon_h", "max_col_limit", "line_spacing"):
            if cfg.get(key) is not None:
                s[key] = cfg.get(key)
        if cfg.get("line_gap") not in (None, ""):
            s["line_gap"] = int(float(cfg.get("line_gap")) or 0)
        if cfg.get("icon_size_overrides") is not None:
            s["icon_size_overrides"] = cfg.get("icon_size_overrides")
        return s

    def _preview_dynamic_settings(cfg: dict) -> dict:
        """Live-preview settings for the Game/Bingo Rules studio panels.

        The full dynamic settings (including layer styles) are passed through
        unchanged: ps_fx_png renders captured/flat layer styles headless, so the
        preview is byte-identical to the final PNG build for the same sheet.
        Uses the same merge as the real build so top-level icon-spacing sliders
        (heading_icon_gap_left/right, icon_gap_left/right) reach the previews."""
        return engine_api._merged_dynamic_settings(cfg)

    def _mirror_template_to_project_root(template_path: str) -> str:
        """Copy a freshly imported/added template JSON into the project root
        folder (config ``output_dir``) so it travels with the game files."""
        template_path = str(template_path or "")
        if not template_path.lower().endswith(".json") or not os.path.isfile(template_path):
            return ""
        root_dir = str(_config().get("output_dir") or "")
        if not root_dir or not os.path.isdir(root_dir):
            return ""
        try:
            target = os.path.join(root_dir, os.path.basename(template_path))
            if os.path.normcase(os.path.abspath(target)) == os.path.normcase(os.path.abspath(template_path)):
                return target
            import shutil

            shutil.copyfile(template_path, target)
            return target
        except Exception as exc:
            print(f"[PaytableTemplates] could not mirror template to project root: {exc}")
            return ""

    if os.environ.get("PSH_TIMING"):                   # PSH_TIMING=1: log every request's server time
        import time as _time

        @app.before_request
        def _timing_start():
            g._t0 = _time.perf_counter()

        @app.after_request
        def _timing_log(resp):
            ms = (_time.perf_counter() - g.get("_t0", _time.perf_counter())) * 1000
            print(f"[timing] {ms:7.0f} ms  {request.method} {request.path}", flush=True)
            return resp

    # ------------------------------------------------------------- static
    @app.route("/")
    def index():
        resp = send_from_directory(_resource_dir(), "index.html")
        resp.headers["Cache-Control"] = "no-store"
        return resp

    @app.route("/static/<path:filename>")
    def static_files(filename):
        resp = send_from_directory(_resource_dir(), filename)
        if filename.split("?")[0].endswith((".js", ".css")):
            # kept by the browser but re-checked every load (304 when unchanged): edits show at
            # once, and Chrome can reuse its compiled copy of the scripts instead of re-parsing them
            resp.headers["Cache-Control"] = "no-cache"
        return resp

    @app.route("/api/style-assets/status")
    def style_assets_status():
        """Why layer styles do (or don't) show in live previews.

        Reports every gate the Photoshop asset path checks so the UI can
        explain 'plain text' previews instead of failing silently."""
        from ps_autotypesetter import png_builder
        from ps_autotypesetter import photoshop_style_assets as psa

        cfg = _config()
        ds = engine_api._merged_dynamic_settings(cfg)
        lib = ds.get("layer_style_library") or {}
        sas = ds.get("style_assignments") or {}
        roles = {}
        for role in ("Heading text", "Body text", "Subheading text",
                     "Game Rules text", "Malfunction/legal text"):
            try:
                fx = png_builder._resolve_fx_config(lib, sas, role)
            except Exception:
                fx = None
            roles[role] = {
                "assigned": bool(fx),
                "complex": bool(fx) and psa.is_complex_style(fx),
            }
        return jsonify({
            "ok": True,
            "photoshop_available": psa.photoshop_available(),
            "style_assets_enabled": psa.photoshop_style_assets_enabled(),
            "roles": roles,
            "library_styles": sorted(lib.keys()),
        })

    @app.route("/api/style-assets/verify", methods=["POST"])
    def style_assets_verify():
        """"Verify in Photoshop": render a saved layer style on sample text in
        whichever Photoshop is open (photoshop_bridge) AND in the
        Photoshop-free engine every preview uses, and return both renders and
        their pixel difference. Only runs when the artist asks for it."""
        from ps_autotypesetter import fx_verify, photoshop_bridge

        data = request.get_json(force=True, silent=True) or {}
        ds = engine_api._merged_dynamic_settings(_config())
        lib = ds.get("layer_style_library") or {}
        name = str(data.get("name") or "").strip()
        role = str(data.get("role") or "").strip()
        if not name and role:
            name = str((ds.get("style_assignments") or {}).get(role) or "")
        style = lib.get(name) if name else None
        if not isinstance(style, dict):
            return jsonify({"ok": False, "error": "Pick a saved layer style first."}), 400
        try:
            size = max(12, min(200, int(float(data.get("size") or 72))))
        except (TypeError, ValueError):
            size = 72
        color = data.get("color") if isinstance(data.get("color"), list) else [255, 255, 255]
        text = str(data.get("text") or "Sample 123")[:40]
        try:
            res = fx_verify.verify_text_style(style, text=text, font_name=str(data.get("font") or "Arial"),
                                              size=size, rgb=color)
        except photoshop_bridge.PhotoshopUnavailable as exc:
            return jsonify({"ok": False, "error": f"Photoshop is not available: {exc}"}), 503
        except fx_verify.VerifyError as exc:
            return jsonify({"ok": False, "error": str(exc)}), 400
        except Exception as exc:
            return jsonify({"ok": False, "error": f"Photoshop render failed: {exc}"}), 500
        bg = (58, 64, 74)
        return jsonify({
            "ok": True, "name": name, "stats": res["stats"],
            "photoshop_png": fx_verify.png_data_uri(res["photoshop"], bg),
            "tool_png": fx_verify.png_data_uri(res["tool"], bg),
            "diff_png": fx_verify.png_data_uri(res["diff"]),
        })

    # ------------------------------------------------------------- state
    @app.route("/api/bootstrap")
    def bootstrap():
        cfg = _config()
        return jsonify(
            {
                "config": cfg,
                "presets": engine_api.list_presets(),
                "canvas_presets": engine_api.CANVAS_PRESETS,
                "app_title": "PsHelpScreenTool",
                "session_note": engine_api.session_note(),
            }
        )

    @app.route("/api/config", methods=["GET"])
    def get_config():
        return jsonify({"config": _config()})

    @app.route("/api/config", methods=["POST"])
    def post_config():
        data = request.get_json(force=True, silent=True) or {}
        cfg = _config()
        previous_excel = cfg.get("excel_path")
        cfg.update(data)
        if "excel_path" in data and engine_api.excel_key(data.get("excel_path")) != engine_api.excel_key(previous_excel):
            engine_api.swap_scoped_icon_mappings(cfg, previous_excel)   # per-workbook symbol relinks
        _set_config(cfg)
        return jsonify({"ok": True, "config": cfg})

    @app.route("/api/config/reset", methods=["POST"])
    def reset_config():
        cfg = dict(engine_api.DEFAULT_CONFIG)
        _set_config(cfg)
        return jsonify({"ok": True, "config": cfg})

    # ------------------------------------------------------------- scan
    @app.route("/api/scan", methods=["POST"])
    def scan():
        data = request.get_json(force=True, silent=True) or {}
        excel_path = data.get("excel_path") or _config().get("excel_path", "")
        icon_folder = data.get("icon_folder") or _config().get("icon_folder", "")

        excel = engine_api.scan_excel(excel_path)
        icons = engine_api.scan_icons(excel_path, icon_folder, _config().get("icon_mappings") or {}) \
            if excel.get("ok") else {"error": "Excel not loaded"}

        suggestions = _build_suggestions(excel, icons)

        _state["scan"] = {"excel": excel, "icons": icons}

        cfg = _config()
        cfg["ai_suggestions"] = suggestions
        if excel_path:
            cfg["excel_path"] = excel_path
        if icon_folder:
            cfg["icon_folder"] = icon_folder
        if excel.get("ok"):
            valid_names = {str(s.get("name", "")).strip() for s in excel.get("sheets", [])}
            old_sheets = cfg.get("selected_sheets") or []
            kept = [n for n in old_sheets if str(n).strip() in valid_names]
            if kept != old_sheets:
                cfg["selected_sheets"] = kept
                excel["pruned_selected_sheets"] = len(old_sheets) - len(kept)
        _set_config(cfg)

        return jsonify({"excel": excel, "icons": icons, "suggestions": suggestions, "config": cfg})

    # ------------------------------------------- project discovery / recents
    @app.route("/api/project/discover", methods=["POST"])
    def project_discover():
        """Detect a game project layout inside a folder (Excel, icons,
        background, output, PSDs). Shared by Create New PSD / Update PSD /
        Export PNGs."""
        folder = str((request.get_json(force=True, silent=True) or {}).get("folder") or "")
        return jsonify(engine_api.project_discovery(folder))

    @app.route("/api/project/open", methods=["POST"])
    def project_open():
        """Mark a folder as "opened" so it appears in recent projects."""
        data = request.get_json(force=True, silent=True) or {}
        cfg = _config()
        engine_api.record_recent_project(cfg, data.get("folder") or "", data.get("name") or "")
        _set_config(cfg)
        return jsonify({"ok": True, "config": cfg})

    @app.route("/api/project/detect", methods=["POST"])
    def project_detect():
        """Auto-detect the project package (MyGame.project.json) beside a PSD."""
        data = request.get_json(force=True, silent=True) or {}
        psd_path = str(data.get("psd") or data.get("psd_path") or "").strip()
        if not psd_path:
            return jsonify({"ok": False, "error": "psd required."}), 400
        return jsonify(engine_api.detect_project_package(psd_path))

    @app.route("/api/project/load", methods=["POST"])
    def project_load():
        """Restore a project package into the session (settings + mapped JSONs)."""
        data = request.get_json(force=True, silent=True) or {}
        path = str(data.get("path") or data.get("manifest") or "").strip()
        if not path:
            return jsonify({"ok": False, "error": "project.json path required."}), 400
        cfg = _config()
        result = engine_api.load_project_package(path, cfg)
        if not result.get("ok"):
            return jsonify(result), 400
        _set_config(result["config"])
        return jsonify(result)

    @app.route("/api/project/save", methods=["POST"])
    def project_save():
        """Write/refresh the package for a PSD from the current session config."""
        from .. import project_package as pp

        data = request.get_json(force=True, silent=True) or {}
        psd_path = str(data.get("psd") or data.get("psd_path") or "").strip()
        if not psd_path:
            return jsonify({"ok": False, "error": "psd required."}), 400
        result = pp.write_project_package(_config(), psd_path)
        if not result.get("ok"):
            return jsonify(result), 400
        return jsonify(result)

    @app.route("/api/update/preview", methods=["POST"])
    def update_preview():
        """Excel diff preview for the Update PSD flow: Old Excel vs New Excel.

        prev_psd_path lets the server resolve the diff source from the saved
        baseline automatically (the Old Excel field then becomes optional)."""
        data = request.get_json(force=True, silent=True) or {}
        cfg = _config()
        if data.get("prev_psd_path"):
            cfg["prev_psd_path"] = data["prev_psd_path"]
        if data.get("prev_excel_path"):
            cfg["prev_excel_path"] = data["prev_excel_path"]
        if data.get("excel_path"):
            cfg["excel_path"] = data["excel_path"]
        if data.get("max_col_limit"):
            cfg["max_col_limit"] = int(data["max_col_limit"])
        return jsonify(engine_api.update_diff_preview(cfg))

    @app.route("/api/update/status", methods=["POST"])
    def update_status():
        """Update PSD readiness for a PSD: saved Excel baseline state plus the
        current Excel remembered by the project package (auto-filled into the
        session when the user has not chosen one)."""
        from .. import project_package as pp

        data = request.get_json(force=True, silent=True) or {}
        psd_path = str(data.get("psd") or data.get("psd_path") or "").strip()
        if not psd_path:
            return jsonify({"ok": False, "error": "psd required."}), 400

        baseline = pp.load_baseline_info(psd_path)
        manifest = None
        current_excel = ""
        manifest_path = pp.manifest_path_for_psd(psd_path)
        if manifest_path and os.path.isfile(manifest_path):
            manifest = pp.load_package_manifest(manifest_path)
            excel_ref = ((manifest or {}).get("files") or {}).get("excel") or {}
            abs_path = str(excel_ref.get("absolute") or "")
            if abs_path and os.path.isfile(abs_path):
                current_excel = abs_path
            else:
                rel = str(excel_ref.get("relative") or "")
                if rel:
                    rel_path = os.path.abspath(os.path.join(os.path.dirname(manifest_path), rel))
                    if os.path.isfile(rel_path):
                        current_excel = rel_path

        cfg = _config()
        if current_excel and not str(cfg.get("excel_path") or "").strip():
            cfg["excel_path"] = current_excel
            _set_config(cfg)
        return jsonify({
            "ok": True,
            "baseline": baseline,
            "project_exists": bool(manifest),
            "current_excel": current_excel,
        })

    @app.route("/api/page_preview", methods=["POST"])
    def page_preview():
        """Full-fidelity preview of one sheet's first page for the Project
        preview grid. Uses the REAL render pipeline (the same renderers the
        Game/Bingo Rules studios use live), disk-cached keyed to the
        workbook's path + mtime so revisits are instant."""
        from . import page_thumbs

        data = request.get_json(force=True, silent=True) or {}
        sheet_name = _raw_sheet(data.get("sheet_name"))
        cfg = _config()
        excel_path = str(cfg.get("excel_path") or "")
        if not excel_path or not os.path.isfile(excel_path):
            return jsonify({"ok": False, "error": "Excel workbook not set."}), 400
        if not sheet_name:
            return jsonify({"ok": False, "error": "sheet_name required."}), 400

        result = page_thumbs.render_sheet_preview(excel_path, sheet_name, cfg)
        if not result.get("ok") or not result.get("path"):
            return jsonify({"ok": False, "error": result.get("error") or "Preview render failed."}), 200

        token = _register_preview(result["path"])
        return jsonify({
            "ok": True,
            "preview_token": token,
            "sheet_name": sheet_name,
            "pages": 1,
            "cached": bool(result.get("cached")),
            "canvas_width": int(cfg.get("c_width") or 1920),
            "canvas_height": int(cfg.get("c_height") or 1080),
        })

    @app.route("/api/pages_preview", methods=["POST"])
    def pages_preview():
        """Batched full-fidelity previews for the whole Pages grid — one
        round trip, rendered in parallel server-side and served from the
        disk cache on subsequent visits. Returns a {sheet: preview_token}
        map so the grid can set <img> srcs directly."""
        from concurrent.futures import ThreadPoolExecutor

        from . import page_thumbs

        data = request.get_json(force=True, silent=True) or {}
        cfg = _config()
        excel_path = str(cfg.get("excel_path") or "")
        if not excel_path or not os.path.isfile(excel_path):
            return jsonify({"ok": False, "error": "Excel workbook not set."}), 400

        names = [str(s) for s in (data.get("sheets") or [])]
        if not names:
            names = [str(s) for s in (cfg.get("selected_sheets") or [])]
        if not names:
            try:
                from openpyxl import load_workbook

                wb_names = load_workbook(excel_path, data_only=False, read_only=True)
                names = [str(s) for s in wb_names.sheetnames]
                wb_names.close()
            except Exception as exc:
                return jsonify({"ok": False, "error": f"Cannot open workbook: {exc}"}), 400
        names = list(dict.fromkeys(names))[:60]

        def _work(name):
            try:
                result = page_thumbs.render_sheet_preview(excel_path, name, cfg)
                if result.get("ok") and result.get("path"):
                    return name, ("ok", _register_preview(result["path"]))
                return name, ("err", result.get("error") or "render failed")
            except Exception as exc:
                return name, ("err", str(exc))

        thumbs, errors = {}, {}
        if names:
            with ThreadPoolExecutor(max_workers=min(6, len(names))) as pool:
                for name, (state, value) in pool.map(_work, names):
                    if state == "ok":
                        thumbs[name] = value
                    else:
                        errors[name] = value
        return jsonify({
            "ok": True,
            "thumbs": thumbs,
            "errors": errors,
            "total": len(names),
            "rendered": len(thumbs),
        })

    @app.route("/api/pages_thumb/<path:sheet_name>")
    def pages_thumb(sheet_name):
        """Direct PNG thumbnail for the Project Pages grid. Renders page 1
        with the real PNG pipeline (the same renderers the Game/Bingo Rules
        studios use live), disk-cached, and serves the file straight back —
        the grid just points <img src> at this URL."""
        from . import page_thumbs

        cfg = _config()
        excel_path = str(cfg.get("excel_path") or "")
        if not excel_path or not os.path.isfile(excel_path):
            resp = jsonify({"ok": False, "error": "Excel workbook not set."})
            resp.headers["Cache-Control"] = "no-store"
            return resp, 400
        result = page_thumbs.preview_or_stale(excel_path, sheet_name, cfg)
        path = result.get("path") or ""
        try:
            page = max(1, int(request.args.get("page") or 1))   # ?page=2: its first Continued page …
        except ValueError:
            page = 1
        if path and page > 1:
            path = page_thumbs.page_path(path, page)
        if not result.get("ok") or not os.path.isfile(path):
            resp = jsonify({"ok": False, "error": result.get("error") or "Preview render failed."})
            resp.headers["Cache-Control"] = "no-store"
            return resp, 404
        resp = send_file(path, mimetype="image/png", max_age=0)
        if result.get("stale"):                        # an older picture: the new one is on its way
            resp.headers["Cache-Control"] = "no-store"
            resp.headers["X-Thumb-Stale"] = "1"
        return resp

    @app.route("/api/pages_count/<path:sheet_name>")
    def pages_count(sheet_name):
        """How many pages a sheet makes (page 1 and its Continued pages) — the Typography page
        rail links them under the sheet. Rendered once with the real pipeline, then cached."""
        from . import page_thumbs

        cfg = _config()
        excel_path = str(cfg.get("excel_path") or "")
        if not excel_path or not os.path.isfile(excel_path):
            return jsonify({"ok": False, "error": "Excel workbook not set."}), 400
        result = page_thumbs.preview_or_stale(excel_path, sheet_name, cfg)
        if not result.get("ok"):
            return jsonify({"ok": False, "error": result.get("error") or "Preview render failed."})
        return jsonify({"ok": True, "sheet_name": sheet_name, "pages": int(result.get("pages") or 1),
                        "stale": bool(result.get("stale"))})

    @app.route("/api/pages_fresh", methods=["POST"])
    def pages_fresh():
        """Which of these sheets' previews are up to date (the rail swaps in the new pictures)."""
        from . import page_thumbs

        cfg = _config()
        excel_path = str(cfg.get("excel_path") or "")
        sheets = [str(s) for s in ((request.get_json(force=True, silent=True) or {}).get("sheets") or [])]
        if not excel_path or not os.path.isfile(excel_path):
            return jsonify({"ok": False, "fresh": {}})
        return jsonify({"ok": True, "fresh": {s: page_thumbs.is_fresh(excel_path, s, cfg) for s in sheets}})

    @app.route("/api/icons")
    def icons():
        folder = request.args.get("folder", "") or _config().get("icon_folder", "")
        blocked = _reject_unallowed_path(folder)
        if blocked:
            return blocked
        return jsonify({"files": engine_api.list_icon_files(folder)})

    @app.route("/api/icon_file")
    def icon_file():
        folder = request.args.get("folder", "") or _config().get("icon_folder", "")
        name = os.path.basename(request.args.get("name", "") or "")
        if not folder or not os.path.isdir(folder) or not name:
            return jsonify({"ok": False, "error": "Invalid icon path."}), 400
        blocked = _reject_unallowed_path(folder)
        if blocked:
            return blocked
        path = os.path.join(folder, name)
        if not os.path.isfile(path):
            return jsonify({"ok": False, "error": "Icon not found."}), 404
        mimetype = {"png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg",
                    "gif": "image/gif", "svg": "image/svg+xml", "bmp": "image/bmp"}.get(
            os.path.splitext(name)[1].lower().lstrip("."), "application/octet-stream")
        return send_file(path, mimetype=mimetype)

    @app.route("/api/icon_upload", methods=["POST"])
    def icon_upload():
        """Upload an image from the user's PC into the icon folder. Returns the new file name.

        Accepts multipart/form-data with a 'file' part and an optional 'folder' override.
        The token being edited is sent as 'token' for nicer default naming.
        """
        from werkzeug.utils import secure_filename
        import re as _re

        folder = request.form.get("folder") or _config().get("icon_folder", "")
        token = (request.form.get("token") or "").strip()
        if not folder or not os.path.isdir(folder):
            return jsonify({"ok": False, "error": "Icon folder is not set or does not exist."}), 400
        blocked = _reject_unallowed_path(folder)
        if blocked:
            return blocked
        f = request.files.get("file")
        if not f or not f.filename:
            return jsonify({"ok": False, "error": "No file uploaded."}), 400
        ext = os.path.splitext(f.filename)[1].lower()
        allowed = {".png", ".jpg", ".jpeg", ".gif", ".svg", ".bmp"}
        if ext not in allowed:
            return jsonify({"ok": False, "error": f"Unsupported image type '{ext}'."}), 400

        if token:
            stem = secure_filename(_re.sub(r"[^a-zA-Z0-9_\-]+", "_", token)).strip("_") or "icon"
            base = f"{stem}{ext}"
        else:
            base = secure_filename(f.filename) or f"icon{ext}"
        path = os.path.join(folder, base)
        counter = 1
        while os.path.exists(path):
            root, e = os.path.splitext(base)
            path = os.path.join(folder, f"{root}_{counter}{e}")
            counter += 1
        f.save(path)
        name = os.path.basename(path)
        return jsonify({"ok": True, "name": name, "path": path, "size": os.path.getsize(path)})

    @app.route("/api/fonts")
    def fonts():
        from . import ps_actions
        from .. import fontfaces

        # faces: each family's styles as Photoshop's Font style menu lists them; aliases: a PostScript /
        # full / older family name (fonts read from a PSD: "MyriadPro-Bold") -> [family, style]
        try:
            faces = fontfaces.families()
            all_faces, _bf, _bn = fontfaces.index()
            aliases = {}
            for f in all_faces:
                for name in (f["ps"], f["full"], f["legacy_family"]):
                    k = fontfaces.compact(name)
                    if k and k != fontfaces.compact(f["family"]) and k not in aliases:
                        aliases[k] = [f["family"], f["style"]]
        except Exception:
            faces, aliases = {}, {}
        fonts = sorted(faces, key=str.casefold) if faces else ps_actions.list_system_fonts()
        return jsonify({"fonts": fonts, "faces": faces, "aliases": aliases})

    @app.route("/api/image_size")
    def image_size():
        path = request.args.get("path", "")
        blocked = _reject_unallowed_path(path)
        if blocked:
            return blocked
        try:
            from PIL import Image

            with Image.open(path) as im:
                return jsonify({"ok": True, "width": im.width, "height": im.height, "path": path})
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 400

    # ------------------------------------------------------------- PSD memory
    @app.route("/api/psd/memory", methods=["POST"])
    def psd_memory_summary():
        """What project a PSD carries (settings, Excel, game/market/version)."""
        from .. import psd_memory

        path = str((request.get_json(force=True, silent=True) or {}).get("path") or "").strip().strip('"')
        if not path or not os.path.isfile(path):
            return jsonify({"ok": False, "error": "PSD not found."}), 400
        return jsonify(psd_memory.summary(path))

    @app.route("/api/psd/restore", methods=["POST"])
    def psd_memory_restore():
        """Continue working on a PSD: its own saved project becomes the session."""
        from .. import psd_memory

        path = str((request.get_json(force=True, silent=True) or {}).get("path") or "").strip().strip('"')
        if not path or not os.path.isfile(path):
            return jsonify({"ok": False, "error": "PSD not found."}), 400
        res = psd_memory.restore(path, _config())
        if not res.get("ok"):
            return jsonify(res), 400
        cfg = dict(engine_api.DEFAULT_CONFIG)
        cfg.update(res["config"])
        path_policy.grant(path)
        path_policy.grant_config_paths(cfg)
        notes = list(res.get("notes") or [])
        try:                                          # the PSD joins Recent games: Update PSD shows there when its Excel changes
            from .. import games

            listed = games.adopt_psd(cfg, path)
            if listed:
                notes.append(listed)
        except Exception as exc:                      # never block opening the PSD over the games list
            notes.append(f"Could not add this PSD to Recent games: {exc}")
        engine_api.record_recent_project(cfg, os.path.dirname(path), os.path.splitext(os.path.basename(path))[0])
        _set_config(cfg)
        return jsonify({"ok": True, "config": cfg, "notes": notes, "identity": res.get("identity") or {}})

    # ------------------------------------------------------------- native dialogs
    @app.route("/api/native/browse", methods=["POST"])
    def native_browse():
        """Open the real Windows folder/file dialog (the browser can't give full paths)."""
        from . import native_dialogs

        data = request.get_json(force=True, silent=True) or {}
        path = native_dialogs.pick(str(data.get("kind") or "dir"), str(data.get("title") or ""),
                                   str(data.get("initial") or ""))
        if path:
            path_policy.grant(path)
        return jsonify({"ok": bool(path), "path": path})

    # ------------------------------------------------------------- games
    # Game -> Market -> Version (games.py). A game folder holds pshelp_game.json.
    @app.route("/api/games")
    def games_list():
        from .. import games

        cfg = _config()
        return jsonify({"ok": True, "games": games.list_games(),
                        "active_game": cfg.get("active_game") or "", "active_market": cfg.get("active_market") or ""})

    @app.route("/api/games/discover", methods=["POST"])
    def games_discover():
        from .. import games

        folder = str((request.get_json(force=True, silent=True) or {}).get("folder") or "").strip().strip('"')
        if not folder or not os.path.isdir(folder):
            return jsonify({"ok": False, "error": "Folder not found."}), 400
        return jsonify(games.discover(folder))

    @app.route("/api/games/psd_settings", methods=["POST"])
    def games_psd_settings():
        """Read fonts, sizes, colours, spacing and layer styles from a reference PSD (read only)."""
        from .. import psd_style_import

        data = request.get_json(force=True, silent=True) or {}
        psd_path = str(data.get("psd_path") or "").strip().strip('"')
        if not psd_path or not os.path.isfile(psd_path):
            return jsonify({"ok": False, "error": "PSD file not found."}), 400
        path_policy.grant(psd_path)
        try:
            out = psd_style_import.analyse(psd_path)
        except Exception as exc:
            return jsonify({"ok": False, "error": f"Could not read the PSD: {exc}"}), 400
        return jsonify(out), (200 if out.get("ok") else 400)

    @app.route("/api/games/create", methods=["POST"])
    def games_create():
        from .. import games

        data = request.get_json(force=True, silent=True) or {}
        folder = str(data.get("folder") or "").strip().strip('"')
        if not folder or not os.path.isdir(folder):
            return jsonify({"ok": False, "error": "Folder not found."}), 400
        path_policy.grant_tree(folder)                 # the user chose this game folder
        markets = data.get("markets")
        if markets is not None:
            markets = [m for m in markets if isinstance(m, dict) and m.get("excel_path") and os.path.isfile(m["excel_path"])]
        try:
            mode = str(data.get("settings_mode") or "")
            mode = mode if mode in ("new", "psd") else "current"
            psd_settings = data.get("psd_settings") if mode == "psd" else None
            if mode == "psd" and not isinstance(psd_settings, dict):
                return jsonify({"ok": False, "error": "Read the styles from a PSD first."}), 400
            game = games.create(folder, str(data.get("name") or "").strip(), base_config=_config(), markets=markets,
                                settings_mode=mode, defaults=engine_api.DEFAULT_CONFIG, psd_settings=psd_settings)
        except ValueError as exc:
            return jsonify({"ok": False, "error": str(exc)}), 400
        out = games.summary(game)
        out["not_copied"] = game.get("not_copied") or []
        out["settings_mode"] = game.get("settings_mode") or ""
        return jsonify({"ok": True, "game": out})

    @app.route("/api/games/<game_id>/psd_style", methods=["POST"])
    def games_psd_style(game_id):
        """Mimic a PSD design on an existing game: only the fields / layer styles ticked in the review
        (psd_settings = {source, fields, styles}, from /api/games/psd_settings), and the PSD's background."""
        from .. import games, psd_style_import

        data = request.get_json(force=True, silent=True) or {}
        ps = data.get("psd_settings")
        if not isinstance(ps, dict) or not ps.get("source") or not os.path.isfile(str(ps.get("source"))):
            return jsonify({"ok": False, "error": "Read the design from a PSD first."}), 400
        path_policy.grant(str(ps["source"]))
        game = games.get(game_id)
        if not game:
            return jsonify({"ok": False, "error": "Game not found."}), 404
        cfg = _config()
        if cfg.get("active_game") == game_id:
            # the game being worked on: its settings are the session's (a game-file-only change would be
            # written over by the next save) — applied to the session, which saves into the game
            new = psd_style_import.apply(dict(cfg), ps.get("fields"), ps.get("styles"))
            bg = games.psd_background(ps, game.get("folder") or "")
            if bg:
                new["bg_path"], new["bg_source"] = bg, "image"
            _set_config(new)
            game = games.get(game_id) or game
        else:
            game = games.restyle(game, ps)
        return jsonify({"ok": True, "game": games.summary(game), "active": cfg.get("active_game") == game_id,
                        "config": _config() if cfg.get("active_game") == game_id else None})

    @app.route("/api/games/<game_id>", methods=["GET", "DELETE"])
    def games_one(game_id):
        from .. import games

        if request.method == "DELETE":
            cfg = _config()
            if cfg.get("active_game") == game_id:
                cfg.pop("active_game", None)
                cfg.pop("active_market", None)
                _set_config(cfg)
            return jsonify(games.unregister(game_id))
        game = games.get(game_id)
        if game is None:
            return jsonify({"ok": False, "error": "Game not found."}), 404
        out = games.summary(game)
        out["market_versions"] = {m["id"]: m.get("versions") or [] for m in game.get("markets") or []}
        return jsonify({"ok": True, "game": out})

    @app.route("/api/games/<game_id>/markets", methods=["POST"])
    def games_add_market(game_id):
        from .. import games

        data = request.get_json(force=True, silent=True) or {}
        game = games.get(game_id)
        excel = str(data.get("excel_path") or "").strip().strip('"')
        if game is None:
            return jsonify({"ok": False, "error": "Game not found."}), 404
        if not excel or not os.path.isfile(excel):
            return jsonify({"ok": False, "error": "Excel file not found."}), 400
        market = games.add_market(game, excel, str(data.get("name") or "").strip())
        return jsonify({"ok": True, "market": games.market_status(market)})

    @app.route("/api/games/<game_id>/markets/<market_id>/changes")
    def games_market_changes(game_id, market_id):
        """Pages changed in the market's Excel since its last version."""
        from .. import games

        game = games.get(game_id)
        market = games.find_market(game, market_id) if game else None
        if market is None:
            return jsonify({"ok": False, "error": "Market not found."}), 404
        limit = int((game.get("style") or {}).get("max_col_limit") or 12)
        return jsonify({"ok": True, **games.changed_pages(market, limit)})

    @app.route("/api/games/<game_id>/open", methods=["POST"])
    def games_open(game_id):
        """Work on one market: its Excel + the game's shared style become the session."""
        from .. import games

        data = request.get_json(force=True, silent=True) or {}
        game = games.get(game_id)
        if game is None:
            return jsonify({"ok": False, "error": "Game not found."}), 404
        try:
            cfg = games.open_market(game, str(data.get("market_id") or ""), _config(),
                                    defaults=engine_api.DEFAULT_CONFIG)
        except KeyError as exc:
            return jsonify({"ok": False, "error": str(exc)}), 404
        if data.get("update"):
            cfg["update_mode"] = True                  # one-click update of the last built PSD
        engine_api.record_recent_project(cfg, game["folder"], game.get("name") or "")
        _set_config(cfg)
        return jsonify({"ok": True, "config": cfg})

    @app.route("/api/games/<game_id>/thumb")
    def games_thumb(game_id):
        """The game's card picture on the Dashboard: its Paytable page (else its first page),
        drawn with the game's own look. Kept beside the games list; redrawn when the Excel or
        the look changes."""
        import hashlib

        from .. import games
        from . import page_thumbs

        game = games.get(game_id)
        if game is None:
            return jsonify({"ok": False}), 404
        market = next((m for m in game.get("markets") or [] if os.path.isfile(m.get("excel_path") or "")), None)
        if market is None:
            return jsonify({"ok": False, "error": "No Excel found."}), 404
        excel = market["excel_path"]
        try:
            from openpyxl import load_workbook

            wb = load_workbook(excel, read_only=True)
            names = [ws.title for ws in wb.worksheets if getattr(ws, "sheet_state", "visible") == "visible"]
            wb.close()
        except Exception:
            return jsonify({"ok": False, "error": "Excel unreadable."}), 404
        sheet = next((n for n in names if "paytable" in re.sub(r"[^a-z]", "", n.casefold())), names[0] if names else "")
        style = json.dumps(game.get("style") or {}, sort_keys=True, default=str)
        key = hashlib.sha1(f"{excel}|{os.path.getmtime(excel)}|{sheet}|{style}".encode("utf-8")).hexdigest()[:16]
        folder = os.path.join(games._store_dir(), "thumbs")
        path = os.path.join(folder, f"{game_id}-{key}.png")
        if not os.path.isfile(path):
            try:
                cfg = games.open_market(game, market["id"], {}, defaults=engine_api.DEFAULT_CONFIG)
                cfg.pop("active_game", None)                     # a picture only: never touches the game
                result = page_thumbs.render_sheet_preview(excel, sheet, cfg)
                if not result.get("ok") or not os.path.isfile(result.get("path") or ""):
                    return jsonify({"ok": False, "error": result.get("error") or "No preview."}), 404
                from PIL import Image

                os.makedirs(folder, exist_ok=True)
                with Image.open(result["path"]) as im:
                    im = im.convert("RGB")
                    im.thumbnail((640, 640))
                    im.save(path, "PNG")
                for old in os.listdir(folder):                   # earlier pictures of this game
                    if old.startswith(f"{game_id}-") and old != os.path.basename(path):
                        try:
                            os.remove(os.path.join(folder, old))
                        except OSError:
                            pass
            except Exception as exc:
                return jsonify({"ok": False, "error": str(exc)}), 404
        return send_file(path, mimetype="image/png", max_age=0)

    @app.route("/api/games/check_excel", methods=["POST"])
    def games_check_excel():
        """Before the open game takes another Excel: is it this game's? (else the user is asked)"""
        from .. import games

        data = request.get_json(force=True, silent=True) or {}
        path = str(data.get("excel_path") or "").strip().strip('"')
        cfg = _config()
        game = games.get(cfg.get("active_game") or "") if cfg.get("active_game") else None
        if game is None or not path or not os.path.isfile(path):
            return jsonify({"ok": True, "same": True, "no_game": game is None})
        market = games.find_market(game, cfg.get("active_market") or "") or {}
        return jsonify({"ok": True, "market": market.get("name") or "", **games.check_excel(game, path)})

    @app.route("/api/games/accept_excel", methods=["POST"])
    def games_accept_excel():
        """The user confirmed the Excel belongs to the open game (e.g. a much-changed revision)."""
        from .. import games

        data = request.get_json(force=True, silent=True) or {}
        path = str(data.get("excel_path") or "").strip().strip('"')
        game = games.get(_config().get("active_game") or "")
        if game is None or not os.path.isfile(path):
            return jsonify({"ok": False, "error": "No open game, or the Excel is missing."}), 400
        games.accept_excel(game, path)
        return jsonify({"ok": True})

    @app.route("/api/games/close", methods=["POST"])
    def games_close():
        cfg = _config()
        cfg.pop("active_game", None)
        cfg.pop("active_market", None)
        _set_config(cfg)
        return jsonify({"ok": True, "config": cfg})

    # ------------------------------------------------------------- presets
    @app.route("/api/presets")
    def presets():
        return jsonify({"presets": engine_api.list_presets()})

    @app.route("/api/presets/<name>", methods=["GET", "POST", "DELETE"])
    def preset(name):
        if request.method == "GET":
            try:
                return jsonify({"ok": True, "preset": engine_api.load_preset(name)})
            except FileNotFoundError as e:
                return jsonify({"ok": False, "error": str(e)}), 404
        if request.method == "POST":
            data = request.get_json(force=True, silent=True) or {}
            cfg = data.get("config") or _config()
            engine_api.save_preset(name, cfg)
            return jsonify({"ok": True, "name": engine_api._sanitize_preset_name(name)})
        engine_api.delete_preset(name)
        return jsonify({"ok": True})

    # ------------------------------------------------------------- build
    @app.route("/api/psd/finish_text", methods=["POST"])
    def psd_finish_text():
        """Let Photoshop adopt a built PSD's text layers (clears the
        'requires a layout change' warning); starts Photoshop if needed."""
        from ..psd_writer import photoshop_finish

        path = str((request.get_json(force=True, silent=True) or {}).get("path") or "").strip()
        if not path or not os.path.isfile(path) or not path.lower().endswith((".psd", ".psb")):
            return jsonify({"ok": False, "error": "PSD not found."}), 400
        if not photoshop_finish.available("always"):
            return jsonify({"ok": False, "error": "Photoshop is not installed or cannot be reached."}), 400
        msg = photoshop_finish.finish(path)
        ok = msg.startswith("[PSD] Photoshop finished")
        if ok:
            photoshop_finish.remove_fix_script(path)     # no longer needed
        return jsonify({"ok": ok, "message": msg.replace("[PSD] ", "")})

    @app.route("/api/build", methods=["POST"])
    def start_build():
        data = request.get_json(force=True, silent=True) or {}
        mode = data.get("mode", "both")
        if mode not in ("psd", "png", "both"):
            return jsonify({"ok": False, "error": f"Unknown mode '{mode}'"}), 400
        cfg = _config()
        if data.get("config"):
            cfg.update(data["config"])
        cfg["build_output"] = mode
        _set_config(cfg)
        if not cfg.get("excel_path") or not os.path.isfile(cfg.get("excel_path", "")):
            return jsonify({"ok": False, "error": "Choose an Excel file before building."}), 400
        job_id = job_manager.start(cfg, mode)
        return jsonify({"ok": True, "job_id": job_id})

    @app.route("/api/jobs/<job_id>")
    def job_status(job_id):
        job = job_manager.get(job_id)
        if job is None:
            return jsonify({"ok": False, "error": "Job not found"}), 404
        return jsonify({"ok": True, "job": job})

    @app.route("/api/jobs/<job_id>/cancel", methods=["POST"])
    def job_cancel(job_id):
        ok = job_manager.cancel(job_id)
        return jsonify({"ok": ok})

    @app.route("/api/open-dir", methods=["POST"])
    def open_dir():
        """Open a local output folder in the platform file manager."""
        data = request.get_json(force=True, silent=True) or {}
        path = str(data.get("path") or "").strip()
        if not path or not os.path.isdir(path):
            return jsonify({"ok": False, "error": "Folder does not exist."}), 400
        blocked = _reject_unallowed_path(path)
        if blocked:
            return blocked
        import subprocess

        try:
            if sys.platform.startswith("win"):
                subprocess.Popen(["explorer", os.path.normpath(path)])
            elif sys.platform == "darwin":
                subprocess.Popen(["open", path])
            else:
                subprocess.Popen(["xdg-open", path])
            return jsonify({"ok": True})
        except Exception as exc:
            return jsonify({"ok": False, "error": str(exc)}), 500

    # ------------------------------------------------------------- export symbols
    @app.route("/api/symbols/list", methods=["POST"])
    def symbols_list():
        """List exportable layers (pixel/shape/text/smart-object/group) of a PSD."""
        data = request.get_json(force=True, silent=True) or {}
        psd_path = str(data.get("psd_path") or "").strip()
        if not psd_path or not os.path.isfile(psd_path):
            return jsonify({"ok": False, "error": "PSD file not found."}), 400
        blocked = _reject_unallowed_path(psd_path)
        if blocked:
            return blocked
        if not symbol_exporter.psd_tools_available():
            return jsonify({"ok": False, "error": "psd-tools is not installed (pip install psd-tools)."}), 400
        try:
            return jsonify(symbol_exporter.list_psd_layers(psd_path))
        except Exception as exc:
            return jsonify({"ok": False, "error": f"Could not read PSD: {exc}"}), 400

    @app.route("/api/symbols/preview")
    def symbols_preview():
        """Return a PNG preview of a single layer."""
        psd_path = str(request.args.get("psd_path") or "").strip()
        key = str(request.args.get("key") or "").strip()
        try:
            max_size = max(32, min(512, int(request.args.get("max") or 200)))
        except (TypeError, ValueError):
            max_size = 200
        if not psd_path or not os.path.isfile(psd_path):
            return jsonify({"ok": False, "error": "PSD file not found."}), 400
        blocked = _reject_unallowed_path(psd_path)
        if blocked:
            return blocked
        if not key:
            return jsonify({"ok": False, "error": "Missing layer key."}), 400
        try:
            img = symbol_exporter.render_layer_image(psd_path, key, max_size)
        except Exception as exc:
            return jsonify({"ok": False, "error": str(exc)}), 400
        buf = io.BytesIO()
        img.save(buf, "PNG")
        buf.seek(0)
        resp = Response(buf.getvalue(), mimetype="image/png")
        resp.headers["Cache-Control"] = "no-store"
        return resp

    @app.route("/api/symbols/export", methods=["POST"])
    def symbols_export():
        """Export selected layers as trimmed, transparent PNG icons."""
        data = request.get_json(force=True, silent=True) or {}
        psd_path = str(data.get("psd_path") or "").strip()
        keys = [str(k) for k in (data.get("keys") or [])]
        output_dir = str(data.get("output_dir") or "").strip()
        if not psd_path or not os.path.isfile(psd_path):
            return jsonify({"ok": False, "error": "PSD file not found."}), 400
        blocked = _reject_unallowed_path(psd_path) or _reject_unallowed_path(output_dir)
        if blocked:
            return blocked
        if not output_dir:
            return jsonify({"ok": False, "error": "Choose an output folder first."}), 400
        if not keys:
            return jsonify({"ok": False, "error": "Select at least one layer to export."}), 400
        try:
            result = symbol_exporter.export_selected_layers(psd_path, keys, output_dir)
        except Exception as exc:
            return jsonify({"ok": False, "error": f"Export failed: {exc}"}), 500
        return jsonify({"ok": True, **result})

    # ------------------------------------------------------------- symbols (fast scan)
    def _symbol_targets(cfg):
        """Where exported symbols / background go: the market's Working/Symbols and
        Working/BG (depot games), else <output folder>/Symbols and /BG."""
        base = str(cfg.get("output_dir") or "").strip()
        if not base:
            excel = str(cfg.get("excel_path") or "")
            base = os.path.dirname(excel) if excel else ""
        if not base:
            return "", ""
        return os.path.join(base, "Symbols"), os.path.join(base, "BG")

    def _excel_tokens(cfg):
        excel = str(cfg.get("excel_path") or "")
        if not excel or not os.path.isfile(excel):
            return []
        try:
            from ..icon_mapping import scan_excel_icon_tokens

            toks = set(scan_excel_icon_tokens(excel))
        except Exception:
            toks = set()
        # the paytable's own symbols too: many AGRs write them plain ("ACE", "KING") rather than <ACE>
        try:
            from openpyxl import load_workbook as _lw
            from ..dynamic_pages.paytable import card_templates as _ct

            names = _lw(excel, read_only=True).sheetnames
            have = {t.casefold() for t in toks}
            for sheet in names:
                if "paytable" not in sheet.replace(" ", "").casefold():
                    continue
                keys, _scat = _ct._clean_keys(engine_api.paytable_sheet_structure(excel, sheet).get("block_keys") or [])
                for k in keys:
                    if k.casefold() not in have and not k.isdigit():
                        toks.add(k.upper())
                        have.add(k.casefold())
        except Exception:
            pass
        from .. import symbol_match as _sm

        # not symbols: formula pieces ("&$H$49&"), placeholders (X, FEATURE NAME, TRANSLATION OF SYMBOL)
        return sorted((t for t in toks if _sm.is_symbol_token(t)), key=lambda t: t.casefold())

    def _game_symbols_dir(cfg):
        """Where a game's symbols go: the game folder's Symbols — one folder for every market — else the
        market's (_symbol_targets)."""
        gid = str(cfg.get("active_game") or "")
        if gid:
            try:
                from .. import games

                game = games.get(gid)
                folder = str((game or {}).get("folder") or "")
                if folder and os.path.isabs(folder):
                    return os.path.join(folder, "Symbols")
            except Exception:
                pass
        return _symbol_targets(cfg)[0]

    @app.route("/api/symbols/scan", methods=["POST"])
    def symbols_scan():
        """Symbols, backgrounds and pay-line pictures of a PSD (one entry per symbol)."""
        from . import symbol_scan

        data = request.get_json(force=True, silent=True) or {}
        psd_path = str(data.get("psd_path") or "").strip().strip('"')
        if not psd_path or not os.path.isfile(psd_path):
            return jsonify({"ok": False, "error": "PSD file not found."}), 400
        path_policy.grant(psd_path)
        try:
            out = symbol_scan.public(symbol_scan.scan(psd_path))
        except Exception as exc:
            return jsonify({"ok": False, "error": f"Could not read the PSD: {exc}"}), 400
        cfg = _config()
        tokens = _excel_tokens(cfg)
        sym_dir, bg_dir = _symbol_targets(cfg)
        out["tokens"] = tokens
        out["suggested"] = symbol_scan.suggest_names([e["name"] for e in out["symbols"]], tokens)
        out["symbols_dir"], out["bg_dir"] = sym_dir, bg_dir
        return jsonify(out)

    @app.route("/api/symbols/agr_match", methods=["POST"])
    def symbols_agr_match():
        """{psd_path, agr_path?}: the PSD's pictures named from the AGR it was made from, matched to this
        game's symbols (symbol_match.match) — for the review screen. Nothing is written."""
        from .. import symbol_match

        data = request.get_json(force=True, silent=True) or {}
        psd_path = str(data.get("psd_path") or "").strip().strip('"')
        agr_path = str(data.get("agr_path") or "").strip().strip('"')
        if not psd_path or not os.path.isfile(psd_path):
            return jsonify({"ok": False, "error": "PSD file not found."}), 400
        if agr_path and not os.path.isfile(agr_path):
            return jsonify({"ok": False, "error": "AGR file not found."}), 400
        path_policy.grant(psd_path)
        cfg = _config()
        tokens = _excel_tokens(cfg)
        if not tokens:
            return jsonify({"ok": False, "error": "This game's Excel names no symbols (or no Excel is open)."}), 400
        try:
            out = symbol_match.match(psd_path, tokens, agr_path)
        except Exception as exc:
            return jsonify({"ok": False, "error": f"Could not read the PSD / AGR: {exc}"}), 400
        out["psd_path"] = psd_path
        out["symbols_dir"] = _game_symbols_dir(cfg)
        out["existing"] = {r["token"]: os.path.exists(os.path.join(out["symbols_dir"], symbol_match.file_name(r["token"])))
                           for r in out["rows"]} if out["symbols_dir"] else {}
        return jsonify(out)

    @app.route("/api/symbols/agr_save", methods=["POST"])
    def symbols_agr_save():
        """{psd_path, picks: [{token, key}], folder, choices?: {token: "replace" | "keep"}}: one PNG per
        token, named after it, into `folder`; the game uses that folder and every token is linked. A file
        another picture already has: 409 {needs_choice, ask: [...]} until a choice is sent for it."""
        from .. import symbol_match

        data = request.get_json(force=True, silent=True) or {}
        psd_path = str(data.get("psd_path") or "").strip().strip('"')
        folder = str(data.get("folder") or "").strip().strip('"')
        picks = [p for p in (data.get("picks") or []) if isinstance(p, dict) and p.get("token") and p.get("key")]
        if not psd_path or not os.path.isfile(psd_path):
            return jsonify({"ok": False, "error": "PSD file not found."}), 400
        if not folder or not os.path.isabs(folder):
            return jsonify({"ok": False, "error": "Choose the folder to save the symbols in (a full path)."}), 400
        if not picks:
            return jsonify({"ok": False, "error": "No symbol has a picture picked."}), 400
        path_policy.grant_tree(folder)
        try:
            res = symbol_match.save(psd_path, picks, folder, data.get("choices") or {})
        except Exception as exc:
            return jsonify({"ok": False, "error": f"Saving failed: {exc}"}), 500
        if res["ask"]:
            return jsonify({"ok": False, "needs_choice": True, "ask": res["ask"],
                            "error": f"{len(res['ask'])} symbol file(s) already have another picture."}), 409
        cfg = _config()
        cfg["icon_folder"] = folder
        maps = dict(cfg.get("icon_mappings") or {})
        from ..icon_mapping import normalize_token

        for tok, fn in (res.get("files") or {}).items():
            # the file is the token's own name; a token with characters a file can't have is linked
            if normalize_token(os.path.splitext(fn)[0]) != normalize_token(tok):
                maps[tok] = fn
            elif maps.get(tok) and maps[tok] != fn:
                maps.pop(tok, None)                       # an older link to another file: this one now
        cfg["icon_mappings"] = maps
        try:
            from .. import icon_mapping as _im

            _im._clear_folder_cache(folder)
        except Exception:
            pass
        _set_config(cfg)
        return jsonify({"ok": True, **{k: v for k, v in res.items() if k != "ask"}, "folder": folder, "config": cfg})

    @app.route("/api/symbols/thumb")
    def symbols_thumb():
        from . import symbol_scan

        psd_path = str(request.args.get("psd_path") or "").strip()
        key = str(request.args.get("key") or "").strip()
        if not psd_path or not os.path.isfile(psd_path) or not key:
            return jsonify({"ok": False, "error": "Not found."}), 404
        blocked = _reject_unallowed_path(psd_path)
        if blocked:
            return blocked
        try:
            data = symbol_scan.thumbnail(psd_path, key)
        except Exception as exc:
            return jsonify({"ok": False, "error": str(exc)}), 400
        if not data:
            return jsonify({"ok": False, "error": "Nothing to show."}), 404
        resp = Response(data, mimetype="image/png")
        resp.headers["Cache-Control"] = "max-age=600"
        return resp

    @app.route("/api/symbols/export_picked", methods=["POST"])
    def symbols_export_picked():
        """Save picked symbols (and a background) and make the project use them."""
        from . import symbol_scan

        data = request.get_json(force=True, silent=True) or {}
        psd_path = str(data.get("psd_path") or "").strip()
        items = [i for i in (data.get("items") or []) if isinstance(i, dict) and i.get("key")]
        cfg = _config()
        sym_default, bg_default = _symbol_targets(cfg)
        sym_dir = str(data.get("symbols_dir") or "").strip() or sym_default
        bg_dir = str(data.get("bg_dir") or "").strip() or bg_default
        if not psd_path or not os.path.isfile(psd_path):
            return jsonify({"ok": False, "error": "PSD file not found."}), 400
        if not items:
            return jsonify({"ok": False, "error": "Pick at least one symbol."}), 400
        if not sym_dir:
            return jsonify({"ok": False, "error": "Choose where to save the symbols."}), 400
        path_policy.grant_tree(sym_dir)
        path_policy.grant_tree(bg_dir)
        on_conflict = str(data.get("on_conflict") or "ask")
        if on_conflict == "ask":
            clash = symbol_scan.conflicts(items, sym_dir, bg_dir)
            if clash:                                    # never overwrite user assets silently
                return jsonify({"ok": False, "needs_choice": True, "conflicts": clash,
                                "error": f"{len(clash)} file(s) with these names already exist."}), 409
        try:
            res = symbol_scan.export(psd_path, items, sym_dir, bg_dir,
                                     on_conflict="replace" if on_conflict == "replace" else "keep_both")
        except Exception as exc:
            return jsonify({"ok": False, "error": f"Export failed: {exc}"}), 500
        symbols = [f for f in res["files"] if f["kind"] == "symbol"]
        backgrounds = [f for f in res["files"] if f["kind"] == "background"]
        if symbols:
            cfg["icon_folder"] = sym_dir                  # the project now uses these symbols
        if backgrounds:
            cfg["bg_path"] = backgrounds[0]["path"]
            cfg["bg_source"] = "image"
        if symbols or backgrounds:
            _set_config(cfg)
        return jsonify({"ok": True, **res, "symbols_dir": sym_dir, "bg_dir": bg_dir, "config": cfg})

    @app.route("/api/symbols/mapping", methods=["GET", "POST"])
    def symbols_mapping():
        """GET: the game's Excel symbol tokens and what picture each uses.
        POST {links: {token: file or ""}}: save the links (per game, icon_mappings)."""
        from .. import symbol_tokens

        cfg = _config()
        if request.method == "POST":
            body = request.get_json(force=True, silent=True) or {}
            links = body.get("links") or {}
            if not isinstance(links, dict):
                return jsonify({"ok": False, "error": "links must be an object."}), 400
            seen = body.get("tokens")
            cfg = symbol_tokens.apply(cfg, links, seen if isinstance(seen, list) else None)
            _set_config(cfg)
        return jsonify({**symbol_tokens.state(cfg), "config": cfg if request.method == "POST" else None})

    @app.route("/api/symbols/check", methods=["POST"])
    def symbols_check():
        """Before a build: can every symbol the Excel uses be found?"""
        from .. import symbol_tokens

        data = request.get_json(force=True, silent=True) or {}
        cfg = dict(_config())
        if isinstance(data.get("config"), dict):
            cfg.update(data["config"])
        return jsonify(symbol_tokens.check(cfg))

    @app.route("/api/symbols/use_folder", methods=["POST"])
    def symbols_use_folder():
        """"I already have a symbols folder": copy its pictures into Working/Symbols
        (when the market has one) and use them."""
        import shutil

        data = request.get_json(force=True, silent=True) or {}
        folder = str(data.get("folder") or "").strip().strip('"')
        if not folder or not os.path.isdir(folder):
            return jsonify({"ok": False, "error": "Folder not found."}), 400
        cfg = _config()
        target, _bg = _symbol_targets(cfg)
        copied = 0
        if data.get("copy", True) and target and os.path.normcase(os.path.abspath(target)) != os.path.normcase(os.path.abspath(folder)):
            pics = [fn for fn in os.listdir(folder) if fn.lower().endswith((".png", ".jpg", ".jpeg", ".webp"))]
            on_conflict = str(data.get("on_conflict") or "ask")
            clash = [os.path.join(target, fn) for fn in pics if os.path.exists(os.path.join(target, fn))]
            if clash and on_conflict == "ask":
                return jsonify({"ok": False, "needs_choice": True, "conflicts": clash,
                                "error": f"{len(clash)} file(s) with these names already exist in {target}."}), 409
            os.makedirs(target, exist_ok=True)
            for fn in pics:
                dest = os.path.join(target, fn)
                if os.path.exists(dest) and on_conflict != "replace":
                    stem, ext = os.path.splitext(dest)
                    n = 2
                    while os.path.exists(f"{stem}_{n}{ext}"):
                        n += 1
                    dest = f"{stem}_{n}{ext}"
                shutil.copy2(os.path.join(folder, fn), dest)
                copied += 1
            use = target
        else:
            use = folder
        path_policy.grant_tree(use)
        cfg["icon_folder"] = use
        _set_config(cfg)
        return jsonify({"ok": True, "icon_folder": use, "copied": copied, "config": cfg})

    @app.route("/api/symbols/provide", methods=["POST"])
    def symbols_provide():
        """"Provide symbols": find the build's MISSING symbols in a folder the user picks and copy just
        those into the game's symbols folder. Never overwrites: a name already taken there is saved
        as the token's own name ("<Red Bag>" -> "Red Bag.png") so it still matches."""
        import shutil
        from .. import symbol_tokens as _st
        from ..icon_mapping import resolve_icon_path

        data = request.get_json(force=True, silent=True) or {}
        src = str(data.get("folder") or "").strip().strip('"')
        if not src or not os.path.isdir(src):
            return jsonify({"ok": False, "error": "Folder not found."}), 400
        cfg = _config()
        before = _st.check(cfg)
        missing = list(before.get("unresolved") or [])
        if not missing:
            return jsonify({"ok": True, "found": [], "missing": [], "icon_folder": cfg.get("icon_folder"), "config": cfg})
        target = str(cfg.get("icon_folder") or "")
        if not target or not os.path.isdir(target):
            target = _symbol_targets(cfg)[0] or src
        path_policy.grant_tree(target)
        files = _st.symbol_files(src)
        found = []
        for tok in missing:
            path = resolve_icon_path(tok, src, {}) or (os.path.join(src, _st.suggest(tok, files)) if _st.suggest(tok, files) else None)
            if not path or not os.path.isfile(path):
                continue
            if os.path.normcase(os.path.abspath(target)) == os.path.normcase(os.path.abspath(src)):
                found.append({"token": tok, "file": os.path.basename(path)})
                continue
            os.makedirs(target, exist_ok=True)
            dest = os.path.join(target, os.path.basename(path))
            if os.path.exists(dest):                            # taken by another picture: use the token's name
                dest = os.path.join(target, re.sub(r'[\\/:*?"<>|]+', "_", tok) + os.path.splitext(path)[1])
            if os.path.exists(dest):
                stem, ext = os.path.splitext(dest)
                n = 2
                while os.path.exists(f"{stem}_{n}{ext}"):
                    n += 1
                dest = f"{stem}_{n}{ext}"
            shutil.copy2(path, dest)
            found.append({"token": tok, "file": os.path.basename(dest)})
            if os.path.splitext(os.path.basename(dest))[0].casefold() != tok.casefold():
                cfg.setdefault("icon_mappings", {})[tok] = os.path.basename(dest)   # linked, whatever its name
        if found:
            cfg["icon_folder"] = target
            try:
                from .. import icon_mapping as _im
                _im._clear_folder_cache(target)
            except Exception:
                pass
            _set_config(cfg)
        after = _st.check(cfg)
        return jsonify({"ok": True, "found": found, "missing": after.get("unresolved") or [],
                        "icon_folder": target, "config": cfg})

    # ------------------------------------------------------------- AI
    @app.route("/api/ai", methods=["POST"])
    def ai():
        data = request.get_json(force=True, silent=True) or {}
        command = (data.get("command") or "").strip()
        if not command:
            return jsonify({"ok": False, "error": "Empty command."}), 400
        result = engine_api.interpret_ai_command(_config(), command)
        if result.get("changes"):
            _set_config(result["config"])
        return jsonify({"ok": True, **result})

    # ------------------------------------------------------------- MIRA.AI
    @app.route("/api/mira/status")
    def mira_status():
        from .. import ai_assist

        return jsonify(ai_assist.mira_available())

    def _mira_setup_worker(model):
        """Background thread: install Ollama if needed, then pull the model.
        Progress is kept in _state["mira_setup"] for the GET poll endpoint."""
        from .. import ai_assist

        st = _state.setdefault("mira_setup", {})
        st.update({"state": "running", "model": model})

        def _progress(phase, message="", pct=None):
            cur = _state.setdefault("mira_setup", {})
            cur["phase"] = phase
            cur["message"] = message
            if pct is not None:
                cur["pct"] = round(pct)

        try:
            result = ai_assist.setup_ollama_and_model(model, _progress)
            st.update({"state": "done", "phase": "done", "message": result, "pct": 100})
        except Exception as exc:
            st.update({"state": "error", "phase": "error", "message": str(exc), "error": str(exc)})

    def _mira_setup_start(model=""):
        """Kick off the one-click AI setup unless one is already running."""
        from .. import ai_assist

        if (_state.get("mira_setup") or {}).get("state") == "running":
            return False
        model = str(model or "").strip() or ai_assist.MODEL
        _state["mira_setup"] = {"state": "queued", "phase": "start",
                                "message": "Starting…", "pct": 0, "model": model}
        threading.Thread(target=_mira_setup_worker, args=(model,), daemon=True).start()
        return True

    @app.route("/api/mira/setup", methods=["GET"])
    def mira_setup_status():
        from .. import ai_assist

        st = dict(_state.get("mira_setup") or {"state": "idle"})
        st.setdefault("model", ai_assist.MODEL)
        return jsonify(st)

    @app.route("/api/mira/setup", methods=["POST"])
    def mira_setup_start():
        data = request.get_json(force=True, silent=True) or {}
        model = str(data.get("model") or "").strip()
        started = _mira_setup_start(model)
        return jsonify({"ok": True, "started": started})

    @app.route("/api/mira/chat", methods=["POST"])
    def mira_chat():
        from .. import ai_assist
        from . import ps_actions

        data = request.get_json(force=True, silent=True) or {}
        command = (data.get("command") or "").strip()
        if not command:
            return jsonify({"ok": False, "error": "Empty command."}), 400
        sheets = data.get("sheets") or []
        if not sheets:
            scan = _state.get("scan") or {}
            excel = scan.get("excel") or {}
            sheets = [str(s.get("name", "")).strip() for s in excel.get("sheets", [])]
        fonts = data.get("fonts") or ps_actions.list_system_fonts()

        # ---- MIRA intents: undo / presets / review / batch ----------------
        if ai_assist.is_undo_command(command):
            snapshots = _state.setdefault("mira_undo", [])
            if snapshots:
                _set_config(snapshots.pop())
                return jsonify({"ok": True, "message": "Reverted the last MIRA change.",
                                "changes": {}, "config": _config(), "action": None})
            return jsonify({"ok": True, "message": "There is nothing to undo yet.",
                            "changes": {}, "config": _config(), "action": None})

        preset_cmd = ai_assist.parse_preset_command(command, engine_api.list_presets())
        if preset_cmd:
            op, name = preset_cmd
            if op == "list":
                names = engine_api.list_presets()
                msg = ("Your saved presets:\n- " + "\n- ".join(names)) if names \
                    else 'You have no saved presets yet. Say "save preset <name>" to save the current look.'
                return jsonify({"ok": True, "message": msg, "changes": {}, "config": _config(),
                                "action": None, "presets": names})
            if op == "save":
                cfg = dict(_config())
                cfg.pop("ai_suggestions", None)
                engine_api.save_preset(name, cfg)
                return jsonify({"ok": True, "message": f'Saved the current look as preset "{name}".',
                                "changes": {}, "config": _config(), "action": None, "preset": name})
            if op == "delete":
                engine_api.delete_preset(name)
                return jsonify({"ok": True, "message": f'Preset "{name}" deleted.',
                                "changes": {}, "config": _config(), "action": None})
            if op == "apply":
                try:
                    loaded = engine_api.load_preset(name)
                except FileNotFoundError as exc:
                    return jsonify({"ok": True, "message": str(exc), "changes": {},
                                    "config": _config(), "action": None})
                _state.setdefault("mira_undo", []).append(_config())
                if len(_state["mira_undo"]) > 5:
                    _state["mira_undo"] = _state["mira_undo"][-5:]
                _set_config(loaded)
                return jsonify({"ok": True, "message": f'Applied preset "{name}".', "changes": {},
                                "config": _config(), "action": None, "preset": name, "reload": True})

        dm = re.search(r"\bdownload(?: the)? model\b[\s:]*([\w.\-:]+)?", command, re.IGNORECASE)
        wants_setup = bool(
            re.search(r"\b(?:install|download|setup)\b", command, re.IGNORECASE)
            and re.search(r"\b(?:ollama|mira|ai assistant|the ai)\b", command, re.IGNORECASE)
        )
        if dm or wants_setup:
            model = (dm.group(1) or "").strip() if dm else ""
            started = _mira_setup_start(model)
            if not started:
                return jsonify({"ok": True,
                                "message": "The AI download is already running — follow the progress in the MIRA panel header.",
                                "changes": {}, "config": _config(), "action": None})
            label = model or ai_assist.MODEL
            return jsonify({"ok": True,
                            "message": f"Started: installing/downloading the AI model “{label}”. "
                                       "Follow the progress in the MIRA panel header.",
                            "changes": {}, "config": _config(), "action": None, "mira_hint": True})

        if ai_assist.is_review_command(command):
            cfg = _config()
            png = ai_assist.find_latest_png(cfg.get("output_dir")) or ai_assist.find_latest_png(cfg.get("output"))
            if not png and cfg.get("excel_path"):
                base = os.path.basename(os.path.splitext(str(cfg.get("excel_path", "")))[0])
                root = cfg.get("output_dir") or os.path.dirname(os.path.abspath(cfg["excel_path"]))
                png = ai_assist.find_latest_png(os.path.join(root, f"{base}_PNGs"))
            sheet = (data.get("sheets") or [""])[0]
            review = ai_assist.mira_review(png, cfg, sheet or "")
            _state["mira_pending"] = {"review_changes": review.get("changes") or {}}
            return jsonify({"ok": True, "pending": bool(review.get("changes")), "review": True,
                            "message": review["message"], "changes": {}, "config": cfg, "action": None,
                            "issues": review.get("issues") or []})

        if ai_assist.is_batch_command(command):
            cfg = _config()
            root = ai_assist.extract_folder_path(command)
            if not root or not os.path.isdir(root):
                excel = str(cfg.get("excel_path") or "")
                root = os.path.dirname(os.path.dirname(os.path.abspath(excel))) if os.path.isfile(excel) \
                    else os.path.abspath(os.curdir)
            det = ai_assist.detect_batch_projects(root)
            if det.get("error"):
                return jsonify({"ok": True, "message": det["error"], "changes": {},
                                "config": cfg, "action": None})
            projects = det["projects"]
            if not projects:
                return jsonify({"ok": True, "message": f"No game folders with an Excel workbook were found in {root}.",
                                "changes": {}, "config": cfg, "action": None})
            if ai_assist.is_affirmative(command) and _state.get("mira_batch_pending"):
                pending = _state.pop("mira_batch_pending")
                mode = str(pending.get("mode") or cfg.get("build_output") or "both")
                if mode not in ("psd", "png", "both"):
                    mode = "both"
                job_id = job_manager.start_batch(pending["projects"], pending["config"], mode)
                return jsonify({"ok": True, "message": f"Batch build started for {len(pending['projects'])} project(s) ({mode}).",
                                "changes": {}, "config": _config(), "action": "build", "job_id": job_id,
                                "batch": {"count": len(pending["projects"])}})
            proposal = ai_assist.mira_batch_propose(cfg, command, projects, fonts)
            _state["mira_batch_pending"] = {
                "projects": projects,
                "mode": str(cfg.get("build_output") or "both"),
                "config": cfg,
            }
            return jsonify({"ok": True, "pending": True, "batch": True, "message": proposal["message"],
                            "changes": {}, "config": cfg, "action": None,
                            "batch_projects": projects})

        # ---- project-folder flow: propose ---------------------------------
        folder = ai_assist.extract_folder_path(command)
        if folder and os.path.isdir(folder) and not ai_assist.is_affirmative(command):
            detection = ai_assist.detect_project(folder)
            if detection.get("error"):
                return jsonify({"ok": True, "message": detection["error"], "changes": {},
                                "config": _config(), "action": None})
            excel_dict = engine_api.scan_excel(detection["excel_path"]) if detection["excel_path"] else {"sheets": []}
            sheet_names = [str(s.get("name", "")).strip() for s in excel_dict.get("sheets", [])]
            proposal = ai_assist.mira_propose(_config(), command, detection, sheet_names, fonts)
            _state["mira_pending"] = {
                "detection": detection,
                "changes": proposal.get("changes") or {},
                "sheets": sheet_names,
            }
            return jsonify({
                "ok": True, "pending": True, "proposal": True,
                "message": proposal.get("message") or "",
                "changes": {}, "config": _config(), "action": None,
                "project": {"folder": folder, "sheets_count": len(sheet_names),
                            "sheets": sheet_names, "excel_path": detection.get("excel_path")},
            })

        # ---- project-folder flow: confirm/apply ---------------------------
        pending = _state.get("mira_pending")
        if pending and ai_assist.is_affirmative(command):
            if pending.get("review_changes") is not None:
                changes = pending["review_changes"]
                _state["mira_pending"] = None
                if changes:
                    cfg = _config()
                    prev = dict(cfg)
                    cfg.update(changes)
                    _set_config(cfg)
                    _state.setdefault("mira_undo", []).append(prev)
                    if len(_state["mira_undo"]) > 5:
                        _state["mira_undo"] = _state["mira_undo"][-5:]
                    keys = ", ".join(k.replace("_", " ") for k in changes)
                    return jsonify({"ok": True, "message": f"Applied {len(changes)} fix(es): {keys}. Rebuild to see the result.",
                                    "changes": changes, "config": _config(), "action": None, "reload": True})
                return jsonify({"ok": True, "message": "Nothing to apply — the render looked fine to me.",
                                "changes": {}, "config": _config(), "action": None})
            detection = pending["detection"]
            cfg = _config()
            applied = {}
            for key in ("excel_path", "icon_folder", "bg_path", "output_dir"):
                val = detection.get(key)
                if val:
                    cfg[key] = val
                    applied[key] = val
            created_output = False
            if detection.get("output_will_be_created"):
                try:
                    os.makedirs(detection["output_dir"], exist_ok=True)
                    created_output = True
                except OSError:
                    pass
            cfg.update(pending.get("changes") or {})
            applied.update(pending.get("changes") or {})
            cfg["selected_sheets"] = []
            cfg["render_all_pages"] = True
            _set_config(cfg)

            excel_dict = engine_api.scan_excel(cfg.get("excel_path", ""))
            icons = engine_api.scan_icons(cfg.get("excel_path", ""), cfg.get("icon_folder", ""), cfg.get("icon_mappings") or {}) if excel_dict.get("ok") else {"error": "Excel not loaded"}
            _state["scan"] = {"excel": excel_dict, "icons": icons}
            cfg = _config()
            cfg["ai_suggestions"] = _build_suggestions(excel_dict, icons)
            _set_config(cfg)
            _state["mira_pending"] = None

            sheet_names = [str(s.get("name", "")).strip() for s in excel_dict.get("sheets", [])]
            summary = ai_assist.project_summary(detection, cfg, sheet_names, created_output)
            result = {"message": summary, "changes": applied, "config": cfg, "action": None,
                      "project": {"folder": detection["folder"], "sheets_count": len(sheet_names),
                                  "sheets": sheet_names}}
            if ai_assist.wants_build(command):
                mode = str(cfg.get("build_output") or "both")
                if mode not in ("psd", "png", "both"):
                    mode = "both"
                if cfg.get("excel_path") and os.path.isfile(cfg.get("excel_path", "")):
                    result["job_id"] = job_manager.start(cfg, mode)
                    result["message"] += f"\nBuild started ({mode})."
                else:
                    result["message"] += "\nI could not start the build — no valid Excel file."
            return jsonify({"ok": True, **result})

        # ---- batch flow: plain confirmation -------------------------------
        if ai_assist.is_affirmative(command) and _state.get("mira_batch_pending"):
            pending_batch = _state.pop("mira_batch_pending")
            mode = str(pending_batch.get("mode") or _config().get("build_output") or "both")
            if mode not in ("psd", "png", "both"):
                mode = "both"
            job_id = job_manager.start_batch(pending_batch["projects"], pending_batch["config"], mode)
            return jsonify({"ok": True, "message": f"Batch build started for {len(pending_batch['projects'])} project(s) ({mode}).",
                            "changes": {}, "config": _config(), "action": "build", "job_id": job_id,
                            "batch": {"count": len(pending_batch["projects"])}})

        # user said something else while a proposal is pending -> drop it
        if pending:
            _state["mira_pending"] = None
        if not ai_assist.is_affirmative(command) and _state.get("mira_batch_pending") and not ai_assist.is_batch_command(command):
            _state["mira_batch_pending"] = None

        result = ai_assist.mira_apply(_config(), command, sheets, fonts)
        cfg = result.get("config") or _config()
        if result.get("changes"):
            _state.setdefault("mira_undo", []).append(_config())
            if len(_state["mira_undo"]) > 5:
                _state["mira_undo"] = _state["mira_undo"][-5:]
            _set_config(cfg)

        action = result.get("action")
        if action == "scan":
            excel = engine_api.scan_excel(cfg.get("excel_path", ""))
            icons = engine_api.scan_icons(cfg.get("excel_path", ""), cfg.get("icon_folder", ""), cfg.get("icon_mappings") or {}) if excel.get("ok") else {"error": "Excel not loaded"}
            suggestions = _build_suggestions(excel, icons)
            _state["scan"] = {"excel": excel, "icons": icons}
            cfg = _config()
            cfg["ai_suggestions"] = suggestions
            if excel.get("ok"):
                valid_names = {str(s.get("name", "")).strip() for s in excel.get("sheets", [])}
                cfg["selected_sheets"] = [s for s in (cfg.get("selected_sheets") or []) if str(s).strip() in valid_names]
            _set_config(cfg)
            result["scan"] = excel
        elif action == "build":
            mode = str(cfg.get("build_output") or "both")
            if mode not in ("psd", "png", "both"):
                mode = "both"
            if not cfg.get("excel_path") or not os.path.isfile(cfg.get("excel_path", "")):
                result["message"] = (result.get("message") or "") + " I could not start the build — no valid Excel file is set."
            else:
                job_id = job_manager.start(cfg, mode)
                result["job_id"] = job_id
                result["build_mode"] = mode

        return jsonify({"ok": True, **result})

    # ------------------------------------------------------------- photoshop
    @app.route("/api/ps/status")
    def ps_status():
        return jsonify(engine_api.check_photoshop())

    @app.route("/api/ps/capture-style", methods=["POST"])
    def ps_capture_style():
        from . import ps_actions

        data = request.get_json(force=True, silent=True) or {}
        result = ps_actions.capture_style(data.get("mode", "selected"))
        if result.get("ok"):
            cfg = _config()
            name = (data.get("name") or "").strip() or "Copied Photoshop layer style"
            role = (data.get("role") or "").strip()
            ds = cfg.setdefault("dynamic_settings", {})
            if not isinstance(ds, dict):
                ds = cfg["dynamic_settings"] = {}
            library = ds.setdefault("layer_style_library", {})
            if not isinstance(library, dict):
                library = ds["layer_style_library"] = {}
            if not result["style"].get("fx_base_size"):
                # not copied from a text layer: the text size of the role it is for is the best guess
                from .. import fx_scale

                result["style"] = fx_scale.remember_size(result["style"], fx_scale.role_size(cfg, role))
            library[name] = result["style"]
            # the project's Global Light: the document the style was copied from has the one its "Use Global
            # Light" shadows / bevels were made at — taken with every copy (Photoshop too has one per document),
            # so nobody types angles in; the reply says when it changed
            light = result.get("global_light")
            if light and light != ds.get("fx_global_light"):
                result["light_changed"] = {"from": ds.get("fx_global_light"), "to": light}
                ds["fx_global_light"] = light
            if role:
                assignments = ds.setdefault("style_assignments", {})
                if not isinstance(assignments, dict):
                    assignments = ds["style_assignments"] = {}
                assignments[role] = name
            _set_config(cfg)
            result["config"] = cfg
            result["saved_as"] = name
            result["assigned_role"] = role or None
        return jsonify(result)

    @app.route("/api/layer-styles", methods=["GET"])
    def layer_styles_list():
        cfg = _config()
        ds = cfg.get("dynamic_settings") or {}
        return jsonify({
            "library": ds.get("layer_style_library") or {},
            "assignments": ds.get("style_assignments") or {},
        })

    @app.route("/api/layer-styles/light", methods=["GET"])
    def layer_styles_light():
        """The project's Global Light (set, or what the built PSD gets from its styles) and the angles its
        "Use Global Light" styles were saved at — the layer-style menu shows them."""
        from .. import global_light

        ds = _config().get("dynamic_settings") or {}
        lib = ds.get("layer_style_library") if isinstance(ds.get("layer_style_library"), dict) else {}
        angles = []
        for name, style in lib.items():
            for a, alt in global_light.style_angles([style]):
                angles.append({"style": name, "angle": a, "altitude": alt})
        return jsonify({"ok": True, "light": global_light.resolve(ds), "effective": global_light.for_document(ds),
                        "angles": angles})

    _SWATCHES = {}

    @app.route("/api/layer-styles/swatch", methods=["GET"])
    def layer_styles_swatch():
        """A layer style as a picture: "Sample" drawn with it (the same effects engine as builds).
        Remembered per style content, so a re-captured style gets a fresh picture."""
        import hashlib

        from ps_autotypesetter import png_builder

        name = str(request.args.get("name") or "")
        text = str(request.args.get("text") or "Sample")[:24]
        ds = _config().get("dynamic_settings") or {}
        style = (ds.get("layer_style_library") or {}).get(name)
        from .. import global_light

        key = hashlib.sha1(json.dumps([name, style, text, global_light.current()], sort_keys=True,       # a light turns its shadows
                                      default=str).encode("utf-8")).hexdigest()
        png = _SWATCHES.get(key)
        if png is None:
            from PIL import Image, ImageDraw, ImageFont

            fx = png_builder.fx_by_name({name: style}, name) if style else None
            size = 64
            font = png_builder._load_font(ImageFont, "Arial Black", size, bold=True)
            probe = ImageDraw.Draw(Image.new("RGBA", (8, 8)))
            box = png_builder._text_bbox(probe, text, font)
            pad = 34                                     # room for strokes, glows and shadows
            w, h = int(box[2] - box[0]) + 2 * pad, int(size * 1.3) + 2 * pad
            img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
            png_builder._draw_text_visual(ImageDraw.Draw(img), pad, pad, text, font, (255, 255, 255, 255),
                                          int(size * 1.3), base=img, fx_config=fx)
            buf = io.BytesIO()
            img.save(buf, "PNG")
            png = _SWATCHES[key] = buf.getvalue()
            if len(_SWATCHES) > 400:
                _SWATCHES.pop(next(iter(_SWATCHES)))
        return Response(png, mimetype="image/png", headers={"Cache-Control": "max-age=86400"})

    @app.route("/api/layer-styles/assign", methods=["POST"])
    def layer_styles_assign():
        data = request.get_json(force=True, silent=True) or {}
        role = (data.get("role") or "").strip()
        name = (data.get("name") or "").strip()
        cfg = _config()
        ds = cfg.setdefault("dynamic_settings", {})
        if not isinstance(ds, dict):
            ds = cfg["dynamic_settings"] = {}
        assignments = ds.setdefault("style_assignments", {})
        if not isinstance(assignments, dict):
            assignments = ds["style_assignments"] = {}
        if role:
            if name:
                assignments[role] = name
            else:
                assignments.pop(role, None)
            _set_config(cfg)
        return jsonify({"ok": True, "config": cfg})

    @app.route("/api/layer-styles/delete", methods=["POST"])
    def layer_styles_delete():
        data = request.get_json(force=True, silent=True) or {}
        name = (data.get("name") or "").strip()
        cfg = _config()
        ds = cfg.get("dynamic_settings")
        if not isinstance(ds, dict):
            ds = {}
        library = ds.get("layer_style_library")
        if isinstance(library, dict) and name in library:
            del library[name]
            assignments = ds.get("style_assignments")
            if isinstance(assignments, dict):
                for role in [r for r, n in list(assignments.items()) if n == name]:
                    assignments.pop(role, None)
            _set_config(cfg)
        return jsonify({"ok": True, "config": cfg})

    @app.route("/api/layer-styles/rename", methods=["POST"])
    def layer_styles_rename():
        from .. import layer_style_names

        data = request.get_json(force=True, silent=True) or {}
        try:
            cfg, moved = layer_style_names.rename(_config(), data.get("name"), data.get("new_name"))
        except ValueError as exc:
            return jsonify({"ok": False, "error": str(exc)})
        _set_config(cfg)
        return jsonify({"ok": True, "config": cfg, "references": moved})

    @app.route("/api/layer-styles/upgrade", methods=["POST"])
    def layer_styles_upgrade():
        from . import ps_actions

        cfg = _config()
        result = ps_actions.upgrade_style_params(cfg)
        if result.get("ok"):
            _set_config(result["config"])
            result["config"] = _config()
        return jsonify(result)

    @app.route("/api/ps/groups")
    def ps_groups():
        from . import ps_actions

        psd_path = request.args.get("psd_path", "") or _config().get("prev_psd_path", "")
        return jsonify({"groups": ps_actions.list_psd_groups(psd_path)})

    # ------------------------------------------------------------- export
    @app.route("/api/export/paytable-json", methods=["POST"])
    def export_paytable_json():
        from . import ps_actions

        data = request.get_json(force=True, silent=True) or {}
        return jsonify(ps_actions.export_paytable_json(
            mode=data.get("mode", "active"),
            psd_path=data.get("psd_path", "") or _config().get("prev_psd_path", ""),
            group_path=data.get("group_path", ""),
            slot_prefix=data.get("slot_prefix", "@slot"),
        ))

    @app.route("/api/export/batch", methods=["POST"])
    def export_batch():
        from . import ps_actions

        data = request.get_json(force=True, silent=True) or {}
        cfg = _config()
        psd_path = data.get("psd_path") or cfg.get("prev_psd_path", "")
        output_folder = data.get("output_folder") or cfg.get("output_dir", "")
        if not psd_path or not output_folder:
            return jsonify({"ok": False, "error": "Provide a PSD path and an output folder."}), 400
        job_id = job_manager.start_task(
            lambda: ps_actions.batch_export_groups(
                psd_path=psd_path,
                output_folder=output_folder,
                group_names=data.get("group_names"),
                image_format=data.get("image_format", "PNG"),
                jpg_quality=int(data.get("jpg_quality", 90)),
                transparent=bool(data.get("transparent", True)),
                suffix=data.get("suffix", "MyExport"),
                export_visible_groups=bool(data.get("export_visible_groups", True)),
                export_visible_layers=bool(data.get("export_visible_layers", False)),
                bottom_to_top=bool(data.get("bottom_to_top", False)),
            ),
            "Batch Export",
        )
        return jsonify({"ok": True, "job_id": job_id})

    @app.route("/api/export/backup", methods=["POST"])
    def export_backup():
        from . import ps_actions

        data = request.get_json(force=True, silent=True) or {}
        psd_path = data.get("psd_path") or _config().get("prev_psd_path", "")
        if not psd_path:
            return jsonify({"ok": False, "error": "Provide a PSD path."}), 400
        return jsonify(ps_actions.copy_backup(psd_path, data.get("backup_folder", "")))

    # ------------------------------------------------------------- templates & mappings
    @app.route("/api/templates")
    def templates():
        from . import ps_actions

        folder = request.args.get("folder", "")
        return jsonify({"templates": ps_actions.list_dynamic_templates(folder)})

    @app.route("/api/mappings", methods=["GET", "POST"])
    def mappings():
        cfg = _config()
        if request.method == "GET":
            tokens = []
            if _state.get("scan") and _state["scan"].get("icons"):
                tokens = _state["scan"]["icons"].get("tokens") or []
            return jsonify({
                "mappings": cfg.get("icon_mappings") or {},
                "size_overrides": cfg.get("icon_size_overrides") or {},
                "tokens": tokens,
            })
        data = request.get_json(force=True, silent=True) or {}
        if "icon_mappings" in data:
            cfg["icon_mappings"] = data["icon_mappings"]
        if "icon_size_overrides" in data:
            cfg["icon_size_overrides"] = data["icon_size_overrides"]
        if "icon_mappings_by_excel" in data:
            cfg["icon_mappings_by_excel"] = data["icon_mappings_by_excel"]
        _set_config(cfg)
        return jsonify({"ok": True, "config": cfg})

    # ------------------------------------------------------------- table mapper
    _preview_files: dict = {}
    _preview_counter: itertools.count = itertools.count()
    _preview_by_path: dict = {}

    def _register_preview(path: str) -> str:
        if not path or not os.path.isfile(path):
            return ""
        existing = _preview_by_path.get(path, "")
        if existing and _preview_files.get(existing):
            return existing
        token = f"t{next(_preview_counter)}"
        _preview_files[token] = path
        _preview_by_path[path] = token
        if len(_preview_files) > 800:
            oldest = next(iter(_preview_files))
            _preview_by_path.pop(_preview_files.pop(oldest), None)
        return token

    @app.route("/api/table_preview/<token>")
    def table_preview(token):
        from . import ps_actions

        path = _preview_files.get(token, "")
        if not path or not os.path.isfile(path):
            return jsonify({"ok": False, "error": "Preview not found."}), 404
        return send_file(path, mimetype="image/png")

    # -------- Visualiser addon (separate module; must never break the core) --------
    try:
        from visualiser.visualiser_web import register_visualiser

        register_visualiser(
            app,
            get_config=_config,
            set_config=_set_config,
            register_preview=_register_preview,
        )
    except Exception as exc:  # addon unavailable (e.g. packaged exe without it)
        print(f"[Visualiser] addon not loaded: {exc}")

    # -------- Canonical layout preview (PageLayout as single source of truth)
    # Returns the SAME PageLayout objects the PNG/Photoshop renderers consume
    # (with live_overrides applied), so the live preview becomes a viewer of
    # PageLayout. Sheets the canonical engine cannot model come back with
    # mode "legacy" and the frontend keeps its current independent render.
    @app.route("/api/layout/preview", methods=["POST"])
    def layout_preview():
        from ps_autotypesetter import live_layout_adapter

        cfg = _config()
        data = request.get_json(force=True, silent=True) or {}
        sheet_name = _raw_sheet(data.get("sheet_name"))
        if not sheet_name:
            return jsonify({"ok": False, "error": "sheet_name is required."}), 400
        # a drag in progress: its values laid out for this answer only, never saved
        # ({"dynamic_settings.body_boxes": {...}, "heading_top_margin": 120})
        draft = data.get("settings_draft")
        if isinstance(draft, dict) and draft:
            cfg = _with_settings_draft(cfg, draft)
        _load_live_settings(cfg)                         # the saved settings, never a background build's older ones
        from ps_autotypesetter import text_edits

        from ps_autotypesetter import rules_layout

        kind = rules_layout.rules_kind(sheet_name)
        try:
            if kind:
                # Game Rules / Bingo Rules: their own renderer's lines, edited like every other page
                payload = rules_layout.layout_payload(lambda report: _render_rules_page(data, kind, report, cfg),
                                                      kind, sheet_name, register_preview=_register_preview)
                return jsonify(payload), (200 if payload.get("ok") else 400)
            if _is_paylines_sheet(cfg, sheet_name):
                # Paylines / Win Lines: their own renderer's pages, the lines as the build draws them
                return jsonify(_paylines_layout_payload(cfg, sheet_name))
            # text being typed in a preview editor: laid out live, saved only when the editor closes
            with text_edits.draft(data.get("text_edits_draft")):
                payload = live_layout_adapter.layout_payload_for_sheet(
                    dict(cfg),
                    sheet_name,
                    apply_overrides=bool(data.get("apply_overrides", True)),
                    register_preview=_register_preview,      # tables' pictures
                )
        except Exception as exc:  # the addon must never break the UI
            return jsonify({"ok": False, "error": f"Canonical layout preview failed: {exc}"}), 500
        finally:
            if cfg is not _config():
                _load_live_settings(_config())             # a drag's values never reach other routes
        if not payload.get("ok"):
            return jsonify(payload), 400
        return jsonify(payload)

    # ── table designs (Tables → designs) ─────────────────────────────────────
    @app.route("/api/tables/designs", methods=["POST"])
    def tables_designs():
        """The design library and every table the Excel has, with the design each one uses."""
        from ps_autotypesetter import png_builder, table_designs, workbook_cache

        cfg = _config()
        ts = cfg.get("table_style") or {}
        # each design's own colours too: the Typography table bar shows what a table really looks like
        designs = [{"id": k, "name": v["name"], "builtin": v.get("builtin", False), "about": v.get("about", ""),
                    "style": dict(v.get("style") or {}), "excel": bool(v.get("excel"))}
                   for k, v in table_designs.all_designs(ts).items()]
        tables = []
        excel = str(cfg.get("excel_path") or "")
        if excel and os.path.isfile(excel):
            max_col = int(cfg.get("max_col_limit") or 12)
            try:
                with workbook_cache.borrow(excel) as wb:
                    for ws in wb.worksheets:
                        if getattr(ws, "sheet_state", "visible") != "visible" or engine_api._sheet_type(ws.title) != "page":
                            continue
                        try:
                            found = png_builder._prepare_tables(ws, ts, max_col, ws.title)
                        except Exception:
                            continue
                        for t in found:
                            header = png_builder._table_header_text(ws, t)
                            tables.append({"sheet": ws.title, "key": t["design_key"], "header": header[:90],
                                           "design": t["design"], "own": t["design_key"] in (ts.get("designs") or {}),
                                           "rows": int(t.get("end_row", 0)) - int(t.get("start_row", 0)) + 1})
            except Exception as exc:
                return jsonify({"ok": False, "error": str(exc), "designs": designs, "tables": []})
        return jsonify({"ok": True, "designs": designs, "default": ts.get("default_design") or "current", "tables": tables})

    @app.route("/api/tables/design_swatch")
    def tables_design_swatch():
        """A small table drawn in a design (header + striped rows) — the design picker's picture."""
        import io

        from PIL import Image, ImageDraw

        from ps_autotypesetter import png_builder, table_designs

        ts = _config().get("table_style") or {}
        did = str(request.args.get("id") or "current")
        st = table_designs.apply(ts, did)
        w, h, rows, cols = 180, 96, 4, 3
        img = Image.new("RGB", (w, h), (24, 26, 34))
        d = ImageDraw.Draw(img)
        excel = table_designs.uses_excel_colours(ts, did)
        excel_cells = [(255, 242, 204), (198, 239, 206), (255, 199, 206), (221, 235, 247)]
        mode = str(st.get("render_mode") or "both")
        stroke = png_builder._rgb(st.get("stroke_rgb"), (255, 255, 255))
        sw = 0 if mode == "fill" else max(1, int(st.get("stroke_width") or 1))
        ch, cw = (h - 8) // rows, (w - 8) // cols
        for r in range(rows):
            for c in range(cols):
                x0, y0 = 4 + c * cw, 4 + r * ch
                if excel:
                    fill = (68, 114, 196) if r == 0 else excel_cells[(r + c) % len(excel_cells)]
                    text = (255, 255, 255) if r == 0 else (40, 40, 40)
                elif r == 0:
                    fill, text = png_builder._rgb(st.get("header_bg_rgb"), (20, 20, 30)), png_builder._rgb(st.get("header_text_rgb"))
                else:
                    key = "row1_bg_rgb" if r % 2 else "row2_bg_rgb"
                    fill, text = png_builder._rgb(st.get(key), (35, 35, 50)), png_builder._rgb(st.get("table_body_text_rgb"))
                if mode != "stroke" or excel:
                    d.rectangle([x0, y0, x0 + cw - 1, y0 + ch - 1], fill=fill)
                if sw and not excel:
                    d.rectangle([x0, y0, x0 + cw - 1, y0 + ch - 1], outline=stroke, width=min(sw, 3))
                d.rectangle([x0 + 10, y0 + ch // 2 - 2, x0 + cw - 12, y0 + ch // 2 + 2], fill=text)   # a "word"
        buf = io.BytesIO()
        img.save(buf, "PNG")
        return Response(buf.getvalue(), mimetype="image/png", headers={"Cache-Control": "no-cache"})

    @app.route("/api/tables/save_design", methods=["POST"])
    def tables_save_design():
        """The current Tables colours become a design of the user's own."""
        from ps_autotypesetter import table_designs

        data = request.get_json(force=True, silent=True) or {}
        name = str(data.get("name") or "").strip()[:40] or "My design"
        cfg = _config()
        ts = dict(cfg.get("table_style") or {})
        custom = dict(ts.get("custom_designs") or {})
        did = "my_" + re.sub(r"[^a-z0-9]+", "_", name.casefold()).strip("_")
        custom[did] = {"name": name, "style": table_designs.style_from_settings(ts)}
        ts["custom_designs"] = custom
        cfg["table_style"] = ts
        _set_config(cfg)
        return jsonify({"ok": True, "id": did, "config": cfg})

    @app.route("/api/table_template/scan", methods=["POST"])
    def table_template_scan():
        from . import ps_actions

        data = request.get_json(force=True, silent=True) or {}
        psd_path = data.get("psd_path") or ""
        slot_prefix = str(data.get("slot_prefix") or "@table")
        result = ps_actions.scan_table_template(psd_path, slot_prefix=slot_prefix)
        if result.get("ok"):
            result["preview_token"] = _register_preview(result.get("preview_path", ""))
            result.pop("preview_path", None)
        return jsonify(result)

    @app.route("/api/table_template/load", methods=["POST"])
    def table_template_load():
        from . import ps_actions

        data = request.get_json(force=True, silent=True) or {}
        path = data.get("path") or ""
        if not path or not os.path.isfile(path):
            return jsonify({"ok": False, "error": "JSON file not found."}), 400
        try:
            payload = engine_api.load_table_mapper_session(path)
        except Exception as exc:
            return jsonify({"ok": False, "error": str(exc)}), 400
        preview_path = os.path.join(tempfile.gettempdir(), "psh_table_previews", f"{uuid.uuid4().hex}.png")
        os.makedirs(os.path.dirname(preview_path), exist_ok=True)
        cfg = _config()
        rendered = ps_actions.render_table_outline_preview(
            payload["template"], preview_path,
            settings=_preview_render_settings(cfg),
            mappings=payload.get("mappings") or [],
            excel_path=str(cfg.get("excel_path") or ""),
            sheet_name=str(payload.get("sheet_name") or ""),
            icon_folder=str(cfg.get("icon_folder") or ""),
            icon_mappings=cfg.get("icon_mappings") or {},
            bg_path=str(cfg.get('bg_path') or ''),
            annotations=bool(data.get("annotations", True)),
        )
        payload["preview_token"] = _register_preview(rendered or preview_path) if os.path.isfile(preview_path) else ""
        payload["ok"] = True
        return jsonify(payload)

    @app.route("/api/table_mapper/preview", methods=["POST"])
    def table_mapper_preview():
        from . import ps_actions

        data = request.get_json(force=True, silent=True) or {}
        template = data.get("template") or {}
        if not isinstance(template, dict) or not (template.get("slots") or {}):
            return jsonify({"ok": False, "error": "Missing template slots."}), 400
        cfg = _config()
        sheet_name = _raw_sheet(data.get("sheet_name"))
        mapping_items = data.get("mappings") or []
        mappings = {}
        if isinstance(mapping_items, dict):
            mappings = mapping_items
        else:
            for m in mapping_items:
                if isinstance(m, dict) and m.get("slot"):
                    mappings[str(m["slot"])] = m
        preview_path = os.path.join(tempfile.gettempdir(), "psh_table_previews", f"{uuid.uuid4().hex}.png")
        os.makedirs(os.path.dirname(preview_path), exist_ok=True)
        rendered = ps_actions.render_table_outline_preview(
            template, preview_path,
            settings=_preview_render_settings(cfg),
            mappings=mappings,
            excel_path=str(cfg.get("excel_path") or ""),
            sheet_name=sheet_name,
            icon_folder=str(cfg.get("icon_folder") or ""),
            icon_mappings=cfg.get("icon_mappings") or {},
            bg_path=str(cfg.get('bg_path') or ''),
            annotations=bool(data.get("annotations", True)),
        )
        token = _register_preview(rendered or preview_path) if os.path.isfile(preview_path) else ""
        return jsonify({
            "ok": True,
            "preview_token": token,
            "icons": ps_actions.resolve_mapped_slot_icons(
                mappings,
                str(cfg.get("excel_path") or ""),
                sheet_name,
                icon_folder=str(cfg.get("icon_folder") or ""),
                icon_mappings=cfg.get("icon_mappings") or {},
            ),
        })

    @app.route("/api/table_mapper/automap", methods=["POST"])
    def table_mapper_automap():
        data = request.get_json(force=True, silent=True) or {}
        result = engine_api.automap_table_slots(
            data.get("template") or {},
            data.get("excel_path") or _config().get("excel_path", ""),
            data.get("sheet_name") or "",
        )
        return jsonify({"ok": True, "mappings": result["mappings"], "unmapped": result["unmapped"], "count": len(result["mappings"])})

    @app.route("/api/table_mapper/source_range", methods=["POST"])
    def table_mapper_source_range():
        data = request.get_json(force=True, silent=True) or {}
        return jsonify({"ok": True, "range": engine_api.table_mapper_source_range(data.get("mappings") or [])})

    @app.route("/api/table_mapper/save", methods=["POST"])
    def table_mapper_save():
        data = request.get_json(force=True, silent=True) or {}
        cfg = _config()
        result, new_cfg = engine_api.save_table_mapper_mapping(cfg, data)
        if result.get("ok"):
            _set_config(new_cfg)
            result["config"] = new_cfg
        return jsonify(result)

    @app.route("/api/table_mapper/save_as", methods=["POST"])
    def table_mapper_save_as():
        data = request.get_json(force=True, silent=True) or {}
        from .native_dialog import ask_save_path

        cfg = _config()
        table_name = str(data.get("table_name") or "").strip() or "table"
        safe_name = re.sub(r"[^A-Za-z0-9_\-]+", "_", table_name).strip("_") or "table"
        base_dir = str((cfg or {}).get("output_dir") or "").strip()
        psd_path = str(data.get("psd_path") or "").strip()
        if not base_dir or not os.path.isdir(base_dir):
            base_dir = os.path.dirname(os.path.abspath(psd_path)) if psd_path else ""
        out_dir = os.path.join(base_dir, "mapped_tables") if base_dir else os.path.abspath("mapped_tables")
        os.makedirs(out_dir, exist_ok=True)
        default_path = os.path.join(out_dir, f"{safe_name}_mapped.json")
        chosen, dialog_error = ask_save_path(
            "Save mapped table JSON",
            out_dir,
            f"{safe_name}_mapped.json",
        )
        if not chosen:
            return jsonify({
                "ok": False,
                "cancelled": True,
                "dialog_error": dialog_error or None,
                "default_path": default_path,
            })
        if not str(chosen).casefold().endswith(".json"):
            chosen = f"{chosen}.json"
        data["output_path"] = chosen
        result, new_cfg = engine_api.save_table_mapper_mapping(cfg, data)
        if result.get("ok"):
            _set_config(new_cfg)
            result["config"] = new_cfg
        return jsonify(result)

    @app.route("/api/paytable_mapper/load", methods=["POST"])
    def paytable_mapper_load():
        from . import ps_actions

        data = request.get_json(force=True, silent=True) or {}
        path = data.get("path") or ""
        if not path or not os.path.isfile(path):
            path = str((_config().get("dynamic_settings") or {}).get("template_json") or "").strip()
        if not path or not os.path.isfile(path):
            return jsonify({"ok": False, "error": "JSON file not found."}), 400
        try:
            payload = engine_api.load_paytable_mapper_session(path)
        except Exception as exc:
            return jsonify({"ok": False, "error": str(exc)}), 400
        preview_path = os.path.join(tempfile.gettempdir(), "psh_table_previews", f"{uuid.uuid4().hex}.png")
        os.makedirs(os.path.dirname(preview_path), exist_ok=True)
        settings = _preview_render_settings(_config())
        cfg = _config()
        rendered = ps_actions.render_table_outline_preview(
            payload["template"], preview_path,
            settings=settings,
            mappings=payload.get("mappings"),
            excel_path=str(cfg.get("excel_path") or ""),
            sheet_name=str(payload.get("sheet_name") or ""),
            icon_folder=str(cfg.get("icon_folder") or ""),
            icon_mappings=cfg.get("icon_mappings") or {},
            bg_path=str(cfg.get('bg_path') or ''),
            annotations=bool(data.get("annotations", True)),
        )
        payload["preview_token"] = _register_preview(rendered or preview_path) if os.path.isfile(preview_path) else ""
        payload["ok"] = True
        payload["path"] = path
        payload["global_styles"] = (_config().get("paytable_global_styles") or {})
        return jsonify(payload)

    @app.route("/api/paytable_templates", methods=["GET"])
    def paytable_templates_list():
        from . import paytable_templates

        return jsonify({
            "ok": True,
            "templates": paytable_templates.list_templates(),
            "dir": paytable_templates.templates_dir(),
        })

    @app.route("/api/paytable_templates/delete", methods=["POST"])
    def paytable_templates_delete():
        from . import paytable_templates

        data = request.get_json(force=True, silent=True) or {}
        target = str(data.get("path") or data.get("name") or "").strip()
        if not target:
            return jsonify({"ok": False, "error": "No template selected."}), 400
        try:
            resolved = paytable_templates.resolve_template_path(target)
        except Exception as exc:
            return jsonify({"ok": False, "error": str(exc)}), 400
        try:
            result = paytable_templates.delete_template(resolved)
        except Exception as exc:
            return jsonify({"ok": False, "error": str(exc)}), 400
        return jsonify({"ok": True, "name": result["name"], "path": result["path"]})

    @app.route("/api/paytable_templates/save", methods=["POST"])
    def paytable_templates_save():
        from . import paytable_templates

        data = request.get_json(force=True, silent=True) or {}
        name = str(data.get("name") or "").strip()
        template = data.get("template")
        if not isinstance(template, dict) or not (template.get("slots") or {}):
            return jsonify({"ok": False, "error": "Missing template slots."}), 400
        try:
            path = paytable_templates.save_template(template, name)
        except Exception as exc:
            return jsonify({"ok": False, "error": str(exc)}), 400
        return jsonify({"ok": True, "path": path})

    @app.route("/api/paytable_templates/import", methods=["POST"])
    def paytable_templates_import():
        from . import paytable_templates

        data = request.get_json(force=True, silent=True) or {}
        file_path = str(data.get("path") or "")
        if not file_path or not os.path.isfile(file_path):
            return jsonify({"ok": False, "error": "File not found."}), 400
        try:
            result = paytable_templates.import_from_file(file_path)
            result["root_path"] = _mirror_template_to_project_root(result.get("path") or "")
        except Exception as exc:
            return jsonify({"ok": False, "error": str(exc)}), 400
        return jsonify({"ok": True, **result})

    @app.route("/api/paytable_templates/import_active", methods=["POST"])
    def paytable_templates_import_active():
        from . import paytable_templates
        from . import ps_actions

        if not ps_actions.is_photoshop_running():
            return jsonify({"ok": False, "error": "Photoshop is not running. Open the PSD you want to import and try again."}), 400
        try:
            result = paytable_templates.import_from_active_psd()
            result["root_path"] = _mirror_template_to_project_root(result.get("path") or "")
        except Exception as exc:
            return jsonify({"ok": False, "error": str(exc)}), 400
        return jsonify({"ok": True, **result})

    @app.route("/api/game_name/status", methods=["GET"])
    def game_name_status():
        """Does any sheet use <GAME NAME>, and is there an image or a typed name for it?"""
        import re as _re

        from ps_autotypesetter import workbook_cache

        cfg = _config()
        ds = cfg.get("dynamic_settings") or {}
        excel = str(cfg.get("excel_path") or "")
        used = False
        if excel and os.path.isfile(excel):
            pat = _re.compile(r"<\s*game[\s_-]*name\s*>", _re.I)
            try:
                with workbook_cache.borrow(excel) as wb:
                    for ws in wb.worksheets:
                        for row in ws.iter_rows(min_row=1, max_row=min(ws.max_row or 1, 12), values_only=True):
                            if any(isinstance(v, str) and pat.search(v) for v in row):
                                used = True
                                break
                        if used:
                            break
            except Exception:
                used = False
        image = ""
        try:
            from ps_autotypesetter.icon_mapping import resolve_icon_path
            from ps_autotypesetter.png_builder import _GAME_NAME_FILES

            image = resolve_icon_path("<GAME NAME>", cfg.get("icon_folder") or "", cfg.get("icon_mappings") or {},
                                      _GAME_NAME_FILES) or ""
        except Exception:
            image = ""
        name = str(ds.get("heading_game_name_text") or "").strip()
        return jsonify({"ok": True, "used": used, "image": image, "name": name,
                        "needed": bool(used and not name and not image)})

    @app.route("/api/artist_design/groups", methods=["POST"])
    def artist_design_groups():
        data = request.get_json(force=True, silent=True) or {}
        psd_path = str(data.get("psd_path") or "").strip()
        if not psd_path or not os.path.isfile(psd_path) or not psd_path.lower().endswith((".psd", ".psb")):
            return jsonify({"ok": False, "error": "Choose an artist .psd/.psb file."}), 400
        try:
            return jsonify(engine_api.artist_psd_groups(psd_path))
        except Exception as exc:
            return jsonify({"ok": False, "error": f"Could not read the PSD: {exc}"}), 400

    @app.route("/api/artist_design/learn", methods=["POST"])
    def artist_design_learn():
        """Learn a paytable layout from an artist PSD group (background job)."""
        data = request.get_json(force=True, silent=True) or {}
        cfg = _config()
        psd_path = str(data.get("psd_path") or "").strip()
        group = str(data.get("group") or "").strip()
        sheet = _raw_sheet(data.get("sheet_name"))
        if not psd_path or not group or not sheet:
            return jsonify({"ok": False, "error": "Choose the PSD, its paytable group and the Excel sheet."}), 400
        kwargs = dict(
            psd_path=psd_path, group=group, sheet_name=sheet,
            excel_path=str(data.get("excel_path") or cfg.get("excel_path") or ""),
            icon_folder=str(cfg.get("icon_folder") or ""),
            icon_mappings=cfg.get("icon_mappings") or {},
            name=str(data.get("name") or "").strip(),
            symbol_overrides=data.get("symbol_overrides") or {},
        )

        _adopt_psd_light(psd_path)

        def _task(progress):
            result = engine_api.learn_artist_paytable(progress=progress, **kwargs)
            if result.get("ok") and result.get("path"):
                result["root_path"] = _mirror_template_to_project_root(result["path"])
            return result

        job_id = job_manager.start_task(_task, "Learn paytable from artist PSD", with_progress=True)
        return jsonify({"ok": True, "job_id": job_id})

    def _clone_inputs(data):
        """(psd, excel A, excel B, None) from a clone request, or (.., error response)."""
        src = str(data.get("source_psd") or "").strip().strip('"')
        excel_a = str(data.get("excel_a") or "").strip().strip('"')
        excel_b = str(data.get("excel_b") or "").strip().strip('"')
        for label, path in (("the market A PSD", src), ("the market A Excel", excel_a), ("the new market's Excel", excel_b)):
            if not path or not os.path.isfile(path):
                return src, excel_a, excel_b, (jsonify({"ok": False, "error": f"Choose {label}."}), 400)
            blocked = _reject_unallowed_path(path)
            if blocked:
                return src, excel_a, excel_b, blocked
        return src, excel_a, excel_b, None

    def _clone_icons(cfg):
        # the game's symbol pictures, when the project has them: one more way to tell cards apart
        icons = str(cfg.get("icon_folder") or "").strip().strip('"')
        return icons if icons and os.path.isdir(icons) else None

    @app.route("/api/market_clone/check", methods=["POST"])
    def market_clone_check():
        """Which sheet each page of the PSD shows and which picture is which symbol — worked out,
        merged with what the artist confirmed before (saved with the game). Nothing is written."""
        import hashlib
        import tempfile

        from .. import market_clone

        data = request.get_json(force=True, silent=True) or {}
        cfg = _config()
        src, excel_a, excel_b, err = _clone_inputs(data)
        if err:
            return err
        game_id = cfg.get("active_game") or None

        def _task(progress):
            progress("Reading the PSD and both Excel files…", 20)
            saved = market_clone.load_links(src, game_id)
            report = market_clone.check(src, excel_a, excel_b, links=saved, icon_folder=_clone_icons(cfg),
                                        game_id=game_id)
            progress("Drawing the symbols…", 70)
            key = hashlib.sha1(os.path.abspath(src).casefold().encode("utf-8")).hexdigest()[:16]
            market_clone.symbol_thumbs(src, report, os.path.join(tempfile.gettempdir(), "psh_clone_pages", "symbols " + key))
            report.update(ok=True, saved=saved)
            return report

        job_id = job_manager.start_task(_task, "Check a market clone's links", with_progress=True)
        return jsonify({"ok": True, "job_id": job_id})

    _CLONE_PREVIEW = {}                              # the last preview's PSD in memory (whole pages on demand)

    @app.route("/api/market_clone/preview", methods=["POST"])
    def market_clone_preview():
        """Every page the new AGR would change, add or mark deleted — before / after pictures for the
        artist to approve one by one. Nothing is written to the PSD; the links come along and are
        saved with the game."""
        import hashlib
        import tempfile

        from .. import market_clone

        data = request.get_json(force=True, silent=True) or {}
        cfg = _config()
        src, excel_a, excel_b, err = _clone_inputs(data)
        if err:
            return err
        game_id = cfg.get("active_game") or None
        links = data.get("links") if isinstance(data.get("links"), dict) else None
        if links is not None:
            market_clone.save_links(src, links, game_id)
        else:
            links = market_clone.load_links(src, game_id)
        key = hashlib.sha1(f"{os.path.abspath(src)}|{excel_b}".casefold().encode("utf-8")).hexdigest()[:16]
        folder = os.path.join(tempfile.gettempdir(), "psh_clone_pages", "preview " + key)

        def _task(progress):
            import shutil
            import threading

            shutil.rmtree(folder, ignore_errors=True)
            # the changes come back as soon as they are worked out; their before / after crops are
            # drawn in the background (the dialog shows each one as it appears)
            report = market_clone.preview(src, excel_a, excel_b, folder, links=links, icon_folder=_clone_icons(cfg),
                                          progress=progress, draw=False)
            jobs = report.pop("_crop_jobs", [])
            _CLONE_PREVIEW.clear()
            _CLONE_PREVIEW.update(key=key, source=src, psd=report.pop("_psd"), plan=report.pop("_plan"), folder=folder)
            threading.Thread(target=market_clone.draw_crops, args=(jobs,), daemon=True,
                             name="clone-crops").start()
            progress("Done", 100)
            return dict(report, ok=True, preview_key=key)

        job_id = job_manager.start_task(_task, "Preview a market clone", with_progress=True)
        return jsonify({"ok": True, "job_id": job_id})

    @app.route("/api/market_clone/edit", methods=["POST"])
    def market_clone_edit():
        """The artist edits one changed text in the preview: written into the preview's PSD in memory,
        its crop drawn again (about a second). The edit is sent again with "Create the PSD"."""
        from .. import market_clone

        data = request.get_json(force=True, silent=True) or {}
        slot = dict(_CLONE_PREVIEW)
        if not slot or data.get("preview_key") != slot.get("key"):
            return jsonify({"ok": False, "error": "This preview has expired — show the changes again."}), 409
        box = data.get("box") or [0, 0, 1, 1]
        try:
            path, box = market_clone.edit_crop(slot["psd"], str(data.get("key") or ""), str(data.get("text") or ""),
                                               [int(v) for v in box], os.path.join(slot["folder"], "edits"))
        except Exception as exc:
            return jsonify({"ok": False, "error": str(exc)}), 400
        return jsonify({"ok": True, "path": path, "box": box})

    @app.route("/api/market_clone/page", methods=["POST"])
    def market_clone_page():
        """A whole page of the last preview, before or after (drawn on demand: ~15 s the first time)."""
        from .. import market_clone

        data = request.get_json(force=True, silent=True) or {}
        slot = dict(_CLONE_PREVIEW)
        if not slot or data.get("preview_key") != slot.get("key"):
            return jsonify({"ok": False, "error": "This preview has expired — show the changes again."}), 409
        which = "after" if data.get("which") == "after" else "before"
        try:
            path = market_clone.page_picture(slot["source"], slot["psd"], slot["plan"], int(data.get("page_key")),
                                             which, os.path.join(slot["folder"], "pages"))
        except Exception as exc:
            return jsonify({"ok": False, "error": f"The page could not be drawn: {exc}"}), 500
        return jsonify({"ok": True, "path": path})

    @app.route("/api/market_clone", methods=["POST"])
    def market_clone_run():
        """Market B's PSD from market A's hand-made PSD: the artist's file, with the text layers
        that show Excel data given market B's values (market_clone.py). A background job. The
        page / symbol links the artist confirmed come along and are saved with the game."""
        from .. import market_clone
        from ..psd_writer import photoshop_finish

        data = request.get_json(force=True, silent=True) or {}
        cfg = _config()
        src, excel_a, excel_b, err = _clone_inputs(data)
        if err:
            return err
        game_id = cfg.get("active_game") or None
        links = data.get("links") if isinstance(data.get("links"), dict) else None
        if links is not None:
            market_clone.save_links(src, links, game_id)
        else:
            links = market_clone.load_links(src, game_id)
        _CLONE_PREVIEW.clear()                        # the PSD is written from scratch: let the preview go
        out = str(data.get("out_psd") or "").strip().strip('"') or market_clone.default_out(src, excel_b)
        path_policy.grant(os.path.dirname(os.path.abspath(out)))
        try:                                          # only when asked: it opens the PSD in Photoshop
            finish = bool(data.get("photoshop")) and photoshop_finish.available(photoshop_finish.mode_of(cfg))
        except Exception:
            finish = False

        reject = [str(x) for x in (data.get("reject") or []) if x]   # pages the artist kept as they were
        edits = {str(k): str(v) for k, v in (data.get("edits") or {}).items()}   # texts the artist edited
        pictures = "list" if data.get("pictures") == "list" else data.get("pictures", True) is not False

        def _task(progress):
            import uuid

            progress("Reading the PSD and both Excel files…", 15)
            report = market_clone.clone(src, excel_a, excel_b, out, icon_folder=_clone_icons(cfg), progress=progress,
                                        links=links, photoshop=finish, reject=reject, pictures=pictures, edits=edits,
                                        game_id=game_id, engine="photoshop" if data.get("photoshop") else "records")
            if pictures == "list":                    # the new PSD in memory: a change is drawn when it's clicked
                key = uuid.uuid4().hex[:16]
                _CLONE_PREVIEW.clear()
                _CLONE_PREVIEW.update(key=key, source=src, psd=report.pop("_psd"), plan=report.pop("_plan"),
                                      jobs=report.pop("_crop_jobs", []), folder=os.path.splitext(out)[0] + " - review")
                report["preview_key"] = key
            progress("Done", 100)
            return dict(report, ok=True)

        job_id = job_manager.start_task(_task, "Update an artist-made PSD", with_progress=True)
        return jsonify({"ok": True, "job_id": job_id, "out_psd": out})

    @app.route("/api/market_clone/crop", methods=["POST"])
    def market_clone_crop():
        """Draw the before / after pictures of one change of the last clone, when the artist clicks it
        (nothing is drawn while the PSD is made)."""
        from .. import market_clone

        data = request.get_json(force=True, silent=True) or {}
        slot = dict(_CLONE_PREVIEW)
        if not slot or data.get("preview_key") != slot.get("key"):
            return jsonify({"ok": False, "error": "These changes have expired — update the PSD again."}), 409
        want = {os.path.normcase(str(p)) for p in data.get("paths") or [] if p}
        jobs = [j for j in slot.get("jobs") or [] if os.path.normcase(j[0]) in want and not os.path.isfile(j[0])]
        try:
            market_clone.draw_crops(jobs, threads=2)
        except Exception as exc:
            return jsonify({"ok": False, "error": f"The picture could not be drawn: {exc}"}), 500
        return jsonify({"ok": True, "drawn": len(jobs)})

    @app.route("/api/market_clone/picture")
    def market_clone_picture():
        """A clone review picture: a before / after page (a .jpg in a "- review" folder), or a symbol of
        the links check / a page of the preview (in the tool's own temp folder)."""
        import tempfile

        path = str(request.args.get("path") or "").strip()
        folder = os.path.basename(os.path.dirname(path))
        if path.lower().endswith((".png", ".jpg")) and os.path.isfile(path):
            root = os.path.normcase(os.path.join(tempfile.gettempdir(), "psh_clone_pages"))
            if os.path.normcase(os.path.abspath(path)).startswith(root + os.sep):
                return send_file(path, mimetype="image/png" if path.lower().endswith(".png") else "image/jpeg", max_age=0)
        if not path.lower().endswith(".jpg") or not folder.endswith(" - review") or not os.path.isfile(path):
            return jsonify({"ok": False, "error": "Picture not found."}), 404
        blocked = _reject_unallowed_path(path)
        if blocked:
            return blocked
        return send_file(path, mimetype="image/jpeg", max_age=0)

    @app.route("/api/paytable_layouts", methods=["GET"])
    def paytable_layouts_list():
        from . import paytable_layouts

        layouts = paytable_layouts.list_paytable_layouts()
        return jsonify({"ok": True, "layouts": layouts})

    @app.route("/api/paytable_layouts/<name>", methods=["GET"])
    def paytable_layouts_get(name):
        from . import paytable_layouts

        layout = paytable_layouts.get_paytable_layout(name)
        if not layout:
            return jsonify({"ok": False, "error": "Layout not found."}), 404
        return jsonify({"ok": True, "layout": layout})

    @app.route("/api/paytable_layouts/save", methods=["POST"])
    def paytable_layouts_save():
        from . import paytable_layouts

        data = request.get_json(force=True, silent=True) or {}
        name = str(data.get("name") or "").strip()
        layout = data.get("layout")
        if not name or not isinstance(layout, dict):
            return jsonify({"ok": False, "error": "name and layout are required."}), 400
        try:
            saved = paytable_layouts.save_user_layout(layout, name)
        except Exception as exc:
            return jsonify({"ok": False, "error": str(exc)}), 400
        return jsonify({"ok": True, "layout": saved})

    @app.route("/api/paytable_mapper/automap", methods=["POST"])
    def paytable_mapper_automap():
        data = request.get_json(force=True, silent=True) or {}
        result = engine_api.automap_paytable_slots(
            data.get("template") or {},
            data.get("excel_path") or _config().get("excel_path", ""),
            data.get("sheet_name") or "",
        )
        return jsonify({
            "ok": True,
            "mappings": result["mappings"],
            "unmapped": result["unmapped"],
            "pays_column": result["pays_column"],
            "values_column": result["values_column"],
            "sheet_dims": result.get("sheet_dims") or {"rows": 0, "cols": 0},
            "count": len(result["mappings"]),
        })

    @app.route("/api/paytable_mapper/card_symbol", methods=["POST"])
    def paytable_mapper_card_symbol():
        """The symbol a card really shows (after the live re-bind) and whether it has an image."""
        from . import ps_actions

        data = request.get_json(force=True, silent=True) or {}
        cfg = _config()
        template = data.get("template") or {}
        slot = str(data.get("slot") or "")
        mapped = ps_actions._mapping_dict(data.get("mappings") or template.get("mappings") or {})
        excel_path = data.get("excel_path") or cfg.get("excel_path", "")
        engine_api.drop_foreign_symbol_picks(mapped, excel_path)
        spec = dict(mapped.get(slot) or {"slot": slot, "mode": "icon", "token": f"<{slot}>"})
        sheet = data.get("sheet_name") or ""
        if excel_path and sheet and os.path.isfile(excel_path):
            try:
                ws = _borrow_wb(excel_path, data_only=True)[sheet]
                one = {slot: spec}
                ps_actions._sanitize_preview_mappings(one, ws, template)
                spec = one.get(slot) or spec
            except Exception:
                pass
        icons = dict(template.get("icon_mappings") or {})
        icons.update(cfg.get("icon_mappings") or {})
        info = ps_actions._mapping_preview_icon(spec, None, cfg.get("icon_folder", ""), icons)
        return jsonify({"ok": True, "token": spec.get("token") or "", "symbol": spec.get("symbol") or "",
                        "image": (info or {}).get("path") or ""})

    @app.route("/api/paytable_mapper/sheet_coverage", methods=["POST"])
    def paytable_mapper_sheet_coverage():
        """The paytable sheet with every filled cell marked rendered / not on the page."""
        from ps_autotypesetter import workbook_cache

        data = request.get_json(force=True, silent=True) or {}
        cfg = _config()
        excel_path = str(data.get("excel_path") or cfg.get("excel_path") or "")
        sheet = str(data.get("sheet_name") or "")
        if not excel_path or not os.path.isfile(excel_path):
            return jsonify({"ok": False, "error": "Choose an Excel file first."}), 400
        try:
            with workbook_cache.borrow(excel_path, data_only=True) as wb:
                if sheet not in wb.sheetnames:
                    return jsonify({"ok": False, "error": f"Sheet '{sheet}' not found."}), 400
                return jsonify(engine_api.paytable_sheet_coverage(
                    data.get("template") or {}, data.get("mappings"), wb[sheet], excel_path))
        except Exception as exc:
            return jsonify({"ok": False, "error": str(exc)}), 400

    @app.route("/api/paytable_mapper/auto_layout", methods=["POST"])
    def paytable_mapper_auto_layout():
        """Generate a fresh auto-fitted paytable layout for a sheet with explicit
        style options (pay/value placement + grid shape), auto-map it, and return
        the template + mappings + a live preview token so the mapper can adopt
        it. Does NOT persist config — the mapper saves on Apply, exactly like
        loading a built-in layout."""
        data = request.get_json(force=True, silent=True) or {}
        cfg = _config()
        excel_path = str(data.get("excel_path") or cfg.get("excel_path") or "").strip()
        sheet_name = _raw_sheet(data.get("sheet_name"))
        if not excel_path or not os.path.isfile(excel_path):
            return jsonify({"ok": False, "error": "Choose an Excel file first."}), 400
        if not sheet_name:
            return jsonify({"ok": False, "error": "No sheet selected."}), 400
        options = data.get("options") if isinstance(data.get("options"), dict) else {}
        try:
            template = engine_api._auto_paytable_template(excel_path, sheet_name, options)
        except Exception as exc:
            return jsonify({"ok": False, "error": f"Could not generate layout: {exc}"}), 400
        if not isinstance(template, dict) or not (template.get("slots") or {}):
            return jsonify({"ok": False, "error": "Generated layout has no slots."}), 400
        automap = engine_api.automap_paytable_slots(template, excel_path, sheet_name)
        mappings_list = automap.get("mappings") or []
        unmapped = automap.get("unmapped") or []

        # Best-effort live preview (mirrors /api/auto_page). Never fail the call
        # on a render hiccup — the mapper re-renders authoritatively on save.
        preview_token = ""
        try:
            from . import ps_actions

            mappings = {}
            for m in mappings_list:
                if isinstance(m, dict) and m.get("slot"):
                    mappings[str(m["slot"])] = m
            sheet_worksheet = None
            try:
                from openpyxl import load_workbook

                wb_preview = load_workbook(excel_path, data_only=True, read_only=True)
                if sheet_name in wb_preview.sheetnames:
                    sheet_worksheet = wb_preview[sheet_name]
            except Exception:
                sheet_worksheet = None
            preview_path = os.path.join(tempfile.gettempdir(), "psh_table_previews", f"{uuid.uuid4().hex}.png")
            os.makedirs(os.path.dirname(preview_path), exist_ok=True)
            rendered = ps_actions.render_table_outline_preview(
                template,
                preview_path,
                settings=_preview_render_settings(cfg),
                mappings=mappings,
                excel_path=excel_path,
                sheet_name=sheet_name,
                worksheet=sheet_worksheet,
                icon_folder=str(cfg.get("icon_folder") or ""),
                icon_mappings=cfg.get("icon_mappings") or {},
                bg_path=str(cfg.get("bg_path") or ""),
                annotations=bool(data.get("annotations", True)),
            )
            if os.path.isfile(preview_path):
                preview_token = _register_preview(rendered or preview_path)
        except Exception as exc:
            print(f"[auto_layout] preview render failed: {exc}")

        return jsonify({
            "ok": True,
            "template": template,
            "mappings": mappings_list,
            "unmapped": unmapped,
            "pays_column": automap.get("pays_column", ""),
            "values_column": automap.get("values_column", ""),
            "sheet_dims": automap.get("sheet_dims") or {"rows": 0, "cols": 0},
            "preview_token": preview_token,
            "count": len(mappings_list),
        })

    @app.route("/api/paytable_mapper/fill_pay_values", methods=["POST"])
    def paytable_mapper_fill_pay_values():
        data = request.get_json(force=True, silent=True) or {}
        result = engine_api.auto_fill_pay_value_slots(
            data.get("template") or {},
            data.get("mappings") or {},
            data.get("excel_path") or _config().get("excel_path", ""),
            data.get("sheet_name") or "",
        )
        return jsonify(result)

    @app.route("/api/paytable_mapper/sheet_data", methods=["POST"])
    def paytable_mapper_sheet_data():
        """Raw contents of the chosen paytable sheet — the mapper sidebar's
        data picker (rows + refs, filtered/selected client-side)."""
        data = request.get_json(force=True, silent=True) or {}
        result = engine_api.read_paytable_sheet_data(
            data.get("excel_path") or _config().get("excel_path", ""),
            data.get("sheet_name") or "",
        )
        return jsonify(result), (200 if result.get("ok") else 400)

    @app.route("/api/paytable_mapper/save", methods=["POST"])
    def paytable_mapper_save():
        from . import ps_actions

        data = request.get_json(force=True, silent=True) or {}
        cfg = _config()
        result, new_cfg = engine_api.save_paytable_mapping(cfg, data)
        if result.get("ok"):
            _set_config(new_cfg)
            result["config"] = new_cfg
            template = data.get("template") or {}
            if (template.get("slots") or {}):
                preview_path = os.path.join(tempfile.gettempdir(), "psh_table_previews", f"{uuid.uuid4().hex}.png")
                os.makedirs(os.path.dirname(preview_path), exist_ok=True)
                mapping_items = data.get("mappings") or []
                mappings = {}
                if isinstance(mapping_items, dict):
                    mappings = mapping_items
                else:
                    for m in mapping_items:
                        if isinstance(m, dict) and m.get("slot"):
                            mappings[str(m["slot"])] = m
                settings = _preview_render_settings(_config())
                cfg = _config()
                rendered = ps_actions.render_table_outline_preview(
                    template, preview_path,
                    settings=settings,
                    mappings=mappings,
                    excel_path=str(cfg.get("excel_path") or ""),
                    sheet_name=str(data.get("sheet_name") or ""),
                    icon_folder=str(cfg.get("icon_folder") or ""),
                    icon_mappings=cfg.get("icon_mappings") or {},
            bg_path=str(cfg.get('bg_path') or ''),
            annotations=bool(data.get("annotations", True)),
                )
                if os.path.isfile(preview_path):
                    result["preview_token"] = _register_preview(rendered or preview_path)
        return jsonify(result)

    # ── card templates (Paytable studio) ─────────────────────────────────────
    def _card_preview_token(template, mappings_list, cfg, sheet_name, drawn=None, icons=None):
        """Render the mapped card layout like /api/auto_page does; "" on failure.
        drawn (dict): filled with where each slot's icon / text actually landed, as image fractions.
        icons (list): filled with every icon inside text ({slot, tok, rect}), image fractions."""
        try:
            from . import ps_actions

            mappings = {str(m["slot"]): m for m in (mappings_list or []) if isinstance(m, dict) and m.get("slot")}
            excel_path = str(cfg.get("excel_path") or "")
            preview_path = os.path.join(tempfile.gettempdir(), "psh_table_previews", f"{uuid.uuid4().hex}.png")
            os.makedirs(os.path.dirname(preview_path), exist_ok=True)
            report = {}
            rendered = ps_actions.render_table_outline_preview(
                template, preview_path, settings=_preview_render_settings(cfg), mappings=mappings,
                excel_path=excel_path, sheet_name=sheet_name, worksheet=None,
                icon_folder=str(cfg.get("icon_folder") or ""), icon_mappings=cfg.get("icon_mappings") or {},
                bg_path=str(cfg.get("bg_path") or ""), annotations=False, report=report,
            )
            if os.path.isfile(preview_path):
                if (isinstance(drawn, dict) and report.get("drawn")) or (isinstance(icons, list) and report.get("icons")):
                    from PIL import Image as _Img

                    with _Img.open(rendered or preview_path) as im:
                        iw, ih = im.size
                    fr = lambda b: [b[0] / iw, b[1] / ih, b[2] / iw, b[3] / ih]
                    if isinstance(drawn, dict):
                        drawn.update({k: fr(b) for k, b in (report.get("drawn") or {}).items()})
                    if isinstance(icons, list):
                        icons.extend({"slot": i["slot"], "tok": i["tok"], "rect": fr(i["rect"])} for i in report.get("icons") or [])
                return _register_preview(rendered or preview_path)
        except Exception as exc:
            print(f"[card_templates] preview render failed: {exc}")
        return ""

    @app.route("/api/card_templates", methods=["GET"])
    def card_templates_list():
        from ..dynamic_pages.paytable import card_templates as ct

        ds = _config().get("dynamic_settings") or {}
        current = ds.get("paytable_card_template") if isinstance(ds.get("paytable_card_template"), dict) else None
        return jsonify({"ok": True, "templates": ct.list_templates(), "current": current})

    @app.route("/api/card_looks", methods=["GET"])
    def card_looks():
        """The card looks library: one card's shape, colours and layer style (dynamic_pages/paytable/card_looks.json)."""
        path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "dynamic_pages", "paytable", "card_looks.json")
        try:
            with open(path, encoding="utf-8") as fh:
                return jsonify({"ok": True, "looks": json.load(fh).get("looks") or []})
        except (OSError, ValueError):
            return jsonify({"ok": True, "looks": []})

    @app.route("/api/card_looks/auto_palette", methods=["POST"])
    def card_looks_auto_palette():
        """Extract a harmonious card & plate palette from the game's background image or symbol assets."""
        from ..dynamic_pages.paytable import card_templates as ct

        cfg = _config()
        bg = str(cfg.get("bg_path") or "")
        if not (bg and os.path.isfile(bg)):
            folder = str(cfg.get("icon_folder") or "")
            if folder and os.path.isdir(folder):
                for fn in sorted(os.listdir(folder)):
                    if fn.lower().endswith((".png", ".jpg", ".jpeg")):
                        bg = os.path.join(folder, fn)
                        break
        pal = ct.extract_auto_palette(bg)
        return jsonify({"ok": True, "palette": pal, "source": os.path.basename(bg) if bg else ""})

    @app.route("/api/paytable/split_pages", methods=["POST"])
    def paytable_split_pages():
        """Split a crowded paytable into 2 balanced compiled pages (Page 1: High + Features, Page 2: Low + Rules)."""
        from ..dynamic_pages.paytable import card_templates as ct
        from .. import workbook_cache as _wbc

        data = request.get_json(force=True, silent=True) or {}
        cfg = _config()
        excel = str(cfg.get("excel_path") or "")
        sheet = str(data.get("sheet_name") or "")
        template = data.get("template") or (cfg.get("dynamic_settings") or {}).get("paytable_card_template")
        if not isinstance(template, dict):
            first = (ct.list_templates() or [{}])[0].get("id")
            template = ct.get_template(first) if first else {}
        st = engine_api.paytable_sheet_structure(excel, sheet) if (excel and sheet) else {}
        ctx = {"canvas": (float(cfg.get("c_width") or 1920), float(cfg.get("c_height") or 1080)),
               "icon_folder": str(cfg.get("icon_folder") or ""), "icon_mappings": cfg.get("icon_mappings") or {}}
        try:
            with _wbc.borrow(excel, data_only=True) as wb:
                ws = wb[sheet] if sheet in wb.sheetnames else None
                pages = ct.split_paytable_pages(template, st, ws, ctx,
                                                min_fit=float(data.get("min_fit", 0.75)),
                                                max_single_cards=int(data.get("max_single_cards", 11)))
        except Exception:
            pages = ct.split_paytable_pages(template, st, None, ctx)
        return jsonify({"ok": True, "page_count": len(pages), "pages": pages})

    @app.route("/api/card_templates/<template_id>", methods=["GET"])
    def card_templates_get(template_id):
        from ..dynamic_pages.paytable import card_templates as ct

        t = ct.get_template(template_id)
        if not t:
            return jsonify({"ok": False, "error": "Template not found."}), 404
        return jsonify({"ok": True, "template": t})

    @app.route("/api/card_templates/save_copy", methods=["POST"])
    def card_templates_save_copy():
        """Save the (edited) template as the user's own copy; built-ins never change."""
        from ..dynamic_pages.paytable import card_templates as ct

        data = request.get_json(force=True, silent=True) or {}
        if not isinstance(data.get("template"), dict):
            return jsonify({"ok": False, "error": "No template to save."}), 400
        try:
            tid = ct.save_copy(data["template"], data.get("name"))
        except ValueError as exc:
            return jsonify({"ok": False, "error": str(exc)}), 400
        saved = ct.get_template(tid)
        cfg = _config()
        ds = dict(cfg.get("dynamic_settings") or {})
        ds["paytable_card_template"] = saved                # the game now uses its own copy
        cfg["dynamic_settings"] = ds
        _set_config(cfg)
        return jsonify({"ok": True, "id": tid, "template": saved, "templates": ct.list_templates(), "config": cfg})

    @app.route("/api/card_templates/delete", methods=["POST"])
    def card_templates_delete():
        from ..dynamic_pages.paytable import card_templates as ct

        data = request.get_json(force=True, silent=True) or {}
        try:
            ct.delete_user(data.get("id"))
        except ValueError as exc:
            return jsonify({"ok": False, "error": str(exc)}), 400
        return jsonify({"ok": True, "templates": ct.list_templates()})

    def _page_framed(template, tmpl, cfg):
        """A design made on the old centred 1920 x 1080 frame, moved once to this page's frame and settled
        where its compiled layout ``tmpl`` kept it (card_templates.to_page_frame / settle_frame) — the
        editor goes on from that copy; None for a design already on the page frame."""
        from ..dynamic_pages.paytable import card_templates as ct

        if not isinstance(template, dict) or template.get("frame") == "page" or not isinstance(tmpl, dict):
            return None
        from .. import bg_place

        canvas = (float(cfg.get("c_width") or 1920), float(cfg.get("c_height") or 1080))
        area = bg_place.area(cfg)
        return ct.settle_frame(ct.to_page_frame(template, canvas, ct.bg_area(canvas, area) if area else None), tmpl)

    @app.route("/api/card_templates/apply", methods=["POST"])
    def card_templates_apply():
        """Use this template (possibly edited, unsaved) for the game's paytables and preview one sheet."""
        data = request.get_json(force=True, silent=True) or {}
        template = data.get("template")
        if not isinstance(template, dict) or template.get("kind") != "card_template":
            return jsonify({"ok": False, "error": "Pick a paytable template first."}), 400
        cfg = _config()
        ds = dict(cfg.get("dynamic_settings") or {})
        ds["paytable_card_template"] = template            # per game: builds use it for every paytable sheet
        cfg["dynamic_settings"] = ds
        result, new_cfg = engine_api.auto_map_page(cfg, data.get("sheet_name") or "", "", {"card_template": template})
        tmpl = result.pop("_template", None)
        maps = result.pop("_mappings", None)
        if not result.get("ok"):
            _set_config(cfg)
            return jsonify(result), 400
        _set_config(new_cfg)
        result["config"] = new_cfg
        drawn, drawn_icons = {}, []
        result["preview_token"] = _card_preview_token(tmpl, maps, new_cfg, str(result.get("sheet_name") or ""), drawn, drawn_icons)
        result["drawn"] = drawn
        result["drawn_icons"] = drawn_icons
        result.update(_card_meta(tmpl, new_cfg))
        framed = _page_framed(template, tmpl, new_cfg)
        if framed:                                          # moved to the page frame: the editor goes on from it
            result["template"] = framed
        return jsonify(result)

    def _canvas_xf(tmpl, cfg):
        """(canvas w, h, scale, x offset, y offset): design px (the template's page-shaped frame) -> preview canvas px."""
        st = _preview_render_settings(cfg)
        cw, ch = float(st.get("canvas_width") or 1920), float(st.get("canvas_height") or 1080)
        dw, dh = float((tmpl.get("canvas") or {}).get("width") or 1920), float((tmpl.get("canvas") or {}).get("height") or 1080)
        sc = min(cw / dw, ch / dh)
        return cw, ch, sc, (cw - dw * sc) / 2.0, (ch - dh * sc) / 2.0

    def _card_meta(tmpl, cfg):
        """Where each block (title, features, card rows, notes, page area) lands on the preview image,
        as fractions of the image, plus design px per canvas px, for the on-canvas editor."""
        out = {}
        try:
            cw, ch, sc, ox, oy = _canvas_xf(tmpl, cfg)
            meta = tmpl.get("mapper_meta") or {}
            out["blocks"] = {k: [(ox + b[0] * sc) / cw, (oy + b[1] * sc) / ch, (ox + b[2] * sc) / cw, (oy + b[3] * sc) / ch]
                             for k, b in (meta.get("blocks") or {}).items()}
            out["canvas"] = {"width": cw, "height": ch, "scale": sc, "ox": ox, "oy": oy,
                             "dw": float((tmpl.get("canvas") or {}).get("width") or 1920),
                             "dh": float((tmpl.get("canvas") or {}).get("height") or 1080)}
            out["fit"] = meta.get("fit")
            out["texts"] = meta.get("texts") or []
            out["wild_text"] = meta.get("wild_text") or {}
            out["text_info"] = meta.get("text_info") or {}
            out["band_geo"] = meta.get("band_geo") or {}
            out["card_geo"] = meta.get("card_geo") or {}
            out["feature_parts"] = meta.get("feature_parts") or {}
            out["auto_boxes"] = meta.get("auto_boxes") or []
            out["required_boxes"] = meta.get("required_boxes") or []
            out["zones"] = meta.get("zones") or []
            out["free_cards"] = meta.get("free_cards") or {}
            out["auto_free"] = meta.get("auto_free") or []          # broken out by the layout (a paying WILD)
            out["scatter_key"] = meta.get("scatter_key") or ""      # the lone SCATTER box's symbol
            out["joined"] = meta.get("joined") or {}                 # independent cards put in a row
            out["scatter_card_parts"] = meta.get("scatter_card_parts") or []
            out["box_texts"] = meta.get("box_texts") or {}
            out["counts"] = {"high": meta.get("top_count"), "low": meta.get("lower_count")}
        except Exception:
            out["blocks"] = {}
        return out

    _live_icons = {}          # key -> icon file, for the studio's live view (only files the layout resolved)

    def _drafted(data, fn):
        """fn run with the text being typed on the Canvas (data["text_edits_draft"], not saved yet)."""
        from ps_autotypesetter import text_edits as _te

        def run(*a, **k):
            with _te.draft(data.get("text_edits_draft")):
                return fn(*a, **k)
        return run

    def _with_rules_icons(layout, kw):
        """A Game / Bingo Rules preview's layout with layout["icons"] = {TOKEN: url} for every <icon> in its
        text: the Canvas shows them as pictures while the text is typed in place."""
        from ps_autotypesetter.icon_mapping import resolve_icon_path

        texts = [str(x.get("text") or "") for x in (layout.get("lines") or [])]
        cells = layout.get("cells")
        texts += [str(v or "") for v in (cells.values() if isinstance(cells, dict) else [c.get("text") for c in cells or [] if isinstance(c, dict)])]
        icons = {}
        for tok in re.findall(r"<([^<>\n]+)>", "\n".join(texts)):
            name = re.sub(r"(?:~\d+(?:\.\d+)?)?(?:\^[\d.]+,[\d.]+)?\s*$", "", tok).strip(" .;,-!")
            key = name.upper()
            if not name or key in icons:
                continue
            try:
                path = resolve_icon_path(name, kw.get("icon_folder") or "", kw.get("icon_mappings") or {})
            except Exception:
                path = None
            icons[key] = _live_icon_url(path) if path and os.path.isfile(path) else ""
        layout["icons"] = icons
        return layout

    def _live_icon_url(path):
        import hashlib

        key = hashlib.sha1(os.path.abspath(path).encode("utf-8")).hexdigest()[:16]
        _live_icons[key] = path
        return f"/api/card_templates/icon/{key}"

    @app.route("/api/card_templates/icon/<key>")
    def card_templates_icon(key):
        path = _live_icons.get(str(key))
        if not path or not os.path.isfile(path):
            return jsonify({"ok": False, "error": "Icon not found."}), 404
        resp = send_file(path)
        resp.headers["Cache-Control"] = "max-age=3600"
        return resp

    @app.route("/api/card_templates/background")
    def card_templates_background():
        bg = str(_config().get("bg_path") or "")
        if not bg or not os.path.isfile(bg):
            return jsonify({"ok": False}), 404
        return send_file(bg)

    @app.route("/api/paytable/check", methods=["POST"])
    def paytable_check():
        """The paytable sheet(s) read back — one list per symbol: its pays and their cells — and checked
        against the page the card design makes of it: every pay of the Excel on the page, the same
        numbers, nothing cut off. Nothing is saved."""
        from ..dynamic_pages.paytable import pay_reader
        from . import ps_actions
        from .. import workbook_cache as _wbc

        data = request.get_json(force=True, silent=True) or {}
        cfg = dict(_config())
        excel = str(cfg.get("excel_path") or "")
        if not excel or not os.path.isfile(excel):
            return jsonify({"ok": False, "error": "Load the Excel first."}), 400
        sheet = str(data.get("sheet_name") or "")
        try:
            reads = pay_reader.read_workbook(excel, sheet or None)
        except Exception as exc:
            return jsonify({"ok": False, "error": f"The paytable could not be read: {exc}"}), 400
        ds = dict(cfg.get("dynamic_settings") or {})
        template = data.get("template") or ds.get("paytable_card_template")
        out = []
        for rd in reads:
            entry = {"read": rd}
            if isinstance(template, dict) and template.get("kind") == "card_template":
                c2 = dict(cfg, dynamic_settings=dict(ds, paytable_card_template=template))
                try:
                    result, _ = engine_api.auto_map_page(c2, rd["sheet"], "", {"card_template": template, "dry_run": True})
                except Exception as exc:
                    result = {"ok": False, "error": str(exc)}
                if result.get("ok"):
                    maps = {str(m.get("slot")): m for m in result.get("_mappings") or [] if isinstance(m, dict) and m.get("slot")}
                    texts = {}
                    with _wbc.borrow(excel, data_only=True) as wb:
                        ws = wb[rd["sheet"]] if rd["sheet"] in wb.sheetnames else None
                        for slot, m in maps.items():
                            kind, mode = str(m.get("kind") or "").casefold(), str(m.get("mode") or "").casefold()
                            if kind in {"icon", "dedicated_icon", "background"} or mode in {"icon", "symbol", "none"}:
                                continue
                            try:
                                texts[slot] = ps_actions._mapping_preview_text(m, ws)
                            except Exception:
                                texts[slot] = str(m.get("text") or "")
                    hidden = [o.get("slot") for o in result.get("overflow") or [] if isinstance(o, dict)]
                    entry["check"] = pay_reader.check_pays(rd, maps, texts, hidden)
                else:
                    entry["check_error"] = result.get("error") or "The page could not be laid out."
            out.append(entry)
        return jsonify({"ok": True, "excel": os.path.basename(excel), "sheets": out})

    @app.route("/api/paytable/psd_pages", methods=["POST"])
    def paytable_psd_pages():
        """The pages of an artist PSD that could be its paytable (artist_design/learn_cards.py), or the
        whole PSD when it is a blueprint (artist_design/blueprint.py)."""
        from ..artist_design import blueprint, learn_cards, psd_reader

        path = str((request.get_json(force=True, silent=True) or {}).get("psd_path") or "")
        if not path or not os.path.isfile(path):
            return jsonify({"ok": False, "error": "That PSD file isn't there."}), 400
        try:
            psd = psd_reader.open_psd(path)
            pages = learn_cards.paytable_groups(psd)
            if not pages and blueprint.is_blueprint(psd):     # plain named shapes, no text: a blueprint
                pages = [{"path": blueprint.PAGE, "visible": True, "numbers": 0, "blueprint": True}]
        except Exception as exc:
            return jsonify({"ok": False, "error": f"The PSD could not be read: {exc}"}), 400
        return jsonify({"ok": True, "pages": pages})

    @app.route("/api/paytable/learn", methods=["POST"])
    def paytable_learn():
        """An editable card design learned from the artist's paytable page, built on the game's design
        (or the first one): cards, rows, the card look, the symbol / counts / pays in a card. Nothing is
        saved — the Canvas shows it and Use makes it the game's design."""
        from ..artist_design import blueprint, learn_cards, psd_reader
        from ..dynamic_pages.paytable import card_templates as ct

        data = request.get_json(force=True, silent=True) or {}
        path, group = str(data.get("psd_path") or ""), str(data.get("group") or "")
        if not path or not os.path.isfile(path):
            return jsonify({"ok": False, "error": "That PSD file isn't there."}), 400
        ds = (_config().get("dynamic_settings") or {})
        base = ds.get("paytable_card_template") if isinstance(ds.get("paytable_card_template"), dict) else None
        if not base:
            first = (ct.list_templates() or [{}])[0].get("id")
            base = ct.get_template(first) if first else {}
        try:
            if group == blueprint.PAGE:                    # a blueprint: a design of its own, not built on the game's
                template, report = blueprint.read_blueprint(psd_reader.open_psd(path), os.path.splitext(os.path.basename(path))[0])
                return jsonify({"ok": True, "template": template, "report": report})
            out_w = int(float(_config().get("c_width") or 1920))     # card text sizes are in the canvas's px
            template, report = learn_cards.learn(psd_reader.open_psd(path), group, base, out_w)
        except Exception as exc:
            return jsonify({"ok": False, "error": str(exc)}), 400
        template["learned_from"]["psd"] = os.path.basename(path)
        _adopt_psd_light(path)
        return jsonify({"ok": True, "template": template, "report": report})

    @app.route("/api/paytable/read", methods=["POST"])
    def paytable_read():
        """The paytable sheet read back (pay_reader): what the Canvas needs to offer only symbols that pay
        the same for one shared card."""
        from ..dynamic_pages.paytable import pay_reader

        data = request.get_json(force=True, silent=True) or {}
        excel = str(_config().get("excel_path") or "")
        if not excel or not os.path.isfile(excel):
            return jsonify({"ok": False, "error": "Load the Excel first."}), 400
        try:
            reads = pay_reader.read_workbook(excel, str(data.get("sheet_name") or "") or None)
        except Exception as exc:
            return jsonify({"ok": False, "error": str(exc)}), 400
        return jsonify({"ok": True, "read": reads[0] if reads else None})

    @app.route("/api/paytable/suggest", methods=["POST"])
    def paytable_suggest():
        """Suggested layouts for a paytable sheet: the game's own design first, then the best rule-made
        arrangements of it (tiers, cards across, same pays sharing a card), each laid out for real and
        scored (dynamic_pages/paytable/suggest.py). Nothing is saved — the Canvas applies the one picked."""
        from ..dynamic_pages.paytable import card_templates as ct, pay_reader, suggest as sg

        data = request.get_json(force=True, silent=True) or {}
        cfg = dict(_config())
        excel, sheet = str(cfg.get("excel_path") or ""), str(data.get("sheet_name") or "")
        if not excel or not os.path.isfile(excel):
            return jsonify({"ok": False, "error": "Load the Excel first."}), 400
        ds = dict(cfg.get("dynamic_settings") or {})
        own = ds.get("paytable_card_template") if isinstance(ds.get("paytable_card_template"), dict) else None
        base = data.get("template") if isinstance(data.get("template"), dict) else own
        if not base:
            first = (ct.list_templates() or [{}])[0].get("id")
            base = ct.get_template(first) if first else None
        if not base:
            return jsonify({"ok": False, "error": "No paytable design to start from."}), 400
        try:
            read = pay_reader.read_workbook(excel, sheet or None)[0]
        except Exception as exc:
            return jsonify({"ok": False, "error": f"The paytable could not be read: {exc}"}), 400

        def lay_out(t):
            c2 = dict(cfg, dynamic_settings=dict(ds, paytable_card_template=t))
            try:
                return engine_api.auto_map_page(c2, read["sheet"], "", {"card_template": t, "dry_run": True})[0]
            except Exception:
                return None

        out = sg.suggest(base, read, lay_out, own=bool(own))
        archetypes = sg.suggest_archetypes(read, lay_out) if data.get("include_archetypes", True) else []
        return jsonify({"ok": True, "suggestions": out, "archetypes": archetypes})

    @app.route("/api/card_templates/layout", methods=["POST"])
    def card_templates_layout():
        """The studio's live view: the mapped card layout as a draw list (shapes, icons, text in canvas
        px) — no PNG, nothing saved. The browser draws it instantly; the exact PNG follows via /apply."""
        from . import ps_actions
        from .. import workbook_cache as _wbc

        data = request.get_json(force=True, silent=True) or {}
        template = data.get("template")
        if not isinstance(template, dict) or template.get("kind") != "card_template":
            return jsonify({"ok": False, "error": "Pick a paytable template first."}), 400
        cfg = dict(_config())
        ds = dict(cfg.get("dynamic_settings") or {})
        ds["paytable_card_template"] = template
        cfg["dynamic_settings"] = ds
        sheet = data.get("sheet_name") or ""
        result, _ = engine_api.auto_map_page(cfg, sheet, "", {"card_template": template, "dry_run": True})
        if not result.get("ok"):
            return jsonify(result), 400
        tmpl, maps = result["_template"], {str(m.get("slot")): m for m in result["_mappings"] if isinstance(m, dict)}
        cw, ch, sc, ox, oy = _canvas_xf(tmpl, cfg)
        folder, imaps = str(cfg.get("icon_folder") or ""), cfg.get("icon_mappings") or {}
        from .. import png_builder as _pb

        _hov = _pb._png_page_style_override(sheet, cfg.get("page_overrides"))             # this page's own heading
        heading = {"font": str(_hov.get("h_font") or cfg.get("h_font") or ""),
                   "size": float(_hov.get("h_size") or cfg.get("h_size") or 60),
                   "color": str(_hov.get("h_rgb") or cfg.get("h_rgb") or "#FFFFFF")}
        items, icons = [], {}
        # layer styles, as the build draws them: the title gets the page heading's style ("Heading
        # text"), a text its own (text_fx), a shape its own (shape.fx) — full configs for window.PsFx

        _ds = cfg.get("dynamic_settings") or {}
        _lib, _assign = _ds.get("layer_style_library") or {}, _ds.get("style_assignments") or {}

        def fx_cfg(name=None, role=None):
            if isinstance(name, dict):                  # a design's own layer style (glow, bevel, gold…) written in it
                return name
            try:
                return (_pb._resolve_fx_config(_lib, _assign, role) if role else _pb.fx_by_name(_lib, name)) or None
            except Exception:
                return None

        def inline_icons(text):
            from ps_autotypesetter.icon_mapping import resolve_icon_path

            for tok in re.findall(r"<([^<>]+)>", str(text or "")):
                key = tok.strip(" .;,-!").upper()
                if key in icons:
                    continue
                try:
                    path = resolve_icon_path(tok.strip(" .;,-!"), folder, imaps)
                except Exception:
                    path = None
                icons[key] = _live_icon_url(path) if path and os.path.isfile(path) else ""

        excel = str(cfg.get("excel_path") or "")
        try:
            borrowed = _wbc.borrow(excel, data_only=True)
            wb = borrowed.__enter__()
        except Exception:
            borrowed, wb = None, None
        try:
            ws = wb[sheet] if wb is not None and sheet in wb.sheetnames else None
            for slot, b in (tmpl.get("slots") or {}).items():
                m = maps.get(slot) or {}
                try:
                    rect = [ox + float(b["x"]) * sc, oy + float(b["y"]) * sc, float(b["w"]) * sc, float(b["h"]) * sc]
                except Exception:
                    continue
                it = {"slot": slot, "rect": [round(v, 1) for v in rect]}
                if m.get("shape"):
                    it["shape"] = m["shape"]
                    if m["shape"].get("fx"):
                        it["shape_fx"] = fx_cfg(m["shape"]["fx"])
                mode = str(m.get("mode") or "").casefold()
                kind = str(m.get("kind") or "").casefold()
                if kind == "background" or mode == "none":
                    if it.get("shape"):
                        items.append(it)
                    continue
                style = {"size": float(m.get("font_size") or m.get("size") or 30), "color": m.get("color") or "#FFFFFF",
                         "align": m.get("alignment") or "center", "valign": m.get("vertical_align") or "center",
                         "font": m.get("font_name") or m.get("font_family") or "", "bold": bool(m.get("bold")),
                         "italic": bool(m.get("italic")), "line_height": float(m.get("line_height") or 0),
                         "icon_h": float(m.get("icon_height") or 0), "icon_scales": m.get("icon_scales") or {},
                         "shrink": bool(m.get("shrink_to_fit")), "fit": bool(m.get("fit_box"))}
                if kind in {"icon", "dedicated_icon"} or mode in {"icon", "symbol"}:
                    info = ps_actions._mapping_preview_icon(m, ws, folder, imaps)
                    # the <TOKEN> it shows (Change picture… on the Canvas maps another picture to it)
                    it["token"] = str(m.get("token") or (info or {}).get("token") or slot.split(".", 1)[-1]).strip("<> ").upper()
                    if info:
                        it["icon"] = _live_icon_url(info["path"])
                        it["align"], it["valign"] = style["align"], style["valign"]
                    elif str(m.get("token") or "").strip("<> "):
                        it["text"] = "<" + str(m.get("token")).strip("<> ").upper() + ">"
                        it["style"] = style
                    items.append(it)
                    continue
                if slot == "@slot.title" or ps_actions._preview_slot_is_title(slot):
                    text = ps_actions._preview_page_heading(ws, tmpl) or "PAYTABLE"
                    # <GAME NAME>: the game's name (or its name picture), as the Paytable page's preview
                    # and the build show it
                    _pb_settings = dict(cfg, **(cfg.get("dynamic_settings") or {}))
                    text = _pb.game_name_heading(text, _pb_settings, folder, imaps)
                    if bool(_pb_settings.get("heading_uppercase_enabled", False)):
                        text = text.upper()
                    style.update(size=heading["size"], color=heading["color"], font=heading["font"], bold=True)
                    own = m.get("title_own") or {}         # the paytable title's own look (page.title)
                    if own.get("font_size"):
                        style["size"] = float(own["font_size"])
                    if own.get("color"):
                        style["color"] = str(own["color"])
                    if own.get("font"):
                        style["font"] = str(own["font"])
                    if "bold" in own:
                        style["bold"] = bool(own["bold"])
                    if "italic" in own:
                        style["italic"] = bool(own["italic"])
                    title_size0 = float(style["size"])        # its size before it is fit to one line
                    # on its own lines (one, or as many as its text has): too long for its box it gets smaller,
                    # the same steps as the build (ps_actions)
                    try:
                        from PIL import ImageFont as _IF

                        want_w = max(8.0, rect[2] - 6)
                        lines_ = [ln for ln in str(text).split("\n") if ln.strip()] or [str(text)]
                        size0 = float(style["size"])
                        floor_ = max(9, int(size0 * 0.2))

                        def _widest(sz):
                            f_ = _pb._load_font(_IF, style.get("font") or "Arial", int(sz), bold=bool(style.get("bold")), italic=bool(style.get("italic")))
                            return max(f_.getlength(re.sub(r"<[^<>]+>", "MM", ln)) for ln in lines_)

                        sz = int(size0)
                        while _widest(sz) > want_w and sz > floor_:
                            sz = max(floor_, int(sz * 0.97))
                        if sz < int(size0):
                            style["size"] = float(sz)
                    except Exception:
                        pass
                else:
                    text = ps_actions._mapping_preview_text(m, ws)
                if text:
                    it["text"], it["style"] = text, style
                    inline_icons(text)
                    # the build's own layout of this text (ps_actions.slot_text_layout — what the PSD gets):
                    # the Canvas draws these lines, sizes and places, never a wrap of its own
                    try:
                        is_title = slot == "@slot.title" or ps_actions._preview_slot_is_title(slot)
                        mm = dict(m, font_size=title_size0 or style["size"], font_name=style["font"], font_override=True,
                                  bold=style["bold"], italic=style["italic"]) if is_title else m
                        bx, by, bw, bh = (int(v) for v in rect)
                        lay = ps_actions.slot_text_layout(slot, mm, text, bx, by, bw, bh, folder, imaps, kind)
                        it["layout"] = dict(ps_actions.layout_for_canvas(lay, by), rect=it["rect"], x=bx, y=by)
                        style["size"] = float(it["layout"]["size"])
                        if ps_actions.plate_is_late(m.get("shape")) or (is_title and m.get("shape")):
                            # the plate (the title's): where the build draws it — around its text, or its slot
                            pr = ps_actions.plate_rect(m["shape"], bx, by, bw, bh, lay) if ps_actions.plate_is_late(m.get("shape"))                                 else (bx, by, bw, bh)
                            it["plate_rect"] = [round(float(v), 2) for v in pr]
                            it["text_rect"] = [round(v, 2) for v in ps_actions.text_rect(lay)]
                    except Exception:
                        pass
                    fx = None
                    if (slot == "@slot.title" or ps_actions._preview_slot_is_title(slot)) and not m.get("effects_block"):
                        _own_fx = (m.get("title_own") or {}).get("fx")          # the title's own layer style
                        fx = fx_cfg(_own_fx) if _own_fx else fx_cfg(role="Heading text")
                    if not fx and m.get("text_fx"):
                        fx = fx_cfg(m["text_fx"])
                    if fx:
                        it["fx"] = fx
                if it.get("text") or it.get("shape"):
                    items.append(it)
        finally:
            if borrowed is not None:
                try:
                    borrowed.__exit__(None, None, None)
                except Exception:
                    pass
        from .. import bg_place as _bgp

        bg = str(cfg.get("bg_path") or "")
        out = {"ok": True, "canvas_px": {"width": cw, "height": ch}, "items": items, "icons": icons,
               "background": "/api/card_templates/background" if bg and os.path.isfile(bg) else "",
               "bg_color": _bgp.behind(cfg), "overflow": result.get("overflow") or []}
        out.update(_card_meta(tmpl, cfg))
        framed = _page_framed(template, tmpl, cfg)
        if framed:                                          # moved to the page frame: the editor goes on from it
            out["template"] = framed
        return jsonify(out)

    @app.route("/api/auto_page", methods=["POST"])
    def auto_page():
        """Zero-map convention path: auto-map a conventionally-named paytable
        sheet against a bundled/default layout and register it for the build —
        no manual mapping. Mirrors the paytable_mapper/save config-persist and
        returns a live preview token (like game_rules/preview) so the wizard can
        show the result immediately with no manual mapping step."""
        data = request.get_json(force=True, silent=True) or {}
        cfg = _config()
        result, new_cfg = engine_api.auto_map_page(
            cfg,
            data.get("sheet_name") or "",
            data.get("layout_name") or "",
        )
        # Pop the private render hand-off before the result reaches the client.
        template = result.pop("_template", None)
        mappings_list = result.pop("_mappings", None)
        if result.get("ok"):
            _set_config(new_cfg)
            result["config"] = new_cfg
            # Mint a preview token exactly like /api/paytable_mapper/render_preview.
            result["preview_token"] = ""
            if isinstance(template, dict) and (template.get("slots") or {}):
                try:
                    from . import ps_actions

                    mappings = {}
                    for m in (mappings_list or []):
                        if isinstance(m, dict) and m.get("slot"):
                            mappings[str(m["slot"])] = m
                    sheet_name = str(result.get("sheet_name") or "")
                    sheet_worksheet = None
                    excel_path = str(new_cfg.get("excel_path") or "")
                    if sheet_name and excel_path and os.path.isfile(excel_path):
                        try:
                            from openpyxl import load_workbook

                            wb_preview = load_workbook(excel_path, data_only=True, read_only=True)
                            if sheet_name in wb_preview.sheetnames:
                                sheet_worksheet = wb_preview[sheet_name]
                        except Exception:
                            sheet_worksheet = None
                    preview_path = os.path.join(tempfile.gettempdir(), "psh_table_previews", f"{uuid.uuid4().hex}.png")
                    os.makedirs(os.path.dirname(preview_path), exist_ok=True)
                    rendered = ps_actions.render_table_outline_preview(
                        template,
                        preview_path,
                        settings=_preview_render_settings(new_cfg),
                        mappings=mappings,
                        excel_path=excel_path,
                        sheet_name=sheet_name,
                        worksheet=sheet_worksheet,
                        icon_folder=str(new_cfg.get("icon_folder") or ""),
                        icon_mappings=new_cfg.get("icon_mappings") or {},
                        bg_path=str(new_cfg.get("bg_path") or ""),
                        annotations=False,
                    )
                    if os.path.isfile(preview_path):
                        result["preview_token"] = _register_preview(rendered or preview_path)
                except Exception as exc:
                    # Preview is best-effort — the map + config write already
                    # succeeded, so never fail the whole call on a render hiccup.
                    print(f"[auto_page] preview render failed: {exc}")
        return jsonify(result), (200 if result.get("ok") else 400)

    @app.route("/api/preflight", methods=["POST"])
    def preflight():
        """Structured, side-effect-free pre-build check. The frontend posts the
        same ``{config}`` it will build with; nothing is persisted here."""
        data = request.get_json(force=True, silent=True) or {}
        cfg = _config()
        if isinstance(data.get("config"), dict):
            cfg = dict(cfg)
            cfg.update(data["config"])
        return jsonify(engine_api.preflight(cfg))

    @app.route("/api/paytable_mapper/global_styles", methods=["POST"])
    def paytable_mapper_global_styles_save():
        """Remember the last-used Global Settings across sessions (stored in
        the session file, shared by every paytable layout)."""
        data = request.get_json(force=True, silent=True) or {}
        if data.get("clear"):
            styles = {}
        else:
            styles = data.get("styles")
            if not isinstance(styles, dict):
                return jsonify({"ok": False, "error": "styles must be an object."}), 400
        cfg = dict(_config())
        cfg["paytable_global_styles"] = styles
        _set_config(cfg)
        return jsonify({"ok": True, "styles": styles})

    @app.route("/api/paytable_mapper/preview", methods=["POST"])
    def paytable_mapper_preview():
        from . import ps_actions

        data = request.get_json(force=True, silent=True) or {}
        path = str(data.get("path") or "").strip()
        if not path:
            path = str((_config().get("dynamic_settings") or {}).get("template_json") or "").strip()
        if not path or not os.path.isfile(path):
            return jsonify({"ok": False, "error": "No mapped paytable JSON configured."}), 400
        try:
            payload = engine_api.load_paytable_mapper_session(path)
        except Exception as exc:
            return jsonify({"ok": False, "error": str(exc)}), 400
        preview_path = os.path.join(tempfile.gettempdir(), "psh_table_previews", f"{uuid.uuid4().hex}.png")
        os.makedirs(os.path.dirname(preview_path), exist_ok=True)
        settings = _preview_render_settings(_config())
        cfg = _config()
        template = payload.get("template") or {}
        rendered = ps_actions.render_table_outline_preview(
            template,
            preview_path,
            settings=settings,
            mappings=payload.get("mappings"),
            excel_path=str(cfg.get("excel_path") or ""),
            sheet_name=str(data.get("sheet_name") or (template.get("mapper_meta") or {}).get("sheet_name") or ""),
            icon_folder=str(cfg.get("icon_folder") or ""),
            icon_mappings=cfg.get("icon_mappings") or {},
            bg_path=str(cfg.get('bg_path') or ''),
            annotations=bool(data.get("annotations", True)),
        )
        token = _register_preview(rendered or preview_path) if os.path.isfile(preview_path) else ""
        slots_total = len((payload.get("template") or {}).get("slots") or {})
        mappings = payload.get("mappings") or {}
        slots_mapped = len([s for s in mappings.values() if isinstance(s, dict) and (s.get("text") or s.get("source_cell") or "").strip()])
        return jsonify({
            "ok": True,
            "preview_token": token,
            "slots_total": int(slots_total or 0),
            "slots_mapped": int(slots_mapped or 0),
        })

    @app.route("/api/paytable_mapper/render_preview", methods=["POST"])
    def paytable_mapper_render_preview():
        """Render a live preview PNG for an in-progress mapping session
        (no config writes) — used for live updates while editing slot props."""
        from . import ps_actions

        data = request.get_json(force=True, silent=True) or {}
        template = data.get("template") or {}
        if not isinstance(template, dict) or not (template.get("slots") or {}):
            return jsonify({"ok": False, "error": "Missing template slots."}), 400
        mapping_items = data.get("mappings") or {}
        mappings = {}
        if isinstance(mapping_items, dict):
            mappings = mapping_items
        else:
            for m in mapping_items:
                if isinstance(m, dict) and m.get("slot"):
                    mappings[str(m["slot"])] = m
        preview_path = os.path.join(tempfile.gettempdir(), "psh_table_previews", f"{uuid.uuid4().hex}.png")
        os.makedirs(os.path.dirname(preview_path), exist_ok=True)
        cfg = _config()
        report = {}
        sheet_name = str(data.get("sheet_name") or (template.get("mapper_meta") or {}).get("sheet_name") or "")
        sheet_worksheet = None     # the renderer reads the sheet from the shared parsed-workbook cache
        rendered = ps_actions.render_table_outline_preview(
            template,
            preview_path,
            settings=_preview_render_settings(cfg),
            mappings=mappings,
            excel_path=str(cfg.get("excel_path") or ""),
            sheet_name=sheet_name,
            worksheet=sheet_worksheet,
            icon_folder=str(cfg.get("icon_folder") or ""),
            icon_mappings=cfg.get("icon_mappings") or {},
            bg_path=str(cfg.get('bg_path') or ''),
            annotations=bool(data.get("annotations", True)),
            report=report,
        )
        token = _register_preview(rendered or preview_path) if os.path.isfile(preview_path) else ""
        return jsonify({"ok": True, "preview_token": token, "icon_issues": report.get("icon_issues") or [], "overflow_issues": report.get("overflow_issues") or [], "card_grid": report.get("card_grid") or {}})

    def _render_rules_page(data, kind, report, cfg=None):
        """Render the Game Rules / Bingo Rules sheet (kind "game_rules" / "bingo_rules") with the same
        pure-Python renderer as the PNG build. Returns (pages, sheet_name, kw), or (None, error, status).
        cfg: the settings to draw with (a drag's unsaved values); the saved ones when None."""
        from ps_autotypesetter import png_builder

        label = "Game Rules" if kind == "game_rules" else "Bingo Rules"
        cfg = _config() if cfg is None else cfg
        excel_path = str(cfg.get("excel_path") or "")
        if not excel_path or not os.path.isfile(excel_path):
            return None, "Excel workbook not set. Configure it in the Project view first.", 400

        kw = engine_api._build_kwargs(cfg)
        try:
            wb = _borrow_wb(excel_path)
        except Exception as exc:
            return None, f"Cannot open workbook: {exc}", 400

        wanted = [str(s) for s in (cfg.get("selected_sheets") or []) if str(s) in wb.sheetnames]
        kind_candidates = [s for s in wb.sheetnames if png_builder._normalized_sheet_kind(s) == kind]
        candidates = [s for s in wanted if s in kind_candidates] or kind_candidates
        sheet_name = _raw_sheet(data.get("sheet_name")) or (candidates[0] if candidates else "")
        if sheet_name not in wb.sheetnames:
            return None, f"No {label} sheet found in the workbook.", 400
        if png_builder._normalized_sheet_kind(sheet_name) != kind:
            return None, f"'{sheet_name}' is not a {label} sheet.", 400
        ws = wb[sheet_name]

        Image, ImageDraw, ImageFont = png_builder._require_pillow()
        dynamic_settings = _preview_dynamic_settings(cfg)
        alignment_settings = kw["alignment_settings"] or {}
        _ps_ov = png_builder._png_page_style_override(sheet_name, kw.get("page_overrides"))
        pg_h_font = str(_ps_ov.get("h_font") or kw["h_font"])
        pg_h_rgb = _ps_ov.get("h_rgb") or kw["h_rgb"]
        pg_b_font = str(_ps_ov.get("b_font") or kw["b_font"])
        pg_b_rgb = _ps_ov.get("b_rgb") or kw["b_rgb"]
        pg_h_size = kw["h_size"]
        if _ps_ov.get("h_size") is not None:
            try:
                pg_h_size = max(8, int(float(_ps_ov.get("h_size") or kw["h_size"])))
            except Exception:
                pg_h_size = kw["h_size"]
        pg_b_size = kw["b_size"]
        if _ps_ov.get("b_size") is not None:
            try:
                pg_b_size = max(8, int(float(_ps_ov.get("b_size") or kw["b_size"])))
            except Exception:
                pg_b_size = kw["b_size"]
        heading_size = png_builder._png_heading_size_for_sheet(sheet_name, dynamic_settings, pg_h_size)
        page_min_row, page_max_row, page_min_col, page_max_col = png_builder._render_window_for_sheet(
            dynamic_settings, sheet_name, kw["max_col_limit"], ws
        )
        extra = {}
        if kind == "game_rules":
            extra["xtra_candidate_dirs"] = [
                str(cfg.get("output_dir") or ""),
                str(cfg.get("icon_folder") or ""),
                os.path.dirname(os.path.abspath(excel_path)),
            ]
        render = png_builder._render_game_rules_png_pages if kind == "game_rules" else png_builder._render_bingo_rules_png_pages
        from ps_autotypesetter import text_styles

        try:
            # word styles and line strips, as the build draws them (text_styles.begin covers every sheet)
            with text_styles.active(dynamic_settings.get("text_style_rules") or [], sheet_name,
                                    dynamic_settings.get("layer_style_library")):
              pages = _drafted(data, render)(
                Image, ImageDraw, ImageFont, ws, sheet_name,
                kw["bg_path"], kw["bg_mode"], kw["bg_color"],
                kw["c_width"], kw["c_height"],
                pg_h_font, heading_size, kw["h_icon_h"], pg_h_rgb,
                pg_b_font, pg_b_size, kw["b_icon_h"], pg_b_rgb,
                kw["margin_x"], kw["heading_top_margin"], kw["heading_to_body_gap"],
                kw["bottom_margin"], kw["line_spacing"], kw["para_spacing"],
                kw["icon_folder"], kw["icon_mappings"] or {}, kw["icon_size_overrides"] or {},
                dynamic_settings, alignment_settings,
                page_min_col=page_min_col, page_max_col=page_max_col,
                page_min_row=page_min_row, page_max_row=page_max_row,
                report=report, **extra,
            )
        except Exception as exc:
            return None, f"Preview render failed: {exc}", 500
        if not pages:
            return None, "Renderer produced no pages.", 500
        return pages, sheet_name, kw

    def _adopt_psd_light(psd_path):
        """Styles brought in from an artist PSD: the project takes that PSD's Global Light (its "Use Global
        Light" shadows / bevels are drawn at it) — every time, like a style copied from Photoshop, so the
        angle is never typed in."""
        from ps_autotypesetter import global_light

        cfg = _config()
        ds = cfg.get("dynamic_settings") if isinstance(cfg.get("dynamic_settings"), dict) else {}
        light = global_light.read_psd(psd_path)
        if light and light != ds.get("fx_global_light"):
            cfg = dict(cfg, dynamic_settings=dict(ds, fx_global_light=light))
            _set_config(cfg)

    _paylines_memo = {}

    def _is_paylines_sheet(cfg, sheet_name):
        """Does this sheet build as Paylines / Win Lines pages (paylines.is_payline_page)? Asked for every
        page the Canvas lays out: kept per Excel file version."""
        from ps_autotypesetter.memo import file_stamp
        from ..dynamic_pages import paylines as pl

        excel_path = str(cfg.get("excel_path") or "")
        if not excel_path or not os.path.isfile(excel_path):
            return False
        key = (excel_path, repr(file_stamp(excel_path)), sheet_name)
        if key not in _paylines_memo:
            try:
                wb = _borrow_wb(excel_path, data_only=True)
                _paylines_memo[key] = sheet_name in wb.sheetnames and pl.is_payline_page(wb[sheet_name])
            except Exception:
                return False
            if len(_paylines_memo) > 200:
                _paylines_memo.clear()
        return _paylines_memo[key]

    def _paylines_layout_payload(cfg, sheet_name):
        """/api/layout/preview for a payline sheet: every page of it (built or switched off), drawn by the
        build's renderer with the build's arguments (png_builder.build_pngs_only), as canonical layouts."""
        from ps_autotypesetter import paylines_layout, png_builder, text_styles
        from ..dynamic_pages import paylines as pl

        kw = engine_api._build_kwargs(cfg)
        dynamic_settings = _preview_dynamic_settings(cfg)
        ws = _borrow_wb(str(cfg.get("excel_path") or ""), data_only=True)[sheet_name]
        Image, ImageDraw, ImageFont = png_builder._require_pillow()
        ov = png_builder._png_sheet_page_style(sheet_name, kw.get("page_overrides"), kw["h_font"], kw["h_rgb"], kw["b_font"],
                                               kw["b_rgb"], kw["h_size"], kw["b_size"], dynamic_settings)
        h_size = (ov["h_size"] if ov.get("h_size") is not None
                  else png_builder._png_heading_size_for_sheet(sheet_name, dynamic_settings, ov["h_size"]))
        cw, ch = int(kw["c_width"]), int(kw["c_height"])
        effective = pl.settings_for(dynamic_settings, cw)
        extra = {"settings": effective, "defaults": pl.settings_for({}, cw), "sheet": sheet_name}

        def render(meta):
            # word styles and strips on the heading, as the build draws them
            with text_styles.active(dynamic_settings.get("text_style_rules") or [], sheet_name,
                                    dynamic_settings.get("layer_style_library")):
                return png_builder._render_paylines_png_pages(
                    Image, ImageDraw, ImageFont, ws, sheet_name, kw["bg_path"], kw["bg_mode"], kw["bg_color"], cw, ch,
                    ov["h_font"], h_size, kw["h_icon_h"], ov["h_rgb"], kw["margin_x"], kw["heading_top_margin"],
                    kw["line_spacing"], kw["icon_folder"], kw["icon_mappings"] or {}, kw["icon_size_overrides"] or {},
                    dynamic_settings, kw["alignment_settings"] or {}, meta=meta, every=True,
                )

        return paylines_layout.layout_payload(render, sheet_name, cw, ch, int(kw["margin_x"] or 0),
                                              int(kw["heading_top_margin"] or 0), register_preview=_register_preview, extra=extra)

    def _rules_preview(kind):
        data = request.get_json(force=True, silent=True) or {}
        layout = {}                       # where everything landed: the studio's click-to-edit overlay
        pages, sheet_name, kw = _render_rules_page(data, kind, layout)
        if pages is None:
            return jsonify({"ok": False, "error": sheet_name}), kw
        out_dir = os.path.join(tempfile.gettempdir(), "psh_table_previews")
        os.makedirs(out_dir, exist_ok=True)
        preview_path = os.path.join(out_dir, f"{uuid.uuid4().hex}.png")
        pages[0].save(preview_path, "PNG")
        token = _register_preview(preview_path)
        return jsonify({
            "ok": True,
            "preview_token": token,
            "sheet_name": sheet_name,
            "pages": len(pages),
            "canvas_width": int(kw["c_width"]),
            "canvas_height": int(kw["c_height"]),
            "layout": _with_rules_icons(layout, kw),
        })

    @app.route("/api/game_rules/preview", methods=["POST"])
    def game_rules_preview():
        """Live PNG preview of the Game Rules sheet — uses the same pure-Python
        renderer as the PNG build (no Photoshop needed) so the studio preview
        matches the real output."""
        return _rules_preview("game_rules")

    @app.route("/api/paylines/preview", methods=["POST"])
    def paylines_preview():
        """Paylines / Win Lines: what the Excel says (lines, denomination pages,
        problems) and a PNG of one page, from the real renderer.
        Body: {sheet_name?, page?: index, settings?: unsaved paylines settings}."""
        from ps_autotypesetter import png_builder
        from ..dynamic_pages import paylines as pl

        data = request.get_json(force=True, silent=True) or {}
        cfg = copy.deepcopy(_config())
        if isinstance(data.get("settings"), dict):
            ds = cfg.get("dynamic_settings") if isinstance(cfg.get("dynamic_settings"), dict) else {}
            cfg["dynamic_settings"] = dict(ds, paylines=data["settings"])
        excel_path = str(cfg.get("excel_path") or "")
        kw = engine_api._build_kwargs(cfg)
        dynamic_settings = _preview_dynamic_settings(cfg)
        effective = pl.settings_for(dynamic_settings, kw["c_width"])
        out = {"ok": True, "settings": effective, "defaults": pl.settings_for({}, kw["c_width"]),
               "sheets": [], "pages": [], "errors": [], "warnings": []}
        if not excel_path or not os.path.isfile(excel_path):
            out.update(ok=False, error="Excel workbook not set. Configure it in the Project view first.")
            return jsonify(out)
        try:
            wb = _borrow_wb(excel_path, data_only=True)
        except Exception as exc:
            out.update(ok=False, error=f"Cannot open workbook: {exc}")
            return jsonify(out)
        out["sheets"] = [n for n in wb.sheetnames if pl.is_payline_page(wb[n])]
        named = [n for n in wb.sheetnames if pl.is_payline_sheet(n) and n not in out["sheets"]]
        if named:
            out["warnings"].append("Sheet(s) named like paylines but with no payline table or line grids "
                                   "(built as normal pages): " + ", ".join(named))
        sheet = _raw_sheet(data.get("sheet_name")) or (out["sheets"][0] if out["sheets"] else "")
        if sheet not in out["sheets"]:
            out.update(ok=False, error="No payline sheet found — the tool looks for a table with a header "
                                       "row \"Line | Reel1 | Reel2 | …\", or numbered little reel grids with each "
                                       "line's cells marked (X, a colour…).")
            return jsonify(out)
        out["sheet_name"] = sheet
        ws = wb[sheet]
        try:
            parsed = pl.parse(ws, effective.get("rows", 3))
        except pl.PaylineError as exc:
            out.update(ok=False, error=str(exc))
            return jsonify(out)
        out["lines"] = len(parsed["lines"])
        out["reels"] = parsed["reels"]
        out["rows"] = parsed["rows"]
        out["form"] = parsed.get("form", "table")
        out["denoms"] = parsed["denoms"]
        out["errors"] = parsed["errors"]
        out["warnings"] += parsed["warnings"]
        out["pages"] = pl.page_list(parsed, effective) if not parsed["errors"] else []
        if parsed["errors"]:
            out.update(ok=False, error="The payline table has problems — fix them in the Excel:")
            return jsonify(out)

        Image, ImageDraw, ImageFont = png_builder._require_pillow()
        _ps_ov = png_builder._png_page_style_override(sheet, kw.get("page_overrides"))
        pg_h_font = str(_ps_ov.get("h_font") or kw["h_font"])
        pg_h_rgb = _ps_ov.get("h_rgb") or kw["h_rgb"]
        pg_h_size = png_builder._png_heading_size_for_sheet(sheet, dynamic_settings, kw["h_size"])
        try:
            index = max(0, min(len(out["pages"]) - 1, int(data.get("page") or 0)))
        except (TypeError, ValueError):
            index = 0
        shown = out["pages"][index]
        meta = {}
        try:
            pages, warnings = png_builder._render_paylines_png_pages(
                Image, ImageDraw, ImageFont, ws, sheet, kw["bg_path"], kw["bg_mode"], kw["bg_color"],
                kw["c_width"], kw["c_height"], pg_h_font, pg_h_size, kw["h_icon_h"], pg_h_rgb,
                kw["margin_x"], kw["heading_top_margin"], kw["line_spacing"],
                kw["icon_folder"], kw["icon_mappings"] or {}, kw["icon_size_overrides"] or {},
                dynamic_settings, kw["alignment_settings"] or {}, counts=[shown["count"]], meta=meta,
            )
        except pl.PaylineError as exc:
            out.update(ok=False, error=str(exc))
            return jsonify(out)
        except Exception as exc:
            out.update(ok=False, error=f"Preview render failed: {exc}")
            return jsonify(out)
        out["warnings"] = list(dict.fromkeys(out["warnings"] + list(warnings)))
        if not pages:
            out.update(ok=False, error="Renderer produced no page.")
            return jsonify(out)
        out["block"] = pl.block_box(shown["count"], effective, int(kw["c_width"]), int(kw["c_height"]),
                                    parsed["reels"], parsed["rows"])
        gw, gh = pl.grid_size(effective, parsed["reels"], parsed["rows"])
        cols = max(1, min(int(effective["columns"]), shown["count"]))
        # what the on-canvas handles and "Fit to page" need
        out["layout"] = {
            "count": shown["count"], "max_count": max(p["count"] for p in out["pages"]),
            "cols": cols, "nrows": -(-shown["count"] // cols), "grid_w": gw, "grid_h": gh,
            "heading_bottom": int(meta.get("heading_bottom") or 0), "margin_x": int(kw["margin_x"] or 0),
            "fit_warning": pl.layout(shown["count"], effective, int(kw["c_width"]), int(kw["c_height"]),
                                     parsed["reels"], parsed["rows"])[1],
        }
        out_dir = os.path.join(tempfile.gettempdir(), "psh_table_previews")
        os.makedirs(out_dir, exist_ok=True)
        preview_path = os.path.join(out_dir, f"{uuid.uuid4().hex}.png")
        pages[0][1].convert("RGB").save(preview_path, "PNG", compress_level=1)
        out.update(preview_token=_register_preview(preview_path), page=index,
                   canvas_width=int(kw["c_width"]), canvas_height=int(kw["c_height"]))
        return jsonify(out)

    @app.route("/api/bingo_rules/preview", methods=["POST"])
    def bingo_rules_preview():
        """Live PNG preview of the Bingo Rules sheet — same pure-Python renderer
        as the PNG build (no Photoshop needed)."""
        return _rules_preview("bingo_rules")

    @app.route("/api/paytable_mapper/duplicate", methods=["POST"])
    def paytable_mapper_duplicate():
        from . import ps_actions

        data = request.get_json(force=True, silent=True) or {}
        path = str(data.get("path") or "").strip()
        if not path or not os.path.isfile(path):
            return jsonify({"ok": False, "error": "JSON file not found."}), 400
        base, ext = os.path.splitext(path)
        dup_path = f"{base}_copy{ext or '.json'}"
        n = 2
        while os.path.exists(dup_path):
            dup_path = f"{base}_copy{n}{ext or '.json'}"
            n += 1
        try:
            with open(path, "r", encoding="utf-8") as f:
                document = json.load(f)
        except Exception as exc:
            return jsonify({"ok": False, "error": str(exc)}), 400
        document["template_id"] = f"{document.get('template_id') or 'paytable'}_copy"
        try:
            with open(dup_path, "w", encoding="utf-8") as f:
                json.dump(document, f, indent=2)
        except Exception as exc:
            return jsonify({"ok": False, "error": str(exc)}), 400
        try:
            payload = engine_api.load_paytable_mapper_session(dup_path)
        except Exception as exc:
            return jsonify({"ok": True, "path": dup_path})
        preview_path = os.path.join(tempfile.gettempdir(), "psh_table_previews", f"{uuid.uuid4().hex}.png")
        os.makedirs(os.path.dirname(preview_path), exist_ok=True)
        cfg = _config()
        settings = _preview_render_settings(cfg)
        rendered = ps_actions.render_table_outline_preview(
            payload["template"], preview_path,
            settings=settings,
            mappings=payload.get("mappings"),
            excel_path=str(cfg.get("excel_path") or ""),
            sheet_name=str(payload.get("sheet_name") or ""),
            icon_folder=str(cfg.get("icon_folder") or ""),
            icon_mappings=cfg.get("icon_mappings") or {},
            bg_path=str(cfg.get('bg_path') or ''),
            annotations=bool(data.get("annotations", True)),
        )
        token = _register_preview(rendered or preview_path) if os.path.isfile(preview_path) else ""
        return jsonify({"ok": True, "path": dup_path, "preview_token": token})

    return app


def _build_suggestions(excel: dict, icons: dict) -> list:
    out = []
    pages = excel.get("pages", [])
    paytables = excel.get("paytables", [])
    if pages:
        out.append(f"{len(pages)} pages detected in Excel — ready to render.")
    if paytables:
        out.append(f"{len(paytables)} paytable sheet(s) found — shared layouts will be applied automatically.")
    if excel.get("bingo_rules"):
        out.append("Bingo Rules sheet detected — legal text auto-adjustment available.")
    if excel.get("game_rules"):
        out.append("Game Rules sheet detected — will render with legal-safe margins.")
    if isinstance(icons, dict) and icons.get("ok"):
        missing = icons.get("missing") or []
        if missing:
            out.append(f"{len(missing)} missing icons: {', '.join(missing[:4])}{'…' if len(missing) > 4 else ''}")
        else:
            out.append(f"All {len(icons.get('tokens') or [])} icon tokens matched in the icon folder.")
    elif excel.get("ok"):
        out.append("Icon folder not set — set it in Project to auto-check missing icons.")
    return out


def find_free_port(preferred: int, max_tries: int = 10) -> int:
    """Return the first free port at or after ``preferred``.

    A stale server can otherwise silently shadow a fresh one: the new
    process would fail to bind and the app window would keep loading
    the old process instead. Warn loudly and pick a free port instead.
    """
    import socket

    for offset in range(max_tries):
        port = preferred + offset
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                sock.bind(("127.0.0.1", port))
            return port
        except OSError:
            if offset == 0:
                print(
                    f"[Port] Port {preferred} is already in use (stale server?). "
                    f"Starting on a free port instead."
                )
            continue
    raise RuntimeError(
        f"No free port found in range {preferred}-{preferred + max_tries - 1}. "
        f"Close whatever is holding port {preferred} and try again."
    )


def launch_web(port: int = 8750, open_browser: bool = True):
    app = create_app()
    actual_port = find_free_port(port)
    url = f"http://127.0.0.1:{actual_port}"
    if open_browser:
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    print(f"PsHelpScreenTool Web UI running at {url}  (Ctrl+C to stop)")
    app.run(host="127.0.0.1", port=actual_port, debug=False, use_reloader=False, threaded=True)


if __name__ == "__main__":
    launch_web()
