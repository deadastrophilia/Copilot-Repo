"""Ultra-fast page thumbnail renderer for the Project preview grid.

Deliberately simpler than the real PNG pipeline: draws the background, the
heading and wrapped body text with cached fonts and cheap metrics so a
1920x1080 preview renders in tens of milliseconds. Thumbnails are cached on
disk keyed to the workbook's path + mtime, so revisiting a project is
instant. The real pipeline (png_builder.build_pngs_only) is untouched and
still produces the actual output.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import tempfile
import threading
import uuid
from collections import OrderedDict
from functools import lru_cache

from openpyxl import load_workbook

from .. import png_builder, safe_json, workbook_cache

THUMB_ROOT = os.path.join(
    os.environ.get("TEMP") or os.path.expanduser("~"),
    "psh_page_thumbs",
)

_TOKEN_RE = re.compile(r"<[^>]{1,40}>")

# Config fields that change the rendered page. The cache key is derived from
# the workbook path + mtime AND these values, so switching backgrounds, canvas
# or fonts re-renders instead of serving a stale preview.
_CACHE_CONFIG_KEYS = (
    "bg_path", "bg_source", "bg_mode", "bg_color", "bg_anchor", "bg_rect",
    "c_width", "c_height", "c_resolution", "margin_x", "inner_canvas_width",
    "h_font", "h_size", "h_rgb", "h_icon_h", "heading_top_margin",
    "b_font", "b_size", "b_rgb", "b_icon_h", "heading_to_body_gap",
    "bottom_margin", "line_spacing", "para_spacing", "max_col_limit",
    "icon_folder", "icon_mappings", "icon_size_overrides",
    "page_overrides", "gap_px", "icon_y_offset", "line_gap",
    "alignment_settings", "dynamic_settings", "paytable_auto",
    "table_style", "output_name", "continued_gap", "table_alignment",
)


def _cache_dir(excel_path: str, cfg: dict = None) -> str:
    try:
        stamp = str(int(os.path.getmtime(excel_path)))
    except OSError:
        stamp = "0"
    # "framed2": previews made before notes outside the sheet's frame were dropped (one-column
    # frames included) are retired; "pages3": before every page (Continued ones too) was kept
    digest = hashlib.sha1(f"{os.path.abspath(excel_path)}@{stamp}@framed2@pages3".encode("utf-8"))
    if cfg:
        try:
            subset = {k: cfg.get(k) for k in _CACHE_CONFIG_KEYS}
            digest.update(json.dumps(subset, sort_keys=True, default=str).encode("utf-8"))
        except Exception:
            pass
    return os.path.join(THUMB_ROOT, digest.hexdigest()[:24])


def _thumbnail_path(excel_path: str, sheet_name: str, cfg: dict = None) -> str:
    return os.path.join(_cache_dir(excel_path, cfg), f"{png_builder._file_safe(sheet_name)}.png")


@lru_cache(maxsize=48)
def _heading_font(ImageFont, name, size):
    try:
        return png_builder._load_font(ImageFont, str(name or "ArialMT"), max(8, int(size)), bold=True)
    except Exception:
        return None


@lru_cache(maxsize=48)
def _body_font(ImageFont, name, size):
    try:
        return png_builder._load_font(ImageFont, str(name or "ArialMT"), max(8, int(size)), bold=False)
    except Exception:
        return None


def _strip_tokens(text: str) -> str:
    return _TOKEN_RE.sub("", str(text or "")).strip()


def _first_bg_image(bg_path: str) -> str:
    for fn in sorted(os.listdir(bg_path)):
        if fn.lower().startswith(("bg", "background")) and fn.lower().endswith(
            (".png", ".jpg", ".jpeg", ".bmp", ".gif")
        ):
            return os.path.join(bg_path, fn)
    for fn in sorted(os.listdir(bg_path)):
        if fn.lower().endswith((".png", ".jpg", ".jpeg", ".bmp")):
            return os.path.join(bg_path, fn)
    return ""


def _draw_background(page, Image, cfg):
    canvas_w, canvas_h = page.size
    if str(cfg.get("bg_source") or "image") == "color":
        rgb = png_builder._rgb(cfg.get("bg_color"), (255, 255, 255))
        page.paste(rgb, (0, 0, canvas_w, canvas_h))
        return
    bg_path = str(cfg.get("bg_path") or "")
    img_path = ""
    if bg_path and os.path.isdir(bg_path):
        img_path = _first_bg_image(bg_path)
    elif bg_path and os.path.isfile(bg_path):
        img_path = bg_path
    if not img_path or not os.path.isfile(img_path):
        rgb = png_builder._rgb(cfg.get("bg_color"), (0, 0, 0))
        page.paste(rgb, (0, 0, canvas_w, canvas_h))
        return
    try:                                     # placed like the build (cover / fit / fit width / a PSD's rectangle)
        from .. import bg_place

        tmp = Image.new("RGBA", page.size, (0, 0, 0, 0))
        png_builder._paint_background(tmp, Image, img_path, bg_place.spec(cfg), bg_place.behind(cfg))
        page.paste(tmp.convert(page.mode), (0, 0), tmp)    # its see-through parts keep the page under them
    except Exception:
        pass


def _wrap_words(draw, text, font, max_width):
    words = str(text).split()
    lines = []
    cur = ""
    for w in words:
        trial = f"{cur} {w}".strip()
        if cur and draw.textlength(trial, font=font) > max_width:
            lines.append(cur)
            cur = w
        else:
            cur = trial
    if cur:
        lines.append(cur)
    return lines


def render_sheet_thumbnail(excel_path: str, sheet_name: str, cfg: dict, dynamic_settings: dict = None):
    """Render one sheet's first page as a fast preview thumbnail.

    Returns {"ok": True, "path": png_path} (saved + disk-cached) or
    {"ok": False, "error": str}."""
    try:
        Image, ImageDraw, ImageFont = png_builder._require_pillow()
        canvas_w = max(320, int((cfg or {}).get("c_width") or 1920))
        canvas_h = max(320, int((cfg or {}).get("c_height") or 1080))
        margin_x = max(0, int((cfg or {}).get("margin_x") or 80))
        h_font_name = str((cfg or {}).get("h_font") or "ArialMT")
        h_size = max(12, min(220, int((cfg or {}).get("h_size") or 60)))
        h_rgb = png_builder._rgb((cfg or {}).get("h_rgb"), (255, 255, 255))
        b_font_name = str((cfg or {}).get("b_font") or "ArialMT")
        b_size = max(8, min(160, int((cfg or {}).get("b_size") or 30)))
        b_rgb = png_builder._rgb((cfg or {}).get("b_rgb"), (255, 255, 255))
        heading_top_margin = max(0, int((cfg or {}).get("heading_top_margin") or 150))
        heading_to_body_gap = max(0, int((cfg or {}).get("heading_to_body_gap") or 40))
        bottom_margin = max(0, int((cfg or {}).get("bottom_margin") or 80))
        line_spacing = float((cfg or {}).get("line_spacing") or 1.1)
        para_spacing = max(0, int((cfg or {}).get("para_spacing") or 14))
        max_col_limit = max(1, int((cfg or {}).get("max_col_limit") or 12))

        out_path = _thumbnail_path(excel_path, sheet_name, cfg)
        os.makedirs(os.path.dirname(out_path), exist_ok=True)

        wb = load_workbook(excel_path, data_only=True, read_only=True)
        try:
            if sheet_name not in wb.sheetnames:
                return {"ok": False, "error": f"Sheet not found: {sheet_name}"}
            ws = wb[sheet_name]
            page = Image.new("RGB", (canvas_w, canvas_h))
            _draw_background(page, Image, cfg)
            draw = ImageDraw.Draw(page)
            safe_left, safe_width = png_builder._inner_safe_box(canvas_w, canvas_h, margin_x)
            safe_bottom = max(heading_top_margin + 100, canvas_h - bottom_margin)

            page_min_row, page_max_row, page_min_col, page_max_col = png_builder._render_window_for_sheet(
                dynamic_settings or {}, sheet_name, max_col_limit, ws,
            )

            y = heading_top_margin
            heading_row, heading_text = png_builder._find_heading_row(
                ws, max_col_limit, min_row=page_min_row, max_row=min(page_max_row, page_min_row + 19),
            )
            if heading_row and heading_text:
                text = _strip_tokens(heading_text)
                if text:
                    font = _heading_font(ImageFont, h_font_name, h_size)
                    if font:
                        lines = _wrap_words(draw, text, font, max(200, safe_width - h_size))
                        for ln in lines:
                            x = safe_left + (safe_width - draw.textlength(ln, font=font)) / 2
                            draw.text((x, y), ln, font=font, fill=h_rgb)
                            y += int(draw.textlength("H", font=font) * 1.25)
                    y += heading_to_body_gap

            body_font = _body_font(ImageFont, b_font_name, b_size)
            line_h = int(b_size * line_spacing)
            if body_font:
                for row_idx in range(max(page_min_row, heading_row + 1), page_max_row + 1):
                    if y > safe_bottom:
                        break
                    row_text = png_builder._row_page_text(ws, row_idx, page_max_col, page_min_col)
                    if not row_text or _png_skip_helper(row_text):
                        continue
                    text = _strip_tokens(row_text)
                    if not text:
                        continue
                    for ln in _wrap_words(draw, text, body_font, safe_width):
                        if y > safe_bottom:
                            break
                        draw.text((safe_left, y), ln, font=body_font, fill=b_rgb)
                        y += line_h
                    y += para_spacing
        finally:
            wb.close()

        page.save(out_path, "PNG")
        return {"ok": True, "path": out_path, "pages": 1}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def _png_skip_helper(text: str) -> bool:
    t = str(text or "").strip().lower()
    return bool(t) and (t.startswith("<mod") or not t)


def _full_thumbnail_path(excel_path: str, sheet_name: str, cfg: dict = None) -> str:
    return os.path.join(_cache_dir(excel_path, cfg), f"full_{png_builder._file_safe(sheet_name)}.png")


def page_path(first_page_path: str, page: int) -> str:
    """Page N of a sheet's full preview beside page 1 (its Continued pages: __p2, __p3 …)."""
    return first_page_path if int(page) <= 1 else first_page_path[:-4] + f"__p{int(page)}.png"


def _pages_meta(first_page_path: str) -> str:
    return first_page_path[:-4] + ".pages.json"


def _save_page_count(first_page_path: str, count: int) -> None:
    try:
        with open(_pages_meta(first_page_path), "w", encoding="utf-8") as fh:
            json.dump({"pages": int(count)}, fh)
    except OSError:
        pass


def cached_page_count(first_page_path: str) -> int:
    """How many pages the cached preview has (1 when it was made before pages were kept)."""
    try:
        with open(_pages_meta(first_page_path), encoding="utf-8") as fh:
            return max(1, int(json.load(fh).get("pages") or 1))
    except (OSError, ValueError, TypeError):
        return 1


def _page_order(name: str):
    """The build's file names in page order: 'Sheet.png', 'Sheet_Continued_1.png', … _Continued_10."""
    m = re.search(r"_Continued_(\d+)\.png$", name, re.IGNORECASE)
    return (1, int(m.group(1))) if m else (0, 0)


def _render_full_preview(excel_path: str, sheet_name: str, cfg: dict, out_path: str) -> dict:
    """Render sheet page 1 with the REAL pipeline, byte-identical to the final
    PNG build (the same renderers the Game/Bingo Rules studios use live).

    Game/Bingo Rules sheets render through `_render_game_rules_png_pages` /
    `_render_bingo_rules_png_pages`; every other sheet renders through
    `png_builder.build_pngs_only` (first page only)."""
    from . import engine_api

    kind = png_builder._normalized_sheet_kind(sheet_name)
    if engine_api._sheet_type(sheet_name) == "paytable":
        # lay the paytable out exactly as the build does (card template / auto layout);
        # without it the page came out as plain text rows
        try:
            cfg = engine_api._with_auto_paytables(dict(cfg, selected_sheets=[sheet_name], render_all_pages=False))
        except Exception:
            pass
    kw = engine_api._build_kwargs(cfg)
    _loan = workbook_cache.borrow(excel_path)          # parsed once per Excel version, reused
    wb = _loan.__enter__()
    try:
        if sheet_name not in wb.sheetnames:
            return {"ok": False, "error": f"Sheet not found: {sheet_name}"}
        if kind in ("game_rules", "bingo_rules"):
            ws = wb[sheet_name]
            Image, ImageDraw, ImageFont = png_builder._require_pillow()
            dynamic_settings = dict(cfg.get("dynamic_settings") or {})
            alignment_settings = kw["alignment_settings"] or {}
            _ps_ov = png_builder._png_page_style_override(sheet_name, kw.get("page_overrides"))
            pg_h_font = str(_ps_ov.get("h_font") or kw["h_font"])
            pg_h_rgb = _ps_ov.get("h_rgb") or kw["h_rgb"]
            pg_b_font = str(_ps_ov.get("b_font") or kw["b_font"])
            pg_b_rgb = _ps_ov.get("b_rgb") or kw["b_rgb"]
            pg_h_size = kw["h_size"]
            if _ps_ov.get("h_size") is not None:
                try:
                    pg_h_size = max(8, int(float(_ps_ov.get("h_size") or kw["h_size"])))
                except Exception:
                    pg_h_size = kw["h_size"]
            pg_b_size = kw["b_size"]
            if _ps_ov.get("b_size") is not None:
                try:
                    pg_b_size = max(8, int(float(_ps_ov.get("b_size") or kw["b_size"])))
                except Exception:
                    pg_b_size = kw["b_size"]
            heading_size = png_builder._png_heading_size_for_sheet(sheet_name, dynamic_settings, pg_h_size)
            page_min_row, page_max_row, page_min_col, page_max_col = png_builder._render_window_for_sheet(
                dynamic_settings, sheet_name, kw["max_col_limit"], ws,
            )
            if kind == "game_rules":
                pages = png_builder._render_game_rules_png_pages(
                    Image, ImageDraw, ImageFont, ws, sheet_name,
                    kw["bg_path"], kw["bg_mode"], kw["bg_color"],
                    kw["c_width"], kw["c_height"],
                    pg_h_font, heading_size, kw["h_icon_h"], pg_h_rgb,
                    pg_b_font, pg_b_size, kw["b_icon_h"], pg_b_rgb,
                    kw["margin_x"], kw["heading_top_margin"], kw["heading_to_body_gap"],
                    kw["bottom_margin"], kw["line_spacing"], kw["para_spacing"],
                    kw["icon_folder"], kw["icon_mappings"] or {}, kw["icon_size_overrides"] or {},
                    dynamic_settings, alignment_settings,
                    page_min_col=page_min_col, page_max_col=page_max_col,
                    page_min_row=page_min_row, page_max_row=page_max_row,
                )
            else:
                pages = png_builder._render_bingo_rules_png_pages(
                    Image, ImageDraw, ImageFont, ws, sheet_name,
                    kw["bg_path"], kw["bg_mode"], kw["bg_color"],
                    kw["c_width"], kw["c_height"],
                    pg_h_font, heading_size, kw["h_icon_h"], pg_h_rgb,
                    pg_b_font, pg_b_size, kw["b_icon_h"], pg_b_rgb,
                    kw["margin_x"], kw["heading_top_margin"], kw["heading_to_body_gap"],
                    kw["bottom_margin"], kw["line_spacing"], kw["para_spacing"],
                    kw["icon_folder"], kw["icon_mappings"] or {}, kw["icon_size_overrides"] or {},
                    dynamic_settings, alignment_settings,
                    page_min_col=page_min_col, page_max_col=page_max_col,
                    page_min_row=page_min_row, page_max_row=page_max_row,
                )
            if not pages:
                return {"ok": False, "error": "Renderer produced no pages."}
            os.makedirs(os.path.dirname(out_path), exist_ok=True)
            for i, page in enumerate(pages, start=1):          # every page: the Continued ones too
                page.save(page_path(out_path, i), "PNG")
            _save_page_count(out_path, len(pages))
            return {"ok": True, "pages": len(pages)}
        else:
            # hand the workbook back first: the build borrows the same cached copy
            # (still holding it would make the build parse the Excel again)
            _loan.__exit__(None, None, None)
            _loan = None
            out_dir = os.path.join(tempfile.gettempdir(), f"psh_full_preview_{uuid.uuid4().hex}")
            os.makedirs(out_dir, exist_ok=True)
            try:
                full_kw = dict(kw)
                for _clash in ("output_dir", "output_format", "selected_sheets", "performance_mode"):
                    full_kw.pop(_clash, None)
                png_builder.build_pngs_only(
                    **full_kw,
                    output_dir=out_dir,
                    output_format="png",
                    selected_sheets=[sheet_name],
                    performance_mode=True,
                )
                found = []
                for root, _dirs, files in os.walk(out_dir):
                    found.extend(os.path.join(root, fn) for fn in files if fn.lower().endswith(".png"))
                if not found:
                    return {"ok": False, "error": "PNG pipeline produced no pages."}
                found.sort(key=lambda f: _page_order(os.path.basename(f)))
                os.makedirs(os.path.dirname(out_path), exist_ok=True)
                for i, f in enumerate(found, start=1):           # page 1, then its Continued pages
                    shutil.copyfile(f, page_path(out_path, i))
                _save_page_count(out_path, len(found))
                return {"ok": True, "pages": len(found)}
            finally:
                shutil.rmtree(out_dir, ignore_errors=True)
    finally:
        if _loan is not None:
            _loan.__exit__(None, None, None)


def render_sheet_preview(excel_path: str, sheet_name: str, cfg: dict) -> dict:
    """Full-fidelity page-1 preview for any sheet kind, disk-cached.

    Game/Bingo Rules sheets use the exact studio renderers, other sheets the
    real PNG pipeline — so the grid thumbnail shows what the final build
    produces. Re-renders are served straight from the disk cache (keyed to
    the workbook's path + mtime). If the full render fails, we fall back to
    the fast thumbnail renderer so the grid never empties.

    Returns {"ok": True, "path": str, "pages": int, "cached": bool,
             "source": "full"|"fast"} or {"ok": False, "error": str}."""
    cached = _full_thumbnail_path(excel_path, sheet_name, cfg)
    if os.path.isfile(cached):
        return {"ok": True, "path": cached, "pages": cached_page_count(cached), "cached": True, "source": "full"}
    # one render at a time: the rail asks for every sheet at once, and parallel renders in one
    # Python process only slowed each other (and the page being edited) down
    with _RENDER_LOCK:
        if os.path.isfile(cached):                     # rendered while we waited (pages_count + thumb)
            return {"ok": True, "path": cached, "pages": cached_page_count(cached), "cached": True, "source": "full"}
        try:
            result = _render_full_preview(excel_path, sheet_name, cfg, cached)
        except Exception as exc:
            result = {"ok": False, "error": str(exc)}
    if result.get("ok") and os.path.isfile(cached):
        result["path"] = cached
        result["cached"] = False
        result["source"] = "full"
        _remember_latest(excel_path, sheet_name, cached)
        return result
    fallback = render_sheet_thumbnail(excel_path, sheet_name, cfg)
    if fallback.get("ok") and fallback.get("path") and os.path.isfile(fallback["path"]):
        try:
            os.makedirs(os.path.dirname(cached), exist_ok=True)
            shutil.copyfile(fallback["path"], cached)
            fallback["path"] = cached
        except OSError:
            pass
        fallback["cached"] = False
        fallback["source"] = "fast"
        return fallback
    return {
        "ok": False,
        "error": result.get("error") or fallback.get("error") or "render failed",
    }



# ── show the last picture at once, draw the new one in the background ──────────
# A thumbnail's cache key holds the whole page config, so any edit retires every
# sheet's picture. Rather than make the rail wait for a full re-render of each
# sheet, the previous picture of that sheet is served straight away (marked stale)
# and one background worker draws the up-to-date one; the rail polls
# /api/pages_fresh and swaps it in.
_RENDER_LOCK = threading.Lock()
_LATEST = {"map": None}
_LATEST_LOCK = threading.Lock()
_QUEUE = OrderedDict()                     # cache path -> (excel, sheet, cfg); newest asked first
_QUEUE_LOCK = threading.Condition()
_WORKER = {"thread": None}


def _latest_file() -> str:
    return os.path.join(THUMB_ROOT, "latest.json")


def _latest_key(excel_path: str, sheet_name: str) -> str:
    return os.path.normcase(os.path.abspath(str(excel_path))) + "|" + str(sheet_name)


def _latest_map() -> dict:
    if _LATEST["map"] is None or _LATEST.get("root") != THUMB_ROOT:
        try:
            data = safe_json.read_json(_latest_file())
        except Exception:
            data = {}
        _LATEST.update(map=data if isinstance(data, dict) else {}, root=THUMB_ROOT)
    return _LATEST["map"]


def _remember_latest(excel_path: str, sheet_name: str, path: str) -> None:
    with _LATEST_LOCK:
        latest = _latest_map()
        latest[_latest_key(excel_path, sheet_name)] = path
        try:
            safe_json.write_json(_latest_file(), latest)
        except Exception:
            pass


def latest_preview(excel_path: str, sheet_name: str) -> str:
    """The last full preview drawn for this sheet of this workbook (any settings), or ""."""
    with _LATEST_LOCK:
        path = _latest_map().get(_latest_key(excel_path, sheet_name)) or ""
    return path if path and os.path.isfile(path) else ""


def is_fresh(excel_path: str, sheet_name: str, cfg: dict) -> bool:
    return os.path.isfile(_full_thumbnail_path(excel_path, sheet_name, cfg))


def _worker_loop() -> None:
    while True:
        with _QUEUE_LOCK:
            while not _QUEUE:
                _QUEUE_LOCK.wait()
            _key, job = _QUEUE.popitem(last=True)
        try:
            render_sheet_preview(*job)
        except Exception as exc:
            print(f"[page_thumbs] background preview failed for {job[1]!r}: {exc}")


def request_refresh(excel_path: str, sheet_name: str, cfg: dict) -> None:
    """Queue an up-to-date preview of this sheet (newest requests are drawn first)."""
    key = _full_thumbnail_path(excel_path, sheet_name, cfg)
    with _QUEUE_LOCK:
        _QUEUE.pop(key, None)
        _QUEUE[key] = (excel_path, sheet_name, json.loads(json.dumps(cfg, default=str)))
        if _WORKER["thread"] is None or not _WORKER["thread"].is_alive():
            _WORKER["thread"] = threading.Thread(target=_worker_loop, name="page-thumbs", daemon=True)
            _WORKER["thread"].start()
        _QUEUE_LOCK.notify()


def preview_or_stale(excel_path: str, sheet_name: str, cfg: dict) -> dict:
    """render_sheet_preview, but never waits when an older picture of the sheet exists.

    Returns its result, with "stale": True when the older picture was served and the
    new one is being drawn in the background."""
    cached = _full_thumbnail_path(excel_path, sheet_name, cfg)
    if os.path.isfile(cached):
        if latest_preview(excel_path, sheet_name) != cached:   # drawn before this was recorded
            _remember_latest(excel_path, sheet_name, cached)
        return {"ok": True, "path": cached, "pages": cached_page_count(cached), "cached": True,
                "source": "full", "stale": False}
    old = latest_preview(excel_path, sheet_name)
    if old:
        request_refresh(excel_path, sheet_name, cfg)
        return {"ok": True, "path": old, "pages": cached_page_count(old), "cached": True,
                "source": "full", "stale": True}
    result = render_sheet_preview(excel_path, sheet_name, cfg)    # never drawn before: wait for it
    result["stale"] = False
    return result
