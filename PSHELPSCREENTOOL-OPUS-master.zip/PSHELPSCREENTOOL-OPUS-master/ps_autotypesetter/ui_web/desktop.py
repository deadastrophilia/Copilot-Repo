"""CLI entry: python -m ps_autotypesetter.ui_web.desktop  (native window)"""

from .window import launch_desktop

if __name__ == "__main__":
    launch_desktop()
