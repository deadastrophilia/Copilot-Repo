"""Native Windows file dialogs for the local web UI (no tkinter dependency)."""

import ctypes
import os
from ctypes import wintypes

_GET_SAVE_FILE_NAME_W = None


class _OPENFILENAME(ctypes.Structure):
    _fields_ = [
        ("lStructSize", wintypes.DWORD),
        ("hwndOwner", wintypes.HWND),
        ("hInstance", wintypes.HINSTANCE),
        ("lpstrFilter", wintypes.LPCWSTR),
        ("lpstrCustomFilter", wintypes.LPWSTR),
        ("nMaxCustFilter", wintypes.DWORD),
        ("nFilterIndex", wintypes.DWORD),
        ("lpstrFile", wintypes.LPWSTR),
        ("nMaxFile", wintypes.DWORD),
        ("lpstrFileTitle", wintypes.LPWSTR),
        ("nMaxFileTitle", wintypes.DWORD),
        ("lpstrInitialDir", wintypes.LPCWSTR),
        ("lpstrTitle", wintypes.LPCWSTR),
        ("Flags", wintypes.DWORD),
        ("nFileOffset", wintypes.WORD),
        ("nFileExtension", wintypes.WORD),
        ("lpstrDefExt", wintypes.LPCWSTR),
        ("lCustData", wintypes.LPARAM),
        ("lpfnHook", ctypes.c_void_p),
        ("lpTemplateName", wintypes.LPCWSTR),
        ("pvReserved", ctypes.c_void_p),
        ("dwReserved", wintypes.DWORD),
        ("FlagsEx", wintypes.DWORD),
    ]


def _ask_save_path_tk(title, initial_dir, default_name):
    """Fallback native dialog via tkinter (same dialog the old desktop UI used)."""
    try:
        import tkinter as tk
        from tkinter import filedialog

        root = tk.Tk()
        root.withdraw()
        try:
            root.attributes("-topmost", True)
        except Exception:
            pass
        try:
            path = filedialog.asksaveasfilename(
                parent=root,
                title=title,
                initialdir=initial_dir or None,
                initialfile=default_name or "file.json",
                defaultextension=".json",
                filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
            )
        finally:
            try:
                root.destroy()
            except Exception:
                pass
        return os.path.abspath(path) if path else ""
    except Exception:
        return None


def ask_save_path(title="Save file", initial_dir="", default_name="file.json"):
    """Show the native Windows 'Save As' dialog.

    Returns (path, error_code). path is "" if the dialog did not produce a
    file; error_code is non-zero only when every dialog attempt failed to
    open (0 = the user simply cancelled).
    """
    global _GET_SAVE_FILE_NAME_W
    if os.name != "nt":
        return "", 0
    try:
        if _GET_SAVE_FILE_NAME_W is None:
            _GET_SAVE_FILE_NAME_W = ctypes.windll.comdlg32.GetSaveFileNameW
        buf = ctypes.create_unicode_buffer(32768)
        default_path = default_name
        if initial_dir:
            default_path = os.path.join(initial_dir, default_name)
        buf.value = default_path
        ofn = _OPENFILENAME()
        ofn.lStructSize = ctypes.sizeof(_OPENFILENAME)
        ofn.lpstrFilter = "JSON files\0*.json\0All files\0*.*\0"
        ofn.lpstrFile = buf
        ofn.nMaxFile = 32768
        ofn.lpstrInitialDir = initial_dir or None
        ofn.lpstrTitle = title
        ofn.lpstrDefExt = "json"
        # OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR
        ofn.Flags = 0x00000002 | 0x00000800 | 0x00000008
        if _GET_SAVE_FILE_NAME_W(ctypes.byref(ofn)):
            return os.path.abspath(buf.value), 0
        try:
            error_code = int(ctypes.windll.comdlg32.CommDlgExtendedError())
        except Exception:
            error_code = 0
        if not error_code:
            return "", 0
        tk_path = _ask_save_path_tk(title, initial_dir, default_name)
        if tk_path:
            return tk_path, 0
        if tk_path == "":
            return "", 0
        return "", error_code
    except Exception:
        try:
            import traceback
            traceback.print_exc()
        except Exception:
            pass
        return "", -1
