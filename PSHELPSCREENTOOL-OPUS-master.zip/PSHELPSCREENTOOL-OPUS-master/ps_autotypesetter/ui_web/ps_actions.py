"""Web UI backend actions: Photoshop-live features and exports.

All Photoshop calls are lazy-imported and return serializable dicts.
These run synchronously (quick COM calls); long operations (batch export)
are dispatched through the job manager.
"""

from __future__ import annotations

import os
import re
import tempfile
import uuid


def _photoshop_available() -> bool:
    try:
        import photoshop.api  # noqa: F401
        return True
    except Exception:
        return False


def ensure_com_initialized():
    """Initialise COM on the calling thread.

    ``photoshop.api`` (comtypes) initialises COM on the thread that imports
    it first — usually the server's main thread. Flask job workers and the
    status-probe thread then fail to create the Photoshop COM object with a
    swallowed OSError ("Invalid class string"), which surfaces as the
    misleading "Please check if you have Photoshop installed correctly."
    Calling CoInitialize() on every worker thread fixes the connection.
    """
    try:
        from comtypes import CoInitialize
        CoInitialize()
        return
    except Exception:
        pass
    try:
        import pythoncom
        pythoncom.CoInitialize()
    except Exception:
        pass


def is_photoshop_running() -> bool:
    """Return True only if Photoshop is ALREADY running.

    ``photoshop.api``'s ``Application()`` silently LAUNCHES Photoshop when it
    is not running, so any passive probe (status dot, font list) must check the
    process list first — the tool should never open Photoshop on its own.
    """
    if os.name != "nt":
        return True
    try:
        import subprocess

        out = subprocess.run(
            ["tasklist", "/FI", "IMAGENAME eq Photoshop.exe", "/NH"],
            capture_output=True, text=True, timeout=4,
        )
        return "Photoshop.exe" in (out.stdout or "")
    except Exception:
        return True


def scan_table_template(psd_path: str = "", slot_prefix: str = "@table") -> dict:
    """Scan a PSD for @table.* (or @slot.*) slots and rasterize an outline preview PNG."""
    if not psd_path or not os.path.isfile(psd_path):
        return {"ok": False, "error": "PSD file not found."}
    if not _photoshop_available():
        return {"ok": False, "error": "photoshop.api is not installed."}
    from ps_autotypesetter.custom_layout_exporter import export_table_slots_json

    preview_dir = os.path.join(tempfile.gettempdir(), "psh_table_previews")
    os.makedirs(preview_dir, exist_ok=True)
    preview_path = os.path.join(preview_dir, f"{uuid.uuid4().hex}.png")
    try:
        template = export_table_slots_json(psd_path, preview_path="", slot_prefix=slot_prefix)
        render_table_outline_preview(template, preview_path)
        return {
            "ok": True,
            "template": template,
            "preview_path": preview_path if os.path.isfile(preview_path) else "",
            "preview_saved": bool(os.path.isfile(preview_path)),
        }
    except Exception as e:
        return {"ok": False, "error": f"Scan failed: {e}"}


def _hex_to_rgb(value):
    if isinstance(value, (list, tuple)) and len(value) >= 3:
        try:
            return tuple(int(float(v)) for v in value[:3])
        except Exception:
            return (255, 255, 255)
    s = str(value or "").lstrip("#")
    if len(s) == 6:
        try:
            return tuple(int(s[i : i + 2], 16) for i in (0, 2, 4))
        except Exception:
            pass
    return (255, 255, 255)


def _load_font(size: int, bold: bool = False):
    from PIL import ImageFont

    names = ["arialbd.ttf", "arial.ttf"] if bold else ["arial.ttf"]
    if not bold:
        names.insert(0, "arial.ttf")
    for n in names:
        try:
            return ImageFont.truetype(n, size)
        except Exception:
            continue
    return ImageFont.load_default()


def _truncate_label(label: str, font, max_w: int):
    label = str(label)
    if max_w <= 8:
        return label[:6] + "…" if len(label) > 6 else label
    text = label
    while text and font.getbbox(text)[2] > max_w and len(text) > 1:
        text = text[:-1]
    if text != label:
        text = text[:-1] + "…"
    return text


def _wrap_preview_text(text: str, font, max_w: int):
    out = []
    current = ""
    for word in str(text or "").split(" "):
        candidate = word if not current else current + " " + word
        if font.getbbox(candidate)[2] <= max_w:
            current = candidate
        else:
            if current:
                line = current.strip()
                if line:
                    out.append(line)
            current = word.strip()
    if current:
        line = current.strip()
        if line:
            out.append(line)
    return out or [""]


_INLINE_TOKEN_RE = re.compile(r"(<[^<>]+>)")


def _preview_icon_metrics(token, icon_h, icon_folder, icon_mappings):
    """Resolve <token> to (loaded RGBA image, display width) at icon height."""
    token = str(token or "").strip(" .;,-!")
    if not token or icon_h <= 0:
        return None
    try:
        from ps_autotypesetter.icon_mapping import resolve_icon_path

        path = resolve_icon_path(token, icon_folder or "", icon_mappings or {})
    except Exception:
        path = None
    if not path or not os.path.isfile(path):
        return None
    try:
        from PIL import Image

        img = Image.open(path).convert("RGBA")
        ratio = img.width / max(1.0, float(img.height))
        return {
            "token": token,
            "path": path,
            "img": img,
            "h": icon_h,
            "w": max(1, int(round(icon_h * ratio))),
        }
    except Exception:
        return None


def icon_height_for(scales, token, icon_h, nth=None):
    """An inline <token>'s height: its own px ("40px") when it has one, else icon_h × its percent.
    nth: which copy of the token in its text it is (0 = the first) — "TOKEN#1" sizes only the second."""
    if scales:
        key = str(token or "").strip("<> .;,-!").upper()
        norm = {str(k).strip("<> ").upper(): v for k, v in scales.items()}
        one = norm.get(f"{key}#{nth}") if nth is not None else None
        if one is not None:                                                     # this copy only
            return icon_height_for({key: one}, token, icon_h)
        v = norm.get(key, norm.get("*"))
        if isinstance(v, str) and v.strip().lower().endswith("px"):
            try:
                return max(4, int(round(float(v.strip()[:-2]))))
            except ValueError:
                pass
    return max(4, int(round(icon_h * icon_scale_for(scales, token))))


def icon_scale_for(scales, token):
    """The size factor for an inline <token> (scales: {"WILD": 140} in percent, by icon name)."""
    if not scales:
        return 1.0
    key = str(token or "").strip("<> .;,-!").upper()
    norm = {str(k).strip("<> ").upper(): v for k, v in scales.items()}
    v = norm.get(key, norm.get("*"))                    # "*": every icon in the text, unless it has its own size
    try:
        return max(0.2, min(4.0, float(v) / 100.0)) if v is not None and not str(v).strip().lower().endswith("px") else 1.0
    except (TypeError, ValueError):
        return 1.0


def _wrap_preview_inline(content, font, max_w, icon_h, icon_folder, icon_mappings, icon_scales=None, keep_blank=False):
    """Word-wrap preview text keeping <icon tokens> unbreakable.

    Newlines in the content become hard line breaks (pay/value ranges render
    one Excel row per line). keep_blank: two breaks in a row leave an empty
    line, as typed (card-studio text boxes). Returns a list of lines; each line is a list of
    items: {"type": "text", "val": word, "w": px} or
    {"type": "icon", "w": px, "img": image}.
    """
    max_w = max(8, int(max_w))
    from ps_autotypesetter import png_builder as _png

    space_w = max(1.0, _png._advance(font, " "))
    icon_h = max(4, int(icon_h or 0))
    gap = max(2, icon_h // 10)
    items = []
    seen = {}                                          # copies of each token so far ("TOKEN#n": one copy's size)
    for part in _INLINE_TOKEN_RE.split(str(content or "")):
        if not part:
            continue
        if _INLINE_TOKEN_RE.fullmatch(part):
            k = part.strip("<> .;,-!").upper()
            nth = seen[k] = seen.get(k, -1) + 1
            ih = icon_height_for(icon_scales, part, icon_h, nth)                  # this icon's own size (px or %)
            metric = _preview_icon_metrics(part[1:-1], ih, icon_folder, icon_mappings)
            if metric:
                items.append({"type": "icon", "val": metric["token"], "w": metric["w"], "img": metric["img"], "h": ih})
            else:
                # no picture for it: show the token itself, so nothing silently goes missing
                # (a long "<BUFFALO BG SCATTER>" wraps at its spaces like words)
                tw = _png._advance(font, part)
                for word in (part.split(" ") if tw > max_w else [part]):
                    if word:
                        items.append({"type": "text", "val": word, "w": _png._advance(font, word)})
            continue
        chunks = str(part).split("\n")
        for chunk_index, chunk in enumerate(chunks):
            for word in chunk.split(" "):
                word = word.strip()
                if not word:
                    continue
                # Photoshop's width of the word. Never cut it to "…": Excel's text (a pay of 1500)
                # always prints in full — a word wider than its box shrinks with the font, or overflows
                w = _png._advance(font, word)
                items.append({"type": "text", "val": word, "w": w})
            if chunk_index < len(chunks) - 1:
                items.append({"type": "break"})
    lines = []
    current = []
    current_w = 0
    prev_break = False
    for item in items:
        if item["type"] == "break":
            if current:
                lines.append(current)
                current = []
                current_w = 0
            elif keep_blank and prev_break and lines:
                lines.append([])                       # an empty line the user typed
            prev_break = True
            continue
        prev_break = False
        sep = gap if item["type"] == "icon" else space_w
        if current and current_w + sep + item["w"] > max_w:
            lines.append(current)
            current = []
            current_w = 0
            sep = 0
        if current:
            current_w += sep
        current.append(item)
        current_w += item["w"]
    if current:
        lines.append(current)
    return lines or [[]]


def _draw_preview_inline_line(draw, overlay, items, x, y, box_w, fcol, font, line_h, icon_h, align="center", fx_config=None,
                              icons_out=None):
    """Draw one wrapped preview line, embedding icons inline.

    Text and icons share the SAME vertical center of the line box (icons at
    (line_h - icon_h) / 2, text bbox-centered) exactly like the normal-text
    renderers (png_builder._draw_inline / the PSD inline flow), so icons sit
    on their text lines the usual way instead of drifting to the box top.
    """
    if not items:
        return
    from PIL import Image
    from ps_autotypesetter.psd_writer import recorder as _psd

    # PSD build: inside a slot's text block the line is recorded, not painted.
    _rec = _psd.active_recorder()
    _block = _rec.current_block(overlay) if _rec is not None else None
    _page = _psd.page_for(overlay) if _block is not None else None
    _line = _psd.TextLine() if _block is not None else None
    _label, _group = (_rec.slot or (_block.name, _block.group)) if _block is not None else ("", None)

    from ps_autotypesetter import png_builder as _png

    space_w = max(1.0, _png._advance(font, " "))
    icon_h = max(4, int(icon_h or 0))
    gap = max(2, icon_h // 10)
    total = 0
    for i, it in enumerate(items):
        total += it["w"]
        if i < len(items) - 1:
            total += gap if it["type"] == "icon" else space_w
    if align == "left":
        cx = x
    elif align == "right":
        cx = x + max(0, box_w - total)
    else:
        cx = x + max(0, (box_w - total) // 2)
    # styled text (a layer style) is drawn a run of words at a time, like one Photoshop text layer:
    # word by word, each word's stroke / glow would paint over the end of the word before it
    run = {"x": None, "words": []}

    def flush_run():
        if run["words"]:
            _png._draw_text_visual(draw, int(run["x"]), int(y), " ".join(run["words"]), font, fcol, line_h,
                                   base=overlay, fx_config=fx_config)
        run["x"], run["words"] = None, []

    for i, it in enumerate(items):
        if it["type"] == "icon":
            if fx_config and _line is None:
                flush_run()
            ih = int(it.get("h") or min(icon_h, it["img"].height))
            iw = max(1, int(round(ih * it["img"].width / max(1.0, float(it["img"].height)))))
            try:
                resized = it["img"].resize((iw, ih), Image.LANCZOS)
            except Exception:
                resized = it["img"]
            iy = y + max(0, (line_h - ih) // 2)
            if icons_out is not None:              # where this icon landed: the studio's per-icon handles
                icons_out.append({"tok": it.get("val"), "rect": [int(cx), int(iy), int(cx) + iw, int(iy) + ih]})
            if _line is not None:
                _page.icons.append(_psd.ImageRecord(resized, int(cx), int(iy), f"{_label} icon", group=_group))
                _line.gaps.append((cx, cx + it["w"]))
            else:
                overlay.paste(resized, (int(cx), int(iy)), resized)
        else:
            box = font.getbbox(it["val"])
            text_h = max(0, box[3] - box[1])
            text_x = int(cx) - box[0]
            text_y = int(y + max(0, (line_h - text_h) // 2)) - box[1]
            if _line is not None:
                if _line.baseline is None:
                    _line.baseline = text_y + font.getmetrics()[0]
                _line.runs.append(_psd.TextRun(it["val"], fcol, text_x, _png._advance(font, it["val"])))
            else:
                if fx_config:                     # the text box's layer style (PNG / preview): collected, drawn per run
                    if run["x"] is None:
                        run["x"] = cx
                    run["words"].append(it["val"])
                else:
                    _png._ps_draw(draw, overlay, text_x, text_y + font.getmetrics()[0], it["val"], font, fcol)
        cx += it["w"]
        if i < len(items) - 1:
            cx += gap if it["type"] == "icon" else space_w
    if fx_config and _line is None:
        flush_run()
    if _line is not None and _line.runs:
        _block.lines.append(_line)
    return (x + max(0, box_w - total) if align == "right" else x if align == "left" else x + max(0, (box_w - total) // 2)), total


def _mapping_dict(mappings):
    """Normalize a mapping list (web mapper) or dict (paytable) to slot->spec."""
    if isinstance(mappings, dict):
        return dict(mappings)
    out = {}
    for m in mappings or []:
        if isinstance(m, dict) and m.get("slot"):
            out[str(m["slot"])] = m
    return out


def _mapping_preview_text(mapping, worksheet):
    """Resolve the text a mapped slot will render (explicit text or Excel cell).

    ``mode == "text"`` strips <icon tokens> so only plain text renders
    (unless the mapping asks for ``inline_icons``: card-studio text boxes hold
    Excel text whose icons must draw); every other mode keeps tokens so the
    inline renderer can draw icons.
    """
    mode = str((mapping or {}).get("mode") or "excel").casefold()
    source = str((mapping or {}).get("source") or "").strip()
    text = ""
    if mode in {"excel", "excel_text"} and source and worksheet is not None:
        # Worksheet-first (mirrors the PSD renderer): a template JSON shared
        # by several paytable tabs must show each tab's own sheet data, so
        # never trust the stored resolved text when the live sheet is here.
        try:
            from ps_autotypesetter.table_mapping import resolve_paytable_source_text

            text = str(resolve_paytable_source_text(worksheet, source) or "").strip()
        except Exception:
            text = ""
    if not text:
        text = str((mapping or {}).get("text") or "").strip()
        if not text and mode in {"literal", "text", "mixed"}:
            text = source
    if mode in {"text", "excel_text"} and not (mapping or {}).get("inline_icons"):
        import re

        text = re.sub(r"[ \t]+", " ", re.sub(r"<[^<>]+>", "", text)).strip()
    return text


def resolve_mapped_slot_icons(mappings: dict, excel_path: str, sheet_name: str, icon_folder: str = "", icon_mappings: dict = None) -> dict:
    """Resolve the icon file per mapped 'icon'/'dedicated_icon' slot.

    Returns {slot_name: {"token": ..., "file": ...}} for slots whose token
    resolves to an existing icon file in the icon folder.
    """
    icons = {}
    try:
        from ps_autotypesetter.table_mapping import resolve_table_token
        from ps_autotypesetter.icon_mapping import resolve_icon_path
    except Exception:
        return icons
    worksheet = None
    workbook = None
    if excel_path and os.path.isfile(excel_path) and sheet_name:
        try:
            from openpyxl import load_workbook

            workbook = load_workbook(excel_path, data_only=True, read_only=True)
            if sheet_name in workbook.sheetnames:
                worksheet = workbook[sheet_name]
            else:
                workbook.close()
                workbook = None
        except Exception:
            workbook = None
    if worksheet is None:
        return icons
    try:
        for slot_name, mapping in (mappings or {}).items():
            if not isinstance(mapping, dict):
                continue
            kind = str(mapping.get("kind") or "").casefold()
            if kind not in {"icon", "dedicated_icon"}:
                continue
            token = str(mapping.get("token") or "").strip()
            if not token:
                source = str(mapping.get("source") or "").strip()
                if not source:
                    continue
                try:
                    token = str(resolve_table_token(worksheet, source, mapping.get("token_index", 0)) or "").strip()
                except Exception:
                    continue
            if not token:
                continue
            try:
                path = resolve_icon_path(token, icon_folder or "", icon_mappings or {})
            except Exception:
                path = None
            if path and os.path.isfile(path):
                icons[str(slot_name)] = {"token": token, "file": os.path.basename(path)}
    finally:
        try:
            if workbook is not None:
                workbook.close()
        except Exception:
            pass
    return icons


def _mapping_preview_icon(mapping, worksheet, icon_folder, icon_mappings):
    """Resolve the icon file for an icon-kind mapping, or None."""
    token = str((mapping or {}).get("token") or "").strip()
    asset = str((mapping or {}).get("asset_path") or "").strip()
    if asset and os.path.isfile(asset):
        # design art learned from an artist PSD carries its own file
        return {"token": token or os.path.basename(asset), "path": asset}
    if not token and worksheet is not None:
        source = str((mapping or {}).get("source") or "").strip()
        if source:
            try:
                from ps_autotypesetter.table_mapping import resolve_table_token

                token = str(resolve_table_token(worksheet, source, mapping.get("token_index", 0)) or "").strip()
            except Exception:
                token = ""
    if not token:
        return None
    try:
        from ps_autotypesetter.icon_mapping import resolve_icon_path
    except Exception:
        return None
    try:
        # a paytable card's royal also answers to its other spelling (A / ACE ...) — the exact name first
        path = resolve_icon_path(token, icon_folder or "", icon_mappings or {}, (mapping or {}).get("icon_aliases") or None)
    except Exception:
        path = None
    if not path or not os.path.isfile(path):
        return None
    return {"token": token, "path": path}


_LAST_ICON_RECT = None      # where the last slot icon landed (x, y, w, h): the card studio's tight boxes
_ICON_CACHE = {}            # (path, mtime, size) -> RGBA image: previews redraw the same icons on every edit


def _icon_image(path, size=None):
    """The icon file as RGBA (resized to `size` with LANCZOS); a fresh copy, cached per file version."""
    from PIL import Image

    key = (path, os.path.getmtime(path), tuple(size) if size else None)
    img = _ICON_CACHE.get(key)
    if img is None:
        if len(_ICON_CACHE) > 400:
            _ICON_CACHE.clear()
        img = _icon_image(path).resize(tuple(size), Image.LANCZOS) if size else Image.open(path).convert("RGBA")
        _ICON_CACHE[key] = img
    return img.copy()


def _draw_mapped_slot_icon(overlay, mapping, worksheet, icon_folder, icon_mappings,
                           x, y, w, h, scale):
    """Paste the mapped slot's icon into the preview overlay.

    ``icon_height`` is a target-canvas pixel value (same as the PSD renderer's
    ``_place_asset`` max_height) and is clamped to the already-scaled slot
    box. Returns True when an icon was drawn."""
    global _LAST_ICON_RECT
    try:
        from PIL import Image
    except Exception:
        return False
    info = _mapping_preview_icon(mapping, worksheet, icon_folder, icon_mappings)
    if not info:
        return False
    try:
        icon_img = _icon_image(info["path"])
    except Exception:
        return False
    if str(mapping.get("fit") or "").casefold() == "exact":
        # design art learned from an artist PSD: fills its box exactly, under the text
        try:
            icon_img = icon_img.resize((max(1, int(w)), max(1, int(h))), Image.LANCZOS)
        except Exception:
            return False
        try:
            opacity = min(1.0, max(0.0, float(mapping.get("layer_opacity", 1.0))))
        except (TypeError, ValueError):
            opacity = 1.0
        from ps_autotypesetter.psd_writer import recorder as _psd
        _page = _psd.page_for(overlay)
        if _page is not None:
            _rec = _psd.active_recorder()
            label, group = (_rec.slot if _rec is not None and _rec.slot else ("art", None))
            _page.shapes.append(_psd.ImageRecord(icon_img, int(x), int(y), label, group=group,
                                                 opacity=opacity, effects=mapping.get("effects_block")))
            return True
        preview = str(mapping.get("preview_image") or "")
        if preview and os.path.isfile(preview):
            # baked look of the artist's effects (the PSD gets the live effects instead)
            try:
                baked = Image.open(preview).convert("RGBA")
                s = float(w) / max(1, Image.open(info["path"]).width)
                pad = float(mapping.get("preview_pad") or 0) * s
                icon_img = baked.resize((max(1, int(round(baked.width * s))), max(1, int(round(baked.height * s)))),
                                        Image.LANCZOS)
                x, y = int(round(x - pad)), int(round(y - pad))
            except Exception:
                pass
        if opacity < 1.0:
            alpha = icon_img.getchannel("A").point(lambda a: int(a * opacity + 0.5))
            icon_img.putalpha(alpha)
        _LAST_ICON_RECT = (int(x), int(y), icon_img.width, icon_img.height)
        try:
            overlay.alpha_composite(icon_img, (int(x), int(y)))
        except (ValueError, TypeError):
            overlay.paste(icon_img, (int(x), int(y)), icon_img)
        return True
    try:
        icon_h = int(float(mapping.get("icon_height") or 0) or 48)
    except Exception:
        icon_h = 48
    icon_h_px = max(4, int(icon_h))
    max_h = max(4, h - 4)
    if icon_h_px > max_h:
        icon_h_px = max_h
    ratio = max(0.01, float(icon_img.width) / max(1, float(icon_img.height)))
    icon_w = max(1, int(icon_h_px * ratio))
    if icon_w > w - 4:
        icon_w = max(1, w - 4)
        icon_h_px = max(1, int(icon_w / ratio))
    try:
        icon_img = _icon_image(info["path"], (icon_w, icon_h_px))
    except Exception:
        try:
            icon_img = icon_img.resize((icon_w, icon_h_px), Image.LANCZOS)
        except Exception:
            return False
    valign = str(mapping.get("vertical_align") or "center").casefold()
    align = str(mapping.get("alignment") or "center").casefold()
    if valign == "top":
        ty = y + 2
    elif valign == "bottom":
        ty = y + h - icon_h_px - 2
    else:
        ty = y + max(2, (h - icon_h_px) // 2)
    if align == "left":
        tx = x + 2
    elif align == "right":
        tx = x + w - icon_w - 2
    else:
        tx = x + max(2, (w - icon_w) // 2)
    from ps_autotypesetter.psd_writer import recorder as _psd
    _page = _psd.page_for(overlay)
    if _page is not None:  # PSD build: the slot icon is its own layer
        _rec = _psd.active_recorder()
        label, group = (_rec.slot if _rec is not None and _rec.slot else ("icon", None))
        name = f"{label} symbol" if group else label  # the card group already carries the bare name
        _page.icons.append(_psd.ImageRecord(icon_img, int(tx), int(ty), name, group=group,
                                            effects=mapping.get("effects_block")))
        return True
    _LAST_ICON_RECT = (int(tx), int(ty), icon_w, icon_h_px)
    try:
        overlay.paste(icon_img, (int(tx), int(ty)), icon_img)
    except Exception:
        return False
    return True


_PREVIEW_TEXT_SLOT_NAMES = {
    "title", "count", "payout", "payouts", "notes", "text", "note",
    "label", "description", "subtitle", "heading",
}


def _paytable_preview_default_mapping(slot_name):
    """Name-based default preview mapping: ``@slot.whatever`` renders the
    ``<whatever>`` icon; text-ish names and bounds slots stay unmapped
    (returns None). Mirrors the PSD renderer's default."""
    from ps_autotypesetter.table_mapping import _slot_name_is_bounds_like

    raw = str(slot_name or "")
    if _slot_name_is_bounds_like(raw):
        return None
    parts = raw.split(".")
    last = (parts.pop() or "").strip()
    first = (parts[0] if parts else last).strip()
    norm = re.sub(r"[^a-z0-9]", "", last.casefold())
    first_norm = re.sub(r"[^a-z0-9]", "", first.casefold())
    if not norm:
        return None
    if (norm in _PREVIEW_TEXT_SLOT_NAMES or first_norm in _PREVIEW_TEXT_SLOT_NAMES
            or re.fullmatch(r"(pay|value)s?\d*", norm)):
        return None
    token = "<wild>" if first_norm == "wild" and re.fullmatch(r"\d+", norm) else f"<{norm}>"
    return {
        "mode": "icon",
        "token": token,
        "slot": raw,
        "icon_height": 120,
        "color": "#FFFFFF",
        "alignment": "center",
        "vertical_align": "center",
        "padding": [0, 0, 0, 0],
    }


def _preview_slot_is_wild_title(slot_name):
    """True for the hardcoded WILD-title slot: ``@slot.wild.title`` (plus the
    ``feature.title`` / ``special.title`` aliases). This slot always renders
    the text "WILD" with the heading typography unless the user maps it."""
    raw = str(slot_name or "").strip()
    for pfx in ("@slot.", "@table."):
        if raw.casefold().startswith(pfx.casefold()):
            raw = raw[len(pfx):]
            break
    return re.sub(r"\s+", "", raw).casefold() in {"wild.title", "wild.text", "feature.title", "special.title"}


def _preview_slot_is_title(slot_name):
    """True for the page-heading slot: ``@slot.title`` / ``title``."""
    raw = str(slot_name or "").strip()
    for pfx in ("@slot.", "@table."):
        if raw.casefold().startswith(pfx.casefold()):
            raw = raw[len(pfx):]
            break
    return re.sub(r"\s+", "", raw).casefold() == "title"


def _preview_page_heading(worksheet, template):
    """The page heading text the card renderer would use (from the sheet)."""
    try:
        from ps_autotypesetter.dynamic_pages.paytable.parser import parse_paytable_sheet

        parsed = parse_paytable_sheet(worksheet, template=template)
        return str((parsed or {}).get("title") or "").strip()
    except Exception:
        return ""


_CELL_LIKE_RE = re.compile(r"^[A-Za-z]{1,3}[0-9]{1,7}$")

_GAME_NAME_HEADING_TOKEN_RE = re.compile(r"<\s*game[\s_-]*name\s*>", flags=re.IGNORECASE)


def _cell_like_source(value):
    return bool(_CELL_LIKE_RE.match(str(value or "").strip()))


def _preview_heading_text(value, settings):
    """Heading text prep mirrored from the PSD renderer: replace the
    ``<game name>`` token (if a replacement is configured) and uppercase
    when the heading-uppercase option is on."""
    from ps_autotypesetter.png_builder import game_name_heading

    text = game_name_heading(value, settings)      # game-name image if found, else the typed name
    if bool((settings or {}).get("heading_uppercase_enabled", False)):
        text = text.upper()
    return text


def _rgb_to_hex(value):
    if isinstance(value, (list, tuple)) and len(value) >= 3:
        try:
            return "#%02X%02X%02X" % (int(value[0]), int(value[1]), int(value[2]))
        except Exception:
            pass
    return ""


_LIVE_DATA_ROLES = {"pay", "value"}


def _card_under(template, symbol_slot):
    """Name of the card whose pay/value boxes sit directly under `symbol_slot`'s box, or None."""
    slots = (template or {}).get("slots") or {}

    def box(name):
        b = slots.get(name)
        try:
            return float(b["x"]), float(b["y"]), float(b["w"]), float(b["h"])
        except Exception:
            return None

    sb = box(symbol_slot)
    if not sb:
        return None
    x, y, w, h = sb
    own = _norm_slot(symbol_slot)
    best = None
    for name in slots:
        m = re.fullmatch(r"(.+?)\.(?:pay|value)s?", str(name), flags=re.IGNORECASE)
        pb = box(name) if m else None
        if not pb:
            continue
        # edge-to-edge distance in any direction: pays may sit below, above or beside the symbol
        dx = max(0.0, pb[0] - (x + w), x - (pb[0] + pb[2]))
        dy = max(0.0, pb[1] - (y + h), y - (pb[1] + pb[3]))
        d = (dx * dx + dy * dy) ** 0.5
        if d > 2.0 * max(w, h):
            continue
        key = (d, 0 if _norm_slot(m.group(1)) == own else 1)   # ties: the card's own pays
        if best is None or key < best[0]:
            best = (key, m.group(1))
    return best[1] if best else None


def _norm_slot(name):
    name = str(name or "").strip()
    for pfx in ("@slot.", "@table."):
        if name.casefold().startswith(pfx):
            name = name[len(pfx):]
            break
    return re.sub(r"\s+", "", name).casefold()


def _rebind_data_slots_to_live_sheet(mapped, worksheet, template):
    """Point pay/value slots at their symbol's block in the CURRENT sheet.

    Mappings store cell addresses (``F14,F15,...``) from the workbook they were
    made against. Reused on another workbook — or after rows move — those
    addresses read the wrong rows (a paytable starting one row higher loses
    its first pay line). Excel is the source of truth, so slots the automapper
    produced follow their symbol (``role`` + ``symbol``) to wherever it is now.
    Slots an artist assigned by hand (``source_pinned``) keep their cells.
    """
    if worksheet is None or not template:
        return 0
    try:
        from ps_autotypesetter.ui_web.engine_api import _paytable_norm_name, automap_paytable_slots_ws
        live = automap_paytable_slots_ws(worksheet, template) or {}
    except Exception:
        return 0
    by_slot, icon_by_slot = {}, {}
    for spec in live.get("mappings") or []:
        if not isinstance(spec, dict):
            continue
        if str(spec.get("role") or "").casefold() in _LIVE_DATA_ROLES and spec.get("source"):
            by_slot[_paytable_norm_name(spec.get("slot"))] = spec
        elif str(spec.get("mode") or "").casefold() == "icon" and spec.get("token") and spec.get("symbol"):
            icon_by_slot[_paytable_norm_name(spec.get("slot"))] = spec
        elif _paytable_norm_name(spec.get("slot")) == "text" and spec.get("source"):
            by_slot["text"] = spec                       # the rules catch-all follows the sheet too
    sheet_symbols = {_paytable_norm_name(b.get("key")) for b in live.get("blocks") or [] if b.get("key")}
    fixed = 0
    for slot_name, spec in mapped.items():
        if not isinstance(spec, dict) or spec.get("source_pinned"):
            continue
        if (str(spec.get("mode") or "").casefold() == "icon" and sheet_symbols
                and not spec.get("symbol_pinned") and not spec.get("asset_path")):
            token_sym = _paytable_norm_name(str(spec.get("token") or "").strip("<> "))
            if token_sym == "wild":
                continue
            # the card is what the artist SEES: the symbol box shows the symbol whose
            # pays sit under it (templates with swapped pic4/pic5 boxes render right)
            owner = _card_under(template, slot_name)
            fresh = icon_by_slot.get(_paytable_norm_name(owner or slot_name))
            if owner and _paytable_norm_name(owner) != _paytable_norm_name(slot_name):
                new_token = fresh["token"] if fresh else f"<{owner}>"
                if new_token != spec.get("token"):
                    spec["token"] = new_token
                    spec["symbol"] = fresh["symbol"] if fresh else owner
                    fixed += 1
            elif fresh and token_sym and token_sym not in sheet_symbols:
                # a symbol not in THIS sheet (<pic4> where the 4th card is
                # <spaceship>) shows the symbol the sheet has in that position
                spec["token"], spec["symbol"] = fresh["token"], fresh["symbol"]
                fixed += 1
            continue
        if str(spec.get("mode") or "excel").casefold() != "excel":
            continue
        if (str(spec.get("role") or "").casefold() not in _LIVE_DATA_ROLES
                and _paytable_norm_name(slot_name) != "text"):
            continue
        fresh = by_slot.get(_paytable_norm_name(slot_name))
        if fresh and (fresh.get("source") != spec.get("source")
                      or (fresh.get("symbol") and fresh.get("symbol") != spec.get("symbol"))):
            spec["source"] = fresh.get("source")
            spec["text"] = fresh.get("text", spec.get("text"))
            if fresh.get("symbol"):
                # a saved symbol from another workbook (<spaceship>) would get the pays filtered out
                spec["symbol"] = fresh.get("symbol")
            fixed += 1
    return fixed


def _sanitize_preview_mappings(mapped, worksheet, template=None):
    """Heal stale mappings before the preview draw:

      * pay/value slots follow their symbol to its rows in the current sheet
        (see _rebind_data_slots_to_live_sheet) unless the artist pinned them;

      * excel-mode mappings whose single-cell source does not exist in the
        worksheet (slot ``pic1`` saved with source ``PIC1`` — a phantom cell)
        fall back to the name-based default so the slot still shows its icon;
      * icon/symbol mappings on text-ish names or style-less bounds slots
        (leftovers of old automap runs) are dropped — unless the user
        explicitly assigned them this session (``userTouched``).
    """
    fixed = _rebind_data_slots_to_live_sheet(mapped, worksheet, template)
    # a design learned from an artist PSD names its own art slots (decor.N, rules.N.icon.M)
    from ps_autotypesetter.artist_design.fit_cards import is_artist_template
    learned = is_artist_template(template)
    for slot_name, spec in list(mapped.items()):
        if not isinstance(spec, dict):
            continue
        mode = str(spec.get("mode") or "").casefold()
        if learned and mode in {"icon", "symbol"}:
            continue
        has_style = any(spec.get(k) for k in (
            "background_color", "fill_color", "stroke_color",
            "fill_enabled", "stroke_enabled", "opacity", "shape"))
        if mode in {"icon", "symbol"} and _paytable_preview_default_mapping(slot_name) is None:
            if not has_style and not spec.get("userTouched"):
                del mapped[slot_name]
                fixed += 1
            continue
        if mode != "excel" or worksheet is None:
            continue
        source = str(spec.get("source") or "").strip()
        if not source or ":" in source or "," in source or ";" in source or "\n" in source:
            continue
        match = re.fullmatch(r"([A-Za-z]{1,3})(\d+)", source)
        if not match:
            continue
        try:
            value = worksheet[f"{match.group(1)}{match.group(2)}"].value
        except Exception:
            value = None
        if value is not None:
            continue
        default = _paytable_preview_default_mapping(slot_name)
        if default:
            mapped[slot_name] = default
            fixed += 1
    return fixed


def _filter_preview_dead_mappings(mapped, live_data, slot_is_dead):
    """Drop mapped specs for cards the live sheet lacks (parallel to the PSD
    renderer's filter) so the outline preview matches the built output."""
    try:
        for name, spec in list(mapped.items()):
            if slot_is_dead(name, spec, live_data):
                del mapped[name]
    except Exception:
        pass



def title_mapping(m, settings):
    """The paytable title's mapping as drawn: the page heading's size / colour / font unless the slot has its
    own, then the design's own title look (page.title: title_own), always centred — one rule for the
    preview, the build and the Canvas."""
    eff = dict(m)
    cur_size = int(float(m.get("font_size") or 0) or 0)
    heading_size = int(float(settings.get("title_size") or settings.get("heading_size") or 0) or 0)
    eff["font_size"] = (heading_size or cur_size or 30) if cur_size in (0, 30) else cur_size
    if not m.get("color") or str(m.get("color")).casefold() == "#ffffff":
        eff["color"] = _rgb_to_hex(settings.get("title_rgb") or settings.get("heading_rgb")) or "#FFFFFF"
    if not (m.get("font_override") or (m.get("font_name") or m.get("font_family") or "").strip()):
        eff["font_name"] = str(settings.get("heading_font") or "").strip()
        eff["font_override"] = True
    own = m.get("title_own") or {}          # the paytable title's own look (page.title)
    if own.get("font_size"):
        eff["font_size"] = int(round(float(own["font_size"])))
    if own.get("color"):
        eff["color"] = str(own["color"])
    if own.get("font"):
        eff["font_name"], eff["font_override"] = str(own["font"]), True
    eff["bold"] = bool(own["bold"]) if "bold" in own else bool(m.get("bold", True))
    if "italic" in own:
        eff["italic"] = bool(own["italic"])
    # Page headings always sit dead-center in their slot; per-slot alignment only applies to data slots.
    eff["alignment"] = "center"
    eff["vertical_align"] = "center"
    return eff


def slot_text_layout(name, m, content, x, y, w, h, icon_folder="", icon_mappings=None, kind=""):
    """A slot's text as it is drawn — its font, size, wrapped lines, line heights and top (canvas px).

    The ONE layout for a paytable text: the preview, the build (png_builder → the PSD's text layers) and
    the Canvas (the server sends these lines; the browser only draws them) all use it, so what the Canvas
    shows is what the PSD gets. Rules: the title keeps to its own lines (smaller when too long); Auto size
    (fit_box) takes the biggest size that fits the box; legacy slots shrink until they fit."""
    from PIL import ImageFont

    try:
        fsize = int(float(m.get("font_size") or 30))
    except Exception:
        fsize = 30
    explicit_font = (bool(m.get("font_override"))
                     or m.get("font_size") is not None
                     or m.get("size") is not None)
    if m.get("shrink_to_fit"):
        explicit_font = False      # learned prose: the artist's size, shrunk only when Excel runs longer
    # Per-mapping padding [top, right, bottom, left] insets the content box (same semantics as
    # _flow_padding in the PSD paytable renderer). Everything — wrap width, alignment, vertical
    # centering and overflow checks — happens inside it.
    pad_vals = m.get("padding")
    if isinstance(pad_vals, (int, float)):
        padT = padR = padB = padL = max(0.0, float(pad_vals or 0))
    elif isinstance(pad_vals, (list, tuple)):
        try:
            padT, padR, padB, padL = [max(0.0, float(v or 0)) for v in list(pad_vals)[:4]]
            if len(list(pad_vals)) == 2:
                padT = padB = max(0.0, float(pad_vals[0] or 0))
                padL = padR = max(0.0, float(pad_vals[1] or 0))
            elif len(list(pad_vals)) < 4:
                padT = padR = padB = padL = 0.0
        except Exception:
            padT = padR = padB = padL = 0.0
    else:
        padT = padR = padB = padL = 0.0
    box_x = x + padL
    box_w = max(8, w - padL - padR)
    box_h = max(8, h - padT - padB)
    max_tw = max(8, box_w - 6)
    fh = max(9, int(fsize))  # target-canvas px, like the PSD

    def _font(size_px, fname=None):
        if m.get("bold") or m.get("italic"):       # card studio: bold / italic face of the font
            try:
                from ps_autotypesetter import png_builder as _pngb
                return _pngb._load_font(ImageFont, fname or "Arial", size_px, bold=bool(m.get("bold")), italic=bool(m.get("italic")))
            except Exception:
                pass
        path = _resolve_font_file(fname) if fname else None
        if path:
            try:
                return ImageFont.truetype(path, size_px)
            except Exception:
                pass
        try:
            return ImageFont.truetype("arialbd.ttf" if kind == "heading" else "arial.ttf", size_px)
        except Exception:
            try:
                return ImageFont.truetype("arial.ttf", size_px)
            except Exception:
                return ImageFont.load_default()

    fname = m.get("font_name") or m.get("font_family")
    flab = _font(fh, fname)
    try:
        icon_h = int(float(m.get("icon_height") or 0))
    except Exception:
        icon_h = 0
    initial_fh = max(9, int(fsize))

    def _auto_line_h(font_px, line_icon_px):
        line_icon_px = max(0, int(line_icon_px or 0))
        try:
            manual = max(0, int(float(m.get("line_height") or 0)))
        except Exception:
            manual = 0
        if manual > 0:
            return max(font_px + 4, line_icon_px + 8, manual)
        return max(int(font_px * 1.25), font_px + 8, line_icon_px + 8)

    def _scaled_icon_h(cur_fh):
        if icon_h > 0:
            if m.get("fit_box"):              # a text that fills its box: its icons grow with it too
                return max(1, int(round(icon_h * cur_fh / max(1, initial_fh))))
            return max(1, min(icon_h, max(1, int(round(icon_h * cur_fh / max(1, initial_fh))))))
        return min(cur_fh, max(4, box_h - 4))

    def _measure_block(cur_fh):
        cur_font = _font(cur_fh, fname)
        lns = _wrap_preview_inline(content, cur_font, max_tw, _scaled_icon_h(cur_fh), icon_folder, icon_mappings,
                                   m.get("icon_scales"), keep_blank=bool(m.get("inline_icons")))
        lh = [_auto_line_h(cur_fh, max([it.get("h") or min(it["img"].height, _scaled_icon_h(cur_fh)) for it in ln
                                        if it["type"] == "icon"] or [0])) for ln in lns]
        return lns, lh, sum(lh or [0])

    lines, line_heights, block_h = _measure_block(fh)
    # the paytable title stays on its own lines (one, or as many as its text has): too long for its
    # box, it gets smaller — as a page heading does (layout_engine)
    if name == "@slot.title" or _preview_slot_is_title(name):
        _want = max(1, len([ln for ln in str(content).split("\n") if ln.strip()]))
        _floor = max(9, int(fsize * 0.2))
        while len(lines) > _want and fsize > _floor:
            fsize = max(_floor, int(fsize * 0.97))
            fh = max(9, int(fsize))
            lines, line_heights, block_h = _measure_block(fh)
        flab = _font(fh, fname)
    if m.get("fit_box") and content:
        # Auto size: the biggest size whose lines fit the box (wrapped to its width) — up to 3x the
        # design's, never below 8 px
        def _fits(sz):
            lns, _lh, bh = _measure_block(max(9, int(sz)))
            return bh <= max(1, box_h - 4) and not any(sum(it["w"] for it in ln) > max_tw for ln in lns)
        lo_, hi_ = 8.0, float(max(9, min(box_h, initial_fh * 3)))
        if _fits(hi_):
            lo_ = hi_
        else:
            for _ in range(14):
                mid_ = (lo_ + hi_) / 2.0
                if _fits(mid_):
                    lo_ = mid_
                else:
                    hi_ = mid_
        fsize = lo_
        fh = max(9, int(fsize))
        lines, line_heights, block_h = _measure_block(fh)
        flab = _font(fh, fname)
    while not explicit_font and fsize > 8 and (
        block_h > max(1, box_h - 4)
        or any(sum(it["w"] for it in ln) > max_tw for ln in lines)
    ):
        fsize -= 1
        fh = max(9, int(fsize))
        lines, line_heights, block_h = _measure_block(fh)
    if m.get("shrink_to_fit"):     # learned prose draws at the fitted size (legacy slots keep theirs)
        flab = _font(fh, fname)
    valign = str(m.get("vertical_align") or "center").casefold()
    if valign == "bottom":
        ty = y + h - padB - block_h - 3
    elif valign == "top":
        ty = y + padT + 3
    else:
        ty = y + padT + max(3, (box_h - block_h) // 2)
    overflow = block_h > max(1, box_h - 4) or any(sum(it["w"] for it in ln) > max(8, box_w - 6) for ln in lines)
    return {"font": flab, "fh": fh, "lines": lines, "line_heights": line_heights, "block_h": block_h, "ty": ty,
            "box_x": box_x, "box_w": box_w, "box_h": box_h, "icon_h": _scaled_icon_h(fh), "overflow": overflow,
            "align": str(m.get("alignment") or "center").casefold()}


def plate_is_late(shape):
    """A plate drawn after its text, from where the text lands: fit to it, or sized by hand around it."""
    return isinstance(shape, dict) and (shape.get("fit") is not None or isinstance(shape.get("pads"), (list, tuple)))


def text_rect(lay):
    """(x, y, w, h) of a laid-out text (canvas px): its widest line, where its alignment puts it, its lines."""
    from ps_autotypesetter import png_builder as _png

    sp = _png._advance(lay["font"], " ")
    tw = max([sum(it["w"] for it in ln) + max(0, len(ln) - 1) * sp for ln in lay["lines"]] or [0])
    bw = max(1.0, float(lay["box_w"]) - 6)
    x0 = float(lay["box_x"]) + 3
    if lay["align"] == "center":
        x0 += max(0, (bw - tw) // 2)
    elif lay["align"] == "right":
        x0 += max(0.0, bw - tw)
    return x0, float(lay["ty"]), float(tw), float(lay["block_h"])


def plate_rect(shape, x, y, w, h, lay):
    """(x, y, w, h) of a plate drawn after its text (the paytable title's): its own margins around the text
    (shape["pads"]: left, top, right, bottom — any size), else as wide as the text + shape["fit"] on each
    side and as tall as its slot. The preview, the build and the Canvas (the server sends it) draw this."""
    tx, ty, tw, th = text_rect(lay)
    pads = shape.get("pads") if isinstance(shape, dict) else None
    if isinstance(pads, (list, tuple)) and len(pads) == 4:
        pl, pt, pr, pb = (float(v or 0) for v in pads)
        return tx - pl, ty - pt, max(1.0, tw + pl + pr), max(1.0, th + pt + pb)
    fw = min(float(w), tw + 2 * float((shape or {}).get("fit") or 0))
    return x + (w - fw) / 2.0, float(y), fw, float(h)


def layout_for_canvas(lay, rect_y):
    """The layout as the Canvas draws it (JSON): its size, each line's words / icons with the build's widths,
    the space between words and the gap after an icon (as _draw_preview_inline_line), each line's height
    and the text's top — the browser places every word and icon where the build (the PSD) does."""
    from ps_autotypesetter import png_builder as _png

    out, bases, font = [], [], lay["font"]
    for ln, lh in zip(lay["lines"], lay["line_heights"]):
        first = next((it for it in ln if it.get("type") != "icon"), None)
        if first is not None:                      # the line's baseline from its top, as the PSD records it
            box = font.getbbox(first["val"])
            bases.append(round(max(0, (lh - max(0, box[3] - box[1])) // 2) - box[1] + font.getmetrics()[0], 2))
        else:
            bases.append(None)
        row = []
        for it in ln:
            if it.get("type") == "icon":
                row.append({"i": str(it.get("val") or ""), "h": round(float(it.get("h") or it["img"].height), 2),
                            "w": round(float(it.get("w") or 0), 2)})
            else:
                row.append({"t": str(it.get("val") or ""), "w": round(float(it.get("w") or 0), 2)})
        out.append(row)
    icon_h = max(4, int(lay["icon_h"] or 0))
    return {"size": int(getattr(lay["font"], "size", lay["fh"]) or lay["fh"]), "lines": out,
            "lh": [round(float(v), 2) for v in lay["line_heights"]], "base": bases, "top": round(float(lay["ty"]) - float(rect_y), 2),
            "space": round(max(1.0, _png._advance(lay["font"], " ")), 3), "gap": max(2, icon_h // 10),
            "box_x": round(float(lay["box_x"]) + 3, 2), "box_w": round(max(1.0, float(lay["box_w"]) - 6), 2), "align": lay["align"]}


def render_table_outline_preview(template: dict, preview_path: str = "", settings: dict = None, mappings: dict = None, excel_path: str = "", sheet_name: str = "", worksheet: object = None, icon_folder: str = "", icon_mappings: dict = None, report: dict = None, bg_path: str = "", annotations: bool = True) -> str:
    """Render the mapper preview; the sheet comes from the shared parsed-workbook cache.

    openpyxl's read-only mode re-scans the sheet XML for every random cell
    lookup (~3 s per preview on a game doc); a cached full parse makes each
    live preview a fraction of a second.
    """
    kwargs = dict(template=template, preview_path=preview_path, settings=settings, mappings=mappings,
                  excel_path=excel_path, sheet_name=sheet_name, icon_folder=icon_folder,
                  icon_mappings=icon_mappings, report=report, bg_path=bg_path, annotations=annotations)
    if worksheet is not None and type(worksheet).__name__ == "ReadOnlyWorksheet":
        worksheet = None          # callers' read-only sheets are the slow path: use the cached parse instead
    if worksheet is None and excel_path and sheet_name and os.path.isfile(excel_path):
        try:
            from ps_autotypesetter import workbook_cache

            with workbook_cache.borrow(excel_path, data_only=True) as wb:
                if sheet_name in wb.sheetnames:
                    return _render_table_outline_preview(worksheet=wb[sheet_name], **kwargs)
        except Exception:
            pass
    return _render_table_outline_preview(worksheet=worksheet, **kwargs)


def page_heading_settings(settings, sheet_name):
    """The settings with this page's own heading (Canvas › Heading › This page: page_overrides[sheet]
    h_font / h_size / h_rgb) in place of the game's — the paytable's title is drawn with them."""
    from ps_autotypesetter import png_builder as _pb

    ov = _pb._png_page_style_override(sheet_name, (settings or {}).get("page_overrides")) if sheet_name else {}
    if not ov or not any(ov.get(k) not in (None, "") for k in ("h_font", "h_size", "h_rgb")):
        return settings
    out = dict(settings)
    if ov.get("h_size") not in (None, ""):
        try:
            out["title_size"] = out["heading_size"] = max(8, int(float(ov["h_size"])))
            for k in ("per_page_heading_sizes", "page_heading_sizes", "heading_size_overrides", "per_page_heading_size_overrides"):
                out.pop(k, None)                          # this page's own size is the size
        except (TypeError, ValueError):
            pass
    if ov.get("h_font"):
        out["heading_font"] = str(ov["h_font"])
    if ov.get("h_rgb"):
        out["title_rgb"] = out["heading_rgb"] = _pb._rgb(ov["h_rgb"], (255, 255, 255))
    return out


def _render_table_outline_preview(template: dict, preview_path: str = "", settings: dict = None, mappings: dict = None, excel_path: str = "", sheet_name: str = "", worksheet: object = None, icon_folder: str = "", icon_mappings: dict = None, report: dict = None, bg_path: str = "", annotations: bool = True) -> str:
    """Draw a PIL outline preview (slot boxes + names) of a template JSON.

    Mapped slots are filled with their ``background_color``/``opacity``,
    stroked with their ``stroke_color``/``stroke_width``, and labelled with
    the actual mapped content (explicit ``text`` or the resolved Excel cell
    value) using the mapping's ``font_size``/``color``/``alignment``.
    Unmapped slots keep a dim outline. When ``bg_path`` points to an image it
    is used as the canvas background instead of the dark fallback color.
    The preview replicates the PSD renderer: slot boxes are contain/center
    scaled from the template canvas to the target canvas (``canvas_width`` /
    ``canvas_height`` settings, default 1920x1080), while icon heights, font
    sizes and stroke widths keep their target-canvas pixel values (clamped to
    the scaled slot box), so the preview matches the Photoshop output 1:1.
    Set ``annotations=False`` to hide the blueprint layer (slot outlines,
    slot-name labels) and see only the rendered content, like the PSD result.
    Returns the preview PNG path, or "".
    """
    try:
        from PIL import Image, ImageDraw, ImageFont  # noqa: F401
    except Exception:
        return ""
    try:
        canvas = (template or {}).get("canvas") or {}
        slots = (template or {}).get("slots") or {}
        cw = int(canvas.get("width", 0) or 0)
        ch = int(canvas.get("height", 0) or 0)
        if not cw or not ch or not isinstance(slots, dict) or not slots:
            return ""
        settings = page_heading_settings(settings or {}, sheet_name)
        mapped = _mapping_dict(mappings if mappings is not None else ((template or {}).get("mappings") or {}))
        if excel_path:
            # card images picked for another workbook give way to this sheet's own symbols
            from ps_autotypesetter.ui_web.engine_api import drop_foreign_symbol_picks

            mapped = {k: dict(v) for k, v in mapped.items()}
            drop_foreign_symbol_picks(mapped, excel_path)
        workbook = None                                   # a passed-in worksheet is used as is
        if worksheet is None and excel_path and os.path.isfile(excel_path) and sheet_name:
            try:
                from openpyxl import load_workbook

                workbook = load_workbook(excel_path, data_only=True, read_only=True)
                if sheet_name in workbook.sheetnames:
                    worksheet = workbook[sheet_name]
                else:
                    workbook.close()
                    workbook = None
            except Exception:
                workbook = None
        # Layout learned from an artist PSD: fit it to this sheet (drop/clone cards)
        from ps_autotypesetter.artist_design import fit_cards as _fit_cards
        if worksheet is not None and _fit_cards.is_artist_template(template):
            template = _fit_cards.prepare(dict(template, mappings=mapped), worksheet, target=(
                int(float((settings or {}).get("canvas_width") or 1920)),
                int(float((settings or {}).get("canvas_height") or 1080))))
            slots = template.get("slots") or {}
            mapped = _mapping_dict(template.get("mappings") or {})
        elif worksheet is not None:
            # same Excel-driven card grid as the build (png_builder): 4+6 sheets on a 5+5 design
            try:
                from ps_autotypesetter.dynamic_pages.router import _is_mapper_design
                from ps_autotypesetter.dynamic_pages.paytable import card_grid as _card_grid

                if _is_mapper_design(template):
                    grid_info = {}
                    template = _card_grid.adapt(dict(template, mappings=mapped), worksheet, info=grid_info)
                    slots = template.get("slots") or {}
                    mapped = _mapping_dict(template.get("mappings") or {})
                    if isinstance(report, dict) and grid_info:
                        report["card_grid"] = grid_info      # band boxes + generated cards for the canvas
            except Exception:
                pass
        _sanitize_preview_mappings(mapped, worksheet, template)
        try:
            target_width = int(float(settings.get("canvas_width") or 1920))
            target_height = int(float(settings.get("canvas_height") or 1080))
        except Exception:
            target_width, target_height = 1920, 1080
        # Same contain/center transform as scale_template_slots() so a 4K JSON
        # renders at the 1920 target like the PSD output.
        sx = float(target_width) / float(cw)
        sy = float(target_height) / float(ch)
        scale = min(sx, sy)
        offset_x = (float(target_width) - cw * scale) / 2.0
        offset_y = (float(target_height) - ch * scale) / 2.0
        img = None
        if bg_path and os.path.isfile(bg_path):
            try:
                # same fill mode as the build (stretch / fit / cover / center), not always stretch
                from ps_autotypesetter import png_builder as _pbg

                canvas = Image.new("RGBA", (max(1, target_width), max(1, target_height)), (18, 22, 30, 255))
                _pbg._paint_background(canvas, Image, bg_path, (settings or {}).get("bg_mode") or "cover",
                                       (settings or {}).get("bg_color") or "#FFFFFF")
                img = canvas.convert("RGB")
            except Exception:
                img = None
        if img is None:
            img = Image.new("RGB", (max(1, target_width), max(1, target_height)), (18, 22, 30))
        overlay = Image.new("RGBA", img.size, (0, 0, 0, 0))
        draw = ImageDraw.Draw(overlay)
        try:
            small = ImageFont.truetype("arial.ttf", max(9, int(11 * scale)))
        except Exception:
            small = ImageFont.load_default()

        count_rgb = _hex_to_rgb(settings.get("count_rgb"))
        accent = (96, 140, 255)
        dim = (90, 100, 116)
        live_data = None
        from ps_autotypesetter.artist_design.fit_cards import is_artist_template as _is_artist
        if worksheet is not None and not _is_artist(template):   # learned layouts are fitted already
            try:
                from ps_autotypesetter.ui_web.engine_api import _paytable_live_slot_data, paytable_slot_is_dead

                live_data = _paytable_live_slot_data(worksheet, template)
            except Exception:
                live_data = None
        if live_data is not None:
            _filter_preview_dead_mappings(mapped, live_data, paytable_slot_is_dead)
        for name, box in slots.items():
            if live_data is not None:
                m_spec = mapped.get(name) if isinstance(mapped, dict) else None
                if m_spec is None:
                    m_spec = _paytable_preview_default_mapping(name)
                try:
                    if paytable_slot_is_dead(name, m_spec, live_data):
                        continue
                except Exception:
                    pass
            try:
                if isinstance(box, dict) and all(key in box for key in ("x", "y", "w", "h")):
                    x = int(offset_x + float(box["x"]) * scale)
                    y = int(offset_y + float(box["y"]) * scale)
                    w = int(float(box["w"]) * scale)
                    h = int(float(box["h"]) * scale)
                elif isinstance(box, (list, tuple)) and len(box) >= 4:
                    x = int(offset_x + float(box[0]) * scale)
                    y = int(offset_y + float(box[1]) * scale)
                    w = int(float(box[2]) * scale)
                    h = int(float(box[3]) * scale)
                elif isinstance(box, dict) and box.get("bounds"):
                    bbox = box["bounds"]
                    x = int(offset_x + float(bbox[0]) * scale)
                    y = int(offset_y + float(bbox[1]) * scale)
                    w = int(float(bbox[2]) * scale)
                    h = int(float(bbox[3]) * scale)
                else:
                    continue
            except Exception:
                continue
            m = mapped.get(name) if isinstance(mapped, dict) else None
            if not (m and isinstance(m, dict)):
                m = _paytable_preview_default_mapping(name)
                if m:
                    if _draw_mapped_slot_icon(
                        overlay, m, worksheet, icon_folder, icon_mappings, x, y, w, h, scale
                    ):
                        pass
                    else:
                        m = None
                if not m and _preview_slot_is_wild_title(name):
                    # Hardcoded: this slot always renders "WILD" with the
                    # heading typography unless the user explicitly maps it.
                    try:
                        wsize = int(float(settings.get("wild_title_size") or settings.get("title_size") or settings.get("heading_size") or 30))
                    except Exception:
                        wsize = 30
                    wcolor = _rgb_to_hex(settings.get("wild_title_rgb") or settings.get("title_rgb") or settings.get("heading_rgb")) or "#FFCD32"
                    m = {
                        "mode": "text", "source": "", "text": "WILD", "slot": name,
                        "font_size": wsize, "color": wcolor, "font_override": True,
                        "alignment": "center", "vertical_align": "center",
                        "padding": [0, 0, 0, 0],
                    }
                if not m and _preview_slot_is_title(name):
                    # Hardcoded: the title slot always points to the page
                    # heading (typography applied in the heading branch below)
                    # unless the user explicitly maps it.
                    m = {
                        "mode": "text", "source": "", "slot": name,
                        "font_size": 0, "color": "",
                        "alignment": "center", "vertical_align": "center",
                        "padding": [0, 0, 0, 0],
                    }
                if not m:
                    if annotations:
                        draw.rectangle([x, y, x + w, y + h], outline=dim, width=1)
                        txt = _truncate_label(name, small, max(8, w - 4))
                        draw.text((x + 3, y + 2), txt, fill=(120, 130, 148), font=small)
                    continue

            kind = str(m.get("kind") or "").casefold()
            # card templates: rounded box + border + layer style (same drawing as builds)
            from .. import paytable_box as _pbox
            _fit_plate = plate_is_late(m.get("shape"))
            _shaped = True if _fit_plate else _pbox.draw(overlay, m, x, y, w, h, settings)   # a fit plate: after its text
            has_bg = bool(str(m.get("background_color") or m.get("fill_color") or "").strip())
            fill_ctl = m.get("fill_enabled")
            fill_off = fill_ctl is False or str(fill_ctl).casefold() in ("false", "off", "no", "0")
            fill_enabled = (not _shaped) and (not fill_off) and (
                has_bg or bool(fill_ctl) or kind == "background"
            )
            if fill_enabled:
                bg = m.get("background_color") or m.get("fill_color")
                if bg:
                    try:
                        opacity = int(float(m.get("opacity") if m.get("opacity") is not None else 100) or 100)
                    except Exception:
                        opacity = 100
                    alpha = int(255 * (opacity / 100.0) * 0.85)
                    draw.rectangle([x, y, x + w, y + h], fill=_hex_to_rgb(bg) + (alpha,))
            try:
                stroke_w = int(m.get("stroke_width", 0) or 0)
            except Exception:
                stroke_w = 0
            stroke_ctl = m.get("stroke_enabled")
            stroke_off = _shaped or stroke_ctl is False or str(stroke_ctl).casefold() in ("false", "off", "no", "0")
            if (not stroke_off) and (bool(stroke_ctl) or stroke_w > 0):
                stroke = m.get("stroke_color")
                outline = _hex_to_rgb(stroke) if stroke else accent
                sw = max(1, int(stroke_w) or 1)  # target-canvas px, like the PSD
                draw.rectangle([x, y, x + w, y + h], outline=outline, width=sw)
            elif annotations and not _shaped:
                draw.rectangle([x, y, x + w, y + h], outline=accent, width=2)

            icon_drawn = False
            mode = str(m.get("mode") or "").casefold()
            icon_mode = kind in {"icon", "dedicated_icon"} or mode in {"icon", "symbol"}
            if icon_mode:
                global _LAST_ICON_RECT
                _LAST_ICON_RECT = None
                icon_drawn = _draw_mapped_slot_icon(
                    overlay, m, worksheet, icon_folder, icon_mappings, x, y, w, h, scale
                )
                if not icon_drawn and isinstance(report, dict):
                    report.setdefault("icon_issues", []).append(name)
                if icon_drawn and _LAST_ICON_RECT and isinstance(report, dict):
                    ix, iy, iw, ih = _LAST_ICON_RECT
                    report.setdefault("drawn", {})[name] = [ix, iy, ix + iw, iy + ih]
            if icon_mode and not icon_drawn and str(m.get("token") or "").strip("<> "):
                # no picture for this symbol: show its <NAME> in the box rather than nothing
                icon_mode = False
                content = "<" + str(m.get("token")).strip("<> ").upper() + ">"
            elif icon_mode:
                content = ""
            else:
                content = _mapping_preview_text(m, worksheet)
            if not icon_mode and _preview_slot_is_title(name):
                # Page-heading slot: ALWAYS show the page heading with the
                # heading typography (font/size/color from the header
                # settings — no layer styles, those are PSD-only) unless the
                # user mapped an explicit non-default text/source/font.
                if (mode == "literal" and _cell_like_source(content)) or not content:
                    content = _preview_page_heading(worksheet, template)
                    if not content:
                        content = str((template or {}).get("title")
                                      or ((template or {}).get("mapper_meta") or {}).get("title")
                                      or "").strip()
                    if not content:
                        content = str((settings or {}).get("title_text") or "").strip()
                content = _preview_heading_text(content, settings)
                if content:
                    m = title_mapping(m, settings)
            if not icon_mode and _preview_slot_is_wild_title(name) and not content:
                # Hardcoded: this slot renders "WILD" with the heading
                # typography unless the user provided explicit text/source.
                content = str(m.get("text") or settings.get("wild_title", "WILD")).strip() or "WILD"
                eff = dict(m)
                cur_size = int(float(m.get("font_size") or 0) or 0)
                try:
                    wsize = int(float(settings.get("wild_title_size") or settings.get("title_size") or settings.get("heading_size") or 30))
                except Exception:
                    wsize = 30
                eff["font_size"] = wsize if cur_size in (0, 30) else cur_size
                if not m.get("color") or str(m.get("color")).casefold() == "#ffffff":
                    eff["color"] = _rgb_to_hex(settings.get("wild_title_rgb") or settings.get("title_rgb") or settings.get("heading_rgb")) or "#FFCD32"
                if not (m.get("font_override") or (m.get("font_name") or m.get("font_family") or "").strip()):
                    eff["font_name"] = str(settings.get("heading_font") or "").strip()
                    eff["font_override"] = True
                eff["font_override"] = True
                m = eff
            if content:
                fcol = _hex_to_rgb(m.get("color")) if m.get("color") else count_rgb
                _lay = slot_text_layout(name, m, content, x, y, w, h, icon_folder, icon_mappings, kind)
                flab, fh, lines, line_heights, block_h = _lay["font"], _lay["fh"], _lay["lines"], _lay["line_heights"], _lay["block_h"]
                ty, box_x, box_w, align = _lay["ty"], _lay["box_x"], _lay["box_w"], _lay["align"]
                _icon_h = _lay["icon_h"]
                if isinstance(report, dict) and not icon_mode and content and _lay["overflow"]:
                    report.setdefault("overflow_issues", []).append(name)
                if _fit_plate:                       # the plate around the text: fit to it, or sized by hand
                    _pbox.draw(overlay, m, *plate_rect(m["shape"], x, y, w, h, _lay), settings)
                _title_fx = None
                if (_preview_slot_is_title(name) or _preview_slot_is_wild_title(name)) and not m.get("effects_block"):
                    from ps_autotypesetter import png_builder as _pbt

                    _own_fx = (m.get("title_own") or {}).get("fx")      # the title's own layer style
                    _title_fx = (_pbt.fx_by_name(settings.get("layer_style_library") or {}, _own_fx) if _own_fx else
                                 _pbt._resolve_fx_config(settings.get("layer_style_library") or {},
                                                         settings.get("style_assignments") or {}, "Heading text"))
                if _title_fx:
                    # same styled heading as the build (png_builder) and every other page
                    _pbt._draw_inline(
                        overlay, draw, Image, content, box_x + 3, ty, flab, fcol, max(1, box_w - 6),
                        icon_folder, icon_mappings, _icon_h, settings.get("icon_size_overrides") or {},
                        align=align, line_spacing=2, fx_config=_title_fx,
                        font_request=m.get("font_name") or m.get("font_family"), font_size=fh, bold=bool(m.get("bold", True)),
                    )
                    lines = []
                _ext = []
                _icons = [] if isinstance(report, dict) else None
                _text_fx = None
                if m.get("text_fx"):
                    from ps_autotypesetter import png_builder as _pbx

                    _text_fx = _pbx.fx_by_name(settings.get("layer_style_library"), m.get("text_fx"))
                for line_index, line in enumerate(lines):
                    _drawn = _draw_preview_inline_line(
                        draw, overlay, line, box_x + 3, ty, max(1, box_w - 6),
                        fcol, flab, line_heights[line_index], _icon_h, align, fx_config=_text_fx,
                        icons_out=_icons,
                    )
                    if _drawn and line:
                        _pad = max(0, (line_heights[line_index] - fh) // 2)
                        _ext.append((_drawn[0], ty + _pad, _drawn[0] + _drawn[1], ty + line_heights[line_index] - _pad))
                    ty += line_heights[line_index]
                if _icons:
                    report.setdefault("icons", []).extend(dict(i, slot=name) for i in _icons)
                if _ext and isinstance(report, dict):
                    report.setdefault("drawn", {})[name] = [min(e[0] for e in _ext), min(e[1] for e in _ext),
                                                            max(e[2] for e in _ext), max(e[3] for e in _ext)]
            elif not icon_mode and annotations:
                txt = _truncate_label(name, small, max(8, w - 4))
                draw.text((x + 3, y + 2), txt, fill=(214, 220, 232), font=small)
            if annotations:
                txt = _truncate_label(name, small, max(8, w - 6))
                draw.text((x + 3, max(1, y + h - 14)), txt, fill=(180, 190, 205), font=small)
        # Templates without any title slot still render the page heading the
        # normal way (every other page / the Visualiser preview): top with
        # heading_top_margin, inside the margin_x box, heading size/overrides,
        # h font/rgb and measured heading height -- same helpers, same result.
        _artist_meta = (((template or {}).get("mapper_meta") or {}).get("artist_design") or {})
        if not any(_preview_slot_is_title(name) for name in slots) and not _artist_meta.get("title_art"):
            heading = _preview_page_heading(worksheet, template)
            if heading:
                try:
                    from ps_autotypesetter import png_builder as _pb

                    Image, _ID, _IF = _pb._require_pillow()
                    margin_x = int(float(settings.get("margin_x") or 80))
                    heading_top = max(0, _pb._safe_int(settings.get("heading_top_margin"), 120))
                    safe_width = max(100, target_width - margin_x * 2)
                    base_size = int(float(settings.get("title_size") or settings.get("heading_size") or 90))
                    try:
                        current_size = max(8, int(float(_pb._png_heading_size_for_sheet(sheet_name, settings, base_size))))
                    except Exception:
                        current_size = base_size
                    hfont_name = str(settings.get("heading_font") or settings.get("h_font") or "ArialMT")
                    heading_font = _pb._heading_font(_IF, hfont_name, current_size, settings)
                    heading_color = _pb._rgb(
                        settings.get("title_rgb") or settings.get("heading_rgb") or settings.get("h_rgb"),
                        (255, 80, 80))
                    heading_icon_h = max(1, _pb._safe_int(
                        current_size, _pb._safe_int(settings.get("h_icon_h"), 48)))
                    try:
                        heading_line_spacing = max(0, _pb._safe_int(settings.get("line_spacing"), 4))
                    except Exception:
                        heading_line_spacing = 4
                    try:
                        _pt_heading_fx = _pb._resolve_fx_config(
                            settings.get("layer_style_library") or {},
                            settings.get("style_assignments") or {},
                            "Heading text",
                        )
                    except Exception:
                        _pt_heading_fx = None
                    _pb._draw_inline(
                        overlay, draw, Image, heading, margin_x, heading_top,
                        heading_font, heading_color, safe_width,
                        icon_folder, icon_mappings, heading_icon_h,
                        settings.get("icon_size_overrides") or {},
                        align="center", line_spacing=heading_line_spacing,
                        fx_config=_pt_heading_fx,
                        font_request=hfont_name, font_size=current_size, bold=True,
                    )
                except Exception:
                    pass
        if worksheet is not None and workbook is not None:
            try:
                workbook.close()
            except Exception:
                pass
        img = Image.alpha_composite(img.convert("RGBA"), overlay).convert("RGB")
        if preview_path:
            img.save(preview_path, "PNG", compress_level=1)     # live preview: fast encode over file size
            return preview_path
        return ""
    except Exception:
        return ""


def capture_style(mode: str = "selected") -> dict:
    """Capture a layer style from Photoshop and wrap it as a reusable style config.
    mode: 'selected' (active layer) or 'copied' (clipboard style)."""
    if not _photoshop_available():
        return {"ok": False, "error": "photoshop.api is not installed."}
    from ps_autotypesetter.layer_styles import (
        capture_copied_layer_style_from_photoshop,
        capture_selected_layer_style_from_photoshop,
    )

    fn = capture_selected_layer_style_from_photoshop if mode == "selected" else capture_copied_layer_style_from_photoshop
    try:
        ensure_com_initialized()
        # one script does it all (the document's Global Light rides along): a Photoshop that isn't the
        # COM-registered version asks before every script it is handed
        style = fn(extra_js=_GLOBAL_LIGHT_GET_JSX.strip().rstrip(";"))
        if not style:
            return {"ok": False, "error": "Photoshop returned an empty style. Open a document and select a styled layer first."}
        if isinstance(style, dict):
            hex_stream = str(style.get("hex") or style.get("captured_effects_hex") or "")
        else:
            hex_stream = str(style or "")
        if not hex_stream:
            return {"ok": False, "error": "Photoshop returned an empty style descriptor."}
        config = {
            "paste_copied_style": False,
            "copied_style_name": "Copied Photoshop layer style",
            "captured_effects_hex": hex_stream,
            "captured_params": style.get("captured_params") or {} if isinstance(style, dict) else {},
            "stroke_enabled": False,
            "shadow_enabled": False,
        }
        text_px = style.get("text_px") if isinstance(style, dict) else None
        if text_px:
            # the size of the text it was copied from: its effects follow the text size (fx_scale)
            from ps_autotypesetter import fx_scale

            config = fx_scale.remember_size(config, text_px)
        return {
            "ok": True,
            "style": config,
            "hex_len": len(hex_stream),
            "text_px": text_px,
            "hint": f"Captured layer style ({len(hex_stream)} bytes).",
            # the document's Global Light: "Use Global Light" effects in this style are drawn at it
            "global_light": _parse_global_light(style.get("extra") if isinstance(style, dict) else ""),
        }
    except Exception as e:
        return {"ok": False, "error": f"Capture failed: {e}"}


# The active document's Layer Style › Global Light as "angle,altitude" ("" when it can't be read)
_GLOBAL_LIGHT_GET_JSX = r"""
(function () {
    // "angle,altitude,file" of the active document's Global Light. Photoshop 27 no longer lists
    // globalAngle / globalAltitude on the whole document: the angle is read as its own property (gblA),
    // the altitude can't be read live at all — the saved file has it (image resource 1049)
    function num(d, key) {
        var id = stringIDToTypeID(key);
        if (!d.hasKey(id)) return "";
        var t = d.getType(id);
        if (t == DescValueType.UNITDOUBLE) return d.getUnitDoubleValue(id);
        if (t == DescValueType.DOUBLETYPE) return d.getDouble(id);
        if (t == DescValueType.INTEGERTYPE) return d.getInteger(id);
        return "";
    }
    var angle = "", altitude = "", file = "";
    try {
        var ref = new ActionReference();
        ref.putEnumerated(charIDToTypeID("Dcmn"), charIDToTypeID("Ordn"), charIDToTypeID("Trgt"));
        var d = executeActionGet(ref);
        angle = num(d, "globalAngle");
        altitude = num(d, "globalAltitude");
    } catch (e) { return ""; }
    if (angle === "") {
        try {
            var r2 = new ActionReference();
            r2.putProperty(charIDToTypeID("Prpr"), charIDToTypeID("gblA"));
            r2.putEnumerated(charIDToTypeID("Dcmn"), charIDToTypeID("Ordn"), charIDToTypeID("Trgt"));
            angle = num(executeActionGet(r2), "globalAngle");
        } catch (e2) { }
    }
    try { file = app.activeDocument.fullName.fsName; } catch (e3) { file = ""; }
    return angle + "," + altitude + "," + file;
})();
"""


def document_global_light():
    """{"angle", "altitude"} of Photoshop's active document, or None (no document, an old Photoshop)."""
    try:
        from ps_autotypesetter import photoshop_bridge

        return _parse_global_light(photoshop_bridge.run_jsx(_GLOBAL_LIGHT_GET_JSX, timeout=30))
    except Exception:
        return None


def _parse_global_light(raw):
    """{"angle", "altitude"} from _GLOBAL_LIGHT_GET_JSX's "angle,altitude,file", or None."""
    try:
        from ps_autotypesetter import global_light

        raw = str(raw or "")
        angle, _, rest = raw.partition(",")
        altitude, _, path = rest.partition(",")
        if not angle.strip():
            return None
        if not altitude.strip() and path.strip() and os.path.isfile(path.strip()):
            saved = global_light.read_psd(path.strip())     # the altitude Photoshop won't report live
            if saved:
                altitude = str(saved["altitude"])
        return global_light.clean({"angle": angle, "altitude": altitude or None})
    except Exception:
        return None


def upgrade_style_params(cfg):
    """Add readable captured_params to legacy library entries (hex only).

    Re-deserializes each stored hex stream inside Photoshop (one JSX call) and
    merges the resulting params back into the config copy. Returns the updated
    config; the caller persists it.
    """
    import copy

    cfg = copy.deepcopy(cfg)
    ds = cfg.get("dynamic_settings") or {}
    library = ds.get("layer_style_library") or {}
    if not isinstance(library, dict):
        return {"ok": True, "upgraded": 0, "config": cfg}
    hexes = []
    for entry in library.values():
        fx_hex = str((entry or {}).get("captured_effects_hex") or "")
        if fx_hex and not (entry or {}).get("captured_params"):
            hexes.append(fx_hex)
    if not hexes:
        return {"ok": True, "upgraded": 0, "config": cfg, "note": "No legacy styles to upgrade."}
    if not _photoshop_available():
        return {
            "ok": False,
            "error": "photoshop.api is not installed — open Photoshop with a document to upgrade saved styles.",
        }
    from ps_autotypesetter.layer_styles import extract_params_from_effects_hex

    ensure_com_initialized()
    params_map = extract_params_from_effects_hex(hexes)
    upgraded = 0
    idx = 0
    for entry in library.values():
        fx_hex = str((entry or {}).get("captured_effects_hex") or "")
        if fx_hex and not (entry or {}).get("captured_params"):
            if idx in params_map and params_map[idx]:
                entry["captured_params"] = params_map[idx]
                upgraded += 1
            idx += 1
    result = {"ok": True, "upgraded": upgraded, "config": cfg}
    if not upgraded:
        result["note"] = "Photoshop could not decode the saved styles (is a document open with Photoshop running?). Try again after opening a document."
    return result





def list_psd_groups(psd_path: str = "") -> list:
    if not _photoshop_available():
        return []
    from ps_autotypesetter.custom_layout_exporter import list_psd_group_paths

    try:
        return list_psd_group_paths(psd_path=psd_path)
    except Exception:
        return []


def export_paytable_json(mode: str = "active", psd_path: str = "", group_path: str = "", slot_prefix: str = "@slot") -> dict:
    if not _photoshop_available():
        return {"ok": False, "error": "photoshop.api is not installed."}
    from ps_autotypesetter.custom_layout_exporter import (
        export_paytable_json_from_active_psd,
        export_paytable_json_from_psd_group,
    )

    try:
        if mode == "group":
            if not psd_path or not group_path:
                return {"ok": False, "error": "Choose a PSD and a group path."}
            result = export_paytable_json_from_psd_group(psd_path, group_path, slot_prefix=slot_prefix)
        else:
            result = export_paytable_json_from_active_psd(slot_prefix=slot_prefix)
        return {"ok": True, "result": result}
    except Exception as e:
        return {"ok": False, "error": f"Export failed: {e}"}


def batch_export_groups(
    psd_path: str,
    output_folder: str,
    group_names=None,
    image_format: str = "PNG",
    jpg_quality: int = 90,
    transparent: bool = True,
    suffix: str = "MyExport",
    export_visible_groups: bool = True,
    export_visible_layers: bool = False,
    bottom_to_top: bool = False,
) -> dict:
    if not psd_path or not os.path.isfile(psd_path):
        return {"ok": False, "error": "PSD file not found."}
    if not _photoshop_available():
        return {"ok": False, "error": "photoshop.api is not installed."}
    from ps_autotypesetter.production_features import batch_export_psd_groups

    try:
        exported = batch_export_psd_groups(
            psd_path,
            output_folder,
            group_names=group_names or None,
            image_format=image_format,
            jpg_quality=jpg_quality,
            transparent=transparent,
            suffix=suffix,
            export_visible_groups=export_visible_groups,
            export_visible_layers=export_visible_layers,
            bottom_to_top=bottom_to_top,
        )
        return {"ok": True, "files": exported, "count": len(exported)}
    except Exception as e:
        return {"ok": False, "error": f"Batch export failed: {e}"}


def copy_backup(psd_path: str, backup_folder: str = "") -> dict:
    if not psd_path or not os.path.isfile(psd_path):
        return {"ok": False, "error": "PSD file not found."}
    from ps_autotypesetter.production_features import copy_psd_backup

    try:
        dest = copy_psd_backup(psd_path, backup_folder)
        return {"ok": bool(dest), "path": dest or "Backup failed."}
    except Exception as e:
        return {"ok": False, "error": f"Backup failed: {e}"}


def list_dynamic_templates(folder: str = "") -> list:
    """List JSON template files from the dynamic_pages templates folder."""
    if not folder:
        folder = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "dynamic_pages",
            "templates",
        )
    if not os.path.isdir(folder):
        return []
    return [fn for fn in sorted(os.listdir(folder)) if fn.lower().endswith(".json")]


def _norm_font(name):
    """Normalize a font display/PostScript name for matching (e.g. 'ArialMT' -> 'arial')."""
    from . import paytable_style_common as _style

    return _style.norm_font(name)


def _font_map() -> dict:
    """Normalized font name -> font file path (Windows registry + Fonts folder scan)."""
    from . import paytable_style_common as _style

    return _style.font_map()


def _resolve_font_file(name):
    """Resolve a font display or PostScript name to a font file path, or None."""
    from . import paytable_style_common as _style

    return _style.resolve_font_file(name)


def _registry_fonts() -> list:
    """Windows fonts from the registry as fallback (stable, no Photoshop needed)."""
    fonts = []
    try:
        import re as _re
        import winreg

        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Fonts") as key:
            i = 0
            while True:
                try:
                    name, _val, _typ = winreg.EnumValue(key, i)
                except OSError:
                    break
                i += 1
                clean = _re.sub(r"\s+\((TrueType|OpenType|Type 1)\)$", "", str(name or "")).strip()
                if clean:
                    fonts.append(clean)
    except Exception:
        pass
    return sorted(set(fonts))


def list_system_fonts() -> list:
    """Return the REAL installed system font families, read from the font
    files themselves (Windows Fonts + per-user + Adobe Fonts folders and all
    registry-registered font files).

    Family names come from each file's own ``name`` table, so they are the
    exact display names Photoshop's font menus show -- no Photoshop launch,
    and no registry/PostScript aliases like "Arial MT" that Photoshop cannot
    apply. Symbol/icon faces (Wingdings, Segoe MDL2 Assets, ...) that
    Photoshop hides from its text menus are excluded.
    """
    fonts = []
    try:
        from .paytable_style_common import system_font_list

        fonts = system_font_list()
    except Exception:
        fonts = []
    if not fonts:
        fonts = _registry_fonts()
    out = []
    seen = set()
    for name in fonts:
        if name and str(name).lower() not in seen:
            seen.add(str(name).lower())
            out.append(name)
    return sorted(out)
