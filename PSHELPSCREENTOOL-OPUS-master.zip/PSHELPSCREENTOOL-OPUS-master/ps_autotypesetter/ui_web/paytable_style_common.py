"""Canonical paytable style constants + font resolution shared by BOTH render
paths: the web preview (PIL, ``ps_actions.render_table_outline_preview``) and
the real Photoshop renderer (``dynamic_pages/paytable/renderer.py``).

Everything here is read-only and import-safe (no Photoshop, PIL or openpyxl
dependency) so the two renderers use one source of truth for typography
defaults, size conversions and font-name resolution. The PSD renderer applies
PostScript font names (e.g. ``ArialMT``); the preview resolves the same name to
a system TrueType file so both sides render the same typeface at the same size.
"""

from __future__ import annotations

import os
import re
import struct
import time

# Canonical defaults (mirror the PSD renderer / mapper conventions).
DEFAULT_BODY_FONT = "ArialMT"
DEFAULT_HEADING_FONT = "ArialMT"
DEFAULT_BODY_FONT_SIZE = 30
DEFAULT_HEADING_FONT_SIZE = 72
DEFAULT_ICON_HEIGHT = 120
DEFAULT_STROKE_WIDTH = 0
MIN_FONT_SIZE = 8

# PostScript-style font name -> TrueType fallback used by the preview when the
# exact file cannot be resolved from the Windows registry / Fonts folder scan.
PS_FONT_TTF_FALLBACKS = {
    "arialmt": "arial.ttf",
    "arialboldmt": "arialbd.ttf",
    "arialitalicmt": "ariali.ttf",
    "arialbolditalicmt": "arialbi.ttf",
    "timesnewromanpsmt": "times.ttf",
    "timesnewromanpsboldmt": "timesbd.ttf",
    "timesnewromanpsitalicmt": "timesi.ttf",
    "couriernewpsmt": "cour.ttf",
    "verdana": "verdana.ttf",
    "verdana-bold": "verdanab.ttf",
    "tahoma": "tahoma.ttf",
    "tahomabd": "tahomabd.ttf",
    "consolas": "consola.ttf",
    "consolas-bold": "consolab.ttf",
    "trebuchetms": "trebuc.ttf",
    "trebuchetms-bold": "trebucbd.ttf",
    "comicsansms": "comic.ttf",
    "impact": "impact.ttf",
    "georgia": "georgia.ttf",
    "georgia-bold": "georgiab.ttf",
}


def norm_font(name):
    """Normalize a font display/PostScript name for matching ('ArialMT' -> 'arial')."""
    s = re.sub(r"[^a-z0-9]", "", str(name or "").casefold())
    for suf in ("mt", "ps", "otf", "ttf"):
        if s.endswith(suf) and len(s) > len(suf) + 2:
            s = s[: -len(suf)]
    return s


def font_map() -> dict:
    """Normalized font name -> font file path (Windows registry + Fonts folder scan)."""
    cached = getattr(font_map, "_cache", None)
    if cached is not None:
        return cached
    fonts_dir = os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts")
    mapping = {}
    try:
        import winreg

        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Fonts") as key:
            i = 0
            while True:
                try:
                    name, val, _typ = winreg.EnumValue(key, i)
                except OSError:
                    break
                i += 1
                if not val:
                    continue
                path = val if os.path.isabs(str(val)) else os.path.join(fonts_dir, str(val))
                if os.path.isfile(path):
                    mapping.setdefault(norm_font(str(name)), path)
    except Exception:
        pass
    try:
        for fn in os.listdir(fonts_dir):
            if fn.lower().endswith((".ttf", ".otf", ".ttc")):
                mapping.setdefault(norm_font(os.path.splitext(fn)[0]), os.path.join(fonts_dir, fn))
    except Exception:
        pass
    font_map._cache = mapping
    return mapping


def resolve_font_file(name):
    """Resolve a font display or PostScript name to a font file path, or None.

    Tries the exact normalized key first, then a prefix fuzzy match, then the
    canonical PostScript->TrueType fallback table (e.g. ArialMT -> arial.ttf).
    """
    target = norm_font(name)
    if not target:
        return None
    mapping = font_map()
    if target in mapping:
        return mapping[target]
    for key, path in mapping.items():
        if len(target) >= 4 and (key.startswith(target) or target.startswith(key)):
            return path
    fallback = PS_FONT_TTF_FALLBACKS.get(target)
    if fallback:
        fonts_dir = os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts")
        path = os.path.join(fonts_dir, fallback)
        if os.path.isfile(path):
            return path
    # the page builder's own lookup also knows per-user fonts (AppData\...\Windows\Fonts) and font
    # styles in the name ("Bilderberg Italic"): without it a paytable title fell back to Arial while
    # every other page's heading had the right face. Its Arial fallback doesn't count as found.
    try:
        from PIL import ImageFont
        from ps_autotypesetter import png_builder

        path = getattr(png_builder._load_font(ImageFont, str(name), 24), "path", "") or ""
        if path and os.path.isfile(path) and ("arial" in target or not os.path.basename(path).lower().startswith("arial")):
            return path
    except Exception:
        pass
    return None


def px_to_pt(px):
    """Convert pixel size to Photoshop point size (1:1 at 72 dpi)."""
    try:
        return float(px)
    except Exception:
        return float(DEFAULT_BODY_FONT_SIZE)


def pt_to_px(pt):
    """Convert Photoshop point size to pixels (1:1 at 72 dpi)."""
    try:
        return float(pt)
    except Exception:
        return float(DEFAULT_BODY_FONT_SIZE)


def default_font_size_for(kind: str = "") -> int:
    """Canonical starting font size: heading/wild slots use the heading size."""
    if str(kind or "").casefold() in {"heading", "wild", "title"}:
        return DEFAULT_HEADING_FONT_SIZE
    return DEFAULT_BODY_FONT_SIZE


# Families Photoshop does not offer for text editing (symbol/icon faces).
_ICONISH_FONT_MARKERS = (
    "wingding", "webding", "symbol", "marlett", "mdl2", "segmdl2",
    "segoe icon", "fluent icons", "emoji",
)

_FONT_EXTS = (".ttf", ".otf", ".ttc")

# Known Windows-family -> Photoshop PostScript names (used when the file's
# own PostScript name cannot be read or the family is not installed).
_FAMILY_PS_NAMES = {
    "arial": "ArialMT",
    "arial black": "Arial-Black",
    "times new roman": "TimesNewRomanPSMT",
    "courier new": "CourierNewPSMT",
    "verdana": "Verdana",
    "tahoma": "Tahoma",
    "trebuchet ms": "TrebuchetMS",
    "comic sans ms": "ComicSansMS",
    "impact": "Impact",
    "georgia": "Georgia",
    "consolas": "Consolas",
    "calibri": "Calibri",
    "cambria": "Cambria",
    "candara": "Candara",
    "constantia": "Constantia",
    "corbel": "Corbel",
    "segoe ui": "SegoeUI",
    "segoe print": "SegoePrint",
    "segoe script": "SegoeScript",
    "palatino linotype": "PalatinoLinotype",
    "lucida console": "LucidaConsole",
    "lucida sans unicode": "LucidaSansUnicode",
    "franklin gothic medium": "FranklinGothicMedium",
    "microsoft sans serif": "MicrosoftSansSerif",
    "malgun gothic": "MalgunGothic",
    "gabriola": "Gabriola",
    "bahnschrift": "Bahnschrift",
    "ink free": "InkFree",
    "ebrima": "Ebrima",
    "gadugi": "Gadugi",
    "nirmala ui": "NirmalaUI",
}


def _font_file_candidates() -> list:
    """Deduped paths of every TTF/OTF/TTC installed on the system.

    Scans the Windows Fonts folder, the per-user Fonts folder, Adobe's shared
    Fonts folders and every registry-registered font file (HKLM + HKCU), so
    fonts Photoshop can actually use are found without ever launching it.
    """
    seen = set()
    out = []

    def _add(p):
        try:
            key = os.path.normcase(os.path.normpath(str(p)))
        except Exception:
            return
        if key not in seen:
            seen.add(key)
            out.append(p)

    windir = os.environ.get("WINDIR", r"C:\Windows")
    dirs = [os.path.join(windir, "Fonts")]
    local = os.environ.get("LOCALAPPDATA", "")
    if local:
        dirs.append(os.path.join(local, "Microsoft", "Windows", "Fonts"))
    for adobe in (r"C:\Program Files\Common Files\Adobe\Fonts",
                  r"C:\Program Files (x86)\Common Files\Adobe\Fonts"):
        dirs.append(adobe)
    for d in dirs:
        try:
            for fn in sorted(os.listdir(d)):
                if fn.lower().endswith(_FONT_EXTS):
                    _add(os.path.join(d, fn))
        except Exception:
            pass
    try:
        import winreg

        for root in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
            try:
                with winreg.OpenKey(root, r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Fonts") as key:
                    i = 0
                    while True:
                        try:
                            _n, val, _t = winreg.EnumValue(key, i)
                        except OSError:
                            break
                        i += 1
                        if not val:
                            continue
                        v = str(val)
                        p = v if os.path.isabs(v) else os.path.join(windir, "Fonts", v)
                        if os.path.isfile(p) and p.lower().endswith(_FONT_EXTS):
                            _add(p)
            except Exception:
                pass
    except Exception:
        pass
    return out


def _name_table_ps_name(path):
    """Best-effort PostScript name (nameID 6) from an sfnt ``name`` table.

    Windows fonts occasionally carry non-standard platforms (encoding 0 /
    language-encoded name IDs), so this is a bonus source only: family names
    come from FreeType, which handles every layout."""
    try:
        with open(path, "rb") as _fh:
            _fh.seek(0)
            tag = _fh.read(4)
            base = 0
            if tag == b"ttcf":
                _fh.seek(8)
                num = struct.unpack(">L", _fh.read(4))[0]
                if num < 1:
                    return ""
                _fh.seek(12)
                base = struct.unpack(">L", _fh.read(4))[0]
                _fh.seek(base)
                tag = _fh.read(4)
            if tag not in (b"\x00\x01\x00\x00", b"true", b"OTTO"):
                return ""
            _fh.seek(base + 4)
            num_tables = struct.unpack(">H", _fh.read(2))[0]
            if num_tables > 512:
                return ""
            _fh.seek(base + 12)
            name_off = name_len = None
            for _ in range(num_tables):
                rec = _fh.read(16)
                if len(rec) < 16:
                    break
                if rec[:4] == b"name":
                    _ck, name_off, name_len = struct.unpack(">LLL", rec[4:16])
                    break
            if name_off is None:
                return ""
            _fh.seek(name_off)
            nbuf = _fh.read(min(int(name_len), 131072))
            if len(nbuf) < 6:
                return ""
            _fmt, _cnt, _str_off = struct.unpack(">HHH", nbuf[:6])
            if _fmt not in (0, 1) or _cnt > 4096:
                return ""
            records = []
            for _i in range(_cnt):
                rec = nbuf[6 + _i * 12: 6 + (_i + 1) * 12]
                if len(rec) < 12:
                    break
                records.append(struct.unpack(">HHHHHH", rec))

            def _decode(_nid, _pid, _eid, _lid):
                for _nid2, _pid2, _eid2, _lid2, _ln, _lo in records:
                    if (_nid2 == _nid and _pid2 == _pid and _eid2 == _eid
                            and (_lid2 == _lid or _lid2 == 0)):
                        raw = nbuf[_str_off + _lo: _str_off + _lo + _ln]
                        for enc in ("utf-16-be", "latin-1"):
                            try:
                                got = raw.decode(enc).strip()
                                if got:
                                    return got
                            except Exception:
                                continue
                return ""

            for _pid, _eid in ((3, 1), (3, 10), (1, 0), (3, 0), (0, 3), (0, 0)):
                got = _decode(6, _pid, _eid, 0x409)
                if got:
                    return got
            for _nid2, _pid2, _eid2, _lid2, _ln, _lo in records:
                if _nid2 == 6:
                    raw = nbuf[_str_off + _lo: _str_off + _lo + _ln]
                    for enc in ("utf-16-be", "latin-1"):
                        try:
                            got = raw.decode(enc).strip()
                            if got:
                                return got
                        except Exception:
                            continue
            return ""
    except Exception:
        return ""


def _read_font_meta(path):
    """Read (family, style, PostScript name) of the first face of a
    TTF/OTF/TTC. Family/style come from FreeType (the same engine that
    renders the previews, so dropdown names always match what is drawn);
    the PostScript name is a best-effort parse of the ``name`` table.
    Returns None for files that are not loadable fonts."""
    fam = ""
    style = ""
    try:
        from PIL import ImageFont

        _ff = ImageFont.truetype(path, 10)
        try:
            fam, style = _ff.getname()
        except Exception:
            fam = ""
        fam = str(fam or "").strip()
        style = str(style or "").strip()
    except Exception:
        fam = ""
    psname = _name_table_ps_name(path)
    if not fam and not psname:
        return None
    return (fam, style, psname)


def system_fonts_metadata():
    """``(sorted_families, {family: PostScript name})`` from the actually
    installed font files.

    Family names (from each file's own name table) are the display names
    Photoshop's font menus show; the PostScript names are what Photoshop's
    ``textItem.font`` accepts. Cached briefly so repeated dropdown refreshes
    stay cheap but new installs are picked up.
    """
    cached = getattr(system_fonts_metadata, "_cache", None)
    if cached is not None:
        stamp, value = cached
        if time.time() - stamp < 60:
            return value
    families = {}
    ps_names = {}
    for path in _font_file_candidates():
        meta = _read_font_meta(path)
        if not meta:
            continue
        fam = (meta[0] or "").strip()
        psname = (meta[2] or "").strip()
        if not fam:
            continue
        low = fam.casefold()
        if any(m in low for m in _ICONISH_FONT_MARKERS):
            continue
        families[fam] = families.get(fam, 0) + 1
        if psname:
            ps_names.setdefault(fam.casefold(), psname)
    ps_out = {fam: ps_names.get(fam.casefold(), "") for fam in families}
    value = (sorted(families), ps_out)
    system_fonts_metadata._cache = (time.time(), value)
    return value


def system_font_list() -> list:
    """Sorted, deduped family names of every font file installed on the system."""
    return system_fonts_metadata()[0]


def ps_font_name(name):
    """Best-effort family-name -> PostScript name for direct Photoshop use.

    Matches the exact family first (from the installed font files), then a
    style-suffixed family ("Arial Bold"); otherwise known Windows families
    fall back to a curated table; anything else passes through unchanged
    (Phototshop also accepts PostScript names and PS-bundled display names)."""
    raw = str(name or "").strip()
    if raw and "|" in raw:                              # "Family|Semibold": that face's own PostScript name
        try:
            from .. import fontfaces

            face = fontfaces.face_of(raw)
            if face and face.get("ps"):
                return face["ps"]
        except Exception:
            pass
    if not raw or "|" in raw:
        return raw
    _families, ps_names = system_fonts_metadata()
    hit = ps_names.get(raw.casefold())
    if hit:
        return hit
    base = re.sub(r"\s+(bold|italic|light|regular|semibold|medium|black|thin|heavy)(\s+italic)?$",
                  "", raw, flags=re.IGNORECASE).strip()
    if base and base.casefold() != raw.casefold():
        hit = ps_names.get(base.casefold())
        if hit:
            return hit
        return _FAMILY_PS_NAMES.get(base.casefold(), raw)
    return _FAMILY_PS_NAMES.get(raw.casefold(), raw)
