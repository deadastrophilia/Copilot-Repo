"""MIRA.AI — local LLM assistant for PsHelpScreenTool (Ollama backend).

MIRA is a pure add-on: it reads and writes the same session config the
web UI already uses, so the rendering engine and every existing feature
stay untouched. When Ollama is unreachable, the UI automatically falls
back to the built-in rule-based assistant.

MIRA knows the whole tool: every config key, how rendering works, how
table detection works, and what a build does. The user can either change
settings in plain language ("change the icon folder to ...", "use the
FEATURES sheet only") or ask questions about the tool ("how does table
detection work?") — questions are answered in the message with empty
changes.

Every suggested value is validated against a schema; paths are checked
against the filesystem, so a hallucinated value can never corrupt the
project config.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import tempfile
import time

try:
    import requests
except ImportError:  # pragma: no cover - fallback for minimal environments
    requests = None

OLLAMA_URL = os.environ.get("OLLAMA_URL", "http://localhost:11434")
MODEL = os.environ.get("MIRA_MODEL", "qwen2.5:7b")
_TIMEOUT = 120

OLLAMA_INSTALLER_URL = "https://ollama.com/download/OllamaSetup.exe"
OLLAMA_INSTALL_DIRS = (
    r"%LOCALAPPDATA%\Programs\Ollama",
    r"%PROGRAMFILES%\Ollama",
    r"%PROGRAMFILES(X86)%\Ollama",
)

_MODEL_CACHE_TTL = 30.0
_model_cache = {"t": 0.0, "models": []}


def _installed_models(force=False):
    """Names of the models currently pulled on the local Ollama (briefly cached)."""
    now = time.monotonic()
    if not force and now - _model_cache["t"] < _MODEL_CACHE_TTL:
        return _model_cache["models"]
    lst = []
    try:
        resp = requests.get(f"{OLLAMA_URL}/api/tags", timeout=5)
        if resp.ok:
            lst = [str(m.get("name", "")) for m in resp.json().get("models", [])]
    except Exception:
        pass
    _model_cache["t"] = now
    _model_cache["models"] = lst
    return lst


def _pick_model():
    """Model used for chat: the configured MODEL when installed, otherwise any
    model the local Ollama has, otherwise MODEL itself (chat returns 404 and
    the UI offers the one-click download)."""
    known = _installed_models()
    if MODEL in known:
        return MODEL
    if known:
        return known[0]
    return MODEL


def _mira_model_hint(model_name=None) -> str:
    """Friendly explanation for HTTP 404 (model not pulled yet)."""
    return (
        "MIRA's model is not installed on your Ollama yet (HTTP 404). "
        f"Click “Download AI model” in the MIRA.AI panel to install it automatically, "
        f"or run this yourself: ollama pull {model_name or MODEL}"
    )


# ---------------------------------------------------------------------------
# one-click AI setup: download + install Ollama, then pull the MIRA model
# ---------------------------------------------------------------------------


def find_ollama_exe():
    """Path to ollama.exe, or None when Ollama is not installed."""
    exe = shutil.which("ollama")
    if exe:
        return exe
    for d in OLLAMA_INSTALL_DIRS:
        p = os.path.join(os.path.abspath(os.path.expandvars(d)), "ollama.exe")
        if os.path.isfile(p):
            return p
    return None


def _download_ollama_installer(progress=None):
    """Stream the official Windows installer into a temp folder."""
    if requests is None:
        raise RuntimeError("The requests library is missing — cannot download Ollama.")
    dest_dir = os.path.join(tempfile.gettempdir(), "psh_ai_setup")
    os.makedirs(dest_dir, exist_ok=True)
    dest = os.path.join(dest_dir, "OllamaSetup.exe")
    try:
        with requests.get(OLLAMA_INSTALLER_URL, stream=True, timeout=(30, 60)) as resp:
            if not resp.ok:
                raise RuntimeError(f"Download failed (HTTP {resp.status_code}). "
                                   "Check your internet connection and try again.")
            total = int(resp.headers.get("content-length") or 0)
            done = 0
            with open(dest, "wb") as f:
                for chunk in resp.iter_content(chunk_size=1 << 20):
                    if not chunk:
                        continue
                    f.write(chunk)
                    done += len(chunk)
                    if total and progress:
                        progress("download",
                                 f"Downloading the Ollama installer — {done // 1048576} / {total // 1048576} MB",
                                 10 + 25 * done / total)
        if os.path.getsize(dest) < 1024 * 1024:
            raise RuntimeError("The downloaded installer looks invalid (too small). Please try again.")
        return dest
    except Exception as exc:
        raise RuntimeError(f"Could not download Ollama: {exc}")


def _run_installer(exe_path):
    """Launch the installer silently. It finishes in the background; we detect
    success by polling the Ollama server."""
    flags = ["/VERYSILENT", "/NORESTART"]
    opts = {}
    if os.name == "nt":
        opts["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        subprocess.Popen([exe_path] + flags, **opts)
    except Exception as exc:
        raise RuntimeError(f"Could not start the Ollama installer: {exc}")


def _start_ollama(exe_path):
    """Best-effort start of the Ollama background server when it is not running."""
    try:
        opts = {}
        if os.name == "nt":
            opts["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        subprocess.Popen([exe_path, "serve"], **opts)
    except Exception:
        pass


def _wait_for_ollama(timeout=300, progress=None):
    """Poll until the Ollama HTTP server answers, or the timeout runs out."""
    t0 = time.monotonic()
    last_report = -1
    while time.monotonic() - t0 < timeout:
        if _installed_models(force=True):
            return True
        elapsed = int(time.monotonic() - t0)
        if progress and elapsed != last_report and elapsed % 10 == 0:
            last_report = elapsed
            progress("install", f"Waiting for Ollama to start ({elapsed}s)…", 40)
        time.sleep(1)
    return False


def _pull_model(model, progress=None):
    """POST /api/pull and stream the NDJSON progress lines."""
    if requests is None:
        raise RuntimeError("The requests library is missing — cannot pull the model.")
    try:
        with requests.post(f"{OLLAMA_URL}/api/pull", json={"name": model},
                           stream=True, timeout=(30, 3600)) as resp:
            if not resp.ok:
                raise RuntimeError(f"Could not pull the model (HTTP {resp.status_code}).")
            for line in resp.iter_lines():
                if not line:
                    continue
                try:
                    ev = json.loads(line)
                except Exception:
                    continue
                if ev.get("error"):
                    raise RuntimeError(f"Could not pull the model: {ev['error']}")
                status = str(ev.get("status") or "")
                if status == "success":
                    if progress:
                        progress("pull", f"Model “{model}” is installed.", 100)
                    return
                if ev.get("total"):
                    done = ev.get("completed") or 0
                    pct = 58 + 40 * max(0.0, min(1.0, done / ev["total"]))
                    if progress:
                        progress("pull", status +
                                 (f" — {done // 1048576} MB" if done else ""), pct)
                elif progress:
                    progress("pull", status, 60)
        raise RuntimeError("The model download ended without a success status — please retry.")
    except Exception as exc:
        raise RuntimeError(f"Could not download the model: {exc}")


def setup_ollama_and_model(model=None, progress=None):
    """Full automatic AI setup for this PC: make sure Ollama is installed and
    running, then pull the MIRA model. progress(phase, message, pct) receives
    updates; raises RuntimeError with a human-readable reason on failure."""
    model = model or MODEL
    if not _installed_models(force=True):
        exe = find_ollama_exe()
        if exe is None:
            if progress:
                progress("download", "Downloading the Ollama installer (~700 MB)…", 5)
            exe = _download_ollama_installer(progress)
            if progress:
                progress("install", "Installing Ollama — allow the Windows prompt…", 35)
            _run_installer(exe)
        else:
            if progress:
                progress("install", "Starting the already-installed Ollama…", 35)
            _start_ollama(exe)
        if not _wait_for_ollama(progress=progress):
            raise RuntimeError(
                "Ollama did not come online. Open the Ollama app once (Start menu) "
                "and then click the button again."
            )
    known = _installed_models(force=True)
    if model in known:
        if progress:
            progress("done", f"All set — model “{model}” is ready.", 100)
        return f"Ollama is running and “{model}” is installed. MIRA is ready to use."
    if progress:
        progress("pull", f"Downloading the MIRA model “{model}”… (about 4.7 GB, one-time download)", 58)
    _pull_model(model, progress)
    return f"Done — Ollama installed and model “{model}” downloaded. MIRA is ready to use."

_HEX_RE = re.compile(r"^#[0-9a-fA-F]{6}$")

_ALIGNMENTS = ["left", "center", "right"]
_STYLES = ["regular", "bold", "italic", "bold italic"]
_BUILD_OUTPUTS = ["both", "psd", "png"]
_BG_MODES = ["stretch", "fit", "fill", "center"]
_PRESETS = ["Full HD", "4K", "PS4", "PS5", "Mobile", "Custom"]

# Keys MIRA is allowed to touch, with validation rules. Anything else the
# model suggests is discarded, so a hallucinated key can never corrupt the
# project config.
SCHEMA = {
    # ---- files & output -------------------------------------------------
    "excel_path": {"type": "excelpath", "desc": "path to the Excel workbook to render (must exist, .xlsx/.xlsm)"},
    "icon_folder": {"type": "dirpath", "desc": "folder containing symbol icon PNGs (must exist)"},
    "bg_path": {"type": "filepath", "desc": "path to the background image file (PNG/JPG; a folder is accepted too)"},
    "output_dir": {"type": "dirpath", "desc": "folder where built files are saved (must exist)"},
    "safe_backup_folder": {"type": "dirpath", "desc": "backup destination when safe_backup is on (must exist)"},
    "output_name": {"type": "string", "desc": "output file name without extension"},
    "png_suffix": {"type": "string", "desc": "suffix appended to PNG file names"},
    "overwrite_existing": {"type": "bool", "desc": "overwrite existing PSD/PNG files instead of asking"},
    "safe_backup": {"type": "bool", "desc": "copy existing outputs to safe_backup_folder before overwriting"},
    "build_output": {"type": "enum", "values": _BUILD_OUTPUTS, "desc": "what to build: 'both', 'psd' or 'png'"},

    # ---- canvas ----------------------------------------------------------
    "canvas_preset": {"type": "enum", "values": _PRESETS, "desc": "canvas size preset name"},
    "c_width": {"type": "int", "min": 320, "max": 7680, "desc": "canvas width in px"},
    "c_height": {"type": "int", "min": 320, "max": 7680, "desc": "canvas height in px"},
    "c_resolution": {"type": "int", "min": 72, "max": 600, "desc": "canvas resolution in DPI"},
    "margin_x": {"type": "int", "min": 0, "max": 2000, "desc": "left/right margin in px"},
    "max_col_limit": {"type": "int", "min": 1, "max": 30, "desc": "max columns per table row"},

    # ---- heading ---------------------------------------------------------
    "h_font": {"type": "string", "desc": "heading font family name (e.g. 'Impact')"},
    "h_font_style": {"type": "enum", "values": _STYLES, "desc": "heading style"},
    "h_bold": {"type": "bool", "desc": "heading bold"},
    "h_size": {"type": "int", "min": 6, "max": 220, "desc": "heading font size in px"},
    "h_rgb": {"type": "hexcolor", "desc": "heading text color as #RRGGBB"},
    "h_icon_h": {"type": "int", "min": 8, "max": 400, "desc": "height of heading icons in px"},

    # ---- body ------------------------------------------------------------
    "b_font": {"type": "string", "desc": "body font family name (e.g. 'Georgia')"},
    "b_font_style": {"type": "enum", "values": _STYLES, "desc": "body style"},
    "b_size": {"type": "int", "min": 6, "max": 160, "desc": "body font size in px"},
    "b_rgb": {"type": "hexcolor", "desc": "body text color as #RRGGBB"},
    "b_icon_h": {"type": "int", "min": 8, "max": 400, "desc": "height of body icons in px"},

    # ---- layout ----------------------------------------------------------
    "line_spacing": {"type": "float", "min": 0.8, "max": 2.0, "desc": "body line spacing multiplier"},
    "para_spacing": {"type": "int", "min": 0, "max": 300, "desc": "space between paragraphs in px"},
    "gap_px": {"type": "int", "min": 0, "max": 300, "desc": "gap between text columns in px"},
    "heading_top_margin": {"type": "int", "min": 0, "max": 2000, "desc": "space above the heading in px"},
    "heading_to_body_gap": {"type": "int", "min": 0, "max": 500, "desc": "gap between heading and body in px"},
    "bottom_margin": {"type": "int", "min": 0, "max": 2000, "desc": "bottom margin in px"},
    "continued_gap": {"type": "int", "min": 0, "max": 300, "desc": "gap between continued pages in px"},
    "alignment": {"type": "enum", "values": _ALIGNMENTS, "desc": "global text alignment"},
    "heading_icon_gap": {"type": "int", "min": 0, "max": 200, "desc": "gap between heading text and its icon"},
    "icon_gap_left": {"type": "int", "min": 0, "max": 200, "desc": "space left of inline icons"},
    "icon_gap_right": {"type": "int", "min": 0, "max": 200, "desc": "space right of inline icons"},
    "icon_y_offset": {"type": "int", "min": -200, "max": 200, "desc": "vertical offset of inline icons in px"},

    # ---- background ------------------------------------------------------
    "bg_source": {"type": "enum", "values": ["image", "color"], "desc": "background: 'image' file or solid 'color'"},
    "bg_color": {"type": "hexcolor", "desc": "solid background color as #RRGGBB"},
    "bg_mode": {"type": "enum", "values": _BG_MODES, "desc": "background image fit mode"},

    # ---- rendering -------------------------------------------------------
    "enable_tables": {"type": "bool", "desc": "render detected Excel tables as styled tables"},
    "render_all_pages": {"type": "bool", "desc": "render every sheet; false = only the selected sheets"},
    "selected_sheets": {"type": "sheets", "desc": "list of Excel sheet names to render (only those)"},
    "heading_png_mode": {"type": "bool", "desc": "render headings as pre-made PNG images instead of text"},
    "icon_simple_mode": {"type": "bool", "desc": "use simple icon rendering (faster)"},
    "body_icons_use_original_size": {"type": "bool", "desc": "keep icons at their original size instead of scaling"},
    "performance_mode": {"type": "bool", "desc": "reduce quality for faster previews"},
    "headless_mode": {"type": "bool", "desc": "build PSD files without Photoshop via PSAPI (new builds only, ~2-5s per page)"},
    "update_mode": {"type": "bool", "desc": "only re-render pages that changed since the last build"},

    # ---- structured settings (JSON objects) -----------------------------
    "keyword_colors": {"type": "object", "desc": "map of keyword -> '#RRGGBB' to colorize body text"},
    "icon_mappings": {"type": "object", "desc": "map of keyword -> icon file name (without extension)"},
    "icon_size_overrides": {"type": "intmap", "desc": "map of keyword -> icon height in px"},
    "heading_style": {"type": "object", "desc": "heading layer-style settings (stroke, shadow, etc.)"},
    "body_style": {"type": "object", "desc": "body layer-style settings (stroke, shadow, etc.)"},
    "icon_style": {"type": "object", "desc": "icon layer-style settings"},
    "table_style": {"type": "object", "desc": "table rendering style settings"},
    "dynamic_settings": {"type": "object", "desc": "advanced dynamic rendering tweaks"},
    "alignment_settings": {"type": "alignsettings", "desc": "per-element alignment overrides"},
    "page_overrides": {"type": "pageoverrides", "desc": "per-sheet typography: map of sheet name -> {h_font, h_size, h_rgb, b_font, b_size, b_rgb}"},
}

_PAGE_STYLE_KEYS = {
    "h_font": "string", "h_size": "int", "h_rgb": "hexcolor",
    "b_font": "string", "b_size": "int", "b_rgb": "hexcolor",
}

_OBJ_KEYS = {"keyword_colors", "icon_mappings", "icon_size_overrides", "heading_style",
             "body_style", "icon_style", "table_style", "dynamic_settings"}


def _clamp(value, lo, hi):
    return max(lo, min(hi, value))


def _sanitize(key, value, valid_sheets):
    """Validate/coerce a model suggestion for one config key. Returns the
    cleaned value or None when it must be dropped."""
    rule = SCHEMA.get(key)
    if not rule:
        return None
    kind = rule["type"]

    if kind in ("excelpath", "dirpath", "filepath"):
        s = str(value or "").strip()
        if not s:
            return None
        if kind == "excelpath":
            exists = os.path.isfile(s)
        elif kind == "filepath":
            exists = os.path.isfile(s) or os.path.isdir(s)
        else:
            exists = os.path.isdir(s)
        if not exists:
            return None
        if kind == "excelpath" and not s.lower().endswith((".xlsx", ".xlsm")):
            return None
        return s

    if kind == "string":
        if not isinstance(value, str) or not value.strip():
            return None
        return value.strip()[:120]
    if kind == "int":
        try:
            v = int(round(float(value)))
        except (TypeError, ValueError):
            return None
        return _clamp(v, rule["min"], rule["max"])
    if kind == "float":
        try:
            v = float(value)
        except (TypeError, ValueError):
            return None
        return round(_clamp(v, rule["min"], rule["max"]), 2)
    if kind == "bool":
        return bool(value) if isinstance(value, bool) else None
    if kind == "enum":
        s = str(value or "").strip().lower()
        return s if s in rule["values"] else None
    if kind == "hexcolor":
        s = str(value or "").strip()
        if not _HEX_RE.match(s):
            return None
        return s.upper()
    if kind == "sheets":
        if not isinstance(value, (list, str)):
            return None
        names = [str(x).strip() for x in value] if isinstance(value, list) else [str(value).strip()]
        valid = {str(s).strip() for s in valid_sheets}
        kept = [n for n in names if n in valid]
        return kept if kept else None
    if kind == "intmap":
        if not isinstance(value, dict):
            return None
        out = {}
        for k, v in value.items():
            try:
                out[str(k).strip()[:120]] = _clamp(int(round(float(v))), 8, 400)
            except (TypeError, ValueError):
                continue
        return out or None
    if kind == "alignsettings":
        if not isinstance(value, dict):
            return None
        out = {}
        for k in ("use_global",):
            if k in value and isinstance(value[k], bool):
                out[k] = value[k]
        for k in ("heading", "body", "table", "bottom", "paytable_notes"):
            if k in value and str(value[k]).strip().lower() in _ALIGNMENTS:
                out[k] = str(value[k]).strip().lower()
        if not out:
            return None
        return out
    if kind == "pageoverrides":
        if not isinstance(value, dict) or not value:
            return None
        out = {}
        valid = {str(s).strip() for s in valid_sheets}
        for sheet, sty in value.items():
            sname = str(sheet).strip()
            if valid and sname not in valid:
                continue
            if not isinstance(sty, dict):
                continue
            clean = {}
            for k, v in sty.items():
                if k not in _PAGE_STYLE_KEYS:
                    continue
                cleaned = _sanitize(k, v, [])
                if cleaned is not None:
                    clean[k] = cleaned
            if clean:
                out[sname] = clean
        return out or None
    if kind == "object":
        if not isinstance(value, dict):
            return None
        try:
            json.dumps(value)
        except (TypeError, ValueError):
            return None
        only_hex = key == "keyword_colors"
        out = {}
        for k, v in value.items():
            if only_hex:
                s = str(v or "").strip()
                if _HEX_RE.match(s):
                    out[str(k)[:120]] = s.upper()
                continue
            if isinstance(v, bool):
                out[str(k)[:120]] = v
            elif isinstance(v, (int, float)):
                out[str(k)[:120]] = v
            elif isinstance(v, str):
                s = v.strip()
                if _HEX_RE.match(s):
                    out[str(k)[:120]] = s.upper()
                elif s:
                    out[str(k)[:120]] = s[:120]
        return out if out else None
    return None


def mira_available() -> dict:
    """Report whether Ollama is running, which models are present, and whether
    the one-click setup can be offered in the UI."""
    if requests is None:
        return {"ok": False, "error": "requests library not available", "models": [],
                "model": MODEL, "can_setup": False, "ollama": False}
    try:
        resp = requests.get(f"{OLLAMA_URL}/api/tags", timeout=5)
        models = [str(m.get("name", "")) for m in resp.json().get("models", [])] if resp.ok else []
    except Exception as exc:
        return {"ok": False, "error": str(exc), "models": [], "model": MODEL,
                "can_setup": True, "ollama": False}
    if not resp.ok:
        return {"ok": False, "error": f"HTTP {resp.status_code}", "models": [], "model": MODEL,
                "can_setup": True, "ollama": False}
    if not models:
        return {"ok": False, "error": "no models pulled", "models": [], "model": MODEL,
                "can_setup": True, "ollama": True, "model_missing": True}
    active = MODEL if MODEL in models else models[0]
    return {"ok": True, "models": models, "model": active, "can_setup": True, "ollama": True,
            "model_missing": MODEL not in models}


def _rgb_str(value):
    if isinstance(value, list) and len(value) == 3:
        return "#{:02X}{:02X}{:02X}".format(int(value[0] & 255), int(value[1] & 255), int(value[2] & 255))
    return value or "unset"


def _config_snapshot(config: dict) -> str:
    """Human-readable one-liners of the current settings, for the prompt."""
    def on(key):
        return "on" if config.get(key) else "off"
    lines = [
        f"excel={config.get('excel_path') or '(not set)'}",
        f"icon folder={config.get('icon_folder') or '(not set)'}",
        f"output dir={config.get('output_dir') or '(not set)'}, name={config.get('output_name') or '(not set)'}",
        f"heading: font={config.get('h_font') or 'unset'}, style={config.get('h_font_style') or 'regular'}, "
        f"bold={on('h_bold')}, size={config.get('h_size')}px, color={_rgb_str(config.get('h_rgb'))}",
        f"body: font={config.get('b_font') or 'unset'}, style={config.get('b_font_style') or 'regular'}, "
        f"size={config.get('b_size')}px, color={_rgb_str(config.get('b_rgb'))}",
        f"line spacing={config.get('line_spacing') or 1.1}, paragraph spacing={config.get('para_spacing') or 14}, "
        f"alignment={config.get('alignment') or 'center'}",
        f"canvas={config.get('canvas_preset') or 'custom'} {config.get('c_width')}x{config.get('c_height')} "
        f"@{config.get('c_resolution') or 72}dpi",
        f"background: source={config.get('bg_source') or 'image'}, mode={config.get('bg_mode') or 'stretch'}, "
        f"color={_rgb_str(config.get('bg_color'))}",
        f"tables rendering={'on' if config.get('enable_tables') else 'off'}, "
        f"render_all_pages={on('render_all_pages')}, selected sheets={config.get('selected_sheets') or '(all)'}",
        f"build output={config.get('build_output') or 'both'}, performance_mode={on('performance_mode')}, "
        f"update_mode={on('update_mode')}, overwrite={on('overwrite_existing')}",
        f"heading image mode={on('heading_png_mode')}, icon simple mode={on('icon_simple_mode')}",
    ]
    return "\n".join(lines)


def _knowledge() -> str:
    """Compact but complete description of the tool, injected into the
    system prompt so MIRA can answer questions and change anything."""
    return (
        "ABOUT THE TOOL:\n"
        "PsHelpScreenTool renders slot-game 'help screen' pages. Each sheet of an Excel workbook "
        "(in any order: features, paytable, bingo rules, etc.) becomes one page of a full-canvas "
        "Photoshop document (PSD) and PNG export. Text with special keywords triggers inline icon "
        "insertion (e.g. a symbol name in square brackets becomes its PNG from the icon folder). "
        "The build pipeline: read Excel -> detect structured tables (bordered grids; the detector "
        "also accepts compact single-content-column grids) -> lay out heading/body/tables on the "
        "canvas -> drive Photoshop via COM (or direct PNG rendering) -> save PSD + PNG.\n"
        "WORKFLOW:\n"
        "1. Project: pick the Excel file (excel_path) and icon folder (icon_folder). "
        "2. Scan: analyzes the workbook; reports sheets, missing icons, and drops page selections "
        "that don't exist. 3. Style: heading/body fonts, sizes, colors, spacing, alignment, "
        "background, canvas size. 4. Pages: choose which sheets to render (selected_sheets; empty "
        "means all, render_all_pages must stay true). 5. Build: creates the PSD/PNG in output_dir "
        "under output_name; overwrite_existing controls replacing files; safe_backup copies old "
        "outputs to safe_backup_folder first; update_mode re-renders only changed pages.\n"
        "DETAILS:\n"
        "- keyword_colors: map like {\"WILD\": \"#FFD700\"} colorizes the keyword wherever it appears.\n"
        "- icon_mappings: map like {\"WILD\": \"wild_icon\"} picks the icon file for a keyword.\n"
        "- icon_size_overrides: per-keyword icon heights in px.\n"
        "- heading_style / body_style / icon_style / table_style: Photoshop layer-style settings "
        "(stroke_enabled, stroke_size, stroke_rgb, shadow_enabled, shadow_rgb, shadow_opacity, "
        "shadow_distance, shadow_size, shadow_angle, shadow_spread, paste_copied_style, "
        "copied_style_name, captured_effects_hex).\n"
        "- dynamic_settings: advanced rendering tweaks (safe to leave untouched).\n"
        "- alignment_settings: per-element overrides {use_global, heading, body, table, bottom, "
        "paytable_notes} each left/center/right.\n"
        "- canvas presets: Full HD (1920x1080), 4K (3840x2160), PS4 (1920x1080), PS5 (3840x2160), "
        "Mobile (1080x1920), or Custom via c_width/c_height.\n"
        "- Session config is saved between runs in the user profile; MIRA edits are applied "
        "immediately and take effect on the next build.\n"
        "BEHAVIOR:\n"
        "- If the user asks a question or wants an explanation (about the tool, a setting, the "
        "pipeline, a field, etc.), answer thoroughly in \"message\" and return EMPTY changes.\n"
        "- If the user wants a change, map it to config keys and return them in changes; when a "
        "suggested value is unusable (e.g. a path that does not exist), omit it and say so in message.\n"
        "- For file/folder changes, return the FULL path exactly as the user typed it.\n"
        "- Never invent sheet names: only use names from the available sheets list.\n"
        "- Use the action field ONLY when the user wants something executed NOW: "
        "action=\"build\" for 'build', 'render', 'generate', 'make the PSD/PNG', 'create the help "
        "screen', 'produce the pages'; action=\"scan\" for 'scan', 'analyze the Excel'. "
        "You never perform the action yourself — you only request it; the tool executes it and "
        "reports progress. A page-rendering request ('render only the FEATURES page') means "
        "changes (selected_sheets) AND action=\"build\".\n"
        "HONESTY RULES (never hallucinate):\n"
        "- You cannot run builds, open Photoshop, or see the filesystem; never claim a build "
        "succeeded or failed — you only set config and request actions.\n"
        "- Use the EXACT value the user asked for (font names, sizes, colors, paths). If the user "
        "does not give a number/name, keep the current value or leave the key out — do not invent.\n"
        "- When the user names a font, use exactly that name even if unsure it is installed; "
        "prefer names from INSTALLED FONTS when the user is vague.\n"
        "- If you cannot do what the user asks (unknown feature, impossible request), say so "
        "clearly in message with empty changes and no action.\n"
    )


def _schema_hint() -> str:
    return "\n".join(f"- {key}: {rule['desc']}" for key, rule in SCHEMA.items())


def mira_apply(config: dict, command: str, sheet_names=None, fonts=None, history=None) -> dict:
    """Ask MIRA to translate a plain-language request into config changes,
    a question answer, and/or an executable action ("build" | "scan").

    history: recent [{role, content}] turns for conversational context.
    Returns the same shape as the rule-based interpreter so the web UI
    handles both identically: {message, changes, config, action, ...}.
    """
    sheet_names = [str(s) for s in (sheet_names or [])]
    fonts = [str(f) for f in (fonts or [])]
    snapshot = _config_snapshot(config)
    sheets_line = ", ".join(sheet_names) if sheet_names else "(no Excel loaded yet)"
    fonts_line = ", ".join(fonts) if fonts else "(font list unavailable)"
    history_block = ""
    if history:
        turns = []
        for turn in history[-10:]:
            content = str(turn.get("content") or "").strip().replace("\n", " ")[:400]
            if content:
                turns.append(f"{turn.get('role')}: {content}")
        if turns:
            history_block = "RECENT CONVERSATION (short-term memory — you may reference it):\n" + "\n".join(turns) + "\n"

    system = (
        "You are MIRA.AI, the local assistant inside PsHelpScreenTool, a tool that renders "
        "slot-machine help screens from Excel workbooks into Photoshop documents.\n"
        "A user gives you a plain-language request. You answer with ONLY a JSON object of the "
        "form {\"changes\": {\"key\": value}, \"message\": \"...\", \"action\": null|\"build\"|\"scan\"}.\n"
        "Rules:\n"
        "- Whenever the user explicitly asks for a value, include that config key in changes "
        "(with the exact requested value), even if the current config already looks similar.\n"
        "- Use the exact values the user asked for; never invent numbers, names, colors or paths "
        "they did not give. Map color words to their standard hex (gold -> #FFD700, red -> #FF0000, "
        "blue -> #0000FF, white -> #FFFFFF, black -> #000000, green -> #008000, yellow -> #FFFF00, "
        "purple -> #800080, orange -> #FFA500).\n"
        "- Only include keys the user asked about; leave everything else out.\n"
        "- When the user refers back to something from RECENT CONVERSATION ('also make it bold', "
        "'same for the body', 'apply that to all pages'), carry the earlier intent into changes.\n"
        "- When the request is a question (how does X work, what does X do, explain ...), set "
        "changes to {}, action to null and answer fully in message.\n"
        "- Per-page requests ('make the PAYTABLE page heading gold') map to page_overrides: "
        "{\"PAYTABLE\": {\"h_rgb\": \"#FFD700\"}} using exact sheet names from AVAILABLE SHEETS.\n"
        f"{history_block}"
        f"{_knowledge()}\n"
        f"AVAILABLE CONFIG KEYS:\n{_schema_hint()}\n"
        f"INSTALLED FONTS: {fonts_line}\n"
        f"CURRENT CONFIG:\n{snapshot}\n"
        f"AVAILABLE SHEETS: {sheets_line}\n"
        "Example change: user: \"make the heading Impact, 72px, gold\" -> "
        "{\"changes\": {\"h_font\": \"Impact\", \"h_size\": 72, \"h_rgb\": \"#FFD700\"}, "
        "\"message\": \"Heading set to Impact 72px in gold.\", \"action\": null}\n"
        "Example build: user: \"render only the FEATURES page now\" -> "
        "{\"changes\": {\"selected_sheets\": [\"FEATURES\"], \"render_all_pages\": false}, "
        "\"message\": \"Rendering only the FEATURES page.\", \"action\": \"build\"}\n"
        "Example per-page: user: \"make the PAYTABLE heading gold\" -> "
        "{\"changes\": {\"page_overrides\": {\"PAYTABLE\": {\"h_rgb\": \"#FFD700\"}}}, "
        "\"message\": \"PAYTABLE heading set to gold.\", \"action\": null}\n"
        "Example question: user: \"what does enable_tables do?\" -> "
        "{\"changes\": {}, \"message\": \"enable_tables turns the detection of bordered Excel "
        "tables on or off...\", \"action\": null}\n"
        "Answer JSON: {\"changes\": {\"key\": value}, \"message\": \"one short sentence ...\", "
        "\"action\": null|\"build\"|\"scan\"}"
    )

    model = _pick_model()
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": command},
        ],
        "format": "json",
        "stream": False,
        "options": {"temperature": 0.2},
    }
    if requests is None:
        return {"message": "MIRA unavailable (requests library missing).", "changes": {}, "config": config}
    try:
        resp = requests.post(f"{OLLAMA_URL}/api/chat", json=payload, timeout=_TIMEOUT)
        if not resp.ok:
            if resp.status_code == 404:
                return {"message": _mira_model_hint(model), "changes": {}, "config": config, "mira_hint": True}
            return {"message": f"MIRA error: HTTP {resp.status_code}.", "changes": {}, "config": config}
        content = (resp.json().get("message") or {}).get("content") or "{}"
    except Exception as exc:
        return {"message": f"MIRA unavailable: {exc}. Using the built-in assistant instead.",
                "changes": {}, "config": config}

    try:
        parsed = json.loads(content)
        if not isinstance(parsed, dict):
            raise ValueError("not an object")
    except Exception:
        return {"message": "MIRA did not return valid JSON — nothing was changed.", "changes": {},
                "config": config}

    changes = {}
    notes = []
    cfg = dict(config)
    for key, value in (parsed.get("changes") or {}).items():
        cleaned = _sanitize(key, value, sheet_names)
        if cleaned is None:
            notes.append(key.replace("_", " ") + " (rejected — invalid value or missing file/folder)")
            continue
        changes[key] = cleaned
        cfg[key] = cleaned

    action = parsed.get("action")
    action = action if action in ("build", "scan") else None

    message = str(parsed.get("message") or "").strip() or ("Applied " + ", ".join(changes) if changes
                                                           else "I did not find anything to change.")
    if notes:
        message += "\nNote: " + "; ".join(notes) + "."
    result = {"message": message, "changes": changes, "config": cfg, "action": action}
    return result


# ---------------------------------------------------------------------------
# project-folder auto-setup ("here is my main folder ...")
# ---------------------------------------------------------------------------

_EXCEL_EXT = {".xlsx", ".xlsm"}
_IMG_EXT = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tif", ".tiff"}
_SKIP_DIRS = {"$recycle.bin", "system volume information", "__pycache__", ".git", ".svn"}
_SKIP_OUTPUT = {"output", "out", "exports", "build", "psd", "png", "renders"}
_BG_DIR_NAMES = {"bg", "background", "backgrounds", "bg images", "bgs"}
_BG_IMG_EXT = (".png", ".jpg", ".jpeg", ".bmp", ".gif")
_PATH_RE = re.compile(r"[A-Za-z]:[\\/][^\s'\";,]+")
_QUOTED_PATH_RE = re.compile(r"['\"]([A-Za-z]:[\\/][^'\"]*)['\"]")
_AFFIRM_RE = re.compile(
    r"^\s*(yes|yeah|yep|ya|y|ok|okay|sure|apply|confirm|proceed|go ahead|go|do it|do that|"
    r"looks good|looks fine|fine|approved|accepted|great|perfect|please)\b[^.]*\.?$",
    re.IGNORECASE,
)


def extract_folder_path(command: str):
    """Return a plausible folder path from a chat message, or None."""
    m = _QUOTED_PATH_RE.search(command)
    if m:
        return m.group(1).rstrip("\\/")
    m = _PATH_RE.search(command)
    if m:
        return m.group(0).rstrip("\\/")
    return None


def is_affirmative(command: str) -> bool:
    return bool(_AFFIRM_RE.match(command.strip()))


def wants_build(command: str) -> bool:
    return bool(re.search(r"\b(build|render|generate|create the (psd|png)s?)\b", command, re.IGNORECASE))


def _score_excels(candidates):
    """Rank Excel candidates best-first: (score, abs_path) pairs."""
    scored = []
    for p in candidates:
        name = os.path.basename(p).lower()
        score = 0
        if "rules" in name:
            score += 3
        if "help" in name or "helptext" in name:
            score += 2
        if name.startswith(("~$", "~")):
            continue
        try:
            score += min(os.path.getsize(p) // 100000, 5)
        except OSError:
            pass
        scored.append((score, p))
    scored.sort(key=lambda x: x[0], reverse=True)
    return scored


def _best_excel(candidates):
    scored = _score_excels(candidates)
    if not scored:
        return None
    return scored[0][1]


def _pick_background_file(candidates):
    """Pick the single background image FILE to use from the candidates found
    during the folder walk. Priority:

      1. a file named exactly bg.<ext> / background.<ext> (case-insensitive)
      2. a file inside a folder named bg / background / backgrounds / bgs
      3. any file whose name starts with bg or background
      4. any remaining image candidate (e.g. any image inside a BG folder)

    Returns a full path, or None when no candidate exists.
    """
    if not candidates:
        return None

    def _rank(p):
        base = os.path.splitext(os.path.basename(p))[0].lower()
        parent = os.path.basename(os.path.dirname(p)).lower()
        ext = os.path.splitext(p)[1].lower()
        in_bg_dir = parent in _BG_DIR_NAMES
        exact_name = base in ("bg", "background")
        starts_bg = base.startswith(("bg", "background"))
        ext_ok = ext in _BG_IMG_EXT
        if exact_name:
            cls = 0
        elif in_bg_dir:
            cls = 1
        elif starts_bg:
            cls = 2
        else:
            cls = 3
        return (cls, 0 if ext_ok else 1, p.lower())

    return min(candidates, key=_rank)


def detect_project(folder: str) -> dict:
    """Deterministically discover a project layout inside a main folder:
    Excel workbook(s), icon folder, background, output folder (proposed).

    Pure filesystem logic — no LLM involved, so the user gets real facts.
    """
    folder = os.path.abspath(folder)
    if not os.path.isdir(folder):
        return {"error": f"Folder not found: {folder}"}

    excel_files, bg_files, psd_files, png_counts = [], [], [], {}
    root_depth = folder.rstrip("\\/").count(os.sep)
    for dirpath, dirnames, filenames in os.walk(folder):
        depth = dirpath.count(os.sep) - root_depth
        if depth >= 3:
            dirnames[:] = []
            continue
        dirnames[:] = [d for d in dirnames
                       if d.lower() not in _SKIP_DIRS and not d.startswith((".", "$"))]
        for fn in filenames:
            ext = os.path.splitext(fn)[1].lower()
            if ext in _EXCEL_EXT and not fn.startswith("~$"):
                excel_files.append(os.path.join(dirpath, fn))
            elif ext == ".psd" and not fn.startswith("~$"):
                psd_files.append(os.path.join(dirpath, fn))
            elif ext in _IMG_EXT:
                low = fn.lower()
                parent = os.path.basename(dirpath).lower()
                if low.startswith(("bg", "background")) or parent in _BG_DIR_NAMES:
                    bg_files.append(os.path.join(dirpath, fn))
                png_counts[dirpath] = png_counts.get(dirpath, 0) + 1

    excel_path = _best_excel(excel_files)
    excel_candidates = [p for _, p in _score_excels(excel_files)]

    icon_folder = None
    best_score = 0
    for d, count in png_counts.items():
        name = os.path.basename(d).lower()
        score = count
        if "icon" in name or "symbol" in name:
            score += 1000
        if "asset" in name:
            score += 300
        if d == folder:
            score += 500
        if score > best_score:
            best_score, icon_folder = score, d
    if icon_folder is None and png_counts:
        icon_folder = max(png_counts, key=png_counts.get)

    bg_path = _pick_background_file(bg_files)

    output_dir, will_create = None, False
    for d in os.listdir(folder):
        if d.lower() in _SKIP_OUTPUT and os.path.isdir(os.path.join(folder, d)):
            output_dir = os.path.join(folder, d)
            break
    if output_dir is None:
        output_dir = os.path.join(folder, "output")
        will_create = not os.path.isdir(output_dir)

    return {
        "folder": folder,
        "excel_path": excel_path,
        "excel_candidates": excel_candidates,
        "icon_folder": icon_folder,
        "bg_path": bg_path,
        "output_dir": output_dir,
        "output_will_be_created": will_create,
        "excel_count": len(excel_files),
        "bg_count": len(bg_files),
        "psd_files": psd_files,
    }


def _style_report(config: dict) -> str:
    def rgb(key):
        return _rgb_str(config.get(key))
    return (
        f"heading: {config.get('h_font') or 'ArialMT'} "
        f"{config.get('h_size') or 60}px {rgb('h_rgb')} "
        f"({config.get('h_font_style') or 'regular'})"
        f" | body: {config.get('b_font') or 'ArialMT'} "
        f"{config.get('b_size') or 30}px {rgb('b_rgb')} "
        f"({config.get('b_font_style') or 'regular'})"
    )


def _proposal_system_prompt(detection: dict, config: dict, sheets: list, fonts: list) -> str:
    sheets_line = ", ".join(str(s) for s in sheets) if sheets else "(none found)"
    return (
        "You are MIRA.AI inside PsHelpScreenTool. The user pointed you at a main project folder and "
        "the tool has ALREADY detected the layout. Your job: explain the plan and ask for "
        "confirmation. Reply with ONLY JSON: {\"message\": \"...\", \"changes\": {\"key\": value}}.\n"
        "DETECTED LAYOUT (facts, do not change them):\n"
        f"- main folder: {detection['folder']}\n"
        f"- excel workbook: {detection['excel_path'] or 'none found'}\n"
        f"- icon folder: {detection['icon_folder'] or 'none found'}\n"
        f"- background: {detection['bg_path'] or 'none found'}\n"
        f"- output folder: {detection['output_dir']}"
        f"{' (will be created)' if detection['output_will_be_created'] else ''}\n"
        f"- pages found: {len(sheets)} — {sheets_line}\n"
        f"- canvas that will be used: {config.get('canvas_preset') or 'Custom'} "
        f"{config.get('c_width')}x{config.get('c_height')}\n"
        f"- styles that will be used: {_style_report(config)}\n"
        "TASK:\n"
        "1. In \"message\", summarize the plan: the paths that will be set, how many pages were "
        "found (list the page names), the canvas size, and the heading/body font, color, size and "
        "style that will be used. Keep it compact and readable, then end with a question asking "
        "the user to confirm.\n"
        "2. In \"changes\", include EVERY style/layout tweak the user explicitly asked for in "
        "their message (e.g. 'gold bold headings' -> {\"h_rgb\": \"#FFD700\", \"h_bold\": true}). "
        "This is mandatory — if the user mentions any color, font, size or style preference, it "
        "MUST appear in changes. NEVER put paths in changes — the tool applies the detected "
        "paths itself. Use exact values: color words -> #RRGGBB hex, sizes in px.\n"
        "3. If the user asked for nothing extra, changes must be {}.\n"
        f"INSTALLED FONTS: {', '.join(str(f) for f in fonts[:200]) if fonts else '(unavailable)'}\n"
        "Answer JSON: {\"message\": \"plan + confirmation question\", \"changes\": {...}}"
    )


def mira_propose(config: dict, command: str, detection: dict, sheets: list, fonts=None) -> dict:
    """Turn a detected project layout into a confirmation proposal. Returns
    {message, changes} — nothing is applied by this function."""
    fonts = [str(f) for f in (fonts or [])]
    system = _proposal_system_prompt(detection, config, sheets, fonts)
    model = _pick_model()
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": command},
        ],
        "format": "json",
        "stream": False,
        "options": {"temperature": 0.2},
    }
    if requests is None:
        message = ("I found a project layout here:\n"
                   f"Excel: {detection['excel_path'] or 'none'} | Icons: {detection['icon_folder'] or 'none'} | "
                   f"Background: {detection['bg_path'] or 'none'} | Output: {detection['output_dir']}\n"
                   f"Pages: {len(sheets)}. Shall I apply it? (reply \"yes\")")
        return {"message": message, "changes": {}}
    try:
        resp = requests.post(f"{OLLAMA_URL}/api/chat", json=payload, timeout=_TIMEOUT)
        if not resp.ok:
            if resp.status_code == 404:
                return {"message": _mira_model_hint(model), "changes": {}}
            raise RuntimeError(f"HTTP {resp.status_code}")
        content = (resp.json().get("message") or {}).get("content") or "{}"
    except Exception:
        content = "{}"
    try:
        parsed = json.loads(content)
        if not isinstance(parsed, dict):
            raise ValueError("not an object")
    except Exception:
        parsed = {}

    changes = {}
    for key, value in (parsed.get("changes") or {}).items():
        cleaned = _sanitize(key, value, sheets)
        if cleaned is not None:
            changes[key] = cleaned
    message = str(parsed.get("message") or "").strip()
    if not message:
        message = ("I found this layout: Excel: %s | Icons: %s | Output: %s. "
                   "Shall I apply it?" % (
                       os.path.basename(detection["excel_path"] or "?"),
                       detection["icon_folder"] or "?",
                       detection["output_dir"] or "?",
                   ))
    return {"message": message, "changes": changes}


def project_summary(detection: dict, config: dict, sheets: list, created_output: bool) -> str:
    """Deterministic post-apply summary — exact facts, no LLM."""
    lines = [
        f"Project applied: {detection['folder']}",
        f"Excel: {detection['excel_path'] or '(none found)'}",
    ]
    if sheets:
        lines.append(f"Pages: {len(sheets)} — {', '.join(str(s) for s in sheets)}")
    else:
        lines.append("Pages: 0 — no sheets detected.")
    lines.append(f"Icons: {detection['icon_folder'] or '(none found)'}")
    lines.append(f"Background: {detection['bg_path'] or '(none found)'}")
    lines.append(f"Output: {detection['output_dir']}" + (" (created)" if created_output else ""))
    lines.append("Using: " + _style_report(config))
    lines.append(f"Canvas: {config.get('canvas_preset') or 'Custom'} "
                 f"{config.get('c_width')}x{config.get('c_height')}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# presets / undo / review / batch — deterministic intent helpers
# ---------------------------------------------------------------------------

VISION_MODEL = os.environ.get("MIRA_VISION_MODEL", "qwen2.5vl:7b")

_PRESET_SAVE_RE = re.compile(
    r"^\s*(save|store|remember)( this| the| my)?( current)?( look| style| styles| theme| "
    r"preset| settings| config)?( as)?\s+[\"']?([\w .\-]{2,40})[\"']?\s*$", re.IGNORECASE)
_PRESET_APPLY_RE = re.compile(
    r"^\s*(apply|load|use|restore)( the| my)?( style| preset| theme)?\s+[\"']?"
    r"([\w .\-]{2,40})[\"']?\s*$", re.IGNORECASE)
_PRESET_DELETE_RE = re.compile(
    r"^\s*(delete|remove)( the)? preset\s+[\"']?([\w .\-]{2,40})[\"']?\s*$", re.IGNORECASE)
_PRESET_LIST_RE = re.compile(
    r"^\s*(list|show)( my)? presets|what presets (do i have|are there)\s*$", re.IGNORECASE)
_UNDO_RE = re.compile(
    r"^\s*(undo|revert)( that| it| this| the last (change|thing|edit))?\s*$", re.IGNORECASE)
_REVIEW_KEYWORDS = ("review", "critique", "inspect", "check the render", "check the output",
                    "look at the render", "look at the output", "look at the page",
                    "how does it look", "how does the render look", "quality check")
_BATCH_KEYWORDS = ("batch", "all game folders", "all the game folders", "all folders",
                   "every game folder", "every folder", "all my games", "all games in",
                   "all projects in")


def parse_preset_command(command: str, known_presets=None):
    """Return ('save'|'apply'|'delete'|'list', name) or None."""
    m = _PRESET_SAVE_RE.match(command.strip())
    if m and m.group(6):
        return "save", m.group(6).strip()
    m = _PRESET_DELETE_RE.match(command.strip())
    if m and m.group(3):
        return "delete", m.group(3).strip()
    if _PRESET_LIST_RE.match(command.strip()):
        return "list", None
    m = _PRESET_APPLY_RE.match(command.strip())
    if m and m.group(4):
        name = m.group(4).strip()
        if known_presets:
            try:
                if name not in known_presets and f"my {name}" in known_presets:
                    name = f"my {name}"
            except TypeError:
                pass
        return "apply", name
    return None


def is_undo_command(command: str) -> bool:
    return bool(_UNDO_RE.match(command.strip()))


def is_review_command(command: str) -> bool:
    low = command.lower()
    return any(kw in low for kw in _REVIEW_KEYWORDS) and any(
        w in low for w in ("render", "build", "output", "png", "page", "psd"))


def is_batch_command(command: str) -> bool:
    low = command.lower()
    return any(kw in low for kw in _BATCH_KEYWORDS)


def detect_batch_projects(root: str) -> dict:
    """Find game-project subfolders inside root (each with an Excel file)."""
    root = os.path.abspath(root)
    if not os.path.isdir(root):
        return {"error": f"Folder not found: {root}"}
    projects = []
    for entry in sorted(os.listdir(root)):
        p = os.path.join(root, entry)
        if not os.path.isdir(p) or entry.lower() in _SKIP_DIRS:
            continue
        det = detect_project(p)
        if det.get("excel_path"):
            det["name"] = entry
            projects.append(det)
    return {"projects": projects, "root": root}


def mira_batch_propose(config: dict, command: str, projects: list, fonts=None) -> dict:
    """LLM summary of a multi-folder batch plan. Returns {message}."""
    if not projects:
        return {"message": "I did not find any game folders with an Excel workbook in there."}
    lines = [f"- {p.get('name')}: {os.path.basename(p.get('excel_path') or '?')} -> "
             f"{p.get('output_dir')}" for p in projects]
    plan = "\n".join(lines)
    system = (
        "You are MIRA.AI inside PsHelpScreenTool. The tool detected several game folders for a "
        "batch build. Reply with ONLY JSON: {\"message\": \"...\"}.\n"
        "In message: state how many folders were found, list them compactly, say that each will "
        "be built sequentially with the current style (heading/body font, size, color, style, "
        f"canvas {config.get('c_width')}x{config.get('c_height')}), and ask for confirmation.\n"
        f"FOLDERS:\n{plan}\n"
        "Answer JSON: {\"message\": \"plan + confirmation question\"}"
    )
    payload = {
        "model": MODEL,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": command},
        ],
        "format": "json",
        "stream": False,
        "options": {"temperature": 0.2},
    }
    if requests is not None:
        try:
            resp = requests.post(f"{OLLAMA_URL}/api/chat", json=payload, timeout=_TIMEOUT)
            if resp.ok:
                content = (resp.json().get("message") or {}).get("content") or "{}"
                try:
                    msg = str(json.loads(content).get("message") or "").strip()
                    if msg:
                        return {"message": msg}
                except Exception:
                    pass
        except Exception:
            pass
    return {"message": (f"I found {len(projects)} game folders:\n{plan}\n"
                        "I will build each one with the current style. Shall I go ahead?")}


def mira_review(png_path: str, config: dict, sheet_name: str = "") -> dict:
    """Send a rendered PNG to the vision model for critique + safe fix
    suggestions. Returns {message, changes, issues} — changes are NOT applied."""
    if not png_path or not os.path.isfile(png_path):
        return {"message": "No rendered PNG found yet — build the project first, then ask me to review.",
                "changes": {}, "issues": []}
    if requests is None:
        return {"message": "MIRA vision review unavailable (requests library missing).",
                "changes": {}, "issues": []}
    try:
        import base64
        with open(png_path, "rb") as f:
            b64 = base64.b64encode(f.read()).decode()
    except Exception as exc:
        return {"message": f"Could not read the image: {exc}", "changes": {}, "issues": []}

    system = (
        "You are MIRA.AI, the visual quality inspector inside PsHelpScreenTool. You are looking "
        "at a rendered slot-game help-screen page image. Identify real visual problems only "
        "(text overflow, cut-off text, overlapping elements, icons misaligned or too small, "
        "poor contrast, cramped or scattered layout).\n"
        "Reply with ONLY JSON: {\"issues\": [\"one short issue each\"], "
        "\"changes\": {\"config key\": value}}.\n"
        "changes may only contain small, conservative, safe fixes: h_size, b_size, h_rgb, b_rgb, "
        "line_spacing, alignment, margin_x, heading_top_margin, heading_to_body_gap, bottom_margin, "
        "b_font, h_font. Never invent fonts: prefer names from INSTALLED FONTS. If the page looks "
        "fine, return empty changes and issues [].\n"
        f"INSTALLED FONTS: (not available to the vision model — prefer keeping current fonts)\n"
        f"CURRENT CONFIG:\n{_config_snapshot(config)}\n"
        f"PAGE BEING REVIEWED: {sheet_name or 'a rendered page'}\n"
        "Answer JSON: {\"issues\": [...], \"changes\": {...}}"
    )
    payload = {
        "model": VISION_MODEL,
        "messages": [{"role": "user", "content": system, "images": [b64]}],
        "format": "json",
        "stream": False,
        "options": {"temperature": 0.1},
    }
    try:
        resp = requests.post(f"{OLLAMA_URL}/api/chat", json=payload, timeout=_TIMEOUT)
        if not resp.ok:
            if resp.status_code == 404:
                return {"message": ("The vision model is not installed (HTTP 404). "
                                    "Say “download model qwen2.5vl:7b” to fetch it through the MIRA panel, "
                                    "or run: ollama pull qwen2.5vl:7b"),
                        "changes": {}, "issues": []}
            return {"message": f"Vision model error: HTTP {resp.status_code}.", "changes": {}, "issues": []}
        content = (resp.json().get("message") or {}).get("content") or "{}"
        parsed = json.loads(content)
        if not isinstance(parsed, dict):
            raise ValueError("not an object")
    except Exception:
        return {"message": "Vision model is not installed or failed. Run: ollama pull qwen2.5vl:7b",
                "changes": {}, "issues": []}

    issues = [str(i) for i in (parsed.get("issues") or []) if str(i).strip()][:8]
    changes = {}
    for key, value in (parsed.get("changes") or {}).items():
        cleaned = _sanitize(key, value, [])
        if cleaned is not None:
            changes[key] = cleaned
    if not issues and not changes:
        message = "The page looks good to me — no obvious issues found."
    else:
        message = ("My review of the render:\n- " + "\n- ".join(issues[:6])) if issues else ""
        if changes:
            message += "\nI suggest these fixes: " + ", ".join(
                k.replace("_", " ") for k in changes) + ". Shall I apply them?"
        else:
            message += "\nI suggest no config changes."
    return {"message": message, "changes": changes, "issues": issues}


def find_latest_png(output_dir: str) -> str:
    """Newest *.png directly in output_dir (best-effort)."""
    if not output_dir or not os.path.isdir(output_dir):
        return ""
    candidates = []
    try:
        for fn in os.listdir(output_dir):
            if fn.lower().endswith(".png"):
                p = os.path.join(output_dir, fn)
                candidates.append((os.path.getmtime(p), p))
    except OSError:
        return ""
    if not candidates:
        return ""
    candidates.sort(reverse=True)
    return candidates[0][1]
