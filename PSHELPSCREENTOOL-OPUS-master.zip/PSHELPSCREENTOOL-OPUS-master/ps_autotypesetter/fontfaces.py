"""Every installed font face, read from the font files themselves — family and style like Photoshop's menus.

Photoshop groups faces by the typographic family (name IDs 16/17, else 1/2): "Myriad Pro" with
Regular, Semibold, Bold, Bold Italic ... This index does the same, and `pick()` turns any way a font
was asked for into one face file:

    "Myriad Pro|Semibold"   family + a face's own style (the Font style menu)
    "MyriadPro-Bold"        a PostScript name (fonts read from a PSD), "Myriad Pro Bold" a full name
    "Arial|bold", "Arial Bold" + bold / italic flags   the older ways the tool asked (still honoured)

The PNG / PSD build (png_builder._load_font) and the Canvas (visualiser_data.resolve_font_file) both
ask here, so the Canvas draws with exactly the file the build uses.
"""
import os
import re
import struct
import threading

_EXTS = (".ttf", ".otf", ".ttc")
_LEGACY = {"bold", "italic", "regular", "normal", "bold italic", ""}
_STYLE_WORDS = ("regular", "normal", "book", "roman", "plain", "medium", "semibold", "semi bold", "demibold",
                "demi bold", "bold", "extrabold", "extra bold", "ultrabold", "black", "heavy", "light", "extralight",
                "extra light", "ultralight", "thin", "hairline", "italic", "oblique", "condensed", "narrow",
                "semicondensed", "extended", "expanded")
_lock = threading.Lock()
_INDEX = None          # (stamp, faces, by_family, by_name)


def compact(value):
    return re.sub(r"[^a-z0-9]+", "", str(value or "").casefold())


def _dirs():
    windir = os.environ.get("WINDIR", r"C:\Windows")
    out = [os.path.join(windir, "Fonts"), r"C:\Windows\Fonts"]
    local = os.environ.get("LOCALAPPDATA", "")
    if local:
        out.append(os.path.join(local, "Microsoft", "Windows", "Fonts"))
    out += [r"C:\Program Files\Common Files\Adobe\Fonts", r"C:\Program Files (x86)\Common Files\Adobe\Fonts",
            os.path.join(os.getcwd(), "fonts"), os.path.join(os.getcwd(), "Fonts"),
            "/usr/share/fonts", "/usr/local/share/fonts"]
    seen, res = set(), []
    for d in out:
        k = os.path.normcase(os.path.normpath(d))
        if d and k not in seen and os.path.isdir(d):
            seen.add(k)
            res.append(d)
    return res


def _adobe_lists():
    """Photoshop's own font lists (every version installed): "CT Font Cache/AdobeDefault_Fonts.lst"."""
    roaming = os.environ.get("APPDATA", "")
    base = os.path.join(roaming, "Adobe") if roaming else ""
    out = []
    try:
        for d in sorted(os.listdir(base)) if base and os.path.isdir(base) else []:
            if d.casefold().startswith("adobe photoshop"):
                p = os.path.join(base, d, "CT Font Cache", "AdobeDefault_Fonts.lst")
                if os.path.isfile(p):
                    out.append(p)
    except OSError:
        pass
    return out


def _adobe_files():
    """Font files that Adobe apps use but Windows never lists, so other programs can't see them:
    Photoshop's own fonts (Myriad Pro, Minion Pro ... — hidden in "Required/typesupport/.f" with numbered
    names, found through Photoshop's font list) and Adobe Fonts activated in Creative Cloud (CoreSync)."""
    out = []
    for lst in _adobe_lists():
        try:
            with open(lst, "r", encoding="latin-1") as fh:
                for line in fh:
                    if line.startswith("OutlineFileName:"):
                        p = os.path.normpath(line.split(":", 1)[1].strip().replace("\\\\", "\\"))
                        if os.path.isfile(p):
                            out.append(p)
        except OSError:
            pass
    roaming = os.environ.get("APPDATA", "")
    live = os.path.join(roaming, "Adobe", "CoreSync", "plugins", "livetype") if roaming else ""
    if live and os.path.isdir(live):
        for root, _d, files in os.walk(live):
            for fn in files:
                out.append(os.path.join(root, fn))
    return out


def _files():
    seen, out = set(), []
    for d in _dirs():
        try:
            for root, _dirs2, files in os.walk(d):
                for fn in files:
                    if fn.lower().endswith(_EXTS):
                        p = os.path.join(root, fn)
                        k = os.path.normcase(p)
                        if k not in seen:
                            seen.add(k)
                            out.append(p)
        except OSError:
            pass
    return out


def _decode(raw, pid):
    for enc in (("utf-16-be", "latin-1") if pid in (0, 3) else ("latin-1", "utf-16-be")):
        try:
            s = raw.decode(enc).replace("\x00", "").strip()
            if s:
                return s
        except Exception:
            continue
    return ""


def _face_at(fh, base):
    """{names: {id: text}, weight, italic} of the sfnt starting at `base`, or None."""
    fh.seek(base)
    if fh.read(4) not in (b"\x00\x01\x00\x00", b"true", b"OTTO"):
        return None
    num = struct.unpack(">H", fh.read(2))[0]
    if num > 512:
        return None
    fh.seek(base + 12)
    tables = {}
    for _ in range(num):
        rec = fh.read(16)
        if len(rec) < 16:
            break
        tables[rec[:4]] = struct.unpack(">LLL", rec[4:16])[1:]
    names = {}
    if b"name" in tables:
        off, ln = tables[b"name"]
        fh.seek(off)
        buf = fh.read(min(ln, 262144))
        if len(buf) >= 6:
            _fmt, cnt, soff = struct.unpack(">HHH", buf[:6])
            best = {}
            for i in range(min(cnt, 4096)):
                r = buf[6 + i * 12: 18 + i * 12]
                if len(r) < 12:
                    break
                pid, eid, lid, nid, l2, o2 = struct.unpack(">HHHHHH", r)
                if nid not in (1, 2, 4, 6, 16, 17):
                    continue
                # Windows English first, then any Windows, then Mac Roman, then the rest
                rank = 0 if (pid == 3 and lid == 0x409) else 1 if pid == 3 else 2 if (pid == 1 and lid == 0) else 3
                if nid in best and best[nid][0] <= rank:
                    continue
                text = _decode(buf[soff + o2: soff + o2 + l2], pid)
                if text:
                    best[nid] = (rank, text)
            names = {k: v[1] for k, v in best.items()}
    weight, italic = 400, False
    if b"OS/2" in tables:
        off, ln = tables[b"OS/2"]
        fh.seek(off)
        os2 = fh.read(min(ln, 96))
        if len(os2) >= 64:
            weight = struct.unpack(">H", os2[4:6])[0] or 400
            italic = bool(struct.unpack(">H", os2[62:64])[0] & 1)
    return {"names": names, "weight": weight, "italic": italic}


def _read(path):
    """[(index in the file, face info)] for a TTF / OTF / TTC."""
    out = []
    try:
        with open(path, "rb") as fh:
            tag = fh.read(4)
            if tag == b"ttcf":
                fh.seek(8)
                n = struct.unpack(">L", fh.read(4))[0]
                offs = struct.unpack(">%dL" % min(n, 64), fh.read(4 * min(n, 64)))
                for i, off in enumerate(offs):
                    f = _face_at(fh, off)
                    if f:
                        out.append((i, f))
            else:
                f = _face_at(fh, 0)
                if f:
                    out.append((0, f))
    except Exception:
        return []
    return out


def _stamp():
    parts = []
    for d in _dirs() + _adobe_lists():
        try:
            parts.append((d, os.path.getmtime(d)))
        except OSError:
            pass
    return tuple(parts)


def index():
    """(faces, by_family, by_name). faces: [{path, index, family, style, ps, full, legacy_family, weight, italic}];
    by_family: {compact family: [face]} (typographic and older family names); by_name: {compact name: face}
    (PostScript name, full name, file name)."""
    global _INDEX
    st = _stamp()
    with _lock:
        if _INDEX is not None and _INDEX[0] == st:
            return _INDEX[1:]
        faces, have = [], set()
        # the fonts installed in Windows first; Adobe's own ones only add faces Windows doesn't have
        for adobe, paths in ((False, _files()), (True, _adobe_files())):
            for path in paths:
                for i, f in _read(path):
                    n = f["names"]
                    fam = n.get(16) or n.get(1) or ""
                    if not fam:
                        continue
                    style = n.get(17) or n.get(2) or "Regular"
                    k = (compact(fam), compact(style))
                    if adobe and k in have:
                        continue
                    have.add(k)
                    faces.append({"path": path, "index": i, "family": fam, "style": style,
                                  "legacy_family": n.get(1) or fam, "legacy_style": n.get(2) or "",
                                  "ps": n.get(6) or "", "full": n.get(4) or "",
                                  "weight": f["weight"], "italic": f["italic"], "adobe": adobe})
        by_family, by_name = {}, {}
        for f in faces:
            for k in {compact(f["family"]), compact(f["legacy_family"])}:
                if k:
                    by_family.setdefault(k, []).append(f)
            for k in (compact(f["ps"]), compact(f["full"]), compact(os.path.splitext(os.path.basename(f["path"]))[0]) if not f["adobe"] else "",
                      compact(f["family"] + f["style"]), compact(f["legacy_family"] + f["legacy_style"])):
                if k and k not in by_name:
                    by_name[k] = f
        _INDEX = (st, faces, by_family, by_name)
        return faces, by_family, by_name


def families():
    """{family: [style, ...]} as Photoshop's Font / Font style menus list them (styles lightest first)."""
    faces, _bf, _bn = index()
    out = {}
    for f in faces:
        styles = out.setdefault(f["family"], {})
        styles.setdefault(f["style"], (f["italic"], f["weight"]))
    return {fam: [s for s, _k in sorted(st.items(), key=lambda kv: (kv[1][1], kv[1][0], kv[0]))]
            for fam, st in sorted(out.items(), key=lambda kv: kv[0].casefold())}


def _parse(request):
    """(name, explicit face style or None, bold, italic) of a font request."""
    raw = str(request or "").strip()
    name, explicit, bold, italic = raw, None, False, False
    if "|" in raw:
        name, rest = raw.split("|", 1)
        name = name.strip()
        words = [w.strip() for w in rest.split("|") if w.strip()]
        legacy = all(w == w.casefold() and w in ("bold", "italic", "regular", "normal") for w in words)
        if legacy:
            bold = "bold" in words
            italic = "italic" in words
        else:
            explicit = " ".join(words)
    return name, explicit, bold, italic


def _flags(text):
    t = compact(text)
    return ({"bold": any(w in t for w in ("bold", "black", "heavy")) and "semibold" not in t and "demibold" not in t,
             "semibold": "semibold" in t or "demibold" in t, "italic": "italic" in t or "oblique" in t,
             "light": any(w in t for w in ("light", "thin", "hairline")), "condensed": "condensed" in t or "narrow" in t})


def _best(faces, bold, italic, want=""):
    """The face of a family closest to the request: its own style name first, else weight and slant."""
    if want:
        w = compact(want)
        hit = next((f for f in faces if compact(f["style"]) == w), None) or \
            next((f for f in faces if compact(f["legacy_style"]) == w), None)
        if hit:
            return hit
        fl = _flags(want)
        bold, italic = fl["bold"] or fl["semibold"], fl["italic"]
        target = 300 if fl["light"] else 600 if fl["semibold"] else 700 if fl["bold"] else 400
        cond = fl["condensed"]
    else:
        target, cond = (700 if bold else 400), False

    def score(f):
        st = compact(f["style"])
        return (int(f["italic"] != bool(italic)), abs(int(f["weight"]) - target),
                int(("condensed" in st or "narrow" in st) != cond),
                int(st not in ("regular", "bold", "italic", "bolditalic", "book", "roman", "normal")), len(st))
    return min(faces, key=score) if faces else None


def pick(request, bold=False, italic=False):
    """The face file for a font request: (path, index in the file) or None when no installed face fits.

    An explicit face style (from the Font style menu) wins over the bold / italic flags; without one
    the flags pick the weight and slant (a heading asked bold gets the family's Bold face)."""
    name, explicit, b2, i2 = _parse(request)
    bold, italic = bool(bold or b2), bool(italic or i2)
    if not name:
        return None
    faces, by_family, by_name = index()
    key = compact(name)
    fam = by_family.get(key)
    if not fam:
        face = by_name.get(key)                       # a PostScript / full / file name: that very face
        if face is not None:
            plain = int(face["weight"]) <= 500 and not face["italic"]
            if explicit is None and not (plain and (bold or italic)):
                return face["path"], face["index"]
            # a family's plain face named ("ArialMT") but bold / italic asked: that family's face for it
            fam = by_family.get(compact(face["family"]))
    if not fam:                                        # "Arial Bold": a family and a style in one name
        words = re.split(r"\s+", name)
        for cut in range(len(words) - 1, 0, -1):
            tail = " ".join(words[cut:]).casefold()
            if not all(w in _STYLE_WORDS for w in tail.split()):
                break
            fam = by_family.get(compact(" ".join(words[:cut])))
            if fam:
                if explicit is None:
                    explicit = " ".join(words[cut:])
                break
    if not fam:
        return None
    face = _best(fam, bold, italic, explicit or "")
    return (face["path"], face["index"]) if face else None


def is_face_style(style):
    """True for a style picked from a font's own Font style menu ("Regular", "Semibold", "Bold Italic"),
    False for the older lowercase choices ("regular", "bold", "italic", "bold italic") the tool used to
    store — those keep their old meaning (the heading drawn bold unless asked otherwise)."""
    s = str(style or "").strip()
    return bool(s) and not (s == s.casefold() and s in _LEGACY)


def request(name, style):
    """A font request for a family and a face style from its menu: "Myriad Pro|Semibold"."""
    name = str(name or "").strip()
    return f"{name}|{str(style).strip()}" if name and is_face_style(style) else name


def face_of(request, bold=False, italic=False):
    """{family, style, path, ps} of the face a request draws with, or None — what the font menus show."""
    hit = pick(request, bold, italic)
    if not hit:
        return None
    faces, _bf, _bn = index()
    f = next((x for x in faces if x["path"] == hit[0] and x["index"] == hit[1]), None)
    return {"family": f["family"], "style": f["style"], "path": f["path"], "ps": f["ps"]} if f else None


def file_key(path):
    """The name the Canvas fetches a font file by (/api/font_file): its file name — for Adobe's hidden
    files (numbered ".19" in every Photoshop version) a name of its own, unique to that file."""
    base = os.path.basename(str(path or ""))
    if os.path.splitext(base)[1].lower() in _EXTS:
        return base
    import hashlib

    return "adobe-" + hashlib.sha1(os.path.normcase(os.path.abspath(path)).encode("utf-8")).hexdigest()[:12] + ".otf"


def path_by_basename(filename):
    """Full path of an indexed font file by its file name or file_key (the Canvas fetches faces by it)."""
    want = os.path.basename(str(filename or "")).casefold()
    faces, _bf, _bn = index()
    return next((f["path"] for f in faces if file_key(f["path"]).casefold() == want), None)
