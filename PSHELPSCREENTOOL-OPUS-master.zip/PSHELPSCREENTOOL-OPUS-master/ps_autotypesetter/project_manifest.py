import os
import json
import hashlib
import datetime
from openpyxl import load_workbook

MANIFEST_SUFFIX = ".pshelpscreen.json"
MANIFEST_VERSION = 1


def manifest_path_for_psd(psd_path):
    if not psd_path:
        return None
    base, _ = os.path.splitext(psd_path)
    return base + MANIFEST_SUFFIX


def _norm_cell(v):
    if v is None:
        return ""
    return str(v).strip()


def _sheet_hash(ws, max_col_limit):
    h = hashlib.sha256()
    for row in ws.iter_rows(min_row=1, max_col=max_col_limit, values_only=True):
        vals = [_norm_cell(v) for v in row]
        h.update(("\x1f".join(vals) + "\x1e").encode("utf-8", errors="ignore"))
    return h.hexdigest()


def workbook_hashes(excel_path, max_col_limit):
    wb = load_workbook(excel_path, data_only=True)
    return {name: _sheet_hash(wb[name], max_col_limit) for name in wb.sheetnames}


def build_group_map(doc, sheet_names):
    result = {}
    try:
        layer_sets = list(doc.layerSets)
    except Exception:
        layer_sets = []
    for name in sheet_names:
        groups = []
        for ls in layer_sets:
            try:
                ls_name = ls.name
            except Exception:
                continue
            if ls_name == name or ls_name.startswith(f"{name} (Page"):
                groups.append(ls_name)
        result[name] = sorted(groups)
    return result


def save_manifest(psd_path, excel_path, max_col_limit, doc=None, extra=None):
    path = manifest_path_for_psd(psd_path)
    if not path:
        return None
    sheet_hashes = workbook_hashes(excel_path, max_col_limit)
    payload = {
        "manifest_version": MANIFEST_VERSION,
        "updated_at": datetime.datetime.now().isoformat(timespec="seconds"),
        "psd_file": os.path.abspath(psd_path),
        "excel_file": os.path.abspath(excel_path),
        "max_col_limit": int(max_col_limit),
        "sheets": {},
    }
    group_map = build_group_map(doc, sheet_hashes.keys()) if doc is not None else {}
    for sheet_name, sheet_hash in sheet_hashes.items():
        payload["sheets"][sheet_name] = {
            "hash": sheet_hash,
            "groups": group_map.get(sheet_name, []),
        }
    if extra:
        payload.update(extra)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)
    return path


def load_manifest(psd_path):
    path = manifest_path_for_psd(psd_path)
    if not path or not os.path.exists(path):
        return None
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def compare_excel_to_manifest(excel_path, manifest, max_col_limit):
    current_hashes = workbook_hashes(excel_path, max_col_limit)
    old_sheets = (manifest or {}).get("sheets", {}) or {}
    old_hashes = {name: (info or {}).get("hash", "") for name, info in old_sheets.items()}

    changed = {}
    all_names = set(current_hashes.keys()) | set(old_hashes.keys())
    for name in sorted(all_names):
        old_hash = old_hashes.get(name)
        new_hash = current_hashes.get(name)
        if old_hash is None:
            changed[name] = ["Tab added"]
        elif new_hash is None:
            changed[name] = ["Tab removed"]
        elif old_hash != new_hash:
            changed[name] = ["Sheet content changed (manifest hash mismatch)"]
    return changed
