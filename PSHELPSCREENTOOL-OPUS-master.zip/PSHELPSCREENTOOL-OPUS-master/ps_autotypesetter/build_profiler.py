import json
from contextlib import contextmanager
from pathlib import Path
from time import perf_counter


class BuildProfiler:
    """Small build timing helper used to find expensive render stages."""

    def __init__(self):
        self.events = []
        self._starts = {}
        self.counters = {}

    def start(self, name):
        self._starts[str(name)] = perf_counter()

    def stop(self, name):
        key = str(name)
        start = self._starts.pop(key, None)
        if start is not None:
            self.events.append({
                "name": key,
                "seconds": round(perf_counter() - start, 4),
            })

    def inc(self, name, amount=1):
        key = str(name)
        self.counters[key] = self.counters.get(key, 0) + int(amount)

    def save(self, output_dir):
        Path(output_dir).mkdir(parents=True, exist_ok=True)
        path = Path(output_dir) / "build_report.json"
        events = self.events + GLOBAL.events
        counters = dict(self.counters)
        for key, value in GLOBAL.counters.items():
            counters[key] = counters.get(key, 0) + value
        path.write_text(
            json.dumps({
                "events": events,
                "counters": counters,
            }, indent=2),
            encoding="utf-8",
        )
        return str(path)


GLOBAL = BuildProfiler()


@contextmanager
def timed(name):
    """Time a code region into the shared GLOBAL profiler.

    Nested same-name regions are not supported; use unique names.
    """
    GLOBAL.start(name)
    try:
        yield
    finally:
        GLOBAL.stop(name)
