"""
RenderBackend protocol — the interface between build_engine's layout logic and
the actual PSD rendering layer.

Two implementations:
  - COMRenderBackend   — wraps existing Adobe Photoshop COM calls
  - PSAPIRenderBackend — wraps PhotoshopAPI (headless, no Photoshop needed)
"""
from abc import ABC, abstractmethod
from typing import Optional


class RenderBackend(ABC):
    """Minimal interface for all PSD creation operations used by build_engine."""

    # ── Document lifecycle ──────────────────────────────────────────────
    @abstractmethod
    def create_document(self, width: int, height: int):
        ...

    @abstractmethod
    def open_document(self, path: str):
        ...

    @abstractmethod
    def save(self, path: str):
        ...

    @abstractmethod
    def close(self):
        ...

    # ── Groups ──────────────────────────────────────────────────────────
    @abstractmethod
    def create_group(self, parent, name: str):
        """Create a group layer.  Returns a group handle."""
        ...

    @abstractmethod
    def find_group(self, parent, name: str):
        """Find a group by name (returns handle or None)."""
        ...

    @abstractmethod
    def delete_group(self, group):
        ...

    @abstractmethod
    def rename_group(self, group, new_name: str):
        ...

    # ── Text layers ─────────────────────────────────────────────────────
    @abstractmethod
    def create_text_layer(self, parent, text: str, font_name: str, font_size: int,
                          color_rgb, x: float, y: float, name: str = "Text",
                          line_height: Optional[float] = None):
        """Create an editable text layer.  Returns a layer handle."""
        ...

    @abstractmethod
    def update_text_layer(self, layer, text: str):
        ...

    @abstractmethod
    def text_layer_bounds(self, layer):
        """Return (left, top, right, bottom) or None."""
        ...

    # ── Image / icon layers ────────────────────────────────────────────
    @abstractmethod
    def create_image_layer(self, parent, pil_image, name: str,
                           x: float, y: float):
        ...

    @abstractmethod
    def create_placed_layer(self, parent, file_path: str, name: str,
                            x: float, y: float):
        """Embed an external file (e.g. .png/.gif) as a Smart Object."""
        ...

    # ── Shape layers ────────────────────────────────────────────────────
    @abstractmethod
    def create_shape_layer(self, parent, width: int, height: int,
                           fill_color_rgb, x: int, y: int,
                           name: str = "Shape"):
        ...

    # ── Alignment ───────────────────────────────────────────────────────
    @abstractmethod
    def align_group(self, group, box_left: float, box_width: float,
                    alignment: str):
        """Horizontally centre/left/right the group within the given box."""
        ...

    @abstractmethod
    def translate_layer(self, layer, dx: float, dy: float):
        ...

    # ── Background ──────────────────────────────────────────────────────
    @abstractmethod
    def apply_background(self, bg_path: str, width: int, height: int, mode: str, bg_color: str = "#FFFFFF"):
        ...

    # ── Measurement ─────────────────────────────────────────────────────
    @abstractmethod
    def measure_text(self, text: str, font_size: int, font_name: str) -> float:
        ...

    @abstractmethod
    def measure_layer_bounds(self, layer):
        """Return (left, top, right, bottom) for a rendered layer."""
        ...

    # ── Misc ────────────────────────────────────────────────────────────
    @abstractmethod
    def flatten(self):
        ...

    @property
    @abstractmethod
    def document_size(self):
        """Return (width, height)."""
        ...
