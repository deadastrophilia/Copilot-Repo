import json
import os
from .config import SESSION_FILE
from .safe_json import write_json

# Backwards compatibility: older builds saved the session under this name.
LEGACY_SESSION_FILES = [
    os.path.join(os.path.expanduser("~"), "PS_AutoTypesetter_Session.json"),
    os.path.join(os.path.expanduser("~"), "PhotoshopAutoTypesetter_Session.json"),
]

def _read_json(path):
    try:
        if path and os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception as e:
        print(f"Could not load session from {path}: {e}")
    return None

def save_session(data):
    """Save current UI state to JSON file.

    V34 renamed the app to PsHelpScreenTool, but we also write the old
    PS_AutoTypesetter session file so users moving between builds do not lose
    their remembered settings.
    """
    targets = [SESSION_FILE] + LEGACY_SESSION_FILES[:1]
    for path in targets:
        try:
            write_json(path, data)
        except Exception as e:
            print(f"Could not save session to {path}: {e}")

def load_session():
    """Load previous UI state.

    First tries the new PsHelpScreenTool session file. If it does not exist,
    tries legacy session names from older builds and migrates the loaded data
    to the new filename.
    """
    data = _read_json(SESSION_FILE)
    if data is not None:
        return data

    for legacy_path in LEGACY_SESSION_FILES:
        data = _read_json(legacy_path)
        if data is not None:
            # Migrate silently to the new app-name session file.
            try:
                with open(SESSION_FILE, "w", encoding="utf-8") as f:
                    json.dump(data, f, indent=2)
            except Exception as e:
                print(f"Could not migrate legacy session to {SESSION_FILE}: {e}")
            return data

    return {}
