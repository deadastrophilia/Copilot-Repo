"""rules_layout — the Game Rules / Bingo Rules pages as canonical PageLayouts for the Canvas.

These pages have their own renderer (png_builder._render_game_rules_png_pages /
_render_bingo_rules_png_pages: one page, one fit factor, the separator, XTRAA REELS, the cells grid).
The Canvas edits them like every other page — the row editor, the top bar, icon handles — so it needs
their lines as PageLayout text elements. They come from the renderer itself: it runs once inside
png_builder.line_sink(skip_text=True), which records every line _draw_inline lays out (text, place,
runs with icon boxes) and draws no text. What it does draw — strips, the separator, the XTRAA REELS
icons, a heading picture — is the page's "decor" picture, drawn under the text.

Line elements are keyed by their Excel CELL ("B7"): the text_edits and icon_scales keys of these pages.
"""

from __future__ import annotations

import hashlib
import os
import re
import tempfile
import uuid

from .page_layout import ImageElement, PageLayout, TextElement

RULES_KINDS = ("game_rules", "bingo_rules")


def rules_kind(sheet_name):
    """"game_rules" / "bingo_rules" for those sheets, else ""."""
    from . import png_builder

    kind = png_builder._normalized_sheet_kind(str(sheet_name or ""))
    return kind if kind in RULES_KINDS else ""


def _cell_row(cell):
    m = re.match(r"^[A-Za-z]+(\d+)$", str(cell or ""))
    return int(m.group(1)) if m else None


def _font_file(font, bold=False, path=""):
    """The font file the canvas loads to draw a line: the one the renderer drew it with."""
    if path and os.path.isfile(path):
        return os.path.basename(path)
    try:
        from visualiser.visualiser_data import resolve_font_file

        return resolve_font_file(font, bold=bool(bold), italic="italic" in str(font).casefold()) or ""
    except Exception:
        return ""


def _jsonable(value):
    """The renderer's report without what JSON can't carry."""
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


def build_layout(lines, report, kind, sheet_name, canvas_w, canvas_h, decor_url="", decor_box=None):
    """The PageLayout of a rules page from the sunk lines (png_builder.line_sink) and the report."""
    guides = report.get("guides") or {}
    margin_x = float(guides.get("margin_x") or 0)
    safe_bottom = float(guides.get("safe_bottom") or canvas_h)
    top = float(guides.get("heading_top") or 0)
    layout = PageLayout(
        source={"sheet_name": sheet_name, "page_index": 0, "layout_mode": "rules", "rules": kind},
        canvas={"width": canvas_w, "height": canvas_h},
        safe_area={"left": margin_x, "top": top, "width": max(0.0, canvas_w - 2 * margin_x),
                   "height": max(0.0, safe_bottom - top), "bottom": safe_bottom},
        margins={"margin_x": margin_x},
    )
    if decor_url:
        bx, by, bw, bh = decor_box or (0, 0, canvas_w, canvas_h)
        layout.add(ImageElement(element_id="rules_decor", x=bx, y=by, width=bw, height=bh,
                                style_role="Decor", meta={"kind": "picture", "url": decor_url}))

    # each cell's whole text (as shown: the artist's edits in, icon size tags out)
    if kind == "game_rules":
        cell_text = {str(k): str(v or "") for k, v in (report.get("cells") or {}).items()}
    else:
        cell_text = {str(c.get("cell")): str(c.get("text") or "") for c in report.get("cells") or [] if isinstance(c, dict)}

    heading = [ln for ln in lines if (ln.get("ctx") or {}).get("kind") == "heading"]
    if heading:
        h0 = heading[0]
        layout.add(TextElement(
            element_id="heading", x=h0["box_x"], y=h0["y"], width=h0["box_w"],
            height=heading[-1]["y"] + heading[-1]["h"] - h0["y"],
            text=" ".join(ln["text"] for ln in heading), font=h0["font"], size=h0["size"], bold=True,
            color=h0["color"], align=h0["align"], line_spacing=h0["spacing"], icon_height=h0["icon_h"],
            icon_gap_left=h0["gap_l"], icon_gap_right=h0["gap_r"],
            wrapped_lines=[ln["text"] for ln in heading], line_heights=[ln["h"] for ln in heading],
            line_widths=[ln["w"] for ln in heading], line_runs=[ln["runs"] for ln in heading],
            effects=dict(h0["fx"] or {}), style_role="Heading",
            meta={"kind": "heading", "page": 1, "tracking": h0["tracking"]},
        ))

    # blank lines (Enter pressed twice): the caret's places, kept on the cell's next drawn line
    blanks = {}
    for b in report.get("blanks") or []:
        blanks.setdefault(str(b.get("cell")), []).append({"top": float(b.get("top") or 0), "h": float(b.get("h") or 1)})
    font_files, count, last_of = {}, {}, {}
    for ln in lines:
        ctx = ln.get("ctx") or {}
        if ctx.get("kind") != "body":
            continue
        cell = str(ctx.get("cell") or "")
        if not str(ln["text"]).strip():               # an empty line inside a cell (Bingo): a blank line
            blanks.setdefault(cell, []).append({"top": ln["y"], "h": ln["h"]})
            continue
        n = count[cell] = count.get(cell, 0) + 1
        fkey = (ln["font"], ln["bold"], ln.get("font_path") or "")
        if fkey not in font_files:
            font_files[fkey] = _font_file(*fkey)
        meta = {"kind": "body", "rules": kind, "part": ctx.get("part") or "rules", "cell": cell, "key": cell,
                "row": _cell_row(cell), "line": n, "role": "", "tracking": ln["tracking"],
                "font_file": font_files[fkey], "ink_top": ln["y"], "ink_bottom": ln["y"] + ln["h"]}
        mine = [b for b in blanks.get(cell, []) if b["top"] < ln["y"]]
        if mine:
            meta["blank_above"] = mine
            blanks[cell] = [b for b in blanks[cell] if b not in mine]
        last_of[cell] = layout.add(TextElement(
            element_id=f"rules_{cell}_{n}", x=ln["box_x"], y=ln["y"], width=ln["box_w"], height=ln["h"],
            text=cell_text.get(cell, ln["text"]), font=ln["font"], size=ln["size"], bold=ln["bold"],
            color=ln["color"], align=ln["align"], line_height=ln["h"], line_spacing=ln["spacing"],
            icon_height=ln["icon_h"], icon_gap_left=ln["gap_l"], icon_gap_right=ln["gap_r"],
            wrapped_lines=[ln["text"]], line_heights=[ln["h"]], line_widths=[ln["w"]], line_runs=[ln["runs"]],
            effects=dict(ln["fx"] or {}), style_role="Body", meta=meta,
        ))
    for cell, rest in blanks.items():                # blank lines after a cell's last line
        if rest and cell in last_of:
            last_of[cell].meta["blank_below"] = rest
    return layout


def _decor_url(page, register_preview):
    """The decor picture's url and its [x, y, w, h] on the page — only where something is drawn (nothing
    drawn: no picture). The same picture keeps its file and url, so typing never reloads it on the
    Canvas; a small, quickly packed PNG (it is made again at every keystroke)."""
    bbox = page.getbbox()
    if not bbox:
        return "", None
    crop = page.crop(bbox)
    digest = hashlib.md5(crop.tobytes() + repr(bbox).encode()).hexdigest()
    work = os.path.join(tempfile.gettempdir(), "psh_table_previews")
    os.makedirs(work, exist_ok=True)
    path = os.path.join(work, f"rules_decor_{digest}.png")
    if not os.path.isfile(path):
        tmp = f"{path}.{uuid.uuid4().hex}.tmp"
        crop.save(tmp, "PNG", compress_level=1)
        os.replace(tmp, path)
    token = register_preview(path) or ""
    box = [bbox[0], bbox[1], bbox[2] - bbox[0], bbox[3] - bbox[1]]
    return (f"/api/table_preview/{token}" if token else ""), box


def layout_payload(render, kind, sheet_name, register_preview=None):
    """The /api/layout/preview payload of a rules page. `render(report)` runs the page's renderer and
    returns (pages, sheet_name, ...) — or (None, error, ...)."""
    from . import png_builder

    report = {}
    with png_builder.line_sink(skip_text=True) as rec:
        res = render(report)
    pages = res[0]
    if pages is None:
        return {"ok": False, "error": str(res[1] or "The page could not be laid out.")}
    sheet_name = str(res[1] or sheet_name)
    url, box = "", None
    if callable(register_preview):
        try:
            url, box = _decor_url(pages[0], register_preview)
        except Exception:
            url, box = "", None
    canvas_w, canvas_h = (list(report.get("canvas") or []) + [pages[0].width, pages[0].height])[:2]
    layout = build_layout(rec["lines"], report, kind, sheet_name, int(canvas_w), int(canvas_h), url, box)
    lay = layout.to_dict()
    return {
        "ok": True, "sheet_name": sheet_name, "mode": "canonical", "use_canonical_layout": True,
        "layouts": [lay], "canvas": lay["canvas"], "live_overrides": [],
        # the renderer's report: the kept guides and handles (separator, XTRAA REELS, margins) read it
        "rules": {"kind": kind, "report": _jsonable(report)},
    }
