"""learn_cards — an artist's paytable page (PSD) read as an editable card design.

learn_paytable turns an artist page into a fixed slot template, and only finds cards whose symbol art
matches a symbols folder. This reads the page by its geometry instead, so it works on any artist PSD:

  cards     the repeated card-sized shape layers with numbers inside them (live shapes: their corner
            radius, fill, fill opacity, and stroke — the shape's own or a stroke layer effect); with
            no card shapes, each symbol's own group (its picture + its numbers) is a card
  rows      cards side by side are a row: the top row is the high band, the others the low band
            (cards across = the most cards in a row); card size and the gaps between cards
  inside    the symbol picture and the counts / pays text as boxes in the card (fractions), with
            their font, size, colour and alignment — counts one layer per column, one layer per row,
            or counts and pays in one tabbed layer
  title     the biggest text above the cards: its size and colour

The result is a card design (dynamic_pages/paytable/card_templates schema) built on the design given
(its boxes, title plate, styles it doesn't set), in the 1920 x 1080 design space — every market's own
Excel then fills it, and the Canvas edits it like any design. Layer effects other than a stroke
(glows, shadows, bevels) are not carried: the report says so, a layer style can be picked for them.
"""
from __future__ import annotations

import copy
import re
import statistics

DW, DH = 1920, 1080
_NUM = re.compile(r"^[\d.,\s×x]+$")
_PAGE_WORDS = re.compile(r"pay\s*table|paytable", re.I)


# ------------------------------------------------------------------ finding the page
def _groups(node, path=()):
    for layer in node:
        if layer.is_group():
            p = path + (layer.name,)
            yield p, layer
            yield from _groups(layer, p)


def _numbers_in(group):
    return [x for x in group.descendants() if x.kind == "type" and _is_num(x)]


def paytable_groups(psd):
    """The page groups a paytable could be: named like one (at any depth), with numbers in them —
    [{"path": "K2/Paytable", "name", "visible", "numbers"}], visible ones first."""
    out = []
    for path, g in _groups(psd):
        if not _PAGE_WORDS.search(g.name or ""):
            continue
        n = len(_numbers_in(g))
        if n >= 3:
            out.append({"path": "/".join(path), "name": g.name, "visible": bool(g.visible), "numbers": n})
    if not out:                                        # no page named like a paytable: the innermost groups with pays in them
        found = [{"path": "/".join(p), "name": g.name, "visible": bool(g.visible), "numbers": len(_numbers_in(g))}
                 for p, g in _groups(psd)]
        found = [f for f in found if f["numbers"] >= 6]
        out = [f for f in found if not any(o["path"].startswith(f["path"] + "/") for o in found)]
        out.sort(key=lambda x: -x["numbers"])
        return out
    out.sort(key=lambda x: (not x["visible"], x["path"].count("/"), x["path"]))
    return out


def find_group(psd, path):
    """A group by its path ("Parent/Child"), else by its name at any depth."""
    want = [p for p in str(path or "").split("/") if p != ""] or [str(path or "")]
    for p, g in _groups(psd):
        if list(p) == want or (len(want) == 1 and g.name == want[0]):
            return g
    return None


# ------------------------------------------------------------------ reading layers
def _visible_leaves(group):
    out = []
    for layer in group:
        if not layer.visible:
            continue
        out.extend(_visible_leaves(layer) if layer.is_group() else [layer])
    return out


def _is_num(layer):
    try:
        t = (layer.text or "").strip()
    except Exception:
        return False
    return bool(t) and bool(_NUM.match(t)) and any(c.isdigit() for c in t)


def _blocks(layer):
    try:
        return layer._record.tagged_blocks
    except Exception:
        return None


def _tag(layer, name):
    from psd_tools.constants import Tag

    b, tag = _blocks(layer), getattr(Tag, name, None)
    if b is None or tag is None or tag not in b:
        return None
    return b[tag].data


def _v(x):
    return getattr(x, "value", x)


def _rgb(c):
    try:
        if b"redFloat" in c:
            return "#%02x%02x%02x" % tuple(int(round(float(c[k]) * 255)) for k in (b"redFloat", b"greenFloat", b"blueFloat"))
        return "#%02x%02x%02x" % tuple(int(round(float(_v(c[k])))) for k in (b"Rd  ", b"Grn ", b"Bl  "))
    except Exception:
        return None


def _box(layer):
    """A layer's box (x, y, w, h); a shape layer's own drawn box (its live shape), not its effects."""
    o = _tag(layer, "VECTOR_ORIGINATION_DATA")
    try:
        bb = o[b"keyDescriptorList"][0][b"keyOriginShapeBBox"]
        x0, y0, x1, y1 = (float(_v(bb[k])) for k in (b"Left", b"Top ", b"Rght", b"Btom"))
        if x1 > x0 and y1 > y0:
            return (x0, y0, x1 - x0, y1 - y0)
    except Exception:
        pass
    return (float(layer.left), float(layer.top), float(layer.width), float(layer.height))


def _centre(b):
    return (b[0] + b[2] / 2.0, b[1] + b[3] / 2.0)


def _inside(pt, b, pad=0.0):
    return b[0] - pad <= pt[0] <= b[0] + b[2] + pad and b[1] - pad <= pt[1] <= b[1] + b[3] + pad


def _union(boxes):
    x0 = min(b[0] for b in boxes)
    y0 = min(b[1] for b in boxes)
    x1 = max(b[0] + b[2] for b in boxes)
    y1 = max(b[1] + b[3] for b in boxes)
    return (x0, y0, x1 - x0, y1 - y0)


def shape_look(layer):
    """A card shape's look: {radius, fill_enabled, fill, fill_opacity, stroke{…}} in the PSD's px."""
    look = {"radius": 0, "fill_enabled": True, "fill": "#000000", "fill_opacity": 100,
            "stroke": {"enabled": False, "width": 2, "color": "#ffffff", "align": "inside"}, "fx": ""}
    o = _tag(layer, "VECTOR_ORIGINATION_DATA")
    try:
        r = o[b"keyDescriptorList"][0].get(b"keyOriginRRectRadii")
        if r:
            look["radius"] = max(float(_v(r[k])) for k in (b"topLeft", b"topRight", b"bottomRight", b"bottomLeft"))
    except Exception:
        pass
    fill = None
    soco = _tag(layer, "SOLID_COLOR_SHEET_SETTING")
    if soco is not None:
        fill = _rgb(soco.get(b"Clr ", {}))
    vc = _tag(layer, "VECTOR_STROKE_CONTENT_DATA")
    if fill is None and vc is not None:
        fill = _rgb(vc.get(b"Clr ", {}))
    vs = _tag(layer, "VECTOR_STROKE_DATA")
    if vs is not None:
        try:
            if not bool(_v(vs.get(b"fillEnabled", True))):
                look["fill_enabled"] = False
            if bool(_v(vs.get(b"strokeEnabled", False))):
                al = str(getattr(vs.get(b"strokeStyleLineAlignment"), "enum", vs.get(b"strokeStyleLineAlignment")) or "").lower()
                look["stroke"] = {"enabled": True, "width": float(_v(vs[b"strokeStyleLineWidth"])),
                                  "color": _rgb(vs[b"strokeStyleContent"][b"Clr "]) or "#ffffff",
                                  "align": "outside" if "out" in al else "center" if ("cent" in al or "cntr" in al) else "inside"}
        except Exception:
            pass
    if fill:
        look["fill"] = fill
    fop = _tag(layer, "BLEND_FILL_OPACITY")
    try:
        f = (float(fop) / 255.0) if fop is not None else 1.0
    except Exception:
        f = 1.0
    look["fill_opacity"] = round(100 * f * (layer.opacity / 255.0))
    if look["fill_opacity"] <= 1:
        look["fill_enabled"] = False
    fx = _effects(layer)
    if not look["stroke"]["enabled"] and "FrFX" in fx:   # a stroke as a layer effect (FrFX)
        look["stroke"] = {"enabled": True, "width": float(fx["FrFX"].get("size") or 2),
                          "color": fx["FrFX"].get("color") or "#ffffff", "align": "outside"}
    captured = {}
    if "OrGl" in fx:
        captured["outer_glow"] = {
            "enabled": True,
            "color": fx["OrGl"].get("color") or "#FFD24A",
            "opacity": 60,
            "size": max(4, int(round(float(fx["OrGl"].get("size") or 12)))),
            "spread": 0,
            "blend": "screen",
        }
    if "DrSh" in fx:
        captured["drop_shadow"] = {
            "enabled": True,
            "color": fx["DrSh"].get("color") or "#000000",
            "opacity": 65,
            "distance": 6,
            "size": max(4, int(round(float(fx["DrSh"].get("size") or 10)))),
            "angle": 120,
        }
    if captured:
        look["fx"] = {"captured_params": captured}
    return look


def _effects(layer):
    """The layer's switched-on effects: {key: {color, size}} (FrFX, OrGl, DrSh, IrGl, IrSh, ebbl …)."""
    d = _tag(layer, "OBJECT_BASED_EFFECTS_LAYER_INFO")
    out = {}
    if d is None:
        return out
    try:
        if not bool(_v(d.get(b"masterFXSwitch", True))):
            return out
    except Exception:
        pass
    for k in (b"FrFX", b"OrGl", b"DrSh", b"IrGl", b"IrSh", b"ebbl", b"GrFl", b"SoFi"):
        v = d.get(k)
        try:
            if v is not None and bool(_v(v.get(b"enab"))):
                out[k.decode().strip()] = {"color": _rgb(v.get(b"Clr ", {})) if v.get(b"Clr ") is not None else None,
                                           "size": float(_v(v.get(b"Sz  ") or v.get(b"blur") or 0) or 0)}
        except Exception:
            continue
    for k, name in ((b"frameFXMulti", "FrFX"), (b"dropShadowMulti", "DrSh"), (b"innerShadowMulti", "IrSh")):
        for v in d.get(k, []) or []:
            try:
                if bool(_v(v.get(b"enab"))) and name not in out:
                    out[name] = {"color": _rgb(v.get(b"Clr ", {})), "size": float(_v(v.get(b"Sz  ") or v.get(b"blur") or 0) or 0)}
            except Exception:
                continue
    return out


def _style(layer):
    from .learn_paytable import text_style

    try:
        s = text_style(layer)
    except Exception:
        return {}
    return {"font": s.get("font_name") or "", "font_size": float(s.get("font_size") or 30), "color": s.get("color") or "#ffffff",
            "align": s.get("alignment") or "center"}


# ------------------------------------------------------------------ the cards
def _cards_from_shapes(leaves, nums, page_area):
    """Card-sized shapes with numbers in them; two stacked (a back and a front) count once — the front."""
    cards = []
    for layer in leaves:
        if layer.kind != "shape":
            continue
        b = _box(layer)
        if b[2] < 20 or b[3] < 20 or b[2] * b[3] > 0.4 * page_area:
            continue
        inside = [n for n in nums if _inside(_centre(n[1]), b, 2)]
        if not inside:
            continue
        # front of a stack: a later layer of (nearly) the same box replaces the one behind it
        same = [c for c in cards if abs(c["box"][0] - b[0]) < 6 and abs(c["box"][1] - b[1]) < 6
                and abs(c["box"][2] - b[2]) < 8 and abs(c["box"][3] - b[3]) < 8]
        for c in same:
            cards.remove(c)
        cards.append({"box": b, "layer": layer, "nums": inside})
    # nested: a card inside another one (a page frame with numbers in it) — keep the inner ones
    return [c for c in cards if not any(o is not c and o["box"][2] * o["box"][3] < c["box"][2] * c["box"][3]
                                        and _inside(_centre(o["box"]), c["box"]) for o in cards)]


def _cards_from_groups(group, nums):
    """No card shapes: each innermost group with a picture and numbers in it is a card (its box: theirs)."""
    out = []

    def walk(g):
        found = False
        for layer in g:
            if layer.is_group() and layer.visible and walk(layer):
                found = True
        if found:
            return True
        leaves = _visible_leaves(g)
        pics = [x for x in leaves if x.kind in ("smartobject", "pixel") and x.width >= 30 and x.height >= 30]
        mine = [n for n in nums if n[0] in leaves]
        if g is not group and pics and mine and len(leaves) <= 16:
            out.append({"box": _union([_box(x) for x in pics] + [n[1] for n in mine]), "layer": None, "nums": mine})
            return True
        return False

    walk(group)
    return out


def _rows(cards):
    rows = []
    for c in sorted(cards, key=lambda c: _centre(c["box"])[1]):
        cy, h = _centre(c["box"])[1], c["box"][3]
        if rows and abs(cy - rows[-1]["cy"]) <= 0.5 * h:
            rows[-1]["cards"].append(c)
        else:
            rows.append({"cy": cy, "cards": [c]})
    for r in rows:
        r["cards"].sort(key=lambda c: c["box"][0])
    return rows


def _columns(card):
    """The numbers in a card as columns: [{"layers", "box", "values"}], left to right."""
    cols = []
    for layer, b in sorted(card["nums"], key=lambda n: n[1][0]):
        cx = _centre(b)[0]
        col = next((c for c in cols if abs(_centre(c["box"])[0] - cx) <= 0.12 * card["box"][2]), None)
        if col:
            col["layers"].append(layer)
            col["box"] = _union([col["box"], b])
        else:
            cols.append({"layers": [layer], "box": b})
    for c in cols:
        c["values"] = [float(v.replace(",", "")) for x in c["layers"] for v in re.findall(r"\d[\d,]*(?:\.\d+)?", x.text or "")]
    return cols


def _frac(b, card):
    cx, cy, cw, ch = card
    x0 = max(0.0, min(1.0, (b[0] - cx) / cw))
    y0 = max(0.0, min(1.0, (b[1] - cy) / ch))
    x1 = max(0.0, min(1.0, (b[0] + b[2] - cx) / cw))
    y1 = max(0.0, min(1.0, (b[1] + b[3] - cy) / ch))
    return {"x": round(x0, 3), "y": round(y0, 3), "w": round(max(0.02, x1 - x0), 3), "h": round(max(0.02, y1 - y0), 3)}


def _parts(cards, leaves, s):
    """The symbol / counts / pays boxes in a card (median over the cards) with the numbers' text look."""
    found = {"symbol": [], "counts": [], "pays": []}
    looks = {"counts": [], "pays": []}
    digits = {"counts": 1, "pays": 1}

    def longest(layers):
        return max([len(re.sub(r"\D", "", v)) for x in layers for v in re.findall(r"\d[\d,]*", x.text or "")] or [1])
    for c in cards:
        box = c["box"]
        def overlap(b):                                # how much of a picture lies in the card
            ix = max(0.0, min(b[0] + b[2], box[0] + box[2]) - max(b[0], box[0]))
            iy = max(0.0, min(b[1] + b[3], box[1] + box[3]) - max(b[1], box[1]))
            return ix * iy / max(1.0, b[2] * b[3])

        pics = [x for x in leaves if x.kind in ("smartobject", "pixel") and x is not c["layer"]
                and overlap(_box(x)) >= 0.4 and _box(x)[3] >= 0.15 * box[3] and _box(x)[2] < 0.95 * box[2]]
        if pics:
            found["symbol"].append(_frac(_box(max(pics, key=lambda x: x.width * x.height)), box))
        tabbed = [n for n in c["nums"] if "\t" in (n[0].text or "")]
        if tabbed:                                     # counts and pays in one layer: left part, right part
            layer, b = tabbed[0]
            st = _style(layer)
            found["counts"].append(_frac((b[0], b[1], b[2] * 0.4, b[3]), box))
            found["pays"].append(_frac((b[0] + b[2] * 0.45, b[1], b[2] * 0.55, b[3]), box))
            digits["pays"] = max(digits["pays"], max([len(v) for v in re.findall(r"\d+", layer.text or "")] or [1]))
            looks["counts"].append(st)
            looks["pays"].append(st)
            continue
        cols = _columns(c)
        if not cols:
            continue
        counts = [col for col in cols if col["values"] and all(v <= 10 and float(v).is_integer() for v in col["values"])]
        pays = [col for col in cols if col not in counts]
        if counts and pays:
            cnt, pay = counts[0], max(pays, key=lambda col: max(col["values"] or [0]))
        elif len(cols) >= 2:
            cnt, pay = cols[0], cols[-1]
        else:
            cnt, pay = None, cols[0]
        if cnt:
            found["counts"].append(_frac(cnt["box"], box))
            looks["counts"].append(_style(cnt["layers"][0]))
            digits["counts"] = max(digits["counts"], longest(cnt["layers"]))
        digits["pays"] = max(digits["pays"], longest(pay["layers"]))
        found["pays"].append(_frac(pay["box"], box))
        looks["pays"].append(_style(pay["layers"][0]))
    parts = []
    for role in ("symbol", "counts", "pays"):
        if not found[role]:
            continue
        p = {"role": role}
        for k in ("x", "y", "w", "h"):
            p[k] = round(statistics.median(f[k] for f in found[role]), 3)
        if role != "symbol" and looks[role]:
            sty = [x for x in looks[role] if x]
            if sty:
                p["font_size"] = round(statistics.median(x["font_size"] for x in sty) * s, 1)
                p["color"] = statistics.mode(x["color"] for x in sty)
                p["align"] = statistics.mode(x["align"] for x in sty)
                p["font"] = statistics.mode(x["font"] for x in sty)
            p["digits"] = digits[role]
        parts.append(p)
    return parts


def _roomy(parts, s, w_px):
    """Number boxes wide enough for their numbers: an artist's text box hugs the digits it has (a count
    "5" is one digit wide); here the counts get room for 2 digits and the pays for 5, grown from the side
    their text is aligned to."""
    out = []
    for p in parts:
        p = dict(p)
        if p.get("role") in ("counts", "pays") and p.get("font_size") and w_px:
            # room for the longest number the artist set, in the artist's px
            d = int(p.get("digits") or 1)
            need = (0.62 * d + 0.3) * float(p["font_size"]) / s / w_px
            if p["w"] < need:
                grow = need - p["w"]
                al = p.get("align") or "center"
                x = p["x"] - (grow if al == "right" else 0 if al == "left" else grow / 2.0)
                cnt = next((c for c in out if c.get("role") == "counts"), None)
                if p["role"] == "pays" and cnt and cnt["x"] < p["x"]:
                    x = max(x, cnt["x"] + cnt["w"] + 0.01)        # the pays grow away from the counts
                x = max(0.0, min(1.0 - min(need, 1.0), x))
                p["x"], p["w"] = round(x, 3), round(max(p["w"], min(need, 1.0 - x)), 3)
        p.pop("digits", None)
        out.append(p)
    # grown counts never run into the pays: they stop just before them
    cnt = next((p for p in out if p.get("role") == "counts"), None)
    pay = next((p for p in out if p.get("role") == "pays"), None)
    if cnt and pay and cnt["x"] < pay["x"] and cnt["x"] + cnt["w"] > pay["x"] - 0.01:
        right = pay["x"] + pay["w"]                     # no room for both: they share what lies between
        mid = (cnt["x"] + cnt["w"] + pay["x"]) / 2.0
        cnt["w"] = round(max(0.03, mid - 0.005 - cnt["x"]), 3)
        pay["x"] = round(mid + 0.005, 3)
        pay["w"] = round(max(0.03, right - pay["x"]), 3)
    return out


# ------------------------------------------------------------------ the design
def learn(psd, group_path, base, out_width=DW):
    """(card design, report) from the artist's page ``group_path`` in ``psd``, built on ``base``.
    ``out_width``: the project's canvas width — card text sizes are in its px (boxes in design px)."""
    g = find_group(psd, group_path)
    if g is None:
        raise ValueError(f"No group “{group_path}” in the PSD.")
    W, H = (float(v) for v in psd.size)
    leaves = [x for x in _visible_leaves(g) if x.width * x.height < 0.8 * W * H]   # not a page background
    if not leaves:
        raise ValueError("The page group has nothing visible in it.")
    page = _union([_box(x) for x in leaves])
    nums = [(x, _box(x)) for x in leaves if x.kind == "type" and _is_num(x)]
    notes = []
    cards = _cards_from_shapes(leaves, nums, page[2] * page[3])
    if len(cards) < 3:
        cards = _cards_from_groups(g, nums)
        if cards:
            notes.append("No card shapes on this page: each symbol's own group is a card, with no fill or stroke.")
    if len(cards) < 2:
        raise ValueError("No paytable cards found on this page (card shapes or symbol groups with their pays).")
    s = min(DW / page[2], DH / page[3])                # artist px → design px
    rows = _rows(cards)
    high, low = rows[0]["cards"], [c for r in rows[1:] for c in r["cards"]]

    def band(cs, name, base_band):
        b = copy.deepcopy(base_band or {})
        ws = [c["box"][2] for c in cs]
        hs = [c["box"][3] for c in cs]
        per = max(len(r["cards"]) for r in rows if any(c in cs for c in r["cards"]))
        w_px, h_px = statistics.median(ws), statistics.median(hs)
        gaps = [r["cards"][i + 1]["box"][0] - (r["cards"][i]["box"][0] + r["cards"][i]["box"][2])
                for r in rows for i in range(len(r["cards"]) - 1) if all(c in cs for c in r["cards"][i:i + 2])]
        gap = (statistics.median(gaps) if gaps else 0.12 * w_px)
        # the cards fill their row on this page (the page has its own boxes and text), at the artist's
        # proportions: the card's height to width, the gap to the card
        left, right = float(page_t.get("left", 60)), float(page_t.get("right", 60))
        # a row of one or two cards is sized like the page's fullest row (else it would fill the page)
        n = max(per, max(len(r["cards"]) for r in rows))
        cw = (DW - left - right) / (n + (n - 1) * gap / w_px)
        b.update(name=name, per_row=per, card_h=round(cw * h_px / w_px, 1), gap_x=round(cw * max(0.0, gap) / w_px, 1))
        for k in ("pos", "lock_size", "card_w"):
            b.pop(k, None)
        b["parts"] = _roomy(_parts(cs, leaves, s), s, w_px)
        b["_scale"] = cw / w_px
        return b

    t = copy.deepcopy(base or {})
    page_t = t.get("page") or {}
    bands = t.get("bands") or [{"name": "high"}, {"name": "low"}]
    t["bands"] = [band(high, "high", bands[0])] + ([band(low, "low", bands[min(1, len(bands) - 1)])] if low else [])
    k = t["bands"][0].get("_scale", s)                 # artist px → design px for this page's cards
    if len(rows) > 1:
        t.setdefault("page", {})["gap_y"] = round(max(0.0, rows[1]["cards"][0]["box"][1] - (rows[0]["cards"][0]["box"][1] + rows[0]["cards"][0]["box"][3])) * k, 1)
    out_k = float(out_width or DW) / DW
    for b in t["bands"]:                               # the numbers keep their size against their card
        kb = b.pop("_scale", s)
        for p in b["parts"]:
            if p.get("font_size"):
                p["font_size"] = round(p["font_size"] / s * kb * out_k, 1)
    # the cards' look: the front card shape of the high row (its corners, fill, stroke)
    styles = t.setdefault("styles", {})
    shape = next((c["layer"] for c in high if c["layer"] is not None), None)
    look = shape_look(shape) if shape is not None else {"radius": 0, "fill_enabled": False, "fill": "#000000", "fill_opacity": 0,
                                                        "stroke": {"enabled": False, "width": 2, "color": "#ffffff", "align": "inside"}, "fx": ""}
    look["radius"] = round(float(look.get("radius") or 0) * k, 1)
    look["stroke"]["width"] = round(max(1.0, float(look["stroke"].get("width") or 2) * k), 1)
    for name in ("card", "high_card", "low_card"):
        if name == "card" or name in styles:
            styles[name] = copy.deepcopy(look)
    for b in t["bands"]:
        b["style"] = "card"
    t.setdefault("card", {})["parts"] = copy.deepcopy(t["bands"][0]["parts"])
    for key in ("card_order", "row_of", "tiers"):       # the artist's page decides the arrangement now
        t.pop(key, None)
    fx = _effects(shape) if shape is not None else {}
    if any(k in fx for k in ("OrGl", "DrSh", "IrGl", "IrSh", "ebbl", "GrFl")):
        notes.append("The cards' glow / shadow / bevel aren't carried — pick a layer style for them in the Row bar.")
    # the title: the biggest text above the cards
    top = min(c["box"][1] for c in cards)
    words = [x for x in leaves if x.kind == "type" and not _is_num(x) and _box(x)[1] + _box(x)[3] <= top + 4]
    if words:
        tl = max(words, key=lambda x: (_style(x).get("font_size") or 0))
        st = _style(tl)
        if st:
            title = t.setdefault("page", {}).setdefault("title", {})
            title.setdefault("text", {}).update(font_size=round(st["font_size"] * k * float(out_width or DW) / DW, 1), color=st["color"])
    t.update(id="learned_" + re.sub(r"[^a-z0-9]+", "_", str(group_path).lower()).strip("_"),
             name=f"From the artist: {str(group_path).split('/')[-1]}", edited=True,
             based_on=(base or {}).get("id"), learned_from={"group": group_path})
    report = {"cards": len(cards), "rows": [len(r["cards"]) for r in rows],
              "card_px": [round(statistics.median(c["box"][2] for c in high)), round(statistics.median(c["box"][3] for c in high))],
              "scale": round(s, 3), "look": look, "parts": t["bands"][0]["parts"], "notes": notes,
              "from_shapes": cards[0]["layer"] is not None}
    return t, report
