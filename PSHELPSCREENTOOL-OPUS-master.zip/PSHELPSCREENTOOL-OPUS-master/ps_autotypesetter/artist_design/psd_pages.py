"""Page groups of an artist's PSD: copied or marked inside the file, without Photoshop.

A new AGR sheet is almost always a variant of a page the PSD already has (another
denom, a "continued" page), so its page is made the way an artist would: the
nearest page group is duplicated — every layer, style, strip and symbol picture —
and then filled with the new sheet's text (market_clone). A sheet that left the
AGR keeps its group, labelled red and renamed, for the artist to remove.

Everything is done on the layer records, as Photoshop's own "Duplicate Group"
would: the copy's layers get new layer ids, each copied text layer its own entry in
the document text block (Txt2) and each smart object its own instance id (the
embedded picture stays shared), and the document's per-layer lists (image
resources 1026 / 1072) grow with them. Records are listed bottom to top: a group
is its closing "</Layer group>" record, its contents, then its own record on top.
"""
import copy
import uuid

from psd_tools.constants import SheetColorType, Tag

COLORS = {"red": SheetColorType.RED, "green": SheetColorType.GREEN, "yellow": SheetColorType.YELLOW,
          "orange": SheetColorType.ORANGE, "none": SheetColorType.NO_COLOR}


class _Rec:
    """A record standing in for its layer (group_span finds groups by their record)."""

    def __init__(self, record):
        self._record = record

    def is_group(self):
        return True


def set_color(record, color):
    record.tagged_blocks.set_data(Tag.SHEET_COLOR_SETTING, COLORS[color])


def nest_groups(psd, groups, name, color="red", hidden=True):
    """Put top-level groups (their whole contents) into one new top-level group at the top of the
    Layers panel, e.g. pages whose sheets left the AGR into "[Deleted From Excel]": the new group
    and the groups in it are labelled `color` and, with `hidden`, switched off. Returns the new
    group's record."""
    tops = list(psd)
    cont = empty_group_like(psd, groups[0], above=tops[-1], name=name, color=color)
    holder = _Rec(cont)
    info = _layer_info(psd)
    recs, chans = info.layer_records, info.channel_image_data
    res = psd._record.image_resources
    lists = [getattr(getattr(res.get(k), "data", None), "_items", None) for k in (1026, 1072)]
    lists = [x for x in lists if x is not None and len(x) == len(recs)]
    for g in groups:
        first, last = group_span(psd, g)
        block = (recs._items[first:last + 1], chans._items[first:last + 1], [x[first:last + 1] for x in lists])
        del recs._items[first:last + 1]
        del chans._items[first:last + 1]
        for x in lists:
            del x[first:last + 1]
        at = group_span(psd, holder)[1]               # just under the new group's top
        recs._items[at:at] = block[0]
        chans._items[at:at] = block[1]
        for x, part in zip(lists, block[2]):
            x[at:at] = part
        set_color(g._record, color)
        if hidden:
            g._record.flags.visible = False
    if hidden:
        cont.flags.visible = False
    return cont


def _layer_info(psd):
    return psd._record.layer_and_mask_information.layer_info


def group_span(psd, group):
    """(first, last) record indexes of a top-level group: its closing marker .. its own record."""
    recs = _layer_info(psd).layer_records
    last = next(i for i, r in enumerate(recs) if r is group._record)
    depth, i = 0, last
    while i >= 0:
        sec = recs[i].tagged_blocks.get_data(Tag.SECTION_DIVIDER_SETTING)
        kind = int(getattr(sec, "kind", 0) or 0) if sec is not None else 0
        if kind in (1, 2):
            depth += 1
        elif kind == 3:
            depth -= 1
            if depth == 0:
                return i, last
        i -= 1
    raise ValueError(f"group {group.name!r} has no closing marker")


def rename(record, name):
    record.name = name[:255]
    record.tagged_blocks.set_data(Tag.UNICODE_LAYER_NAME, name)


def mark_group(psd, group, name=None, color="red"):
    """Label a page group with a colour (and a new name), as the Layers panel shows them."""
    record = group._record
    record.tagged_blocks.set_data(Tag.SHEET_COLOR_SETTING, COLORS[color])
    if name:
        rename(record, name)


def _text_engine(psd):
    blocks = psd._record.layer_and_mask_information.tagged_blocks
    data = blocks.get_data(Tag.TEXT_ENGINE_DATA) if blocks is not None else None
    return data


def _copy_text_object(engine, index):
    """A new Txt2 text object (with its own frame) copied from object `index`; returns its index."""
    from .psd_reader import engine_copy

    objects, frames = engine["1"]["1"], engine["0"]["8"]["0"]
    obj = engine_copy(objects[index])
    frame_old = None
    view = obj["1"]
    try:
        frame_old = int(view["0"][0]["0"])
    except Exception:
        pass
    new_frame = None
    if frame_old is not None and frame_old < len(frames):
        frames.append(engine_copy(frames[frame_old]))
        new_frame = len(frames) - 1
        view["0"][0]["0"] = type(view["0"][0]["0"])(new_frame)

        def walk(node):                               # the line layout names its frame too
            if hasattr(node, "items"):
                if str(node.get("99", "")) == "F" and "10" in node and int(node["10"]) == frame_old:
                    node["10"] = type(node["10"])(new_frame)
                for _k, v in node.items():
                    walk(v)
            elif isinstance(node, list):
                for v in node:
                    walk(v)

        if "2" in view:
            walk(view["2"])
    objects.append(obj)
    return len(objects) - 1


def duplicate_group(psd, group, above=None, name=None, color="green"):
    """Copy a top-level page group, every layer in it, into the PSD. The copy goes right above the
    top-level layer `above` (default: right above the group itself). Returns the copy's record
    indexes (first, last) in the new layer list."""
    info = _layer_info(psd)
    recs, chans = info.layer_records, info.channel_image_data
    first, last = group_span(psd, group)
    at = (group_span(psd, above)[1] if above is not None and above.is_group()
          else next(i for i, r in enumerate(recs) if r is above._record) if above is not None else last) + 1
    next_id = [1 + max(int(r.tagged_blocks.get_data(Tag.LAYER_ID) or 0) for r in recs)]
    engine = _text_engine(psd)
    if engine is not None:                            # copies get text objects of their own
        from ..psd_apply import splice

        splice.mark_document(psd)
    new_recs, new_chans = [], []
    for i in range(first, last + 1):
        rec, ch = _copy_record(recs[i], chans[i], engine, next_id)
        new_recs.append(rec)
        new_chans.append(ch)
    top = new_recs[-1]
    if name:
        rename(top, name)
    if color:
        top.tagged_blocks.set_data(Tag.SHEET_COLOR_SETTING, COLORS[color])
    recs._items[at:at] = new_recs
    chans._items[at:at] = new_chans
    info.layer_count = (abs(info.layer_count) + len(new_recs)) * (-1 if info.layer_count < 0 else 1)
    _grow_layer_lists(psd, first, last, at)
    return at, at + len(new_recs) - 1


def _copy_record(rec, chan, engine, next_id):
    """A layer record (and its pixels) copied the way Photoshop duplicates a layer: its own layer id,
    its own document text entry, its own smart-object instance (the embedded picture shared)."""
    rec = copy.deepcopy(rec)
    tb = rec.tagged_blocks
    if tb.get_data(Tag.LAYER_ID) is not None:
        tb.set_data(Tag.LAYER_ID, next_id[0])
        next_id[0] += 1
    tool = tb.get_data(Tag.TYPE_TOOL_OBJECT_SETTING)
    if tool is not None and engine is not None and b"TextIndex" in tool.text_data:
        idx = int(tool.text_data[b"TextIndex"])
        tool.text_data[b"TextIndex"] = type(tool.text_data[b"TextIndex"])(_copy_text_object(engine, idx))
    placed = str(uuid.uuid4())
    for tag in (Tag.PLACED_LAYER1, Tag.PLACED_LAYER2):
        pl = tb.get_data(tag)
        if pl is not None and getattr(pl, "uuid", None) is not None:
            pl.uuid = placed.encode("ascii") if isinstance(pl.uuid, bytes) else placed
    for tag in (Tag.SMART_OBJECT_LAYER_DATA1, Tag.SMART_OBJECT_LAYER_DATA2):
        so = tb.get_data(tag)
        if so is not None and b"placed" in so.data:
            so.data[b"placed"] = type(so.data[b"placed"])(placed + "\x00")
    return rec, copy.deepcopy(chan)


def copy_layers(psd, layers, into=None):
    """Copy single (non-group) layers. Each copy goes right above its original — or, with `into` (a
    top-level group), inside that group just under its top. Returns the copies' records, in order;
    the layer tree must be rebuilt from the records afterwards to use them as layers."""
    info = _layer_info(psd)
    recs, chans = info.layer_records, info.channel_image_data
    next_id = [1 + max(int(r.tagged_blocks.get_data(Tag.LAYER_ID) or 0) for r in recs)]
    engine = _text_engine(psd)
    if engine is not None:                            # copies get text objects of their own
        from ..psd_apply import splice

        splice.mark_document(psd)
    out = []
    for layer in layers:
        i = next(k for k, r in enumerate(recs) if r is layer._record)
        rec, ch = _copy_record(recs[i], chans[i], engine, next_id)
        at = group_span(psd, into)[1] if into is not None else i + 1
        recs._items[at:at] = [rec]
        chans._items[at:at] = [ch]
        info.layer_count = (abs(info.layer_count) + 1) * (-1 if info.layer_count < 0 else 1)
        _grow_layer_lists(psd, i, i, at)              # the per-layer lists haven't moved yet: entry i
        out.append(rec)
    return out


def empty_group_like(psd, group, above=None, name=None, color="green"):
    """A new, empty top-level group with `group`'s own settings, right above the top-level layer
    `above` (default: above `group`). Returns its top record."""
    info = _layer_info(psd)
    recs, chans = info.layer_records, info.channel_image_data
    first, last = group_span(psd, group)
    at = (group_span(psd, above)[1] if above is not None and above.is_group()
          else next(i for i, r in enumerate(recs) if r is above._record) if above is not None else last) + 1
    next_id = [1 + max(int(r.tagged_blocks.get_data(Tag.LAYER_ID) or 0) for r in recs)]
    close_rec, close_ch = _copy_record(recs[first], chans[first], None, next_id)
    top_rec, top_ch = _copy_record(recs[last], chans[last], None, next_id)
    if name:
        rename(top_rec, name)
    if color:
        top_rec.tagged_blocks.set_data(Tag.SHEET_COLOR_SETTING, COLORS[color])
    recs._items[at:at] = [close_rec, top_rec]
    chans._items[at:at] = [close_ch, top_ch]
    info.layer_count = (abs(info.layer_count) + 2) * (-1 if info.layer_count < 0 else 1)
    res = psd._record.image_resources
    for key in (1026, 1072):
        items = getattr(getattr(res.get(key), "data", None), "_items", None)
        if items is not None and len(items) > last:
            items[at:at] = [items[first], items[last]]
    return top_rec


def move_layers(psd, layers, into):
    """Move single layers (their records, pixels and per-layer entries) into the top-level group
    `into`, each just under its top, in the order given (the last ends up highest)."""
    info = _layer_info(psd)
    recs, chans = info.layer_records, info.channel_image_data
    res = psd._record.image_resources
    lists = [getattr(getattr(res.get(k), "data", None), "_items", None) for k in (1026, 1072)]
    lists = [x for x in lists if x is not None and len(x) == len(recs)]
    for layer in layers:
        i = next(k for k, r in enumerate(recs) if r is layer._record)
        rec, ch = recs._items.pop(i), chans._items.pop(i)
        entries = [x.pop(i) for x in lists]
        at = group_span(psd, into)[1]
        recs._items.insert(at, rec)
        chans._items.insert(at, ch)
        for x, e in zip(lists, entries):
            x.insert(at, e)


def _grow_layer_lists(psd, first, last, at):
    """The document's one-entry-per-layer lists get the copied layers' entries at the same place."""
    res = psd._record.image_resources
    n = last - first + 1
    for key in (1026, 1072):                          # group ids for dragging / groups enabled
        block = res.get(key)
        items = getattr(getattr(block, "data", None), "_items", None)
        if items is not None and len(items) >= last + 1:
            items[at:at] = list(items[first:last + 1])
    target = getattr(res.get(1024), "data", None)    # the selected layer, counted from the bottom
    if target is not None and hasattr(target, "value") and int(target.value) >= at:
        target.value = int(target.value) + n


def ensure_layer_ids(psd):
    """Give every layer record its own Photoshop layer ID. A PSD written without Photoshop (the tool's
    own writer) has none (psd-tools reads -1 for all of them), and bindings find layers by ID; a
    record with a repeated ID gets a new one too. Photoshop gives IDs the same way (one counter for
    the document). Returns how many records got one."""
    recs = _layer_info(psd).layer_records
    seen, without = set(), []
    for rec in recs:
        lid = rec.tagged_blocks.get_data(Tag.LAYER_ID) if rec.tagged_blocks is not None else None
        if lid is None or int(lid) <= 0 or int(lid) in seen:
            without.append(rec)
        else:
            seen.add(int(lid))
    next_id = max(seen, default=0) + 1
    for rec in without:
        if rec.tagged_blocks is None:
            continue
        rec.tagged_blocks.set_data(Tag.LAYER_ID, next_id)
        next_id += 1
    return len(without)
