"""Fit a learned (artist-design) paytable template to the CURRENT sheet.

Runs at render time, so Excel stays the source of truth:
  * cards whose symbol is not in the sheet are dropped (with their art);
  * symbols the design has no card for get a clone of a sibling card,
    placed on the artist's grid (next column, wrapping to a new row); if the
    grid would run past the design's content area, the card grid is scaled
    down uniformly to fit;
  * rules text drops the icon tokens the artist placed beside the sentence
    (those icons are their own slots), keeping the rest inline.
Returns a NEW template; the saved one is never modified.
"""
import copy
import re

TOKEN_RE = re.compile(r"<([^<>]+)>")
_LOW = {"ace", "king", "queen", "jack", "ten", "nine", "a", "k", "q", "j", "10", "9"}


def break_after_words(text, words):
    """Insert line breaks after `words`, in order, each after the previous break."""
    pos = 0
    for word in words:
        # the word (plus trailing punctuation) followed by a space: break there
        m = re.compile(r"(?<![^\W_])" + re.escape(word) + r"(?![^\W_])[^\s<]*\s+", re.IGNORECASE).search(text, pos)
        if not m:
            continue
        head = text[:m.end()].rstrip()
        text = head + "\n" + text[m.end():]
        pos = len(head) + 1
    return text


def is_artist_template(template):
    # the artist_design block survives the mapper's re-saves (generated_by does not)
    return isinstance(((template or {}).get("mapper_meta") or {}).get("artist_design"), dict)


def _tier(key):
    return "low" if str(key).casefold() in _LOW else "high"


def prepare(template, ws, notes=None, target=None):
    """Return a copy of `template` fitted to worksheet `ws` (None -> unchanged copy).

    `target` = (width, height) of the output canvas: slot boxes are scaled to it
    by the renderers, but mapped font sizes are output pixels, so the learned
    (artist-canvas) sizes are scaled here by the same contain factor.
    """
    t = copy.deepcopy(template)
    if not is_artist_template(t):
        return t
    _art_first(t)
    if target:
        _scale_sizes(t, target)
    if ws is None:
        return t
    from ..ui_web.engine_api import automap_paytable_slots_ws

    meta = t["mapper_meta"]["artist_design"]
    slots, mappings = t["slots"], t["mappings"]
    blocks = automap_paytable_slots_ws(ws, {"slots": {}, "slot_prefix": "@slot"}).get("blocks") or []
    live = {b["key"]: b for b in blocks}
    cards = list(meta.get("cards") or [])
    design_cards = [c for c in cards if not c.get("cloned_from")]   # the artist's own grid
    say = (lambda m: notes.append(m)) if isinstance(notes, list) else (lambda m: None)

    # 1. rules text: drop tokens the artist moved beside the sentence and
    #    keep the artist's manual line breaks where the same words still occur
    for name, spec in mappings.items():
        drop = [d.casefold() for d in spec.get("drop_tokens") or []]
        breaks = [str(w).casefold() for w in spec.get("break_after") or []]
        if not (drop or breaks) or not spec.get("source"):
            continue
        try:
            cell = str(ws[spec["source"]].value or "")
        except Exception:
            continue
        text = TOKEN_RE.sub(lambda m: "" if m.group(1).strip().casefold() in drop else m.group(0), cell)
        spec["mode"] = "literal"          # keeps the remaining <tokens> for inline icons
        spec["text"] = break_after_words(re.sub(r"\s+", " ", text).strip(), breaks)

    # 2. drop cards whose symbol is gone
    kept = []
    for card in cards:
        if card["symbol"] in live:
            kept.append(card)
            continue
        for member in card["slots"]:
            slots.pop(member, None)
            mappings.pop(member, None)
        say(f"Card '{card['symbol']}' is not in the sheet: removed.")
    cards = kept

    # 3. clone cards for symbols the design lacks, on the artist's grid
    pitch = meta.get("pitch") or {}
    px, py = float(pitch.get("x") or 0), float(pitch.get("y") or 0)
    have = {c["symbol"] for c in cards}
    extra = [b for b in blocks if b["key"] not in have]
    if extra and cards:
        free = _free_cells(design_cards, cards)
        left = min(c["box"]["x"] for c in design_cards)
        right = max(c["box"]["x"] + c["box"]["w"] for c in design_cards)
        grid_bottom = max(c["box"]["y"] + c["box"]["h"] for c in design_cards)
        row_y, row_x, row_h = None, left, 0.0                 # the row of new cards below the grid
        for block in extra:
            same_tier = [c for c in cards if _tier(c["symbol"]) == _tier(block["key"])] or cards
            src = max(same_tier, key=lambda c: (c["box"]["y"], c["box"]["x"]))
            w, h = src["box"]["w"], src["box"]["h"]
            # a cell a dropped card left (same tier's row first), else a new row below the grid
            cell = next((f for f in free if abs(f[1] - src["box"]["y"]) < 50), None) or (free[0] if free else None)
            if cell is not None:
                free.remove(cell)
                x, y = cell
            else:
                if row_y is None or row_x + w > right + 1:
                    row_y = (grid_bottom if row_y is None else row_y + row_h) + 10
                    row_x, row_h = left, 0.0
                x, y = row_x, row_y
                row_x += px or (w + 10)
                row_h = max(row_h, h)
            new = _clone_card(src, block, x - src["box"]["x"], y - src["box"]["y"], slots, mappings)
            cards.append(new)
            say(f"Card '{block['key']}' added by cloning '{src['symbol']}' — review its placement.")
        _fit_grid(cards, slots, mappings, float(meta.get("content_bottom") or 0), say)

    meta["cards"] = cards
    _art_first(t)                       # again: cloned card art must sit under its card too
    return t


def _free_cells(design_cards, kept):
    """(x, y) of the artist's card cells whose card was dropped, top row first."""
    taken = {c["symbol"] for c in kept}
    return sorted(((c["box"]["x"], c["box"]["y"]) for c in design_cards if c["symbol"] not in taken),
                  key=lambda p: (p[1], p[0]))


def _art_first(t):
    """Design art (exact-fit image slots) first: renderers draw slots in order.

    Slot order is not reliable once a template went through JSON APIs that sort
    keys (Flask's jsonify), so it is re-established at render time.
    """
    slots, mappings = t.get("slots") or {}, t.get("mappings") or {}
    if not isinstance(slots, dict) or not isinstance(mappings, dict):
        return
    is_art = lambda n: str((mappings.get(n) or {}).get("fit") or "").casefold() == "exact"
    t["slots"] = {n: slots[n] for n in sorted(slots, key=lambda n: 0 if is_art(n) else 1)}


def _scale_sizes(t, target):
    canvas = t.get("canvas") or {}
    try:
        s = min(float(target[0]) / float(canvas["width"]), float(target[1]) / float(canvas["height"]))
    except Exception:
        return
    if abs(s - 1.0) < 1e-3:
        return
    for spec in (t.get("mappings") or {}).values():
        for key in ("font_size", "line_height", "leading", "icon_height"):
            if spec.get(key):
                spec[key] = round(float(spec[key]) * s, 2)


def _clone_card(src, block, dx, dy, slots, mappings):
    old, new = src["symbol"], block["key"]
    members = []
    for member in src["slots"]:
        name = member.replace(old, new, 1) if member.startswith(old) else f"{member}.{new}"
        box = dict(slots[member])
        box["x"] = box["x"] + dx
        box["y"] = box["y"] + dy
        slots[name] = box
        spec = copy.deepcopy(mappings.get(member) or {})
        spec["slot"] = name
        spec["symbol"] = new
        if spec.get("mode") == "icon" and str(spec.get("token") or "").casefold() == f"<{old}>".casefold():
            spec["token"] = f"<{new}>"
        if spec.get("role") == "pay":
            spec["source"] = block["pay_ref"]
        elif spec.get("role") == "value":
            spec["source"] = block["value_ref"]
        mappings[name] = spec
        members.append(name)
    b = src["box"]
    return {"symbol": new, "slots": members, "cloned_from": old,
            "box": {"x": b["x"] + dx, "y": b["y"] + dy, "w": b["w"], "h": b["h"]}}


def _fit_grid(cards, slots, mappings, content_bottom, say):
    """Shrink the card grid (boxes, fonts, icons) if it overflows the design area.

    Scales about the grid's top edge and horizontal centre, so the grid stays
    where the artist centred it.
    """
    if not cards or content_bottom <= 0:
        return
    top = min(c["box"]["y"] for c in cards)
    bottom = max(c["box"]["y"] + c["box"]["h"] for c in cards)
    if bottom <= content_bottom:
        return
    cx = (min(c["box"]["x"] for c in cards) + max(c["box"]["x"] + c["box"]["w"] for c in cards)) / 2.0
    s = (content_bottom - top) / float(bottom - top)
    for card in cards:
        for member in card["slots"]:
            box = slots[member]
            box["x"] = cx + (box["x"] - cx) * s
            box["y"] = top + (box["y"] - top) * s
            box["w"] *= s
            box["h"] *= s
            spec = mappings.get(member) or {}
            for key in ("font_size", "line_height", "leading", "icon_height"):
                if spec.get(key):
                    spec[key] = round(float(spec[key]) * s, 2)
        b = card["box"]
        card["box"] = {"x": cx + (b["x"] - cx) * s, "y": top + (b["y"] - top) * s, "w": b["w"] * s, "h": b["h"] * s}
    say(f"Card grid scaled to {s:.0%} so every symbol fits.")
