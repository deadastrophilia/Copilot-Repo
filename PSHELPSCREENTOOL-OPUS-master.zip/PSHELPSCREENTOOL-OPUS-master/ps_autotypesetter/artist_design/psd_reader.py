"""Fast PSD opening for design learning.

psd-tools parses every text layer's EngineData — and the document-wide
``Txt2`` text-engine block — eagerly, in pure Python. On an 86 MB artist PSD
with 314 text layers that is ~98 % of a 54 s open. Here those blocks are kept
as raw bytes and parsed only when something asks for them (a layer's
``engine_dict`` / ``resource_dict``), so opening takes a few seconds.
Unparsed blocks write back byte-for-byte.

``open_psd()`` also keeps the most recently opened file in memory (keyed by
path + size + mtime), so re-opening the same design is instant.
"""
import logging
import os
import threading

from psd_tools import PSDImage
from psd_tools.constants import Tag
from psd_tools.psd import tagged_blocks as _tb

logging.getLogger("psd_tools").setLevel(logging.ERROR)

_PATCH_LOCK = threading.Lock()
_CACHE = {"key": None, "psd": None}


class LazyEngineData:
    """Stands in for a parsed EngineData / EngineData2 until first use."""

    __slots__ = ("_raw", "_parser", "_parsed")

    def __init__(self, raw, parser):
        self._raw = bytes(raw)
        self._parser = parser
        self._parsed = None

    @property
    def parsed(self):
        if self._parsed is None:
            try:
                self._parsed = self._parser.frombytes(self._raw)
            except ValueError:
                # psd-tools' tokenizer needs whitespace inside an empty dictionary / list, which
                # Photoshop always writes ("<< >>") but other writers may not ("<<>>")
                raw = self._raw.replace(b"<<>>", b"<< >>").replace(b"[]", b"[ ]")
                self._parsed = self._parser.frombytes(raw)
        return self._parsed

    @property
    def is_parsed(self):
        return self._parsed is not None

    def __deepcopy__(self, memo):
        # an untouched copy stays unparsed (copying a page group copies its layers' text data)
        twin = LazyEngineData(self._raw, self._parser)
        if self._parsed is not None:
            twin._parsed = engine_copy(self._parsed)
        return twin

    # dict-like access used by psd-tools' TypeLayer API and our code
    def __getitem__(self, key):
        return self.parsed[key]

    def __setitem__(self, key, value):
        self.parsed[key] = value

    def __contains__(self, key):
        return key in self.parsed

    def __iter__(self):
        return iter(self.parsed)

    def __len__(self):
        return len(self.parsed)

    def get(self, key, default=None):
        return self.parsed.get(key, default)

    def keys(self):
        return self.parsed.keys()

    def items(self):
        return self.parsed.items()

    def __getattr__(self, name):
        if name in LazyEngineData.__slots__:
            raise AttributeError(name)
        return getattr(self.parsed, name)

    def write(self, fp, **kwargs):
        data = self._raw if self._parsed is None else engine_bytes(self._parsed, **kwargs)
        fp.write(data)
        return len(data)


def _simple_kinds():
    """{first byte: token -> its EngineToken or None (then the full ordered test decides)}. Each check
    is the pattern psd-tools would find first for a token starting with that byte: ARRAY_END /
    ARRAY_START / DICT_START are exact, the others the same anchored patterns."""
    from psd_tools.psd.engine_data import EngineToken as E

    def exact(kind, text):
        return lambda t: kind if t == text else None

    def pattern(*kinds):
        def check(t):
            for kind in kinds:
                if kind.value.search(t):
                    return kind
            return None
        return check

    number = pattern(E.NUMBER, E.NUMBER_WITH_DECIMAL)
    kinds = {b"]": exact(E.ARRAY_END, b"]"), b"[": exact(E.ARRAY_START, b"["), b"<": exact(E.DICT_START, b"<<"),
             b">": pattern(E.DICT_END), b"/": pattern(E.PROPERTY), b"(": pattern(E.STRING, E.UNKNOWN_TAG),
             b"t": pattern(E.BOOLEAN), b"f": pattern(E.BOOLEAN), b"-": None, b".": number}
    kinds[b"-"] = lambda t: None if t.startswith(b"--") else number(t)   # "--(.-0" is UNKNOWN_TAG2
    for d in b"0123456789":
        kinds[bytes([d])] = number
    return kinds


_SIMPLE = {}


def _fast_next(self):
    """psd-tools' engine-data Tokenizer.__next__ without copying the rest of the data for every
    token (`self.data[index:]`): the same tokens, but linear — a 2.3 MB document text block (Txt2)
    took ~130 s to parse, now a few seconds."""
    from psd_tools.psd.engine_data import EngineToken, Tokenizer

    data, index, n = self.data, self.index, len(self.data)
    while True:
        if index >= n:
            self.index = index
            raise StopIteration
        if data.startswith(Tokenizer.UTF16_START, index):
            match = Tokenizer.UTF16_END.search(data, index)
            if match is None:
                raise ValueError("Invalid token: %r" % (data[index:]))
            token, index = data[index:match.end()], match.end()
        else:
            match = Tokenizer.DIVIDER.search(data, index)
            if match is None:
                token, index = data[index:], n
            else:
                token, index = data[index:match.start()], match.end()
                if token == b"":
                    continue
        self.index = index
        # the common tokens told apart by their first byte, with the same pattern psd-tools would
        # match first (its patterns are tried in order, up to 12 per token); anything else as it does
        first = token[:1]
        if first in _SIMPLE:
            got = _SIMPLE[first](token)
            if got is not None:
                return token, got
        for token_type in EngineToken:
            if token_type.value.search(token):
                return token, token_type
        raise ValueError("Unknown token: %r" % (token))


def engine_bytes(obj, **kwargs):
    """psd-tools' EngineData / EngineData2 .write() output, built as one join instead of millions of
    small writes through its element classes: byte for byte the same (tested on real PSDs), many
    times faster — Photoshop's 2.3 MB document text block in well under a second."""
    from psd_tools.psd.engine_data import (Bool, Dict, EngineData2, Float, Integer, List, Property, String,
                                           Tag)

    out = []
    put = out.append
    escapes = String._ESCAPED_CHARS

    def scalar(v):
        if isinstance(v, String):
            b = v.value.encode("utf-16-be")
            for c in escapes:
                b = b.replace(c, b"\\" + c)
            put(b"(\xfe\xff" + b + b")")
        elif isinstance(v, Bool):
            put(b"true" if v.value else b"false")
        elif isinstance(v, Integer):
            put(b"%d" % v.value)
        elif isinstance(v, Float):
            b = (b"%.8f" % v.value).rstrip(b"0")
            b = b + b"0" if b.endswith(b".") else b
            if 0.0 < abs(v.value) < 1.0:
                b = b.replace(b"0.", b".")
            put(b)
        elif isinstance(v, Property):
            put(b"/" + v.value.encode("macroman"))
        elif isinstance(v, Tag):
            put(v.value)
        else:
            raise TypeError(f"unknown engine data element {type(v).__name__}")

    def dict_(d, indent, container):
        inner = None if indent is None else indent + 1
        if container:
            if indent == 0:
                put(b"\n")
            if indent is not None:
                put(b"\n")
            put(b" " if indent is None else b"\t" * indent)
            put(b"<<")
            if indent is not None:
                put(b"\n")
        tab = b" " if inner is None else b"\t" * inner
        for key, value in d.items():
            put(tab)
            put(b"/" + key.value.encode("macroman"))
            if isinstance(value, Dict):
                dict_(value, inner, True)
            else:
                put(b" ")
                if isinstance(value, List):
                    list_(value, inner if len(value) > 0 and isinstance(value[0], Dict) else None)
                else:
                    scalar(value)
            if indent is not None:
                put(b"\n")
        if container:
            put(b" " if indent is None else b"\t" * indent)
            put(b">>")

    def list_(items, indent):
        put(b"[")
        if indent is None:
            for item in items:
                if isinstance(item, Dict):
                    dict_(item, None, True)
                else:
                    put(b" ")
                    list_(item, None) if isinstance(item, List) else scalar(item)
            put(b" ")
        else:
            for item in items:
                if isinstance(item, Dict):
                    dict_(item, indent, True)
                elif isinstance(item, List):
                    list_(item, indent)
                else:
                    scalar(item)
            put(b"\n")
            put(b"\t" * indent)
        put(b"]")

    if isinstance(obj, EngineData2):
        dict_(obj, kwargs.get("indent"), kwargs.get("write_container", False))
    else:
        dict_(obj, kwargs.get("indent", 0), kwargs.get("write_container", True))
    return b"".join(out)


def engine_copy(node):
    """A deep copy of parsed engine data, element by element (copy.deepcopy walks the attrs machinery
    of every element and was most of the time a page copy took)."""
    from psd_tools.psd.engine_data import Dict, List, Property

    if isinstance(node, Dict):
        twin = type(node)()
        for key, value in node.items():
            twin[key] = engine_copy(value)
        return twin
    if isinstance(node, List):
        return type(node)([engine_copy(v) for v in node])
    if isinstance(node, Property):                    # frozen
        return node
    return type(node)(node.value)


def _patch_tokenizer():
    from psd_tools.psd.engine_data import Tokenizer

    if not getattr(Tokenizer, "_psh_fast", False):
        _SIMPLE.update(_simple_kinds())
        Tokenizer.__next__ = _fast_next
        Tokenizer._psh_fast = True


def _shim(parser):
    class _Lazy:
        @staticmethod
        def frombytes(raw, **kwargs):
            return LazyEngineData(raw, parser)
    return _Lazy


def open_lazy(path):
    """PSDImage with text-engine data parsed on demand (not cached)."""
    with _PATCH_LOCK:
        eager_layer_parser = _tb.EngineData
        eager_doc_parser = _tb.TYPES.get(Tag.TEXT_ENGINE_DATA)
        _tb.EngineData = _shim(eager_layer_parser)                       # used by TypeToolObjectSetting.read
        if eager_doc_parser is not None:
            _tb.TYPES[Tag.TEXT_ENGINE_DATA] = _shim(eager_doc_parser)  # document 'Txt2'
        try:
            return PSDImage.open(path)
        finally:
            _tb.EngineData = eager_layer_parser
            if eager_doc_parser is not None:
                _tb.TYPES[Tag.TEXT_ENGINE_DATA] = eager_doc_parser


def _file_key(path):
    st = os.stat(path)
    return (os.path.normcase(os.path.abspath(path)), st.st_size, st.st_mtime_ns)


def open_psd(path):
    """Open (lazily) with a one-file in-memory cache; treat the result as read-only."""
    key = _file_key(path)
    if _CACHE["key"] == key and _CACHE["psd"] is not None:
        return _CACHE["psd"]
    psd = open_lazy(path)
    _CACHE["key"], _CACHE["psd"] = key, psd
    return psd


def clear_cache():
    _CACHE["key"], _CACHE["psd"] = None, None


_patch_tokenizer()                                    # every engine-data parse in the app, linear
