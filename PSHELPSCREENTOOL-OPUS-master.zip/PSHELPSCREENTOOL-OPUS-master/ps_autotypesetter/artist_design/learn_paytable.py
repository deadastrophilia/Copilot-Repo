"""Learn a paytable layout from an artist's PSD page group.

Produces a normal mapped-paytable template (canvas + slots + mappings +
icon_mappings) that the existing mapper, slot editor and renderers use, plus
PNG assets for the artist's design art. Nothing here writes to the PSD.

Classification of the group's visible layers:
  * symbol images   -> matched to the sheet's symbol art   -> "<sym>" icon slots
  * number columns  -> attached to the symbol above them   -> "<sym>.pay" / "<sym>.value"
  * prose           -> matched to an Excel text cell       -> "rules.N" (+ "rules.N.icon.M"
                       for icons the artist set beside the sentence)
  * other text      -> literal text slots with the artist's style (title, labels)
  * other images    -> "decor.N" assets drawn at their exact box (card art is
                       tied to its card's symbol so a missing symbol drops it)
"""
import difflib
import os
import re
from collections import Counter

import numpy as np
from PIL import Image

from ..icon_mapping import resolve_icon_path
from . import fx_preview

NUM_RE = re.compile(r"^[\d.,]+$")
TOKEN_RE = re.compile(r"<([^<>]+)>")
EFFECT_TAGS = {"lmfx": "OBJECT_BASED_EFFECTS_LAYER_INFO_V0", "lfx2": "OBJECT_BASED_EFFECTS_LAYER_INFO"}
SYMBOL_MATCH_MAX = 0.04     # mean squared error on 48x48 thumbnails (0 = identical art)


# ── small helpers ───────────────────────────────────────────────────────────
def lines_of(text):
    return [t.strip() for t in str(text).replace("\r", "\n").split("\n") if t.strip()]


def strip_tokens(text):
    return re.sub(r"\s+", " ", TOKEN_RE.sub("", str(text or ""))).strip()


def _thumb(img, size=48):
    img = img.convert("RGBA")
    bb = img.getbbox()
    if bb:
        img = img.crop(bb)
    canvas = Image.new("RGB", img.size, (0, 0, 0))
    canvas.paste(img, mask=img.split()[3])
    return np.asarray(canvas.resize((size, size), Image.LANCZOS), dtype=np.float32) / 255.0


def _box(layer):
    return {"x": int(layer.left), "y": int(layer.top), "w": int(layer.width), "h": int(layer.height)}


def _visible_leaves(group):
    out = []
    for layer in group:
        if not layer.visible:
            continue
        if layer.is_group():
            out.extend(_visible_leaves(layer))
        else:
            out.append(layer)
    return out


def _combined_opacity(layer, root):
    """Layer opacity x every enclosing group's opacity up to (and including) `root`."""
    op = layer.opacity / 255.0
    parent = layer.parent
    while parent is not None and parent is not root.parent:
        if getattr(parent, "is_group", lambda: False)():
            op *= parent.opacity / 255.0
        if parent is root:
            break
        parent = parent.parent
    return op


def _effects_block(layer):
    """The layer's Photoshop effects as {"key", "hex"} (raw tagged-block payload) or None."""
    from psd_tools.constants import Tag
    import io
    blocks = layer._record.tagged_blocks
    for key, tag_name in EFFECT_TAGS.items():
        tag = getattr(Tag, tag_name)
        if blocks is not None and tag in blocks:
            buf = io.BytesIO()
            blocks[tag].data.write(buf)
            return {"key": key, "hex": buf.getvalue().hex()}
    return None


def _hex(rgb):
    return "#%02x%02x%02x" % tuple(int(c) for c in rgb[:3])


def _thumb_uri(layer, size=56):
    """Small PNG data URI of a layer, for the UI's symbol list."""
    import base64
    import io
    try:
        img = layer.topil().convert("RGBA")
        img.thumbnail((size, size))
        buf = io.BytesIO()
        img.save(buf, "PNG")
        return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode("ascii")
    except Exception:
        return ""


def _line_end_words(text):
    """Last word of every artist line that is followed by more text (manual breaks)."""
    lines = [ln.strip() for ln in re.split(r"[\r\n]", str(text or ""))]
    out = []
    for i, ln in enumerate(lines):
        words = re.findall(r"[^\W_]+", ln)
        if words and any(re.search(r"\S", rest) for rest in lines[i + 1:]):
            out.append(words[-1].casefold())
    return out


def _bold_face(ps_name):
    """The installed bold face for Photoshop's faux bold (renderers have no faux bold)."""
    try:
        from ..ui_web.ps_actions import _resolve_font_file
    except Exception:
        return ps_name
    if any(w in ps_name.casefold() for w in ("bold", "black", "heavy")):
        return ps_name                                  # already a heavy face
    base = ps_name.split("-")[0]
    stem = base[:-2] if base.endswith("MT") else base
    for cand in (f"{stem}-BoldMT", f"{stem}-Bold", f"{base}-Bold", f"{stem} Bold"):
        if cand != ps_name and _resolve_font_file(cand):
            return cand
    return ps_name


def text_style(layer):
    """Font, px size, leading, colour, alignment and effects of a type layer."""
    eng = layer.engine_dict
    fonts = layer.resource_dict["FontSet"]
    runs = list(eng["StyleRun"]["RunArray"])
    lens = [int(n) for n in eng["StyleRun"]["RunLengthArray"]]
    text = layer.text
    # dominant style = the run covering most visible characters
    weight, pos = Counter(), 0
    for run, n in zip(runs, lens):
        weight[id(run)] += len(text[pos:pos + n].strip())
        pos += n
    run = max(runs, key=lambda r: weight[id(r)])
    sd = run["StyleSheet"]["StyleSheetData"]
    xx, xy, yx, yy, tx, ty = [float(v) for v in layer.transform]
    size = float(sd.get("FontSize", 12)) * yy
    auto = bool(sd.get("AutoLeading", True))
    leading = float(sd["Leading"]) * yy if (not auto and "Leading" in sd) else size * 1.2
    col = sd.get("FillColor", {}).get("Values")
    rgb = tuple(int(round(float(v) * 255)) for v in col[1:4]) if col else (255, 255, 255)
    just = int(eng["ParagraphRun"]["RunArray"][0]["ParagraphSheet"]["Properties"].get("Justification", 0))
    font_name = str(fonts[int(sd.get("Font", 0))]["Name"]).strip("'")
    if bool(sd.get("FauxBold", False)):
        font_name = _bold_face(font_name)
    return {
        "font_name": font_name,
        "font_size": round(size, 2),
        "leading": round(leading, 2),
        "line_height": round(leading, 2),        # the mapped renderer's manual line pitch
        "color": _hex(rgb),
        "alignment": {1: "right", 2: "center"}.get(just, "left"),
        "font_override": True,
    }


def _text_box(layer, style, n_lines, prose=False):
    """Slot box for a text layer: room for longer values, anchored like the artist's text.

    Prose keeps the artist's width (so it wraps where the artist wrapped);
    numbers and labels get sideways room for longer values.
    """
    b = _box(layer)
    if prose:
        grow = int(max(style["font_size"], b["w"] * 0.1))       # renderer metrics differ slightly
    else:
        grow = max(int(b["w"] * 0.6), int(style["font_size"] * 1.5))
    if style["alignment"] == "left":
        x, w = b["x"], b["w"] + grow
    elif style["alignment"] == "right":
        x, w = b["x"] - grow, b["w"] + grow
    else:
        x, w = b["x"] - grow // 2, b["w"] + grow
    h = max(b["h"], int(style["leading"] * max(1, n_lines))) + max(10, int(style["leading"] * 0.4))  # renderer insets
    return {"x": x, "y": b["y"] - 3, "w": w, "h": h}


def _sheet_text_cells(ws):
    cells = {}
    for row in ws.iter_rows():
        for c in row:
            if isinstance(c.value, str) and len(c.value.strip()) > 8:
                cells[c.coordinate] = c.value.strip()
    return cells


def _sheet_values(ws, refs):
    return [str(ws[r.strip()].value).strip() for r in str(refs).split(",") if ws[r.strip()].value not in (None, "")]


# ── learn ───────────────────────────────────────────────────────────────────
def learn_paytable(psd, group_name, ws, symbols_dir, assets_dir, icon_mappings=None, progress=None,
                   symbol_overrides=None):
    """Return {"template": dict, "report": dict}; writes design art PNGs to assets_dir.

    `symbol_overrides` = {layer_id: symbol key, or "" for "not a symbol"} from the
    user's corrections in the UI; every other image is matched automatically.
    """
    overrides = {int(k): str(v or "").strip().casefold() for k, v in (symbol_overrides or {}).items()}
    from ..ui_web.engine_api import automap_paytable_slots_ws

    def step(msg):
        if callable(progress):
            progress(msg)

    group = next((l for l in psd if l.name == group_name), None)
    if group is None:
        raise ValueError(f"Group '{group_name}' not found in the PSD.")
    os.makedirs(assets_dir, exist_ok=True)
    W, H = psd.size
    blocks = automap_paytable_slots_ws(ws, {"slots": {}, "slot_prefix": "@slot"}).get("blocks") or []
    cells = _sheet_text_cells(ws)
    card_keys = [b["key"] for b in blocks]
    leaves = _visible_leaves(group)
    images = [l for l in leaves if l.kind in ("pixel", "smartobject", "shape") and l.width * l.height > 0]
    texts = [l for l in leaves if l.kind == "type" and l.text.strip()]
    report = {"group": group_name, "symbols": [], "data": [], "literal_text": [], "decor": 0,
              "inline_icons": 0, "warnings": []}

    # 1. symbol art candidates: card symbols + every token used in the sheet's text
    step("Identifying symbols")
    tokens = set(card_keys)
    for txt in cells.values():
        tokens.update(t.strip().casefold() for t in TOKEN_RE.findall(txt))
    candidates = {}
    for tok in tokens:
        path = resolve_icon_path(f"<{tok}>", symbols_dir, icon_mappings or {})
        if path and os.path.isfile(path):
            try:
                candidates[tok] = _thumb(Image.open(path))
            except Exception:
                pass
    scored = []
    symbol_of, used_cards = {}, set()
    for layer in images:
        if layer.layer_id in overrides:                  # the user's pick wins
            tok = overrides[layer.layer_id]
            if tok:
                symbol_of[id(layer)] = (tok, layer, 0.0)
                if tok in card_keys:
                    used_cards.add(tok)
            continue
        if layer.width < 40 or layer.height < 40:
            continue
        t = _thumb(layer.topil())
        for tok, c in candidates.items():
            scored.append((float(np.mean((t - c) ** 2)), layer, tok))
    scored.sort(key=lambda s: s[0])
    for err, layer, tok in scored:                       # cards: one-to-one; legend icons may repeat
        if id(layer) in symbol_of or err > SYMBOL_MATCH_MAX:
            continue
        if tok in card_keys:
            if tok in used_cards:
                continue
            used_cards.add(tok)
        symbol_of[id(layer)] = (tok, layer, err)
    card_symbols = {tok: layer for tok, layer, _ in symbol_of.values() if tok in card_keys}
    for tok, layer, err in symbol_of.values():
        report["symbols"].append({"layer": layer.name, "layer_id": layer.layer_id, "box": _box(layer),
                                  "symbol": tok, "error": round(err, 4), "card": tok in card_keys,
                                  "thumb": _thumb_uri(layer)})
    report["symbol_choices"] = sorted(tokens)
    report["other_images"] = [
        {"layer": l.name, "layer_id": l.layer_id, "box": _box(l), "thumb": _thumb_uri(l)}
        for l in images if id(l) not in symbol_of and l.width >= 40 and l.height >= 40
        and not (l.width > W * 0.5 and l.height > H * 0.5)][:40]
    missing = [k for k in card_keys if k not in card_symbols]
    if missing:
        report["warnings"].append(f"No card found in the design for: {', '.join(missing)} (will be cloned).")

    slots, mappings = {}, {}
    consumed = set()

    # 2. card symbols
    for tok, layer in card_symbols.items():
        slots[tok] = _box(layer)
        mappings[tok] = {"slot": tok, "mode": "icon", "token": f"<{tok}>", "symbol": tok,
                         "icon_height": int(layer.height), "alignment": "center", "vertical_align": "center",
                         "padding": [0, 0, 0, 0]}
        fx = _effects_block(layer)
        if fx:
            mappings[tok]["effects_block"] = fx
        consumed.add(id(layer))

    # 3. text layers
    step("Linking text to Excel")
    rules_n = 0
    design_text = []                                  # squeezed literal text -> kept as art
    for layer in texts:
        txt = lines_of(layer.text)
        if layer.width < 8 and layer.height < 8:
            continue                                          # stray dots/spaces
        style = text_style(layer)
        if txt and all(NUM_RE.match(t) for t in txt):
            cx = (layer.left + layer.right) / 2
            best = None
            for tok, sl in card_symbols.items():
                if sl.bottom <= layer.top + 5 and sl.left - 80 <= cx <= sl.right + 80:
                    d = (layer.top - sl.bottom) + abs(cx - (sl.left + sl.right) / 2) * 0.5
                    if best is None or d < best[0]:
                        best = (d, tok)
            if best is None:
                report["warnings"].append(f"Number column '{' / '.join(txt)}' has no symbol above it; kept as text.")
            else:
                block = next(b for b in blocks if b["key"] == best[1])
                pays, values = _sheet_values(ws, block["pay_ref"]), _sheet_values(ws, block["value_ref"])
                if txt == pays and txt != values:
                    role = "pay"
                elif txt == values and txt != pays:
                    role = "value"
                else:
                    sib = [o for o in texts if o is not layer and abs(o.top - layer.top) < 15 and abs(o.left - layer.left) < 120
                           and all(NUM_RE.match(t) for t in lines_of(o.text))]
                    role = "pay" if all(layer.left < s.left for s in sib) else "value"
                name = f"{best[1]}.{role}"
                lines_n = len(_sheet_values(ws, block["pay_ref" if role == "pay" else "value_ref"])) or len(txt)
                slots[name] = _text_box(layer, style, max(lines_n, len(txt)))
                mappings[name] = dict(style, slot=name, mode="excel", role=role, symbol=best[1],
                                      source=block["pay_ref" if role == "pay" else "value_ref"],
                                      vertical_align="top", padding=[0, 0, 0, 0])
                fx = _effects_block(layer)
                if fx:
                    mappings[name]["effects_block"] = fx
                report["data"].append({"layer": layer.name, "slot": name, "source": mappings[name]["source"]})
                consumed.add(id(layer))
                continue

        artist = strip_tokens(" ".join(txt)).casefold()
        best = max(((difflib.SequenceMatcher(None, strip_tokens(v).casefold(), artist).ratio(), ref)
                    for ref, v in cells.items()), default=(0.0, None))
        fx = _effects_block(layer)
        if best[0] >= 0.6:
            rules_n += 1
            name = f"rules.{rules_n}"
            cell = cells[best[1]]
            beside, inline_h, inline_imgs = [], 0, []
            # icons the artist placed OUTSIDE the sentence (e.g. a big WILD above it) stay where they are
            for tok in (t.strip().casefold() for t in TOKEN_RE.findall(cell)):
                for lid, (stok, img, _) in symbol_of.items():
                    if stok != tok or lid in consumed:
                        continue
                    # in the sentence's line band (icons in text gaps poke past the ink box sideways)
                    overlap = min(img.bottom, layer.bottom) - max(img.top, layer.top)
                    inside = (overlap >= 0.4 * img.height
                              and img.left < layer.right + img.width and img.right > layer.left - img.width)
                    near = abs((img.top + img.bottom) / 2 - (layer.top + layer.bottom) / 2) < max(layer.height, img.height) * 2
                    if inside:
                        consumed.add(lid)                       # drawn inline from the Excel token
                        report["inline_icons"] += 1
                        inline_h = max(inline_h, int(img.height))
                        inline_imgs.append(img)
                    elif near and abs((img.left + img.right) / 2 - (layer.left + layer.right) / 2) < layer.width:
                        beside.append((tok, img))
                        consumed.add(lid)
            # tokens the artist set beside the sentence are dropped from it at render
            # time (fit_cards.prepare); the rest render inline from Excel
            beside_tokens = sorted({t for t, _ in beside})
            slots[name] = _text_box(layer, style, len(txt), prose=True)
            mappings[name] = dict(style, slot=name, mode="excel", source=best[1], role="text",
                                  drop_tokens=beside_tokens, shrink_to_fit=True,
                                  break_after=_line_end_words(layer.text),
                                  vertical_align="top", padding=[0, 0, 0, 0])
            if inline_h:
                mappings[name]["icon_height"] = inline_h             # the artist's inline icon size
                box = slots[name]                                    # room for the icons' rows too
                x2 = max([box["x"] + box["w"]] + [i.right for i in inline_imgs])
                y2 = max([box["y"] + box["h"]] + [i.bottom for i in inline_imgs])
                box["x"] = min([box["x"]] + [i.left for i in inline_imgs])
                box["y"] = min([box["y"]] + [i.top for i in inline_imgs])
                box["w"], box["h"] = x2 - box["x"], y2 - box["y"]
            if fx:
                mappings[name]["effects_block"] = fx
            for m, (tok, img) in enumerate(beside, start=1):
                iname = f"{name}.icon.{m}"
                slots[iname] = _box(img)
                mappings[iname] = {"slot": iname, "mode": "icon", "token": f"<{tok}>", "icon_height": int(img.height),
                                   "alignment": "center", "vertical_align": "center", "padding": [0, 0, 0, 0]}
            report["data"].append({"layer": layer.name, "slot": name, "source": best[1], "match": round(best[0], 2),
                                   "icons_beside": [t for t, _ in beside]})
        else:
            xx, _, _, yy = [float(v) for v in layer.transform[:4]]
            if yy and abs(xx / yy - 1.0) > 0.03:
                # squeezed/stretched title art: keep the artist's pixels + live effects
                design_text.append(layer)
                report["literal_text"].append({"layer": layer.name, "slot": "(art)", "text": " ".join(txt)[:60]})
                continue
            # title / labels: the artist's literal text, editable, with its style and effects
            literal = "\n".join(lines_of(layer.text))
            is_title = layer.top < H * 0.25 and style["font_size"] >= max(
                (text_style(t)["font_size"] for t in texts if t.top < H * 0.25), default=0) - 0.5
            name = "title" if is_title and "title" not in slots else f"label.{len(report['literal_text']) + 1}"
            slots[name] = _text_box(layer, style, len(txt))
            mappings[name] = dict(style, slot=name, mode="text", text=literal, source=literal,
                                  vertical_align="top", padding=[0, 0, 0, 0])
            if fx:
                mappings[name]["effects_block"] = fx
            report["literal_text"].append({"layer": layer.name, "slot": name, "text": literal[:60]})
        consumed.add(id(layer))

    # 4. design art -> exact-box image slots, tied to a card when they sit behind one
    step("Exporting design art")
    template_icons = {}
    decor_n = 0
    title_art = []                                    # the artist's title is art: no Excel heading
    for layer in images + design_text:
        if id(layer) in consumed:
            continue
        img = layer.topil()
        if img is None or not img.getbbox():
            continue
        decor_n += 1
        name = f"decor.{decor_n}"
        path = os.path.join(assets_dir, f"decor_{decor_n}.png")
        img.convert("RGBA").save(path)
        token = f"<decor_{decor_n}>"
        template_icons[token] = os.path.abspath(path)
        slots[name] = _box(layer)
        if layer in design_text and layer.top < H * 0.25:
            title_art.append(name)
        spec = {"slot": name, "mode": "icon", "token": token, "fit": "exact", "icon_height": int(layer.height),
                "asset_path": os.path.abspath(path),         # survives mapper re-saves (icon_mappings do not)
                "alignment": "left", "vertical_align": "top", "padding": [0, 0, 0, 0],
                "layer_opacity": round(_combined_opacity(layer, group), 3)}
        fx = _effects_block(layer)
        if fx:
            spec["effects_block"] = fx
            # PNG output has no effects engine: bake an approximate preview
            try:
                baked, pad = fx_preview.render(layer, img)
            except Exception:
                baked, pad = None, 0
            if baked is not None:
                ppath = os.path.join(assets_dir, f"decor_{decor_n}.preview.png")
                baked.save(ppath)
                spec["preview_image"] = os.path.abspath(ppath)
                spec["preview_pad"] = pad
        # card art: behind exactly one card symbol -> belongs to that card
        owners = [tok for tok, sl in card_symbols.items()
                  if layer.left <= (sl.left + sl.right) / 2 <= layer.right and layer.top <= (sl.top + sl.bottom) / 2 <= layer.bottom]
        if len(owners) == 1:
            spec["symbol"] = owners[0]
        mappings[name] = spec
    report["decor"] = decor_n

    # 5. card clusters + grid pitch (for cloning extra symbols)
    cards = []
    for tok, sl in card_symbols.items():
        members = [n for n, m in mappings.items() if m.get("symbol") == tok]
        xs = [slots[n]["x"] for n in members]
        ys = [slots[n]["y"] for n in members]
        x2 = [slots[n]["x"] + slots[n]["w"] for n in members]
        y2 = [slots[n]["y"] + slots[n]["h"] for n in members]
        cards.append({"symbol": tok, "slots": members,
                      "box": {"x": min(xs), "y": min(ys), "w": max(x2) - min(xs), "h": max(y2) - min(ys)}})
    cards.sort(key=lambda c: (round(c["box"]["y"] / 50), c["box"]["x"]))

    # design art first: renderers draw slots in order, so art never covers symbols/text
    order = sorted(slots, key=lambda n: 0 if n.startswith("decor.") else 1)
    slots = {n: slots[n] for n in order}

    template = {
        "template_id": f"Artist_{group_name}",
        "source_psd": "",
        "page_type": "paytable",
        "canvas": {"width": W, "height": H},
        "slot_prefix": "@slot",
        "slots": slots,
        "mappings": mappings,
        "icon_mappings": template_icons,
        "mapper_meta": {"generated_by": "artist_design", "artist_design": {
            "group": group_name, "cards": cards, "pitch": _grid_pitch(cards), "title_art": title_art,
            "content_bottom": max((s["y"] + s["h"] for s in slots.values()), default=H)}},
    }
    return {"template": template, "report": report}


def _grid_pitch(cards):
    """Typical x spacing within a row and y spacing between rows of cards."""
    if not cards:
        return {"x": 0, "y": 0}
    rows = {}
    for c in cards:
        rows.setdefault(round(c["box"]["y"] / 50), []).append(c["box"])
    xs = []
    for boxes in rows.values():
        boxes = sorted(boxes, key=lambda b: b["x"])
        xs += [b2["x"] - b1["x"] for b1, b2 in zip(boxes, boxes[1:])]
    row_tops = sorted(min(b["y"] for b in boxes) for boxes in rows.values())
    ys = [b - a for a, b in zip(row_tops, row_tops[1:])]
    med = lambda v: sorted(v)[len(v) // 2] if v else 0
    return {"x": med(xs), "y": med(ys), "row_sizes": [len(rows[k]) for k in sorted(rows)]}
