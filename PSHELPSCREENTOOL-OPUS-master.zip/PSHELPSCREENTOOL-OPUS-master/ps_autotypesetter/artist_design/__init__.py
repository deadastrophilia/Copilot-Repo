"""Use an artist's PSD as a design reference.

The artist's file is read (never modified) to learn a paytable layout and the
page style; the tool's own builder then renders every Excel page with it.
"""
