"""Bake an artist layer's effects into a PNG preview image.

The PSD output carries the artist's effects block untouched and Photoshop
draws it live; PNG output has no Photoshop, so learned design art with effects
(e.g. squeezed title text: plain green glyphs + gradient, strokes, shadows and
a bevel) gets a baked preview image here. When the layer carries its effects
descriptor (lfx2 / lmfx), every effect is rendered by the shared
Photoshop-free engine (ps_fx_png, decoded by fx_descriptor); the older
approximation below remains for layers whose effects cannot be decoded.
"""
import math

import numpy as np
from PIL import Image, ImageChops, ImageFilter


def _rgb(desc):
    try:
        get = lambda *keys: next(float(desc[k]) for k in keys if k in desc)
        return (int(round(get(b"Rd  "))), int(round(get(b"Grn "))), int(round(get(b"Bl  "))))
    except Exception:
        return (255, 255, 255)


def _dilate(mask, n):
    for _ in range(max(0, int(round(n)))):
        mask = mask.filter(ImageFilter.MaxFilter(3))
    return mask


def _erode(mask, n):
    for _ in range(max(0, int(round(n)))):
        mask = mask.filter(ImageFilter.MinFilter(3))
    return mask


def _gradient(desc, angle, size, reverse=False):
    """RGB image of a linear gradient descriptor (colour stops only)."""
    w, h = size
    stops = []
    for stop in (desc or {}).get(b"Clrs", []) or []:
        try:
            stops.append((float(stop.get(b"Lctn", 0)) / 4096.0, _rgb(stop.get(b"Clr ", {}))))
        except Exception:
            continue
    if not stops:
        return None
    stops.sort()
    if reverse:
        stops = [(1.0 - p, c) for p, c in reversed(stops)]
    a = math.radians(float(angle or 90.0))
    dx, dy = math.cos(a), -math.sin(a)                   # Photoshop: 90 deg = bottom -> top
    xs = np.arange(w, dtype=np.float32)[None, :] - (w - 1) / 2.0
    ys = np.arange(h, dtype=np.float32)[:, None] - (h - 1) / 2.0
    proj = xs * dx + ys * dy
    half = (abs(dx) * w + abs(dy) * h) / 2.0 or 1.0
    t = np.clip((proj + half) / (2.0 * half), 0.0, 1.0)  # 0 at the start, 1 along (dx, dy)
    pos = [p for p, _ in stops]
    out = np.stack([np.interp(t, pos, [c[k] for _, c in stops]) for k in range(3)], axis=-1)
    return Image.fromarray(out.astype(np.uint8), "RGB")


def _fill(effect, size):
    grad = getattr(effect, "gradient", None)
    if grad is None:
        try:
            grad = effect.value.get(b"Grad")
        except Exception:
            grad = None
    fill_type = str(getattr(effect, "fill_type", b"") or b"")
    if grad is not None and ("GrFl" in fill_type or effect.__class__.__name__ == "GradientOverlay"):
        img = _gradient(grad, getattr(effect, "angle", 90), size, bool(getattr(effect, "reversed", False)))
        if img is not None:
            return img
    return Image.new("RGB", size, _rgb(getattr(effect, "color", {}) or {}))


def _put(canvas, fill_rgb, mask, opacity):
    if opacity < 1.0:
        mask = mask.point(lambda v: int(v * opacity))
    layer = fill_rgb.convert("RGBA")
    layer.putalpha(mask)
    canvas.alpha_composite(layer)


def _effects_style(layer):
    """{"effects_block": {...}, "captured_params": {fill opacity}} or None."""
    import io

    try:
        from psd_tools.constants import Tag

        blocks = layer._record.tagged_blocks
    except Exception:
        return None
    if blocks is None:
        return None
    for key, tag in (("lmfx", "OBJECT_BASED_EFFECTS_LAYER_INFO_V0"), ("lfx2", "OBJECT_BASED_EFFECTS_LAYER_INFO")):
        tag = getattr(Tag, tag)
        if tag in blocks:
            buf = io.BytesIO()
            blocks[tag].data.write(buf)
            fill = float(getattr(layer, "fill_opacity", 255) or 0) / 255.0 * 100.0
            return {"effects_block": {"key": key, "hex": buf.getvalue().hex()},
                    "captured_params": {"fill_opacity": fill}}
    return None


def render(layer, image=None):
    """(RGBA preview, pad) for a psd-tools layer; pad = pixels added on each side.

    Returns (None, 0) when the layer has no enabled effects we can draw.
    """
    style = _effects_style(layer)
    if style is not None:
        from .. import ps_fx_png

        try:
            src = image if image is not None else layer.topil()
            if src is not None:
                baked, pad = ps_fx_png.render_layer_image(src, style)
                if baked is not None:
                    return baked, pad
        except Exception as exc:  # fall back to the approximation below
            print(f"[fx_preview] effects engine failed on '{getattr(layer, 'name', '')}': {exc}")
    effects = [e for e in getattr(layer, "effects", []) or [] if getattr(e, "enabled", False)]
    kinds = {e.__class__.__name__ for e in effects}
    if not kinds & {"DropShadow", "Stroke", "GradientOverlay", "ColorOverlay"}:
        return None, 0
    src = (image if image is not None else layer.topil())
    if src is None:
        return None, 0
    src = src.convert("RGBA")
    reach = 0.0
    for e in effects:
        reach = max(reach, float(getattr(e, "size", 0) or 0) + float(getattr(e, "distance", 0) or 0))
    pad = int(math.ceil(reach)) + 4
    W, H = src.width + 2 * pad, src.height + 2 * pad
    glyph = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    glyph.paste(src, (pad, pad))
    alpha = glyph.getchannel("A")
    canvas = Image.new("RGBA", (W, H), (0, 0, 0, 0))

    # psd-tools lists effects top-most first within each kind: paint bottom-up.
    for e in reversed([e for e in effects if e.__class__.__name__ == "DropShadow"]):
        size = float(getattr(e, "size", 0) or 0)
        choke = float(getattr(e, "choke", 0) or 0) / 100.0
        mask = _dilate(alpha, size * choke)
        blur = size * (1.0 - choke)
        if blur > 0.5:
            mask = mask.filter(ImageFilter.GaussianBlur(blur / 2.0))
        a = math.radians(float(getattr(e, "angle", 90) or 90))
        d = float(getattr(e, "distance", 0) or 0)
        mask = ImageChops.offset(mask, int(round(-math.cos(a) * d)), int(round(math.sin(a) * d)))
        _put(canvas, _fill(e, (W, H)), mask, float(getattr(e, "opacity", 100) or 100) / 100.0)

    strokes = [e for e in effects if e.__class__.__name__ == "Stroke"]
    for e in reversed([s for s in strokes if "InsF" not in str(getattr(s, "position", ""))]):
        size = float(getattr(e, "size", 0) or 0)
        mask = _dilate(alpha, size if "OutF" in str(getattr(e, "position", "")) else size / 2.0)
        _put(canvas, _fill(e, (W, H)), mask, float(getattr(e, "opacity", 100) or 100) / 100.0)

    overlay = next((e for e in effects if e.__class__.__name__ in ("GradientOverlay", "ColorOverlay")), None)
    if overlay is not None:
        _put(canvas, _fill(overlay, (W, H)), alpha, float(getattr(overlay, "opacity", 100) or 100) / 100.0)
    else:
        canvas.alpha_composite(glyph)

    for e in reversed([s for s in strokes if "InsF" in str(getattr(s, "position", ""))]):
        ring = ImageChops.subtract(alpha, _erode(alpha, float(getattr(e, "size", 0) or 0)))
        _put(canvas, _fill(e, (W, H)), ring, float(getattr(e, "opacity", 100) or 100) / 100.0)
    return canvas, pad
