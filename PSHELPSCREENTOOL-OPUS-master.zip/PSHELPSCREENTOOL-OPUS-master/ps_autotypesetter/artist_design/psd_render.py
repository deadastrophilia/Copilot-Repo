"""Pictures of a PSD's pages without Photoshop (psd-tools compositing).

An artist's help-screen PSD keeps every page as a top-level group, all hidden
but one, over shared background layers. A page's picture is the visible
background layers with that page's group drawn on top, as if it were the one
switched on — what Photoshop shows when the artist clicks its eye.

psd-tools needs scipy only to interpolate gradient colours; when scipy is not
installed (the EXE does not ship it) the same interpolation is done with numpy,
so gradient fills and gradient overlays still draw.
"""
import logging

import numpy as np
from PIL import Image

logging.getLogger("psd_tools").setLevel(logging.ERROR)
_READY = {"done": False}


def _gradients_without_scipy():
    """psd-tools' gradient fill with numpy.interp standing in for scipy's interp1d."""
    if _READY["done"]:
        return
    _READY["done"] = True
    try:
        import scipy  # noqa: F401  (installed: psd-tools uses it as it is)
        return
    except ImportError:
        pass
    try:
        from psd_tools.composite import paint
        from psd_tools.terminology import Key
    except Exception:
        return

    def interp(xs, ys):
        xs = np.asarray(xs, dtype=np.float32)
        ys = np.asarray(ys, dtype=np.float32)

        def f(z):
            z = np.asarray(z, dtype=np.float32)
            if ys.ndim == 1:
                return np.interp(z, xs, ys).astype(np.float32)
            return np.stack([np.interp(z, xs, ys[:, c]) for c in range(ys.shape[1])], axis=-1).astype(np.float32)
        return f

    def linear_gradient_color(color_mode, grad):
        xc, yc = paint._collect_stops(grad.get(Key.Colors, []),
                                      lambda stop: np.array(paint._get_color(color_mode, stop), dtype=np.float32))
        g = interp(xc, yc)
        if Key.Transparency not in grad:
            return g, None
        xt, yt = paint._collect_stops(grad.get(Key.Transparency), lambda stop: float(stop.get(Key.Opacity)) / 100.0)
        return g, interp(xt, yt)

    paint._make_linear_gradient_color = linear_gradient_color
    raw = getattr(paint.draw_gradient_fill, "__wrapped__", None)
    if raw is not None:                               # without the "requires scipy" check
        paint.draw_gradient_fill = raw


def _effects_without_skimage():
    """psd-tools draws stroke effects (the outline on most help-screen text) with scikit-image;
    without it, the stroke is made with PIL's max/min filters — outside, centred or inside,
    as Photoshop's Position says — on just the layer's own pixels. Pattern fills (also
    scikit-image) are left out instead of stopping the whole page."""
    if _READY.get("fx"):
        return
    _READY["fx"] = True
    try:
        import skimage  # noqa: F401
        return
    except ImportError:
        pass
    try:
        import sys

        import psd_tools.composite.composite  # noqa: F401  (the module: the package also has a function of that name)
        from psd_tools.composite import effects, paint
        from psd_tools.terminology import Enum, Key

        composite = sys.modules["psd_tools.composite.composite"]
    except Exception:
        return
    from PIL import ImageFilter

    def stroke(viewport, shape, desc, psd):
        height, width = viewport[3] - viewport[1], viewport[2] - viewport[0]
        if not isinstance(shape, np.ndarray):
            shape = np.full((height, width, 1), shape, dtype=np.float32)
        color = None
        kind = desc.get(Key.PaintType).enum
        try:
            if kind == Enum.SolidColor:
                color, _ = paint.draw_solid_color_fill(viewport, psd.color_mode, desc)
            elif kind == Enum.GradientFill:
                color, _ = paint.draw_gradient_fill(viewport, psd.color_mode, desc)
        except Exception:
            color = None
        if color is None:
            color = np.ones((height, width, 1), dtype=np.float32)
        size = float(desc.get(Key.SizeKey, 1.0))
        style = desc.get(Key.Style).enum
        alpha = shape[:, :, 0]
        mask = np.zeros((height, width), dtype=np.float32)
        ys, xs = np.nonzero(alpha > 0.004)
        if len(xs):
            pad = int(size) + 3
            y0, y1 = max(0, ys.min() - pad), min(height, ys.max() + pad + 1)
            x0, x1 = max(0, xs.min() - pad), min(width, xs.max() + pad + 1)
            sub = Image.fromarray((np.clip(alpha[y0:y1, x0:x1], 0, 1) * 255).astype(np.uint8))

            def grow(img, r):
                r = int(round(r))
                return img.filter(ImageFilter.MaxFilter(2 * r + 1)) if r > 0 else img

            def shrink(img, r):
                r = int(round(r))
                return img.filter(ImageFilter.MinFilter(2 * r + 1)) if r > 0 else img

            a = np.asarray(sub, dtype=np.float32) / 255.0
            if style == Enum.InsetFrame:
                ring = a - np.asarray(shrink(sub, size), dtype=np.float32) / 255.0
            elif style == Enum.CenteredFrame:
                ring = (np.asarray(grow(sub, size / 2.0), dtype=np.float32)
                        - np.asarray(shrink(sub, size / 2.0), dtype=np.float32)) / 255.0
            else:                                     # outside (Photoshop's default)
                ring = np.asarray(grow(sub, size), dtype=np.float32) / 255.0 - a
            mask[y0:y1, x0:x1] = np.clip(ring, 0, 1)
        return color, np.expand_dims(mask, 2)

    effects.draw_stroke_effect = stroke
    composite.draw_stroke_effect = stroke             # imported there by name

    raw_pattern = paint.draw_pattern_fill

    def pattern(*args, **kwargs):
        try:
            return raw_pattern(*args, **kwargs)
        except ImportError:
            return None, None
    paint.draw_pattern_fill = pattern


def _paste(base, img):
    if img is not None:
        base.alpha_composite(img.convert("RGBA"))


def _draw(base, psd, group, as_shown, viewport=None):
    """Draw a group (as if switched on when `as_shown`) into `base`, which covers `viewport`
    (default: the whole document); layer by layer if the group as a whole can't be drawn."""
    viewport = tuple(viewport or psd.viewbox)
    keep = (lambda l: l is group or l.visible) if as_shown else (lambda l: l.visible)
    try:
        _paste(base, group.composite(viewport=viewport, layer_filter=keep, force=True))
        return
    except Exception:
        pass
    for layer in group.descendants():
        if layer.is_group() or not layer.visible:
            continue
        try:
            _paste(base, layer.composite(viewport=viewport, force=True))
        except Exception:
            px = layer.topil()                        # its stored pixels, at least
            if px is not None:
                canvas = Image.new("RGBA", base.size)
                canvas.paste(px.convert("RGBA"), (layer.left - viewport[0], layer.top - viewport[1]))
                _paste(base, canvas)


def is_page(layer):
    """A top-level group holding text: a help-screen page (backgrounds hold none)."""
    return layer.is_group() and any(l.kind == "type" for l in layer.descendants())


def stacked_pages(group):
    """The pages a group holds — its groups whose text sits in the same place, one over the other, not
    both shown: a game's pages in a multi-game PSD (Midnight Express's K2 …), every page in the
    artist's "Group 1" (Hunt for Neptune) — in stack order; [] for a page (its own parts, a heading and
    its paragraphs, sit apart or are shown together)."""
    kids = []
    for g in group:
        if not g.is_group():
            continue
        texts = [l for l in g.descendants() if l.kind == "type" and l.width * l.height > 0]
        if texts:
            kids.append((g, (min(l.left for l in texts), min(l.top for l in texts),
                             max(l.right for l in texts), max(l.bottom for l in texts))))
    stacked = set()
    for n, (g, a) in enumerate(kids):
        for h, b in kids[n + 1:]:
            w, ht = min(a[2], b[2]) - max(a[0], b[0]), min(a[3], b[3]) - max(a[1], b[1])
            small = min((a[2] - a[0]) * (a[3] - a[1]), (b[2] - b[0]) * (b[3] - b[1]))
            if w > 0 and ht > 0 and small > 0 and w * ht >= 0.5 * small and not (g.visible and h.visible):
                stacked.update((id(g), id(h)))
    return [g for g, _b in kids if id(g) in stacked]


_PAGE_TOPS = {}
NOT_PAGES = ("[Deleted From Excel]",)                # market_clone.GONE_GROUP


def page_tops(psd):
    """The PSD's top-level layers in stack order, each group that holds pages (stacked_pages) replaced
    by its pages: what the tool's page keys number. The same as list(psd) for a PSD whose pages are its
    top-level groups."""
    try:
        key = (id(psd), id(psd._record), len(psd._record.layer_and_mask_information.layer_info.layer_records))
    except AttributeError:                            # (not a whole PSD: worked out each time)
        key = None
    got = _PAGE_TOPS.get(key) if key else None
    if got is not None and got[0] is psd:
        return list(got[1])
    out = []
    for t in psd:
        # (the tool's "[Deleted From Excel]" group holds pages too: it stays one group, not pages)
        inner = stacked_pages(t) if getattr(t, "is_group", lambda: False)() and not str(t.name).startswith(NOT_PAGES) else []
        out += inner if inner else [t]
    if key:
        if len(_PAGE_TOPS) > 64:
            _PAGE_TOPS.clear()
        _PAGE_TOPS[key] = (psd, out)
    return list(out)


def holder_of(psd, page):
    """The top-level group a page inside a group of pages sits in (None for a top-level page)."""
    parent = getattr(page, "parent", None)
    return parent if parent is not None and parent is not psd and getattr(parent, "is_group", lambda: False)() else None


def render_page(psd, page, viewport=None):
    """RGBA picture of `page` (a page group: top-level, or one of the pages a group holds) over the
    PSD's visible background layers — and, for a page in a group of pages, that group's own shown
    layers (its backdrop, logo); only the box `viewport` (left, top, right, bottom) of it when given —
    much faster."""
    _gradients_without_scipy()
    _effects_without_skimage()
    viewport = tuple(int(v) for v in (viewport or psd.viewbox))
    base = Image.new("RGBA", (viewport[2] - viewport[0], viewport[3] - viewport[1]), (0, 0, 0, 255))
    holder = holder_of(psd, page)
    for top in psd:
        if top is page:
            _draw(base, psd, top, True, viewport)
        elif holder is not None and top is holder:
            siblings = {id(g) for g in stacked_pages(holder)}
            for c in holder:                          # its backdrop and logo, then the page itself
                if c is page:
                    _draw(base, psd, c, True, viewport)
                elif c.visible and id(c) not in siblings:
                    if c.is_group():
                        _draw(base, psd, c, False, viewport)
                    else:
                        try:
                            _paste(base, c.composite(viewport=viewport, force=True))
                        except Exception:
                            pass
        elif top.visible and not is_page(top):
            if top.is_group():
                _draw(base, psd, top, False, viewport)
            else:
                try:
                    _paste(base, top.composite(viewport=viewport, force=True))
                except Exception:
                    pass
    return base
