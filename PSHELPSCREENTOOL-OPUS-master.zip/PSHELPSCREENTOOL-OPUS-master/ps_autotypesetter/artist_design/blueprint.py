"""A paytable blueprint PSD -> an editable card template.

A blueprint is a page of plain named shapes, no text or symbols: the artist draws where things go and
the tool fills them from each sheet's Excel. What the names mean (any case, any group):

  "<card> pays and values"  the counts / pays of a card (its place inside the card it sits on) — every
                            card of that row gets the same
  "... scatter ..."         a SCATTER box (only drawn when the sheet has a scatter): its biggest shape
  "... wild ..."            is the box, "heading" / "title" its heading, "text" / "caption" the line
                            under the symbol, "symbol" the symbol, any other shape a panel inside it
  "text box" / "rules"      a text area: one wide box above every card is the page title, the others
                            hold the rules text
  any other shape           a card (a group of cards, or a row of them, is one row of the paytable:
                            the topmost row holds the top symbols, the next the royals)

A blueprint is a rough draft of WHERE things go: only places and sizes are read, never its shapes'
colours (the template starts with its own looks). The SCATTER is always a card of its own, in no row.
Everything read becomes ordinary template settings (bands with their place and card size, card
parts, the scatter section, text boxes), so the Canvas edits all of it and nothing is fixed in code."""
import json
import os
import statistics

from ..dynamic_pages.paytable.card_templates import design_frame


# the looks a blueprint's template starts with (the artist restyles them on the Canvas)
LOOKS = {
    "card": {"radius": 12, "fill_enabled": True, "fill": "#140A26", "fill_opacity": 85,
             "stroke": {"enabled": True, "width": 3, "color": "#C9A227", "align": "inside"}, "fx": ""},
    # the SCATTER card: a rounded gold frame, the heading above it (as artists draw it)
    "scatter": {"radius": 20, "fill_enabled": False, "fill": "#000000", "fill_opacity": 0,
                "stroke": {"enabled": True, "width": 4, "color": "#FFC23A", "align": "inside"}, "fx": ""},
}


def _bbox(layer):
    b = layer.bbox
    return (float(b[0]), float(b[1]), float(b[2]), float(b[3]))


def _leaves(node, groups=()):
    for ch in node:
        if not ch.visible:
            continue
        if ch.is_group():
            yield from _leaves(ch, groups + (ch.name,))
        else:
            yield ch, groups


def _key(s):
    return " ".join(str(s or "").lower().replace("_", " ").split())


def _inside(a, b, pad=4.0):
    return a[0] >= b[0] - pad and a[1] >= b[1] - pad and a[2] <= b[2] + pad and a[3] <= b[3] + pad


def _overlap(a, b):
    w = min(a[2], b[2]) - max(a[0], b[0])
    h = min(a[3], b[3]) - max(a[1], b[1])
    return max(0.0, w) * max(0.0, h)


def _area(b):
    return max(0.0, b[2] - b[0]) * max(0.0, b[3] - b[1])


def _frac(b, box):
    w, h = box[2] - box[0], box[3] - box[1]
    return {"x": round((b[0] - box[0]) / w, 4), "y": round((b[1] - box[1]) / h, 4),
            "w": round((b[2] - b[0]) / w, 4), "h": round((b[3] - b[1]) / h, 4)}


def _rows_of(boxes):
    """Cards in rows (by their middles), each row left to right."""
    rows = []
    for b in sorted(boxes, key=lambda b: (b[1] + b[3]) / 2):
        mid = (b[1] + b[3]) / 2
        for r in rows:
            if r[0][1] <= mid <= r[0][3]:
                r.append(b)
                break
        else:
            rows.append([b])
    return [sorted(r, key=lambda b: b[0]) for r in rows]


def _pitch(vals, size):
    vals = sorted(set(round(v) for v in vals))
    steps = [b - a for a, b in zip(vals, vals[1:]) if b - a > size * 0.5]
    return max(0.0, (statistics.median(steps) - size)) if steps else None


def card_parts(pays, font_k=1.0):
    """The symbol / counts / pays of a card, from where its "pays and values" box is (card fractions):
    the symbol takes the side of the card the numbers leave free."""
    if not pays:
        pays = {"x": 0.55, "y": 0.0, "w": 0.45, "h": 1.0}
    px, py, pw, ph = pays["x"], pays["y"], pays["w"], pays["h"]
    pad = 0.03
    if pw >= ph * 1.6 and pw > 0.6:                  # a strip: numbers above or below the symbol
        above = py + ph / 2 < 0.5
        sym = {"x": pad, "y": (py + ph + pad) if above else pad, "w": 1 - 2 * pad,
               "h": max(0.1, (1 - py - ph - 2 * pad) if above else (py - 2 * pad))}
        counts = {"x": px + pw * 0.05, "y": py, "w": pw * 0.4, "h": ph}
        pays_ = {"x": px + pw * 0.5, "y": py, "w": pw * 0.45, "h": ph}
    else:                                            # a column: numbers left or right of the symbol
        left = px + pw / 2 < 0.5
        sym = {"x": (px + pw + pad) if left else pad, "y": pad,
               "w": max(0.1, (1 - px - pw - 2 * pad) if left else (px - 2 * pad)), "h": 1 - 2 * pad}
        counts = {"x": px + pw * 0.02, "y": py + ph * 0.06, "w": pw * 0.33, "h": ph * 0.88}
        pays_ = {"x": px + pw * 0.4, "y": py + ph * 0.06, "w": pw * 0.57, "h": ph * 0.88}
    fs = max(12, round(30 * font_k))
    r = lambda d: {k: round(v, 4) for k, v in d.items()}   # noqa: E731
    return [dict(r(sym), role="symbol"),
            dict(r(counts), role="counts", font_size=fs, color="#FFD21F", align="right"),
            dict(r(pays_), role="pays", font_size=fs, color="#FFFFFF", align="left")]


PAGE = "(blueprint: the whole PSD)"


def is_blueprint(psd):
    """Shapes and no text: a page drawn to be filled by the tool."""
    kinds = [layer.kind for layer, _g in _leaves(psd)]
    return "type" not in kinds and sum(1 for k in kinds if k == "shape") >= 3


def read_blueprint(psd, name=""):
    """(template, report) from an opened PSD (psd_tools)."""
    W, H = design_frame((psd.width, psd.height))      # the design frame is the PSD page's own shape
    k = W / float(psd.width)
    D = lambda b: [round(b[0] * k, 1), round(b[1] * k, 1), round((b[2] - b[0]) * k, 1), round((b[3] - b[1]) * k, 1)]  # noqa: E731
    full = float(psd.width) * float(psd.height)
    shapes = []
    for layer, groups in _leaves(psd):
        b = _bbox(layer)
        if _area(b) <= 0 or (layer.kind == "pixel" and _area(b) >= full * 0.9):
            continue                                 # the background
        if layer.kind in ("type", "smartobject"):
            continue
        shapes.append({"layer": layer, "box": b, "name": _key(layer.name), "groups": [_key(g) for g in groups]})
    if not shapes:
        raise ValueError("No shapes in this blueprint.")

    styles, report = {}, {"cards": 0, "rows": [], "boxes": [], "texts": 0}

    # a blueprint is a rough draft of WHERE things go: its shapes' colours are never copied — the
    # template's own looks are used (editable on the Canvas like any design)
    def style(sid, kind):
        styles[sid] = json.loads(json.dumps(LOOKS[kind]))
        return sid

    # ── WILD / SCATTER boxes: every shape named (or grouped) as one ──
    boxes_at, sec = {}, None
    feat_of = lambda s: next((f for f in ("scatter", "wild") if f in s["name"] or any(f in g for g in s["groups"])), None)  # noqa: E731
    features = {"enabled": False, "wild": False, "scatter": False, "tab": {"enabled": False}, "tab_h": 0}
    for f in ("scatter", "wild"):
        mine = [s for s in shapes if feat_of(s) == f]
        if not mine:
            continue
        for s in mine:
            s["used"] = True
        role = lambda s: next((r for r, words in (("title", ("heading", "title", "header")), ("label", ("caption", "text", "label")),  # noqa: E731
                                                  ("symbol", ("symbol", "icon", "pic"))) if any(w in s["name"] for w in words)), None)
        # the box is everything of it (a heading may stick out above the frame)
        outer = (min(s["box"][0] for s in mine), min(s["box"][1] for s in mine),
                 max(s["box"][2] for s in mine), max(s["box"][3] for s in mine))
        boxes_at[f] = outer
        report["boxes"].append(f)
        if f == "scatter":
            # an independent SCATTER card (in no row): the heading above a frame, the symbol(s) and their
            # numbers inside, the caption under them — the template's scatter section, where this was drawn
            title_h = 64.0
            ox, oy, ow, oh = D(outer)
            fh = oh - title_h - 4
            fs = max(18, min(60, round(fh * 0.62 / 3.6)))
            sec = {"enabled": True, "area": [ox, oy, ow, oh], "rect": [ox, round(oy + title_h + 4, 1), ow, round(fh, 1)],
                   "title_h": title_h, "caption_h": round(fh * 0.2, 1), "pad": round(min(ow, fh) * 0.06, 1),
                   "style": style("scatter_frame", "scatter"),
                   "title": {"font_size": round(title_h * 0.7), "color": "#FFC23A"},
                   "caption": {"font_size": round(fh * 0.2 * 0.45), "color": "#FFFFFF"},
                   "card": {"parts": [
                       {"role": "symbol", "x": 0.02, "y": 0.04, "w": 0.44, "h": 0.92},
                       {"role": "counts", "x": 0.48, "y": 0.04, "w": 0.16, "h": 0.92, "align": "right", "font_size": fs, "color": "#FFFFFF"},
                       {"role": "pays", "x": 0.68, "y": 0.04, "w": 0.3, "h": 0.92, "align": "left", "font_size": fs, "color": "#FFC23A"}]}}
            continue
        parts = {}
        for s in mine:
            r = role(s)
            if r in ("title", "label") and r not in parts:
                bh = (s["box"][3] - s["box"][1]) * k               # its band's height: the words sized to it
                parts[r] = dict(_frac(s["box"], outer), font_size=round(bh * (0.45 if r == "title" else 0.3)),
                                color="#FFD21F" if r == "title" else "#FFFFFF", align="center")
                parts[r]["keep"] = True                 # drawn on every sheet, its words or not
            elif r == "symbol" and r not in parts:
                parts["symbol"] = _frac(s["box"], outer)
        # the symbol and (a scatter's) numbers between the heading and the caption
        inner = parts.get("panel") or {"x": 0.04, "y": 0.04, "w": 0.92, "h": 0.92}
        y0 = max(inner["y"], (parts["title"]["y"] + parts["title"]["h"]) if "title" in parts else inner["y"]) + 0.02
        y1 = min(inner["y"] + inner["h"], parts["label"]["y"] if "label" in parts else inner["y"] + inner["h"]) - 0.02
        x0, ww = inner["x"] + 0.03, inner["w"] - 0.06
        parts.setdefault("symbol", {"x": x0, "y": y0, "w": ww, "h": y1 - y0})
        # the WILD's words under its symbol
        parts["text"] = {"x": x0, "y": y0 + (y1 - y0) * 0.5, "w": ww, "h": (y1 - y0) * 0.5, "font_size": 26, "color": "#FFFFFF"}
        parts["symbol"]["h"] = (y1 - y0) * 0.45
        for p in parts.values():
            for kk in ("x", "y", "w", "h"):
                if kk in p:
                    p[kk] = round(p[kk], 4)
        features.update(enabled=True, **{f: True, f"{f}_box": {"rect": D(outer)}, f"{f}_parts": parts})
        features["style"] = features.get("style") or style(f"{f}_box", "card")   # both boxes share one look

    # ── text areas: the title (one wide box above all the cards) and the rules ──
    is_text = lambda s: any(w in s["name"] for w in ("text box", "textbox", "rules", "notes", "title", "heading"))  # noqa: E731
    texts = [s for s in shapes if not s.get("used") and is_text(s)]
    for s in texts:
        s["used"] = True

    # ── cards and their "pays and values" boxes ──
    pay_boxes = [s for s in shapes if not s.get("used") and ("pays" in s["name"] or "values" in s["name"])]
    for s in pay_boxes:
        s["used"] = True
    cards = [s for s in shapes if not s.get("used")]
    if not cards:
        raise ValueError("No card shapes in this blueprint.")

    page = {"top": 30, "bottom": 30, "align": "center", "notes": {"enabled": True, "font_size": 26, "color": "#FFFFFF", "align": "center"}}
    # the page heading is the other pages' heading (its place and look); every text box holds rules text,
    # shared out in reading order (top to bottom, left to right)
    page["title"] = {"enabled": True, "plate": False}
    page["split_rules"] = True
    page["texts"] = []
    for i, s in enumerate(sorted(texts, key=lambda s: (round(s["box"][1] / 40), s["box"][0]))):
        tid = "notes" if i == 0 else f"t{i}"
        # beside a WILD / SCATTER box (same height band): it takes the box's place on a sheet without one
        beside = [f for f in report["boxes"] if min(s["box"][3], boxes_at[f][3]) > max(s["box"][1], boxes_at[f][1])]
        page["texts"].append({"id": tid, "rect": D(s["box"]), "font_size": 26, "color": "#FFFFFF", "align": "center",
                              "size_mode": "body", "locked": True,
                              **({"grow_into": beside} if beside else {})})
    report["texts"] = len(page["texts"])

    # rows: a group of cards is a row, else cards side by side
    by_group = {}
    for c in cards:
        by_group.setdefault(c["groups"][-1] if c["groups"] else "", []).append(c)
    sets = [v for g, v in by_group.items() if g] + ([v for g, v in by_group.items() if not g] or [])
    rows = []
    for st in sets:
        if any(not c["groups"] for c in st):          # loose cards: each row of them is a row
            rows += [[next(c for c in st if c["box"] == b) for b in r] for r in _rows_of([c["box"] for c in st])]
        else:
            rows.append(st)
    rows.sort(key=lambda r: min(c["box"][1] for c in r))
    names = ("high", "low", "mid")
    bands = []
    xs0 = min(c["box"][0] for c in cards)
    xs1 = max(c["box"][2] for c in cards)
    for ri, row in enumerate(rows[:3]):
        boxes = [c["box"] for c in row]
        cw = statistics.median(b[2] - b[0] for b in boxes)
        chh = statistics.median(b[3] - b[1] for b in boxes)
        grid = _rows_of(boxes)
        per = max(len(g) for g in grid)
        gx = _pitch([b[0] for b in boxes], cw)
        gy = _pitch([b[1] for b in boxes], chh)
        # its numbers' box: the one on one of its cards
        pb = next((p for p in pay_boxes for b in boxes if _overlap(p["box"], b) >= _area(p["box"]) * 0.6), None)
        pays = None
        if pb:
            host = max(boxes, key=lambda b: _overlap(pb["box"], b))
            cl = (max(pb["box"][0], host[0]), max(pb["box"][1], host[1]), min(pb["box"][2], host[2]), min(pb["box"][3], host[3]))
            pays = _frac(cl, host)
        sid = style("card", "card")
        band = {"name": names[ri], "per_row": per, "card_w": round(cw * k, 1), "card_h": round(chh * k, 1),
                "pos": [round(min(b[0] for b in boxes) * k, 1), round(min(b[1] for b in boxes) * k, 1)],
                # the row's box as drawn: fewer cards centre in it, more cards shrink to stay inside
                "lock_size": [round((max(b[2] for b in boxes) - min(b[0] for b in boxes)) * k, 1),
                              round((max(b[3] for b in boxes) - min(b[1] for b in boxes)) * k, 1)],
                "style": sid, "parts": card_parts(pays, min(cw * k / 320.0, chh * k / 150.0))}
        if gx is not None:
            band["gap_x"] = round(gx * k, 1)
        if gy is not None:
            band["gap_y"] = round(gy * k, 1)
        bands.append(band)
        report["rows"].append({"row": names[ri], "cards": len(row), "per_row": per})
        report["cards"] += len(row)
    if len(bands) == 1:                              # one row of cards: the royals go under it, same cards
        b2 = dict(bands[0], name="low")
        b2.pop("pos", None)
        b2.pop("lock_size", None)
        bands.append(b2)
    if len(bands) >= 3:                              # the third row the design drew is the middle tier
        bands[1], bands[2] = bands[2], bands[1]
        bands[1]["name"], bands[2]["name"] = "low", "mid"
        bands[0]["count"] = report["rows"][0]["cards"]
    gaps = [b.get("gap_x") for b in bands if b.get("gap_x")]
    page.update(left=round(xs0 * k, 1), right=round(W - xs1 * k, 1),
                gap_x=gaps[0] if gaps else 24, gap_y=bands[0].get("gap_y", 18), band_gap=bands[0].get("gap_y", 18))
    card0 = {"parts": bands[0]["parts"]}
    nm = name or os.path.splitext(os.path.basename(getattr(psd, "_path", "") or "Blueprint"))[0]
    template = {"kind": "card_template", "schema": 1, "name": nm,
                "description": f"From the blueprint {nm}: " + ", ".join(
                    f"{r['cards']} {r['row']} cards" for r in report["rows"]) + (
                    "; " + " and ".join(b.upper() for b in report["boxes"]) + " (when the sheet has one)" if report["boxes"] else ""),
                "page": page, "features": features, "band_mode": "split", "bands": bands, "styles": styles,
                "card": card0, "frame": "page", **({"scatter_section": sec} if sec else {}), "blueprint": {"psd": nm, "size": [psd.width, psd.height]}}
    look = styles.get(bands[0]["style"]) or {}
    report.update(rows=[r["cards"] for r in report["rows"]], look=look, parts=[], blueprint=True, notes=[
        "A blueprint: every sheet fills it from its own Excel.",
        *[f"The {b.upper()} " + ("card" if b == "scatter" else "box") + f" shows only on sheets that have a {b}" + (" — the rules text takes its place on the others." if any(
            b in (x.get("grow_into") or []) for x in page["texts"]) else ".") for b in report["boxes"]],
        "Rows keep the box drawn for them: fewer cards centre in it, more cards get smaller.",
        "Move the numbers left / right / above / below on the Card bar; everything stays editable."])
    return template, report
