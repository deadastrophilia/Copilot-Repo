"""Games library: Game -> Market -> Version.

How artists actually work: one game has several markets, each market has its
own Excel, and every market of a game shares ONE art style. Excel files get
revised, so each market accumulates versions.

    <game folder>/pshelp_game.json      # the game: shared style + markets + versions

    {
      "schema": 1, "id": "baozhao_1a2b3c", "name": "BaoZhao",
      "style":  {...every setting that is the game's look (fonts, styles, templates...)},
      "markets": [
        {"id": "nyl_4d5e", "name": "NYL", "excel_path": "...xlsx",
         "settings": {...the market's own: output folder/name, page tweaks...},
         "versions": [{"n": 1, "date": "...", "excel_path": "...", "excel_sha256": "...",
                       "psd_path": "...", "baseline": "..."}]}
      ]
    }

The file lives in the game folder so it travels with the game (and can be
shared). A small registry in the user's profile remembers where games are.

The web session keeps working exactly as before: opening a market merges
style + market settings into the session config (plus ``active_game`` /
``active_market``), and every config save is split back — the look goes to
the game (so all markets change together), market fields to the market.
"""
import copy
import datetime
import os
import re
import uuid

from . import project_package as _pp

GAME_FILE = "pshelp_game.json"
SCHEMA = 1
REGISTRY_FILE = os.path.join(os.path.expanduser("~"), "PsHelpScreenTool_Games.json")


def set_registry(path):
    """Keep the games list next to the session file (isolated sessions get their own)."""
    global REGISTRY_FILE
    REGISTRY_FILE = os.path.abspath(path)


def _store_dir():
    """Game files live on this PC (beside the registry), never inside the depot."""
    return os.path.splitext(REGISTRY_FILE)[0]


def find_by_folder(folder):
    """The registered game whose folder is `folder` (or None)."""
    want = os.path.normcase(os.path.abspath(folder))
    for path in _registry()["games"]:
        g = _read(path)
        if g and os.path.normcase(os.path.abspath(g.get("folder") or "")) == want:
            return g
    legacy = _read(game_file_for(folder))           # games made before files moved off the depot
    return legacy

# Settings that belong to one market; everything else is the game's style.
MARKET_KEYS = (
    "excel_path", "output_dir", "output_name", "selected_sheets", "render_all_pages",
    "prev_excel_path", "prev_psd_path", "update_mode", "overwrite_existing",
    "update_save_mode", "png_suffix", "page_overrides", "png_output_dir",
)
# dynamic_settings entries that are per market (hand tweaks keyed by sheet)
MARKET_DYNAMIC_KEYS = ("live_overrides",)
# never stored in a game: session bookkeeping
SESSION_KEYS = ("recent_projects", "ai_suggestions", "active_game", "active_market")


def _now():
    return datetime.datetime.now().isoformat(timespec="seconds")


def _slug(text, fallback="game"):
    s = re.sub(r"[^A-Za-z0-9]+", "_", str(text or "")).strip("_").lower()
    return s or fallback


def _new_id(name):
    return f"{_slug(name)}_{uuid.uuid4().hex[:6]}"


# ── registry ────────────────────────────────────────────────────────────────
def _registry():
    data, _err = _pp._load_json(REGISTRY_FILE)
    data = data if isinstance(data, dict) else {}
    data.setdefault("games", [])
    return data


def _register(game_file):
    reg = _registry()
    game_file = os.path.abspath(game_file)
    reg["games"] = [g for g in reg["games"] if os.path.abspath(g) != game_file] + [game_file]
    _pp._write_json(REGISTRY_FILE, reg)


def unregister(game_id):
    """Forget a game (its folder and files are left untouched)."""
    reg = _registry()
    keep = []
    for path in reg["games"]:
        g = _read(path)
        if not (g and g.get("id") == game_id):
            keep.append(path)
    reg["games"] = keep
    _pp._write_json(REGISTRY_FILE, reg)
    return {"ok": True}


# ── game files ──────────────────────────────────────────────────────────────
def game_file_for(folder):
    return os.path.join(os.path.abspath(folder), GAME_FILE)


def _read(path):
    data, _err = _pp._load_json(path)
    if not isinstance(data, dict) or not data.get("id"):
        return None
    data["_file"] = os.path.abspath(path)
    data["folder"] = data.get("folder") or os.path.dirname(os.path.abspath(path))
    return data


def psd_background(psd_settings, folder):
    """The reference PSD's background layer saved into the game folder, when the artist kept
    "Use the PSD's background picture" ticked — its path, or "" (psd_style_import.export_bg)."""
    ps = psd_settings or {}
    wanted = any(f.get("key") == "bg_from_psd" and f.get("apply") is not False and f.get("value") not in (False, "false", 0)
                 for f in (ps.get("fields") or []) if isinstance(f, dict))
    src = str(ps.get("source") or "")
    if not wanted or not src or not os.path.isfile(src) or not folder or not os.path.isdir(folder):
        return ""
    from . import psd_style_import

    out = os.path.join(folder, os.path.splitext(os.path.basename(src))[0] + "_BG.png")
    try:
        got = psd_style_import.export_bg(src, out)
    except Exception:
        return ""
    return got[0] if got else ""


def restyle(game, psd_settings):
    """Mimic a PSD design on an existing (closed) game: the fields and layer styles the artist ticked,
    and the PSD's background picture. The game's markets, paths and everything else stay."""
    from . import psd_style_import

    game = dict(game)
    style = psd_style_import.apply(game.get("style") or {}, (psd_settings or {}).get("fields"),
                                   (psd_settings or {}).get("styles"))
    bg = psd_background(psd_settings, game.get("folder") or "")
    if bg:
        style["bg_path"], style["bg_source"] = bg, "image"
    game["style"] = style
    game["settings_source"] = os.path.basename(str((psd_settings or {}).get("source") or ""))
    save(game)
    return game


def save(game):
    game = dict(game)
    path = game.pop("_file", None) or os.path.join(_store_dir(), f"{game['id']}.json")
    if os.path.basename(path) == GAME_FILE:
        game.pop("folder", None)                      # legacy file inside the game folder
    game["updated_at"] = _now()
    _pp._write_json(path, game)
    return path


def list_games():
    """Summaries of every registered game (missing folders are reported, not dropped)."""
    out = []
    for path in _registry()["games"]:
        g = _read(path)
        if g is None:
            out.append({"id": "", "file": path, "missing": True,
                        "name": os.path.basename(os.path.dirname(path)) or path})
            continue
        out.append(summary(g))
    return out


def get(game_id):
    for path in _registry()["games"]:
        g = _read(path)
        if g and g.get("id") == game_id:
            return g
    return None


def summary(game):
    markets = [market_status(m) for m in game.get("markets") or []]
    last = max((v.get("date") or "" for m in game.get("markets") or [] for v in m.get("versions") or []), default="")
    return {
        "id": game["id"], "name": game.get("name") or "", "folder": game["folder"], "file": game["_file"],
        "markets": markets, "market_count": len(markets), "last_built": last,
        "changed": sum(1 for m in markets if m["state"] == "changed"),
        "assets": game.get("assets") or {},
    }


def market_status(market):
    """{id, name, excel_path, state: never_built|up_to_date|changed|excel_missing, version, ...}"""
    versions = market.get("versions") or []
    last = versions[-1] if versions else None
    excel = market.get("excel_path") or ""
    st = {"id": market["id"], "name": market.get("name") or "", "excel_path": excel,
          "version": last.get("n") if last else 0, "last_built": last.get("date") if last else "",
          "psd_path": last.get("psd_path") if last else "", "versions": len(versions)}
    if not excel or not os.path.isfile(excel):
        st["state"] = "excel_missing"
    elif not last:
        st["state"] = "never_built"
    else:
        same = _pp.file_sha256(excel) == last.get("excel_sha256")
        st["state"] = "up_to_date" if same else "changed"
    return st


# ── creating a game from a folder (auto-fill) ────────────────────────────────
def market_names(excel_paths):
    """Short market names from Excel file names: the part that differs.

    BZZF_Blast_AGR_NYL.xlsx + BZZF_Blast_AGR_PA.xlsx -> NYL, PA.
    """
    stems = [os.path.splitext(os.path.basename(p))[0] for p in excel_paths]
    if len(stems) < 2:
        return [s.replace("_", " ").strip() or "Market" for s in stems]
    split = [re.split(r"[_\-\s.]+", s) for s in stems]
    prefix = 0
    while all(len(t) > prefix + 1 for t in split) and len({t[prefix].lower() for t in split}) == 1:
        prefix += 1
    names = [" ".join(t[prefix:]) or s for t, s in zip(split, stems)]
    # keep them unique
    seen = {}
    out = []
    for n in names:
        seen[n] = seen.get(n, 0) + 1
        out.append(n if seen[n] == 1 else f"{n} {seen[n]}")
    return out


def _norm(name):
    return re.sub(r"[\s_\-]+", "", str(name or "")).lower()


def _child(parent, names, depth=1):
    """First sub-folder of `parent` whose normalised name is in `names` (searches `depth` levels)."""
    try:
        entries = sorted(e for e in os.listdir(parent) if os.path.isdir(os.path.join(parent, e)))
    except OSError:
        return ""
    for e in entries:
        if _norm(e) in names:
            return os.path.join(parent, e)
    if depth > 1:
        for e in entries:
            hit = _child(os.path.join(parent, e), names, depth - 1)
            if hit:
                return hit
    return ""


PRODUCTION = {"production", "productions"}
VIDEO = {"video", "videos"}
HELP_SCREEN = {"helpscreen", "helpscreens"}
WORKING = {"working", "work"}
STATIC = {"static", "statics"}
SYMBOL_DIRS = {"symbols", "symbol", "icons", "icon", "symbolsicons", "syms"}
# market keywords a docs sub-folder name may START with ("NYL - New York", "HHR_2024")
MARKET_KEYWORDS = ("NYL", "HHR", "ATLS", "C2")
_SKIP_WALK = {"output", "outputs", "static", "statics", "working", ".git", ".svn", "$recycle.bin", "__pycache__", "node_modules"}
_EXCEL_EXT = (".xlsx", ".xlsm", ".xls")
_IMG_EXT = (".png", ".jpg", ".jpeg", ".webp")


def _is_docs(name):
    """Game Docs / Game Documentation / Help Docs / Help Documentation (any spacing/case)."""
    n = _norm(name)
    return "doc" in n and ("game" in n or "help" in n)


def _docs_dirs(folder):
    """Documentation folders, best first (depth 2; plain "Docs" last)."""
    found = []
    for dirpath, dirnames, _files in os.walk(folder):
        depth = dirpath.count(os.sep) - folder.count(os.sep)
        dirnames[:] = [d for d in dirnames if _norm(d) not in _SKIP_WALK and not d.startswith((".", "$"))]
        if depth >= 2:
            dirnames[:] = []
        for d in dirnames:
            if _is_docs(d):
                found.append((0, depth, os.path.join(dirpath, d)))
            elif _norm(d) in ("docs", "documentation", "documents"):
                found.append((1, depth, os.path.join(dirpath, d)))
    return [p for _r, _d, p in sorted(found)]


def market_keyword(name, keywords=MARKET_KEYWORDS):
    """The market a folder/file name belongs to: "NYL - New York" -> "NYL",
    "BZZF_Blast_AGR_HHR.xlsx" -> "HHR" (keyword at the start, or as a separate word)."""
    raw = str(name or "")
    for kw in keywords:
        if re.match(rf"^{re.escape(kw)}(?![A-Za-z])", raw, re.I):
            return kw
    for kw in keywords:
        if re.search(rf"(?<![A-Za-z0-9]){re.escape(kw)}(?![A-Za-z0-9])", os.path.splitext(raw)[0], re.I):
            return kw
    return ""


def _walk_files(root, exts, depth_limit=4):
    out = []
    for dirpath, dirnames, files in os.walk(root):
        depth = dirpath.count(os.sep) - root.count(os.sep)
        dirnames[:] = [d for d in dirnames if _norm(d) not in _SKIP_WALK and not d.startswith((".", "$"))]
        if depth >= depth_limit:
            dirnames[:] = []
        for f in files:
            if f.lower().endswith(exts) and not f.startswith("~$"):
                out.append(os.path.join(dirpath, f))
    return out


def _excel_score(path, market=""):
    """How likely an Excel is a help-screen workbook (higher = better)."""
    name = _norm(os.path.basename(path))
    score = 0
    for word, pts in (("help", 3), ("agr", 3), ("rules", 2), ("paytable", 2), ("helpscreen", 3)):
        if word in name:
            score += pts
    for word in ("math", "par", "budget", "schedule", "invoice", "timesheet", "tracker"):
        if word in name:
            score -= 4
    if market and _norm(market) in name:
        score += 2
    try:
        from openpyxl import load_workbook

        wb = load_workbook(path, read_only=True)
        sheets = " ".join(wb.sheetnames).lower()
        wb.close()
        if re.search(r"pay\s*table|game\s*rules|rules|help|features?|jackpot", sheets):
            score += 4
    except Exception:
        score -= 2                                      # unreadable: unlikely to be ours
    return score


def help_screen_paths(video_dir, market):
    """(help, working, static) for a market under Production/Video — existing
    folders when found (any spelling), else the standard ones to create."""
    market_dir = ""
    if video_dir and os.path.isdir(video_dir):
        for e in sorted(os.listdir(video_dir)):
            if os.path.isdir(os.path.join(video_dir, e)) and (_norm(e) == _norm(market) or market_keyword(e) == market):
                market_dir = os.path.join(video_dir, e)
                break
    if not market_dir:
        market_dir = os.path.join(video_dir, market) if video_dir else ""
    help_dir = _child(market_dir, HELP_SCREEN) if market_dir and os.path.isdir(market_dir) else ""
    help_dir = help_dir or (os.path.join(market_dir, "Help Screen") if market_dir else "")
    if not help_dir:
        # no Production\Video folder: nothing to name — a bare "Working" was a folder RELATIVE to wherever
        # the tool runs (JuCaiJin's symbols and PSDs landed in the tool's own folder); the caller falls back
        return "", "", ""
    working = (_child(help_dir, WORKING) if os.path.isdir(help_dir) else "") or os.path.join(help_dir, "Working")
    static = (_child(help_dir, STATIC) if os.path.isdir(help_dir) else "") or os.path.join(help_dir, "Static")
    return help_dir, working, static


def find_symbols_folder(roots):
    """The game's symbol folder: a folder named symbols/icons (most pictures wins),
    searched in `roots` in order. "" when none."""
    best = ("", 0)
    for root in roots:
        if not root or not os.path.isdir(root):
            continue
        for dirpath, dirnames, files in os.walk(root):
            depth = dirpath.count(os.sep) - root.count(os.sep)
            dirnames[:] = [d for d in dirnames if _norm(d) not in _SKIP_WALK - {"working"} and not d.startswith((".", "$"))]
            if depth >= 5:
                dirnames[:] = []
            base = _norm(os.path.basename(dirpath))
            if base in SYMBOL_DIRS or "symbol" in base:
                n = sum(1 for f in files if f.lower().endswith(_IMG_EXT))
                if n >= 3 and n > best[1]:
                    best = (dirpath, n)
        if best[0]:
            return best[0]                            # the first root that has one wins
    return ""


def discover_depot(folder):
    """Markets and their Excel files, preferring the standard layout but never
    depending on it:

      1. documentation folders (Game Docs / Game Documentation / Help Docs …),
      2. market folders inside them whose names start with a market keyword
         (NYL, HHR, ATLS, C2 — extra text allowed),
      3. any other sub-folder of the docs, then the rest of the game folder,
         so an Excel moved out of its market folder is still found and is
         matched to its market by the keyword in its file name.

    Excel files are scored (name, sheet names) so unrelated workbooks rank
    low; every plausible candidate is returned for the user to choose from.
    Returns None when the folder has no documentation folder and no market
    Excel anywhere.
    """
    docs_list = _docs_dirs(folder)
    production = _child(folder, PRODUCTION, depth=2)
    video = _child(production, VIDEO) if production else ""
    if production and not video:
        video = os.path.join(production, "Video")

    # candidates: (excel, market or "", priority) — lower priority = preferred place
    seen, cands = set(), []

    def add(path, market, prio):
        key = os.path.normcase(os.path.abspath(path))
        if key not in seen:
            seen.add(key)
            cands.append((path, market, prio))

    for docs in docs_list:
        for entry in sorted(os.listdir(docs)):
            mdir = os.path.join(docs, entry)
            if not os.path.isdir(mdir):
                continue
            kw = market_keyword(entry)
            for x in _walk_files(mdir, _EXCEL_EXT, 3):
                add(x, kw or market_keyword(os.path.basename(x)), 0 if kw else 1)
        for x in _walk_files(docs, _EXCEL_EXT, 1):           # loose files in the docs folder
            add(x, market_keyword(os.path.basename(x)), 1)
    for x in _walk_files(folder, _EXCEL_EXT, 4):             # moved elsewhere in the game folder
        add(x, market_keyword(os.path.basename(x)), 2)
    if not docs_list and not production:
        return None                                      # a plain folder of Excel files, not a depot

    scored = [(p, m, r, _excel_score(p, m)) for p, m, r in cands]
    markets, unassigned = {}, []
    for p, m, r, s in scored:
        if s < 0:
            continue                                     # clearly not a help-screen workbook
        if m:
            markets.setdefault(m, []).append((r, -s, -os.path.getmtime(p), p, s))
        else:
            unassigned.append({"excel_path": p, "score": s})
    out_markets = []
    for name in sorted(markets, key=lambda k: (MARKET_KEYWORDS.index(k) if k in MARKET_KEYWORDS else 99, k)):
        ranked = sorted(markets[name])
        best = ranked[0]
        # several help-screen-looking workbooks in the same place: the user should confirm
        plausible = [c for c in ranked if c[0] == best[0] and c[4] >= 4]
        help_dir, working, static = help_screen_paths(video, name)
        out_markets.append({
            "name": name, "excel_path": best[3],
            "excel_candidates": [c[3] for c in ranked],
            "ambiguous": len(plausible) > 1,               # let the user pick the right workbook
            "outside_market_folder": best[0] > 0,
            "help_screen": help_dir, "working": working, "static": static,
            "help_exists": bool(help_dir) and os.path.isdir(help_dir),
        })
    unassigned.sort(key=lambda u: -u["score"])
    return {"game_docs": docs_list[0] if docs_list else "", "docs_dirs": docs_list,
            "production": production, "video": video, "markets": out_markets,
            "other_excels": [u["excel_path"] for u in unassigned]}


def ensure_output_folders(cfg):
    """Create the market's Help Screen/Working/Static folders when missing."""
    made = []
    for key in ("output_dir", "png_output_dir"):
        target = str((cfg or {}).get(key) or "")
        if target and not os.path.isdir(target):
            os.makedirs(target, exist_ok=True)
            made.append(target)
    return made


def discover(folder):
    """What a game folder contains: Excel workbooks (= markets), symbols,
    background, output, heading/logo art. Pure filesystem facts, nothing is written."""
    from . import ai_assist

    folder = os.path.abspath(folder)
    det = ai_assist.detect_project(folder)
    if det.get("error"):
        return {"ok": False, "error": det["error"]}
    depot = discover_depot(folder)
    excels = [p for p in (det.get("excel_candidates") or []) if os.path.isfile(p)]
    excels.sort(key=lambda p: os.path.basename(p).lower())
    bg = det.get("bg_path") or ""
    if bg and os.path.isdir(bg):
        from .ui_web.engine_api import _first_bg_image_file

        bg = _first_bg_image_file(bg) or ""
    markets = depot["markets"] if depot else [{"name": n, "excel_path": p} for n, p in zip(market_names(excels), excels)]
    # symbols: the market's Working/Symbols first, then the docs, then the whole game folder
    roots = [os.path.dirname(m["working"]) for m in markets if m.get("working")] + list((depot or {}).get("docs_dirs") or []) + [folder]
    symbols = find_symbols_folder(roots)
    return {
        "ok": True,
        "folder": folder,
        "name": os.path.basename(folder.rstrip("\\/")),
        "layout": "depot" if depot else "folder",
        "markets": markets,
        "other_excels": (depot or {}).get("other_excels") or [],
        "game_docs": (depot or {}).get("game_docs") or "",
        "video": (depot or {}).get("video") or "",
        "icon_folder": symbols,                         # "" -> the user is asked (folder or PSD)
        "bg_path": bg,
        "output_dir": det.get("output_dir") or os.path.join(folder, "output"),
        "heading_folder": _heading_folder(folder),
        "existing": find_by_folder(folder) is not None,
    }


def _heading_folder(folder):
    for dirpath, dirnames, _files in os.walk(folder):
        if dirpath.count(os.sep) - os.path.abspath(folder).count(os.sep) >= 2:
            dirnames[:] = []
            continue
        for d in dirnames:
            if re.search(r"heading|title|logo", d, re.I):
                return os.path.join(dirpath, d)
    return ""


def split_config(cfg):
    """(style, market_settings) from a session config."""
    style, market = {}, {}
    for key, value in (cfg or {}).items():
        if key in SESSION_KEYS:
            continue
        if key in MARKET_KEYS:
            market[key] = copy.deepcopy(value)
        else:
            style[key] = copy.deepcopy(value)
    ds = style.get("dynamic_settings")
    if isinstance(ds, dict):
        ds = dict(ds)
        market_ds = {k: ds.pop(k) for k in MARKET_DYNAMIC_KEYS if k in ds}
        style["dynamic_settings"] = ds
        if market_ds:
            market["dynamic_settings"] = market_ds
    return style, market


_ABS_PATH = re.compile(r"^(?:[A-Za-z]:[\\/]|\\\\|/)")
# settings that belong to ONE game even though they are not paths
GAME_SPECIFIC_KEYS = ("icon_mappings", "icon_mappings_by_excel", "icon_size_overrides", "page_overrides",
                      "selected_sheets", "keyword_colors", "game_name", "symbol_tokens_known")
GAME_SPECIFIC_DYNAMIC = ("template_json", "live_overrides", "game_name", "text_style_rules")


def strip_game_specific(style):
    """(clean_style, removed) — the reusable formatting only.

    Every absolute file/folder path is dropped (symbols, background, templates,
    heading art…) together with per-game data like symbol mappings, so a new
    game never silently points at another game's files. `removed` lists what
    was dropped (dotted keys) for the user.
    """
    removed = []

    def walk(obj, prefix):
        if isinstance(obj, dict):
            out = {}
            for k, v in obj.items():
                key = f"{prefix}.{k}" if prefix else str(k)
                if isinstance(v, str) and _ABS_PATH.match(v.strip()):
                    removed.append(key)
                    continue
                if isinstance(v, str) and "\n" in v and all(_ABS_PATH.match(x.strip()) for x in v.splitlines() if x.strip()):
                    if v.strip():
                        removed.append(key)
                    continue
                if isinstance(v, dict) and v and all(isinstance(kk, str) and _ABS_PATH.match(kk) for kk in v):
                    removed.append(key)                     # dict keyed by file paths (json_sheet_overrides)
                    continue
                out[k] = walk(v, key)
            return out
        return obj

    clean = walk(copy.deepcopy(style or {}), "")
    for k in GAME_SPECIFIC_KEYS:
        if clean.get(k):
            removed.append(k)
        clean.pop(k, None)
    ds = clean.get("dynamic_settings")
    if isinstance(ds, dict):
        for k in GAME_SPECIFIC_DYNAMIC:
            if ds.get(k):
                removed.append("dynamic_settings." + k)
            ds.pop(k, None)
    return clean, sorted(set(removed))


def create(folder, name="", base_config=None, markets=None, settings_mode="current", defaults=None,
           psd_settings=None):
    """Create (or re-open) the game for `folder`.

    settings_mode:
      "current" — the current look (fonts, sizes, layer styles, spacing) is the
                  starting point, WITHOUT the previous game's paths and per-game
                  data (strip_game_specific);
      "new"     — fresh default settings;
      "psd"     — fresh defaults with the formatting read from a reference PSD
                  and reviewed by the user (psd_settings = {source, fields,
                  styles}, see psd_style_import); no path from that PSD.
    Only what this game's folder contains (symbols, background, heading art)
    is filled in; anything not found is left empty so the user is asked.
    """
    folder = os.path.abspath(folder)
    existing = find_by_folder(folder)
    if existing:
        _register(existing["_file"])
        return existing
    found = discover(folder)
    if not found.get("ok"):
        raise ValueError(found.get("error") or "Folder not found.")
    source = copy.deepcopy(defaults or {}) if settings_mode in ("new", "psd") else (base_config or {})
    style, _market = split_config(source)
    style, dropped = strip_game_specific(style)
    if settings_mode == "psd":
        from . import psd_style_import

        style = psd_style_import.apply(style, (psd_settings or {}).get("fields"), (psd_settings or {}).get("styles"))
    for key in ("icon_folder", "bg_path"):
        style.pop(key, None)
    if found["icon_folder"]:
        style["icon_folder"] = found["icon_folder"]
    if found["bg_path"]:
        style["bg_path"] = found["bg_path"]
        style["bg_source"] = "image"
    if settings_mode == "psd":                          # the PSD's own background picture, where it sits
        bg = psd_background(psd_settings, folder)
        if bg:
            style["bg_path"], style["bg_source"] = bg, "image"
    if found["heading_folder"]:
        al = dict(style.get("alignment_settings") or {})
        al["heading_image_folder"] = found["heading_folder"]
        style["alignment_settings"] = al
    game = {
        "schema": SCHEMA, "id": _new_id(name or found["name"]), "name": name or found["name"],
        "created_at": _now(), "style": style, "markets": [],
        "settings_mode": settings_mode, "not_copied": dropped,
        "settings_source": os.path.basename(str((psd_settings or {}).get("source") or "")) if settings_mode == "psd" else "",
        "assets": {"icon_folder": found["icon_folder"], "bg_path": found["bg_path"],
                   "heading_folder": found["heading_folder"], "output_dir": found["output_dir"]},
        "folder": folder,
        "layout": found.get("layout") or "folder",
        # depot: one fixed file per market in Working (Perforce keeps the history);
        # plain folders: "<Game> <Market> vN.psd" per build
        "naming": "fixed" if found.get("layout") == "depot" else "versioned",
        "video": found.get("video") or "",
    }
    by_excel = {os.path.normcase(m["excel_path"]): m for m in found["markets"]}
    for m in (markets if markets is not None else found["markets"]):
        info = by_excel.get(os.path.normcase(m["excel_path"]), {})
        if not info and found.get("layout") == "depot":
            # an Excel the user chose for a market (or an "other" Excel added as a market)
            info = next((x for x in found["markets"] if x["name"] == m.get("name")), {})
        add_market(game, m["excel_path"], m.get("name") or info.get("name") or "", save_now=False,
                   output_dir=info.get("working") or "", png_dir=info.get("static") or "")
    path = save(game)
    _register(path)
    return _read(path)


def add_market(game, excel_path, name="", save_now=True, output_dir="", png_dir=""):
    name = name or market_names([excel_path])[0]
    if not output_dir and game.get("layout") == "depot" and game.get("video"):
        _h, output_dir, png_dir = help_screen_paths(game.get("video") or "", name)
    settings = {
        "output_dir": output_dir or (game.get("assets") or {}).get("output_dir") or "",
        "output_name": f"{game.get('name') or 'Game'} {name}".strip(),
    }
    if png_dir:
        settings["png_output_dir"] = png_dir             # PNGs straight into the market's Static folder
    market = {
        "id": _new_id(name), "name": name, "excel_path": os.path.abspath(excel_path),
        "settings": settings,
        "versions": [],
    }
    game.setdefault("markets", []).append(market)
    if save_now:
        save(game)
    return market


def find_market(game, market_id):
    for m in game.get("markets") or []:
        if m["id"] == market_id:
            return m
    return None


# ── session <-> game ─────────────────────────────────────────────────────────
def open_market(game, market_id, session_cfg, defaults=None):
    """Session config for working on one market: defaults + game style + market."""
    market = find_market(game, market_id)
    if market is None:
        raise KeyError("Market not found.")
    cfg = copy.deepcopy(defaults or {})
    cfg.update(copy.deepcopy(game.get("style") or {}))
    settings = copy.deepcopy(market.get("settings") or {})
    market_ds = settings.pop("dynamic_settings", None)
    cfg.update(settings)
    if market_ds:
        ds = dict(cfg.get("dynamic_settings") or {})
        ds.update(market_ds)
        cfg["dynamic_settings"] = ds
    cfg["excel_path"] = market.get("excel_path") or ""
    last = (market.get("versions") or [None])[-1]
    cfg["prev_psd_path"] = (last or {}).get("psd_path") or ""
    # every build is a new version file: an earlier PSD (maybe edited by an artist)
    # is never overwritten
    base_name = _strip_version(cfg.get("output_name") or f"{game.get('name') or 'Game'} {market.get('name') or ''}".strip())
    if game.get("naming") == "fixed":
        cfg["output_name"] = base_name               # same file each build (the depot keeps revisions)
    else:
        cfg["output_name"] = f"{base_name} v{((last or {}).get('n') or 0) + 1}"
    cfg["overwrite_existing"] = False
    cfg["update_save_mode"] = "new_copy"
    cfg["prev_excel_path"] = ""                    # the PSD's saved baseline is the diff source
    cfg["update_mode"] = False
    for key in ("recent_projects", "ai_suggestions"):
        cfg[key] = (session_cfg or {}).get(key) or []
    cfg["active_game"] = game["id"]
    cfg["active_market"] = market_id
    return cfg


def sync_from_session(cfg):
    """Write the session config back into its game/market (no-op without one).

    Returns the game id written, or "".
    """
    game_id = (cfg or {}).get("active_game")
    market_id = (cfg or {}).get("active_market")
    if not game_id:
        return ""
    game = get(game_id)
    if game is None:
        return ""
    style, market_settings = split_config(cfg)
    style.pop("excel_path", None)
    game["style"] = style
    market = find_market(game, market_id) if market_id else None
    if market is not None:
        market_settings.pop("excel_path", None)
        for transient in ("prev_excel_path", "prev_psd_path", "update_mode", "overwrite_existing", "update_save_mode"):
            market_settings.pop(transient, None)
        if market_settings.get("output_name"):
            market_settings["output_name"] = re.sub(r"_rebuilt$", "", _strip_version(market_settings["output_name"]))
        market["settings"] = market_settings
        if cfg.get("excel_path"):
            market["excel_path"] = cfg["excel_path"]
    save(game)
    return game_id


def protect_artist_psd(cfg):
    """Fixed-name builds: never overwrite a PSD that was edited after our last
    build, or that is read-only (not checked out). Returns a note or "".

    The build is redirected to "<name>_rebuilt.psd" beside it instead.
    """
    out_dir, name = str(cfg.get("output_dir") or ""), str(cfg.get("output_name") or "")
    if not (out_dir and name):
        return ""
    ext = ".psb" if str(cfg.get("output_format") or "PSD").upper() == "PSB" else ".psd"
    target = os.path.join(out_dir, name + ext)
    if not os.path.isfile(target):
        return ""
    game = get(cfg.get("active_game") or "")
    market = find_market(game, cfg.get("active_market")) if game else None
    last = ((market or {}).get("versions") or [None])[-1] or {}
    st = os.stat(target)
    ours = (last.get("psd_path") and os.path.normcase(last["psd_path"]) == os.path.normcase(target)
            and last.get("psd_size") == st.st_size and abs((last.get("psd_mtime") or 0) - st.st_mtime) < 2)
    readonly = not os.access(target, os.W_OK)
    if ours and not readonly:
        return ""
    cfg["output_name"] = name + "_rebuilt"
    why = ("it is read-only (check it out in Perforce first)" if readonly
           else "it was changed after the last build (an artist may have edited it)")
    return f"{os.path.basename(target)} was not overwritten because {why}; the new build is {name}_rebuilt{ext}."


def _strip_version(name):
    return re.sub(r"\s+v\d+$", "", str(name or "").strip())


def record_version(cfg, psd_path, note=""):
    """After a successful PSD build of the active market: add a version entry."""
    game_id, market_id = (cfg or {}).get("active_game"), (cfg or {}).get("active_market")
    if not (game_id and market_id and psd_path):
        return None
    game = get(game_id)
    market = find_market(game, market_id) if game else None
    if market is None:
        return None
    excel = cfg.get("excel_path") or market.get("excel_path") or ""
    versions = market.setdefault("versions", [])
    entry = {
        "n": (versions[-1]["n"] + 1) if versions else 1,
        "date": _now(),
        "excel_path": excel,
        "excel_sha256": _pp.file_sha256(excel) if excel and os.path.isfile(excel) else "",
        "psd_path": os.path.abspath(psd_path),
        "baseline": _pp.baseline_path_for_psd(psd_path) or "",
        "note": note,
    }
    try:
        st = os.stat(psd_path)
        entry["psd_size"], entry["psd_mtime"] = st.st_size, st.st_mtime   # to spot later artist edits
    except OSError:
        pass
    versions.append(entry)
    save(game)
    # the session now points at the next version's file name
    if cfg.get("output_name") and game.get("naming") != "fixed":
        cfg["output_name"] = f"{_strip_version(cfg['output_name'])} v{entry['n'] + 1}"
    return entry


def adopt_psd(cfg, psd_path, mem=None):
    """A tool-made PSD opened with "Open a PSD": put it in the games list as its market's current
    version, so its market shows "Update PSD" once its Excel changes. The game and market come from
    the PSD's identity, else the game whose folder holds it, else a new game for that folder; the
    market is the one with the same Excel, else a new one. The version's Excel hash is the PSD's
    own snapshot, so an Excel changed since the build reads as changed. Sets cfg's active game and
    market. Returns a note for the user, or "" when the PSD was already listed."""
    from . import psd_memory

    mem = mem if mem is not None else psd_memory.read(psd_path)
    psd_path = os.path.abspath(psd_path)
    ident = (mem or {}).get("identity") or {}
    snap = (mem or {}).get("excel") or {}
    excel = snap.get("path") if snap.get("path") and os.path.isfile(snap["path"]) else (cfg.get("excel_path") or "")
    game = get(ident.get("game_id") or "") if ident.get("game_id") else None
    if game is None and ident.get("game_folder") and os.path.isdir(ident["game_folder"]):
        game = find_by_folder(ident["game_folder"])
    if game is None:
        game = find_by_folder(os.path.dirname(psd_path))
    made_game = game is None
    if made_game:
        folder = ident.get("game_folder") if os.path.isdir(ident.get("game_folder") or "") else os.path.dirname(psd_path)
        game = create(folder, name=ident.get("game_name") or "", base_config=cfg, markets=[])
    else:
        _register(game["_file"])                      # (a game on the depot that this PC hadn't listed)
    market = find_market(game, ident.get("market_id")) if ident.get("market_id") else None
    if market is None and excel:
        want = os.path.normcase(os.path.abspath(excel))
        market = next((m for m in game.get("markets") or []
                       if os.path.normcase(os.path.abspath(m.get("excel_path") or "")) == want), None)
    made_market = market is None
    if made_market:
        market = add_market(game, excel, ident.get("market_name") or "", save_now=False,
                            output_dir=os.path.dirname(psd_path))
        market["settings"]["output_name"] = _strip_version(os.path.splitext(os.path.basename(psd_path))[0])
    cfg["active_game"], cfg["active_market"] = game["id"], market["id"]
    versions = market.setdefault("versions", [])
    if any(os.path.normcase(v.get("psd_path") or "") == os.path.normcase(psd_path) for v in versions):
        save(game)
        return ""
    entry = {
        "n": (versions[-1]["n"] + 1) if versions else 1,
        "date": _now(),
        "excel_path": excel,
        # the Excel as the PSD was built from it (no snapshot: the file now, so nothing reads as changed)
        "excel_sha256": snap.get("sha256") or (_pp.file_sha256(excel) if excel and os.path.isfile(excel) else ""),
        "psd_path": psd_path,
        "baseline": _pp.baseline_path_for_psd(psd_path) or "",
        "note": "opened with Open a PSD",
    }
    try:
        st = os.stat(psd_path)
        entry["psd_size"], entry["psd_mtime"] = st.st_size, st.st_mtime
    except OSError:
        pass
    versions.append(entry)
    save(game)
    where = f"{game.get('name') or 'Game'} › {market.get('name') or ''}".strip()
    if made_game:
        return f"Added to Recent games as {where} (v{entry['n']})."
    if made_market:
        return f"Added to Recent games as a new market: {where} (v{entry['n']})."
    return f"Added to Recent games: {where} v{entry['n']}."


def changed_pages(market, max_col_limit=12):
    """Which pages changed since the market's last version: compares the current
    Excel with the per-sheet content hashes saved beside the last PSD (baseline).

    Returns {"changed": [...], "added": [...], "removed": [...], "known": bool}.
    """
    versions = market.get("versions") or []
    excel = market.get("excel_path") or ""
    out = {"changed": [], "added": [], "removed": [], "known": False}
    if not versions or not excel or not os.path.isfile(excel):
        return out
    psd = versions[-1].get("psd_path") or ""
    manifest, _err = _pp._load_json(_pp.baseline_manifest_path_for_psd(psd))
    if not isinstance(manifest, dict) or not manifest.get("pages"):
        from . import psd_memory                       # the PSD carries its own snapshot

        mem = psd_memory.read(psd) if psd and os.path.isfile(psd) else None
        sheets = ((mem or {}).get("excel") or {}).get("sheets") or {}
        manifest = {"pages": [{"sheet_name": k, "content_hash": v} for k, v in sheets.items()]}
        if not manifest["pages"]:
            return out
    before = {p.get("sheet_name"): p.get("content_hash") for p in manifest["pages"]}
    now = _pp._sheet_hashes(excel, max_col_limit)
    if not now:
        return out
    out["known"] = True
    out["changed"] = sorted(s for s in now if s in before and now[s] != before[s])
    out["added"] = sorted(s for s in now if s not in before)
    out["removed"] = sorted(s for s in before if s not in now)
    return out


# ── which game an Excel belongs to ───────────────────────────────────────────
# AGRs rarely name their game (they write <GAME NAME>), but each game has its own symbols
# and sheet names. Symbols every game has (royals, WILD…) and words every file name has
# (AGR, market codes) say nothing and are left out.
_GENERIC_TOKENS = {"A", "K", "Q", "J", "10", "9", "ACE", "KING", "QUEEN", "JACK", "TEN", "NINE",
                   "WILD", "SCATTER", "SCAT", "BONUS", "GAME NAME", "GAMENAME", "DYNAMIC TEXT"}
_GENERIC_WORDS = {"agr", "copy", "final", "new", "old", "the", "rules", "game", "games", "gamerules",
                  "paytable", "help", "screen", "xlsx", "xlsm", "rev", "version"}


def fingerprint(excel_path):
    """{tokens, sheets, words} of an Excel — what tells one game's AGRs from another's."""
    from openpyxl import load_workbook

    from .icon_mapping import scan_excel_icon_tokens

    try:
        tokens = {re.sub(r"\s+", " ", str(t).strip("<> ").upper()) for t in scan_excel_icon_tokens(excel_path)}
    except Exception:
        tokens = set()
    try:
        wb = load_workbook(excel_path, read_only=True)
        sheets = {re.sub(r"[^a-z]", "", s.casefold()) for s in wb.sheetnames}
        wb.close()
    except Exception:
        sheets = set()
    stem = os.path.splitext(os.path.basename(excel_path))[0]
    words = {w for w in re.split(r"[^a-z]+", re.sub(r"([a-z])([A-Z])", r"\1 \2", stem).casefold())
             if len(w) > 2 and w not in _GENERIC_WORDS and not market_keyword(w)}
    return {"tokens": sorted(tokens - _GENERIC_TOKENS), "sheets": sorted(s for s in sheets if s),
            "words": sorted(words)}


def _jaccard(a, b):
    a, b = set(a or []), set(b or [])
    return len(a & b) / len(a | b) if (a | b) else 0.0


def same_game(fp_a, fp_b):
    """(belongs, score): the same game shares most of its symbols, or its name in the file names.
    Measured on real AGRs: markets / revisions of one game share 57–100 % of their symbols,
    different games 15 % at most."""
    tok = _jaccard(fp_a.get("tokens"), fp_b.get("tokens"))
    sh = _jaccard(fp_a.get("sheets"), fp_b.get("sheets"))
    named = bool(set(fp_a.get("words") or []) & set(fp_b.get("words") or []))
    score = max(tok, 0.5 * tok + 0.5 * sh)
    return (tok >= 0.5 or named or (tok >= 0.3 and sh >= 0.3)), round(score, 2)


def _merge(fp, more):
    return {k: sorted(set(fp.get(k) or []) | set(more.get(k) or [])) for k in ("tokens", "sheets", "words")}


def game_fingerprint(game, save_now=True):
    """The game's own fingerprint: every Excel it has accepted (made once, kept in the game)."""
    fp = game.get("fingerprint")
    if isinstance(fp, dict) and (fp.get("tokens") or fp.get("sheets")):
        return fp
    fp = {"tokens": [], "sheets": [], "words": []}
    seen = set()
    for m in game.get("markets") or []:
        for path in [m.get("excel_path")] + [v.get("excel_path") for v in m.get("versions") or []]:
            key = os.path.normcase(os.path.abspath(path)) if path else ""
            if key and key not in seen and os.path.isfile(path):
                seen.add(key)
                fp = _merge(fp, fingerprint(path))
    fp["words"] = sorted(set(fp["words"]) | {w for w in re.split(r"[^a-z]+", str(game.get("name") or "").casefold())
                                              if len(w) > 2 and w not in _GENERIC_WORDS})
    if fp["tokens"] or fp["sheets"]:
        game["fingerprint"] = fp
        if save_now and game.get("_file"):
            save(game)
    return fp


def belongs(game, excel_path):
    """Quick yes/no for the build checks (remembered per file version; writes nothing)."""
    try:
        key = (game.get("id"), os.path.normcase(os.path.abspath(excel_path)), os.path.getmtime(excel_path),
               repr(game.get("fingerprint")))
    except OSError:
        return True
    if key not in _BELONGS:
        mine = game_fingerprint(game, save_now=False)
        _BELONGS[key] = (not (mine.get("tokens") or mine.get("sheets"))) or same_game(fingerprint(excel_path), mine)[0]
    return _BELONGS[key]


_BELONGS = {}


def check_excel(game, excel_path):
    """Does `excel_path` belong to `game`? {same, score, game, other: [{id, name, score}]} —
    `other` lists registered games it does look like (to switch to)."""
    new = fingerprint(excel_path)
    mine = game_fingerprint(game)
    if not (mine.get("tokens") or mine.get("sheets")):
        return {"same": True, "score": 1.0, "game": game.get("name") or "", "other": [], "unknown": True}
    same, score = same_game(new, mine)
    other = []
    if not same:
        for path in _registry()["games"]:
            g = _read(path)
            if not g or g.get("id") == game.get("id"):
                continue
            ok, sc = same_game(new, game_fingerprint(g))
            if ok:
                other.append({"id": g["id"], "name": g.get("name") or "", "score": sc,
                              "market": _market_for_excel(g, excel_path)})
        other.sort(key=lambda o: -o["score"])
    return {"same": same, "score": score, "game": game.get("name") or "", "other": other[:3]}


def _market_for_excel(game, excel_path):
    """The market of `game` this Excel is for: same file, else the market keyword in its name."""
    want = os.path.normcase(os.path.abspath(excel_path))
    for m in game.get("markets") or []:
        if os.path.normcase(os.path.abspath(m.get("excel_path") or "")) == want:
            return m["id"]
    kw = market_keyword(os.path.basename(excel_path))
    for m in game.get("markets") or []:
        if kw and market_keyword(m.get("name") or "") == kw:
            return m["id"]
    return (game.get("markets") or [{}])[0].get("id", "")


def accept_excel(game, excel_path):
    """The user says this Excel IS this game (a revision that changed a lot): remember it."""
    game["fingerprint"] = _merge(game_fingerprint(game, save_now=False), fingerprint(excel_path))
    save(game)
    return game["fingerprint"]
