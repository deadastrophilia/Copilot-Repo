"""Reuse parsed Excel workbooks between renders.

openpyxl spends most of a page preview re-parsing the whole workbook (merged
cell styles dominate: ~0.85s per load on a 28-sheet game doc), and a preview
loads it twice. ``borrow()`` hands out one parsed workbook per file version
(path + size + mtime) to ONE caller at a time; a concurrent caller gets its
own fresh load, so no workbook object is ever used by two threads at once.
Editing the Excel file changes its mtime, which retires the cached copy.
"""
import contextlib
import os
import threading

from openpyxl import load_workbook

_LOCK = threading.Lock()
_CACHE = {}          # key -> {"wb": Workbook, "busy": bool}
_MAX = 2


def formula_results(wb, path):
    """`wb` (loaded with data_only=False, read_only=False — for the cells' colours, bold, rich text)
    with every formula cell's value replaced by the result Excel saved for it, its formatting kept.
    Loaded with its formulas, a cell like =IF(Checklist!$B$321="x",Checklist!E321,"") read as that text
    and was drawn on the page; its result ("" here: nothing) is what the sheet shows. Returns `wb`."""
    todo = {}
    for ws in getattr(wb, "worksheets", []):
        cells = {}
        for row in ws.iter_rows():
            for c in row:
                if c.data_type == "f":
                    cells[(c.row, c.column)] = c
        if cells:
            todo[ws.title] = cells
    if not todo:
        return wb
    try:
        values = load_workbook(path, data_only=True, read_only=True)
    except Exception:
        values = None
    try:
        for title, cells in todo.items():
            got = {}
            if values is not None and title in values.sheetnames:
                rows = [r for r, _c in cells]
                for row in values[title].iter_rows(min_row=min(rows), max_row=max(rows)):
                    for v in row:
                        if (getattr(v, "row", None), getattr(v, "column", None)) in cells:
                            got[(v.row, v.column)] = v.value
            for key, c in cells.items():
                c.value = got.get(key)          # no saved result (never calculated): nothing, not the formula
    finally:
        if values is not None:
            values.close()
    return wb


def load_formatted(path, **kw):
    """load_workbook(path, data_only=False) — the formatting — with formula cells holding their results
    (formula_results)."""
    return formula_results(load_workbook(path, data_only=False, read_only=False, **kw), path)


def _key(path, data_only, read_only):
    st = os.stat(path)
    return (os.path.normcase(os.path.abspath(path)), st.st_size, st.st_mtime_ns, bool(data_only), bool(read_only))


@contextlib.contextmanager
def borrow(path, data_only=False, read_only=False):
    """Yield a parsed workbook for `path`; callers must not modify it."""
    if read_only:                      # streaming workbooks hold a file handle: never share them
        wb = load_workbook(path, data_only=data_only, read_only=True)
        try:
            yield wb
        finally:
            wb.close()
        return
    key = _key(path, data_only, read_only)
    with _LOCK:
        entry = _CACHE.get(key)
        if entry is not None and not entry["busy"]:
            entry["busy"] = True
        else:
            entry = None
    if entry is None:
        wb = load_workbook(path, data_only=data_only, read_only=False)
        if not data_only:
            formula_results(wb, path)          # the formatted copy shows what the cells show, never a formula
        with _LOCK:
            if key not in _CACHE:
                for old in [k for k in _CACHE if k[0] == key[0]] + list(_CACHE)[:max(0, len(_CACHE) - _MAX + 1)]:
                    if old in _CACHE and not _CACHE[old]["busy"]:
                        _CACHE.pop(old, None)
                entry = _CACHE[key] = {"wb": wb, "busy": True}
            else:
                entry = {"wb": wb, "busy": True, "private": True}
    try:
        yield entry["wb"]
    finally:
        with _LOCK:
            entry["busy"] = False


def clear():
    with _LOCK:
        _CACHE.clear()
