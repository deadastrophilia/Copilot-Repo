"""Photoshop layer-effects descriptor -> readable ``captured_params``.

A captured style carries the byte-exact effects descriptor
(``captured_effects_hex``: the capture JSX writes 4 hex digits per byte, older
presets plain byte hex) and learned artist art carries the raw tagged block
(``effects_block``: {"key": "lfx2"|"lmfx", "hex": payload}). The PSD output
copies those bytes untouched; the previews need readable numbers, which this
module decodes with psd-tools into the ``captured_params`` shape
``ps_fx_png.normalize_params`` (and the browser twin in ps_fx_canvas.js) read.

Every effect kind may appear more than once (Photoshop's "multiple effects":
dropShadowMulti, frameFXMulti, ...). A kind that occurs once stays a dict (the
historical schema); repeated kinds become a list in Photoshop's dialog order
(index 0 = top-most, painted last). Disabled effects are dropped.

Lengths are the effect's own sizes, as Photoshop draws them: the descriptor's top-level "Scl " is
NOT applied. It records a resolution change (416.67 % = 300 / 72 dpi on every layer of a 300 dpi
artist PSD) — Photoshop draws a 5 px stroke stored there at 5 px (checked against the composite it
saved and against Photoshop 27.7 itself); multiplying made strokes, shadows and glows 4x too big.
"""
import functools
import hashlib
import io
import re

_HEX_RE = re.compile(r"[^0-9a-fA-F]")

# effect descriptor key -> captured_params key
_EFFECT_KEYS = {
    "DrSh": "drop_shadow", "dropShadowMulti": "drop_shadow",
    "IrSh": "inner_shadow", "innerShadowMulti": "inner_shadow",
    "OrGl": "outer_glow",
    "IrGl": "inner_glow",
    "ebbl": "bevel",
    "ChFX": "satin",
    "SoFi": "color_overlay", "solidFillMulti": "color_overlay",
    "GrFl": "gradient_overlay", "gradientFillMulti": "gradient_overlay",
    "patternFill": "pattern_overlay", "patternFillMulti": "pattern_overlay",
    "FrFX": "stroke", "frameFXMulti": "stroke",
}

_BLEND_NAMES = {
    "nrml": "normal", "norm": "normal", "dslv": "normal",
    "drkn": "darken", "mltp": "multiply", "cbrn": "color burn",
    "linearburn": "linear burn", "darkercolor": "darken",
    "lghn": "lighten", "scrn": "screen", "cddg": "color dodge",
    "lineardodge": "linear dodge", "lightercolor": "lighten",
    "ovrl": "overlay", "sftl": "soft light", "hrdl": "hard light",
    "vividlight": "vivid light", "linearlight": "linear light",
    "pinlight": "pin light", "hardmix": "hard mix",
    "dfrn": "difference", "xclu": "exclusion",
    "blendsubtraction": "subtract", "blenddivide": "divide",
    "h": "hue", "strt": "saturation", "clr": "color", "lmns": "luminosity",
    # the long stringIDs Photoshop stores in layerEffects descriptors ("overlay", "softLight"…):
    # without them every such effect was drawn Normal (an Overlay inner glow painted the text white)
    "normal": "normal", "dissolve": "normal", "darken": "darken", "multiply": "multiply",
    "colorburn": "color burn", "lighten": "lighten", "screen": "screen", "colordodge": "color dodge",
    "overlay": "overlay", "softlight": "soft light", "hardlight": "hard light",
    "difference": "difference", "exclusion": "exclusion", "subtract": "subtract", "divide": "divide",
    "hue": "hue", "saturation": "saturation", "color": "color", "luminosity": "luminosity",
}

_GRADIENT_TYPES = {
    "lnr": "linear", "linear": "linear", "rdl": "radial", "radial": "radial",
    "angl": "angle", "angle": "angle", "rflc": "reflected", "reflected": "reflected",
    "dmnd": "diamond", "diamond": "diamond", "shpb": "shape_burst",
    "shapeburst": "shape_burst",
}

_BEVEL_STYLES = {
    "otrb": "outer", "inrb": "inner", "embs": "emboss", "pleb": "pillow",
    "strokeemboss": "stroke",
}

_BEVEL_TECHNIQUES = {
    "sfbl": "smooth", "prbl": "chisel_hard", "slmt": "chisel_soft",
}


# --------------------------------------------------------------------------
# bytes / psd-tools objects -> plain python
# --------------------------------------------------------------------------


def descriptor_bytes(raw_hex):
    """Descriptor stream (starting with descriptor version 16) from capture hex.

    Accepts the capture JSX's 4-hex-digits-per-byte form, plain byte hex, and
    payloads that still carry the 4-byte object-effects version (lfx2/lmfx).
    Returns None for anything that is not an effects descriptor.
    """
    raw = _HEX_RE.sub("", str(raw_hex or ""))
    if len(raw) < 16:
        return None
    try:
        if len(raw) % 4 == 0 and all(raw[i:i + 2] == "00" for i in range(0, len(raw), 4)):
            data = bytes(int(raw[i:i + 4], 16) for i in range(0, len(raw), 4))
        else:
            data = bytes.fromhex(raw[: len(raw) // 2 * 2])
    except ValueError:
        return None
    if data[:8] == b"\x00\x00\x00\x00\x00\x00\x00\x10":
        data = data[4:]
    if data[:4] != b"\x00\x00\x00\x10" or len(data) <= 44:
        return None
    return data


def _key(k):
    if isinstance(k, bytes):
        k = k.decode("latin-1")
    return str(k).rstrip("\x00")


def _enum_text(value):
    raw = getattr(value, "enum", value)
    if isinstance(raw, bytes):
        raw = raw.decode("latin-1")
    return str(raw).strip()


def plain(value):
    """psd-tools descriptor tree -> dicts / lists / floats / bools / strings."""
    from psd_tools.psd.descriptor import Enumerated

    if isinstance(value, Enumerated):
        return {"$enum": _enum_text(value)}
    if hasattr(value, "items") and callable(value.items):
        return {_key(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)) or (
            hasattr(value, "__iter__") and hasattr(value, "__len__")
            and not isinstance(value, (str, bytes, bytearray)) and not hasattr(value, "value")):
        return [plain(v) for v in value]
    if isinstance(value, bool):
        return value
    inner = getattr(value, "value", value)
    if isinstance(inner, bool):
        return inner
    if isinstance(inner, (int, float)):
        return float(inner)
    if isinstance(inner, bytes):
        return inner.decode("latin-1").rstrip("\x00")
    if isinstance(inner, str):
        return inner.rstrip("\x00")
    try:
        return float(value)
    except (TypeError, ValueError):
        return str(inner)


def read_descriptor(data):
    """Plain dict of an effects descriptor stream (see descriptor_bytes)."""
    from psd_tools.psd.descriptor import DescriptorBlock

    return plain(DescriptorBlock.read(io.BytesIO(data)))


# --------------------------------------------------------------------------
# plain descriptor -> captured_params
# --------------------------------------------------------------------------


def _num(d, key, fallback):
    try:
        v = d.get(key, fallback)
        if isinstance(v, dict):
            return float(fallback)
        return float(v)
    except (TypeError, ValueError):
        return float(fallback)


def _bool(d, key, fallback=False):
    v = d.get(key, fallback)
    return bool(v) if isinstance(v, (bool, int, float)) else fallback


def _enum(d, key):
    v = d.get(key)
    return v.get("$enum", "") if isinstance(v, dict) else ""


def _color(node, fallback):
    if not isinstance(node, dict):
        return list(fallback)
    try:
        r = node.get("Rd  ", node.get("Rd", node.get("red")))
        g = node.get("Grn ", node.get("Grn", node.get("green")))
        b = node.get("Bl  ", node.get("Bl", node.get("blue")))
        return [int(max(0, min(255, round(float(c))))) for c in (r, g, b)]
    except (TypeError, ValueError):
        return list(fallback)


def _blend(d, key="Md  "):
    raw = _enum(d, key).replace(" ", "").casefold()
    return _BLEND_NAMES.get(raw, "normal")


def _contour(d, key="TrnS"):
    """Transfer curve [[in, out], ...] 0..255, or None for the linear default."""
    node = d.get(key)
    if not isinstance(node, dict):
        return None
    pts = []
    for p in node.get("Crv ", node.get("Crv", [])) or []:
        if isinstance(p, dict):
            try:
                pts.append([float(p.get("Hrzn", 0)), float(p.get("Vrtc", 0))])
            except (TypeError, ValueError):
                continue
    pts.sort(key=lambda q: q[0])
    if len(pts) < 2 or (len(pts) == 2 and pts[0] == [0.0, 0.0] and pts[1] == [255.0, 255.0]):
        return None
    return pts


def _gradient(node):
    """{"colors": [[rgb, loc%, mid%]], "transparency": [[opacity%, loc%, mid%]], "smoothness"}."""
    if not isinstance(node, dict):
        return None
    colors = []
    for stop in node.get("Clrs", []) or []:
        if not isinstance(stop, dict):
            continue
        rgb = _color(stop.get("Clr "), [255, 255, 255])
        if _enum(stop, "Type") in ("FrgC", "BckC") and not isinstance(stop.get("Clr "), dict):
            rgb = [0, 0, 0] if _enum(stop, "Type") == "FrgC" else [255, 255, 255]
        colors.append([rgb, _clamp(_num(stop, "Lctn", 0) / 40.96, 0, 100), _clamp(_num(stop, "Mdpn", 50), 0, 100)])
    trans = []
    for stop in node.get("Trns", []) or []:
        if isinstance(stop, dict):
            trans.append([_clamp(_num(stop, "Opct", 100), 0, 100), _clamp(_num(stop, "Lctn", 0) / 40.96, 0, 100),
                          _clamp(_num(stop, "Mdpn", 50), 0, 100)])
    if not colors:
        return None
    return {
        "colors": colors,
        "transparency": trans or None,
        "smoothness": _clamp(_num(node, "Intr", 4096) / 40.96, 0, 100),
        "name": str(node.get("Nm  ", "") or ""),
    }


def _clamp(v, lo, hi):
    return max(lo, min(hi, v))


def _gradient_fields(d, scale):
    grad = _gradient(d.get("Grad"))
    if grad is None:
        return None
    off = d.get("Ofst") if isinstance(d.get("Ofst"), dict) else {}
    return {
        "colors": grad["colors"],
        "transparency": grad["transparency"],
        "smoothness": grad["smoothness"],
        "type": _GRADIENT_TYPES.get(_enum(d, "Type").replace(" ", "").casefold(), "linear"),
        "angle": _num(d, "Angl", 90),
        "scale": _num(d, "Scl ", 100),
        "reverse": _bool(d, "Rvrs"),
        "align": _bool(d, "Algn", True),
        "offset": [_num(off, "Hrzn", 0), _num(off, "Vrtc", 0)],
    }


def _shadow(d, s):
    return {
        "enabled": True,
        "color": _color(d.get("Clr "), [0, 0, 0]),
        "opacity": _num(d, "Opct", 75),
        "angle": _num(d, "lagl", 120),
        "use_global_light": _bool(d, "uglg"),
        "distance": _num(d, "Dstn", 5) * s,
        "size": _num(d, "blur", 5) * s,
        "spread": _num(d, "Ckmt", 0),
        "blend": _blend(d),
        "contour": _contour(d),
        "knockout": _bool(d, "layerConceals", True),
    }


def _glow(d, s, inner):
    out = {
        "enabled": True,
        "color": _color(d.get("Clr "), [255, 255, 190] if not inner else [255, 255, 255]),
        "opacity": _num(d, "Opct", 75),
        "size": _num(d, "blur", 5) * s,
        "spread": _num(d, "Ckmt", 0),
        "blend": _blend(d),
        "technique": "precise" if _enum(d, "GlwT") == "PrBL" else "softer",
        "range": _num(d, "Inpr", 50),
        "contour": _contour(d),
    }
    grad = _gradient(d.get("Grad"))
    if grad is not None and not isinstance(d.get("Clr "), dict):
        out["gradient"] = grad
    if inner:
        out["source"] = "center" if _enum(d, "glwS") == "SrcC" else "edge"
    return out


def _stroke(d, s):
    pos = _enum(d, "Styl")
    paint = _enum(d, "PntT")
    out = {
        "enabled": True,
        "color": _color(d.get("Clr "), [0, 0, 0]),
        "opacity": _num(d, "Opct", 100),
        "size": _num(d, "Sz  ", 3) * s,
        "position": {"InsF": "inside", "CtrF": "center"}.get(pos, "outside"),
        "blend": _blend(d),
        "fill_type": {"GrFl": "gradient", "Ptrn": "pattern"}.get(paint, "color"),
    }
    if out["fill_type"] == "gradient":
        grad = _gradient_fields(d, s)
        if grad is None:
            out["fill_type"] = "color"
        else:
            out["gradient"] = grad
    return out


def _color_overlay(d, s):
    return {
        "enabled": True,
        "color": _color(d.get("Clr "), [255, 0, 0]),
        "opacity": _num(d, "Opct", 100),
        "blend": _blend(d),
    }


def _gradient_overlay(d, s):
    out = {"enabled": True, "opacity": _num(d, "Opct", 100), "blend": _blend(d)}
    grad = _gradient_fields(d, s)
    if grad is None:
        return None
    out.update(grad)
    return out


def _bevel(d, s):
    return {
        "enabled": True,
        "style": _BEVEL_STYLES.get(_enum(d, "bvlS").replace(" ", "").casefold(), "inner"),
        "technique": _BEVEL_TECHNIQUES.get(_enum(d, "bvlT").replace(" ", "").casefold(), "smooth"),
        "depth": _num(d, "srgR", 100),
        "direction": "down" if _enum(d, "bvlD").strip() == "Out" else "up",
        "size": _num(d, "blur", 5) * s,
        "soften": _num(d, "Sftn", 0) * s,
        "angle": _num(d, "lagl", 120),
        "altitude": _num(d, "Lald", 30),
        "use_global_light": _bool(d, "uglg"),
        "highlight_color": _color(d.get("hglC"), [255, 255, 255]),
        "highlight_opacity": _num(d, "hglO", 75),
        "highlight_blend": _blend(d, "hglM"),
        "shadow_color": _color(d.get("sdwC"), [0, 0, 0]),
        "shadow_opacity": _num(d, "sdwO", 75),
        "shadow_blend": _blend(d, "sdwM"),
        "gloss_contour": _contour(d, "TrnS"),
    }


def _satin(d, s):
    return {
        "enabled": True,
        "color": _color(d.get("Clr "), [0, 0, 0]),
        "opacity": _num(d, "Opct", 50),
        "blend": _blend(d),
        "angle": _num(d, "lagl", 19),
        "distance": _num(d, "Dstn", 11) * s,
        "size": _num(d, "blur", 14) * s,
        "invert": _bool(d, "Invr", True),
        "contour": _contour(d, "MpgS"),
    }


def _pattern(d, s):
    return {"enabled": True, "opacity": _num(d, "Opct", 100), "blend": _blend(d),
            "scale": _num(d, "Scl ", 100)}


_BUILDERS = {
    "drop_shadow": _shadow, "inner_shadow": _shadow,
    "outer_glow": lambda d, s: _glow(d, s, False),
    "inner_glow": lambda d, s: _glow(d, s, True),
    "stroke": _stroke, "color_overlay": _color_overlay,
    "gradient_overlay": _gradient_overlay, "bevel": _bevel, "satin": _satin,
    "pattern_overlay": _pattern,
}


def params_from_descriptor(desc, base=None):
    """Plain effects descriptor -> captured_params (see module docstring)."""
    params = {"opacity": 100, "fill_opacity": 100, "is_fill_enabled": True}
    if isinstance(base, dict):
        for key in ("opacity", "fill_opacity", "is_fill_enabled"):
            if key in base:
                params[key] = base[key]
    params["source"] = "descriptor"
    if not isinstance(desc, dict):
        return params
    if desc.get("masterFXSwitch") is False:
        return params
    scale = 1.0                                    # "Scl " is not applied (see the module docstring)
    found = {}
    for key, value in desc.items():
        target = _EFFECT_KEYS.get(key)
        if target is None:
            continue
        items = value if isinstance(value, list) else [value]
        for item in items:
            if not isinstance(item, dict) or not item.get("enab", True):
                continue
            if item.get("present") is False and not item.get("enab"):
                continue
            eff = _BUILDERS[target](item, scale)
            if eff:
                found.setdefault(target, []).append(eff)
    for target, effects in found.items():
        params[target] = effects[0] if len(effects) == 1 else effects
    return params


@functools.lru_cache(maxsize=256)
def _decode_cached(data):
    return params_from_descriptor(read_descriptor(data))


def decode_effects_hex(raw_hex, base=None):
    """captured_params decoded from a captured_effects_hex / effects block hex, or None."""
    data = descriptor_bytes(raw_hex)
    if data is None:
        return None
    try:
        params = _decode_cached(data)
    except Exception as exc:  # a damaged capture must never break a preview
        print(f"[fx_descriptor] could not decode effects descriptor: {exc}")
        return None
    params = _deep_copy(params)
    if isinstance(base, dict):
        for key in ("opacity", "fill_opacity", "is_fill_enabled"):
            if key in base:
                params[key] = base[key]
    return params


def _deep_copy(value):
    if isinstance(value, dict):
        return {k: _deep_copy(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_deep_copy(v) for v in value]
    return value


def effective_params(fx_config):
    """The captured_params a preview should render for a style config.

    The byte-exact descriptor (captured_effects_hex or an artist effects_block)
    wins over the lossy JSX-readable captured_params; layer opacity / fill
    opacity come from captured_params when present. Returns None when the
    style has neither (legacy flat stroke_enabled / shadow_enabled styles are
    read by ps_fx_png.normalize_params directly).
    """
    if not isinstance(fx_config, dict):
        return None
    base = fx_config.get("captured_params") if isinstance(fx_config.get("captured_params"), dict) else None
    block = fx_config.get("effects_block")
    hexes = []
    if isinstance(block, dict) and block.get("hex"):
        hexes.append(block["hex"])
    if fx_config.get("captured_effects_hex"):
        hexes.append(fx_config["captured_effects_hex"])
    for raw in hexes:
        decoded = decode_effects_hex(raw, base)
        if decoded is not None:
            return decoded
    return base


def enrich_style(fx_config):
    """Copy of a style config whose captured_params is the full decoded set.

    Used where style configs leave the server for the live canvas, so the
    browser renderer sees every effect (multiple strokes, bevel, ...) without
    parsing descriptors itself. Configs without a descriptor come back as is.
    """
    if not isinstance(fx_config, dict):
        return fx_config
    if not (fx_config.get("captured_effects_hex") or isinstance(fx_config.get("effects_block"), dict)):
        return fx_config
    params = effective_params(fx_config)
    if not isinstance(params, dict) or params.get("source") != "descriptor":
        return fx_config
    out = dict(fx_config)
    out["captured_params"] = params
    return out


def style_fingerprint(fx_config):
    """Short stable hash of a style config (cache keys)."""
    import json

    try:
        raw = json.dumps(fx_config or {}, sort_keys=True, default=str)
    except Exception:
        raw = str(fx_config)
    return hashlib.sha1(raw.encode("utf-8", "replace")).hexdigest()[:16]
