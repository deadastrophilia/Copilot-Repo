"""PageLayout — canonical page layout model (single source of truth).

Phase 1 of the canonical layout pipeline. Every renderer (live preview, PNG,
Photoshop) consumes the SAME PageLayout object so positions, wrapped lines,
spacing, alignment and style parameters are guaranteed identical.

Design rules:
  * Plain-JSON serialization — no mapper, preset, session or template format
    is touched.
  * No import of the renderers — this module stays renderer-agnostic so it
    can be used by preview, PNG and Photoshop code without cycles.
  * Positions are FINAL layout values in page pixels (top-left origin).
    Renderers do not recalculate wrapping, icon placement or geometry; they
    only draw what this model contains.
"""

from __future__ import annotations

import json
import os

from typing import Any, Dict, List, Optional

PAGE_LAYOUT_VERSION = 1


class PageLayoutError(ValueError):
    """Raised for invalid PageLayout data."""


def _clean_num(value, fallback: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return float(fallback)


def _clean_int(value, fallback: int = 0) -> int:
    try:
        return int(float(value))
    except Exception:
        return int(fallback)


def _normalize_color(value, fallback=(255, 255, 255)):
    try:
        vals = list(value)
        if len(vals) >= 3:
            return [max(0, min(255, int(v))) for v in vals[:3]]
    except Exception:
        pass
    if isinstance(value, str):
        try:
            raw = value.lstrip("#")
            if len(raw) >= 6:
                return [int(raw[0:2], 16), int(raw[2:4], 16), int(raw[4:6], 16)]
        except Exception:
            pass
    return list(fallback)


def _clean_text(value) -> str:
    if value is None:
        return ""
    return str(value)


class Element:
    """Base layout element. `type` values: "text" | "rect" | "image" | "table".

    x/y = top-left corner in page pixels; width/height = final rendered box.
    rotation is degrees (0 = none); opacity 0..1.
    effects holds RESOLVED style parameters (e.g. a captured layer-style FX
    dict or the name of a saved layer style) — PNG applies them via
    ps_fx_png, Photoshop applies them via layer_styles.py.
    """

    _TYPE = "element"

    def __init__(
        self,
        element_id: str = "",
        x: float = 0.0,
        y: float = 0.0,
        width: float = 0.0,
        height: float = 0.0,
        rotation: float = 0.0,
        opacity: float = 1.0,
        effects: Optional[dict] = None,
        style_role: str = "",
        meta: Optional[dict] = None,
    ):
        self.id = _clean_text(element_id)
        self.type = self._TYPE
        self.x = _clean_num(x)
        self.y = _clean_num(y)
        self.width = _clean_num(width)
        self.height = _clean_num(height)
        self.rotation = _clean_num(rotation)
        self.opacity = max(0.0, min(1.0, _clean_num(opacity, 1.0)))
        self.effects = dict(effects or {})
        self.style_role = _clean_text(style_role)
        self.meta = dict(meta or {})

    # ------------------------------------------------------------------
    def to_dict(self) -> dict:
        data = {
            "id": self.id,
            "type": self.type,
            "x": self.x,
            "y": self.y,
            "width": self.width,
            "height": self.height,
            "rotation": self.rotation,
            "opacity": self.opacity,
            "effects": self.effects,
            "style_role": self.style_role,
            "meta": self.meta,
        }
        return data

    @classmethod
    def from_dict(cls, data: dict) -> "Element":
        return cls(
            element_id=_clean_text(data.get("id")),
            x=_clean_num(data.get("x")),
            y=_clean_num(data.get("y")),
            width=_clean_num(data.get("width")),
            height=_clean_num(data.get("height")),
            rotation=_clean_num(data.get("rotation")),
            opacity=_clean_num(data.get("opacity"), 1.0),
            effects=data.get("effects") or {},
            style_role=_clean_text(data.get("style_role")),
            meta=data.get("meta") or {},
        )

    def __repr__(self):
        return f"{self.__class__.__name__}(id={self.id!r}, x={self.x}, y={self.y}, w={self.width}, h={self.height})"


class TextElement(Element):
    """Pre-wrapped text block.

    wrapped_lines holds the FINAL lines (no renderer may re-wrap them);
    line_heights holds the per-line pixel height used for line top offsets.
    Icon tokens ('<token>') inside wrapped_lines are expanded by the
    renderers exactly as today; icon_height controls their size.
    """

    _TYPE = "text"

    def __init__(
        self,
        element_id: str = "",
        x: float = 0.0,
        y: float = 0.0,
        width: float = 0.0,
        height: float = 0.0,
        text: str = "",
        font: str = "",
        size: float = 24.0,
        bold: bool = False,
        italic: bool = False,
        color: Optional[list] = None,
        align: str = "center",
        line_height: float = 0.0,
        line_spacing: float = 0.0,
        paragraph_gap: float = 0.0,
        icon_height: float = 0.0,
        icon_gap_left: float = 0.0,
        icon_gap_right: float = 0.0,
        wrapped_lines: Optional[List[str]] = None,
        line_heights: Optional[List[float]] = None,
        line_widths: Optional[List[float]] = None,
        line_runs: Optional[List[List[dict]]] = None,
        tokens: Optional[List[str]] = None,
        rotation: float = 0.0,
        opacity: float = 1.0,
        effects: Optional[dict] = None,
        style_role: str = "",
        meta: Optional[dict] = None,
    ):
        super().__init__(
            element_id=element_id, x=x, y=y, width=width, height=height,
            rotation=rotation, opacity=opacity, effects=effects,
            style_role=style_role, meta=meta,
        )
        self.text = _clean_text(text)
        self.font = _clean_text(font)
        self.size = _clean_num(size, 24.0)
        self.bold = bool(bold)
        self.italic = bool(italic)
        self.color = _normalize_color(color, (255, 255, 255))
        self.align = _clean_text(align).lower() or "center"
        if self.align not in ("left", "center", "right", "justify", "justify_all"):   # justify_all: a stretched line
            self.align = "center"
        self.line_height = _clean_num(line_height)
        self.line_spacing = _clean_num(line_spacing)
        self.paragraph_gap = _clean_num(paragraph_gap)
        self.icon_height = _clean_num(icon_height)
        self.icon_gap_left = _clean_num(icon_gap_left)
        self.icon_gap_right = _clean_num(icon_gap_right)
        self.wrapped_lines = [str(line) for line in (wrapped_lines or [])]
        self.line_heights = [_clean_num(h) for h in (line_heights or [])]
        self.line_widths = [_clean_num(w) for w in (line_widths or [])]
        self.line_runs = []
        for raw_line in (line_runs or []):
            runs = []
            for raw_run in raw_line or []:
                run = {"kind": _clean_text(raw_run.get("kind"))}
                if run["kind"] == "icon":
                    run["token"] = _clean_text(raw_run.get("token"))
                    run["x"] = _clean_num(raw_run.get("x"))
                    run["y"] = _clean_num(raw_run.get("y"))
                    run["w"] = _clean_num(raw_run.get("w"))
                    run["h"] = _clean_num(raw_run.get("h"))
                else:
                    run["text"] = _clean_text(raw_run.get("text"))
                    run["x"] = _clean_num(raw_run.get("x"))
                    run["w"] = _clean_num(raw_run.get("w"))
                    st = raw_run.get("style")
                    if isinstance(st, dict):          # word-style run (text_styles rule)
                        rgb = st.get("rgb")
                        run["style"] = {"rgb": [int(c) for c in rgb[:3]] if rgb else None,
                                        "bold": bool(st.get("bold")), "italic": bool(st.get("italic")),
                                        "font": _clean_text(st.get("font")),
                                        "size": float(st["size"]) if st.get("size") else None,
                                        "fx": st.get("fx") if isinstance(st.get("fx"), dict) else None,
                                        "tracking": float(st["tracking"]) if st.get("tracking") is not None else None,
                                        "bg": st.get("bg") if isinstance(st.get("bg"), dict) else None}
                runs.append(run)
            self.line_runs.append(runs)
        self.tokens = [str(t) for t in (tokens or [])]

    def to_dict(self) -> dict:
        data = super().to_dict()
        data.update(
            {
                "text": self.text,
                "font": self.font,
                "size": self.size,
                "bold": self.bold,
                "italic": self.italic,
                "color": self.color,
                "align": self.align,
                "line_height": self.line_height,
                "line_spacing": self.line_spacing,
                "paragraph_gap": self.paragraph_gap,
                "icon_height": self.icon_height,
                "icon_gap_left": self.icon_gap_left,
                "icon_gap_right": self.icon_gap_right,
                "wrapped_lines": list(self.wrapped_lines),
                "line_heights": list(self.line_heights),
                "line_widths": list(self.line_widths),
                "line_runs": list(self.line_runs),
                "tokens": list(self.tokens),
            }
        )
        return data

    @classmethod
    def from_dict(cls, data: dict) -> "TextElement":
        return cls(
            element_id=_clean_text(data.get("id")),
            x=_clean_num(data.get("x")),
            y=_clean_num(data.get("y")),
            width=_clean_num(data.get("width")),
            height=_clean_num(data.get("height")),
            text=_clean_text(data.get("text")),
            font=_clean_text(data.get("font")),
            size=_clean_num(data.get("size"), 24.0),
            bold=bool(data.get("bold")),
            italic=bool(data.get("italic")),
            color=data.get("color") or (255, 255, 255),
            align=_clean_text(data.get("align")),
            line_height=_clean_num(data.get("line_height")),
            line_spacing=_clean_num(data.get("line_spacing")),
            paragraph_gap=_clean_num(data.get("paragraph_gap")),
            icon_height=_clean_num(data.get("icon_height")),
            icon_gap_left=_clean_num(data.get("icon_gap_left")),
            icon_gap_right=_clean_num(data.get("icon_gap_right")),
            wrapped_lines=data.get("wrapped_lines") or [],
            line_heights=data.get("line_heights") or [],
            line_widths=data.get("line_widths") or [],
            line_runs=data.get("line_runs") or [],
            tokens=data.get("tokens") or [],
            rotation=_clean_num(data.get("rotation")),
            opacity=_clean_num(data.get("opacity"), 1.0),
            effects=data.get("effects") or {},
            style_role=_clean_text(data.get("style_role")),
            meta=data.get("meta") or {},
        )


class RectElement(Element):
    """Filled/stroked rectangle (e.g. text-background boxes)."""

    _TYPE = "rect"

    def __init__(
        self,
        element_id: str = "",
        x: float = 0.0,
        y: float = 0.0,
        width: float = 0.0,
        height: float = 0.0,
        fill_rgb=(20, 20, 30),
        fill_opacity: float = 1.0,
        stroke_rgb=(255, 255, 255),
        stroke_width: float = 0.0,
        rotation: float = 0.0,
        opacity: float = 1.0,
        effects: Optional[dict] = None,
        style_role: str = "",
        meta: Optional[dict] = None,
    ):
        super().__init__(
            element_id=element_id, x=x, y=y, width=width, height=height,
            rotation=rotation, opacity=opacity, effects=effects,
            style_role=style_role, meta=meta,
        )
        self.fill_rgb = _normalize_color(fill_rgb, (20, 20, 30))
        self.fill_opacity = max(0.0, min(1.0, _clean_num(fill_opacity, 1.0)))
        self.stroke_rgb = _normalize_color(stroke_rgb, (255, 255, 255))
        self.stroke_width = _clean_num(stroke_width)

    def to_dict(self) -> dict:
        data = super().to_dict()
        data.update(
            {
                "fill_rgb": list(self.fill_rgb),
                "fill_opacity": self.fill_opacity,
                "stroke_rgb": list(self.stroke_rgb),
                "stroke_width": self.stroke_width,
            }
        )
        return data

    @classmethod
    def from_dict(cls, data: dict) -> "RectElement":
        return cls(
            element_id=_clean_text(data.get("id")),
            x=_clean_num(data.get("x")),
            y=_clean_num(data.get("y")),
            width=_clean_num(data.get("width")),
            height=_clean_num(data.get("height")),
            fill_rgb=data.get("fill_rgb") or (20, 20, 30),
            fill_opacity=_clean_num(data.get("fill_opacity"), 1.0),
            stroke_rgb=data.get("stroke_rgb") or (255, 255, 255),
            stroke_width=_clean_num(data.get("stroke_width")),
            rotation=_clean_num(data.get("rotation")),
            opacity=_clean_num(data.get("opacity"), 1.0),
            effects=data.get("effects") or {},
            style_role=_clean_text(data.get("style_role")),
            meta=data.get("meta") or {},
        )


class TableElement(Element):
    """A table — or one part of a table cut across pages — at its place in the page's flow.

    The layout only places it; png_builder._draw_auto_table draws it (the PNG / PSD builds, through
    canonical_png's table drawer). meta: which table ("table": its index on the sheet), the rows of a
    part ("slice": [a, b]), the artist's move ("dx", "dy"), its alignment and height cap, and what
    the Canvas needs (its id "jsid", geo, cut info). `image` (not saved) is its picture as the layout
    measured it — the Canvas shows that."""

    _TYPE = "table"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.image = None


class ImageElement(Element):
    """A picture drawn as it is (meta.url): a Game / Bingo Rules page's separator, strips and XTRAA
    REELS icons, made by its own renderer (rules_layout.py)."""

    _TYPE = "image"


_ELEMENT_FACTORIES = {
    "text": TextElement,
    "rect": RectElement,
    "table": TableElement,
    "image": ImageElement,
}


def element_from_dict(data: dict) -> Element:
    factory = _ELEMENT_FACTORIES.get(_clean_text(data.get("type")))
    if factory is None:
        return Element.from_dict(data)
    return factory.from_dict(data)


class PageLayout:
    """One rendered page. A build produces one PageLayout per page.

    source       : {"excel_path", "sheet_name", "page_index", "layout_mode"}
    canvas       : {"width", "height"}
    safe_area    : {"left", "top", "width", "height", "bottom"}
    margins      : resolved margin/spacing values used at layout time
    elements     : final elements in draw order
    """

    def __init__(
        self,
        source: Optional[dict] = None,
        canvas: Optional[dict] = None,
        safe_area: Optional[dict] = None,
        margins: Optional[dict] = None,
        elements: Optional[List[Element]] = None,
        version: int = PAGE_LAYOUT_VERSION,
    ):
        self.version = int(version or PAGE_LAYOUT_VERSION)
        self.source = dict(source or {})
        self.canvas = dict(canvas or {"width": 0, "height": 0})
        self.safe_area = dict(
            safe_area or {"left": 0, "top": 0, "width": 0, "height": 0, "bottom": 0}
        )
        self.margins = dict(margins or {})
        self.elements = list(elements or [])

    # ------------------------------------------------------------------
    def add(self, element: Element) -> Element:
        self.elements.append(element)
        return element

    def find(self, element_id: str) -> Optional[Element]:
        for element in self.elements:
            if element.id == element_id:
                return element
        return None

    # ------------------------------------------------------------------
    def to_dict(self) -> dict:
        return {
            "version": self.version,
            "source": dict(self.source),
            "canvas": dict(self.canvas),
            "safe_area": dict(self.safe_area),
            "margins": dict(self.margins),
            "elements": [element.to_dict() for element in self.elements],
        }

    @classmethod
    def from_dict(cls, data: dict) -> "PageLayout":
        if not isinstance(data, dict):
            raise PageLayoutError("PageLayout data must be a dict")
        elements = []
        for raw in data.get("elements") or []:
            try:
                elements.append(element_from_dict(raw))
            except Exception:
                continue
        return cls(
            source=data.get("source") or {},
            canvas=data.get("canvas") or {},
            safe_area=data.get("safe_area") or {},
            margins=data.get("margins") or {},
            elements=elements,
            version=data.get("version", PAGE_LAYOUT_VERSION),
        )

    # ------------------------------------------------------------------
    def to_json(self, indent: Optional[int] = None) -> str:
        return json.dumps(self.to_dict(), indent=indent)

    def save(self, path: str) -> None:
        with open(path, "w", encoding="utf-8") as handle:
            handle.write(self.to_json(indent=2))

    @classmethod
    def load(cls, path: str) -> "PageLayout":
        if not os.path.isfile(path):
            raise PageLayoutError(f"PageLayout file not found: {path}")
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        return cls.from_dict(data)


def layouts_to_json(layouts: List[PageLayout], indent: Optional[int] = None) -> str:
    return json.dumps([layout.to_dict() for layout in layouts], indent=indent)


def layouts_from_json(raw: Any) -> List[PageLayout]:
    try:
        if isinstance(raw, str):
            data = json.loads(raw)
        else:
            data = raw
    except Exception as exc:
        raise PageLayoutError(f"Invalid PageLayout JSON: {exc}") from exc
    layouts = []
    for item in data or []:
        layouts.append(PageLayout.from_dict(item))
    return layouts