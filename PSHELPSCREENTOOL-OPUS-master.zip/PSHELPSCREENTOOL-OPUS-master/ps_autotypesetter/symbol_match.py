"""Symbols from a PSD and the AGR it was made from — each picture named, matched to this game's symbols.

The game's symbols step: "Select a symbol PSD" plus, optionally, the AGR that PSD was made from. With
that AGR the tool reads the PSD the way Clone a Market does (market_clone.plan / Symbols): a picture
in a text row where the AGR says <SCAT>, the n-th picture over the n-th icon gap, the picture on a pay
card whose numbers are <KING>'s, a layer named like the token. Each picture of the PSD's symbol scan
(symbol_scan: one entry per distinct picture) gets the AGR token(s) the evidence gave it; the AGR
tokens are then matched to this game's AGR tokens. Without the AGR only layer names can say.

The user's rules (2026-10-28):
  * one PNG per AGR token, named after the token — <OVERLAYx1> and <OVERLAYx2> are two files even when
    the picture is the same;
  * never a second file for one token (no "_2" copies): the same picture already there is reused; a
    different one asks: replace or keep;
  * saved into one folder for the whole game (asked, the game folder's Symbols suggested), every
    token linked, so the Canvas shows them at once.
"""

import os
import re

from .content_model import sym_key

# how a picture was named -> (confidence, why)
_HOW = {
    "link": ("high", "you chose it before"),
    "row": ("high", "it stands where the AGR has this symbol in the text — the sentences around it match"),
    "card": ("high", "it is on this symbol's pay card"),
    "name": ("medium", "its layer is named like this symbol"),
    "folder": ("medium", "it looks like this symbol's picture"),
    "suggested": ("low", "its layer name looks like this symbol"),
    "shared": ("medium", "its sentences name this symbol too, on a picture another symbol has"),
}
_RANK = {"link": 6, "row": 5, "card": 4, "name": 3, "folder": 2, "shared": 1.5, "suggested": 1}

# not symbols: placeholders and headings an AGR writes between < > (FEATURE NAME, X, "&$H$49&" …)
_NOISE_WORDS = {"symbol", "symbols", "feature name", "feature", "name", "icon", "image", "picture", "logo",
                "translation", "x", "y", "z", "n", "game name", "insert", "tbd", "tbc"}


def is_symbol_token(token):
    """False for what an AGR puts between < > that is not a symbol: formula pieces ("&$H$49&"),
    placeholders (X, FEATURE NAME, TRANSLATION OF SYMBOL), empty ones."""
    t = str(token or "").strip().strip("<>").strip()
    if not t or len(t) > 60:
        return False
    if re.search(r'["&$=\\{}\[\]]', t):
        return False
    low = re.sub(r"\s+", " ", t.casefold())
    if low in _NOISE_WORDS or low.startswith("translation") or low.startswith("insert "):
        return False
    return True


_ROYALS = {"ace": "a", "king": "k", "queen": "q", "jack": "j", "ten": "10", "nine": "9"}


def _game_key_map(game_tokens):
    """sym_key -> the game's token, royals both ways (ACE <-> A)."""
    out = {}
    for t in game_tokens or []:
        out.setdefault(sym_key(t), t)
    for long, short in _ROYALS.items():
        for a, b in ((long, short), (short, long)):
            if sym_key(a) in out and sym_key(b) not in out:
                out[sym_key(b)] = out[sym_key(a)]
    return out


def match(psd_path, game_tokens, agr_path=""):
    """The review: {"ok", "rows": [{token, key, how, confidence, why, agr_token, others}], "unused":
    [picture keys no symbol took], "not_in_game": [AGR tokens with a picture this game doesn't use],
    "symbols": [the scan's pictures], "agr": bool}. Nothing is written."""
    from .ui_web import symbol_scan

    game_tokens = [t for t in (game_tokens or []) if is_symbol_token(t)]
    scan = symbol_scan.scan(psd_path)
    pictures = scan["symbols"]
    named, conflicts = {}, {}                       # picture key -> {agr token: how}; -> [tied tokens]
    if agr_path and os.path.isfile(agr_path):
        named, conflicts = _named_by_agr(psd_path, agr_path, pictures, symbol_scan)
    keymap = _game_key_map(game_tokens)
    best = {}                                       # game token -> (rank, key, how, agr token)
    not_in_game = {}
    for key, toks in named.items():
        for agr_tok, how in toks.items():
            if how == "other" or str(how).startswith("shared") or not is_symbol_token(agr_tok):
                continue
            tok = keymap.get(sym_key(agr_tok))
            if tok is None:
                not_in_game.setdefault(agr_tok, key)
                continue
            cand = (_RANK.get(how, 0), key, how, agr_tok)
            if tok not in best or cand[0] > best[tok][0]:
                best[tok] = cand
    # what the AGR evidence didn't name: the layer names (the old way)
    free = [t for t in game_tokens if t not in best]
    if free:
        by_name = symbol_scan.suggest_names([p["name"] for p in pictures], free)
        taken = {v[1] for v in best.values()} | set(named)   # a picture the evidence named stays its symbol's
        for p in pictures:
            tok = by_name.get(p["name"])
            if tok and tok not in best and p["key"] not in taken:
                best[tok] = (_RANK["suggested"], p["key"], "suggested", tok)
    # a symbol still without a picture that sentences also name on a picture another symbol has: that picture
    # (one picture, several symbols — saved once per symbol)
    # — the picture its own sentences name most
    shared = {}
    for key, toks in named.items():
        for agr_tok, how in toks.items():
            tok = keymap.get(sym_key(agr_tok))
            if str(how).startswith("shared:") and tok and tok not in best and is_symbol_token(agr_tok):
                v = float(str(how).split(":", 1)[1])
                if tok not in shared or v > shared[tok][0]:
                    shared[tok] = (v, key, agr_tok)
    for tok, (_v, key, agr_tok) in shared.items():
        best[tok] = (_RANK["shared"], key, "shared", agr_tok)
    # pictures the evidence is split on: offered to the symbols they could be, never picked
    maybe = {}
    for key, toks in conflicts.items():
        for agr_tok in toks:
            tok = keymap.get(sym_key(agr_tok))
            if tok and tok not in best:
                maybe.setdefault(tok, []).append({"key": key, "with": [t for t in toks if t != agr_tok]})
    rows = []
    for tok in game_tokens:
        hit = best.get(tok)
        if hit is None:
            m = maybe.get(tok)
            rows.append({"token": tok, "key": None, "how": "conflict" if m else None, "confidence": "none",
                         "why": (f"a picture's sentences say <{tok}> as often as <{'>, <'.join(m[0]['with'])}> — pick it"
                                 if m else "no picture found"), "maybe": [x["key"] for x in m] if m else []})
            continue
        _r, key, how, agr_tok = hit
        conf, why = _HOW.get(how, ("low", ""))
        others = sorted(t for t, h in (named.get(key) or {}).items()
                        if (h == "other" or str(h).startswith("shared")) and sym_key(t) != sym_key(agr_tok) and is_symbol_token(t))
        rows.append({"token": tok, "key": key, "how": how, "confidence": conf, "why": why, "agr_token": agr_tok,
                     "others": others})
    used = {r["key"] for r in rows if r["key"]}
    return {"ok": True, "agr": bool(named) or bool(agr_path), "rows": rows,
            "unused": [p["key"] for p in pictures if p["key"] not in used],
            "not_in_game": sorted(not_in_game),
            "symbols": [{k: v for k, v in p.items() if not k.startswith("_")} for p in pictures]}


# how much one piece of evidence counts when the text and the other clues are added up
_WEIGHT = {"link": 1000, "card": 3, "name": 1, "folder": 1, "row": 2}


def _named_by_agr(psd_path, agr_path, pictures, symbol_scan):
    """({picture key: {AGR token: how}} — the token each picture is decided to be, {picture key: [tokens]}
    — pictures their evidence disagrees on). The PSD's text lined up with the AGR (symbol_align: every
    sentence a picture is in votes) plus Clone a Market's other clues (market_clone.plan: the pay card a
    picture is on, its layer name, a link chosen before), added up; a tie is not decided."""
    from collections import Counter

    from . import market_clone as mc
    from . import symbol_align
    from .artist_design import psd_reader
    from .content_model import read_workbook

    sheets = read_workbook(agr_path)
    psd = psd_reader.open_lazy(psd_path)
    keys = {}                                       # picture signature -> scan key (decoded once per art)

    scan = symbol_scan.scan(psd_path)

    def key_of(layer):
        if isinstance(layer, symbol_align.Stack):
            return _stack_key(layer, scan, symbol_scan, keys, mc)
        sig = _cache_key(layer, mc)
        if sig not in keys:
            img = symbol_scan._pixels(layer)
            hit = symbol_scan.closest(pictures, symbol_scan._signature(img), img, scan["_images"]) if img is not None else None
            keys[sig] = hit["key"] if hit else None
        return keys[sig]

    pages = [(name, root) for _k, name, _l, root in mc._pages(psd)]
    votes, _evidence = symbol_align.name_pictures(pages, sheets, mc._is_picture, lambda l: key_of(l) or "")
    score = {k: Counter({t: 10 * n for t, n in c.items()}) for k, c in votes.items() if k}
    how_of = {k: {t: "row" for t in c} for k, c in score.items()}
    # the other clues: pay cards, layer names, links (market_clone)
    try:
        the_plan = mc.plan(psd, sheets, sheets, agr_path)
        syms = the_plan["_symbols"]
        for layer in psd.descendants():
            try:
                if not mc._is_picture(layer):
                    continue
            except Exception:
                continue
            got = syms.named.get(syms.sig(layer))
            if not got:
                continue
            tok, how = got
            if how == "row":
                continue                            # the text: counted above, sentence by sentence
            key = key_of(layer)
            if not key:
                continue
            c = score.setdefault(key, Counter())
            if tok not in how_of.setdefault(key, {}) or _RANK.get(how, 0) > _RANK.get(how_of[key][tok], 0):
                how_of[key][tok] = how if tok not in c else how_of[key].get(tok, how)
            c[tok] += 10 * _WEIGHT.get(how, 1) if how != "link" else _WEIGHT["link"]
    except Exception:
        pass                                        # the text alone still names what it can
    named, conflicts = {}, {}
    for key, c in score.items():
        ranked = c.most_common()
        if not ranked:
            continue
        (tok, n), rest = ranked[0], ranked[1:]
        if rest and rest[0][1] == n:
            conflicts[key] = sorted(t for t, v in ranked if v == n)
            continue
        named[key] = {tok: how_of.get(key, {}).get(tok, "row")}
        for t, v in rest:
            # another symbol at least two of its sentences name: the same picture can be that symbol too (an AGR
            # with <Feature Mummy> and <Feature Mummy2x2> for one picture); fewer: shown, not used
            named[key].setdefault(t, f"shared:{v}" if v >= 20 else "other")
    return named, conflicts


def _cache_key(layer, mc):
    """What copies of one picture share, for decoding it once: its smart object's file — with its layer name
    (less " copy N") and size, because an artist's duplicated smart object can hold another picture under
    the same file name (FoMo Mummy: "3x3mummy" and "3x3 SF mummy")."""
    import re as _re

    name = _re.sub(r"(\s+copy(\s+\d+)?)+\s*$", "", str(getattr(layer, "name", "") or ""), flags=_re.I).strip().casefold()
    return (mc.picture_sig(layer), name, int(getattr(layer, "width", 0) or 0), int(getattr(layer, "height", 0) or 0))


def _stack_key(stack, scan, symbol_scan, keys, mc):
    """The scan key of a Stack: its layers composed into one picture (as they stand on the page), added to
    the scan's symbols once (key "d<n>") — the same stack on other pages is that entry again."""
    from PIL import Image

    sig = ("stack",) + tuple(_cache_key(l, mc) for l in stack.layers)
    if sig in keys:
        return keys[sig]
    canvas = Image.new("RGBA", (max(1, stack.width), max(1, stack.height)), (0, 0, 0, 0))
    for l in stack.layers:                          # bottom first
        try:
            img = l.topil()
        except Exception:
            img = None
        if img is None:
            continue
        canvas.alpha_composite(img.convert("RGBA"), (int(l.left - stack.left), int(l.top - stack.top)))
    box = canvas.getchannel("A").getbbox()
    if not box:
        keys[sig] = None
        return None
    img = canvas.crop(box)
    art = symbol_scan._signature(img)
    pics = scan["symbols"]
    hit = next((e for e in pics if e["key"].startswith("d") and symbol_scan.same_picture(scan["_images"][e["key"]], e["_sig"], img, art)), None)
    if hit is None:
        key = f"d{sum(1 for e in pics if e['key'].startswith('d'))}"
        hit = {"key": key, "name": stack.name[:80], "kind": "stack", "w": img.width, "h": img.height, "count": 0,
               "pages": [], "hidden": False, "sizes": [f"{img.width}x{img.height}"], "_sig": art}
        pics.append(hit)                            # in the scan (cached): reviewed, thumbnailed and saved like any
        scan["_images"][key] = img
        scan["_thumbs"][key] = symbol_scan._thumb(img)
    hit["count"] += 1
    keys[sig] = hit["key"]
    return hit["key"]


def file_name(token):
    """The PNG a token's picture is saved as: the token's own name."""
    name = re.sub(r'[\\/:*?"<>|\r\n\t]+', "_", str(token or "").strip().strip("<>")).strip(" .")
    return (name or "symbol") + ".png"


def _same_picture(path, img):
    """True when the file at `path` already is this picture (same art, same size)."""
    from PIL import Image

    from .ui_web import symbol_scan

    def trimmed(im):
        im = im.convert("RGBA")
        box = im.getchannel("A").getbbox()
        return im.crop(box) if box else im

    try:
        img = trimmed(img)
        with Image.open(path) as old:
            old = trimmed(old)
            if abs(old.width - img.width) > 2 or abs(old.height - img.height) > 2:
                return False
            return symbol_scan._same_art(symbol_scan._signature(old), symbol_scan._signature(img))
    except Exception:
        return False


def plan_save(psd_path, picks, folder):
    """[{token, key, file, path, state}] — state: "new", "same" (that picture is already there: reused) or
    "differs" (another picture has the name: replace or keep)."""
    from .ui_web import symbol_scan

    scan = symbol_scan.scan(psd_path)
    out = []
    for p in picks or []:
        tok, key = str(p.get("token") or ""), str(p.get("key") or "")
        if not tok or not key:
            continue
        img = symbol_scan._image(scan, key)
        if img is None:
            continue
        fn = file_name(tok)
        path = os.path.join(folder, fn)
        state = "new" if not os.path.exists(path) else ("same" if _same_picture(path, img) else "differs")
        out.append({"token": tok, "key": key, "file": fn, "path": path, "state": state, "_img": img})
    return out


def save(psd_path, picks, folder, choices=None):
    """Write the picked pictures, one PNG per token. `choices`: {token: "replace" | "keep"} for files a
    different picture already has. Returns {"saved", "reused", "kept", "ask"} — "ask" lists the tokens
    that still need a choice (nothing is written then)."""
    choices = choices or {}
    plan = plan_save(psd_path, picks, folder)
    ask = [{"token": p["token"], "file": p["file"], "path": p["path"]} for p in plan
           if p["state"] == "differs" and choices.get(p["token"]) not in ("replace", "keep")]
    if ask:
        return {"saved": [], "reused": [], "kept": [], "ask": ask}
    os.makedirs(folder, exist_ok=True)
    saved, reused, kept = [], [], []
    for p in plan:
        if p["state"] == "same":
            reused.append(p["token"])
        elif p["state"] == "differs" and choices.get(p["token"]) == "keep":
            kept.append(p["token"])
        else:
            p["_img"].save(p["path"], "PNG")
            saved.append(p["token"])
    return {"saved": saved, "reused": reused, "kept": kept, "ask": [],
            "files": {p["token"]: p["file"] for p in plan}}
