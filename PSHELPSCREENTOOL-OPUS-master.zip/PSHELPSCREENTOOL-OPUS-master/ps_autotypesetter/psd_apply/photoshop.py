"""The Photoshop executor: ops (see __init__) carried out by Photoshop itself, on the artist's PSD.

Photoshop opens the PSD (or uses it where the artist has it open), makes the changes through
Action Manager and saves a copy to the new path; the original is never written. Photoshop lays the
text out itself, so text keeps its exact layout, overflow is measured, and the file is Photoshop's
own (no "requires a layout change" warnings, nothing a later Photoshop could call incompatible).
Runs through photoshop_bridge: whichever Photoshop is running, any version, nothing to install.

Verified in the Phase 0 spike (DESIGN_PRESERVING_UPDATES.md): text set with Action Manager by
layer ID keeps every style run when the runs are rebuilt around the change (the DOM's
textItem.contents puts the first character's style on everything — never used); "Use Smart Quotes"
would turn every ' into ’ (switched off while working); a font that isn't installed would become
Myriad Pro (such a layer is left alone and reported); paragraph text past its box is clipped, so
its full height is read with the box stretched for a moment.

Ops supported: copy_page, delete_pages, set_text (one per layer: its final text and, for every
character, the original character whose style it takes), remove_symbols, label. Rows the new AGR
added (add_row, continue_if_over) are not made here yet: they are reported for the artist.
"""
import json
import os
import re
import threading
import time

PHOTOSHOP_OPS = ("copy_page", "delete_pages", "set_text", "remove_symbols", "label")


class PhotoshopBusy(RuntimeError):
    """Photoshop is running but doesn't answer (a dialog is open in it)."""


# ── the interpreter (ExtendScript; ES3: no JSON object, the payload is a JS literal) ─────────────
JSX = r"""
var P = __PAYLOAD__;
function S(s) { return stringIDToTypeID(s); }
function C(c) { return charIDToTypeID(c); }
function now() { return new Date().getTime(); }
function q(s) {
  s = String(s); var o = '"';
  for (var i = 0; i < s.length; i++) {
    var ch = s.charAt(i), code = s.charCodeAt(i);
    if (ch == '"') o += '\\"'; else if (ch == '\\') o += '\\\\';
    else if (ch == '\r') o += '\\r'; else if (ch == '\n') o += '\\n';
    else if (code < 32 || code > 126) { var h = code.toString(16); while (h.length < 4) h = "0" + h; o += "\\u" + h; }
    else o += ch;
  }
  return o + '"';
}
function js(v) {
  if (v === null || v === undefined) return "null";
  if (typeof v == "number" || typeof v == "boolean") return String(v);
  if (typeof v == "string") return q(v);
  if (v instanceof Array) { var a = []; for (var i = 0; i < v.length; i++) a.push(js(v[i])); return "[" + a.join(",") + "]"; }
  var parts = []; for (var k in v) if (v.hasOwnProperty(k)) parts.push(q(k) + ":" + js(v[k]));
  return "{" + parts.join(",") + "}";
}

var IDMAP = {};                                   // the plan's layer ID -> Photoshop's (copied layers)
function T(id) { return (IDMAP.hasOwnProperty(String(id))) ? IDMAP[String(id)] : id; }
function ref(id) { var r = new ActionReference(); r.putIdentifier(C("Lyr "), id); return r; }
function desc(id) { return executeActionGet(ref(id)); }
function textKey(id) { return desc(id).getObjectValue(S("textKey")); }
function clone(d) { var c = new ActionDescriptor(); c.fromStream(d.toStream()); return c; }
function select(id) {
  var d = new ActionDescriptor(); d.putReference(C("null"), ref(id)); d.putBoolean(C("MkVs"), false);
  executeAction(C("slct"), d, DialogModes.NO);
}
var COLORS = {red: "Rd  ", orange: "Orng", yellow: "Ylw ", green: "Grn ", none: "None"};
function setColor(id, color) {
  var d = new ActionDescriptor(); d.putReference(C("null"), ref(id));
  var o = new ActionDescriptor(); o.putEnumerated(C("Clr "), C("Clr "), C(COLORS[color] || "None"));
  d.putObject(C("T   "), C("Lyr "), o); executeAction(C("setd"), d, DialogModes.NO);
}
function hide(id) {
  var d = new ActionDescriptor(), l = new ActionList(); l.putReference(ref(id));
  d.putList(C("null"), l); executeAction(C("Hd  "), d, DialogModes.NO);
}
function moveBy(id, dx, dy) {
  select(id);
  var d = new ActionDescriptor(), r = new ActionReference(); r.putEnumerated(C("Lyr "), C("Ordn"), C("Trgt"));
  d.putReference(C("null"), r);
  var o = new ActionDescriptor(); o.putUnitDouble(C("Hrzn"), C("#Pxl"), dx); o.putUnitDouble(C("Vrtc"), C("#Pxl"), dy);
  d.putObject(C("T   "), C("Ofst"), o); executeAction(C("move"), d, DialogModes.NO);
}
function exists(id) { try { desc(id); return true; } catch (e) { return false; } }
function topById(doc, id) {
  for (var i = 0; i < doc.layers.length; i++) if (doc.layers[i].id == id) return doc.layers[i];
  return null;
}

// ── text ──
function ranges(tk, key) {
  var out = [];
  if (!tk.hasKey(S(key))) return out;
  var list = tk.getList(S(key));
  for (var i = 0; i < list.count; i++) {
    var r = list.getObjectValue(i);
    out.push({from: r.getInteger(S("from")), to: r.getInteger(S("to")), d: r, cls: list.getObjectType(i)});
  }
  return out;
}
function containing(rs, at) {
  for (var i = 0; i < rs.length; i++) if (rs[i].from <= at && at < rs[i].to) return i;
  return rs.length ? rs.length - 1 : -1;
}
function rebuild(rs, cuts) {                      // cuts: [[from, to, index into rs]]
  var out = new ActionList();
  for (var i = 0; i < cuts.length; i++) {
    var d = clone(rs[cuts[i][2]].d);
    d.putInteger(S("from"), cuts[i][0]); d.putInteger(S("to"), cuts[i][1]);
    out.putObject(rs[cuts[i][2]].cls, d);
  }
  return out;
}
function missingFonts(rs) {
  var miss = [];
  for (var i = 0; i < rs.length; i++) {
    var st = rs[i].d.getObjectValue(S("textStyle"));
    if (!st.hasKey(S("fontPostScriptName"))) continue;
    var f = st.getString(S("fontPostScriptName"));
    try { app.fonts.getByName(f); } catch (e) { if (("," + miss.join(",") + ",").indexOf("," + f + ",") < 0) miss.push(f); }
  }
  return miss;
}
function inkBottomFull(id) {                      // paragraph text: its whole height, the box stretched a moment
  var orig = textKey(id), tk = textKey(id);
  var shapes = tk.getList(S("textShape")), shape = shapes.getObjectValue(0);
  if (!shape.hasKey(S("bounds"))) return null;
  var b = shape.getObjectValue(S("bounds"));
  var top = b.getUnitDoubleValue(S("top")), bottom = b.getUnitDoubleValue(S("bottom")), unit = b.getUnitDoubleType(S("bottom"));
  b.putUnitDouble(S("bottom"), unit, top + 20000);
  shape.putObject(S("bounds"), C("Rctn"), b);
  var nl = new ActionList(); nl.putObject(shapes.getObjectType(0), shape);
  for (var j = 1; j < shapes.count; j++) nl.putObject(shapes.getObjectType(j), shapes.getObjectValue(j));
  tk.putList(S("textShape"), nl);
  putText(id, tk);
  var full = textKey(id).getObjectValue(S("boundingBox")).getUnitDoubleValue(S("bottom"));
  putText(id, orig);
  return [full, bottom];
}
function putText(id, tk) {
  var d = new ActionDescriptor(), r = new ActionReference(); r.putIdentifier(C("TxLr"), id);
  d.putReference(C("null"), r); d.putObject(C("T   "), C("TxLr"), tk);
  executeAction(C("setd"), d, DialogModes.NO);
}
function setText(op) {
  var id = T(op.layer);
  if (!exists(id)) return {ok: false, why: "the layer is not in the PSD Photoshop opened"};
  var tk = textKey(id), cur = tk.getString(S("textKey"));
  if (cur != op.old) return {ok: false, why: "the layer's text in Photoshop differs from the plan — not changed"};
  var styles = ranges(tk, "textStyleRange"), paras = ranges(tk, "paragraphStyleRange");
  var miss = missingFonts(styles);
  if (miss.length) return {ok: false, why: "font not installed on this PC: " + miss.join(", ") + " — not changed"};
  var text = op.text, n = text.length + 1, src = [];      // + Photoshop's end-of-text character
  for (var c = 0; c < op.carry.length; c++) {
    var seg = op.carry[c];
    for (var k = seg[0]; k < seg[1]; k++) src[k] = seg[2] + (k - seg[0]) * seg[3];
  }
  for (var k2 = 0; k2 < n; k2++) if (src[k2] === undefined) src[k2] = k2 > 0 ? src[k2 - 1] : 0;
  var cuts = [];
  for (var k3 = 0; k3 < n; k3++) {
    var at = containing(styles, src[k3]);
    if (cuts.length && cuts[cuts.length - 1][2] == at) cuts[cuts.length - 1][1] = k3 + 1;
    else cuts.push([k3, k3 + 1, at]);
  }
  var pcuts = [], start = 0;
  while (start < n) {                              // a new paragraph takes the style of the one it came from
    var end = text.indexOf("\r", start); end = end < 0 ? n : Math.min(n, end + 1);
    var p = containing(paras, src[start]);
    if (pcuts.length && pcuts[pcuts.length - 1][2] == p) pcuts[pcuts.length - 1][1] = end;
    else pcuts.push([start, end, p]);
    start = end;
  }
  tk.putString(S("textKey"), text);
  if (styles.length) tk.putList(S("textStyleRange"), rebuild(styles, cuts));
  if (paras.length) tk.putList(S("paragraphStyleRange"), rebuild(paras, pcuts));
  putText(id, tk);
  var got = textKey(id), res = {ok: got.getString(S("textKey")) == text};
  if (!res.ok) res.why = "Photoshop did not take the new text";
  try {
    var shape = got.getList(S("textShape")).getObjectValue(0);
    if (typeIDToStringID(shape.getEnumerationValue(C("TEXT"))) == "box") {
      var m = inkBottomFull(id);
      if (m && m[0] > m[1] + 0.5) { res.overflow = true; res.why = "the new text runs past its text box — check it"; }
    }
  } catch (e) { res.measure_error = String(e); }
  return res;
}

// ── symbols, labels, pages ──
function removeSymbols(op) {
  var i;
  for (i = 0; i < op.hide.length; i++) if (!exists(T(op.hide[i].layer))) return {ok: false, why: "the row's layers could not be found — not changed"};
  for (i = 0; i < op.move.length; i++) if (!exists(T(op.move[i].layer))) return {ok: false, why: "the row's layers could not be found — not changed"};
  for (i = 0; i < op.hide.length; i++) hide(T(op.hide[i].layer));
  for (i = 0; i < op.move.length; i++) moveBy(T(op.move[i].layer), op.move[i].dx, op.move[i].dy || 0);
  return {ok: true};
}
function pair(a, b, map) {
  map[String(a.id)] = b.id;
  if (a.typename == "LayerSet") for (var i = 0; i < a.layers.length && i < b.layers.length; i++) pair(a.layers[i], b.layers[i], map);
}
function copyPage(doc, op) {
  var g = topById(doc, T(op.group));
  if (!g) return {ok: false, why: "the page to copy is not in the PSD"};
  var dup;
  if (op.above !== null) {
    var a = topById(doc, T(op.above));
    if (!a) return {ok: false, why: "the page to place the copy above is not in the PSD"};
    dup = g.duplicate(a, ElementPlacement.PLACEBEFORE);
  } else {
    dup = g.duplicate(doc.layers[doc.layers.length - 1], ElementPlacement.PLACEAFTER);
  }
  dup.name = op.name;
  if (dup.visible != g.visible) dup.visible = g.visible;   // a copy is shown or hidden like its page
  var map = {};
  pair(g, dup, map);
  for (var i = 0; i < op.pairs.length; i++) {
    var o = String(T(op.pairs[i][0]));
    if (map.hasOwnProperty(o)) IDMAP[String(op.pairs[i][1])] = map[o];
  }
  setColor(dup.id, op.color);
  return {ok: true, id: dup.id};
}
function deletePages(doc, op) {
  var holder = doc.layerSets.add();
  if (doc.layers[0].id != holder.id) holder.move(doc.layers[0], ElementPlacement.PLACEBEFORE);   // the very top
  holder.name = op.name;
  // a group can't be moved INTO a group (Illegal Argument): it goes above the holder's top layer
  // instead (a stand-in layer while the holder is empty), so each page ends on top, as in the records
  var standIn = holder.artLayers.add();
  for (var i = 0; i < op.groups.length; i++) {
    var g = topById(doc, T(op.groups[i]));
    if (!g) continue;
    g.move(holder.layers[0], ElementPlacement.PLACEBEFORE);
    if (op.hidden) g.visible = false;
    setColor(g.id, op.color);
  }
  standIn.remove();
  if (op.hidden) holder.visible = false;
  setColor(holder.id, op.color);
  IDMAP[String(op.holder)] = holder.id;
  return {ok: true, id: holder.id};
}

(function () {
  var report = {version: app.version, timings: {}, results: [], idmap: IDMAP};
  var prevDialogs = app.displayDialogs, prevQuotes = null, doc = null, opened = false, state = null, t;
  app.displayDialogs = DialogModes.NO;
  try { prevQuotes = app.preferences.smartQuotes; app.preferences.smartQuotes = false; } catch (e) {}
  try {
    var src = new File(P.source);
    for (var i = 0; i < app.documents.length; i++) {
      try { if (app.documents[i].fullName.fsName.toLowerCase() == src.fsName.toLowerCase()) doc = app.documents[i]; } catch (e) {}
    }
    report.was_open = !!doc;
    t = now();
    if (!doc) { doc = app.open(src); opened = true; }
    app.activeDocument = doc;
    if (!opened) state = doc.activeHistoryState;     // the artist's own document: put back as it was
    report.timings.open_ms = now() - t;
    t = now();
    for (var k = 0; k < P.ops.length; k++) {
      var op = P.ops[k], res;
      try {
        if (op.op == "copy_page") res = copyPage(doc, op);
        else if (op.op == "delete_pages") res = deletePages(doc, op);
        else if (op.op == "set_text") res = setText(op);
        else if (op.op == "remove_symbols") res = removeSymbols(op);
        else if (op.op == "label") { var gid = T(op.group); if (exists(gid)) { setColor(gid, op.color); res = {ok: true}; } else res = {ok: false, why: "no such group"}; }
        else res = {ok: false, why: "not an op Photoshop makes yet"};
      } catch (e) { res = {ok: false, why: "Photoshop: " + String(e) + " (line " + e.line + ")"}; }
      report.results.push(res);
    }
    report.timings.ops_ms = now() - t;
    try { executeAction(S("collapseAllGroupsEvent"), new ActionDescriptor(), DialogModes.NO); } catch (e) {}
    t = now();
    var opts = new PhotoshopSaveOptions(); opts.maximizeCompatibility = true;
    doc.saveAs(new File(P.out), opts, true);
    report.timings.save_ms = now() - t;
  } catch (e) {
    report.error = String(e) + " (line " + e.line + ")";
  } finally {
    try {
      if (doc && opened) doc.close(SaveOptions.DONOTSAVECHANGES);
      else if (doc && state) doc.activeHistoryState = state;
    } catch (e) {}
    if (prevQuotes !== null) try { app.preferences.smartQuotes = prevQuotes; } catch (e) {}
    app.displayDialogs = prevDialogs;
  }
  return js(report);
})();
"""


# ── Python side ───────────────────────────────────────────────────────────────
def available():
    from .. import photoshop_bridge

    return photoshop_bridge.describe()["route"] != "none"


def ready(timeout=20.0):
    """Photoshop answers (started when needed). PhotoshopBusy when it is running but doesn't answer
    within `timeout` — a dialog is open in it; the artist is told instead of the tool waiting."""
    from .. import photoshop_bridge

    if os.environ.get("PYTEST_CURRENT_TEST") and not os.environ.get("PSH_TEST_PHOTOSHOP"):
        raise photoshop_bridge.PhotoshopUnavailable("tests never drive Photoshop")
    running = bool(photoshop_bridge.running_photoshops())
    box = {}

    def ask():
        try:
            box["version"] = photoshop_bridge.run_jsx("app.version", timeout=timeout if running else 300)
        except Exception as exc:
            box["error"] = exc

    th = threading.Thread(target=ask, daemon=True)
    th.start()
    th.join(timeout if running else 300)
    if th.is_alive():
        raise PhotoshopBusy("Photoshop is open but doesn't answer — close any dialog in it and try again.")
    if "error" in box:
        raise box["error"]
    return box["version"]


def _carry_runs(old, new):
    """For every character of `new`, the character of `old` whose style it takes (as the record
    executor carries styles), compressed to [from, to, first old index, step] runs."""
    from .. import market_clone as mc

    src = mc._carry(old, new, list(range(len(old))))
    runs = []
    for k, o in enumerate(src):
        if runs:
            r = runs[-1]
            step = r[3] if r[1] - r[0] > 1 else o - r[2]
            if r[1] == k and step in (0, 1) and o == r[2] + (k - r[0]) * step:
                r[1], r[3] = k + 1, step
                continue
        runs.append([k, k + 1, o, 0])
    return runs


def payload(psd, the_plan):
    """The ops Photoshop is given, from a clone run made in memory (`psd`: the PSD as the record
    executor left it): page copies / deleted pages; for every text layer changed, ONE set_text with
    its final text (preview edits included) and the style each character takes; symbols removed;
    labels. Returns (ops, skipped ops)."""
    layers = {l.layer_id: l for l in psd.descendants()}
    olds = {}
    for item in the_plan.get("items") or []:
        if item.get("layer_id") is not None and "old" in item:
            olds.setdefault(item["layer_id"], (item["old"], item))
    # the layers Photoshop will have: the artist's, and the copies the page ops make
    known = set(the_plan.get("_source_ids") or ())
    for op in the_plan.get("_ops") or []:
        if op["op"] == "copy_page":
            known.update(p[1] for p in op["pairs"])
        elif op["op"] == "delete_pages":
            known.add(op["holder"])
    out, skipped, texts = [], [], {}
    for op in the_plan.get("_ops") or []:
        kind = op["op"]
        if kind == "label" and known and op["group"] not in known:
            skipped.append(op)                        # a page made in memory only (a Continued page)
            continue
        if kind in ("set_text", "edit_text"):
            lid = op["layer"]
            if lid in texts:
                continue
            layer, was = layers.get(lid), olds.get(lid)
            if layer is None or was is None:
                skipped.append(op)
                continue
            old, new = was[0], str(layer.text or "")
            texts[lid] = {"op": "set_text", "layer": lid, "old": old, "text": new, "carry": _carry_runs(old, new),
                          "ref": op.get("ref") or ["items", the_plan["items"].index(was[1])]}
            out.append(texts[lid])
        elif kind in PHOTOSHOP_OPS:
            out.append(op)
        else:
            skipped.append(op)
    return out, skipped


def execute(source_psd, out_path, ops, timeout=3600):
    """Run `ops` in Photoshop on `source_psd`, saving a copy to `out_path`. Returns Photoshop's
    report: {"results": [one per op], "idmap", "timings", "was_open", "error"?, "wall_s"}."""
    from .. import photoshop_bridge

    pay = {"source": os.path.abspath(source_psd).replace("\\", "/"),
           "out": os.path.abspath(out_path).replace("\\", "/"), "ops": ops}
    os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
    t = time.perf_counter()
    raw = photoshop_bridge.run_jsx(JSX.replace("__PAYLOAD__", json.dumps(pay)), timeout=timeout)
    report = json.loads(str(raw or "{}"))
    report["wall_s"] = round(time.perf_counter() - t, 1)
    return report


def merge(the_plan, ops, skipped, report):
    """Photoshop's outcome written into the plan the way the clone reports it."""
    edited = 0
    for op, res in zip(ops, report.get("results") or []):
        ref = op.get("ref")
        entry = the_plan[ref[0]][ref[1]] if ref else None
        if res.get("ok"):
            edited += op["op"] in ("set_text", "remove_symbols")
            if entry is not None and res.get("why"):
                entry["why"] = (entry.get("why", "") + " · " + res["why"]).strip(" ·")
        elif entry is not None:
            entry.update(status="artist", why=res.get("why") or "Photoshop could not make this change")
    # rows the new AGR added (and the Continued pages they'd need) were placed in memory only: in
    # Photoshop's PSD they are the artist's to add for now
    not_yet = "add this row by hand — rows aren't added in Photoshop yet"
    for op in skipped:
        ref = op.get("ref")
        if ref and ref[0] == "rows_added":
            the_plan["rows_added"][ref[1]].update(status="artist", why=not_yet)
        elif op["op"] == "add_symbol" and ref:
            entry = the_plan[ref[0]][ref[1]]
            names = ", ".join(f"<{s['token']}>" for s in op["symbols"])
            also = " and move the icons already on its lines" if op.get("icons") else ""
            entry["why"] = (entry.get("why", "") + f" · put the {names} picture(s) in{also} by hand").strip(" ·")
        elif op["op"] == "flow_over":
            for item in the_plan.get("items") or []:
                if item.pop("moved_to", None):
                    item["why"] = re.sub(r"\s*·\s*moved onto “[^”]*”: it ran past[^·]*", "", item.get("why", ""))
                    item["why"] = (item["why"] + " · this page runs past the area the artist keeps content in — "
                                   "move what doesn't fit onto the continued page by hand").strip(" ·")
        elif op["op"] == "continue_if_over":
            for row in the_plan.get("rows_added") or []:
                if row.get("row") is None and row.get("sheet") == op["sheet"]:
                    row.update(status="artist", why="no Continued page was made: the rows weren't added")
    for item in the_plan.get("items") or []:
        if item.get("layer") in ("row added", "continued page") and item.get("status") == "change":
            item.update(status="artist", why=not_yet)
    return edited
