"""The record executor: ops (see __init__) applied to a PSD in memory by patching its psd-tools
records — no Photoshop. The layer section is never rebuilt (Photoshop refuses such a file); text
keeps its style runs and Photoshop's document text block (Txt2) is kept in step; previews are
redrawn by the tool's own text layout (an approximation of Photoshop's).

Outcomes are written back into the plan entries the ops point at ("ref"), the way the clone
reports them. The text-editing helpers live in market_clone (shared with the preview editor).
"""
from . import Layers


class RecordExecutor:
    def __init__(self, psd, the_plan=None):
        self.psd, self.plan = psd, the_plan
        self.layers = Layers(psd)
        self.engine = None                            # Photoshop's document text block, for set_text
        self.previews = []                            # edited text layers whose pixels are drawn next
        self.placed = {}                              # (page group ID, row) -> (top, bottom) of a row added

    def _entry(self, op):
        ref = op.get("ref")
        return self.plan[ref[0]][ref[1]] if ref and self.plan is not None else {}

    def _rebuild(self):
        """The layer tree again from the records (after layers were added)."""
        from psd_tools import PSDImage

        self.psd = PSDImage(self.psd._record)
        self.layers = Layers(self.psd)
        return self.psd

    def run(self, op):
        """Apply one op; True when it was applied."""
        return getattr(self, op["op"])(op)

    def run_all(self, ops):
        done, k = 0, 0
        while k < len(ops):
            if ops[k]["op"] == "add_symbol":          # a run of them together: drawn at once, copied in one go
                j = k
                while j < len(ops) and ops[j]["op"] == "add_symbol":
                    j += 1
                done += self.add_symbols(ops[k:j])
                k = j
            else:
                done += bool(self.run(ops[k]))
                k += 1
        return done

    # ── text ──────────────────────────────────────────────────────────────────
    def apply_text_ops(self, ops):
        """set_text / remove_symbols ops, with the document text block kept in step for all of them:
        the plan's "text_engine" says what became of it. Returns how many were applied."""
        from psd_tools.constants import Tag

        from .. import market_clone as mc

        blocks = self.psd._record.layer_and_mask_information.tagged_blocks
        self.engine = mc.TextEngine(blocks.get_data(Tag.TEXT_ENGINE_DATA) if blocks is not None else None)
        done = 0
        for op in ops:
            if op["op"] != "set_text":
                self.draw_previews()                  # before anything moves a layer whose text changed
            done += bool(self.run(op))
        self.draw_previews()
        self.plan["text_engine"] = self.engine.state()
        if self.engine.edited:
            from . import splice

            splice.mark_document(self.psd)            # Photoshop's text block changed in place
        if self.engine.edited and self.plan.get("photoshop_redraw", True) and Tag.TEXT_ENGINE_DATA in blocks:
            # text was changed outside Photoshop: our preview pixels are only close (the artist's font may
            # not be where Python looks). Without the document text block Photoshop asks on open "Some
            # text layers might need to be updated…" — one click on Update lays every text out exactly.
            del blocks[Tag.TEXT_ENGINE_DATA]
            from . import splice

            splice.mark_document(self.psd)
            self.plan["text_engine"] = "redraw"
            return done
        if self.engine.failed:
            # Photoshop CC prefers the document-wide Txt2 copy of every text layer over the layer's own;
            # one that couldn't be kept in step would show the old text, so the block goes (Photoshop
            # then reads every layer's own text, flagged "requires a layout change")
            del blocks[Tag.TEXT_ENGINE_DATA]
        return done

    def set_text(self, op):
        from .. import market_clone as mc

        item = self._entry(op)
        layer = self.layers.get(op)
        if layer is None or layer.kind != "type" or str(layer.text or "") != op["old"]:
            item.update(status="artist", why="the layer could not be found again — not changed")
            return False
        old_text = mc._editor_text(layer)
        try:
            old_height = mc._layout_height(layer, old_text)
        except Exception:
            old_height = 0.0
        text = op["text"]
        if mc._box_frame(layer) is None:              # point text doesn't wrap: long new lines are broken
            text = item["new"] = mc.rewrap_point(layer, op["old"], text)
        new = mc.edit_text_layer(layer, text)
        self.engine.update(layer, old_text, new)
        if not op.get("draw_later"):                  # (symbols added to it: drawn once they're in, add_symbol)
            self.previews.append((layer, new, item, old_height))
        return True

    def draw_previews(self, threads=4):
        """The pixels of the text layers edited so far, drawn by the tool's own layout (a few at a time —
        each is independent) and put in place in the order the layers were edited."""
        from concurrent.futures import ThreadPoolExecutor

        from .. import market_clone as mc

        pending, self.previews = self.previews, []
        if not pending:
            return
        mc._font_file("")                             # the installed-fonts table, built once before the threads

        def draw(job):
            try:
                return mc._preview(job[0], job[1])
            except Exception as exc:
                return exc

        with ThreadPoolExecutor(max(1, min(threads, len(pending)))) as ex:
            drawn = list(ex.map(draw, pending))
        for (layer, new, item, old_height), got in zip(pending, drawn):
            try:
                if isinstance(got, Exception):
                    raise got
                if got:
                    mc._swap_pixels(self.psd, layer, *got[:3])
                    if got[3] and mc._layout_height(layer, new) > old_height + 1:
                        item["why"] = (item.get("why", "") + " · the new text may not fit its text box — check it").strip(" ·")
            except Exception as exc:                  # the text is right; only its preview is stale
                item["why"] = (item.get("why", "") + f" · preview not redrawn ({exc})").strip(" ·")

    def remove_symbols(self, op):
        from .. import market_clone as mc

        edit = self._entry(op)
        hide = [self.layers.get(r) for r in op["hide"]]
        move = [(self.layers.get(r), r["dx"], r.get("dy", 0)) for r in op["move"]]
        if any(l is None for l in hide) or any(l is None for l, _dx, _dy in move):
            edit.update(status="artist", why="the row's layers could not be found again — not changed")
            return False
        for layer in hide:
            layer.visible = False
        for layer, dx, dy in move:
            mc.move_layer(layer, dx, dy)
        return True

    # ── rows ──────────────────────────────────────────────────────────────────
    def add_row(self, op):
        """A copy of the template row's paragraphs (and its symbols) with the new text, under the row
        before it, at the gap the artist left above the template row; what is below moves down."""
        from psd_tools.constants import Tag

        from .. import market_clone as mc
        from ..artist_design import psd_pages

        entry = self._entry(op)
        psd, h = self.psd, self.psd.size[1]
        page = self.layers.tops[self.layers.top_index(op["page"])]
        tmpl = self.layers.get(op["template"])
        p0, p1 = op["template"]["paragraphs"]
        text = mc._editor_text(tmpl)
        tops = mc._line_tops(tmpl, text)
        band = (tops[p0][0], tops[p1][1]) if tops[p0] and tops[p1] else (tmpl.top, tmpl.bottom)
        pics = [l for l in page.descendants() if not l.is_group() and l.visible and mc._is_picture(l)
                and tmpl.left - 8 <= (l.left + l.right) / 2.0 <= tmpl.right + 8
                and band[0] - 12 <= (l.top + l.bottom) / 2.0 <= band[1] + 12] if op["symbols"] else []
        # where it goes: under the row before it (shown, or placed just now)
        after = op["after"]
        if "row" in after:
            anchor_bottom = self.placed[(op["page"], after["row"])][1]
        else:
            lay, last = self.layers.get(after), after["paragraph"]
            t2 = mc._line_tops(lay, mc._editor_text(lay))
            anchor_bottom = t2[last][1] if t2[last] else lay.bottom
            anchor_bottom = max([anchor_bottom] + [p.bottom for p in page.descendants() if not p.is_group() and p.visible
                                                   and mc._is_picture(p) and lay.left <= (p.left + p.right) / 2.0 <= lay.right
                                                   and t2[last] and t2[last][0] - 12 <= (p.top + p.bottom) / 2.0 <= anchor_bottom + 12])
        # the gap the artist left above the template row: from the paragraph before it in the same
        # layer, else from the row of layers above it
        prev_para = next((tops[k] for k in range(p0 - 1, -1, -1) if tops[k]), None)
        if prev_para is not None:
            gap = max(4.0, band[0] - prev_para[1])
        else:
            above_tmpl = [b for b in mc._row_bands(mc._page_content(page, h)) if b["bottom"] <= band[0] + 2]
            gap = max(8.0, band[0] - above_tmpl[-1]["bottom"]) if above_tmpl else 24.0
        # the copies: the template's text layer (just this row's paragraphs) and its symbols
        recs = psd_pages.copy_layers(psd, [tmpl] + pics)
        psd = self._rebuild()
        by_rec = {id(l._record): l for l in psd.descendants()}
        copy_t, copy_pics = by_rec[id(recs[0])], [by_rec[id(x)] for x in recs[1:]]
        engine = mc.TextEngine(psd._record.layer_and_mask_information.tagged_blocks.get_data(Tag.TEXT_ENGINE_DATA))
        old_text = mc._editor_text(copy_t)
        done_text = mc.edit_text_layer(copy_t, op["text"])
        engine.update(copy_t, old_text, done_text)
        if engine.edited:
            from . import splice

            splice.mark_document(psd)
        got = mc._preview(copy_t, done_text)
        if got:
            mc._swap_pixels(psd, copy_t, *got[:3])
        target = anchor_bottom + gap
        mc.move_layer(copy_t, 0, target - copy_t.top)
        for p in copy_pics:
            mc.move_layer(p, 0, target - band[0])
        bottom = max([copy_t.bottom] + [p.bottom for p in copy_pics])
        # what was under the insertion point moves down
        shift = bottom + gap - target
        page = self.layers.tops[self.layers.top_index(op["page"])]
        moved = 0
        for l in mc._page_content(page, h):
            if l._record is copy_t._record or any(l._record is p._record for p in copy_pics):
                continue
            if l.top >= anchor_bottom + 2:
                mc.move_layer(l, 0, shift)
                moved += 1
        self.placed[(op["page"], op["row"])] = (target, bottom)
        entry.update(status="change", why=f"added as a copy of row {op['template_row']}"
                                          + (f"; {moved} layer(s) below moved down" if moved else ""),
                     _rec=id(copy_t._record))
        return True

    def continue_if_over(self, op):
        """The rows past the page's content limit move onto a Continued page right after it."""
        from .. import market_clone as mc

        index = self.layers.top_index(op["page"])
        page = self.layers.tops[index]
        bands = mc._row_bands(mc._page_content(page, self.psd.size[1]))
        over = next((k for k, b in enumerate(bands) if k > 0 and b["bottom"] > op["limit"] + 4), None)
        if over is None:
            return False
        self.psd = mc._continue_page(self.psd, self.plan, index, bands, over, op["sheet"], op["limit"])
        self.plan["rows_added"][-1]["_from_page"] = op["page_key"]   # the page as the plan knew it
        self.layers = Layers(self.psd)
        return True

    def flow_over(self, op):
        """A page past the bottom of the artist's working area: what runs over goes onto its continued
        page, and on from there (market_clone.flow_over)."""
        from .. import market_clone as mc

        index = self.layers.top_index(op["page"])
        if index is None:
            return False
        self.psd = mc.flow_over(self.psd, self.plan, index, op["limit"])
        self.layers = Layers(self.psd)
        return True

    # ── symbols the new Excel added ───────────────────────────────────────────
    def add_symbol(self, op):
        """A copy of a picture of each symbol (from elsewhere in the PSD) in the gap left for it in a
        text layer (op["symbols"]: token, the gap's characters "at", pictures to copy): as tall as the
        page's other icons — the PSD's when the page has none — relative to the font of the gap's line,
        sat on the line as they are, its own proportions kept. Gaps are widened first where the
        picture is wider and the lines next to a picture spaced out to clear it; then the artist's
        own icons in the text and the new pictures are set where the final text puts each gap."""
        return self.add_symbols([op])

    def add_symbols(self, ops):
        """add_symbol for several text layers at once: each one's text and spacing changed, then all of
        them drawn (a few at a time), then every icon set and every picture put in — copied in one go,
        the layer tree rebuilt once."""
        from concurrent.futures import ThreadPoolExecutor

        from PIL import Image

        from .. import market_clone as mc
        from ..artist_design import psd_pages

        jobs = [j for j in (self._symbol_text(op) for op in ops) if j is not None]
        mc._font_file("")                             # the installed-fonts table, built once before the threads

        def draw(job):
            try:
                return mc._preview(job["t"], job["text"])
            except Exception as exc:
                return exc

        with ThreadPoolExecutor(max(1, min(4, len(jobs) or 1))) as ex:
            drawn = list(ex.map(draw, jobs))
        for job, got in zip(jobs, drawn):              # the one drawing of each layer's new text
            if isinstance(got, Exception):
                job["by_hand"].append(f"preview not redrawn ({got})")
            elif got:
                mc._swap_pixels(self.psd, job["t"], *got[:3])
                if got[3] and not job["grow"]:
                    job["by_hand"].append("the new text may not fit its text box — check it")
        # what is under each text that grew moved down first — the lowest text first, so a text that one
        # above it pushes down is pushed with everything under it — and only then each icon and picture
        # placed, from where its text ends up (placed before the texts above had grown, they were left
        # behind: page 7's lanterns rose further above their lines block by block)
        for job in sorted((j for j in jobs if j["grow"]), key=lambda j: -j["old_bottom"]):
            moved = self._push_below(job["page"], job["t"], job["op"], job["old_bottom"], job["grow"])
            job["item"]["why"] = (job["item"].get("why", "") + " · the lines with the new pictures were spaced"
                                  " out to fit them" + (f"; {moved} layer(s) below moved down" if moved else "")).strip(" ·")
        self._outside_area(jobs)
        copies = []                                   # [job, symbol, picture to copy, its image, box]
        for job in jobs:
            copies += self._symbol_places(job)
        by_page = {}
        for c in copies:
            by_page.setdefault(id(c[0]["page"]._record), (c[0]["page"], []))[1].append(c)
        made = {}
        for page, group in by_page.values():
            for c, rec in zip(group, psd_pages.copy_layers(self.psd, [c[2] for c in group], into=page)):
                made[id(c)] = rec
        if copies:
            psd = self._rebuild()
            by_rec = {id(l._record): l for l in psd.descendants()}
            for c in copies:
                job, sym, _src, img, (x, y, w, h) = c
                copy = by_rec[id(made[id(c)])]
                mc.put_pixels(psd, copy, img.resize((w, h), Image.LANCZOS), x, y)
                if copy.kind == "smartobject":
                    mc.set_placement(copy, (x, y, x + w, y + h))
                if not copy.visible:
                    copy.visible = True
                job["placed"] += 1
        for job in jobs:
            item, placed = job["item"], job["placed"]
            if placed:
                item["why"] = item.get("why", "").replace(
                    "a gap was left for it: put the picture in",
                    ("its picture was put in the gap" if placed == 1 else "their pictures were put in the gaps")
                    + " — check the size")
            self._note(item, job["by_hand"])
        return sum(1 for j in jobs if j["placed"] or j["op"].get("icons"))

    @staticmethod
    def _note(item, by_hand):
        if by_hand:
            item["why"] = (item.get("why", "") + " · " + "; ".join(by_hand)).strip(" ·")

    def _symbol_text(self, op):
        """add_symbol's first part for one layer: the gaps widened to fit their pictures and the lines
        next to them spaced out — text and styles only, nothing drawn. A job for the rest, or None."""
        from .. import market_clone as mc

        item = self._entry(op)
        by_hand = []
        t = self.layers.get(op["text"])
        index = self.layers.top_index(op["page"])
        if t is None or index is None:
            self._note(item, ["put the pictures in by hand"])
            return None
        page = self.layers.tops[index]
        text = str(t.text or "").rstrip("\r")
        todo = []                                     # [symbol, picture to copy, gap (start, end)]
        skipped = []                                  # [gap] of symbols with no picture to put in
        for s in op["symbols"]:
            a, b = s["at"]
            sources = [l for l in (self.layers.get(r) for r in s["sources"]) if l is not None]
            src = next((l for l in sources if not getattr(l._record, "mask_data", None)), None)
            if src is None:
                by_hand.append(f"no picture of <{s['token']}> in the PSD to copy — put it in by hand")
                skipped.append([(a, b)])
            elif b > len(text) or a >= b or text[a:b].strip(" \u00a0"):
                by_hand.append(f"put the <{s['token']}> picture in by hand (its gap couldn't be found)")
            else:
                todo.append([s, src, (a, b)])
        job = {"op": op, "item": item, "by_hand": by_hand, "t": t, "page": page, "text": text, "todo": todo,
               "skipped": skipped, "ratio": 1.6, "offset": 0.0, "grow": 0.0, "old_bottom": t.bottom, "placed": 0}
        if not todo and not op.get("icons"):
            return job                                # only drawn (set_text: draw_later)
        if not mc._wrap_ok(t):                        # where its gaps fall can't be told: drawn only
            by_hand.append("put the pictures in by hand — " + mc._WRAP_WHY.replace(" — move its icons by hand", ""))
            job["todo"], job["op"] = [], dict(op, icons=[])
            return job
        if not hasattr(self, "_icons"):
            self._icons = {}
        key = id(page._record)
        if key not in self._icons:                    # (the page's own icons, before any are added)
            self._icons[key] = mc.page_icons(page)
        icons = self._icons[key]
        if icons is None:                             # no icons on this page: as on the PSD's other pages
            if "psd" not in self._icons:
                self._icons["psd"] = mc.page_icons(*self.psd)
            icons = self._icons["psd"]
        job["ratio"], job["offset"] = ratio, offset = icons or (1.6, 0.0)
        try:
            spots, lines = mc._laid_out(t, text)
            widths = mc._measure(t, text)
        except Exception:
            spots, widths = None, None
        if not spots or widths is None:
            by_hand.append("put the pictures in by hand (the text couldn't be measured)")
            job["todo"], job["op"] = [], dict(op, icons=[])
            return job

        def line_of(a, b):
            return next((spots[i][2] for i in range((a + b) // 2, b) if i in spots), 0)

        # 1. each gap made as wide as its picture (+ a space each side), last first so the places hold;
        # one size for a symbol however close the lines are: room is made for it (1b)
        changed = False
        for entry in sorted(todo, key=lambda e: -e[2][0]):
            s, src, (a, b) = entry
            height = ratio * lines[line_of(a, b)][1]
            width = height * src.width / max(1, src.height)
            fill = "\u00a0" if "\u00a0" in text[a:b] else " "
            space = (mc._measure(t, fill) or [0.0])[0] or 1.0
            have, need = sum(widths[a:b]), width + 2 * space
            if need > have + 0.5:                     # the gap made room for the page's icons; this one is wider
                extra = int(-(-(need - have) // space))
                mid = (a + b) // 2
                text = text[:mid] + fill * extra + text[mid:]
                widths = widths[:mid] + [space] * extra + widths[mid:]
                for other in todo:                    # gaps after this one move along
                    if other[2][0] > a:
                        other[2] = (other[2][0] + extra, other[2][1] + extra)
                for other in skipped:
                    if other[0][0] > a:
                        other[0] = (other[0][0] + extra, other[0][1] + extra)
                entry[2] = (a, b + extra)
                changed = True
        if changed:                                   # (lines are laid out from the text, not its pixels)
            mc.set_layer_text(self.psd, t, text, draw=False, photoshop_redraw=(self.plan or {}).get("photoshop_redraw", True))
            item["new"] = job["text"] = text
            spots, lines = mc._laid_out(t, text)
        # 1b. room for each picture: a picture taller than its line's spacing would cover the lines next
        # to it, so the line it sits on is pushed down from the one above, and the line below from it
        # (a line's leading — its distance from the line above — is the largest of its characters')
        job["grow"] = self._make_room(t, text, spots, lines, [line_of(a, b) for _s, _src, (a, b) in todo],
                                      ratio, offset)
        return job

    def _outside_area(self, jobs):
        """A note on each changed text that now reaches past the artist's working area (the_plan
        "work_area": as far as any page's content goes each way), and on each grown text whose page now
        runs below it — what doesn't fit belongs on a Continued page."""
        from .. import market_clone as mc

        area = (self.plan or {}).get("work_area")
        if area is None:
            if not hasattr(self, "_area"):
                self._area = mc.working_area(self.psd)
            area = self._area
        left, _top, right, bottom = area
        lowest = {}
        for job in jobs:
            t, page = job["t"], job["page"]
            if t.left < left - 4 or t.right > right + 4:
                job["by_hand"].append("the text now runs past the side of the area the artist keeps content in — "
                                      "check its lines")
            if not job["grow"]:
                continue
            key = id(page._record)
            if key not in lowest:
                lowest[key] = max((l.bottom for l in mc._page_content(page, self.psd.size[1])), default=0)
            if lowest[key] > bottom + 4:
                job["by_hand"].append(f"the page now runs {int(lowest[key] - bottom)} px below the area the artist "
                                      "keeps content in — move what doesn't fit onto a Continued page")

    def _symbol_places(self, job):
        """add_symbol's last part for one layer, once drawn and everything under the texts that grew moved
        down: the artist's own icons set in their gaps of the final text (as they sat in them before), and
        where each new picture goes. Returns [job, symbol, picture, its image, (x, y, w, h)]."""
        from .. import market_clone as mc

        op, item, by_hand, t, page, text = (job[k] for k in ("op", "item", "by_hand", "t", "page", "text"))
        if not job["todo"] and not op.get("icons"):
            return []
        spots, lines = mc._laid_out(t, text)
        ratio, offset = job["ratio"], job["offset"]
        # the artist's own icons: from the text as it now is (a shift worked out earlier goes stale once a
        # gap widens)
        if op.get("icons"):
            added = [e[2] for e in job["todo"]] + [e[0] for e in job["skipped"]]
            new_gaps = [(a, b) for _n, a, b in mc._gaps(text) if not any(a < y and x < b for x, y in added)]
            pics = [(self.layers.get(r), r) for r in op["icons"]]
            if len(new_gaps) != len(pics) or any(p is None for p, _r in pics):
                by_hand.append("the icons already in this text couldn't be matched to their gaps — move them by hand")
            else:
                for (p, r), (a, b) in zip(pics, new_gaps):
                    at = mc._gap_spots(spots, lines, text, a, b)
                    if at is None:
                        by_hand.append(f"move the “{p.name}” icon by hand")
                        continue
                    mc.move_layer(p, at[0] + r["dx"] - (p.left + p.right) / 2.0,
                                  at[1] + r["dy"] - (p.top + p.bottom) / 2.0)
        # each new picture centred in its gap, on the gap's line
        out = []
        for s, src, (a, b) in job["todo"]:
            at = mc._gap_spots(spots, lines, text, a, b)
            if at is None:
                by_hand.append(f"put the <{s['token']}> picture in by hand (its gap couldn't be measured)")
                continue
            top, size, _n = lines[spots[next(i for i in range((a + b) // 2, b) if i in spots)][2]]
            height = ratio * size
            w, h = max(1, int(round(height * src.width / max(1, src.height)))), max(1, int(round(height)))
            cy = top + size / 2.0 + offset * size
            img = src.topil()
            if img is None:
                by_hand.append(f"the <{s['token']}> picture couldn't be read — put it in by hand")
                continue
            out.append([job, s, src, img.convert("RGBA"),
                        (int(round(at[0] - w / 2.0)), int(round(cy - h / 2.0)), w, h)])
        return out

    def _make_room(self, t, text, spots, lines, on_lines, ratio, offset):
        """Lines spaced out so the pictures to go on `on_lines` (line numbers in `lines`, _laid_out)
        clear the text above and below them (a paragraph's box grown to fit); draw the text again
        afterwards. Returns how much taller the text became (document pixels)."""
        from .. import market_clone as mc

        # how far a line's letters reach below its top — capitals and the tails of g, q, y ("triggered"
        # was clipped when only capitals were cleared) — and the clearance kept: x the font size
        CAP, MARGIN = 0.92, 0.1
        extra = {}
        for ln in on_lines:
            top, size, _n = lines[ln]
            h = ratio * size
            cy = top + size / 2.0 + offset * size
            above = next((k for k in range(ln - 1, -1, -1) if lines[k][2]), None)
            below = next((k for k in range(ln + 1, len(lines)) if lines[k][2]), None)
            if above is not None:
                need = lines[above][0] + CAP * lines[above][1] + MARGIN * size - (cy - h / 2.0)
                if need > 0.5:
                    extra[ln] = max(extra.get(ln, 0.0), need)
            if below is not None:
                need = cy + h / 2.0 + MARGIN * size - lines[below][0]
                if need > 0.5:
                    extra[below] = max(extra.get(below, 0.0), need)
        if not extra:
            return 0.0
        spans = []
        for k, more in extra.items():
            chars = [i for i, s in spots.items() if s[2] == k]
            lead = lines[k][0] - lines[k - 1][0]      # (k > 0: a line above it was found)
            spans.append((min(chars), max(chars) + 1, lead + more))
        old_h = mc._layout_height(t, text)
        mc.set_leading(self.psd, t, spans)
        if mc._box_frame(t):
            box = mc._box_frame(t)
            new_h = mc._layout_height(t, text)
            if new_h > box[3]:
                mc.grow_box(self.psd, t, box[3] + (new_h - old_h))
        return sum(extra.values())

    def _push_below(self, page, t, op, old_bottom, grow):
        """The page's layers under a text that grew `grow` pixels taller moved down as much (not its
        own icons, which are set from its new lines). Returns how many moved."""
        from .. import market_clone as mc

        own = {id(t._record)} | {id(l._record) for l in (self.layers.get(r) for r in op.get("icons") or []) if l is not None}
        moved = 0
        for l in mc._page_content(page, self.psd.size[1]):
            if id(l._record) in own:
                continue
            if l.top >= old_bottom - 2 and l.right > t.left and l.left < t.right:
                mc.move_layer(l, 0, grow)
                moved += 1
        return moved

    # ── the artist's edits, labels ────────────────────────────────────────────
    def edit_text(self, op):
        from .. import market_clone as mc

        mc.set_layer_text(self.psd, self.layers.get(op), op["text"], photoshop_redraw=(self.plan or {}).get("photoshop_redraw", True))
        return True

    def label(self, op):
        from ..artist_design import psd_pages

        psd_pages.set_color(self.layers.tops[self.layers.top_index(op["group"])]._record, op["color"])
        return True
