"""Write an updated PSD by copying everything the update didn't touch byte for byte.

psd-tools writes a PSD by serializing every layer record, every block and every channel again, in
Python: 20 s for a 512 MB artist PSD even when three text layers changed. Here the source file is
indexed when it is opened (record / pixel / block offsets, read with struct — milliseconds), and on
writing each layer record and its pixels are copied raw from the source unless the update changed
them; only those are serialized by psd-tools. The document's own blocks (Photoshop's text block
Txt2 and the rest) and the composite image are copied raw too when untouched.

What counts as changed:
  * a record whose fingerprint differs from the one taken when the file was opened (box, flags,
    opacity, name, blend mode, which tagged blocks / channel data objects it holds), or
  * a record marked with mark() — the edits that change data inside a block in place (text,
    moved transforms, redrawn pixels): market_clone.edit_text_layer / move_layer / _swap_pixels,
    psd_pages.rename. mark_document() does the same for the document's blocks (Txt2).
A page whose layers were all copied raw is identical to the artist's by construction.

Raw copies also keep what psd-tools can't round-trip exactly (channels stored with length 0).
"""
import os
import struct
import threading

import attr

_LOCK = threading.Lock()
_SOURCES = {}          # id(document record) -> Source
_DIRTY = {}            # id(document record) -> {id(layer record): layer record}
_DOC_DIRTY = set()     # id(document record) whose document-level blocks were edited in place


class Source:
    def __init__(self, path, doc, records, channels, layer_info_end, lmi_end, version):
        self.path, self.doc, self.version = path, doc, version
        self.records = records           # id(record) -> (start, end) of its bytes in the source
        self.channels = channels         # id(channel list) -> (start, end)
        self.layer_info_end, self.lmi_end = layer_info_end, lmi_end
        self.fp_records, self.fp_channels, self.fp_doc = {}, {}, None


# ── fingerprints ──────────────────────────────────────────────────────────────
def _blocks_fp(blocks):
    if blocks is None:
        return None
    return tuple((str(k), id(b), id(getattr(b, "data", None))) for k, b in blocks.items())


def _record_fp(rec):
    return (rec.top, rec.left, rec.bottom, rec.right, rec.opacity, rec.clipping, str(rec.blend_mode), rec.name,
            attr.astuple(rec.flags), len(rec.channel_info), id(rec.mask_data), id(rec.blending_ranges),
            _blocks_fp(rec.tagged_blocks))


def _channels_fp(chans):
    return (len(chans), tuple((id(c), id(c.data), int(c.compression)) for c in chans))


def _doc_fp(lmi):
    return (id(lmi.global_layer_mask_info), _blocks_fp(lmi.tagged_blocks))


# ── the source index ──────────────────────────────────────────────────────────
def _index(path):
    """Byte ranges of the layer section of a PSD / PSB: [(record start, end, [channel lengths])],
    channel data ranges, the end of the layer info and of the layer & mask section."""
    with open(path, "rb") as f:
        head = f.read(26)
        if head[:4] != b"8BPS":
            raise ValueError("not a Photoshop file")
        version = struct.unpack(">H", head[4:6])[0]
        size, fmt = (4, ">I") if version == 1 else (8, ">Q")
        f.seek(struct.unpack(">I", f.read(4))[0], 1)                 # colour mode data
        f.seek(struct.unpack(">I", f.read(4))[0], 1)                 # image resources
        lmi_len = struct.unpack(fmt, f.read(size))[0]
        lmi_end = f.tell() + lmi_len
        if lmi_len == 0:
            return version, [], [], f.tell(), lmi_end
        li_len = struct.unpack(fmt, f.read(size))[0]
        li_end = f.tell() + li_len
        if li_len == 0:
            return version, [], [], li_end, lmi_end
        count = abs(struct.unpack(">h", f.read(2))[0])
        records = []
        for _ in range(count):
            start = f.tell()
            f.seek(16, 1)
            n = struct.unpack(">H", f.read(2))[0]
            lengths = []
            for _c in range(n):
                f.seek(2, 1)
                lengths.append(struct.unpack(fmt, f.read(size))[0])
            f.seek(12, 1)                                            # blend sig/key, opacity, clip, flags, filler
            f.seek(struct.unpack(">I", f.read(4))[0], 1)             # extra data
            records.append((start, f.tell(), lengths))
        chans = []
        for _s, _e, lengths in records:
            start = f.tell()
            f.seek(sum(lengths), 1)
            chans.append((start, f.tell()))
        if f.tell() > li_end:
            raise ValueError("layer section longer than its length says")
        return version, records, chans, li_end, lmi_end


def remember(psd, path):
    """Index `path`, the file `psd` (psd-tools, just opened, unchanged) was read from, so that
    write() can copy what an update leaves alone. Returns False when the file can't be indexed
    (then write() serializes everything, as psd-tools does)."""
    doc = psd._record
    info = doc.layer_and_mask_information.layer_info
    recs = list(info.layer_records) if info is not None else []
    chans = list(info.channel_image_data) if info is not None else []
    try:
        version, rec_ranges, chan_ranges, li_end, lmi_end = _index(path)
    except Exception:
        return False
    if len(rec_ranges) != len(recs) or len(chan_ranges) != len(chans) or version != doc.header.version:
        return False
    src = Source(os.path.abspath(path), doc, {id(r): rr[:2] for r, rr in zip(recs, rec_ranges)},
                 {id(c): cr for c, cr in zip(chans, chan_ranges)}, li_end, lmi_end, version)
    src.keep = (recs, chans)          # the objects stay alive: their ids keep meaning them
    src.fp_records = {id(r): _record_fp(r) for r in recs}
    src.fp_channels = {id(c): _channels_fp(c) for c in chans}
    src.fp_doc = _doc_fp(doc.layer_and_mask_information)
    with _LOCK:
        _SOURCES[id(doc)] = src
        _DIRTY[id(doc)] = {}
        _DOC_DIRTY.discard(id(doc))
    return True


def forget(psd):
    doc = psd._record
    with _LOCK:
        _SOURCES.pop(id(doc), None)
        _DIRTY.pop(id(doc), None)
        _DOC_DIRTY.discard(id(doc))


def _doc_of(layer_or_psd):
    psd = getattr(layer_or_psd, "_psd", None) or layer_or_psd
    return getattr(psd, "_record", None)


def mark(layer):
    """`layer`'s record (and pixels) changed in place: write it, don't copy it."""
    doc = _doc_of(layer)
    if doc is None:
        return
    with _LOCK:
        if id(doc) in _DIRTY:
            _DIRTY[id(doc)][id(layer._record)] = layer._record


def mark_document(psd_or_doc):
    """The document's own blocks (Photoshop's text block) changed in place."""
    doc = getattr(psd_or_doc, "_record", psd_or_doc)
    with _LOCK:
        _DOC_DIRTY.add(id(doc))


def known(psd):
    return id(psd._record) in _SOURCES


# ── writing ───────────────────────────────────────────────────────────────────
def _copy(src, dst, start, end, buf=8 << 20):
    src.seek(start)
    left = end - start
    while left > 0:
        chunk = src.read(min(buf, left))
        if not chunk:
            raise IOError("the source PSD ended early")
        dst.write(chunk)
        left -= len(chunk)


def write(psd, out_path):
    """Write `psd` to `out_path` copying every untouched part from the source it was read from
    (see remember). Returns {"raw": records copied, "written": records serialized, "doc": "raw" |
    "written", "clean": set of ids of records copied raw}."""
    doc = psd._record
    src = _SOURCES[id(doc)]
    dirty = _DIRTY.get(id(doc), {})
    version = doc.header.version
    size, fmt = (4, ">I") if version == 1 else (8, ">Q")
    lmi = doc.layer_and_mask_information
    info = lmi.layer_info
    recs = list(info.layer_records)
    chans = list(info.channel_image_data)
    raw_rec, raw_ch = [], []
    for rec, ch in zip(recs, chans):
        ok_ch = (id(ch) in src.channels and src.fp_channels.get(id(ch)) == _channels_fp(ch))
        ok_rec = (ok_ch and id(rec) in src.records and id(rec) not in dirty
                  and src.fp_records.get(id(rec)) == _record_fp(rec))
        raw_ch.append(ok_ch)
        raw_rec.append(ok_rec)
    # a record written again carries its channels' lengths (as psd-tools' _update_channel_length)
    for rec, ch, ok in zip(recs, chans, raw_rec):
        if not ok:
            for ci, length in zip(rec.channel_info, ch._lengths):
                ci.length = length
    doc_raw = id(doc) not in _DOC_DIRTY and src.fp_doc == _doc_fp(lmi)
    tmp = out_path + ".part"
    with open(src.path, "rb") as s, open(tmp, "wb") as f:
        doc.header.write(f)
        doc.color_mode_data.write(f)
        doc.image_resources.write(f, "macroman")
        lmi_at = f.tell()
        f.write(struct.pack(fmt, 0))
        li_at = f.tell()
        f.write(struct.pack(fmt, 0))
        body = f.tell()
        f.write(struct.pack(">h", info.layer_count))
        for rec, ok in zip(recs, raw_rec):
            if ok:
                _copy(s, f, *src.records[id(rec)])
            else:
                rec.write(f, "macroman", version)
        run = None                                    # consecutive raw channel ranges in one copy
        for ch, ok in zip(chans, raw_ch):
            if ok:
                a, b = src.channels[id(ch)]
                if run and run[1] == a:
                    run[1] = b
                    continue
                if run:
                    _copy(s, f, *run)
                run = [a, b]
            else:
                if run:
                    _copy(s, f, *run)
                    run = None
                ch.write(f)
        if run:
            _copy(s, f, *run)
        pad = (f.tell() - body) % 4
        if pad:
            f.write(b"\x00" * (4 - pad))
        li_end = f.tell()
        if doc_raw:
            _copy(s, f, src.layer_info_end, src.lmi_end)
        else:
            if lmi.global_layer_mask_info:
                lmi.global_layer_mask_info.write(f)
            if lmi.tagged_blocks:
                lmi.tagged_blocks.write(f, version=version, padding=4)
        lmi_end = f.tell()
        _copy(s, f, src.lmi_end, os.path.getsize(src.path))          # the composite image, as it was
        f.seek(li_at)
        f.write(struct.pack(fmt, li_end - body))
        f.seek(lmi_at)
        f.write(struct.pack(fmt, lmi_end - li_at))
    os.replace(tmp, out_path)
    return {"raw": sum(raw_rec), "written": len(recs) - sum(raw_rec), "doc": "raw" if doc_raw else "written",
            "clean": {id(r) for r, ok in zip(recs, raw_rec) if ok}}
