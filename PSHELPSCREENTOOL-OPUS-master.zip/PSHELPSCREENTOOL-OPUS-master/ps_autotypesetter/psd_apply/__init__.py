"""Changes to an existing PSD as a list of small operations, and the engines that carry them out.

The PSD updater decides (market_clone: what each layer shows, what the new AGR changes) and writes
the decision down as ops; an executor applies them. The same op list can go to the record executor
(records.py: psd-tools record surgery, no Photoshop) or, later, to Photoshop itself, which measures
text exactly. See DESIGN_PRESERVING_UPDATES.md, Phase 3.

Every op is a JSON-ready dict with "op" and the layers it touches as {"layer": <layer ID>,
"place": <index in psd.descendants()>} (by ID; the place only for a file whose IDs repeat).
"ref": [list name, index] points at the plan entry the outcome is written back to
(the_plan["items"], ["icon_edits"] or ["rows_added"]).

  set_text          {"layer", "place", "old", "text"}
                    A text layer's characters: each keeps the style run it had; point text that
                    would run too long is broken into lines first.
  remove_symbols    {"hide": [layer refs], "move": [layer refs with "dx", "dy"]}
                    Symbols gone from a row: their layers hidden, the rest of the row closed up.
  add_row           {"page", "page_key", "sheet", "row", "template": {layer ref, "paragraphs"},
                     "text", "symbols", "after": {layer ref, "paragraph"} | {"row": <row placed>}}
                    A row the new AGR added: a copy of the template row's paragraphs (and its
                    symbols) with the new text, under the row before it; what is below moves down.
                    Where it lands is measured by the executor.
  continue_if_over  {"page", "page_key", "sheet", "limit"}
                    The page now runs past `limit`: the rows past it move onto a Continued page.
  add_symbol        {"text": layer ref, "page", "symbols": [{"token", "at": [start, end], "sources": [layer refs]}]}
                    Symbols the new AGR added to a text: a copy of one of each one's pictures in the
                    PSD put into the gap left for it (its characters `at`), sized and sat like the
                    page's other icons; gaps are widened first when a picture is wider.
  flow_over         {"page", "limit"}
                    A page past the bottom of the artist's working area (`limit`): its last sections
                    (with their sub-heading) go onto the artist's own continued page — at the top of
                    its content, which moves down — and on from there; a new Continued page only
                    where the artist has none.
  edit_text         {"layer", "place", "key", "text"}
                    The artist's own wording from the preview.
  label             {"group", "color"}
                    A page group's colour in the Layers panel.
"""

OPS = ("set_text", "remove_symbols", "add_row", "continue_if_over", "add_symbol", "flow_over", "edit_text", "label")


def layer_ref(layer, place):
    return {"layer": layer.layer_id, "place": place}


class Layers:
    """Find a layer the way ops name it: by ID, or by place in a file whose IDs repeat."""

    def __init__(self, psd):
        self.all = list(psd.descendants())
        self.by_id, self.repeated = {}, set()
        for layer in self.all:
            if layer.layer_id in self.by_id:
                self.repeated.add(layer.layer_id)
            self.by_id.setdefault(layer.layer_id, layer)
        from ..artist_design import psd_render

        self.tops = psd_render.page_tops(psd)         # pages, also those in a group of pages

    def get(self, ref):
        lid, place = ref.get("layer"), ref.get("place")
        if lid not in self.repeated:
            return self.by_id.get(lid)
        got = self.all[place] if place is not None and 0 <= place < len(self.all) else None
        return got if got is not None and got.layer_id == lid else None

    def top_index(self, group_id):
        return next((i for i, t in enumerate(self.tops) if t.layer_id == group_id), None)
