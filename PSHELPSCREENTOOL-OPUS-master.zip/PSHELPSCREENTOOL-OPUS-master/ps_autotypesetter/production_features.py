from __future__ import annotations

import datetime
import json
import os
import re
import shutil
import time
from typing import Dict, Iterable, List, Optional

from openpyxl import load_workbook

from .diff_engine import compare_workbooks
from .icon_mapping import normalize_token, resolve_icon_path, scan_excel_icon_tokens


def _safe_name(value: str) -> str:
    cleaned = re.sub(r'[<>:"/\\|?*]+', "_", str(value or "").strip())
    return cleaned.strip(" .") or "Untitled"


def start_render_report(action: str, selected_pages: Optional[Iterable[str]] = None) -> Dict:
    return {
        "action": action,
        "started_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "render_time_seconds": 0.0,
        "output_psd_path": "",
        "rendered_pages": [],
        "skipped_pages": [],
        "updated_pages": [],
        "removed_pages": [],
        "selected_pages": list(selected_pages or []),
        "missing_icons": [],
        "warnings": [],
        "errors": [],
        "notes": [],
        "_start_time": time.time(),
    }


def finish_render_report(report: Dict, output_path: str = "") -> Dict:
    report["render_time_seconds"] = round(time.time() - float(report.get("_start_time", time.time())), 2)
    if output_path:
        report["output_psd_path"] = output_path
    report.pop("_start_time", None)
    return report


def format_render_report(report: Dict) -> str:
    lines = [
        "PsHelpScreenTool Render Report",
        "=" * 32,
        f"Action: {report.get('action', '')}",
        f"Started: {report.get('started_at', '')}",
        f"Render time: {report.get('render_time_seconds', 0)} seconds",
        f"Output PSD: {report.get('output_psd_path', '') or '(not saved)'}",
        "",
    ]

    def section(title: str, values: Iterable[str]):
        values = list(values or [])
        lines.append(title)
        lines.append("-" * len(title))
        if values:
            lines.extend(f"- {value}" for value in values)
        else:
            lines.append("- None")
        lines.append("")

    section("Rendered pages", report.get("rendered_pages", []))
    section("Skipped pages", report.get("skipped_pages", []))
    section("Updated pages", report.get("updated_pages", []))
    section("Removed pages", report.get("removed_pages", []))
    section("Missing icons", [f"<{v}>" for v in report.get("missing_icons", [])])
    section("Warnings", report.get("warnings", []))
    section("Errors", report.get("errors", []))
    section("Notes", report.get("notes", []))
    return "\n".join(lines).rstrip() + "\n"


def save_render_report(report: Dict, output_path: str = "", fallback_folder: str = "") -> str:
    folder = ""
    if output_path:
        folder = os.path.dirname(os.path.abspath(output_path))
    if not folder:
        folder = fallback_folder or os.getcwd()
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, "render_report.txt")
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(format_render_report(report))
    return path


def scan_icon_status(excel_path: str, icon_folder: str, icon_mappings: Optional[Dict[str, str]] = None,
                     icon_size_overrides: Optional[Dict[str, int]] = None) -> List[Dict[str, str]]:
    rows = []
    for token in scan_excel_icon_tokens(excel_path):
        override = ""
        for key, value in (icon_mappings or {}).items():
            if normalize_token(key) == normalize_token(token):
                override = str(value or "")
                break
        size = ""
        for key, value in (icon_size_overrides or {}).items():
            if normalize_token(key) == normalize_token(token):
                size = str(value or "")
                break
        resolved = resolve_icon_path(token, icon_folder, icon_mappings)
        rows.append({
            "token": token,
            "status": "Found" if resolved else "Missing",
            "path": resolved or "",
            "mapped": override,
            "size": size,
        })
    return rows


def missing_icon_tokens(excel_path: str, icon_folder: str, icon_mappings: Optional[Dict[str, str]] = None) -> List[str]:
    return [row["token"] for row in scan_icon_status(excel_path, icon_folder, icon_mappings) if row["status"] == "Missing"]


def preview_excel_tab(excel_path: str, sheet_name: str, max_col_limit: int = 20, max_rows: int = 60) -> str:
    if not excel_path or not os.path.isfile(excel_path):
        return "Select a valid Excel file first."
    wb = load_workbook(excel_path, data_only=False, read_only=True)
    try:
        if sheet_name not in wb.sheetnames:
            return "Select an Excel tab to preview."
        ws = wb[sheet_name]
        lines = [f"Preview: {sheet_name}", "=" * (9 + len(sheet_name))]
        token_hits = []
        non_empty_rows = 0
        for row_index, row in enumerate(ws.iter_rows(max_col=max_col_limit, values_only=True), start=1):
            values = ["" if value is None else str(value) for value in row]
            if not any(value.strip() for value in values):
                continue
            non_empty_rows += 1
            joined = " | ".join(value.strip() for value in values if value.strip())
            if joined:
                lines.append(f"{row_index:>3}: {joined[:220]}")
                token_hits.extend(re.findall(r"<([^<>]+)>", joined))
            if len(lines) >= max_rows:
                lines.append("...")
                break
        lines.append("")
        lines.append(f"Non-empty rows scanned: {non_empty_rows}")
        if token_hits:
            unique = []
            seen = set()
            for token in token_hits:
                key = normalize_token(token)
                if key not in seen:
                    unique.append(token)
                    seen.add(key)
            lines.append("Icon/dynamic tokens: " + ", ".join(f"<{token}>" for token in unique[:40]))
        else:
            lines.append("Icon/dynamic tokens: none detected")
        return "\n".join(lines)
    finally:
        try:
            wb.close()
        except Exception:
            pass


def excel_diff_summary(old_excel_path: str, new_excel_path: str, max_col_limit: int = 20) -> Dict[str, List[str]]:
    result = {"changed": [], "added": [], "removed": [], "unchanged": []}
    if not old_excel_path or not new_excel_path or not os.path.isfile(old_excel_path) or not os.path.isfile(new_excel_path):
        return result
    old_wb = load_workbook(old_excel_path, data_only=True)
    new_wb = load_workbook(new_excel_path, data_only=True)
    try:
        changes = compare_workbooks(old_wb, new_wb, max_col_limit)
        old_names = set(old_wb.sheetnames)
        new_names = set(new_wb.sheetnames)
        result["added"] = sorted(new_names - old_names)
        result["removed"] = sorted(old_names - new_names)
        result["changed"] = sorted([name for name in changes if name in old_names and name in new_names])
        result["unchanged"] = sorted([name for name in new_names if name not in changes])
        result["details"] = [f"{name}: {', '.join(changes[name][:5])}" for name in sorted(changes)]
        return result
    finally:
        try:
            old_wb.close()
            new_wb.close()
        except Exception:
            pass


def copy_psd_backup(psd_path: str, backup_folder: str = "") -> str:
    if not psd_path or not os.path.isfile(psd_path):
        return ""
    folder = backup_folder or os.path.join(os.path.dirname(os.path.abspath(psd_path)), "_BACKUP")
    os.makedirs(folder, exist_ok=True)
    root, ext = os.path.splitext(os.path.basename(psd_path))
    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    destination = os.path.join(folder, f"{root}_backup_{stamp}{ext}")
    shutil.copy2(psd_path, destination)
    return destination


def list_psd_top_level_groups(psd_path: str) -> List[str]:
    import photoshop.api as ps

    if not psd_path or not os.path.isfile(psd_path):
        raise ValueError("Select a valid PSD/PSB file first.")
    app = ps.Application()
    app.displayDialogs = ps.DialogModes.DisplayNoDialogs
    psd_js = json.dumps(os.path.abspath(psd_path))
    jsx = f"""
    (function() {{
        var psdFile = File({psd_js});
        if (!psdFile.exists) return "ERROR:PSD_NOT_FOUND";
        var doc = app.open(psdFile);
        var names = [];
        for (var i = 0; i < doc.layerSets.length; i++) {{
            var name = String(doc.layerSets[i].name || "");
            if (name && name !== "Asset_Cache_Hidden") names.push(name);
        }}
        doc.close(SaveOptions.DONOTSAVECHANGES);
        return names.join("\\n");
    }})();
    """
    result = app.doJavaScript(jsx)
    if not result:
        return []
    text = str(result)
    if text.startswith("ERROR:"):
        raise RuntimeError(text)
    return [line for line in text.splitlines() if line.strip()]


def batch_export_psd_groups(psd_path: str, output_folder: str, group_names: Optional[Iterable[str]] = None,
                            image_format: str = "PNG", jpg_quality: int = 90,
                            transparent: bool = True, suffix: str = "MyExport",
                            export_visible_groups: bool = True, export_visible_layers: bool = False,
                            bottom_to_top: bool = False) -> List[str]:
    import photoshop.api as ps

    if not psd_path or not os.path.isfile(psd_path):
        raise ValueError("Select a valid PSD/PSB file to export.")
    if not output_folder:
        raise ValueError("Select an output folder for exports.")
    if not export_visible_groups and not export_visible_layers:
        raise ValueError("Enable visible groups, visible layers, or both before exporting.")
    os.makedirs(output_folder, exist_ok=True)
    requested_format = str(image_format or "PNG").upper()
    if requested_format.startswith("J"):
        image_format = "JPG"
    elif requested_format == "PSD":
        image_format = "PSD"
    elif requested_format == "PDF":
        image_format = "PDF"
    else:
        image_format = "PNG"
    names_js = json.dumps(list(group_names or []))
    app = ps.Application()
    app.displayDialogs = ps.DialogModes.DisplayNoDialogs
    psd_js = json.dumps(os.path.abspath(psd_path))
    out_js = json.dumps(os.path.abspath(output_folder))
    quality = max(1, min(100, int(jpg_quality)))
    transparent_js = "true" if transparent else "false"
    suffix_js = json.dumps((suffix or "MyExport").strip() or "MyExport")
    export_groups_js = "true" if export_visible_groups else "false"
    export_layers_js = "true" if export_visible_layers else "false"
    bottom_to_top_js = "true" if bottom_to_top else "false"
    jsx = f"""
    (function() {{
        var psdFile = File({psd_js});
        var outFolder = Folder({out_js});
        if (!outFolder.exists) outFolder.create();
        var selected = {names_js};
        var suffix = {suffix_js};
        var format = "{image_format}";
        var exportGroups = {export_groups_js};
        var exportLayers = {export_layers_js};
        var bottomToTop = {bottom_to_top_js};
        var selectedMode = selected.length > 0;
        var selectedMap = {{}};
        for (var s = 0; s < selected.length; s++) selectedMap[selected[s]] = true;
        var doc = app.open(psdFile);
        var exported = [];
        var runningIndex = 1;

        function safeName(name) {{
            return String(name).replace(/[\\\\\\/:*?"<>|]/g, "_").replace(/^\\s+|\\s+$/g, "") || "Page";
        }}

        function isVisible(layer) {{
            while (layer) {{
                if (!layer.visible) return false;
                try {{
                    layer = layer.parent;
                    if (layer.typename === "Document") break;
                }} catch (e) {{
                    break;
                }}
            }}
            return true;
        }}

        function extensionFor(format) {{
            if (format === "JPG") return "jpg";
            if (format === "PSD") return "psd";
            if (format === "PDF") return "pdf";
            return "png";
        }}

        function exportFile(exportDoc, outFile, format) {{
            if (format === "PNG" || format === "JPG") {{
                var opts = new ExportOptionsSaveForWeb();
                if (format === "PNG") {{
                    opts.format = SaveDocumentType.PNG;
                    opts.PNG8 = false;
                    opts.transparency = {transparent_js};
                }} else {{
                    opts.format = SaveDocumentType.JPEG;
                    opts.quality = {quality};
                }}
                exportDoc.exportDocument(outFile, ExportType.SAVEFORWEB, opts);
                return;
            }}
            if (format === "PSD") {{
                var psdOptions = new PhotoshopSaveOptions();
                exportDoc.saveAs(outFile, psdOptions, true);
                return;
            }}
            if (format === "PDF") {{
                var pdfOptions = new PDFSaveOptions();
                exportDoc.saveAs(outFile, pdfOptions, true);
            }}
        }}

        function shouldInclude(layer) {{
            if (selected.length > 0 && selectedMap[layer.name] !== true) return false;
            if (layer.name === "Asset_Cache_Hidden") return false;
            return true;
        }}

        function exportLayer(layer, indexNumber) {{
            if (!shouldInclude(layer)) return false;
            if (!selectedMode && !isVisible(layer)) return false;
            var duplicate = doc.duplicate();
            for (var j = duplicate.layers.length - 1; j >= 0; j--) {{
                if (duplicate.layers[j].name !== layer.name) {{
                    duplicate.layers[j].remove();
                }}
            }}
            if (duplicate.layers.length > 0) duplicate.layers[0].visible = true;
            var fileName = safeName(suffix) + "_" + indexNumber + "." + extensionFor(format);
            var outFile = File(outFolder.fsName + "/" + fileName);
            exportFile(duplicate, outFile, format);
            exported.push(outFile.fsName);
            duplicate.close(SaveOptions.DONOTSAVECHANGES);
            return true;
        }}

        function exportCollection(collection, skipGroups) {{
            if (bottomToTop) {{
                for (var i = collection.length - 1; i >= 0; i--) {{
                    if (skipGroups && collection[i].typename === "LayerSet") continue;
                    if (selectedMode) {{
                        if (exportLayer(collection[i], runningIndex)) runningIndex++;
                    }} else {{
                        var currentIndex = runningIndex;
                        runningIndex++;
                        exportLayer(collection[i], currentIndex);
                    }}
                }}
            }} else {{
                for (var k = 0; k < collection.length; k++) {{
                    if (skipGroups && collection[k].typename === "LayerSet") continue;
                    if (selectedMode) {{
                        if (exportLayer(collection[k], runningIndex)) runningIndex++;
                    }} else {{
                        var forwardIndex = runningIndex;
                        runningIndex++;
                        exportLayer(collection[k], forwardIndex);
                    }}
                }}
            }}
        }}

        if (exportGroups) exportCollection(doc.layerSets, false);
        if (exportLayers) exportCollection(doc.layers, true);

        doc.close(SaveOptions.DONOTSAVECHANGES);
        return exported.join("\\n");
    }})();
    """
    result = app.doJavaScript(jsx)
    if not result:
        return []
    return [line for line in str(result).splitlines() if line.strip()]
