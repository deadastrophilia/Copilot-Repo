"""ps_fx_png.py — Photoshop layer styles rendered without Photoshop (PIL + numpy).

Renders a layer (text glyphs, or any RGBA pixels) with the readable Photoshop
layer-style params ("captured_params"; see fx_descriptor for the byte-exact
descriptor decoding) into a Pillow RGBA image. The browser renderer
static/ps_fx_canvas.js is a 1:1 port of this file — same pipeline, same math
(windowed exact distance field, 3-pass box blur, W3C blend formulas), so the
live canvas, the PNG output and the Photoshop "verify" render agree.

Paint order (bottom -> top), Photoshop's own stacking:

    drop shadows -> outer glows -> outside strokes -> layer fill ->
    pattern (skipped) -> gradient overlays -> colour overlays -> satin ->
    inner glows -> inner shadows -> centre / inside strokes -> bevel & emboss

Every effect kind may be a list (Photoshop "multiple effects"); index 0 is
the top-most entry and is painted last. Lengths follow Photoshop: a blur
"size" s becomes a Gaussian with sigma = 0.4 * s + 0.3, "spread"/"choke"
grow the shape by size * % before
the remaining size blurs it. Blend modes composite against the backdrop the
layer is drawn on (the page for PNG output). The constants were fitted to
Photoshop 2026 renders with tools/fx_fidelity_harness.py.
"""

import math

import numpy as np
from PIL import Image, ImageDraw

# --------------------------------------------------------------------------
# Normalization (mirror of ps_fx_canvas.js normalize())
# --------------------------------------------------------------------------

EFFECT_LISTS = (
    "drop_shadows", "outer_glows", "inner_shadows", "inner_glows", "strokes",
    "color_overlays", "gradient_overlays", "satins", "bevels", "pattern_overlays",
)


def _num(value, fallback):
    try:
        n = float(value)
        return n if math.isfinite(n) else float(fallback)
    except Exception:
        return float(fallback)


def _clamp(v, lo, hi):
    return max(lo, min(hi, v))


def _rgb(value, fallback):
    try:
        if isinstance(value, (list, tuple)) and len(value) >= 3:
            return [int(_clamp(round(_num(c, 0)), 0, 255)) for c in value[:3]]
    except Exception:
        pass
    if isinstance(value, str):
        import re

        m = re.fullmatch(r"#?([0-9a-fA-F]{6})", value.strip())
        if m:
            n = int(m.group(1), 16)
            return [(n >> 16) & 255, (n >> 8) & 255, n & 255]
    return list(fallback)


_BLEND_SHORT = {
    "NRML": "normal", "NORM": "normal", "MLTP": "multiply", "MULT": "multiply",
    "SCRN": "screen", "SCRE": "screen", "OVRL": "overlay", "OVER": "overlay",
    "SFTL": "soft-light", "SOFT": "soft-light", "HRDL": "hard-light", "HARD": "hard-light",
    "CDDG": "color-dodge", "DODG": "color-dodge", "CBRN": "color-burn", "BURN": "color-burn",
    "LNRD": "linear-dodge", "LIGH": "linear-dodge", "LNRB": "linear-burn",
    "DFRN": "difference", "DIFF": "difference", "XCLU": "exclusion", "EXCL": "exclusion",
    "DRKN": "darken", "LGHN": "lighten",
}
_BLEND_LONG = {
    "normal": "normal", "source-over": "normal", "dissolve": "normal",
    "multiply": "multiply", "screen": "screen", "overlay": "overlay",
    "soft light": "soft-light", "soft-light": "soft-light",
    "hard light": "hard-light", "hard-light": "hard-light",
    "color dodge": "color-dodge", "color-dodge": "color-dodge",
    "color burn": "color-burn", "color-burn": "color-burn",
    "linear dodge": "linear-dodge", "linear-dodge": "linear-dodge", "lighter": "linear-dodge",
    "add": "linear-dodge", "linear burn": "linear-burn", "linear-burn": "linear-burn",
    "darken": "darken", "lighten": "lighten", "difference": "difference",
    "exclusion": "exclusion", "vivid light": "vivid-light", "vivid-light": "vivid-light",
    "linear light": "linear-light", "linear-light": "linear-light",
    "pin light": "pin-light", "pin-light": "pin-light", "hard mix": "hard-mix",
    "hard-mix": "hard-mix", "subtract": "subtract", "divide": "divide",
}


def _blend_code(value):
    """Any blend spelling (PS long name, char code, canvas op) -> internal name."""
    if not isinstance(value, str):
        return "normal"
    up = value.strip().upper()
    if up in _BLEND_SHORT:
        return _BLEND_SHORT[up]
    return _BLEND_LONG.get(value.strip().lower(), "normal")


def _enabled(eff):
    return bool(eff and eff.get("enabled"))


def _stroke_pos(value):
    s = str(value or "outside").strip().lower()
    if s in ("center", "cntf", "ctrf", "centre"):
        return "center"
    if s in ("inside", "insf"):
        return "inside"
    return "outside"


def _as_list(value):
    if isinstance(value, dict):
        return [value]
    if isinstance(value, (list, tuple)):
        return [v for v in value if isinstance(v, dict)]
    return []


def _opacity01(value, fallback):
    return _clamp(_num(value, fallback), 0, 100) / 100.0


def _contour(value):
    if not isinstance(value, (list, tuple)) or len(value) < 2:
        return None
    pts = []
    for p in value:
        if isinstance(p, (list, tuple)) and len(p) >= 2:
            pts.append([_clamp(_num(p[0], 0), 0, 255), _clamp(_num(p[1], 0), 0, 255)])
    pts.sort(key=lambda q: q[0])
    return pts if len(pts) >= 2 else None


def _stops(colors):
    """[[rgb, loc01, mid01]] sorted, from [[rgb|hex, loc0-100, mid0-100?], ...]."""
    out = []
    for s in colors or []:
        if isinstance(s, (list, tuple)) and len(s) >= 2:
            mid = _num(s[2], 50) if len(s) >= 3 else 50.0
            out.append([_rgb(s[0], [255, 0, 0]), _clamp(_num(s[1], 0), 0, 100) / 100.0,
                        _clamp(mid, 1, 99) / 100.0])
    out.sort(key=lambda q: q[1])
    if not out:
        out = [[[0, 0, 0], 0.0, 0.5], [[255, 255, 255], 1.0, 0.5]]
    return out


def _trans_stops(trans):
    out = []
    for s in trans or []:
        if isinstance(s, (list, tuple)) and len(s) >= 2:
            mid = _num(s[2], 50) if len(s) >= 3 else 50.0
            out.append([_clamp(_num(s[0], 100), 0, 100) / 100.0, _clamp(_num(s[1], 0), 0, 100) / 100.0,
                        _clamp(mid, 1, 99) / 100.0])
    out.sort(key=lambda q: q[1])
    if not out or all(abs(s[0] - 1.0) < 1e-6 for s in out):
        return None
    return out


def _norm_gradient(g, default_angle=90.0):
    gtype = str(g.get("type") or "linear").strip().lower().replace(" ", "_")
    if gtype not in ("linear", "radial", "angle", "reflected", "diamond", "shape_burst"):
        gtype = "linear"
    off = g.get("offset") if isinstance(g.get("offset"), (list, tuple)) else [0, 0]
    return {
        "stops": _stops(g.get("colors")),
        "trans": _trans_stops(g.get("transparency")),
        "type": gtype,
        "angle": _num(g.get("angle", default_angle), default_angle),
        "scale": max(0.01, _num(g.get("scale", 100), 100) / 100.0),
        "reverse": bool(g.get("reverse")),
        "offset": [_num(off[0] if len(off) > 0 else 0, 0), _num(off[1] if len(off) > 1 else 0, 0)],
        "smooth": _clamp(_num(g.get("smoothness", 0), 0), 0, 100) / 100.0,
    }


def _norm_shadow(e, inner):
    return {
        "enabled": _enabled(e), "color": _rgb(e.get("color"), [0, 0, 0]),
        "opacity": _opacity01(e.get("opacity", 75 if not inner else 50), 75 if not inner else 50),
        "angle": _num(e.get("angle", 120), 120),
        "distance": _num(e.get("distance", 8 if not inner else 5), 8 if not inner else 5),
        "size": max(0.0, _num(e.get("size", 12 if not inner else 5), 12 if not inner else 5)),
        "spread": _clamp(_num(e.get("spread", e.get("choke", 0)), 0), 0, 100),
        "blend": _blend_code(e.get("blend")),
        "contour": _contour(e.get("contour")),
        "knockout": e.get("knockout") is not False,
    }


def _norm_glow(e, inner):
    return {
        "enabled": _enabled(e),
        "color": _rgb(e.get("color"), [255, 255, 255] if inner else [255, 255, 190]),
        "opacity": _opacity01(e.get("opacity", 50 if inner else 66), 50 if inner else 66),
        "size": max(0.0, _num(e.get("size", 8 if inner else 18), 8 if inner else 18)),
        "spread": _clamp(_num(e.get("spread", e.get("choke", 0)), 0), 0, 100),
        "blend": _blend_code(e.get("blend")),
        "contour": _contour(e.get("contour")),
        "range": _clamp(_num(e.get("range", 50), 50), 1, 100) / 100.0,
        "source": "center" if str(e.get("source") or "").lower() == "center" else "edge",
    }


def _norm_stroke(e):
    out = {
        "enabled": _enabled(e), "color": _rgb(e.get("color"), [255, 255, 255]),
        "opacity": _opacity01(e.get("opacity", 100), 100),
        "size": max(0.0, _num(e.get("size", 3), 3)), "position": _stroke_pos(e.get("position")),
        "blend": _blend_code(e.get("blend")), "gradient": None,
    }
    if str(e.get("fill_type") or "").lower() == "gradient" and isinstance(e.get("gradient"), dict):
        out["gradient"] = _norm_gradient(e["gradient"])
    return out


def _norm_bevel(e):
    style = str(e.get("style") or "inner").lower()
    if style not in ("inner", "outer", "emboss", "pillow", "stroke"):
        style = "inner"
    tech = str(e.get("technique") or "smooth").lower()
    if tech not in ("smooth", "chisel_hard", "chisel_soft"):
        tech = "smooth"
    return {
        "enabled": _enabled(e), "style": style, "technique": tech,
        "depth": _clamp(_num(e.get("depth", 100), 100), 1, 1000) / 100.0,
        "direction": "down" if str(e.get("direction") or "").lower() == "down" else "up",
        "size": max(0.0, _num(e.get("size", 5), 5)), "soften": max(0.0, _num(e.get("soften", 0), 0)),
        "angle": _num(e.get("angle", 120), 120), "altitude": _clamp(_num(e.get("altitude", 30), 30), 0, 90),
        "highlight_color": _rgb(e.get("highlight_color"), [255, 255, 255]),
        "highlight_opacity": _opacity01(e.get("highlight_opacity", 75), 75),
        "highlight_blend": _blend_code(e.get("highlight_blend", "screen")),
        "shadow_color": _rgb(e.get("shadow_color"), [0, 0, 0]),
        "shadow_opacity": _opacity01(e.get("shadow_opacity", 75), 75),
        "shadow_blend": _blend_code(e.get("shadow_blend", "multiply")),
        "contour": _contour(e.get("gloss_contour")),
    }


def _norm_satin(e):
    return {
        "enabled": _enabled(e), "color": _rgb(e.get("color"), [0, 0, 0]),
        "opacity": _opacity01(e.get("opacity", 50), 50), "blend": _blend_code(e.get("blend", "multiply")),
        "angle": _num(e.get("angle", 19), 19), "distance": _num(e.get("distance", 11), 11),
        "size": max(0.0, _num(e.get("size", 14), 14)), "invert": e.get("invert") is not False,
        "contour": _contour(e.get("contour")),
    }


def _source_params(raw):
    """captured_params dict to render from a style config / captured params."""
    if not isinstance(raw, dict):
        return {}
    if raw.get("captured_effects_hex") or isinstance(raw.get("effects_block"), dict):
        from . import fx_descriptor

        decoded = fx_descriptor.effective_params(raw)
        if isinstance(decoded, dict):
            merged = dict(raw)
            merged.update(decoded)
            return merged
    if isinstance(raw.get("captured_params"), dict):
        merged = dict(raw)
        merged.update(raw["captured_params"])
        return merged
    return raw


def normalize_params(raw):
    """Normalized effect dict (has_fx False when nothing renders).

    Accepts captured_params (single dicts or lists per effect kind), a full
    style config (captured_effects_hex / effects_block / captured_params /
    legacy flat stroke_enabled & shadow_enabled keys).
    """
    N = {"opacity": 1.0, "fill_opacity": 1.0, "fill_enabled": True, "has_fx": False}
    for key in EFFECT_LISTS:
        N[key] = []
    src = _source_params(raw)
    if src:
        from . import global_light

        src = global_light.apply(src)               # "Use Global Light" effects: the project's light
        N["opacity"] = _opacity01(src.get("opacity", 100), 100)
        N["fill_opacity"] = _opacity01(src.get("fill_opacity", 100), 100)
        N["fill_enabled"] = src.get("is_fill_enabled") is not False
        N["drop_shadows"] = [_norm_shadow(e, False) for e in _as_list(src.get("drop_shadow"))]
        N["inner_shadows"] = [_norm_shadow(e, True) for e in _as_list(src.get("inner_shadow"))]
        N["outer_glows"] = [_norm_glow(e, False) for e in _as_list(src.get("outer_glow"))]
        N["inner_glows"] = [_norm_glow(e, True) for e in _as_list(src.get("inner_glow"))]
        N["strokes"] = [_norm_stroke(e) for e in _as_list(src.get("stroke"))]
        N["color_overlays"] = [
            {"enabled": _enabled(e), "color": _rgb(e.get("color"), [255, 0, 0]),
             "opacity": _opacity01(e.get("opacity", 100), 100), "blend": _blend_code(e.get("blend"))}
            for e in _as_list(src.get("color_overlay"))]
        gos = []
        for e in _as_list(src.get("gradient_overlay")):
            g = _norm_gradient(e)
            g.update({"enabled": _enabled(e), "opacity": _opacity01(e.get("opacity", 100), 100),
                      "blend": _blend_code(e.get("blend"))})
            gos.append(g)
        N["gradient_overlays"] = gos
        N["satins"] = [_norm_satin(e) for e in _as_list(src.get("satin"))]
        N["bevels"] = [_norm_bevel(e) for e in _as_list(src.get("bevel"))]
        # Legacy flat fields (stroke_enabled / shadow_enabled ...)
        if not N["drop_shadows"] and src.get("shadow_enabled") is not None:
            N["drop_shadows"] = [{
                "enabled": bool(src.get("shadow_enabled")), "color": _rgb(src.get("shadow_rgb"), [0, 0, 0]),
                "opacity": _opacity01(src.get("shadow_opacity", 60), 60),
                "angle": _num(src.get("shadow_angle", 120), 120),
                "distance": _num(src.get("shadow_distance", 8), 8),
                "size": max(0.0, _num(src.get("shadow_size", 12), 12)),
                "spread": _clamp(_num(src.get("shadow_spread", 0), 0), 0, 100),
                "blend": _blend_code(src.get("shadow_blend_mode")), "contour": None, "knockout": True,
            }]
        if not N["strokes"] and src.get("stroke_enabled") is not None:
            N["strokes"] = [{
                "enabled": bool(src.get("stroke_enabled")), "color": _rgb(src.get("stroke_rgb"), [255, 255, 255]),
                "opacity": _opacity01(src.get("stroke_opacity", 100), 100),
                "size": max(0.0, _num(src.get("stroke_size", 3), 3)), "position": "outside",
                "blend": "normal", "gradient": None,
            }]
    for key in EFFECT_LISTS:
        N[key] = [e for e in N[key] if _enabled(e)]
    N["has_fx"] = any(N[key] for key in EFFECT_LISTS if key != "pattern_overlays")
    # historical single-effect view (first = top-most of each kind)
    for single, many in (("drop_shadow", "drop_shadows"), ("outer_glow", "outer_glows"),
                         ("inner_shadow", "inner_shadows"), ("inner_glow", "inner_glows"),
                         ("stroke", "strokes"), ("color_overlay", "color_overlays"),
                         ("gradient_overlay", "gradient_overlays"), ("satin", "satins"),
                         ("bevel", "bevels")):
        N[single] = N[many][0] if N[many] else None
    return N


def effect_pad(N):
    """Pixels the effects reach beyond the layer's ink (sprite padding)."""
    pad = 2.0
    for e in N["drop_shadows"]:
        pad = max(pad, abs(e["distance"]) + e["size"] + 2)
    for e in N["outer_glows"]:
        pad = max(pad, e["size"] + 2)
    for e in N["strokes"]:
        if e["position"] != "inside":
            pad = max(pad, e["size"] + 2)
    for e in N["bevels"]:
        if e["style"] != "inner":
            pad = max(pad, e["size"] + 2)
    return int(math.ceil(min(pad, 400)))


def _distance_reach(N):
    """Largest distance-field radius any effect needs (0 = no distance field)."""
    r = 0.0
    for e in N["drop_shadows"] + N["outer_glows"] + N["inner_shadows"] + N["inner_glows"]:
        r = max(r, e["size"] * e["spread"] / 100.0)
    for e in N["strokes"]:
        r = max(r, e["size"])
    for e in N["bevels"]:
        r = max(r, e["size"])
    return int(math.ceil(min(r, 400))) + 2 if r > 0 else 0


# --------------------------------------------------------------------------
# Pixel primitives (mirror of the ps_fx_canvas.js helpers)
# --------------------------------------------------------------------------


def _round(x):
    """JS Math.round (half up) — Python's round() is banker's rounding."""
    return int(math.floor(x + 0.5))


def size_sigma(size):
    """Photoshop blur size (px) -> Gaussian sigma (fitted with the fidelity harness)."""
    return 0.4 * size + 0.3 if size > 0 else 0.0


def _box_radii(sigma, n=3):
    """Box sizes whose n passes approximate a Gaussian (Kutskir)."""
    w_ideal = math.sqrt(12.0 * sigma * sigma / n + 1.0)
    wl = int(math.floor(w_ideal))
    if wl % 2 == 0:
        wl -= 1
    wu = wl + 2
    m = _round((12.0 * sigma * sigma - n * wl * wl - 4.0 * n * wl - 3.0 * n) / (-4.0 * wl - 4.0))
    return [((wl if i < m else wu) - 1) // 2 for i in range(n)]


def _box1d(a, r, axis):
    """Mean over a 2r+1 window along axis, zero outside the array."""
    n = a.shape[axis]
    pad = [(0, 0), (0, 0)]
    pad[axis] = (r + 1, r)
    c = np.cumsum(np.pad(a, pad), axis=axis, dtype=np.float64)
    if axis == 1:
        s = c[:, 2 * r + 1: 2 * r + 1 + n] - c[:, 0:n]
    else:
        s = c[2 * r + 1: 2 * r + 1 + n, :] - c[0:n, :]
    return (s / (2 * r + 1)).astype(np.float32)


def blur(a, sigma):
    if sigma < 0.3:
        return a
    out = a
    for r in _box_radii(sigma):
        if r > 0:
            out = _box1d(out, r, 1)
            out = _box1d(out, r, 0)
    return out


def _satin_mask(A, sigma, ox, oy):
    """|blur(A) shifted by (ox, oy) − shifted by (−ox, −oy)| on the layer's pixels.

    Worked out on a canvas big enough for the whole blur and both shifts: a satin's blur and
    distance are often far bigger than the layer (a 464px satin on a 240px card), and cutting the
    blur off at the layer's edge made the effect almost vanish where Photoshop brightens the card."""
    P = int(math.ceil(min(1600.0, max(abs(ox), abs(oy)) + 3.0 * sigma + 2.0)))
    big = np.pad(A, P)
    soft = blur(big, sigma)
    m = np.abs(_shift(soft, ox, oy, 0.0) - _shift(soft, -ox, -oy, 0.0))
    return m[P:P + A.shape[0], P:P + A.shape[1]]


def _shift(a, dx, dy, fill):
    """Integer-shift a 2-D array by (dx, dy); uncovered pixels get `fill`."""
    if dx == 0 and dy == 0:
        return a
    h, w = a.shape
    out = np.full_like(a, fill)
    if abs(dx) >= w or abs(dy) >= h:
        return out
    ys, yd = (slice(0, h - dy), slice(dy, h)) if dy >= 0 else (slice(-dy, h), slice(0, h + dy))
    xs, xd = (slice(0, w - dx), slice(dx, w)) if dx >= 0 else (slice(-dx, w), slice(0, w + dx))
    out[yd, xd] = a[ys, xs]
    return out


def _edt(seed, R, value=None):
    """Exact Euclidean distance (px) to the nearest seed pixel, capped at R + 1.

    With `value`, also returns the value of that nearest seed (a feature
    transform): ties keep the first candidate in pass order, which
    ps_fx_canvas.js follows exactly.
    """
    big = float((R + 1) * (R + 1))
    f = np.where(seed, 0.0, big).astype(np.float32)
    fv = np.where(seed, value, 0.0).astype(np.float32) if value is not None else None

    def sweep(src, srcv, axis):
        dst = src.copy()
        dstv = srcv.copy() if srcv is not None else None
        n = src.shape[axis]
        for d in range(1, min(R, n - 1) + 1):
            dd = float(d * d)
            for a, b in ((slice(d, None), slice(None, -d)), (slice(None, -d), slice(d, None))):
                ta, tb = ((slice(None), a), (slice(None), b)) if axis == 1 else ((a, slice(None)), (b, slice(None)))
                cand = src[tb] + dd
                if dstv is not None:
                    np.copyto(dstv[ta], srcv[tb], where=cand < dst[ta])
                np.minimum(dst[ta], cand, out=dst[ta])
        return dst, dstv

    g, gv = sweep(f, fv, 1)
    h, hv = sweep(g, gv, 0)
    dist = np.sqrt(np.minimum(h, big))
    return dist if value is None else (dist, hv)


class _Shape:
    """Layer alpha + its signed distance field (px, negative inside).

    Distances run to the anti-aliased 50 % contour: every seed pixel carries
    its own sub-pixel offset (0.5 - alpha), so a stroke or spread grows the
    shape like Photoshop's grey-level dilation and keeps its edge profile.
    """

    def __init__(self, alpha, reach):
        self.A = alpha
        self.R = int(reach)
        self._S = None

    @property
    def S(self):
        if self._S is None:
            A = self.A
            R = max(1, self.R)
            d_o, off_o = _edt(A > 0.0, R, 0.5 - A)
            d_i, off_i = _edt(A < 1.0, R, A - 0.5)
            self._S = np.where(A >= 0.5, -(d_i + off_i), d_o + off_o).astype(np.float32)
        return self._S

    def grow(self, r):
        """Coverage of the shape grown by r px (r <= 0: the shape itself)."""
        if r <= 0:
            return self.A.copy()
        return np.clip(r - self.S + 0.5, 0.0, 1.0)

    def shrink(self, r):
        if r <= 0:
            return self.A.copy()
        return np.clip(-self.S - r + 0.5, 0.0, 1.0)

    def outside_grown(self, r):
        """Coverage of the area outside the shape, grown inward by r px."""
        if r <= 0:
            return 1.0 - self.A
        return np.clip(self.S + r + 0.5, 0.0, 1.0)


def _apply_contour(m, contour):
    if not contour:
        return m
    xs = [p[0] / 255.0 for p in contour]
    ys = [p[1] / 255.0 for p in contour]
    return np.interp(m, xs, ys).astype(np.float32)


GRADIENT_TANGENT = 0.5     # Catmull-Rom tangent scale at 100 % smoothness


def _stop_tangents(stops, smooth):
    """Per-stop slopes (value per unit t) for smooth (Catmull-Rom) gradients."""
    n = len(stops)
    k = GRADIENT_TANGENT * smooth
    vals = [np.asarray(s[0], dtype=np.float32).reshape(-1) for s in stops]
    out = []
    for i in range(n):
        if k <= 0 or n < 2:
            out.append(np.zeros_like(vals[i]))
            continue
        a, b = max(0, i - 1), min(n - 1, i + 1)
        span = stops[b][1] - stops[a][1]
        out.append((vals[b] - vals[a]) / span * k if span > 1e-6 else np.zeros_like(vals[i]))
    return vals, out


def _interp_stops(t, stops, channels, smooth=0.0, hi=255.0):
    """Stop interpolation with Photoshop midpoints; `smooth` (0..1) bends the
    segments into a Catmull-Rom curve like Photoshop's gradient Smoothness."""
    vals, tans = _stop_tangents(stops, smooth)
    out = np.empty(t.shape + (channels,), dtype=np.float32)
    out[...] = vals[0]
    for i in range(len(stops) - 1):
        loc0, loc1, mid = stops[i][1], stops[i + 1][1], stops[i + 1][2]
        if loc1 <= loc0:
            continue
        sel = (t > loc0) & (t <= loc1)
        if not np.any(sel):
            continue
        h = loc1 - loc0
        u = (t[sel] - loc0) / h
        if abs(mid - 0.5) > 1e-6:
            u = np.where(u < mid, 0.5 * u / mid, 0.5 + 0.5 * (u - mid) / (1.0 - mid))
        u = u[:, None]
        u2, u3 = u * u, u * u * u
        seg = ((2 * u3 - 3 * u2 + 1) * vals[i] + (u3 - 2 * u2 + u) * (h * tans[i])
               + (3 * u2 - 2 * u3) * vals[i + 1] + (u3 - u2) * (h * tans[i + 1]))
        out[sel] = np.clip(seg, 0.0, hi)
    out[t > stops[-1][1]] = vals[-1]
    return out


def _gradient_t(g, shape, bounds, S=None, stroke_size=0.0, position="outside"):
    """Gradient parameter t (0..1) for every pixel of `shape` (H, W)."""
    h, w = shape
    x0, y0, x1, y1 = bounds
    bw, bh = max(1.0, x1 - x0), max(1.0, y1 - y0)
    cx = (x0 + x1) / 2.0 + g["offset"][0] / 100.0 * bw
    cy = (y0 + y1) / 2.0 + g["offset"][1] / 100.0 * bh
    X = np.arange(w, dtype=np.float32)[None, :] + 0.5 - cx
    Y = np.arange(h, dtype=np.float32)[:, None] + 0.5 - cy
    a = math.radians(g["angle"])
    dx, dy = math.cos(a), -math.sin(a)
    sc = g["scale"]
    span = abs(bw * dx) + abs(bh * dy)
    gtype = g["type"]
    if gtype == "shape_burst" and S is not None:
        size = max(1e-3, stroke_size)
        if position == "inside":
            t = -S / size
        elif position == "center":
            t = (S + size / 2.0) / size
        else:
            t = S / size
    elif gtype == "radial":
        t = np.sqrt(X * X + Y * Y) / max(1e-3, math.hypot(bw, bh) / 2.0 * sc)
    elif gtype == "angle":
        ang = np.arctan2(-Y, X) - a
        t = np.mod(ang / (2.0 * math.pi), 1.0)
    elif gtype == "reflected":
        t = np.abs(X * dx + Y * dy) / max(1e-3, span / 2.0 * sc)
    elif gtype == "diamond":
        u = X * dx + Y * dy
        v = -X * dy + Y * dx
        t = (np.abs(u) + np.abs(v)) / max(1e-3, span / 2.0 * sc)
    else:
        t = 0.5 + (X * dx + Y * dy) / max(1e-3, span * sc)
    t = np.broadcast_to(t, shape).astype(np.float32)
    if g["reverse"]:
        t = 1.0 - t
    return np.clip(t, 0.0, 1.0)


def _gradient_fill(g, shape, bounds, S=None, stroke_size=0.0, position="outside"):
    """(rgb (H,W,3) 0..1, alpha (H,W) 0..1) of a normalized gradient."""
    t = _gradient_t(g, shape, bounds, S, stroke_size, position)
    rgb = _interp_stops(t, g["stops"], 3, g["smooth"]) / 255.0
    alpha = None
    if g["trans"]:
        alpha = _interp_stops(t, [[[s[0]], s[1], s[2]] for s in g["trans"]], 1, g["smooth"], 1.0)[..., 0]
    return rgb, alpha


# --------------------------------------------------------------------------
# Blending / compositing (straight alpha, 0..1 floats)
# --------------------------------------------------------------------------


def _blend_colors(b, l, mode):
    """b backdrop, l layer colour (0..1). Returns the blended colour."""
    if mode == "multiply":
        return b * l
    if mode == "screen":
        return b + l - b * l
    if mode == "overlay":
        return np.where(b <= 0.5, 2.0 * b * l, 1.0 - 2.0 * (1.0 - b) * (1.0 - l))
    if mode == "hard-light":
        return np.where(l <= 0.5, 2.0 * b * l, 1.0 - 2.0 * (1.0 - b) * (1.0 - l))
    if mode == "soft-light":
        d = np.where(b <= 0.25, ((16.0 * b - 12.0) * b + 4.0) * b, np.sqrt(np.maximum(b, 0.0)))
        return np.where(l <= 0.5, b - (1.0 - 2.0 * l) * b * (1.0 - b), b + (2.0 * l - 1.0) * (d - b))
    if mode == "color-dodge":
        return np.where(b <= 0.0, 0.0, np.where(l >= 1.0, 1.0, np.minimum(1.0, b / np.maximum(1e-6, 1.0 - l))))
    if mode == "color-burn":
        return np.where(b >= 1.0, 1.0, np.where(l <= 0.0, 0.0, 1.0 - np.minimum(1.0, (1.0 - b) / np.maximum(1e-6, l))))
    if mode == "linear-dodge":
        return np.minimum(1.0, b + l)
    if mode == "linear-burn":
        return np.maximum(0.0, b + l - 1.0)
    if mode == "darken":
        return np.minimum(b, l)
    if mode == "lighten":
        return np.maximum(b, l)
    if mode == "difference":
        return np.abs(b - l)
    if mode == "exclusion":
        return b + l - 2.0 * b * l
    if mode == "subtract":
        return np.maximum(0.0, b - l)
    if mode == "divide":
        return np.where(l <= 0.0, 1.0, np.minimum(1.0, b / np.maximum(1e-6, l)))
    if mode == "linear-light":
        return np.clip(b + 2.0 * l - 1.0, 0.0, 1.0)
    if mode == "vivid-light":
        burn = np.where(l <= 0.0, 0.0, 1.0 - np.minimum(1.0, (1.0 - b) / np.maximum(1e-6, 2.0 * l)))
        dodge = np.where(l >= 1.0, 1.0, np.minimum(1.0, b / np.maximum(1e-6, 2.0 * (1.0 - l))))
        return np.where(l <= 0.5, burn, dodge)
    if mode == "pin-light":
        return np.where(l <= 0.5, np.minimum(b, 2.0 * l), np.maximum(b, 2.0 * l - 1.0))
    if mode == "hard-mix":
        return np.where(b + l >= 1.0, 1.0, 0.0)
    return np.broadcast_to(l, np.broadcast(b, l).shape)


def _composite(out, color, alpha, mode):
    """Composite a colour (3-vector or (H,W,3)) with coverage `alpha` onto out (in place)."""
    a_s = np.clip(alpha, 0.0, 1.0)
    if not np.any(a_s > 0.0):
        return out
    a_s = a_s[..., None]
    cb = out[..., :3]
    ab = out[..., 3:4]
    cs = np.asarray(color, dtype=np.float32)
    if mode == "normal":
        mixed = np.broadcast_to(cs, cb.shape)
    else:
        mixed = (1.0 - ab) * cs + ab * _blend_colors(cb, cs, mode)
    co = a_s * mixed + (1.0 - a_s) * ab * cb
    ao = a_s + ab * (1.0 - a_s)
    hit = a_s > 0.0
    out[..., :3] = np.where(hit, np.where(ao > 1e-6, co / np.maximum(ao, 1e-6), 0.0), cb)
    out[..., 3:4] = np.where(hit, ao, ab)
    return out


def _rgb01(rgb):
    return np.asarray(rgb, dtype=np.float32) / 255.0


# --------------------------------------------------------------------------
# The effects pipeline
# --------------------------------------------------------------------------


def _ink_bounds(A):
    ys, xs = np.nonzero(A > 0.004)
    if len(xs) == 0:
        h, w = A.shape
        return (0.0, 0.0, float(w), float(h))
    return (float(xs.min()), float(ys.min()), float(xs.max() + 1), float(ys.max() + 1))


def _offset(angle, distance):
    a = math.radians(angle)
    return _round(-math.cos(a) * distance), _round(math.sin(a) * distance)


# Bevel / glow calibration against Photoshop (tools/fx_fidelity_harness.py);
# ps_fx_canvas.js carries the same numbers.
BEVEL_SLOPE = 1.0          # height (px) per px of bevel size at depth 100 %
BEVEL_HI_GAIN = 1.0        # highlight strength
BEVEL_LO_GAIN = 1.0        # shadow strength
SMOOTH_SIGMA = 0.35        # smooth bevel: sigma = SMOOTH_SIGMA * size + 0.3
CHISEL_SLOPE = 0.5         # chisel bevels are gentler than their distance ramp
CHISEL_BLUR = 1.0          # sigma smoothing the chisel-hard distance ramp
EMBOSS_REACH = 0.5         # emboss / pillow: share of the size on each side of the edge
EMBOSS_SLOPE = 0.5         # emboss / pillow are gentler than an inner / outer bevel


def _bevel_layers(e, shape):
    """(highlight, shadow, outside region or None, lights the inside?) of one bevel.

    highlight / shadow are unmasked; the caller applies them inside the layer
    (interior pass) and/or outside it (`outside region`, under the layer).
    """
    size = max(1.0, e["size"])
    S = shape.S
    A = shape.A
    style = e["style"]
    reach = size * EMBOSS_REACH
    if style == "outer":
        outside, inside = shape.grow(size), False
        lin = np.clip(1.0 - S / size, 0.0, 1.0)
        smooth_src, smooth_r = A, size
    elif style in ("emboss", "stroke"):
        outside, inside = shape.grow(reach), True
        lin = np.clip(0.5 - S / (2.0 * reach), 0.0, 1.0)
        smooth_src, smooth_r = A, reach
    elif style == "pillow":
        # the edge is pressed in: a valley rising inward and outward
        outside, inside = shape.grow(reach), True
        lin = np.clip(np.abs(S) / (2.0 * reach), 0.0, 1.0)
        smooth_src, smooth_r = None, reach
    else:
        outside, inside = None, True
        lin = np.clip(-S / size, 0.0, 1.0)
        smooth_src, smooth_r = A, size
    smooth_sigma = SMOOTH_SIGMA * smooth_r + 0.3
    slope = BEVEL_SLOPE
    if e["technique"] == "smooth" and smooth_src is not None:
        height = blur(smooth_src, smooth_sigma)
    elif e["technique"] == "smooth":
        height = np.abs(blur(A, smooth_sigma) - 0.5)
    elif e["technique"] == "chisel_soft":
        height = blur(lin, CHISEL_BLUR * 2.0)
        slope = BEVEL_SLOPE * CHISEL_SLOPE
    else:
        height = blur(lin, CHISEL_BLUR)
        slope = BEVEL_SLOPE * CHISEL_SLOPE
    if style in ("emboss", "stroke", "pillow"):
        slope *= EMBOSS_SLOPE
    if e["soften"] > 0:
        height = blur(height, size_sigma(e["soften"]))
    if e["direction"] == "down":
        height = 1.0 - height
    z = height * (size * e["depth"] * slope)
    zp = np.pad(z, 1, mode="edge")
    gx = ((zp[:-2, 2:] + 2.0 * zp[1:-1, 2:] + zp[2:, 2:]) - (zp[:-2, :-2] + 2.0 * zp[1:-1, :-2] + zp[2:, :-2])) / 8.0
    gy = ((zp[2:, :-2] + 2.0 * zp[2:, 1:-1] + zp[2:, 2:]) - (zp[:-2, :-2] + 2.0 * zp[:-2, 1:-1] + zp[:-2, 2:])) / 8.0
    a = math.radians(e["angle"])
    alt = math.radians(e["altitude"])
    lx, ly, lz = math.cos(alt) * math.cos(a), -math.cos(alt) * math.sin(a), math.sin(alt)
    shade = (-gx * lx - gy * ly + lz) / np.sqrt(gx * gx + gy * gy + 1.0)
    if e["contour"]:
        shade = _apply_contour(np.clip(shade, 0.0, 1.0), e["contour"])
    hi = np.clip((shade - lz) / max(1e-3, 1.0 - lz) * BEVEL_HI_GAIN, 0.0, 1.0)
    lo = np.clip((lz - shade) / max(1e-3, lz) * BEVEL_LO_GAIN, 0.0, 1.0)
    return hi, lo, outside, inside


def _glow_range(m, e):
    """Photoshop glow "Range": the contour spans the first `range` of the falloff."""
    return np.clip(m / max(0.01, e["range"]), 0.0, 1.0)


def _merge(under, part, A):
    """Pixel = A of the layer interior (`part`) + (1 - A) of what lies around it."""
    pa = part[..., 3:4] * A[..., None]
    ua = under[..., 3:4] * (1.0 - A[..., None])
    ao = pa + ua
    out = np.empty_like(under)
    out[..., :3] = np.where(ao > 1e-6, (part[..., :3] * pa + under[..., :3] * ua) / np.maximum(ao, 1e-6),
                            under[..., :3])
    out[..., 3:4] = ao
    return out


def render_effects(content, params, backdrop=None, bounds=None):
    """Apply a layer style to a layer's pixels.

    content:  float32 (H, W, 4) straight RGBA 0..1 — the layer itself, with
              room around the ink for outer effects (see effect_pad).
    backdrop: float32 (H, W, 4) the layer is composited onto (None = transparent).
    bounds:   (x0, y0, x1, y1) the gradients span (default: the ink bounds).
    Returns the composited float32 (H, W, 4).

    Like Photoshop, effects outside the shape (shadows, outer glow, outside
    strokes, outer bevel) paint "under" the layer and interior effects
    (fill, overlays, satin, inner glow / shadow, inside strokes, inner bevel)
    paint the layer's own region; a pixel takes the layer's coverage of the
    interior and the rest of what lies around it, so anti-aliased edges keep
    exactly the layer's coverage.
    """
    N = params if isinstance(params, dict) and "strokes" in params and "has_fx" in params else normalize_params(params)
    content = np.asarray(content, dtype=np.float32)
    A = np.clip(content[..., 3], 0.0, 1.0)
    C = content[..., :3]
    under = np.zeros_like(content) if backdrop is None else np.array(backdrop, dtype=np.float32, copy=True)
    shape = _Shape(A, _distance_reach(N))
    layer_a = N["opacity"]
    if bounds is None:
        bounds = _ink_bounds(A)
    knock = (1.0 - A) if N["fill_opacity"] < 1.0 or not N["fill_enabled"] else None
    ones = np.ones(A.shape, dtype=np.float32)

    # ---- below the layer
    for e in reversed(N["drop_shadows"]):
        spread_r = e["size"] * e["spread"] / 100.0
        m = blur(shape.grow(spread_r), size_sigma(e["size"] - spread_r))
        dx, dy = _offset(e["angle"], e["distance"])
        m = _apply_contour(_shift(m, dx, dy, 0.0), e["contour"])
        if knock is not None and e["knockout"]:
            m = m * knock
        _composite(under, _rgb01(e["color"]), m * e["opacity"] * layer_a, e["blend"])

    for e in reversed(N["outer_glows"]):
        spread_r = e["size"] * e["spread"] / 100.0
        m = _apply_contour(_glow_range(blur(shape.grow(spread_r), size_sigma(e["size"] - spread_r)), e), e["contour"])
        if knock is not None:
            m = m * knock
        _composite(under, _rgb01(e["color"]), m * e["opacity"] * layer_a, e["blend"])

    # the layer interior starts from what lies beneath it
    part = under.copy()

    def stroke_color(e):
        if e["gradient"] is None:
            return _rgb01(e["color"]), None
        # a stroke's gradient spans the layer bounds grown by the stroke
        g = {"outside": e["size"], "center": e["size"] / 2.0}.get(e["position"], 0.0)
        sb = (bounds[0] - g, bounds[1] - g, bounds[2] + g, bounds[3] + g)
        return _gradient_fill(e["gradient"], A.shape, sb,
                              shape.S if e["gradient"]["type"] == "shape_burst" else None, e["size"], e["position"])

    # ---- around the layer: outside strokes, outer half of centre strokes
    for e in reversed(N["strokes"]):
        if e["position"] == "inside":
            continue
        m = shape.grow(e["size"] if e["position"] == "outside" else e["size"] / 2.0)
        color, galpha = stroke_color(e)
        if galpha is not None:
            m = m * galpha
        _composite(under, color, m * e["opacity"] * layer_a, e["blend"])

    # ---- the layer interior
    if N["fill_enabled"]:
        _composite(part, C, ones * (N["fill_opacity"] * layer_a), "normal")

    for e in reversed(N["gradient_overlays"]):
        rgb, galpha = _gradient_fill(e, A.shape, bounds)
        m = ones if galpha is None else galpha
        _composite(part, rgb, m * e["opacity"] * layer_a, e["blend"])

    for e in reversed(N["color_overlays"]):
        _composite(part, _rgb01(e["color"]), ones * (e["opacity"] * layer_a), e["blend"])

    for e in reversed(N["satins"]):
        a = math.radians(e["angle"])
        ox, oy = _round(math.cos(a) * e["distance"]), _round(-math.sin(a) * e["distance"])
        m = _satin_mask(A, size_sigma(e["size"]), ox, oy)
        if e["invert"]:
            m = 1.0 - m
        m = _apply_contour(np.clip(m, 0.0, 1.0), e["contour"])
        _composite(part, _rgb01(e["color"]), m * e["opacity"] * layer_a, e["blend"])

    for e in reversed(N["inner_glows"]):
        choke_r = e["size"] * e["spread"] / 100.0
        m = blur(shape.outside_grown(choke_r), size_sigma(e["size"] - choke_r))
        if e["source"] == "center":
            m = 1.0 - m
        m = _apply_contour(_glow_range(np.clip(m, 0.0, 1.0), e), e["contour"])
        _composite(part, _rgb01(e["color"]), m * e["opacity"] * layer_a, e["blend"])

    for e in reversed(N["inner_shadows"]):
        choke_r = e["size"] * e["spread"] / 100.0
        m = blur(shape.outside_grown(choke_r), size_sigma(e["size"] - choke_r))
        dx, dy = _offset(e["angle"], e["distance"])
        m = _apply_contour(_shift(m, dx, dy, 1.0), e["contour"])
        _composite(part, _rgb01(e["color"]), m * e["opacity"] * layer_a, e["blend"])

    for e in reversed(N["strokes"]):
        if e["position"] == "outside":
            continue
        m = 1.0 - shape.shrink(e["size"] if e["position"] == "inside" else e["size"] / 2.0)
        color, galpha = stroke_color(e)
        if galpha is not None:
            m = m * galpha
        _composite(part, color, m * e["opacity"] * layer_a, e["blend"])

    for e in reversed(N["bevels"]):
        hi, lo, outside, inside = _bevel_layers(e, shape)
        targets = ([(part, 1.0)] if inside else []) + ([(under, outside)] if outside is not None else [])
        for target, region in targets:
            _composite(target, _rgb01(e["shadow_color"]), lo * region * e["shadow_opacity"] * layer_a,
                       e["shadow_blend"])
            _composite(target, _rgb01(e["highlight_color"]), hi * region * e["highlight_opacity"] * layer_a,
                       e["highlight_blend"])

    return _merge(under, part, A)


# --------------------------------------------------------------------------
# PIL front ends
# --------------------------------------------------------------------------


def _to_float(img):
    return np.asarray(img.convert("RGBA"), dtype=np.float32) / 255.0


def _to_image(arr):
    return Image.fromarray(np.clip(np.rint(arr * 255.0), 0, 255).astype(np.uint8))


def render_layer_image(img, params, pad=None, backdrop=None):
    """(styled RGBA image, pad) for a layer image; pad pixels added on every side.

    Returns (None, 0) when the params render nothing.
    """
    N = normalize_params(params)
    if not N["has_fx"]:
        return None, 0
    if pad is None:
        pad = effect_pad(N)
    src = img.convert("RGBA")
    canvas = Image.new("RGBA", (src.width + 2 * pad, src.height + 2 * pad), (0, 0, 0, 0))
    canvas.paste(src, (pad, pad))
    back = None if backdrop is None else _to_float(backdrop)
    return _to_image(render_effects(_to_float(canvas), N, back)), pad


def render_captured_params_text(base, x, y, text, font, fill_rgb, params, box_w=None, box_h=None):
    """Draw `text` with a layer style onto RGBA `base`.

    `params` is captured_params or a whole style config (descriptor hex,
    captured_params, legacy flat keys). (x, y) is the Pillow text anchor the
    plain renderer would use, so the styled ink lands exactly where unstyled
    text would. Blend modes composite against `base`. Returns True when any
    effect was drawn.
    """
    if base is None or not text:
        return False
    N = normalize_params(params)
    if not N["has_fx"]:
        return False
    text = str(text)
    if not text.strip():
        return False
    fill_rgb = _rgb(fill_rgb, [255, 80, 80])
    pad = effect_pad(N)
    res = None
    if getattr(font, "path", None):
        # glyph coverage exactly as Photoshop rasterises the text (ps_text); the
        # effects are then built from the same pixels Photoshop styles
        from . import ps_text

        res = ps_text.coverage([(text, font, float(x), float(y) + font.getmetrics()[0], 0.0)], pad=pad)
    if res is not None:
        glyph, ox, oy = res
        iw, ih = glyph.size
    else:
        try:
            bbox = font.getbbox(text)
        except Exception:
            bbox = (0, 0, int(font.getlength(text)), int(font.size * 1.2))
        iw = int(max(1, bbox[2] - bbox[0]) + pad * 2)
        ih = int(max(1, bbox[3] - bbox[1]) + pad * 2)
        glyph = Image.new("L", (iw, ih), 0)
        ImageDraw.Draw(glyph).text((pad - bbox[0], pad - bbox[1]), text, font=font, fill=255)
        ox = int(math.floor(x)) - pad + bbox[0]
        oy = int(math.floor(y)) - pad + bbox[1]
    content = np.zeros((ih, iw, 4), dtype=np.float32)
    content[..., :3] = np.asarray(fill_rgb, dtype=np.float32) / 255.0
    content[..., 3] = np.asarray(glyph, dtype=np.float32) / 255.0
    bw, bh = base.size
    x0, y0 = max(0, ox), max(0, oy)
    x1, y1 = min(bw, ox + iw), min(bh, oy + ih)
    if x1 <= x0 or y1 <= y0:
        return True
    backdrop = np.zeros((ih, iw, 4), dtype=np.float32)
    backdrop[y0 - oy:y1 - oy, x0 - ox:x1 - ox] = _to_float(base.crop((x0, y0, x1, y1)))
    bounds = None
    if box_w and box_h and box_w > 0 and box_h > 0:
        bounds = (float(pad), float(pad), float(pad + box_w), float(pad + box_h))
    out = render_effects(content, N, backdrop, bounds)
    base.paste(_to_image(out[y0 - oy:y1 - oy, x0 - ox:x1 - ox]), (x0, y0))
    return True
