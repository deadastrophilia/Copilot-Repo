"""Mapping model for artist-authored @table component JSON."""

import copy
import json
import os
import re
from collections import OrderedDict

from openpyxl import load_workbook
from openpyxl.utils import get_column_letter, range_boundaries, column_index_from_string

from .icon_mapping import resolve_icon_path
from .table_detector import detect_tables_in_sheet


_TOKEN = re.compile(r"<\s*([^>]+?)\s*>")
_TABLE_MARKER = re.compile(r"<\s*table\s*:\s*([^>]+?)\s*>", re.IGNORECASE)
_DIRECT_RANGE = re.compile(r"^\s*([A-Za-z]+)(\d+)(?::([A-Za-z]+)(\d+))?\s*$")
_CELL_REF_RE = re.compile(
    r"^(?:@table\.)?([A-Za-z]{1,3})(\d+)(?::([A-Za-z]{1,3})(\d+))?$",
    re.IGNORECASE,
)


def _text(value):
    return "" if value is None else str(value).strip()


def _tokens(value):
    return [token.strip() for token in _TOKEN.findall(str(value or ""))]


def _safe_int(value, fallback=0):
    try:
        return int(float(value))
    except Exception:
        return int(fallback)


def _safe_float(value, fallback=0.0):
    try:
        return float(value)
    except Exception:
        return float(fallback)


def _column_index(col_letter):
    """Convert column letter(s) to 1-based index, e.g. 'A' -> 1, 'AA' -> 27."""
    result = 0
    for c in col_letter.upper():
        result = result * 26 + (ord(c) - 64)
    return result


def _iter_column_letters(start_col, end_col):
    """Yield column letters from start_col to end_col inclusive."""
    start_num = _column_index(start_col)
    end_num = _column_index(end_col)
    for num in range(start_num, end_num + 1):
        n = num
        col = ""
        while n > 0:
            n, remainder = divmod(n - 1, 26)
            col = chr(65 + remainder) + col
        yield col


def parse_table_slot_ref(slot_name):
    """
    Parse a slot name that references an Excel cell or range.

    Returns (col1, row1, col2, row2) tuple if matched, or None.

    Examples:
        '@table.B22'      -> ('B', 22, 'B', 22)
        '@table.D8:J22'   -> ('D', 8, 'J', 22)
        'B22'              -> ('B', 22, 'B', 22)
        'cashExpress'      -> None
    """
    m = _CELL_REF_RE.match(str(slot_name).strip())
    if not m:
        return None
    col1 = m.group(1).upper()
    row1 = int(m.group(2))
    col2 = (m.group(3) or m.group(1)).upper()
    row2 = int(m.group(4)) if m.group(4) else row1
    return col1, row1, col2, row2


def resolve_excel_ref(ws, cell_ref):
    """
    Given a parsed cell ref tuple from parse_table_slot_ref, read the cell/range content.

    Returns a dict with:
        'text': combined cell text
        'has_tokens': bool
        'kind': inferred mapping kind
    Or None if the ref is invalid.
    """
    if isinstance(cell_ref, str):
        cell_ref = parse_table_slot_ref(cell_ref)
    if not cell_ref:
        return None

    col1, row1, col2, row2 = cell_ref
    text_parts = []
    has_tokens = False

    for r in range(row1, row2 + 1):
        for c in _iter_column_letters(col1, col2):
            cell = ws[f"{c}{r}"]
            val = str(cell.value or "").strip()
            text_parts.append(val)
            if "<" in val and ">" in val:
                has_tokens = True

    text = " ".join(text_parts)

    kind = "flow"
    if not has_tokens:
        non_empty = [p for p in text_parts if p]
        if len(non_empty) == 1 and non_empty[0].lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.bmp', '.svg')):
            kind = "dedicated_icon"

    return {
        "text": text,
        "has_tokens": has_tokens,
        "kind": kind,
    }


_VALID_SLOT_KEYS = {"x", "y", "w", "h"}
_VALID_KINDS = {"text", "flow", "icon", "dedicated_icon", "inline_token", "background"}
_VALID_INSERT_MODES = {"after_row", "absolute", "range_start", "source_start", "marker"}
_VALID_FIT_MODES = {"scale", "absolute", "next_page", "move_to_next_page"}
_VALID_ALIGNMENTS = {"left", "center", "right"}
_VALID_VERTICAL = {"top", "center", "bottom"}


def validate_table_template(template, path=""):
    """Validate raw (unmapped) table JSON structure. Returns (errors, warnings)."""
    errors = []
    warnings = []
    label = os.path.basename(path) if path else "JSON"

    if not isinstance(template, dict):
        errors.append(f"{label}: Root must be a JSON object, got {type(template).__name__}.")
        return errors, warnings

    canvas = template.get("canvas")
    if not isinstance(canvas, dict):
        errors.append(f"{label}: Missing 'canvas' object.")
    else:
        if not isinstance(canvas.get("width"), (int, float)) or canvas["width"] <= 0:
            errors.append(f"{label}: canvas.width must be a positive number.")
        if not isinstance(canvas.get("height"), (int, float)) or canvas["height"] <= 0:
            errors.append(f"{label}: canvas.height must be a positive number.")

    slots = template.get("slots") or template.get("table_slots")
    if not isinstance(slots, dict) or not slots:
        errors.append(f"{label}: Missing 'slots' (exported PSD slot boxes).")
    else:
        for slot_name, box in slots.items():
            if not isinstance(box, dict):
                errors.append(f"{label}: Slot '{slot_name}' must be an object with x/y/w/h.")
                continue
            missing = _VALID_SLOT_KEYS - set(box.keys())
            if missing:
                errors.append(f"{label}: Slot '{slot_name}' is missing keys: {', '.join(sorted(missing))}.")
            for key in _VALID_SLOT_KEYS:
                val = box.get(key)
                if val is not None and not isinstance(val, (int, float)):
                    try:
                        float(val)
                    except (TypeError, ValueError):
                        errors.append(f"{label}: Slot '{slot_name}' key '{key}' is not numeric: {val!r}.")

    table_templates = template.get("table_templates")
    if table_templates is not None:
        if not isinstance(table_templates, dict):
            errors.append(f"{label}: 'table_templates' must be a dict, got {type(table_templates).__name__}.")
        else:
            for tname, spec in table_templates.items():
                spec_errors, spec_warnings = _validate_table_spec(spec, tname, label, slots or {})
                errors.extend(spec_errors)
                warnings.extend(spec_warnings)

    if slots and table_templates and isinstance(table_templates, dict):
        slot_set = {str(n).casefold() for n in (slots or {})}
        for tname, spec in table_templates.items():
            if not isinstance(spec, dict):
                continue
            for mapping in spec.get("mappings") or []:
                if not isinstance(mapping, dict):
                    continue
                slot = str(mapping.get("slot") or "").strip()
                if slot and ".rowtemplate." not in slot.casefold() and slot.casefold() not in slot_set:
                    warnings.append(f"{label}: Mapping in '{tname}' references slot '{slot}' not found in template slots.")

    if not table_templates and not (template.get("flow_regions") or template.get("token_bindings")):
        warnings.append(f"{label}: No 'table_templates', 'flow_regions', or 'token_bindings' found. The JSON may not produce output.")

    return errors, warnings


def _validate_table_spec(spec, table_name, file_label, template_slots):
    """Validate a single table_templates entry. Returns (errors, warnings)."""
    errors = []
    warnings = []
    prefix = f"{file_label}: table_templates['{table_name}']"

    if not isinstance(spec, dict):
        errors.append(f"{prefix}: Must be a JSON object.")
        return errors, warnings

    source_range = str(spec.get("source_range") or "").strip()
    if not source_range:
        errors.append(f"{prefix}: 'source_range' is required (Excel cell range like B4:D6).")
    else:
        parts = re.split(r"[;\n]+", source_range)
        for part in parts:
            part = part.strip()
            if not part:
                continue
            clean = part.replace("$", "")
            if not _DIRECT_RANGE.match(clean):
                warnings.append(f"{prefix}: source_range part '{part}' may not be a valid Excel range.")

    sheet_names = spec.get("source_sheet") or spec.get("source_sheets") or spec.get("sheet_aliases")
    if not sheet_names:
        warnings.append(f"{prefix}: No 'source_sheet' or 'source_sheets' specified. Sheet matching will fail.")

    insert_mode = str(spec.get("insert_mode") or "after_row").strip().casefold()
    if insert_mode not in _VALID_INSERT_MODES:
        errors.append(f"{prefix}: 'insert_mode' must be one of {sorted(_VALID_INSERT_MODES)}, got '{insert_mode}'.")

    if insert_mode == "after_row":
        row_val = spec.get("insert_after_row")
        if row_val is not None and not isinstance(row_val, (int, float)):
            errors.append(f"{prefix}: 'insert_after_row' must be numeric, got {row_val!r}.")

    fit_mode = str(spec.get("fit_mode") or "scale").strip().casefold()
    if fit_mode and fit_mode not in _VALID_FIT_MODES:
        warnings.append(f"{prefix}: 'fit_mode' value '{fit_mode}' is not a recognized mode.")

    for key in ("margin_before", "margin_after"):
        val = spec.get(key)
        if val is not None and not isinstance(val, (int, float)):
            try:
                float(val)
            except (TypeError, ValueError):
                errors.append(f"{prefix}: '{key}' must be numeric, got {val!r}.")

    mappings = spec.get("mappings")
    if mappings is not None:
        if not isinstance(mappings, list):
            errors.append(f"{prefix}: 'mappings' must be a list, got {type(mappings).__name__}.")
        else:
            slot_set = {str(n).casefold() for n in template_slots}
            for i, mapping in enumerate(mappings, start=1):
                m_errors, m_warnings = _validate_mapping(mapping, i, prefix, slot_set, list(template_slots))
                errors.extend(m_errors)
                warnings.extend(m_warnings)

    return errors, warnings


def _validate_mapping(mapping, index, prefix, template_slots, slot_names=None):
    """Validate a single mapping object. Returns (errors, warnings)."""
    errors = []
    warnings = []
    label = f"{prefix}, mapping #{index}"

    if not isinstance(mapping, dict):
        errors.append(f"{label}: Must be a JSON object.")
        return errors, warnings

    kind = str(mapping.get("kind") or "").strip().casefold()
    if not kind:
        errors.append(f"{label}: 'kind' is required (text/flow/icon/dedicated_icon/inline_token/background).")
    elif kind not in _VALID_KINDS:
        errors.append(f"{label}: 'kind' must be one of {sorted(_VALID_KINDS)}, got '{kind}'.")

    source = str(mapping.get("source") or "").strip()
    if kind != "background" and not source:
        errors.append(f"{label}: 'source' (Excel range) is required for kind '{kind}'.")

    slot = str(mapping.get("slot") or "").strip()
    if not slot:
        errors.append(f"{label}: 'slot' (PSD slot name) is required.")
    elif ".rowtemplate." not in slot.casefold() and slot.casefold() not in template_slots:
        suggestions = suggest_slot_names(slot, slot_names or [], max_suggestions=3, max_distance=3)
        msg = f"{label}: Slot '{slot}' not found in template slots."
        if suggestions:
            msg += f" Did you mean: {', '.join(suggestions)}?"
        warnings.append(msg)

    for key in ("font_size", "icon_height", "token_index", "max_height", "opacity",
                "stroke_width", "line_height", "repeat_row_gap"):
        val = mapping.get(key)
        if val is not None and not isinstance(val, (int, float)):
            try:
                float(val)
            except (TypeError, ValueError):
                errors.append(f"{label}: '{key}' must be numeric, got {val!r}.")

    alignment = str(mapping.get("alignment") or "").strip().casefold()
    if alignment and alignment not in _VALID_ALIGNMENTS:
        warnings.append(f"{label}: 'alignment' must be one of {sorted(_VALID_ALIGNMENTS)}, got '{alignment}'.")

    vertical = str(mapping.get("vertical_align") or "").strip().casefold()
    if vertical and vertical not in _VALID_VERTICAL:
        warnings.append(f"{label}: 'vertical_align' must be one of {sorted(_VALID_VERTICAL)}, got '{vertical}'.")

    padding = mapping.get("padding")
    if padding is not None:
        if not isinstance(padding, (list, tuple)):
            errors.append(f"{label}: 'padding' must be a list of 4 numbers, got {type(padding).__name__}.")
        elif len(padding) != 4:
            warnings.append(f"{label}: 'padding' should have 4 elements [top, right, bottom, left], got {len(padding)}.")

    if kind in ("token", "inline_token") and mapping.get("token_index") is None:
        warnings.append(f"{label}: 'token_index' is recommended for kind '{kind}'.")

    return errors, warnings


def _coerce_rgb(value, fallback=(255, 255, 255)):
    if isinstance(value, str):
        cleaned = value.strip().lstrip("#")
        if len(cleaned) == 6:
            try:
                return tuple(int(cleaned[index:index + 2], 16) for index in (0, 2, 4))
            except Exception:
                pass
    if isinstance(value, (list, tuple)) and len(value) >= 3:
        try:
            return tuple(max(0, min(255, int(value[index]))) for index in range(3))
        except Exception:
            pass
    return tuple(fallback)


def _source_parts(source):
    if isinstance(source, (list, tuple)):
        raw = source
    else:
        raw = re.split(r"[;\n]+", str(source or ""))
    return [str(part or "").strip() for part in raw if str(part or "").strip()]


def load_table_template(path, strict=False):
    path = os.path.abspath(os.path.expanduser(str(path or "")))
    if not os.path.isfile(path):
        raise FileNotFoundError(f"Table JSON not found:\n{path}")
    with open(path, "r", encoding="utf-8") as handle:
        template = json.load(handle)
    errors, warnings = validate_table_template(template, path)
    if strict and errors:
        raise ValueError("\n".join(errors))
    slots = template.get("slots") or template.get("table_slots") or {}
    if not template.get("slots") and slots:
        template["slots"] = slots
    canvas = template.get("canvas") or {}
    if not isinstance(slots, dict) or not slots:
        raise ValueError("The selected JSON does not contain exported PSD slots.")
    if strict and (not canvas.get("width") or not canvas.get("height")):
        raise ValueError("The selected JSON needs canvas width and height.")
    prefix = str(template.get("slot_prefix") or "").strip().casefold()
    if not template.get("export_kind"):
        template["export_kind"] = "table" if prefix in ("@table", "table", "") else prefix.lstrip("@")
    if _is_table_template(template):
        _ensure_synthetic_bounds_slot(template)
    if template.get("export_kind") == "table" and "table_slots" not in template:
        template["table_slots"] = template.get("slots") or slots
    template["_validation_errors"] = errors
    template["_validation_warnings"] = warnings
    return template


def _flat_table_name(template):
    for key in ("template_id", "name", "table_name"):
        value = str((template or {}).get(key) or "").strip()
        if value:
            return value
    source = str((template or {}).get("source_psd") or "").strip()
    if source:
        return os.path.splitext(os.path.basename(source))[0]
    return "table"


def _is_table_template(template):
    kind = str((template or {}).get("export_kind") or "").strip().casefold()
    prefix = str((template or {}).get("slot_prefix") or "").strip().casefold()
    return kind in ("table", "all_at_layers") or prefix in ("@table", "table", "@")


def _is_paytable_template(template):
    kind = str((template or {}).get("export_kind") or "").strip().casefold()
    page_type = str((template or {}).get("page_type") or "").strip().casefold()
    return kind == "paytable" or page_type == "paytable"


def _slot_box_area(box):
    try:
        return max(0.0, float(box.get("w", 0))) * max(0.0, float(box.get("h", 0)))
    except Exception:
        return 0.0


def _slot_name_is_bounds_like(slot_name):
    key = str(slot_name or "").strip()
    if not key:
        return False
    last_part = key.split(".")[-1].casefold()
    compact = re.sub(r"[^a-z0-9]+", "", last_part)
    if compact in {"bound", "bounds", "tablebound", "tablebounds", "container", "tablebox", "bg", "background", "textbg", "textbackground"}:
        return True
    full = re.sub(r"[^a-z0-9]+", "", key.casefold())
    return bool(re.search(r"bg\d*$", full))


def _box_copy(box):
    return {
        "x": float(box.get("x", 0)),
        "y": float(box.get("y", 0)),
        "w": float(box.get("w", 0)),
        "h": float(box.get("h", 0)),
    }


def _union_slot_bounds(slots):
    usable = []
    for box in (slots or {}).values():
        try:
            copied = _box_copy(box)
            if copied["w"] > 0 and copied["h"] > 0:
                usable.append(copied)
        except Exception:
            pass
    if not usable:
        return None
    left = min(box["x"] for box in usable)
    top = min(box["y"] for box in usable)
    right = max(box["x"] + box["w"] for box in usable)
    bottom = max(box["y"] + box["h"] for box in usable)
    return {
        "x": int(round(left)),
        "y": int(round(top)),
        "w": int(round(max(1.0, right - left))),
        "h": int(round(max(1.0, bottom - top))),
    }


def _bounds_slot_for_table(template, table_name=None):
    slots = (template or {}).get("slots") or {}
    if not isinstance(slots, dict) or not slots:
        return ""
    table = str(table_name or default_table_name(template)).strip()
    lower = {str(name).casefold(): str(name) for name in slots}
    direct_candidates = []
    if table:
        direct_candidates.extend([
            f"{table}.bounds",
            f"{table}.bound",
            f"{table}.tableBounds",
            f"{table}.tableBound",
            table,
        ])
    for candidate in direct_candidates:
        found = lower.get(str(candidate).casefold())
        if found:
            return found

    candidates = []
    for name, box in slots.items():
        key = str(name or "").strip()
        if not key:
            continue
        if _slot_name_is_bounds_like(key):
            candidates.append((key, box))
    if candidates:
        candidates.sort(key=lambda item: _slot_box_area(item[1]), reverse=True)
        return candidates[0][0]
    return ""


def _ensure_synthetic_bounds_slot(template, table_name=None):
    slots = (template or {}).get("slots") or {}
    if not isinstance(slots, dict) or not slots:
        return ""
    existing = _bounds_slot_for_table(template, table_name)
    if existing:
        return existing
    table = str(table_name or _flat_table_name(template)).strip() or "table"
    key = f"{table}.bounds"
    suffix = 2
    while key in slots:
        key = f"{table}.bounds{suffix}"
        suffix += 1
    union = _union_slot_bounds(slots)
    if not union:
        return ""
    slots[key] = union
    template["slots"] = slots
    if isinstance(template.get("table_slots"), dict):
        template["table_slots"][key] = dict(union)
    generated = dict(template.get("generated_bounds_slots") or {})
    generated[key] = "union_of_exported_slots"
    template["generated_bounds_slots"] = generated
    return key


def table_template_names(template):
    if _is_table_template(template):
        explicit = OrderedDict()
        for slot_name in (template.get("slots") or {}).keys():
            parts = str(slot_name or "").split(".")
            if len(parts) >= 2 and parts[0] and parts[1].casefold() == "bounds":
                explicit.setdefault(parts[0], None)
            elif len(parts) >= 3 and parts[0].lstrip("@").casefold() == "table" and parts[2].casefold() == "bounds":
                explicit.setdefault(".".join(parts[:2]), None)
        return list(explicit.keys()) or [_flat_table_name(template)]
    names = OrderedDict()
    has_dotted_slots = False
    for slot_name in (template.get("slots") or {}).keys():
        parts = str(slot_name or "").split(".")
        if not parts or not parts[0]:
            continue
        if len(parts) < 2:
            continue
        has_dotted_slots = True
        names.setdefault(parts[0], None)
    if names and has_dotted_slots:
        return list(names.keys())
    return list(names.keys())


def default_table_name(template):
    names = table_template_names(template)
    return names[0] if names else "table"


def slots_for_table_template(template, table_name=None):
    slots = template.get("slots") or {}
    table = str(table_name or "").strip().casefold()
    if not table:
        return dict(slots)
    matching = {
        str(name): box for name, box in slots.items()
        if str(name).casefold() == table or str(name).casefold().startswith(table + ".")
    }
    if matching and any(not _slot_name_is_bounds_like(name) for name in matching):
        return matching
    if matching and table != _flat_table_name(template).casefold():
        return matching
    return dict(slots)


def direct_range_bounds(source):
    cleaned = str(source or "").replace("$", "").strip()
    match = _DIRECT_RANGE.fullmatch(cleaned)
    if not match:
        return None
    start_col, start_row, end_col, end_row = match.groups()
    end_col = end_col or start_col
    end_row = end_row or start_row
    min_col, min_row, max_col, max_row = range_boundaries(f"{start_col}{start_row}:{end_col}{end_row}")
    if min_col > max_col:
        min_col, max_col = max_col, min_col
    if min_row > max_row:
        min_row, max_row = max_row, min_row
    return min_col, min_row, max_col, max_row


def normalize_range(source):
    parts = _source_parts(source)
    if len(parts) > 1:
        return "; ".join(normalize_range(part) for part in parts)
    if len(parts) == 1:
        source = parts[0]
    bounds = direct_range_bounds(source)
    if not bounds:
        return str(source or "").strip()
    min_col, min_row, max_col, max_row = bounds
    if min_col == max_col and min_row == max_row:
        return f"{get_column_letter(min_col)}{min_row}"
    return f"{get_column_letter(min_col)}{min_row}:{get_column_letter(max_col)}{max_row}"


def range_start_row(source, fallback=0):
    rows = []
    for part in _source_parts(source):
        bounds = direct_range_bounds(part)
        if bounds:
            rows.append(bounds[1])
    return min(rows) if rows else int(fallback or 0)


def range_end_row(source, fallback=0):
    rows = []
    for part in _source_parts(source):
        bounds = direct_range_bounds(part)
        if bounds:
            rows.append(bounds[3])
    return max(rows) if rows else int(fallback or 0)


def _bounds_from_source(source):
    bounds = []
    for part in _source_parts(source):
        item = direct_range_bounds(part)
        if item:
            bounds.append(item)
    return bounds


def _row_range_from_bounds(bounds):
    rows = [(item[1], item[3]) for item in bounds or []]
    if not rows:
        return None
    return min(start for start, _end in rows), max(end for _start, end in rows)


def _rows_from_bounds(bounds):
    rows = set()
    for _min_col, min_row, _max_col, max_row in bounds or []:
        rows.update(range(int(min_row), int(max_row) + 1))
    return rows


def _mapping_source_bounds(mappings):
    bounds = []
    for mapping in mappings or []:
        source = str((mapping or {}).get("source") or "").strip()
        if source:
            bounds.extend(_bounds_from_source(source))
    return bounds


def _slot_source_bounds(template):
    bounds = []
    for slot_name, slot_def in (template.get("slots") or {}).items():
        source = str((slot_def or {}).get("source") or "").strip()
        if source:
            bounds.extend(_bounds_from_source(source))
    table_templates = template.get("table_templates") or {}
    for table_name, table_spec in table_templates.items():
        source = str((table_spec or {}).get("source_range") or "").strip()
        if source:
            bounds.extend(_bounds_from_source(source))
    return bounds


def source_for_row_offset(source, row_offset):
    parts = _source_parts(source)
    if len(parts) > 1:
        return "; ".join(source_for_row_offset(part, row_offset) for part in parts)
    bounds = direct_range_bounds(source)
    if not bounds:
        return source
    min_col, min_row, max_col, max_row = bounds
    target_row = min(max_row, min_row + int(row_offset or 0))
    if min_col == max_col:
        return f"{get_column_letter(min_col)}{target_row}"
    return f"{get_column_letter(min_col)}{target_row}:{get_column_letter(max_col)}{target_row}"


_FORMULA_VALUE_WBS = {}


def _cell_value(worksheet, row, col):
    """Read a cell, resolving formula strings to their cached values when the
    worksheet's workbook was loaded without ``data_only`` (``=H31`` -> value)."""
    try:
        raw = worksheet.cell(row=row, column=col).value
    except Exception:
        return None
    if not isinstance(raw, str) or not raw.startswith("="):
        return raw
    try:
        from openpyxl import load_workbook as _load_workbook

        path = ""
        archive = getattr(worksheet.parent, "_archive", None)
        if archive is not None:
            try:
                path = str(getattr(archive, "filename", "") or "")
            except Exception:
                path = ""
        wb = _FORMULA_VALUE_WBS.get(path)
        if wb is None:
            if not path or not os.path.isfile(path):
                return raw
            wb = _load_workbook(path, data_only=True)
            _FORMULA_VALUE_WBS[path] = wb
        cached = wb[worksheet.title].cell(row=row, column=col).value
        return cached if cached is not None else raw
    except Exception:
        return raw


def _range_text_from_bounds(worksheet, bounds):
    min_col, min_row, max_col, max_row = bounds
    row_texts = []
    for row_idx in range(min_row, max_row + 1):
        values = []
        for col_idx in range(min_col, max_col + 1):
            text = _text(_cell_value(worksheet, row_idx, col_idx))
            if text:
                values.append(text)
        if values:
            row_texts.append(" ".join(values))
    return "\n".join(row_texts).strip()


def resolve_table_source_text(worksheet, source):
    parts = _source_parts(source)
    if len(parts) > 1:
        return "\n".join(
            chunk for chunk in (resolve_table_source_text(worksheet, part) for part in parts)
            if chunk
        ).strip()
    if len(parts) == 1:
        source = parts[0]
    bounds = direct_range_bounds(source)
    if bounds:
        return _range_text_from_bounds(worksheet, bounds)
    # Light fallback for named ranges. The mapper UI mainly writes direct ranges.
    try:
        destinations = list(worksheet.parent.defined_names[str(source)].destinations)
    except Exception:
        destinations = []
    chunks = []
    for sheet_name, coordinate in destinations:
        if str(sheet_name) != str(worksheet.title):
            continue
        try:
            chunks.append(_range_text_from_bounds(worksheet, range_boundaries(coordinate)))
        except Exception:
            pass
    return "\n".join(chunk for chunk in chunks if chunk).strip()


def resolve_paytable_source_text(worksheet, source):
    """Paytable-specific source reader: one cell, a range, or comma/;
    separated refs (as the paytable automap writes for pay/value runs) —
    returns one line per Excel row (rows joined with "\\n")."""
    parts = [str(part).strip() for part in re.split(r"[;,]+", str(source or "")) if str(part).strip()]
    if not parts:
        return ""
    chunks = []
    for part in parts:
        chunk = str(resolve_table_source_text(worksheet, part) or "").strip()
        if chunk:
            chunks.append(chunk)
    return "\n".join(chunks).strip()


def resolve_table_token(worksheet, source, token_index=0):
    text = resolve_table_source_text(worksheet, source)
    tokens = _tokens(text)
    index = _safe_int(token_index, 0)
    if index < 0 or index >= len(tokens):
        return ""
    return tokens[index]


def remove_token_indexes(text, indexes):
    indexes = {int(index) for index in indexes or []}
    if not indexes:
        return str(text or "")
    current = -1

    def replace(match):
        nonlocal current
        current += 1
        return "" if current in indexes else match.group(0)

    cleaned = _TOKEN.sub(replace, str(text or ""))
    cleaned = re.sub(r"[ \t]{2,}", " ", cleaned)
    cleaned = re.sub(r"\s+\n", "\n", cleaned)
    cleaned = re.sub(r"\n\s+", "\n", cleaned)
    return cleaned.strip()


def scan_table_excel_content(path, sheet_name, max_column=30):
    workbook = load_workbook(path, data_only=False, read_only=False)
    try:
        if sheet_name not in workbook.sheetnames:
            raise ValueError(f"Excel sheet not found: {sheet_name}")
        worksheet = workbook[sheet_name]
        max_column = max(1, min(_safe_int(max_column, worksheet.max_column), worksheet.max_column))
        blocks = []
        try:
            for table in detect_tables_in_sheet(worksheet, max_column):
                source = (
                    f"{get_column_letter(table['min_col'])}{table['start_row']}:"
                    f"{get_column_letter(table['max_col'])}{table['end_row']}"
                )
                blocks.append({
                    "id": f"table:{source}",
                    "source": source,
                    "label": f"Detected table {source}",
                    "text": f"Rows {table['start_row']}-{table['end_row']}",
                    "tokens": [],
                    "kind": "table_range",
                    "row": int(table["start_row"]),
                })
        except Exception:
            pass

        for row_number in range(1, worksheet.max_row + 1):
            populated = []
            values = []
            cells = []
            for column_number in range(1, max_column + 1):
                cell = worksheet.cell(row=row_number, column=column_number)
                text = _text(cell.value)
                if text:
                    populated.append(column_number)
                    values.append(text)
                    source = cell.coordinate
                    merged_source = ""
                    try:
                        for merged_range in worksheet.merged_cells.ranges:
                            if cell.coordinate in merged_range:
                                merged_source = str(merged_range)
                                break
                    except Exception:
                        merged_source = ""
                    cells.append({
                        "source": source,
                        "merged_source": merged_source,
                        "label": f"Cell {source}",
                        "text": text,
                        "tokens": _tokens(text),
                        "kind": "cell",
                        "row": row_number,
                        "column": column_number,
                    })
            if not values:
                continue
            source = (
                f"{get_column_letter(min(populated))}{row_number}:"
                f"{get_column_letter(max(populated))}{row_number}"
            )
            text = " ".join(values).strip()
            blocks.append({
                "id": f"row:{row_number}",
                "source": source,
                "label": f"Row {row_number}",
                "text": text,
                "tokens": _tokens(text),
                "cells": cells,
                "kind": "flow" if _tokens(text) else "text",
                "row": row_number,
            })
        blocks.sort(key=lambda item: (int(item.get("row", 0)), 0 if item.get("kind") == "table_range" else 1))
        return blocks
    finally:
        workbook.close()


def extract_existing_table_mappings(template, table_name=None):
    table_templates = template.get("table_templates") or {}
    if not isinstance(table_templates, dict) or not table_templates:
        return [], {}
    chosen = table_name or next(iter(table_templates.keys()))
    spec = table_templates.get(chosen) or {}
    return list(spec.get("mappings") or []), dict(spec)


def _mapping_signature(mapping):
    kind = str(mapping.get("kind") or "").casefold()
    slot = str(mapping.get("slot") or "").strip().casefold()
    source = str(mapping.get("source") or "").strip().casefold()
    token_index = _safe_int(mapping.get("token_index", 0), 0)
    if kind == "inline_token":
        return kind, slot, source, token_index
    return kind, slot


def validate_table_mappings(
        template, table_name, mappings, excel_path="", sheet_name="",
        icon_folder="", icon_mappings=None, source_range=""):
    slots = {str(name).casefold() for name in (template.get("slots") or {})}
    table_name = str(table_name or default_table_name(template)).strip()
    warnings = []
    errors = []
    primary_slots = {}
    seen = set()

    for index, mapping in enumerate(mappings or [], start=1):
        kind = str(mapping.get("kind") or "").strip().casefold()
        slot = str(mapping.get("slot") or "").strip()
        source = str(mapping.get("source") or "").strip()
        if (not source and not str(mapping.get("text") or "").strip()
                and slot and _slot_name_is_bounds_like(slot)):
            # Auto-generated container slots (e.g. "<table>.bounds") are never
            # mapped to Excel content; ignore their placeholder mappings.
            continue
        if kind not in {"text", "flow", "icon", "dedicated_icon", "inline_token", "background", "heading"}:
            errors.append(f"Mapping {index} has unsupported type: {kind or '[blank]'}")
        if kind != "background" and not source and not str(mapping.get("text") or "").strip():
            errors.append(f"Mapping {index} has no Excel source.")
        if slot and slot.casefold() not in slots and ".rowtemplate." not in slot.casefold():
            errors.append(f"Mapping {index} references missing table slot: {slot}")
        if not slot:
            errors.append(f"Mapping {index} has no table slot.")
        signature = _mapping_signature(mapping)
        if signature in seen:
            warnings.append(f"Mapping {index} duplicates an existing {kind} assignment for {slot}.")
        seen.add(signature)
        if kind in {"text", "flow", "icon", "dedicated_icon", "heading"} and slot:
            prior = primary_slots.get(slot.casefold())
            if prior is not None:
                errors.append(f"Table slot {slot} is assigned more than once by mappings {prior} and {index}.")
            else:
                primary_slots[slot.casefold()] = index

    if not mappings:
        warnings.append("No Excel-to-table-slot mappings have been created.")
    elif not any(str(m.get("kind") or "").casefold() in {"text", "flow"} for m in mappings):
        warnings.append("No text or flow mapping exists; this table will only render icons/backgrounds.")

    # NEW: Text overflow risk
    template_slots = template.get("slots") or {}
    for index, mapping in enumerate(mappings or [], start=1):
        kind = str(mapping.get("kind") or "").strip().casefold()
        slot = str(mapping.get("slot") or "").strip()
        if kind in ("text", "flow") and slot:
            box = template_slots.get(slot)
            if box:
                try:
                    w = float(box.get("w", 0))
                    h = float(box.get("h", 0))
                    font_size = int(mapping.get("font_size", 30))
                    if w > 0 and h > 0 and w < font_size * 3 and h < font_size * 1.5:
                        warnings.append(f"Mapping {index}: Text overflow risk. Slot '{slot}' is very small for font size {font_size}.")
                except Exception:
                    pass

    if excel_path and sheet_name and os.path.isfile(excel_path):
        workbook = load_workbook(excel_path, data_only=False, read_only=False)
        try:
            if sheet_name in workbook.sheetnames:
                worksheet = workbook[sheet_name]
                missing_icons = []
                for mapping in mappings or []:
                    if str(mapping.get("kind") or "").casefold() not in {"icon", "dedicated_icon"}:
                        continue
                    token = resolve_table_token(worksheet, mapping.get("source"), mapping.get("token_index", 0))
                    if token and not resolve_icon_path(token, icon_folder, icon_mappings):
                        missing_icons.append(token)
                if missing_icons:
                    warnings.append("Missing dedicated icon assets: " + ", ".join(f"<{name}>" for name in sorted(set(missing_icons))))
                
                mapped_bounds = _mapping_source_bounds(mappings)
                source_bounds = _bounds_from_source(source_range)
                mapped_rows = _rows_from_bounds(mapped_bounds)
                source_rows = _rows_from_bounds(source_bounds)

                # Only audit tokens inside mapped table sources. Page copy outside
                # the table can legitimately contain icon-like tokens.
                all_excel_tokens = []
                audited_sources = {
                    str(mapping.get("source") or "").strip()
                    for mapping in mappings or []
                    if str(mapping.get("source") or "").strip()
                }
                for source in audited_sources:
                    all_excel_tokens.extend(_tokens(resolve_table_source_text(worksheet, source)))

                unmapped_missing_tokens = []
                for t in set(all_excel_tokens):
                    if not resolve_icon_path(t, icon_folder, icon_mappings):
                        unmapped_missing_tokens.append(t)
                
                if unmapped_missing_tokens:
                    warnings.append(f"Unmapped/missing icon tokens in Excel: {', '.join(sorted(set(unmapped_missing_tokens))[:5])}")
                    
                # NEW: Unmapped Excel rows
                try:
                    if source_rows and (not mapped_rows or len(source_rows) > 1):
                        audit_rows = source_rows
                    else:
                        audit_rows = mapped_rows
                    unmapped_rows = []
                    for row_number in sorted(audit_rows):
                        if row_number in mapped_rows:
                            continue
                        has_text = False
                        for column_number in range(1, min(worksheet.max_column or 1, 30) + 1):
                            if _text(worksheet.cell(row=row_number, column=column_number).value):
                                has_text = True
                                break
                        if has_text:
                            unmapped_rows.append(str(row_number))
                    if unmapped_rows:
                        warnings.append(f"Unmapped Excel rows with content: {', '.join(sorted(set(unmapped_rows), key=int)[:10])}")
                except Exception:
                    pass
        finally:
            workbook.close()

    return errors, warnings


def _clean_mapping(mapping):
    cleaned = {
        "kind": str(mapping.get("kind") or "flow").strip(),
        "source": normalize_range(mapping.get("source")),
        "slot": str(mapping.get("slot") or "").strip(),
        "font_size": _safe_int(mapping.get("font_size", 30), 30),
        "icon_height": _safe_int(mapping.get("icon_height", 48), 48),
        "color": _coerce_rgb(mapping.get("color"), (255, 255, 255)),
        "alignment": str(mapping.get("alignment") or "center").strip().lower(),
        "vertical_align": str(mapping.get("vertical_align") or "center").strip().lower(),
        "padding": list(mapping.get("padding") or [0, 0, 0, 0])[:4],
    }
    while len(cleaned["padding"]) < 4:
        cleaned["padding"].append(0)
    cleaned["padding"] = [_safe_int(value, 0) for value in cleaned["padding"]]
    for key in ("token_index", "max_height", "opacity", "stroke_width", "repeat_row_gap", "line_height"):
        if key in mapping:
            cleaned[key] = _safe_int(mapping.get(key), 0)
    for key in ("token", "text", "background_color", "stroke_color", "font_name", "font_family", "font_style", "font_weight", "role"):
        if str(mapping.get(key) or "").strip():
            cleaned[key] = mapping.get(key)
    if str(mapping.get("layer_style") or "").strip():
        cleaned["layer_style"] = str(mapping.get("layer_style")).strip()
    for key in ("fill_enabled", "stroke_enabled", "keep_dedicated_tokens", "bold", "italic"):
        if key in mapping:
            cleaned[key] = bool(mapping.get(key))
    if bool(mapping.get("repeat")) or ".rowtemplate." in cleaned["slot"].casefold():
        cleaned["repeat"] = True
    return cleaned


def build_mapped_table_template(
        base_template, sheet_name, table_name, source_range, mappings,
        insert_mode="after_row", insert_after_row=0, marker="", absolute_x=None, absolute_y=None,
        margin_before=30, margin_after=30, fit_mode="scale", scale_if_needed=True,
        alternate_template="", icon_mappings=None, source_sheets=None):
    template = copy.deepcopy(base_template)
    table_name = str(table_name or default_table_name(template)).strip() or "table"
    source_range = normalize_range(source_range)
    template.setdefault("slot_prefix", "@table")
    template["export_kind"] = "table"
    _ensure_synthetic_bounds_slot(template, table_name)
    template["table_slots"] = copy.deepcopy(template.get("slots") or {})

    table_templates = copy.deepcopy(template.get("table_templates") or {})
    spec = {
        "source_sheet": str(sheet_name or "").strip(),
        "source_sheets": _sheet_name_list(source_sheets),
        "source_range": source_range,
        "insert_mode": str(insert_mode or "after_row").strip(),
        "insert_after_row": _safe_int(insert_after_row, max(0, range_start_row(source_range, 1) - 1)),
        "marker": str(marker or f"<table:{table_name}>").strip(),
        "absolute_x": None if absolute_x in ("", None) else _safe_float(absolute_x),
        "absolute_y": None if absolute_y in ("", None) else _safe_float(absolute_y),
        "margin_before": _safe_int(margin_before, 30),
        "margin_after": _safe_int(margin_after, 30),
        "placement": "flow_under_text",
        "fit_mode": str(fit_mode or "scale").strip().lower(),
        "scale_if_needed": bool(scale_if_needed),
        "alternate_template": str(alternate_template or "").strip(),
        "bounds_slot": _bounds_slot_for_table(template, table_name),
        "mappings": [
            mapping for mapping in (_clean_mapping(m) for m in mappings or [])
            if str(mapping.get("source") or "").strip()
            or str(mapping.get("text") or "").strip()
            or str(mapping.get("kind") or "").casefold() == "background"
            or not _slot_name_is_bounds_like(str(mapping.get("slot") or ""))
        ],
    }
    table_templates[table_name] = spec
    template["table_templates"] = table_templates
    if icon_mappings is not None:
        template["icon_mappings"] = {
            str(key): str(value)
            for key, value in dict(icon_mappings or {}).items()
            if str(key).strip() and str(value).strip()
        }
    try:
        old_schema = int(template.get("schema_version", 0) or 0)
    except Exception:
        old_schema = 0
    template["schema_version"] = max(4, old_schema)
    template["mapper_meta"] = {
        "generated_by": "PsHelpScreenTool Table JSON Mapper",
        "sheet": str(sheet_name or "").strip(),
        "table": table_name,
        "mapping_count": len(mappings or []),
        "authoritative": True,
    }

    # For paytables, bridge table mappings into the renderer's flow/token system
    if _is_paytable_template(template):
        tbindings = []
        fregions = []
        # Keep existing regions that aren't from a previous save of ours
        for region in (template.get("flow_regions") or []):
            if isinstance(region, dict) and not str(region.get("id") or "").startswith("mapped."):
                fregions.append(region)
        for mapping in (mappings or []):
            kind = str(mapping.get("kind") or "").casefold()
            slot = str(mapping.get("slot") or "").strip()
            source = normalize_range(mapping.get("source") or "")
            if not slot:
                continue
            slot_key = slot.casefold()
            if kind in ("dedicated_icon", "icon"):
                tbindings.append({
                    "slot": slot,
                    "source": source,
                    "token_index": _safe_int(mapping.get("token_index", 0), 0),
                })
            elif kind in ("text", "flow"):
                # Remove stale region for this slot (overwrite)
                fregions = [r for r in fregions if str(r.get("slot") or "").casefold() != slot_key]
                fregions.append({
                    "slot": slot,
                    "sources": [source],
                    "render_mode": "inline_flow" if kind == "flow" else "text",
                    "id": f"mapped.{slot}",
                })
        template["token_bindings"] = tbindings
        template["flow_regions"] = fregions
    return template


def save_mapped_table_template(
        base_template, sheet_name, table_name, source_range, mappings, output_path,
        insert_mode="after_row", insert_after_row=0, marker="", absolute_x=None, absolute_y=None,
        margin_before=30, margin_after=30, fit_mode="scale", scale_if_needed=True,
        alternate_template="", icon_mappings=None, source_sheets=None):
    errors, warnings = validate_table_mappings(
        base_template, table_name, mappings, source_range=source_range
    )
    if errors:
        raise ValueError("\n".join(errors))
    output_path = os.path.abspath(os.path.expanduser(str(output_path)))
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    template = build_mapped_table_template(
        base_template, sheet_name, table_name, source_range, mappings,
        insert_mode=insert_mode, insert_after_row=insert_after_row, marker=marker,
        absolute_x=absolute_x, absolute_y=absolute_y,
        margin_before=margin_before, margin_after=margin_after, fit_mode=fit_mode,
        scale_if_needed=scale_if_needed, alternate_template=alternate_template,
        icon_mappings=icon_mappings, source_sheets=source_sheets,
    )
    with open(output_path, "w", encoding="utf-8") as handle:
        json.dump(template, handle, indent=2, ensure_ascii=True)
        handle.write("\n")
    return output_path, warnings


def _path_list(value):
    if not value:
        return []
    if isinstance(value, (list, tuple)):
        raw = value
    else:
        raw = re.split(r"[;\n]", str(value))
    paths = []
    for item in raw:
        path = os.path.abspath(os.path.expanduser(str(item or "").strip()))
        if path and os.path.isfile(path) and path not in paths:
            paths.append(path)
    return paths


def _sheet_name_list(value):
    if not value:
        return []
    raw_items = value if isinstance(value, (list, tuple, set)) else re.split(r"[;\n]+", str(value))
    names = []
    for item in raw_items:
        name = str(item or "").strip()
        if name and name not in names:
            names.append(name)
    return names


def load_mapped_table_templates(paths, sheet_overrides=None):
    loaded = []
    for path in _path_list(paths):
        try:
            template = load_table_template(path)
        except Exception as exc:
            loaded.append({"error": str(exc), "path": path})
            continue
        template_errors = list(template.get("_validation_errors") or [])
        template_warnings = list(template.get("_validation_warnings") or [])
        for name, spec in (template.get("table_templates") or {}).items():
            if not isinstance(spec, dict):
                continue
            record = {
                "path": path,
                "table_name": str(name),
                "template": template,
                "slots": template.get("slots") or {},
                "canvas": template.get("canvas") or {},
                "spec": copy.deepcopy(spec),
                "icon_mappings": template.get("icon_mappings") or {},
                "validation_errors": list(template_errors),
                "validation_warnings": list(template_warnings),
            }
            # Apply runtime sheet overrides (user-assigned sheet picker).
            if sheet_overrides:
                json_path = os.path.abspath(path)
                assigned = sheet_overrides.get(path) or sheet_overrides.get(json_path) or []
                if assigned:
                    existing = record["spec"].get("source_sheets") or []
                    if isinstance(existing, str):
                        existing = [existing] if existing.strip() else []
                    merged = list(dict.fromkeys(str(a) for a in list(existing) + list(assigned)))
                    record["spec"]["source_sheets"] = merged
            loaded.append(record)
    return loaded


def template_matches_sheet(record, sheet_name, sheet_overrides=None):
    if record.get("error"):
        return False
    spec = record.get("spec") or {}
    # Check runtime overrides first (user-assigned sheet picker).
    if sheet_overrides:
        json_path = str(record.get("path") or "").strip()
        if json_path:
            assigned = sheet_overrides.get(json_path) or sheet_overrides.get(os.path.abspath(json_path)) or []
            for assigned_sheet in assigned:
                if " ".join(str(assigned_sheet or "").strip().casefold().split()) == " ".join(str(sheet_name or "").strip().casefold().split()):
                    return True
    wanted_names = []
    wanted_names.extend(_sheet_name_list(spec.get("source_sheet")))
    wanted_names.extend(_sheet_name_list(spec.get("source_sheets")))
    wanted_names.extend(_sheet_name_list(spec.get("sheet_aliases")))
    if not wanted_names:
        return False
    sheet_clean = " ".join(str(sheet_name or "").strip().casefold().split())
    for wanted in wanted_names:
        wanted_clean = " ".join(str(wanted or "").strip().casefold().split())
        if wanted_clean == sheet_clean:
            return True
    return False

def trigger_row_for_template(record):
    spec = record.get("spec") or {}
    source_range = spec.get("source_range")
    mode = str(spec.get("insert_mode") or "after_row").strip().casefold()
    if mode == "after_row":
        configured = _safe_int(spec.get("insert_after_row", 0), 0)
        return configured + 1 if configured > 0 else range_start_row(source_range, 0)
    if mode in {"absolute", "range_start", "source_start"}:
        return range_start_row(source_range, 0)
    return 0

def source_row_range_for_template(record):
    spec = record.get("spec") or {}
    direct_rows = _row_range_from_bounds(_bounds_from_source(spec.get("source_range")))
    if direct_rows:
        return direct_rows
    mapped_rows = _row_range_from_bounds(_mapping_source_bounds(spec.get("mappings") or []))
    if mapped_rows:
        return mapped_rows
    slot_rows = _row_range_from_bounds(_slot_source_bounds(record.get("template") or {}))
    if slot_rows:
        return slot_rows
    return direct_rows


def mapped_record_consumed_rows(record):
    """Rows actually occupied by a mapped table's cells.

    Every row referenced by the slot mappings is treated as table content and
    is skipped from normal body rendering, even when those source rows fall
    outside the wide claimed ``source_range`` -- the mapping sources are the
    authoritative "assigned" cells. Falls back to the full claimed range only
    when the JSON references no cell sources at all.
    """
    spec = record.get("spec") or {}
    claimed = source_row_range_for_template(record)
    try:
        rows = _rows_from_bounds(_mapping_source_bounds(spec.get("mappings") or []))
    except Exception:
        rows = set()
    if rows:
        return {int(r) for r in rows}
    if not claimed:
        return set()
    return set(range(int(claimed[0]), int(claimed[1]) + 1))

def table_template_for_excel_table(records, sheet_name, table_data):
    if not table_data:
        return None
    start_row = int(table_data.get("start_row") or 0)
    end_row = int(table_data.get("end_row") or start_row)
    
    best_match = None
    best_overlap = -1
    
    for record in records or []:
        if not template_matches_sheet(record, sheet_name):
            continue
        spec = record.get("spec") or {}
        mode = str(spec.get("insert_mode") or "").strip().casefold()
        if mode == "marker":
            continue
            
        source_rows = source_row_range_for_template(record)
        if not source_rows:
            continue
            
        src_start, src_end = source_rows
        
        # Calculate overlap between detected table and mapped JSON range
        overlap_start = max(src_start, start_row)
        overlap_end = min(src_end, end_row)
        overlap = max(0, overlap_end - overlap_start + 1)
        
        if overlap > 0:
            # Require at least 50% of the mapped range to overlap with the detected table
            range_len = src_end - src_start + 1
            if overlap >= (range_len * 0.5) and overlap > best_overlap:
                best_overlap = overlap
                best_match = record
                
    return best_match
def marker_names_in_text(text):
    return [match.group(1).strip() for match in _TABLE_MARKER.finditer(str(text or ""))]

def strip_table_markers(text):
    return _TABLE_MARKER.sub("", str(text or "")).strip()

def table_templates_for_marker(records, sheet_name, text):
    names = marker_names_in_text(text)
    if not names:
        return []
    wanted = {name.casefold() for name in names}
    matches = []
    for record in records or []:
        if not template_matches_sheet(record, sheet_name):
            continue
        table_name = str(record.get("table_name") or "").casefold()
        marker = str((record.get("spec") or {}).get("marker") or "").casefold()
        if table_name in wanted or any(name in marker for name in wanted):
            matches.append(record)
    return matches


def levenshtein_distance(a, b):
    """Compute Levenshtein edit distance between two strings."""
    a = str(a or "")
    b = str(b or "")
    if a == b:
        return 0
    if not a:
        return len(b)
    if not b:
        return len(a)
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a):
        curr = [i + 1]
        for j, cb in enumerate(b):
            cost = 0 if ca == cb else 1
            curr.append(min(curr[j] + 1, prev[j + 1] + 1, prev[j] + cost))
        prev = curr
    return prev[len(b)]


def suggest_slot_names(target, slot_names, max_suggestions=3, max_distance=3):
    """Return up to max_suggestions closest slot names within max_distance edits."""
    target_lower = str(target or "").strip().casefold()
    if not target_lower:
        return []
    scored = []
    for name in slot_names or []:
        name_str = str(name or "")
        dist = levenshtein_distance(target_lower, name_str.casefold())
        if 0 < dist <= max_distance:
            scored.append((dist, name_str))
    scored.sort(key=lambda item: (item[0], item[1].casefold()))
    return [name for _, name in scored[:max_suggestions]]


def validate_source_range_against_worksheet(source_range, worksheet):
    """Check if source_range falls within the worksheet bounds. Returns (errors, warnings)."""
    errors = []
    warnings = []
    if not source_range or not worksheet:
        return errors, warnings
    max_row = getattr(worksheet, "max_row", None) or 0
    max_col = getattr(worksheet, "max_column", None) or 0
    if max_row <= 0 or max_col <= 0:
        return errors, warnings
    parts = re.split(r"[;\n]+", str(source_range))
    for part in parts:
        part = part.strip().replace("$", "")
        if not part:
            continue
        match = _DIRECT_RANGE.match(part)
        if not match:
            continue
        start_col_str, start_row_str, end_col_str, end_row_str = match.groups()
        start_row = int(start_row_str)
        end_row = int(end_row_str) if end_row_str else start_row
        if end_row > max_row:
            warnings.append(
                f"Range '{part}' extends to row {end_row}, "
                f"but the worksheet only has {max_row} rows."
            )
        if start_row > max_row:
            warnings.append(
                f"Range '{part}' starts at row {start_row}, "
                f"but the worksheet only has {max_row} rows — the range may be empty."
            )
    return errors, warnings
