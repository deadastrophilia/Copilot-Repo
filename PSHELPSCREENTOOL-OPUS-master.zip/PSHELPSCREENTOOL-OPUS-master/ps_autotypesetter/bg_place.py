"""Where the background picture goes on the canvas — one rule for the PNG / PSD build, the Canvas,
the page thumbnails and Photoshop.

The artist's choice travels as the one `bg_mode` setting every renderer already receives:

    "cover"                    fill the canvas, crop the overflow (the default)
    "stretch"                  exactly the canvas, out of proportion if need be
    "fit"                      the whole picture, as big as fits, centred
    "center"                   its own size, centred
    "tile"                     repeated
    "fit_width:top|center|bottom"   as wide as the canvas, at the top / middle / bottom
    "place:x,y,w,h"            exactly that rectangle (canvas px) — a background read from a PSD
    "color"                    no picture, the colour only

`spec(config)` builds it from the settings (bg_mode, bg_anchor, bg_rect); `dest()` is the rectangle the
picture is drawn into. Where the picture leaves the canvas uncovered (a fit / placed picture, or the
picture's own transparent parts) the page is transparent; `behind(config)` is the colour painted
there instead when the artist asks for one (bg_behind_fill).
"""

MODES = ("cover", "stretch", "fit", "center", "tile", "fit_width", "place", "color")


def spec(config):
    """The bg_mode string the renderers get, from the settings."""
    config = config or {}
    if str(config.get("bg_source") or "image") == "color":
        return "color"
    mode = str(config.get("bg_mode") or "cover").strip().casefold()
    if mode == "fill":                                      # an older name for cover
        mode = "cover"
    if mode == "fit_width":
        anchor = str(config.get("bg_anchor") or "center").strip().casefold()
        return "fit_width:" + (anchor if anchor in ("top", "center", "bottom") else "center")
    if mode == "place":
        r = rect_of(config.get("bg_rect"))
        return "place:" + ",".join(str(int(round(v))) for v in r) if r else "cover"
    return mode if mode in MODES else "cover"


def behind(config):
    """The colour every renderer gets as bg_color: a colour background's own colour; behind a picture,
    the "Colour behind" only when it is switched on, else "" (transparent)."""
    config = config or {}
    if str(config.get("bg_source") or "image") == "color":
        return str(config.get("bg_color") or "#FFFFFF")
    return str(config.get("bg_color") or "#000000") if config.get("bg_behind_fill") else ""


def _rgba(color):
    """(r, g, b, 255) of "#rrggbb", or None for "" / "none" / "transparent" (nothing painted)."""
    hexv = str(color or "").strip().lstrip("#")
    if not hexv or hexv.casefold() in ("none", "transparent"):
        return None
    try:
        return tuple(int(hexv[i:i + 2], 16) for i in (0, 2, 4)) + (255,)
    except ValueError:
        return None


def rect_of(value):
    """[x, y, w, h] from a list / "x,y,w,h", or None."""
    try:
        if isinstance(value, str):
            value = [float(v) for v in value.split(",")]
        x, y, w, h = (float(v) for v in value)
    except (TypeError, ValueError):
        return None
    return [x, y, w, h] if w > 0 and h > 0 else None


def parse(bg_mode):
    """(mode, anchor, rect) of a bg_mode string."""
    raw = str(bg_mode or "cover").strip()
    name, _, arg = raw.partition(":")
    name = name.strip().casefold() or "cover"
    if name == "fill":
        name = "cover"
    if name == "fit_width":
        a = arg.strip().casefold()
        return name, (a if a in ("top", "center", "bottom") else "center"), None
    if name == "place":
        r = rect_of(arg)
        return ("place", "center", r) if r else ("cover", "center", None)
    return (name if name in MODES else "stretch"), "center", None


def fills_canvas(bg_mode):
    """True when the picture covers the whole canvas (nothing left for the colour behind it)."""
    return parse(bg_mode)[0] in ("cover", "stretch", "tile")


def dest(bg_mode, canvas_w, canvas_h, img_w, img_h):
    """(x, y, w, h): where the whole picture is drawn (it may reach past the canvas — cover crops)."""
    mode, anchor, rect = parse(bg_mode)
    W, H = float(canvas_w), float(canvas_h)
    iw, ih = max(1.0, float(img_w)), max(1.0, float(img_h))
    if mode == "place":
        return tuple(rect)
    if mode == "fit_width":
        h = ih * W / iw
        y = 0.0 if anchor == "top" else (H - h) if anchor == "bottom" else (H - h) / 2.0
        return 0.0, y, W, h
    if mode == "fit":
        k = min(W / iw, H / ih)
        return (W - iw * k) / 2.0, (H - ih * k) / 2.0, iw * k, ih * k
    if mode == "center":
        return (W - iw) / 2.0, (H - ih) / 2.0, iw, ih
    if mode == "cover":
        k = max(W / iw, H / ih)
        return (W - iw * k) / 2.0, (H - ih * k) / 2.0, iw * k, ih * k
    return 0.0, 0.0, W, H


def area(config, canvas_w=None, canvas_h=None):
    """(x, y, w, h) canvas px of the background picture inside the canvas — the page's area the content
    goes into (a paytable starts there) — or None when the picture fills the canvas / there is none."""
    config = config or {}
    W = float(canvas_w or config.get("c_width") or 1920)
    H = float(canvas_h or config.get("c_height") or 1080)
    mode_str = spec(config)
    mode, _anchor, rect = parse(mode_str)
    if mode in ("color",) or fills_canvas(mode_str):
        return None
    if mode == "place":
        x, y, w, h = rect
    else:
        path = str(config.get("bg_path") or "")
        try:
            from PIL import Image

            with Image.open(path) as im:                     # the header only
                iw, ih = im.size
        except Exception:
            return None
        x, y, w, h = dest(mode_str, W, H, iw, ih)
    x0, y0 = max(0.0, x), max(0.0, y)
    x1, y1 = min(W, x + w), min(H, y + h)
    if x1 - x0 < 50 or y1 - y0 < 50 or (x0 <= 0.5 and y0 <= 0.5 and x1 >= W - 0.5 and y1 >= H - 0.5):
        return None
    return (x0, y0, x1 - x0, y1 - y0)
