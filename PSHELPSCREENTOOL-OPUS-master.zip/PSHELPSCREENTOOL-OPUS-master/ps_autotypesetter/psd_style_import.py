"""Read a reference PSD's look (fonts, sizes, colours, alignment, spacing,
layer styles, canvas) and turn it into settings for a new game.

The PSD is only read (psd_reader opens it lazily, nothing is written back).
No path from it is imported: not its symbols, Excel, background file or
links — only formatting. Every value comes with where it came from and how
sure the guess is, so the user can review and edit before saving.

Roles are guessed from the text layers:
  body       — the font/size carrying the most prose (long, multi-line text);
  heading    — larger, short texts, usually repeated on every page;
  subheading — between the two in size, or body size but bolder.
Layer names ("title", "header", "sub", "body"…) strengthen a guess.
"""
import os
import re
from collections import Counter, defaultdict

from . import fontfaces, fx_scale

ROLE_NAMES = {"heading": "Heading text", "subheading": "Subheading text", "body": "Body text"}
_NAME_HINTS = {
    "heading": re.compile(r"title|head(?!.*sub)|header", re.I),
    "subheading": re.compile(r"sub", re.I),
    "body": re.compile(r"body|desc|para|text|rule|copy", re.I),
}


def _type_layers(psd):
    for layer in psd.descendants():
        try:
            if layer.kind == "type":
                yield layer
        except Exception:
            continue


def _is_numberish(text):
    """Payouts, counts, "25-1250 Credits" — values, not typography roles."""
    letters = sum(c.isalpha() for c in text)
    digits = sum(c.isdigit() for c in text)
    solid = len(re.sub(r"\s", "", text)) or 1
    return letters < max(2, len(text) * 0.3) or (solid <= 30 and digits >= max(2, solid * 0.25))


def _shape(layer):
    """The Character panel's width / height scale (%), tracking and kerning of a type layer's main run, and its
    Blend If. The size Photoshop shows is the run's size × the layer's vertical transform (text_style), so a
    152 px layer stretched to 136 % tall reads 207 px: its width scale is its own × (wide ÷ tall stretch)."""
    from . import blend_if

    eng = layer.engine_dict
    runs = list(eng["StyleRun"]["RunArray"])
    lens = [int(n) for n in eng["StyleRun"]["RunLengthArray"]]
    text, pos, weight = str(layer.text or ""), 0, Counter()
    for i, n in enumerate(lens):
        weight[i] += len(text[pos:pos + n].strip())
        pos += n
    sd = runs[max(range(len(runs)), key=lambda i: weight[i])]["StyleSheet"]["StyleSheetData"] if runs else {}
    xx, _xy, _yx, yy, _tx, _ty = [float(v) for v in layer.transform]
    stretch = xx / yy if yy else 1.0
    try:
        under = blend_if.from_ranges(layer._record.blending_ranges)
    except Exception:
        under = None
    return {"hscale": round(float(sd.get("HorizontalScale", 1.0)) * stretch * 100.0, 2),
            "vscale": round(float(sd.get("VerticalScale", 1.0)) * 100.0, 2),
            "tracking": int(round(float(sd.get("Tracking", 0) or 0))),
            "kerning": "metrics" if bool(sd.get("AutoKerning", True)) else "none",
            "blend_if": under}


def read_layers(psd):
    """[{name, text, font, size, color, alignment, lines, chars, bbox, bold, effects, shape}]"""
    from .artist_design.fx_preview import _effects_style
    from .artist_design.learn_paytable import text_style

    out = []
    for layer in _type_layers(psd):
        try:
            text = str(layer.text or "").replace("\r", "\n").strip()
        except Exception:
            continue
        if not text:
            continue
        try:
            st = text_style(layer)
        except Exception:
            continue
        try:
            fx = _effects_style(layer)
        except Exception:
            fx = None
        try:
            shape = _shape(layer)
        except Exception:
            shape = None
        font = st["font_name"]
        out.append({
            "name": str(layer.name or ""), "text": text, "font": font,
            "size": float(st["font_size"]), "leading": float(st["leading"]),
            "color": st["color"], "alignment": st["alignment"],
            "lines": text.count("\n") + 1, "chars": len(re.sub(r"\s", "", text)),
            "bbox": tuple(int(v) for v in layer.bbox),
            "bold": bool(re.search(r"bold|black|heavy|semibold|extrabold", font, re.I)),
            "numbers": _is_numberish(text), "effects": fx, "visible": bool(layer.is_visible()), "shape": shape,
        })
    return out


def _groups(layers):
    g = defaultdict(list)
    for L in layers:
        if not L["numbers"]:
            g[(L["font"], round(L["size"]))].append(L)
    out = []
    for (font, size), items in g.items():
        chars = sum(i["chars"] for i in items)
        texts = Counter(i["text"] for i in items)
        out.append({
            "font": font, "size": size, "items": items, "count": len(items), "chars": chars,
            "avg_chars": chars / len(items), "multi_line": sum(i["lines"] > 1 for i in items),
            "repeats": texts.most_common(1)[0][1] if texts else 0,
            "bold": items[0]["bold"],
            "hints": Counter(r for i in items for r, rx in _NAME_HINTS.items() if rx.search(i["name"])),
        })
    return out


def _most(items, key, weight="chars"):
    c = Counter()
    for i in items:
        c[i[key]] += max(1, i[weight])
    return c.most_common(1)[0][0] if c else None


def _style_of(items):
    """The layer style most of the role's layers share (by bytes)."""
    c, first = Counter(), {}
    for i in items:
        fx = i.get("effects")
        if fx:
            k = fx["effects_block"]["hex"]
            c[k] += 1
            first.setdefault(k, fx)
    if not c:
        return None, 0
    k, n = c.most_common(1)[0]
    return first[k], n


def _most_shape(items):
    """The width / height scale, tracking, kerning and Blend If most of the role's characters use."""
    c, first = Counter(), {}
    for i in items:
        sh = i.get("shape")
        if sh:
            k = repr(sorted(sh.items()))
            c[k] += max(1, i["chars"])
            first.setdefault(k, sh)
    return first[c.most_common(1)[0][0]] if c else None


def classify(layers):
    """{role: {font, size, color, alignment, ..., confidence, why}}"""
    groups = _groups(layers)
    if not groups:
        return {}
    roles = {}

    def body_score(g):
        return g["chars"] * (1.5 if g["multi_line"] else 1.0) * (1.3 if g["hints"]["body"] else 1.0) \
            * (1.0 if g["avg_chars"] >= 20 else 0.4)

    body = max(groups, key=body_score)
    sure = body["avg_chars"] >= 30 or body["multi_line"] >= 2
    roles["body"] = (body, "high" if sure else "low",
                     f"most text ({body['chars']} characters in {body['count']} layer{'s' if body['count'] != 1 else ''})")

    bigger = [g for g in groups if g["size"] > body["size"] * 1.15 and g["avg_chars"] <= 60]
    if bigger:
        def head_score(g):
            return g["size"] * (1 + min(g["count"], 6) / 3) * (1.5 if g["hints"]["heading"] else 1.0) \
                * (0.6 if g["hints"]["subheading"] else 1.0)

        head = max(bigger, key=head_score)
        sure = head["count"] >= 2 and head["size"] >= body["size"] * 1.3
        roles["heading"] = (head, "high" if sure else "medium",
                            f"largest short text ({head['size']}px, {head['count']} layer{'s' if head['count'] != 1 else ''}"
                            + (", same text on several pages" if head["repeats"] >= 2 else "") + ")")
        between = [g for g in groups if g is not head and g is not body
                   and (body["size"] < g["size"] <= head["size"] * 0.9
                        or (g["size"] == body["size"] and g["bold"] and not body["bold"]))]
    else:
        between = [g for g in groups if g is not body and g["size"] >= body["size"] and g["bold"] and not body["bold"]]
    if between:
        sub = max(between, key=lambda g: g["count"] * (2 if g["hints"]["subheading"] else 1) + g["chars"] / 100)
        roles["subheading"] = (sub, "medium" if sub["count"] >= 3 or sub["hints"]["subheading"] else "low",
                               f"between body and heading in size or weight ({sub['size']}px)")

    out = {}
    for role, (g, conf, why) in roles.items():
        items = g["items"]
        style, n_fx = _style_of(items)
        lead = Counter(round(i["leading"] / i["size"], 2) for i in items if i["size"])
        out[role] = {
            "font": g["font"], "size": g["size"], "color": _most(items, "color"),
            "alignment": _most(items, "alignment"), "bold": g["bold"],
            "count": g["count"], "sample": items[0]["text"][:80],
            "line_ratio": lead.most_common(1)[0][0] if lead else None,
            "layer_style": style, "layer_style_layers": n_fx,
            "shape": _most_shape(items),
            "confidence": conf, "why": why,
        }
    return out


def _canvas_items(psd):
    """Biggest pixel layer covering (almost) the whole canvas — the background."""
    w, h = psd.width, psd.height
    best = None
    for layer in psd.descendants():
        try:
            if layer.is_group() or layer.kind == "type":
                continue
            l, t, r, b = layer.bbox
        except Exception:
            continue
        cover = max(0, min(r, w) - max(l, 0)) * max(0, min(b, h) - max(t, 0)) / float(w * h or 1)
        if cover >= 0.9 and (best is None or cover > best[1]):
            best = (str(layer.name or ""), cover)
    return best


_BG_NAME = re.compile(r"^\s*(bg|background|backgrounds|back\s*ground)\b|\b(bg|background)\s*$", re.I)


# a name that is nothing but the background: BG, Background, Help BG, Help_Background, BG group, Help …
_BG_ONLY = {"bg", "background", "backgrounds", "backround", "back ground", "help bg", "help background",
            "help backgrounds", "bg group", "background group", "help bg group", "help background group",
            "help group", "help", "bg png", "background png", "help bg png"}


def bg_name_strength(name, layer=None):
    """2: the name is the background's alone ("BG", "Background group", "Help BG", "help_bg", "BG.png"); a
    group named just "Help" counts only when it holds no text (else it is the help pages themselves).
    1: the name ends / starts with BG / Background ("Panel BG"). 0: not a background name."""
    words = " ".join(re.findall(r"[a-z0-9]+", str(name or "").casefold()))
    words = re.sub(r"( copy( \d+)?)+$", "", words)          # Photoshop's "BG copy 21" is still BG
    if words in _BG_ONLY:
        if words in ("help", "help group") and layer is not None:
            try:
                if not layer.is_group() or any(l.kind == "type" for l in layer.descendants()):
                    return 0
            except Exception:
                return 0
        return 2
    return 1 if _BG_NAME.search(str(name or "")) else 0


def bg_layer(psd):
    """The background layer: one named BG / Background / Help BG / Background group … (a picture, or a
    group — then the whole group is the background), else the biggest picture layer covering at least a
    quarter of the canvas. (layer, (x, y, w, h)) or None."""
    w, h = psd.width, psd.height
    named, best = [], None
    for layer in psd.descendants():
        try:
            if layer.kind == "type":
                continue
            l, t, r, b = (int(v) for v in layer.bbox)
        except Exception:
            continue
        if r <= l or b <= t:
            continue
        area = (r - l) * (b - t)
        try:
            hidden = not layer.is_visible()
        except Exception:
            hidden = False
        strength = bg_name_strength(layer.name, layer)
        if strength:
            # a name that is only the background's first ("BG", "Help BG group" before "Panel BG"), a shown
            # layer before a hidden one (an old full-canvas "Background" left switched off), then the biggest
            named.append((-strength, int(hidden), -area, layer, (l, t, r - l, b - t)))
            continue
        if hidden:
            continue
        try:
            if layer.is_group():
                continue
        except Exception:
            continue
        cover = max(0, min(r, w) - max(l, 0)) * max(0, min(b, h) - max(t, 0)) / float(w * h or 1)
        if cover >= 0.25 and (best is None or area > best[0]):
            best = (area, layer, (l, t, r - l, b - t))
    if named:
        named.sort(key=lambda x: x[:3])
        return named[0][3], named[0][4]
    return (best[1], best[2]) if best else None


def export_bg(psd_path, out_path):
    """The PSD's background layer saved as a PNG at `out_path` (its own pixels, the size of its rectangle).
    Returns (path, [x, y, w, h]) or None."""
    from .artist_design.psd_reader import open_psd

    psd = open_psd(psd_path)
    hit = bg_layer(psd)
    if not hit:
        return None
    layer, rect = hit
    img = None
    try:
        # a group: all of it, its own switched-on layers (even when the group or its page is hidden)
        img = layer.composite(layer_filter=lambda l: bool(getattr(l, "visible", True))) if layer.is_group() else None
    except Exception:
        img = None
    if img is None or not img.getbbox():
        img = layer.composite()
    if img is None:
        return None
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    img.convert("RGBA").save(out_path)
    return out_path, [int(v) for v in rect]


def _text_box(items):
    """(left, top, right, bottom) around text layers."""
    bx = [i["bbox"] for i in items if i.get("bbox")]
    if not bx:
        return None
    return min(b[0] for b in bx), min(b[1] for b in bx), max(b[2] for b in bx), max(b[3] for b in bx)


def _margin(layers, width, body_font_size):
    """Typical side margin of the wide text blocks (estimate)."""
    sides = []
    for L in layers:
        l, _t, r, _b = L["bbox"]
        if (r - l) >= width * 0.4 and not L["numbers"]:
            sides.append(min(l, width - r))
    if len(sides) < 2:
        return None
    sides.sort()
    return int(sides[len(sides) // 2])


def _rgb_list(hexcol):
    h = str(hexcol or "#FFFFFF").lstrip("#")
    return [int(h[i:i + 2], 16) for i in (0, 2, 4)]


def analyse(path):
    """Read the reference PSD. Returns {ok, fields, styles, detected, not_detected, roles, ...}."""
    from .artist_design.psd_reader import open_psd

    if not path or not os.path.isfile(path):
        return {"ok": False, "error": "PSD not found."}
    if not path.lower().endswith((".psd", ".psb")):
        return {"ok": False, "error": "Choose a .psd file."}
    try:
        psd = open_psd(path)
    except Exception as exc:
        return {"ok": False, "error": f"Could not read the PSD: {exc}"}
    layers = read_layers(psd)
    roles = classify(layers)
    W, H = int(psd.width), int(psd.height)
    fields, detected, missing = [], [], []

    def field(key, label, value, source, confidence="high"):
        fields.append({"key": key, "label": label, "value": value, "source": source,
                       "confidence": confidence, "apply": confidence != "low"})

    field("c_width", "Canvas width", W, "document size")
    field("c_height", "Canvas height", H, "document size")
    detected.append(f"Document size {W} × {H}")

    labels = {"heading": ("h", "Heading"), "body": ("b", "Body")}
    for role in ("heading", "subheading", "body"):
        r = roles.get(role)
        name = role.capitalize()
        if not r:
            missing.append(f"{name} style — no text layer looked like a {role}")
            continue
        src = f"{r['count']} layer{'s' if r['count'] != 1 else ''}, e.g. “{r['sample']}”"
        conf = r["confidence"]
        detected.append(f"{name}: {r['font']} {r['size']}px {r['color']} ({conf} confidence — {r['why']})")
        # the font as the Font / Font style menus show it: "MyriadPro-Bold" -> Myriad Pro + Bold (an installed
        # face, so the Canvas and the build draw it); a font not installed keeps its PostScript name
        face = fontfaces.face_of(r["font"])
        fam, fstyle = (face["family"], face["style"]) if face else (r["font"], "")
        if not face:
            missing.append(f"{name} font “{r['font']}” is not installed on this PC — install it to see it on the Canvas")
        if role in labels:
            p, lab = labels[role]
            field(f"{p}_font", f"{lab} font", fam, src, conf)
            if fstyle:
                field(f"{p}_font_style", f"{lab} font style", fstyle, src, conf)
            field(f"{p}_size", f"{lab} size", r["size"], src, conf)
            field(f"{p}_rgb", f"{lab} colour", r["color"], src, conf)
            field(f"{p}_bold", f"{lab} faux bold", False, "the font face carries the weight", conf)
            sh = r.get("shape")
            if role == "heading" and sh:
                # the Character panel as the artist set it: a layer stretched with Free Transform, squeezed,
                # spaced out or unkerned looks different from plain text at the same size
                field("ds.heading_hscale", "Heading width scale %", sh["hscale"], src + " (Character panel × Free Transform)", conf)
                field("ds.heading_vscale", "Heading height scale %", sh["vscale"], src + " (Character panel)", conf)
                field("ds.heading_tracking", "Heading letter spacing (tracking)", sh["tracking"], src, conf)
                field("ds.heading_kerning", "Heading kerning", sh["kerning"], src, conf)
                if sh["hscale"] != 100 or sh["vscale"] != 100 or sh["tracking"] or sh["kerning"] != "metrics":
                    detected.append(f"Heading text {sh['hscale']:g}% wide × {sh['vscale']:g}% tall, tracking {sh['tracking']}, "
                                    f"kerning {sh['kerning']}")
                if sh.get("blend_if"):
                    field("ds.heading_blend_if", "Heading Blend If (underlying: black, black, white, white)", sh["blend_if"],
                          src + " — Blending Options › Blend If: hidden over a background outside this range", conf)
                    detected.append(f"Heading Blend If, underlying layer {sh['blend_if']}")
        else:
            field("ds.subheading_font_request", "Subheading font", fam, src, conf)
            if fstyle:
                field("ds.subheading_font_style", "Subheading font style", fstyle, src, conf)
            field("ds.subheading_size", "Subheading size", r["size"], src, conf)
            field("ds.subheading_rgb", "Subheading colour", r["color"], src, conf)
        if r["layer_style"]:
            detected.append(f"{name} layer style (from {r['layer_style_layers']} layer{'s' if r['layer_style_layers'] != 1 else ''})")
        else:
            missing.append(f"{name} layer style — its layers have none")

    body = roles.get("body")
    if body:
        field("alignment", "Text alignment", body["alignment"], "body text layers", body["confidence"])
        ratio = body.get("line_ratio")
        if ratio and abs(ratio - 1.2) > 0.01:                 # 1.2 = Photoshop auto leading: not a real choice
            field("line_spacing", "Line spacing", ratio, "body leading ÷ size", "medium")
            detected.append(f"Line spacing {ratio}")
        else:
            missing.append("Line spacing — the PSD uses Photoshop's automatic leading")
        m = _margin(layers, W, body["size"])
        if m is not None and 0 < m < W * 0.4:
            field("margin_x", "Side margin", m, "wide text blocks (estimate)", "medium")
            detected.append(f"Side margin ≈ {m}px (estimate)")
        else:
            missing.append("Side margins — not enough wide text blocks to measure")
    else:
        missing.append("Alignment, line spacing and margins — no body text found")

    # the background: where it sits on the canvas (its pixels are saved into the game when applied)
    bg = bg_layer(psd)
    if bg:
        layer, (bx, by, bw, bh) = bg
        whole = bx <= 0 and by <= 0 and bx + bw >= W and by + bh >= H
        field("bg_mode", "Background placement", "cover" if whole else "place",
              f"layer “{layer.name}”" + (" covers the canvas" if whole else f" at {bx}, {by}"))
        if not whole:
            field("bg_rect", "Background rectangle (x, y, width, height)", [bx, by, bw, bh], f"layer “{layer.name}”")
        field("bg_from_psd", "Use the PSD's background picture", True, f"layer “{layer.name}”, {bw} × {bh}px")
        detected.append(f"Background layer “{layer.name}” {bw} × {bh}px at {bx}, {by}")
    else:
        missing.append("Background — no layer named BG / Background, and no large picture layer")

    # the text's margins on the canvas: the heading's top, the paragraph's sides and bottom
    def role_items(role):
        r = roles.get(role)
        return [L for L in layers if r and L["font"] == r["font"] and round(L["size"]) == round(r["size"])
                and not L["numbers"] and L.get("visible", True)]
    hb = _text_box(role_items("heading"))
    if hb:
        field("heading_top_margin", "Heading top margin", max(0, hb[1]), "top of the heading layers", "medium")
    bb = _text_box(role_items("body"))
    if bb:
        field("inner_canvas_width", "Text width (side margins)", max(100, bb[2] - bb[0]),
              f"paragraph from x {bb[0]} to {bb[2]}", "medium")
        field("bottom_margin", "Bottom margin", max(0, H - bb[3]), "bottom of the lowest paragraph", "medium")
        detected.append(f"Text area x {bb[0]}–{bb[2]}, bottom margin {H - bb[3]}px")
    missing.append("Symbols, Excel, background file and other paths — never taken from another game")

    # Layer › Layer Style › Global Light: the angle its "Use Global Light" shadows / bevels are drawn at
    from . import global_light

    light = global_light.read_psd(path)
    if light:
        field("ds.fx_global_light", "Global light (angle, altitude)", [light["angle"], light["altitude"]],
              "Layer Style › Global Light")

    styles = {}
    stem = os.path.splitext(os.path.basename(path))[0]
    for role, r in roles.items():
        if r.get("layer_style"):
            # the text size the style was made at (its effects scale from it when the text size changes)
            # and the PSD's Global Light: a "Use Global Light" shadow / bevel ignores the angle saved in
            # the style and takes the document's (Buffalo_Help.psd: saved 120°, drawn at 90°) — the style
            # carries it so ticking only the heading still gives the angle Photoshop draws
            styles[ROLE_NAMES[role]] = {"name": f"{stem} {role}",
                                        "style": fx_scale.remember_size(r["layer_style"], r["size"]),
                                        "apply": r["confidence"] != "low"}
            if light and global_light.style_angles([r["layer_style"]]):
                styles[ROLE_NAMES[role]]["global_light"] = light
    return {
        "ok": True, "path": path, "width": W, "height": H, "text_layers": len(layers),
        "roles": {k: {kk: vv for kk, vv in v.items() if kk != "layer_style"} for k, v in roles.items()},
        "fields": fields, "styles": styles, "detected": detected, "not_detected": missing,
    }


_INT = {"c_width", "c_height", "margin_x", "heading_top_margin", "inner_canvas_width", "bottom_margin"}
_NUM = {"h_size", "b_size", "line_spacing", "ds.subheading_size", "ds.heading_hscale", "ds.heading_vscale",
        "ds.heading_tracking"}
_BOOL = {"h_bold", "b_bold"}
ALLOWED = {"c_width", "c_height", "margin_x", "h_font", "h_font_style", "h_size", "h_rgb", "h_bold", "b_font",
           "b_font_style", "b_size", "b_rgb", "b_bold", "alignment", "line_spacing",
           "ds.subheading_font_request", "ds.subheading_font_style", "ds.subheading_size", "ds.subheading_rgb",
           "heading_top_margin", "inner_canvas_width", "bottom_margin", "bg_mode", "bg_rect", "ds.fx_global_light",
           "ds.heading_hscale", "ds.heading_vscale", "ds.heading_tracking", "ds.heading_kerning", "ds.heading_blend_if"}


def apply(style, fields, styles=None):
    """Write reviewed fields [{key, value, apply}] and layer styles into a game style.

    Only formatting keys are accepted (ALLOWED) — never a path."""
    style = dict(style or {})
    ds = dict(style.get("dynamic_settings") or {})
    blend = False                                     # Blend If field not ticked: the style keeps its own
    for f in fields or []:
        key = f.get("key")
        if key not in ALLOWED or f.get("apply") is False:
            continue
        value = f.get("value")
        try:
            if key == "ds.fx_global_light":
                from . import global_light

                if isinstance(value, (list, tuple)):
                    value = {"angle": value[0] if value else None, "altitude": value[1] if len(value) > 1 else None}
                value = global_light.clean(value)
                if value is None:
                    continue
            elif key == "ds.heading_blend_if":
                from . import blend_if

                if isinstance(value, str):
                    value = [v for v in re.split(r"[,\s]+", value) if v]
                blend = blend_if.clean(value)               # None = the default: nothing hidden
                continue
            elif key == "ds.heading_kerning":
                value = "none" if str(value).strip().lower() in ("none", "0", "off", "false") else "metrics"
            elif key in ("ds.heading_hscale", "ds.heading_vscale"):
                value = max(1.0, min(1000.0, float(value)))
                value = int(value) if value.is_integer() else round(value, 2)
            elif key == "bg_rect":
                value = [int(round(float(v))) for v in value]
                if len(value) != 4 or value[2] <= 0 or value[3] <= 0:
                    continue
            elif key == "bg_mode":
                value = str(value)
                if value not in ("place", "cover", "fit", "fit_width", "stretch"):
                    continue
            elif key in _INT:
                value = int(round(float(value)))
            elif key in _NUM:
                value = float(value)
                value = int(value) if value.is_integer() and key != "line_spacing" else value
            elif key in _BOOL:
                value = bool(value) and str(value).lower() not in ("false", "0", "no")
            else:
                value = str(value)
        except (TypeError, ValueError):
            continue
        if key == "ds.subheading_rgb":
            value = _rgb_list(value)
        if key.startswith("ds."):
            ds[key[3:]] = value
        else:
            style[key] = value
    lib = dict(ds.get("layer_style_library") or {})
    assign = dict(ds.get("style_assignments") or {})
    light_field = any(f.get("key") == "ds.fx_global_light" and f.get("apply") is not False for f in fields or [])
    for role, entry in (styles or {}).items():
        if not isinstance(entry, dict) or entry.get("apply") is False or not isinstance(entry.get("style"), dict):
            continue
        if role not in ROLE_NAMES.values():
            continue
        name = str(entry.get("name") or role)
        lib[name] = entry["style"]
        assign[role] = name
        # like a style copied from Photoshop: its document's Global Light comes with it (the ticked
        # Global light field, which the artist may have edited, wins)
        if not light_field and entry.get("global_light"):
            from . import global_light

            light = global_light.clean(entry["global_light"])
            if light:
                ds["fx_global_light"] = light
    if blend is not False and lib.get(assign.get("Heading text")) is not None:
        # Blend If is part of the heading's layer style (Photoshop's Blending Options, drawn with it)
        name = assign["Heading text"]
        lib[name] = {k: v for k, v in lib[name].items() if k != "blend_if"}
        if blend:
            lib[name]["blend_if"] = {"under": blend}
    if lib:
        ds["layer_style_library"] = lib
        ds["style_assignments"] = assign
    if ds:
        style["dynamic_settings"] = ds
    return style
