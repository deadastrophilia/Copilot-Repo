"""Geometry manifests for cross-renderer layout parity checks.

A manifest is a JSON-serializable snapshot of where every element lands on
the canvas. Comparing manifests from two renderers (PNG pipeline vs PSAPI
PSD writer, or two runs of the same renderer) turns layout drift into an
explicit, testable diff instead of a silent visual regression.

PNG side: canonical PageLayout objects serialize via PageLayout.to_dict().
PSAPI side: PSAPIRenderBackend(record_ops=True) records every text/image
placement in op_log; manifest_from_backend_ops() converts that log.
"""

from __future__ import annotations

import json
import math
import os
import re

MANIFEST_VERSION = 1

_ELEMENT_KEYS = (
    "id", "type", "x", "y", "width", "height", "text", "font", "size",
    "bold", "align", "wrapped_lines", "line_widths",
)


def _norm_text(value) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip().casefold()


def _center(element: dict) -> float:
    x = element.get("x") or 0.0
    width = element.get("width")
    if width in (None, 0):
        runs = element.get("line_widths") or []
        if runs:
            width = runs[0]
    return float(x) + float(width or 0.0) / 2.0


def manifest_from_layouts(layouts) -> dict:
    """Serialize canonical PageLayout objects into a manifest dict."""
    pages = []
    for layout in layouts or []:
        data = layout.to_dict() if hasattr(layout, "to_dict") else dict(layout or {})
        pages.append({
            "source": data.get("source") or {},
            "canvas": data.get("canvas") or {},
            "elements": [
                {key: raw.get(key) for key in _ELEMENT_KEYS if key in raw}
                for raw in (data.get("elements") or [])
            ],
        })
    return {"manifest_version": MANIFEST_VERSION, "pages": pages}


def manifest_from_backend_ops(ops, canvas_w=0, canvas_h=0) -> dict:
    """Convert PSAPIRenderBackend.op_log entries into a manifest dict."""
    elements = []
    for op in ops or []:
        kind = str(op.get("op") or "")
        entry = {
            "id": op.get("name") or "",
            "type": "text" if kind == "text" else "image",
            "x": op.get("x"),
            "y": op.get("y"),
            "width": op.get("w"),
            "height": op.get("h"),
        }
        if kind == "text":
            entry["text"] = op.get("text")
            entry["font"] = op.get("font")
            entry["size"] = op.get("size")
        elements.append(entry)
    return {
        "manifest_version": MANIFEST_VERSION,
        "pages": [{
            "source": {},
            "canvas": {"width": canvas_w, "height": canvas_h},
            "elements": elements,
        }],
    }


def diff_manifests(a: dict, b: dict, tol_px: float = 2.0) -> list:
    """Compare two manifests; return a list of human-readable mismatches."""
    issues = []
    pages_a = (a or {}).get("pages") or []
    pages_b = (b or {}).get("pages") or []
    if len(pages_a) != len(pages_b):
        issues.append(f"page count differs: {len(pages_a)} vs {len(pages_b)}")
        return issues
    for page_index, (pa, pb) in enumerate(zip(pages_a, pages_b), start=1):
        ea = pa.get("elements") or []
        eb = pb.get("elements") or []
        if len(ea) != len(eb):
            issues.append(
                f"page {page_index}: element count differs: {len(ea)} vs {len(eb)}"
            )
            continue
        for idx, (ra, rb) in enumerate(zip(ea, eb)):
            label = f"page {page_index} element {idx} ({ra.get('id') or ra.get('type')})"
            ta, tb = str(ra.get("type") or ""), str(rb.get("type") or "")
            if ta != tb:
                issues.append(f"{label}: type differs ({ta} vs {tb})")
                continue
            text_a, text_b = ra.get("text"), rb.get("text")
            if text_a is not None and text_b is not None:
                if _norm_text(text_a) != _norm_text(text_b):
                    issues.append(f"{label}: text differs ({text_a!r} vs {text_b!r})")
                    continue
            ca, cb = _center(ra), _center(rb)
            if math.isfinite(ca) and math.isfinite(cb) and abs(ca - cb) > tol_px:
                issues.append(f"{label}: center-x differs by {abs(ca - cb):.2f}px")
            ya, yb = float(ra.get("y") or 0), float(rb.get("y") or 0)
            if abs(ya - yb) > tol_px:
                issues.append(f"{label}: y differs by {abs(ya - yb):.2f}px")
    return issues


def write_manifest(path: str, manifest: dict) -> str:
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, sort_keys=True)
    return path


def read_manifest(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)
