"""fx_text_roundtrip — a styled TEXT LAYER in Photoshop vs the same text drawn by the tool.

The check behind "what Photoshop shows is what the Canvas / build shows": Photoshop makes a real type
layer (font, size, colour, the layer style, the document's Global Light) and exports it; the tool draws
the same text with the build's own text path (png_builder._draw_inline: the font file, layer-style
engine ps_fx_png, effect scaling). Both are lined up by their plain glyphs and compared:

  glyphs   plain text, no style: the font / weight / size (a "bolder" heading shows up here)
  all      the whole style
  <kind>   one effect at a time (gradient_overlay, stroke, inner_glow, …): which effect differs

Photoshop is only driven through photoshop_bridge (temporary documents, closed unsaved; the user's open
documents are never touched). tools/ps_text_roundtrip.py is the command line.
"""

from __future__ import annotations

import json
import os
import tempfile
import uuid

import numpy as np
from PIL import Image

# captured_params kinds -> the effect keys of a Photoshop layerEffects descriptor (stringIDs)
KIND_KEYS = {
    "drop_shadow": ("dropShadow", "dropShadowMulti"),
    "inner_shadow": ("innerShadow", "innerShadowMulti"),
    "outer_glow": ("outerGlow",),
    "inner_glow": ("innerGlow",),
    "bevel": ("bevelEmboss",),
    "satin": ("chromeFX",),
    "color_overlay": ("solidFill", "solidFillMulti"),
    "gradient_overlay": ("gradientFill", "gradientFillMulti"),
    "pattern_overlay": ("patternFill",),
    "stroke": ("frameFX", "frameFXMulti"),
}
_KEEP_ALWAYS = ("scale", "masterFXSwitch")

_JSX = r"""
(function (args) {
    var outDir = args[0], font = args[1], size = Number(args[2]), text = args[3], hex = args[4];
    var effectsHex = args[5], lightAngle = Number(args[6]), lightAltitude = Number(args[7]);
    var W = Number(args[8]), H = Number(args[9]), x = Number(args[10]), y = Number(args[11]);
    var kinds = args[12] ? args[12].split(";") : [];
    var kerning = args[13] || "metrics";
    var prevDialogs = app.displayDialogs, prevUnits = app.preferences.rulerUnits, prevType = app.preferences.typeUnits;
    app.displayDialogs = DialogModes.NO;
    app.preferences.rulerUnits = Units.PIXELS;
    app.preferences.typeUnits = TypeUnits.PIXELS;
    var doc = app.documents.add(W, H, 72, "psh_roundtrip", NewDocumentMode.RGB, DocumentFill.TRANSPARENT);
    var out = {};
    function png(name) {
        var opts = new PNGSaveOptions();
        opts.interlaced = false;
        doc.saveAs(new File(outDir + "/" + name + ".png"), opts, true, Extension.LOWERCASE);
    }
    function effects() {
        var stream = "";
        for (var i = 0; i < effectsHex.length; i += 4) stream += String.fromCharCode(parseInt(effectsHex.substr(i, 4), 16));
        var d = new ActionDescriptor();
        d.fromStream(stream);
        return d;
    }
    // only these effect keys of the style (+ its scale): one effect at a time
    function subset(d, keep) {
        var o = new ActionDescriptor();
        for (var i = 0; i < d.count; i++) {
            var k = d.getKey(i), s = typeIDToStringID(k);
            var on = false;
            for (var j = 0; j < keep.length; j++) if (keep[j] == s) on = true;
            if (s == "scale" || s == "masterFXSwitch") on = true;
            if (!on) continue;
            var t = d.getType(k);
            if (t == DescValueType.OBJECTTYPE) o.putObject(k, d.getObjectType(k), d.getObjectValue(k));
            else if (t == DescValueType.LISTTYPE) o.putList(k, d.getList(k));
            else if (t == DescValueType.UNITDOUBLE) o.putUnitDouble(k, d.getUnitDoubleType(k), d.getUnitDoubleValue(k));
            else if (t == DescValueType.BOOLEANTYPE) o.putBoolean(k, d.getBoolean(k));
            else if (t == DescValueType.DOUBLETYPE) o.putDouble(k, d.getDouble(k));
            else if (t == DescValueType.INTEGERTYPE) o.putInteger(k, d.getInteger(k));
        }
        return o;
    }
    function apply(d) {
        var setDesc = new ActionDescriptor(), ref = new ActionReference();
        ref.putProperty(stringIDToTypeID("property"), stringIDToTypeID("layerEffects"));
        ref.putEnumerated(stringIDToTypeID("layer"), stringIDToTypeID("ordinal"), stringIDToTypeID("targetEnum"));
        setDesc.putReference(stringIDToTypeID("null"), ref);
        setDesc.putObject(stringIDToTypeID("to"), stringIDToTypeID("layerEffects"), d);
        executeAction(stringIDToTypeID("set"), setDesc, DialogModes.NO);
    }
    function clear() {
        try {
            var d = new ActionDescriptor(), ref = new ActionReference();
            ref.putEnumerated(charIDToTypeID("Lyr "), charIDToTypeID("Ordn"), charIDToTypeID("Trgt"));
            d.putReference(charIDToTypeID("null"), ref);
            executeAction(stringIDToTypeID("disableLayerStyle"), d, DialogModes.NO);
        } catch (e) { }
    }
    try {
        pshSetGlobalLight(lightAngle, lightAltitude);
        var layer = doc.artLayers.add();
        layer.kind = LayerKind.TEXT;
        var ti = layer.textItem;
        ti.kind = TextType.POINTTEXT;
        ti.contents = text;
        ti.font = font;
        ti.size = new UnitValue(size, "px");
        var c = new SolidColor();
        c.rgb.hexValue = hex;
        ti.color = c;
        ti.justification = Justification.LEFT;
        try {
            // (plain if / else: ExtendScript gets nested ?: wrong)
            var kern = AutoKernType.METRICS;
            if (kerning == "none") kern = AutoKernType.MANUAL;
            if (kerning == "optical") kern = AutoKernType.OPTICAL;
            ti.autoKerning = kern;
            if (kerning == "none") ti.tracking = 0;
        } catch (e) { }
        try { out.kerning = String(ti.autoKerning); } catch (e) { }
        ti.position = [new UnitValue(x, "px"), new UnitValue(y, "px")];
        out.font = ti.font;
        try { out.fauxBold = ti.fauxBold; } catch (e) { out.fauxBold = null; }
        png("plain");
        var b = layer.bounds;
        out.bounds = [b[0].as("px"), b[1].as("px"), b[2].as("px"), b[3].as("px")];
        if (effectsHex) {
            var full = effects();
            apply(full);
            png("all");
            for (var k = 0; k < kinds.length; k++) {
                var pair = kinds[k].split("=");
                clear();
                apply(subset(full, pair[1].split(",")));
                png(pair[0]);
            }
        }
    } finally {
        doc.close(SaveOptions.DONOTSAVECHANGES);
        app.preferences.rulerUnits = prevUnits;
        app.preferences.typeUnits = prevType;
        app.displayDialogs = prevDialogs;
    }
    return out.toSource ? out.toSource() : String(out.font);
})(arguments);
"""


def kinds_in(params):
    """The effect kinds a style really draws (enabled), in KIND_KEYS order."""
    out = []
    for kind in KIND_KEYS:
        eff = (params or {}).get(kind)
        items = eff if isinstance(eff, list) else [eff]
        if any(isinstance(e, dict) and e.get("enabled", True) is not False for e in items):
            out.append(kind)
    return out


def subset_style(style, params, kind):
    """The style with only `kind` (readable params: the tool's engine draws captured_params)."""
    keep = {k: v for k, v in params.items() if k in ("opacity", "fill_opacity", "is_fill_enabled") or k == kind}
    keep["source"] = "descriptor"
    out = {k: v for k, v in style.items() if k not in ("effects_block", "captured_effects_hex", "captured_params")}
    out["captured_params"] = keep
    return out


def photoshop_text(work, font_ps, size, text, rgb_hex, effects_hex4, light, canvas, origin, kinds, kerning="metrics"):
    """Photoshop's renders (PNG paths by name) and what it reported (font used, faux bold, bounds)."""
    from . import fx_verify, photoshop_bridge

    spec = ";".join(f"{k}={','.join(KIND_KEYS[k])}" for k in kinds)
    raw = photoshop_bridge.run_jsx(
        fx_verify.GLOBAL_LIGHT_JSX + _JSX,
        args=[work.replace("\\", "/"), font_ps, str(size), text, rgb_hex.lstrip("#"), effects_hex4 or "",
              str((light or {}).get("angle", "")), str((light or {}).get("altitude", "")),
              str(canvas[0]), str(canvas[1]), str(origin[0]), str(origin[1]), spec, kerning],
        timeout=600,
    )
    names = ["plain"] + (["all"] + list(kinds) if effects_hex4 else [])
    return {n: os.path.join(work, n + ".png") for n in names}, str(raw)


def tool_text(font_request, size, text, rgb, style, canvas, origin_top):
    """The tool's render of the text (the build's _draw_inline), on a transparent page."""
    from . import png_builder as pb

    Image_, ImageDraw, ImageFont = pb._require_pillow()
    page = Image.new("RGBA", canvas, (0, 0, 0, 0))
    font = pb._load_font(ImageFont, font_request, int(size), bold=True)
    pb._draw_inline(page, ImageDraw.Draw(page), Image_, text, origin_top[0], origin_top[1], font, tuple(rgb),
                    canvas[0] - origin_top[0], "", {}, int(size), None, align="left", line_spacing=0,
                    fx_config=style, font_request=font_request, font_size=int(size), bold=True, strips=False)
    return page


def _alpha_box(img, cut=128):
    a = np.asarray(img.convert("RGBA"))[..., 3]
    ys, xs = np.nonzero(a >= cut)
    return (int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1) if len(xs) else None


def shift(img, dx, dy):
    out = Image.new("RGBA", img.size, (0, 0, 0, 0))
    out.paste(img, (dx, dy))
    return out


def compare(ps_img, tool_img, backdrop=(128, 128, 128)):
    """Mean |ΔRGB| (0–255) where either has ink, the share of those pixels off by more than 32, and how
    many more ink pixels the tool has (+ = the tool's drawing is heavier)."""
    bg = Image.new("RGBA", ps_img.size, backdrop + (255,))
    a = np.asarray(Image.alpha_composite(bg, ps_img.convert("RGBA")), np.float32)[..., :3]
    b = np.asarray(Image.alpha_composite(bg, tool_img.convert("RGBA")), np.float32)[..., :3]
    pa, pb_ = np.asarray(ps_img.convert("RGBA"))[..., 3], np.asarray(tool_img.convert("RGBA"))[..., 3]
    mask = (pa > 8) | (pb_ > 8)
    if not mask.any():
        return {"mean": 0.0, "bad_pct": 0.0, "ink_ps": 0, "ink_tool": 0, "ink_diff_pct": 0.0}
    d = np.abs(a - b)[mask]
    ink_ps, ink_tool = int((pa > 128).sum()), int((pb_ > 128).sum())
    return {"mean": round(float(d.mean()), 2), "bad_pct": round(float((d.max(axis=1) > 32).mean() * 100), 2),
            "ink_ps": ink_ps, "ink_tool": ink_tool,
            "ink_diff_pct": round((ink_tool - ink_ps) * 100.0 / max(1, ink_ps), 2)}


def run(style, font_request, size, text="GAME RULES", rgb="#FFFFFF", light=None, out_dir=None, per_effect=True,
        kerning="metrics"):
    """Photoshop vs the tool for one style. Returns {"font", "faux_bold", "offset", "rows": {name: stats}, "dir"}."""
    from . import fontfaces, fx_descriptor, fx_verify, global_light

    style = dict(style or {})
    params = fx_descriptor.effective_params(style) or {}
    face = fontfaces.face_of(font_request, bold=True) or {}
    font_ps = face.get("ps") or str(font_request).split("|")[0]
    light = global_light.clean(light) if light else (global_light.current()
                                                    or global_light.for_document({"layer_style_library": {"s": style}}))
    pad = int(max(60, size))
    canvas = (int(size * (0.75 * len(text) + 1)) + 2 * pad, int(size * 1.6) + 2 * pad)
    work = out_dir or os.path.join(tempfile.gettempdir(), f"psh_roundtrip_{uuid.uuid4().hex[:8]}")
    os.makedirs(work, exist_ok=True)
    kinds = kinds_in(params) if per_effect else []
    # Photoshop gets the effects at this text size, as the build draws them and the PSD writer stores
    # them (fx_scale: a style made for 207 px text, drawn at 120 px, has its lengths × 120/207)
    from . import fx_scale

    hex4 = fx_verify.descriptor_hex4(fx_scale.scaled(style, size))
    ps_files, raw = photoshop_text(work, font_ps, size, text, rgb, hex4, light, canvas,
                                   (pad, pad + int(size)), kinds, kerning)
    rgb3 = tuple(int(str(rgb).lstrip("#")[i:i + 2], 16) for i in (0, 2, 4))
    prev = global_light.current()
    global_light.set_all({"fx_global_light": light} if light else {})
    try:
        tool = {"plain": tool_text(font_request, size, text, rgb3, None, canvas, (pad, pad))}
        if hex4:
            tool["all"] = tool_text(font_request, size, text, rgb3, style, canvas, (pad, pad))
            for k in kinds:
                tool[k] = tool_text(font_request, size, text, rgb3, subset_style(style, params, k), canvas, (pad, pad))
    finally:
        global_light.set_all({"fx_global_light": prev} if prev else {})
    ps = {n: Image.open(p).convert("RGBA") for n, p in ps_files.items() if os.path.isfile(p)}
    if "plain" not in ps:
        raise RuntimeError(f"Photoshop wrote no render ({raw[:200]}).")
    # line the two up by their plain glyphs (the tool places by line box, Photoshop by baseline)
    bp, bt = _alpha_box(ps["plain"]), _alpha_box(tool["plain"])
    dx, dy = (bp[0] - bt[0], bp[1] - bt[1]) if bp and bt else (0, 0)
    # a threshold box can land a pixel off: the whole-pixel offset nearby that fits the glyphs best
    best = None
    for ox in (-1, 0, 1):
        for oy in (-1, 0, 1):
            m = compare(ps["plain"], shift(tool["plain"], dx + ox, dy + oy))["mean"]
            if best is None or m < best[0]:
                best = (m, dx + ox, dy + oy)
    dx, dy = best[1], best[2]
    rows = {}
    for name, img in tool.items():
        if name not in ps:
            continue
        moved = shift(img, dx, dy)
        moved.save(os.path.join(work, f"{name}.tool.png"))
        rows[name] = compare(ps[name], moved)
        if name == "plain":
            rows[name]["box_ps"], rows[name]["box_tool"] = bp, (bt[0] + dx, bt[1] + dy, bt[2] + dx, bt[3] + dy) if bt else None
    with open(os.path.join(work, "report.json"), "w", encoding="utf-8") as fh:
        json.dump({"font_ps": font_ps, "photoshop": raw, "offset": [dx, dy], "rows": rows, "light": light}, fh, indent=1)
    return {"font": font_ps, "photoshop": raw, "offset": (dx, dy), "rows": rows, "dir": work, "light": light}
