"""Visual Excel-to-PSD slot mapper for artist-authored custom layouts."""

import os
import tkinter as tk
from tkinter import colorchooser, filedialog, messagebox, ttk

from .icon_mapping import list_icon_files, normalize_token, resolve_icon_path

from .template_mapping import (
    extract_existing_mappings,
    load_base_template,
    save_mapped_template,
    scan_excel_content,
    validate_mappings,
    workbook_sheet_names,
)


DEFAULT_PALETTE = {
    "app_bg": "#101114",
    "sidebar_bg": "#15171B",
    "panel_bg": "#1A1C20",
    "panel_soft": "#202329",
    "input_bg": "#24262B",
    "border": "#34363D",
    "text": "#F8F5EA",
    "muted": "#B8B2A3",
    "accent": "#F6C343",
    "accent_alt": "#E89B24",
    "success": "#4CAF50",
    "danger": "#E05252",
}

EXCEL_FILETYPES = [
    ("Excel workbooks", "*.xlsx;*.xlsm"),
    ("Excel workbook", "*.xlsx"),
    ("Excel macro-enabled workbook", "*.xlsm"),
    ("All files", "*.*"),
]


def _int(value, fallback):
    try:
        return int(value)
    except Exception:
        return int(fallback)


def _padding_values(variables):
    return [_int(variable.get(), 0) for variable in variables]


def _clean_hex(value, fallback="#FFFFFF"):
    text = str(value or "").strip()
    if not text.startswith("#"):
        text = "#" + text
    if len(text) == 7:
        try:
            int(text[1:], 16)
            return text.upper()
        except Exception:
            pass
    return str(fallback).upper()


def _contrast_text(hex_color):
    color = _clean_hex(hex_color, "#000000").lstrip("#")
    try:
        red = int(color[0:2], 16)
        green = int(color[2:4], 16)
        blue = int(color[4:6], 16)
        return "#101114" if (red * 299 + green * 587 + blue * 114) / 1000 > 145 else "#FFFFFF"
    except Exception:
        return "#FFFFFF"


class TemplateMapperDialog(tk.Toplevel):
    def __init__(
            self, parent, initial_excel="", initial_json="", output_folder="",
            on_saved=None, palette=None, initial_font_size=30,
            icons_folder="", initial_icon_mappings=None):
        super().__init__(parent)
        self.parent = parent
        self.palette = dict(DEFAULT_PALETTE)
        self.palette.update(palette or {})
        self.on_saved = on_saved
        self.output_folder = str(output_folder or "")
        self.initial_icon_mappings = dict(initial_icon_mappings or {})
        self.icon_overrides = {}
        self.template = None
        self.blocks = []
        self.source_items = {}
        self.mappings = []
        self.slot_rectangles = []
        self._syncing_selection = False
        self.active_mapping_index = None

        self.title("Visual Template Mapper")
        screen_width = max(900, int(self.winfo_screenwidth()))
        screen_height = max(650, int(self.winfo_screenheight()))
        initial_width = min(1320, screen_width - 100)
        initial_height = min(820, screen_height - 120)
        self.geometry(f"{initial_width}x{initial_height}")
        self.minsize(min(860, initial_width), min(580, initial_height))
        self.configure(bg=self.palette["app_bg"])
        self.resizable(True, True)

        self.excel_var = tk.StringVar(value=initial_excel)
        self.json_var = tk.StringVar(value=initial_json)
        self.icons_folder_var = tk.StringVar(value=icons_folder)
        self.sheet_var = tk.StringVar()
        self.max_col_var = tk.IntVar(value=100)
        self.slot_var = tk.StringVar()
        self.mode_var = tk.StringVar(value="Flow: text + icons")
        self._last_sel_key = None
        self.font_size_var = tk.IntVar(value=max(1, _int(initial_font_size, 30)))
        self.min_font_size_var = tk.IntVar(value=20)
        self.emergency_min_font_size_var = tk.IntVar(value=6)
        self.icon_height_var = tk.IntVar(value=48)
        self.gap_var = tk.IntVar(value=18)
        self.min_gap_var = tk.IntVar(value=8)
        self.padding_vars = [tk.IntVar(value=0) for _ in range(4)]
        self.vertical_align_var = tk.StringVar(value="top")
        self.token_height_var = tk.IntVar(value=0)
        self.text_color_var = tk.StringVar(value="#FFFFFF")
        self.bg_color_var = tk.StringVar(value="#000000")
        self.opacity_var = tk.IntVar(value=100)
        self.stroke_color_var = tk.StringVar(value="#FFFFFF")
        self.stroke_width_var = tk.IntVar(value=0)
        self.fill_enabled_var = tk.BooleanVar(value=False)
        self.stroke_enabled_var = tk.BooleanVar(value=False)
        self.row_icon_size_var = tk.IntVar(value=0)
        self.row_icon_asset_var = tk.StringVar()
        self.status_var = tk.StringVar(value="Load an Excel workbook and exported slot JSON to begin.")

        self._build_ui()
        self.after_idle(self._load_initial_files)

    def _build_ui(self):
        mapper_style = ttk.Style(self)
        mapper_style.configure(
            "Mapper.Treeview",
            rowheight=28,
            background=self.palette["panel_bg"],
            fieldbackground=self.palette["panel_bg"],
            foreground=self.palette["text"],
        )
        mapper_style.map(
            "Mapper.Treeview",
            background=[("selected", self.palette["accent"])],
            foreground=[("selected", "#101114")],
        )
        shell = ttk.Frame(self, padding=14)
        shell.pack(fill="both", expand=True)

        title_row = ttk.Frame(shell)
        title_row.pack(fill="x", pady=(0, 10))
        ttk.Label(title_row, text="Visual Template Mapper", style="Title.TLabel").pack(side="left")
        ttk.Label(
            title_row,
            text="Connect arbitrary Excel content to artist-authored PSD placeholders.",
            foreground=self.palette["muted"],
            wraplength=520,
        ).pack(side="left", padx=18)

        files = ttk.LabelFrame(shell, text="Source Files")
        files.pack(fill="x", pady=(0, 10))
        files.columnconfigure(1, weight=1)
        ttk.Label(files, text="Excel:").grid(row=0, column=0, sticky="w", padx=10, pady=(10, 5))
        ttk.Entry(files, textvariable=self.excel_var).grid(row=0, column=1, sticky="ew", padx=6, pady=(10, 5))
        ttk.Button(files, text="Browse", command=self._browse_excel).grid(row=0, column=2, padx=(4, 10), pady=(10, 5))
        ttk.Label(files, text="Slot JSON:").grid(row=1, column=0, sticky="w", padx=10, pady=(5, 10))
        ttk.Entry(files, textvariable=self.json_var).grid(row=1, column=1, sticky="ew", padx=6, pady=(5, 10))
        ttk.Button(files, text="Browse", command=self._browse_json).grid(row=1, column=2, padx=(4, 10), pady=(5, 10))
        ttk.Label(files, text="Icons folder:").grid(row=2, column=0, sticky="w", padx=10, pady=(0, 10))
        ttk.Entry(files, textvariable=self.icons_folder_var).grid(row=2, column=1, sticky="ew", padx=6, pady=(0, 10))
        ttk.Button(files, text="Browse", command=self._browse_icons_folder).grid(row=2, column=2, padx=(4, 10), pady=(0, 10))
        ttk.Label(files, text="Sheet:").grid(row=3, column=0, sticky="w", padx=10, pady=(0, 10))
        self.sheet_combo = ttk.Combobox(files, textvariable=self.sheet_var, width=22, state="readonly")
        self.sheet_combo.grid(row=3, column=1, sticky="w", padx=6, pady=(0, 10))
        self.sheet_combo.bind("<<ComboboxSelected>>", lambda _event: self._scan_excel())
        ttk.Label(files, text="Max column:").grid(row=3, column=2, sticky="e", padx=(14, 5), pady=(0, 10))
        ttk.Spinbox(files, textvariable=self.max_col_var, from_=1, to=100, width=7).grid(row=3, column=3, sticky="w", pady=(0, 10))
        ttk.Button(files, text="Refresh", command=self._refresh_all_sources).grid(row=3, column=4, sticky="w", padx=10, pady=(0, 10))

        panes = tk.PanedWindow(
            shell,
            orient=tk.HORIZONTAL,
            sashwidth=6,
            bg=self.palette["app_bg"],
            bd=0,
            relief="flat",
        )
        source_panel = ttk.LabelFrame(panes, text="Excel Content")
        preview_panel = ttk.LabelFrame(panes, text="PSD Slot Preview")
        mapping_panel = ttk.LabelFrame(panes, text="Assignments")
        panes.add(source_panel, minsize=220, width=330)
        panes.add(preview_panel, minsize=220, width=360)
        panes.add(mapping_panel, minsize=340, width=430)

        self.source_tree = ttk.Treeview(
            source_panel,
            columns=("source", "preview"),
            show="tree headings",
            selectmode="browse",
            style="Mapper.Treeview",
        )
        self.source_tree.heading("#0", text="Type")
        self.source_tree.heading("source", text="Excel source")
        self.source_tree.heading("preview", text="Content")
        self.source_tree.column("#0", width=74, stretch=False)
        self.source_tree.column("source", width=90, stretch=False)
        self.source_tree.column("preview", width=250, stretch=True)
        source_scroll = ttk.Scrollbar(source_panel, orient="vertical", command=self.source_tree.yview)
        self.source_tree.configure(yscrollcommand=source_scroll.set)
        self.source_tree.pack(side="left", fill="both", expand=True, padx=(8, 0), pady=8)
        source_scroll.pack(side="right", fill="y", padx=(0, 8), pady=8)
        def _on_source_tree_wheel(event):
            self.source_tree.yview_scroll(int(-1 * (event.delta / 120)), "units")
            return "break"
        self.source_tree.bind("<MouseWheel>", _on_source_tree_wheel)
        self.source_tree.bind("<<TreeviewSelect>>", self._source_selected)
        self.source_tree.bind("<Double-1>", lambda _event: self._add_mapping())

        self.preview_canvas = tk.Canvas(
            preview_panel,
            bg=self.palette["app_bg"],
            highlightthickness=0,
            bd=0,
        )
        self.preview_canvas.pack(fill="both", expand=True, padx=8, pady=8)
        self.preview_canvas.bind("<Configure>", lambda _event: self._draw_preview())

        mapping_split = tk.PanedWindow(
            mapping_panel,
            orient=tk.VERTICAL,
            sashwidth=6,
            bg=self.palette["app_bg"],
            bd=0,
            relief="flat",
        )
        mapping_split.pack(fill="both", expand=True)
        mapping_control_outer = ttk.Frame(mapping_split)
        mapping_assign_outer = ttk.Frame(mapping_split)
        mapping_control_outer.configure(height=520)
        mapping_assign_outer.configure(height=240)
        mapping_split.add(mapping_control_outer, minsize=260)
        mapping_split.add(mapping_assign_outer, minsize=150)

        mapping_control_canvas = tk.Canvas(
            mapping_control_outer,
            bg=self.palette["app_bg"],
            highlightthickness=0,
            bd=0,
        )
        mapping_control_scroll = ttk.Scrollbar(
            mapping_control_outer,
            orient="vertical",
            command=mapping_control_canvas.yview,
        )
        mapping_control_canvas.configure(yscrollcommand=mapping_control_scroll.set)
        mapping_controls = ttk.Frame(mapping_control_canvas)
        mapping_controls_window = mapping_control_canvas.create_window(
            (0, 0),
            window=mapping_controls,
            anchor="nw",
        )
        mapping_controls.bind(
            "<Configure>",
            lambda _event: mapping_control_canvas.configure(scrollregion=mapping_control_canvas.bbox("all")),
        )
        mapping_control_canvas.bind(
            "<Configure>",
            lambda event: mapping_control_canvas.itemconfigure(mapping_controls_window, width=event.width),
        )
        def _on_control_mousewheel(event):
            mapping_control_canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        for _ctrl_widget in (mapping_control_canvas, mapping_controls):
            _ctrl_widget.bind("<MouseWheel>", _on_control_mousewheel)
        mapping_control_canvas.pack(side="left", fill="both", expand=True)
        mapping_control_scroll.pack(side="right", fill="y")

        slot_row = ttk.Frame(mapping_controls)
        slot_row.pack(fill="x", padx=8, pady=(8, 5))
        ttk.Label(slot_row, text="PSD slot:").pack(side="left")
        self.slot_combo = ttk.Combobox(slot_row, textvariable=self.slot_var, state="readonly")
        self.slot_combo.pack(side="left", fill="x", expand=True, padx=(8, 0))
        self.slot_combo.bind("<<ComboboxSelected>>", self._slot_selected)

        options = ttk.Frame(mapping_controls)
        options.pack(fill="x", padx=8, pady=4)
        ttk.Label(options, text="Mode:").grid(row=0, column=0, sticky="w", pady=3)
        self.mode_combo = ttk.Combobox(
            options,
            textvariable=self.mode_var,
            values=("Flow: text + icons", "Text only", "Inline icon size", "Dedicated icon"),
            state="readonly",
            width=22,
        )
        self.mode_combo.grid(row=0, column=1, columnspan=3, sticky="ew", padx=(6, 0), pady=3)
        labels = (
            ("Fixed font", self.font_size_var, 1, 0),
            ("Inline icon", self.icon_height_var, 1, 2),
            ("Block gap", self.gap_var, 2, 0),
            ("Selected icon", self.token_height_var, 2, 2),
        )
        for label, variable, row, column in labels:
            ttk.Label(options, text=label + ":").grid(row=row, column=column, sticky="w", pady=3)
            ttk.Spinbox(options, textvariable=variable, from_=0, to=2000, width=7).grid(
                row=row, column=column + 1, sticky="w", padx=(5, 12), pady=3
            )
        ttk.Label(options, text="Padding T/R/B/L:").grid(row=3, column=0, sticky="w", pady=3)
        padding_host = ttk.Frame(options)
        padding_host.grid(row=3, column=1, columnspan=3, sticky="w", pady=3)
        for variable in self.padding_vars:
            ttk.Spinbox(padding_host, textvariable=variable, from_=0, to=1000, width=5).pack(side="left", padx=(0, 4))
        ttk.Label(options, text="Vertical:").grid(row=4, column=0, sticky="w", pady=3)
        ttk.Combobox(
            options,
            textvariable=self.vertical_align_var,
            values=("top", "center", "bottom"),
            state="readonly",
            width=12,
        ).grid(row=4, column=1, sticky="w", padx=(5, 12), pady=3)
        ttk.Label(options, text="Text color:").grid(row=5, column=0, sticky="w", pady=3)
        self.text_color_button = tk.Button(
            options,
            textvariable=self.text_color_var,
            bg=self.text_color_var.get(),
            fg="#101114",
            width=10,
            relief="ridge",
            command=lambda: self._pick_color(self.text_color_var, self.text_color_button, "Text Color"),
        )
        self.text_color_button.grid(row=5, column=1, sticky="w", padx=(5, 12), pady=3)
        ttk.Label(options, text="Fill:").grid(row=5, column=2, sticky="w", pady=3)
        self.bg_color_button = tk.Button(
            options,
            textvariable=self.bg_color_var,
            bg=self.bg_color_var.get(),
            fg="#FFFFFF",
            width=10,
            relief="ridge",
            command=lambda: self._pick_color(self.bg_color_var, self.bg_color_button, "Fill Color"),
        )
        self.bg_color_button.grid(row=5, column=3, sticky="w", padx=(5, 12), pady=3)
        ttk.Label(options, text="Opacity:").grid(row=6, column=0, sticky="w", pady=3)
        ttk.Spinbox(options, textvariable=self.opacity_var, from_=0, to=100, width=7).grid(
            row=6, column=1, sticky="w", padx=(5, 12), pady=3
        )
        ttk.Label(options, text="Stroke:").grid(row=6, column=2, sticky="w", pady=3)
        stroke_host = ttk.Frame(options)
        stroke_host.grid(row=6, column=3, sticky="w", pady=3)
        self.stroke_color_button = tk.Button(
            stroke_host,
            textvariable=self.stroke_color_var,
            bg=self.stroke_color_var.get(),
            fg="#101114",
            width=10,
            relief="ridge",
            command=lambda: self._pick_color(self.stroke_color_var, self.stroke_color_button, "Stroke Color"),
        )
        self.stroke_color_button.pack(side="left")
        ttk.Label(stroke_host, text="W:").pack(side="left", padx=(8, 2))
        ttk.Spinbox(stroke_host, textvariable=self.stroke_width_var, from_=0, to=50, width=5).pack(side="left")
        ttk.Checkbutton(options, text="Fill", variable=self.fill_enabled_var).grid(row=7, column=1, sticky="w", padx=(5, 12), pady=3)
        ttk.Checkbutton(options, text="Stroke", variable=self.stroke_enabled_var).grid(row=7, column=3, sticky="w", padx=(5, 12), pady=3)
        ttk.Label(options, text="Font size is exact. Overflow is clipped and reported, never auto-shrunk.", foreground=self.palette["muted"], wraplength=390).grid(row=8, column=0, columnspan=4, sticky="w", pady=(4, 2))
        options.columnconfigure(1, weight=1)
        options.columnconfigure(3, weight=1)

        row_icon_frame = ttk.LabelFrame(mapping_controls, text="Icons in Selected Excel Row")
        row_icon_frame.pack(fill="x", padx=8, pady=(5, 7))
        row_icon_list = ttk.Frame(row_icon_frame)
        row_icon_list.pack(fill="x", padx=6, pady=(6, 3))
        self.row_icon_tree = ttk.Treeview(
            row_icon_list,
            columns=("number", "token", "height", "asset"),
            show="headings",
            selectmode="browse",
            height=5,
            style="Mapper.Treeview",
        )
        self.row_icon_tree.heading("number", text="#")
        self.row_icon_tree.heading("token", text="Excel icon token")
        self.row_icon_tree.heading("height", text="Inline height")
        self.row_icon_tree.heading("asset", text="Icon asset")
        self.row_icon_tree.column("number", width=36, stretch=False, anchor="center")
        self.row_icon_tree.column("token", width=170, stretch=True)
        self.row_icon_tree.column("height", width=90, stretch=False, anchor="center")
        self.row_icon_tree.column("asset", width=150, stretch=True)
        row_icon_scroll = ttk.Scrollbar(row_icon_list, orient="vertical", command=self.row_icon_tree.yview)
        self.row_icon_tree.configure(yscrollcommand=row_icon_scroll.set)
        self.row_icon_tree.pack(side="left", fill="both", expand=True)
        row_icon_scroll.pack(side="right", fill="y")
        self.row_icon_tree.bind("<<TreeviewSelect>>", self._row_icon_selected)

        row_icon_actions = ttk.Frame(row_icon_frame)
        row_icon_actions.pack(fill="x", padx=6, pady=(3, 6))
        ttk.Label(row_icon_actions, text="Selected icon height:").pack(side="left")
        ttk.Spinbox(row_icon_actions, textvariable=self.row_icon_size_var, from_=1, to=2000, width=8).pack(
            side="left", padx=(6, 8)
        )
        ttk.Button(row_icon_actions, text="Apply Size", command=self._apply_row_icon_size).pack(side="left")
        ttk.Button(row_icon_actions, text="Clear Size", command=self._clear_row_icon_size).pack(side="left", padx=5)
        ttk.Label(
            row_icon_actions,
            text="Assign the parent row to this PSD slot first.",
            foreground=self.palette["muted"],
        ).pack(side="left", padx=8)

        row_asset_actions = ttk.Frame(row_icon_frame)
        row_asset_actions.pack(fill="x", padx=6, pady=(0, 7))
        ttk.Label(row_asset_actions, text="Icon override:").pack(side="left")
        self.row_icon_asset_combo = ttk.Combobox(row_asset_actions, textvariable=self.row_icon_asset_var, width=24)
        self.row_icon_asset_combo.pack(side="left", fill="x", expand=True, padx=(6, 8))
        ttk.Button(row_asset_actions, text="Apply Asset", command=self._apply_row_icon_asset).pack(side="left")
        ttk.Button(row_asset_actions, text="Browse", command=self._browse_row_icon_asset).pack(side="left", padx=5)
        ttk.Button(row_asset_actions, text="Clear Asset", command=self._clear_row_icon_asset).pack(side="left")

        action_row = ttk.Frame(mapping_assign_outer)
        action_row.pack(fill="x", padx=8, pady=(4, 7))
        ttk.Button(action_row, text="Assign", command=self._add_mapping).pack(side="left")
        ttk.Button(action_row, text="Update", command=self._update_mapping).pack(side="left", padx=5)
        ttk.Button(action_row, text="Remove", command=self._remove_mapping, style="Danger.TButton").pack(side="left")
        ttk.Button(action_row, text="Up", command=lambda: self._move_mapping(-1)).pack(side="right")
        ttk.Button(action_row, text="Down", command=lambda: self._move_mapping(1)).pack(side="right", padx=5)

        self.mapping_tree = ttk.Treeview(
            mapping_assign_outer,
            columns=("kind", "source", "slot"),
            show="headings",
            selectmode="browse",
            height=10,
            style="Mapper.Treeview",
        )
        self.mapping_tree.heading("kind", text="Mode")
        self.mapping_tree.heading("source", text="Excel")
        self.mapping_tree.heading("slot", text="PSD slot")
        self.mapping_tree.column("kind", width=70, stretch=False)
        self.mapping_tree.column("source", width=120, stretch=True)
        self.mapping_tree.column("slot", width=120, stretch=True)
        self.mapping_tree.tag_configure(
            "active_mapping",
            background=self.palette["accent"],
            foreground="#101114",
        )
        mapping_scroll = ttk.Scrollbar(mapping_assign_outer, orient="vertical", command=self.mapping_tree.yview)
        self.mapping_tree.configure(yscrollcommand=mapping_scroll.set)
        self.mapping_tree.pack(side="left", fill="both", expand=True, padx=(8, 0), pady=(0, 8))
        mapping_scroll.pack(side="right", fill="y", padx=(0, 8), pady=(0, 8))
        def _on_mapping_tree_wheel(event):
            self.mapping_tree.yview_scroll(int(-1 * (event.delta / 120)), "units")
            return "break"
        self.mapping_tree.bind("<MouseWheel>", _on_mapping_tree_wheel)
        self.mapping_tree.bind("<<TreeviewSelect>>", self._mapping_selected)
        self.mapping_tree.bind("<Button-1>", self._toggle_mapping_click)

        bottom = ttk.Frame(shell)
        bottom.pack(side="bottom", fill="x", pady=(10, 0))
        ttk.Label(bottom, textvariable=self.status_var, style="Status.TLabel").pack(side="left", fill="x", expand=True)
        ttk.Button(bottom, text="Preflight", command=self._preflight).pack(side="right", padx=5, ipadx=8, ipady=4)
        ttk.Button(bottom, text="Save Mapped JSON", command=self._save, style="Primary.TButton").pack(side="right", padx=5, ipadx=10, ipady=4)
        panes.pack(side="top", fill="both", expand=True)

    def _load_initial_files(self):
        if self.excel_var.get().strip() and os.path.isfile(self.excel_var.get().strip()):
            self._load_excel()
        if self.json_var.get().strip() and os.path.isfile(self.json_var.get().strip()):
            self._load_json()
        self._refresh_icon_asset_choices()

    def _browse_excel(self):
        path = filedialog.askopenfilename(parent=self, filetypes=EXCEL_FILETYPES)
        if path:
            self.excel_var.set(path)
            self._load_excel()

    def _browse_json(self):
        path = filedialog.askopenfilename(parent=self, filetypes=[("JSON", "*.json")])
        if path:
            self.json_var.set(path)
            self._load_json()

    def _browse_icons_folder(self):
        path = filedialog.askdirectory(parent=self)
        if path:
            self.icons_folder_var.set(path)
            self._refresh_icon_asset_choices()
            self._refresh_row_icon_mapper()

    def _refresh_all_sources(self):
        self._scan_excel()
        self._refresh_icon_asset_choices()
        self._refresh_row_icon_mapper()

    def _pick_color(self, variable, button, title):
        initial = _clean_hex(variable.get(), "#FFFFFF")
        _rgb_value, chosen = colorchooser.askcolor(color=initial, title=title, parent=self)
        if not chosen:
            return
        chosen = _clean_hex(chosen, initial)
        variable.set(chosen)
        try:
            button.configure(bg=chosen, fg=_contrast_text(chosen))
        except Exception:
            pass

    def _refresh_icon_asset_choices(self):
        self.row_icon_asset_combo["values"] = list_icon_files(self.icons_folder_var.get().strip())

    def _load_excel(self):
        try:
            sheets = workbook_sheet_names(self.excel_var.get().strip())
            self.sheet_combo["values"] = sheets
            preferred = self.sheet_var.get()
            if preferred not in sheets:
                preferred = next((name for name in sheets if name.casefold() == "paytable"), sheets[0] if sheets else "")
            self.sheet_var.set(preferred)
            self._scan_excel()
        except Exception as exc:
            messagebox.showerror("Excel Error", str(exc), parent=self)

    def _load_json(self):
        try:
            self.template = load_base_template(self.json_var.get().strip())
            slots = list((self.template.get("slots") or {}).keys())
            self.slot_combo["values"] = slots
            if self.slot_var.get() not in slots:
                self.slot_var.set(slots[0] if slots else "")
            self.mappings = extract_existing_mappings(self.template)
            self.icon_overrides = dict(self.template.get("icon_mappings") or {})
            sheet_matches = self.template.get("sheet_match") or []
            if sheet_matches and not self.sheet_var.get():
                self.sheet_var.set(str(sheet_matches[0]))
            self._refresh_mappings()
            self._refresh_icon_asset_choices()
            self._draw_preview()
            self.status_var.set(f"Loaded {len(slots)} PSD slots and {len(self.mappings)} existing assignments.")
        except Exception as exc:
            messagebox.showerror("Template Error", str(exc), parent=self)

    def _scan_excel(self):
        path = self.excel_var.get().strip()
        sheet = self.sheet_var.get().strip()
        if not path or not sheet:
            return
        try:
            self.blocks = scan_excel_content(
                path,
                sheet,
                max_column=self.max_col_var.get(),
                include_numeric=True,
            )
            self._refresh_sources()
            self.status_var.set(f"Found {len(self.blocks)} Excel content blocks in {sheet}.")
        except Exception as exc:
            messagebox.showerror("Excel Scan Error", str(exc), parent=self)

    def _refresh_sources(self):
        self.source_tree.delete(*self.source_tree.get_children())
        self.source_items.clear()
        for block in self.blocks:
            item = self.source_tree.insert(
                "",
                "end",
                text=block.get("kind", "text").title(),
                values=(block["source"], block["text"][:180]),
                open=False,
            )
            self.source_items[item] = {"type": "block", "block": block}
            for cell_block in block.get("cells") or []:
                cell_item = self.source_tree.insert(
                    item,
                    "end",
                    text="Cell",
                    values=(cell_block.get("source", ""), cell_block.get("text", "")[:180]),
                )
                self.source_items[cell_item] = {"type": "cell", "block": cell_block}
            for token_index, token in enumerate(block.get("tokens") or []):
                child = self.source_tree.insert(
                    item,
                    "end",
                    text="Icon",
                    values=(f"Token {token_index + 1}", f"<{token}>")
                )
                self.source_items[child] = {
                    "type": "token",
                    "block": block,
                    "token_index": token_index,
                    "token": token,
                }

    def _selected_source(self):
        selected = self.source_tree.selection()
        return self.source_items.get(selected[0]) if selected else None

    def _selected_mapping_index(self):
        if self.active_mapping_index is not None:
            try:
                index = int(self.active_mapping_index)
                if 0 <= index < len(self.mappings):
                    return index
            except Exception:
                pass
        selected = self.mapping_tree.selection()
        if not selected:
            return None
        try:
            return int(selected[0].split(":", 1)[1])
        except Exception:
            return None

    def _style_from_controls(self):
        return {
            "color": _clean_hex(self.text_color_var.get(), "#FFFFFF"),
            "background_color": _clean_hex(self.bg_color_var.get(), "#000000"),
            "opacity": max(0, min(100, _int(self.opacity_var.get(), 100))),
            "fill_enabled": bool(self.fill_enabled_var.get()),
            "stroke_enabled": bool(self.stroke_enabled_var.get()),
            "stroke_color": _clean_hex(self.stroke_color_var.get(), "#FFFFFF"),
            "stroke_width": max(0, _int(self.stroke_width_var.get(), 0)),
        }

    def _apply_style_to_controls(self, mapping):
        self.text_color_var.set(_clean_hex(mapping.get("color", mapping.get("text_color", "#FFFFFF")), "#FFFFFF"))
        self.bg_color_var.set(_clean_hex(mapping.get("background_color", mapping.get("bg_color", "#000000")), "#000000"))
        self.opacity_var.set(max(0, min(100, _int(mapping.get("opacity", 100), 100))))
        self.fill_enabled_var.set(bool(mapping.get("fill_enabled", False)))
        self.stroke_enabled_var.set(bool(mapping.get("stroke_enabled", False)))
        self.stroke_color_var.set(_clean_hex(mapping.get("stroke_color", "#FFFFFF"), "#FFFFFF"))
        self.stroke_width_var.set(max(0, _int(mapping.get("stroke_width", 0), 0)))
        for variable, button in (
                (self.text_color_var, getattr(self, "text_color_button", None)),
                (self.bg_color_var, getattr(self, "bg_color_button", None)),
                (self.stroke_color_var, getattr(self, "stroke_color_button", None))):
            if button is None:
                continue
            color = _clean_hex(variable.get(), "#FFFFFF")
            try:
                button.configure(bg=color, fg=_contrast_text(color))
            except Exception:
                pass

    def _mapping_conflict_index(self, candidate, ignore_index=None):
        kind = str(candidate.get("kind") or "")
        slot = str(candidate.get("slot") or "").strip().casefold()
        source = str(candidate.get("source") or "").strip().casefold()
        token_index = int(candidate.get("token_index", -1))
        for index, existing in enumerate(self.mappings):
            if index == ignore_index:
                continue
            existing_kind = str(existing.get("kind") or "")
            existing_slot = str(existing.get("slot") or "").strip().casefold()
            if kind == "token" and existing_kind == "token":
                if slot and existing_slot == slot:
                    return index
            elif kind == "inline_token" and existing_kind == "inline_token":
                if (
                    existing_slot == slot
                    and str(existing.get("source") or "").strip().casefold() == source
                    and int(existing.get("token_index", -2)) == token_index
                ):
                    return index
        return None

    def _toggle_mapping_click(self, event):
        item = self.mapping_tree.identify_row(event.y)
        if not item:
            self.active_mapping_index = None
            for selected_item in self.mapping_tree.selection():
                self.mapping_tree.selection_remove(selected_item)
            self._refresh_mappings()
            return "break"
        try:
            clicked_index = int(item.split(":", 1)[1])
        except Exception:
            return "break"
        if clicked_index == self.active_mapping_index:
            self.active_mapping_index = None
            for selected_item in self.mapping_tree.selection():
                self.mapping_tree.selection_remove(selected_item)
            self._refresh_mappings()
            self.status_var.set("Assignment deselected. Select one assignment before using Update.")
            return "break"
        self.active_mapping_index = clicked_index
        self.mapping_tree.selection_set(item)
        self.mapping_tree.focus(item)
        self._refresh_mappings(select_index=clicked_index)
        self._mapping_selected()
        self.status_var.set(f"Assignment {clicked_index + 1} selected. Edit controls, then click Update.")
        return "break"

    def _slot_selected(self, _event=None):
        self._draw_preview()
        self._refresh_row_icon_mapper()

    def _selected_block(self):
        selected = self._selected_source()
        return (selected or {}).get("block")

    def _inline_mapping_index(self, source, slot, token_index):
        source = str(source or "").casefold()
        slot = str(slot or "").casefold()
        for index, mapping in enumerate(self.mappings):
            if mapping.get("kind") != "inline_token":
                continue
            if (
                str(mapping.get("source") or "").casefold() == source
                and str(mapping.get("slot") or "").casefold() == slot
                and int(mapping.get("token_index", -1)) == int(token_index)
            ):
                return index
        return None

    def _token_override(self, token):
        wanted = normalize_token(token)
        for key, value in self.icon_overrides.items():
            if normalize_token(key) == wanted and str(value or "").strip():
                return str(value).strip()
        return ""

    def _combined_icon_mappings(self):
        combined = dict(self.initial_icon_mappings)
        combined.update(self.icon_overrides)
        return combined

    def _resolved_row_icon_asset(self, token):
        return resolve_icon_path(
            token,
            self.icons_folder_var.get().strip(),
            self._combined_icon_mappings(),
        )

    def _refresh_row_icon_mapper(self, select_token_index=None):
        self.row_icon_tree.delete(*self.row_icon_tree.get_children())
        block = self._selected_block()
        slot = self.slot_var.get().strip()
        if not block:
            return
        for token_index, token in enumerate(block.get("tokens") or []):
            mapping_index = self._inline_mapping_index(block.get("source"), slot, token_index)
            height = "Default"
            if mapping_index is not None:
                height = str(int(self.mappings[mapping_index].get("icon_height", 0))) + " px"
            override = self._token_override(token)
            resolved = self._resolved_row_icon_asset(token)
            if override:
                asset_label = "Override: " + os.path.basename(override)
            elif resolved:
                asset_label = os.path.basename(resolved)
            else:
                asset_label = "Missing"
            item = f"rowicon:{token_index}"
            self.row_icon_tree.insert(
                "", "end", iid=item,
                values=(token_index + 1, f"<{token}>", height, asset_label),
            )
        if select_token_index is not None:
            item = f"rowicon:{int(select_token_index)}"
            if self.row_icon_tree.exists(item):
                self.row_icon_tree.selection_set(item)
                self.row_icon_tree.see(item)

    def _selected_row_icon_index(self):
        selected = self.row_icon_tree.selection()
        if not selected:
            return None
        try:
            return int(selected[0].split(":", 1)[1])
        except Exception:
            return None

    def _row_icon_selected(self, _event=None):
        block = self._selected_block()
        token_index = self._selected_row_icon_index()
        if not block or token_index is None:
            return
        mapping_index = self._inline_mapping_index(block.get("source"), self.slot_var.get(), token_index)
        if mapping_index is None:
            self.row_icon_size_var.set(max(1, _int(self.icon_height_var.get(), 48)))
        else:
            self.row_icon_size_var.set(int(self.mappings[mapping_index].get("icon_height", 48)))
        token = (block.get("tokens") or [])[token_index]
        override = self._token_override(token)
        resolved = self._resolved_row_icon_asset(token)
        self.row_icon_asset_var.set(override or (os.path.basename(resolved) if resolved else ""))

    def _apply_row_icon_size(self):
        block = self._selected_block()
        token_index = self._selected_row_icon_index()
        slot = self.slot_var.get().strip()
        if not block or token_index is None:
            messagebox.showwarning("Icon Size Mapper", "Select an icon from the row icon list first.", parent=self)
            return
        if not slot:
            messagebox.showwarning("Icon Size Mapper", "Select the PSD text slot first.", parent=self)
            return
        has_parent_flow = any(
            mapping.get("kind") == "flow"
            and str(mapping.get("source") or "").casefold() == str(block.get("source") or "").casefold()
            and str(mapping.get("slot") or "").casefold() == slot.casefold()
            for mapping in self.mappings
        )
        if not has_parent_flow:
            messagebox.showwarning(
                "Icon Size Mapper",
                "Assign this Excel row to the selected PSD slot using Flow: text + icons first.",
                parent=self,
            )
            return
        icon_height = _int(self.row_icon_size_var.get(), 0)
        if icon_height <= 0:
            messagebox.showwarning("Icon Size Mapper", "Enter an icon height greater than zero.", parent=self)
            return
        token = (block.get("tokens") or [])[token_index]
        candidate = {
            "kind": "inline_token",
            "source": block.get("source"),
            "slot": slot,
            "token_index": token_index,
            "token": token,
            "icon_height": icon_height,
        }
        mapping_index = self._inline_mapping_index(block.get("source"), slot, token_index)
        if mapping_index is None:
            self.mappings.append(candidate)
        else:
            self.mappings[mapping_index] = candidate
        self._refresh_mappings()
        self._refresh_row_icon_mapper(select_token_index=token_index)
        self.status_var.set(f"<{token}> will render at {icon_height}px in {slot}.")

    def _clear_row_icon_size(self):
        block = self._selected_block()
        token_index = self._selected_row_icon_index()
        slot = self.slot_var.get().strip()
        if not block or token_index is None:
            return
        mapping_index = self._inline_mapping_index(block.get("source"), slot, token_index)
        if mapping_index is not None:
            self.mappings.pop(mapping_index)
            self._refresh_mappings()
        self._refresh_row_icon_mapper(select_token_index=token_index)
        self.status_var.set("Inline icon size cleared. The row default will be used.")

    def _selected_row_token(self):
        block = self._selected_block()
        token_index = self._selected_row_icon_index()
        tokens = (block or {}).get("tokens") or []
        if token_index is None or token_index < 0 or token_index >= len(tokens):
            return ""
        return str(tokens[token_index])

    def _apply_row_icon_asset(self):
        token = self._selected_row_token()
        asset = self.row_icon_asset_var.get().strip()
        if not token:
            messagebox.showwarning("Icon Override", "Select an icon from the row icon list first.", parent=self)
            return
        if not asset:
            messagebox.showwarning("Icon Override", "Choose or browse an icon asset first.", parent=self)
            return
        resolved = resolve_icon_path(
            token,
            self.icons_folder_var.get().strip(),
            {token: asset},
        )
        if not resolved:
            messagebox.showwarning("Icon Override", f"The selected asset could not be found:\n{asset}", parent=self)
            return
        for key in list(self.icon_overrides):
            if normalize_token(key) == normalize_token(token):
                del self.icon_overrides[key]
        self.icon_overrides[token] = asset
        self._refresh_row_icon_mapper(select_token_index=self._selected_row_icon_index())
        self.status_var.set(f"<{token}> will use {os.path.basename(resolved)} for this template.")

    def _browse_row_icon_asset(self):
        path = filedialog.askopenfilename(
            parent=self,
            filetypes=[("Icon assets", "*.png;*.jpg;*.jpeg;*.psd"), ("All files", "*.*")],
        )
        if path:
            self.row_icon_asset_var.set(path)
            self._apply_row_icon_asset()

    def _clear_row_icon_asset(self):
        token = self._selected_row_token()
        if not token:
            return
        for key in list(self.icon_overrides):
            if normalize_token(key) == normalize_token(token):
                del self.icon_overrides[key]
        self.row_icon_asset_var.set("")
        self._refresh_row_icon_mapper(select_token_index=self._selected_row_icon_index())
        self.status_var.set(f"<{token}> icon override cleared; normal folder lookup will be used.")

    def _source_selected(self, _event=None):
        selected = self._selected_source()
        preserve_active_mapping = False
        if self.active_mapping_index is not None and selected:
            try:
                active_mapping = self.mappings[int(self.active_mapping_index)]
                selected_block = selected.get("block") or {}
                same_source = (
                    str(selected_block.get("source") or "").casefold()
                    == str(active_mapping.get("source") or "").casefold()
                )
                if active_mapping.get("kind") in {"token", "inline_token"}:
                    same_token = (
                        selected.get("type") == "token"
                        and int(selected.get("token_index", -1)) == int(active_mapping.get("token_index", -2))
                    )
                else:
                    same_token = selected.get("type") != "token"
                preserve_active_mapping = same_source and same_token
            except Exception:
                preserve_active_mapping = False
        if not self._syncing_selection and not preserve_active_mapping:
            self.active_mapping_index = None
            for item in self.mapping_tree.selection():
                self.mapping_tree.selection_remove(item)
            self._refresh_mappings()
        if selected:
            sel_key = (
                str(selected.get("block", {}).get("source", "")),
                str(selected.get("type", "")),
                str(selected.get("token_index", "")),
            )
        else:
            sel_key = None
        if sel_key and sel_key != getattr(self, "_last_sel_key", None):
            if selected.get("type") == "token":
                self.mode_var.set("Inline icon size")
            else:
                self.mode_var.set("Flow: text + icons")
        self._last_sel_key = sel_key
        self._refresh_row_icon_mapper()

    def _mapping_from_controls(self):
        selected = self._selected_source()
        slot = self.slot_var.get().strip()
        if not selected:
            raise ValueError("Select an Excel row or token first.")
        if not slot:
            raise ValueError("Select a PSD slot first.")
        block = selected["block"]
        mode = self.mode_var.get()
        if mode in {"Inline icon size", "Dedicated icon"}:
            if selected.get("type") != "token":
                raise ValueError("Expand an Excel row and select the specific <token> first.")
            if mode == "Inline icon size":
                icon_height = _int(self.token_height_var.get(), 0)
                if icon_height <= 0:
                    raise ValueError("Enter the selected inline icon height in pixels.")
                mapping = {
                    "kind": "inline_token",
                    "source": block["source"],
                    "slot": slot,
                    "token_index": int(selected["token_index"]),
                    "token": selected["token"],
                    "icon_height": icon_height,
                }
                mapping.update(self._style_from_controls())
                return mapping
            mapping = {
                "kind": "token",
                "source": block["source"],
                "slot": slot,
                "token_index": int(selected["token_index"]),
                "token": selected["token"],
                "max_height": _int(self.token_height_var.get(), 0),
            }
            mapping.update(self._style_from_controls())
            return mapping
        if selected.get("type") == "token":
            raise ValueError("Select the parent Excel row for a text/flow assignment.")
        fixed_font_size = max(1, _int(self.font_size_var.get(), 30))
        fixed_gap = max(0, _int(self.gap_var.get(), 18))
        mapping = {
            "kind": "flow",
            "source": block["source"],
            "slot": slot,
            "render_mode": "text" if self.mode_var.get() == "Text only" else "inline_flow",
            "font_size": fixed_font_size,
            "minimum_font_size": fixed_font_size,
            "emergency_minimum_font_size": fixed_font_size,
            "icon_height": _int(self.icon_height_var.get(), 48),
            "gap": fixed_gap,
            "minimum_gap": fixed_gap,
            "padding": _padding_values(self.padding_vars),
            "vertical_align": self.vertical_align_var.get(),
        }
        mapping.update(self._style_from_controls())
        return mapping

    def _add_mapping(self):
        try:
            candidate = self._mapping_from_controls()
            conflict = self._mapping_conflict_index(candidate)
            if conflict is not None:
                self._refresh_mappings(select_index=conflict)
                raise ValueError(
                    "This PSD slot or inline icon already has an assignment. "
                    "The existing assignment was selected; edit it and click Update instead."
                )
            self.mappings.append(candidate)
            self._refresh_mappings(select_index=len(self.mappings) - 1)
            self.status_var.set("Assignment added. Assignment order controls vertical flow order.")
        except Exception as exc:
            messagebox.showwarning("Cannot Assign", str(exc), parent=self)

    def _update_mapping(self):
        index = self._selected_mapping_index()
        if index is None:
            messagebox.showwarning("Update Assignment", "Select an existing assignment first.", parent=self)
            return
        try:
            candidate = self._mapping_from_controls()
            conflict = self._mapping_conflict_index(candidate, ignore_index=index)
            if conflict is not None:
                self._refresh_mappings(select_index=conflict)
                raise ValueError(
                    "That PSD slot or inline icon is already assigned by another row. "
                    "The conflicting assignment was selected."
                )
            self.mappings[index] = candidate
            self._refresh_mappings(select_index=index)
            self.status_var.set(f"Updated assignment {index + 1} only.")
        except Exception as exc:
            messagebox.showwarning("Cannot Update", str(exc), parent=self)

    def _remove_mapping(self):
        index = self._selected_mapping_index()
        if index is None:
            return
        self.mappings.pop(index)
        self._refresh_mappings(select_index=min(index, len(self.mappings) - 1))

    def _move_mapping(self, direction):
        index = self._selected_mapping_index()
        if index is None:
            return
        target = index + int(direction)
        if target < 0 or target >= len(self.mappings):
            return
        self.mappings[index], self.mappings[target] = self.mappings[target], self.mappings[index]
        self._refresh_mappings(select_index=target)

    def _refresh_mappings(self, select_index=None):
        if select_index is not None and 0 <= select_index < len(self.mappings):
            self.active_mapping_index = int(select_index)
        elif self.active_mapping_index is not None and not (0 <= self.active_mapping_index < len(self.mappings)):
            self.active_mapping_index = None
        self.mapping_tree.delete(*self.mapping_tree.get_children())
        for index, mapping in enumerate(self.mappings):
            if mapping.get("kind") == "token":
                kind = "Icon"
                source = f"{mapping.get('source')} #{int(mapping.get('token_index', 0)) + 1}"
            elif mapping.get("kind") == "inline_token":
                kind = "Inline size"
                source = f"{mapping.get('source')} #{int(mapping.get('token_index', 0)) + 1}"
            else:
                kind = "Text" if mapping.get("render_mode") == "text" else "Flow"
                source = mapping.get("source")
            tags = ("active_mapping",) if index == self.active_mapping_index else ()
            self.mapping_tree.insert("", "end", iid=f"map:{index}", values=(kind, source, mapping.get("slot")), tags=tags)
        if self.active_mapping_index is not None and 0 <= self.active_mapping_index < len(self.mappings):
            item = f"map:{self.active_mapping_index}"
            self.mapping_tree.selection_set(item)
            self.mapping_tree.focus(item)
            self.mapping_tree.see(item)
        self._refresh_row_icon_mapper()
        self._draw_preview()

    def _mapping_selected(self, _event=None):
        selected = self.mapping_tree.selection()
        if selected and self.active_mapping_index is None:
            try:
                self.active_mapping_index = int(selected[0].split(":", 1)[1])
            except Exception:
                self.active_mapping_index = None
        index = self._selected_mapping_index()
        if index is None:
            return
        mapping = self.mappings[index]
        self._syncing_selection = True
        try:
            self._select_source_for_mapping(mapping)
            self.slot_var.set(str(mapping.get("slot") or ""))
        finally:
            self._syncing_selection = False
        if mapping.get("kind") == "token":
            self.mode_var.set("Dedicated icon")
            self.token_height_var.set(int(mapping.get("max_height", 0)))
        elif mapping.get("kind") == "inline_token":
            self.mode_var.set("Inline icon size")
            self.token_height_var.set(int(mapping.get("icon_height", 0)))
        else:
            self.mode_var.set("Text only" if mapping.get("render_mode") == "text" else "Flow: text + icons")
            self.font_size_var.set(int(mapping.get("font_size", 30)))
            self.min_font_size_var.set(int(mapping.get("minimum_font_size", 20)))
            self.emergency_min_font_size_var.set(int(mapping.get("emergency_minimum_font_size", 6)))
            self.icon_height_var.set(int(mapping.get("icon_height", 48)))
            self.gap_var.set(int(mapping.get("gap", 18)))
            self.min_gap_var.set(int(mapping.get("minimum_gap", 8)))
            padding = list(mapping.get("padding", [0, 0, 0, 0]))
            padding = (padding + [0, 0, 0, 0])[:4]
            for variable, value in zip(self.padding_vars, padding):
                variable.set(int(value))
            self.vertical_align_var.set(str(mapping.get("vertical_align") or "top"))
        self._apply_style_to_controls(mapping)
        self._refresh_row_icon_mapper()
        self._draw_preview()

    def _select_source_for_mapping(self, mapping):
        wanted_source = str(mapping.get("source") or "").casefold()
        wanted_index = (
            int(mapping.get("token_index", -1))
            if mapping.get("kind") in {"token", "inline_token"}
            else -1
        )
        for item_id, item in self.source_items.items():
            block = item.get("block") or {}
            if str(block.get("source") or "").casefold() != wanted_source:
                continue
            if wanted_index >= 0:
                if item.get("type") != "token" or int(item.get("token_index", -2)) != wanted_index:
                    continue
            elif item.get("type") != "block":
                continue
            self.source_tree.selection_set(item_id)
            self.source_tree.see(item_id)
            return

    def _draw_preview(self):
        canvas = self.preview_canvas
        canvas.delete("all")
        self.slot_rectangles.clear()
        if not self.template:
            label_item = canvas.create_text(
                max(20, canvas.winfo_width() / 2),
                max(20, canvas.winfo_height() / 2),
                text="Load an exported slot JSON",
                fill=self.palette["muted"],
            )
            return
        source_canvas = self.template.get("canvas") or {}
        page_width = float(source_canvas.get("width", 1))
        page_height = float(source_canvas.get("height", 1))
        available_width = max(100, canvas.winfo_width() - 28)
        available_height = max(100, canvas.winfo_height() - 28)
        scale = min(available_width / page_width, available_height / page_height)
        offset_x = (canvas.winfo_width() - page_width * scale) / 2.0
        offset_y = (canvas.winfo_height() - page_height * scale) / 2.0
        canvas.create_rectangle(
            offset_x,
            offset_y,
            offset_x + page_width * scale,
            offset_y + page_height * scale,
            fill=self.palette["panel_bg"],
            outline=self.palette["border"],
            width=2,
        )
        mapped = {}
        for mapping in self.mappings:
            mapped.setdefault(str(mapping.get("slot") or "").casefold(), []).append(mapping)
        selected_slot = self.slot_var.get().casefold()

        for slot_name, box in (self.template.get("slots") or {}).items():
            try:
                x1 = offset_x + float(box["x"]) * scale
                y1 = offset_y + float(box["y"]) * scale
                x2 = x1 + float(box["w"]) * scale
                y2 = y1 + float(box["h"]) * scale
            except Exception:
                continue
            key = str(slot_name).casefold()
            color = self.palette["success"] if key in mapped else self.palette["accent"]
            width = 3 if key == selected_slot else 1
            if key == selected_slot:
                color = self.palette["accent_alt"]
            rectangle = canvas.create_rectangle(x1, y1, x2, y2, outline=color, width=width)
            label = str(slot_name)
            if key in mapped:
                first = mapped[key][0]
                source = first.get("token") or first.get("source") or ""
                label += f"\n{source}"
            label_item = canvas.create_text(
                (x1 + x2) / 2.0,
                (y1 + y2) / 2.0,
                text=label,
                fill=self.palette["text"],
                width=max(20, x2 - x1 - 6),
                justify="center",
                font=("Segoe UI", max(7, min(11, int(9 * max(0.8, scale))))),
            )
            self.slot_rectangles.append((rectangle, slot_name, (x1, y1, x2, y2)))
            canvas.tag_bind(rectangle, "<Button-1>", lambda _event, name=slot_name: self._select_slot(name))
            canvas.tag_bind(label_item, "<Button-1>", lambda _event, name=slot_name: self._select_slot(name))

    def _select_slot(self, name):
        self.slot_var.set(str(name))
        slot_key = str(name).casefold()
        matching_indices = [
            i for i, m in enumerate(self.mappings)
            if str(m.get("slot") or "").casefold() == slot_key
        ]
        if matching_indices:
            idx = matching_indices[0]
            self.active_mapping_index = idx
            self._refresh_mappings(select_index=idx)
            self._mapping_selected()
            self.status_var.set(f"Slot '{name}' has {len(matching_indices)} assignment(s). Selected mapping {idx + 1}.")
        else:
            self.active_mapping_index = None
            for item in self.mapping_tree.selection():
                self.mapping_tree.selection_remove(item)
            self._refresh_mappings()
            self.status_var.set(f"Slot '{name}' has no assignments yet. Create one from the Excel panel.")
        self._draw_preview()
        self._refresh_row_icon_mapper()

    def _preflight(self):
        if not self.template:
            messagebox.showwarning("Template Mapper", "Load a slot JSON first.", parent=self)
            return False
        errors, warnings = validate_mappings(self.template, self.mappings)
        lines = []
        if errors:
            lines.append("Errors:\n- " + "\n- ".join(errors))
        if warnings:
            lines.append("Warnings:\n- " + "\n- ".join(warnings))
        if not lines:
            lines.append(f"Preflight passed. {len(self.mappings)} assignments are ready.")
        messagebox.showinfo("Template Mapper Preflight", "\n\n".join(lines), parent=self)
        return not errors

    def _save(self):
        if not self.template or not self.sheet_var.get().strip():
            messagebox.showwarning("Save Mapped JSON", "Load both Excel and slot JSON first.", parent=self)
            return
        errors, warnings = validate_mappings(self.template, self.mappings)
        if errors:
            messagebox.showerror("Cannot Save", "\n".join(errors), parent=self)
            return
        initial_dir = self.output_folder or os.path.dirname(self.json_var.get().strip()) or os.getcwd()
        output_path = filedialog.asksaveasfilename(
            parent=self,
            initialdir=initial_dir,
            initialfile=f"{self.sheet_var.get().strip()}.json",
            defaultextension=".json",
            filetypes=[("JSON", "*.json")],
        )
        if not output_path:
            return
        try:
            saved_path, save_warnings = save_mapped_template(
                self.template,
                self.sheet_var.get().strip(),
                self.mappings,
                output_path,
                icon_mappings=self.icon_overrides,
            )
            self.status_var.set(f"Saved mapped template: {saved_path}")
            if callable(self.on_saved):
                self.on_saved(saved_path, self.sheet_var.get().strip())
            detail = f"Mapped JSON saved to:\n{saved_path}"
            all_warnings = warnings + save_warnings
            if all_warnings:
                detail += "\n\nWarnings:\n- " + "\n- ".join(dict.fromkeys(all_warnings))
            messagebox.showinfo("Template Mapping Saved", detail, parent=self)
        except Exception as exc:
            messagebox.showerror("Save Error", str(exc), parent=self)


def open_template_mapper(
        parent, initial_excel="", initial_json="", output_folder="",
        on_saved=None, palette=None, initial_font_size=30,
        icons_folder="", initial_icon_mappings=None):
    return TemplateMapperDialog(
        parent,
        initial_excel=initial_excel,
        initial_json=initial_json,
        output_folder=output_folder,
        on_saved=on_saved,
        palette=palette,
        initial_font_size=initial_font_size,
        icons_folder=icons_folder,
        initial_icon_mappings=initial_icon_mappings,
    )
