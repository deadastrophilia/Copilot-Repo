"""Tk dialog for mapping Excel table content into @table JSON slots."""

import os
import tkinter as tk
from tkinter import colorchooser, filedialog, messagebox, ttk

from openpyxl import load_workbook
from openpyxl.utils import column_index_from_string

import copy
from PIL import Image, ImageDraw, ImageFont, ImageTk

from .table_mapping import (
    _is_paytable_template,
    extract_existing_table_mappings,
    load_table_template,
    parse_table_slot_ref,
    save_mapped_table_template,
    scan_table_excel_content,
    slots_for_table_template,
    suggest_slot_names,
    table_template_names,
    validate_source_range_against_worksheet,
    validate_table_mappings,
)


DEFAULT_PALETTE = {
    "app_bg": "#101114",
    "panel_bg": "#1A1C20",
    "border": "#34363D",
    "text": "#F8F5EA",
    "muted": "#B8B2A3",
    "accent": "#F6C343",
    "accent_alt": "#E89B24",
    "success": "#4CAF50",
}

_STYLE_PRESETS = {
    "Heading": {
        "font_size": 36, "icon_height": 48, "color": "#F6C343",
        "align": "center", "valign": "center", "role": "heading",
    },
    "Body": {
        "font_size": 28, "icon_height": 48, "color": "#FFFFFF",
        "align": "center", "valign": "center", "role": "text_icon",
    },
    "Subhead": {
        "font_size": 24, "icon_height": 36, "color": "#B8B2A3",
        "align": "center", "valign": "center", "role": "heading",
    },
    "Icon": {
        "font_size": 30, "icon_height": 48, "color": "#FFFFFF",
        "align": "center", "valign": "center", "role": "dedicated_icon",
    },
    "Fill": {
        "font_size": 30, "icon_height": 48, "color": "#FFFFFF",
        "align": "center", "valign": "center", "role": "slot_style",
    },
}

EXCEL_FILETYPES = [
    ("Excel workbooks", "*.xlsx;*.xlsm"),
    ("Excel workbook", "*.xlsx"),
    ("Excel macro-enabled workbook", "*.xlsm"),
    ("All files", "*.*"),
]

MODE_LONG_TO_KIND = {
    "Flow text + inline icons": "flow",
    "Text": "text_only",
    "Dedicated icon": "dedicated_icon",
    "Inline icon size": "inline_icon_size",
    "Box fill/stroke": "box_fill_stroke",
}
KIND_TO_MODE_LONG = {v: k for k, v in MODE_LONG_TO_KIND.items()}
MODE_LONG_TO_KIND.setdefault("flow", "Flow text + inline icons")


def _int(value, fallback=0):
    try:
        return int(float(value))
    except Exception:
        return int(fallback)


def _sheet_names(path):
    workbook = load_workbook(path, data_only=False, read_only=False)
    try:
        return list(workbook.sheetnames)
    finally:
        workbook.close()


class TableMapperDialog(tk.Toplevel):
    def __init__(
            self, parent, initial_excel="", initial_json="", output_folder="",
            on_saved=None, palette=None, initial_font_size=30,
            icons_folder="", initial_icon_mappings=None,
            extra_json_paths=None):
        super().__init__(parent)
        self.parent = parent
        self.palette = dict(DEFAULT_PALETTE)
        self.palette.update(palette or {})
        self.on_saved = on_saved
        self.output_folder = str(output_folder or "")
        self.icons_folder = str(icons_folder or "")
        self.icon_mappings = dict(initial_icon_mappings or {})
        self.extra_json_paths = list(extra_json_paths) if extra_json_paths else []
        self.template = None
        self.blocks = []
        self.source_items = {}
        self.mappings = []
        self.slot_rectangles = []
        self.active_mapping_index = None
        self.selected_slot_names = set()
        self._syncing_source_selection = False
        self._syncing_slot_selection = False
        self._syncing_controls = False
        self._auto_apply_after_id = None
        self._pending_auto_style_fields = set()
        self._auto_style_trace_refs = []
        self._auto_applying = False
        self._undo_stack = []
        self._redo_stack = []
        self._undo_limit = 80
        self._active_preset = "Body"
        self._placement_collapsed = True

        self.title("Table JSON Mapper")
        screen_width = max(1100, int(self.winfo_screenwidth()))
        screen_height = max(760, int(self.winfo_screenheight()))
        initial_width = min(1800, max(1200, screen_width - 60))
        initial_height = min(1040, max(760, screen_height - 80))
        self.geometry(f"{initial_width}x{initial_height}")
        self.minsize(min(1100, initial_width), min(720, initial_height))
        self.configure(bg=self.palette["app_bg"])
        self.resizable(True, True)

        self.excel_var = tk.StringVar(value=initial_excel)
        self.json_var = tk.StringVar(value=initial_json)
        self.sheet_var = tk.StringVar()
        self.table_var = tk.StringVar()
        self.max_col_var = tk.IntVar(value=30)
        self.table_source_var = tk.StringVar()
        self.source_sheets_var = tk.StringVar()
        self.source_var = tk.StringVar()
        self.slot_var = tk.StringVar()
        self.mode_var = tk.StringVar(value="Flow text + inline icons")
        self.role_var = tk.StringVar(value="Auto")
        self.font_size_var = tk.IntVar(value=max(1, _int(initial_font_size, 30)))
        self.icon_height_var = tk.IntVar(value=48)
        self.text_color_var = tk.StringVar(value="#FFFFFF")
        self.bg_color_var = tk.StringVar(value="#000000")
        self.stroke_color_var = tk.StringVar(value="#FFFFFF")
        self.opacity_var = tk.IntVar(value=100)
        self.stroke_width_var = tk.IntVar(value=0)
        self.fill_enabled_var = tk.BooleanVar(value=False)
        self.stroke_enabled_var = tk.BooleanVar(value=False)
        self.align_var = tk.StringVar(value="center")
        self.valign_var = tk.StringVar(value="center")
        self.padding_vars = [tk.IntVar(value=0) for _ in range(4)]
        self.token_height_var = tk.IntVar(value=0)
        self.insert_mode_var = tk.StringVar(value="after_row")
        self.insert_after_row_var = tk.IntVar(value=0)
        self.marker_var = tk.StringVar()
        self.absolute_x_var = tk.StringVar()
        self.absolute_y_var = tk.StringVar()
        self.margin_before_var = tk.IntVar(value=30)
        self.margin_after_var = tk.IntVar(value=30)
        self.fit_mode_var = tk.StringVar(value="scale")
        self.scale_if_needed_var = tk.BooleanVar(value=True)
        self.status_var = tk.StringVar(value="Load an Excel workbook and @table JSON to begin.")
        self._all_slots = []
        self._build_ui()
        self._install_auto_style_traces()
        self.after_idle(self._load_initial_files)

    def _build_ui(self):
        mapper_style = ttk.Style(self)
        mapper_style.configure(
            "TableMapper.Treeview",
            rowheight=28,
            background=self.palette["panel_bg"],
            fieldbackground=self.palette["panel_bg"],
            foreground=self.palette["text"],
        )
        mapper_style.map(
            "TableMapper.Treeview",
            background=[("selected", self.palette["accent"])],
            foreground=[("selected", "#101114")],
        )

        shell = ttk.Frame(self, padding=14)
        shell.pack(fill="both", expand=True)

        header = ttk.Frame(shell)
        header.pack(fill="x", pady=(0, 10))
        ttk.Label(header, text="Table JSON Mapper", style="Title.TLabel").pack(side="left")
        ttk.Label(
            header,
            text="Map Excel table content into artist-authored @table slots.",
            foreground=self.palette["muted"],
        ).pack(side="left", padx=18)

        files = ttk.LabelFrame(shell, text="Source Files")
        files.pack(fill="x", pady=(0, 4))
        files.columnconfigure(1, weight=1)
        ttk.Label(files, text="Excel:").grid(row=0, column=0, sticky="w", padx=8, pady=(6, 2))
        ttk.Entry(files, textvariable=self.excel_var).grid(row=0, column=1, sticky="ew", padx=4, pady=(6, 2))
        ttk.Button(files, text="Browse", command=self._browse_excel).grid(row=0, column=2, padx=(4, 8), pady=(6, 2))
        ttk.Label(files, text="@table JSON:").grid(row=1, column=0, sticky="w", padx=8, pady=2)
        self.json_combo = ttk.Combobox(files, textvariable=self.json_var, state="readonly")
        self.json_combo.grid(row=1, column=1, sticky="ew", padx=4, pady=2)
        self.json_combo.bind("<<ComboboxSelected>>", lambda _event: self._load_json())
        ttk.Button(files, text="Browse", command=self._browse_json).grid(row=1, column=2, padx=(4, 8), pady=2)
        ttk.Label(files, text="Sheet:").grid(row=2, column=0, sticky="w", padx=8, pady=(2, 6))
        self.sheet_combo = ttk.Combobox(files, textvariable=self.sheet_var, width=28, state="readonly")
        self.sheet_combo.grid(row=2, column=1, sticky="w", padx=4, pady=(2, 6))
        self.sheet_combo.bind("<<ComboboxSelected>>", lambda _event: self._scan_excel())
        ttk.Label(files, text="Max col:").grid(row=2, column=2, sticky="e", padx=(8, 4), pady=(2, 6))
        ttk.Spinbox(files, textvariable=self.max_col_var, from_=1, to=120, width=7).grid(row=2, column=3, sticky="w", pady=(2, 6))
        ttk.Button(files, text="Refresh", command=self._refresh_all).grid(row=2, column=4, padx=8, pady=(2, 6))

        placement = ttk.LabelFrame(shell, text="Table Component")
        placement.pack(fill="x", pady=(0, 4))
        placement.columnconfigure(1, weight=1)
        ttk.Label(placement, text="Template:").grid(row=0, column=0, sticky="w", padx=8, pady=(6, 2))
        self.table_combo = ttk.Combobox(placement, textvariable=self.table_var, width=30, state="readonly")
        self.table_combo.grid(row=0, column=1, sticky="w", padx=4, pady=(6, 2))
        self.table_combo.bind("<<ComboboxSelected>>", lambda _event: self._table_selected())
        ttk.Label(placement, text="Component source range:").grid(row=0, column=2, sticky="e", padx=(10, 4), pady=(6, 2))
        ttk.Entry(placement, textvariable=self.table_source_var, width=18).grid(row=0, column=3, sticky="w", pady=(6, 2))
        self._placement_toggle_var = tk.BooleanVar(value=False)
        self._placement_toggle_btn = ttk.Checkbutton(
            placement, text="Placement settings \u25b6", variable=self._placement_toggle_var,
            command=self._toggle_placement,
        )
        self._placement_toggle_btn.grid(row=1, column=0, columnspan=4, sticky="w", padx=8, pady=(2, 4))
        self._placement_detail_frame = ttk.Frame(placement)
        self._placement_detail_frame.grid(row=2, column=0, columnspan=4, sticky="ew")
        self._placement_detail_frame.columnconfigure(1, weight=1)
        pd = self._placement_detail_frame
        ttk.Label(pd, text="Insert:").grid(row=0, column=0, sticky="w", padx=8, pady=2)
        ttk.Combobox(
            pd,
            textvariable=self.insert_mode_var,
            values=("after_row", "marker", "absolute", "range_start"),
            state="readonly",
            width=14,
        ).grid(row=0, column=1, sticky="w", padx=4, pady=2)
        ttk.Label(pd, text="After row:").grid(row=0, column=2, sticky="e", padx=(10, 4), pady=2)
        ttk.Spinbox(pd, textvariable=self.insert_after_row_var, from_=0, to=10000, width=8).grid(row=0, column=3, sticky="w", pady=2)
        ttk.Label(pd, text="Marker:").grid(row=1, column=0, sticky="w", padx=8, pady=2)
        ttk.Entry(pd, textvariable=self.marker_var, width=28).grid(row=1, column=1, sticky="w", padx=4, pady=2)
        ttk.Label(pd, text="Absolute X/Y:").grid(row=1, column=2, sticky="e", padx=(10, 4), pady=2)
        abs_frame = ttk.Frame(pd)
        abs_frame.grid(row=1, column=3, sticky="w", pady=2)
        ttk.Entry(abs_frame, textvariable=self.absolute_x_var, width=8).pack(side="left")
        ttk.Entry(abs_frame, textvariable=self.absolute_y_var, width=8).pack(side="left", padx=(4, 0))
        ttk.Label(pd, text="Margins before/after:").grid(row=2, column=0, sticky="w", padx=8, pady=(2, 6))
        margin_frame = ttk.Frame(pd)
        margin_frame.grid(row=2, column=1, sticky="w", padx=4, pady=(2, 6))
        ttk.Spinbox(margin_frame, textvariable=self.margin_before_var, from_=0, to=1000, width=7).pack(side="left")
        ttk.Spinbox(margin_frame, textvariable=self.margin_after_var, from_=0, to=1000, width=7).pack(side="left", padx=(4, 0))
        ttk.Label(pd, text="Overflow:").grid(row=2, column=2, sticky="e", padx=(10, 4), pady=(2, 6))
        overflow_frame = ttk.Frame(pd)
        overflow_frame.grid(row=2, column=3, sticky="w", pady=(2, 6))
        ttk.Combobox(
            overflow_frame,
            textvariable=self.fit_mode_var,
            values=("scale", "next_page", "warn", "alternate_template"),
            state="readonly",
            width=18,
        ).pack(side="left")
        ttk.Checkbutton(overflow_frame, text="Scale if needed", variable=self.scale_if_needed_var).pack(side="left", padx=8)
        ttk.Label(pd, text="Also use on sheets:").grid(row=3, column=0, sticky="w", padx=8, pady=(0, 6))
        ttk.Entry(pd, textvariable=self.source_sheets_var).grid(row=3, column=1, columnspan=3, sticky="ew", padx=4, pady=(0, 6))
        ttk.Label(
            pd,
            text="Optional aliases for the same cell layout, separated by semicolon.",
            foreground=self.palette["muted"],
        ).grid(row=4, column=4, sticky="w", padx=(8, 4), pady=(0, 6))

        panes = tk.PanedWindow(shell, orient=tk.HORIZONTAL, sashwidth=6, bg=self.palette["app_bg"], bd=0, relief="flat")
        source_panel = ttk.LabelFrame(panes, text="Excel Rows / Tokens")
        slot_panel = ttk.LabelFrame(panes, text="@table Slots")
        mapping_panel = ttk.LabelFrame(panes, text="Mappings")
        panes.add(source_panel, minsize=260, width=330)
        panes.add(slot_panel, minsize=620, width=930)
        panes.add(mapping_panel, minsize=420, width=560)

        self.source_tree = ttk.Treeview(
            source_panel,
            columns=("source", "content"),
            show="tree headings",
            selectmode="extended",
            style="TableMapper.Treeview",
        )
        self.source_tree.heading("#0", text="Type")
        self.source_tree.heading("source", text="Source")
        self.source_tree.heading("content", text="Content")
        self.source_tree.column("#0", width=90, stretch=False)
        self.source_tree.column("source", width=100, stretch=False)
        self.source_tree.column("content", width=260, stretch=True)
        source_scroll = ttk.Scrollbar(source_panel, orient="vertical", command=self.source_tree.yview)
        self.source_tree.configure(yscrollcommand=source_scroll.set)
        self.source_tree.pack(side="left", fill="both", expand=True, padx=(8, 0), pady=8)
        source_scroll.pack(side="right", fill="y", padx=(0, 8), pady=8)
        self.source_tree.bind("<<TreeviewSelect>>", self._source_selected)
        self.source_tree.bind("<Double-1>", lambda _event: self._add_mapping())

        slot_top = ttk.Frame(slot_panel)
        slot_top.pack(fill="x", padx=8, pady=(8, 4))
        ttk.Label(slot_top, text="Filter:").pack(side="left")
        self.slot_filter_var = tk.StringVar()
        self.slot_filter_entry = ttk.Entry(slot_top, textvariable=self.slot_filter_var)
        self.slot_filter_entry.pack(side="left", fill="x", expand=True, padx=(8, 0))
        self.slot_filter_var.trace_add("write", lambda *_: self._filter_slots())
        ttk.Label(slot_top, text="Slot:").pack(side="left", padx=(8, 4))
        self.slot_combo = ttk.Combobox(slot_top, textvariable=self.slot_var, state="readonly", width=16)
        self.slot_combo.pack(side="left")
        self.slot_combo.bind("<<ComboboxSelected>>", lambda _event: self._select_slot(self.slot_var.get()))
        preview_toolbar = ttk.Frame(slot_panel)
        preview_toolbar.pack(fill="x", padx=8, pady=(0, 4))
        self.preview_mode_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(preview_toolbar, text="Show rendered preview", variable=self.preview_mode_var,
                        command=self._draw_preview).pack(side="left")
        self.preview_render_status = tk.StringVar(value="")
        ttk.Label(preview_toolbar, textvariable=self.preview_render_status,
                  foreground=self.palette["muted"], font=("Segoe UI", 8)).pack(side="right", padx=(4, 0))
        self.preview_canvas = tk.Canvas(slot_panel, bg=self.palette["app_bg"], highlightthickness=0, bd=0)
        self.preview_canvas.pack(fill="both", expand=True, padx=8, pady=(4, 2))
        self.preview_canvas.bind("<Configure>", lambda _event: self._draw_preview())
        self.preview_summary_var = tk.StringVar(value="")
        ttk.Label(slot_panel, textvariable=self.preview_summary_var, foreground=self.palette["muted"], font=("Segoe UI", 8)).pack(fill="x", padx=8, pady=(0, 6))

        controls_holder = ttk.Frame(mapping_panel)
        controls_holder.pack(fill="x", padx=8, pady=(8, 4))
        controls_canvas = tk.Canvas(
            controls_holder,
            height=330,
            bg=self.palette["panel_bg"],
            highlightthickness=0,
            bd=0,
        )
        controls_scroll = ttk.Scrollbar(controls_holder, orient="vertical", command=controls_canvas.yview)
        controls_canvas.configure(yscrollcommand=controls_scroll.set)
        controls_canvas.pack(side="left", fill="x", expand=True)
        controls_scroll.pack(side="right", fill="y")
        controls_frame = ttk.Frame(controls_canvas)
        controls_window = controls_canvas.create_window((0, 0), window=controls_frame, anchor="nw")

        def _sync_controls_scroll(_event=None):
            controls_canvas.configure(scrollregion=controls_canvas.bbox("all"))

        def _sync_controls_width(event):
            controls_canvas.itemconfigure(controls_window, width=max(1, event.width))

        def _scroll_controls(event):
            delta = -1 if event.delta > 0 else 1
            controls_canvas.yview_scroll(delta * 3, "units")

        controls_frame.bind("<Configure>", _sync_controls_scroll)
        controls_canvas.bind("<Configure>", _sync_controls_width)
        controls_canvas.bind("<MouseWheel>", _scroll_controls)
        controls_frame.bind("<MouseWheel>", _scroll_controls)

        quick_frame = ttk.Frame(controls_frame)
        quick_frame.pack(fill="x", pady=(2, 2))
        ttk.Label(quick_frame, text="Font:").pack(side="left")
        ttk.Spinbox(quick_frame, textvariable=self.font_size_var, from_=1, to=500, width=6).pack(side="left", padx=(4, 8))
        ttk.Label(quick_frame, text="Icon:").pack(side="left")
        ttk.Spinbox(quick_frame, textvariable=self.icon_height_var, from_=0, to=1000, width=6).pack(side="left", padx=(4, 8))
        ttk.Button(quick_frame, textvariable=self.text_color_var, command=self._pick_text_color, width=8).pack(side="left", padx=(0, 4))
        ttk.Button(quick_frame, textvariable=self.bg_color_var, command=self._pick_bg_color, width=8).pack(side="left")

        map_row = ttk.Frame(controls_frame)
        map_row.pack(fill="x", pady=(2, 4))
        ttk.Button(map_row, text="Map Selected", command=self._add_mapping, style="Primary.TButton").pack(side="left")
        ttk.Button(map_row, text="Remove", command=self._remove_mapping).pack(side="left", padx=(6, 0))

        action_row2 = ttk.Frame(controls_frame)
        action_row2.pack(fill="x", pady=(0, 4))
        ttk.Button(action_row2, text="Apply to Slots", command=self._apply_controls_to_slots).pack(side="left")
        ttk.Button(action_row2, text="Auto Map", command=self._auto_map_cell_refs).pack(side="left", padx=(6, 0))
        ttk.Button(action_row2, text="Map Remaining", command=self._map_remaining).pack(side="left", padx=(6, 0))

        self._advanced_toggle_var = tk.BooleanVar(value=False)
        self._advanced_frame = ttk.Frame(controls_frame)
        options = ttk.Frame(self._advanced_frame)
        options.pack(fill="x", pady=(2, 4))
        ttk.Label(options, text="Opacity:").grid(row=0, column=0, sticky="w", pady=3)
        ttk.Spinbox(options, textvariable=self.opacity_var, from_=0, to=100, width=7).grid(row=0, column=1, sticky="w", padx=(6, 12), pady=3)
        ttk.Label(options, text="Align:").grid(row=0, column=2, sticky="w", pady=3)
        ttk.Combobox(options, textvariable=self.align_var, values=("left", "center", "right"), state="readonly", width=10).grid(row=0, column=3, sticky="w", padx=(6, 0), pady=3)
        ttk.Label(options, text="Vertical:").grid(row=1, column=0, sticky="w", pady=3)
        ttk.Combobox(options, textvariable=self.valign_var, values=("top", "center", "bottom"), state="readonly", width=10).grid(row=1, column=1, sticky="w", padx=(6, 12), pady=3)
        ttk.Label(options, text="Padding T/R/B/L:").grid(row=1, column=2, sticky="w", pady=3)
        pad_frame = ttk.Frame(options)
        pad_frame.grid(row=1, column=3, sticky="w", padx=(6, 0), pady=3)
        for variable in self.padding_vars:
            ttk.Spinbox(pad_frame, textvariable=variable, from_=0, to=500, width=5).pack(side="left", padx=(0, 4))
        ttk.Label(options, text="Token icon size:").grid(row=2, column=0, sticky="w", pady=3)
        ttk.Spinbox(options, textvariable=self.token_height_var, from_=0, to=1000, width=7).grid(row=2, column=1, sticky="w", padx=(6, 12), pady=3)
        ttk.Label(options, text="Stroke:").grid(row=3, column=0, sticky="w", pady=3)
        stroke_frame = ttk.Frame(options)
        stroke_frame.grid(row=4, column=1, columnspan=3, sticky="w", padx=(6, 0), pady=3)
        ttk.Button(stroke_frame, textvariable=self.stroke_color_var, command=self._pick_stroke_color, width=10).pack(side="left")
        ttk.Label(stroke_frame, text="Width").pack(side="left", padx=(8, 4))
        ttk.Spinbox(stroke_frame, textvariable=self.stroke_width_var, from_=0, to=200, width=6).pack(side="left")
        fill_frame = ttk.Frame(options)
        fill_frame.grid(row=5, column=1, columnspan=3, sticky="w", padx=(6, 0), pady=3)
        ttk.Checkbutton(fill_frame, text="Fill", variable=self.fill_enabled_var).pack(side="left")
        ttk.Checkbutton(fill_frame, text="Stroke", variable=self.stroke_enabled_var).pack(side="left", padx=(12, 0))
        options.columnconfigure(1, weight=1)
        options.columnconfigure(3, weight=1)

        ttk.Separator(self._advanced_frame, orient="horizontal").pack(fill="x", pady=2)
        overall_frame = ttk.Frame(self._advanced_frame)
        overall_frame.pack(fill="x", pady=(2, 4))
        self.overall_stroke_enabled_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(overall_frame, text="Overall Stroke", variable=self.overall_stroke_enabled_var).pack(side="left")
        ttk.Label(overall_frame, text="Color:").pack(side="left", padx=(8, 4))
        self.overall_stroke_color_var = tk.StringVar(value="#FFFFFF")
        ttk.Button(overall_frame, textvariable=self.overall_stroke_color_var, command=self._pick_overall_stroke_color, width=8).pack(side="left")
        ttk.Label(overall_frame, text="Width:").pack(side="left", padx=(8, 4))
        self.overall_stroke_width_var = tk.IntVar(value=2)
        ttk.Spinbox(overall_frame, textvariable=self.overall_stroke_width_var, from_=0, to=100, width=6).pack(side="left")
        ttk.Button(overall_frame, text="Apply to All", command=self._apply_overall_stroke).pack(side="left", padx=(8, 0))

        adv_toggle_btn = ttk.Checkbutton(
            controls_frame, text="Advanced options \u25b6", variable=self._advanced_toggle_var,
            command=self._toggle_advanced_panel, style="Toggle.TCheckbutton",
        )
        adv_toggle_btn.pack(fill="x", pady=(2, 0))

        self.mapping_tree = ttk.Treeview(
            mapping_panel,
            columns=("kind", "source", "slot"),
            show="headings",
            selectmode="extended",
            height=10,
            style="TableMapper.Treeview",
        )
        self.mapping_tree.heading("kind", text="Mode")
        self.mapping_tree.heading("source", text="Excel")
        self.mapping_tree.heading("slot", text="Slot")
        self.mapping_tree.column("kind", width=92, stretch=False)
        self.mapping_tree.column("source", width=120, stretch=True)
        self.mapping_tree.column("slot", width=140, stretch=True)
        mapping_scroll = ttk.Scrollbar(mapping_panel, orient="vertical", command=self.mapping_tree.yview)
        self.mapping_tree.configure(yscrollcommand=mapping_scroll.set)
        self.mapping_tree.pack(side="left", fill="both", expand=True, padx=(8, 0), pady=(0, 8))
        mapping_scroll.pack(side="right", fill="y", padx=(0, 8), pady=(0, 8))
        self.mapping_tree.bind("<<TreeviewSelect>>", self._mapping_selected)

        bottom = ttk.Frame(shell)
        bottom.pack(side="bottom", fill="x", pady=(10, 0))
        ttk.Label(bottom, textvariable=self.status_var, style="Status.TLabel").pack(side="left", fill="x", expand=True)
        self.undo_indicator_var = tk.StringVar(value="")
        ttk.Label(bottom, textvariable=self.undo_indicator_var, foreground=self.palette["muted"], font=("Segoe UI", 8)).pack(side="left", padx=(8, 0))
        ttk.Button(bottom, text="Preflight", command=self._preflight).pack(side="right", padx=5, ipadx=8, ipady=4)
        ttk.Button(bottom, text="Save Mapped Table JSON", command=self._save, style="Primary.TButton").pack(side="right", padx=5, ipadx=10, ipady=4)
        panes.pack(side="top", fill="both", expand=True)

    def _load_initial_files(self):
        if self.excel_var.get().strip() and os.path.isfile(self.excel_var.get().strip()):
            self._load_excel()
        all_json = []
        initial = self.json_var.get().strip()
        if initial and os.path.isfile(initial):
            all_json.append(initial)
        for p in self.extra_json_paths:
            p = str(p).strip()
            if p and os.path.isfile(p) and p not in all_json:
                all_json.append(p)
        self.json_combo["values"] = all_json
        if initial and os.path.isfile(initial):
            self._load_json()
        self.bind_all("<Control-z>", lambda _e: self._undo())
        self.bind_all("<Control-y>", lambda _e: self._redo())
        self.bind_all("<Control-Z>", lambda _e: self._undo())
        self.bind_all("<Control-Y>", lambda _e: self._redo())

    def _push_undo(self):
        self._undo_stack.append(copy.deepcopy(self.mappings))
        if len(self._undo_stack) > self._undo_limit:
            self._undo_stack.pop(0)
        self._redo_stack.clear()
        self._update_undo_indicator()

    def _update_undo_indicator(self):
        parts = []
        if self._undo_stack:
            parts.append(f"Undo ({len(self._undo_stack)})")
        if self._redo_stack:
            parts.append(f"Redo ({len(self._redo_stack)})")
        self.undo_indicator_var.set(" | ".join(parts) if parts else "")

    def _undo(self):
        if not self._undo_stack:
            self.status_var.set("Nothing to undo.")
            return
        self._redo_stack.append(copy.deepcopy(self.mappings))
        self.mappings = self._undo_stack.pop()
        self._refresh_mappings()
        self._update_undo_indicator()
        self.status_var.set(f"Undo ({len(self._undo_stack)} left).")

    def _redo(self):
        if not self._redo_stack:
            self.status_var.set("Nothing to redo.")
            return
        self._undo_stack.append(copy.deepcopy(self.mappings))
        self.mappings = self._redo_stack.pop()
        self._refresh_mappings()
        self._update_undo_indicator()
        self.status_var.set(f"Redo ({len(self._redo_stack)} left).")

    def _toggle_placement(self):
        expanded = bool(self._placement_toggle_var.get())
        self._placement_collapsed = not expanded
        if expanded:
            self._placement_detail_frame.grid()
        else:
            self._placement_detail_frame.grid_remove()
        arrow = "\u25bc" if expanded else "\u25b6"
        self._placement_toggle_btn.configure(text=f"Placement settings {arrow}")

    def _toggle_advanced_panel(self):
        expanded = bool(self._advanced_toggle_var.get())
        if expanded:
            self._advanced_frame.pack(fill="x", padx=8, pady=(2, 4))
        else:
            self._advanced_frame.pack_forget()

    def _infer_preset_from_slot_name(self, slot_name):
        name_lower = slot_name.lower()
        for keyword, preset in [("header", "Heading"), ("title", "Heading"), ("heading", "Heading"),
                                ("body", "Body"), ("text", "Body"), ("label", "Body"), ("rowtemplate", "Body"),
                                ("subhead", "Subhead"), ("subtitle", "Subhead"), ("caption", "Subhead"),
                                ("icon", "Icon"), ("img", "Icon"), ("image", "Icon"),
                                ("bounds", "Fill"), ("box", "Fill"), ("bg", "Fill"), ("background", "Fill")]:
            if keyword in name_lower:
                return preset
        return "Body"

    def _infer_mapping_kind_from_excel(self, excel_row_values):
        if not excel_row_values:
            return "flow_text"
        combined = " ".join(str(v) for v in excel_row_values if v)
        if "<" in combined and ">" in combined:
            return "flow_text"
        non_empty = [v for v in excel_row_values if v]
        if len(non_empty) == 1:
            val = str(non_empty[0]).strip()
            if val.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.bmp', '.svg')):
                return "dedicated_icon"
        return "flow_text"

    def _browse_excel(self):
        path = filedialog.askopenfilename(parent=self, filetypes=EXCEL_FILETYPES)
        if path:
            self.excel_var.set(path)
            self._load_excel()

    def _browse_json(self):
        path = filedialog.askopenfilename(parent=self, filetypes=[("JSON", "*.json")])
        if path:
            cur = list(self.json_combo["values"] or [])
            if path not in cur:
                cur.append(path)
            self.json_combo["values"] = cur
            self.json_var.set(path)
            self._load_json()

    def _load_excel(self):
        try:
            sheets = _sheet_names(self.excel_var.get().strip())
            self.sheet_combo["values"] = sheets
            if self.sheet_var.get() not in sheets:
                self.sheet_var.set(sheets[0] if sheets else "")
            self._scan_excel()
        except Exception as exc:
            messagebox.showerror("Excel Error", str(exc), parent=self)

    def _load_json(self):
        try:
            old_template = self.template
            old_mappings = list(self.mappings) if self.mappings else []
            old_table = self.table_var.get().strip()
            self.template = load_table_template(self.json_var.get().strip())
            self.is_paytable = _is_paytable_template(self.template)
            if self.is_paytable:
                # Paytable has no table templates; use "Main" as the table name
                self.table_combo["values"] = ["Main"]
                self.table_var.set("Main")
            else:
                names = table_template_names(self.template)
                self.table_combo["values"] = names
                if self.table_var.get() not in names:
                    self.table_var.set(names[0] if names else "")
            self._load_existing_spec()
            self._refresh_slots()
            self._draw_preview()
            self._undo_stack.clear()
            self._redo_stack.clear()
            self._update_undo_indicator()
            if old_template and old_template is not None:
                self._show_template_diff(old_template, old_mappings, old_table)
            self._update_preview_summary()
        except Exception as exc:
            messagebox.showerror("Table JSON Error", str(exc), parent=self)

    def _show_template_diff(self, old_template, old_mappings, old_table):
        old_slots = set((old_template.get("slots") or {}).keys())
        new_slots = set((self.template.get("slots") or {}).keys())
        added_slots = sorted(new_slots - old_slots)
        removed_slots = sorted(old_slots - new_slots)
        old_tables = set((old_template.get("table_templates") or {}).keys())
        new_tables = set((self.template.get("table_templates") or {}).keys())
        added_tables = sorted(new_tables - old_tables)
        removed_tables = sorted(old_tables - new_tables)
        old_mapped_slots = {str(m.get("slot") or "") for m in old_mappings if m.get("slot")}
        new_mapped_slots = {str(m.get("slot") or "") for m in self.mappings if m.get("slot")}
        lost_mappings = sorted(old_mapped_slots - new_mapped_slots)
        lines = []
        if added_slots:
            lines.append(f"Slots added ({len(added_slots)}): {', '.join(added_slots[:8])}")
        if removed_slots:
            lines.append(f"Slots removed ({len(removed_slots)}): {', '.join(removed_slots[:8])}")
        if added_tables:
            lines.append(f"Table templates added: {', '.join(added_tables)}")
        if removed_tables:
            lines.append(f"Table templates removed: {', '.join(removed_tables)}")
        if lost_mappings:
            lines.append(f"Existing mappings referencing removed slots ({len(lost_mappings)}): {', '.join(lost_mappings[:8])}")
        if not lines:
            return
        lines.insert(0, "JSON diff — changes from the previously loaded template:\n")
        messagebox.showinfo("Template Diff", "\n".join(lines), parent=self)

    def _load_existing_spec(self):
        if not self.template:
            return
        if getattr(self, "is_paytable", False):
            # Paytable templates store mappings in table_templates["Main"]["mappings"]
            mappings, spec = extract_existing_table_mappings(self.template, self.table_var.get().strip())
            self.mappings = mappings
            if not mappings:
                self.mappings = list(self.template.get("mappings") or [])
            if not spec:
                spec = self.template.get("spec") or {}
            self.sheet_var.set(str(spec.get("sheet_name") or spec.get("source_sheet") or "Paytable"))
            self.table_source_var.set(str(spec.get("source_range") or ""))
            self.sheet_var.set(str(spec.get("source_sheet") or "Paytable"))
            self.marker_var.set("PAYTABLE")
            self.source_sheets_var.set("")
        else:
            mappings, spec = extract_existing_table_mappings(self.template, self.table_var.get().strip())
            self.mappings = mappings
            if spec:
                self.sheet_var.set(str(spec.get("source_sheet") or self.sheet_var.get()))
                alias_names = spec.get("source_sheets") or spec.get("sheet_aliases") or []
                if isinstance(alias_names, (list, tuple)):
                    self.source_sheets_var.set("; ".join(str(name) for name in alias_names if str(name).strip()))
                else:
                    self.source_sheets_var.set(str(alias_names or ""))
                self.table_source_var.set(str(spec.get("source_range") or self.table_source_var.get()))
                self.insert_mode_var.set(str(spec.get("insert_mode") or "after_row"))
                self.insert_after_row_var.set(_int(spec.get("insert_after_row", 0), 0))
                self.marker_var.set(str(spec.get("marker") or f"<table:{self.table_var.get().strip()}>"))
                self.margin_before_var.set(_int(spec.get("margin_before", 30), 30))
                self.margin_after_var.set(_int(spec.get("margin_after", 30), 30))
                self.fit_mode_var.set(str(spec.get("fit_mode") or "scale"))
                self.scale_if_needed_var.set(bool(spec.get("scale_if_needed", True)))
                if spec.get("absolute_x") is not None:
                    self.absolute_x_var.set(str(spec.get("absolute_x")))
                if spec.get("absolute_y") is not None:
                    self.absolute_y_var.set(str(spec.get("absolute_y")))
            else:
                self.source_sheets_var.set("")
                self.marker_var.set(f"<table:{self.table_var.get().strip()}>")
        self._refresh_mappings()

    def _table_selected(self):
        self._load_existing_spec()
        self._refresh_slots()
        self._draw_preview()

    def _scan_excel(self):
        path = self.excel_var.get().strip()
        sheet = self.sheet_var.get().strip()
        if not path or not sheet:
            return
        try:
            self.blocks = scan_table_excel_content(path, sheet, max_column=self.max_col_var.get())
            self._rebuild_source_tree()
            if not self.table_source_var.get().strip():
                first_table = next((block for block in self.blocks if block.get("kind") == "table_range"), None)
                if first_table:
                    self.table_source_var.set(first_table.get("source") or "")
                    self.insert_after_row_var.set(max(0, _int(first_table.get("row", 1), 1) - 1))
            self.status_var.set(f"Loaded {len(self.blocks)} Excel rows/ranges.")
        except Exception as exc:
            messagebox.showerror("Excel Scan Error", str(exc), parent=self)

    def _refresh_all(self):
        self._scan_excel()
        self._refresh_slots()

    def _rebuild_source_tree(self):
        self.source_tree.delete(*self.source_tree.get_children())
        self.source_items.clear()
        for block_index, block in enumerate(self.blocks):
            item_id = f"block:{block_index}"
            label = "Table" if block.get("kind") == "table_range" else block.get("label", "Row")
            preview = str(block.get("text") or "")
            if len(preview) > 140:
                preview = preview[:137] + "..."
            self.source_tree.insert("", "end", iid=item_id, text=label, values=(block.get("source"), preview))
            self.source_items[item_id] = {"type": "block", "block": block}
            for cell_index, cell in enumerate(block.get("cells") or []):
                cell_id = f"cell:{block_index}:{cell_index}"
                cell_preview = str(cell.get("text") or "")
                if len(cell_preview) > 120:
                    cell_preview = cell_preview[:117] + "..."
                merged = str(cell.get("merged_source") or "")
                source_label = str(cell.get("source") or "")
                if merged and merged != source_label:
                    source_label = f"{source_label} ({merged})"
                self.source_tree.insert(item_id, "end", iid=cell_id, text="Cell", values=(source_label, cell_preview))
                self.source_items[cell_id] = {"type": "cell", "block": block, "cell": cell}
                for token_index, token in enumerate(cell.get("tokens") or []):
                    child_id = f"token:{block_index}:{cell_index}:{token_index}"
                    self.source_tree.insert(cell_id, "end", iid=child_id, text="Token", values=(cell.get("source"), f"<{token}>"))
                    self.source_items[child_id] = {
                        "type": "token",
                        "block": block,
                        "cell": cell,
                        "token_index": token_index,
                        "token": token,
                    }

    def _refresh_slots(self):
        if not self.template:
            self.slot_combo["values"] = []
            self._all_slots = []
            return
        table = self.table_var.get().strip()
        slots = list(slots_for_table_template(self.template, table).keys())
        for slot_name in (self.template.get("slots") or {}):
            if slot_name not in slots and parse_table_slot_ref(slot_name):
                slots.append(slot_name)
        self._all_slots = slots[:]
        self._filter_slots()
        if self.slot_var.get() not in slots:
            self.slot_var.set(slots[0] if slots else "")
        self.selected_slot_names = {self.slot_var.get()} if self.slot_var.get() else set()

    def _filter_slots(self):
        query = self.slot_filter_var.get().strip().casefold()
        if not query:
            filtered = list(self._all_slots)
        else:
            filtered = [s for s in self._all_slots if query in s.casefold()]
        self.slot_combo["values"] = filtered

    def _slot_names(self):
        return list(self.slot_combo["values"] or [])

    def _selected_slot_names(self):
        name = self.slot_var.get().strip()
        return [name] if name else []

    def _sync_slot_list_selection(self):
        pass

    def _slot_list_selected(self, _event=None):
        slot = self.slot_var.get().strip()
        if slot:
            preset = self._infer_preset_from_slot_name(slot)
            self._active_preset = preset
            self._highlight_active_preset()

    def _selected_source(self):
        sources = self._selected_sources()
        return sources[0] if sources else None

    def _selected_sources(self):
        return [
            self.source_items[item_id]
            for item_id in self.source_tree.selection()
            if item_id in self.source_items
        ]

    def _source_for_item(self, item):
        if not item:
            return ""
        if item.get("type") == "token":
            return str((item.get("cell") or item.get("block") or {}).get("source") or "")
        if item.get("type") == "cell":
            return str((item.get("cell") or {}).get("source") or "")
        return str((item.get("block") or {}).get("source") or "")

    def _item_source_matches(self, item, source):
        wanted = str(source or "").strip().casefold()
        if not wanted:
            return False
        return self._source_for_item(item).strip().casefold() == wanted

    def _combined_selected_source(self):
        sources = []
        for item in self._selected_sources():
            source = self._source_for_item(item)
            if source and source not in sources:
                sources.append(source)
        return "; ".join(sources)

    def _source_selected(self, _event=None):
        if self._syncing_source_selection:
            return
        # Cancel any pending auto-apply so it doesn't revert slot/source later
        if self._auto_apply_after_id is not None:
            try:
                self.after_cancel(self._auto_apply_after_id)
            except Exception:
                pass
            self._auto_apply_after_id = None
        self._pending_auto_style_fields.clear()
        selected_items = self._selected_sources()
        if not selected_items:
            return
        # Deselect mappings when selecting a different source (like template mapper)
        if self.mapping_tree.selection():
            self.active_mapping_index = None
            for item in self.mapping_tree.selection():
                self.mapping_tree.selection_remove(item)
            self._auto_applying = True
            try:
                self._refresh_mappings()
            finally:
                self._auto_applying = False
        self.source_var.set(self._combined_selected_source())
        selected = selected_items[0]
        block = selected.get("block") or {}
        if len(selected_items) > 1:
            self.mode_var.set("Flow text + inline icons")
        elif selected.get("type") == "token":
            self.mode_var.set("Dedicated icon")
        elif block.get("kind") == "table_range":
            self.mode_var.set("Flow text + inline icons")
        if selected.get("type") == "token":
            self.role_var.set("Dedicated icon")
        elif not self._syncing_controls:
            slot = self.slot_var.get().strip()
            kind = self._kind_from_mode()
            auto_role = self._auto_role_for_kind_and_slot(kind, slot)
            self.role_var.set({
                "heading": "Heading",
                "normal_text": "Normal text",
                "text_icon": "Text + inline icons",
                "dedicated_icon": "Dedicated icon",
                "slot_style": "Slot style",
            }.get(auto_role, "Auto"))
        # Re-assert source tree selection in case something reverted it
        selected_ids = self.source_tree.selection()
        if selected_ids:
            self.after_idle(lambda ids=selected_ids: self._assert_source_selection(ids))

    def _assert_source_selection(self, ids):
        if not ids:
            return
        current = set(self.source_tree.selection())
        wanted = set(str(i) for i in ids)
        if current != wanted:
            self._syncing_source_selection = True
            try:
                self.source_tree.selection_set(list(wanted))
            except Exception:
                pass
            finally:
                self._syncing_source_selection = False

    def _pick_text_color(self):
        color = colorchooser.askcolor(title="Slot Text Color", initialcolor=self.text_color_var.get(), parent=self)
        if color and color[1]:
            self.text_color_var.set(color[1])

    def _pick_bg_color(self):
        color = colorchooser.askcolor(title="Slot Background Color", initialcolor=self.bg_color_var.get(), parent=self)
        if color and color[1]:
            self.bg_color_var.set(color[1])

    def _pick_stroke_color(self):
        color = colorchooser.askcolor(title="Slot Stroke Color", initialcolor=self.stroke_color_var.get(), parent=self)
        if color and color[1]:
            self.stroke_color_var.set(color[1])

    def _has_style_controls_enabled(self):
        return bool(self.fill_enabled_var.get()) or bool(self.stroke_enabled_var.get())

    def _install_auto_style_traces(self):
        def watch(variable, *fields):
            trace_id = variable.trace_add(
                "write",
                lambda *_args, field_names=tuple(fields): self._schedule_auto_style_apply(field_names),
            )
            self._auto_style_trace_refs.append((variable, trace_id))

        watch(self.font_size_var, "font_size")
        watch(self.icon_height_var, "icon_size")
        watch(self.token_height_var, "icon_size")
        watch(self.text_color_var, "text_color")
        watch(self.bg_color_var, "fill_bg")
        watch(self.opacity_var, "fill_bg")
        watch(self.fill_enabled_var, "fill_bg")
        watch(self.stroke_color_var, "stroke")
        watch(self.stroke_width_var, "stroke")
        watch(self.stroke_enabled_var, "stroke")
        watch(self.align_var, "align_pad")
        watch(self.valign_var, "align_pad")
        for variable in self.padding_vars:
            watch(variable, "align_pad")
        watch(self.mode_var, "mode_role")
        watch(self.role_var, "mode_role")

    def _schedule_auto_style_apply(self, fields):
        if self._syncing_controls:
            return
        fields = {field for field in fields or [] if field in {"font_size", "text_color", "icon_size", "fill_bg", "stroke", "align_pad", "mode_role"}}
        if not fields:
            return
        if not (self._selected_mapping_indexes() or self._selected_slot_names()):
            return
        self._pending_auto_style_fields.update(fields)
        if self._auto_apply_after_id is not None:
            try:
                self.after_cancel(self._auto_apply_after_id)
            except Exception:
                pass
        self._auto_apply_after_id = self.after(250, self._auto_apply_visual_fields_to_selection)

    def _auto_apply_visual_fields_to_selection(self):
        self._auto_apply_after_id = None
        if self._syncing_controls:
            return
        fields = set(self._pending_auto_style_fields)
        self._pending_auto_style_fields.clear()
        if not fields:
            return

        indexes = self._selected_mapping_indexes()
        if indexes:
            try:
                self._push_undo()
                for index in indexes:
                    slot = str(self.mappings[index].get("slot") or self.slot_var.get() or "")
                    self._patch_mapping_from_controls(self.mappings[index], slot, fields)
                self._auto_applying = True
                try:
                    self._refresh_mappings(select_indexes=indexes)
                finally:
                    self._auto_applying = False
                self.status_var.set(f"Auto-applied visual fields to {len(indexes)} mapping(s).")
            except Exception as exc:
                self.status_var.set(str(exc))
            return

        # When no mapping is selected, don't auto-apply — would create mappings and revert tree
        self._auto_applying = True
        try:
            self._apply_fields_to_slots(fields, show_messages=False, auto=True)
        finally:
            self._auto_applying = False

    def _kind_from_mode(self, mode=None):
        return MODE_LONG_TO_KIND.get(mode or self.mode_var.get(), "flow")

    def _apply_style_controls_to_mapping(self, mapping, require_style=False):
        fill_enabled = bool(self.fill_enabled_var.get())
        stroke_enabled = bool(self.stroke_enabled_var.get())
        stroke_width = max(0, _int(self.stroke_width_var.get(), 0))
        if require_style and not fill_enabled and not stroke_enabled:
            raise ValueError("Enable Fill, Stroke, or both for a box styling mapping.")
        if stroke_enabled and stroke_width <= 0:
            raise ValueError("Stroke is enabled, so set Stroke Width above 0.")
        if fill_enabled or stroke_enabled or require_style:
            mapping["background_color"] = self.bg_color_var.get()
            mapping["opacity"] = max(0, min(100, _int(self.opacity_var.get(), 100)))
            mapping["fill_enabled"] = fill_enabled
            mapping["stroke_enabled"] = stroke_enabled
            mapping["stroke_color"] = self.stroke_color_var.get()
            mapping["stroke_width"] = stroke_width

    def _force_style_controls_to_mapping(self, mapping):
        stroke_width = max(0, _int(self.stroke_width_var.get(), 0))
        stroke_enabled = bool(self.stroke_enabled_var.get())
        if stroke_enabled and stroke_width <= 0:
            raise ValueError("Stroke is enabled, so set Stroke Width above 0.")
        mapping["background_color"] = self.bg_color_var.get()
        mapping["opacity"] = max(0, min(100, _int(self.opacity_var.get(), 100)))
        mapping["fill_enabled"] = bool(self.fill_enabled_var.get())
        mapping["stroke_enabled"] = stroke_enabled
        mapping["stroke_color"] = self.stroke_color_var.get()
        mapping["stroke_width"] = stroke_width if stroke_enabled else 0

    def _role_value_from_controls(self, kind, slot):
        label = str(self.role_var.get() or "Auto").strip().casefold()
        explicit = {
            "heading": "heading",
            "normal text": "normal_text",
            "text + inline icons": "text_icon",
            "dedicated icon": "dedicated_icon",
            "slot style": "slot_style",
        }.get(label)
        if explicit:
            return explicit
        return self._auto_role_for_kind_and_slot(kind, slot)

    def _mapping_from_controls(self):
        mode = self.mode_var.get()
        selected_items = self._selected_sources()
        selected = selected_items[0] if selected_items else None
        slot = self.slot_var.get().strip()
        source = self._combined_selected_source() or self.source_var.get().strip()
        if not slot:
            raise ValueError("Select a table slot first.")
        if mode not in {"Box fill/stroke"} and not source:
            raise ValueError("Select an Excel row/range or enter a source range.")
        kind = self._kind_from_mode(mode)
        if len(selected_items) > 1 and kind in {"dedicated_icon", "inline_icon_size"}:
            raise ValueError("Icon and Icon Size mappings need one selected token only.")
        role = self._role_value_from_controls(kind, slot)
        mapping = {
            "kind": kind,
            "source": source,
            "slot": slot,
            "role": role,
            "font_size": max(1, _int(self.font_size_var.get(), 30)),
            "icon_height": max(0, _int(self.icon_height_var.get(), 48)),
            "color": self.text_color_var.get(),
            "alignment": self.align_var.get(),
            "vertical_align": self.valign_var.get(),
            "padding": [_int(variable.get(), 0) for variable in self.padding_vars],
        }
        if kind == "box_fill_stroke":
            self._apply_style_controls_to_mapping(mapping, require_style=True)
        else:
            self._apply_style_controls_to_mapping(mapping, require_style=False)
        if selected and selected.get("type") == "token":
            mapping["token_index"] = int(selected.get("token_index", 0))
            mapping["token"] = selected.get("token", "")
            if kind == "inline_icon_size":
                mapping["icon_height"] = max(1, _int(self.token_height_var.get(), self.icon_height_var.get()))
        elif kind in {"dedicated_icon", "inline_icon_size"}:
            raise ValueError("Expand an Excel row and select the specific <token> first.")
        if ".rowtemplate." in slot.casefold():
            mapping["repeat"] = True
        return mapping

    def _patch_mapping_from_controls(self, mapping, slot=None, fields=None):
        fields = set(fields or [])
        if not fields:
            fields = {"source", "mode_role", "font_size", "text_color", "icon_size", "fill_bg", "stroke", "align_pad"}
        slot = str(slot or mapping.get("slot") or self.slot_var.get() or "").strip()
        if not slot:
            raise ValueError("Select a table slot first.")
        mapping["slot"] = slot

        if "source" in fields:
            source = self._combined_selected_source() or self.source_var.get().strip()
            if not source and str(mapping.get("kind") or "").casefold() != "box_fill_stroke":
                raise ValueError("Row data/source is selected for update, but no Excel row/cell/range is selected.")
            mapping["source"] = source

        if "mode_role" in fields:
            kind = self._kind_from_mode()
            mapping["kind"] = kind
            mapping["role"] = self._role_value_from_controls(kind, slot)
            if kind == "box_fill_stroke":
                mapping["source"] = ""
            elif not str(mapping.get("source") or "").strip():
                source = self._combined_selected_source() or self.source_var.get().strip()
                if not source:
                    raise ValueError("Mode/role update needs an Excel row/cell/range for content mappings.")
                mapping["source"] = source

        if "font_size" in fields:
            mapping["font_size"] = max(1, _int(self.font_size_var.get(), 30))
        if "text_color" in fields:
            mapping["color"] = self.text_color_var.get()
        if "icon_size" in fields:
            mapping["icon_height"] = max(0, _int(self.icon_height_var.get(), 48))
        if "fill_bg" in fields:
            mapping["background_color"] = self.bg_color_var.get()
            mapping["opacity"] = max(0, min(100, _int(self.opacity_var.get(), 100)))
            mapping["fill_enabled"] = bool(self.fill_enabled_var.get())
        if "stroke" in fields:
            stroke_width = max(0, _int(self.stroke_width_var.get(), 0))
            stroke_enabled = bool(self.stroke_enabled_var.get())
            if stroke_enabled and stroke_width <= 0:
                raise ValueError("Stroke is enabled, so set Stroke Width above 0.")
            mapping["stroke_enabled"] = stroke_enabled
            mapping["stroke_color"] = self.stroke_color_var.get()
            mapping["stroke_width"] = stroke_width if stroke_enabled else 0
        if "align_pad" in fields:
            mapping["alignment"] = self.align_var.get()
            mapping["vertical_align"] = self.valign_var.get()
            mapping["padding"] = [_int(variable.get(), 0) for variable in self.padding_vars]
        if ".rowtemplate." in slot.casefold():
            mapping["repeat"] = True
        return mapping

    def _new_background_mapping_for_slot(self, slot, fields):
        if not ({"fill_bg", "stroke"} & set(fields or [])):
            return None
        mapping = {
            "kind": "box_fill_stroke",
            "source": "",
            "slot": slot,
            "role": "slot_style",
            "font_size": max(1, _int(self.font_size_var.get(), 30)),
            "icon_height": max(0, _int(self.icon_height_var.get(), 48)),
            "color": self.text_color_var.get(),
            "alignment": self.align_var.get(),
            "vertical_align": self.valign_var.get(),
            "padding": [_int(variable.get(), 0) for variable in self.padding_vars],
        }
        return self._patch_mapping_from_controls(mapping, slot, fields)

    def _auto_role_for_kind_and_slot(self, kind, slot):
        slot_key = str(slot or "").casefold()
        kind = str(kind or "").casefold()
        if "header" in slot_key or "heading" in slot_key or "title" in slot_key:
            return "heading"
        if kind in {"dedicated_icon"}:
            return "dedicated_icon"
        if kind == "flow":
            return "text_icon"
        if kind == "box_fill_stroke":
            return "slot_style"
        return "normal_text"

    def _role_label_from_value(self, role):
        return {
            "heading": "Heading",
            "normal_text": "Normal text",
            "text_icon": "Text + inline icons",
            "dedicated_icon": "Dedicated icon",
            "slot_style": "Slot style",
        }.get(str(role or "").strip().casefold(), "Auto")

    def _apply_visual_controls_to_mapping(self, mapping, slot):
        role = self._role_value_from_controls(mapping.get("kind"), slot)
        mapping["role"] = role
        mapping["font_size"] = max(1, _int(self.font_size_var.get(), 30))
        mapping["icon_height"] = max(0, _int(self.icon_height_var.get(), 48))
        mapping["color"] = self.text_color_var.get()
        mapping["alignment"] = self.align_var.get()
        mapping["vertical_align"] = self.valign_var.get()
        mapping["padding"] = [_int(variable.get(), 0) for variable in self.padding_vars]
        self._force_style_controls_to_mapping(mapping)
        if ".rowtemplate." in str(slot or "").casefold():
            mapping["repeat"] = True

    def _mapping_indexes_for_slot(self, slot):
        slot_key = str(slot or "").casefold()
        return [
            index for index, mapping in enumerate(self.mappings)
            if str(mapping.get("slot") or "").casefold() == slot_key
        ]

    def _apply_fields_to_slots(self, fields, show_messages=True, auto=False):
        slots = self._selected_slot_names()
        if not slots:
            if show_messages:
                messagebox.showwarning("Apply to Slots", "Select one or more @table slots first.", parent=self)
            return False
        if not fields:
            fields = {"source", "mode_role", "font_size", "text_color", "icon_size", "fill_bg", "stroke", "align_pad"}
        self._push_undo()
        updated = 0
        created = 0
        selected_indexes = []
        try:
            for slot in slots:
                indexes = self._mapping_indexes_for_slot(slot)
                if indexes:
                    for index in indexes:
                        self._patch_mapping_from_controls(self.mappings[index], slot, fields)
                        selected_indexes.append(index)
                        updated += 1
                    continue
                mapping = self._new_background_mapping_for_slot(slot, fields)
                if mapping is None:
                    continue
                self.mappings.append(mapping)
                selected_indexes.append(len(self.mappings) - 1)
                created += 1
        except Exception as exc:
            if show_messages:
                messagebox.showwarning("Apply to Slots", str(exc), parent=self)
            else:
                self.status_var.set(str(exc))
            return False
        if not updated and not created:
            message = "No existing mappings were found for those slots. Tick Fill/BG or Stroke to create style-only mappings."
            if show_messages:
                messagebox.showwarning("Apply to Slots", message, parent=self)
            elif not auto:
                self.status_var.set(message)
            return False
        self.selected_slot_names = set(slots)
        self._refresh_mappings(select_indexes=selected_indexes)
        self._sync_slot_list_selection()
        action = "Auto-applied visual fields" if auto else "Applied selected fields"
        self.status_var.set(f"{action} to {updated} mappings; created {created} style mappings.")
        return True

    def _apply_controls_to_slots(self):
        self._apply_fields_to_slots(None, show_messages=True)

    def _mapping_conflict_index(self, candidate, ignore_index=None):
        kind = str(candidate.get("kind") or "").casefold()
        slot = str(candidate.get("slot") or "").casefold()
        source = str(candidate.get("source") or "").casefold()
        token_index = _int(candidate.get("token_index", 0), 0)
        for index, mapping in enumerate(self.mappings):
            if ignore_index is not None and index == ignore_index:
                continue
            existing_kind = str(mapping.get("kind") or "").casefold()
            if kind == "inline_icon_size" or existing_kind == "inline_icon_size":
                if (
                    kind == existing_kind
                    and slot == str(mapping.get("slot") or "").casefold()
                    and source == str(mapping.get("source") or "").casefold()
                    and token_index == _int(mapping.get("token_index", 0), 0)
                ):
                    return index
                continue
            if kind != "box_fill_stroke" and existing_kind != "box_fill_stroke" and slot == str(mapping.get("slot") or "").casefold():
                return index
        return None

    def _map_deterministic_cell_refs(self):
        """Scan all template slots for Excel cell references.
        Supports namespaced (cashExpressTrains.B22) and flat (@table.B22) formats."""
        if not self.template:
            return 0
        excel_path = self.excel_var.get().strip()
        sheet_name = self.sheet_var.get().strip()
        if not excel_path or not sheet_name:
            return 0
        table_name = self.table_var.get().strip()
        table_prefix = table_name + "." if table_name else ""
        all_slots = list(self.template.get("slots", {}).keys())
        mapped_keys = {str(m.get("slot") or "").casefold() for m in self.mappings
                       if str(m.get("kind") or "").casefold() != "box_fill_stroke"}
        created = 0
        workbook = None
        try:
            for slot in all_slots:
                if slot.casefold() in mapped_keys:
                    continue
                if "bounds" in slot.casefold():
                    continue
                cell_ref = parse_table_slot_ref(slot)
                if not cell_ref and table_prefix and slot.casefold().startswith(table_prefix.casefold()):
                    remainder = slot[len(table_prefix):]
                    cell_ref = parse_table_slot_ref(remainder)
                if not cell_ref:
                    continue
                col1, row1, col2, row2 = cell_ref
                if workbook is None:
                    try:
                        workbook = load_workbook(excel_path, data_only=True, read_only=True)
                    except Exception as e:
                        import traceback
                        traceback.print_exc()
                        self.status_var.set(f"Auto-map: cannot load workbook - {e}")
                        return 0
                if sheet_name not in workbook.sheetnames:
                    print(f"[auto-map] SKIP {slot}: sheet {sheet_name!r} not in workbook sheets {workbook.sheetnames}")
                    continue
                ws = workbook[sheet_name]
                try:
                    max_row = ws.max_row if ws.max_row is not None else 2**31
                    max_col = ws.max_column if ws.max_column is not None else 2**31
                except Exception:
                    max_row = 2**31
                    max_col = 2**31
                if row1 > max_row or row1 < 1:
                    print(f"[auto-map] SKIP {slot}: row {row1} out of range (max_row={max_row})")
                    continue
                col_idx = column_index_from_string(col1)
                if col_idx > max_col or col_idx < 1:
                    print(f"[auto-map] SKIP {slot}: col {col1}({col_idx}) out of range (max_col={max_col})")
                    continue
                ref_str = f"{col1}{row1}" if col1 == col2 and row1 == row2 else f"{col1}{row1}:{col2}{row2}"
                cell_val = str(ws[f"{col1}{row1}"].value or "")
                kind = "flow"
                if "<" in cell_val and ">" in cell_val:
                    kind = "flow"
                elif cell_val.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.bmp', '.svg')):
                    kind = "dedicated_icon"
                candidate = {
                    "kind": kind,
                    "source": ref_str,
                    "slot": slot,
                    "role": self._auto_role_for_kind_and_slot(kind, slot),
                    "font_size": max(1, _int(self.font_size_var.get(), 30)),
                    "icon_height": max(0, _int(self.icon_height_var.get(), 48)),
                    "color": self.text_color_var.get(),
                    "alignment": self.align_var.get(),
                    "vertical_align": self.valign_var.get(),
                    "padding": [_int(v.get(), 0) for v in self.padding_vars],
                }
                conflict = self._mapping_conflict_index(candidate)
                if conflict is None:
                    self.mappings.append(candidate)
                    created += 1
                    mapped_keys.add(slot.casefold())
            if created:
                self.status_var.set(f"Cell-ref auto-map: {created} slot(s) mapped from cell references.")
        except Exception as exc:
            import traceback
            traceback.print_exc()
            self.status_var.set(f"Auto-map error: {exc}")
        finally:
            if workbook is not None:
                workbook.close()
        return created

    def _auto_map_cell_refs(self):
        """Map only cell-ref slots deterministically. No sequential fallback."""
        if not self.template:
            messagebox.showwarning("Auto Map", "Load a @table JSON first.", parent=self)
            return
        excel_path = self.excel_var.get().strip()
        sheet_name = self.sheet_var.get().strip()
        if not excel_path or not sheet_name:
            messagebox.showwarning("Auto Map", "Load an Excel workbook and select a sheet first.", parent=self)
            return
        count = self._map_deterministic_cell_refs()
        if count == 0:
            slots_list = list(self.template.get("slots", {}).keys())
            cell_ref_slots = [s for s in slots_list if parse_table_slot_ref(s) and "bounds" not in s.casefold()]
            if not cell_ref_slots:
                messagebox.showinfo("Auto Map", "No cell-ref slots found.\nName slots like '@table.B22', 'cashExpressTrains.B22', or bare 'D22'.", parent=self)
            else:
                messagebox.showwarning("Auto Map", f"Found {len(cell_ref_slots)} cell-ref slot(s) but could not resolve them.\nCheck that the Excel sheet '{sheet_name}' has the expected rows/columns.", parent=self)
        else:
            self._refresh_mappings(select_index=len(self.mappings) - 1)
            messagebox.showinfo("Auto Map", f"Created {count} deterministic mapping(s) from cell references.", parent=self)

    def _pick_overall_stroke_color(self):
        color = colorchooser.askcolor(title="Overall Stroke Color", initialcolor=self.overall_stroke_color_var.get(), parent=self)
        if color and color[1]:
            self.overall_stroke_color_var.set(color[1])

    def _apply_overall_stroke(self):
        if not self.overall_stroke_enabled_var.get():
            messagebox.showinfo("Overall Stroke", "Enable 'Overall Stroke' checkbox first.", parent=self)
            return
        color = self.overall_stroke_color_var.get()
        width = max(0, _int(self.overall_stroke_width_var.get(), 2))
        count = 0
        for mapping in self.mappings:
            mapping["stroke_color"] = color
            mapping["stroke_width"] = width
            count += 1
        if count:
            self.status_var.set(f"Applied overall stroke (color={color}, width={width}) to {count} mapping(s).")
            messagebox.showinfo("Overall Stroke", f"Applied stroke to {count} mapping(s).\nEdit individual strokes in Advanced options.", parent=self)
        else:
            messagebox.showinfo("Overall Stroke", "No mappings exist to apply stroke to.", parent=self)

    def _map_remaining(self):
        """Auto-assign unmapped Excel rows to unmapped slots sequentially."""
        if not self.template:
            messagebox.showwarning("Map Remaining", "Load a @table JSON first.", parent=self)
            return
        cell_ref_count = self._map_deterministic_cell_refs()
        mapped_slots = {str(m.get("slot") or "").casefold() for m in self.mappings if str(m.get("kind") or "").casefold() != "box_fill_stroke"}
        all_slots = [str(s) for s in (self._slot_names() or []) if s and s.casefold() not in mapped_slots and "bounds" not in s.casefold()]
        all_slots.sort(key=lambda s: (len(s), s))
        if not all_slots:
            messagebox.showinfo("Map Remaining", "All slots already have mappings.", parent=self)
            return
        unmapped_rows = []
        for item_id in self.source_tree.get_children():
            item = self.source_items.get(item_id)
            if not item or item.get("type") != "block":
                continue
            block = item.get("block") or {}
            if str(block.get("kind") or "").casefold() in ("table_range",):
                continue
            source = str(block.get("source") or "").strip()
            if source and not any(
                str(m.get("source") or "").strip().casefold() == source.casefold()
                for m in self.mappings
            ):
                unmapped_rows.append((block.get("row", 0), source, block))
        unmapped_rows.sort(key=lambda r: r[0])
        if not unmapped_rows:
            messagebox.showinfo("Map Remaining", "All Excel rows already have mappings.", parent=self)
            return
        self._push_undo()
        created = 0
        for (row, source, block), slot in zip(unmapped_rows, all_slots):
            self.slot_var.set(slot)
            self.source_var.set(source)
            self.source_tree.selection_set(item_id)
            kind = "flow"
            text = str(block.get("text") or "")
            if "<" in text and ">" in text:
                kind = "flow"
            candidate = {
                "kind": kind,
                "source": source,
                "slot": slot,
                "role": self._auto_role_for_kind_and_slot(kind, slot),
                "font_size": max(1, _int(self.font_size_var.get(), 30)),
                "icon_height": max(0, _int(self.icon_height_var.get(), 48)),
                "color": self.text_color_var.get(),
                "alignment": self.align_var.get(),
                "vertical_align": self.valign_var.get(),
                "padding": [_int(v.get(), 0) for v in self.padding_vars],
            }
            conflict = self._mapping_conflict_index(candidate)
            if conflict is None:
                self.mappings.append(candidate)
                created += 1
        self._refresh_mappings(select_index=len(self.mappings) - created if created else None)
        self.status_var.set(f"Map Remaining: created {created} mapping(s). {len(all_slots) - min(created, len(all_slots))} slot(s) still unused.")
        if created > 0:
            self.source_tree.selection_set()

    def _add_mapping(self):
        try:
            candidate = self._mapping_from_controls()
            conflict = self._mapping_conflict_index(candidate)
            if conflict is not None:
                self._refresh_mappings(select_index=conflict)
                raise ValueError("That table slot already has a content assignment. Update the selected mapping instead.")
            self._push_undo()
            self.mappings.append(candidate)
            self._refresh_mappings(select_index=len(self.mappings) - 1)
            self.status_var.set("Mapping added.")
        except Exception as exc:
            messagebox.showwarning("Cannot Assign", str(exc), parent=self)

    def _remove_mapping(self):
        index = self._selected_mapping_index()
        if index is None:
            return
        self._push_undo()
        self.mappings.pop(index)
        self._refresh_mappings(select_index=min(index, len(self.mappings) - 1))

    def _move_mapping(self, direction):
        index = self._selected_mapping_index()
        if index is None:
            return
        target = index + int(direction)
        if target < 0 or target >= len(self.mappings):
            return
        self._push_undo()
        self.mappings[index], self.mappings[target] = self.mappings[target], self.mappings[index]
        self._refresh_mappings(select_index=target)

    def _copy_mappings(self):
        indexes = self._selected_mapping_indexes()
        if not indexes:
            self.status_var.set("Select one or more mappings to copy.")
            return
        self._clipboard_mappings = [copy.deepcopy(self.mappings[i]) for i in indexes]
        self.status_var.set(f"Copied {len(self._clipboard_mappings)} mapping(s).")

    def _paste_mappings(self):
        pasted = getattr(self, "_clipboard_mappings", None)
        if not pasted:
            self.status_var.set("No copied mappings to paste.")
            return
        self._push_undo()
        for mapping in pasted:
            self.mappings.append(copy.deepcopy(mapping))
        self._refresh_mappings(select_index=len(self.mappings) - len(pasted))
        self.status_var.set(f"Pasted {len(pasted)} mapping(s).")

    def _selected_mapping_index(self):
        indexes = self._selected_mapping_indexes()
        return indexes[0] if indexes else None

    def _selected_mapping_indexes(self):
        selected = self.mapping_tree.selection()
        if not selected:
            return []
        indexes = []
        for item_id in selected:
            try:
                index = int(str(item_id).split(":", 1)[1])
            except Exception:
                continue
            if 0 <= index < len(self.mappings):
                indexes.append(index)
        return sorted(set(indexes))

    def _refresh_mappings(self, select_index=None, select_indexes=None):
        selected_indexes = None
        if select_indexes is not None:
            selected_indexes = sorted({
                int(index) for index in select_indexes
                if isinstance(index, int) and 0 <= int(index) < len(self.mappings)
            })
            self.active_mapping_index = selected_indexes[0] if selected_indexes else None
        elif select_index is not None and 0 <= select_index < len(self.mappings):
            self.active_mapping_index = int(select_index)
        elif self.active_mapping_index is not None and not (0 <= self.active_mapping_index < len(self.mappings)):
            self.active_mapping_index = None
        self.mapping_tree.delete(*self.mapping_tree.get_children())
        labels = {
            "flow": "Flow",
            "text_only": "Text",
            "dedicated_icon": "Icon",
            "inline_icon_size": "Inline size",
            "box_fill_stroke": "Box fill",
        }
        for index, mapping in enumerate(self.mappings):
            kind = labels.get(str(mapping.get("kind") or "").casefold(), mapping.get("kind"))
            role = str(mapping.get("role") or "").strip().casefold()
            if role == "heading":
                kind = "Heading"
            elif role == "text_icon":
                kind = "Text/Icon"
            elif role == "dedicated_icon":
                kind = "Dedicated icon"
            elif str(mapping.get("kind") or "").casefold() == "box_fill_stroke":
                kind = "Box fill"
            source = str(mapping.get("source") or "")
            if mapping.get("kind") in {"dedicated_icon", "inline_icon_size"}:
                source = f"{source} #{_int(mapping.get('token_index', 0), 0) + 1}"
            self.mapping_tree.insert("", "end", iid=f"map:{index}", values=(kind, source, mapping.get("slot")))
        if selected_indexes is not None:
            items = [f"map:{index}" for index in selected_indexes if 0 <= index < len(self.mappings)]
            if items:
                self.mapping_tree.selection_set(*items)
                self.mapping_tree.focus(items[0])
                self.mapping_tree.see(items[0])
        elif self.active_mapping_index is not None and 0 <= self.active_mapping_index < len(self.mappings):
            item = f"map:{self.active_mapping_index}"
            self.mapping_tree.selection_set(item)
            self.mapping_tree.focus(item)
            self.mapping_tree.see(item)
        self._draw_preview()
        self._update_preview_summary()

    def _mapping_selected(self, _event=None):
        if getattr(self, "_auto_applying", False):
            return
        indexes = self._selected_mapping_indexes()
        if not indexes:
            return
        # Apply any pending auto-style changes to the about-to-be-selected
        # mappings before syncing controls, so user's edits are not overwritten.
        if self._pending_auto_style_fields:
            fields = set(self._pending_auto_style_fields)
            self._pending_auto_style_fields.clear()
            canceled = self._auto_apply_after_id
            if canceled is not None:
                try:
                    self.after_cancel(canceled)
                except Exception:
                    pass
                self._auto_apply_after_id = None
            for index in indexes:
                try:
                    slot = str(self.mappings[index].get("slot") or self.slot_var.get() or "")
                    self._patch_mapping_from_controls(self.mappings[index], slot, fields)
                except Exception:
                    pass
            self._refresh_mappings(select_indexes=indexes)
        if len(indexes) > 1:
            self.active_mapping_index = indexes[0]
            # Show common values across selected mappings
            common = dict(self.mappings[indexes[0]])
            for i in indexes[1:]:
                m = self.mappings[i]
                for k in list(common.keys()):
                    if common.get(k) != m.get(k):
                        del common[k]
            self._syncing_controls = True
            try:
                self.source_var.set(str(common.get("source") or ""))
                self.slot_var.set(str(common.get("slot") or ""))
                self.selected_slot_names = {str(common.get("slot") or "")} if common.get("slot") else set()
                self._sync_slot_list_selection()
                self.mode_var.set(KIND_TO_MODE_LONG.get(str(common.get("kind") or "").casefold(), "Flow text + inline icons"))
                self.role_var.set(self._role_label_from_value(common.get("role")))
                self.font_size_var.set(_int(common.get("font_size", 30), 30))
                self.icon_height_var.set(_int(common.get("icon_height", 48), 48))
                self.text_color_var.set(self._hex_from_value(common.get("color"), "#FFFFFF"))
                self.bg_color_var.set(self._hex_from_value(common.get("background_color"), "#000000"))
                self.stroke_color_var.set(self._hex_from_value(common.get("stroke_color"), "#FFFFFF"))
                self.opacity_var.set(_int(common.get("opacity", 100), 100))
                self.stroke_width_var.set(_int(common.get("stroke_width", 0), 0))
                self.fill_enabled_var.set(bool(common.get("fill_enabled", False)))
                stroke_enabled = bool(common.get("stroke_enabled", False)) or _int(common.get("stroke_width", 0), 0) > 0
                self.stroke_enabled_var.set(stroke_enabled)
                self.align_var.set(str(common.get("alignment") or "center"))
                self.valign_var.set(str(common.get("vertical_align") or "center"))
                padding = list(common.get("padding") or [0, 0, 0, 0])
                padding = (padding + [0, 0, 0, 0])[:4]
                for variable, value in zip(self.padding_vars, padding):
                    variable.set(_int(value, 0))
                self.token_height_var.set(_int(common.get("icon_height", self.icon_height_var.get()), self.icon_height_var.get()))
            finally:
                self._syncing_controls = False
            self.status_var.set(f"Selected {len(indexes)} mappings (showing common values). Changes auto-apply to all.")
            return
        index = indexes[0]
        self.active_mapping_index = index
        mapping = self.mappings[index]
        self._syncing_controls = True
        try:
            self.source_var.set(str(mapping.get("source") or ""))
            self.slot_var.set(str(mapping.get("slot") or ""))
            self.selected_slot_names = {str(mapping.get("slot") or "")} if mapping.get("slot") else set()
            self._sync_slot_list_selection()
            mode_by_kind = KIND_TO_MODE_LONG.copy()
            mode_by_kind.setdefault("flow", "Flow text + inline icons")
            self.mode_var.set(mode_by_kind.get(str(mapping.get("kind") or "").casefold(), "Flow text + inline icons"))
            self.role_var.set(self._role_label_from_value(mapping.get("role")))
            self.font_size_var.set(_int(mapping.get("font_size", 30), 30))
            self.icon_height_var.set(_int(mapping.get("icon_height", 48), 48))
            self.text_color_var.set(self._hex_from_value(mapping.get("color"), "#FFFFFF"))
            self.bg_color_var.set(self._hex_from_value(mapping.get("background_color"), "#000000"))
            self.stroke_color_var.set(self._hex_from_value(mapping.get("stroke_color"), "#FFFFFF"))
            self.opacity_var.set(_int(mapping.get("opacity", 100), 100))
            self.stroke_width_var.set(_int(mapping.get("stroke_width", 0), 0))
            self.fill_enabled_var.set(bool(mapping.get("fill_enabled", False)))
            stroke_enabled = bool(mapping.get("stroke_enabled", False)) or _int(mapping.get("stroke_width", 0), 0) > 0
            self.stroke_enabled_var.set(stroke_enabled)
            self.align_var.set(str(mapping.get("alignment") or "center"))
            self.valign_var.set(str(mapping.get("vertical_align") or "center"))
            padding = list(mapping.get("padding") or [0, 0, 0, 0])
            padding = (padding + [0, 0, 0, 0])[:4]
            for variable, value in zip(self.padding_vars, padding):
                variable.set(_int(value, 0))
            self.token_height_var.set(_int(mapping.get("icon_height", self.icon_height_var.get()), self.icon_height_var.get()))
        finally:
            self._syncing_controls = False
        self._select_source_items_for_mapping(mapping)
        self._draw_preview()

    def _select_source_items_for_mapping(self, mapping):
        source_parts = [part.strip() for part in str(mapping.get("source") or "").split(";") if part.strip()]
        if not source_parts:
            return
        wanted = {part.casefold() for part in source_parts}
        token_index = _int(mapping.get("token_index", -1), -1)
        preferred = []
        fallback = []
        for item_id, item in self.source_items.items():
            item_source = self._source_for_item(item).strip().casefold()
            if item_source not in wanted:
                continue
            if item.get("type") == "token":
                if token_index >= 0 and _int(item.get("token_index", -1), -1) == token_index:
                    preferred.append(item_id)
                else:
                    fallback.append(item_id)
            elif item.get("type") == "cell":
                preferred.append(item_id)
            else:
                fallback.append(item_id)
        chosen = preferred or fallback
        if not chosen:
            return
        try:
            self._syncing_source_selection = True
            self.source_tree.selection_set(chosen)
            self.source_tree.focus(chosen[0])
            self.source_tree.see(chosen[0])
        except Exception:
            pass
        finally:
            self._syncing_source_selection = False

    def _hex_from_value(self, value, fallback):
        if isinstance(value, str) and value.strip().startswith("#"):
            return value.strip()
        if isinstance(value, (list, tuple)) and len(value) >= 3:
            try:
                return "#%02x%02x%02x" % (int(value[0]), int(value[1]), int(value[2]))
            except Exception:
                pass
        return fallback

    def _draw_preview(self):
        canvas = self.preview_canvas
        canvas.delete("all")
        if not self.template:
            canvas.create_text(
                max(20, canvas.winfo_width() / 2),
                max(20, canvas.winfo_height() / 2),
                text="Load @table / @slot JSON",
                fill=self.palette["muted"],
            )
            return
        if self.preview_mode_var.get():
            self._render_live_preview(canvas)
            return
        source_canvas = self.template.get("canvas") or {}
        page_width = float(source_canvas.get("width", 1))
        page_height = float(source_canvas.get("height", 1))
        available_width = max(100, canvas.winfo_width() - 28)
        available_height = max(100, canvas.winfo_height() - 28)
        scale = min(available_width / page_width, available_height / page_height)
        offset_x = (canvas.winfo_width() - page_width * scale) / 2.0
        offset_y = (canvas.winfo_height() - page_height * scale) / 2.0
        canvas.create_rectangle(
            offset_x,
            offset_y,
            offset_x + page_width * scale,
            offset_y + page_height * scale,
            fill=self.palette["panel_bg"],
            outline=self.palette["border"],
            width=2,
        )
        mapped = {}
        for mapping in self.mappings:
            mapped.setdefault(str(mapping.get("slot") or "").casefold(), []).append(mapping)
        selected_slots = {slot.casefold() for slot in (self.selected_slot_names or set())}
        selected = self.slot_var.get().casefold()
        # For paytable, use all slots; for table, use table-specific slot resolution
        if getattr(self, "is_paytable", False):
            slot_boxes = dict(self.template.get("slots") or {})
        else:
            slot_boxes = slots_for_table_template(self.template, self.table_var.get().strip())
            for name, box in (self.template.get("slots") or {}).items():
                if name not in slot_boxes and parse_table_slot_ref(name):
                    slot_boxes[name] = box
        for slot_name, box in slot_boxes.items():
            key = str(slot_name).casefold()
            try:
                x1 = offset_x + float(box["x"]) * scale
                y1 = offset_y + float(box["y"]) * scale
                x2 = x1 + float(box["w"]) * scale
                y2 = y1 + float(box["h"]) * scale
            except Exception:
                continue
            color = self.palette["success"] if key in mapped else self.palette["accent"]
            width = 3 if key == selected or key in selected_slots else 1
            if key == selected or key in selected_slots:
                color = self.palette["accent_alt"]
            # Fill for slots with background_color
            fill_color = None
            if key in mapped:
                bg = str(mapped[key][0].get("background_color") or "").strip()
                if bg:
                    try:
                        fill_rgb = tuple(int(bg.lstrip("#")[i:i+2], 16) for i in (0, 2, 4))
                        fill_color = "#%02x%02x%02x" % fill_rgb
                    except Exception:
                        pass
            rect = canvas.create_rectangle(x1, y1, x2, y2, outline=color, width=width, fill=fill_color)
            label = str(slot_name)
            if key in mapped:
                label += "\n" + str(mapped[key][0].get("source") or mapped[key][0].get("kind") or "")
            label_item = canvas.create_text(
                (x1 + x2) / 2,
                (y1 + y2) / 2,
                text=label,
                fill=self.palette["text"],
                width=max(20, x2 - x1 - 6),
                justify="center",
                font=("Segoe UI", 8),
            )
            for item in (rect, label_item):
                canvas.tag_bind(item, "<Button-1>", lambda event, name=slot_name: self._select_slot(
                    name, additive=bool(event.state & 0x0004), shift=bool(event.state & 0x0001)))
                canvas.tag_bind(item, "<Button-3>", lambda event, name=slot_name: self._slot_context_menu(event, name))

    def _render_live_preview(self, canvas):
        """Render a content preview using PIL from current mappings + Excel."""
        if getattr(self, "is_paytable", False):
            self._render_paytable_live_preview(canvas)
            return
        excel_path = self.excel_var.get().strip()
        sheet_name = self.sheet_var.get().strip()
        wb = None
        try:
            source_canvas = self.template.get("canvas") or {}
            page_width = float(source_canvas.get("width", 1))
            page_height = float(source_canvas.get("height", 1))
            scale = min((canvas.winfo_width() - 28) / page_width, (canvas.winfo_height() - 28) / page_height)
            scale = max(0.05, min(2.0, scale))
            img_w = max(1, int(page_width * scale))
            img_h = max(1, int(page_height * scale))
            img = Image.new("RGBA", (img_w, img_h), (24, 26, 30, 255))
            draw = ImageDraw.Draw(img)

            if excel_path and sheet_name and os.path.isfile(excel_path):
                wb = load_workbook(excel_path, data_only=True, read_only=True)
                ws = wb[sheet_name] if sheet_name in wb.sheetnames else None
            else:
                ws = None

            slot_boxes = {}
            table = self.table_var.get().strip()
            slot_boxes.update(slots_for_table_template(self.template, table))
            for name, box in (self.template.get("slots") or {}).items():
                if name not in slot_boxes and parse_table_slot_ref(name):
                    slot_boxes[name] = box

            # First pass — draw ALL slot outlines
            mapped_keys = {str(m.get("slot") or "").casefold() for m in self.mappings}
            for slot_name, box in slot_boxes.items():
                try:
                    bx = float(box["x"]) * scale
                    by = float(box["y"]) * scale
                    bw = max(1, float(box["w"]) * scale)
                    bh = max(1, float(box["h"]) * scale)
                except Exception:
                    continue
                key = str(slot_name).casefold()
                outline = (76, 175, 80, 180) if key in mapped_keys else (100, 120, 140, 150)
                draw.rectangle([bx, by, bx + bw, by + bh], outline=outline, width=max(1, int(round(scale))))

            # Second pass — draw mapped content
            for mapping in self.mappings:
                slot_name = str(mapping.get("slot") or "").casefold()
                raw_box = None
                for sn, sb in slot_boxes.items():
                    if sn.casefold() == slot_name:
                        raw_box = sb
                        break
                if not raw_box:
                    continue
                try:
                    bx = float(raw_box["x"]) * scale
                    by = float(raw_box["y"]) * scale
                    bw = max(1, float(raw_box["w"]) * scale)
                    bh = max(1, float(raw_box["h"]) * scale)
                except Exception:
                    continue

                # Background fill
                bg = str(mapping.get("background_color") or "").strip()
                if bg:
                    try:
                        bg_rgb = tuple(int(bg.lstrip("#")[i:i+2], 16) for i in (0, 2, 4))
                        draw.rectangle([bx, by, bx + bw, by + bh], fill=bg_rgb + (220,))
                    except Exception:
                        pass

                # Stroke
                stroke = str(mapping.get("stroke_color") or "").strip()
                stroke_w = int(mapping.get("stroke_width", 0) or 0)
                stroke_enabled = bool(mapping.get("stroke_enabled", False)) or stroke_w > 0
                if stroke_enabled and stroke_w > 0 and stroke:
                    try:
                        sw = max(1, int(round(stroke_w * scale)))
                        srgb = tuple(int(stroke.lstrip("#")[i:i+2], 16) for i in (0, 2, 4))
                        draw.rectangle([bx, by, bx + bw, by + bh], outline=srgb + (255,), width=sw)
                    except Exception:
                        pass

                # Text content
                source = str(mapping.get("source") or "").strip()
                cell_text = ""
                if source and ws is not None:
                    try:
                        refs = [r.strip() for r in source.replace(";", " ").split() if r.strip()]
                        for ref in refs:
                            try:
                                cell = ws[ref]
                            except Exception:
                                continue
                            if isinstance(cell, tuple):
                                vals = []
                                for row in cell:
                                    for c in row:
                                        if c and c.value is not None:
                                            vals.append(str(c.value))
                                if vals:
                                    cell_text = " | ".join(vals)
                                continue
                            if cell and cell.value is not None:
                                cell_text = str(cell.value)
                                break
                    except Exception:
                        pass

                if not cell_text:
                    kind = str(mapping.get("kind") or "").casefold()
                    if kind == "dedicated_icon":
                        cell_text = "\U0001F5BC"
                    elif kind == "box_fill_stroke":
                        cell_text = ""
                    else:
                        cell_text = source or slot_name

                if cell_text:
                    fs = max(8, int(scale * max(10, int(mapping.get("font_size", 14) or 14))))
                    try:
                        font = ImageFont.truetype("segoeui.ttf", fs)
                    except Exception:
                        try:
                            font = ImageFont.truetype("arial.ttf", fs)
                        except Exception:
                            try:
                                font = ImageFont.truetype("Segoe UI", fs)
                            except Exception:
                                font = ImageFont.load_default()
                    color = str(mapping.get("color") or "#FFFFFF").strip()
                    try:
                        crgb = tuple(int(color.lstrip("#")[i:i+2], 16) for i in (0, 2, 4))
                    except Exception:
                        crgb = (200, 200, 200)
                    padding = int(4 * scale)
                    tx = bx + padding
                    ty = by + padding
                    mw = max(8, bw - 2 * padding)
                    # Word-wrap text
                    words = str(cell_text[:200]).split()
                    lines = []
                    cur = ""
                    for w in words:
                        test = cur + (" " if cur else "") + w
                        tw, _ = draw.textsize(test, font=font)
                        if tw <= mw:
                            cur = test
                        else:
                            if cur:
                                lines.append(cur)
                            cur = w
                    if cur:
                        lines.append(cur)
                    line_h = fs + 2
                    for i, line in enumerate(lines[:max(1, int(bh / line_h))]):
                        draw.text((tx, ty + i * line_h), line, fill=crgb + (255,), font=font)

            offset_x = (canvas.winfo_width() - img_w) / 2
            offset_y = (canvas.winfo_height() - img_h) / 2
            self._preview_photo = ImageTk.PhotoImage(img)
            canvas.create_image(offset_x, offset_y, image=self._preview_photo, anchor="nw")
            self.preview_render_status.set("Rendered")
        except Exception as exc:
            import traceback
            traceback.print_exc()
            self.preview_render_status.set(f"Preview error: {exc}")
            canvas.create_text(
                max(20, canvas.winfo_width() / 2),
                max(20, canvas.winfo_height() / 2),
                text=f"Preview error: {exc}",
                fill=self.palette["muted"],
            )
        finally:
            if wb is not None:
                try:
                    wb.close()
                except Exception:
                    pass

    def _render_paytable_live_preview(self, canvas):
        """Render a paytable preview: title, symbol cards, payouts, feature text, bottom notes."""
        import re
        from .dynamic_pages.paytable.parser import parse_paytable_sheet

        excel_path = self.excel_var.get().strip()
        sheet_name = self.sheet_var.get().strip()
        if not excel_path or not os.path.isfile(excel_path):
            self._draw_empty_preview(canvas, "Load Excel workbook")
            return
        try:
            wb = load_workbook(excel_path, data_only=True, read_only=True)
            ws = wb[sheet_name] if sheet_name in wb.sheetnames else None
        except Exception as e:
            self._draw_empty_preview(canvas, f"Excel error: {e}")
            return
        if ws is None:
            self._draw_empty_preview(canvas, f"Sheet '{sheet_name}' not found")
            return

        source_canvas = self.template.get("canvas") or {}
        page_width = float(source_canvas.get("width", 1))
        page_height = float(source_canvas.get("height", 1))
        available_w = max(100, canvas.winfo_width() - 28)
        available_h = max(100, canvas.winfo_height() - 28)
        scale = min(available_w / page_width, available_h / page_height)
        scale = max(0.05, min(2.0, scale))
        img_w = max(1, int(page_width * scale))
        img_h = max(1, int(page_height * scale))
        img = Image.new("RGBA", (img_w, img_h), (16, 18, 20, 255))
        draw = ImageDraw.Draw(img)

        # Parse paytable data
        try:
            page_data = parse_paytable_sheet(ws, self.template)
        except Exception as e:
            self._draw_empty_preview(canvas, f"Parse error: {e}")
            return

        slots = self.template.get("slots") or {}
        slot_prefix = str(self.template.get("slot_prefix") or "").strip()

        def get_slot(name):
            # Try exact, then with prefix
            for key in (name, f"{slot_prefix}{name}"):
                if key in slots:
                    return slots[key]
                # Case-insensitive
                for k, v in slots.items():
                    if k.casefold() == key.casefold():
                        return v
            return None

        def draw_box(box, fill=None, outline=None, width=1):
            if not box:
                return
            x = float(box["x"]) * scale
            y = float(box["y"]) * scale
            w = max(1, float(box["w"]) * scale)
            h = max(1, float(box["h"]) * scale)
            if fill:
                draw.rectangle([x, y, x + w, y + h], fill=fill)
            if outline and width > 0:
                sw = max(1, int(round(width * scale)))
                draw.rectangle([x, y, x + w, y + h], outline=outline, width=sw)

        def draw_text_in_box(box, text, font_size=12, color="#FFFFFF", align="center"):
            if not box or not text:
                return
            x = float(box["x"]) * scale
            y = float(box["y"]) * scale
            w = max(1, float(box["w"]) * scale)
            h = max(1, float(box["h"]) * scale)
            fs = max(8, int(font_size * scale))
            try:
                font = ImageFont.truetype("segoeui.ttf", fs)
            except Exception:
                font = ImageFont.load_default()
            try:
                crgb = tuple(int(color.lstrip("#")[i:i+2], 16) for i in (0, 2, 4))
            except Exception:
                crgb = (200, 200, 200)
            # Simple text placement
            tw, th = draw.textsize(text, font=font)
            if align == "center":
                tx = x + (w - tw) / 2
                ty = y + (h - th) / 2
            elif align == "right":
                tx = x + w - tw - 4
                ty = y + (h - th) / 2
            else:
                tx = x + 4
                ty = y + (h - th) / 2
            draw.text((tx, ty), text, fill=crgb + (255,), font=font)

        # 1. Title
        title_box = get_slot("title")
        if title_box:
            draw_box(title_box, outline=(100, 100, 100), width=1)
            draw_text_in_box(title_box, page_data.get("title", "PAYTABLE"), font_size=24, color="#F6C343")

        # 2. Top cards (feature symbols)
        top_cards = page_data.get("top_cards") or []
        for idx, card in enumerate(top_cards, 1):
            # Icon
            icon_box = get_slot(f"symbol.{idx}.icon") or get_slot(f"symbol.{idx}")
            if icon_box:
                draw_box(icon_box, outline=(80, 80, 80), width=1)
                draw_text_in_box(icon_box, f"[{card.get('label','?')}]", font_size=14, color="#88AAFF")

            # Payouts
            pay_box = get_slot(f"symbol.{idx}.pay") or get_slot(f"symbol.{idx}.pays")
            if pay_box and card.get("payouts"):
                pay_text = "\n".join(f"{p.get('count','?')}x {p.get('value','?')}" for p in card["payouts"][:3])
                draw_text_in_box(pay_box, pay_text, font_size=11, color="#FFFFFF")

        # 3. Lower cards
        lower_cards = page_data.get("lower_cards") or []
        for idx, card in enumerate(lower_cards, 1):
            icon_box = get_slot(f"symbol.{len(top_cards)+idx}.icon") or get_slot(f"symbol.{len(top_cards)+idx}")
            if icon_box:
                draw_box(icon_box, outline=(80, 80, 80), width=1)
                draw_text_in_box(icon_box, f"[{card.get('label','?')}]", font_size=14, color="#88AAFF")
            pay_box = get_slot(f"symbol.{len(top_cards)+idx}.pay") or get_slot(f"symbol.{len(top_cards)+idx}.pays")
            if pay_box and card.get("payouts"):
                pay_text = "\n".join(f"{p.get('count','?')}x {p.get('value','?')}" for p in card["payouts"][:3])
                draw_text_in_box(pay_box, pay_text, font_size=11, color="#FFFFFF")

        # 4. Wild/Feature icon
        wild_icon_box = get_slot("wild.icon1") or get_slot("feature.icon1")
        if wild_icon_box:
            draw_box(wild_icon_box, fill=(50, 50, 80, 180), outline=(100, 100, 200), width=2)
            draw_text_in_box(wild_icon_box, "[WILD]", font_size=16, color="#FFD700")

        # 5. Feature text (strip wild tokens)
        side = page_data.get("side_panel") or {}
        feat_lines = side.get("feature_text_lines") or []
        if feat_lines:
            # Wild icon text slots
            for i, line in enumerate(feat_lines[:2]):
                text_box = get_slot(f"wild.icon{i+1}.text") or get_slot(f"feature.text{i+1}")
                if text_box:
                    clean = re.sub(r"<[^>]+>", "", line)
                    draw_text_in_box(text_box, clean[:120], font_size=12, color="#FFFFFF")

        # 6. Bottom notes
        notes_box = get_slot("bottom_notes")
        bn = side.get("bottom_notes") or []
        if notes_box and bn:
            draw_box(notes_box, outline=(80, 80, 80), width=1)
            draw_text_in_box(notes_box, "\n".join(bn[:3]), font_size=10, color="#BBBBBB", align="left")

        # Composite onto canvas
        offset_x = (canvas.winfo_width() - img_w) / 2
        offset_y = (canvas.winfo_height() - img_h) / 2
        self._preview_photo = ImageTk.PhotoImage(img)
        canvas.create_image(offset_x, offset_y, image=self._preview_photo, anchor="nw")
        self.preview_render_status.set("Paytable preview rendered")

    def _draw_empty_preview(self, canvas, msg):
        canvas.delete("all")
        canvas.create_text(
            max(20, canvas.winfo_width() / 2),
            max(20, canvas.winfo_height() / 2),
            text=msg,
            fill=self.palette["muted"],
        )
        self.preview_render_status.set(msg)

    def _update_preview_summary(self):
        if not self.template:
            self.preview_summary_var.set("")
            return
        if getattr(self, "is_paytable", False):
            slot_boxes = dict(self.template.get("slots") or {})
        else:
            table = self.table_var.get().strip()
            slot_boxes = slots_for_table_template(self.template, table)
            for name, box in (self.template.get("slots") or {}).items():
                if name not in slot_boxes and parse_table_slot_ref(name):
                    slot_boxes[name] = box
        mapped_slots = {str(m.get("slot") or "").casefold() for m in self.mappings if m.get("slot")}
        total = len(slot_boxes)
        mapped_count = sum(1 for name in slot_boxes if name.casefold() in mapped_slots)
        unmapped_count = total - mapped_count
        canvas = self.template.get("canvas") or {}
        cw = canvas.get("width", "?")
        ch = canvas.get("height", "?")
        parts = [f"{total} slots: {mapped_count} mapped, {unmapped_count} unmapped"]
        parts.append(f"Canvas {cw}x{ch}")
        if self.mappings:
            parts.append(f"{len(self.mappings)} mapping(s)")
        self.preview_summary_var.set("  |  ".join(parts))

    def _select_slot(self, slot_name, additive=False, shift=False):
        if self._auto_apply_after_id is not None:
            try:
                self.after_cancel(self._auto_apply_after_id)
            except Exception:
                pass
            self._auto_apply_after_id = None
        self._pending_auto_style_fields.clear()
        if shift:
            current = self.selected_slot_names or set()
            current.add(str(slot_name))
            self.selected_slot_names = current
            self.slot_var.set(str(slot_name))
            self.status_var.set(f"Shift-selected slot: {slot_name} ({len(self.selected_slot_names)} selected)")
            self._draw_preview()
            return
        self.slot_var.set(str(slot_name))
        self.selected_slot_names = {str(slot_name)} if slot_name else set()
        if len(self.selected_slot_names) > 1:
            self.status_var.set(f"Selected {len(self.selected_slot_names)} table slots for bulk editing.")
            self._draw_preview()
            return
        slot_key = str(slot_name or "").casefold()
        chosen_index = None
        for index, mapping in enumerate(self.mappings):
            if str(mapping.get("slot") or "").casefold() != slot_key:
                continue
            if str(mapping.get("kind") or "").casefold() != "box_fill_stroke":
                chosen_index = index
                break
            if chosen_index is None:
                chosen_index = index
        if chosen_index is not None:
            self._refresh_mappings(select_index=chosen_index)
            self._mapping_selected()
            self.status_var.set(f"Selected mapped slot: {slot_name}")
            return
        self._draw_preview()

    def _slot_context_menu(self, event, slot_name):
        # Preserve multi-selection if clicked slot is already selected
        current = set(self.selected_slot_names or [])
        if slot_name not in current:
            self._select_slot(slot_name)
        targets = set(self.selected_slot_names or []) or {slot_name}
        has_multi = len(targets) > 1
        target_label = f"{len(targets)} slots" if has_multi else slot_name

        menu = tk.Menu(self, tearoff=0, bg=self.palette["panel_bg"], fg=self.palette["text"],
                       activebackground=self.palette["accent"], activeforeground="#000000")

        slot_key = slot_name.casefold()
        mapping = None
        for m in self.mappings:
            if str(m.get("slot") or "").casefold() == slot_key:
                mapping = m
                break

        # Copy / Paste
        menu.add_command(label="Copy properties", command=self._copy_single_mapping)
        if getattr(self, "_clipboard_props", None):
            lbl = f"Paste properties to {target_label}" if has_multi else "Paste properties"
            menu.add_command(label=lbl, command=lambda: self._paste_to_slot(targets))
        menu.add_separator()

        # Mode
        mode_menu = tk.Menu(menu, tearoff=0, bg=self.palette["panel_bg"], fg=self.palette["text"])
        for mode in ("Flow text + inline icons", "Text", "Dedicated icon", "Inline icon size", "Box fill/stroke"):
            mode_menu.add_command(label=mode, command=lambda m=mode: self._quick_set_mode(targets, m))
        menu.add_cascade(label="Mode", menu=mode_menu)

        # Role
        role_menu = tk.Menu(menu, tearoff=0, bg=self.palette["panel_bg"], fg=self.palette["text"])
        for role in ("Auto", "Heading", "Normal text", "Text + inline icons", "Dedicated icon", "Slot style"):
            role_menu.add_command(label=role, command=lambda r=role: self._quick_set_role(targets, r))
        menu.add_cascade(label="Role", menu=role_menu)

        # Style presets
        preset_menu = tk.Menu(menu, tearoff=0, bg=self.palette["panel_bg"], fg=self.palette["text"])
        for name in ("Heading", "Body", "Subhead", "Icon", "Fill"):
            preset_menu.add_command(label=name, command=lambda n=name: self._apply_preset_to_targets(targets, n))
        menu.add_cascade(label="Style preset", menu=preset_menu)

        menu.add_separator()

        # Colors
        color_menu = tk.Menu(menu, tearoff=0, bg=self.palette["panel_bg"], fg=self.palette["text"])
        color_menu.add_command(label="Text color...", command=lambda: self._quick_set_color(targets, "color"))
        color_menu.add_command(label="Background...", command=lambda: self._quick_set_color(targets, "background_color"))
        color_menu.add_command(label="Stroke color...", command=lambda: self._quick_set_color(targets, "stroke_color"))
        color_menu.add_separator()
        color_menu.add_command(label="No background / Clear fill", command=lambda: self._clear_background_color(targets))
        menu.add_cascade(label="Colors", menu=color_menu)

        # Font size
        size_menu = tk.Menu(menu, tearoff=0, bg=self.palette["panel_bg"], fg=self.palette["text"])
        for sz in (10, 12, 14, 16, 18, 20, 24, 30, 36, 48, 60, 72):
            size_menu.add_command(label=f"{sz}px", command=lambda s=sz: self._quick_set_font_size(targets, s))
        menu.add_cascade(label="Font size", menu=size_menu)

        # Stroke width
        stroke_menu = tk.Menu(menu, tearoff=0, bg=self.palette["panel_bg"], fg=self.palette["text"])
        for sw in (0, 1, 2, 3, 4, 5, 8, 10):
            lbl = "None" if sw == 0 else f"{sw}px"
            stroke_menu.add_command(label=lbl, command=lambda w=sw: self._quick_set_stroke(targets, w))
        menu.add_cascade(label="Stroke width", menu=stroke_menu)

        # Alignment
        align_menu = tk.Menu(menu, tearoff=0, bg=self.palette["panel_bg"], fg=self.palette["text"])
        for al in ("left", "center", "right"):
            align_menu.add_command(label=al.title(), command=lambda a=al: self._quick_set_align(targets, a))
        menu.add_cascade(label="Alignment", menu=align_menu)

        menu.add_separator()
        menu.add_command(label=f"Remove mapping{'s' if has_multi else ''}", command=lambda: self._remove_slot_mapping(targets))

        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()

    def _apply_preset_to_targets(self, targets, name):
        presets = {
            "Heading": dict(font_size=36, icon_height=48, color="#F6C343", align="center", valign="center",
                            role="Heading", mode="Flow text + inline icons"),
            "Body":    dict(font_size=28, icon_height=48, color="#FFFFFF", align="center", valign="center",
                            role="Normal text", mode="Flow text + inline icons"),
            "Subhead": dict(font_size=24, icon_height=36, color="#B8B2A3", align="center", valign="center",
                            role="Normal text", mode="Text"),
            "Icon":    dict(font_size=30, icon_height=48, color="#FFFFFF", align="center", valign="center",
                            role="Dedicated icon", mode="Dedicated icon"),
            "Fill":    dict(font_size=28, icon_height=0, color="#FFFFFF", align="center", valign="center",
                            role="Slot style", mode="Box fill/stroke",
                            fill_enabled=True, background_color="#333333"),
        }
        preset = presets.get(name)
        if not preset:
            return
        self._push_undo()
        for tgt in targets:
            tgt_key = tgt.casefold()
            for m in self.mappings:
                if str(m.get("slot") or "").casefold() == tgt_key:
                    for k, v in preset.items():
                        if k == "mode":
                            kind = MODE_LONG_TO_KIND.get(v, "flow")
                            m["kind"] = kind
                        elif k == "role":
                            role_map = {"Heading": "heading", "Normal text": "normal_text",
                                        "Dedicated icon": "dedicated_icon", "Slot style": "slot_style"}
                            m["role"] = role_map.get(v, v)
                        elif k in ("align",):
                            m["alignment"] = v
                        elif k in ("valign",):
                            m["vertical_align"] = v
                        else:
                            m[k] = v
                    break
        self._refresh_mappings()
        self._draw_preview()
        self.status_var.set(f"Applied preset '{name}' to {len(targets)} slot(s).")

    def _quick_set_mode(self, targets, mode_label):
        kind = MODE_LONG_TO_KIND.get(mode_label, "flow")
        self._push_undo()
        for tgt in targets:
            tgt_key = tgt.casefold()
            for m in self.mappings:
                if str(m.get("slot") or "").casefold() == tgt_key:
                    m["kind"] = kind
                    if kind == "box_fill_stroke":
                        m["role"] = "slot_style"
                    m["role"] = self._auto_role_for_kind_and_slot(kind, str(m.get("slot") or ""))
                    break
        self._refresh_mappings()
        self._draw_preview()

    def _quick_set_role(self, targets, role_label):
        role_map = {"Heading": "heading", "Normal text": "normal_text",
                    "Text + inline icons": "text_icon", "Dedicated icon": "dedicated_icon",
                    "Slot style": "slot_style"}
        role = role_map.get(role_label, role_label)
        self._push_undo()
        for tgt in targets:
            tgt_key = tgt.casefold()
            for m in self.mappings:
                if str(m.get("slot") or "").casefold() == tgt_key:
                    m["role"] = role
                    break
        self._refresh_mappings()
        self._draw_preview()

    def _copy_single_mapping(self):
        targets = list(self.selected_slot_names or [])
        if not targets:
            self.status_var.set("Select a slot first.")
            return
        slot_key = targets[0].casefold()
        for m in self.mappings:
            if str(m.get("slot") or "").casefold() == slot_key:
                props = {
                    "font_size": m.get("font_size"),
                    "icon_height": m.get("icon_height"),
                    "color": m.get("color"),
                    "background_color": m.get("background_color"),
                    "stroke_color": m.get("stroke_color"),
                    "stroke_width": m.get("stroke_width"),
                    "stroke_enabled": m.get("stroke_enabled"),
                    "fill_enabled": m.get("fill_enabled"),
                    "opacity": m.get("opacity"),
                    "alignment": m.get("alignment"),
                    "vertical_align": m.get("vertical_align"),
                    "padding": copy.deepcopy(m.get("padding")),
                    "token_height": m.get("token_height"),
                }
                self._clipboard_props = {k: v for k, v in props.items() if v is not None}
                self.status_var.set(f"Copied style properties from {targets[0]}.")
                return
        self.status_var.set(f"No mapping to copy for {targets[0]}.")

    def _paste_to_slot(self, targets):
        props = getattr(self, "_clipboard_props", None)
        if not props:
            self.status_var.set("No copied properties to paste.")
            return
        self._push_undo()
        if isinstance(targets, str):
            targets = {targets}
        updated = 0
        for tgt in targets:
            tgt_key = tgt.casefold()
            found = False
            for m in self.mappings:
                if str(m.get("slot") or "").casefold() == tgt_key:
                    for k, v in props.items():
                        m[k] = copy.deepcopy(v)
                    found = True
                    updated += 1
                    break
            if not found:
                new_map = {"slot": tgt, "source": "", "kind": "flow"}
                new_map.update(copy.deepcopy(props))
                self.mappings.append(new_map)
                updated += 1
        self._refresh_mappings()
        self.status_var.set(f"Pasted style properties to {updated} slot(s).")

    def _quick_set_color(self, targets, field):
        if isinstance(targets, str):
            targets = {targets}
        color = colorchooser.askcolor(title=f"Pick {field}", parent=self)
        if not color or not color[1]:
            return
        self._push_undo()
        for tgt in targets:
            tgt_key = tgt.casefold()
            for m in self.mappings:
                if str(m.get("slot") or "").casefold() == tgt_key:
                    m[field] = color[1]
        self._refresh_mappings()
        self._draw_preview()

    def _quick_set_font_size(self, targets, size):
        if isinstance(targets, str):
            targets = {targets}
        self._push_undo()
        for tgt in targets:
            tgt_key = tgt.casefold()
            for m in self.mappings:
                if str(m.get("slot") or "").casefold() == tgt_key:
                    m["font_size"] = size
        self._refresh_mappings()
        self._draw_preview()

    def _quick_set_stroke(self, targets, width):
        if isinstance(targets, str):
            targets = {targets}
        self._push_undo()
        for tgt in targets:
            tgt_key = tgt.casefold()
            for m in self.mappings:
                if str(m.get("slot") or "").casefold() == tgt_key:
                    m["stroke_width"] = width
                    m["stroke_enabled"] = width > 0
        self._refresh_mappings()
        self._draw_preview()

    def _quick_set_align(self, targets, align):
        if isinstance(targets, str):
            targets = {targets}
        self._push_undo()
        for tgt in targets:
            tgt_key = tgt.casefold()
            for m in self.mappings:
                if str(m.get("slot") or "").casefold() == tgt_key:
                    m["alignment"] = align
        self._refresh_mappings()
        self._draw_preview()

    def _remove_slot_mapping(self, targets):
        if isinstance(targets, str):
            targets = {targets}
        self._push_undo()
        target_keys = {t.casefold() for t in targets}
        self.mappings[:] = [m for m in self.mappings if str(m.get("slot") or "").casefold() not in target_keys]
        self._refresh_mappings()
        self.status_var.set(f"Removed mappings for {len(targets)} slot(s).")

    def _clear_background_color(self, targets):
        if isinstance(targets, str):
            targets = {targets}
        self._push_undo()
        for tgt in targets:
            tgt_key = tgt.casefold()
            for m in self.mappings:
                if str(m.get("slot") or "").casefold() == tgt_key:
                    m.pop("background_color", None)
                    m.pop("fill_enabled", None)
                    m.pop("opacity", None)
                    break
        self._refresh_mappings()
        self.status_var.set(f"Cleared background fill for {len(targets)} slot(s).")

    def _preflight(self):
        if not self.template:
            messagebox.showwarning("Table Mapper", "Load a table JSON first.", parent=self)
            return False
        errors, warnings = validate_table_mappings(
            self.template,
            self.table_var.get().strip(),
            self.mappings,
            excel_path=self.excel_var.get().strip(),
            sheet_name=self.sheet_var.get().strip(),
            icon_folder=self.icons_folder,
            icon_mappings=self.icon_mappings,
            source_range=self.table_source_var.get().strip() or self.source_var.get().strip(),
        )
        source_range = self.table_source_var.get().strip() or self.source_var.get().strip()
        if source_range:
            try:
                excel_path = self.excel_var.get().strip()
                sheet = self.sheet_var.get().strip()
                if excel_path and sheet and os.path.isfile(excel_path):
                    wb = load_workbook(excel_path, data_only=False, read_only=True)
                    try:
                        if sheet in wb.sheetnames:
                            ws = wb[sheet]
                            _range_errors, range_warnings = validate_source_range_against_worksheet(source_range, ws)
                            warnings.extend(range_warnings)
                    finally:
                        wb.close()
            except Exception:
                pass
        lines = []
        if errors:
            lines.append("Errors:\n- " + "\n- ".join(errors))
        if warnings:
            lines.append("Warnings:\n- " + "\n- ".join(warnings))
        if not lines:
            lines.append(f"Preflight passed. {len(self.mappings)} mappings are ready.")
        messagebox.showinfo("Table Mapper Preflight", "\n\n".join(lines), parent=self)
        return not errors

    def _save(self):
        # Flush any pending auto-style changes so the save captures current edits.
        if self._pending_auto_style_fields:
            if self._auto_apply_after_id is not None:
                try:
                    self.after_cancel(self._auto_apply_after_id)
                except Exception:
                    pass
                self._auto_apply_after_id = None
            self._auto_apply_visual_fields_to_selection()
        if not self.template:
            messagebox.showwarning("Save Mapped Table JSON", "Load a table JSON first.", parent=self)
            return
        source_range = self.table_source_var.get().strip() or self.source_var.get().strip()
        errors, warnings = validate_table_mappings(
            self.template,
            self.table_var.get().strip(),
            self.mappings,
            source_range=source_range,
        )
        if source_range:
            try:
                excel_path = self.excel_var.get().strip()
                sheet = self.sheet_var.get().strip()
                if excel_path and sheet and os.path.isfile(excel_path):
                    wb = load_workbook(excel_path, data_only=False, read_only=True)
                    try:
                        if sheet in wb.sheetnames:
                            ws = wb[sheet]
                            _range_errors, range_warnings = validate_source_range_against_worksheet(source_range, ws)
                            warnings.extend(range_warnings)
                    finally:
                        wb.close()
            except Exception:
                pass
        if errors:
            messagebox.showerror("Cannot Save", "\n".join(errors), parent=self)
            return
        initial_dir = self.output_folder or os.path.dirname(self.json_var.get().strip()) or os.getcwd()
        initial_name = os.path.splitext(os.path.basename(self.json_var.get().strip() or "table"))[0]
        if self.table_var.get().strip():
            initial_name = self.table_var.get().strip()
        output_path = filedialog.asksaveasfilename(
            parent=self,
            initialdir=initial_dir,
            initialfile=f"{initial_name}_mapped.json",
            defaultextension=".json",
            filetypes=[("JSON", "*.json")],
        )
        if not output_path:
            return
        try:
            saved_path, save_warnings = save_mapped_table_template(
                self.template,
                self.sheet_var.get().strip(),
                self.table_var.get().strip(),
                self.table_source_var.get().strip() or self.source_var.get().strip(),
                self.mappings,
                output_path,
                insert_mode=self.insert_mode_var.get(),
                insert_after_row=self.insert_after_row_var.get(),
                marker=self.marker_var.get().strip() or f"<table:{self.table_var.get().strip()}>",
                absolute_x=self.absolute_x_var.get().strip(),
                absolute_y=self.absolute_y_var.get().strip(),
                margin_before=self.margin_before_var.get(),
                margin_after=self.margin_after_var.get(),
                fit_mode=self.fit_mode_var.get(),
                scale_if_needed=self.scale_if_needed_var.get(),
                icon_mappings=self.icon_mappings,
                source_sheets=self.source_sheets_var.get(),
            )
            self.status_var.set(f"Saved mapped table JSON: {saved_path}")
            if callable(self.on_saved):
                self.on_saved(saved_path, self.table_var.get().strip())
            detail = f"Mapped table JSON saved to:\n{saved_path}"
            all_warnings = warnings + save_warnings
            if all_warnings:
                detail += "\n\nWarnings:\n- " + "\n- ".join(dict.fromkeys(all_warnings))
            messagebox.showinfo("Table Mapping Saved", detail, parent=self)
        except Exception as exc:
            messagebox.showerror("Save Error", str(exc), parent=self)


def open_table_mapper(
        parent, initial_excel="", initial_json="", output_folder="",
        on_saved=None, palette=None, initial_font_size=30,
        icons_folder="", initial_icon_mappings=None,
        extra_json_paths=None):
    return TableMapperDialog(
        parent,
        initial_excel=initial_excel,
        initial_json=initial_json,
        output_folder=output_folder,
        on_saved=on_saved,
        palette=palette,
        initial_font_size=initial_font_size,
        icons_folder=icons_folder,
        initial_icon_mappings=initial_icon_mappings,
        extra_json_paths=extra_json_paths,
    )
