"""Only the AGR text inside the sheet's drawn frame.

Game docs draw a box (cell borders) around what goes on the help screen; editors' notes sit
outside it ("< modified table 7/2/25", "< removed 7/2/25"). Every workbook the tool opens goes
through `install()`'s loader: cells outside a sheet's frame read as empty, so no page, preview
or PSD ever shows those notes. A sheet without a clear frame is left exactly as it is.

The frame: a run of top borders (>= 4 cells, or fewer very wide ones) near the top of the sheet whose first cell has a
left border and whose last cell has a right border, continuing down while that left or right
edge keeps its border. One thing outside the frame is data, not a note, and stays: a
"Denom / Paylines" table (the Paylines generator reads which lines each denomination uses).
Nothing is ever written back to the Excel file.
"""
import re
import os
import threading

_LOCK = threading.Lock()
_FRAMES = {}                 # (path, size, mtime) -> {sheet title: (r0, c0, r1, c1)}
_orig_load = None


def _on(side):
    return side is not None and bool(getattr(side, "style", None))


MIN_FRAME_WIDTH = 40         # Excel width units: one very wide column can hold the whole page


def _width(ws, c0, c1):
    """Total width of columns c0..c1 (Excel units, 8.43 when a column has no width set)."""
    from openpyxl.utils import get_column_letter
    total = 0.0
    for c in range(c0, c1 + 1):
        try:
            dim = ws.column_dimensions.get(get_column_letter(c)) if hasattr(ws.column_dimensions, "get") else None
            w = float(dim.width) if dim is not None and dim.width else 8.43
        except Exception:
            w = 8.43
        total += w
    return total


def detect_frame(ws, max_top=12, max_gap=4):
    """(first row, first col, last row, last col) of the sheet's drawn frame, or None."""
    try:
        maxr, maxc = int(ws.max_row or 0), int(ws.max_column or 0)
    except Exception:
        return None
    if maxr < 4 or maxc < 1:
        return None
    border = lambda r, c: ws.cell(row=r, column=c).border
    best = None
    for r in range(1, min(maxr, max_top) + 1):
        tops = [_on(border(r, c).top) or (r > 1 and _on(border(r - 1, c).bottom)) for c in range(1, maxc + 1)]
        c = 1
        while c <= maxc:
            if not tops[c - 1]:
                c += 1
                continue
            c0 = c
            while c <= maxc and tops[c - 1]:
                c += 1
            c1 = c - 1
            if c1 - c0 + 1 < 4 and _width(ws, c0, c1) < MIN_FRAME_WIDTH:
                continue                   # a few narrow cells: a table cell, not the page
            # the corners: a left border at its first cell, a right border at its last
            left = _on(border(r, c0).left) or (c0 > 1 and _on(border(r, c0 - 1).right))
            right = _on(border(r, c1).right) or (c1 < maxc and _on(border(r, c1 + 1).left))
            if not (left and right):
                continue
            # down the sides while either edge keeps its border (short gaps allowed)
            last, gap, i = r, 0, r + 1
            while i <= maxr and gap <= max_gap:
                edge = (_on(border(i, c0).left) or (c0 > 1 and _on(border(i, c0 - 1).right))
                        or _on(border(i, c1).right) or (c1 < maxc and _on(border(i, c1 + 1).left)))
                if edge:
                    last, gap = i, 0
                else:
                    gap += 1
                i += 1
            if last - r < 3:
                continue
            area = (c1 - c0 + 1) * (last - r + 1)
            if best is None or area > best[0]:
                best = (area, (r, c0, last, c1))
        if best is not None:
            break                      # the topmost frame (inner tables sit inside it)
    return best[1] if best else None


def _key(path):
    st = os.stat(path)
    return (os.path.normcase(os.path.abspath(path)), st.st_size, st.st_mtime_ns)


def frames_for(path, wb=None):
    """{sheet: frame} for a workbook file, worked out once per file version."""
    try:
        key = _key(path)
    except (OSError, TypeError, ValueError):
        return {}
    with _LOCK:
        if key in _FRAMES:
            return _FRAMES[key]
    frames = {}
    try:
        styled = wb if wb is not None and not getattr(wb, "read_only", False) else _orig_load(path, data_only=True)
        for ws in styled.worksheets:
            fr = detect_frame(ws)
            if fr:
                frames[ws.title] = fr + (_kept_rows(ws, fr),)
    except Exception:
        frames = {}
    with _LOCK:
        if len(_FRAMES) > 32:
            _FRAMES.clear()
        _FRAMES[key] = frames
    return frames


_DATA_ROW = re.compile(r"^\s*(denoms?|denominations?|pay\s*lines|lines)\s*:?\s*$", re.I)


def _kept_rows(ws, fr):
    """Rows outside the frame that hold a Denom / Paylines table: they stay (tool data)."""
    keep = set()
    for row in ws.iter_rows():
        for cell in row:
            v = cell.value
            if isinstance(v, str) and _DATA_ROW.match(v) and (cell.row < fr[0] or cell.row > fr[2] or cell.column < fr[1] or cell.column > fr[3]):
                keep.add(cell.row)
    return frozenset(keep)


def _outside(fr, r, c):
    if len(fr) > 4 and r in fr[4]:
        return False
    return r < fr[0] or r > fr[2] or c < fr[1] or c > fr[3]


def clear_outside(wb, frames):
    """Empty every cell outside its sheet's frame (in memory only)."""
    from openpyxl.cell.cell import MergedCell

    for ws in getattr(wb, "worksheets", []):
        fr = frames.get(ws.title)
        if not fr or getattr(ws, "_psh_framed", False):
            continue
        for row in ws.iter_rows():
            for cell in row:
                if cell.value is not None and not isinstance(cell, MergedCell) and _outside(fr, cell.row, cell.column):
                    cell.value = None
        ws._psh_framed = True


def _load(filename, *args, **kwargs):
    wb = _orig_load(filename, *args, **kwargs)
    try:
        if os.environ.get("PSH_KEEP_OUTSIDE_FRAME") or not isinstance(filename, (str, os.PathLike)):
            return wb
        path = os.fspath(filename)
        frames = frames_for(path, wb)
        if not frames:
            return wb
        if getattr(wb, "read_only", False):
            for ws in wb.worksheets:
                if ws.title in frames:
                    ws._psh_frame = frames[ws.title]
        else:
            clear_outside(wb, frames)
    except Exception:
        pass                           # never let the filter stop a workbook from opening
    return wb


def _patch_read_only():
    """Read-only (streaming) sheets: cells outside the frame come back empty."""
    from openpyxl.worksheet._read_only import ReadOnlyWorksheet, EMPTY_CELL

    if getattr(ReadOnlyWorksheet, "_psh_patched", False):
        return
    orig = ReadOnlyWorksheet._cells_by_row

    def _cells_by_row(self, min_col, min_row, max_col, max_row, values_only=False):
        fr = getattr(self, "_psh_frame", None)
        r = min_row or 1
        for row in orig(self, min_col, min_row, max_col, max_row, values_only):
            if fr is None:
                yield row
            else:
                out = []
                for j, cell in enumerate(row):
                    c = (min_col or 1) + j
                    if _outside(fr, r, c):
                        out.append(None if values_only else EMPTY_CELL)
                    else:
                        out.append(cell)
                yield tuple(out)
            r += 1

    ReadOnlyWorksheet._cells_by_row = _cells_by_row
    ReadOnlyWorksheet._psh_patched = True


def install():
    """Route every load_workbook through the frame filter (idempotent)."""
    global _orig_load
    import openpyxl
    import openpyxl.reader.excel as _rx

    if getattr(_rx.load_workbook, "_psh_framed", False):
        return
    _orig_load = _rx.load_workbook
    _load._psh_framed = True
    _rx.load_workbook = _load
    openpyxl.load_workbook = _load
    try:
        _patch_read_only()
    except Exception:
        pass
