"""Table designs: a library of looks for the tables found in the Excel.

A design is a set of table_style values (colours, borders, which cells are filled) — never
sizes, so changing a table's design never moves anything on its page. "Like Excel" draws
the cells with Excel's own fills and font colours (conditional formatting included).

    table_style = {
        ...the Tables settings...,
        "default_design": "midnight",                    # every table, unless it has its own
        "designs": {"Paytable|symbol pays": "excel"},    # a table's own design, by its header
        "custom_designs": {"my_blue": {"name": "My blue", "style": {...}}},
    }

A table is recognised by its sheet and its header text, so its design survives Excel
revisions that move it to other rows.
"""
import re

# keys a design may set (colours, borders, fill modes — never geometry)
DESIGN_KEYS = ("render_mode", "header_render_mode", "row1_render_mode", "row2_render_mode",
               "header_bg_rgb", "row1_bg_rgb", "row2_bg_rgb", "header_text_rgb", "table_body_text_rgb",
               "stroke_rgb", "stroke_width")

BUILTINS = {
    "current": {"name": "Tables settings", "style": {},
                "about": "The colours set on this page (Render behaviour, Colors)."},
    "excel": {"name": "Like Excel", "excel": True, "style": {"render_mode": "fill"},
              "about": "Each cell's own fill and font colour from the Excel, coloured rules included."},
    "midnight": {"name": "Midnight", "style": {
        "render_mode": "both", "header_render_mode": "", "row1_render_mode": "", "row2_render_mode": "",
        "header_bg_rgb": "#22305A", "row1_bg_rgb": "#141B30", "row2_bg_rgb": "#1A2340",
        "header_text_rgb": "#FFFFFF", "table_body_text_rgb": "#E8ECF6", "stroke_rgb": "#3D4F86", "stroke_width": 1}},
    "gold": {"name": "Gold header", "style": {
        "render_mode": "both", "header_render_mode": "", "row1_render_mode": "", "row2_render_mode": "",
        "header_bg_rgb": "#C8952B", "row1_bg_rgb": "#2A1F10", "row2_bg_rgb": "#33270F",
        "header_text_rgb": "#1A1206", "table_body_text_rgb": "#FFF4DA", "stroke_rgb": "#E2B65A", "stroke_width": 2}},
    "lines": {"name": "Lines only", "style": {
        "render_mode": "stroke", "header_render_mode": "", "row1_render_mode": "", "row2_render_mode": "",
        "header_text_rgb": "#FFD54A", "table_body_text_rgb": "#FFFFFF", "stroke_rgb": "#FFFFFF", "stroke_width": 1}},
    "light": {"name": "Light stripes", "style": {
        "render_mode": "both", "header_render_mode": "", "row1_render_mode": "", "row2_render_mode": "",
        "header_bg_rgb": "#2D6CDF", "row1_bg_rgb": "#FFFFFF", "row2_bg_rgb": "#EEF3FB",
        "header_text_rgb": "#FFFFFF", "table_body_text_rgb": "#1B1F2A", "stroke_rgb": "#C9D6EE", "stroke_width": 1}},
    "ruby": {"name": "Ruby", "style": {
        "render_mode": "both", "header_render_mode": "", "row1_render_mode": "", "row2_render_mode": "",
        "header_bg_rgb": "#9E1B32", "row1_bg_rgb": "#2B0D14", "row2_bg_rgb": "#36111A",
        "header_text_rgb": "#FFFFFF", "table_body_text_rgb": "#FBE9EC", "stroke_rgb": "#D9506A", "stroke_width": 1}},
    "fill_only": {"name": "Blocks, no lines", "style": {
        "render_mode": "fill", "header_render_mode": "", "row1_render_mode": "", "row2_render_mode": "",
        "header_bg_rgb": "#0E7C66", "row1_bg_rgb": "#10241F", "row2_bg_rgb": "#152E28",
        "header_text_rgb": "#FFFFFF", "table_body_text_rgb": "#E6F5F1", "stroke_width": 0}},
}


def _norm(text):
    return re.sub(r"\s+", " ", str(text or "")).strip().casefold()


def table_key(sheet_name, header_text):
    """How a table is recognised across Excel revisions: its sheet and its header text."""
    return f"{sheet_name}|{_norm(header_text)[:120]}"


def all_designs(table_style):
    """{id: design} — the built-ins, then the user's own."""
    out = {k: dict(v, builtin=True) for k, v in BUILTINS.items()}
    for k, v in ((table_style or {}).get("custom_designs") or {}).items():
        if isinstance(v, dict):
            out[str(k)] = {"name": str(v.get("name") or k), "style": dict(v.get("style") or {}),
                           "excel": bool(v.get("excel")), "builtin": False}
    return out


def design_for(table_style, key):
    """The design id a table uses: its own, else the default ("current" = the Tables settings)."""
    ts = table_style or {}
    own = (ts.get("designs") or {}).get(key)
    designs = all_designs(ts)
    if own in designs:
        return own
    default = ts.get("default_design") or "current"
    return default if default in designs else "current"


def apply(table_style, design_id):
    """table_style with the design's values on top (only the keys a design may set)."""
    design = all_designs(table_style).get(design_id) or {}
    merged = dict(table_style or {})
    for k, v in (design.get("style") or {}).items():
        if k in DESIGN_KEYS:
            merged[k] = v
    return merged


def uses_excel_colours(table_style, design_id):
    return bool((all_designs(table_style).get(design_id) or {}).get("excel"))


def style_from_settings(table_style):
    """A new design made from the current Tables settings (Save as design)."""
    return {k: (table_style or {}).get(k) for k in DESIGN_KEYS if (table_style or {}).get(k) not in (None, "")}


# ── Excel's conditional formatting (the "coloured rules" Like Excel draws) ─────────────
def _const(formula):
    f = str(formula or "").strip()
    if len(f) >= 2 and f[0] == f[-1] == '"':
        return f[1:-1]
    try:
        return float(f)
    except ValueError:
        return None


def _cmp(value, op, a, b=None):
    if a is None:
        return False
    if isinstance(a, float):
        try:
            value = float(value)
        except (TypeError, ValueError):
            return False
    else:
        value = "" if value is None else str(value)
        a = str(a)
        if op in ("equal", "notEqual"):
            value, a = value.casefold(), a.casefold()
    try:
        return {"equal": value == a, "notEqual": value != a, "greaterThan": value > a, "lessThan": value < a,
                "greaterThanOrEqual": value >= a, "lessThanOrEqual": value <= a,
                "between": b is not None and a <= value <= b,
                "notBetween": b is not None and not (a <= value <= b)}.get(op, False)
    except TypeError:
        return False


def _rule_fill(rule):
    try:
        fill = rule.dxf.fill if rule.dxf is not None else None
    except Exception:
        return None
    if fill is None:
        return None
    for colour in (getattr(fill, "bgColor", None), getattr(fill, "fgColor", None)):
        rgb = getattr(colour, "rgb", None) if colour is not None and getattr(colour, "type", "") == "rgb" else None
        if not isinstance(rgb, str) or len(rgb) not in (6, 8):
            continue
        if len(rgb) == 8 and rgb[:2] == "00":          # "00000000": no colour set here
            continue
        hexv = rgb[-6:]
        try:
            return tuple(int(hexv[i:i + 2], 16) for i in (0, 2, 4))
        except ValueError:
            continue
    return None


def conditional_fill(ws, cell):
    """The fill a conditional formatting rule paints on `cell` (simple value rules), or None."""
    cf = getattr(ws, "conditional_formatting", None)
    if cf is None or cell is None:
        return None
    coord = getattr(cell, "coordinate", None)
    if not coord:
        return None
    best = None
    for rng in cf:
        try:
            if coord not in rng.sqref:
                continue
        except Exception:
            continue
        for rule in rng.rules:
            hit = False
            if rule.type == "cellIs" and rule.formula:
                a = _const(rule.formula[0])
                b = _const(rule.formula[1]) if len(rule.formula) > 1 else None
                hit = _cmp(cell.value, rule.operator, a, b)
            elif rule.type == "containsText" and rule.text:
                hit = str(rule.text).casefold() in str(cell.value or "").casefold()
            elif rule.type == "containsBlanks":
                hit = str(cell.value or "").strip() == ""
            if hit:
                fill = _rule_fill(rule)
                if fill is not None and (best is None or (rule.priority or 0) < best[0]):
                    best = (rule.priority or 0, fill)
    return best[1] if best else None
