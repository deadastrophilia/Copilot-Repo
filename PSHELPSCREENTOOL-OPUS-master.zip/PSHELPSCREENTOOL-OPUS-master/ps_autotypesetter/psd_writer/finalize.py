"""psd-tools pass over the PhotoshopAPI file: preview pixels + layer effects.

PhotoshopAPI writes text layers without pixels, and Photoshop shows such
layers as blank until it re-lays them out. Here every text layer gets the
pixels of its own text (drawn with the same PIL font and positions as the PNG
renderer), so the PSD opens showing text, and editing it in Photoshop simply
re-renders it. Captured layer styles are attached as lfx2 blocks; Photoshop
draws the effects live from the layer pixels.
"""
import io
import logging
import struct

from PIL import Image, ImageDraw
from psd_tools import PSDImage
from psd_tools.api import layers as ptl
from psd_tools.constants import Compression
from psd_tools.psd.tagged_blocks import TaggedBlock, TaggedBlocks

from .. import blend_if
from . import document, txt2

# psd-tools can't parse PhotoshopAPI's engine data and logs a warning per text
# layer; it keeps the raw bytes, which is all we need.
logging.getLogger("psd_tools").setLevel(logging.ERROR)


def render_preview(record, backdrop=None):
    """(RGBA image, left, top) of a TextRecord's glyphs, or None when empty.

    Glyphs are rasterised the way Photoshop draws the layer (ps_text: exact
    advances, unhinted outlines, pixel-snapped baseline). With `backdrop` (what
    lies under the layer) the alpha is baked so the preview also shows
    Photoshop's gamma-1.45 text blending; editing the layer then changes nothing.
    """
    from .. import ps_text

    pieces = []
    for ln in record.lines:
        for run in ln.runs:
            if not run.text.strip():
                continue
            face = getattr(run, "font", None) or record.font
            n = max(1, len(run.text))
            tracking = (float(run.advance) - ps_text.advance(face, run.text)) / n
            res = ps_text.coverage([(run.text, face, run.x, ln.baseline, tracking)])
            if res is not None:
                pieces.append((res, run.rgb))
    if not pieces:
        return None
    left = min(c[1] for c, _ in pieces)
    top = min(c[2] for c, _ in pieces)
    right = max(c[1] + c[0].width for c, _ in pieces)
    bottom = max(c[2] + c[0].height for c, _ in pieces)
    canvas = Image.new("RGBA", (right - left, bottom - top), (0, 0, 0, 0))
    for (cov, cl, ct), rgb in pieces:
        alpha = ps_text.baked_alpha(cov, cl, ct, rgb, backdrop) if backdrop is not None else cov
        solid = Image.new("RGBA", cov.size, tuple(rgb[:3]) + (0,))
        solid.putalpha(alpha)
        canvas.alpha_composite(solid, (cl - left, ct - top))
    bbox = canvas.getbbox()
    if not bbox:
        return None
    return canvas.crop(bbox), left + bbox[0], top + bbox[1]


def _backdrop(page, shared_bg, size):
    """What lies under a page's text layers: background, graphics, then shape layers."""
    base = shared_bg if shared_bg is not None else page.background
    img = base.convert("RGBA").copy() if base is not None else Image.new("RGBA", size, (255, 255, 255, 255))
    if page.image is not None:
        img.alpha_composite(page.image.convert("RGBA"))
    _add_shapes(img, page)
    return img.convert("RGB")


def _add_shapes(img, page):
    """The page's shape layers as Photoshop shows them (layer style, Fill and Opacity)."""
    for shape in reversed(list(page.shapes)):          # first-added shape sits on top
        preview = getattr(shape, "preview", None)
        if preview:
            layer, left, top = preview[0].convert("RGBA"), int(preview[1]), int(preview[2])
            o = float(getattr(shape, "opacity", 1.0) or 0)
        else:
            layer, left, top = shape.image.convert("RGBA"), int(shape.left), int(shape.top)
            o = float(getattr(shape, "opacity", 1.0) or 0) * float(getattr(shape, "fill", 1.0))
        if o != 1.0:
            layer.putalpha(layer.getchannel("A").point(lambda v, o=o: int(v * o)))
        x0, y0 = max(0, -left), max(0, -top)
        x1, y1 = min(layer.width, img.width - left), min(layer.height, img.height - top)
        if x1 > x0 and y1 > y0:
            img.alpha_composite(layer.crop((x0, y0, x1, y1)), (left + x0, top + y0))


def _effects_block(key, payload):
    """Tagged block `key` (b"lfx2" or b"lmfx") holding a layer-effects payload."""
    raw = b"8BIM" + key + struct.pack(">I", len(payload)) + payload
    if len(raw) % 2:
        raw += b"\x00"
    return TaggedBlock.read(io.BytesIO(raw))


def _set_text_index(layer, index):
    """Point the layer at its entry in the document text block (Txt2)."""
    for key, block in layer._record.tagged_blocks.items():
        if str(key).endswith("TYPE_TOOL_OBJECT_SETTING"):
            item = block.data.text_data.get(b"TextIndex")
            if item is not None:
                item.value = int(index)


def finalize(raw_path, out_path, plans, pages, shared_bg, memory=None, light=None):
    """Attach previews/effects to the PhotoshopAPI file and write `out_path`.

    light: the document's Global Light ({"angle", "altitude"}, global_light.for_document) — without it
    Photoshop reads the file as 30° and turns every "Use Global Light" shadow away from the preview.

    Returns the number of text layers that received preview pixels.
    """
    psd = PSDImage.open(raw_path)
    first = pages[0] if pages else None
    composite = None
    if first is not None:
        base = shared_bg if shared_bg is not None else first.background
        composite = base.convert("RGBA").copy() if base is not None else Image.new("RGBA", psd.size, (255, 255, 255, 255))
        if first.image is not None:
            composite.alpha_composite(first.image)
        _add_shapes(composite, first)
        for icon in first.icons:
            composite.alpha_composite(icon.image.convert("RGBA"), (max(0, icon.left), max(0, icon.top)))

    attached = 0
    image_fx = plans.pop("__image_fx__", {})       # pixel-layer name -> (key, payload)
    vectors = plans.pop("__vectors__", {})         # layer name -> live shape spec
    text_models = []                               # Txt2 entries, in TextIndex order
    backdrops = {}                                 # page index -> what lies under its text
    for layer in psd.descendants():
        if layer.kind != "type":
            fx = None if layer.is_group() else image_fx.get(layer.name.rstrip("\x00"))
            if fx:
                block = _effects_block(*fx)
                layer._record.tagged_blocks[block.key] = block
            spec = None if layer.is_group() else vectors.get(layer.name.rstrip("\x00"))
            if spec:
                try:                                   # live rounded rectangle (editable vectors)
                    from . import shapes as _shapes

                    _shapes.make_live(layer._record, spec, psd.width, psd.height)
                except Exception as exc:
                    logging.getLogger(__name__).warning("Live shape skipped for %s: %s", layer.name, exc)
            continue
        plan = plans.get(layer.name.rstrip("\x00"))
        if plan is None:
            text_models = None                     # unknown layer: leave the file as legacy text
            continue
        if text_models is not None:
            _set_text_index(layer, len(text_models))
            text_models.append(document.text_model(plan.record))
        index = getattr(plan, "page_index", 0)
        if index not in backdrops and 0 <= index < len(pages):
            try:
                backdrops[index] = _backdrop(pages[index], shared_bg, psd.size)
            except Exception:
                backdrops[index] = None
        under = blend_if.of(plan.record.fx_config)
        preview = render_preview(plan.record, backdrops.get(index))
        if preview is not None:
            image, left, top = preview
            record, channels = ptl.PixelLayer._build_layer_record_and_channels(
                image, plan.name, left, top, Compression.RLE, version=psd._record.header.version)
            r = layer._record
            r.top, r.left, r.bottom, r.right = record.top, record.left, record.bottom, record.right
            r.channel_info = record.channel_info
            layer._channels = channels
            attached += 1
            if composite is not None and plan.page_index == 0:
                before = composite.copy() if under else None
                composite.alpha_composite(image, (max(0, left), max(0, top)))
                if under:
                    blend_if.apply(composite, before, under)
        if under:
            # Blending Options › Blend If: the layer hides over a too-bright / too-dark background, as in
            # the artist's file (blend_if.py)
            blend_if.to_ranges(layer._record.blending_ranges, under)
        if plan.fx_payload:
            block = _effects_block(*plan.fx_payload)
            layer._record.tagged_blocks[block.key] = block

    # Records were edited in place: rebuild the layer section so channel data
    # is re-serialised. psd.save() would re-composite the whole document in
    # pure Python (~48s for a 9-page file); Photoshop rebuilds the view from
    # layers anyway, so write our own quick merged image instead.
    if text_models:
        # Photoshop's document text block: without it every text layer is "legacy"
        # (warning triangle, update prompt on open); see txt2.py
        try:
            # raw bytes: psd-tools would re-parse an EngineData2 block and write its own version
            block = TaggedBlock(key=b"Txt2", data=txt2.build(text_models))
            lmi = psd._record.layer_and_mask_information
            if lmi.tagged_blocks is None:
                lmi.tagged_blocks = TaggedBlocks()
            lmi.tagged_blocks[block.key] = block
        except Exception as exc:                   # never fail a build over it
            logging.getLogger(__name__).warning("Txt2 block skipped: %s", exc)
    try:                                           # PhotoshopAPI writes no layer IDs; Photoshop's own files
        from ..artist_design import psd_pages      # have them (bindings and the splice writer find layers by ID)

        psd_pages.ensure_layer_ids(psd)
    except Exception as exc:
        logging.getLogger(__name__).warning("Layer IDs skipped: %s", exc)
    if memory:
        # the project lives inside the PSD (settings, templates, Excel, links): psd_memory.py
        try:
            from .. import psd_memory

            # layer names can be changed by the artist (and Photoshop renames text layers after their
            # text); the layer ID stays: every text layer and page group is kept by both
            ids = {}
            for layer in psd.descendants():
                ids.setdefault(layer.name.rstrip("\x00"), layer.layer_id)   # PhotoshopAPI names end in NUL
            for name, src in (memory.get("layers") or {}).items():
                if name in ids and isinstance(src, dict):
                    src["id"] = ids[name]
            tops = {top.name.rstrip("\x00"): top.layer_id for top in psd if top.is_group()}
            for page in memory.get("pages") or []:
                if page.get("group") in tops:
                    page["group_id"] = tops[page["group"]]
            psd_memory.attach(psd._record, memory)
        except Exception as exc:
            logging.getLogger(__name__).warning("Project memory skipped: %s", exc)
    if light:
        try:
            from .. import global_light

            global_light.write_resources(psd, light)
        except Exception as exc:                   # never fail a build over it
            logging.getLogger(__name__).warning("Global light skipped: %s", exc)
    psd._update_record()
    if composite is not None:
        rgb = composite.convert(psd.pil_mode)
        psd._record.image_data.set_data([c.tobytes() for c in rgb.split()], psd._record.header)
    with open(out_path, "wb") as f:
        psd._record.write(f)
    return attached
