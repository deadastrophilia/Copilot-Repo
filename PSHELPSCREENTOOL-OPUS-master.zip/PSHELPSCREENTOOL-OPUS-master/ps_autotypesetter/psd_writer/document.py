"""Recorded pages -> layered PSD via PhotoshopAPI (editable text, icons, graphics).

PhotoshopAPI quirks handled here (verified against Photoshop 2026):
  * fill colours are ARGB floats (not the AGBR its docs mention);
  * the first layer added sits on TOP of the stack;
  * image layers are positioned by their CENTRE and need an explicit alpha
    channel plus fill/opacity 1.0 or they come out invisible;
  * Photoshop ignores the document-level ("normal") style sheet for leading,
    so leading/size/font/tracking are set on every style run.
Text layers carry no pixels here — finalize.py attaches preview pixels.
"""
import hashlib
import math

import numpy as np
import photoshopapi as psapi

from .. import ps_text
from . import fontnames

NBSP = " "  # icon gaps: Photoshop doesn't drop non-breaking spaces at line ends


def argb(rgb, alpha=1.0):
    return [float(alpha), rgb[0] / 255.0, rgb[1] / 255.0, rgb[2] / 255.0]


class LayerPlan:
    """What finalize.py needs per text layer (looked up by unique layer name)."""

    def __init__(self, name, record, fx_payload):
        self.name = name
        self.record = record
        self.fx_payload = fx_payload
        self.page_index = 0


def _unique(name, seen):
    base = (name or "Layer").replace("\x00", "").strip()[:80] or "Layer"
    candidate, n = base, 2
    while candidate in seen:
        candidate = f"{base} #{n}"
        n += 1
    seen.add(candidate)
    return candidate


def _image_layer(image, name, left, top, opacity=1.0):
    image = image.convert("RGBA")
    arr = np.ascontiguousarray(np.transpose(np.asarray(image, dtype=np.uint8), (2, 0, 1)))
    layer = psapi.ImageLayer_8bit(arr, name, width=image.width, height=image.height,
                                  pos_x=int(left) + image.width // 2, pos_y=int(top) + image.height // 2)
    layer.fill = 1.0
    layer.opacity = float(opacity)
    return layer


def effects_of(fx_config):
    """(tagged-block key, payload bytes) for a layer's effects, or None.

    An artist layer's raw block ({"effects_block": {"key", "hex"}}) is copied as
    is (lfx2 or lmfx); a style captured by the tool becomes an lfx2 block.
    """
    block = (fx_config or {}).get("effects_block") if isinstance(fx_config, dict) else None
    if isinstance(block, dict) and block.get("hex") and str(block.get("key")) in ("lfx2", "lmfx"):
        try:
            return str(block["key"]).encode("ascii"), bytes.fromhex(block["hex"])
        except ValueError:
            return None
    payload = _effects_payload(fx_config)
    return (b"lfx2", payload) if payload else None


def _effects_payload(fx_config):
    """lfx2 payload bytes for a captured layer style, or None.

    The tool's capture JSX (layer_styles.py) hex-encodes the descriptor
    string 4 hex digits per character ("00xx"); older presets use plain
    byte hex. The stream itself is either the raw ActionDescriptor stream
    (starts with descriptor version 16) or already prefixed with the 4-byte
    object-effects version 0 — normalise to the latter.
    """
    raw = str((fx_config or {}).get("captured_effects_hex") or "")
    raw = "".join(ch for ch in raw if ch in "0123456789abcdefABCDEF")
    if len(raw) < 16:
        return None
    try:
        if len(raw) % 4 == 0 and all(raw[i:i + 2] == "00" for i in range(0, len(raw), 4)):
            data = bytes(int(raw[i:i + 4], 16) for i in range(0, len(raw), 4))
        else:
            data = bytes.fromhex(raw[: len(raw) // 2 * 2])
    except ValueError:
        return None
    if data[:8] == b"\x00\x00\x00\x00\x00\x00\x00\x10":
        payload = data
    elif data[:4] == b"\x00\x00\x00\x10":
        payload = b"\x00\x00\x00\x00" + data
    else:
        return None
    # A capture of a layer with no effects is just an empty 'null' descriptor.
    return payload if len(payload) > 48 else None


# ── text layout -> Photoshop text string + style spans ───────────────────────


def _exact_length(font, text):
    """Width of `text` as Photoshop lays it out: fractional, unhinted advances."""
    if getattr(font, "path", None):
        from .. import ps_text

        return ps_text.advance(font, text)
    return font.getlength(text)


def _width_tracking(font, text, advance):
    """Tracking (1/1000 em per character) that makes Photoshop's width of `text`
    equal the PNG renderer's `advance` (Pillow rounds every glyph to whole pixels),
    so editing the layer in Photoshop re-lays it out without moving anything."""
    n = len(text)
    if n == 0 or not text.strip():
        return 0.0
    # Photoshop widens tracking by the width scale too (ps_text.shaped)
    return (float(advance) - _exact_length(font, text)) / n * 1000.0 / float(font.size) / ps_text.shape_of(font)[0]
def text_spans(record):
    """Build the layer string and style spans for a TextRecord.

    Returns (text, spans, line_starts) where spans are
    (start, length, rgb, tracking, line_index, font_or_None) and line_starts the pen x of each
    line's first character (gap characters included).
    """
    font = record.font
    size = float(font.size) * ps_text.shape_of(font)[0]      # tracking's em, as wide as the text draws
    # Photoshop's widths (fractional, unhinted) — gaps are filled to match the PNG exactly
    nbsp_w = max(0.1, _exact_length(font, NBSP))
    space_w = max(0.1, _exact_length(font, " "))
    text, spans, line_starts = "", [], []

    def add(chunk, rgb, tracking, line_index, run_font=None):
        """Append `chunk`; Photoshop tracking is whole 1/1000 em, so a fractional
        value is split into a floor part and a ceil part with the exact total."""
        nonlocal text
        if not chunk:
            return
        lo = math.floor(tracking)
        k = int(round((tracking - lo) * len(chunk)))       # characters that get lo + 1
        parts = [(chunk[:len(chunk) - k], lo), (chunk[len(chunk) - k:], lo + 1)] if 0 < k < len(chunk)             else [(chunk, lo + 1 if k else lo)]
        for piece, t in parts:
            spans.append((len(text), len(piece), tuple(rgb), int(t), line_index, run_font))
            text += piece

    def add_gap(width, line_index, between_words=False):
        if width <= 0.5:
            return
        if between_words and abs(width - space_w) <= max(2.0, space_w * 0.35):
            # word-by-word renderers leave one space between runs: keep it a real space
            add(" ", record.color, (width - space_w) * 1000.0 / size, line_index)
            return
        n = max(1, int(round(width / nbsp_w)))
        tracking = (width / n - nbsp_w) * 1000.0 / size
        add(NBSP * n, record.color, tracking, line_index)

    for li, line in enumerate(record.lines):
        runs = sorted(line.runs, key=lambda r: r.x)
        start = min([runs[0].x] + [g[0] for g in line.gaps])
        line_starts.append(start)
        pen = start
        for k, run in enumerate(runs):
            gap_is_icon = any(a <= pen + 1 and b >= run.x - 1 for a, b in line.gaps)
            add_gap(run.x - pen, li, between_words=bool(k) and not gap_is_icon)
            run_font = getattr(run, "font", None)
            add(run.text, run.rgb, _width_tracking(run_font or font, run.text, run.advance), li, run_font)
            pen = run.x + run.advance
        end = max([pen] + [g[1] for g in line.gaps])
        add_gap(end - pen, li)
        if li < len(record.lines) - 1:
            # the line break belongs to the line's last run
            add("\r", spans[-1][2] if spans else record.color, 0, li)
    return text, spans, line_starts


def _anchor_x(record, line_starts):
    left, width = record.box or (line_starts[0], 0.0)
    if record.align == "left":
        return line_starts[0]
    if record.align == "right":
        return left + width
    return left + width / 2.0


def _justification(align):
    J = psapi.enum.Justification
    return {"left": J.Left, "right": J.Right}.get(align, J.Center)


def _font_index(layer, ps_name, pil_font):
    """FontSet index of `ps_name`, adding it with the type of the real font file.

    A TrueType font listed as OpenType (PhotoshopAPI's default) makes Photoshop
    report the font as present but needing a layout change on edit.
    """
    idx = layer.find_font_index(ps_name)
    if idx >= 0:
        return idx
    FT = psapi.enum.FontType
    kind = FT.TrueType if fontnames.is_truetype(getattr(pil_font, "path", ""), getattr(pil_font, "index", 0)) else FT.OpenType
    layer.add_font(ps_name, kind)
    return layer.find_font_index(ps_name)


def _leadings(record, size):
    """Leading per line: the baseline pitch the PNG renderer used."""
    baselines = [ln.baseline for ln in record.lines]
    pitches = [baselines[i] - baselines[i - 1] for i in range(1, len(baselines))]
    first_pitch = pitches[0] if pitches else round(size * 1.2, 2)
    return [first_pitch] + pitches


def text_model(record):
    """What a text layer says, independent of the file format: the layer string,
    alignment and style runs [{length, rgb, tracking, leading, size, ps_font, pil_font}].
    text_layer() writes it via PhotoshopAPI; txt2.py writes the same model into
    Photoshop's document text block, so the two always agree."""
    font = record.font
    size = float(font.size)
    ps_font = fontnames.postscript_name_for_font(font) or "ArialMT"
    text, spans, _starts = text_spans(record)
    leading = _leadings(record, size)
    runs = []
    for start, length, rgb, tracking, line_index, run_font in spans:
        face, name = font, ps_font
        if run_font is not None:
            ps_run = fontnames.postscript_name_for_font(run_font)
            if ps_run and ps_run != ps_font:
                face, name = run_font, ps_run
        run_size = float(getattr(run_font, "size", size) or size) if run_font is not None else size
        if run_font is not None and abs(run_size - size) > 0.01:
            face = run_font                                # a word drawn bigger / smaller than its line
        hs, vs, kerned = ps_text.shape_of(face)
        runs.append({"start": start, "length": length, "rgb": tuple(rgb), "tracking": int(tracking),
                     "leading": float(leading[line_index]), "size": run_size, "ps_font": name, "pil_font": face,
                     "hscale": hs, "vscale": vs, "kerning": kerned and ps_text.KERNING})
    return {"text": text, "align": record.align, "runs": runs}


def text_layer(record, name):
    font = record.font
    ps_font = fontnames.postscript_name_for_font(font) or "ArialMT"
    size = float(font.size)
    text, spans, line_starts = text_spans(record)
    leading = _leadings(record, size)

    # the constructor lists its font as TrueType; a CFF (.otf) face is added
    # afterwards with its real type so the FontSet never misdescribes it
    cff = not fontnames.is_truetype(getattr(font, "path", ""), getattr(font, "index", 0))
    layer = psapi.TextLayer_8bit(layer_name=name, text=text, font="ArialMT" if cff else ps_font, font_size=size,
                                 fill_color=argb(record.color),
                                 position_x=float(_anchor_x(record, line_starts)),
                                 position_y=float(record.lines[0].baseline))
    layer.fill = 1.0
    layer.opacity = 1.0
    layer.convert_to_point_text()
    font_index = _font_index(layer, ps_font, font)
    layer.set_font(ps_font)
    font_index = layer.find_font_index(ps_font)

    run, run_start = 0, 0
    font_indexes = {}
    for k, (start, length, rgb, tracking, line_index, run_font) in enumerate(spans):
        if k and start > run_start:
            layer.split_style_run(run, start - run_start)
            run += 1
            run_start = start
        idx = font_index
        if run_font is not None:
            # a word-styled run (bold / italic / other family) uses its own face
            ps_run = fontnames.postscript_name_for_font(run_font)
            if ps_run and ps_run != ps_font:
                if ps_run not in font_indexes:
                    font_indexes[ps_run] = _font_index(layer, ps_run, run_font)
                idx = font_indexes[ps_run]
        layer.set_style_run_font(run, idx)
        layer.set_style_run_font_size(run, float(getattr(run_font, "size", size) or size) if run_font is not None else size)
        layer.set_style_run_fill_color(run, argb(rgb))
        layer.set_style_run_auto_leading(run, False)
        layer.set_style_run_leading(run, float(leading[line_index]))
        layer.set_style_run_tracking(run, int(tracking))
        # Photoshop's Metrics kerning, as the PNG layout kerns (ps_text): an edited layer keeps
        # every letter where it was
        hs, vs, kerned = ps_text.shape_of(run_font if run_font is not None else font)
        layer.set_style_run_auto_kerning(run, bool(ps_text.KERNING and kerned))
        layer.set_style_run_kerning(run, 0)
        if hs != 1.0 or vs != 1.0:
            # Character panel width / height scale (a heading learned from an artist's PSD)
            layer.set_style_run_horizontal_scale(run, float(hs))
            layer.set_style_run_vertical_scale(run, float(vs))
    # one paragraph run per line: Photoshop treats every CR as a paragraph end,
    # and a single run spanning several paragraphs makes its own text update
    # (the "Update" dialog, or editing a not-yet-updated layer) merge the lines
    breaks = [i + 1 for i, ch in enumerate(text) if ch == chr(13) and i + 1 < len(text)]
    para, para_start = 0, 0
    for end in breaks:
        layer.split_paragraph_run(para, end - para_start)
        para += 1
        para_start = end
    for p in range(layer.paragraph_run_count):
        layer.set_paragraph_run_justification(p, _justification(record.align))
    return layer


# ── document ────────────────────────────────────────────────────────────────
def _page_group_name(page):
    return page.sheet if page.part <= 1 else f"{page.sheet} (Continued {page.part - 1})"


def build_document(recorder, canvas_w, canvas_h, report=None):
    """Return (LayeredFile, {layer name: LayerPlan}, pages in order, shared background)."""
    pages = [p for _, sheet_pages in recorder.sheets for p in sheet_pages]
    lf = psapi.LayeredFile_8bit(psapi.enum.ColorMode.rgb, int(canvas_w), int(canvas_h))
    seen, plans, image_fx, vectors = set(), {}, {}, {}

    digests = {hashlib.sha1(p.background.tobytes()).hexdigest() for p in pages if p.background is not None}
    shared_bg = pages[0].background if (len(digests) == 1 and pages and pages[0].background is not None) else None

    def add_items(target, icons, texts, shapes, index):
        # Top of the stack first: icons, text, then fills/strokes underneath.
        for icon in icons:
            name = _unique(icon.name, seen)
            target.add_layer(lf, _image_layer(icon.image, name, icon.left, icon.top, icon.opacity))
            if icon.effects:
                image_fx[name] = effects_of({"effects_block": icon.effects})
        for record in texts:
            name = _unique(record.name, seen)
            plan = LayerPlan(name, record, effects_of(record.fx_config))
            plan.page_index = index
            if not plan.fx_payload:
                param = _param_effects_payload(record.fx_config, report, name)
                plan.fx_payload = (b"lfx2", param) if param else None
            target.add_layer(lf, text_layer(record, name))
            plans[name] = plan
        # shapes are recorded in drawing order (the first drawn lies lowest, as in the PNG); the stack is
        # built top first, so the last drawn goes in first — a selected word's strip stays above the
        # strip of its row / text box, a tab above its card
        for shape in reversed(list(shapes)):
            name = _unique(shape.name, seen)
            layer = _image_layer(shape.image, name, shape.left, shape.top, shape.opacity)
            layer.fill = float(getattr(shape, "fill", 1.0))
            target.add_layer(lf, layer)
            if shape.effects:
                image_fx[name] = effects_of({"effects_block": shape.effects})
            elif getattr(shape, "fx_config", None):
                fx = effects_of(shape.fx_config)
                if not fx:                                    # plain settings (a card look's drop shadow)
                    payload = _param_effects_payload(shape.fx_config, None, name)
                    fx = (b"lfx2", payload) if payload else None
                if fx:
                    image_fx[name] = fx
            if getattr(shape, "vector", None):
                vectors[name] = shape.vector

    for index, page in enumerate(pages):
        # every group starts closed in the Layers panel (artists open what they work on)
        group = psapi.GroupLayer_8bit(layer_name=_unique(_page_group_name(page), seen), is_visible=(index == 0),
                                      is_collapsed=True)
        group.fill = 1.0
        group.opacity = 1.0
        lf.add_layer(group)
        # Paytable cards etc.: everything tagged with the same group goes in one sub-group.
        order = []
        for item in list(page.icons) + list(page.texts) + list(page.shapes):
            if item.group and item.group not in order:
                order.append(item.group)
        # a group of nothing but boxes (the panels behind text boxes) is a background: it goes under
        # the loose text and symbols, never over them (it hid the paytable's rules text)
        content = {i.group for i in list(page.icons) + list(page.texts) if i.group}

        def add_sub(sub_name):
            sub = psapi.GroupLayer_8bit(layer_name=_unique(sub_name, seen), is_collapsed=True)
            sub.fill = 1.0
            sub.opacity = 1.0
            group.add_layer(lf, sub)
            add_items(sub, [i for i in page.icons if i.group == sub_name],
                      [t for t in page.texts if t.group == sub_name],
                      [s for s in page.shapes if s.group == sub_name], index)

        for sub_name in [n for n in order if n in content]:
            add_sub(sub_name)
        add_items(group, [i for i in page.icons if not i.group], [t for t in page.texts if not t.group], [], index)
        for sub_name in [n for n in order if n not in content]:
            add_sub(sub_name)
        add_items(group, [], [], [s for s in page.shapes if not s.group], index)
        bbox = page.image.getbbox() if page.image is not None else None
        if bbox:
            graphics = page.image.crop(bbox)
            group.add_layer(lf, _image_layer(graphics, _unique("Graphics", seen), bbox[0], bbox[1]))
        if page.background is not None and shared_bg is None:
            group.add_layer(lf, _image_layer(page.background, _unique("Background", seen), 0, 0))
    if shared_bg is not None:
        lf.add_layer(_image_layer(shared_bg, _unique("Background", seen), 0, 0))
    plans["__image_fx__"] = image_fx       # pixel-layer name -> (key, payload)
    plans["__vectors__"] = vectors         # layer name -> live shape spec (finalize.make_live)
    return lf, plans, pages, shared_bg


def _param_effects_payload(fx_config, report, name):
    """Stroke/shadow settings without a captured style -> generated effects block."""
    if not fx_config:
        return None
    from . import effects
    try:
        return effects.params_payload(fx_config)
    except Exception as exc:  # never fail a build over a style
        if report is not None:
            report.append(f"Layer style on '{name[:40]}' could not be converted: {exc}")
        return None
