"""Headless PSD writer: records png_builder's layout as editable PSD layers.

The PNG builder already lays out every page type without Photoshop. While a
LayerRecorder is active, its draw primitives emit layer records instead of
painting text and inline icons onto the page; ``build.build_psd`` turns those
records into a PSD with PhotoshopAPI (editable text with colour runs, icon
layers, a graphics layer per page, background) and psd-tools (preview pixels
so text shows when Photoshop opens the file, copied layer-effect blocks).
"""
