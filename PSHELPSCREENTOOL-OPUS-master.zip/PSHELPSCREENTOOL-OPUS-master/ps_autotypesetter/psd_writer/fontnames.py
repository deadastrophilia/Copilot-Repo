"""PostScript name of a font file — what Photoshop text layers reference.

Reads the sfnt 'name' table (nameID 6) directly, so it works for exactly the
file Pillow loaded (including a face inside a .ttc collection) without
fontTools.
"""
import functools
import struct


def _read_name_table(data, offset):
    num_tables = struct.unpack_from(">H", data, offset + 4)[0]
    for i in range(num_tables):
        tag, _, table_off, _ = struct.unpack_from(">4sIII", data, offset + 12 + i * 16)
        if tag == b"name":
            return table_off
    return None


@functools.lru_cache(maxsize=256)
def postscript_name(path, index=0):
    """PostScript name of face `index` in `path`, or "" when it can't be read."""
    try:
        with open(path, "rb") as f:
            data = f.read()
        offset = 0
        if data[:4] == b"ttcf":
            count = struct.unpack_from(">I", data, 8)[0]
            index = max(0, min(int(index or 0), count - 1))
            offset = struct.unpack_from(">I", data, 12 + index * 4)[0]
        name_off = _read_name_table(data, offset)
        if name_off is None:
            return ""
        _, count, strings = struct.unpack_from(">HHH", data, name_off)
        fallback = ""
        for i in range(count):
            pid, eid, _, nid, length, off = struct.unpack_from(">HHHHHH", data, name_off + 6 + i * 12)
            if nid != 6:
                continue
            raw = data[name_off + strings + off: name_off + strings + off + length]
            if pid == 3 or pid == 0:
                return raw.decode("utf-16-be", "ignore").strip("\x00 ")
            if pid == 1 and not fallback:
                fallback = raw.decode("latin-1", "ignore").strip("\x00 ")
        return fallback
    except Exception:
        return ""


def postscript_name_for_font(font):
    """PostScript name for a PIL FreeTypeFont (uses its file and face index)."""
    path = getattr(font, "path", None)
    if not path:
        return ""
    return postscript_name(str(path), int(getattr(font, "index", 0) or 0))


@functools.lru_cache(maxsize=256)
def is_truetype(path, index=0):
    """True for TrueType outlines (glyf), False for CFF/PostScript ('OTTO')."""
    try:
        with open(path, "rb") as f:
            head = f.read(16)
            if head[:4] == b"ttcf":
                count = struct.unpack_from(">I", head, 8)[0]
                index = max(0, min(int(index or 0), count - 1))
                f.seek(12 + index * 4)
                f.seek(struct.unpack(">I", f.read(4))[0])
                head = f.read(4)
        return head[:4] != b"OTTO"
    except Exception:
        return True


@functools.lru_cache(maxsize=256)
def version_name(path, index=0):
    """The font's version string (name ID 5, e.g. "Version 7.06"), or ""."""
    try:
        with open(path, "rb") as f:
            data = f.read()
        offset = 0
        if data[:4] == b"ttcf":
            count = struct.unpack_from(">I", data, 8)[0]
            index = max(0, min(int(index or 0), count - 1))
            offset = struct.unpack_from(">I", data, 12 + index * 4)[0]
        name_off = _read_name_table(data, offset)
        if name_off is None:
            return ""
        _, count, strings = struct.unpack_from(">HHH", data, name_off)
        fallback = ""
        for i in range(count):
            pid, eid, _, nid, length, off = struct.unpack_from(">HHHHHH", data, name_off + 6 + i * 12)
            if nid != 5:
                continue
            raw = data[name_off + strings + off: name_off + strings + off + length]
            if pid in (0, 3):
                return raw.decode("utf-16-be", "ignore").strip("\x00 ")
            if pid == 1 and not fallback:
                fallback = raw.decode("latin-1", "ignore").strip("\x00 ")
        return fallback
    except Exception:
        return ""


@functools.lru_cache(maxsize=256)
def cmap_ranges(path, index=0):
    """The character ranges face `index` of `path` has glyphs for ((lo, hi), …), () when unreadable."""
    try:
        with open(path, "rb") as f:
            data = f.read()
        offset = 0
        if data[:4] == b"ttcf":
            count = struct.unpack_from(">I", data, 8)[0]
            offset = struct.unpack_from(">I", data, 12 + max(0, min(int(index or 0), count - 1)) * 4)[0]
        tables = struct.unpack_from(">H", data, offset + 4)[0]
        cmap = None
        for i in range(tables):
            tag, _, off, _ = struct.unpack_from(">4sIII", data, offset + 12 + i * 16)
            if tag == b"cmap":
                cmap = off
        if cmap is None:
            return ()
        out = []
        for i in range(struct.unpack_from(">H", data, cmap + 2)[0]):
            pid, eid, sub = struct.unpack_from(">HHI", data, cmap + 4 + i * 8)
            if (pid, eid) not in ((3, 1), (3, 10), (0, 3), (0, 4), (0, 6)):
                continue
            s = cmap + sub
            fmt = struct.unpack_from(">H", data, s)[0]
            if fmt == 4:
                segs = struct.unpack_from(">H", data, s + 6)[0] // 2
                ends = struct.unpack_from(">%dH" % segs, data, s + 14)
                starts = struct.unpack_from(">%dH" % segs, data, s + 16 + segs * 2)
                out += [(a, b) for a, b in zip(starts, ends) if a != 0xFFFF]
            elif fmt == 12:
                for g in range(struct.unpack_from(">I", data, s + 12)[0]):
                    a, b, _ = struct.unpack_from(">III", data, s + 16 + g * 12)
                    out.append((a, b))
        return tuple(sorted(set(out)))
    except Exception:
        return ()


def has_glyph(font, ch):
    """Whether a PIL FreeTypeFont draws `ch` (True when its file can't be read: nothing is changed)."""
    path = getattr(font, "path", None)
    if not path or not ch:
        return True
    ranges = cmap_ranges(str(path), int(getattr(font, "index", 0) or 0))
    cp = ord(ch[0])
    return not ranges or any(a <= cp <= b for a, b in ranges)
