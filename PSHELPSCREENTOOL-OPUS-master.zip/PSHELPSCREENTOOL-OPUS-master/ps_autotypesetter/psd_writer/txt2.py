"""Photoshop's document text block (Txt2), written without Photoshop.

Photoshop CC keeps every text layer's model in one document-level block,
"Txt2" (fonts with versions, style/paragraph sheets, and per text object its
string, paragraph runs and style runs). A PSD without it is read as legacy
text: every type layer gets the "Font is present on system but requires a
layout change" triangle and Photoshop asks to update the layers on open.

Verified against Photoshop 2026 (2026-10-18):
  * each layer's TySh ``TextIndex`` must point at its entry here (0, 1, 2…);
    PhotoshopAPI writes 1 for every layer, so finalize renumbers them;
  * the per-object glyph layout (the view's key 2) and the font-usage table
    (key 1/5) may be left out: Photoshop lays the text out again itself;
  * font entries carry the font file's version name (name ID 5).

Everything we don't set comes from txt2_template.bin, a block Photoshop
wrote for a two-line Arial layer (layout removed), so defaults match what
Photoshop itself writes. The syntax is EngineData-like with numeric keys.
"""
import copy
import os
import re
import struct

from .. import ps_text
from . import fontnames

_TEMPLATE_PATH = os.path.join(os.path.dirname(__file__), "txt2_template.bin")

# style-run sheet keys (numeric form of EngineData's StyleSheetData)
_FONT, _SIZE, _FAUX_BOLD, _FAUX_ITALIC, _AUTO_LEADING, _LEADING, _HSCALE, _VSCALE, _TRACKING, _AUTO_KERN, _FILL = (
    0, 1, 2, 3, 4, 5, 6, 7, 8, 11, 53)
_JUSTIFY = 0                       # paragraph sheet: 0 left, 1 right, 2 centre


class Name(str):
    """A /name value (as opposed to a string)."""


# ── reading (the template) ───────────────────────────────────────────────────
_WS = b" \t\r\n"
_ATOM = re.compile(rb"[^\s<>\[\]()/]+")
_NAME = re.compile(rb"/([^\s<>\[\]()/]*)")


def parse(data):
    """Parse a Txt2 body into dicts/lists (keys are ints or Names)."""
    pos, n = 0, len(data)

    def skip():
        nonlocal pos
        while pos < n and data[pos] in _WS:
            pos += 1

    def value():
        nonlocal pos
        skip()
        if data.startswith(b"<<", pos):
            pos += 2
            out = {}
            while True:
                skip()
                if data.startswith(b">>", pos):
                    pos += 2
                    return out
                key = value()
                out[key] = value()
        c = data[pos:pos + 1]
        if c == b"[":
            pos += 1
            out = []
            while True:
                skip()
                if data[pos:pos + 1] == b"]":
                    pos += 1
                    return out
                out.append(value())
        if c == b"(":
            pos += 1
            buf = bytearray()
            while True:
                ch = data[pos]
                if ch == 0x5C:
                    buf.append(data[pos + 1])
                    pos += 2
                    continue
                pos += 1
                if ch == 0x29:
                    break
                buf.append(ch)
            raw = bytes(buf)
            return raw[2:].decode("utf-16-be") if raw.startswith(b"\xfe\xff") else raw
        if c == b"/":
            m = _NAME.match(data, pos)
            pos = m.end()
            t = m.group(1).decode("latin-1")
            return int(t) if t.isdigit() else Name(t)
        m = _ATOM.match(data, pos)
        pos = m.end()
        t = m.group(0).decode("latin-1")
        if t in ("true", "false"):
            return t == "true"
        if t == "nil":
            return None
        return int(t) if re.fullmatch(r"-?\d+", t) else float(t)

    top = {}
    while True:
        skip()
        if pos >= n or data[pos] == 0:
            return top
        key = value()
        top[key] = value()


# ── writing ──────────────────────────────────────────────────────────────────
def _num(v):
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, int):
        return str(v)
    s = ("%.5f" % v).rstrip("0").rstrip(".")
    if "." not in s:
        s += ".0"
    if s.startswith("0."):
        s = s[1:]
    elif s.startswith("-0."):
        s = "-" + s[2:]
    return s


def _string(v):
    raw = v if isinstance(v, bytes) else b"\xfe\xff" + v.encode("utf-16-be")
    out = bytearray(b"(")
    for ch in raw:
        if ch in (0x28, 0x29, 0x5C):
            out.append(0x5C)
        out.append(ch)
    out.append(0x29)
    return bytes(out)


def _value(v):
    if isinstance(v, dict):
        # the class tag (/99 /SimplePaint, /CoolTypeFont…) must lead its dictionary:
        # Photoshop's reader crashes on a dictionary whose /99 comes later
        items = sorted(v.items(), key=lambda kv: kv[0] != 99)
        return b"<<" + b"".join(b" " + _key(k) + b" " + _value(x) for k, x in items) + b" >>"
    if isinstance(v, list):
        return b"[" + b"".join(b" " + _value(x) for x in v) + b" ]"
    if v is None:
        return b"/nil"
    if isinstance(v, Name):
        return b"/" + str(v).encode("latin-1")
    if isinstance(v, (str, bytes)):
        return _string(v)
    return _num(v).encode("ascii")


def _key(k):
    return b"/" + str(k).encode("latin-1")


def dump(top):
    return b"".join(b" " + _key(k) + b" " + _value(v) for k, v in top.items())


# ── building ─────────────────────────────────────────────────────────────────
_TEMPLATE = None


def _template():
    global _TEMPLATE
    if _TEMPLATE is None:
        with open(_TEMPLATE_PATH, "rb") as f:
            _TEMPLATE = parse(f.read())
    return copy.deepcopy(_TEMPLATE)


def _font_version(pil_font):
    path = getattr(pil_font, "path", None)
    if not path:
        return ""
    return fontnames.version_name(str(path), int(getattr(pil_font, "index", 0) or 0))


class _Fonts:
    """The document font list (template entries first, so their indices stay valid)."""

    def __init__(self, entries):
        self.entries = entries
        self.index = {e[0][0][0]: i for i, e in enumerate(entries)}

    def get(self, ps_name, pil_font):
        if ps_name in self.index:
            entry = self.entries[self.index[ps_name]][0][0]
            version = _font_version(pil_font)
            if version:                      # this machine's version, not the template's
                entry[5] = version
            return self.index[ps_name]
        info = {0: ps_name, 2: 1 if fontnames.is_truetype(getattr(pil_font, "path", ""),
                                                        getattr(pil_font, "index", 0)) else 0}
        version = _font_version(pil_font)
        if version:
            info[5] = version
        self.entries.append({0: {99: Name("CoolTypeFont"), 0: info}})
        self.index[ps_name] = len(self.entries) - 1
        return self.index[ps_name]


def _argb(rgb):
    return [1.0, rgb[0] / 255.0, rgb[1] / 255.0, rgb[2] / 255.0]


def _entry(model, fonts, proto):
    """One text object for `model` (document.text_model), from the template object."""
    obj = copy.deepcopy(proto)
    text = model["text"] + "\r"                            # Photoshop ends every story with a CR
    paragraphs = [len(p) + 1 for p in model["text"].split("\r")]
    justify = {"left": 0, "right": 1}.get(model["align"], 2)

    story = obj[0]
    story[0] = text
    para_proto = story[5][0][0]
    story[5][0] = []
    for length in paragraphs:
        item = copy.deepcopy(para_proto)
        item[0][0][5][_JUSTIFY] = justify
        item[1] = length
        story[5][0].append(item)

    style_proto = story[6][0][0]
    story[6][0] = []
    runs = model["runs"] or [{"length": len(model["text"]), "rgb": (255, 255, 255), "tracking": 0,
                              "leading": 36.0, "size": 30.0, "ps_font": "ArialMT", "pil_font": None}]
    for k, run in enumerate(runs):
        item = copy.deepcopy(style_proto)
        sheet = item[0][0][6]
        sheet[_FONT] = fonts.get(run["ps_font"], run["pil_font"])
        sheet[_SIZE] = float(run["size"])
        sheet[_FAUX_BOLD] = False
        sheet[_FAUX_ITALIC] = False
        sheet[_AUTO_LEADING] = False
        sheet[_LEADING] = float(run["leading"])
        sheet[_TRACKING] = int(run["tracking"])
        sheet[_AUTO_KERN] = 1 if run.get("kerning", ps_text.KERNING) else 0    # Metrics, as the PNG layout kerns
        if run.get("hscale", 1.0) != 1.0 or run.get("vscale", 1.0) != 1.0:
            sheet[_HSCALE] = float(run["hscale"])                 # Character panel width / height scale
            sheet[_VSCALE] = float(run["vscale"])
        sheet[_FILL] = {99: Name("SimplePaint"), 0: {0: 1, 1: _argb(run["rgb"])}}
        item[1] = int(run["length"]) + (1 if k == len(runs) - 1 else 0)   # last run owns the final CR
        story[6][0].append(item)

    view = obj[1]
    view.pop(2, None)                                      # glyph layout: Photoshop rebuilds it
    line_proto = view[1][0][0]
    view[1][0] = []
    for length in paragraphs:
        item = copy.deepcopy(line_proto)
        item[1] = length
        view[1][0].append(item)
    return obj


def build(models):
    """Txt2 body for text objects in TextIndex order (list of document.text_model)."""
    top = _template()
    fonts = _Fonts(top[0][1][0])
    proto = top[1][1][0]
    top[1][1] = [_entry(m, fonts, proto) for m in models]
    top[1].pop(5, None)
    body = dump(top)
    return body + b" " if len(body) % 2 else body          # blocks are even-sized


def tagged_block(models):
    """Raw bytes of the '8BIMTxt2' tagged block (length-prefixed, even-padded)."""
    body = build(models)
    return b"8BIMTxt2" + struct.pack(">I", len(body)) + body


def has_block(psd_path):
    """True when the PSD carries a document text block (written by us or Photoshop)."""
    import mmap

    try:
        with open(psd_path, "rb") as f, mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as m:
            return m.find(b"8BIMTxt2") >= 0
    except (OSError, ValueError):
        return False
