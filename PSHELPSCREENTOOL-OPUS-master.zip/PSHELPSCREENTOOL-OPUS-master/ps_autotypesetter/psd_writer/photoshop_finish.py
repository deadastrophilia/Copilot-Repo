"""Optional last step: let Photoshop adopt the text layers of a built PSD.

A PSD written without Photoshop has no document text-engine block (Txt2, where
Photoshop records the layout and the version of every font). Photoshop then
treats each text layer as legacy text: the Layers panel shows a warning
triangle ("Font is present on system but requires a layout change") until the
layer is edited. Re-applying each layer's own text descriptor with the legacy
flag cleared, then saving, makes Photoshop write Txt2 itself. The layers' text,
style runs and effects are unchanged, and because psd_writer matches
Photoshop's metrics (no auto kerning, width tracking) nothing moves.

Uses whichever Photoshop is available (photoshop_bridge). Measured ~0.1s per
text layer; only layers Photoshop flags are touched.
"""
import json
import os

# Shared by the build step and the standalone script: adopt every flagged text
# layer of `doc`; returns [fixed, total, failed].
_ADOPT = r"""
function __pshAdoptText(doc) {
  var S = function (s) { return stringIDToTypeID(s); }, C = function (c) { return charIDToTypeID(c); };
  var fixed = 0, total = 0, failed = 0;
  function current() {
    var r = new ActionReference(); r.putEnumerated(C("Lyr "), C("Ordn"), C("Trgt"));
    return executeActionGet(r);
  }
  function adopt(layer) {
    doc.activeLayer = layer;
    var d = current();
    if (d.hasKey(S("textWarningLevel")) && d.getInteger(S("textWarningLevel")) == 0) return false;
    var tk = d.getObjectValue(S("textKey"));
    tk.putBoolean(S("oldText"), false);                 // a plain re-apply would copy the legacy flag back
    if (tk.hasKey(S("oldTextAge"))) tk.erase(S("oldTextAge"));
    var s = new ActionDescriptor(), r = new ActionReference();
    r.putEnumerated(C("TxLr"), C("Ordn"), C("Trgt"));
    s.putReference(C("null"), r);
    s.putObject(C("T   "), C("TxLr"), tk);
    executeAction(C("setd"), s, DialogModes.NO);
    return true;
  }
  // re-applying a hidden text layer's text switches it (and its groups) on: every layer's and group's
  // visibility is noted first and put back after, so hidden pages / layers stay hidden
  var shown = [];
  function note(c) {
    for (var i = 0; i < c.layers.length; i++) {
      var l = c.layers[i];
      shown.push([l, l.visible]);
      if (l.typename == "LayerSet") note(l);
    }
  }
  function walk(c) {
    for (var i = 0; i < c.layers.length; i++) {
      var l = c.layers[i];
      if (l.typename == "LayerSet") { walk(l); continue; }
      if (l.kind != LayerKind.TEXT) continue;
      total++;
      try { if (adopt(l)) fixed++; } catch (e) { failed++; }
    }
  }
  var keep = doc.activeLayer;
  try { note(doc); } catch (e) {}
  walk(doc);
  try { doc.activeLayer = keep; } catch (e) {}
  for (var k = shown.length - 1; k >= 0; k--) {     // innermost first: a group shown again shows nothing hidden
    try { if (shown[k][0].visible != shown[k][1]) shown[k][0].visible = shown[k][1]; } catch (e) {}
  }
  // selecting each text layer opened the groups it sits in: close them all again (the Layers panel's
  // own "Collapse All Groups"), so the PSD is saved with its groups collapsed as the artist keeps them
  try { executeAction(S("collapseAllGroupsEvent"), new ActionDescriptor(), DialogModes.NO); } catch (e) {}
  return [fixed, total, failed];
}
"""

_JSX = _ADOPT + r"""
(function () {
  var target = new File(__PATH__);
  for (var i = 0; i < app.documents.length; i++) {
    try { if (app.documents[i].fullName.fsName.toLowerCase() == target.fsName.toLowerCase()) return "OPEN"; } catch (e) {}
  }
  var prevDialogs = app.displayDialogs;
  app.displayDialogs = DialogModes.NO;
  var doc = app.open(target), n;
  try {
    n = __pshAdoptText(doc);
    if (n[0]) doc.saveAs(target, new PhotoshopSaveOptions(), false);
  } finally {
    doc.close(SaveOptions.DONOTSAVECHANGES);
    app.displayDialogs = prevDialogs;
  }
  return "OK " + n[0] + " " + n[1] + " " + n[2];
})();
"""

# Standalone copy written next to a PSD built without Photoshop: anyone with
# Photoshop (any version, no PsHelpScreenTool) runs it via File > Scripts > Browse…
_STANDALONE = r"""// Fix text layers — PsHelpScreenTool
//
// This PSD was made without Photoshop, so Photoshop shows a warning triangle on its
// text layers ("Font is present on system but requires a layout change") and may ask
// to update them when the file opens. This script updates every text layer exactly
// as it was laid out (nothing moves, styles stay) and saves the PSD.
//
// How to run: in Photoshop choose File > Scripts > Browse... and pick this file.
// With the PSD already open it fixes that document; otherwise it opens the PSD next
// to this script (or asks you to choose one).
#target photoshop
""" + _ADOPT + r"""
(function () {
  var prevDialogs = app.displayDialogs;
  app.displayDialogs = DialogModes.NO;     // answers "No" to the update prompt; this script does the update
  try {
    var doc = null, opened = false;
    var wanted = new File(File($.fileName).parent + "/" + __NAME__);
    for (var i = 0; i < app.documents.length; i++) {
      try { if (app.documents[i].fullName.fsName.toLowerCase() == wanted.fsName.toLowerCase()) doc = app.documents[i]; } catch (e) {}
    }
    if (!doc && app.documents.length) doc = app.activeDocument;
    if (!doc) {
      var f = wanted.exists ? wanted : File.openDialog("Choose the PSD to fix", "Photoshop:*.psd;*.psb");
      if (!f) return;
      doc = app.open(f);
      opened = true;
    }
    app.activeDocument = doc;
    var n = __pshAdoptText(doc);
    var saved = false;
    if (n[0]) {
      try { doc.save(); saved = true; } catch (e) {
        try { doc.saveAs(doc.fullName, new PhotoshopSaveOptions(), false); saved = true; } catch (e2) {}
      }
    }
    app.displayDialogs = prevDialogs;
    alert(n[0] ? ("Updated " + n[0] + " of " + n[1] + " text layer(s)" + (saved ? " and saved the PSD." : ". Save the document to keep it."))
               + (n[2] ? "\n" + n[2] + " layer(s) could not be updated." : "")
             : "All " + n[1] + " text layer(s) are already up to date.", "Fix text layers");
  } finally {
    app.displayDialogs = prevDialogs;
  }
})();
"""


def mode_of(config):
    """"always" (default: start Photoshop when it is installed but closed), "auto"
    (only a Photoshop that is already running) or "off"."""
    value = str((config or {}).get("photoshop_finish_text", "always") or "always").strip().casefold()
    return value if value in ("auto", "always", "off") else "always"


def available(mode):
    from .. import photoshop_bridge

    if mode == "off" or os.environ.get("PYTEST_CURRENT_TEST"):     # tests never drive Photoshop
        return False
    info = photoshop_bridge.describe()
    if mode == "always":
        return info["route"] != "none"
    return bool(info["running"])


def finish(psd_path, note=None, timeout=900):
    """Run the adoption pass on `psd_path`; returns a one-line result message."""
    from .. import photoshop_bridge

    jsx = _JSX.replace("__PATH__", json.dumps(os.path.abspath(psd_path).replace("\\", "/")))
    if callable(note):
        running = bool(photoshop_bridge.running_photoshops())
        note("[PSD] " + ("" if running else "Starting Photoshop — ") +
             "Photoshop is finishing the text layers (removes the 'requires a layout change' warning)…")
    try:
        res = str(photoshop_bridge.run_jsx(jsx, timeout=timeout) or "").strip()
    except Exception as exc:
        return f"[PSD] Photoshop finish skipped: {exc}"
    if res == "OPEN":
        return ("[PSD] Photoshop finish skipped: this PSD is open in Photoshop. Close it and build again "
                "to clear the text-layer warnings.")
    parts = res.split()
    if len(parts) == 4 and parts[0] == "OK":
        fixed, total, failed = (int(p) for p in parts[1:])
        msg = f"[PSD] Photoshop finished {fixed} of {total} text layer(s)"
        return msg + (f"; {failed} could not be updated." if failed else ".")
    return f"[PSD] Photoshop finish: unexpected result {res!r}"


def script_path(psd_path):
    stem = os.path.splitext(os.path.basename(psd_path))[0]
    return os.path.join(os.path.dirname(os.path.abspath(psd_path)), f"{stem} - Fix text layers.jsx")


def write_fix_script(psd_path):
    """Write the standalone "Fix text layers" script next to `psd_path`; returns its path."""
    path = script_path(psd_path)
    body = _STANDALONE.replace("__NAME__", json.dumps(os.path.basename(psd_path)))
    with open(path, "w", encoding="utf-8-sig", newline=chr(13) + chr(10)) as f:
        f.write(body)
    return path


def remove_fix_script(psd_path):
    """Drop a stale script once the PSD's text layers are already finished."""
    try:
        os.remove(script_path(psd_path))
    except OSError:
        pass
