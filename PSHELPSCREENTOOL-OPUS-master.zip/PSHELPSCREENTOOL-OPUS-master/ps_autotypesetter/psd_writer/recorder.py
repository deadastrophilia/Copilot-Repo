"""Layer recorder: captures png_builder draw calls as PSD layer records.

Pages are PIL images; every page gets ``_draw_background`` right after it is
created, which is where the recorder registers it. Text and inline icons drawn
onto a registered page are recorded (not painted); everything else the PNG
pipeline paints (rects, table art, symbols, heading images) stays on the page,
which starts transparent in record mode and becomes the page's graphics layer.

Nothing here is active unless ``LayerRecorder.recording()`` is entered, so the
PNG output is untouched by default.
"""
import contextlib
import contextvars

_ACTIVE = contextvars.ContextVar("psd_layer_recorder", default=None)
_SOURCE = contextvars.ContextVar("psd_layer_source", default=None)


@contextlib.contextmanager
def source(**info):
    """Where the text drawn inside the block comes from (Excel row, kind...);
    text records remember it -> layer-to-cell links in the PSD's memory."""
    cur = dict(_SOURCE.get() or {})
    cur.update({k: v for k, v in info.items() if v is not None})
    token = _SOURCE.set(cur)
    try:
        yield
    finally:
        _SOURCE.reset(token)


def current_source():
    return dict(_SOURCE.get() or {})


def active_recorder():
    return _ACTIVE.get()


def page_for(image):
    """PageRecord for a registered page image, or None (not recording / not a page)."""
    rec = _ACTIVE.get()
    if rec is None or image is None:
        return None
    return rec.page_for(image)


class TextRun:
    """A run of glyphs drawn at pen position ``x`` on its line's baseline."""

    __slots__ = ("text", "rgb", "x", "advance", "font")

    def __init__(self, text, rgb, x, advance, font=None):
        self.text = str(text)
        self.rgb = tuple(int(c) for c in tuple(rgb)[:3])
        self.x = float(x)
        self.advance = float(advance)
        self.font = font            # a word-styled run's own face (bold / italic / family), else None


class TextLine:
    __slots__ = ("baseline", "runs", "gaps")

    def __init__(self, baseline=None):
        # set by the line's first text segment (icons alone don't define it)
        self.baseline = None if baseline is None else float(baseline)
        self.runs = []    # TextRun, in drawing order
        self.gaps = []    # (left, right) spans covered by inline icons


class TextRecord:
    """One editable text layer: a paragraph (one or more lines) from a draw call."""

    def __init__(self, font, color, align, fx_config=None):
        self.font = font                    # PIL FreeTypeFont used by the PNG renderer
        self.color = tuple(int(c) for c in tuple(color)[:3])
        self.align = str(align or "center").strip().lower()
        self.fx_config = dict(fx_config or {}) if isinstance(fx_config, dict) else {}
        if self.fx_config:
            from .. import fx_scale

            # the layer's effects at this text size (the descriptor bytes too), as the PNG draws them
            self.fx_config = fx_scale.scaled(self.fx_config, getattr(font, "size", None))
        self.lines = []
        self.box = None                     # (left, width) of the alignment box
        self.name = ""
        self.group = None                   # sub-group inside the page (e.g. a paytable card)
        self.source = current_source()      # Excel row / kind it came from (psd_memory)

    @property
    def text(self):
        return "\n".join("".join(r.text for r in ln.runs) for ln in self.lines)

    def shift(self, dx, dy):
        for ln in self.lines:
            ln.baseline += dy
            for r in ln.runs:
                r.x += dx
            ln.gaps = [(a + dx, b + dx) for a, b in ln.gaps]
        if self.box:
            self.box = (self.box[0] + dx, self.box[1])


class ImageRecord:
    def __init__(self, image, left, top, name, group=None, opacity=1.0, effects=None):
        self.image = image
        self.left = int(round(left))
        self.top = int(round(top))
        self.name = str(name or "image")
        self.group = group
        self.opacity = float(opacity)
        self.effects = effects              # {"key": "lfx2"|"lmfx", "hex": payload} from an artist layer
        self.vector = None                  # shapes.py spec: written as a live Photoshop shape
        self.fx_config = None               # a layer style without captured bytes (generated lfx2)
        self.fill = 1.0                     # the layer's Fill opacity (fades the pixels, not the style)
        self.preview = None                 # (image, left, top): how it looks with its layer style

    def shift(self, dx, dy):
        self.left += int(round(dx))
        self.top += int(round(dy))
        if self.vector:
            self.vector = dict(self.vector, left=self.vector["left"] + dx, top=self.vector["top"] + dy)
        if self.preview:
            im, l, t = self.preview
            self.preview = (im, l + int(round(dx)), t + int(round(dy)))


class PageRecord:
    def __init__(self, image, background):
        self.image = image                  # the live page (graphics accumulate here)
        self.background = background        # flattened background as drawn by the PNG path
        self.texts = []
        self.icons = []                     # pixel layers drawn ABOVE text (inline icons, symbols)
        self.shapes = []                    # pixel layers drawn BELOW text (slot fills/strokes)
        self.sheet = ""
        self.part = 1


class _ShiftingList:
    """Appends shifted records to a parent page list (buffer -> page offset)."""

    def __init__(self, target, dx, dy):
        self._target, self._dx, self._dy = target, dx, dy

    def append(self, record):
        record.shift(self._dx, self._dy)
        self._target.append(record)


class BufferPage:
    """A scratch image that is composited onto a page at (dx, dy) later.

    Renderers draw clipped regions (paytable flow text, mapped table cells)
    into such buffers; records made there land on the parent page, shifted.
    """

    def __init__(self, parent, dx, dy):
        self.texts = _ShiftingList(parent.texts, dx, dy)
        self.icons = _ShiftingList(parent.icons, dx, dy)
        self.shapes = _ShiftingList(parent.shapes, dx, dy)


class LayerRecorder:
    def __init__(self):
        self._pages = {}
        self._buffers = {}
        self.sheets = []                    # [(sheet_name, [PageRecord, ...])] in build order
        self.notes = []
        self.block = None                   # TextRecord collecting lines for the current slot
        self.slot = None                    # (label, group) of the paytable slot being drawn

    # -- registration --------------------------------------------------------
    def register_page(self, image, background):
        page = PageRecord(image, background)
        self._pages[id(image)] = page
        return page

    def register_buffer(self, buffer, parent_image, dx, dy):
        """Records drawn into `buffer` belong to `parent_image`'s page at +(dx, dy)."""
        parent = self.page_for(parent_image)
        if parent is None:
            return None
        view = BufferPage(parent, dx, dy)
        self._buffers[id(buffer)] = (buffer, view)
        return view

    def page_for(self, image):
        page = self._pages.get(id(image))
        if page is not None and page.image is image:
            return page
        entry = self._buffers.get(id(image))
        if entry is not None and entry[0] is image:
            return entry[1]
        return None

    @contextlib.contextmanager
    def text_block(self, image, name, font, color, align, box, group=None, fx_config=None):
        """Collect every line drawn onto `image` inside the block into ONE text layer."""
        page = self.page_for(image)
        if page is None:
            yield None
            return
        record = TextRecord(font, color, align, fx_config)
        record.box = box
        record.name = str(name or "Text")
        record.group = group
        previous, self.block = self.block, (image, record)
        try:
            yield record
        finally:
            self.block = previous
            if record.lines:
                page.texts.append(record)

    def current_block(self, image):
        if self.block is not None and self.block[0] is image:
            return self.block[1]
        return None

    def commit_sheet(self, sheet_name, images):
        pages = []
        for part, image in enumerate(images, start=1):
            page = self.page_for(image)
            if page is None:
                # A page that never went through _draw_background: keep its pixels.
                page = PageRecord(image, None)
            page.sheet = str(sheet_name)
            page.part = part
            pages.append(page)
        self.sheets.append((str(sheet_name), pages))

    def note(self, message):
        self.notes.append(str(message))

    @contextlib.contextmanager
    def recording(self):
        token = _ACTIVE.set(self)
        try:
            yield self
        finally:
            _ACTIVE.reset(token)
