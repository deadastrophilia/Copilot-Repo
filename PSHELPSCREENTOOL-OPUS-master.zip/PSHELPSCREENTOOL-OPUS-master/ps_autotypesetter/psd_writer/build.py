"""build_psd — the headless PSD build (no Photoshop).

Runs the PNG builder's layout for the selected sheets with a LayerRecorder
active, then writes the recorded pages as a layered PSD. Takes the same
keyword arguments as build_engine.execute_build so run_build can call either.
"""
import os
import shutil
import tempfile
import time

from .. import config as _config
from .. import png_builder
from . import document, finalize, recorder


def _emit(progress_callback, event, **payload):
    if callable(progress_callback):
        try:
            progress_callback(dict(event=event, **payload))
        except Exception:
            pass


def _note(progress_callback, message):
    _emit(progress_callback, "note", message=message)


def _save_path(excel_path, output_dir, output_name, output_format, overwrite_existing, prev_psd_path):
    """Same naming rule as the Photoshop engine; never overwrites the old PSD.

    A full rebuild would wipe an artist's edits on pages that didn't change,
    so an in-place update request writes a separate file until page splicing
    (rebuild only changed page groups) is available.
    """
    from ..build_engine import _psd_reuse_previous, _safe_output_basename

    folder = os.path.abspath(output_dir) if output_dir else os.path.dirname(os.path.abspath(excel_path))
    ext = ".psb" if str(output_format or "PSD").strip().upper() == "PSB" else ".psd"
    redirected = False
    if overwrite_existing and prev_psd_path and _psd_reuse_previous(output_name, prev_psd_path):
        stem = os.path.splitext(os.path.basename(prev_psd_path))[0] + "_rebuilt"
        folder = os.path.dirname(os.path.abspath(prev_psd_path))
        redirected = True
    else:
        stem = _safe_output_basename(output_name)
    return os.path.join(folder, stem + ext), redirected


def _project_memory(project_config, plans, pages, progress_callback=None):
    """Memory dict for psd_memory: settings + page map + layer-to-Excel links."""
    if project_config is None:
        return None
    try:
        from .. import psd_memory

        page_map = [{"group": document._page_group_name(p), "sheet": p.sheet, "part": p.part} for p in pages]
        layers = {}
        for name, plan in plans.items():
            record = getattr(plan, "record", None)
            if record is None:
                continue
            index = getattr(plan, "page_index", 0)
            src = dict(getattr(record, "source", None) or {})
            if 0 <= index < len(pages):
                src["sheet"] = pages[index].sheet
            if record.group:
                src["group"] = record.group          # paytable card / slot group
            layers[name] = src
        return psd_memory.build(project_config, page_map, layers)
    except Exception as exc:
        _note(progress_callback, f"[PSD] Project memory not saved: {exc}")
        return None


def build_psd(excel_path, c_width, c_height, output_dir=None, output_name=None, output_format="PSD",
              overwrite_existing=False, prev_psd_path=None, progress_callback=None, cancel_event=None,
              project_config=None, **kwargs):
    """Build the PSD; returns its path (or None when nothing was rendered).

    With `project_config` (the app's settings) the whole project is stored
    inside the PSD (psd_memory.py), so the PSD alone can restore it.
    """
    t0 = time.perf_counter()
    save_path, redirected = _save_path(excel_path, output_dir, output_name, output_format,
                                       overwrite_existing, prev_psd_path)
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    work = tempfile.mkdtemp(prefix="psh_psd_")
    rec = recorder.LayerRecorder()
    previous_style_override = _config._STYLE_ASSETS_OVERRIDE
    try:
        # Layer styles become real effects in the PSD; never render them through Photoshop.
        _config.set_photoshop_style_assets_enabled(False)
        kwargs["show_completion_dialogs"] = False
        with rec.recording():
            png_builder.build_pngs_only(
                excel_path=excel_path, c_width=c_width, c_height=c_height,
                output_dir=work, output_name=output_name, output_format="png",
                prev_psd_path=prev_psd_path, progress_callback=progress_callback,
                cancel_event=cancel_event, **kwargs,
            )
        t_layout = time.perf_counter()
        if not rec.sheets:
            _note(progress_callback, "[PSD] No pages were rendered; nothing to save.")
            return None

        report = list(rec.notes)
        lf, plans, pages, shared_bg = document.build_document(rec, c_width, c_height, report)
        raw_path = os.path.join(work, "layers.psd")
        lf.write(raw_path)
        t_layers = time.perf_counter()
        memory = _project_memory(project_config, plans, pages, progress_callback)
        from .. import global_light

        light = global_light.for_document(kwargs.get("dynamic_settings") or {})
        attached = finalize.finalize(raw_path, save_path, plans, pages, shared_bg, memory=memory, light=light)
        t_done = time.perf_counter()

        for line in report:
            _note(progress_callback, f"[PSD] {line}")
        if redirected:
            _note(progress_callback, (
                "[PSD] In-place update isn't available in the new engine yet (it would overwrite "
                f"artist edits); wrote a fresh PSD instead: {os.path.basename(save_path)}"))
        _note(progress_callback, (
            f"[PSD] {len(pages)} page(s), {len(plans)} editable text layer(s) "
            f"({attached} with preview), {sum(len(p.icons) for p in pages)} icon layer(s) in "
            f"{t_done - t0:.2f}s (layout {t_layout - t0:.2f}s, layers {t_layers - t_layout:.2f}s, "
            f"previews+save {t_done - t_layers:.2f}s)"))
        return save_path
    finally:
        _config._STYLE_ASSETS_OVERRIDE = previous_style_override
        shutil.rmtree(work, ignore_errors=True)
