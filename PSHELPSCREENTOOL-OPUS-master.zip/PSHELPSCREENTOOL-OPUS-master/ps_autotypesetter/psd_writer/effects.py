"""Simple style settings (stroke / drop shadow) -> a real Photoshop effects block.

Styles captured from Photoshop are copied byte for byte (document.py). The
simple settings panel only stores numbers (stroke_enabled, stroke_rgb, ...),
so here they are written into a template effects descriptor that was captured
from Photoshop once (fx_template.bin: drop shadow + stroke) and serialised with
psd-tools — every key Photoshop expects is present, only the values change.
"""
import io
import os

from psd_tools.psd.descriptor import Bool, DescriptorBlock

_TEMPLATE = os.path.join(os.path.dirname(__file__), "fx_template.bin")


def _num(value, fallback):
    try:
        return float(value)
    except (TypeError, ValueError):
        return float(fallback)


def _rgb(value, fallback):
    try:
        if isinstance(value, str):
            v = value.lstrip("#")
            return tuple(int(v[i:i + 2], 16) for i in (0, 2, 4))
        rgb = tuple(int(c) for c in list(value)[:3])
        return rgb if len(rgb) == 3 else fallback
    except (TypeError, ValueError):
        return fallback


def _set_color(desc, rgb):
    color = desc[b"Clr "]
    for key, value in zip((b"Rd  ", b"Grn ", b"Bl  "), rgb):
        color[key].value = float(value)


def _truthy(value):
    return value is True or str(value).strip().casefold() in ("1", "true", "yes", "on")


# Photoshop's own descriptors of the other effects (captured once from Photoshop: outer / inner glow, inner
# shadow, bevel, gradient overlay) — a design's or a card look's captured_params are written into them, so
# every effect the Canvas draws (ps_fx_canvas.js / ps_fx_png.py read the same numbers) is the PSD's too
_PARTS_TEMPLATE = os.path.join(os.path.dirname(__file__), "fx_glow_template.bin")
_BLEND = {"screen": b"Scrn", "normal": b"Nrml", "multiply": b"Mltp", "overlay": b"Ovrl", "linear dodge": b"lddg",
          "lineardodge": b"lddg", "color dodge": b"CDdg", "lighten": b"Lghn", "darken": b"Drkn",
          "soft light": b"SftL", "hard light": b"HrdL", "color burn": b"CBrn"}
_BEVEL_STYLE = {"inner": b"InrB", "outer": b"OtrB", "emboss": b"Embs", "pillow": b"PlEb", "stroke": b"strokeEmboss"}
_BEVEL_TECH = {"smooth": b"SfBL", "chisel_hard": b"PrBL", "chisel_soft": b"Slmt"}
_GRAD_TYPE = {"linear": b"Lnr ", "radial": b"Rdl ", "angle": b"Angl", "reflected": b"Rflc", "diamond": b"Dmnd"}


def _on(cp, key):
    v = cp.get(key) if isinstance(cp, dict) else None
    return v if isinstance(v, dict) and v.get("enabled", True) is not False else None


def _rgb_into(node, rgb):
    for key, value in zip((b"Rd  ", b"Grn ", b"Bl  "), rgb):
        node[key].value = float(value)


def _enum(desc, key, value):
    if value is not None and key in desc:
        desc[key].enum = value


def _blend(desc, value, default):
    _enum(desc, b"Md  ", _BLEND.get(str(value or default).casefold(), _BLEND[default]))


def _shadow_into(d, v, default_blend="multiply"):
    _set_color(d, _rgb(v.get("color"), (0, 0, 0)))
    d[b"Opct"].value = _num(v.get("opacity"), 75)
    d[b"lagl"].value = _num(v.get("angle"), 120)
    d[b"Dstn"].value = _num(v.get("distance"), 5)
    d[b"blur"].value = _num(v.get("size"), 5)
    if b"Ckmt" in d:
        d[b"Ckmt"].value = _num(v.get("spread", v.get("choke")), 0)
    if b"uglg" in d:
        d[b"uglg"] = Bool(bool(v.get("use_global_light")))
    _blend(d, v.get("blend"), default_blend)


def _glow_into(d, v, default_blend="screen"):
    _set_color(d, _rgb(v.get("color"), (255, 210, 74)))
    d[b"Opct"].value = _num(v.get("opacity"), 60)
    d[b"blur"].value = _num(v.get("size"), 16)
    d[b"Ckmt"].value = _num(v.get("spread", v.get("choke")), 0)
    _enum(d, b"GlwT", b"PrBL" if str(v.get("technique") or "softer").casefold() == "precise" else b"SfBL")
    if b"glwS" in d:                                  # an inner glow's source: the edge or the centre
        _enum(d, b"glwS", b"SrcC" if str(v.get("source") or "edge").casefold() == "center" else b"SrcE")
    _blend(d, v.get("blend"), default_blend)


def _bevel_into(d, v):
    _enum(d, b"bvlS", _BEVEL_STYLE.get(str(v.get("style") or "inner").casefold()))
    _enum(d, b"bvlT", _BEVEL_TECH.get(str(v.get("technique") or "smooth").casefold()))
    _enum(d, b"bvlD", b"Out " if str(v.get("direction") or "up").casefold() == "down" else b"In  ")
    d[b"srgR"].value = _num(v.get("depth"), 100)
    d[b"blur"].value = _num(v.get("size"), 5)
    d[b"lagl"].value = _num(v.get("angle"), 120)
    d[b"Lald"].value = _num(v.get("altitude"), 30)
    d[b"Sftn"].value = _num(v.get("soften"), 0)
    d[b"uglg"] = Bool(bool(v.get("use_global_light")))
    _rgb_into(d[b"hglC"], _rgb(v.get("highlight_color"), (255, 255, 255)))
    d[b"hglO"].value = _num(v.get("highlight_opacity"), 75)
    _rgb_into(d[b"sdwC"], _rgb(v.get("shadow_color"), (0, 0, 0)))
    d[b"sdwO"].value = _num(v.get("shadow_opacity"), 75)


def _gradient_into(d, v):
    import copy

    d[b"Opct"].value = _num(v.get("opacity"), 100)
    d[b"Angl"].value = _num(v.get("angle"), 90)
    if b"Scl " in d:
        d[b"Scl "].value = _num(v.get("scale"), 100)
    _enum(d, b"Type", _GRAD_TYPE.get(str(v.get("type") or "linear").casefold(), b"Lnr "))
    d[b"Rvrs"] = Bool(bool(v.get("reverse")))
    _blend(d, v.get("blend"), "normal")
    stops = []
    for c in v.get("colors") or []:
        try:
            col, loc = (c[0], c[1]) if isinstance(c, (list, tuple)) else (c.get("color"), c.get("location", 0))
        except (TypeError, IndexError, AttributeError):
            continue
        stops.append((_rgb(col, (255, 255, 255)), max(0.0, min(100.0, _num(loc, 0)))))
    grad = d[b"Grad"]
    # its smoothness as the effects engine reads it (ps_fx_png / ps_fx_canvas: none given = 0 %, a straight
    # blend) — the template's 100 % would ease the colours and look more contrasty than the Canvas
    grad[b"Intr"].value = max(0.0, min(100.0, _num(v.get("smoothness"), 0))) * 40.96
    if len(stops) >= 2:
        proto = grad[b"Clrs"][0]
        items = []
        for rgb, loc in stops:
            st = copy.deepcopy(proto)
            _rgb_into(st[b"Clr "], rgb)
            st[b"Lctn"].value = int(round(loc * 40.96))
            st[b"Mdpn"].value = 50
            items.append(st)
        del grad[b"Clrs"][:]
        grad[b"Clrs"].extend(items)
        tproto = grad[b"Trns"][0]
        ts = []
        for loc in (0, 4096):
            t = copy.deepcopy(tproto)
            t[b"Opct"].value = 100.0
            t[b"Lctn"].value = loc
            t[b"Mdpn"].value = 50
            ts.append(t)
        del grad[b"Trns"][:]
        grad[b"Trns"].extend(ts)


_PARTS = (("outer_glow", b"OrGl", _glow_into), ("inner_glow", b"IrGl", lambda d, v: _glow_into(d, v)),
          ("inner_shadow", b"IrSh", _shadow_into), ("bevel", b"ebbl", _bevel_into),
          ("gradient_overlay", b"GrFl", _gradient_into))


def params_payload(fx):
    """lfx2 payload for a parameter style, or None when it has no effect: the simple settings (stroke /
    drop shadow numbers) and a design's / card look's captured_params (drop shadow, outer and inner glow,
    inner shadow, bevel, gradient overlay) — what the Canvas draws is what the PSD's layer style holds."""
    fx = fx or {}
    cp = fx.get("captured_params") if isinstance(fx.get("captured_params"), dict) else {}
    stroke, shadow = _truthy(fx.get("stroke_enabled")), _truthy(fx.get("shadow_enabled"))
    cshadow = _on(cp, "drop_shadow")
    parts = [(key, tag, into, _on(cp, key)) for key, tag, into in _PARTS]
    parts = [p for p in parts if p[3]]
    if not (stroke or shadow or cshadow or parts):
        return None
    with open(_TEMPLATE, "rb") as f:
        desc = DescriptorBlock.read(io.BytesIO(f.read()))
    if parts:
        with open(_PARTS_TEMPLATE, "rb") as f:
            lib = DescriptorBlock.read(io.BytesIO(f.read()))
        for _key, tag, into, v in parts:
            d = lib[tag]
            d[b"enab"] = Bool(True)
            d[b"present"] = Bool(True)
            into(d, v)
            desc[tag] = d
    if cshadow:                                       # the look's own drop shadow (captured_params)
        sh = desc[b"DrSh"]
        sh[b"enab"] = Bool(True)
        sh[b"present"] = Bool(True)
        _shadow_into(sh, cshadow)
        shadow = None                                 # written: the flat shadow_* keys don't override it

    sh = desc[b"DrSh"]
    if shadow is not None:
        sh[b"enab"] = Bool(shadow)
        sh[b"present"] = Bool(shadow)
    if shadow:
        _set_color(sh, _rgb(fx.get("shadow_rgb"), (0, 0, 0)))
        sh[b"Opct"].value = _num(fx.get("shadow_opacity"), 75)
        sh[b"lagl"].value = _num(fx.get("shadow_angle"), 120)
        sh[b"Dstn"].value = _num(fx.get("shadow_distance"), 5)
        sh[b"blur"].value = _num(fx.get("shadow_size"), 5)

    fr = desc[b"FrFX"]
    fr[b"enab"] = Bool(stroke)
    fr[b"present"] = Bool(stroke)
    if stroke:
        _set_color(fr, _rgb(fx.get("stroke_rgb"), (0, 0, 0)))
        fr[b"Opct"].value = _num(fx.get("stroke_opacity"), 100)
        fr[b"Sz  "].value = _num(fx.get("stroke_size"), 2)

    buf = io.BytesIO()
    desc.write(buf)
    return b"\x00\x00\x00\x00" + buf.getvalue()
