"""Live Photoshop shapes: rounded rectangles artists can still edit as vectors.

A Photoshop "live shape" layer is a normal layer plus five tagged blocks:

  vsms  vector mask — the outline as Bezier knots (y, x relative to the document)
  vogk  vector origination — "this is a rounded rectangle": box, 4 corner radii
        (what the Properties panel edits; keeps corners round when resized)
  vowv  origination version (small, constant)
  vscg  fill content (solid colour, SoCo)
  vstk  stroke: on/off, width, colour, inside/centre/outside

The blocks come from a template (shape_template.bin, a plain rounded
rectangle) and are filled in for each shape, the same approach as Txt2 and
the effects template. The layer's pixels are our own render of the shape, so
the file looks right everywhere (thumbnails, viewers, psd-tools) before
Photoshop redraws it from the vectors. Layer styles are added as lfx2 like
any other layer.

spec = {left, top, width, height,              canvas px
        radius | radii: (tl, tr, br, bl),      px; "pill" = half the height
        corner | corners: (tl, tr, br, bl),    "round" (default) · "cut" (a chamfer) · "notch" (a
                                               quarter circle cut in) · "step" (a square cut in) —
                                               a shape that isn't all round is a plain vector path
        fill: "#RRGGBB", fill_opacity: 0-100,
        stroke: {enabled, width, color, align: inside|center|outside, opacity}}
"""
import copy
import io
import os

from psd_tools.constants import Tag
from psd_tools.psd.tagged_blocks import TaggedBlock

TEMPLATE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "shape_template.bin")
KAPPA = 0.5522847498            # Bezier handle length for a quarter circle
_ALIGN = {"inside": b"strokeStyleAlignInside", "center": b"strokeStyleAlignCenter",
          "outside": b"strokeStyleAlignOutside"}
_cache = {}


def _template():
    if "blocks" not in _cache:
        data = open(TEMPLATE, "rb").read()
        fp, blocks = io.BytesIO(data), {}
        while fp.tell() < len(data):
            tb = TaggedBlock.read(fp, version=1)
            blocks[tb.key] = tb
        _cache["blocks"] = blocks
    return {k: copy.deepcopy(v) for k, v in _cache["blocks"].items()}


def _hex(value, fallback=(255, 255, 255)):
    if isinstance(value, (list, tuple)) and len(value) >= 3:
        return tuple(int(v) for v in value[:3])
    s = str(value or "").strip().lstrip("#")
    if len(s) == 6:
        try:
            return tuple(int(s[i:i + 2], 16) for i in (0, 2, 4))
        except ValueError:
            pass
    return fallback


def radii_of(spec):
    """(tl, tr, br, bl), each clamped to half the shorter side."""
    w, h = float(spec["width"]), float(spec["height"])
    limit = max(0.0, min(w, h) / 2.0)
    r = spec.get("radii")
    if r is None:
        r = spec.get("radius", 0)
        r = limit if str(r).lower() == "pill" else r
        r = (r, r, r, r)
    return tuple(max(0.0, min(limit, float(v))) for v in r)


CORNERS = ("round", "cut", "notch", "step")


def corners_of(spec):
    """(tl, tr, br, bl) corner kinds."""
    c = spec.get("corners")
    if not (isinstance(c, (list, tuple)) and len(c) == 4):
        c = [spec.get("corner") or "round"] * 4
    return tuple(str(k).lower() if str(k).lower() in CORNERS else "round" for k in c)


def is_round(spec):
    return all(k == "round" for k in corners_of(spec))


def knots(spec, inset=0.0):
    """Knots [(preceding, anchor, leaving)] of any corner kinds, canvas px, clockwise from the top-left
    corner; `inset`: the outline moved inwards (a border's inner edge)."""
    l, t = float(spec["left"]) + inset, float(spec["top"]) + inset
    r, b = float(spec["left"]) + float(spec["width"]) - inset, float(spec["top"]) + float(spec["height"]) - inset
    lim = max(0.0, min(r - l, b - t) / 2.0)
    kinds = corners_of(spec)
    k = KAPPA
    out = []
    # each corner: its point, the edge it comes in on (start) and leaves on (end), clockwise
    for (cx, cy), (sx, sy), (ex, ey), rad, kind in (
            ((l, t), (0, 1), (1, 0), radii_of(spec)[0], kinds[0]),
            ((r, t), (-1, 0), (0, 1), radii_of(spec)[1], kinds[1]),
            ((r, b), (0, -1), (-1, 0), radii_of(spec)[2], kinds[2]),
            ((l, b), (1, 0), (0, -1), radii_of(spec)[3], kinds[3])):
        rr = rad - inset if kind == "round" else rad + inset if kind in ("notch", "step") else rad
        rr = max(0.0, min(lim, rr))
        if rr <= 1e-6:
            out.append(((cx, cy), (cx, cy), (cx, cy)))
            continue
        S = (cx + sx * rr, cy + sy * rr)                 # where the corner starts (on the edge coming in)
        E = (cx + ex * rr, cy + ey * rr)                 # where it ends (on the edge going out)
        O = (S[0] + E[0] - cx, S[1] + E[1] - cy)         # the inner point of the corner square
        if kind == "round":                            # bulges out: handles towards the corner point
            s_out = (S[0] + k * (cx - S[0]), S[1] + k * (cy - S[1]))
            e_in = (E[0] + k * (cx - E[0]), E[1] + k * (cy - E[1]))
            out += [(S, S, s_out), (e_in, E, E)]
        elif kind == "notch":                          # a quarter circle round the corner point, cut in
            s_out = (S[0] + k * (O[0] - S[0]), S[1] + k * (O[1] - S[1]))
            e_in = (E[0] + k * (O[0] - E[0]), E[1] + k * (O[1] - E[1]))
            out += [(S, S, s_out), (e_in, E, E)]
        elif kind == "step":                           # a square cut in
            out += [(S, S, S), (O, O, O), (E, E, E)]
        else:                                          # cut: a straight chamfer
            out += [(S, S, S), (E, E, E)]
    merged = []
    for pre, anc, lea in out:
        if merged and abs(merged[-1][1][0] - anc[0]) < 1e-6 and abs(merged[-1][1][1] - anc[1]) < 1e-6:
            merged[-1] = (merged[-1][0], anc, lea)
        else:
            merged.append((pre, anc, lea))
    if len(merged) > 1 and abs(merged[0][1][0] - merged[-1][1][0]) < 1e-6 and abs(merged[0][1][1] - merged[-1][1][1]) < 1e-6:
        merged[0] = (merged[-1][0], merged[0][1], merged[0][2])
        merged.pop()
    return merged


def polygon(spec, inset=0.0, scale=1.0, ox=0.0, oy=0.0, step=2.0):
    """The outline sampled as points (for drawing): each curve in short straight pieces."""
    ks = knots(spec, inset)
    pts = []
    for i, (_pre, anc, lea) in enumerate(ks):
        nxt = ks[(i + 1) % len(ks)]
        p0, p1, p2, p3 = anc, lea, nxt[0], nxt[1]
        curved = p1 != p0 or p2 != p3
        n = max(1, int((abs(p3[0] - p0[0]) + abs(p3[1] - p0[1])) / step)) if curved else 1
        for j in range(n):
            u = j / float(n)
            a, b2, c, d = (1 - u) ** 3, 3 * u * (1 - u) ** 2, 3 * u * u * (1 - u), u ** 3
            x = a * p0[0] + b2 * p1[0] + c * p2[0] + d * p3[0]
            y = a * p0[1] + b2 * p1[1] + c * p2[1] + d * p3[1]
            pts.append((ox + x * scale, oy + y * scale))
    return pts


def outline(spec):
    """Knots [(preceding, anchor, leaving)] in canvas px (x, y), clockwise from the top edge."""
    if not is_round(spec):
        return knots(spec)
    l, t = float(spec["left"]), float(spec["top"])
    r, b = l + float(spec["width"]), t + float(spec["height"])
    tl, tr, br, bl = radii_of(spec)
    k = KAPPA
    raw = [
        ((l + tl - k * tl, t), (l + tl, t), (l + tl, t)),            # top edge, after the top-left arc
        ((r - tr, t), (r - tr, t), (r - tr + k * tr, t)),            # top edge, before the top-right arc
        ((r, t + tr - k * tr), (r, t + tr), (r, t + tr)),
        ((r, b - br), (r, b - br), (r, b - br + k * br)),
        ((r - br + k * br, b), (r - br, b), (r - br, b)),
        ((l + bl, b), (l + bl, b), (l + bl - k * bl, b)),
        ((l, b - bl + k * bl), (l, b - bl), (l, b - bl)),
        ((l, t + tl), (l, t + tl), (l, t + tl - k * tl)),
    ]
    out = []
    for pre, anc, lea in raw:                          # merge knots that meet (pill ends, square corners)
        if out and abs(out[-1][1][0] - anc[0]) < 1e-6 and abs(out[-1][1][1] - anc[1]) < 1e-6:
            out[-1] = (out[-1][0], anc, lea)
        else:
            out.append((pre, anc, lea))
    if len(out) > 1 and abs(out[0][1][0] - out[-1][1][0]) < 1e-6 and abs(out[0][1][1] - out[-1][1][1]) < 1e-6:
        out[0] = (out[-1][0], out[0][1], out[0][2])
        out.pop()
    return out


# gradient_dir → (Photoshop gradient type, angle): the first colour at the top / left / top-left / centre
_GRAD = {"vertical": (b"Lnr ", -90.0), "horizontal": (b"Lnr ", 0.0), "diagonal": (b"Lnr ", -45.0),
         "radial": (b"Rdl ", 90.0)}


def _gradient_content(spec):
    """vscg for a gradient fill (GdFl): fill → fill_to along gradient_dir, as Photoshop's own Gradient Fill."""
    from psd_tools.psd.descriptor import Bool, Descriptor, Double, Enumerated, Integer, List, String, UnitFloat
    from psd_tools.psd.vector import VectorStrokeContentSetting
    from psd_tools.terminology import Unit

    def rgb(value):
        c = Descriptor(classID=b"RGBC")
        r, g, b = _hex(value, (255, 255, 255))
        c[b"Rd  "], c[b"Grn "], c[b"Bl  "] = Double(float(r)), Double(float(g)), Double(float(b))
        return c

    def stop(value, at):
        s = Descriptor(classID=b"Clrt")
        s[b"Clr "] = rgb(value)
        s[b"Type"] = Enumerated(b"Clry", b"UsrS")
        s[b"Lctn"], s[b"Mdpn"] = Integer(at), Integer(50)
        return s

    def opaque(at):
        s = Descriptor(classID=b"TrnS")
        s[b"Opct"] = UnitFloat(100.0, Unit.Percent)
        s[b"Lctn"], s[b"Mdpn"] = Integer(at), Integer(50)
        return s

    kind, angle = _GRAD.get(str(spec.get("gradient_dir") or "vertical").lower(), _GRAD["vertical"])
    grad = Descriptor(classID=b"Grdn")
    grad[b"Nm  "] = String("Custom")
    grad[b"GrdF"] = Enumerated(b"GrdF", b"CstS")
    # Smoothness 0 %: a straight blend, as the Canvas and the PNG draw it (Photoshop's default 100 % eases the
    # colours along a curve — the ends hold their colour longer, more contrast than the preview shows)
    grad[b"Intr"] = Double(0.0)
    grad[b"Clrs"] = List([stop(spec.get("fill"), 0), stop(spec.get("fill_to"), 4096)])
    grad[b"Trns"] = List([opaque(0), opaque(4096)])
    out = VectorStrokeContentSetting(key=b"GdFl", version=16, classID=b"null")
    out[b"Grad"] = grad
    out[b"Angl"] = UnitFloat(angle, Unit.Angle)
    out[b"Type"] = Enumerated(b"GrdT", kind)
    out[b"Algn"] = Bool(True)
    out[b"Scl "] = UnitFloat(100.0, Unit.Percent)
    ofs = Descriptor(classID=b"Pnt ")
    ofs[b"Hrzn"], ofs[b"Vrtc"] = UnitFloat(0.0, Unit.Percent), UnitFloat(0.0, Unit.Percent)
    out[b"Ofst"] = ofs
    return out


def blocks(spec, doc_w, doc_h):
    """The five tagged blocks that make a layer a live rounded rectangle."""
    tpl = _template()
    W, H = float(doc_w), float(doc_h)
    l, t = float(spec["left"]), float(spec["top"])
    r, b = l + float(spec["width"]), t + float(spec["height"])
    tl, tr, br, bl = radii_of(spec)

    # vector mask: replace the template's knots (relative (y, x))
    vsms = tpl[Tag.VECTOR_MASK_SETTING2]
    path = vsms.data.path
    sub_i = next(i for i, item in enumerate(path) if hasattr(item, "is_closed"))
    sub = path[sub_i]
    knot_cls = type(sub[0])
    rel = lambda p: (p[1] / H, p[0] / W)
    new_sub = copy.deepcopy(sub)
    del new_sub[:]
    for pre, anc, lea in outline(spec):
        new_sub.append(knot_cls(rel(pre), rel(anc), rel(lea)))
    new_sub.index = 0
    path[sub_i] = new_sub

    # live shape: box, corners, radii, no transform
    vogk = tpl[Tag.VECTOR_ORIGINATION_DATA]
    item = vogk.data[b"keyDescriptorList"][0]
    rad = item[b"keyOriginRRectRadii"]
    for key, v in ((b"topLeft", tl), (b"topRight", tr), (b"bottomRight", br), (b"bottomLeft", bl)):
        rad[key].value = float(v)
    box = item[b"keyOriginShapeBBox"]
    box[b"Top "].value, box[b"Left"].value, box[b"Btom"].value, box[b"Rght"].value = t, l, b, r
    corners = item[b"keyOriginBoxCorners"]
    for key, (x, y) in ((b"rectangleCornerA", (l, t)), (b"rectangleCornerB", (r, t)),
                        (b"rectangleCornerC", (r, b)), (b"rectangleCornerD", (l, b))):
        corners[key][b"Hrzn"].value, corners[key][b"Vrtc"].value = x, y
    trnf = item[b"Trnf"]
    for key, v in ((b"xx", 1.0), (b"xy", 0.0), (b"yx", 0.0), (b"yy", 1.0), (b"tx", 0.0), (b"ty", 0.0)):
        trnf[key].value = v
    item[b"keyOriginIndex"].value = 0

    # fill colour
    vscg = tpl[Tag.VECTOR_STROKE_CONTENT_DATA]
    clr = vscg.data[b"Clr "]
    fr, fg, fb = _hex(spec.get("fill"), (255, 255, 255))
    clr[b"Rd  "].value, clr[b"Grn "].value, clr[b"Bl  "].value = float(fr), float(fg), float(fb)
    if spec.get("fill") is not None and spec.get("fill_to"):
        vscg.data = _gradient_content(spec)            # a gradient fill Photoshop draws (and the artist edits)

    # stroke
    vstk = tpl[Tag.VECTOR_STROKE_DATA]
    st = vstk.data
    stroke = spec.get("stroke") or {}
    on = bool(stroke.get("enabled")) and float(stroke.get("width") or 0) > 0
    st[b"strokeEnabled"].value = on
    st[b"fillEnabled"].value = spec.get("fill") is not None
    st[b"strokeStyleLineWidth"].value = float(stroke.get("width") or 1)
    st[b"strokeStyleOpacity"].value = float(stroke.get("opacity", 100))
    sc = st[b"strokeStyleContent"][b"Clr "]
    sr, sg, sb = _hex(stroke.get("color"), (0, 0, 0))
    sc[b"redFloat"].value, sc[b"greenFloat"].value, sc[b"blueFloat"].value = sr / 255.0, sg / 255.0, sb / 255.0
    align = _ALIGN.get(str(stroke.get("align") or "inside").lower(), _ALIGN["inside"])
    st[b"strokeStyleLineAlignment"].enum = align
    if not is_round(spec):                             # cut / notched corners: a path of its own, still a
        return [vsms, vscg, vstk]                      # vector the artist can edit (not a "rounded rectangle")
    return [vsms, vogk, tpl[Tag.VECTOR_ORIGINATION_UNKNOWN], vscg, vstk]


_RENDER_CACHE = {}


def render(spec, ss=4):
    """(RGBA image, left, top): the shape's look for the layer pixels and previews.

    Remembered by look + sub-pixel offset: the same card moved by whole pixels, or redrawn
    by the next preview, reuses its pixels (the card studio redraws on every edit)."""
    import json
    import math

    l, t = float(spec["left"]), float(spec["top"])
    il, it = math.floor(l), math.floor(t)
    local = dict(spec, left=l - il, top=t - it)
    try:
        key = (json.dumps(local, sort_keys=True, default=str), ss)
    except (TypeError, ValueError):
        return _render(spec, ss)
    hit = _RENDER_CACHE.get(key)
    if hit is None:
        if len(_RENDER_CACHE) > 256:
            _RENDER_CACHE.clear()
        hit = _RENDER_CACHE[key] = _render(local, ss)
    img, left, top = hit
    return img.copy(), left + il, top + it


def _render(spec, ss=4):
    import math

    from PIL import Image, ImageDraw

    stroke = spec.get("stroke") or {}
    sw = float(stroke.get("width") or 0) if stroke.get("enabled") else 0.0
    align = str(stroke.get("align") or "inside").lower()
    grow = {"outside": sw, "center": sw / 2.0}.get(align, 0.0)
    l, t = float(spec["left"]) - grow, float(spec["top"]) - grow
    w, h = float(spec["width"]) + 2 * grow, float(spec["height"]) + 2 * grow
    left, top = int(l // 1), int(t // 1)
    W, H = int(-(-(l + w) // 1)) - left, int(-(-(t + h) // 1)) - top
    big = Image.new("RGBA", (max(1, W * ss), max(1, H * ss)), (0, 0, 0, 0))
    d = ImageDraw.Draw(big)
    ox, oy = (l - left) * ss, (t - top) * ss
    radii = radii_of(spec)

    plain = is_round(spec)

    def rrect(inset, fill):
        if not plain:                                  # cut / notched corners: the outline's own polygon
            local = dict(spec, left=0.0, top=0.0, width=w, height=h)
            if min(w, h) - 2 * inset <= 0:
                return
            d.polygon(polygon(local, inset, ss, ox, oy, step=1.0), fill=fill)
            return
        x0, y0 = ox + inset * ss, oy + inset * ss
        x1, y1 = ox + (w - inset) * ss - 1, oy + (h - inset) * ss - 1
        if x1 <= x0 or y1 <= y0:
            return
        rs = [min(max(0.0, r + grow - inset) * ss, (x1 - x0) / 2.0, (y1 - y0) / 2.0) for r in radii]
        if max(rs) - min(rs) < 0.5:
            d.rounded_rectangle((x0, y0, x1, y1), radius=int(rs[0]), fill=fill)
            return
        # each corner its own radius: the outline as a polygon, a quarter circle per corner
        pts = []
        for cx, cy, r, a0 in ((x0 + rs[0], y0 + rs[0], rs[0], 180), (x1 - rs[1], y0 + rs[1], rs[1], 270),
                              (x1 - rs[2], y1 - rs[2], rs[2], 0), (x0 + rs[3], y1 - rs[3], rs[3], 90)):
            steps = max(1, int(r / 2))
            pts += [(cx + r * math.cos(math.radians(a0 + 90.0 * i / steps)),
                     cy + r * math.sin(math.radians(a0 + 90.0 * i / steps))) for i in range(steps + 1)]
        d.polygon(pts, fill=fill)

    fill = spec.get("fill")
    fill_to = spec.get("fill_to")
    grad_dir = str(spec.get("gradient_dir") or "vertical").lower()
    opacity = int(round(255 * float(spec.get("fill_opacity", 100)) / 100.0))

    def _apply_fill(inset_px):
        if fill is None:
            rrect(inset_px, (0, 0, 0, 0))
            return
        if not fill_to:
            rrect(inset_px, _hex(fill) + (opacity,))
            return
        # Render gradient fill inside the inset shape mask
        c1, c2 = _hex(fill), _hex(fill_to)
        bw, bh = big.size
        mask = Image.new("L", (bw, bh), 0)
        md = ImageDraw.Draw(mask)
        # Swap d temporarily to draw the mask polygon
        nonlocal d
        orig_d = d
        d = md
        rrect(inset_px, 255)
        d = orig_d
        # the gradient at 1x (numpy, the same ramps as the Canvas and the PSD's gradient fill), then supersampled
        import numpy as np

        gw, gh = max(1, W), max(1, H)
        gx = np.linspace(0.0, 1.0, gw)[None, :]
        gy = np.linspace(0.0, 1.0, gh)[:, None]
        if grad_dir == "horizontal":
            tv = np.broadcast_to(gx, (gh, gw))
        elif grad_dir == "diagonal":
            tv = 0.5 * (gx + gy)
        elif grad_dir == "radial":
            tv = np.minimum(1.0, np.hypot(gx - 0.5, gy - 0.5) * 1.4142)
        else:
            tv = np.broadcast_to(gy, (gh, gw))
        rgb = [np.rint(c1[i] + (c2[i] - c1[i]) * tv) for i in range(3)]
        arr = np.dstack(rgb + [np.full((gh, gw), opacity)]).astype(np.uint8)
        gimg = Image.fromarray(arr)                     # H x W x 4 uint8: RGBA
        if (gw, gh) != (bw, bh):
            gimg = gimg.resize((bw, bh), Image.BILINEAR)
        # Clear inside inset first if stroke was drawn, then composite gradient with mask
        if inset_px > 0:
            rrect(inset_px, (0, 0, 0, 0))
        big.paste(gimg, (0, 0), mask)

    if sw > 0:
        rrect(0, _hex(stroke.get("color"), (0, 0, 0)) + (int(round(255 * float(stroke.get("opacity", 100)) / 100.0)),))
        _apply_fill(sw)
    elif fill is not None:
        _apply_fill(0)
    return big.resize((max(1, W), max(1, H)), Image.LANCZOS), left, top


def make_live(layer_record, spec, doc_w, doc_h):
    """Turn a psd-tools layer record into a live rounded rectangle (blocks added in place)."""
    for tb in blocks(spec, doc_w, doc_h):
        layer_record.tagged_blocks[tb.key] = tb
    # what Photoshop sets on shape layers: the pixels are only a preview of the vectors
    layer_record.flags.photoshop_v5_later = True
    layer_record.flags.pixel_data_irrelevant = True
