import json
import os


class TemplateError(ValueError):
    pass


def load_template_json(path):
    path = os.path.abspath(os.path.expanduser(str(path)))
    if not os.path.isfile(path):
        raise TemplateError(f"Template JSON not found: {path}")
    try:
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
    except json.JSONDecodeError as exc:
        raise TemplateError(f"Invalid template JSON: {exc}") from exc

    canvas = data.get("canvas") or {}
    slots = data.get("slots") or {}
    try:
        width = float(canvas["width"])
        height = float(canvas["height"])
    except Exception as exc:
        raise TemplateError("Template JSON needs canvas.width and canvas.height.") from exc
    if width <= 0 or height <= 0:
        raise TemplateError("Template canvas dimensions must be positive.")
    if not isinstance(slots, dict) or not slots:
        raise TemplateError("Template JSON does not contain any slots.")

    normalized = dict(data)
    normalized["_path"] = path
    normalized["canvas"] = {"width": width, "height": height}
    normalized["slots"] = slots
    return normalized


def scale_template_slots(template, target_width, target_height):
    """Scale coordinates proportionally using a contain/center transform.

    The template remains proportional at 4K, 2K, FHD, or custom sizes. If the
    aspect ratio differs, it is centered with unused space rather than stretched.
    """
    source = template["canvas"]
    sx = float(target_width) / float(source["width"])
    sy = float(target_height) / float(source["height"])
    scale = min(sx, sy)
    offset_x = (float(target_width) - float(source["width"]) * scale) / 2.0
    offset_y = (float(target_height) - float(source["height"]) * scale) / 2.0

    result = {}
    for name, box in template["slots"].items():
        if not isinstance(box, dict):
            continue
        try:
            result[name] = {
                "x": offset_x + float(box["x"]) * scale,
                "y": offset_y + float(box["y"]) * scale,
                "w": float(box["w"]) * scale,
                "h": float(box["h"]) * scale,
            }
        except Exception:
            continue
    return result, scale, offset_x, offset_y
