"""Optional dynamic-page addon.

The normal text/icon/table renderer is untouched. Dynamic renderers are called only
when an Excel sheet name exactly matches a configured rule.
"""

from .router import should_handle_sheet, render_dynamic_sheet

__all__ = ["should_handle_sheet", "render_dynamic_sheet"]
