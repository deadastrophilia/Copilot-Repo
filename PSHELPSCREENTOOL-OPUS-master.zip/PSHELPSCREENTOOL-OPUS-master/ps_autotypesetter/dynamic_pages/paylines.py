"""Paylines / Win Lines pages, generated from the Excel.

Excel (e.g. sheet "Pay Lines"):
    Line | Reel1 | Reel2 | Reel3 | Reel4 | Reel5      one row per payline;
    1    | 1     | 1     | 1     | 1     | 1          reel value = row index
                                                        (0 top, 1 middle, 2 bottom)
    Denom    | 1,2 | 5,10 | $1, $2                     optional: one page per
    Paylines | 50  | 25   | 5                          column, showing lines 1..N

Every value is validated (missing/duplicate line numbers, row index out of
range, missing reels, more lines asked for than exist); a sheet with errors
is not rendered — the errors are reported instead of drawing wrong lines.

Each payline is a small reels x rows grid with the cells of its pattern
highlighted and a numbered badge. In a PSD build every line is its own group
("Line 7": number text, badge, highlighted cells, grid) so artists can edit
it; the heading is the page's normal heading text layer.

Settings live in dynamic_settings["paylines"] (per game). Defaults match the
BZZF reference (2210 x 1341 canvas) and scale with the canvas width.
"""
import re

PAGE_KIND = "paylines"
_NAME_RX = re.compile(r"(pay|win|min)\s*_?-?\s*lines?", re.I)

# measured on the reference Win Lines page (2210 px wide)
REF_WIDTH = 2210
DEFAULTS = {
    "heading_text": "WIN LINES",
    "rows": 3,                       # symbol positions per reel
    "cell_w": 28, "cell_h": 23,
    "cell_gap": 4,                   # gold lines between (and around) the cells
    "outline": 1,                    # thin dark edge around the grid
    "cell_radius": 0,
    "cell_rgb": "#FFFFFF",
    "gap_rgb": "#D7962D",
    "outline_rgb": "#755723",
    "columns": 10,                   # paylines per row
    "pitch_x": 188, "pitch_y": 165,  # grid to grid (left-left / top-top)
    "align": "center",               # left | center | right — the block on the page
    "last_row": "left",              # left | center — a short last row
    "top": 448,                      # preferred top of the first grid row
    "bottom": 1081,                  # lowest the last grid row may reach
    "offset_x": 0,
    "badge_w": 63, "badge_h": 50,
    "badge_dx": 2, "badge_dy": -40,  # badge top-left from the grid top-left
    "badge_radius": 18,
    "badge_stroke": 2,
    "badge_stroke_rgb": "#755723",
    "badge_gloss": True,
    "badge_font": "Arial-Black",
    "badge_font_size": 38,
    "badge_text_rgb": "#FFFFFF",
    "badge_text_dy": 0,
    "badge_shadow": True,
    "badge_color_mode": "line",      # line (= the line's colour) | fixed
    "badge_rgb": "#16B0EA",
    # line colours (repeat when there are more lines)
    "palette": [
        "#16b0ea", "#df0f8a", "#e92f36", "#089b50", "#34378d", "#f6bf22", "#e89028", "#1495d1", "#8d308c", "#8bbf45",
        "#b8288e", "#0ea4b8", "#e96b30", "#1478b9", "#ea957e", "#ec1a7b", "#643387", "#e9274a", "#1baba0", "#c3d332",
        "#e5d90d", "#50b560", "#e42763", "#1a65b0", "#cc66a1", "#20a5d9", "#e2118c", "#e8242c", "#45b47a", "#373a91",
        "#f5be1e", "#f0962c", "#219ad6", "#9e429b", "#8bbe48", "#b6268c", "#24b2c8", "#e96a2e", "#1174b5", "#f4a08a",
    ],
    "highlight_mode": "line",        # line (palette) | fixed
    "highlight_rgb": "#16B0EA",
    "page_name": "{sheet} {count}L",
    "pages_off": [],                 # payline counts (pages) the user switched off, e.g. [25]
}
_SCALED = ("cell_w", "cell_h", "cell_gap", "outline", "cell_radius", "pitch_x", "pitch_y", "top", "bottom",
           "offset_x", "badge_w", "badge_h", "badge_dx", "badge_dy", "badge_radius", "badge_stroke",
           "badge_font_size", "badge_text_dy")


class PaylineError(ValueError):
    """The sheet can't be turned into correct payline pages; message says where."""


def is_payline_sheet(name):
    return bool(_NAME_RX.search(str(name or "")))


_GRID_MAX_R, _GRID_MAX_C = 250, 160


def _sized(ws):
    """Read-only sheets report the size saved in the file, which can be missing (None) or wrong
    ("A1" on a full sheet): measure them."""
    if hasattr(ws, "calculate_dimension") and type(ws).__name__ == "ReadOnlyWorksheet":
        try:
            ws.calculate_dimension(force=True)
        except Exception:
            pass
    return ws


class _Cell:
    __slots__ = ("value", "coordinate")

    def __init__(self, value, coordinate):
        self.value, self.coordinate = value, coordinate


class _View:
    """The sheet read once, row by row: cell lookups are free afterwards (a read-only sheet
    re-reads the file for every ws.cell() call)."""

    def __init__(self, ws, max_r=_GRID_MAX_R, max_c=_GRID_MAX_C):
        from openpyxl.utils import get_column_letter

        self.title = ws.title
        self.raw = {}
        # a fixed window, not the size saved in the file (read-only sheets can report none, or
        # "A1" for a full sheet); positions are counted, as empty read-only cells carry none
        mr = mc = 1
        for r, row in enumerate(ws.iter_rows(min_row=1, max_row=max_r, min_col=1, max_col=max_c), start=1):
            for c, cell in enumerate(row, start=1):
                if getattr(cell, "value", None) is None and not hasattr(cell, "border"):
                    continue
                self.raw[(r, c)] = cell
                if cell.value is not None:
                    mr, mc = max(mr, r), max(mc, c)
        self.max_row, self.max_column = mr, mc
        self._col = get_column_letter

    def cell(self, r, c):
        cell = self.raw.get((r, c))
        return _Cell(cell.value if cell is not None else None, f"{self._col(c)}{r}")


def _view(ws):
    return ws if isinstance(ws, _View) else _View(ws)


def is_payline_page(ws):
    """A payline sheet: a "Line | Reel1 | Reel2 …" table, or numbered little reel grids with
    each line's cells marked (an X, a filled cell…), in any sheet."""
    try:
        # grids are looked for in sheets named for lines (Paylines, Win Lines, Line Patterns…)
        named = is_payline_sheet(ws.title) or re.search(r"lines?\s*patterns?", str(ws.title), re.I)
        v = _View(ws) if named else _View(ws, 60, 40)
        if _find_header(v) is not None:
            return True
        return bool(named) and len(_grid_blocks(_cells(v))) >= 2
    except Exception:
        return False


def _clean(value):
    if value is None:
        return ""
    return str(value).replace("\xa0", " ").strip()


def _int(value):
    s = _clean(value)
    if isinstance(value, float) and value.is_integer():
        return int(value)
    if isinstance(value, int) and not isinstance(value, bool):
        return value
    return int(s) if re.fullmatch(r"[+-]?\d+", s) else None


def _count(value):
    """A payline count: 50, "50", "50 lines" or a range of lines "1-50" (= 50)."""
    n = _int(value)
    if n is not None:
        return n
    s = _clean(value)
    m = re.fullmatch(r"(\d+)\s*(?:lines?|l)?", s, re.I)
    if m:
        return int(m.group(1))
    m = re.fullmatch(r"(\d+)\s*[-–—~]\s*(\d+)(?:\s*lines?)?", s, re.I)
    if m and int(m.group(1)) == 1 and int(m.group(2)) >= 1:
        return int(m.group(2))
    return None


# ── grid sheets: one little reels x rows grid per line, its cells marked ────────


def _fill_key(cell):
    try:
        f = cell.fill
        if f is None or f.fill_type != "solid":
            return ""
        c = f.fgColor
        if c.type == "rgb" and isinstance(c.rgb, str):
            rgb = c.rgb[-6:].upper()
            return "" if rgb == "FFFFFF" else rgb
        if c.type == "theme":
            return "" if (c.theme == 0 and not c.tint) else f"theme{c.theme}:{c.tint}"
        if c.type == "indexed":
            return "" if c.indexed in (1, 9, 64) else f"idx{c.indexed}"
    except Exception:
        pass
    return ""


def _boxed(cell):
    try:
        b = cell.border
        return sum(1 for side in (b.left, b.right, b.top, b.bottom) if side is not None and side.style) >= 3
    except Exception:
        return False


def _cells(ws):
    """{(row, col): (value, boxed, fill)} of every cell with something in it (one pass: fast
    on read-only sheets too)."""
    out = {}
    for (r, c), cell in _view(ws).raw.items():
        v, bx, fl = cell.value, _boxed(cell), _fill_key(cell)
        if v is not None or bx or fl:
            out[(r, c)] = (v, bx, fl)
    return out


def _grid_blocks(cells):
    """[(line number, label cell (r, c), top, left, rows, reels)] — a whole number with a
    rectangle of grid cells (bordered, or holding a mark) right under it."""
    def gridcell(r, c):
        v = cells.get((r, c))
        return bool(v) and (v[1] or (v[0] is not None and _int(v[0]) is None))

    blocks = []
    for (r, c), (v, _bx, _fl) in cells.items():
        n = _int(v)
        if n is None or n < 1 or not gridcell(r + 1, c) or gridcell(r, c):
            continue
        reels = 0
        while gridcell(r + 1, c + reels) and reels < 12:
            reels += 1
        rows = 0
        while gridcell(r + 1 + rows, c) and rows < 10:
            rows += 1
        if reels < 3 or rows < 2:
            continue
        blocks.append((n, (r, c), r + 1, c, rows, reels))
    return sorted(blocks, key=lambda b: (b[1][0], b[1][1]))


def _block_marks(cells, top, left, rows, reels):
    """Which cells of a block are the line's: a mark (X, ●, 1…) wins; else a cell holding
    something the others don't (Excel's " " that a colour rule paints); else a different fill."""
    sig = {(r, c): cells.get((r, c), (None, False, "")) for r in range(top, top + rows) for c in range(left, left + reels)}
    marked = {k for k, (v, _b, _f) in sig.items() if _clean(v) != ""}
    if marked and len(marked) < len(sig):
        return marked
    raw = {k for k, (v, _b, _f) in sig.items() if v not in (None, "")}
    if raw and len(raw) < len(sig):
        return raw
    fills = {}
    for k, (_v, _b, f) in sig.items():
        fills.setdefault(f, set()).add(k)
    if len(fills) == 2:
        plain = "" if "" in fills else max(fills, key=lambda f: len(fills[f]))
        return next(s for f, s in fills.items() if f != plain)
    return set()


def _parse_grids(ws):
    """{lines, reels, rows, errors} from a sheet of numbered grids, or None when it has none."""
    from openpyxl.utils import get_column_letter as _col

    cells = _cells(ws)
    blocks = _grid_blocks(cells)
    if not blocks:
        return None
    sheet = ws.title
    sizes = {}
    for b in blocks:
        sizes.setdefault((b[4], b[5]), []).append(b)
    (rows, reels), _same = max(sizes.items(), key=lambda kv: len(kv[1]))
    lines, errors = {}, []
    for n, (lr, lc), top, left, brows, breels in blocks:
        where = f"{_col(lc)}{lr}"
        if (brows, breels) != (rows, reels):
            errors.append(f'"{sheet}" {where}: line {n} is a {breels}x{brows} grid, the others are {reels}x{rows}.')
            continue
        if n in lines:
            errors.append(f'"{sheet}" {where}: line {n} appears twice.')
            continue
        marks = _block_marks(cells, top, left, rows, reels)
        pattern = []
        for i in range(reels):
            col = left + i
            hit = sorted(r - top for (r, c) in marks if c == col)
            ref = f"{_col(col)}{top}:{_col(col)}{top + rows - 1}"
            if len(hit) != 1:
                errors.append(f'"{sheet}" {ref} (line {n}, reel {i + 1}): '
                              + ("no cell is marked." if not hit else f"{len(hit)} cells are marked — one per reel."))
                pattern.append(None)
            else:
                pattern.append(hit[0])
        lines[n] = pattern
    return {"lines": lines, "reels": reels, "rows": rows, "errors": errors}


def settings_for(dynamic_settings, canvas_w=REF_WIDTH):
    """Defaults (scaled to the canvas) overlaid with the game's saved settings."""
    saved = (dynamic_settings or {}).get("paylines") or {}
    out = dict(DEFAULTS)
    scale = float(canvas_w or REF_WIDTH) / REF_WIDTH
    if abs(scale - 1) > 0.01:
        for k in _SCALED:
            out[k] = int(round(out[k] * scale))
    for k, v in saved.items():
        if v is not None and v != "":
            out[k] = v
    return out


def _find_header(ws):
    """(row, line_col, [reel cols]) of the 'Line | Reel1 | Reel2 …' header, or None."""
    max_r = min(ws.max_row or 1, 60)
    max_c = min(ws.max_column or 1, 40)
    for r in range(1, max_r + 1):
        for c in range(1, max_c + 1):
            if not re.fullmatch(r"(pay\s*|win\s*)?lines?(\s*(no\.?|#|number))?", _clean(ws.cell(r, c).value), re.I):
                continue
            reels = []
            for cc in range(c + 1, max_c + 1):
                m = re.fullmatch(r"reel\s*(\d+)", _clean(ws.cell(r, cc).value), re.I)
                if not m:
                    break
                reels.append(cc)
            if reels:
                return r, c, reels
    return None


def _find_denoms(ws, header):
    """[{label, count, cell}] from a 'Denom' row with a 'Paylines' row under it (or columns)."""
    max_r = min(ws.max_row or 1, 200)
    max_c = min(ws.max_column or 1, 40)
    skip = (set(header[2]) | {header[1]}) if header else set()
    for r in range(1, max_r + 1):
        for c in range(1, max_c + 1):
            if c in skip and header and r > header[0]:
                continue
            if not re.fullmatch(r"denom(ination)?s?\.?:?", _clean(ws.cell(r, c).value), re.I):
                continue
            # row layout: labels to the right; the count row is a row below with "Paylines"/"Lines"
            for rr in range(r + 1, min(r + 4, max_r) + 1):
                if re.fullmatch(r"(pay|win)?\s*lines?\.?:?|number of (pay)?lines", _clean(ws.cell(rr, c).value), re.I):
                    out = []
                    for cc in range(c + 1, max_c + 1):
                        label, count = _clean(ws.cell(r, cc).value), ws.cell(rr, cc).value
                        if not label and count in (None, ""):
                            break
                        out.append({"label": label, "count": _count(count), "cell": ws.cell(rr, cc).coordinate})
                    return out
            # column layout: labels below; the count column has "Paylines"
            for cc in range(c + 1, min(c + 4, max_c) + 1):
                if re.fullmatch(r"(pay|win)?\s*lines?\.?:?|number of (pay)?lines", _clean(ws.cell(r, cc).value), re.I):
                    out = []
                    for rr in range(r + 1, max_r + 1):
                        label, count = _clean(ws.cell(rr, c).value), ws.cell(rr, cc).value
                        if not label and count in (None, ""):
                            break
                        out.append({"label": label, "count": _count(count), "cell": ws.cell(rr, cc).coordinate})
                    return out
    return []


def parse(ws, rows=3):
    """{lines: {n: [row index per reel]}, reels, denoms, errors, warnings} — never guesses.

    Two ways an AGR draws its lines:
      * a table "Line | Reel1 | Reel2 …", one row per line, each reel the row (0 top; or 1 top
        when the table never uses 0 and does use the bottom row's number);
      * a little reels x rows grid per line under its number, the line's cells marked
        (an X, a cell Excel colours, a filled cell) — the grid's size gives reels and rows.
    """
    ws = _view(ws)
    sheet = ws.title
    header = _find_header(ws)
    if not header:
        grid = _parse_grids(ws)
        if not grid:
            raise PaylineError(f'"{sheet}": no paylines found — neither a "Line | Reel1 | Reel2 | …" table '
                               f'nor numbered grids with the cells of each line marked.')
        return _finish(ws, sheet, None, grid["lines"], grid["reels"], grid["rows"], grid["errors"], [], "grid")
    hr, lc, reel_cols = header
    rows = max(1, int(rows or 3))
    lines, errors, warnings = {}, [], []
    # rows counted from 1 (1 top … 3 bottom): no 0 anywhere and the bottom row's number used
    vals = set()
    for r in range(hr + 1, min((ws.max_row or hr), hr + 400) + 1):
        for c in reel_cols:
            v = _int(ws.cell(r, c).value)
            if v is not None:
                vals.add(v)
    base = 1 if vals and 0 not in vals and rows in vals and min(vals) >= 1 and max(vals) <= rows else 0
    blank_run = 0
    for r in range(hr + 1, (ws.max_row or hr) + 1):
        raw_line = ws.cell(r, lc).value
        raw_reels = [ws.cell(r, c).value for c in reel_cols]
        if _clean(raw_line) == "" and all(_clean(v) == "" for v in raw_reels):
            blank_run += 1
            if blank_run >= 2 and lines:
                break
            continue
        blank_run = 0
        n = _int(raw_line)
        if n is None or n < 1:
            errors.append(f'"{sheet}" row {r}: line number "{_clean(raw_line)}" is not a whole number ≥ 1.')
            continue
        if n in lines:
            errors.append(f'"{sheet}" row {r}: line {n} appears twice.')
            continue
        pattern = []
        for c, v in zip(reel_cols, raw_reels):
            col_name = ws.cell(hr, c).value
            idx = _int(v)
            if idx is not None:
                idx -= base
            if _clean(v) == "":
                errors.append(f'"{sheet}" {ws.cell(r, c).coordinate} (line {n}, {col_name}): missing value.')
            elif idx is None or not (0 <= idx < rows):
                errors.append(f'"{sheet}" {ws.cell(r, c).coordinate} (line {n}, {col_name}): "{_clean(v)}" '
                              f'is not a row index {base}–{rows - 1 + base}.')
            pattern.append(idx)
        lines[n] = pattern
    return _finish(ws, sheet, header, lines, len(reel_cols), rows, errors, warnings, "table", hr)


def _finish(ws, sheet, header, lines, reels, rows, errors, warnings, form, header_row=None):
    """The checks every payline sheet gets, and the parsed result."""
    if not lines and not errors:
        errors.append(f'"{sheet}": the payline table has no rows.')
    if lines:
        # a sheet may carry on from another (lines 51–100 after a sheet with 1–50)
        first = 1 if header else min(lines)
        missing = [i for i in range(first, max(lines) + 1) if i not in lines]
        if missing:
            errors.append(f'"{sheet}": line number(s) missing: {", ".join(map(str, missing[:12]))}'
                          + ("…" if len(missing) > 12 else ""))
        if first > 1:
            warnings.append(f'"{sheet}": lines {first}–{max(lines)} (carrying on from another sheet).')
    denoms = _find_denoms(ws, header)
    for d in denoms:
        if d["count"] is None or d["count"] < 1:
            errors.append(f'"{sheet}" {d["cell"]}: payline count for denom "{d["label"]}" is not a whole number.')
        elif lines and d["count"] > len(lines):
            errors.append(f'"{sheet}" {d["cell"]}: denom "{d["label"]}" needs {d["count"]} lines but the table has {len(lines)}.')
    if not denoms and header:
        warnings.append(f'"{sheet}": no Denom / Paylines table — one page with all {len(lines)} lines.')
    return {"sheet": sheet, "lines": lines, "reels": reels, "rows": rows, "form": form,
            "denoms": denoms, "errors": errors, "warnings": warnings, "header_row": header_row}


def line_numbers(data, count):
    """The lines a page with `count` lines shows: the sheet's first `count` line numbers."""
    return sorted(data["lines"])[:count]


def variants(data):
    """[(label, count)] — one page per distinct payline count, denoms with the same count share it."""
    if not data["denoms"]:
        return [("", len(data["lines"]))]
    out = {}
    for d in data["denoms"]:
        out.setdefault(d["count"], []).append(d["label"])
    return [(", ".join(labels), count) for count, labels in out.items()]


def pages_off(cfg):
    """Pages switched off: a count (that page in every payline sheet) or "Sheet|count" (one sheet's)."""
    out = set()
    for v in cfg.get("pages_off") or []:
        n = _int(v)
        if n is not None:
            out.add(n)
        elif "|" in str(v):
            out.add(str(v))
    return out


def page_key(sheet, count):
    return f"{sheet}|{count}"


def page_list(data, cfg):
    """[{name, denoms, count, on}] — every page the Excel defines, and whether it is built."""
    off = pages_off(cfg)
    out = []
    for label, count in variants(data):
        nums = line_numbers(data, count)
        key = page_key(data["sheet"], count)
        out.append({"name": page_name(data["sheet"], label, count, cfg), "denoms": label, "count": count,
                    "key": key, "first": nums[0] if nums else 1, "last": nums[-1] if nums else count,
                    "on": count not in off and key not in off})
    return out


def page_name(sheet, label, count, cfg):
    fmt = str(cfg.get("page_name") or DEFAULTS["page_name"])
    try:
        name = fmt.format(sheet=sheet, count=count, denoms=label)
    except (KeyError, IndexError, ValueError):
        name = f"{sheet} {count}L"
    return name.strip() or f"{sheet} {count}L"


# ── layout ──────────────────────────────────────────────────────────────────
def grid_size(cfg, reels, rows):
    g, o = int(cfg["cell_gap"]), int(cfg["outline"])
    return (reels * int(cfg["cell_w"]) + (reels + 1) * g + 2 * o,
            rows * int(cfg["cell_h"]) + (rows + 1) * g + 2 * o)


def validate_layout(cfg):
    problems = []
    for k in ("cell_w", "cell_h", "columns", "pitch_x", "pitch_y", "badge_w", "badge_h", "badge_font_size"):
        try:
            if int(cfg[k]) < 1:
                problems.append(f"Paylines setting {k} must be at least 1.")
        except (TypeError, ValueError):
            problems.append(f"Paylines setting {k} must be a number.")
    for k in ("cell_gap", "outline", "badge_stroke", "cell_radius", "badge_radius"):
        try:
            if int(cfg[k]) < 0:
                problems.append(f"Paylines setting {k} can't be negative.")
        except (TypeError, ValueError):
            problems.append(f"Paylines setting {k} must be a number.")
    return problems


def layout(count, cfg, canvas_w, canvas_h, reels=5, rows=3):
    """[(x, y)] top-left of each grid, in line order, plus a warning or None."""
    cols = max(1, min(int(cfg["columns"]), count))
    nrows = -(-count // cols)
    gw, gh = grid_size(cfg, reels, rows)
    px, py = int(cfg["pitch_x"]), int(cfg["pitch_y"])
    block_w = (cols - 1) * px + gw
    block_h = (nrows - 1) * py + gh
    align = str(cfg.get("align") or "center").lower()
    margin = max(0, int(cfg.get("badge_dx", 0)) * -1)
    if align == "left":
        left = margin + 0
    elif align == "right":
        left = canvas_w - block_w
    else:
        left = (canvas_w - block_w) / 2.0
    left += int(cfg.get("offset_x") or 0)
    top = min(int(cfg["top"]), int(cfg["bottom"]) - block_h)
    badge_above = max(0, -int(cfg["badge_dy"]))
    warning = None
    if top - badge_above < 0 or top + block_h > canvas_h or left < 0 or left + block_w > canvas_w:
        warning = (f"{count} paylines in {cols} columns ({block_w}x{block_h}px) don't fit the "
                   f"{canvas_w}x{canvas_h} page — lower the cell size or spacing, or add columns.")
    pos = []
    for i in range(count):
        r, c = divmod(i, cols)
        x = left + c * px
        in_row = min(cols, count - r * cols)
        if in_row < cols and str(cfg.get("last_row") or "left").lower() == "center":
            x += (cols - in_row) * px / 2.0
        pos.append((int(round(x)), int(round(top + r * py))))
    return pos, warning


def block_box(count, cfg, canvas_w, canvas_h, reels=5, rows=3):
    """(left, top, right, bottom) of everything the lines draw (grids + badges), for the UI."""
    pos, _w = layout(count, cfg, canvas_w, canvas_h, reels, rows)
    if not pos:
        return None
    gw, gh = grid_size(cfg, reels, rows)
    bx, by = int(cfg["badge_dx"]), int(cfg["badge_dy"])
    bw, bh = int(cfg["badge_w"]), int(cfg["badge_h"])
    xs0 = [x + min(0, bx) for x, _y in pos]
    xs1 = [x + max(gw, bx + bw) for x, _y in pos]
    ys0 = [y + min(0, by) for _x, y in pos]
    ys1 = [y + max(gh, by + bh) for _x, y in pos]
    return (min(xs0), min(ys0), max(xs1), max(ys1))


# ── drawing ─────────────────────────────────────────────────────────────────
def _hex(value, fallback=(255, 255, 255)):
    s = str(value or "").strip().lstrip("#")
    if isinstance(value, (list, tuple)) and len(value) >= 3:
        return tuple(int(v) for v in value[:3])
    if re.fullmatch(r"[0-9a-fA-F]{6}", s):
        return tuple(int(s[i:i + 2], 16) for i in (0, 2, 4))
    return fallback


def line_rgb(n, cfg):
    if str(cfg.get("highlight_mode") or "line") == "fixed":
        return _hex(cfg.get("highlight_rgb"))
    pal = [p for p in (cfg.get("palette") or []) if p] or DEFAULTS["palette"]
    return _hex(pal[(n - 1) % len(pal)])


def badge_rgb(n, cfg):
    if str(cfg.get("badge_color_mode") or "line") == "fixed":
        return _hex(cfg.get("badge_rgb"))
    return line_rgb(n, cfg)


def _cell_boxes(cfg, reels, rows):
    g, o = int(cfg["cell_gap"]), int(cfg["outline"])
    cw, ch = int(cfg["cell_w"]), int(cfg["cell_h"])
    return [[(o + g + c * (cw + g), o + g + r * (ch + g), o + g + c * (cw + g) + cw - 1, o + g + r * (ch + g) + ch - 1)
             for c in range(reels)] for r in range(rows)]


def grid_image(cfg, reels, rows):
    """The empty grid: outline, gold lines, plain cells."""
    from PIL import Image, ImageDraw

    gw, gh = grid_size(cfg, reels, rows)
    im = Image.new("RGBA", (gw, gh), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    o = int(cfg["outline"])
    if o:
        d.rectangle((0, 0, gw - 1, gh - 1), fill=_hex(cfg["outline_rgb"]) + (255,))
    d.rectangle((o, o, gw - 1 - o, gh - 1 - o), fill=_hex(cfg["gap_rgb"]) + (255,))
    rad = int(cfg.get("cell_radius") or 0)
    fill = _hex(cfg["cell_rgb"]) + (255,)
    for row in _cell_boxes(cfg, reels, rows):
        for box in row:
            if rad:
                d.rounded_rectangle(box, radius=rad, fill=fill)
            else:
                d.rectangle(box, fill=fill)
    return im


def highlight_image(pattern, rgb, cfg, reels, rows):
    from PIL import Image, ImageDraw

    gw, gh = grid_size(cfg, reels, rows)
    im = Image.new("RGBA", (gw, gh), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    rad = int(cfg.get("cell_radius") or 0)
    boxes = _cell_boxes(cfg, reels, rows)
    for c, r in enumerate(pattern):
        if r is None or not (0 <= r < rows) or c >= reels:
            continue
        box = boxes[r][c]
        if rad:
            d.rounded_rectangle(box, radius=rad, fill=tuple(rgb) + (255,))
        else:
            d.rectangle(box, fill=tuple(rgb) + (255,))
    return im


def _mix(a, b, t):
    return tuple(int(round(a[i] + (b[i] - a[i]) * t)) for i in range(3))


_BADGES = {}


def badge_image(rgb, cfg):
    """A glossy rounded badge (supersampled for smooth edges). The same badge is drawn once: lines
    share colours, and the Canvas draws the pages again at every edit. Never changed by its users."""
    key = (tuple(rgb), int(cfg["badge_w"]), int(cfg["badge_h"]), int(cfg["badge_radius"]), int(cfg["badge_stroke"]),
           str(cfg["badge_stroke_rgb"]), bool(cfg.get("badge_gloss", True)))
    if key not in _BADGES:
        if len(_BADGES) > 256:
            _BADGES.clear()
        _BADGES[key] = _badge_image(rgb, cfg)
    return _BADGES[key]


def _badge_image(rgb, cfg):
    from PIL import Image, ImageDraw

    w, h = int(cfg["badge_w"]), int(cfg["badge_h"])
    s = 4
    W, H = w * s, h * s
    rad = max(0, int(cfg["badge_radius"])) * s
    stroke = max(0, int(cfg["badge_stroke"])) * s
    mask = Image.new("L", (W, H), 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, W - 1, H - 1), radius=rad, fill=255)
    out = Image.new("RGBA", (W, H), _hex(cfg["badge_stroke_rgb"]) + (255,))
    inner = Image.new("L", (W, H), 0)
    ImageDraw.Draw(inner).rounded_rectangle((stroke, stroke, W - 1 - stroke, H - 1 - stroke),
                                            radius=max(0, rad - stroke), fill=255)
    body = Image.new("RGBA", (W, H))
    bd = ImageDraw.Draw(body)
    top, bottom = _mix(rgb, (255, 255, 255), 0.10), _mix(rgb, (0, 0, 0), 0.16)
    for y in range(H):
        t = y / max(1, H - 1)
        bd.line([(0, y), (W, y)], fill=_mix(top, bottom, t ** 1.4) + (255,))
    if cfg.get("badge_gloss", True):
        gloss = Image.new("L", (W, H), 0)
        gy0, gy1 = stroke + H * 0.05, stroke + H * 0.24
        ImageDraw.Draw(gloss).rounded_rectangle((stroke + W * 0.10, gy0, W - stroke - W * 0.10, gy1),
                                                radius=int((gy1 - gy0) / 2), fill=95)
        body = Image.composite(Image.new("RGBA", (W, H), (255, 255, 255, 255)), body, gloss)
    out = Image.composite(body, out, inner)
    out.putalpha(mask)
    return out.resize((w, h), Image.LANCZOS)


def render_pages(ws, settings_all, canvas_w, canvas_h, draw_page, counts=None, meta=None, every=False):
    """Build the denomination pages of a payline sheet that are switched on
    (settings "pages_off" lists the ones left out); counts=[...] renders just
    those pages, on or off (the studio preview); every=True: all of them, on or off
    (the Canvas).

    draw_page(name, count) -> (page, draw, heading_bottom) creates a page with
    the background and heading; this function adds the lines. Returns
    [(name, page)], warnings. Raises PaylineError when the data is wrong.
    meta (a dict) receives heading_bottom of the last page drawn (for the UI),
    "data": what the sheet holds (lines, reels, rows, denominations), and "pages": per
    page drawn, where everything landed (the Canvas's handles, paylines_layout.py) —
    its lines' grid / badge places, the block, the layout.
    """
    from PIL import Image, ImageFont

    from .. import png_builder as pb

    cfg = settings_for(settings_all, canvas_w)
    problems = validate_layout(cfg)
    if problems:
        raise PaylineError(" ".join(problems))
    data = parse(ws, cfg.get("rows", 3))
    if isinstance(meta, dict):
        meta["data"] = {"lines_total": len(data["lines"]), "reels": data["reels"], "rows": data["rows"],
                        "form": data.get("form", "table"), "denoms": data["denoms"], "errors": data["errors"]}
    if data["errors"]:
        raise PaylineError(" ".join(data["errors"][:8]) + (f" (+{len(data['errors']) - 8} more)" if len(data["errors"]) > 8 else ""))
    reels, rows = data["reels"], data["rows"]
    grid = grid_image(cfg, reels, rows)
    num_font = pb._load_font(ImageFont, cfg["badge_font"], int(cfg["badge_font_size"]), bold=True)
    num_fx = None
    if cfg.get("badge_shadow", True):
        num_fx = {"stroke_enabled": True, "stroke_rgb": "#3A2A10", "stroke_size": 1, "stroke_opacity": 70,
                  "shadow_enabled": True, "shadow_rgb": "#000000", "shadow_opacity": 55,
                  "shadow_angle": 120, "shadow_distance": max(1, int(cfg["badge_font_size"]) // 16),
                  "shadow_size": max(1, int(cfg["badge_font_size"]) // 14)}
    text_rgb = _hex(cfg["badge_text_rgb"])
    out, warnings = [], list(data["warnings"])
    pages = page_list(data, cfg)
    if every:
        pass                                          # the Canvas: every page, on or off
    elif counts is not None:
        wanted = {int(c) for c in counts}
        pages = [p for p in pages if p["count"] in wanted]
    else:
        if pages and not any(p["on"] for p in pages):
            warnings.append(f'"{data["sheet"]}": every payline page is switched off in Paylines — none built.')
        pages = [p for p in pages if p["on"]]
    sink = getattr(pb._LINE_SINK, "rec", None)          # the Canvas's line sink (paylines_layout.py)
    gw, gh = grid_size(cfg, reels, rows)
    for p in pages:
        label, count, name = p["denoms"], p["count"], p["name"]
        sunk_from = len(sink["lines"]) if sink is not None else 0
        page, draw, _hb = draw_page(name, count)
        if isinstance(meta, dict):
            meta["heading_bottom"] = _hb
        pos, warn = layout(count, cfg, canvas_w, canvas_h, reels, rows)
        if warn:
            warnings.append(f"{name}: {warn}")
        bw, bh = int(cfg["badge_w"]), int(cfg["badge_h"])
        if isinstance(meta, dict):
            cols = max(1, min(int(cfg["columns"]), count))
            meta.setdefault("pages", []).append(dict(
                p, heading_bottom=_hb, sunk_from=sunk_from, warning=warn, block=block_box(count, cfg, canvas_w, canvas_h, reels, rows),
                cols=cols, nrows=-(-count // cols), grid_w=gw, grid_h=gh,
                lines=[{"n": n, "grid": [x, y, gw, gh], "badge": [x + int(cfg["badge_dx"]), y + int(cfg["badge_dy"]), bw, bh]}
                       for n, (x, y) in zip(line_numbers(data, count), pos)]))
        for n, (x, y) in zip(line_numbers(data, count), pos):
            group = f"Line {n}"
            rgb = line_rgb(n, cfg)
            bx, by = x + int(cfg["badge_dx"]), y + int(cfg["badge_dy"])
            # bottom to top: grid, highlighted cells, badge, number
            layers = [(grid, x, y, f"Line {n} grid"),
                      (highlight_image(data["lines"][n], rgb, cfg, reels, rows), x, y, f"Line {n} cells"),
                      (badge_image(badge_rgb(n, cfg), cfg), bx, by, f"Line {n} badge")]
            for img, lx, ly, lname in layers:
                if not pb._psd_shape(page, img, lx, ly, lname, group=group):
                    page.alpha_composite(img, (int(lx), int(ly)))
            # PSD shapes are listed top first
            _reorder_last_shapes(page, 3)
            text = str(n)
            box = pb._text_bbox(draw, text, num_font)
            th = box[3] - box[1]
            ty = by + (bh - th) / 2.0 - box[1] + int(cfg.get("badge_text_dy") or 0)
            # drawn even for the Canvas's picture (its numbers are part of the lines it shows as built)
            with tagged_texts(page, f"Line {n} number", group), pb._sink_ctx(kind="number", line=n, draw=True):
                pb._draw_inline(page, draw, Image, text, bx, ty, num_font, text_rgb, bw, "", {}, int(cfg["badge_font_size"]),
                                None, align="center", line_spacing=0, fx_config=num_fx, strips=False,
                                font_request=cfg["badge_font"], font_size=int(cfg["badge_font_size"]), bold=True)
        out.append((name, page))
    return out, warnings


class tagged_texts:
    """Name/group the text layers drawn inside the block (PSD builds; no-op for PNGs)."""

    def __init__(self, page, name, group=None):
        from ..psd_writer import recorder

        self.rec_page = recorder.page_for(page)
        self.name, self.group = name, group

    def __enter__(self):
        self.start = len(self.rec_page.texts) if self.rec_page is not None else 0
        return self

    def __exit__(self, *exc):
        if self.rec_page is not None:
            for record in list(self.rec_page.texts)[self.start:]:
                record.name = self.name
                if self.group:
                    record.group = self.group
        return False


def _reorder_last_shapes(page, k):
    """The last k recorded shapes were added bottom-first; PSD lists shapes top-first."""
    from ..psd_writer import recorder

    rec_page = recorder.page_for(page)
    if rec_page is None:
        return
    shapes = rec_page.shapes
    target = getattr(shapes, "_target", None)
    lst = target if isinstance(target, list) else shapes
    if isinstance(lst, list) and len(lst) >= k:
        lst[-k:] = list(reversed(lst[-k:]))
