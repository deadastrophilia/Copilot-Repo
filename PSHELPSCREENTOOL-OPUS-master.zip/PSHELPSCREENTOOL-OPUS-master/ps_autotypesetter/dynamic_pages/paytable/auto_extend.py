"""Shared helper for rendering MORE sheet cards than a template defines.

Templates like ``Default-10-icon.json`` ship exactly 10 card slots, but a
paytable sheet can have fewer or more symbols. Fewer cards already work:
the renderers simply draw the cards whose slots matched and leave the rest
empty. For MORE cards this module clones the last matched card slot (its
box plus sub-slots such as ``.pay`` / ``.value`` / ``.icon``) downward,
once per extra card, and registers every alias the renderer searches
(``pic<N>``, ``symbol.<M>``, ``low.<N>``, ...) so every parsed card renders.

The module stays free of Photoshop/PIL imports so it can be unit-tested
without a PSD runtime.
"""


def auto_extend_card_slots(slots, page_data, find_box, card_aliases,
                           card_type="lower", settings=None,
                           canvas_height=None, top_count=0):
    """Extend ``slots`` so every parsed card of ``card_type`` has a box.

    ``slots`` is a dict of name -> box (``x``/``y``/``w``/``h``). Cards
    that match a template slot anchor the layout: the last matched card's
    cluster (base box + its dotted sub-slots) is cloned below itself for
    each unmatched card and stored under every finder-searchable alias.

    ``find_box(slots, card, index, top_count)`` returns the existing box
    for a card (or None); ``card_aliases(card, index, card_type, top_count)``
    returns the casefolded names the renderer will search for that card.

    Mutates ``slots`` in place; returns the number of entries added.
    """
    cards = list(page_data.get(card_type + "_cards") or [])
    if not cards:
        return 0

    settings = settings or {}
    slot_keys = {str(key).casefold() for key in (slots or {})}
    anchor_key = None
    anchor_box = None
    cluster = None
    row_top = 0.0
    row_h = 0.0
    row_pitch = None
    next_row_top = None
    added = 0

    def _is_card_base_name(name):
        for prefix in ("pic", "low", "lower", "bottom", "top"):
            if name.startswith(prefix) and name[len(prefix):].isdigit():
                return True
        if name.startswith("symbol"):
            rest = name[len("symbol"):]
            if rest.isdigit():
                return True
            if rest.startswith(".") and rest[1:].isdigit():
                return True
        return False

    def _build_cluster():
        nonlocal cluster, row_top, row_h, row_pitch
        base_prefix = anchor_key + "."
        members = [(anchor_key, anchor_box)]
        for name in slot_keys:
            if name.startswith(base_prefix):
                members.append((name, slots[name]))
        tops = [float(box["y"]) for _, box in members]
        bottoms = [float(box["y"]) + float(box["h"]) for _, box in members]
        row_top = min(tops)
        row_h = max(bottoms) - row_top
        # Reuse the template's own row rhythm (gap between the anchor row and
        # the row directly above it) when visible; otherwise stack flush.
        explicit_gap = settings.get("extra_card_gap_v") is not None
        if not explicit_gap:
            prev_top = None
            for name, box in (slots or {}).items():
                bare = str(name).casefold()
                if not _is_card_base_name(bare):
                    continue
                y_top = float(box["y"])
                if y_top < row_top - 0.5 and (prev_top is None or y_top > prev_top):
                    prev_top = y_top
            if prev_top is not None:
                row_pitch = round(row_top - prev_top, 6)
        if row_pitch is None:
            row_pitch = row_h + max(0, int(float(settings.get("extra_card_gap_v", 0))))
        cluster = members

    for index, card in enumerate(cards, start=1):
        box = find_box(slots, card, index, top_count)
        if box is not None:
            best_key, best_box, best_children = None, None, -1
            for alias in card_aliases(card, index, card_type, top_count):
                key = str(alias).casefold()
                if key in slot_keys:
                    children = sum(1 for name in slot_keys if name.startswith(key + "."))
                    if children > best_children:
                        best_key, best_box, best_children = key, slots[key], children
            if best_key is not None:
                anchor_key, anchor_box = best_key, best_box
            cluster = None
            continue
        if anchor_key is None or anchor_box is None:
            continue
        if cluster is None:
            _build_cluster()
        if next_row_top is None:
            next_row_top = row_top + row_pitch
        if canvas_height is not None and next_row_top + row_h > float(canvas_height):
            break
        for name, member in cluster:
            suffix = name[len(anchor_key):]  # "" for the base, ".pay" etc.
            shifted = {
                "x": member["x"],
                "y": float(member["y"]) - row_top + next_row_top,
                "w": member["w"],
                "h": member["h"],
            }
            for alias in card_aliases(card, index, card_type, top_count):
                key = str(alias).casefold() + suffix
                if key not in slot_keys:
                    slots[key] = shifted
                    slot_keys.add(key)
                    added += 1
        next_row_top += row_pitch
    return added