"""Resolve JSON paytable text-flow regions from Excel ranges.

Templates can opt in with either slot names such as ``FLOW|B5:O6`` and
``TEXT|PT_GENERAL_RULES`` or a top-level ``flow_regions`` collection.  Sources
may be direct cell ranges or workbook/worksheet defined names.  Existing
paytable templates do not use this module and remain on the legacy path.
"""

import re

from openpyxl.utils.cell import range_boundaries

from ...table_mapping import _cell_value


_FLOW_SLOT = re.compile(r"^\s*(FLOW|TEXT)\s*\|\s*(.+?)\s*$", re.IGNORECASE)
_DIRECT_RANGE = re.compile(
    r"^\s*(?:(?:'((?:[^']|'')+)'|([^!]+))!)?"
    r"(\$?[A-Z]{1,3}\$?\d+(?::\$?[A-Z]{1,3}\$?\d+)?)\s*$",
    re.IGNORECASE,
)
_TOKEN = re.compile(r"<\s*([^>]+?)\s*>")


def _text(value):
    return "" if value is None else str(value).strip()


def _find_sheet(workbook, name, fallback):
    if not name:
        return fallback
    wanted = str(name).replace("''", "'").casefold()
    for sheet_name in workbook.sheetnames:
        if str(sheet_name).casefold() == wanted:
            return workbook[sheet_name]
    return None


def _defined_name(container, name):
    if container is None:
        return None
    try:
        direct = container.get(name)
        if direct is not None:
            return direct
    except Exception:
        pass
    try:
        wanted = str(name).casefold()
        for key in container.keys():
            if str(key).casefold() == wanted:
                return container[key]
    except Exception:
        pass
    return None


def _named_destinations(ws, name):
    """Return ``(sheet, range)`` pairs for local or workbook names."""
    workbook = ws.parent
    definitions = []
    local = _defined_name(getattr(ws, "defined_names", None), name)
    global_name = _defined_name(getattr(workbook, "defined_names", None), name)
    for definition in (local, global_name):
        if definition is not None and definition not in definitions:
            definitions.append(definition)

    destinations = []
    for definition in definitions:
        try:
            pairs = list(definition.destinations)
        except Exception:
            pairs = []
        for sheet_name, coordinate in pairs:
            target_sheet = _find_sheet(workbook, sheet_name, ws)
            if target_sheet is not None and coordinate:
                destinations.append((target_sheet, str(coordinate)))
    return destinations


def _direct_destination(ws, source):
    match = _DIRECT_RANGE.fullmatch(str(source or ""))
    if not match:
        return None
    sheet_name = match.group(1) or match.group(2)
    target_sheet = _find_sheet(ws.parent, sheet_name, ws)
    if target_sheet is None:
        return None
    return target_sheet, match.group(3)


def _range_blocks(target_ws, coordinate, preserve_rows=True, split_cell_lines=True):
    coordinate = str(coordinate).replace("$", "")
    min_col, min_row, max_col, max_row = range_boundaries(coordinate)
    rows = []
    for row_number in range(min_row, max_row + 1):
        parts = []
        for col_number in range(min_col, max_col + 1):
            value = _text(_cell_value(target_ws, row_number, col_number))
            if value:
                parts.append(value)
        row_text = " ".join(parts).strip()
        if not row_text:
            continue
        line_parts = row_text.replace("\r\n", "\n").replace("\r", "\n").split("\n") if split_cell_lines else [row_text]
        for line in line_parts:
            line = line.strip()
            if line:
                rows.append({
                    "text": line,
                    "sheet": target_ws.title,
                    "range": coordinate,
                    "source_row": row_number,
                })

    if preserve_rows or not rows:
        return rows
    combined = " ".join(block["text"] for block in rows).strip()
    if not combined:
        return []
    first = rows[0]
    return [{
        "text": combined,
        "sheet": first["sheet"],
        "range": coordinate,
        "source_row": first["source_row"],
    }]


def resolve_source_blocks(ws, source, preserve_rows=True, split_cell_lines=True):
    """Resolve one direct range or defined name into ordered text blocks."""
    source = _text(source)
    if not source:
        return [], "Empty Excel flow source."

    direct = _direct_destination(ws, source)
    destinations = [direct] if direct else _named_destinations(ws, source)
    if not destinations:
        return [], f"Excel flow source not found: {source}"

    blocks = []
    for target_ws, coordinate in destinations:
        try:
            blocks.extend(_range_blocks(
                target_ws,
                coordinate,
                preserve_rows=preserve_rows,
                split_cell_lines=split_cell_lines,
            ))
        except Exception as exc:
            return [], f"Could not read Excel flow source {source}: {exc}"
    for block in blocks:
        block["source"] = source
    return blocks, ""


def _remove_token_indexes(text, indexes):
    indexes = {int(index) for index in (indexes or [])}
    if not indexes:
        return str(text or "")
    occurrence = -1

    def replace(match):
        nonlocal occurrence
        occurrence += 1
        return "" if occurrence in indexes else match.group(0)

    cleaned = _TOKEN.sub(replace, str(text or ""))
    cleaned = re.sub(r"\s+([,.;:!?])", r"\1", cleaned)
    cleaned = re.sub(r"^\s*(?:,|and\b|or\b|&)\s*", "", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"[ \t]+", " ", cleaned)
    return cleaned.strip()


def _remove_token_indexes_from_blocks(blocks, indexes):
    indexes = {int(index) for index in (indexes or [])}
    if not indexes:
        return blocks
    occurrence = -1

    def replace(match):
        nonlocal occurrence
        occurrence += 1
        return "" if occurrence in indexes else match.group(0)

    for block in blocks:
        cleaned = _TOKEN.sub(replace, str(block.get("text", "")))
        cleaned = re.sub(r"\s+([,.;:!?])", r"\1", cleaned)
        cleaned = re.sub(r"^\s*(?:,|and\b|or\b|&)\s*", "", cleaned, flags=re.IGNORECASE)
        block["text"] = re.sub(r"[ \t]+", " ", cleaned).strip()
    return blocks


def _prepare_inline_token_metadata(blocks, excluded_indexes=None, icon_heights=None):
    """Remove dedicated tokens and preserve per-occurrence inline icon heights."""
    excluded_indexes = {int(index) for index in (excluded_indexes or [])}
    icon_heights = {
        int(index): int(height)
        for index, height in (icon_heights or {}).items()
        if int(height or 0) > 0
    }
    occurrence = -1
    for block in blocks:
        kept_occurrence = -1
        block_heights = {}

        def replace(match):
            nonlocal occurrence, kept_occurrence
            occurrence += 1
            if occurrence in excluded_indexes:
                return ""
            kept_occurrence += 1
            if occurrence in icon_heights:
                block_heights[kept_occurrence] = icon_heights[occurrence]
            return match.group(0)

        cleaned = _TOKEN.sub(replace, str(block.get("text", "")))
        cleaned = re.sub(r"\s+([,.;:!?])", r"\1", cleaned)
        cleaned = re.sub(r"^\s*(?:,|and\b|or\b|&)\s*", "", cleaned, flags=re.IGNORECASE)
        block["text"] = re.sub(r"[ \t]+", " ", cleaned).strip()
        if block_heights:
            block["inline_icon_heights"] = block_heights
    return blocks


def resolve_token_binding(ws, binding):
    source = _text(binding.get("source"))
    blocks, warning = resolve_source_blocks(ws, source, preserve_rows=True)
    if warning:
        return None, warning
    combined = " ".join(block.get("text", "") for block in blocks)
    tokens = [token.strip() for token in _TOKEN.findall(combined)]
    try:
        token_index = int(binding.get("token_index", 0))
    except Exception:
        token_index = 0
    if token_index < 0 or token_index >= len(tokens):
        if not tokens and combined:
            # Fallback: use the full plain text as the token value
            resolved = dict(binding)
            resolved["source"] = source
            resolved["token_index"] = token_index
            resolved["token"] = combined.split()[0] if combined.split() else combined
            return resolved, ""
        return None, f"Token #{token_index + 1} was not found in Excel source {source}."
    resolved = dict(binding)
    resolved["source"] = source
    resolved["token_index"] = token_index
    resolved["token"] = tokens[token_index]
    return resolved, ""


def extract_token_bindings(ws, template):
    bindings = []
    warnings = []
    for index, raw in enumerate(template.get("token_bindings") or [], start=1):
        if not isinstance(raw, dict):
            continue
        resolved, warning = resolve_token_binding(ws, raw)
        if resolved:
            resolved.setdefault("id", f"token_binding_{index}")
            bindings.append(resolved)
        if warning:
            warnings.append(f"token_binding_{index}: {warning}")
    return bindings, warnings


def parse_flow_slot_name(slot_name):
    """Convert ``FLOW|source`` or ``TEXT|source`` into a region specification."""
    match = _FLOW_SLOT.fullmatch(str(slot_name or ""))
    if not match:
        return None
    prefix, source = match.groups()
    return {
        "id": str(slot_name),
        "slot": str(slot_name),
        "sources": [source.strip()],
        "render_mode": "inline_flow" if prefix.upper() == "FLOW" else "text",
        "preserve_rows": True,
    }


def _configured_regions(template):
    configured = template.get("flow_regions") or []
    if isinstance(configured, dict):
        items = []
        for region_id, value in configured.items():
            if isinstance(value, dict):
                spec = dict(value)
            else:
                spec = {"sources": value}
            spec.setdefault("id", str(region_id))
            spec.setdefault("slot", str(region_id))
            items.append(spec)
        return items
    if isinstance(configured, list):
        return [dict(value) for value in configured if isinstance(value, dict)]
    return []


def template_flow_specs(template):
    """Return normalized configured and layer-name flow specifications."""
    specs = []
    used_slots = set()

    for index, raw in enumerate(_configured_regions(template), start=1):
        spec = dict(raw)
        region_id = _text(spec.get("id")) or f"flow_region_{index}"
        slot = _text(spec.get("slot")) or region_id
        sources = spec.get("sources", spec.get("source", []))
        if isinstance(sources, str):
            sources = [sources]
        elif not isinstance(sources, (list, tuple)):
            sources = []
        spec.update({
            "id": region_id,
            "slot": slot,
            "sources": list(sources),
            "render_mode": _text(spec.get("render_mode")) or "inline_flow",
        })
        specs.append(spec)
        used_slots.add(slot.casefold())

    slots_raw = template.get("slots") or {}
    if isinstance(slots_raw, list):
        slot_names = [s.get("id", "") for s in slots_raw if isinstance(s, dict)]
    elif isinstance(slots_raw, dict):
        slot_names = list(slots_raw.keys())
    else:
        slot_names = []
    for slot_name in slot_names:
        parsed = parse_flow_slot_name(slot_name)
        if parsed and parsed["slot"].casefold() not in used_slots:
            specs.append(parsed)
            used_slots.add(parsed["slot"].casefold())
    return specs


def extract_flow_regions(ws, template):
    """Resolve every template flow region against the current worksheet."""
    regions = []
    warnings = []
    automatic_exclusions = {}
    for binding in template.get("token_bindings") or []:
        if not isinstance(binding, dict):
            continue
        source = _text(binding.get("source")).casefold()
        try:
            token_index = int(binding.get("token_index", 0))
        except Exception:
            token_index = 0
        if source:
            automatic_exclusions.setdefault(source, set()).add(token_index)

    inline_overrides = {}
    for override in template.get("inline_icon_overrides") or []:
        if not isinstance(override, dict):
            continue
        source = _text(override.get("source")).casefold()
        slot = _text(override.get("slot")).casefold()
        try:
            token_index = int(override.get("token_index", 0))
            icon_height = int(override.get("icon_height", 0))
        except Exception:
            continue
        if source and slot and icon_height > 0:
            inline_overrides.setdefault((slot, source), {})[token_index] = icon_height

    for spec in template_flow_specs(template):
        preserve_rows = bool(spec.get("preserve_rows", True))
        split_cell_lines = bool(spec.get("split_cell_lines", True))
        blocks = []
        for source in spec.get("sources", []):
            source_ref = source.get("source") if isinstance(source, dict) else source
            source_blocks, warning = resolve_source_blocks(
                ws,
                source_ref,
                preserve_rows=preserve_rows,
                split_cell_lines=split_cell_lines,
            )
            explicit_exclusions = source.get("exclude_token_indexes", []) if isinstance(source, dict) else []
            excluded_indexes = set(explicit_exclusions)
            excluded_indexes.update(automatic_exclusions.get(_text(source_ref).casefold(), set()))
            source_icon_heights = inline_overrides.get(
                (_text(spec.get("slot")).casefold(), _text(source_ref).casefold()),
                {},
            )
            if excluded_indexes or source_icon_heights:
                _prepare_inline_token_metadata(
                    source_blocks,
                    excluded_indexes=excluded_indexes,
                    icon_heights=source_icon_heights,
                )
            blocks.extend(source_blocks)
            if warning and bool(spec.get("required", True)):
                warnings.append(f"{spec['id']}: {warning}")

        region = dict(spec)
        region["blocks"] = blocks
        regions.append(region)
        if not blocks and bool(spec.get("required", True)):
            warnings.append(f"{spec['id']}: no renderable text was found.")
    return regions, warnings
