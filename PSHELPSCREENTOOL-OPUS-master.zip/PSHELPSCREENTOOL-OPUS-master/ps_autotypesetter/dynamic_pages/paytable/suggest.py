"""Suggested paytable layouts — the game's own design first, then rule-made variants of it, scored.

A variant changes only how the cards are arranged: the tiers (premium symbols in the high row, card
ranks in the low row, the Excel's order kept — pay_reader.tiers), cards across per row, and whether
symbols with the same pays share a card. Its look (colours, fonts, boxes) is the design's own.

Every candidate is laid out for real (``lay_out(template)`` → engine_api.auto_map_page's dry-run
result) and scored on what an artist would judge:
  fit      the cards drawn at their size (1.0) or shrunk to fit the page (less)
  rows     rows filled — no lone card on a last row
  premium  the premium cards at least as big as the low ones
The best three come back; the game's own design is always shown first, with its score.
"""
from __future__ import annotations

import copy
import math

from . import pay_reader


def _counts(read):
    tier = pay_reader.tiers(read)
    hi = [s for s in read.get("symbols") or [] if tier.get(pay_reader.key_of(s["symbol"])) == "premium"]
    lo = [s for s in read.get("symbols") or [] if tier.get(pay_reader.key_of(s["symbol"])) == "low"]
    runs = pay_reader.same_pays(read)
    low_keys = {pay_reader.key_of(s["symbol"]) for s in lo}
    merged = sum(len(r) - 1 for r in runs if all(k in low_keys for k in r))
    return len(hi), len(lo), len(lo) - merged


def _per_rows(n):
    """Cards across worth trying for a row of n cards: one line when it fits, else even splits."""
    if n <= 0:
        return []
    out = {min(n, 6)} if n <= 6 else set()
    for per in (3, 4, 5, 6):
        if per < n and (n % per == 0 or n % per >= per - 1):
            out.add(per)
    return sorted(out)[:3] or [min(n, 5)]


def score(result, n_hi, n_lo, hp=0, lp=0):
    """0..1 from a dry-run layout (hp / lp: cards across in the high / low row): (score, fit, why)."""
    meta = ((result or {}).get("_template") or {}).get("mapper_meta") or {}
    geo = meta.get("band_geo") or {}
    fit = float(meta.get("fit") or min([float(v.get("fit") or 1) for v in geo.values()] or [1.0]))
    hi, lo = geo.get("high") or {}, geo.get("low") or {}

    def fill(n, per):
        per = int(per or 0)
        if not n or not per:
            return 1.0
        last = n % per or per
        return last / per

    rows = (fill(n_hi, hp) + fill(n_lo, lp)) / 2.0
    hs = [float((b.get("size") or [0, 0])[1]) * float(b.get("fit") or 1) for b in (hi, lo)]
    premium = 1.0 if not hs[1] or hs[0] >= hs[1] * 1.05 else 0.6
    overflow = len((result or {}).get("overflow") or [])
    big = min(1.0, min([h for h in hs if h] or [0]) / 180.0)        # the smallest card's height: easier to read
    total = max(0.0, 0.5 * min(1.0, fit) + 0.25 * rows + 0.15 * premium + 0.1 * big - 0.1 * overflow)
    why = []
    why.append("cards at full size" if fit >= 0.99 else f"cards shrunk to {round(fit * 100)}%")
    why.append("rows full" if rows >= 0.99 else "a short last row")
    if overflow:
        why.append(f"{overflow} number box{'es' if overflow > 1 else ''} too small")
    return round(total, 3), round(fit, 3), ", ".join(why)


def suggest(base, read, lay_out, own=True, limit=3):
    """The game's design (``own``: it has one) and the best rule-made variants of ``base``:
    [{template, label, why, score, fit, own}] — the own design first, then by score."""
    n_hi, n_lo, n_lo_shared = _counts(read)
    can_share = n_lo_shared < n_lo
    out = []
    if own:
        res = lay_out(base)
        per = [int((b or {}).get("per_row") or 0) for b in (base.get("bands") or [])[:2]] + [0, 0]
        sc, fit, why = score(res, n_hi, n_lo, per[0], per[1])
        out.append({"template": base, "label": "Your design as it is", "why": why, "score": sc, "fit": fit, "own": True})
    seen = set()
    tried = []
    for share in ([False, "low"] if can_share else [False]):
        n_low = n_lo_shared if share else n_lo
        for hp in _per_rows(n_hi) or [5]:
            for lp in _per_rows(n_low) or [5]:
                key = (share, hp, lp)
                if key in seen:
                    continue
                seen.add(key)
                t = copy.deepcopy(base)
                t["tiers"] = "auto"
                bands = t.setdefault("bands", [{"name": "high"}, {"name": "low"}])
                while len(bands) < 2:
                    bands.append(copy.deepcopy(bands[-1]))
                for b, per in ((bands[0], hp), (bands[1], lp)):
                    b["per_row"] = per
                    for k in ("card_w", "pos", "lock_size"):            # rule-made: the rows fill the page again
                        b.pop(k, None)
                t.setdefault("card", {})["group_same_pays"] = share or False
                t.pop("edited", None)
                res = lay_out(t)
                if not res or not res.get("ok"):
                    continue
                sc, fit, why = score(res, n_hi, n_low, hp, lp)
                label = f"Premium {hp} across · low {lp} across" + (" · same pays share a card" if share else "")
                tried.append({"template": t, "label": label, "why": why, "score": sc, "fit": fit, "own": False})
    # the best, then the best of the other kind (sharing cards or not), then the next best
    tried.sort(key=lambda c: -c["score"])
    picks = []
    for c in tried:
        if len(picks) >= limit - len(out):
            break
        if len(picks) == 1 and any(x["template"]["card"].get("group_same_pays") != picks[0]["template"]["card"].get("group_same_pays") for x in tried):
            other = next(x for x in tried if x["template"]["card"].get("group_same_pays") != picks[0]["template"]["card"].get("group_same_pays"))
            if other not in picks:
                picks.append(other)
                continue
        if c not in picks:
            picks.append(c)
    out.extend(picks)
    return out



def suggest_archetypes(read, lay_out, limit=5):
    """Evaluate all built-in dynamic templates against ``read`` via ``lay_out(t)`` and return the
    highest-scoring distinct structural designs: [{template, id, label, why, score, fit}]."""
    from . import card_templates as ct

    n_hi, n_lo, n_lo_shared = _counts(read)
    candidates = []
    for meta in ct.list_templates():
        if not meta.get("builtin") or meta.get("id") == "fomo_mummy":
            continue
        t = ct.get_template(meta["id"])
        if not t:
            continue
        res = lay_out(t)
        if not res or not res.get("ok"):
            continue
        bands = (t.get("bands") or [])[:2]
        hp = int((bands[0] if len(bands) > 0 else {}).get("per_row") or n_hi or 5)
        lp = int((bands[1] if len(bands) > 1 else {}).get("per_row") or n_lo or 5)
        share = bool((t.get("card") or {}).get("group_same_pays"))
        sc, fit, why = score(res, n_hi, n_lo_shared if share else n_lo, hp, lp)
        candidates.append({
            "id": meta["id"],
            "template": t,
            "label": meta.get("name") or meta["id"],
            "why": why,
            "score": sc,
            "fit": fit,
            "own": False,
        })
    candidates.sort(key=lambda c: -c["score"])
    return candidates[:limit]
