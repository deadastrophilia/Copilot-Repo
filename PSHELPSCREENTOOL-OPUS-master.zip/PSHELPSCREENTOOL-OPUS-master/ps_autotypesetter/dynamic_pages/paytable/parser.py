"""Parse paytable worksheets without modifying Excel.

V42 notes:
- Treat Excel as data only; ignore right-side artist/meta notes by default.
- Do not join far-right cells into the title.
- Classify lower symbols by label (A/K/Q/J/10 etc.) even when written as <A>.
- Extract feature/special-symbol text generically instead of hard-coding WILD.
"""

import re

from .flow_sources import extract_flow_regions, extract_token_bindings
from ...table_mapping import _cell_value


_ANGLE_ONLY = re.compile(r"^\s*<\s*([^>]+?)\s*>\s*$")
_NUMBER = re.compile(r"^\d+(?:,\d{3})*(?:\.\d+)?$")
_TOKEN = re.compile(r"<\s*([^>]+?)\s*>")

# Most client paytable data lives in the left/middle part of the sheet.
# Far-right cells are often artist notes like "NOTE <BO>..." or brand comments;
# those should not become rendered help-screen text.
_DEFAULT_MAIN_TEXT_COL_LIMIT = 12
_META_HINTS = (
    "note <bo>", "<initial mod", "initial mod", "brand per agreement",
    "do not need", "don't need", "dont need",
)
_LOW_SYMBOL_KEYS = {
    "a", "ace", "k", "king", "q", "queen", "j", "jack",
    "10", "ten", "9", "nine", "8", "eight", "7", "seven",
}
_FEATURE_TOKEN_HINTS = (
    "wild", "scatter", "bonus", "feature", "collect", "multiplier", "free", "spin",
)


def _text(value):
    return "" if value is None else str(value).strip()


def _is_number(value):
    return bool(_NUMBER.fullmatch(_text(value)))


def _cell_color(cell):
    try:
        color = cell.font.color
        if color and color.type == "rgb" and color.rgb:
            value = str(color.rgb)
            if len(value) == 8:
                value = value[2:]
            if len(value) == 6:
                return tuple(int(value[i:i + 2], 16) for i in (0, 2, 4))
    except Exception:
        pass
    return None


def _normalize_key(value):
    value = _text(value).strip("<>")
    value = re.sub(r"[^A-Za-z0-9]+", "", value).lower()
    word_numbers = {
        "10": "ten", "9": "nine", "8": "eight", "7": "seven",
        "6": "six", "5": "five", "4": "four", "3": "three", "2": "two",
    }
    return word_numbers.get(value, value)


def _collect_cells(ws):
    cells = []
    for row in ws.iter_rows():
        for cell in row:
            if getattr(cell, "row", None) is None or getattr(cell, "column", None) is None:
                continue
            value = _text(_cell_value(ws, cell.row, cell.column))
            if not value:
                continue
            cells.append({
                "row": cell.row,
                "col": cell.column,
                "text": value,
                "bold": bool(cell.font.bold) if cell.font else False,
                "color": _cell_color(cell),
            })
    return cells


def _is_meta_text(text):
    lower = _text(text).casefold()
    return any(hint in lower for hint in _META_HINTS)


def _pick_title(cells):
    """Pick only the real paytable title, not all text from that Excel row.

    Earlier versions joined every non-numeric cell in the title row. If row 3
    also contained far-right production notes like "Game Name with BRAND...",
    those were appended to the title. This now prefers the left/middle cell that
    contains PAYTABLE and ignores far-right/meta cells.
    """
    candidates = []
    for item in cells:
        text = item["text"]
        if _is_number(text) or _is_meta_text(text):
            continue
        lower = text.casefold()
        score = 0
        if "paytable" in lower:
            score += 1000
        if item["bold"]:
            score += 80
        if item["col"] <= _DEFAULT_MAIN_TEXT_COL_LIMIT:
            score += 50
        # Prefer upper and left cells.
        score -= item["row"] * 4
        score -= item["col"]
        candidates.append((score, item))
    if candidates:
        candidates.sort(key=lambda pair: (-pair[0], pair[1]["row"], pair[1]["col"]))
        chosen = candidates[0][1]
        return chosen["text"], chosen["row"]

    # Fallback: first non-numeric cell.
    for item in sorted(cells, key=lambda x: (x["row"], x["col"])):
        if not _is_number(item["text"]):
            return item["text"], item["row"]
    return "Paytable", 1


def _candidate_labels(cells, title_row):
    """Find symbol labels in the data area.

    A standalone <anything> can be either a top picture symbol or a lower symbol
    like <A>. The final top/lower classification happens later from the label.
    """
    candidates = []
    for item in cells:
        if item["row"] <= title_row + 2 or item["col"] > 5:
            continue
        text = item["text"]
        match = _ANGLE_ONLY.fullmatch(text)
        if match:
            label = match.group(1).strip()
            candidates.append({**item, "label": label, "angle": True, "slot_key": _normalize_key(label)})
            continue

        # Plain symbols. Numeric candidates are restricted to common low symbols.
        if _is_number(text):
            if text not in {"2", "3", "4", "5", "6", "7", "8", "9", "10"}:
                continue
            label = text
        elif re.fullmatch(r"[A-Za-z][A-Za-z0-9 _-]{0,30}", text):
            label = text
        else:
            continue
        candidates.append({**item, "label": label, "angle": False, "slot_key": _normalize_key(label)})

    candidates.sort(key=lambda item: (item["row"], item["col"]))
    return candidates


def _numeric_rows(cells):
    rows = {}
    for item in cells:
        if _is_number(item["text"]):
            rows.setdefault(item["row"], []).append(item)
    for row in rows.values():
        row.sort(key=lambda item: item["col"])
    return rows


def _extract_payouts(candidate, previous_candidate, next_candidate, numeric_rows):
    # First payout is commonly exactly one row above the symbol label.
    start = candidate["row"] - 1
    upper_bound = (next_candidate["row"] - 2) if next_candidate else candidate["row"] + 5
    end = min(candidate["row"] + 5, upper_bound)

    payouts = []
    for row_number in range(start, end + 1):
        numbers = [item for item in numeric_rows.get(row_number, []) if item["col"] > candidate["col"]]
        if len(numbers) < 2:
            continue
        count_cell = numbers[0]
        value_cell = numbers[-1]
        count = count_cell["text"]
        value = value_cell["text"]
        if count == value:
            continue
        payouts.append({
            "count": count,
            "value": value,
            "count_color": count_cell.get("color"),
            "value_color": value_cell.get("color"),
            "source_row": row_number,
        })
    return payouts


def _main_text_col_limit(cells):
    # Keep the limit stable and predictable for now. This avoids rendering
    # production notes from far-right columns like P/S, while preserving the
    # normal text/payout data in B-H.
    return _DEFAULT_MAIN_TEXT_COL_LIMIT


def _intro_lines(cells, title_row, first_card_row):
    rows = {}
    col_limit = _main_text_col_limit(cells)
    for item in cells:
        if not (title_row < item["row"] < first_card_row):
            continue
        if item["col"] > col_limit:
            continue
        if _is_meta_text(item["text"]):
            continue
        rows.setdefault(item["row"], []).append(item)
    lines = []
    for row_number in sorted(rows):
        row = sorted(rows[row_number], key=lambda item: item["col"])
        parts = []
        for item in row:
            text = item["text"].strip()
            if not text or _is_number(text):
                continue
            parts.append(text)
        line = " ".join(parts).strip()
        if line and not _is_meta_text(line):
            lines.append(line)
    return lines


def _tokens(line):
    return [token.strip() for token in _TOKEN.findall(line or "")]


def _first_angle_token(line):
    tokens = _tokens(line)
    return tokens[0] if tokens else ""


def _feature_token_score(token):
    lower = _normalize_key(token)
    score = 0
    for hint in _FEATURE_TOKEN_HINTS:
        if hint in lower:
            score += 10
    return score


def _add_unique(out, token):
    token = _text(token).strip("<>")
    if not token:
        return
    seen = {_normalize_key(x) for x in out}
    if _normalize_key(token) not in seen:
        out.append(token)


def _classify_side_text(lines):
    substitution = ""
    reels_lines = []
    feature_lines = []
    notes = []
    main_tokens = []

    for line in lines:
        lower = line.casefold()
        toks = _tokens(line)

        if "substitut" in lower:
            substitution = line
            if toks:
                _add_unique(main_tokens, toks[0])
            feature_lines.append(line)
            continue

        if "appears on reel" in lower or "appears on reels" in lower:
            reels_lines.append(line)
            if toks:
                _add_unique(main_tokens, toks[0])
            feature_lines.append(line)
            continue

        # Lines that mention WILD/SCATTER/BONUS-style symbols can still define
        # the main feature icons, but they are usually explanatory notes.
        featureish_tokens = [token for token in toks if _feature_token_score(token) > 0]
        for token in featureish_tokens:
            _add_unique(main_tokens, token)
        notes.append(line)

    if substitution and substitution not in feature_lines:
        feature_lines.insert(0, substitution)
    wild_reels = reels_lines[0] if reels_lines else ""

    if not main_tokens:
        # Fallback: first token from reels/substitution, then first token from any line.
        fallback = _first_angle_token(wild_reels) or _first_angle_token(substitution)
        if not fallback:
            for line in lines:
                fallback = _first_angle_token(line)
                if fallback:
                    break
        _add_unique(main_tokens, fallback or "Wild")

    # Exception tokens are only the non-main tokens in a substitution line.
    excluded = []
    if substitution:
        for token in _tokens(substitution)[1:]:
            if _normalize_key(token) not in {_normalize_key(x) for x in main_tokens}:
                excluded.append(token)

    title_token = main_tokens[0] if main_tokens else "Wild"
    return {
        "substitution": substitution,
        "wild_reels": wild_reels,
        "feature_text_lines": feature_lines,
        "bottom_notes": notes,
        "excluded_tokens": excluded,
        "wild_token": title_token,
        "feature_tokens": main_tokens,
        "feature_title": re.sub(r"[_-]+", " ", str(title_token)).strip().upper() if title_token else "WILD",
    }


def _is_low_symbol_label(label):
    key = _normalize_key(label)
    return key in _LOW_SYMBOL_KEYS


def parse_paytable_sheet(ws, template=None):
    cells = _collect_cells(ws)
    title, title_row = _pick_title(cells)
    candidates = _candidate_labels(cells, title_row)
    numeric_rows = _numeric_rows(cells)

    cards = []
    for index, candidate in enumerate(candidates):
        previous_candidate = candidates[index - 1] if index else None
        next_candidate = candidates[index + 1] if index + 1 < len(candidates) else None
        payouts = _extract_payouts(candidate, previous_candidate, next_candidate, numeric_rows)
        if len(payouts) < 2:
            continue
        cards.append({
            "label": candidate["label"],
            "slot_key": candidate["slot_key"],
            "angle": candidate["angle"],
            "source_row": candidate["row"],
            "payouts": payouts,
        })

    # Classify by label, not by angle-brackets. Some workbooks use <A>, <K>,
    # <Q>, <J> for low symbols, so angle-only classification would put them in
    # the top-picture row incorrectly.
    top_cards = [card for card in cards if not _is_low_symbol_label(card["label"])]
    lower_cards = [card for card in cards if _is_low_symbol_label(card["label"])]

    first_card_row = min((card["source_row"] for card in cards), default=title_row + 1)
    intro = _intro_lines(cells, title_row, first_card_row - 2)
    side_panel = _classify_side_text(intro)

    # Bridge table_templates mappings into flow_regions/token_bindings so the
    # renderer receives mapped data even when the saved JSON was not run through
    # build_mapped_table_template (which does the same conversion at save time).
    enriched = dict(template or {})
    raw_tbindings = enriched.get("token_bindings") or []
    raw_fregions = enriched.get("flow_regions") or []
    tbindings = [b for b in (raw_tbindings if isinstance(raw_tbindings, (list, tuple)) else []) if isinstance(b, dict)]
    fregions = [r for r in (raw_fregions if isinstance(raw_fregions, (list, tuple)) else []) if isinstance(r, dict)]
    used_flow_slots = {str(r.get("slot") or "").casefold() for r in fregions}
    used_tbinding_slots = {str(b.get("slot") or "").casefold() for b in tbindings}
    for table_spec in (enriched.get("table_templates") or {}).values():
        if not isinstance(table_spec, dict):
            continue
        mappings_list = table_spec.get("mappings") or []
        if not isinstance(mappings_list, (list, tuple)):
            continue
        for mapping in mappings_list:
            if not isinstance(mapping, dict):
                continue
            kind = str(mapping.get("kind") or "").casefold()
            slot = str(mapping.get("slot") or "").strip()
            source = str(mapping.get("source") or "").strip()
            if not slot or not source:
                continue
            slot_key = slot.casefold()
            if kind in ("dedicated_icon", "icon"):
                if slot_key not in used_tbinding_slots:
                    tbindings.append({
                        "slot": slot,
                        "source": source,
                        "token_index": int(mapping.get("token_index", 0)),
                    })
                    used_tbinding_slots.add(slot_key)
            elif kind in ("text", "flow"):
                if slot_key not in used_flow_slots:
                    fregions.append({
                        "slot": slot,
                        "sources": [source],
                        "render_mode": "inline_flow" if kind == "flow" else "text",
                        "id": f"mapped.{slot}",
                    })
                    used_flow_slots.add(slot_key)
    enriched["token_bindings"] = tbindings
    enriched["flow_regions"] = fregions

    flow_regions, flow_warnings = extract_flow_regions(ws, enriched)
    token_bindings, token_warnings = extract_token_bindings(ws, enriched)

    return {
        "sheet_name": ws.title,
        "title": title,
        "intro_lines": intro,
        "top_cards": top_cards,
        "lower_cards": lower_cards,
        "side_panel": side_panel,
        "flow_regions": flow_regions,
        "token_bindings": token_bindings,
        "parser_summary": {
            "top_cards": len(top_cards),
            "lower_cards": len(lower_cards),
            "all_cards": [card["label"] for card in cards],
            "ignored_far_right_columns_after": _DEFAULT_MAIN_TEXT_COL_LIMIT,
            "flow_regions": len(flow_regions),
            "flow_warnings": flow_warnings + token_warnings,
            "token_bindings": len(token_bindings),
        },
    }
