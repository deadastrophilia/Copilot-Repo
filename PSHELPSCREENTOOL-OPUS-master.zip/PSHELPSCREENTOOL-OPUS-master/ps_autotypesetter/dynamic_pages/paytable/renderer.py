"""Photoshop renderer for a JSON-driven paytable page."""

import math
import os
import re
import json

import photoshop.api as ps

try:
    from PIL import Image
except Exception:
    Image = None

from ..template_loader import scale_template_slots
from .auto_extend import auto_extend_card_slots
from ...layer_styles import apply_heading_layer_style, apply_style_to_group_text_layers
from ...icon_mapping import resolve_icon_path
from ...build_profiler import GLOBAL as _PROFILER, timed as _timed
from ...text_icon_renderer import _px_to_pt, _measure_text_cached, _measure_text_jsx, premeasure_texts_batch, _doc_and_app_from, _text_fast_jsx, _measure_text_pil, _doc_anchor_jsx


_MEASURE_WIDTH_CACHE = {}
_MEASURE_LAYER_STATE = {}
_CONTROL_TEXT_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]+")
_GAME_NAME_HEADING_TOKEN_RE = re.compile(r"<\s*game[\s_-]*name\s*>", flags=re.IGNORECASE)

# Paytable _add_text JSX fast path: None = untested, True = works, False =
# permanently disabled for this run after a failure (falls back to COM).
_PAYTEXT_FAST_ENABLED = None

# Paytable batched creation: many text layers / asset placements are created
# in ONE JSX call each (per call-site batch, flushed before any style apply or
# bounds read). Disable with PSH_PAYTEXT_BATCH=0 / PSH_PAYASSET_BATCH=0.
_PAYTEXT_BATCH_ENABLED = os.environ.get("PSH_PAYTEXT_BATCH", "1") != "0"
_PAYASSET_BATCH_ENABLED = os.environ.get("PSH_PAYASSET_BATCH", "1") != "0"
_PAYASSET_BATCH = {}  # id(doc) -> {"app": app, "doc": doc, "specs": [...]}
_PAYASSET_BATCH_THRESHOLD = 4

# Mapped inline flow fast path: create ALL text units of a slot in ONE JSX
# (template + duplicate), measure all real widths from the same call, bucket
# the rows offline, then position everything in one finalize JSX. Falls back
# to the legacy per-unit loop on any failure. Disable with PSH_PAYFLOW_BATCH=0.
_FLOW_BATCH_ENABLED = os.environ.get("PSH_PAYFLOW_BATCH", "1") != "0"

# Mapped slot single-JSX create: OFF by default (renders like the 84s-era
# build: one COM create per mapped slot). Opt in with PSH_SLOT_FAST=1 — the
# JSX return protocol is still unverified (36/36 fails in earlier builds),
# so experiments log the raw result into build_report.json for diagnosis.
_MAPPED_SLOT_FAST_ENABLED = os.environ.get("PSH_SLOT_FAST", "0") not in ("0", "false", "False")


def _flush_paytable_batches(app, doc):
    """Create any still-pending batched assets (page-end dump)."""
    if not _PAYASSET_BATCH_ENABLED:
        return
    _payasset_batch_flush(app, doc, force=True)


def _payasset_batch_flush(app, doc, force=False):
    state = _PAYASSET_BATCH.pop(id(doc), None)
    if not state:
        return
    if not force and len(state["specs"]) < _PAYASSET_BATCH_THRESHOLD:
        _PAYASSET_BATCH[id(doc)] = state
        return
    specs = state["specs"]
    _PROFILER.inc("paytable_asset_places", len(specs))
    jsx_parts = [_doc_anchor_jsx(doc), "var __batch_res = [];", (
        "function __findSet(node, id) {\n"
        "    var sets = node.layerSets;\n"
        "    for (var i = 0; i < sets.length; i++) {\n"
        "        if (sets[i].id == id) return sets[i];\n"
        "        var hit = __findSet(sets[i], id);\n"
        "        if (hit) return hit;\n"
        "    }\n"
        "    return null;\n"
        "}\n"
    )]
    for spec in specs:
        safe_path = os.path.abspath(spec["path"]).replace("\\", "/").replace('"', '\\"')
        safe_name = json.dumps(str(spec["name"]))
        try:
            group_id = int(spec["group"].id)
        except Exception:
            group_id = None
        if group_id is None:
            bits = "var parent = doc;"
        else:
            bits = "var parent = __findSet(doc, " + str(group_id) + ");\nif (!parent) { __batch_res.push(false); return; }"
        t_w = float(spec["target_w"])
        t_h = float(spec["target_h"])
        b_x = float(spec["box_x"])
        b_y = float(spec["box_y"])
        b_w = float(spec["box_w"])
        b_h = float(spec["box_h"])
        jsx_parts.append(f"""
            (function(){{
                try {{
                    var idPlc = charIDToTypeID("Plc ");
                    var desc = new ActionDescriptor();
                    desc.putPath(charIDToTypeID("null"), new File("{safe_path}"));
                    executeAction(idPlc, desc, DialogModes.NO);
                    var l = app.activeDocument.activeLayer;
                    l.name = {safe_name};
                    var b = l.bounds;
                    var w = b[2].value - b[0].value;
                    var h = b[3].value - b[1].value;
                    var bx = b[0].value;
                    var by = b[1].value;
                    if (w <= 0 || h <= 0) {{ __batch_res.push(false); return; }}
                    var s = Math.min({t_w} / w, {t_h} / h);
                    if (s > 0 && s !== 1) {{
                        l.resize(s * 100.0, s * 100.0, AnchorPosition.TOPLEFT);
                        b = l.bounds;
                        w = b[2].value - b[0].value;
                        h = b[3].value - b[1].value;
                        bx = b[0].value;
                        by = b[1].value;
                    }}
                    l.translate({b_x} + ({b_w} - w) / 2.0 - bx, {b_y} + ({b_h} - h) / 2.0 - by);
                    {bits}
                    l.move(parent, ElementPlacement.PLACE_INSIDE);
                    __batch_res.push(true);
                }} catch(e) {{
                    __batch_res.push(false);
                }}
            }})();
        """)
    try:
        app.doJavaScript("\n".join(jsx_parts) + "\n__batch_res;")
    except Exception as exc:
        print(f"[Paytable] Asset batch JSX failed ({len(specs)} placements): {exc}")


def _create_text_com(group, spec):
    try:
        layer = group.artLayers.add()
    except Exception:
        return None
    try:
        layer.kind = ps.LayerKind.TextLayer
        layer.name = str(spec["name"])
        layer.textItem.contents = str(spec["text"])
        layer.textItem.size = max(1, int(_px_to_pt(spec["size"], layer)))
        try:
            layer.textItem.font = spec["font_name"]
        except Exception:
            pass
        layer.textItem.color = _rgb_color(spec["rgb"])
        layer.textItem.position = [float(spec["x"]), float(spec["y"])]
    except Exception:
        return None
    return layer


def _add_text_batch(group, specs, reacquire=False):
    """Create several text layers in ONE JSX inside `group`.

    specs: list of dicts with text/x/y/size/font_name/rgb/name. Returns a list
    with one entry per spec (the re-acquired COM layer when reacquire=True,
    else None), or an empty list when the batch path was skipped entirely
    (caller must fall back to its single-layer path). Per-spec JSX failures
    fall back to the COM create so a batch failure never loses a layer.
    """
    if not specs:
        return []
    if _PAYTEXT_FAST_ENABLED is False or not _PAYTEXT_BATCH_ENABLED:
        layers = []
        for s in specs:
            layer = _add_text(group, s["text"], s["x"], s["y"], s["size"], s["font_name"], s["rgb"], s["name"])
            layers.append(layer if reacquire else None)
        return layers if reacquire else []
    try:
        doc, app = _doc_and_app_from(group)
        if doc is None or app is None:
            raise RuntimeError("no doc/app")
    except Exception:
        layers = []
        for s in specs:
            layer = _add_text(group, s["text"], s["x"], s["y"], s["size"], s["font_name"], s["rgb"], s["name"])
            layers.append(layer if reacquire else None)
        return layers if reacquire else []
    with _timed("paytable_add_text_batch"):
        _PROFILER.inc("paytable_text_layers", len(specs))
        _paytext_batch_flush_immediate(app, doc, group, specs)
    if not reacquire:
        return []
    result = []
    for spec in specs:
        try:
            layer = group.artLayers.getByName(str(spec["name"]))
        except Exception:
            layer = None
        if layer is None or getattr(layer, "name", None) != str(spec["name"]):
            layer = None
        result.append(layer)
    return result


def _paytext_batch_flush_immediate(app, doc, group, specs):
    jsx_parts = [_doc_anchor_jsx(doc), "var __batch_res = [];", (
        "function __findSet(node, id) {\n"
        "    var sets = node.layerSets;\n"
        "    for (var i = 0; i < sets.length; i++) {\n"
        "        if (sets[i].id == id) return sets[i];\n"
        "        var hit = __findSet(sets[i], id);\n"
        "        if (hit) return hit;\n"
        "    }\n"
        "    return null;\n"
        "}\n"
    )]
    try:
        group_id = int(group.id)
    except Exception:
        group_id = None
    for spec in specs:
        contents_s = json.dumps(str(spec["text"]))
        font_s = json.dumps(str(spec["font_name"] or ""))
        name_s = json.dumps(str(spec["name"]))
        r, g, b = (int(c) for c in tuple(spec["rgb"] or (255, 255, 255))[:3])
        size_pt = max(1, int(_px_to_pt(spec["size"], doc)))
        if group_id is None:
            bits = "var parent = doc;"
        else:
            bits = (
                "var parent = __findSet(doc, " + str(group_id) + ");\n"
                "if (!parent) { __batch_res.push(false); return; }"
            )
        jsx_parts.append(f"""
            (function(){{
                try {{
                    {bits}
                    var l = parent.artLayers.add();
                    l.name = {name_s};
                    l.kind = LayerKind.TEXT;
                    l.textItem.contents = {contents_s};
                    l.textItem.size = {size_pt};
                    try {{ l.textItem.font = {font_s}; }} catch(eFont) {{}}
                    var c = new SolidColor();
                    c.rgb.red = {r}; c.rgb.green = {g}; c.rgb.blue = {b};
                    l.textItem.color = c;
                    l.textItem.position = [{float(spec['x'])}, {float(spec['y'])}];
                    __batch_res.push(true);
                }} catch(e) {{
                    __batch_res.push(false);
                }}
            }})();
        """)
    flags = []
    try:
        result = app.doJavaScript("\n".join(jsx_parts) + "\n__batch_res;")
        if isinstance(result, str):
            flags = [part.strip().casefold() in ("true", "1") for part in result.split(",")]
        elif isinstance(result, (list, tuple)):
            flags = [bool(v) for v in result]
    except Exception as exc:
        print(f"[Paytable] Text batch JSX failed ({len(specs)} layers): {exc}")
        flags = [False] * len(specs)
    out = []
    for spec, ok in zip(specs, flags):
        if ok:
            out.append(None)
        else:
            print(f"[Paytable] Text batch fallback to COM for '{spec['name']}'")
            out.append(_create_text_com(group, spec))
    return out

_NUMBER_WORDS = {
    "10": "ten", "9": "nine", "8": "eight", "7": "seven",
    "6": "six", "5": "five", "4": "four", "3": "three", "2": "two",
}


def _rgb_color(rgb):
    color = ps.SolidColor()
    values = tuple(rgb or (255, 255, 255))
    color.rgb.red = int(values[0])
    color.rgb.green = int(values[1])
    color.rgb.blue = int(values[2])
    return color


def _coerce_rgb(value, fallback=(255, 255, 255)):
    if isinstance(value, str):
        cleaned = value.strip().lstrip("#")
        if len(cleaned) == 6:
            try:
                return tuple(int(cleaned[index:index + 2], 16) for index in (0, 2, 4))
            except Exception:
                pass
    if isinstance(value, (list, tuple)) and len(value) >= 3:
        try:
            return tuple(max(0, min(255, int(value[index]))) for index in range(3))
        except Exception:
            pass
    if fallback is None:
        return None
    return tuple(fallback)


def _coerce_int(value, fallback=0):
    try:
        if value is None or str(value).strip() == "":
            return int(fallback)
        return int(float(value))
    except Exception:
        return int(fallback)


def _safe_layer_name(value):
    return str(value or "Layer").replace('"', "'")


def _clean_inline_text(value):
    text = str(value or "")
    text = text.replace("\r\n", " ").replace("\r", " ").replace("\n", " ")
    text = text.replace("\u2028", " ").replace("\u2029", " ")
    text = _CONTROL_TEXT_RE.sub(" ", text)
    text = re.sub(r"[ \t]+", " ", text)
    return text.strip()


def _prepare_heading_text(value, settings):
    text = str(value or "")
    replacement = str((settings or {}).get("heading_game_name_text") or "").strip()
    if replacement:
        text = _GAME_NAME_HEADING_TOKEN_RE.sub(replacement, text)
    if bool((settings or {}).get("heading_uppercase_enabled", False)):
        text = text.upper()
    return text


def _game_name_heading_asset(value, settings):
    if str((settings or {}).get("heading_game_name_text") or "").strip():
        return None
    match = _GAME_NAME_HEADING_TOKEN_RE.search(str(value or ""))
    if not match:
        return None
    token = match.group(0).strip("<> ")
    return resolve_icon_path(
        token,
        (settings or {}).get("asset_folder"),
        (settings or {}).get("icon_mappings"),
        ("Game Name", "GameName", "GAME NAME", "game_name", "gamename"),
    )


def _slot(slots, *names, slot_prefix=""):
    lower_map = {str(key).casefold(): value for key, value in slots.items()}
    for name in names:
        if not name:
            continue
        nk = str(name).casefold()
        found = lower_map.get(nk)
        if found:
            return found
    # If a slot_prefix is known (e.g. "@slot"), also try prefixed names
    if slot_prefix:
        pfx = str(slot_prefix).strip().rstrip(".") + "."
        for name in names:
            if not name:
                continue
            found = lower_map.get((pfx + str(name)).casefold())
            if found:
                return found
    return None


def _apply_safe_bottom_to_slots(slots, canvas_height, bottom_margin):
    try:
        safe_bottom = float(canvas_height) - max(0, float(bottom_margin or 0))
    except Exception:
        return slots
    if safe_bottom <= 0:
        return slots
    for box in slots.values():
        try:
            y = float(box.get("y", 0))
            h = float(box.get("h", 0))
            bottom = y + h
            if y >= safe_bottom:
                box["h"] = 1
            elif bottom > safe_bottom:
                box["h"] = max(1, safe_bottom - y)
        except Exception:
            pass
    return slots


def _normalize_key(value):
    value = re.sub(r"[^A-Za-z0-9]+", "", str(value or "")).lower()
    return _NUMBER_WORDS.get(value, value)


def _move_inside(layer, group):
    try:
        layer.move(group, ps.ElementPlacement.PlaceInside)
    except Exception:
        pass
    return layer


def _create_rect(doc, app, group, box, name, rgb, opacity=100, stroke_rgb=None, stroke_width=0):
    if not box:
        return None
    fill_rgb = tuple(rgb or (0, 0, 0))
    stroke_rgb = tuple(stroke_rgb or (255, 255, 255))
    stroke_width = max(0, int(stroke_width or 0))
    stroke_code = ""
    if stroke_width > 0:
        stroke_code = (
            "var sc = new SolidColor();"
            f"sc.rgb.red={int(stroke_rgb[0])};"
            f"sc.rgb.green={int(stroke_rgb[1])};"
            f"sc.rgb.blue={int(stroke_rgb[2])};"
            f"doc.selection.stroke(sc,{stroke_width},StrokeLocation.INSIDE);"
        )
    safe_name = _safe_layer_name(name)
    left = float(box["x"])
    top = float(box["y"])
    right = left + float(box["w"])
    bottom = top + float(box["h"])
    script = f'''
    (function() {{
        var doc = app.activeDocument;
        var layer = doc.artLayers.add();
        layer.name = "{safe_name}";
        doc.selection.select([[{left},{top}],[{right},{top}],[{right},{bottom}],[{left},{bottom}]]);
        var fc = new SolidColor();
        fc.rgb.red={int(fill_rgb[0])};
        fc.rgb.green={int(fill_rgb[1])};
        fc.rgb.blue={int(fill_rgb[2])};
        doc.selection.fill(fc);
        {stroke_code}
        doc.selection.deselect();
        layer.opacity={max(0, min(100, int(opacity)))};
    }})();
    '''
    app.doJavaScript(script)
    return _move_inside(doc.activeLayer, group)


def _create_stroke_rect(doc, app, group, box, name, rgb, stroke_width=1, opacity=100):
    if not box:
        return None
    stroke_rgb = tuple(rgb or (255, 255, 255))
    stroke_width = max(0, int(stroke_width or 0))
    if stroke_width <= 0:
        return None
    safe_name = _safe_layer_name(name)
    left = float(box["x"])
    top = float(box["y"])
    right = left + float(box["w"])
    bottom = top + float(box["h"])
    script = f'''
    (function() {{
        var doc = app.activeDocument;
        var layer = doc.artLayers.add();
        layer.name = "{safe_name}";
        doc.selection.select([[{left},{top}],[{right},{top}],[{right},{bottom}],[{left},{bottom}]]);
        var sc = new SolidColor();
        sc.rgb.red={int(stroke_rgb[0])};
        sc.rgb.green={int(stroke_rgb[1])};
        sc.rgb.blue={int(stroke_rgb[2])};
        doc.selection.stroke(sc,{stroke_width},StrokeLocation.INSIDE);
        doc.selection.deselect();
        layer.opacity={max(0, min(100, int(opacity)))};
    }})();
    '''
    app.doJavaScript(script)
    return _move_inside(doc.activeLayer, group)


def _truthy(value, default=False):
    if value is None:
        return bool(default)
    if isinstance(value, str):
        return value.strip().casefold() in {"1", "true", "yes", "y", "on", "fill", "stroke"}
    return bool(value)


def _render_slot_style_layers(doc, app, group, box, spec, name_prefix):
    if not box or not isinstance(spec, dict):
        return
    fill_enabled = _truthy(spec.get("fill_enabled"), False)
    stroke_enabled = _truthy(spec.get("stroke_enabled"), False)
    try:
        fill_opacity = max(0, min(100, int(float(spec.get("opacity", spec.get("fill_opacity", 100))))))
    except Exception:
        fill_opacity = 100
    if fill_enabled and fill_opacity > 0:
        _create_rect(
            doc,
            app,
            group,
            box,
            f"{name_prefix} Fill",
            _coerce_rgb(spec.get("background_color", spec.get("bg_color", (0, 0, 0))), (0, 0, 0)),
            fill_opacity,
        )
    try:
        stroke_width = max(0, int(float(spec.get("stroke_width", 0) or 0)))
    except Exception:
        stroke_width = 0
    if stroke_enabled and stroke_width > 0:
        _create_stroke_rect(
            doc,
            app,
            group,
            box,
            f"{name_prefix} Stroke",
            _coerce_rgb(spec.get("stroke_color", (255, 255, 255)), (255, 255, 255)),
            stroke_width,
            spec.get("stroke_opacity", 100),
        )


def _add_text(group, text, x, baseline_y, size, font_name, rgb, name):
    _PROFILER.inc("paytable_text_layers")
    with _timed("paytable_add_text"):
        return _add_text_impl(group, text, x, baseline_y, size, font_name, rgb, name)


def _add_text_impl(group, text, x, baseline_y, size, font_name, rgb, name):
    global _PAYTEXT_FAST_ENABLED
    safe_name = _safe_layer_name(name)
    if _PAYTEXT_FAST_ENABLED is not False:
        try:
            doc, app = _doc_and_app_from(group)
            if doc is not None and app is not None:
                # size_pt from the doc resolution (single read, no chain walk)
                size_pt = max(1, int(_px_to_pt(size, doc)))
                jsx = _text_fast_jsx(
                    doc, group, str(text), size, font_name, _rgb_color(rgb),
                    float(x), float(baseline_y), safe_name, 0,
                    use_nbsp=False, size_pt_override=size_pt,
                )
                if jsx:
                    result = app.doJavaScript(jsx)
                    if isinstance(result, str) and result.startswith("OK:"):
                        try:
                            # NOTE: photoshop.api has no getByID, so the freshly
                            # created layer is re-acquired via doc.activeLayer
                            # (still active) and its name verified against the
                            # safe_name the JSX was asked to create.
                            layer = doc.activeLayer
                        except Exception:
                            layer = None
                        if layer is not None and getattr(layer, "name", None) == safe_name:
                            if _PAYTEXT_FAST_ENABLED is None:
                                _PAYTEXT_FAST_ENABLED = True
                            return layer
                        print(f"Paytable text fast path name mismatch for '{name}'; using COM")
                    if isinstance(result, str) and result.startswith("ERR:"):
                        print(f"Paytable text fast path JSX error for '{name}': {result}")
        except Exception as exc:
            print(f"Paytable text fast path failed; using COM for '{name}': {exc}")
            _PAYTEXT_FAST_ENABLED = False
    layer = group.artLayers.add()
    layer.kind = ps.LayerKind.TextLayer
    layer.name = safe_name
    layer.textItem.contents = str(text)
    layer.textItem.size = max(1, int(_px_to_pt(size, layer)))
    try:
        layer.textItem.font = font_name
    except Exception:
        pass
    layer.textItem.color = _rgb_color(rgb)
    layer.textItem.position = [float(x), float(baseline_y)]
    return layer


def _layer_width(layer):
    try:
        bounds = layer.bounds
        return float(bounds[2]) - float(bounds[0])
    except Exception:
        return 0.0


def _center_text(group, text, box, size, font_name, rgb, name, y_fraction=0.5):
    if not text or not box:
        return None
    baseline = float(box["y"]) + float(box["h"]) * float(y_fraction) + float(size) * 0.35
    width = _measure_text_width(group, text, size, font_name)
    if width > 0:
        x = float(box["x"]) + (float(box["w"]) - width) / 2.0
    else:
        x = float(box["x"])
    # Create the layer ONCE at its final centered position (width comes from the
    # measurement cache / PIL), instead of create-then-measure-then-move.
    return _add_text(group, text, x, baseline, size, font_name, rgb, name)


def _fit_center_text(group, text, box, size, font_name, rgb, name, y_fraction=0.5, min_size=12):
    """Center a single text layer and shrink it until it fits the slot.

    Used mainly for paytable titles. This keeps <GAME NAME> / TM / long
    brand titles as one Photoshop text layer instead of splitting the heading
    and causing overlap.
    """
    with _timed("paytable_fit_center"):
        return _fit_center_text_impl(group, text, box, size, font_name, rgb, name, y_fraction, min_size)


def _fit_center_text_impl(group, text, box, size, font_name, rgb, name, y_fraction=0.5, min_size=12):
    if not text or not box:
        return None
    requested_size = int(size)
    fitted_size = requested_size
    for current_size in range(requested_size, int(min_size) - 1, -2):
        width = _measure_text_width(group, text, current_size, font_name)
        if width <= float(box["w"]) * 0.96 or current_size <= int(min_size):
            fitted_size = current_size
            break
    baseline = float(box["y"]) + float(box["h"]) * float(y_fraction) + float(fitted_size) * 0.35
    width = _measure_text_width(group, text, fitted_size, font_name)
    if width > 0:
        x = float(box["x"]) + (float(box["w"]) - width) / 2.0
    else:
        x = float(box["x"])
    # The whole fit happens from cached/PIL widths; the layer is created once at
    # its final size and centered position.
    return _add_text(group, text, x, baseline, fitted_size, font_name, rgb, name)


def _wrap_text(text, box_width, font_size):
    text = re.sub(r"\s+", " ", _clean_inline_text(text)).strip()
    if not text:
        return []
    average_char_width = max(1.0, float(font_size) * 0.54)
    max_chars = max(8, int(float(box_width) / average_char_width))
    words = text.split(" ")
    lines = []
    current = ""
    for word in words:
        trial = word if not current else current + " " + word
        if len(trial) <= max_chars:
            current = trial
        else:
            if current:
                lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines


def _premeasure_wrap_texts(group, texts, font_size, font_name, substrings_of=None):
    with _timed("paytable_premeasure"):
        return _premeasure_wrap_texts_impl(group, texts, font_size, font_name, substrings_of)


def _premeasure_wrap_texts_impl(group, texts, font_size, font_name, substrings_of=None):
    """Measure many (text, size, font) keys in ONE JSX call (full layer bounds).

    texts: exact strings the wrap loops will measure. substrings_of: a list of
    words; all non-empty prefixes of every suffix (i.e. all substrings) of each
    word are added too, so binary-search/char-scan trials in _measured_wrap and
    _split_text_for_wrap become cache hits. Overlong words (>34 chars) are
    skipped here to bound the batch; their trials keep the per-key path."""
    if not texts:
        return
    measure_layer, font_cache = _measure_layer_for(group)
    if measure_layer is None:
        return
    all_texts, all_sizes, all_fonts = [], [], []
    seen = set()
    for text in texts:
        text = str(text or "")
        if not text:
            continue
        key = (text, int(float(font_size)), str(font_name))
        if key in _MEASURE_WIDTH_CACHE or key in font_cache or key in seen:
            continue
        seen.add(key)
        all_texts.append(text)
        all_sizes.append(font_size)
        all_fonts.append(font_name)
    if substrings_of:
        for word in substrings_of:
            word = str(word or "").strip()
            if not word or len(word) > 34:
                continue
            for i in range(1, len(word) + 1):
                for j in range(0, len(word) - i + 1):
                    sub = word[j:j + i]
                    key = (sub, int(float(font_size)), str(font_name))
                    if key in _MEASURE_WIDTH_CACHE or key in font_cache or key in seen:
                        continue
                    seen.add(key)
                    all_texts.append(sub)
                    all_sizes.append(font_size)
                    all_fonts.append(font_name)
    if all_texts:
        premeasure_texts_batch(all_texts, all_sizes, all_fonts, measure_layer, font_cache, full_bounds=True)


def _measured_wrap(group, text, font_size, font_name, max_width):
    with _timed("paytable_measured_wrap"):
        return _measured_wrap_impl(group, text, font_size, font_name, max_width)


def _measured_wrap_impl(group, text, font_size, font_name, max_width):
    """Wrap text using the real measured glyph width instead of an average
    character estimate, so a line never exceeds the slot width."""
    text = _clean_inline_text(text)
    if not text:
        return []
    chunks = re.findall(r"\S+\s*|\s+", text)
    _premeasure_wrap_texts(group, [c for c in chunks if c.strip()], font_size, font_name,
                           substrings_of=[c.strip() for c in chunks if c.strip()])
    lines = []
    current = ""
    current_width = 0.0
    for chunk in chunks:
        if not chunk.strip():
            if current:
                current += chunk
            continue
        chunk_width = _measure_text_width(group, chunk, font_size, font_name)
        if current and current_width + chunk_width > max_width:
            lines.append(current.rstrip())
            current = ""
            current_width = 0.0
        if chunk_width <= max_width:
            current += chunk
            current_width += chunk_width
            continue
        # A single word wider than the slot: split it into measured chunks.
        word = chunk.strip()
        if current:
            lines.append(current.rstrip())
            current = ""
            current_width = 0.0
        rest = word
        while len(rest) > 1:
            low, high = 1, len(rest)
            while low < high:
                mid = (low + high + 1) // 2
                if _measure_text_width(group, rest[:mid], font_size, font_name) <= max_width:
                    low = mid
                else:
                    high = mid - 1
            lines.append(rest[:low])
            rest = rest[low:]
        if rest:
            current = rest + " "
            current_width = _measure_text_width(group, rest + " ", font_size, font_name)
    if current.strip():
        lines.append(current.rstrip())
    return lines


def _text_block(group, text, box, size, font_name, rgb, name, max_lines=None, vertical_center=True, min_size=8):
    """Render wrapped text in a box, shrinking font size until it fits vertically."""
    with _timed("paytable_text_block"):
        return _text_block_impl(group, text, box, size, font_name, rgb, name, max_lines, vertical_center, min_size)


def _text_block_impl(group, text, box, size, font_name, rgb, name, max_lines=None, vertical_center=True, min_size=8):
    if not box or not text:
        return []
    box_w = float(box["w"])
    box_h = float(box["h"])
    source_lines = text if isinstance(text, (list, tuple)) else [text]

    best = None
    for current_size in range(int(size), int(min_size) - 1, -2):
        lines = []
        for source in source_lines:
            lines.extend(_wrap_text(str(source) if source else "", box_w, current_size))
        if max_lines:
            lines = lines[:max_lines]
        if not lines:
            continue
        line_height = max(float(current_size) * 1.18, float(current_size) + 2)
        total_height = len(lines) * line_height
        if total_height <= box_h or current_size <= min_size:
            best = (current_size, lines, line_height, total_height)
            break

    if not best:
        return []
    current_size, lines, line_height, total_height = best
    if vertical_center:
        top = float(box["y"]) + (box_h - total_height) / 2.0
    else:
        top = float(box["y"])
    layers = []
    specs = []
    for index, line in enumerate(lines):
        line_box = {
            "x": float(box["x"]),
            "y": top + index * line_height,
            "w": box_w,
            "h": line_height,
        }
        baseline = float(line_box["y"]) + float(line_box["h"]) * 0.55 + float(current_size) * 0.35
        width = _measure_text_width(group, line, current_size, font_name)
        if width > 0:
            x = float(line_box["x"]) + (float(line_box["w"]) - width) / 2.0
        else:
            x = float(line_box["x"])
        specs.append({
            "text": line,
            "x": x,
            "y": baseline,
            "size": current_size,
            "font_name": font_name,
            "rgb": rgb,
            "name": f"{name} {index + 1}",
        })
    _add_text_batch(group, specs, reacquire=False)
    return layers


def _resolve_asset(folder, candidates):
    if not folder or not os.path.isdir(folder):
        return None
    expanded = []
    for candidate in candidates:
        if not candidate:
            continue
        candidate = str(candidate).strip()
        expanded.append(candidate)
        root, extension = os.path.splitext(candidate)
        if not extension:
            expanded.extend([candidate + ".png", candidate + ".jpg", candidate + ".jpeg"])
    actual = {name.casefold(): name for name in os.listdir(folder)}
    for candidate in expanded:
        matched = actual.get(candidate.casefold())
        if matched:
            return os.path.join(folder, matched)
    return None


def _asset_candidates(label):
    label = str(label or "").strip("<> ")
    normalized = re.sub(r"\s+", "_", label)
    return [label, normalized, label.upper(), label.lower()]


def _place_asset(doc, app, group, path, box, name, max_height=None, max_width=None, batchable=False):
    """Place an asset centered in a slot.

    max_height/max_width are final target-canvas pixels from the Paytable UI.
    They are optional and are clamped to the slot dimensions. With
    batchable=True the placement is queued and created with the next batch
    flush (return value is not needed); callers that read the placed layer's
    bounds must keep batchable=False.
    """
    if not path or not box:
        return None
    if batchable and _PAYASSET_BATCH_ENABLED:
        state = _PAYASSET_BATCH.setdefault(id(doc), {"app": app, "doc": doc, "specs": []})
        target_w = float(box["w"])
        target_h = float(box["h"])
        if max_width is not None:
            target_w = min(target_w, max(1.0, float(max_width)))
        if max_height is not None:
            target_h = min(target_h, max(1.0, float(max_height)))
        state["specs"].append({
            "path": path,
            "group": group,
            "name": _safe_layer_name(name),
            "target_w": target_w,
            "target_h": target_h,
            "box_x": float(box["x"]),
            "box_y": float(box["y"]),
            "box_w": float(box["w"]),
            "box_h": float(box["h"]),
        })
        if len(state["specs"]) >= _PAYASSET_BATCH_THRESHOLD:
            _payasset_batch_flush(app, doc)
        return None
    _PROFILER.inc("paytable_asset_places")
    with _timed("paytable_place_asset"):
        return _place_asset_impl(doc, app, group, path, box, name, max_height, max_width)


def _place_asset_impl(doc, app, group, path, box, name, max_height=None, max_width=None):
    safe_path = os.path.abspath(path).replace("\\", "/").replace('"', '\\"')
    safe_name = json.dumps(_safe_layer_name(name))

    target_w = float(box["w"])
    target_h = float(box["h"])
    if max_width is not None:
        target_w = min(target_w, max(1.0, float(max_width)))
    if max_height is not None:
        target_h = min(target_h, max(1.0, float(max_height)))
    box_x = float(box["x"])
    box_y = float(box["y"])
    box_w = float(box["w"])
    box_h = float(box["h"])
    script = f'''
    (function() {{
    var idPlc = charIDToTypeID("Plc ");
    var desc = new ActionDescriptor();
    desc.putPath(charIDToTypeID("null"), new File("{safe_path}"));
    executeAction(idPlc, desc, DialogModes.NO);
    var l = app.activeDocument.activeLayer;
    l.name = {safe_name};
    var b = l.bounds;
    var w = b[2].value - b[0].value;
    var h = b[3].value - b[1].value;
    var bx = b[0].value;
    var by = b[1].value;
    if (w <= 0 || h <= 0) return [-1, 0, 0].join("|");
    var s = Math.min({target_w} / w, {target_h} / h);
    if (s > 0 && s !== 1) {{
        l.resize(s * 100.0, s * 100.0, AnchorPosition.TOPLEFT);
        b = l.bounds;
        w = b[2].value - b[0].value;
        h = b[3].value - b[1].value;
        bx = b[0].value;
        by = b[1].value;
    }}
    l.translate({box_x} + ({box_w} - w) / 2.0 - bx, {box_y} + ({box_h} - h) / 2.0 - by);
    return [w, h, l.id].join("|");
    }})();
    '''
    result = app.doJavaScript(script)
    # NOTE: photoshop.api has no getByID; the placed layer is still the active
    # layer (nothing else ran since the JSX), so re-acquire it directly.
    try:
        layer = doc.activeLayer
    except Exception:
        return None
    return _move_inside(layer, group)


def _top_card_parts(box):
    return {
        "symbol": {
            "x": box["x"] + box["w"] * 0.07,
            "y": box["y"] + box["h"] * 0.04,
            "w": box["w"] * 0.86,
            "h": box["h"] * 0.50,
        },
        "payouts": {
            "x": box["x"] + box["w"] * 0.08,
            "y": box["y"] + box["h"] * 0.57,
            "w": box["w"] * 0.84,
            "h": box["h"] * 0.35,
        },
    }


def _lower_card_parts(box):
    return {
        "symbol": {
            "x": box["x"] + box["w"] * 0.06,
            "y": box["y"] + box["h"] * 0.04,
            "w": box["w"] * 0.88,
            "h": box["h"] * 0.46,
        },
        "payouts": {
            "x": box["x"] + box["w"] * 0.08,
            "y": box["y"] + box["h"] * 0.54,
            "w": box["w"] * 0.84,
            "h": box["h"] * 0.38,
        },
    }


def _render_payouts(group, payouts, box, settings, name_prefix, doc=None, app=None):
    if not payouts:
        return
    count_size = int(settings.get("count_size", 38))
    value_size = int(settings.get("value_size", 42))
    count_color = tuple(settings.get("count_rgb", (255, 175, 55)))
    value_color = tuple(settings.get("value_rgb", (255, 255, 255)))
    count_font_name = settings.get("count_font") or settings.get("body_font", "ArialMT")
    value_font_name = settings.get("value_font") or settings.get("body_font", "ArialMT")
    rows = len(payouts)
    row_height = float(box["h"]) / max(rows, 1)
    count_x = float(box["x"]) + float(box["w"]) * 0.24
    value_x = float(box["x"]) + float(box["w"]) * 0.58
    for index, payout in enumerate(payouts):
        row_top = float(box["y"]) + index * row_height
        baseline = row_top + row_height * 0.62
        batch_layers = _add_text_batch(group, [
            {
                "text": payout.get("count", ""),
                "x": count_x,
                "y": baseline,
                "size": count_size,
                "font_name": count_font_name,
                "rgb": count_color,
                "name": f"{name_prefix} Count {index + 1}",
            },
            {
                "text": payout.get("value", ""),
                "x": value_x,
                "y": baseline,
                "size": value_size,
                "font_name": value_font_name,
                "rgb": value_color,
                "name": f"{name_prefix} Value {index + 1}",
            },
        ], reacquire=True)
        if not batch_layers:
            count_layer = _add_text(group, payout.get("count", ""), count_x, baseline, count_size, count_font_name, count_color, f"{name_prefix} Count {index + 1}")
            value_layer = _add_text(group, payout.get("value", ""), value_x, baseline, value_size, value_font_name, value_color, f"{name_prefix} Value {index + 1}")
        else:
            count_layer = batch_layers[0]
            value_layer = batch_layers[1]
        if doc is not None and app is not None:
            if count_layer is not None:
                apply_heading_layer_style(app, doc, count_layer, settings.get("paytable_count_style"))
            if value_layer is not None:
                apply_heading_layer_style(app, doc, value_layer, settings.get("paytable_value_style"))


def _render_payouts_in_slots(group, payouts, slots, settings, aliases, doc=None, app=None, slot_prefix=""):
    """Render payout count/value text into dedicated JSON slots.

    Looks for slots named like <card_alias>.pay<N>, <card_alias>.value<N>
    for per-row placement, or <card_alias>.pay / <card_alias>.pays /
    <card_alias>.value / <card_alias>.values for all rows stacked in one slot.
    Returns True if any pay/value slots were used.
    """
    if not payouts or not slots:
        return False
    count_size = int(settings.get("count_size", 38))
    value_size = int(settings.get("value_size", 42))
    count_color = tuple(settings.get("count_rgb", (255, 175, 55)))
    value_color = tuple(settings.get("value_rgb", (255, 255, 255)))
    count_font_name = settings.get("count_font") or settings.get("body_font", "ArialMT")
    value_font_name = settings.get("value_font") or settings.get("body_font", "ArialMT")
    _WORD_TO_DIGIT = {"ten":"10","nine":"9","eight":"8","seven":"7","six":"6","five":"5","four":"4","three":"3","two":"2"}
    raw_aliases = {str(a).casefold() for a in aliases if str(a).strip()}
    base_aliases = set(raw_aliases)
    for a in raw_aliases:
        digit = _WORD_TO_DIGIT.get(a)
        if digit:
            base_aliases.add(digit)
    used_any = False

    # Pre-resolve bulk and numbered slot availability (pay and value independently)
    bulk_pay_slot = None
    bulk_value_slot = None
    numbered_pay_slots = {}
    numbered_value_slots = {}
    _pfx = str(slot_prefix or "").strip().rstrip(".")  # e.g. "@slot"

    def _lookup(*names):
        """Try names as-is, then prefixed if _pfx is set."""
        found = _slot(slots, *names)
        if not found and _pfx:
            prefixed = [f"{_pfx}.{n}" for n in names]
            found = _slot(slots, *prefixed)
        return found

    for base in base_aliases:
        if not bulk_pay_slot:
            bulk_pay_slot = _lookup(f"{base}.pay", f"{base}.pays", f"{base}.Pay", f"{base}.Pays", f"{base}.PAY", f"{base}.PAYS")
        if not bulk_value_slot:
            bulk_value_slot = _lookup(f"{base}.value", f"{base}.values", f"{base}.Value", f"{base}.Values", f"{base}.VALUE", f"{base}.VALUES")
        if bulk_pay_slot and bulk_value_slot:
            break
    for base in base_aliases:
        for row_idx in range(1, len(payouts) + 1):
            if row_idx not in numbered_pay_slots:
                s = _lookup(f"{base}.pay{row_idx}", f"{base}.pays{row_idx}")
                if s:
                    numbered_pay_slots[row_idx] = s
            if row_idx not in numbered_value_slots:
                s = _lookup(f"{base}.value{row_idx}", f"{base}.values{row_idx}")
                if s:
                    numbered_value_slots[row_idx] = s

    # Helper: render rows into bulk slot (numbered rows stacked vertically)
    def _render_bulk(bulk_slot, lines, font_size, font_name, rgb, label_prefix):
        if not bulk_slot or not lines:
            return False
        row_h = float(bulk_slot["h"]) / max(len(lines), 1)
        for idx, text in enumerate(lines):
            row_box = {
                "x": bulk_slot["x"],
                "y": bulk_slot["y"] + idx * row_h,
                "w": bulk_slot["w"],
                "h": row_h,
            }
            _text_block(group, text, row_box, font_size, font_name, rgb, f"{label_prefix} {idx + 1}")
        return True

    # Helper: distribute rows across numbered slots (stack orphans in last slot)
    def _distribute_numbered(slot_dict, row_payouts, get_text_fn, font_size, font_name, rgb, label_prefix):
        if not slot_dict:
            return False
        sorted_slots = sorted(slot_dict.items())
        last_idx, last_slot = sorted_slots[-1]
        slot_rows = {}
        for row_idx, payout in enumerate(row_payouts, start=1):
            text = get_text_fn(payout)
            if not text:
                continue
            if row_idx in slot_dict:
                slot_rows.setdefault(row_idx, []).append(text)
            else:
                slot_rows.setdefault(last_idx, []).append(text)
        used = False
        for slot_idx, slot in slot_dict.items():
            texts = slot_rows.get(slot_idx)
            if texts:
                _text_block(group, texts, slot, font_size, font_name, rgb, f"{label_prefix} {slot_idx}")
                used = True
        return used

    # Helper: render bulk + numbered mixed
    def _mixed_bulk(bulk_slot, slot_dict, row_payouts, get_text_fn, font_size, font_name, rgb, label_prefix):
        covered = set(slot_dict.keys())
        for row_idx, payout in enumerate(row_payouts, start=1):
            text = get_text_fn(payout)
            if text and row_idx in covered:
                _text_block(group, text, slot_dict[row_idx], font_size, font_name, rgb, f"{label_prefix} {row_idx}")
        remaining = [get_text_fn(p) for i, p in enumerate(row_payouts, start=1) if i not in covered and get_text_fn(p)]
        if remaining:
            _render_bulk(bulk_slot, remaining, font_size, font_name, rgb, label_prefix)
        return True

    def _get_count(p):
        return p.get("count", "")

    def _get_value(p):
        return p.get("value", "")

    # Render pay counts:
    all_pay_numbered = (
        len(numbered_pay_slots) >= len(payouts)
        and all(row_idx in numbered_pay_slots for row_idx in range(1, len(payouts) + 1))
    )
    if all_pay_numbered:
        for row_idx, payout in enumerate(payouts, start=1):
            text = _get_count(payout)
            if text:
                _text_block(group, text, numbered_pay_slots[row_idx], count_size, count_font_name, count_color, f"Pay {row_idx}")
                used_any = True
    elif bulk_pay_slot:
        _mixed_bulk(bulk_pay_slot, numbered_pay_slots, payouts, _get_count, count_size, count_font_name, count_color, "Pay")
        used_any = True
    elif numbered_pay_slots:
        if _distribute_numbered(numbered_pay_slots, payouts, _get_count, count_size, count_font_name, count_color, "Pay"):
            used_any = True

    # Render value texts:
    all_value_numbered = (
        len(numbered_value_slots) >= len(payouts)
        and all(row_idx in numbered_value_slots for row_idx in range(1, len(payouts) + 1))
    )
    if all_value_numbered:
        for row_idx, payout in enumerate(payouts, start=1):
            text = _get_value(payout)
            if text:
                _text_block(group, text, numbered_value_slots[row_idx], value_size, value_font_name, value_color, f"Value {row_idx}")
                used_any = True
    elif bulk_value_slot:
        _mixed_bulk(bulk_value_slot, numbered_value_slots, payouts, _get_value, value_size, value_font_name, value_color, "Value")
        used_any = True
    elif numbered_value_slots:
        if _distribute_numbered(numbered_value_slots, payouts, _get_value, value_size, value_font_name, value_color, "Value"):
            used_any = True

    return used_any


def _card_index_aliases(card, index, card_type, top_count=0):
    key = card.get("slot_key") or _normalize_key(card.get("label"))
    global_index = int(index) if card_type == "top" else int(top_count) + int(index)
    aliases = {
        str(key).casefold(),
        f"pic{global_index}".casefold(),
        f"symbol.{global_index}".casefold(),
        f"symbol{global_index}".casefold(),
        f"{card_type}.{index}".casefold(),
    }
    if card_type != "top":
        aliases.update({
            f"low.{index}".casefold(),
            f"lower.{index}".casefold(),
            f"bottom.{index}".casefold(),
        })
    return aliases


def _slot_is_mapped(mapped_slots, aliases, suffixes=()):
    mapped_slots = {str(item).casefold() for item in (mapped_slots or set())}
    alias_set = {str(item).casefold() for item in aliases if str(item).strip()}
    suffixes = tuple(str(suffix).casefold().strip(".") for suffix in (suffixes or ()))
    for slot in mapped_slots:
        if slot in alias_set:
            return True
        for alias in alias_set:
            if slot.startswith(alias + "."):
                if not suffixes:
                    return True
                tail = slot[len(alias) + 1:]
                if any(tail == suffix or tail.startswith(suffix + ".") or tail.startswith(suffix) for suffix in suffixes):
                    return True
        if suffixes and any(slot.startswith(suffix) for suffix in suffixes):
            return True
    return False


def _render_card(doc, app, parent_group, card, slot_box, settings, card_type, index, mapped_slots=None, top_count=0, slots=None, slot_prefix=""):
    with _timed("paytable_render_card"):
        return _render_card_impl(doc, app, parent_group, card, slot_box, settings, card_type, index, mapped_slots, top_count, slots, slot_prefix)


def _render_card_impl(doc, app, parent_group, card, slot_box, settings, card_type, index, mapped_slots=None, top_count=0, slots=None, slot_prefix=""):
    group = parent_group.layerSets.add()
    group.name = f"{card_type.title()} Card {index} - {card['label']}"
    is_top = card_type == "top"
    bg_rgb = settings.get("top_card_bg_rgb", (10, 10, 18)) if is_top else settings.get("lower_card_bg_rgb", (18, 12, 28))
    bg_opacity = settings.get("top_card_bg_opacity", 65) if is_top else settings.get("lower_card_bg_opacity", 65)
    stroke_rgb = settings.get("card_stroke_rgb", (40, 40, 55))
    stroke_width = settings.get("card_stroke_width", 0)
    _create_rect(doc, app, group, slot_box, "Card Background", bg_rgb, bg_opacity, stroke_rgb, stroke_width)

    parts = _top_card_parts(slot_box) if is_top else _lower_card_parts(slot_box)
    aliases = _card_index_aliases(card, index, card_type, top_count=top_count)
    icon_mapped = _slot_is_mapped(mapped_slots, aliases, ("icon", "symbolicon"))
    payouts_mapped = _slot_is_mapped(mapped_slots, aliases, ("pay", "pays", "value", "values"))
    if not icon_mapped:
        icon_folder = settings.get("asset_folder")
        asset = resolve_icon_path(
            card["label"], icon_folder, settings.get("icon_mappings"), _asset_candidates(card["label"])
        )
        if asset:
            icon_height_key = "top_symbol_icon_height" if is_top else "lower_symbol_icon_height"
            icon_height = settings.get(icon_height_key)
            _place_asset(
                doc, app, group, asset, parts["symbol"], f"Symbol {card['label']}",
                max_height=icon_height,
                batchable=True,
            )
        else:
            label = str(card["label"])
            if label.casefold() == "queen":
                label = "Q"
            elif label.casefold() == "king":
                label = "K"
            elif label.casefold() == "jack":
                label = "J"
            elif label.casefold() == "ace":
                label = "A"
            symbol_size = int(settings.get("fallback_symbol_size", 110))
            _center_text(group, label, parts["symbol"], symbol_size, settings.get("heading_font", "ArialMT"), settings.get("fallback_symbol_rgb", (255, 255, 255)), "Fallback Symbol")

    if not payouts_mapped:
        placement_mode = str(settings.get("payout_placement_mode", "Bottom of icon")).strip().casefold()
        used_json_slots = _render_payouts_in_slots(group, card["payouts"], slots, settings, aliases, doc=doc, app=app, slot_prefix=slot_prefix)
        if used_json_slots:
            pass
        elif placement_mode.startswith("use json") or placement_mode == "use json pay/value slots":
            pass
        elif placement_mode.startswith("left"):
            pay_box = dict(parts["payouts"])
            pay_box["x"] = float(slot_box["x"])
            pay_box["w"] = float(parts["symbol"]["x"]) - float(slot_box["x"])
            _render_payouts(group, card["payouts"], pay_box, settings, card["label"], doc=doc, app=app)
        elif placement_mode.startswith("right"):
            sym_right = float(parts["symbol"]["x"]) + float(parts["symbol"]["w"])
            slot_right = float(slot_box["x"]) + float(slot_box["w"])
            pay_box = dict(parts["payouts"])
            pay_box["x"] = sym_right
            pay_box["w"] = slot_right - sym_right
            _render_payouts(group, card["payouts"], pay_box, settings, card["label"], doc=doc, app=app)
        else:
            _render_payouts(group, card["payouts"], parts["payouts"], settings, card["label"], doc=doc, app=app)


def _find_top_box(slots, card, index, slot_prefix=""):
    key = card.get("slot_key") or _normalize_key(card.get("label"))
    return _slot(slots, key, f"pic{index}", f"symbol.{index}", f"symbol{index}", f"top.{index}", slot_prefix=slot_prefix)


def _find_lower_box(slots, card, index, top_count=0, slot_prefix=""):
    key = card.get("slot_key") or _normalize_key(card.get("label"))
    # Support both explicit lower slots and generic continuous symbol.N slots.
    # Auto-detected templates often export all card boxes as symbol.1..symbol.N,
    # where top cards consume the first top_count slots and lower cards continue after them.
    return _slot(
        slots,
        key,
        f"low.{index}", f"lower.{index}", f"bottom.{index}",
        f"symbol.{int(top_count) + int(index)}", f"symbol{int(top_count) + int(index)}",
        slot_prefix=slot_prefix,
    )


def _wild_icon_boxes(slots):
    """Return only the main feature-symbol icon slots.

    Auto-detected PSDs can contain separate artwork boxes for exception icons
    (purple/red/green scatter, etc.). Those must NOT be filled with the WILD
    asset. They are rendered from the Excel text tokens inside the feature text
    line instead. To stay compatible with older JSON files, this function keeps
    only the largest/right feature-icon boxes and ignores small exception-icon
    boxes when both are present.
    """
    matches = []
    for name, box in slots.items():
        key = str(name).casefold()
        is_icon = (
            "wild.icon" in key or "feature.icon" in key or "special.icon" in key or "feature.main_icon" in key
            or key in ("wild", "scatter", "feature", "special", "feature_icon", "wild_icon")
        )
        if not is_icon:
            continue
        if any(word in key for word in ("title", "text", "note", "exception", "inline")):
            continue
        matches.append((name, box))

    # De-dupe aliases, e.g. feature.icon.1 and wild.icon.1 may point to same box.
    seen = set()
    deduped = []
    matches.sort(key=lambda pair: (float(pair[1]["y"]), float(pair[1]["x"])))
    for name, box in matches:
        sig = (round(float(box.get("x", 0))), round(float(box.get("y", 0))), round(float(box.get("w", 0))), round(float(box.get("h", 0))))
        if sig in seen:
            continue
        seen.add(sig)
        deduped.append((name, box))

    if not deduped:
        return []

    max_area = max(float(b.get("w", 0)) * float(b.get("h", 0)) for _, b in deduped)
    if max_area <= 0:
        return [b for _, b in deduped]

    # Keep all clearly-main icons. In the BAO paytable case the exception
    # icons are about 30% of the main icon area, so they are skipped. If a
    # template has only small scatter/bonus icons, max_area comes from those and
    # they are kept.
    main = []
    for name, box in deduped:
        area = float(box.get("w", 0)) * float(box.get("h", 0))
        if area >= max_area * 0.45:
            main.append(box)
    return main or [deduped[0][1]]


def _wild_asset(settings, side):
    """Resolve the primary feature artwork from the Excel <token> first.

    The name remains _wild_asset for backward compatibility, but it can resolve
    WILD, SCATTER, BONUS, WILD2x, etc. It never forces exception icons to use the
    primary feature asset.
    """
    folder = settings.get("asset_folder")
    token = str((side or {}).get("wild_token") or "Wild").strip("<> ")
    preferred = settings.get("wild_asset", "")
    candidates = []
    if preferred:
        candidates.append(preferred)
    candidates.extend(_asset_candidates(token))
    candidates.extend(["Wild.png", "WILD.png", "wild.png", "gold_scat.png"])
    return resolve_icon_path(token, folder, settings.get("icon_mappings"), candidates)


def _feature_assets(settings, side):
    """Resolve main feature icon assets from parsed Excel tokens.

    If Excel says <WILD> and <WILD2x>, two feature icon slots get those two
    different assets. If only one token exists, multiple feature slots can reuse
    it. Inline exception icons are handled separately by _token_asset().
    """
    tokens = list((side or {}).get("feature_tokens") or [])
    if not tokens:
        token = (side or {}).get("wild_token") or "Wild"
        tokens = [token]
    out = []
    for token in tokens:
        token = str(token or "").strip("<> ")
        if not token:
            continue
        asset = resolve_icon_path(token, settings.get("asset_folder"), settings.get("icon_mappings"), _asset_candidates(token))
        if not asset and token.casefold() == str((side or {}).get("wild_token") or "").casefold():
            asset = _wild_asset(settings, side)
        out.append({"token": token, "asset": asset})
    if not out:
        out.append({"token": str((side or {}).get("wild_token") or "Wild"), "asset": _wild_asset(settings, side)})
    return out


def _token_asset(settings, token):
    folder = settings.get("asset_folder")
    normalized = token.casefold()
    aliases = {
        "purple_niggat": ["purple_scat.png", token],
        "red_niggat": ["red_scat.png", "gold_scat.png", token],
        "green_niggat": ["green_scat.png", token],
        "nigga": [settings.get("wild_asset", "gold_scat.png"), token],
        "wild": [settings.get("wild_asset", "gold_scat.png"), token],
    }
    return resolve_icon_path(token, folder, settings.get("icon_mappings"), aliases.get(normalized, [token]))


def _measure_layer_for(group):
    """Return (hidden measure layer, font_cache) for the doc containing `group`.

    One hidden text layer per document; created lazily so the old
    create-layer-per-measure pattern is replaced by a single reused layer."""
    try:
        doc, _app = _doc_and_app_from(group)
        if doc is None:
            return None, None
        doc_id = int(doc.id)
    except Exception:
        return None, None
    state = _MEASURE_LAYER_STATE.get(doc_id)
    if state is None:
        try:
            ml = None
            try:
                ml = doc.artLayers.getByName("MeasureLayer")
            except Exception:
                ml = None
            if ml is None:
                ml = doc.artLayers.add()
                ml.name = "MeasureLayer"
                ml.kind = ps.LayerKind.TextLayer
                ml.visible = False
            state = (ml, {})
            _MEASURE_LAYER_STATE[doc_id] = state
        except Exception:
            return None, None
    return state


def _measure_text_width_com(group, text, size, font_name):
    """Original measurement path: temporary layer at (-10000,-10000), bounds, delete."""
    layer = _add_text(group, text, -10000, -10000, size, font_name, (255, 255, 255), "__measure__")
    width = _layer_width(layer)
    try:
        layer.remove()
    except Exception:
        try:
            layer.delete()
        except Exception:
            pass
    return width


def _measure_text_width(group, text, size, font_name):
    if not text:
        return 0.0
    # PIL resolves ArialMT & friends to local TTFs, so wrap/fit measurement is
    # free for system fonts; Photoshop stays the fallback for custom fonts.
    cache_key = (str(text), int(float(size)), str(font_name))
    if cache_key in _MEASURE_WIDTH_CACHE:
        return _MEASURE_WIDTH_CACHE[cache_key]
    try:
        pil_w = _measure_text_pil(text, int(float(size)), font_name)
        if pil_w is not None:
            _MEASURE_WIDTH_CACHE[cache_key] = pil_w
            return pil_w
    except Exception:
        pass
    measure_layer, font_cache = _measure_layer_for(group)
    if measure_layer is not None:
        if cache_key in font_cache:
            width = font_cache[cache_key]
        else:
            width = _measure_text_jsx(measure_layer, text, size, font_name, full_bounds=True)
            if width is not None:
                font_cache[cache_key] = width
            else:
                width = _measure_text_width_com(group, text, size, font_name)
    else:
        width = _measure_text_width_com(group, text, size, font_name)
    _MEASURE_WIDTH_CACHE[cache_key] = width
    return width


def _premeasure_inline_units(group, parts, font_name, text_size):
    """Batch-measure the exact part strings _inline_units will measure."""
    candidates = []
    for index, part in enumerate(parts):
        if part.startswith("<") and part.endswith(">"):
            continue
        previous_is_pointer = index > 0 and parts[index - 1].startswith("<")
        next_is_pointer = index + 1 < len(parts) and parts[index + 1].startswith("<")
        text_part = _clean_inline_text(part)
        if previous_is_pointer:
            text_part = text_part.lstrip(" \t")
        if next_is_pointer:
            text_part = text_part.rstrip(" \t")
        if text_part:
            candidates.append(text_part)
    _premeasure_wrap_texts(group, candidates, text_size, font_name)


def _asset_ratio(path):
    if Image is not None and path:
        try:
            with Image.open(path) as image:
                width, height = image.size
                if height:
                    return float(width) / float(height)
        except Exception:
            pass
    return 1.0


def _inline_units(group, text, settings, font_name, text_size, icon_height):
    with _timed("paytable_inline_units"):
        return _inline_units_impl(group, text, settings, font_name, text_size, icon_height)


def _inline_units_impl(group, text, settings, font_name, text_size, icon_height):
    """Split only at <symbol> pointers and avoid double spacing around icons.

    Excel text already contains spaces around pointer tokens. The renderer also
    applies the UI icon gap, so keeping both produced an oversized gap such as
    ``<red_Niggat>  and``. Adjacent whitespace is removed here and represented by
    one semantic icon gap. Punctuation immediately after an icon receives no gap.
    """
    cleaned_text = _clean_inline_text(text)
    if not bool(settings.get("parse_icon_tokens", True)):
        return [{
            "type": "text",
            "text": cleaned_text,
            "w": _measure_text_width(group, cleaned_text, text_size, font_name),
        }] if cleaned_text else []

    raw_parts = re.split(r"(<[^>]+>)", cleaned_text)
    parts = [part for part in raw_parts if part != ""]
    _premeasure_inline_units(group, parts, font_name, text_size)
    units = []
    token_occurrence = -1
    custom_icon_heights = {}
    for key, value in (settings.get("_inline_icon_heights") or {}).items():
        try:
            custom_icon_heights[int(key)] = max(1.0, float(value))
        except Exception:
            continue

    for index, part in enumerate(parts):
        is_pointer = part.startswith("<") and part.endswith(">")
        if is_pointer:
            token_occurrence += 1
            token = part[1:-1].strip()
            asset = _token_asset(settings, token)
            next_text = parts[index + 1] if index + 1 < len(parts) and not parts[index + 1].startswith("<") else ""
            previous_text = parts[index - 1] if index > 0 and not parts[index - 1].startswith("<") else ""
            # Normal word/icon boundaries use the UI gap. In paytable exception
            # text, punctuation such as commas/full stops should not touch icons,
            # so a following comma/period also receives the controlled gap.
            pre_gap = bool(previous_text and previous_text.rstrip())
            next_visible = next_text.lstrip()
            post_gap = bool(next_visible)
            if asset:
                unit_icon_height = custom_icon_heights.get(token_occurrence, float(icon_height))
                width = max(1.0, unit_icon_height * _asset_ratio(asset))
                units.append({
                    "type": "icon",
                    "token": token,
                    "asset": asset,
                    "w": width,
                    "h": unit_icon_height,
                    "pre_gap": pre_gap,
                    "post_gap": post_gap,
                })
            else:
                units.append({
                    "type": "text",
                    "text": part,
                    "w": _measure_text_width(group, part, text_size, font_name),
                })
            continue

        # Spaces directly adjacent to a pointer are replaced by that pointer's
        # semantic gap. Internal spaces, commas, 'and', and periods are preserved.
        previous_is_pointer = index > 0 and parts[index - 1].startswith("<")
        next_is_pointer = index + 1 < len(parts) and parts[index + 1].startswith("<")
        text_part = _clean_inline_text(part)
        if previous_is_pointer:
            text_part = text_part.lstrip(" \t")
        if next_is_pointer:
            text_part = text_part.rstrip(" \t")
        if text_part:
            units.append({
                "type": "text",
                "text": text_part,
                "w": _measure_text_width(group, text_part, text_size, font_name),
            })
    return units

def _split_text_for_wrap(group, text, max_width, text_size, font_name):
    with _timed("paytable_split_wrap"):
        return _split_text_for_wrap_impl(group, text, max_width, text_size, font_name)


def _split_text_for_wrap_impl(group, text, max_width, text_size, font_name):
    """Split one text run into word chunks only when it cannot fit on a line."""
    text = _clean_inline_text(text)
    if not text:
        return []
    chunks = re.findall(r"\S+\s*|\s+", text)
    _premeasure_wrap_texts(group, [text] + [c for c in chunks if c.strip()], text_size, font_name,
                           substrings_of=[c.strip() for c in chunks if c.strip()])
    whole_width = _measure_text_width(group, text, text_size, font_name)
    if whole_width <= max_width:
        return [{"type": "text", "text": text, "w": whole_width}]

    # Keep trailing whitespace attached to its word. Adjacent chunks are merged
    # back into one Photoshop text layer after line wrapping.
    result = []
    for chunk in chunks:
        width = _measure_text_width(group, chunk, text_size, font_name)
        if width <= max_width:
            result.append({"type": "text", "text": chunk, "w": width})
            continue

        # Rare fallback for a single token longer than the full slot width.
        current = ""
        for character in chunk:
            trial = current + character
            trial_width = _measure_text_width(group, trial, text_size, font_name)
            if current and trial_width > max_width:
                current_width = _measure_text_width(group, current, text_size, font_name)
                result.append({"type": "text", "text": current, "w": current_width})
                current = character
            else:
                current = trial
        if current:
            current_width = _measure_text_width(group, current, text_size, font_name)
            result.append({"type": "text", "text": current, "w": current_width})
    return result


def _coalesce_text_units(line):
    """Merge adjacent text units so Photoshop never receives one layer per word."""
    merged = []
    text_buffer = ""
    text_width = 0.0
    for unit in line:
        if unit["type"] == "text":
            text_buffer += unit.get("text", "")
            text_width += float(unit.get("w", 0.0))
            continue
        if text_buffer:
            merged.append({"type": "text", "text": text_buffer, "w": text_width})
            text_buffer = ""
            text_width = 0.0
        merged.append(unit)
    if text_buffer:
        merged.append({"type": "text", "text": text_buffer, "w": text_width})
    return merged


def _inline_layout(group, text, box, settings):
    """Measure a token-aware text block without creating its final layers."""
    with _timed("paytable_inline_layout"):
        return _inline_layout_impl(group, text, box, settings)


def _inline_layout_impl(group, text, box, settings):
    if not box or not text:
        return None
    font_name = settings.get("body_font", "ArialMT")
    text_size = int(settings.get("wild_text_size", 30))
    text_rgb = _coerce_rgb(settings.get("wild_text_rgb"), (255, 255, 255))
    icon_height = max(8, int(settings.get("inline_icon_height", max(text_size * 2, 36))))
    maximum_slot_icon_height = max(1.0, float(box.get("h", icon_height)) - 8.0)
    icon_height = min(float(icon_height), maximum_slot_icon_height)
    gap = max(0, int(settings.get("inline_icon_gap", 8)))
    box_width = max(1.0, float(box["w"]))
    # Point-text bounds can differ by a few pixels from Action Manager
    # measurements. Keep a small inner gutter so glyph overhangs never cross
    # the artist-authored JSON slot.
    width_gutter = max(4.0, min(16.0, box_width * 0.025))
    max_width = max(1.0, box_width - width_gutter)

    raw_units = _inline_units(group, text, settings, font_name, text_size, icon_height)
    units = []
    for unit in raw_units:
        if unit["type"] == "icon" and float(unit.get("h", 0.0)) > maximum_slot_icon_height:
            scale = maximum_slot_icon_height / max(1.0, float(unit.get("h", 1.0)))
            unit = dict(unit)
            unit["h"] = maximum_slot_icon_height
            unit["w"] = max(1.0, float(unit.get("w", 1.0)) * scale)
        if unit["type"] == "icon" and float(unit.get("w", 0.0)) > max_width:
            scale = max_width / max(1.0, float(unit.get("w", 1.0)))
            unit = dict(unit)
            unit["w"] = max_width
            unit["h"] = max(1.0, float(unit.get("h", icon_height)) * scale)
        if unit["type"] == "text" and float(unit.get("w", 0.0)) > max_width:
            units.extend(_split_text_for_wrap(group, unit.get("text", ""), max_width, text_size, font_name))
        else:
            units.append(unit)

    lines = []
    current = []
    current_width = 0.0
    for unit in units:
        unit_width = float(unit["w"])
        if unit["type"] == "icon":
            unit_width += gap if unit.get("pre_gap") else 0
            unit_width += gap if unit.get("post_gap") else 0
        is_space_only = unit["type"] == "text" and not unit.get("text", "").strip()
        if current and current_width + unit_width > max_width:
            # Remove line-ending spaces before committing the line.
            while current and current[-1]["type"] == "text" and not current[-1].get("text", "").strip():
                current_width -= float(current[-1].get("w", 0.0))
                current.pop()
            lines.append((_coalesce_text_units(current), current_width))
            current = []
            current_width = 0.0
            if is_space_only:
                continue
        current.append(unit)
        current_width += unit_width
    if current:
        lines.append((_coalesce_text_units(current), current_width))
    if not lines:
        return None

    try:
        manual_line_height = int(settings.get("inline_line_height") or 0)
    except Exception:
        manual_line_height = 0
    line_records = []
    for line, line_width in lines:
        max_icon_h = max([float(unit.get("h", 0.0)) for unit in line if unit.get("type") == "icon"] or [0.0])
        if manual_line_height > 0:
            line_height = max(float(text_size) + 4.0, max_icon_h + 8.0, float(manual_line_height))
        else:
            line_height = max(float(text_size) * 1.25, float(text_size) + 8.0, max_icon_h + 8.0)
        line_records.append((line, line_width, line_height))
    total_height = sum(record[2] for record in line_records)
    return {
        "font_name": font_name,
        "text_size": text_size,
        "text_rgb": text_rgb,
        "icon_height": icon_height,
        "gap": gap,
        "max_width": max_width,
        "box_width": box_width,
        "line_records": line_records,
        "total_height": total_height,
    }


def _render_inline_mixed(
        doc, app, group, text, box, settings, name_prefix,
        vertical_align="center", prepared_layout=None):
    with _timed("paytable_inline_mixed"):
        return _render_inline_mixed_impl(
            doc, app, group, text, box, settings, name_prefix, vertical_align, prepared_layout)


def _render_inline_mixed_impl(
        doc, app, group, text, box, settings, name_prefix,
        vertical_align="center", prepared_layout=None):
    if not box or not text:
        return None
    layout = prepared_layout or _inline_layout(group, text, box, settings)
    if not layout:
        return None

    font_name = layout["font_name"]
    text_size = layout["text_size"]
    text_rgb = layout["text_rgb"]
    icon_height = layout["icon_height"]
    gap = layout["gap"]
    max_width = layout["max_width"]
    box_width = layout.get("box_width", float(box["w"]))
    line_records = layout["line_records"]
    total_height = layout["total_height"]
    horizontal_align = str(
        box.get("horizontal_align") or box.get("align") or settings.get("paytable_notes_alignment") or "center"
    ).strip().casefold()
    if horizontal_align == "justify":
        horizontal_align = "left"
    if horizontal_align not in ("left", "center", "right"):
        horizontal_align = "center"
    if str(vertical_align).casefold() == "top":
        top = float(box["y"])
    elif str(vertical_align).casefold() == "bottom":
        top = float(box["y"]) + max(0.0, float(box["h"]) - total_height)
    else:
        top = float(box["y"]) + max(0.0, (float(box["h"]) - total_height) / 2.0)

    y_offset = 0.0
    for line_index, (line, line_width, line_height) in enumerate(line_records, start=1):
        if horizontal_align == "left":
            x = float(box["x"])
        elif horizontal_align == "right":
            x = float(box["x"]) + max(0.0, float(box_width) - line_width)
        else:
            x = float(box["x"]) + max(0.0, (float(box_width) - line_width) / 2.0)
        line_top = top + y_offset
        baseline = line_top + (line_height + text_size) / 2.0 - text_size * 0.12
        for unit_index, unit in enumerate(line, start=1):
            if unit["type"] == "text":
                text_value = unit.get("text", "")
                if text_value:
                    _add_text(
                        group, text_value, x, baseline, text_size, font_name, text_rgb,
                        f"{name_prefix} Text {line_index}-{unit_index}",
                    )
                x += float(unit["w"])
            else:
                if unit.get("pre_gap"):
                    x += gap
                unit_icon_height = float(unit.get("h", icon_height))
                icon_box = {
                    "x": x,
                    "y": line_top + (line_height - unit_icon_height) / 2.0,
                    "w": float(unit["w"]),
                    "h": unit_icon_height,
                }
                _place_asset(
                    doc, app, group, unit["asset"], icon_box,
                    f"{name_prefix} Icon {unit['token']}", max_height=unit_icon_height,
                    batchable=True,
                )
                x += float(unit["w"])
                if unit.get("post_gap"):
                    x += gap
        y_offset += line_height
    return {
        "height": total_height,
        "lines": len(line_records),
        "text_size": text_size,
        "icon_height": icon_height,
    }


def _split_unit_by_real_width(group, unit_text, max_width, text_size, font_name, name_prefix):
    """Split one over-wide text run into chunks that each really fit.

    Used when a placed text unit still renders wider than the slot (the plan
    split at its measured widths, but the real rendered width can be larger).
    Each chunk is measured from a REAL temporary layer, so the split uses the
    same widths Photoshop will render.
    """
    if not unit_text:
        return []
    try:
        probe = _add_text(group, unit_text, 0, 0, text_size, font_name, (255, 255, 255), "__split_measure__")
        total_w = _layer_width(probe)
    except Exception:
        return [unit_text]
    try:
        probe.remove()
    except Exception:
        try:
            probe.delete()
        except Exception:
            pass
    if total_w <= max_width:
        return [unit_text]
    pieces = int(max(2, int(math.ceil(total_w / max_width))))
    per = max(1, int(math.ceil(len(unit_text) / pieces)))
    result = []
    for index in range(0, len(unit_text), per):
        piece = unit_text[index:index + per]
        if piece:
            result.extend(_split_unit_by_real_width(group, piece, max_width, text_size, font_name, name_prefix))
    return result or [unit_text]


def _cleanup_flow_layers(group, names):
    """Remove layers by name inside `group` (fast-path bail / failure cleanup)."""
    try:
        doc, app = _doc_and_app_from(group)
        gid = int(group.id)
    except Exception:
        return
    names_s = json.dumps([str(n) for n in names])
    jsx = f"""
    (function() {{
        {_doc_anchor_jsx(doc)}
        function __findSet(node, id) {{
            var sets = node.layerSets;
            for (var i = 0; i < sets.length; i++) {{
                if (sets[i].id == id) return sets[i];
                var hit = __findSet(sets[i], id);
                if (hit) return hit;
            }}
            return null;
        }}
        try {{
            var parent = __findSet(doc, {gid});
            if (!parent) return false;
            var want = {names_s};
            for (var i = parent.artLayers.length - 1; i >= 0; i--) {{
                var L = parent.artLayers[i];
                for (var k = 0; k < want.length; k++) {{
                    if (L.name === want[k]) {{ L.remove(); break; }}
                }}
            }}
        }} catch (e) {{}}
        return true;
    }})();
    """
    try:
        app.doJavaScript(jsx)
    except Exception:
        pass


def _flow_remove_icon_layers(layers):
    for layer in layers:
        if layer is None:
            continue
        try:
            layer.remove()
        except Exception:
            try:
                layer.delete()
            except Exception:
                pass


def _flow_batch_place(doc, app, group, units, name_prefix, box,
                      max_width, box_width, box_x, box_y, box_h,
                      text_size, text_rgb, font_name, icon_height, gap,
                      horizontal_align, vertical_align, settings):
    """Fast path for mapped inline flows: ALL text units of the slot are
    created in ONE JSX (template + duplicate, same size/font/color), their
    real widths come back from the same call, rows are bucketed offline, and
    every text is positioned in ONE finalize JSX. Icons are still placed per
    unit (they need real bounds for the translate delta). Returns the
    legacy-shaped result dict, or None so the caller runs the legacy loop."""
    try:
        gid = int(group.id)
    except Exception:
        return None
    text_idx = []
    n = 0
    for unit in units:
        if unit["type"] == "text":
            n += 1
            if not unit.get("text"):
                continue
            text_idx.append((unit, f"{name_prefix} Text {n}"))
    if not text_idx:
        return None
    all_names = [ln for (_u, ln) in text_idx] + ["__flowtpl__"]
    size_pt = max(1, int(_px_to_pt(text_size, doc)))
    r, g, b = (int(c) for c in tuple(text_rgb or (255, 255, 255))[:3])
    font_s = json.dumps(str(font_name or ""))
    parts = [_doc_anchor_jsx(doc), "var __res = [];", (
        "function __findSet(node, id) {\n"
        "    var sets = node.layerSets;\n"
        "    for (var i = 0; i < sets.length; i++) {\n"
        "        if (sets[i].id == id) return sets[i];\n"
        "        var hit = __findSet(sets[i], id);\n"
        "        if (hit) return hit;\n"
        "    }\n"
        "    return null;\n"
        "}\n"
    ), "var __tpl = null;"]
    for unit, lname in text_idx:
        contents_s = json.dumps(str(unit.get("text", "")))
        name_s = json.dumps(lname)
        parts.append(f"""
            (function(){{
                try {{
                    var parent = __findSet(doc, {gid});
                    if (!parent) {{ __res.push("E"); return; }}
                    if (!__tpl) {{
                        var t = parent.artLayers.add();
                        t.name = "__flowtpl__";
                        t.kind = LayerKind.TEXT;
                        t.textItem.contents = " ";
                        t.textItem.size = {size_pt};
                        try {{ t.textItem.font = {font_s}; }} catch(eFont) {{}}
                        __tpl = t;
                    }}
                    var l = __tpl.duplicate();
                    l.name = {name_s};
                    l.textItem.contents = {contents_s};
                    var c = new SolidColor();
                    c.rgb.red = {r}; c.rgb.green = {g}; c.rgb.blue = {b};
                    l.textItem.color = c;
                    l.textItem.position = [0, 0];
                    var b = l.bounds;
                    __res.push("O|" + l.id + "|" + b[0] + "|" + b[1] + "|" + b[2] + "|" + b[3]);
                }} catch (e) {{
                    __res.push("E");
                }}
            }})();
        """)
    parts.append("""
        (function(){ try {
            var parent = __findSet(doc, """ + str(gid) + """);
            if (parent) {
                for (var i = parent.artLayers.length - 1; i >= 0; i--) {
                    if (parent.artLayers[i].name === "__flowtpl__") parent.artLayers[i].remove();
                }
            }
        } catch (e) {}
        })();
    """)
    jsx = "\n".join(parts) + "\n__res.join(\"|\");"
    try:
        result = app.doJavaScript(jsx)
    except Exception as exc:
        print(f"[Mapped Paytable] flow batch JSX error: {exc}")
        _cleanup_flow_layers(group, all_names)
        return None
    if isinstance(result, str):
        toks = [t.strip() for t in result.split("|")]
        if len(toks) == 1 and "," in result:
            toks = [t.strip() for t in result.split(",")]
    elif isinstance(result, (list, tuple)):
        toks = []
        for item in result:
            item_s = str(item)
            if "|" in item_s:
                toks.extend(t.strip() for t in item_s.split("|"))
            else:
                toks.append(item_s.strip())
    else:
        toks = []
    created = []
    failed = False
    i = 0
    while i < len(toks):
        if toks[i] == "O" and i + 5 < len(toks):
            try:
                lid = int(float(toks[i + 1]))
                created.append((lid, (float(toks[i + 2]), float(toks[i + 3]),
                                      float(toks[i + 4]), float(toks[i + 5]))))
                i += 6
                continue
            except Exception:
                failed = True
                break
        if toks[i] == "E":
            failed = True
            break
        i += 1
    if failed:
        _cleanup_flow_layers(group, all_names)
        _PROFILER.inc("paytable_flow_fast_fail")
        print(f"[Mapped Paytable] flow batch token error in result {result!r}, legacy loop")
        return None
    if len(created) != len(text_idx):
        _cleanup_flow_layers(group, all_names)
        _PROFILER.inc("paytable_flow_fast_fail")
        print(f"[Mapped Paytable] flow batch parse mismatch ({len(created)}/{len(text_idx)}), legacy loop")
        return None
    _PROFILER.inc("paytable_flow_fast_ok")
    real_text_w = {}
    for (unit, _lname), (_lid, bnd) in zip(text_idx, created):
        w = max(1.0, bnd[2] - bnd[0])
        if w > max_width:
            _cleanup_flow_layers(group, all_names)
            print(f"[Mapped Paytable] flow unit wider than slot, legacy loop: {w:.1f} > {max_width:.1f}")
            return None
        real_text_w[id(unit)] = w

    # Icons: placed once each (real bounds feed the final translate).
    entries = []            # (idx, unit, is_icon, real_w, gap_w, pre_gap_w, lid, layer, placed_top)
    icon_layers = []
    first_unit = True
    total_units = len(units)
    text_job = 0
    for idx, unit in enumerate(units):
        at_stream_end = (idx == total_units - 1)
        if unit["type"] == "icon":
            pre_gap_w = float(gap) if (unit.get("pre_gap") or first_unit) else 0.0
            post_gap_w = float(gap) if (unit.get("post_gap") or at_stream_end) else 0.0
            icon_h = float(unit.get("h", icon_height))
            icon_box = {"x": 0.0, "y": 0.0, "w": float(unit["w"]), "h": icon_h}
            layer = _place_asset(
                doc, app, group, unit["asset"], icon_box,
                f"{name_prefix} Icon {unit['token']}", max_height=icon_h,
            )
            real_w = float(unit["w"]) if layer is None else max(1.0, _layer_width(layer))
            placed_top = 0.0
            if layer is not None:
                try:
                    placed_top = float(layer.bounds[1])
                except Exception:
                    pass
            entries.append((idx, unit, True, real_w, pre_gap_w + post_gap_w,
                            pre_gap_w, None, layer, placed_top))
            if layer is not None:
                icon_layers.append(layer)
        else:
            tv = unit.get("text", "")
            if not tv:
                continue
            lid, bnd = created[text_job]
            text_job += 1
            entries.append((idx, unit, False, real_text_w[id(unit)], 0.0, 0.0,
                            lid, None, 0.0))
        first_unit = False

    # Offline row bucket: identical greedy rule to the legacy placement loop.
    rows = []
    row = []
    row_w = 0.0
    for entry in entries:
        real_w, gap_w = entry[3], entry[4]
        if row and row_w + real_w + gap_w > max_width:
            rows.append(row)
            row = []
            row_w = 0.0
        row.append(entry)
        row_w += real_w + gap_w
    if row:
        rows.append(row)
    if not rows:
        _flow_remove_icon_layers(icon_layers)
        _cleanup_flow_layers(group, all_names)
        return None

    def row_metrics(row_entries):
        max_icon_h = max([float(e[1].get("h", 0.0)) for e in row_entries if e[2]] or [0.0])
        return max(float(text_size) * 1.25, float(text_size) + 8.0, max_icon_h + 8.0)

    total_height = 0.0
    row_heights = []
    for row_entries in rows:
        rh = row_metrics(row_entries)
        row_heights.append(rh)
        total_height += rh
    needed_height = total_height
    kept_rows = len(rows)
    clipped_rows = False
    if total_height > box_h:
        keep_count = 0
        used = 0.0
        for rh in row_heights:
            if used + rh > box_h + 0.01:
                break
            used += rh
            keep_count += 1
        if keep_count < len(rows):
            clipped_rows = True
        kept_rows = keep_count
        total_height = used
    if kept_rows == 0:
        _flow_remove_icon_layers(icon_layers)
        _cleanup_flow_layers(group, all_names)
        return None
    if str(vertical_align).casefold() == "top":
        offset_y = 0.0
    elif str(vertical_align).casefold() == "bottom":
        offset_y = max(0.0, box_h - total_height)
    else:
        offset_y = max(0.0, (box_h - total_height) / 2.0)

    remove_ids = []
    moves = []             # (lid, x, y)
    icon_moves = []        # (layer, dx, dy)
    y_cursor = 0.0
    for row_index, row_entries in enumerate(rows):
        if row_index >= kept_rows:
            for entry in row_entries:
                lid, layer = entry[6], entry[7]
                if layer is not None:
                    try:
                        layer.remove()
                    except Exception:
                        try:
                            layer.delete()
                        except Exception:
                            pass
                elif lid is not None:
                    remove_ids.append(lid)
            continue
        row_width = sum(float(e[3]) + float(e[4]) for e in row_entries)
        if horizontal_align == "left":
            row_x0 = 0.0
        elif horizontal_align == "right":
            row_x0 = max(0.0, box_width - row_width)
        else:
            row_x0 = max(0.0, (box_width - row_width) / 2.0)
        rh = row_heights[row_index]
        run_x = 0.0
        for entry in row_entries:
            is_icon, real_w, gap_w, pre_gap_w = entry[2], entry[3], entry[4], entry[5]
            final_x = row_x0 + run_x + pre_gap_w
            if is_icon:
                layer, placed_top = entry[7], entry[8]
                icon_h = float(entry[1].get("h", icon_height))
                final_top = y_cursor + (rh - icon_h) / 2.0 + offset_y
                if layer is not None:
                    icon_moves.append((layer, box_x + final_x, box_y + final_top - placed_top))
            else:
                lid = entry[6]
                baseline = y_cursor + (rh + text_size) / 2.0 - text_size * 0.12 + offset_y
                if lid is not None:
                    moves.append((lid, box_x + final_x, box_y + baseline))
            run_x += real_w + gap_w
        y_cursor += rh

    rem_bits = "".join(
        f"try {{ var L = __byId[{int(lid)}]; if (L) L.remove(); }} catch(e) {{}}" 
        for lid in remove_ids)
    move_bits = "".join(
        f"try {{ var L = __byId[{int(lid)}]; if (L) L.textItem.position = [{px}, {py}]; }} catch(e) {{}}"
        for (lid, px, py) in moves)
    fin_jsx = f"""
    (function() {{
        {_doc_anchor_jsx(doc)}
        function __findSet(node, id) {{
            var sets = node.layerSets;
            for (var i = 0; i < sets.length; i++) {{
                if (sets[i].id == id) return sets[i];
                var hit = __findSet(sets[i], id);
                if (hit) return hit;
            }}
            return null;
        }}
        try {{
            var parent = __findSet(doc, {gid});
            if (!parent) return false;
            var __byId = {{}};
            for (var i = parent.artLayers.length - 1; i >= 0; i--) {{
                var L = parent.artLayers[i];
                __byId[L.id] = L;
            }}
            {rem_bits}
            {move_bits}
        }} catch (e) {{ return false; }}
        return true;
    }})();
    """
    try:
        app.doJavaScript(fin_jsx)
    except Exception as exc:
        print(f"[Mapped Paytable] flow finalize JSX error: {exc}")
        _flow_remove_icon_layers(icon_layers)
        _cleanup_flow_layers(group, all_names)
        return None
    for layer, dx, dy in icon_moves:
        try:
            layer.translate(dx, dy)
        except Exception:
            pass

    for entry in entries:
        if not entry[2]:
            unit = entry[1]
            try:
                _MEASURE_WIDTH_CACHE[(str(unit.get("text", "")), int(text_size), str(font_name))] = max(1.0, entry[3])
            except Exception:
                pass
    if clipped_rows:
        _record_flow_warning(
            settings,
            f"Slot {name_prefix}: inline text needs {round(needed_height, 1)}px but the slot "
            f"has {round(box_h, 1)}px at {text_size}px; overflow rows were not rendered. "
            "Enlarge the JSON slot or choose a smaller font.",
        )
    return {
        "height": total_height,
        "lines": kept_rows,
        "text_size": text_size,
        "icon_height": icon_height,
    }


def _render_mapped_inline_flow(
        doc, app, group, text, box, settings, name_prefix,
        vertical_align="center", prepared_layout=None, max_height=None):
    """Place-measure-wrap rendering for mapped slots.

    The planned layout (fonts/sizes/units) is only a starting point. Every text
    unit is placed, then its REAL rendered width is measured from the actual
    layer; when the running row would exceed the slot width the unit moves to
    the next row. This keeps mapped-slot content inside its JSON slot even when
    the installed Photoshop renders glyphs wider than the plan predicted
    (font fallback, PPI, etc.). Real widths are cached so later plans in the
    same session start correct. Rows are clipped to ``max_height`` (the slot
    height) with a warning; content never renders outside the slot.
    """
    if not box or not text:
        return None
    layout = prepared_layout or _inline_layout(group, text, box, settings)
    if not layout or not layout.get("line_records"):
        return None

    font_name = layout["font_name"]
    text_size = int(layout["text_size"])
    text_rgb = layout["text_rgb"]
    icon_height = layout["icon_height"]
    gap = layout["gap"]
    max_width = max(1.0, float(layout["max_width"]))
    box_width = max(1.0, float(layout.get("box_width", box.get("w", 1.0))))
    box_x = float(box["x"])
    box_y = float(box["y"])
    box_h = max(1.0, float(max_height) if max_height else float(box.get("h", 1.0)))
    horizontal_align = str(
        box.get("horizontal_align") or box.get("align")
        or settings.get("paytable_notes_alignment") or "center"
    ).strip().casefold()
    if horizontal_align == "justify":
        horizontal_align = "left"
    if horizontal_align not in ("left", "center", "right"):
        horizontal_align = "center"

    # Flatten the planned unit stream in render order.
    units = []
    for line, _line_width, _line_height in layout.get("line_records", []):
        units.extend(line)
    if not units:
        return None

    if _FLOW_BATCH_ENABLED:
        # Fast path: batch-create the text units, bucket rows from the real
        # measured widths, finalize in one JSX. None -> legacy per-unit loop.
        fast = _flow_batch_place(
            doc, app, group, units, name_prefix, box,
            max_width, box_width, box_x, box_y, box_h,
            text_size, text_rgb, font_name, icon_height, gap,
            horizontal_align, vertical_align, settings,
        )
        if fast is not None:
            return fast

    # ---- placement pass: place at provisional x, measure the real width ----
    # Each entry: (layer, is_text, unit, placed_x, placed_top, real_w, gap_w)
    placed = []
    rows = []  # list of row entries
    row = []
    row_w = 0.0
    x_cursor = 0.0
    pending = list(units)
    first_unit = True
    while pending:
        unit = pending.pop(0)
        at_stream_end = not pending
        is_icon = unit["type"] == "icon"
        if is_icon:
            # Icons keep a symmetric gap: leading icons get the left margin too
            # and trailing icons the right margin, so an icon never sits flush
            # against the slot edge on one side only.
            pre_gap_w = float(gap) if (unit.get("pre_gap") or first_unit) else 0.0
            post_gap_w = float(gap) if (unit.get("post_gap") or at_stream_end) else 0.0
            icon_h = float(unit.get("h", icon_height))
            icon_box = {"x": x_cursor + pre_gap_w, "y": 0.0, "w": float(unit["w"]), "h": icon_h}
            layer = _place_asset(
                doc, app, group, unit["asset"], icon_box,
                f"{name_prefix} Icon {unit['token']}", max_height=icon_h,
            )
            real_w = float(unit["w"]) if layer is None else max(1.0, _layer_width(layer))
            gap_w = pre_gap_w + post_gap_w
            placed_x = x_cursor + pre_gap_w
            placed_top = 0.0
            if layer is not None:
                try:
                    placed_top = float(layer.bounds[1])
                except Exception:
                    pass
        else:
            pre_gap_w = 0.0
            post_gap_w = 0.0
            text_value = unit.get("text", "")
            if not text_value:
                continue
            layer = _add_text(
                group, text_value, x_cursor, 0.0, text_size, font_name, text_rgb,
                f"{name_prefix} Text {len(placed) + 1}",
            )
            real_w = max(1.0, _layer_width(layer))
            gap_w = 0.0
            placed_x = x_cursor
            placed_top = 0.0
            if layer is not None:
                try:
                    placed_top = float(layer.bounds[1])
                except Exception:
                    pass
        if row and row_w + real_w + gap_w > max_width:
            rows.append(row)
            row = []
            row_w = 0.0
            x_cursor = 0.0
        if not is_icon and not row and real_w > max_width:
            # A single run still renders wider than the slot even though the
            # plan split it at measured widths (real widths can be larger).
            # Split it again from REAL layers before placing.
            if layer is not None:
                try:
                    layer.remove()
                except Exception:
                    try:
                        layer.delete()
                    except Exception:
                        pass
            split_text = str(unit.get("text", ""))
            chunks = _split_unit_by_real_width(
                group, split_text, max_width, text_size, font_name, name_prefix)
            pending = [{"type": "text", "text": chunk} for chunk in chunks] + pending
            continue
        entry = (layer, is_icon, unit, placed_x, placed_top, real_w, gap_w, pre_gap_w)
        row.append(entry)
        placed.append(entry)
        row_w += real_w + gap_w
        x_cursor += real_w + gap_w
        first_unit = False
    if row:
        rows.append(row)
    if not rows:
        return None

    # Feed the real widths back so later plans in this session measure correctly.
    for layer, is_icon, unit, _px, _pt, real_w, _gw, _pw in placed:
        if not is_icon and layer is not None:
            try:
                cache_key = (str(unit.get("text", "")), int(text_size), str(font_name))
                _MEASURE_WIDTH_CACHE[cache_key] = max(1.0, real_w)
            except Exception:
                pass

    # ---- finalize: row heights, alignment, vertical position, clipping ----
    def row_metrics(entries):
        max_icon_h = max([float(e[2].get("h", 0.0)) for e in entries if e[1]] or [0.0])
        return max(float(text_size) * 1.25, float(text_size) + 8.0, max_icon_h + 8.0)

    total_height = 0.0
    row_heights = []
    for row_entries in rows:
        rh = row_metrics(row_entries)
        row_heights.append(rh)
        total_height += rh
    needed_height = total_height
    kept_rows = len(rows)
    clipped_rows = False
    if total_height > box_h:
        keep_count = 0
        used = 0.0
        for rh in row_heights:
            if used + rh > box_h + 0.01:
                break
            used += rh
            keep_count += 1
        if keep_count < len(rows):
            clipped_rows = True
        kept_rows = keep_count
        total_height = used
    if kept_rows == 0:
        return None

    if str(vertical_align).casefold() == "top":
        offset_y = 0.0
    elif str(vertical_align).casefold() == "bottom":
        offset_y = max(0.0, box_h - total_height)
    else:
        offset_y = max(0.0, (box_h - total_height) / 2.0)

    y_cursor = 0.0
    for row_index, row_entries in enumerate(rows):
        if row_index >= kept_rows:
            # Clipped rows must not stay in the document: remove their layers.
            for layer, is_icon, unit, _px, _pt, _rw, _gw, _pw in row_entries:
                if layer is None:
                    continue
                try:
                    layer.remove()
                except Exception:
                    try:
                        layer.delete()
                    except Exception:
                        pass
            continue
        row_width = sum(float(e[5]) + float(e[6]) for e in row_entries)
        if horizontal_align == "left":
            row_x0 = 0.0
        elif horizontal_align == "right":
            row_x0 = max(0.0, box_width - row_width)
        else:
            row_x0 = max(0.0, (box_width - row_width) / 2.0)
        rh = row_heights[row_index]
        run_x = 0.0
        for layer, is_icon, unit, placed_x, placed_top, real_w, gap_w, pre_gap_w in row_entries:
            final_x = row_x0 + run_x + pre_gap_w
            if is_icon:
                if layer is not None:
                    icon_h = float(unit.get("h", icon_height))
                    final_top = y_cursor + (rh - icon_h) / 2.0 + offset_y
                    try:
                        layer.translate(box_x + final_x - placed_x, box_y + final_top - placed_top)
                    except Exception:
                        pass
            else:
                if layer is not None:
                    baseline = y_cursor + (rh + text_size) / 2.0 - text_size * 0.12 + offset_y
                    try:
                        layer.textItem.position = [box_x + final_x, box_y + baseline]
                    except Exception:
                        pass
            run_x += real_w + gap_w
        y_cursor += rh

    if clipped_rows:
        _record_flow_warning(
            settings,
            f"Slot {name_prefix}: inline text needs {round(needed_height, 1)}px but the slot "
            f"has {round(box_h, 1)}px at {text_size}px; overflow rows were not rendered. "
            "Enlarge the JSON slot or choose a smaller font.",
        )
    return {
        "height": total_height,
        "lines": kept_rows,
        "text_size": text_size,
        "icon_height": icon_height,
    }


def _fit_heading_title_mixed(doc, app, group, text, box, size, font_name, rgb, name_prefix, settings, min_size=12):
    """Render a heading/title line that can include one inline icon token."""
    if not box or not text:
        return False
    requested_size = max(1, int(size or 1))
    try:
        requested_icon_height = int((settings or {}).get("heading_icon_height") or requested_size)
    except Exception:
        requested_icon_height = requested_size
    best = None
    for current_size in range(requested_size, max(1, int(min_size)) - 1, -2):
        scaled_icon_height = max(1, int(round(float(requested_icon_height) * (float(current_size) / float(requested_size)))))
        title_settings = dict(settings or {})
        title_settings.update({
            "body_font": font_name,
            "wild_text_size": int(current_size),
            "wild_text_rgb": tuple(rgb or (255, 255, 255)),
            "inline_icon_height": max(1, min(scaled_icon_height, int(float(box.get("h", scaled_icon_height))))),
            "inline_icon_gap": max(6, int(current_size * 0.12)),
            "paytable_notes_alignment": "center",
            "parse_icon_tokens": True,
        })
        layout = _inline_layout(group, text, box, title_settings)
        if not layout:
            continue
        best = (layout, title_settings)
        if len(layout.get("line_records") or []) == 1:
            _render_inline_mixed(
                doc, app, group, text, box, title_settings, name_prefix,
                vertical_align="center", prepared_layout=layout,
            )
            return True
    if best:
        layout, title_settings = best
        _render_inline_mixed(
            doc, app, group, text, box, title_settings, name_prefix,
            vertical_align="center", prepared_layout=layout,
        )
        return True
    return False


def _render_substitution_panel(doc, app, group, line, tokens, box, settings):
    with _timed("paytable_substitution_panel"):
        return _render_substitution_panel_impl(doc, app, group, line, tokens, box, settings)


def _render_substitution_panel_impl(doc, app, group, line, tokens, box, settings):
    if not box or not line:
        return
    # The first token identifies the substituting WILD symbol, which already has
    # its own image slots. Remove only that token; preserve every comma, space,
    # conjunction and final period in the remaining sentence.
    content = re.sub(r"^\s*<[^>]+>\s*", "", line, count=1)
    _render_inline_mixed(doc, app, group, content, box, settings, "Wild Substitution")


def _ordered_text_slots(slots):
    """Return feature/wild text slots in numeric order, de-duped by box.
    
    Matches wild.textN, feature.textN, special.textN, and also
    wild.iconN.text, feature.iconN.text patterns.
    """
    pairs = []
    for name, box in slots.items():
        key = str(name).casefold()
        is_text_slot = (
            key.startswith("wild.text")
            or key.startswith("feature.text")
            or key.startswith("special.text")
            or key.endswith(".text")
        )
        if not is_text_slot:
            continue
        m = re.search(r"(\d+)$", key)
        idx = int(m.group(1)) if m else 999
        pairs.append((idx, name, box))
    pairs.sort(key=lambda p: (p[0], p[1]))
    seen = set()
    out = []
    for idx, name, box in pairs:
        sig = (round(float(box.get("x", 0))), round(float(box.get("y", 0))), round(float(box.get("w", 0))), round(float(box.get("h", 0))))
        if sig in seen:
            continue
        seen.add(sig)
        out.append(box)
    return out


def _flow_padding(value):
    if isinstance(value, (int, float)):
        amount = max(0.0, float(value))
        return amount, amount, amount, amount
    if isinstance(value, (list, tuple)):
        try:
            if len(value) == 2:
                vertical, horizontal = map(float, value)
                return max(0.0, vertical), max(0.0, horizontal), max(0.0, vertical), max(0.0, horizontal)
            if len(value) >= 4:
                top, right, bottom, left = map(float, value[:4])
                return tuple(max(0.0, item) for item in (top, right, bottom, left))
        except Exception:
            pass
    return 0.0, 0.0, 0.0, 0.0


def _flow_settings(base_settings, spec, requested_size, current_size):
    result = dict(base_settings or {})
    result["body_font"] = spec.get("font") or spec.get("font_name") or result.get("body_font", "ArialMT")
    result["wild_text_size"] = int(current_size)
    result["wild_text_rgb"] = _coerce_rgb(
        spec.get("color", spec.get("text_rgb", result.get("wild_text_rgb", result.get("body_rgb", (255, 255, 255))))),
        result.get("body_rgb", (255, 255, 255)),
    )
    base_icon_height = spec.get("icon_height", result.get("inline_icon_height", max(requested_size * 2, 36)))
    try:
        scaled_icon_height = float(base_icon_height) * float(current_size) / max(1.0, float(requested_size))
    except Exception:
        scaled_icon_height = max(current_size * 2, 36)
    result["inline_icon_height"] = max(int(current_size), int(round(scaled_icon_height)))
    if "icon_gap" in spec:
        result["inline_icon_gap"] = spec.get("icon_gap")
    if "line_height" in spec:
        result["inline_line_height"] = spec.get("line_height")
    result["parse_icon_tokens"] = str(spec.get("render_mode", "inline_flow")).casefold() != "text"
    return result


def _build_flow_region_plan(group, blocks, box, settings, spec, requested_size, current_size, preferred_gap):
    local_settings = _flow_settings(settings, spec, requested_size, current_size)
    layouts = []
    for block in blocks:
        block_settings = dict(local_settings)
        block_settings["_inline_icon_heights"] = block.get("inline_icon_heights", {})
        layout = _inline_layout(group, block.get("text", ""), box, block_settings)
        if layout:
            layouts.append((block, layout, block_settings))
    total_height = sum(layout["total_height"] for _, layout, _ in layouts)
    total_height += preferred_gap * max(0, len(layouts) - 1)
    return {
        "layouts": layouts,
        "settings": local_settings,
        "gap": preferred_gap,
        "height": total_height,
        "fits": total_height <= float(box["h"]) + 0.01,
        "requested_size": requested_size,
        "text_size": current_size,
        "emergency_fit": current_size != requested_size,
    }


def _plan_flow_region(group, blocks, box, settings, spec):
    requested_size = max(1, _coerce_int(spec.get("font_size"), settings.get("wild_text_size", settings.get("body_size", 30))))
    minimum_size = max(4, _coerce_int(
        spec.get("minimum_font_size", spec.get("emergency_minimum_font_size")),
        min(10, requested_size),
    ))
    minimum_size = min(minimum_size, requested_size)
    # The UI "Row Spacing" field (line_gap) is the source of truth for the
    # vertical distance between the union bounding boxes of consecutive rows.
    # It wins over the template's own gap/block_gap when the user set it.
    try:
        _ui_gap = settings.get("line_gap")
        if _ui_gap not in (None, ""):
            preferred_gap = max(0.0, float(_ui_gap))
        else:
            preferred_gap = max(0.0, float(spec.get("gap", spec.get("block_gap", 18)) or 0))
    except Exception:
        preferred_gap = max(0.0, float(spec.get("gap", spec.get("block_gap", 18)) or 0))
    best = None
    # Explicit user-set size renders at exactly that size (no auto-shrink),
    # matching the mapper preview / ".text" slot behavior.
    explicit_size = spec.get("size") is not None or spec.get("font_size") is not None
    sizes = [requested_size] if explicit_size else range(requested_size, minimum_size - 1, -1)
    for current_size in sizes:
        plan = _build_flow_region_plan(group, blocks, box, settings, spec, requested_size, current_size, preferred_gap)
        if not plan.get("layouts"):
            continue
        best = plan
        if plan["fits"]:
            return plan
    return best or _build_flow_region_plan(group, blocks, box, settings, spec, requested_size, minimum_size, preferred_gap)


def _clip_flow_plan(plan, maximum_height):
    """Keep complete lines inside a fixed-height mapped slot."""
    maximum_height = max(0.0, float(maximum_height))
    kept = []
    used_height = 0.0
    gap = float(plan.get("gap", 0.0))
    clipped = False
    for block, layout, block_settings in plan.get("layouts", []):
        leading_gap = gap if kept else 0.0
        available = maximum_height - used_height - leading_gap
        if available <= 0:
            clipped = True
            break
        records = []
        block_height = 0.0
        for record in layout.get("line_records", []):
            line_height = float(record[2])
            if block_height + line_height > available + 0.01:
                clipped = True
                break
            records.append(record)
            block_height += line_height
        if records:
            clipped_layout = dict(layout)
            clipped_layout["line_records"] = records
            clipped_layout["total_height"] = block_height
            kept.append((block, clipped_layout, block_settings))
            used_height += leading_gap + block_height
        if len(records) < len(layout.get("line_records", [])):
            clipped = True
            break
    if len(kept) < len(plan.get("layouts", [])):
        clipped = True
    result = dict(plan)
    result["layouts"] = kept
    result["height"] = used_height
    result["fits"] = True
    result["clipped"] = clipped
    return result


def _record_flow_warning(settings, message):
    print(f"[Paytable Flow] {message}")
    report = settings.get("_report_collector")
    if isinstance(report, dict):
        warnings = report.setdefault("warnings", [])
        if message not in warnings:
            warnings.append(message)


def _render_paragraph_block(doc, app, group, text, content_box, settings, name):
    with _timed("paytable_paragraph_block"):
        return _render_paragraph_block_impl(doc, app, group, text, content_box, settings, name)


def _render_paragraph_block_impl(doc, app, group, text, content_box, settings, name):
    """Render plain text as Photoshop paragraph text bounded to a box (5px inset)."""
    if not content_box or not text:
        return None
    font_name = settings.get("body_font", "ArialMT")
    requested_size = max(4, int(settings.get("wild_text_size", 30)))
    min_size = max(4, int(settings.get("minimum_font_size", 8)))
    text_rgb = _coerce_rgb(settings.get("wild_text_rgb"), (255, 255, 255))
    inset = 5.0
    para_w = max(1.0, float(content_box["w"]) - inset * 2)
    para_h = max(1.0, float(content_box["h"]) - inset * 2)
    para_x = float(content_box["x"]) + inset
    para_y = float(content_box["y"]) + inset

    best_layer = None
    for current_size in range(requested_size, int(min_size) - 1, -2):
        layer = group.artLayers.add()
        layer.kind = ps.LayerKind.TextLayer
        layer.name = "__para_measure__"
        try:
            layer.textItem.font = font_name
        except Exception:
            pass
        layer.textItem.size = max(1, int(_px_to_pt(current_size, layer)))
        layer.textItem.color = _rgb_color(text_rgb)
        try:
            layer.textItem.kind = ps.TextType.ParagraphText
        except AttributeError:
            layer.textItem.kind = 2  # ParagraphText fallback
        layer.textItem.width = para_w
        layer.textItem.height = para_h * 10  # generous for measurement
        layer.textItem.contents = str(text)
        # Center-align (try both new and legacy APIs)
        try:
            layer.textItem.paragraphStyle.alignment = 2
        except Exception:
            try:
                layer.textItem.justification = 2
            except Exception:
                pass
        layer.textItem.position = [para_x, para_y]

        try:
            bounds = layer.bounds
            actual_h = float(bounds[3]) - float(bounds[1])
        except Exception:
            actual_h = para_h + 1

        if actual_h <= para_h or current_size <= min_size:
            if best_layer:
                try:
                    best_layer.remove()
                except Exception:
                    pass
            best_layer = layer
            if actual_h <= para_h:
                break
        else:
            try:
                layer.remove()
            except Exception:
                pass

    if best_layer:
        best_layer.name = _safe_layer_name(name)
        best_layer.textItem.position = [para_x, para_y]
        try:
            bounds = best_layer.bounds
            best_layer.textItem.height = max(1.0, float(bounds[3]) - float(bounds[1]))
        except Exception:
            pass
    return best_layer


def _render_flow_regions(doc, app, parent_group, page_data, slots, settings, slot_prefix=""):
    with _timed("paytable_flow_regions"):
        return _render_flow_regions_impl(doc, app, parent_group, page_data, slots, settings, slot_prefix)


def _render_flow_regions_impl(doc, app, parent_group, page_data, slots, settings, slot_prefix=""):
    regions = list(page_data.get("flow_regions") or [])
    if not regions:
        return False

    flow_group = parent_group.layerSets.add()
    flow_group.name = "Dynamic Excel Text Flow"
    for warning in page_data.get("parser_summary", {}).get("flow_warnings", []):
        _record_flow_warning(settings, warning)

    for region_index, region in enumerate(regions, start=1):
        region_id = str(region.get("id") or f"Flow Region {region_index}")
        box = _slot(slots, region.get("slot"), region_id, slot_prefix=slot_prefix)
        if not box:
            _record_flow_warning(settings, f"{region_id}: template slot was not found.")
            continue
        blocks = [block for block in region.get("blocks", []) if str(block.get("text", "")).strip()]
        if not blocks:
            continue

        top_pad, right_pad, bottom_pad, left_pad = _flow_padding(region.get("padding", 0))
        content_box = {
            "x": float(box["x"]) + left_pad,
            "y": float(box["y"]) + top_pad,
            "w": max(1.0, float(box["w"]) - left_pad - right_pad),
            "h": max(1.0, float(box["h"]) - top_pad - bottom_pad),
        }
        plan = _plan_flow_region(flow_group, blocks, content_box, settings, region)
        if not plan or not plan.get("layouts"):
            continue
        if plan.get("fits") and plan.get("emergency_fit"):
            _record_flow_warning(
                settings,
                f"{region_id}: reduced mapped slot font from {plan['requested_size']}px "
                f"to {plan['text_size']}px to fit the JSON slot.",
            )
        if not plan["fits"]:
            message = (
                f"{region_id}: content needs {round(plan['height'], 1)}px but the slot has "
                f"{round(content_box['h'], 1)}px even at mapped minimum font size {plan['text_size']}px. "
                "Overflow lines were not rendered; enlarge the JSON slot or choose a smaller mapped font."
            )
            _record_flow_warning(settings, message)
            plan = _clip_flow_plan(plan, content_box["h"])
            if not plan.get("layouts"):
                continue

        region_group = flow_group.layerSets.add()
        region_group.name = f"Flow - {region_id}"
        _render_slot_style_layers(doc, app, region_group, box, region, region_id)
        alignment = str(region.get("vertical_align", "top")).casefold()
        free_height = max(0.0, float(content_box["h"]) - float(plan["height"]))
        if alignment == "center":
            y = float(content_box["y"]) + free_height / 2.0
        elif alignment == "bottom":
            y = float(content_box["y"]) + free_height
        else:
            y = float(content_box["y"])

        for block_index, (block, layout, block_settings) in enumerate(plan["layouts"], start=1):
            block_text = block.get("text", "")
            has_tokens = bool(re.search(r"<[^>]+>", block_text))
            block_height = float(layout["total_height"])
            block_box = {
                "x": content_box["x"],
                "y": y,
                "w": content_box["w"],
                "h": block_height,
            }
            if has_tokens:
                _render_inline_mixed(
                    doc,
                    app,
                    region_group,
                    block_text,
                    block_box,
                    block_settings,
                    f"{region_id} Block {block_index}",
                    vertical_align="top",
                    prepared_layout=layout,
                )
                y += block_height + float(plan["gap"])
            else:
                # Text-only block: render with the SAME union-safe inline
                # renderer used for token blocks, so it stacks by its measured
                # union height + gap (exactly like the PNG renderer). The old
                # paragraph path font-fit the text to the whole remaining slot
                # and then jumped y to the content-box bottom, which placed
                # following rows (whose icons are taller than the text) at the
                # slot bottom and overlapped this line.
                _render_inline_mixed(
                    doc,
                    app,
                    region_group,
                    block_text,
                    block_box,
                    block_settings,
                    f"{region_id} Block {block_index}",
                    vertical_align="top",
                    prepared_layout=layout,
                )
                y += block_height + float(plan["gap"])
    return True


def _render_token_bindings(doc, app, parent_group, page_data, slots, settings, slot_prefix=""):
    with _timed("paytable_token_bindings"):
        return _render_token_bindings_impl(doc, app, parent_group, page_data, slots, settings, slot_prefix)


def _render_token_bindings_impl(doc, app, parent_group, page_data, slots, settings, slot_prefix=""):
    bindings = list(page_data.get("token_bindings") or [])
    if not bindings:
        return False
    binding_group = parent_group.layerSets.add()
    binding_group.name = "Mapped Excel Icons"
    for index, binding in enumerate(bindings, start=1):
        binding_id = str(binding.get("id") or f"Token Binding {index}")
        slot_name = str(binding.get("slot") or "")
        box = _slot(slots, slot_name, slot_prefix=slot_prefix)
        if not box:
            _record_flow_warning(settings, f"{binding_id}: template slot was not found: {slot_name}")
            continue
        _render_slot_style_layers(doc, app, binding_group, box, binding, binding_id)
        token = str(binding.get("token") or "").strip("<> ")
        asset = _token_asset(settings, token)
        try:
            max_height = int(binding.get("max_height", 0) or 0)
        except Exception:
            max_height = 0
        if asset:
            _place_asset(
                doc,
                app,
                binding_group,
                asset,
                box,
                f"Mapped Icon {index} - {token}",
                max_height=max_height or None,
                batchable=True,
            )
        else:
            _center_text(
                binding_group,
                f"<{token}>",
                box,
                int(settings.get("wild_text_size", 30)),
                settings.get("body_font", "ArialMT"),
                tuple(settings.get("wild_text_rgb", (255, 255, 255))),
                f"Missing Mapped Icon {index}",
            )
            _record_flow_warning(settings, f"Missing mapped icon asset: <{token}>")
    return True


def _render_side_panel(doc, app, parent_group, side, slots, settings, render_text=True, slot_prefix=""):
    with _timed("paytable_side_panel"):
        return _render_side_panel_impl(doc, app, parent_group, side, slots, settings, render_text, slot_prefix)


def _render_side_panel_impl(doc, app, parent_group, side, slots, settings, render_text=True, slot_prefix=""):
    side_group = parent_group.layerSets.add()
    side_group.name = "Feature Side Panel"
    title_box = _slot(slots, "feature.title", "wild.title", "special.title", slot_prefix=slot_prefix)
    if title_box:
        title_text = side.get("feature_title") or settings.get("wild_title", "WILD")
        title_group = side_group.layerSets.add()
        title_group.name = "Feature Title"
        _center_text(
            title_group,
            title_text,
            title_box,
            int(settings.get("wild_title_size", 72)),
            settings.get("heading_font", "ArialMT"),
            tuple(settings.get("wild_title_rgb", settings.get("heading_rgb", (255, 205, 50)))),
            "Feature Title Text",
        )
        apply_style_to_group_text_layers(app, doc, title_group, settings.get("heading_style"))

    feature_icons = _feature_assets(settings, side)
    icon_boxes = _wild_icon_boxes(slots)
    for index, box in enumerate(icon_boxes, start=1):
        info = feature_icons[min(index - 1, len(feature_icons) - 1)] if feature_icons else {"token": "Wild", "asset": None}
        asset = info.get("asset")
        token = info.get("token") or side.get("wild_token") or "Wild"
        if asset:
            _place_asset(
                doc, app, side_group, asset, box, f"Feature Symbol {index} - {token}",
                max_height=settings.get("wild_icon_height"),
                batchable=True,
            )
        else:
            _center_text(
                side_group,
                f"<{token}>",
                box,
                int(settings.get("wild_text_size", 30)),
                settings.get("body_font", "ArialMT"),
                tuple(settings.get("wild_text_rgb", (255, 255, 255))),
                f"Missing Feature Asset {index}",
            )

    if not render_text:
        return

    # Fill any available feature text slots sequentially. This supports layouts
    # with only one side text box, multiple side text boxes, or no substitution
    # sentence at all. If old data lacks feature_text_lines, fall back to legacy
    # substitution/reels fields.
    text_lines = list(side.get("feature_text_lines") or [])
    if not text_lines:
        for candidate in (side.get("substitution", ""), side.get("wild_reels", "")):
            if candidate:
                text_lines.append(candidate)

    for idx, box in enumerate(_ordered_text_slots(slots), start=1):
        if idx > len(text_lines):
            break
        line = text_lines[idx - 1]
        # Remove the main feature token only from substitution-style sentences,
        # because the main icon is already shown in its own slot. Keep tokens in
        # normal notes so <WILD>, <WILD2x>, <MrMonopoly>, etc. can render inline.
        lower = str(line).casefold()
        if "substitut" in lower:
            line = re.sub(r"^\s*<[^>]+>\s*", "", line, count=1)
        elif "appears on reel" in lower:
            line = re.sub(r"^\s*<[^>]+>\s*", "", line, count=1)
        _render_inline_mixed(doc, app, side_group, line, box, settings, f"Feature Text {idx}")

    notes = side.get("bottom_notes", [])
    notes_text = "\n".join([str(line) for line in notes if str(line).strip()])
    bottom_box = _slot(slots, "bottom_notes", "feature.notes", "notes", slot_prefix=slot_prefix)
    if notes_text and bottom_box:
        _render_inline_mixed(doc, app, side_group, notes_text, bottom_box, settings, "Bottom Notes")


def render_paytable_page(doc, app, parent_group, page_data, template, settings):
    """Render only the matched Paytable sheet into JSON-defined slots."""
    target_width = int(settings.get("canvas_width", 1920))
    target_height = int(settings.get("canvas_height", 1080))
    slots, _, _, _ = scale_template_slots(template, target_width, target_height)
    _apply_safe_bottom_to_slots(slots, target_height, settings.get("bottom_margin", 0))

    page_group = parent_group.layerSets.add()
    page_group.name = "Dynamic Paytable Addon"

    # Artist-authored optional backdrop for the entire mapped text panel.
    # Exporters may preserve either the raw @slot name or the stripped slot id.
    slot_prefix = str(template.get("slot_prefix") or "").strip()

    # Sheets can have fewer or more cards than the template's icon slots.
    # Fewer cards render only that many (unmatched template slots stay empty);
    # extra cards clone the last matched card row downward so every parsed
    # card still appears (e.g. 12 symbols on a 10-slot template).
    _top_n = len(page_data.get("top_cards") or [])
    auto_extend_card_slots(
        slots, page_data,
        lambda s, c, i, tc: _find_top_box(s, c, i, slot_prefix=slot_prefix),
        _card_index_aliases, card_type="top", settings=settings,
        canvas_height=target_height)
    auto_extend_card_slots(
        slots, page_data,
        lambda s, c, i, tc: _find_lower_box(s, c, i, top_count=tc, slot_prefix=slot_prefix),
        _card_index_aliases, card_type="lower", settings=settings,
        canvas_height=target_height, top_count=_top_n)

    text_bg_box = _slot(slots, "textBG", "@slot.textBG", "text.bg", "text_background", slot_prefix=slot_prefix)
    if text_bg_box:
        _create_rect(
            doc, app, page_group, text_bg_box, "Paytable Text Background",
            settings.get("text_bg_rgb", (10, 10, 18)),
            settings.get("text_bg_opacity", 70),
        )

    mapped_flow_slots = {
        str(region.get("slot") or region.get("id") or "").casefold()
        for region in page_data.get("flow_regions") or []
    }
    mapped_token_slots = {
        str(binding.get("slot") or "").casefold()
        for binding in page_data.get("token_bindings") or []
    }
    mapped_slots = {slot for slot in (mapped_flow_slots | mapped_token_slots) if slot}

    def _render_special_title(enabled, text, aliases, group_name):
        if not bool(enabled) or not str(text or "").strip():
            return None
        if any(str(alias).casefold() in mapped_flow_slots for alias in aliases):
            return None
        special_box = _slot(slots, *aliases, slot_prefix=slot_prefix)
        if not special_box:
            return None
        special_group = page_group.layerSets.add()
        special_group.name = group_name
        layer = _fit_center_text(
            special_group,
            str(text).strip(),
            special_box,
            int(settings.get("wild_title_size", settings.get("heading_size", 72))),
            settings.get("heading_font", "ArialMT"),
            tuple(settings.get("heading_rgb", settings.get("title_rgb", (255, 255, 255)))),
            f"{group_name} Text",
        )
        apply_style_to_group_text_layers(app, doc, special_group, settings.get("heading_style"))
        return layer

    _render_special_title(
        settings.get("wild_title_slot_enabled", False),
        settings.get("wild_title_slot_text", "WILD"),
        ("wildTitle", "@slot.wildTitle", "wild.title", "wild_title"),
        "Wild Title",
    )
    _render_special_title(
        settings.get("scatter_title_slot_enabled", False),
        settings.get("scatter_title_slot_text", "SCATTER"),
        ("scatterTitle", "@slot.scatterTitle", "scatter.title", "scatter_title"),
        "Scatter Title",
    )

    title_box = _slot(slots, "title", slot_prefix=slot_prefix)
    if title_box and "title" not in mapped_flow_slots:
        title_group = page_group.layerSets.add()
        title_group.name = "Paytable Title"
        raw_title = page_data.get("title", "PAYTABLE")
        title_text = _prepare_heading_text(raw_title, settings)
        title_size = int(settings.get("title_size", settings.get("heading_size", 72)))
        title_font = settings.get("heading_font", "ArialMT")
        title_rgb = tuple(settings.get("title_rgb", settings.get("heading_rgb", (255, 255, 255))))
        rendered_mixed_title = False
        if _game_name_heading_asset(raw_title, settings):
            rendered_mixed_title = _fit_heading_title_mixed(
                doc,
                app,
                title_group,
                title_text,
                title_box,
                title_size,
                title_font,
                title_rgb,
                "Paytable Title",
                settings,
                min_size=12,
            )
        if not rendered_mixed_title:
            _fit_center_text(
                title_group,
                title_text,
                title_box,
                title_size,
                title_font,
                title_rgb,
                "Paytable Title Text",
            )
        apply_style_to_group_text_layers(app, doc, title_group, settings.get("heading_style"))

    top_cards = page_data.get("top_cards", [])
    for index, card in enumerate(top_cards, start=1):
        box = _find_top_box(slots, card, index, slot_prefix=slot_prefix)
        if box:
            _render_card(doc, app, page_group, card, box, settings, "top", index, mapped_slots=mapped_slots, slots=slots, slot_prefix=slot_prefix)
        else:
            print(f"[Paytable Addon] No top slot for {card['label']}")

    top_cards = page_data.get("top_cards", [])
    top_count = len(top_cards)
    for index, card in enumerate(page_data.get("lower_cards", []), start=1):
        box = _find_lower_box(slots, card, index, top_count=top_count, slot_prefix=slot_prefix)
        if box:
            _render_card(
                doc, app, page_group, card, box, settings, "lower", index,
                mapped_slots=mapped_slots, top_count=top_count, slots=slots, slot_prefix=slot_prefix,
            )
        else:
            print(f"[Paytable Addon] No lower slot for {card['label']}")

    flow_regions = list(page_data.get("flow_regions") or [])
    has_flow_regions = bool(flow_regions)
    mapper_meta = template.get("mapper_meta") or {}
    mapper_authoritative = bool(has_flow_regions) and bool(
        mapper_meta.get("authoritative", mapper_meta.get("generated_by"))
    )
    replace_legacy_text = bool(template.get("flow_replaces_legacy_text", False)) or any(
        bool(region.get("replace_legacy_text", False)) for region in flow_regions
    )
    if not mapper_authoritative:
        _render_side_panel(
            doc,
            app,
            page_group,
            page_data.get("side_panel", {}),
            slots,
            settings,
            render_text=not replace_legacy_text,
            slot_prefix=slot_prefix,
        )
    else:
        # Auto-render wild/feature icons in dedicated icon slots even with mapper,
        # if those slots are not already covered by token bindings.
        side = page_data.get("side_panel", {})
        rendered_wild_tokens = set()
        for icon_name, icon_box in (slots or {}).items():
            key = str(icon_name).casefold()
            if not ("wild.icon" in key or "feature.icon" in key):
                continue
            if any(word in key for word in ("title", "text", "note")):
                continue
            if str(icon_name).casefold() in mapped_token_slots:
                continue
            w_asset = _wild_asset(settings, side)
            if w_asset:
                _place_asset(doc, app, page_group, w_asset, icon_box, f"Mapped {icon_name}",
                             max_height=settings.get("wild_icon_height"),
                             batchable=True)
            else:
                wild_token = str(side.get("wild_token") or "Wild").strip("<> ")
                _center_text(page_group, wild_token, icon_box,
                             int(settings.get("wild_text_size", 30)),
                             settings.get("body_font", "ArialMT"),
                             tuple(settings.get("wild_text_rgb", (255, 255, 255))),
                             f"Mapped {icon_name} Fallback")
            # Track which tokens were placed as dedicated icons so we can strip them from flow text.
            wt = str(side.get("wild_token") or "Wild").strip("<> ").casefold()
            if wt:
                rendered_wild_tokens.add(wt)
            for ft in (side.get("feature_tokens") or []):
                ftk = str(ft).strip("<> ").casefold()
                if ftk:
                    rendered_wild_tokens.add(ftk)

        # Strip dedicated wild/feature tokens from flow region text so they don't
        # render as inline icons inside text slots (double rendering).
        if rendered_wild_tokens:
            import re as _re_import
            for region in page_data.get("flow_regions") or []:
                for block in region.get("blocks") or []:
                    text = str(block.get("text") or "")
                    new_parts = []
                    for part in _re_import.split(r"(<[^>]+>)", text):
                        if part.startswith("<") and part.endswith(">"):
                            token_key = part.strip("<> ").casefold()
                            if token_key in rendered_wild_tokens:
                                continue
                        new_parts.append(part)
                    cleaned = "".join(new_parts).strip()
                    cleaned = _re_import.sub(r"\s+", " ", cleaned)
                    block["text"] = cleaned
    if has_flow_regions:
        for _fr in flow_regions:
            _fr_slot = str(_fr.get("slot", ""))
            _fr_blocks = _fr.get("blocks") or []
            _fr_texts = [str(b.get("text", "")) for b in _fr_blocks if isinstance(b, dict)]
            print(f"[Paytable Flow Debug] slot={_fr_slot} blocks={len(_fr_blocks)} texts={_fr_texts}")
        _render_flow_regions(doc, app, page_group, page_data, slots, settings, slot_prefix=slot_prefix)
    _render_token_bindings(doc, app, page_group, page_data, slots, settings, slot_prefix=slot_prefix)
    summary = page_data.get("parser_summary", {})
    print(
        "[Paytable Addon] Rendered exact matched sheet. "
        f"Top={summary.get('top_cards', 0)}, lower={summary.get('lower_cards', 0)}, "
        f"symbols={summary.get('all_cards', [])}"
    )
    _flush_paytable_batches(app, doc)
    return page_group


# ---------------------------------------------------------------------------
# Mapped paytable mode (web Paytable Mapper: @slot.* PSD + per-slot mappings)
# ---------------------------------------------------------------------------

_IMAGE_EXTENSIONS = (".png", ".jpg", ".jpeg", ".gif", ".bmp", ".svg")


def _justification_for(halign):
    if halign == "left":
        return ps.Justification.Left
    if halign == "right":
        return ps.Justification.Right
    return ps.Justification.Center


_MAPPED_SLOT_JUST = {
    "left": "Justification.LEFT",
    "right": "Justification.RIGHT",
    "center": "Justification.CENTER",
}


def _create_mapped_slot_fast(group, contents, name, size_px, font_name, rgb,
                             anchor_x, baseline_y, halign, leading_pt, box_x, box_w):
    """Create a mapped slot text layer in ONE JSX call: text, size, font, color,
    justification, leading, anchor position AND the bounds-based anchor nudge
    (previously ~4 COM round trips + one JSX). Returns (layer_id, real_width)
    or None when the fast path cannot run (caller falls back to COM)."""
    if not _MAPPED_SLOT_FAST_ENABLED:
        return None
    try:
        doc, app = _doc_and_app_from(group)
        gid = int(group.id)
    except Exception:
        return None
    contents_s = json.dumps(str(contents))
    font_s = json.dumps(str(font_name or ""))
    name_s = json.dumps(str(name))
    r, g, b = (int(c) for c in tuple(rgb or (255, 255, 255))[:3])
    size_pt = max(1, int(_px_to_pt(size_px, doc)))
    lead_bit = f"try {{ l.textItem.leading = {float(leading_pt)}; }} catch(eLead) {{}}" if leading_pt else ""
    just = _MAPPED_SLOT_JUST.get(str(halign).casefold(), "Justification.CENTER")
    halign_l = str(halign).casefold()
    if halign_l == "left":
        actual_bit = "var actual = b[0];"
        expected_bit = f"var expected = {float(box_x)};"
    elif halign_l == "right":
        actual_bit = "var actual = b[2];"
        expected_bit = f"var expected = {float(box_x) + float(box_w)};"
    else:
        actual_bit = "var actual = (b[0] + b[2]) / 2.0;"
        expected_bit = f"var expected = ({float(box_x)} + {float(box_w)}) / 2.0;"
    jsx = f"""
    (function() {{
        {_doc_anchor_jsx(doc)}
        function __findSet(node, id) {{
            var sets = node.layerSets;
            for (var i = 0; i < sets.length; i++) {{
                if (sets[i].id == id) return sets[i];
                var hit = __findSet(sets[i], id);
                if (hit) return hit;
            }}
            return null;
        }}
        try {{
            var parent = __findSet(doc, {gid});
            if (!parent) return "ERR|group not found";
            var l = parent.artLayers.add();
            l.name = {name_s};
            l.kind = LayerKind.TEXT;
            l.textItem.contents = {contents_s};
            l.textItem.size = {size_pt};
            try {{ l.textItem.font = {font_s}; }} catch(eFont) {{}}
            var c = new SolidColor();
            c.rgb.red = {r}; c.rgb.green = {g}; c.rgb.blue = {b};
            l.textItem.color = c;
            try {{ l.textItem.justification = {just}; }} catch(eJust) {{}}
            {lead_bit}
            l.textItem.position = [{float(anchor_x)}, {float(baseline_y)}];
            var b = l.bounds;
            {actual_bit}
            {expected_bit}
            if (Math.abs(actual - expected) > 1.0) {{
                l.textItem.position = [{float(anchor_x)} - (actual - expected), {float(baseline_y)}];
                var b2 = l.bounds;
                return "OK|" + l.id + "|" + (b2[2] - b2[0]);
            }}
            return "OK|" + l.id + "|" + (b[2] - b[0]);
        }} catch (e) {{
            return "ERR|" + e;
        }}
    }})();
    """
    try:
        result = app.doJavaScript(jsx)
    except Exception as exc:
        print(f"[Mapped Paytable] slot fast-path JSX error: {exc}")
        _remove_layer_by_name(group, str(name))
        return None
    parsed = None
    if isinstance(result, str):
        parts = [p.strip() for p in result.split("|")]
        if len(parts) == 1 and "," in result:
            parts = [p.strip() for p in result.split(",")]
        if len(parts) >= 3 and str(parts[0]).casefold() in ("ok", "true"):
            try:
                parsed = (int(float(parts[1])), float(parts[2]))
            except Exception:
                parsed = None
    elif isinstance(result, (list, tuple)):
        if len(result) >= 3 and str(result[0]).casefold() in ("ok", "true"):
            try:
                parsed = (int(result[1]), float(result[2]))
            except Exception:
                parsed = None
    if parsed is not None:
        _PROFILER.inc("paytable_slot_fast_ok")
        return parsed
    _PROFILER.inc("paytable_slot_fast_fail")
    # The JSX may already have created the layer; remove it by name so the
    # caller's COM fallback never leaves a duplicate layer behind.
    _remove_layer_by_name(group, str(name))
    _PROFILER.events.append({
        "name": f"slot_fast_result: {str(result)[:160]}",
        "seconds": 0.0,
    })
    print(f"[Mapped Paytable] slot fast path result unparsable ({result!r}), COM fallback")
    return None


def _remove_layer_by_id(group, layer_id):
    """Remove a freshly created layer by its JSX id (no COM re-acquire)."""
    try:
        doc, app = _doc_and_app_from(group)
        gid = int(group.id)
    except Exception:
        return False
    jsx = f"""
    (function() {{
        {_doc_anchor_jsx(doc)}
        function __findSet(node, id) {{
            var sets = node.layerSets;
            for (var i = 0; i < sets.length; i++) {{
                if (sets[i].id == id) return sets[i];
                var hit = __findSet(sets[i], id);
                if (hit) return hit;
            }}
            return null;
        }}
        try {{
            var parent = __findSet(doc, {gid});
            if (!parent) return false;
            for (var i = parent.artLayers.length - 1; i >= 0; i--) {{
                if (parent.artLayers[i].id == {int(layer_id)}) {{
                    parent.artLayers[i].remove();
                    return true;
                }}
            }}
        }} catch (e) {{}}
        return false;
    }})();
    """
    try:
        app.doJavaScript(jsx)
        return True
    except Exception:
        return False


def _remove_layer_by_name(group, layer_name):
    """Remove a layer in `group` by name (safety net for unparsable fast-path
    creates so the COM fallback never duplicates a layer)."""
    try:
        doc, app = _doc_and_app_from(group)
        gid = int(group.id)
    except Exception:
        return False
    jsx = f"""
    (function() {{
        {_doc_anchor_jsx(doc)}
        function __findSet(node, id) {{
            var sets = node.layerSets;
            for (var i = 0; i < sets.length; i++) {{
                if (sets[i].id == id) return sets[i];
                var hit = __findSet(sets[i], id);
                if (hit) return hit;
            }}
            return null;
        }}
        try {{
            var parent = __findSet(doc, {gid});
            if (!parent) return false;
            for (var i = parent.artLayers.length - 1; i >= 0; i--) {{
                if (parent.artLayers[i].name == {json.dumps(str(layer_name))}) {{
                    parent.artLayers[i].remove();
                    return true;
                }}
            }}
        }} catch (e) {{}}
        return false;
    }})();
    """
    try:
        app.doJavaScript(jsx)
        return True
    except Exception:
        return False


def _render_mapped_slot_text(group, text, box, spec, settings, name):
    """Render one mapped slot's text with per-slot font/size/color/alignment.

    Newline-separated source lines (e.g. one per Excel row in a pay/value
    range) become ONE multiline Photoshop text layer (lines joined with the
    Photoshop line break "\\r") so a stacked pay block like ``5\\n4\\n3\\n2``
    is a single layer — faster to build and easy to edit. The layer's
    paragraph justification is set per ``alignment`` so every line is
    left/center/right-aligned inside the slot box.

    Content never leaves the slot: lines are wrapped with the real measured
    glyph width, the font shrinks when the block is taller than the slot, and
    any remaining overflow lines are clipped. When the text already fits
    (e.g. pay/value stacks) the rendering is unchanged.
    """
    if not box or not text:
        return
    font_name = str(spec.get("font") or spec.get("font_name") or settings.get("body_font", "ArialMT"))
    requested_size = max(4, _coerce_int(spec.get("size") or spec.get("font_size"), settings.get("wild_text_size", 30)))
    rgb = _coerce_rgb(spec.get("rgb") or spec.get("color"), settings.get("wild_text_rgb", (255, 255, 255)))
    top_pad, right_pad, bottom_pad, left_pad = _flow_padding(spec.get("padding"))
    box_x = float(box["x"]) + left_pad
    box_y = float(box["y"]) + top_pad
    box_w = max(1.0, float(box["w"]) - left_pad - right_pad)
    box_h = max(1.0, float(box["h"]) - top_pad - bottom_pad)
    wrap_width = max(1.0, box_w - 2.0)
    target_wrap = wrap_width
    minimum_size = max(4, min(requested_size, _coerce_int(
        spec.get("minimum_font_size") or spec.get("emergency_minimum_font_size"), min(10, requested_size))))

    # The plan wraps with measured glyph widths; the REAL rendered width can
    # still come out larger (font fallback / PPI differences). When that
    # happens the layer is re-built at a smaller size until it truly fits the
    # slot width, so plain mapped text never renders outside its JSON slot.
    layer = None
    # An explicit user-set size (font_size/size in the mapping) renders at
    # exactly that size — no auto-shrink, exactly like the mapper preview and
    # the ".text" slot. Only mappings WITHOUT an explicit size auto-fit the
    # box (template default typography).
    explicit_size = spec.get("size") is not None or spec.get("font_size") is not None
    sizes = [requested_size] if explicit_size else range(requested_size, minimum_size - 1, -2)
    for _attempt in range(6):
        best = None
        for current_size in sizes:
            lines = []
            for source in str(text or "").split("\n"):
                lines.extend(_measured_wrap(group, str(source or ""), current_size, font_name, wrap_width))
            if not lines:
                continue
            manual_lh = max(0, _coerce_int(spec.get("line_height"), 0))
            line_height = max(float(current_size) * 1.18, float(current_size) + 2, float(manual_lh))
            total_height = len(lines) * line_height
            if explicit_size or total_height <= box_h or current_size <= minimum_size:
                best = (current_size, lines, line_height, total_height)
                break
        if not best:
            return
        current_size, lines, line_height, total_height = best
        clipped = False
        if total_height > box_h:
            keep = int(max(0.0, float(box_h)) // line_height)
            lines = lines[:keep]
            total_height = len(lines) * line_height
            if not lines:
                return
            clipped = True
        valign = str(spec.get("vertical_align") or "center").casefold()
        if valign == "top":
            top = box_y
        elif valign == "bottom":
            top = box_y + max(0.0, float(box_h) - total_height)
        else:
            top = box_y + max(0.0, (float(box_h) - total_height) / 2.0)
        halign = str(spec.get("alignment") or spec.get("align") or spec.get("horizontal_align") or "center").casefold()
        content = "\r".join(lines)
        baseline_y = top + line_height * 0.72
        layer_name = f"{name} Text"
        if halign == "left":
            anchor_x = box_x
        elif halign == "right":
            anchor_x = box_x + float(box_w)
        else:
            anchor_x = box_x + float(box_w) / 2.0
        layer = None
        layer_id = None
        real_width = 0.0
        clipped_leading_pt = None
        if clipped:
            # Pin the leading to our line-height estimate so the clipped block
            # renders exactly inside the slot (auto leading could push the last
            # line below the box edge).
            clipped_leading_pt = max(1, int(_px_to_pt(line_height, group)))
        fast = _create_mapped_slot_fast(
            group, content, layer_name, current_size, font_name, rgb,
            anchor_x, baseline_y, halign, clipped_leading_pt,
            box_x, float(box_w),
        )
        if fast is not None:
            layer_id, real_width = fast
        else:
            # COM fallback: exactly the original create + per-property sets.
            layer = _add_text(group, content, box_x, baseline_y, current_size, font_name, rgb, layer_name)
            if clipped_leading_pt is not None:
                try:
                    layer.textItem.leading = clipped_leading_pt
                except Exception:
                    pass
            # Center/right/left the lines INSIDE the layer: Photoshop justifies point
            # text lines around the anchor point (textItem.position), so the anchor
            # goes to the box center (right edge for right, left edge for left).
            try:
                layer.textItem.justification = _justification_for(halign)
            except Exception as exc:
                print(f"[Mapped Paytable] could not set justification ({halign}) on {layer_name}: {exc}")
            layer.textItem.position = [anchor_x, baseline_y]
            # Guard: verify the measured text edge lands where expected and nudge the
            # anchor if this Photoshop build anchors point text differently.
            try:
                bounds = layer.bounds
                left = float(bounds[0])
                right = float(bounds[2])
                real_width = right - left
                if halign == "left":
                    expected, actual = box_x, left
                elif halign == "right":
                    expected, actual = box_x + float(box_w), right
                else:
                    expected, actual = box_x + float(box_w) / 2.0, (left + right) / 2.0
                if abs(actual - expected) > 1.0:
                    layer.textItem.position = [anchor_x - (actual - expected), baseline_y]
            except Exception:
                pass
        if real_width <= target_wrap + 1.0 or current_size <= minimum_size:
            break
        if layer_id is not None:
            _remove_layer_by_id(group, layer_id)
        else:
            try:
                layer.remove()
            except Exception:
                try:
                    layer.delete()
                except Exception:
                    pass
        # The real line is wider than the plan predicted (font fallback / PPI
        # drift). Tighten the wrap by the measured ratio and re-wrap at the
        # same font size; this converges geometrically in a few attempts.
        wrap_width = max(2.0, wrap_width * wrap_width / max(1.0, real_width))


_PAYTABLE_TEXT_SLOT_NAMES = {
    "title", "count", "payout", "payouts", "notes", "text", "note",
    "label", "description", "subtitle", "heading",
}


def _default_icon_mapping(slot_name):
    """Name-based default mapping: ``@slot.whatever`` renders the ``<whatever>``
    icon (case-insensitive file lookup). Text-ish names, text sections
    (``text.1``), pay/value names and wild-number slots (``wild.1`` ->
    ``<wild>``) are handled. Returns a mapping spec or None."""
    raw = str(slot_name or "")
    parts = raw.split(".")
    last = (parts.pop() or "").strip()
    first = (parts[0] if parts else last).strip()
    norm = re.sub(r"[^a-z0-9]", "", last.casefold())
    first_norm = re.sub(r"[^a-z0-9]", "", first.casefold())
    if not norm:
        return None
    if (norm in _PAYTABLE_TEXT_SLOT_NAMES or first_norm in _PAYTABLE_TEXT_SLOT_NAMES
            or re.fullmatch(r"(pay|value)s?\d*", norm)):
        return None
    token = "<wild>" if first_norm == "wild" and re.fullmatch(r"\d+", norm) else f"<{norm}>"
    return {
        "mode": "icon",
        "token": token,
        "slot": raw,
        "icon_height": 120,
        "color": "#FFFFFF",
        "alignment": "center",
        "vertical_align": "center",
        "padding": [0, 0, 0, 0],
    }


def _fill_default_icon_mappings(mappings, slots):
    """Give every unmapped non-bounds symbol slot a name-based icon default so
    @slot.whatever always renders its <whatever> icon in Photoshop."""
    from ps_autotypesetter.table_mapping import _slot_name_is_bounds_like

    for slot_name in (slots or {}):
        if slot_name in mappings:
            continue
        if _slot_name_is_bounds_like(str(slot_name)):
            continue
        default = _default_icon_mapping(slot_name)
        if default:
            mappings[slot_name] = default


def _sanitize_mapped_specs(mappings, worksheet):
    """Heal stale mappings before rendering:

      * excel-mode mappings whose single-cell source does not exist in the
        worksheet (e.g. slot ``pic1`` saved with source ``PIC1`` — a phantom
        cell) fall back to the name-based icon default so the slot still
        renders its <name> icon;
      * icon/symbol mappings on text-ish names or style-less bounds slots
        (leftovers of old automap runs) are dropped.
    """
    from ps_autotypesetter.table_mapping import _slot_name_is_bounds_like

    fixed = 0
    for slot_name, spec in list(mappings.items()):
        if not isinstance(spec, dict):
            continue
        mode = str(spec.get("mode") or "").casefold()
        has_style = any(spec.get(k) for k in (
            "background_color", "fill_color", "stroke_color",
            "fill_enabled", "stroke_enabled", "opacity"))
        if _slot_name_is_bounds_like(str(slot_name)):
            if not has_style:
                del mappings[slot_name]
                fixed += 1
            continue
        if mode in {"icon", "symbol"} and _default_icon_mapping(slot_name) is None:
            del mappings[slot_name]
            fixed += 1
            continue
        if mode != "excel" or worksheet is None:
            continue
        source = str(spec.get("source") or "").strip()
        if not source or ":" in source or "," in source or ";" in source or "\n" in source:
            continue
        match = re.fullmatch(r"([A-Za-z]{1,3})(\d+)", source)
        if not match:
            continue
        try:
            value = worksheet[f"{match.group(1)}{match.group(2)}"].value
        except Exception:
            value = None
        if value is not None:
            continue
        default = _default_icon_mapping(slot_name)
        if default:
            mappings[slot_name] = default
            fixed += 1
    return fixed


def _slot_is_title(slot_name):
    """True for the page-heading slot: ``@slot.title`` / ``title`` (the
    ``wild.title`` feature slot is not the page heading)."""
    raw = str(slot_name or "").strip()
    for pfx in ("@slot.", "@table."):
        if raw.casefold().startswith(pfx.casefold()):
            raw = raw[len(pfx):]
            break
    return re.sub(r"\s+", "", raw).casefold() == "title"


def _slot_is_wild_title(slot_name):
    """True for the hardcoded WILD feature slot: ``@slot.wild.title`` /
    ``wild.text`` (plus the ``feature.title`` / ``special.title`` aliases).
    This slot always renders "WILD" with the heading typography unless the
    user explicitly maps it."""
    raw = str(slot_name or "").strip()
    for pfx in ("@slot.", "@table."):
        if raw.casefold().startswith(pfx.casefold()):
            raw = raw[len(pfx):]
            break
    return re.sub(r"\s+", "", raw).casefold() in {"wild.title", "wild.text", "feature.title", "special.title"}


def _filter_mappings_to_sheet(mappings, worksheet, template):
    """Drop mapping specs for cards the CURRENT worksheet no longer contains.

    The mapped template JSON was saved against some other sheet (10 cards);
    the sheet actually being rendered may hold fewer (9). Icon/pay/value
    specs whose symbol has no anchor in the live sheet, and card-background
    fills (``TopCardsBG.N`` / ``BottomCardsBG.N``) beyond the sheet's card
    counts, are skipped so only what's present in Excel renders. Title /
    wild-title / text / legend slots are never dropped.
    """
    try:
        from ps_autotypesetter.ui_web.engine_api import filter_paytable_mappings_to_sheet

        return filter_paytable_mappings_to_sheet(mappings, worksheet, template)
    except Exception:
        return 0


def _page_heading_text(worksheet, template):
    """The page heading text the card renderer would use (from the sheet)."""
    try:
        from .parser import parse_paytable_sheet

        parsed = parse_paytable_sheet(worksheet, template=template)
        return str((parsed or {}).get("title") or "").strip()
    except Exception:
        return ""


_CELL_LIKE_RE = re.compile(r"^[A-Za-z]{1,3}[0-9]{1,7}$")


def _cell_like_source(value):
    return bool(_CELL_LIKE_RE.match(str(value or "").strip()))


def _render_page_title_slot(doc, app, page_group, box, spec, slot_name, text, settings):
    """Render the page-heading slot (@slot.title) with heading typography."""
    text = str(text or "").strip()
    if not text:
        return None
    _render_slot_style_layers(doc, app, page_group, box, spec, slot_name)
    title_group = page_group.layerSets.add()
    title_group.name = f"Slot {slot_name}"
    default_title_size = _coerce_int(
        settings.get("title_size", settings.get("heading_size", 72)), 72)
    user_size = _coerce_int(spec.get("font_size"), 0)
    title_size = user_size if user_size not in (0, 30) else default_title_size
    title_font = str(
        spec.get("font_name") or spec.get("font")
        or settings.get("heading_font", "ArialMT"))
    user_rgb = _coerce_rgb(spec.get("color"), None)
    if user_rgb is None or tuple(user_rgb) == (255, 255, 255):
        # The mapper's default white fill means "no explicit color chosen" —
        # the page heading follows the global main-heading treatment (h_rgb
        # plus the assigned "Heading text" layer style) like every other page.
        title_rgb = _coerce_rgb(
            settings.get("title_rgb"),
            _coerce_rgb(settings.get("heading_rgb"), (255, 255, 255)))
    else:
        title_rgb = user_rgb
    # Page headings always sit dead-center in their slot; per-slot
    # alignment only applies to data slots.
    _fit_center_text(
        title_group, text, box, title_size, title_font, title_rgb,
        f"Slot {slot_name} Title")
    apply_style_to_group_text_layers(app, doc, title_group, settings.get("heading_style"))
    return title_group


def _render_wild_title_slot(doc, app, page_group, box, spec, slot_name, text, settings):
    """Render the hardcoded WILD slot (@slot.wild.title) with heading typography."""
    text = str(text or "").strip()
    if not text:
        return None
    _render_slot_style_layers(doc, app, page_group, box, spec, slot_name)
    wild_group = page_group.layerSets.add()
    wild_group.name = f"Slot {slot_name}"
    default_wild_size = _coerce_int(
        settings.get("wild_title_size", settings.get("title_size", settings.get("heading_size", 72))), 72)
    user_size = _coerce_int(spec.get("font_size"), 0)
    wild_size = user_size if user_size not in (0, 30) else default_wild_size
    wild_font = str(
        spec.get("font_name") or spec.get("font")
        or settings.get("heading_font", "ArialMT"))
    user_wild_rgb = _coerce_rgb(spec.get("color"), None)
    if user_wild_rgb is None or tuple(user_wild_rgb) == (255, 255, 255):
        wild_rgb = _coerce_rgb(
            settings.get("wild_title_rgb"),
            _coerce_rgb(settings.get("title_rgb"),
                        _coerce_rgb(settings.get("heading_rgb"), (255, 205, 50))))
    else:
        wild_rgb = user_wild_rgb
    _fit_center_text(wild_group, text, box, wild_size, wild_font, wild_rgb, f"Slot {slot_name} Wild Title")
    apply_style_to_group_text_layers(app, doc, wild_group, settings.get("heading_style"))
    return wild_group


def render_mapped_paytable_page(doc, app, parent_group, worksheet, template, settings):
    """Render a mapper-authored paytable: every mapped @slot.* gets its data.

    Each mapping spec supports ``mode`` ("excel" reads the cell from the
    worksheet, "literal" uses the text as-is), per-slot font/size/color/
    alignment, optional fill/stroke rectangles, and image sources that are
    placed as assets instead of text.
    """
    template = template or {}
    slots = (template.get("slots") or {})
    raw_mappings = template.get("mappings") or {}
    if isinstance(raw_mappings, dict):
        mappings = raw_mappings
    elif isinstance(raw_mappings, list):
        mappings = {}
        for m in raw_mappings:
            if isinstance(m, dict) and m.get("slot"):
                mappings[str(m["slot"])] = m
    else:
        mappings = {}
    _sanitize_mapped_specs(mappings, worksheet)
    _fill_default_icon_mappings(mappings, slots)
    _filter_mappings_to_sheet(mappings, worksheet, template)
    if not isinstance(mappings, dict) or not mappings:
        return None
    target_width = int(settings.get("canvas_width", 1920))
    target_height = int(settings.get("canvas_height", 1080))
    scaled_slots, _, _, _ = scale_template_slots(template, target_width, target_height)
    _apply_safe_bottom_to_slots(scaled_slots, target_height, settings.get("bottom_margin", 0))

    page_group = parent_group.layerSets.add()
    page_group.name = "Mapped Paytable"

    for slot_name, spec in mappings.items():
        if not isinstance(spec, dict):
            continue
        box = _slot(scaled_slots, slot_name) or _slot(scaled_slots, str(slot_name).lstrip("@").strip("."))
        if not box:
            print(f"[Mapped Paytable] slot not found in template: {slot_name}")
            continue
        mode = str(spec.get("mode") or "excel").casefold()
        source = str(spec.get("source") or "")
        token = str(spec.get("token") or "").strip()
        text = ""
        if mode in {"icon", "symbol"} and token:
            text = token
        elif mode in {"excel", "excel_text"} and source:
            # Worksheet-first: re-read THIS page's sheet. The template JSON
            # stores the resolved text of the sheet it was saved against; when
            # one template is shared by several paytable tabs the stored text
            # must never leak from another tab — it is only a fallback when
            # the workbook cannot be read here.
            if worksheet is not None:
                try:
                    from ps_autotypesetter.table_mapping import resolve_paytable_source_text

                    # Keeps one source line per Excel row (pay/value ranges stack).
                    text = str(resolve_paytable_source_text(worksheet, source) or "").strip()
                except Exception as exc:
                    print(f"[Mapped Paytable] could not read Excel {source}: {exc}")
            if not text:
                text = str(spec.get("text") or "").strip()
        elif str(spec.get("text") or "").strip():
            # Literal resolved text (pay/value ranges are stored as
            # "5\n4\n3\n2") renders without a second Excel pass.
            text = str(spec.get("text") or "").strip()
        elif mode in {"literal", "mixed", "text"}:
            text = source
        text = str(text).strip()

        if _slot_is_title(slot_name) and mode not in {"icon", "symbol"}:
            # Page-heading slot: render the page heading with the typography
            # heading settings by default; the user can still override text
            # (excel/excel_text modes or literal non-cell text) and font/size/
            # color per slot.
            if (mode == "literal" and _cell_like_source(text)) or not text:
                text = _page_heading_text(worksheet, template)
            text = _prepare_heading_text(text, settings)
            _render_page_title_slot(doc, app, page_group, box, spec, slot_name, text, settings)
            continue

        if _slot_is_wild_title(slot_name) and mode not in {"icon", "symbol"}:
            # Hardcoded: this slot renders "WILD" with the heading typography
            # unless the user provided explicit text/source in the mapping.
            if not text:
                text = str(spec.get("text") or settings.get("wild_title", "WILD")).strip() or "WILD"
            _render_wild_title_slot(doc, app, page_group, box, spec, slot_name, text, settings)
            continue

        # Style layers (fill/stroke) render even when the slot has no text,
        # so pure-background slots (e.g. TopCardsBG.*) still get their fill.
        _render_slot_style_layers(doc, app, page_group, box, spec, slot_name)

        if not text:
            continue

        if mode in {"icon", "symbol"}:
            asset = resolve_icon_path(
                text,
                settings.get("asset_folder"),
                settings.get("icon_mappings"),
                [text, os.path.basename(text)],
            )
            if asset:
                _place_asset(
                    doc, app, page_group, asset, box,
                    f"Slot {slot_name} Asset",
                    max_height=spec.get("icon_height"),
                )
            continue

        if text.lower().endswith(_IMAGE_EXTENSIONS):
            asset = resolve_icon_path(
                text,
                settings.get("asset_folder"),
                settings.get("icon_mappings"),
                [text, os.path.basename(text)],
            )
            if asset:
                _place_asset(
                    doc, app, page_group, asset, box,
                    f"Slot {slot_name} Asset",
                    max_height=spec.get("icon_height"),
                )
                continue

        if mode in {"text", "excel_text"}:
            plain = re.sub(r"[ \t]+", " ", re.sub(r"<[^<>]+>", "", text)).strip()
            if plain:
                slot_group = page_group.layerSets.add()
                slot_group.name = f"Slot {slot_name}"
                _render_mapped_slot_text(slot_group, plain, box, spec, settings, f"Slot {slot_name}")
            continue

        # excel / literal / mixed: render <token> icons inline with the text.
        # Text that contains inline icons flows row by row inside the slot
        # (same rendering as side-panel/flow text) instead of stacking one
        # centered icon patch over a separate text layer. Tokens that do not
        # resolve to an icon are dropped (never shown as names). Plain text
        # without tokens keeps the stacked multiline rendering (pays/values).
        if re.search(r"<[^<>]+>", text):
            icon_height_setting = _coerce_int(spec.get("icon_height"), 0)
            inline_parts = []
            has_resolved_icon = False
            for part in re.split(r"(<[^<>]+>)", text):
                if not part:
                    continue
                if re.fullmatch(r"<[^<>]+>", part):
                    if icon_height_setting <= 0:
                        continue
                    asset = resolve_icon_path(
                        part,
                        settings.get("asset_folder"),
                        settings.get("icon_mappings"),
                        [part, part.strip("<>")],
                    )
                    if asset:
                        inline_parts.append(part)
                        has_resolved_icon = True
                    continue
                inline_parts.append(part)
            inline_text = re.sub(r"[ \t]+", " ", "".join(inline_parts)).strip()
            if has_resolved_icon and inline_text:
                flow_spec = dict(spec)
                if spec.get("size") is not None:
                    flow_spec["font_size"] = spec.get("size")
                halign = str(
                    spec.get("alignment") or spec.get("align")
                    or spec.get("horizontal_align") or "center"
                ).strip().casefold()
                inline_box = dict(box)
                tp_flow, rp_flow, bp_flow, lp_flow = _flow_padding(spec.get("padding"))
                inline_box["x"] = float(inline_box["x"]) + lp_flow
                inline_box["y"] = float(inline_box["y"]) + tp_flow
                inline_box["w"] = max(1.0, float(inline_box["w"]) - lp_flow - rp_flow)
                inline_box["h"] = max(1.0, float(inline_box["h"]) - tp_flow - bp_flow)
                inline_box["horizontal_align"] = halign
                slot_group = page_group.layerSets.add()
                slot_group.name = f"Slot {slot_name}"
                block_meta = {"text": inline_text}
                if flow_spec.get("inline_icon_heights"):
                    block_meta["inline_icon_heights"] = flow_spec.get("inline_icon_heights")
                plan = _plan_flow_region(slot_group, [block_meta], inline_box, settings, flow_spec)
                if not plan or not plan.get("layouts"):
                    continue
                block, layout, block_settings = plan["layouts"][0]
                # Placement-measured flow: every unit is placed and its real
                # rendered width is measured; rows break inside the slot and
                # rows are clipped to the slot height with a warning.
                _render_mapped_inline_flow(
                    doc, app, slot_group, inline_text, inline_box, block_settings,
                    f"Slot {slot_name}",
                    vertical_align=str(spec.get("vertical_align") or "center").casefold(),
                    prepared_layout=layout,
                    max_height=float(inline_box["h"]),
                )
                continue
            text = inline_text
        plain = re.sub(r"[ \t]+", " ", re.sub(r"<[^<>]+>", "", text)).strip()
        if plain:
            slot_group = page_group.layerSets.add()
            slot_group.name = f"Slot {slot_name}"
            _render_mapped_slot_text(slot_group, plain, box, spec, settings, f"Slot {slot_name}")

    # Unmapped special slots: any template slot named @slot.title renders the
    # page heading with the heading typography, and any @slot.wild.title /
    # wild.text / feature.title / special.title slot renders "WILD" with the
    # heading typography -- even when the user never mapped it.
    covered = set()
    for slot_name in mappings:
        covered.add(slot_name)
        covered.add(str(slot_name).lstrip("@").strip("."))
    for slot_name in scaled_slots:
        if slot_name in covered:
            continue
        box = _slot(scaled_slots, slot_name)
        if not box:
            continue
        if _slot_is_title(slot_name):
            text = _prepare_heading_text(_page_heading_text(worksheet, template), settings)
            if text:
                _render_page_title_slot(doc, app, page_group, box, {}, slot_name, text, settings)
                print(f"[Mapped Paytable] auto-rendered unmapped title slot: {slot_name}")
        elif _slot_is_wild_title(slot_name):
            text = str(settings.get("wild_title", "WILD")).strip() or "WILD"
            _render_wild_title_slot(doc, app, page_group, box, {}, slot_name, text, settings)
            print(f"[Mapped Paytable] auto-rendered unmapped WILD slot: {slot_name}")

    # Templates without any title slot still render the page heading the
    # normal way (every other page): top-center with the heading typography
    # (heading_font/size/rgb, heading_top_margin).
    if not any(_slot_is_title(slot_name) for slot_name in scaled_slots):
        fallback_title = _prepare_heading_text(_page_heading_text(worksheet, template), settings)
        if fallback_title:
            try:
                margin = int(float(settings.get("heading_top_margin") or 120))
            except Exception:
                margin = 120
            try:
                fallback_size = int(float(settings.get("title_size") or settings.get("heading_size") or 90))
            except Exception:
                fallback_size = 90
            fallback_rgb = _coerce_rgb(
                settings.get("title_rgb"),
                _coerce_rgb(settings.get("heading_rgb"), (255, 255, 255)))
            fallback_box = {
                "x": 0.0,
                "y": float(margin),
                "w": float(target_width),
                "h": float(fallback_size) * 1.4,
            }
            heading_group = page_group.layerSets.add()
            heading_group.name = "Page Heading"
            _fit_center_text(
                heading_group, fallback_title, fallback_box, fallback_size,
                str(settings.get("heading_font") or "ArialMT"),
                fallback_rgb, "Page Heading")
            apply_style_to_group_text_layers(app, doc, heading_group, settings.get("heading_style"))
            print(f"[Mapped Paytable] auto-rendered title without a title slot: {fallback_title}")

    print(f"[Mapped Paytable] rendered {len(mappings)} mapped slot(s).")
    _flush_paytable_batches(app, doc)
    return page_group
