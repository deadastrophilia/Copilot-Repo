"""Excel-driven card grid for mapped paytable templates.

A mapped template stores fixed card boxes (e.g. 5 top + 5 bottom). A game's
paytable sheet decides how many cards there really are: every card before the
first <ace> is a top card, <ace> and everything after it is the bottom band
(engine_api card_counts). When a band's card count differs from the
template's, that band is rebuilt at render time:

  * the band's first card (symbol + pay + value + background) is the prototype;
  * the band's area is the union of its template cards;
  * Excel's cards are laid out in that area with the template's row count and
    spacing, each row centred, shrunk only when they would not fit;
  * every card gets its own symbol token and pay/value cells from Excel, and
    keeps a symbol the artist picked by hand for that card name.

A band whose count already matches is left exactly as designed, so manual
tweaks to individual cards survive. Learned artist layouts are fitted by
artist_design.fit_cards instead.
"""
import copy
import math
import re

_BG_RE = re.compile(r"^(topcardsbg|bottomcardsbg|cardbg)\.(\d+)$")
_DATA_RE = re.compile(r"^(.+?)\.(pay|value)s?$")
OWN_LOOK_SUFFIX = "@card"
# what a card's own override may NOT change: its data binding and identity
_STRUCTURAL = {"slot", "mode", "role", "symbol", "source", "token", "text", "source_pinned", "card_override",
               "asset_path", "symbol_pinned", "pinned_excel"}
_KEEP_FROM_USER = ("asset_path", "symbol_pinned")      # the image choice, not stale sizes


def _norm(name):
    name = str(name or "").strip()
    for pfx in ("@slot.", "@table."):
        if name.casefold().startswith(pfx):
            name = name[len(pfx):]
            break
    return re.sub(r"\s+", "", name).casefold()


def _box(b):
    try:
        return float(b["x"]), float(b["y"]), float(b["w"]), float(b["h"])
    except Exception:
        return None


def _union(boxes):
    boxes = [b for b in boxes if b]
    x0 = min(b[0] for b in boxes)
    y0 = min(b[1] for b in boxes)
    x1 = max(b[0] + b[2] for b in boxes)
    y1 = max(b[1] + b[3] for b in boxes)
    return x0, y0, x1 - x0, y1 - y0


def _mapping_dict(mappings):
    if isinstance(mappings, dict):
        return {k: v for k, v in mappings.items() if isinstance(v, dict)}
    out = {}
    for m in mappings or []:
        if isinstance(m, dict) and m.get("slot"):
            out[str(m["slot"])] = m
    return out


def template_cards(template):
    """Cards in a template: [{"key", "members": {role: slot name}, "box", "bg_kind"}]."""
    slots = (template or {}).get("slots") or {}
    mappings = _mapping_dict((template or {}).get("mappings"))
    by_norm = {_norm(n): n for n in slots}
    bgs = []
    for n in slots:
        m = _BG_RE.match(_norm(n))
        if m and _box(slots[n]):
            bgs.append((n, m.group(1)))
    cards = []
    for n in slots:
        base = _norm(n)
        if _BG_RE.match(base) or _DATA_RE.match(base) or "." in base:
            continue
        pay, value = by_norm.get(base + ".pay"), by_norm.get(base + ".value")
        if not (pay or value):
            continue
        spec = mappings.get(n) or {}
        if str(spec.get("mode") or "icon").casefold() != "icon" or base in ("wild", "title", "text"):
            continue
        sb = _box(slots[n])
        if not sb:
            continue
        members = {"symbol": n}
        if pay:
            members["pay"] = pay
        if value:
            members["value"] = value
        cx, cy = sb[0] + sb[2] / 2.0, sb[1] + sb[3] / 2.0
        bg_kind = None
        for bg, kind in bgs:
            b = _box(slots[bg])
            if b[0] <= cx <= b[0] + b[2] and b[1] <= cy <= b[1] + b[3]:
                members["bg"], bg_kind = bg, kind
                break
        box = _union([_box(slots[s]) for s in members.values()])
        cards.append({"key": base, "members": members, "box": box, "bg_kind": bg_kind})
    return cards


def _rows(cards):
    """Cards grouped into rows (by vertical overlap), top to bottom, each left to right."""
    rows = []
    for c in sorted(cards, key=lambda c: (c["box"][1], c["box"][0])):
        cy = c["box"][1] + c["box"][3] / 2.0
        for row in rows:
            r = row[0]["box"]
            if r[1] <= cy <= r[1] + r[3]:
                row.append(c)
                break
        else:
            rows.append([c])
    return [sorted(r, key=lambda c: c["box"][0]) for r in rows]


def template_bands(template):
    """{"top": [rows of cards], "bottom": [rows of cards]} for a template."""
    cards = template_cards(template)
    if not cards:
        return {"top": [], "bottom": []}
    tagged = [c for c in cards if c["bg_kind"] in ("topcardsbg", "bottomcardsbg")]
    if len(tagged) == len(cards):
        top = [c for c in cards if c["bg_kind"] == "topcardsbg"]
        bottom = [c for c in cards if c["bg_kind"] == "bottomcardsbg"]
        return {"top": _rows(top), "bottom": _rows(bottom)}
    rows = _rows(cards)
    return {"top": rows[:1], "bottom": rows[1:]}


def _gap(row):
    gaps = [row[i + 1]["box"][0] - (row[i]["box"][0] + row[i]["box"][2]) for i in range(len(row) - 1)]
    gaps = [g for g in gaps if g >= 0]
    return sorted(gaps)[len(gaps) // 2] if gaps else row[0]["box"][2] * 0.08


def _layout_band(rows, n, area=None, card_size=None, gutter=None, cols=None):
    """Positions (x, y) and scale for n cards.

    Without `area` the cards fill the template band's own area and never grow
    (fewer cards keep the design's size, centred). With a user band box the
    cards scale up or down with the box. `card_size`, `gutter` (space between
    cards) and `cols` (cards per row) come from the band's layout options.
    """
    proto = rows[0][0]
    pw, ph = card_size or (proto["box"][2], proto["box"][3])
    grow = area is not None
    area = area or _union([c["box"] for r in rows for c in r])
    gx = _gap(rows[0]) if len(rows[0]) > 1 else pw * 0.08
    gy = (rows[1][0]["box"][1] - (rows[0][0]["box"][1] + rows[0][0]["box"][3])) if len(rows) > 1 else ph * 0.08
    if gutter is not None:
        gx = gy = float(gutter)
    n_rows = max(1, len(rows))
    cols = max(1, int(cols)) if cols else max(1, math.ceil(n / n_rows))
    used_rows = max(1, math.ceil(n / cols))
    need_w = cols * pw + (cols - 1) * gx
    need_h = used_rows * ph + (used_rows - 1) * gy
    fit_w = area[2] / need_w if need_w else 1.0
    fit_h = area[3] / need_h if need_h else 1.0
    if grow:
        s = min(fit_w, fit_h)
    else:
        s = min(1.0, fit_w, fit_h if used_rows > n_rows else 1.0)
    s = max(0.05, s)
    block_h = used_rows * ph * s + (used_rows - 1) * gy * s
    y0 = area[1] + ((area[3] - block_h) / 2.0 if grow else 0.0)
    out = []
    for r in range(used_rows):
        k = min(cols, n - r * cols)
        row_w = k * pw * s + (k - 1) * gx * s
        x0 = area[0] + (area[2] - row_w) / 2.0
        y = y0 + r * (ph + gy) * s
        for i in range(k):
            out.append((x0 + i * (pw + gx) * s, y))
    return out, s


def _card_name(prefix, key):
    return f"{prefix}{key}"


_PAYS_SIDES = ("below", "above", "right", "left")


def _arrange_card(proto_boxes, layout):
    """Re-arrange a prototype card: symbol + pays block (pay and value side by
    side, as designed) placed below / above / right / left of the symbol, with
    `gap` between them; the background keeps its padding around the content.
    Returns ({role: (x, y, w, h)} anchored at the card's top-left, (w, h))."""
    S, P, V, B = (proto_boxes.get(k) for k in ("symbol", "pay", "value", "bg"))
    side = str((layout or {}).get("pays") or "").casefold()
    if not S or side not in _PAYS_SIDES or not (P or V):
        return None
    content = _union([b for b in (S, P, V) if b])
    pads = (content[0] - B[0], content[1] - B[1], B[0] + B[2] - content[0] - content[2],
            B[1] + B[3] - content[1] - content[3]) if B else (0, 0, 0, 0)
    pads = tuple(max(0.0, v) for v in pads)
    inner = (V[0] - (P[0] + P[2])) if (P and V and V[0] >= P[0] + P[2]) else (8.0 if P and V else 0.0)
    pw = (P[2] if P else 0) + (inner if P and V else 0) + (V[2] if V else 0)
    ph = max(P[3] if P else 0, V[3] if V else 0)
    default_gap = max(0.0, (P or V)[1] - (S[1] + S[3])) if side in ("below", "above") else 12.0
    try:
        gap = float(layout.get("gap")) if layout.get("gap") not in (None, "") else default_gap
    except (TypeError, ValueError):
        gap = default_gap
    if side in ("below", "above"):
        W, H = max(S[2], pw), S[3] + gap + ph
        sx, px = (W - S[2]) / 2.0, (W - pw) / 2.0
        sy, py = (0.0, S[3] + gap) if side == "below" else (ph + gap, 0.0)
    else:
        W, H = S[2] + gap + pw, max(S[3], ph)
        sy, py = (H - S[3]) / 2.0, (H - ph) / 2.0
        sx, px = (0.0, S[2] + gap) if side == "right" else (pw + gap, 0.0)
    ox, oy = pads[0], pads[1]
    out = {"symbol": (ox + sx, oy + sy, S[2], S[3])}
    if P:
        out["pay"] = (ox + px, oy + py, P[2], P[3])
    if V:
        out["value"] = (ox + px + ((P[2] + inner) if P else 0), oy + py, V[2], V[3])
    size = (W + pads[0] + pads[2], H + pads[1] + pads[3])
    if B:
        out["bg"] = (0.0, 0.0, size[0], size[1])
    return out, size


def band_layouts(template):
    """Per-band layout options: {"top": {"pays", "gap", "gutter", "cols"}, ...}."""
    bands = ((((template or {}).get("mapper_meta") or {}).get("card_grid") or {}).get("bands") or {})
    out = {}
    for band in ("top", "bottom"):
        lay = (bands.get(band) or {}).get("layout") or {}
        clean = {}
        if str(lay.get("pays") or "").casefold() in _PAYS_SIDES:
            clean["pays"] = str(lay["pays"]).casefold()
        for k in ("gap", "gutter", "cols"):
            try:
                if lay.get(k) not in (None, ""):
                    clean[k] = max(0.0, float(lay[k]))
            except (TypeError, ValueError):
                pass
        if clean:
            out[band] = clean
    return out


def band_boxes(template):
    """User band boxes: {"top": (x, y, w, h), ...} from mapper_meta.card_grid.bands."""
    bands = ((((template or {}).get("mapper_meta") or {}).get("card_grid") or {}).get("bands") or {})
    out = {}
    for band in ("top", "bottom"):
        b = _box((bands.get(band) or {}).get("box") or {})
        if b and b[2] > 1 and b[3] > 1:
            out[band] = b
    return out


def adapt(template, ws, notes=None, blocks=None, counts=None, info=None):
    """Return a copy of `template` whose card bands match the sheet's cards.

    `blocks`/`counts` default to engine_api.automap_paytable_slots_ws(ws, template).
    `info` (a dict) receives, per band, the band box, the cards drawn there
    and the template slots they replace: what the mapper canvas shows.
    """
    t = copy.deepcopy(template or {})
    say = (lambda m: notes.append(m)) if isinstance(notes, list) else (lambda m: None)
    if ws is None and blocks is None:
        return t
    if str((t.get("mapper_meta") or {}).get("layout") or "") == "cards":
        return t                    # a card template was laid out for this sheet's own symbols already
    if blocks is None or counts is None:
        from ...ui_web.engine_api import automap_paytable_slots_ws
        live = automap_paytable_slots_ws(ws, t) or {}
        blocks = live.get("blocks") or []
        counts = live.get("card_counts") or {}
    bands = template_bands(t)
    if not blocks or not (bands["top"] or bands["bottom"]):
        return t
    n_top = int(counts.get("top") or 0)
    sheet = {"top": blocks[:n_top], "bottom": blocks[n_top:n_top + int(counts.get("lower") or 0)]}
    if not bands["bottom"]:                                  # single-band template: every card goes there
        sheet = {"top": blocks, "bottom": []}

    slots = t.setdefault("slots", {})
    mappings = _mapping_dict(t.get("mappings"))
    prefix = "@slot." if any(str(n).startswith("@slot.") for n in slots) else ""
    user_boxes = band_boxes(t)
    layouts = band_layouts(t)
    changed = False
    for band in ("top", "bottom"):
        rows, cards = bands[band], sheet[band]
        if not rows:
            continue
        have = sum(len(r) for r in rows)
        members = [name for r in rows for c in r for name in c["members"].values()]
        area = user_boxes.get(band)
        layout = layouts.get(band) or {}
        if have == len(cards) and area is None and not layout:
            if isinstance(info, dict):                       # untouched: the design's own cards
                info[band] = {"box": _union([c["box"] for r in rows for c in r]), "managed": False,
                              "excel_cards": len(cards), "template_cards": have, "hidden": [],
                              "cards": [{"key": c["key"], "box": c["box"], "slot": c["members"]["symbol"]}
                                        for r in rows for c in r]}
            continue
        proto = rows[0][0]
        proto_maps = {role: copy.deepcopy(mappings.get(name) or {}) for role, name in proto["members"].items()}
        proto_boxes = {role: _box(slots[name]) for role, name in proto["members"].items()}
        user = {}                                            # hand-made choices per card name
        for r in rows:
            for c in r:
                for role, name in c["members"].items():
                    if role == "symbol":
                        spec = mappings.get(name) or {}
                        if spec.get("symbol_pinned") or spec.get("asset_path"):
                            keep = {k: spec[k] for k in _KEEP_FROM_USER if k in spec}
                            # by slot name and by the symbol the card showed (a pic5 box showing <spaceship>)
                            for k in (c["key"], _norm(spec.get("symbol")), _norm(str(spec.get("token") or "").strip("<>"))):
                                if k:
                                    user.setdefault(k, keep)
                    slots.pop(name, None)
                    mappings.pop(name, None)
        arranged = _arrange_card(proto_boxes, layout) if layout.get("pays") else None
        card_size = None
        if arranged:
            rel, card_size = arranged
            ax, ay = proto["box"][0], proto["box"][1]
            proto_boxes = {role: (ax + b[0], ay + b[1], b[2], b[3]) for role, b in rel.items() if role in proto_boxes}
        positions, s = _layout_band(rows, len(cards), area, card_size=card_size,
                                    gutter=layout.get("gutter"), cols=int(layout["cols"]) if layout.get("cols") else None)
        bg_kind = proto["bg_kind"] or ("topcardsbg" if band == "top" else "bottomcardsbg")
        bg_label = {"topcardsbg": "TopCardsBG", "bottomcardsbg": "BottomCardsBG"}.get(bg_kind, "CardBG")
        px, py = proto["box"][0], proto["box"][1]
        drawn = []
        for i, (block, (x, y)) in enumerate(zip(cards, positions), start=1):
            key = str(block["key"])
            names = {"symbol": _card_name(prefix, key), "pay": _card_name(prefix, key + ".pay"),
                     "value": _card_name(prefix, key + ".value"), "bg": f"{prefix}{bg_label}.{i}"}
            for role, pb in proto_boxes.items():
                if not pb:
                    continue
                name = names[role]
                existing = mappings.get(name) or {}          # a symbol picked on this generated card
                own_look = mappings.get(name + OWN_LOOK_SUFFIX) or {}   # this one card's own look
                slots[name] = {"x": round(x + (pb[0] - px) * s, 2), "y": round(y + (pb[1] - py) * s, 2),
                               "w": round(pb[2] * s, 2), "h": round(pb[3] * s, 2)}
                spec = copy.deepcopy(proto_maps.get(role) or {})
                spec["slot"] = name
                for k in ("asset_path", "symbol_pinned", "source_pinned", "text"):
                    spec.pop(k, None)
                if abs(s - 1.0) > 0.001:
                    for k in ("font_size", "line_height", "leading", "icon_height", "icon_width"):
                        if isinstance(spec.get(k), (int, float)):
                            spec[k] = round(spec[k] * s, 2)
                if role == "symbol":
                    spec.update(mode="icon", token=block.get("token") or f"<{key}>", symbol=key)
                    spec.update(user.get(_norm(key), {}))
                    if existing.get("symbol_pinned") or existing.get("asset_path"):
                        spec.update({k: existing[k] for k in _KEEP_FROM_USER if k in existing})
                elif role in ("pay", "value"):
                    spec.update(mode="excel", role=role, symbol=key,
                                source=block.get("pay_ref" if role == "pay" else "value_ref") or "")
                if own_look:
                    # this one card's own look (colour, font, size...) over the band's prototype;
                    # kept under "<slot>@card" so card 1 never collides with the prototype itself
                    spec.update({k: v for k, v in own_look.items() if k not in _STRUCTURAL})
                    spec["card_override"] = True
                mappings[name] = spec
            card_box = _union([_box(slots[names[r]]) for r in proto_boxes if proto_boxes[r]])
            drawn.append({"key": key, "box": card_box, "slot": names["symbol"],
                          "parts": {r: {"slot": names[r], "box": _box(slots[names[r]]),
                                        "spec": {k: mappings[names[r]].get(k) for k in ("mode", "role", "source", "token", "symbol")
                                                 if mappings[names[r]].get(k) is not None},
                                        "override": bool(mappings[names[r]].get("card_override"))}
                                    for r in proto_boxes if proto_boxes[r]}})
        changed = True
        if isinstance(info, dict):
            info[band] = {"box": area or _union([c["box"] for r in rows for c in r]), "managed": True,
                          "excel_cards": len(cards), "template_cards": have, "scale": round(s, 3),
                          "hidden": members, "cards": drawn, "proto": dict(proto["members"]),
                          "layout": layout}
        if have != len(cards):
            where = "band box" if area else "template's " + band + " area"
            say(f"{band.capitalize()} cards: Excel has {len(cards)}, the template {have}; laid out "
                f"{len(cards)} in the {where}" + (f" at {s:.0%}." if abs(s - 1) > 0.001 else "."))
    t["mappings"] = mappings
    if changed:
        # renderers draw slots in order: card backgrounds first, under symbols and pays
        t["slots"] = {n: slots[n] for n in sorted(slots, key=lambda n: 0 if _BG_RE.match(_norm(n)) else 1)}
    return t
