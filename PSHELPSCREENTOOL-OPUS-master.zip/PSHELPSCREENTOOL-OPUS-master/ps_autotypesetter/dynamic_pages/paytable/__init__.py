"""Paytable dynamic-page addon."""

from .parser import parse_paytable_sheet

__all__ = ["parse_paytable_sheet"]
