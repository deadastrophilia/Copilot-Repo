"""Card templates: paytable designs built from cards, not hand-placed boxes.

A card template describes a paytable page the way an artist thinks of it:

  page      title (with an optional plate behind it), margins, notes area
  features  WILD / SCATTER boxes (each with a label tab) — optional
  bands     rows of symbol cards: "high" (symbols before ACE) and "low"
            (ACE onwards), each with its own cards-per-row and card height
  styles    named box looks: corner roundness, fill, border (plain or none),
            layer style from the library — rendered as live Photoshop shapes
  card      what sits inside every symbol card, in fractions of the card:
            symbol, counts ("5 4 3"), pays ("150 50 8") and any number of
            extra text slots (Excel cell or typed text)

compile_template() turns it into the ordinary mapped-paytable template
(canvas + "@slot.*" boxes) for one sheet's real symbols, plus the style part
of every slot's mapping. The existing auto-mapper then binds counts/pays to
Excel by symbol name, so preview, PNG and PSD builds all work unchanged.

Built-in templates ship in card_templates/ next to this file and are never
written to; edits are saved as copies in the user's CardTemplates folder.
"""
import copy
import hashlib
import json
import math
import os
import re
import sys

BUILTIN_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "card_templates")
CANVAS = (1920, 1080)
KIND = "card_template"
SCHEMA = 1

# ── storage ─────────────────────────────────────────────────────────────────


def user_dir():
    """The user's saved card templates (next to the EXE when frozen, the tool root in dev)."""
    if getattr(sys, "frozen", False):
        base = os.path.dirname(os.path.abspath(sys.executable))
    else:
        base = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    folder = os.path.join(base, "CardTemplates")
    os.makedirs(folder, exist_ok=True)
    return folder


def _read(path):
    try:
        with open(path, "r", encoding="utf-8") as fh:
            doc = json.load(fh)
    except (OSError, ValueError):
        return None
    return doc if isinstance(doc, dict) and doc.get("kind") == KIND else None


def _builtin_dir():
    if getattr(sys, "frozen", False):
        frozen = os.path.join(getattr(sys, "_MEIPASS", ""), "ps_autotypesetter", "dynamic_pages", "paytable", "card_templates")
        if os.path.isdir(frozen):
            return frozen
    return BUILTIN_DIR


def list_templates():
    """[{id, name, description, builtin, default}] — the default design first (a paytable with no design
    of its own starts from it), then the other built-ins, then the user's copies."""
    out = []
    for folder, builtin in ((_builtin_dir(), True), (user_dir(), False)):
        if not os.path.isdir(folder):
            continue
        rows = []
        for fname in os.listdir(folder):
            if not fname.lower().endswith(".json"):
                continue
            doc = _read(os.path.join(folder, fname))
            if doc and not doc.get("retired"):       # retired: not offered any more (old games still open it)
                rows.append({"id": doc.get("id") or os.path.splitext(fname)[0], "name": doc.get("name") or fname,
                             "description": doc.get("description") or "", "builtin": builtin,
                             "order": doc.get("order", 99), "default": bool(doc.get("default"))})
        rows.sort(key=lambda r: (r["order"], r["name"].casefold()))
        out.extend(rows)
    out.sort(key=lambda r: not r["default"])           # stable: the rest keep their order
    return out


def get_template(template_id):
    """A full template (a copy — safe to edit), or None."""
    template_id = str(template_id or "")
    for folder, builtin in ((_builtin_dir(), True), (user_dir(), False)):
        if not os.path.isdir(folder):
            continue
        for fname in os.listdir(folder):
            if not fname.lower().endswith(".json"):
                continue
            doc = _read(os.path.join(folder, fname))
            if doc and (doc.get("id") == template_id or os.path.splitext(fname)[0] == template_id):
                doc = copy.deepcopy(doc)
                doc["builtin"] = builtin
                return doc
    return None


def is_builtin(template_id):
    t = get_template(template_id)
    return bool(t and t.get("builtin"))


def _slug(name):
    s = re.sub(r"[^a-z0-9]+", "_", str(name or "").lower()).strip("_")
    return s or "template"


def save_copy(template, name):
    """Save `template` under a new name in the user's folder. Never touches a built-in.

    Returns the saved template's id. Raises ValueError when the name is taken
    by a built-in (built-ins can't be overwritten) or is empty."""
    name = str(name or "").strip()
    if not name:
        raise ValueError("Give the template a name.")
    tid = "user_" + _slug(name)
    builtins = [_read(os.path.join(_builtin_dir(), f)) or {} for f in os.listdir(_builtin_dir()) if f.lower().endswith(".json")]         if os.path.isdir(_builtin_dir()) else []                # retired ones too: their names stay theirs
    for row in builtins:
        if str(row.get("name") or "").casefold() == name.casefold() or row.get("id") == tid:
            raise ValueError(f'"{name}" is a built-in template name — choose another name.')
    doc = copy.deepcopy(template)
    doc.update({"kind": KIND, "schema": SCHEMA, "id": tid, "name": name})
    doc.pop("builtin", None)
    doc.pop("retired", None)                          # a copy of a retired design is the user's own, offered
    doc["based_on"] = template.get("based_on") or template.get("id") or ""
    path = os.path.join(user_dir(), tid + ".json")
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(doc, fh, indent=2)
    return tid


def delete_user(template_id):
    """Delete one of the user's templates; built-ins are refused."""
    if is_builtin(template_id):
        raise ValueError("Built-in templates can't be deleted.")
    path = os.path.join(user_dir(), str(template_id) + ".json")
    if not os.path.isfile(path):
        raise ValueError("Template not found.")
    os.remove(path)


# ── compile ─────────────────────────────────────────────────────────────────

_HELPER_KEYS = {"payany", "pay", "pays", "any"}

# WILD / SCATTER boxes for a design that has none (they always get a box): size and contents
DEFAULT_FEATURE_BOX = (560.0, 260.0)
DEFAULT_WILD_PARTS = {
    "symbol": {"x": 0.02, "y": 0.22, "w": 0.24, "h": 0.56},
    "text": {"x": 0.28, "y": 0.22, "w": 0.7, "h": 0.56, "font_size": 26, "color": "#FFD21F"},
}
DEFAULT_SCATTER_PARTS = {
    "symbol": {"x": 0.04, "y": 0.22, "w": 0.3, "h": 0.56},
    "counts": {"x": 0.42, "y": 0.22, "w": 0.12, "h": 0.56, "font_size": 32, "color": "#FFD21F", "align": "right"},
    "pays": {"x": 0.57, "y": 0.22, "w": 0.38, "h": 0.56, "font_size": 32, "color": "#FFFFFF", "align": "left"},
}
# the AGR's heading above the symbol ("Scatter") and caption under it ("pay any"), as box parts
DEFAULT_TITLE_PART = {"x": 0.02, "y": 0.02, "w": 0.96, "h": 0.18, "font_size": 34, "color": "#FFD21F", "align": "center"}
DEFAULT_CAPTION_PART = {"x": 0.02, "y": 0.8, "w": 0.96, "h": 0.18, "font_size": 26, "color": "#FFFFFF", "align": "center"}
# a framed tile behind a card's symbol, the panel behind all the cards, the "of a kind" caption of a shared card
DEFAULT_TILE_STYLE = {"radius": 14, "fill_enabled": True, "fill": "#1B1030", "fill_opacity": 100,
                      "stroke": {"enabled": True, "width": 3, "color": "#FFD23A", "align": "inside"}, "fx": ""}
DEFAULT_PANEL_STYLE = {"radius": 28, "fill_enabled": True, "fill": "#120A24", "fill_opacity": 75,
                       "stroke": {"enabled": True, "width": 3, "color": "#8A5CFF", "align": "inside"}, "fx": ""}
DEFAULT_KIND_CAPTION = {"text": "OF A KIND", "x": 0.02, "y": 0.8, "w": 0.96, "h": 0.18, "font_size": 24,
                        "color": "#FFFFFF", "align": "center"}
# a WILD that pays: its counts / pays on the right of the box, the text narrowed beside them
WILD_PAY_PARTS = {
    "counts": {"x": 0.72, "y": 0.12, "w": 0.08, "h": 0.76, "font_size": 32, "color": "#FFD21F", "align": "right"},
    "pays": {"x": 0.82, "y": 0.12, "w": 0.16, "h": 0.76, "font_size": 32, "color": "#FFFFFF", "align": "left"},
}


def _clean_keys(keys):
    """Sheet block keys -> (card keys in order, scatter key or "")."""
    keys = [str(k) for k in keys or [] if k]
    scat = [k for k in keys if "scat" in k.casefold()]
    scatter = "scat" if "scat" in scat else (scat[0] if scat else "")
    cards = [k for k in keys if k not in scat and k.casefold() not in _HELPER_KEYS and len(k) <= 24]
    return cards, scatter


_TOKEN_ONLY = re.compile(r"^\s*<[^<>]+>\s*$")


def _norm(text):
    return re.sub(r"[^a-z0-9]", "", str(text or "").casefold())


def _is_num(v):
    if isinstance(v, bool):
        return False
    if isinstance(v, (int, float)):
        return True
    return isinstance(v, str) and re.fullmatch(r"\s*\d[\d,.]*\s*", v) is not None


def find_pay_section(ws, card_keys):
    """Symbols with their own pays OUTSIDE the main symbol grid — a "Scatter" block like

        Scatter                                   <- heading (optional)
              5  1500            5  1500
        <BG SCATTER> 4 750  <FG SCATTER> 4 750    <- any number of symbols side by side / stacked
              3   200            3   200
        pays in any position.                     <- caption (optional)
        <BG SCATTER> appears only during ...      <- notes: later lines naming those symbols

    Read from the sheet itself (nothing hard-coded): a cell holding only a <token> that is not one
    of the grid's symbols, with a counts column and a pays column to its right.
    Returns {"cards": [{key, token, cell, counts, pays, rows}], "title", "caption", "notes", "rows"} or None."""
    if ws is None:
        return None
    from openpyxl.utils import get_column_letter

    grid = {}
    for row in ws.iter_rows():
        for c in row:
            v = c.value
            if v is None or (isinstance(v, str) and not v.strip()):
                continue
            grid[(c.row, c.column)] = v
    ref = lambda r, c: f"{get_column_letter(c)}{r}"
    keys = {_norm(k) for k in card_keys or []}
    keys |= {_norm(a) for k in card_keys or [] for a in royal_aliases(k)}     # the grid's "ten" is also <10>

    def run_at(r, j):
        near = [i for i in range(r - 2, r + 3) if _is_num(grid.get((i, j)))]
        if not near:
            return []
        start = min(near, key=lambda i: abs(i - r))
        top, bot = start, start
        while _is_num(grid.get((top - 1, j))):
            top -= 1
        while _is_num(grid.get((bot + 1, j))):
            bot += 1
        return list(range(top, bot + 1))

    cards = []
    for (r, c), v in sorted(grid.items()):
        if not (isinstance(v, str) and _TOKEN_ONLY.match(v)):
            continue
        key = _norm(v)
        if not key or key in keys or "wild" in key:
            continue
        cols = []
        for j in range(c + 1, c + 9):
            cell = grid.get((r, j))
            if isinstance(cell, str) and _TOKEN_ONLY.match(cell):
                break                                    # the next symbol on this row has its own columns
            rows = run_at(r, j)
            if len(rows) >= 2:
                cols.append((j, rows))
            if len(cols) == 2:
                break
        if len(cols) == 2:
            (cj, crows), (pj, prows) = cols
            cards.append({"key": key, "token": v.strip(), "cell": ref(r, c),
                          "counts": ",".join(ref(i, cj) for i in crows), "pays": ",".join(ref(i, pj) for i in prows),
                          "rows": (min(crows + prows), max(crows + prows))})
    if not cards:
        return None
    r0, r1 = min(cd["rows"][0] for cd in cards), max(cd["rows"][1] for cd in cards)
    num_rows = {r for (r, _c), v in grid.items() if _is_num(v)}
    texts = [((r, c), str(v).strip()) for (r, c), v in sorted(grid.items())
             if isinstance(v, str) and not _TOKEN_ONLY.match(v) and not _is_num(v)]
    # a heading / caption is a line of its own: not a grid symbol's label, not on a row of pays
    plain = [(rc, tx) for rc, tx in texts if rc[0] not in num_rows and _norm(tx) not in keys]
    above = [(rc, tx) for rc, tx in plain if r0 - 4 <= rc[0] < r0 and len(tx) <= 40 and "<" not in tx]
    below = [(rc, tx) for rc, tx in plain if r1 < rc[0] <= r1 + 3 and len(tx) <= 80 and "<" not in tx]
    title = max(above, key=lambda x: x[0][0]) if above else None
    caption = min(below, key=lambda x: x[0][0]) if below else None
    toks = {cd["token"].upper() for cd in cards}
    notes = [ref(*rc) for rc, tx in texts if rc[0] > r1 and any(tk in tx.upper() for tk in toks)]
    return {"cards": cards, "rows": (r0, r1), "notes": notes,
            "title": (ref(*title[0]), title[1]) if title else None,
            "caption": (ref(*caption[0]), caption[1]) if caption else None}


def _cells(ws):
    if ws is None:
        return []
    out = []
    for row in ws.iter_rows():
        for c in row:
            if isinstance(c.value, str) and c.value.strip():
                out.append((c.coordinate, c.value.strip()))
    return out


def _find_cell(cells, *needles):
    for coord, text in cells:
        low = text.casefold()
        if all(n in low for n in needles):
            return coord, text
    return "", ""


def _symbol_texts(cells, key, others=()):
    """The text the AGR writes around a WILD / SCATTER symbol in its pay block:

            Scatter        <- heading: the text cell just above the symbol (same column)
            <SCAT>   5 100
                     4  10
                     3   2
            pay any        <- caption: the text cell just below it

    Returns ((coord, text) of the heading, (coord, text) of the caption), ("", "") when absent.
    The symbol cell is the one holding only <KEY> (else the plain name); numbers, other symbols
    (`others`, normalised keys) and <tokens> are never a heading or caption."""
    from openpyxl.utils.cell import coordinate_from_string, column_index_from_string

    def rc(coord):
        col, row = coordinate_from_string(coord)
        return row, column_index_from_string(col)

    k = _norm(key)
    if not k:
        return ("", ""), ("", "")
    sym = next((c for c, t in cells if _TOKEN_ONLY.match(t) and _norm(t) == k), "") or \
        next((c for c, t in cells if _norm(t) == k), "")
    if not sym:
        return ("", ""), ("", "")
    r0, c0 = rc(sym)
    skip = {_norm(o) for o in others} | {k}

    def usable(text):
        return bool(text.strip()) and not _is_num(text) and not _TOKEN_ONLY.match(text) and _norm(text) not in skip

    by_pos = {rc(c): (c, t) for c, t in cells}
    # the same column first, then the column either side (an AGR often writes "Scatter" a column to the left)
    near = lambda rows: next((by_pos[(r, c)] for c in (c0, c0 - 1, c0 + 1) for r in rows  # noqa: E731
                              if (r, c) in by_pos and usable(by_pos[(r, c)][1])), ("", ""))
    head = near([r0 - d for d in (1, 2, 3)])
    cap = near([r0 + d for d in (1, 2, 3, 4, 5)])
    return head, cap


def _wild_token(cells):
    for _coord, text in cells:
        m = re.search(r"<\s*(wild[^>]*)>", text, re.I)
        if m:
            return "<" + m.group(1).strip() + ">"
    return ""


def _box(x, y, w, h):
    return {"x": int(round(x)), "y": int(round(y)), "w": max(1, int(round(w))), "h": max(1, int(round(h)))}


def _sub_box(card, part):
    """A slot inside a card: part has x, y, w, h as fractions of the card."""
    cx, cy, cw, ch = card["x"], card["y"], card["w"], card["h"]
    return _box(cx + float(part.get("x", 0)) * cw, cy + float(part.get("y", 0)) * ch,
                float(part.get("w", 1)) * cw, float(part.get("h", 1)) * ch)


def fit_card(parts, cw, ch, pay_rows=3, pad=4.0, pay_digits=0):
    """(parts as card fractions, card width, card height): the card keeps the size the artist gave it.

    What is inside never resizes the card (artist's rule, 2026-10-19: "the card should remain whatever
    size it is — the user changes it with its handles"); a symbol or numbers made bigger than the card
    simply reach past its edge. Only the numbers' own boxes are made big enough for their text:
    tall enough for their lines and wide enough for the sheet's longest number ("1500")."""
    out = []
    for p in parts:
        q = dict(p)
        if p.get("role") in ("counts", "pays"):
            x, y = float(p.get("x", 0)) * cw, float(p.get("y", 0)) * ch
            w, h = float(p.get("w", 1)) * cw, float(p.get("h", 1)) * ch
            fs = float(p.get("font_size") or 30)
            lh = float(p.get("line_height") or 0) or fs * 1.25
            need = pay_rows * lh + 8
            if h < need:
                if float(p.get("y", 0)) >= 0.48:
                    y = min(y, max(float(p.get("y", 0)) * ch - 4.0, ch - need - 4.0))
                else:
                    y -= (need - h) / 2.0
                h = need
            need_w = (pay_digits if p.get("role") == "pays" else 1) * fs * 0.62 + 10 if pay_digits else 0
            if w < need_w:
                if str(p.get("align") or "") == "right":
                    x -= need_w - w
                w = need_w
            q.update(x=x / cw, y=y / ch, w=w / cw, h=h / ch)
        out.append(q)
    return out, cw, ch


def _fitted(style, f):
    """A card's text style for a row drawn at `f` of its designed size: the text shrinks with the
    card, so a row scaled to fit the page looks like the designed card, just smaller."""
    if f >= 0.999:
        return style
    out = dict(style)
    for k in ("font_size", "line_height"):
        if out.get(k):
            out[k] = round(float(out[k]) * f, 1)
    return out


def _room(x, y, w, h, walls, gap, page):
    """(width, height) free from (x, y): up to the first wall (x0, y0, x1, y1) to the right of a
    w × h box there, or below it, else the page's edge. Walls the box starts inside don't count."""
    max_x, max_y = page[2], page[3]
    for x0, y0, x1, y1 in walls:
        if x0 <= x < x1 and y0 <= y < y1:
            continue
        if y0 < y + h and y1 > y and x0 >= x:          # beside it, on its right
            max_x = min(max_x, x0 - gap)
        if x0 < x + w and x1 > x and y0 >= y:          # under it
            max_y = min(max_y, y0 - gap)
    return max(1.0, max_x - x), max(1.0, max_y - y)


def _free_spot(taken, w, h, area_x, area_w, ys):
    """[x, y, w, h] on one of the rows `ys` (in order of preference) covering the least of the
    `taken` rects ([x, y, w, h]); ties go to the row first listed, then nearest the centre."""
    best = None
    steps = max(1, int((area_w - w) // 20))
    for yi, y in enumerate(ys):
        for i in range(steps + 1):
            x = area_x + min(area_w - w, i * 20.0)
            cover = sum(max(0.0, min(x + w, tx + tw) - max(x, tx)) * max(0.0, min(y + h, ty + th) - max(y, ty))
                        for tx, ty, tw, th in taken)
            score = (round(cover), yi, abs(x + w / 2.0 - (area_x + area_w / 2.0)))
            if best is None or score < best[0]:
                best = (score, [x, y, w, h])
    return best[1]


def _step_aside(r, g, page, gap):
    """r moved the shortest way off g (x0, y0, x1, y1), kept on the page; None when they don't touch."""
    if r[2] <= g[0] or r[0] >= g[2] or r[3] <= g[1] or r[1] >= g[3]:
        return None
    w, h = r[2] - r[0], r[3] - r[1]
    options = [(r[0], g[1] - gap - h), (r[0], g[3] + gap), (g[0] - gap - w, r[1]), (g[2] + gap, r[1])]
    fits = [(abs(x - r[0]) + abs(y - r[1]), x, y) for x, y in options
            if x >= page[0] and y >= page[1] and x + w <= page[2] and y + h <= page[3]]
    if not fits:
        return None
    _d, x, y = min(fits)
    return (x, y, x + w, y + h)


_ROYAL_PAIRS = [("ace", "a"), ("king", "k"), ("queen", "q"), ("jack", "j"), ("ten", "10"), ("nine", "9")]


def royal_aliases(name):
    """Other spellings of a card's royal symbol ("<A>" -> ACE, "KING" -> K): a paytable card shows the
    symbol whichever way its picture is named. Cards only — never used for icons inside text."""
    n = _norm(name)
    for long, short in _ROYAL_PAIRS:
        if n == long:
            return [short.upper()]
        if n == short:
            return [long.upper()]
    return []


def icon_scales(t, box=None):
    """Sizes of the icons inside text, by icon name: the page-wide ones (every paytable text) with this
    box's own on top — each a height in px ("40px", template["text_icon_px"] / box["icon_px"], the
    icon as drawn) or, from older designs, a percent (template["text_icon_scale"] / box["icon_scale"])."""
    out = {}
    for src, px in (((t or {}).get("text_icon_scale"), False), ((t or {}).get("text_icon_px"), True),
                    ((box or {}).get("icon_scale"), False), ((box or {}).get("icon_px"), True)):
        for k, v in (src or {}).items() if isinstance(src, dict) else ():
            if v in (None, ""):
                continue
            out[str(k).strip("<> ").upper()] = f"{float(v):g}px" if px else v
    return out


def symbol_px(px_sizes, name):
    """card["symbol_px"]: a symbol's height in px as drawn (canvas px), by name or "*" for every symbol."""
    px_sizes = px_sizes or {}
    for k in (name, str(name).upper(), str(name).lower(), "*"):
        if k in px_sizes:
            try:
                return max(4.0, float(px_sizes[k]))
            except (TypeError, ValueError):
                break
    return None


def symbol_scale(sizes, name):
    """card["symbol_size"]: percent per symbol, "*" for all the others (100 = as designed)."""
    sizes = sizes or {}
    for k in (name, str(name).upper(), str(name).lower(), "*"):
        if k in sizes:
            try:
                return max(0.2, min(3.0, float(sizes[k]) / 100.0))
            except (TypeError, ValueError):
                break
    return 1.0


def _scaled(box, f):
    """The same box grown or shrunk about its centre."""
    if abs(f - 1.0) < 1e-6:
        return box
    cx, cy = box["x"] + box["w"] / 2.0, box["y"] + box["h"] / 2.0
    w, h = box["w"] * f, box["h"] * f
    return _box(cx - w / 2.0, cy - h / 2.0, w, h)


def _mix(a, b, pct):
    """#RRGGBB: colour b taken pct % of the way from colour a (a gradient's strength); b when a isn't a colour."""
    try:
        k = max(0.0, min(1.0, float(100 if pct in (None, "") else pct) / 100.0))
        ca, cb = (tuple(int(str(c).lstrip("#")[i:i + 2], 16) for i in (0, 2, 4)) for c in (a, b))
    except (TypeError, ValueError):
        return str(b)
    return "#%02X%02X%02X" % tuple(int(round(x + (y - x) * k)) for x, y in zip(ca, cb))


def flow_lines(text):
    """Single line breaks → spaces (the text wraps to its box); blank lines (paragraphs) are kept."""
    paras = re.split(r"\n\s*\n", str(text or ""))
    return "\n\n".join(" ".join(ln.strip() for ln in p.split("\n") if ln.strip()) for p in paras).strip("\n")


def shape_of(style):
    """A style (from template["styles"]) -> the mapping's "shape" spec for the renderers."""
    if not isinstance(style, dict):
        return None
    if not style.get("fill_enabled", True) and not (style.get("stroke") or {}).get("enabled") and not style.get("fx"):
        return None
    out = {
        "radius": style.get("radius", 0),
        "fill": style.get("fill") if style.get("fill_enabled", True) else None,
        "fill_opacity": style.get("fill_opacity", 100),
        "stroke": dict(style.get("stroke") or {}),
        "fx": style.get("fx") or "",
        "fx_on": style.get("fx_on") or "",          # "" whole shape · "fill" · "stroke" (split in two layers)
    }
    # each corner its own size and kind (a card look: notched, cut, a leaf, one corner round…)
    if isinstance(style.get("radii"), (list, tuple)) and len(style["radii"]) == 4:
        out["radii"] = [float(v) for v in style["radii"]]
    if isinstance(style.get("corners"), (list, tuple)) and len(style["corners"]) == 4:
        out["corners"] = [str(v) for v in style["corners"]]
    elif style.get("corner") and style.get("corner") != "round":
        out["corner"] = str(style["corner"])
    if style.get("fill_enabled", True) and style.get("fill_to") and style.get("gradient_dir") != "none":
        out["fill_to"] = _mix(style.get("fill"), str(style["fill_to"]), style.get("gradient_amount", 100))
        out["gradient_dir"] = str(style.get("gradient_dir") or "vertical")
    return out


def extract_auto_palette(image_path):
    """Extract a harmonious dark-surface + vibrant-accent paytable palette from a background or symbol image.

    Returns {"fill", "fill_to", "stroke", "glow", "text_accent", "plate_fill"} as #RRGGBB hex strings.
    """
    import colorsys
    from PIL import Image

    default = {
        "fill": "#180D2E",
        "fill_to": "#0B0518",
        "stroke": "#F5C443",
        "glow": "#FFB830",
        "text_accent": "#FFD23A",
        "low_fill": "#100820",
        "low_stroke": "#8A63D2",
        "plate_fill": "#221142",
    }
    if not image_path or not os.path.isfile(str(image_path)):
        return dict(default)
    try:
        with Image.open(image_path) as im:
            small = im.convert("RGB").resize((64, 64), Image.BILINEAR)
            pixels = list(small.getdata())
    except Exception:
        return dict(default)
    if not pixels:
        return dict(default)

    # Find dominant dark hue and vibrant accent hue in HSV space
    dark_samples = []
    vibrant_samples = []
    for r, g, b in pixels:
        h, s, v = colorsys.rgb_to_hsv(r / 255.0, g / 255.0, b / 255.0)
        if 0.08 <= v <= 0.45 and s >= 0.2:
            dark_samples.append((h, s, v))
        if v >= 0.55 and s >= 0.45:
            vibrant_samples.append((s * v, h, s, v))

    def _to_hex(h, s, v):
        rr, gg, bb = colorsys.hsv_to_rgb(h % 1.0, max(0.0, min(1.0, s)), max(0.0, min(1.0, v)))
        return "#%02X%02X%02X" % (int(round(rr * 255)), int(round(gg * 255)), int(round(bb * 255)))

    if dark_samples:
        avg_h = sum(x[0] for x in dark_samples) / len(dark_samples)
        avg_s = min(0.85, max(0.45, sum(x[1] for x in dark_samples) / len(dark_samples)))
    else:
        avg_h, avg_s = 0.74, 0.65

    if vibrant_samples:
        vibrant_samples.sort(reverse=True)
        top_v = vibrant_samples[:max(1, len(vibrant_samples) // 5)]
        acc_h = sum(x[1] for x in top_v) / len(top_v)
        acc_s = min(0.95, max(0.65, sum(x[2] for x in top_v) / len(top_v)))
    else:
        acc_h, acc_s = (avg_h + 0.15) % 1.0, 0.85

    return {
        "fill": _to_hex(avg_h, avg_s, 0.24),
        "fill_to": _to_hex(avg_h, min(1.0, avg_s + 0.1), 0.11),
        "stroke": _to_hex(acc_h, acc_s, 0.96),
        "glow": _to_hex(acc_h, min(1.0, acc_s + 0.05), 1.0),
        "text_accent": _to_hex(acc_h, max(0.6, acc_s - 0.1), 1.0),
        "low_fill": _to_hex(avg_h, max(0.35, avg_s - 0.1), 0.16),
        "low_stroke": _to_hex(avg_h, max(0.4, avg_s - 0.05), 0.68),
        "plate_fill": _to_hex(avg_h, avg_s, 0.28),
    }


def _typed(t, text, slot=None, box_texts=None):
    """A WILD / SCATTER box's own words (heading, caption, tab) as the artist typed them on the Canvas:
    template["text_overrides"][hash of the Excel's words] — another market's words keep their own."""
    text = str(text or "")
    h = hashlib.sha1(text.encode("utf-8")).hexdigest()[:12]
    typed = (t.get("text_overrides") or {}).get(h)
    if slot is not None and box_texts is not None:
        box_texts[slot] = {"hash": h, "original": text}
    return typed if isinstance(typed, str) else text


def _split_fx_shapes(slots, maps):
    """A shape whose layer style is on its fill only or its stroke only becomes two layers: the fill
    and the stroke, the style on the one it is for. (slots in drawing order; returns the new slots)"""
    split = {}
    for key, m in maps.items():
        sh = m.get("shape") if isinstance(m, dict) else None
        if key not in slots or not isinstance(sh, dict) or sh.get("fx_on") not in ("fill", "stroke"):
            continue
        if not sh.get("fx") or not (sh.get("stroke") or {}).get("enabled") or not sh.get("fill"):
            continue
        on_fill = sh["fx_on"] == "fill"
        maps[key] = dict(m, shape=dict(sh, stroke={}, fx=sh["fx"] if on_fill else ""))
        split[key] = dict(m, shape=dict(sh, fill=None, fx="" if on_fill else sh["fx"]))
    if not split:
        return slots
    out = {}
    for k, v in slots.items():
        out[k] = v
        if k in split:
            out[k + ".stroke"] = v
            maps[k + ".stroke"] = split[k]
    return out


def _text_style(spec):
    out = {}
    for key, dst in (("font_size", "font_size"), ("color", "color"), ("align", "alignment"),
                     ("valign", "vertical_align"), ("font", "font_name")):
        if spec.get(key) not in (None, ""):
            out[dst] = spec[key]
    for key in ("bold", "italic"):
        if spec.get(key):
            out[key] = True
    if spec.get("line_height"):
        out["line_height"] = int(round(float(spec["line_height"])))
    if spec.get("fx"):                               # a layer style from the library (or inline dict), on the text itself
        out["text_fx"] = spec["fx"] if isinstance(spec["fx"], dict) else str(spec["fx"])
    if "font_name" in out:
        out["font_override"] = True
    return out


def _layout_band(names, band, area_x, area_w, y, gap_x, gap_y, align, sizes=None):
    """[(name, card box)] for one band; returns (cards, bottom y). ``sizes`` {name: percent}: a card
    bigger or smaller than the others in its row (the row as tall as its tallest card, the cards
    centred in it; a row too wide for the page shrinks as a whole).
    When ``band.get("bento")`` is True and n % per_row != 0, the shorter row comes first (promoting
    the highest-paying symbols to wider hero cards) and every row expands to fill 100% of ``area_w``."""
    n = len(names)
    if not n:
        return [], y
    per_row = max(1, min(int(band.get("per_row") or n), n))
    card_h = float(band.get("card_h") or 150)
    card_w = (area_w - (per_row - 1) * gap_x) / per_row
    if band.get("card_w") and not band.get("bento"):
        card_w = min(card_w, float(band["card_w"]))
    bento = bool(band.get("bento")) and n > per_row and (n % per_row) != 0
    row_slices = []
    if bento:
        rem = n % per_row
        row_slices.append(names[:rem])
        idx = rem
        while idx < n:
            row_slices.append(names[idx:idx + per_row])
            idx += per_row
    else:
        rows = math.ceil(n / per_row)
        for r in range(rows):
            row_slices.append(names[r * per_row:(r + 1) * per_row])
    sizes = {str(k).lower(): float(v) / 100.0 for k, v in (sizes or {}).items() if v}
    out = []
    for row in row_slices:
        if not row:
            continue
        rcw = (area_w - (len(row) - 1) * gap_x) / len(row) if bento else card_w
        ks = [sizes.get(str(nm).lower(), 1.0) for nm in row]
        row_w = sum(rcw * k for k in ks) + (len(row) - 1) * gap_x
        if row_w > area_w and row_w > 0:               # too wide with its big cards: the row shrinks
            f = max(0.2, (area_w - (len(row) - 1) * gap_x) / max(1.0, row_w - (len(row) - 1) * gap_x))
            ks = [k * f for k in ks]
            row_w = sum(rcw * k for k in ks) + (len(row) - 1) * gap_x
        row_h = max(card_h * k for k in ks)
        if align == "left":
            x0 = area_x
        elif align == "right":
            x0 = area_x + area_w - row_w
        else:
            x0 = area_x + (area_w - row_w) / 2.0
        x = x0
        for name, k in zip(row, ks):
            out.append((name, _box(x, y + (row_h - card_h * k) / 2.0, rcw * k, card_h * k)))
            x += rcw * k + gap_x
        y += row_h + gap_y
    return out, y - gap_y


_TOKEN_RX = re.compile(r"<[^<>]+>")
_WORD_RX = re.compile(r"<[^<>]+>\S*|\S+")          # words; an icon token ("<WILD BASE>,") is one word


def tokens_in(text):
    """Icon tokens of a text line, in order, without repeats."""
    out = []
    for t in _TOKEN_RX.findall(str(text or "")):
        if t.upper() not in [x.upper() for x in out]:
            out.append(t)
    return out


def strip_tokens(text, hidden):
    """Leave `hidden` icons out of a line without leaving a gap, a stray comma or a dangling "and".

    "<A>, <B> and <C>." without <C> -> "<A> and <B>."; without <B> -> "<A> and <C>.";
    "of <X> and <Y> functions" without <Y> -> "of <X> functions"."""
    text = str(text or "")
    for tok in hidden or []:
        t = re.escape(str(tok))
        m = re.search(r"\s*,\s*" + t, text, flags=re.I)                          # "<A>, <TOK> and <C>"
        if m:
            text = text[:m.start()] + text[m.end():]
            continue
        m = re.search(r"\s*\b(and|or)\s+" + t, text, flags=re.I)                 # "... and <TOK>"
        if m:
            conj, start = m.group(1), m.start()
            head, tail = text[:start], text[m.end():]
            k = head.rfind(", ")
            if k != -1 and not re.search(r"[.!?]", head[k:]):                     # the list keeps its "and"
                head = head[:k] + " " + conj + " " + head[k + 2:]
            text = head + tail
            continue
        m = re.search(t + r"\s*,\s*", text, flags=re.I)                          # "<TOK>, ..."
        if m:
            text = text[:m.start()] + text[m.end():]
            continue
        m = re.search(t + r"\s+(and|or)\s+", text, flags=re.I)                   # "<TOK> and ..."
        if m:
            text = text[:m.start()] + text[m.end():]
            continue
        text = re.sub(t, "", text, flags=re.I)
    text = re.sub(r"[ \t]{2,}", " ", text)
    text = re.sub(r",\s*,", ",", text)
    text = re.sub(r"\s+([,.;:!?])", r"\1", text)
    return re.sub(r"[ \t]{2,}", " ", text).strip()


def _carve(region, obstacles, gap):
    """The largest part of `region` (x0, y0, x1, y1) that none of `obstacles` overlap.

    Each obstacle that overlaps cuts the region on the side that keeps the
    most room (above it, below it, left or right of it)."""
    x0, y0, x1, y1 = region
    for ox0, oy0, ox1, oy1 in sorted(obstacles, key=lambda o: -(o[2] - o[0]) * (o[3] - o[1])):
        if ox1 + gap <= x0 or ox0 - gap >= x1 or oy1 + gap <= y0 or oy0 - gap >= y1:
            continue
        options = [(x0, y0, x1, oy0 - gap), (x0, oy1 + gap, x1, y1), (x0, y0, ox0 - gap, y1), (ox1 + gap, y0, x1, y1)]
        x0, y0, x1, y1 = max(options, key=lambda r: max(0.0, r[2] - r[0]) * max(0.0, r[3] - r[1]))
    return x0, y0, max(x0 + 1, x1), max(y0 + 1, y1)


def _rect(r):
    return (float(r[0]), float(r[1]), float(r[0]) + float(r[2]), float(r[1]) + float(r[3]))


ZONE_KINDS = ("wild", "scatter", "text", "jackpot")

_JACKPOT_TIERS = ("grand", "mega", "major", "maxi", "minor", "mini")
_JACKPOT_COLORS = {
    "grand": ("#4A0A18", "#FF3B5C", "#FFD23A"),
    "mega":  ("#3B0A45", "#D442FF", "#FFD23A"),
    "major": ("#3D1E05", "#FF9A2E", "#FFFFFF"),
    "maxi":  ("#2A1842", "#A463FF", "#FFFFFF"),
    "minor": ("#0A2442", "#3B9EFF", "#FFFFFF"),
    "mini":  ("#0A3628", "#3BE8A5", "#FFFFFF"),
}


def find_jackpot_tiers(ws):
    """Detect explicit standalone Jackpot tier definitions (e.g. GRAND / MAJOR / MINOR / MINI with
    prize values next to or below them). Returns [{"tier", "label", "value_cell", "value"}, ...]
    when at least 2 tiers exist, else []. Never triggers from prose sentences."""
    if ws is None:
        return []
    from openpyxl.utils import get_column_letter

    grid = {}
    for row in ws.iter_rows():
        for c in row:
            v = c.value
            if v is None or (isinstance(v, str) and not v.strip()):
                continue
            grid[(c.row, c.column)] = v
    ref = lambda r, c: f"{get_column_letter(c)}{r}"
    found = {}
    for (r, c), v in sorted(grid.items()):
        if not isinstance(v, str):
            continue
        clean = re.sub(r"[^a-zA-Z0-9 ]+", " ", v.strip("<> ")).strip().lower()
        words = clean.split()
        if not words or len(words) > 2:
            continue
        tier = next((t for t in _JACKPOT_TIERS if t in words and (len(words) == 1 or "jackpot" in words or "bonus" in words)), None)
        if not tier or tier in found:
            continue
        # Look for a prize value to the right (same row) or immediately below (same column)
        val_rc = next(((r, c + dc) for dc in range(1, 5) if (r, c + dc) in grid and _is_num(grid[(r, c + dc)])), None)
        if not val_rc:
            val_rc = next(((r + dr, c) for dr in (1, 2) if (r + dr, c) in grid and _is_num(grid[(r + dr, c)])), None)
        if val_rc:
            found[tier] = {
                "tier": tier,
                "label": v.strip("<> ").strip().upper(),
                "cell": ref(r, c),
                "value_cell": ref(*val_rc),
                "value": str(grid[val_rc]).strip(),
            }
    if len(found) < 2:
        return []
    return [found[t] for t in _JACKPOT_TIERS if t in found]


def adapt_aspect_parts(parts, aspect_ratio):
    """Adapt a card's internal parts list to its symbol's width/height aspect ratio.

    * Wide symbols (aspect_ratio >= 1.45): symbol spans the top half, counts & pays sit below.
    * Tall / square symbols (aspect_ratio < 1.45): symbol sits on the left, counts & pays on the right.
    Preserves font_size, color, bold, italic, and fx from the original counts/pays parts."""
    if not isinstance(parts, list) or not parts:
        return parts
    sym = next((dict(p) for p in parts if isinstance(p, dict) and p.get("role") == "symbol"), None)
    cnt = next((dict(p) for p in parts if isinstance(p, dict) and p.get("role") == "counts"), None)
    pay = next((dict(p) for p in parts if isinstance(p, dict) and p.get("role") == "pays"), None)
    others = [dict(p) for p in parts if isinstance(p, dict) and p.get("role") not in ("symbol", "counts", "pays")]
    if not (sym and cnt and pay):
        return parts
    if float(aspect_ratio or 1.0) >= 1.45:
        sym.update(x=0.08, y=0.04, w=0.84, h=0.46)
        cnt.update(x=0.12, y=0.54, w=0.28, h=0.42, align="right")
        pay.update(x=0.46, y=0.54, w=0.44, h=0.42, align="left")
    else:
        sym.update(x=0.03, y=0.05, w=0.46, h=0.90)
        cnt.update(x=0.52, y=0.08, w=0.14, h=0.84, align="right")
        pay.update(x=0.69, y=0.08, w=0.28, h=0.84, align="left")
    return [sym, cnt, pay] + others


def _band_icon_aspect(names, icon_folder, icon_mappings=None):
    """Median width/height aspect ratio of the resolved symbol PNGs for ``names``, or None."""
    if not icon_folder or not os.path.isdir(str(icon_folder)):
        return None
    from PIL import Image
    from ...icon_mapping import resolve_icon_path

    ratios = []
    for nm in names or []:
        try:
            p = resolve_icon_path(nm, icon_folder, icon_mappings or {}, royal_aliases(nm))
            if p and os.path.isfile(p):
                with Image.open(p) as im:
                    if im.width > 0 and im.height > 0:
                        ratios.append(float(im.width) / float(im.height))
        except Exception:
            continue
    if not ratios:
        return None
    ratios.sort()
    return ratios[len(ratios) // 2]


def zone_key(item):
    """The block an item of a zone holds: "wild", "scatter" or "text:<id>" (the rules text: "notes")."""
    return f"text:{item.get('id') or 'notes'}" if item.get("kind") == "text" else str(item.get("kind"))


def _zone_layout(zones, has, area_x, area_w, top, bottom, gap):
    """Rows of zones (template["zones"]), e.g. [SCATTER box | rules text | WILD box] under the title.

    Each row is a band across the page: "pos": "top" rows stack down from under the title, "bottom"
    rows up from the bottom margin; the cards take what is left. Its items sit side by side in
    proportion to their "w". An item shows by its rule — "always", "never", or "auto": only when the
    Excel has it (has[key] / has[kind]) — and a hidden item gives its room to the others; a row with
    nothing to show takes no room at all.
    Returns ({item key: (x0, y0, x1, y1)}, [row info for the editor], [row rects])."""
    rects, meta, rows = {}, [], []
    y_top, y_bot = float(top), float(bottom)
    for zi, z in enumerate(zones):
        items = [it for it in (z.get("items") or []) if isinstance(it, dict) and it.get("kind") in ZONE_KINDS]
        rule = lambda it: str(it.get("show") or "auto")     # noqa: E731
        vis = [it for it in items if rule(it) == "always" or (rule(it) == "auto" and has.get(zone_key(it), has.get(it["kind"], False)))]
        pos = "bottom" if z.get("pos") == "bottom" else "top"
        h = max(40.0, float(z.get("h", 280)))
        if z.get("h_share"):                         # a share of the page's height: a short page, a lower zone
            h = max(40.0, min(h, float(z["h_share"]) * (float(bottom) - float(top))))
        zgap = float(z.get("gap", gap))
        info = {"id": str(z.get("id") or f"zone{zi}"), "index": zi, "pos": pos, "h": h, "rect": None, "items": []}
        if vis:
            if pos == "bottom":
                y = y_bot - h
                y_bot = y - gap
            else:
                y = y_top
                y_top = y + h + gap
            ws = [max(0.05, float(it.get("w", 1) or 1)) for it in vis]
            avail = area_w - (len(vis) - 1) * zgap
            x = float(area_x)
            for it, wk in zip(vis, ws):
                w = avail * wk / sum(ws)
                rects[zone_key(it)] = (x, y, x + w, y + h)
                x += w + zgap
            info["rect"] = (float(area_x), y, float(area_x + area_w), y + h)
            rows.append(info["rect"])
        info["items"] = [{"kind": it["kind"], "key": zone_key(it), "show": rule(it), "w": it.get("w", 1),
                          "title": it.get("title", ""), "visible": any(it is v for v in vis),
                          "has": bool(has.get(zone_key(it), has.get(it["kind"], False)))} for it in items]
        meta.append(info)
    return rects, meta, rows


def mid_split(names, ws):
    """Where a third tier starts in the high row: after the biggest drop in top pay (the Excel's order
    kept), else half way. Always leaves at least one symbol on each side."""
    n = len(names)
    if n < 2:
        return n
    tops = []
    if ws is not None:
        from . import pay_reader as _pr

        try:
            read = _pr.read_sheet(ws)
            by = {_pr.key_of(x["symbol"]): max((p["pay"] for p in x["pays"] if isinstance(p["pay"], (int, float))), default=0)
                  for x in read.get("symbols") or []}
            tops = [by.get(_pr.key_of(k)) for k in names]
        except Exception:
            tops = []
    if tops and all(isinstance(v, (int, float)) and v > 0 for v in tops):
        ratio, at = max((tops[i] / tops[i + 1], i) for i in range(n - 1))
        if ratio > 1.05:
            return at + 1
    return (n + 1) // 2


def _fill_free_band(bid, blocks, slots, text_meta, area_x, area_w, top, bottom, gap, W):
    """The rules box into the biggest free space of the page once the cards are placed: above them
    (under the title), below them, or beside them — around the WILD / SCATTER boxes and other text."""
    key = f"text:{bid}"
    others = [b for k, b in blocks.items() if k in ("wild", "scatter", "scatsec") or k.startswith("zone:") or (k.startswith("text:") and k != key)]
    cards = blocks.get("cards")
    x_r = area_x + area_w
    if cards:
        spans = [(area_x, top, x_r, cards[1] - gap), (area_x, cards[3] + gap, x_r, bottom),
                 (cards[2] + gap, top, x_r, bottom), (area_x, top, cards[0] - gap, bottom)]
    else:
        spans = [(area_x, top, x_r, bottom)]
    best, best_area = None, 0.0
    for x0, y0, x1, y1 in spans:
        if x1 - x0 < 300:
            continue
        for o in others:                              # a box in the space: the bigger side of it (above / below)
            if o[3] <= y0 or o[1] >= y1 or o[2] <= x0 or o[0] >= x1:
                continue
            if (o[1] - y0) >= (y1 - o[3]):
                y1 = o[1] - gap
            else:
                y0 = o[3] + gap
        area = (x1 - x0) * (y1 - y0)
        if y1 - y0 >= 60 and area > best_area:
            best, best_area = (x0, y0, x1, y1), area
    if not best:
        return
    x0, y0, x1, y1 = best
    old = blocks[key]
    blocks[key] = (x0, y0, x1, y1)
    tm = next((m for m in text_meta if m["id"] == bid), None)
    if tm:
        slots[tm["slot"]] = _box(x0, y0, x1 - x0, y1 - y0)
        bgk = f"@slot.textbg.{bid}"
        if bgk in slots:                              # its panel / strip goes with it
            pad = (slots[bgk]["h"] - (old[3] - old[1])) / 2.0
            strip = slots[bgk]["x"] == 0 and slots[bgk]["w"] >= W
            slots[bgk] = _box(0 if strip else x0 - pad, y0 - pad, W if strip else (x1 - x0) + 2 * pad, (y1 - y0) + 2 * pad)


def _lock_box(band):
    """A locked row's box [w, h] (its cards scale to stay inside), else None. An unlocked row has no box of
    its own, even with one left from when it was locked: it is exactly its cards, free like any other."""
    lsz = band.get("lock_size")
    if band.get("locked") is False or not isinstance(lsz, (list, tuple)) or len(lsz) != 2:
        return None
    return lsz


def design_frame(canvas=None):
    """(W, H) of the design frame for a page of ``canvas`` (w, h) px: the page's own shape, 1920 wide —
    1080 tall when the page is wider than 16:9 — so a design px is the same canvas px as on the old fixed
    1920 x 1080 frame, and the cards, boxes and text can go anywhere on the page. Rounded down to whole
    px, the growth even: the scale stays exactly the old one (the page's sub-px rest is centred like
    before) and an old design moves by whole px (frame_shift)."""
    try:
        cw, ch = (float(v) for v in canvas)
    except (TypeError, ValueError):
        return float(CANVAS[0]), float(CANVAS[1])
    if cw <= 0 or ch <= 0:
        return float(CANVAS[0]), float(CANVAS[1])
    if cw * CANVAS[1] >= ch * CANVAS[0]:
        return float(CANVAS[0] + 2 * math.floor((CANVAS[1] * cw / ch - CANVAS[0]) / 2 + 1e-6)), float(CANVAS[1])
    return float(CANVAS[0]), float(CANVAS[1] + 2 * math.floor((CANVAS[0] * ch / cw - CANVAS[1]) / 2 + 1e-6))


def bg_area(canvas, area):
    """The background picture's part of the page (bg_place.area: canvas px x, y, w, h) in design px
    (x0, y0, x1, y1), or None (no area: the whole page)."""
    try:
        x, y, w, h = (float(v) for v in area)
        cw, ch = (float(v) for v in canvas)
    except (TypeError, ValueError):
        return None
    W, H = design_frame(canvas)
    sc = min(cw / W, ch / H)
    ox, oy = (cw - W * sc) / 2.0, (ch - H * sc) / 2.0
    x0, y0 = max(0.0, (x - ox) / sc), max(0.0, (y - oy) / sc)
    x1, y1 = min(W, (x + w - ox) / sc), min(H, (y + h - oy) / sc)
    return (x0, y0, x1, y1) if x1 - x0 > 20 and y1 - y0 > 20 else None


def frame_shift(canvas=None, area=None):
    """(dx, dy) design px a design made on the old 1920 x 1080 frame moves by on the page frame: the old
    frame sat centred in the page (0, 0 on a 16:9 page) — in the background picture's part of it when the
    picture covers only a part (``area``: bg_area, design px), so the paytable starts on the background."""
    W, H = design_frame(canvas)
    if area:
        x0, y0, x1, y1 = area
        dx = x0 + ((x1 - x0) - CANVAS[0]) / 2.0
        dy = y0 + ((y1 - y0) - CANVAS[1]) / 2.0
        # whole px, and the old frame kept on the page
        return float(round(max(0.0, min(W - CANVAS[0], dx)))), float(round(max(0.0, min(H - CANVAS[1], dy))))
    return (W - CANVAS[0]) / 2.0, (H - CANVAS[1]) / 2.0


def to_page_frame(template, canvas=None, area=None):
    """The template on the page frame (``frame: "page"``). One made on the old centred 1920 x 1080 frame
    has every page position moved by frame_shift (its bottom / side margins grown by it), so it stays
    where it was on the page. Idempotent: a template already on the page frame comes back as it is;
    otherwise a copy."""
    if not isinstance(template, dict) or template.get("frame") == "page":
        return template
    t = json.loads(json.dumps(template))
    t["frame"] = "page"
    dx, dy = frame_shift(canvas, area)
    if not (dx or dy):
        return t

    def mv(r):                                   # [x, y, ...] -> moved, anything else as it is
        if isinstance(r, (list, tuple)) and len(r) >= 2 and all(isinstance(v, (int, float)) for v in r[:2]):
            return [round(r[0] + dx, 1), round(r[1] + dy, 1), *r[2:]]
        return r

    page = t.setdefault("page", {})
    W, H = design_frame(canvas)
    # the room the old frame leaves on each side (the same both ways when it is centred on the page)
    for k, d, dflt in (("top", dy, 30), ("bottom", H - CANVAS[1] - dy, 30), ("left", dx, 60), ("right", W - CANVAS[0] - dx, 60)):
        try:
            page[k] = round(float(page.get(k, dflt)) + d, 1)
        except (TypeError, ValueError):
            pass
    for k in ("cards_lock", "cards_at"):
        if k in page:
            page[k] = mv(page[k])
    for x in page.get("texts") or []:
        if isinstance(x, dict) and "rect" in x:
            x["rect"] = mv(x["rect"])
    for k, v in (t.get("features") or {}).items():
        if k.endswith("_box") and isinstance(v, dict) and "rect" in v:
            v["rect"] = mv(v["rect"])
    sec = t.get("scatter_section")
    if isinstance(sec, dict):
        for k in ("rect", "area"):
            if k in sec:
                sec[k] = mv(sec[k])
    for b in t.get("bands") or []:
        if isinstance(b, dict) and "pos" in b:
            b["pos"] = mv(b["pos"])
    for v in (t.get("card_overrides") or {}).values():
        if isinstance(v, dict) and "free" in v:
            v["free"] = mv(v["free"])
    return t


NUMBERS_GAP = 0.04          # the space put between counts and pays that had crossed (a share of the card)


def _crossed_numbers(parts):
    """(counts, pays) of a card whose numbers have crossed, else None: counts right-aligned and pays
    left-aligned on the same lines, with the pays starting before the counts end — their numbers would run
    into each other or swap sides ("1005", pays left of counts)."""
    if not isinstance(parts, list):
        return None
    c = next((p for p in parts if isinstance(p, dict) and p.get("role") == "counts"), None)
    q = next((p for p in parts if isinstance(p, dict) and p.get("role") == "pays"), None)
    if not c or not q or str(c.get("align") or "") != "right" or str(q.get("align") or "left") != "left":
        return None
    try:
        cx, cw, cy, ch = (float(c.get(k, d)) for k, d in (("x", 0), ("w", 1), ("y", 0), ("h", 1)))
        qx, qy, qh = (float(q.get(k, d)) for k, d in (("x", 0), ("y", 0), ("h", 1)))
    except (TypeError, ValueError):
        return None
    if min(cy + ch, qy + qh) <= max(cy, qy) or qx >= cx + cw:
        return None
    return c, q


def numbers_in_order(template):
    """The template with every card's counts back before its pays where they had crossed (see
    _crossed_numbers): both columns meet where they overlapped, NUMBERS_GAP apart. Unchanged (the same
    object) when nothing had crossed."""
    if not isinstance(template, dict):
        return template
    lists = lambda t: [(t.get("card") or {}).get("parts")] + [b.get("parts") for b in t.get("bands") or [] if isinstance(b, dict)] +         [v.get("parts") for v in (t.get("card_overrides") or {}).values() if isinstance(v, dict)] +         [(t.get("scatter_section") or {}).get("parts")]  # noqa: E731
    if not any(_crossed_numbers(ps) for ps in lists(template)):
        return template
    t = json.loads(json.dumps(template))
    for ps in lists(t):
        hit = _crossed_numbers(ps)
        if hit:
            c, q = hit
            mid = (float(q.get("x", 0)) + float(c.get("x", 0)) + float(c.get("w", 1))) / 2.0
            c["x"] = round(mid - NUMBERS_GAP / 2.0 - float(c.get("w", 1)), 4)
            q["x"] = round(mid + NUMBERS_GAP / 2.0, 4)
    return t


def settle_frame(framed, compiled):
    """The design moved to the page frame (to_page_frame) with its moved rows / cards offset where the old
    frame kept them (compile_template's mapper_meta["band_at"]): saved like that, nothing jumps when the
    page frame stops holding them in."""
    at = ((compiled or {}).get("mapper_meta") or {}).get("band_at")
    if not isinstance(framed, dict) or not isinstance(at, dict) or not at:
        return framed
    t = json.loads(json.dumps(framed))
    bands = t.get("bands") or []
    for bid, i in (("low", min(1, len(bands) - 1)), ("mid", 2), ("high", 0)):     # the rows' bands (compile_template)
        b = bands[i] if 0 <= i < len(bands) else None
        if bid in at and isinstance(b, dict) and isinstance(b.get("pos"), (list, tuple)) and len(b["pos"]) == 2:
            b["pos"] = list(at[bid])
    if "cards_offset" in at and isinstance((t.get("page") or {}).get("cards_offset"), (list, tuple)):
        t["page"]["cards_offset"] = list(at["cards_offset"])
    return t


def compile_template(template, structure, ws=None, ctx=None):
    """(mapped-paytable template, {slot: style mapping}) for one sheet.

    structure: engine_api.paytable_sheet_structure() — top/lower counts and
    block_keys (the sheet's symbols in order). ws: the sheet (wild token, wild
    description, "pay any", and the rules lines). ctx (optional):
      canvas        (w, h) of the output canvas — to put the title where the
                    other pages' headings are
      heading_top   that heading's top (canvas px), heading_size its size
      bg_area       the background picture's part of the page (canvas px x, y, w, h; bg_place.area) when
                    it covers only a part: the cards, boxes and text start and stay inside it
      rules_cells   the sheet's rules/notes cells (the auto-mapper's catch-all)

    Layout: the title sits at the page-heading position (not movable); WILD /
    SCATTER boxes and text boxes are free rectangles (design px on the page
    frame, design_frame(): 1920 wide, the page's shape);
    the cards (high + low rows) fill the largest free area left over — they
    shrink to fit and never overlap a box or text. mapper_meta carries every
    item's box and the text boxes' lines for the on-canvas editor.
    """
    ctx = ctx or {}
    W, H = design_frame(ctx.get("canvas") or CANVAS)
    area = bg_area(ctx.get("canvas") or CANVAS, ctx.get("bg_area")) if ctx.get("bg_area") else None
    t = numbers_in_order(to_page_frame(template or {}, ctx.get("canvas") or CANVAS, area))
    # a design from the old fixed frame keeps to it (rows, boxes kept inside it) as it did, until it is
    # saved on the page frame: mapper_meta["band_at"] gives the rows' places to save (to_page_frame)
    old_frame = isinstance(template, dict) and template.get("frame") != "page"
    kx0, ky0 = frame_shift(ctx.get("canvas") or CANVAS, area) if old_frame else (0.0, 0.0)
    keep = (kx0, ky0, kx0 + CANVAS[0], ky0 + CANVAS[1]) if old_frame else (area or (0.0, 0.0, float(W), float(H)))
    if old_frame and area:                          # (the old frame inside the background, as far as it fits)
        keep = (max(keep[0], area[0]), max(keep[1], area[1]), min(keep[2], area[2]), min(keep[3], area[3]))
    band_at = {}
    page = t.get("page") or {}
    styles = t.get("styles") or {}
    card = t.get("card") or {}
    left, right = float(page.get("left", 60)), float(page.get("right", 60))
    bottom_m = float(page.get("bottom", 30))
    area_x, area_w = left, W - left - right
    gap_x, gap_y = float(page.get("gap_x", 24)), float(page.get("gap_y", 20))
    gap = float(page.get("band_gap", gap_y))
    align = str(page.get("align") or "center")
    slots, maps, blocks = {}, {}, {}
    cells = _cells(ws)
    cell_text = dict(cells)

    # sheet symbols -> rows
    keys, scatter = _clean_keys((structure or {}).get("block_keys") or [])
    top_n = int((structure or {}).get("top") or 0)
    # the bottom row starts at ACE (or the first royal when there is no ACE); everything above it is the top row
    _royal = [i for i, k in enumerate(keys) if _norm(k) in ("ace", "a")] or \
             [i for i, k in enumerate(keys) if _norm(k) in ("king", "queen", "jack", "ten", "nine", "k", "q", "j", "10", "9")]
    if _royal and _royal[0] > 0:
        top_n = _royal[0]
    high, low = list(keys[:top_n]), list(keys[top_n:])
    if not keys:
        high, low = [f"pic{i}" for i in range(1, 6)], ["ace", "king", "queen", "jack", "ten"]

    # ── title: exactly where the other pages' headings are ──
    cw, ch = ctx.get("canvas") or (W, H)
    sc = min(float(cw) / W, float(ch) / H)
    off_y = (float(ch) - H * sc) / 2.0
    title = page.get("title") or {}
    content_top = float(page.get("top", 30))
    if title.get("enabled", True):
        h_top = (float(ctx.get("heading_top", 150)) - off_y) / sc if ctx.get("heading_top") is not None else content_top
        # the paytable's title can look its own way (page.title: font, size, colour, bold, italic, layer
        # style) — only this design's title, never another page's heading; else the page heading's look
        own = {k: title[k] for k in ("font", "font_size", "color", "bold", "italic", "fx") if title.get(k) not in (None, "")}
        h_size = float(own.get("font_size") or ctx.get("heading_size") or 60) / sc
        plate_on = bool(title.get("plate", True)) and shape_of(styles.get(title.get("style") or "plate")) is not None
        pad_y = float(title.get("pad_y", 10)) if plate_on else 0.0
        th = h_size * 1.35 + 2 * pad_y
        tw = float(title.get("w", 900)) if plate_on else area_w
        # moved on the Canvas (page.title dx / dy, design px): from where the other pages' headings are
        box = _box((W - tw) / 2.0 + float(title.get("dx") or 0), h_top - pad_y + float(title.get("dy") or 0), tw, th)
        slots["@slot.title"] = box
        m = {"alignment": "center", "vertical_align": "center", "font_size": 0}      # the page heading's own look
        if own:
            m["title_own"] = own
        if plate_on:
            m["shape"] = shape_of(styles.get(title.get("style") or "plate"))
            pads = title.get("plate_pads")
            if isinstance(pads, (list, tuple)) and len(pads) == 4:
                # sized on the Canvas: its own margin on each side of the title's text (left, top, right,
                # bottom — any size, below 0 inside the text), so it keeps to the title when its words change
                try:
                    m["shape"]["pads"] = [round(float(v) * sc, 2) for v in pads]
                except (TypeError, ValueError):
                    pass
            if "pads" not in m["shape"] and title.get("fit"):   # the plate hugs the title's text (+ this much each side)
                m["shape"]["fit"] = float(title.get("fit_pad", 40) or 0)
        maps["@slot.title"] = m
        blocks["title"] = _rect((box["x"], box["y"], box["w"], box["h"]))
        # the space under the title to the cards: its own (page.title.gap, the Title–Cards guide) or the rows'
        content_top = box["y"] + box["h"] + (float(title["gap"]) if title.get("gap") not in (None, "") else gap)
    content = (area_x, content_top, area_x + area_w, H - bottom_m)
    blocks["page"] = (area_x, float(page.get("top", 30)), area_x + area_w, H - bottom_m)
    if page.get("use_page_margins") and ctx.get("page_margins"):
        # the design keeps to the other pages' side and bottom margins (canvas px -> design px), as a text page does
        try:
            mx, mb = (float(v) for v in ctx["page_margins"])
            cw_, ch_ = (float(v) for v in (ctx.get("canvas") or CANVAS))
            sc_ = min(cw_ / W, ch_ / H)
            ox_, oy_ = (cw_ - W * sc_) / 2.0, (ch_ - H * sc_) / 2.0
            sx0, sx1, sy1 = (mx - ox_) / sc_, (cw_ - mx - ox_) / sc_, (ch_ - mb - oy_) / sc_
            if sx1 - sx0 > 200 and sy1 - content[1] > 200:
                content = (max(content[0], sx0), content[1], min(content[2], sx1), min(content[3], sy1))
                pg = blocks["page"]
                blocks["page"] = (max(pg[0], sx0), pg[1], min(pg[2], sx1), min(pg[3], sy1))
                tb = slots.get("@slot.title")
                if tb and (tb["x"] < content[0] or tb["x"] + tb["w"] > content[2]):    # the title inside them too
                    nw = min(tb["w"], content[2] - content[0])
                    nx = max(content[0], min(tb["x"], content[2] - nw))
                    slots["@slot.title"] = dict(tb, x=int(nx), w=int(nw))
                    blocks["title"] = (nx, tb["y"], nx + nw, tb["y"] + tb["h"])
        except (TypeError, ValueError):
            pass
    if area:                                        # only the background's part of the page
        content = (max(content[0], area[0]), max(content[1], area[1]),
                   min(content[2], area[2]), min(content[3], area[3]))
        pg = blocks["page"]
        blocks["page"] = (max(pg[0], area[0]), max(pg[1], area[1]), min(pg[2], area[2]), min(pg[3], area[3]))

    # ── a scatter section (symbols with their own pays below the grid), read from the sheet ──
    sec_def = t.get("scatter_section") or {}
    section = find_pay_section(ws, keys) if sec_def.get("enabled", True) else None
    if section and not section.get("cards"):
        section = None                              # no scatter on this sheet: no SCATTER card at all
    if section and len(section["cards"]) < 2 and not sec_def.get("enabled"):
        section = None                              # one lone scatter: the classic SCATTER box / card handles it
    if section:
        heading = _norm(section["title"][1]) if section.get("title") else ""
        sec_keys = {cd["key"] for cd in section["cards"]}
        if scatter and (_norm(scatter) in sec_keys or _norm(scatter) == heading):
            scatter = ""                            # the section's heading, not a symbol of the grid
        high = [k for k in high if _norm(k) != heading]
        low = [k for k in low if _norm(k) != heading]

    # ── an independent card put in a row on the Canvas (card_overrides[key]["in_row"] = "high" | "low"): a
    # SCATTER card, a coin, the lone SCATTER — a card of that row from now on, with its own look (its
    # parts / style in card_overrides) or the row's. Its numbers come from its own cells (joined_src).
    _ovr = {str(k).lower(): v for k, v in (t.get("card_overrides") or {}).items() if isinstance(v, dict)}

    def _joined(key):
        r = (_ovr.get(str(key).lower()) or {}).get("in_row")
        return r if r in ("high", "low") else None

    joined_src = {}
    if section:
        left = []
        for cd in section["cards"]:
            r = _joined(cd["key"])
            if r:
                (high if r == "high" else low).append(cd["key"])
                joined_src[cd["key"]] = cd
            else:
                left.append(cd)
        if len(left) < len(section["cards"]):
            section = dict(section, cards=left) if left else None
    if scatter and _joined(scatter):
        (high if _joined(scatter) == "high" else low).append(scatter)
        scatter = ""                                # no SCATTER box: it is a card of the row

    # ── WILD / SCATTER boxes: free rectangles ──
    feats = t.get("features") or {}
    wild_token = _wild_token(cells)
    wild_text = _find_cell(cells, "substitut")
    if not wild_token and wild_text[1]:
        # a wild not named WILD ("<SUNSET> is wild and substitutes ..."): the symbol that line starts with
        lead = re.match(r"\s*(<[^<>]+>)", wild_text[1])
        wild_token = lead.group(1) if lead else ""
    payany = _find_cell(cells, "pay any")
    # a WILD with its own pays in the symbol grid: it leaves the rows for the WILD box
    wild_key = next((k for k in high + low if "wild" in k.casefold()), "")
    # the WILD that pays is a card like the others, in every design — in its row, the size of its row's cards
    # (no wide WILD box, no rules sentence pulled into it: that line stays in the rules text). "Break out"
    # moves and sizes it like any card (card_overrides[wild]["free"]); "Join row" puts it in another row.
    # The user, 2026-10-29: "the wild card should be transformable"; 2026-10-30: "make the wild card same
    # as our normal card … not so wide", "remove the sentence from the wild box".
    wild_as_card = bool(wild_key)
    auto_free = []
    if wild_key and not wild_as_card:
        high = [k for k in high if k != wild_key]
        low = [k for k in low if k != wild_key]
    if wild_key and not wild_token:
        wild_token = f"<{wild_key.upper()}>"
    # ── zones: rows like [SCATTER box | rules text | WILD box], each item shown by its rule ──
    zones = [z for z in t.get("zones") if isinstance(z, dict)] if isinstance(t.get("zones"), list) else []
    # a WILD / SCATTER box only for a real card of the AGR (the symbol with its own pays) — never for a WILD
    # only named in the rules ("<INGOT> substitutes for…": that line stays in the rules text)
    jackpots = find_jackpot_tiers(ws) if ws is not None else []
    has = {"wild": bool(wild_key) and not wild_as_card, "scatter": bool(scatter or section), "jackpot": bool(jackpots),
           "text": (page.get("notes") or {}).get("enabled", True) is not False
           and any(str(cell_text.get(c, "") or "").strip() for c in ctx.get("rules_cells") or [])}
    zone_rect, zone_meta, zone_rows = _zone_layout(zones, has, content[0], content[2] - content[0], content[1], content[3], gap) \
        if zones else ({}, [], [])
    # ── docked columns (the fruit classic): a row docked to the page's left / right side is a column from the
    # zones above to the zones below; the WILD / SCATTER boxes docked in the middle ("dock": "center") — the
    # ones the sheet has share the middle, and with neither the columns take the whole width. A row moved
    # by hand (pos) or a box moved by hand (its rect) stays where it was put.
    _bands0 = t.get("bands") or []
    _docked = [i for i, b in enumerate(_bands0) if isinstance(b, dict) and b.get("dock") in ("left", "right") and not b.get("pos")]
    if _docked:
        cx0, cx1, dy0, dy1 = content[0], content[2], content[1], content[3]
        for zr in zone_rows:                        # the zone rows above / below the columns
            if (zr[1] + zr[3]) / 2.0 <= (dy0 + dy1) / 2.0:
                dy0 = max(dy0, zr[3] + gap)
            else:
                dy1 = min(dy1, zr[1] - gap)
        mid = [b for b in ("wild", "scatter") if (t.get("features") or {}).get("dock") == "center"
               and has.get(b) and b not in zone_rect and not ((t.get("features") or {}).get(b + "_box") or {}).get("rect")]
        share = max(0.1, min(0.48, float(_bands0[_docked[0]].get("dock_w") or 0.3)))
        col_w = share * (cx1 - cx0) if mid else (cx1 - cx0 - gap) / 2.0
        nb = [dict(b) if isinstance(b, dict) else b for b in _bands0]
        for i in _docked:
            b = nb[i]
            x = cx0 if b["dock"] == "left" else cx1 - col_w
            b["pos"], b["lock_size"] = [round(x, 1), round(dy0, 1)], [round(col_w, 1), round(dy1 - dy0, 1)]
            b.pop("locked", None)
            # one card a line: the cards share the column's height (no taller than designed) and keep its
            # whole width — never the whole card shrunk as a picture, numbers and all
            n = len(high if b.get("name") == "high" else low if b.get("name") == "low" else []) or 1
            if int(b.get("per_row") or 1) == 1:
                gy_ = float(b.get("gap_y", gap_y))
                h0 = float(b.get("card_h") or 150)
                b["card_h"] = round(max(40.0, min(h0, (dy1 - dy0 - (n - 1) * gy_) / n)), 1)
                b["card_w"] = round(col_w, 1)
                # its numbers fit the lower card: smaller with it, and with more pay lines than the 3 designed
                rows_ = max(1, int((structure or {}).get("max_pay_rows") or 3))
                k = min(1.0, b["card_h"] / h0) * min(1.0, 3.0 / rows_)
                if k < 0.999 and isinstance(b.get("parts"), list):
                    b["parts"] = [dict(p, font_size=round(float(p["font_size"]) * k, 1)) if p.get("font_size") else p for p in b["parts"]]
        feats_d = dict(t.get("features") or {})
        if mid:
            mx0, mx1 = cx0 + col_w + gap, cx1 - col_w - gap
            tab_d = float(feats_d.get("tab_h", 56)) if (feats_d.get("tab") or {}).get("enabled", True) else 0.0
            hh = (dy1 - dy0 - (len(mid) - 1) * gap) / len(mid)
            for j, b in enumerate(mid):
                y = dy0 + j * (hh + gap)
                feats_d[b + "_box"] = dict(feats_d.get(b + "_box") or {}, rect=[round(mx0, 1), round(y + tab_d / 2.0, 1), round(mx1 - mx0, 1), round(hh - tab_d / 2.0, 1)])
        t = dict(t, bands=nb, features=feats_d)
        feats = feats_d
    # a text box docked to a side ("dock": "left" / "right", "dock_w" a share of the page): from the zones
    # above to the zones below, the cards keep clear of it (it is locked); one moved by hand keeps its rect
    _tdock = [i for i, x in enumerate(page.get("texts") or []) if isinstance(x, dict) and x.get("dock") in ("left", "right", "top", "bottom")]
    if _tdock:
        cx0, cx1, dy0, dy1 = content[0], content[2], content[1], content[3]
        for zr in zone_rows:
            if (zr[1] + zr[3]) / 2.0 <= (dy0 + dy1) / 2.0:
                dy0 = max(dy0, zr[3] + gap)
            else:
                dy1 = min(dy1, zr[1] - gap)
        tx = [dict(x) if isinstance(x, dict) else x for x in page.get("texts") or []]
        for i in _tdock:
            x = tx[i]
            if x.get("rect") and x.get("moved"):
                continue
            share = max(0.1, min(0.6, float(x.get("dock_w") or 0.3)))
            if x["dock"] in ("left", "right"):
                w = share * (cx1 - cx0)
                x["rect"] = [round(cx0 if x["dock"] == "left" else cx1 - w, 1), round(dy0, 1), round(w, 1), round(dy1 - dy0, 1)]
            else:
                h = share * (dy1 - dy0)
                x["rect"] = [round(cx0, 1), round(dy0 if x["dock"] == "top" else dy1 - h, 1), round(cx1 - cx0, 1), round(h, 1)]
            x["locked"] = True
        page = dict(page, texts=tx)
        t = dict(t, page=page)
    zoned = {it["key"] for z in zone_meta for it in z["items"]}
    zone_title = {it["key"]: it["title"] for z in zone_meta for it in z["items"] if it.get("title")}
    # WILD and SCATTER symbols that pay always get a box of their own (never a card in the top /
    # bottom row), even when the design has none: then a default box sits at the bottom, moves like
    # any box, and shows the symbol and its pays (the rules text stays where it is)
    feature_boxes, forced = [], set()
    if feats.get("enabled") and feats.get("wild", True) and wild_key and not wild_as_card:
        feature_boxes.append("wild")
    elif wild_key and not wild_as_card:
        feature_boxes.append("wild")
        forced.add("wild")
    if scatter:
        feature_boxes.append("scatter")
        if not (feats.get("enabled") and feats.get("scatter", True)):
            forced.add("scatter")
    # a box in a zone: there when its zone shows it (a sheet with no WILD has no WILD box), placed by it
    for b in ("wild", "scatter"):
        if b not in zoned:
            continue
        if b in zone_rect:
            if b not in feature_boxes and not (b == "scatter" and section):
                feature_boxes.append(b)
            forced.discard(b)
        elif b in feature_boxes and b not in forced:
            feature_boxes.remove(b)
    # the AGR's own words around each symbol: "Scatter" above <SCAT> (the box's heading) and
    # "pay any" under it (its caption) — both rendered in the box, movable and styled there
    around = {"scatter": _symbol_texts(cells, scatter, keys) if scatter else (("", ""), ("", "")),
              "wild": _symbol_texts(cells, wild_key, keys) if wild_key else (("", ""), ("", ""))}
    if scatter and not around["scatter"][1][0] and payany[0]:
        around["scatter"] = (around["scatter"][0], payany)
    # a WILD box of the design: the AGR's "<WILD> appears on reels 2, 3, 4 and 5 only." is its caption
    if "wild" in feature_boxes and "wild" not in forced and not around["wild"][1][0] and wild_token:
        wtok = wild_token.strip("<> ").casefold()
        reels = next(((c, tx) for c, tx in cells if c != wild_text[0] and "reel" in tx.casefold()
                      and re.search(r"\bappears?\b", tx, re.I) and re.match(r"\s*<\s*" + re.escape(wtok) + r"\s*>", tx, re.I)), None)
        if reels:
            around["wild"] = (around["wild"][0], reels)
    feature_parts = {}
    box_texts = {}                              # the boxes' own words: their slot -> the Excel's words (typed over on the Canvas)
    tab = feats.get("tab") or {}
    tab_h = float(feats.get("tab_h", 56)) if tab.get("enabled", True) else 0.0
    obstacles = []
    hard = []                                   # boxes the cards never grow into (text boxes step aside instead)
    wild_meta = {}
    if feature_boxes:
        fh = float(feats.get("h", 260))
        widths = {"wild": float(feats.get("wild_w", 0.6)), "scatter": float(feats.get("scatter_w", 0.4))}
        tot = sum(widths[b] for b in feature_boxes) or 1.0
        fgap = float(feats.get("gap", gap_x))
        own = [b for b in feature_boxes if b not in forced]
        avail = area_w - (len(own) - 1) * fgap
        x = area_x
        # boxes the design doesn't have: at the bottom of the page, where they cover the least of
        # the design's text boxes (drawn over them, see the end — the artist moves them from there)
        fw, ffh = DEFAULT_FEATURE_BOX
        taken = [tuple(x["rect"]) for x in (page.get("texts") or []) if isinstance(x, dict) and x.get("rect")] or \
            [(area_x, content[3] - float((page.get("notes") or {}).get("h", 150)), area_w,
              float((page.get("notes") or {}).get("h", 150)))]
        for b in feature_boxes:
            if b in forced:
                default = _free_spot(taken, fw, ffh, content[0], content[2] - content[0], (content[3] - ffh,))
                taken.append(tuple(default))
            else:
                bw = avail * widths[b] / tot
                default = [x, content_top + tab_h / 2.0, bw, fh]          # a row under the title
                x += bw + fgap
            rect = (feats.get(b + "_box") or {}).get("rect") or default
            if b in zone_rect:                                   # its zone places it (less half the tab above it)
                zr = zone_rect[b]
                rect = [zr[0], zr[1] + tab_h / 2.0, zr[2] - zr[0], max(40.0, zr[3] - zr[1] - tab_h / 2.0)]
            box = _box(*rect)
            name = "wildbox" if b == "wild" else "scatbox"
            slots[f"@slot.{name}"] = box
            # a design without a "feature" look: the box looks like its cards
            shape = shape_of(styles.get(feats.get("style") or "feature") or styles.get("card"))
            maps[f"@slot.{name}"] = {"mode": "none", "kind": "background", "symbol_pinned": True,
                                     **({"shape": shape} if shape else {})}
            head, cap = around[b]
            if tab.get("enabled", True):
                tw = min(float(tab.get("w", 240)), box["w"])
                tbox = _box(box["x"] + (box["w"] - tw) * float(tab.get("x", 0.5)), box["y"] - tab_h / 2.0, tw, tab_h)
                slots[f"@slot.{name}.tab"] = tbox
                # a design with a label tab: the AGR's heading is the tab's text
                tm = {"mode": "text", "source": "", "text": _typed(t, zone_title.get(b) or head[1] or ("WILD" if b == "wild" else "SCATTER"), f"@slot.{name}.tab", box_texts),
                      "alignment": "center", "vertical_align": "center", "font_override": True}
                tm.update(_text_style(tab.get("text") or {}))
                tshape = shape_of(styles.get(tab.get("style") or "tab"))
                if tshape:
                    tm["shape"] = tshape
                maps[f"@slot.{name}.tab"] = tm
            fparts = (feats.get("wild_parts") if b == "wild" else feats.get("scatter_parts")) or \
                json.loads(json.dumps(DEFAULT_WILD_PARTS if b == "wild" else DEFAULT_SCATTER_PARTS))
            if b in forced:                               # the substitute line stays in the rules text
                fparts = {k: v for k, v in fparts.items() if k != "text"}
            fparts = dict(fparts)
            if isinstance(fparts.get("panel"), dict):       # a panel inside the box (a blueprint's inner shape)
                pshape = shape_of(styles.get(fparts["panel"].get("style") or ""))
                if pshape:
                    slots[f"@slot.{name}.panel"] = _sub_box(box, fparts["panel"])
                    maps[f"@slot.{name}.panel"] = {"mode": "none", "kind": "background", "symbol_pinned": True, "shape": pshape}
            # a heading / caption the design keeps ("keep": a blueprint drew it) shows on every sheet: the
            # heading then says WILD / SCATTER, the caption keeps its band (empty) for the artist to type in
            kept_part = lambda r: isinstance(fparts.get(r), dict) and fparts[r].get("keep")    # noqa: E731
            if (head[0] or zone_title.get(b) or kept_part("title")) and not tab.get("enabled", True):  # no tab: the heading is a part of the box
                fparts["title"] = fparts.get("title") or dict(DEFAULT_TITLE_PART)
                slots[f"@slot.{name}.title"] = _sub_box(box, fparts["title"])
                m = {"mode": "text", "source": "", "text": _typed(t, zone_title.get(b) or head[1] or b.upper(), f"@slot.{name}.title", box_texts), "alignment": fparts["title"].get("align", "center"),
                     "vertical_align": "center", "symbol_pinned": True, "inline_icons": True, "font_override": True}
                m.update(_text_style(fparts["title"]))
                if shape_of(styles.get(fparts["title"].get("style") or "")):     # a band behind the heading
                    m["shape"] = shape_of(styles.get(fparts["title"]["style"]))
                maps[f"@slot.{name}.title"] = m
            if cap[0] or kept_part("label"):                   # the caption ("pay any"): a part of the box
                fparts["label"] = fparts.get("label") or dict(DEFAULT_CAPTION_PART)
                slots[f"@slot.{name}.label"] = _sub_box(box, fparts["label"])
                m = {"mode": "text", "source": "", "text": _typed(t, cap[1], f"@slot.{name}.label", box_texts), "alignment": fparts["label"].get("align", "center"),
                     "vertical_align": "center", "symbol_pinned": True, "inline_icons": True,
                     "icon_scales": icon_scales(t, feats.get(b + "_box"))}
                m.update(_text_style(fparts["label"]))
                if shape_of(styles.get(fparts["label"].get("style") or "")):
                    m["shape"] = shape_of(styles.get(fparts["label"]["style"]))
                maps[f"@slot.{name}.label"] = m
            hide = (feats.get(b + "_box") or {}).get("hide") or []
            if b == "wild" and wild_key and not fparts.get("counts"):
                fparts = dict(fparts, **json.loads(json.dumps(WILD_PAY_PARTS)))
                if fparts.get("text"):
                    tx = dict(fparts["text"])
                    tx["w"] = max(0.1, min(float(tx.get("w", 0.7)), 0.7 - float(tx.get("x", 0.28))))
                    fparts["text"] = tx
            if b == "wild":
                if wild_key:                                  # the WILD's own pays, like the SCATTER box
                    for role, suffix in (("counts", "pay"), ("pays", "value")):
                        if fparts.get(role):
                            slots[f"@slot.{wild_key}.{suffix}"] = _sub_box(box, fparts[role])
                            maps[f"@slot.{wild_key}.{suffix}"] = dict(_text_style(fparts[role]), shrink_to_fit=True)
                if wild_token and fparts.get("symbol"):
                    slots["@slot.wild"] = _sub_box(box, fparts["symbol"])
                    maps["@slot.wild"] = {"mode": "icon", "token": wild_token, "source": "", "alignment": "center",
                                          "vertical_align": "center", "symbol_pinned": True}
                if wild_text[0] and fparts.get("text"):
                    slots["@slot.wildbox.text"] = _sub_box(box, fparts["text"])
                    typed = ((feats.get("wild_box") or {}).get("edits") or {}).get(hashlib.sha1(wild_text[1].encode("utf-8")).hexdigest()[:12])
                    m = {"mode": "text", "source": "", "text": strip_tokens(typed if isinstance(typed, str) else wild_text[1], hide),
                         "alignment": "center", "vertical_align": "center", "symbol_pinned": True, "inline_icons": True,
                         "icon_scales": icon_scales(t, feats.get(b + "_box"))}
                    m.update(_text_style(fparts["text"]))
                    maps["@slot.wildbox.text"] = m
                    wild_meta.update(cell=wild_text[0], text=typed if isinstance(typed, str) else wild_text[1], tokens=tokens_in(wild_text[1]),
                                     hidden=list(hide), hash=hashlib.sha1(wild_text[1].encode("utf-8")).hexdigest()[:12])
            else:
                if fparts.get("symbol"):
                    slots[f"@slot.{scatter}"] = _sub_box(box, fparts["symbol"])
                    maps[f"@slot.{scatter}"] = {"mode": "icon", "token": f"<{scatter.upper()}>", "source": "",
                                                "alignment": "center", "vertical_align": "center"}
                for role, suffix in (("counts", "pay"), ("pays", "value")):
                    if fparts.get(role):
                        slots[f"@slot.{scatter}.{suffix}"] = _sub_box(box, fparts[role])
                        maps[f"@slot.{scatter}.{suffix}"] = dict(_text_style(fparts[role]), shrink_to_fit=True)
            feature_parts[b] = fparts                     # what the box holds: the studio's Customise edits these
            r = _rect((box["x"], box["y"] - tab_h / 2.0, box["w"], box["h"] + tab_h / 2.0))
            blocks[b] = r
            obstacles.append(r)
            hard.append(r)

    # ── the scatter section: a framed box, heading above, its cards inside, caption under them ──
    sec_rect = None
    sparts = []
    if section:
        n = len(section["cards"])
        pad = float(sec_def.get("pad", 18))
        title_h = float(sec_def.get("title_h", 56)) if section.get("title") and sec_def.get("show_title", True) else 0.0
        cap_h = float(sec_def.get("caption_h", 44)) if section.get("caption") else 0.0
        ccw, cch = float(sec_def.get("card_w", 290)), float(sec_def.get("card_h", 120))
        fw = n * ccw + (n - 1) * gap_x + 2 * pad
        fh = cch + cap_h + 2 * pad
        rect = sec_def.get("rect")
        moved = (feats.get("scatter_box") or {}).get("rect")
        if isinstance(moved, (list, tuple)) and len(moved) == 4:
            # dragged in the studio (saved like a SCATTER box: its outline less half a tab): the
            # section's frame goes there, under its heading
            top = float(moved[1]) - tab_h / 2.0
            # …at the size it was dragged to (its heading above the frame): each edge on its own
            rect = [float(moved[0]), top + title_h + 4, max(60.0, float(moved[2])), max(60.0, float(moved[3]) + tab_h / 2.0 - title_h - 4)]
        if "scatter" in zone_rect:                       # in a zone: the zone is its frame and heading
            zr = zone_rect["scatter"]
            rect = [zr[0], zr[1] + title_h + 4, zr[2] - zr[0], max(60.0, zr[3] - zr[1] - title_h - 4)]
        if not (isinstance(rect, (list, tuple)) and len(rect) == 4):
            fx = area_x + float(sec_def.get("inset", 0))
            if str(sec_def.get("place") or "left") == "center":
                fx = area_x + (area_w - fw) / 2.0
            rect = [fx, H - bottom_m - fh, fw, fh]
        fx, fy, fw, fh = (float(v) for v in rect)
        frame = _box(fx, fy, fw, fh)
        style = shape_of(styles.get(sec_def.get("style") or "scatter_frame") or styles.get("feature") or styles.get("card"))
        slots["@slot.scatsec"] = frame
        maps["@slot.scatsec"] = {"mode": "none", "kind": "background", "symbol_pinned": True, **({"shape": style} if style else {})}
        if title_h:
            tb = _box(fx, fy - title_h - 4, fw, title_h)
            slots["@slot.scatsec.title"] = tb
            tm = {"mode": "text", "source": "", "text": _typed(t, section["title"][1], "@slot.scatsec.title", box_texts), "alignment": "center",
                  "vertical_align": "bottom", "symbol_pinned": True, "font_override": True}
            tm.update(_text_style(sec_def.get("title") or {"font_size": 40, "color": "#FFC23A"}))
            maps["@slot.scatsec.title"] = tm
        inner_w = fw - 2 * pad
        cw1 = (inner_w - (n - 1) * gap_x) / n
        ch1 = fh - 2 * pad - cap_h
        sparts = (sec_def.get("card") or {}).get("parts") or [
            {"role": "symbol", "x": 0.0, "y": 0.04, "w": 0.46, "h": 0.92},
            {"role": "counts", "x": 0.5, "y": 0.06, "w": 0.12, "h": 0.88, "align": "right", "font_size": 26, "color": "#FFD21F"},
            {"role": "pays", "x": 0.65, "y": 0.06, "w": 0.33, "h": 0.88, "align": "left", "font_size": 26, "color": "#FFD21F"}]
        scard_shape = shape_of(styles.get((sec_def.get("card") or {}).get("style") or ""))
        for i, cd in enumerate(section["cards"]):
            cbox = _box(fx + pad + i * (cw1 + gap_x), fy + pad, cw1, ch1)
            if scard_shape:                               # each SCATTER card its own background
                slots[f"@slot.{cd['key']}.card"] = cbox
                maps[f"@slot.{cd['key']}.card"] = {"mode": "none", "kind": "background", "shape": scard_shape,
                                                   "symbol": cd["key"], "symbol_pinned": True}
            for p in sparts:
                role = p.get("role")
                if role == "symbol":
                    sb = slots[f"@slot.{cd['key']}"] = _sub_box(cbox, p)
                    maps[f"@slot.{cd['key']}"] = {"mode": "icon", "token": cd["token"], "symbol_pinned": True,
                                                  "alignment": "center", "vertical_align": "center",
                                                  "icon_height": max(8, int(sb["h"] * sc))}
                elif role in ("counts", "pays"):
                    key = f"@slot.{cd['key']}.{'pay' if role == 'counts' else 'value'}"
                    slots[key] = dict(_sub_box(cbox, p), vertical_align=p.get("valign", "center"))
                    m = {"mode": "excel", "source": cd["counts"] if role == "counts" else cd["pays"], "symbol_pinned": True,
                         "alignment": p.get("align", "center"), "vertical_align": p.get("valign", "center")}
                    m.update(_text_style(p))
                    maps[key] = m
            blocks[f"scard:{cd['key']}"] = (cbox["x"], cbox["y"], cbox["x"] + cbox["w"], cbox["y"] + cbox["h"])
        if cap_h:
            cb = _box(fx + pad, fy + fh - pad - cap_h, inner_w, cap_h)
            slots["@slot.scatsec.caption"] = cb
            cm = {"mode": "text", "source": "", "text": _typed(t, section["caption"][1], "@slot.scatsec.caption", box_texts), "alignment": "center",
                  "vertical_align": "center", "symbol_pinned": True, "inline_icons": True}
            cm.update(_text_style(sec_def.get("caption") or {"font_size": 24, "color": "#FFFFFF"}))
            maps["@slot.scatsec.caption"] = cm
        sec_rect = (fx, fy - title_h - 4, fx + fw, fy + fh)
        blocks["scatter"] = sec_rect
        obstacles.append(sec_rect)
        hard.append(sec_rect)

    # ── text boxes: the sheet's rules text, edited like a document ──
    # All rules lines start in the first box. What the artist does to the text
    # (line breaks, moving a selection to a new box, merging boxes, retyping) is
    # kept per Excel text (page["text_edits"][hash of that text]) — another
    # market whose Excel says something else gets its own Excel text, never
    # edits made for different words.
    notes = page.get("notes") or {}
    used = {c for c in (wild_text[0] if "wild" in feature_boxes and "wild" not in forced else "",) if c}
    for b in feature_boxes:                       # a box's heading and caption are in the box, not the rules
        used |= {x[0] for x in around[b] if x[0]}
    if section:
        used |= {x[0] for x in (section.get("title"), section.get("caption")) if x}
    sec_notes = {c.upper() for c in (section or {}).get("notes") or []}
    rules = [c for c in (ctx.get("rules_cells") or []) if c and c.upper() not in {u.upper() for u in used}]
    full_text = "\n".join(str(cell_text.get(c, "") or "").strip() for c in rules if str(cell_text.get(c, "") or "").strip())
    text_hash = hashlib.sha1(full_text.encode("utf-8")).hexdigest()[:12]
    texts = [dict(x) for x in (page.get("texts") or []) if isinstance(x, dict)]
    # a box for the scatter notes only exists when the sheet has a scatter section
    texts = [x for x in texts if x.get("fill") != "scatter_notes" or sec_notes]
    notes_box = next((str(x.get("id") or i) for i, x in enumerate(texts) if x.get("fill") == "scatter_notes"), None)
    lines_of = lambda pick: "\n".join(str(cell_text.get(c, "") or "").strip() for c in rules
                                      if str(cell_text.get(c, "") or "").strip() and pick(c.upper() in sec_notes))
    if not texts:
        nh = float(notes.get("h", 150))
        texts = [{"id": "notes", "rect": [content[0], content[3] - nh, content[2] - content[0], nh],
                  **{k: notes[k] for k in ("font_size", "color", "align") if k in notes}}]
    if notes.get("enabled", True) is False:
        texts = []
    # a zone's rules text ("notes") is the design's first text box, whatever its id
    if "text:notes" in zone_rect and texts and not any(str(x.get("id")) == "notes" for x in texts):
        zone_rect[f"text:{texts[0].get('id') or 0}"] = zone_rect["text:notes"]
    edits = (page.get("text_edits") or {}).get(text_hash)
    text_meta = []
    fill_box = None
    # the rules shared over the design's text boxes (a blueprint's): line by line in order, each box a
    # share as big as its area — the artist moves lines between boxes on the Canvas (text_edits)
    shares = {}
    if page.get("split_rules") and not isinstance(edits, dict) and notes_box is None and len(texts) > 1:
        lines = [str(cell_text.get(c, "") or "").strip() for c in rules if str(cell_text.get(c, "") or "").strip()]
        areas = [max(1.0, float((x.get("rect") or [0, 0, 1, 1])[2]) * float((x.get("rect") or [0, 0, 1, 1])[3])) for x in texts]
        at, done = 0, 0.0
        for j, x in enumerate(texts):
            done += areas[j] / sum(areas)
            upto = len(lines) if j == len(texts) - 1 else max(at + (1 if at < len(lines) else 0), int(round(done * len(lines))))
            shares[str(x.get("id") or j)] = "\n".join(lines[at:upto])
            at = upto
    on_top = []
    for i, x in enumerate(texts):
        bid = str(x.get("id") or i)
        if shares:
            box_text = shares.get(bid, "")
        elif isinstance(edits, dict):
            box_text = str(edits.get(bid, "") or "")
        elif notes_box is not None:                 # the scatter notes start in their own box
            box_text = lines_of(lambda n: n) if bid == notes_box else (lines_of(lambda n: not n) if i == 0 else "")
        else:
            box_text = full_text if i == 0 else ""
        rect = x.get("rect")
        in_zone = f"text:{bid}" in zone_rect
        if in_zone:                                       # its zone places it
            zr = zone_rect[f"text:{bid}"]
            rect = [zr[0], zr[1], zr[2] - zr[0], zr[3] - zr[1]]
        if not rect and bid == notes_box and sec_rect:   # beside the scatter box
            rect = [sec_rect[2] + gap_x, sec_rect[1] + 30, max(200.0, area_x + area_w - sec_rect[2] - gap_x), sec_rect[3] - sec_rect[1] - 30]
        if not rect and x.get("place") == "under_title":   # a band right under the title, as wide as the page
            inset = float(x.get("inset", 0))
            rect = [area_x + inset, content_top, area_w - 2 * inset, float(x.get("h", 200))]
        rect = rect or [area_x, H - bottom_m - 150, area_w, 150]
        # a WILD / SCATTER box this sheet doesn't have: a text beside it takes its place as well
        for gb in (x.get("grow_into") or []) if not in_zone else []:
            gr = (feats.get(f"{gb}_box") or {}).get("rect")
            if gb == "scatter" and not gr:            # the scatter section's frame (heading above it)
                gr = (t.get("scatter_section") or {}).get("area")
            if not has.get(gb) and gb not in feature_boxes and isinstance(gr, (list, tuple)) and len(gr) == 4:
                x0, y0 = min(rect[0], gr[0]), min(rect[1], gr[1])
                rect = [x0, y0, max(rect[0] + rect[2], gr[0] + gr[2]) - x0, max(rect[1] + rect[3], gr[1] + gr[3]) - y0]
        # a rules box with no place of its own (or "Fill the free space" on) takes the biggest free space
        # once the cards are placed (below), at the other pages' paragraph size unless it has its own
        if bid != notes_box and not in_zone and x.get("fill_space", not x.get("locked") and not x.get("rect")) and i == 0:   # placed by hand: stays
            fill_box = bid
        if x.get("size_mode", "body" if ((bid == fill_box or in_zone) and not x.get("font_size_set")) else "own") == "body" and ctx.get("body_size"):
            x["font_size"] = float(ctx["body_size"])
        box = _box(*rect)
        slot = "@slot.text" if i == 0 else f"@slot.rules.{bid}"
        # its background, drawn behind it: a panel around the box, or a strip across the page
        bg = x.get("bg") if isinstance(x.get("bg"), dict) else {}
        bshape = shape_of(styles.get(bg.get("style") or "")) if bg.get("on") else None
        # the sheet has rules text but none lands here (its text differs from the design's)
        empty = bool(full_text.strip()) and not box_text.strip()
        if bshape and not empty:              # ...draws no empty panel, and blocks nothing
            pad = float(bg.get("pad", 14))
            if str(bg.get("mode") or "box") == "strip":
                brect = (0.0, box["y"] - pad, float(W), box["h"] + 2 * pad)
            else:
                brect = (box["x"] - pad, box["y"] - pad, box["w"] + 2 * pad, box["h"] + 2 * pad)
            slots[f"@slot.textbg.{bid}"] = _box(*brect)
            maps[f"@slot.textbg.{bid}"] = {"mode": "none", "kind": "background", "shape": bshape, "symbol_pinned": True}
        slots[slot] = box
        # icons the artist left out of this box: dropped with their comma / "and", line by line
        hidden = [str(h) for h in (x.get("hide_icons") or []) if str(h).strip()]
        shown = "\n".join(strip_tokens(ln, hidden) for ln in box_text.split("\n")) if hidden else box_text
        if not x.get("keep_breaks"):
            # one paragraph that wraps to its box: the Excel's line breaks join the line above (a wider box,
            # fewer lines); a blank line still starts a new paragraph ("Keep line breaks" keeps them all)
            shown = flow_lines(shown)
        m = {"mode": "text", "source": "", "text": shown,                      # Excel text: its <icons> draw inline
             "alignment": x.get("align", "center"), "vertical_align": "top", "symbol_pinned": True, "inline_icons": True,
             "icon_scales": icon_scales(t, x)}
        m.update(_text_style(x))
        if x.get("size_mode") != "own" and not x.get("font_size_set"):
            # Auto size: the words fill their box — bigger in a big box, smaller in a small one, re-wrapped
            # when the box is widened (a size of its own, Auto size off, is kept as it is)
            m.update(fit_box=True, shrink_to_fit=True)
        maps[slot] = m
        r = _rect(rect)
        blocks[f"text:{bid}"] = r
        # a box placed on the page (its own rect) is free: it overlaps what it likes and nothing makes way
        # for it — unless it is locked (🔒): then the cards fit beside it
        if not empty and bid != fill_box and (not x.get("rect") or x.get("locked")):   # a box that moves to the free space blocks nothing yet
            obstacles.append(r)
        text_meta.append({"id": bid, "slot": slot, "text": box_text, "tokens": tokens_in(box_text), "hidden": hidden})
        if x.get("rect") and not in_zone:              # placed by hand: drawn over the cards it is stretched over
            on_top += [s for s in (f"@slot.textbg.{bid}", slot) if s in slots]
    text_info = {"hash": text_hash, "full": full_text, "edited": isinstance(edits, dict),
                 "other_edits": bool(page.get("text_edits")) and not isinstance(edits, dict)}

    # WILD / SCATTER boxes the design doesn't have (and the artist hasn't moved yet): now that the
    # text boxes are known, at the bottom where they cover the least text
    _heads = {"wild": ("@slot.wildbox", "@slot.wild", f"@slot.{wild_key}" if wild_key else None),
              "scatter": ("@slot.scatbox", f"@slot.{scatter}" if scatter else None)}
    for b in [b for b in feature_boxes if b in forced and not (feats.get(b + "_box") or {}).get("rect")]:
        old = blocks[b]
        others = [o for o in obstacles if o != old]
        taken = [(o[0], o[1], o[2] - o[0], o[3] - o[1]) for o in others]
        bw0, bh0 = old[2] - old[0], old[3] - old[1]
        nx, ny, _w, _h = _free_spot(taken, bw0, bh0, area_x, area_w, (H - bottom_m - bh0,))
        dx, dy = nx - old[0], ny - old[1]
        if abs(dx) < 0.5 and abs(dy) < 0.5:
            continue
        heads = [h for h in _heads[b] if h]
        for k in [k for k in slots if any(k == h or k.startswith(h + ".") for h in heads)]:
            slots[k] = dict(slots[k], x=int(round(slots[k]["x"] + dx)), y=int(round(slots[k]["y"] + dy)))
        new = (old[0] + dx, old[1] + dy, old[2] + dx, old[3] + dy)
        blocks[b] = new
        obstacles[:] = [new if o == old else o for o in obstacles]
        hard[:] = [new if o == old else o for o in hard]

    # ── jackpot bar (when a zone has kind="jackpot" and the sheet defines jackpot tiers) ──
    if "jackpot" in zone_rect and jackpots:
        jx0, jy0, jx1, jy1 = zone_rect["jackpot"]
        jw, jh = jx1 - jx0, jy1 - jy0
        jn = len(jackpots)
        jgap = max(12.0, gap_x * 0.75)
        bw = (jw - (jn - 1) * jgap) / jn
        for ji, jp in enumerate(jackpots):
            bx = jx0 + ji * (bw + jgap)
            tkey = jp["tier"]
            c_fill, c_stroke, c_title = _JACKPOT_COLORS.get(tkey, ("#1F1138", "#FFD23A", "#FFD23A"))
            b_slot = f"@slot.jackpot.{tkey}.card"
            t_slot = f"@slot.jackpot.{tkey}.title"
            v_slot = f"@slot.jackpot.{tkey}.value"
            cbox = _box(bx, jy0, bw, jh)
            slots[b_slot] = cbox
            maps[b_slot] = {
                "mode": "none", "kind": "background", "symbol_pinned": True,
                "shape": {"radius": "pill", "fill": c_fill, "fill_to": "#0A0514", "fill_opacity": 95,
                          "stroke": {"enabled": True, "width": 4, "color": c_stroke, "align": "inside"}, "fx": ""}
            }
            slots[t_slot] = _box(bx + bw * 0.06, jy0 + jh * 0.08, bw * 0.88, jh * 0.38)
            maps[t_slot] = {"mode": "text", "source": "", "text": jp["label"], "alignment": "center",
                            "vertical_align": "center", "font_size": max(16, int(jh * 0.28)), "bold": True,
                            "color": c_title, "symbol_pinned": True, "shrink_to_fit": True}
            slots[v_slot] = _box(bx + bw * 0.06, jy0 + jh * 0.46, bw * 0.88, jh * 0.46)
            maps[v_slot] = {"mode": "excel", "source": jp["value_cell"], "text": jp["value"], "alignment": "center",
                            "vertical_align": "center", "font_size": max(18, int(jh * 0.34)), "bold": True,
                            "color": "#FFFFFF", "symbol_pinned": True, "shrink_to_fit": True}
        blocks["jackpot"] = (jx0, jy0, jx1, jy1)

    # the zones' rows are the cards' no-go areas (the boxes and text in them already are; the gaps too)
    for zi, z in enumerate(zone_meta):
        if z["rect"]:
            blocks[f"zone:{z['id']}"] = z["rect"]
            obstacles.append(z["rect"])
            hard.append(z["rect"])

    # ── cards: the largest free area left, rows stacked, shrunk to fit ──
    # locked: they keep the area they had when locked, whatever moves around them
    lock = page.get("cards_lock") if isinstance(page.get("cards_lock"), (list, tuple)) and len(page.get("cards_lock")) == 4 else None
    cards_area = _rect(lock) if lock else _carve(content, obstacles, gap)
    ax0, ay0, ax1, ay1 = cards_area
    ox0, oy0, ox1, oy1 = cards_area
    # tiers (a suggested layout asks for them): the card ranks the low row, every other symbol the high
    # row, the Excel's order kept; symbols with the same pays share one card (card.group_same_pays:
    # "low" — the low row only — or "all"). Then the artist's own arrangement (dragged on the Canvas):
    # row_of {name: "high" | "low"} moves a card to the other row, card_order [names] is the cards' order,
    # card.shared [[names]] puts symbols on one card, card.unshared [names] keeps them on their own.
    # A design without any of these is laid out as it always was.
    shared = {}
    _own = (t.get("row_of") or t.get("card_order") or card.get("shared") or card.get("unshared"))
    if ws is not None and (t.get("tiers") == "auto" or card.get("group_same_pays") or _own):
        from . import pay_reader as _pr

        try:
            _read = _pr.read_sheet(ws)
        except Exception:
            _read = None
        if _read:
            if t.get("tiers") == "auto":
                tier = _pr.tiers(_read)
                ordered = high + low
                if ordered and all(_pr.key_of(k) in tier for k in ordered):
                    hi2 = [k for k in ordered if tier[_pr.key_of(k)] != "low"]
                    lo2 = [k for k in ordered if tier[_pr.key_of(k)] == "low"]
                    if hi2 and lo2:
                        high, low = hi2, lo2
            row_of = {str(k).lower(): v for k, v in (t.get("row_of") or {}).items() if v in ("high", "low")}
            for k in list(high):
                if row_of.get(str(k).lower()) == "low":
                    high.remove(k)
                    low.append(k)
            for k in list(low):
                if row_of.get(str(k).lower()) == "high":
                    low.remove(k)
                    high.append(k)
            order = [str(k).lower() for k in (t.get("card_order") or []) if isinstance(t.get("card_order"), list)]
            if order:
                for row in (high, low):
                    excel = {k: i for i, k in enumerate(row)}
                    row.sort(key=lambda k: (order.index(str(k).lower()) if str(k).lower() in order else len(order) + excel[k]))
            sig = {_pr.key_of(x["symbol"]): tuple((p["count"], p["pay"]) for p in x["pays"]) for x in _read["symbols"]}
            same = lambda ms: len({sig.get(_pr.key_of(m)) for m in ms}) == 1 and sig.get(_pr.key_of(ms[0])) is not None  # noqa: E731
            alone = {str(k).lower() for k in (card.get("unshared") or [])}
            groups = []
            mode = card.get("group_same_pays")
            if mode:
                for run in _pr.same_pays(_read):
                    for row in ([low] if mode == "low" else [high, low]):
                        members = [k for k in row if _pr.key_of(k) in run and str(k).lower() not in alone]
                        if len(members) > 1:
                            groups.append((row, members))
            for g in card.get("shared") or []:              # the artist's own: only symbols that pay the same
                for row in (high, low):
                    members = [k for k in row if str(k).lower() in {str(x).lower() for x in g}]
                    if len(members) > 1 and same(members) and not any(set(members) & set(m) for _r, m in groups):
                        groups.append((row, members))
            for row, members in groups:
                shared[members[0]] = members
                for m in members[1:]:
                    if m in row:
                        row.remove(m)
    bands = t.get("bands") or [{"name": "high", "per_row": 5, "card_h": 160}, {"name": "low", "per_row": 5, "card_h": 140}]
    # two rows, each its own box: the top row (above ACE) and the bottom row — and a third tier when the
    # design has bands[2]: the top row's lesser symbols in a middle row (bands[0]["count"] stay on top,
    # else the split is at the biggest drop in pay); row_of {name: "mid"} moves a card there by hand
    mid = []
    if len(bands) >= 3 and isinstance(bands[2], dict) and bands[2].get("enabled", True) is not False and high:
        n_top = max(1, min(int(bands[0].get("count") or 0) or mid_split(high, ws), len(high)))
        high, mid = high[:n_top], high[n_top:]
        row_of3 = {str(k).lower(): v for k, v in (t.get("row_of") or {}).items()}
        for row in (high, low):
            for k in [k for k in row if row_of3.get(str(k).lower()) == "mid"]:
                row.remove(k)
                mid.append(k)
        for k in [k for k in mid if row_of3.get(str(k).lower()) in ("high", "low")]:
            mid.remove(k)
            (high if row_of3[str(k).lower()] == "high" else low).append(k)
    groups = [("high", bands[0], high)] + ([("mid", bands[2], mid)] if mid else []) + [("low", bands[min(1, len(bands) - 1)], low)]
    groups = [g for g in groups if g[2]]
    # a card broken out of its row (card_overrides[name]["free"] = [x, y, w, h], design px): placed there,
    # its content scaled with it, its row laid out without it ("join back" deletes "free")
    free = {str(k).lower(): v["free"] for k, v in (t.get("card_overrides") or {}).items()
            if isinstance(v, dict) and isinstance(v.get("free"), (list, tuple)) and len(v["free"]) == 4}
    all_names = {bid: list(names) for bid, _b, names in groups}
    free_of = {bid: [n for n in names if str(n).lower() in free] for bid, _b, names in groups}
    groups = [(bid, band, [n for n in names if str(n).lower() not in free]) for bid, band, names in groups]
    aw = ax1 - ax0

    # each band's card: its own parts (top and bottom cards are designed apart), and a card is
    # never smaller than what is in it — a bigger symbol or numbers make the card bigger
    pay_rows = max(1, int((structure or {}).get("max_pay_rows") or 3))
    pay_digits = 0
    if ws is not None:                                # the longest number on the sheet (pays like 1500)
        try:
            nums = [v for row in ws.iter_rows(values_only=True) for v in row
                    if isinstance(v, (int, float)) and not isinstance(v, bool)]
            pay_digits = max(1, min(7, max(len(str(int(abs(v)))) for v in nums))) if nums else 0
        except Exception:
            pay_digits = 0
    grow_h = 1.0
    if page.get("auto_grow") and not lock and not page.get("cards_at") and all(not b.get("pos") for _bid, b, _ns in groups):
        avail_h = max(100.0, (ay1 - ay0) - gap * max(0, len([g for g in groups if g[2]]) - 1))
        raw_h = 0.0
        for _bid, _band, _names in groups:
            if not _names:
                continue
            _n = len(all_names[_bid])
            _per = max(1, min(int(_band.get("per_row") or _n), _n))
            _rows = math.ceil(len(_names) / _per)
            raw_h += _rows * float(_band.get("card_h") or 150) + (_rows - 1) * float(_band.get("gap_y", gap_y))
        if raw_h > 0 and avail_h > raw_h * 1.04:
            grow_h = min(float(page.get("max_grow", 1.75)), (avail_h * 0.94) / raw_h)

    geo = {}
    for bid, band, names in groups:
        n = len(all_names[bid])                       # its cards' size as if none were broken out
        per = max(1, min(int(band.get("per_row") or n), n))
        # a locked row (its own box) sizes its cards from that box, never from what is left of the page —
        # moving a SCATTER card or a text box never changes it
        lsz0 = _lock_box(band) if band.get("pos") else None
        natural = ((float(lsz0[0]) if lsz0 else aw) - (per - 1) * float(band.get("gap_x", gap_x))) / per
        cw0 = float(band["card_w"]) * (grow_h if page.get("auto_grow_w") else 1.0) if band.get("card_w") else natural
        ch0 = float(band.get("card_h") or 150) * grow_h
        raw_parts = copy.deepcopy(band.get("parts") or card.get("parts") or [])
        if band.get("auto_aspect") or card.get("auto_aspect"):
            _asp = band.get("symbol_aspect") or _band_icon_aspect(names, ctx.get("icon_folder"), ctx.get("icon_mappings"))
            if _asp is not None:
                raw_parts = adapt_aspect_parts(raw_parts, _asp)
        if grow_h > 1.02:
            font_scale = min(1.35, grow_h ** 0.65)
            for rp in raw_parts:
                if isinstance(rp, dict) and rp.get("font_size"):
                    rp["font_size"] = round(float(rp["font_size"]) * font_scale, 1)
        bparts, cwb, chh = fit_card(raw_parts, cw0, ch0, pay_rows, pay_digits=pay_digits)
        geo[bid] = (per, cwb, chh, bparts)

    need_h, need_w = 0.0, 0.0
    for bid, band, names in groups:
        per, cwid, chh, _p = geo[bid]
        if not names:
            continue
        rows = math.ceil(len(names) / per)
        need_h += rows * chh + (rows - 1) * float(band.get("gap_y", gap_y))
        need_w = max(need_w, per * cwid + (per - 1) * float(band.get("gap_x", gap_x)))
    need_h += gap * max(0, len(groups) - 1)
    # bigger cards than their box: the box grows (centred, then within the page), only then do they shrink.
    # A locked box never grows: everything in it scales down to stay inside.
    at = page.get("cards_at") if isinstance(page.get("cards_at"), (list, tuple)) and len(page.get("cards_at")) == 2 else None
    if lock:
        pass
    elif at:
        # unlocked where it was locked: the box starts at that corner and grows right / down (kept on the page)
        ax0, ay0 = float(at[0]), float(at[1])
        ax1 = min(content[2], ax0 + need_w)
        ax0 = max(content[0], min(ax0, ax1 - need_w))
        ay1 = min(content[3], ay0 + need_h)
        ay0 = max(content[1], min(ay0, ay1 - need_h))
        aw = ax1 - ax0
    elif need_w > aw:
        cx = (ax0 + ax1) / 2.0
        ax0 = max(content[0], min(content[2] - need_w, cx - need_w / 2.0)) if need_w <= content[2] - content[0] else content[0]
        ax1 = min(content[2], ax0 + need_w)
        aw = ax1 - ax0
    if need_h > ay1 - ay0 and not lock and not at:
        ay1 = min(content[3], ay0 + need_h)
        ay0 = max(content[1], min(ay0, ay1 - need_h))
    # what the cards stop at: WILD / SCATTER boxes, the scatter section, and a text box that can't
    # step aside for them (locked, or no room left on the page) — cards never run under rules text
    _locked_txt = {str(x.get("id") or i) for i, x in enumerate(texts) if x.get("locked") or f"text:{x.get('id') or i}" in zone_rect}   # a zone's text stays in it
    _placed_txt = {str(x.get("id") or i) for i, x in enumerate(texts) if x.get("rect") and not x.get("locked") and f"text:{x.get('id') or i}" not in zone_rect}
    _texts_r = [(blocks[f"text:{tm['id']}"], tm["id"] in _locked_txt) for tm in text_meta
                if f"text:{tm['id']}" in blocks and blocks[f"text:{tm['id']}"] in obstacles and tm["id"] not in _placed_txt]

    def _walls(box):
        return list(hard) + [r for r, locked in _texts_r
                             if locked or _step_aside(r, box, keep, gap) is None]

    if not lock:
        # grown into one of them: stop at it (the cards shrink instead)
        for hx0, hy0, hx1, hy1 in _walls((ax0, ay0, ax1, ay1)):
            if hx1 <= ax0 or hx0 >= ax1 or hy1 <= ay0 or hy0 >= ay1:
                continue
            if hy0 >= oy1 - 1:
                ay1 = min(ay1, hy0 - gap)
            elif hy1 <= oy0 + 1:
                ay0 = max(ay0, hy1 + gap)
            elif hx0 >= ox1 - 1:
                ax1 = min(ax1, hx0 - gap)
            elif hx1 <= ox0 + 1:
                ax0 = max(ax0, hx1 + gap)
        ay1, ax1 = max(ay0 + 1, ay1), max(ax0 + 1, ax1)
        aw = ax1 - ax0
    cards_area = (ax0, ay0, ax1, ay1)

    # each row (top / bottom) is its own box: a row the artist placed sits where they put it (pos),
    # a locked row keeps its size too (its cards scale inside); the others stack in the cards area.
    # Every row fits on its own — a wide bottom row never shrinks the top row's cards.
    def _pos(band):
        p = band.get("pos")
        return (float(p[0]), float(p[1])) if isinstance(p, (list, tuple)) and len(p) == 2 else None

    def _gaps(band):                              # a row's own card spacing (else the page's)
        return float(band.get("gap_x", gap_x)), float(band.get("gap_y", gap_y))

    def _size(bid):
        per, cwid, chh, _p = geo[bid]
        band, names = next((g[1], g[2]) for g in groups if g[0] == bid)
        gx, gy = _gaps(band)
        if not names:                                 # every card broken out: the row takes no room
            return 0.0, 0.0
        rows = math.ceil(len(names) / per)
        return per * cwid + (per - 1) * gx, rows * chh + (rows - 1) * gy

    # every row keeps its slot in the stack, placed (locked / moved) or not: locking or moving one row
    # never shifts the rows still laid out automatically (they'd slide into its slot)
    stacked = [g for g in groups if g[2]]
    st_h = sum(_size(g[0])[1] for g in stacked) + gap * max(0, len(stacked) - 1)
    fit_v = min(1.0, (ay1 - ay0) / st_h) if st_h else 1.0
    y = ay0
    if str(page.get("valign") or "top") == "center":
        y += max(0.0, (ay1 - ay0) - st_h * fit_v) / 2.0
    band_fit = {}
    shrink = str(card.get("overflow") or "") == "shrink"
    sizes = card.get("symbol_size") if isinstance(card.get("symbol_size"), dict) else {}
    card_slots = []                                   # moved together when the grid is dragged
    # one card edited on its own (double-click in the studio): its own parts, same card size and place
    overrides = {str(k).lower(): v for k, v in (t.get("card_overrides") or {}).items()
                 if isinstance(v, dict) and isinstance(v.get("parts"), list)}
    band_slots = {}
    # one card's own settings (the Canvas Card bar): its size in its row, its dividers
    own_card = {str(k).lower(): v for k, v in (t.get("card_overrides") or {}).items() if isinstance(v, dict)}
    for bid, band, names in groups:
        per, cwid, chh, parts = geo[bid]
        bw, bh = _size(bid)
        pos = _pos(band)
        if pos:
            lsz = _lock_box(band)
            if lsz:                                   # locked: the box keeps its size, the cards scale inside
                f = min(1.0, float(lsz[0]) / bw if bw else 1.0, float(lsz[1]) / bh if bh else 1.0)
                bx, by, bwa = pos[0], pos[1], float(lsz[0])
            else:                                     # moved: exactly where it was dropped — over anything (only
                f = min(1.0, (keep[2] - keep[0]) / bw if bw else 1.0, (keep[3] - keep[1]) / bh if bh else 1.0)    # kept on the canvas)
                bwa = bw * f
                bx = max(keep[0], min(pos[0], keep[2] - bwa))
                by = max(keep[1], min(pos[1], keep[3] - bh * f))
                band_at[bid] = [round(bx, 1), round(by, 1)]
            row_x, row_w, row_y = bx, bwa, by
        else:
            f = min(fit_v, aw / bw if bw else 1.0)
            row_x, row_w, row_y = ax0, aw, y
        band_fit[bid] = f
        # page.fill_rows: rows short of height get lower cards that keep the row's whole width (their words
        # scale with the height) — never the whole card shrunk, leaving the page's sides empty
        fw = min(1.0, aw / bw if bw else 1.0) if (not pos and page.get("fill_rows")) else f
        b2 = dict(band, per_row=per, card_w=cwid * fw, card_h=chh * f)
        gx, gy = _gaps(band)
        own_size = {k: v.get("size") for k, v in own_card.items() if v.get("size")}
        placed, y_end = _layout_band(names, b2, row_x, row_w, row_y, gx * fw, gy * f, align, own_size)
        if pos and placed and not _lock_box(band):    # a row with a box of its own: centred in it
            # a row moved by hand starts where it was dropped (its cards are often narrower than the box it
            # was laid out in, and centred there they'd seem to snap back) — kept on the page
            x0 = min(c["x"] for _n, c in placed)
            x1 = max(c["x"] + c["w"] for _n, c in placed)
            shift = max(keep[0], min(pos[0], keep[2] - (x1 - x0))) - x0
            band_at[bid][0] = round(x0 + shift, 1)
            if abs(shift) >= 0.5:
                placed = [(n_, dict(c, x=int(round(c["x"] + shift)))) for n_, c in placed]
        card_f = {}
        for fname in free_of.get(bid, []):            # broken out: where the artist put it, at its size
            fr = [float(v) for v in free[str(fname).lower()]]
            placed.append((fname, _box(fr[0], fr[1], max(20.0, fr[2]), max(20.0, fr[3]))))
            # its fonts follow its own width against the width it had when it left the row ("free_base") —
            # never the row's card width now (a row made bigger later doesn't grow a card that left it)
            base_w = float((own_card.get(str(fname).lower()) or {}).get("free_base") or cwid)
            card_f[fname] = max(0.1, fr[2] / max(1.0, base_w))
        before = set(slots)
        style = shape_of(styles.get(band.get("style") or "card"))
        prefix = "bottomcardsbg" if bid == "low" else "topcardsbg"
        # a symbol tile: a framed square behind each symbol of the row (bands[i]["tile"])
        tile = band.get("tile") if isinstance(band.get("tile"), dict) and band["tile"].get("enabled") else None
        tile_shape = shape_of(styles.get((tile or {}).get("style") or "tile") or DEFAULT_TILE_STYLE) if tile else None
        # a caption on a card ("OF A KIND"): card.kind_caption for every shared card (on: "shared", the
        # default) or every card (on: "all"); a card's own (card_overrides[name].caption) adds it to that
        # card or hides it there ("enabled": False), and its text / look win over every card's
        g_cap = card.get("kind_caption") if isinstance(card.get("kind_caption"), dict) else {}

        def caption_of(name):
            own_c = (own_card.get(str(name).lower()) or {}).get("caption")
            own_c = own_c if isinstance(own_c, dict) else {}
            if "enabled" in own_c:
                show = bool(own_c["enabled"])
            else:
                show = bool(g_cap.get("enabled")) and (g_cap.get("on") == "all" or len(shared.get(name) or [name]) > 1)
            if not show:
                return None
            out = dict(DEFAULT_KIND_CAPTION)
            out.update({k: v for k, v in g_cap.items() if k not in ("enabled", "on")})
            out.update({k: v for k, v in own_c.items() if k != "enabled" and v not in (None, "")})
            return out

        for name, cbox in placed:
            fc = card_f.get(name, f)                    # a broken-out card's fonts follow its own size
            kind_cap = caption_of(name)
            own = own_card.get(str(name).lower()) or {}
            cstyle = shape_of(styles.get(own["style"])) if own.get("style") and styles.get(own["style"]) else style   # its own look
            if cstyle:
                bg = f"@slot.{name}.card"
                slots[bg] = cbox
                card_slots.append(bg)
                maps[bg] = {"mode": "none", "kind": "background", "shape": cstyle, "card_band": prefix,
                            "symbol": name}                # lives and dies with its card
            # dividers: a line between the symbol and the counts, one between the counts and the pays
            dv = dict(card.get("dividers") or {})
            dv.update((own_card.get(str(name).lower()) or {}).get("dividers") or {})
            if dv.get("enabled"):
                ps = {p.get("role"): _sub_box(cbox, p) for p in (overrides.get(str(name).lower()) or {}).get("parts") or parts}
                lw = max(1.0, float(dv.get("width", 2)))
                lines = []                              # (key, x, y, w, h): a line between two parts side by side
                                                        # (upright), or one above the other (across)

                al_of = {p.get("role"): p.get("align", "center") for p in (overrides.get(str(name).lower()) or {}).get("parts") or parts}

                def text_mid(role, b):                  # where a number column's digits sit (its alignment)
                    est = min(b["w"], 0.22 * cbox["w"])
                    al = al_of.get(role) or "center"
                    return b["x"] + est / 2.0 if al == "left" else b["x"] + b["w"] - est / 2.0 if al == "right" else b["x"] + b["w"] / 2.0

                own_line = dv.get("lines") if isinstance(dv.get("lines"), dict) else {}

                def line_of(key):                       # a line's own length (share of the card) and shift
                    o = own_line.get(key) if isinstance(own_line.get(key), dict) else {}
                    return (float(o["len"]) if o.get("len") else None), float(o.get("off", 0) or 0)

                def upright(key, lx):
                    ln, off = line_of(key)
                    L = max(4.0, (ln if ln else 1.0 - 2 * float(dv.get("inset", 0.1))) * cbox["h"])
                    lines.append((key, lx + off * cbox["w"] - lw / 2.0, cbox["y"] + (cbox["h"] - L) / 2.0, lw, L))

                def across(key, ly):
                    ln, off = line_of(key)
                    ly = max(cbox["y"] + lw, min(cbox["y"] + cbox["h"] - lw, ly)) + off * cbox["h"]
                    L = max(4.0, (ln if ln else 1.0 - 2 * float(dv.get("inset", 0.1))) * cbox["w"])
                    lines.append((key, cbox["x"] + (cbox["w"] - L) / 2.0, ly - lw / 2.0, L, lw))

                def between(key, a, b):
                    if a["x"] + a["w"] <= b["x"] + 2:
                        upright(key, (a["x"] + a["w"] + b["x"]) / 2.0)
                    elif a["y"] + a["h"] <= b["y"] + 2:
                        across(key, (a["y"] + a["h"] + b["y"]) / 2.0)
                    elif key == "div1" and (a["y"] + a["h"] / 2.0) < (b["y"] + b["h"] / 2.0) - 0.12 * cbox["h"]:
                        across(key, a["y"] + a["h"] + 0.02 * cbox["h"])        # the symbol above the numbers
                    elif key == "div2":                                     # the columns' boxes overlap: between their digits
                        upright(key, (text_mid("counts", a) + text_mid("pays", b)) / 2.0)
                    else:
                        upright(key, (a["x"] + a["w"] + text_mid("counts", b) - min(b["w"], 0.22 * cbox["w"]) / 2.0) / 2.0)

                if dv.get("symbol", True) and "symbol" in ps and "counts" in ps:
                    between("div1", ps["symbol"], ps["counts"])
                if dv.get("numbers", True) and "counts" in ps and "pays" in ps:
                    between("div2", ps["counts"], ps["pays"])
                for key, lx, ly, lwd, lh in lines:
                    slot = f"@slot.{name}.{key}"
                    slots[slot] = _box(lx, ly, lwd, lh)
                    maps[slot] = {"mode": "none", "kind": "background", "symbol": name, "symbol_pinned": True,
                                  "shape": {"radius": 0, "fill": dv.get("color") or "#ffffff", "fill_opacity": float(dv.get("opacity", 100)),
                                            "stroke": {}, "fx": ""}}
                    card_slots.append(slot)
            for p in (overrides.get(str(name).lower()) or {}).get("parts") or parts:
                role = p.get("role")
                if role == "symbol":
                    members = shared.get(name) or [name]       # a shared card: its symbols side by side
                    part_box = _sub_box(cbox, p)
                    if kind_cap and float(kind_cap.get("y", 0.8)) >= 0.5:
                        # the caption under the symbols: they stay above it
                        cap_y = cbox["y"] + float(kind_cap.get("y", 0.8)) * cbox["h"]
                        part_box = dict(part_box, h=max(8, min(part_box["h"], int(cap_y - part_box["y"]))))
                    pad = float((tile or {}).get("pad", 0.08))
                    for mi, mem in enumerate(members):
                        mbox = part_box if len(members) == 1 else dict(part_box, x=int(part_box["x"] + part_box["w"] * mi / len(members)),
                                                                         w=max(1, int(part_box["w"] / len(members))))
                        if tile_shape:                       # the tile first (drawn under the symbol), the symbol inside it
                            tk = f"@slot.{mem}.tile" if len(members) > 1 else f"@slot.{name}.tile"
                            slots[tk] = mbox
                            maps[tk] = {"mode": "none", "kind": "background", "shape": tile_shape, "symbol": name, "symbol_pinned": True}
                            mbox = _scaled(mbox, max(0.2, 1.0 - 2 * pad))
                        # its height in px (canvas px, as drawn) when it has one, else its % of the card's design
                        own_px = symbol_px(card.get("symbol_px") if isinstance(card.get("symbol_px"), dict) else None, name)
                        if own_px and mbox["h"] > 0:
                            sbox = _scaled(mbox, max(0.05, min(8.0, (own_px / max(1e-6, sc)) / mbox["h"])))
                        else:
                            sbox = _scaled(mbox, symbol_scale(sizes, name))
                        slots[f"@slot.{mem}"] = sbox
                        # the icon fills its box (the auto-mapper's fixed icon height would cap a bigger symbol)
                        # the card names its symbol: never re-guessed from which numbers sit nearest
                        # (a big symbol reaching the next card's pays would show that card's symbol, or vanish)
                        maps[f"@slot.{mem}"] = {"alignment": p.get("align", "center"), "vertical_align": "center",
                                                "icon_height": max(8, int(sbox["h"] * sc)), "symbol_pinned": True,
                                                "icon_aliases": royal_aliases(mem)}
                elif role in ("counts", "pays"):
                    key = f"@slot.{name}.{'pay' if role == 'counts' else 'value'}"
                    slots[key] = dict(_sub_box(cbox, p), vertical_align=p.get("valign", "center"))
                    maps[key] = _fitted(_text_style(p), fc)
                    if shrink:
                        maps[key]["shrink_to_fit"] = True
                elif role == "text":
                    key = f"@slot.{name}.{p.get('id') or 'text'}"
                    slots[key] = _sub_box(cbox, p)
                    m = {"mode": "text" if p.get("text") else "excel", "source": p.get("source") or "",
                         "text": p.get("text") or "", "alignment": p.get("align", "center"),
                         "vertical_align": p.get("valign", "center"), "inline_icons": True,
                         "icon_scales": icon_scales(t, None)}
                    m.update(_fitted(_text_style(p), fc))
                    maps[key] = m
            if kind_cap:                                  # its caption ("of a kind" on a shared card)
                kk = f"@slot.{name}.kind"
                slots[kk] = _sub_box(cbox, kind_cap)
                m = {"mode": "text", "source": "", "text": str(kind_cap.get("text") or "OF A KIND"), "symbol": name,
                     "symbol_pinned": True, "alignment": kind_cap.get("align", "center"), "vertical_align": "center",
                     "font_override": True, "shrink_to_fit": True}
                m.update(_fitted(_text_style(kind_cap), fc))
                maps[kk] = m
            card_slots.extend(k for k in slots if k == f"@slot.{name}" or k.startswith(f"@slot.{name}."))
            blocks[f"card:{name}"] = (cbox["x"], cbox["y"], cbox["x"] + cbox["w"], cbox["y"] + cbox["h"])
        xs = [c["x"] for _n, c in placed if _n not in card_f] + [c["x"] + c["w"] for _n, c in placed if _n not in card_f]
        if xs:
            blocks[bid] = (min(xs), row_y, max(xs), y_end)
        band_slots[bid] = ([k for k in slots if k not in before], [f"card:{n}" for n, _c in placed])
        if names:                                     # the next row starts under this one's slot in the stack
            y = (y_end if not pos else y + bh * min(fit_v, aw / bw if bw else 1.0)) + gap * fit_v
    fit = min(band_fit.values()) if band_fit else 1.0
    for key, cd in joined_src.items():               # a SCATTER / coin card joined to a row: its own cells
        if f"@slot.{key}" in maps:
            maps[f"@slot.{key}"].update(mode="icon", token=cd["token"])
        for suffix, src in (("pay", cd["counts"]), ("value", cd["pays"])):
            if f"@slot.{key}.{suffix}" in maps:
                maps[f"@slot.{key}.{suffix}"].update(mode="excel", source=src, symbol=key)
    # ── moved by hand (older designs): the stacked rows shift together, kept on the page ──
    off = page.get("cards_offset")
    moving = [bid for bid, band, _n in groups if not _pos(band) and bid in blocks]
    if isinstance(off, (list, tuple)) and len(off) == 2 and moving:
        gx0, gy0 = min(blocks[b][0] for b in moving), min(blocks[b][1] for b in moving)
        gx1, gy1 = max(blocks[b][2] for b in moving), max(blocks[b][3] for b in moving)
        dx = max(keep[0] - gx0, min(keep[2] - gx1, float(off[0] or 0)))
        dy = max(keep[1] - gy0, min(keep[3] - gy1, float(off[1] or 0)))
        band_at["cards_offset"] = [round(dx, 1), round(dy, 1)]
        for bid in moving:
            keys_b, cards_b = band_slots.get(bid, ([], []))
            for k in keys_b:
                slots[k] = dict(slots[k], x=int(round(slots[k]["x"] + dx)), y=int(round(slots[k]["y"] + dy)))
            for k in cards_b + [bid]:
                b = blocks[k]
                blocks[k] = (b[0] + dx, b[1] + dy, b[2] + dx, b[3] + dy)
    if any(b in blocks for b in ("high", "mid", "low")):
        bb = [blocks[b] for b in ("high", "mid", "low") if b in blocks]
        blocks["cards"] = (min(b[0] for b in bb), min(b[1] for b in bb), max(b[2] for b in bb), max(b[3] for b in bb))
        # a panel behind all the cards (page["cards_panel"]): drawn first, under everything
        panel = page.get("cards_panel") if isinstance(page.get("cards_panel"), dict) and page["cards_panel"].get("enabled") else None
        pshape = shape_of(styles.get(panel.get("style") or "panel") or DEFAULT_PANEL_STYLE) if panel else None
        if pshape:
            c0 = blocks["cards"]
            ppad = float(panel.get("pad", 24))
            pr = (max(keep[0], c0[0] - ppad), max(keep[1], c0[1] - ppad), min(keep[2], c0[2] + ppad), min(keep[3], c0[3] + ppad))
            slots = {"@slot.cardspanel": _box(pr[0], pr[1], pr[2] - pr[0], pr[3] - pr[1]), **slots}
            maps["@slot.cardspanel"] = {"mode": "none", "kind": "background", "shape": pshape, "symbol_pinned": True}
            blocks["cardspanel"] = pr
    # ── text boxes the cards were moved onto step aside (locked ones stay) ──
    if "cards" in blocks:
        locked_ids = {str(x.get("id") or i) for i, x in enumerate(texts) if x.get("locked") or f"text:{x.get('id') or i}" in zone_rect}
        for tm in text_meta:
            key = f"text:{tm['id']}"
            if tm["id"] in locked_ids or tm["id"] in _placed_txt or key not in blocks:   # placed by hand: stays put
                continue
            moved = _step_aside(blocks[key], blocks["cards"], keep, gap)
            if moved:
                dx, dy = moved[0] - blocks[key][0], moved[1] - blocks[key][1]
                blocks[key] = moved
                slots[tm["slot"]] = _box(moved[0], moved[1], moved[2] - moved[0], moved[3] - moved[1])
                bgk = f"@slot.textbg.{tm['id']}"
                if bgk in slots:                          # its background goes with it
                    strip = slots[bgk]["x"] == 0 and slots[bgk]["w"] >= W
                    slots[bgk] = dict(slots[bgk], x=slots[bgk]["x"] + (0 if strip else int(round(dx))), y=slots[bgk]["y"] + int(round(dy)))
    blocks["cards_area"] = cards_area
    if fill_box is not None and f"text:{fill_box}" in blocks:
        _fill_free_band(fill_box, blocks, slots, text_meta, area_x, area_w, content_top, H - bottom_m, gap, W)

    # text never leaves its box: longer Excel text shrinks (with its inline symbols) to fit,
    # so it can't spill onto the cards beneath it
    for m in maps.values():
        if m.get("inline_icons"):
            m["shrink_to_fit"] = True

    # WILD / SCATTER boxes the design doesn't have are drawn last: where they land on another box
    # they stay readable until the artist moves them
    if forced:
        heads = [h for b in forced for h in _heads[b] if h]
        late = [k for k in slots if any(k == h or k.startswith(h + ".") for h in heads)]
        slots = {**{k: v for k, v in slots.items() if k not in late}, **{k: slots[k] for k in late}}

    if on_top:
        slots = {**{k: v for k, v in slots.items() if k not in on_top}, **{k: slots[k] for k in on_top if k in slots}}
    slots = _split_fx_shapes(slots, maps)
    doc = {
        "template_id": "Paytable_cards_" + str(t.get("id") or "custom"),
        "page_type": "paytable",
        "source_psd": "",
        "canvas": {"width": W, "height": H},
        "slots": slots,
        "slot_prefix": "@slot",
        "mapper_meta": {"generated_by": "web_paytable_mapper", "layout": "cards", "card_template": t.get("id") or "",
                        "auto_generated": True, "top_count": len(high), "lower_count": len(low),
                        "blocks": {k: [round(v, 1) for v in b] for k, b in blocks.items()},
                        "texts": text_meta, "text_info": text_info, "wild_text": wild_meta, "fit": round(fit, 3),
                        # each band's card as laid out (design px before fit) and its parts as fractions of it
                        "band_geo": {bid: {"size": [round(g[1], 1), round(g[2], 1)], "fit": round(band_fit.get(bid, 1.0), 4),
                                           "parts": [{k: (round(v, 4) if isinstance(v, float) else v) for k, v in pp.items()} for pp in g[3]]}
                                     for bid, g in geo.items()},
                        "card_geo": {k: v["parts"] for k, v in overrides.items()},
                        # cards broken out of their rows: which row each belongs to (it joins back there)
                        "free_cards": {n: bid for bid, ns in free_of.items() for n in ns},
                        "auto_free": list(auto_free),
                        # the lone SCATTER's symbol (its box joins a row as this card) and the cards that joined one
                        "scatter_key": scatter or "",
                        "joined": {k: _joined(k) for k in high + low if _joined(k)},
                        # a design from the old fixed frame: where its moved rows were kept (settle_frame)
                        **({"band_at": band_at} if old_frame else {}),
                        # WILD / SCATTER: the parts each box holds, which boxes were added because the
                        # sheet has them (the design had none), and which the sheet needs (can't be removed)
                        "feature_parts": feature_parts, "auto_boxes": sorted(forced),
                        "scatter_card_parts": sparts if section else [],
                        "box_texts": box_texts,
                        # the zones' rows: where each sits, and which items show (and why not)
                        "zones": [dict(z, rect=[round(v, 1) for v in z["rect"]] if z["rect"] else None) for z in zone_meta],
                        "boxed_symbols": [k for b, k in (("scatter", scatter), ("wild", wild_key)) if k and b in feature_boxes],
                        "required_boxes": [b for b in ("wild", "scatter") if (b == "scatter" and scatter)
                                           or (b == "wild" and wild_key and not wild_as_card)]},
        "mappings": {},
    }
    return doc, maps


# content keys the auto-mapper decides (where the data comes from) vs. look keys the template decides
_CONTENT_KEYS = {"mode", "source", "text", "token", "role", "symbol", "kind"}


def merge_mappings(auto_list, style_maps, excel_path=""):
    """Auto-mapper output (list) + the template's style mappings -> mappings list.

    The template's look always wins; its content wins only for slots the
    auto-mapper couldn't fill (feature texts, tabs, typed text slots)."""
    by_slot = {}
    for m in auto_list or []:
        if isinstance(m, dict) and m.get("slot"):
            by_slot[m["slot"]] = dict(m)
    for slot, style in (style_maps or {}).items():
        cur = by_slot.get(slot)
        # the template names its own content (feature texts, tabs, the wild token, typed text):
        # it always wins over the auto-mapper's guess for that slot
        own_content = any(k in style for k in ("mode", "source", "text", "token"))
        if cur is None or own_content or style.get("kind") == "background":
            merged = dict(cur or {})
            merged.update(style)
        else:
            merged = dict(cur)
            merged.update({k: v for k, v in style.items() if k not in _CONTENT_KEYS})
        if own_content or slot == "@slot.text":
            # the template chose this content: the live-sheet re-binding must leave it alone
            merged["source_pinned"] = True
            merged["userTouched"] = True
            if excel_path:
                merged["pinned_excel"] = excel_path          # pins hold for the workbook they were made on
        if merged.get("symbol_pinned") and excel_path:
            merged["pinned_excel"] = excel_path
        drop = {str(c).upper() for c in merged.pop("exclude_sources", None) or []}
        if drop and isinstance(merged.get("source"), str):
            kept = [c for c in merged["source"].split(",") if c.strip().upper() not in drop]
            if len(kept) != len(merged["source"].split(",")):
                merged["source"] = ",".join(kept)
                merged.pop("text", None)                   # re-read from the remaining cells
        merged["slot"] = slot
        merged.setdefault("padding", [0, 0, 0, 0])
        by_slot[slot] = merged
    return list(by_slot.values())


# ── numbers that don't fit their card ───────────────────────────────────────
_DATA_SLOT = re.compile(r"^@slot\.(.+)\.(pay|value)$")


def measure_overflow(doc, mappings, font_name="ArialMT", scale=1.0):
    """[{card, part, need_w, need_h, have_w, have_h, ratio}] for counts/pays that overflow their box.

    Boxes are design px (x scale = canvas px); font sizes are canvas px, as the renderers use them."""
    from PIL import ImageFont

    from ... import png_builder

    out = []
    slots = (doc or {}).get("slots") or {}
    boxed = set(((doc or {}).get("mapper_meta") or {}).get("boxed_symbols") or [])
    fonts = {}
    for m in mappings or []:
        slot = str((m or {}).get("slot") or "")
        hit = _DATA_SLOT.match(slot)
        if not hit or slot not in slots or hit.group(1) in boxed:
            continue                       # cards only: a WILD / SCATTER box's numbers shrink to fit it
        lines = [l for l in str(m.get("text") or "").split("\n") if l.strip()]
        if not lines:
            continue
        size = int(float(m.get("font_size") or 30))
        key = (m.get("font_name") or font_name, size)
        if key not in fonts:
            try:
                fonts[key] = png_builder._load_font(ImageFont, key[0], size)
            except Exception:
                fonts[key] = None
        font = fonts[key]
        if font is None:
            continue
        need_w = max(font.getlength(l) for l in lines)
        need_h = len(lines) * size * 1.15
        box = slots[slot]
        have_w, have_h = float(box["w"]) * scale, float(box["h"]) * scale
        ratio = max(need_w / max(1.0, have_w), need_h / max(1.0, have_h))
        if ratio > 1.02:
            out.append({"card": hit.group(1), "part": "counts" if hit.group(2) == "pay" else "pays", "slot": slot,
                        "need_w": round(need_w), "need_h": round(need_h), "have_w": round(have_w),
                        "have_h": round(have_h), "ratio": round(ratio, 2)})
    return out


def grown(template, overflow, cap=2.5):
    """A copy of the template whose cards are big enough for the numbers in `overflow`."""
    t = copy.deepcopy(template)
    r = min(cap, max([o["ratio"] for o in overflow] or [1.0]))
    for band in t.get("bands") or []:
        band["card_h"] = round(float(band.get("card_h") or 150) * r)
        if band.get("card_w"):
            band["card_w"] = round(float(band["card_w"]) * r)
    return t


def shrink_slots(mappings, overflow):
    """Let the renderer shrink the numbers of the overflowing cards to fit their boxes."""
    slots = {o["slot"] for o in overflow}
    for m in mappings or []:
        if isinstance(m, dict) and m.get("slot") in slots:
            m["shrink_to_fit"] = True



def split_paytable_pages(template, structure, ws=None, ctx=None, min_fit=0.75, max_single_cards=11):
    """Compile a paytable template and automatically split it into 2 balanced pages when crowded.

    Triggers when the single-page compile has ``fit < min_fit`` or total symbol cards > ``max_single_cards``:
      * Page 1: Title + High-paying premium symbols (at full size) + Special feature boxes (Wild/Scatter)
      * Page 2: Title + Low-paying royal symbols (at full size) + Rules & Notes text box
    Returns a list of ``{"page": 1|2, "suffix": ""|"_cont", "template": doc, "style_maps": maps, "fit": float}``.
    """
    ctx = dict(ctx or {})
    doc1, maps1 = compile_template(template, structure, ws, ctx)
    fit1 = float((doc1.get("mapper_meta") or {}).get("fit") or 1.0)
    keys, _scat = _clean_keys((structure or {}).get("block_keys") or [])
    top_n = int((doc1.get("mapper_meta") or {}).get("top_count") or 0)
    low_n = int((doc1.get("mapper_meta") or {}).get("lower_count") or 0)
    if (top_n + low_n <= max_single_cards and fit1 >= min_fit) or top_n == 0 or low_n == 0:
        return [{"page": 1, "suffix": "", "template": doc1, "style_maps": maps1, "fit": fit1}]

    high_keys = keys[:top_n]
    low_keys = [k for k in keys[top_n:] if "wild" not in k.casefold()]
    if _scat:
        high_keys = high_keys + [_scat]

    # Page 1: High symbols + any special boxes, no general rules text strip
    t_p1 = copy.deepcopy(template)
    t_p1.setdefault("page", {}).setdefault("notes", {})["enabled"] = False
    if isinstance(t_p1["page"].get("texts"), list):
        t_p1["page"]["texts"] = []
    if isinstance(t_p1.get("zones"), list):
        for z in t_p1["zones"]:
            if isinstance(z, dict) and isinstance(z.get("items"), list):
                z["items"] = [it for it in z["items"] if isinstance(it, dict) and it.get("kind") != "text"]
    st_p1 = dict(structure or {}, top=len(high_keys), lower=0, block_keys=high_keys)
    p1_doc, p1_maps = compile_template(t_p1, st_p1, ws, dict(ctx, rules_cells=[]))

    # Page 2: Low symbols + rules text box, no Wild/Scatter boxes
    t_p2 = copy.deepcopy(template)
    t_p2["features"] = {"enabled": False, "wild": False, "scatter": False}
    t_p2["scatter_section"] = {"enabled": False}
    if isinstance(t_p2.get("zones"), list):
        for z in t_p2["zones"]:
            if isinstance(z, dict) and isinstance(z.get("items"), list):
                z["items"] = [it for it in z["items"] if isinstance(it, dict) and it.get("kind") == "text"]
    # Use the high band's generous card height for the low symbols on Page 2
    if isinstance(t_p2.get("bands"), list) and len(t_p2["bands"]) >= 2:
        t_p2["bands"] = [dict(t_p2["bands"][1], name="high", card_h=max(200, float(t_p2["bands"][0].get("card_h") or 220)))]
    st_p2 = dict(structure or {}, top=len(low_keys), lower=0, block_keys=low_keys)
    p2_doc, p2_maps = compile_template(t_p2, st_p2, None, ctx)

    return [
        {"page": 1, "suffix": "", "template": p1_doc, "style_maps": p1_maps, "fit": float(p1_doc["mapper_meta"].get("fit", 1.0))},
        {"page": 2, "suffix": "_cont", "template": p2_doc, "style_maps": p2_maps, "fit": float(p2_doc["mapper_meta"].get("fit", 1.0))},
    ]
