"""pay_reader — an AGR paytable sheet read into one clean list per symbol, and the pay check.

Every AGR seen so far writes its paytable as one vertical block per symbol: the symbol (``<PIC1>``,
``<SCAT>``, or plain text like ``ACE`` / ``10``) on one row, its counts in the first number column to
its right and its pays in the next, one row per count (5, 4, 3 …), the run of rows above and below it.
Scatter blocks sit under a "Scatter" heading, sometimes two side by side, with "pays in any position".

``read_sheet(ws)`` returns that as::

    {"sheet": title,
     "symbols": [{"symbol": "PIC1", "label": "<PIC1>", "cell": "D14", "group": ["A", "K"] | None,
                  "role": "wild" | "scatter" | "", "pays": [{"count": 5, "pay": 150, "count_cell": "F13",
                  "pay_cell": "H13"}, …], "flags": ["…"]}, …],
     "notes": [{"cell": "B5", "text": "…"}], "orphans": [{"cells": "F80:H82", "pays": […]}],
     "problems": [{"level": "error" | "warn", "symbol": …, "text": "…", "cell": "…"}]}

``check_pays(read, mappings, texts)`` compares that with a paytable page (its slots and the cells
each one draws): every symbol's pays on the page, the same numbers, nothing hidden. A paytable that
disagrees with its Excel is a compliance error, so the page says so before it is exported.
"""
from __future__ import annotations

import re

from openpyxl.utils import get_column_letter, range_boundaries

_TOKEN = re.compile(r"<\s*([^<>]+?)\s*>")
_JOIN = re.compile(r"^[\s/,&+|]*(?:(?:and|or)[\s/,&+|]*)*$", re.I)
# plain-text symbol names an AGR writes without < > (card ranks)
_BARE = {"ace", "king", "queen", "jack", "ten", "nine", "a", "k", "q", "j", "10", "9"}
_NUMBER = re.compile(r"-?\d[\d,]*(?:\.\d+)?")


def _blank(v):
    return v is None or (isinstance(v, str) and not v.strip())


def _num(v):
    """A count / pay: an int or float cell, or text that is only a number ("1,000"); else None."""
    if isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return int(v) if float(v).is_integer() else float(v)
    if isinstance(v, str):
        s = v.strip().replace(",", "")
        if re.fullmatch(r"-?\d+(?:\.\d+)?", s):
            f = float(s)
            return int(f) if f.is_integer() else f
    return None


def _ref(r, c):
    return f"{get_column_letter(c)}{r}"


def _symbols_in(text):
    """The symbol(s) a cell names — only symbols and joiners in it ("<A> / <K>": a group) — or None."""
    if not isinstance(text, str) or not text.strip():
        return None
    toks = [t.strip() for t in _TOKEN.findall(text)]
    if toks:
        return toks if _JOIN.match(_TOKEN.sub(" ", text)) else None
    if text.strip().casefold() in _BARE:
        return [text.strip()]
    return None


def _norm(name):
    return re.sub(r"[^A-Z0-9]", "", str(name or "").upper())


def read_sheet(ws, ws_formulas=None):
    """The paytable on this sheet (values: a workbook loaded with data_only=True; ``ws_formulas`` the
    same sheet with formulas, to tell a formula Excel never saved a value for from an empty cell)."""
    max_r, max_c = ws.max_row or 1, ws.max_column or 1
    val = lambda r, c: ws.cell(row=r, column=c).value  # noqa: E731
    problems, symbols, claimed, pairs = [], [], set(), set()

    # --- the symbols: a cell naming them; to its right on the same row the count (the first number)
    # and the pay (the next filled cell — a number, or flagged when it isn't one) ---
    def _pair(r, c):
        cc = next((x for x in range(c + 1, max_c + 1) if _num(val(r, x)) is not None), None)
        if cc is None:
            return None
        pc = next((x for x in range(cc + 1, min(max_c, cc + 4) + 1) if not _blank(val(r, x))), None)
        return (cc, pc) if pc else None

    anchors = []
    for r in range(1, max_r + 1):
        for c in range(1, max_c + 1):
            names = _symbols_in(val(r, c))
            if not names:
                continue
            pair = _pair(r, c)
            if pair:
                anchors.append((r, c, names) + pair)
    # a card rank typed as a number (10, 9) in the column the other symbols are named in
    name_cols = {c for (_r, c, names, _cc, _pc) in anchors if not names[0].isdigit()}
    named = {(a[0], a[1]) for a in anchors}
    for r in range(1, max_r + 1):
        for c in name_cols:
            v = val(r, c)
            if (r, c) in named or isinstance(v, bool) or not isinstance(v, (int, float)) or str(_num(v)) not in _BARE:
                continue
            pair = _pair(r, c)
            if pair:
                anchors.append((r, c, [str(_num(v))]) + pair)
    anchors.sort(key=lambda a: (a[0], a[1]))
    count_cols = {cc for (_r, c, names, cc, pc) in anchors if not names[0].isdigit()}
    # a number written as text ("10") names a symbol only outside the count / pay columns
    anchors = [a for a in anchors if not (a[2][0].isdigit() and (a[1] in count_cols or a[1] in {x[4] for x in anchors}))]

    for (r, c, names, cc, pc) in anchors:
        rows = [r]
        up = r - 1
        while up >= 1 and _num(val(up, cc)) is not None:
            rows.insert(0, up)
            up -= 1
        dn = r + 1
        while dn <= max_r and _num(val(dn, cc)) is not None:
            rows.append(dn)
            dn += 1
        if any((rr, cc) in claimed for rr in rows):
            continue                                       # the same block named twice
        pays, flags = [], []
        for rr in rows:
            claimed.add((rr, cc))
            claimed.add((rr, pc))
            p = _num(val(rr, pc))
            if p is None:
                raw = val(rr, pc)
                f = ws_formulas.cell(row=rr, column=pc).value if ws_formulas is not None else None
                if isinstance(f, str) and f.startswith("="):
                    flags.append(f"{_ref(rr, pc)} is a formula Excel has no saved value for — open the Excel and save it")
                elif _blank(raw):
                    flags.append(f"no pay in {_ref(rr, pc)} for {_num(val(rr, cc))}")
                else:
                    flags.append(f"{_ref(rr, pc)} is not a number: “{raw}”")
            pays.append({"count": _num(val(rr, cc)), "pay": p, "count_cell": _ref(rr, cc), "pay_cell": _ref(rr, pc)})
        counts = [x["count"] for x in pays]
        if any(a <= b for a, b in zip(counts, counts[1:])):
            flags.append("counts don't go down (" + ", ".join(str(x) for x in counts) + ")")
        pairs.add((cc, pc))
        label = str(val(r, c)).strip()
        symbols.append({"symbol": names[0].upper() if len(names) == 1 else " / ".join(n.upper() for n in names),
                        "label": label, "cell": _ref(r, c), "group": [n.upper() for n in names] if len(names) > 1 else None,
                        "role": "", "pays": pays, "flags": flags, "_rows": (rows[0], rows[-1]), "_cols": (c, cc, pc)})

    # --- the sheet's prose (rules, wild / scatter text): what decides a symbol's role ---
    notes = []
    for r in range(1, max_r + 1):
        for c in range(1, max_c + 1):
            v = val(r, c)
            if isinstance(v, str) and len(v.split()) >= 3 and not _symbols_in(v):
                notes.append({"cell": _ref(r, c), "text": " ".join(v.split()), "_r": r, "_c": c})
    prose = " ".join(n["text"] for n in notes).casefold()
    for s in symbols:
        key = s["symbol"].casefold()
        (r0, r1), (c, _cc, pc) = s["_rows"], s["_cols"]
        near = [val(rr, cx) for rr in range(max(1, r0 - 4), r0) for cx in range(1, pc + 1)]
        below = [val(rr, cx) for rr in range(r1 + 1, min(max_r, r1 + 3) + 1) for cx in range(1, pc + 1)]
        if ("SCAT" in s["symbol"] or any(isinstance(x, str) and re.search(r"\bscatters?\b", x, re.I) and len(x.split()) <= 2 for x in near)
                or any(isinstance(x, str) and re.search(r"\b(any position|pays? any)\b", x, re.I) for x in below)):
            s["role"] = "scatter"
        elif "WILD" in s["symbol"] or re.search(r"<\s*" + re.escape(key) + r"\s*>[^.]{0,40}\b(is wild|substitutes?)\b", prose):
            s["role"] = "wild"

    # --- what doesn't add up ---
    for s in symbols:
        for f in s["flags"]:
            problems.append({"level": "error" if "not a number" in f or "no saved value" in f or "no pay" in f else "warn",
                             "symbol": s["symbol"], "text": f, "cell": s["cell"]})
    seen = {}
    for s in symbols:
        k = _norm(s["symbol"])
        if k in seen:
            problems.append({"level": "warn", "symbol": s["symbol"], "cell": s["cell"],
                             "text": f"{s['label']} is listed twice ({seen[k]} and {s['cell']}) — which pays are right?"})
        else:
            seen[k] = s["cell"]
    # pays in a symbol's count / pay columns that no symbol names
    orphans = []
    for (cc, pc) in pairs:
        run = []
        for r in range(1, max_r + 2):
            n, p = (_num(val(r, cc)), _num(val(r, pc))) if r <= max_r else (None, None)
            if n is not None and p is not None and (r, cc) not in claimed:
                run.append({"count": n, "pay": p, "row": r})
                continue
            if run:
                cells = f"{_ref(run[0]['row'], cc)}:{_ref(run[-1]['row'], pc)}"
                orphans.append({"cells": cells, "pays": [{"count": x["count"], "pay": x["pay"]} for x in run]})
                problems.append({"level": "warn", "symbol": "", "cell": cells,
                                 "text": f"pays in {cells} with no symbol next to them — a symbol name missing?"})
                run = []
    for s in symbols:
        s.pop("_rows", None)
        s.pop("_cols", None)
    for n in notes:
        n.pop("_r", None)
        n.pop("_c", None)
    return {"sheet": ws.title, "symbols": symbols, "notes": notes, "orphans": orphans, "problems": problems}


def paytable_sheets(wb):
    from ...content_model import page_kind

    return [ws for ws in wb.worksheets if page_kind(ws.title) == "paytable"
            and getattr(ws, "sheet_state", "visible") == "visible"]


def read_workbook(path, sheet_name=None):
    """Every paytable sheet of this Excel (or just ``sheet_name``), read. The values come from the
    frame-filtered cache (editor notes outside the drawn box gone); formulas are looked at only when
    a pay is missing, to say why."""
    from ... import workbook_cache

    out = []
    with workbook_cache.borrow(path, data_only=True) as wb:
        sheets = [wb[sheet_name]] if sheet_name and sheet_name in wb.sheetnames else paytable_sheets(wb)
        for ws in sheets:
            res = read_sheet(ws)
            if any("no pay in" in p["text"] for p in res["problems"]):
                try:
                    import openpyxl

                    from ...workbook_cache import load_formatted

                    fwb = load_formatted(path)
                    res = read_sheet(ws, fwb[ws.title])
                except Exception:
                    pass
            out.append(res)
    return out


# ------------------------------------------------------------------------------------------------
# the pay check: the page against the Excel
# ------------------------------------------------------------------------------------------------
def _cells_of(source):
    """'F13,F14,F15' / 'F13:F16' / 'Sheet!H5' → {'F13', …}"""
    out = set()
    for part in str(source or "").split(","):
        part = part.strip().split("!")[-1].replace("$", "")
        if not part:
            continue
        try:
            c0, r0, c1, r1 = range_boundaries(part)
        except Exception:
            continue
        for r in range(r0, r1 + 1):
            for c in range(c0, c1 + 1):
                out.add(_ref(r, c))
    return out


def _numbers(text):
    out = []
    for m in _NUMBER.findall(str(text or "")):
        n = _num(m)
        if n is not None:
            out.append(n)
    return out


def check_pays(read, mappings, texts, hidden=()):
    """``read``: read_sheet's result; ``mappings``: the page's slots {slot: spec} (spec["source"] = the
    cells it draws); ``texts``: {slot: the text it shows}; ``hidden``: slots that don't fit the page.
    Returns {"ok", "checked", "problems": [{level, symbol, text}]}."""
    slots = {str(k): v for k, v in (mappings or {}).items() if isinstance(v, dict)}
    cells = {k: _cells_of(v.get("source")) for k, v in slots.items()}
    hidden = {str(h) for h in hidden or ()}
    problems, used = [], set()
    # a shared card (symbols with the same pays): its pictures are slots named after each symbol
    icons = {key_of(k.split("@slot.", 1)[-1]) for k in slots if "." not in k.split("@slot.", 1)[-1]}
    sig = lambda x: tuple((p["count"], p["pay"]) for p in x["pays"])   # noqa: E731
    on_page = {sig(x) for x in read.get("symbols") or [] if any(cs & {p["pay_cell"] for p in x["pays"]} for cs in cells.values())}
    for s in read.get("symbols") or []:
        name = s["label"]
        pay_cells = [p["pay_cell"] for p in s["pays"]]
        want = [p["pay"] for p in s["pays"]]
        drawn = [k for k, cs in cells.items() if cs & set(pay_cells)]
        if not drawn and key_of(s["symbol"]) in icons and sig(s) in on_page:
            continue                                   # on a shared card: its picture, the same pays shown
        if not drawn:
            problems.append({"level": "error", "symbol": s["symbol"],
                             "text": f"{name}: its pays ({', '.join(str(x) for x in want)}) are not on the page"})
            continue
        used.update(drawn)
        for k in drawn:
            if k in hidden:
                problems.append({"level": "warn", "symbol": s["symbol"], "text": f"{name}: its pays don't fit their box — check they aren't cut off"})
            mine = [c for c in pay_cells if c in cells[k]]
            if len(mine) < len(pay_cells) and len(drawn) == 1:
                missing = [p["pay"] for p in s["pays"] if p["pay_cell"] not in cells[k]]
                problems.append({"level": "error", "symbol": s["symbol"],
                                 "text": f"{name}: only some pays are on the page — {', '.join(str(x) for x in missing)} missing"})
            shown = _numbers(texts.get(k, ""))
            expect = [p["pay"] for p in s["pays"] if p["pay_cell"] in cells[k]]
            if shown != expect:
                problems.append({"level": "error", "symbol": s["symbol"],
                                 "text": f"{name}: the page shows {', '.join(str(x) for x in shown) or 'nothing'} — the Excel says {', '.join(str(x) for x in expect)}"})
        count_cells = {p["count_cell"] for p in s["pays"]}
        cslots = [k for k, cs in cells.items() if cs & count_cells]
        used.update(cslots)
        for k in cslots:
            shown = _numbers(texts.get(k, ""))
            expect = [p["count"] for p in s["pays"] if p["count_cell"] in cells[k]]
            if shown != expect:
                problems.append({"level": "error", "symbol": s["symbol"],
                                 "text": f"{name}: the page shows the counts {', '.join(str(x) for x in shown) or 'nothing'} — the Excel says {', '.join(str(x) for x in expect)}"})
    for o in read.get("orphans") or []:
        if not any(cs & _cells_of(o["cells"]) for cs in cells.values()):
            continue
        problems.append({"level": "warn", "symbol": "", "text": f"the page shows pays from {o['cells']}, which no symbol names in the Excel"})
    for p in read.get("problems") or []:
        if p["level"] == "error":
            problems.append(dict(p))
    n = len(read.get("symbols") or [])
    return {"ok": not any(p["level"] == "error" for p in problems), "checked": n, "problems": problems}


# ------------------------------------------------------------------------------------------------
# tiers and shared cards: what the layout makes of the list
# ------------------------------------------------------------------------------------------------
# a card rank, whatever the AGR calls it ("<A>", "ACE", "10", "<TEN>")
_RANKS = {"ace": "a", "a": "a", "king": "k", "k": "k", "queen": "q", "q": "q", "jack": "j", "j": "j",
          "ten": "10", "10": "10", "nine": "9", "9": "9"}


def key_of(name):
    """The name a symbol is matched by across the reader, the card design and the page's slots:
    lower-case letters and digits, a card rank by its short name (ACE / <A> → "a", TEN → "10")."""
    k = re.sub(r"[^a-z0-9]", "", str(name or "").casefold())
    return _RANKS.get(k, k)


def is_rank(name):
    return re.sub(r"[^a-z0-9]", "", str(name or "").casefold()) in _RANKS


def tiers(read):
    """{symbol key: "special" | "premium" | "low"} — WILD / scatters are special, card ranks are low,
    the rest premium. With no card ranks on the sheet, the low tier starts at the biggest drop in top
    pay (in the Excel's order: premium symbols come first). The Excel's order is never changed."""
    syms = [s for s in (read or {}).get("symbols") or [] if s.get("pays")]
    out = {}
    plain = []
    for s in syms:
        k = key_of(s["symbol"])
        if s.get("role") in ("wild", "scatter"):
            out[k] = "special"
        elif is_rank(s["symbol"]) or (s.get("group") and all(is_rank(g) for g in s["group"])):
            out[k] = "low"
        else:
            out[k] = "premium"
            plain.append(s)
    if plain and not any(v == "low" for v in out.values()) and len(plain) > 2:
        tops = [max((p["pay"] for p in s["pays"] if isinstance(p["pay"], (int, float))), default=0) for s in plain]
        drops = [(tops[i] / max(1e-9, tops[i + 1]), i) for i in range(len(tops) - 1) if tops[i + 1] > 0]
        if drops:
            ratio, at = max(drops)
            if ratio >= 1.5:                           # a clear gap: below it, the low tier
                for s in plain[at + 1:]:
                    out[key_of(s["symbol"])] = "low"
    return out


def same_pays(read):
    """Symbols with exactly the same counts and pays, in runs next to each other in the Excel:
    [[key, key, …], …] — what a shared card shows (only runs of 2 or more)."""
    syms = [s for s in (read or {}).get("symbols") or [] if s.get("pays") and s.get("role") not in ("wild", "scatter")]
    runs, cur, sig = [], [], None
    for s in syms:
        here = tuple((p["count"], p["pay"]) for p in s["pays"])
        if here == sig:
            cur.append(key_of(s["symbol"]))
        else:
            if len(cur) > 1:
                runs.append(cur)
            cur, sig = [key_of(s["symbol"])], here
    if len(cur) > 1:
        runs.append(cur)
    return runs
