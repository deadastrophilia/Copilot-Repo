"""What changed between two AGRs (two versions, or two markets of one game).

Rows are aligned by content, not by row number, so a row added in the new AGR
does not make everything under it look changed (RowMap); prose is aligned word
by word (WordMap). compare() turns the two workbooks into a list of typed
changes, each in one of the categories the updater treats differently:

  content     the data changed, the design stays valid (a value, a sentence,
              a symbol in a line, a sheet's name) — applied automatically;
  structural  the amount or order of content changed (rows / sheets added,
              removed or moved) — needs room, copies or Continued pages;
  design      the look itself should change — never applied silently. Nothing
              read from an AGR is a design change today (formatting is not
              read); the category exists so a reviewer's request can use it.
"""
import difflib
import re

from .content_model import TOKEN, norm, tokens_in

CONTENT, STRUCTURAL, DESIGN = "content", "structural", "design"


def name_like(page, sheet):
    """How alike a page group's name and a sheet's name are ("Wheel Blast denom 3 4" ~ "Wheel(denom3&4)")."""
    a = re.sub(r"[^a-z0-9]", "", page.casefold())
    b = re.sub(r"[^a-z0-9]", "", sheet.casefold())
    digits = re.findall(r"\d+", page) == re.findall(r"\d+", sheet)
    return difflib.SequenceMatcher(None, a, b).ratio() + (0.5 if digits else 0.0)


# ── sheets ────────────────────────────────────────────────────────────────────
def _sheet_lines(sheet):
    return [norm(sheet.row_text(r)) + "|" + " ".join(tokens_in(sheet.row_text(r))) for r in sheet.rows]


def sheet_likeness(a, b):
    """How alike two sheets read, 0..1 (rows in order, symbols counted)."""
    la, lb = _sheet_lines(a), _sheet_lines(b)
    if not la or not lb:
        return 0.0
    return difflib.SequenceMatcher(None, la, lb, autojunk=False).ratio()


def sheet_renames(sheets_a, sheets_b, at_least=0.6):
    """{market A sheet: market B sheet} for sheets that only got a new name."""
    gone = [n for n in sheets_a if n not in sheets_b]
    new = [n for n in sheets_b if n not in sheets_a]
    pairs = sorted(((sheet_likeness(sheets_a[a], sheets_b[b]) + 0.05 * name_like(a, b), a, b)
                    for a in gone for b in new), reverse=True)
    out, used = {}, set()
    for score, a, b in pairs:
        if score >= at_least and a not in out and b not in used:
            out[a] = b
            used.add(b)
    return out


# ── rows ──────────────────────────────────────────────────────────────────────
class RowMap:
    """Rows of a market A sheet -> rows of the market B sheet, aligned by content."""

    def __init__(self, a, b):
        self.map, self.new_rows = {}, []
        if b is None:
            return
        ra, rb = a.rows, b.rows
        ta, tb = [norm(a.row_text(r)) for r in ra], [norm(b.row_text(r)) for r in rb]
        used = set()
        for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, ta, tb, autojunk=False).get_opcodes():
            if op == "equal":
                for k in range(i2 - i1):
                    self.map[ra[i1 + k]] = rb[j1 + k]
                    used.add(rb[j1 + k])
            elif op == "replace":
                cols = lambda s, r: tuple(sorted(c for rr, c in s.cells if rr == r))
                if i2 - i1 == j2 - j1 and all(cols(a, ra[i1 + k]) == cols(b, rb[j1 + k]) for k in range(i2 - i1)):
                    # as many rows changed as there are in their place, cells in the same columns:
                    # row for row, however much each changed ("5 150" -> "69 69" is still that row)
                    chosen = [(i1 + k, j1 + k) for k in range(i2 - i1)]
                else:
                    chosen = self._pair(a, b, ra, rb, ta, tb, i1, i2, j1, j2)
                for i, j in chosen:
                    self.map[ra[i]] = rb[j]
                    used.add(rb[j])
        self.new_rows = [r for r in rb if r not in used]

    @staticmethod
    def _pair(a, b, ra, rb, ta, tb, i1, i2, j1, j2):
        """Changed rows next to added / removed ones: each paired with the most alike row in its place
        in market B (a row inserted next to a changed one must not take its place), the order kept;
        rows still unpaired whose cells sit in the same columns (a pay row of new values) pair up
        when they are at the same place in the block."""
        pairs = sorted(((difflib.SequenceMatcher(None, ta[i], tb[j], autojunk=False).ratio(), i, j)
                        for i in range(i1, i2) for j in range(j1, j2)), reverse=True)
        taken_a, taken_b, chosen = set(), set(), []

        def take(i, j):
            if i in taken_a or j in taken_b or any((i - ci) * (j - cj) <= 0 for ci, cj in chosen):
                return                                # pairs never cross: row order stays
            taken_a.add(i)
            taken_b.add(j)
            chosen.append((i, j))

        for score, i, j in pairs:
            if score >= 0.35:
                take(i, j)
        cols = lambda s, r: tuple(sorted(c for rr, c in s.cells if rr == r))
        for end in (False, True):                     # same place counted from the block's top, then its bottom
            for i in range(i1, i2):
                j = (j2 - (i2 - i)) if end else (j1 + i - i1)
                if j1 <= j < j2 and cols(a, ra[i]) == cols(b, rb[j]):
                    take(i, j)
        return sorted(chosen)


# ── words ─────────────────────────────────────────────────────────────────────
class WordMap:
    """Words of a market A sheet -> words of the market B sheet (aligned by content)."""

    def __init__(self, a, b):
        self.a, self.b = a, b
        self.start, self.end = [None] * len(a.keys), [None] * len(a.keys)
        if b is None:
            return
        for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a.keys, b.keys, autojunk=False).get_opcodes():
            for i in range(i1, i2):
                if op == "equal":
                    self.start[i], self.end[i] = j1 + i - i1, j1 + i - i1 + 1
                else:
                    self.start[i], self.end[i] = j1, j2

    def text(self, i, j):
        """(market A words i..j, the market B words in their place) or None."""
        if self.b is None or self.start[i] is None or self.end[j - 1] is None:
            return None
        bi, bj = self.start[i], max(self.start[i], self.end[j - 1])
        return (" ".join(w[1] for w in self.a.words[i:j]), " ".join(w[1] for w in self.b.words[bi:bj]),
                {w[2] for w in self.b.words[bi:bj]})


# ── the change list ───────────────────────────────────────────────────────────
_NUMBER = re.compile(r"^[\d\s.,x×%$€£+-]+$", re.I)


def _shown(text):
    """A cell as the reader sees it: tokens and spacing aside, case kept (a capital is a real change)."""
    return re.sub(r"\s+", " ", TOKEN.sub(" ", str(text or ""))).strip()


def _words_only(text):
    """The words of a cell, punctuation and spacing aside: a symbol removed with its comma
    ("SCATTERED <purple_scat>, <blue_scat>" -> "SCATTERED, <blue_scat>") changes no words."""
    return re.sub(r"[\s,;:.&/]+", " ", _shown(text)).strip()


def _counted(tokens):
    out = {}
    for t in tokens:
        out[t] = out.get(t, 0) + 1
    return out


def _token_change(old, new):
    """(added, removed) symbol tokens between two cells, counted (two <PIC4> -> one is a removal)."""
    a, b = _counted(tokens_in(old)), _counted(tokens_in(new))
    added = [t for t in b for _n in range(b[t] - a.get(t, 0))]
    removed = [t for t in a for _n in range(a[t] - b.get(t, 0))]
    return added, removed


def _row_changes(a, b, rm):
    """Cell, symbol and row changes of one sheet that both AGRs have (rm = RowMap(a, b))."""
    out = []
    removed = [r for r in a.rows if r not in rm.map]
    added = list(rm.new_rows)
    # a row that left one place and came back in another, unchanged, moved
    for ra in list(removed):
        key = (norm(a.row_text(ra)), tuple(tokens_in(a.row_text(ra))))
        rb = next((r for r in added if (norm(b.row_text(r)), tuple(tokens_in(b.row_text(r)))) == key and key[0]), None)
        if rb is not None:
            removed.remove(ra)
            added.remove(rb)
            out.append({"type": "row_moved", "category": STRUCTURAL, "row_a": ra, "row_b": rb,
                        "text": b.row_label(rb)})
    for ra, rb in sorted(rm.map.items()):
        for col in sorted(set(a.row_cols(ra)) | set(b.row_cols(rb))):
            old, new = a.cells.get((ra, col), ""), b.cells.get((rb, col), "")
            if old == new:
                continue
            plus, minus = _token_change(old, new)
            symbols_only = (plus or minus) and _words_only(old) == _words_only(new)
            if _shown(old) != _shown(new) and not symbols_only:
                value = bool(_NUMBER.match(_shown(old) or "0")) and bool(_NUMBER.match(_shown(new) or "0"))
                out.append({"type": "cell_changed", "category": CONTENT, "what": "value" if value else "text",
                            "row_a": ra, "row_b": rb, "col": col, "old": old, "new": new})
            if plus or minus:
                out.append({"type": "symbols_changed", "category": CONTENT, "row_a": ra, "row_b": rb, "col": col,
                            "added": plus, "removed": minus, "old": old, "new": new})
    for ra in removed:
        out.append({"type": "row_removed", "category": STRUCTURAL, "row_a": ra, "text": a.row_label(ra)})
    for rb in added:
        out.append({"type": "row_added", "category": STRUCTURAL, "row_b": rb, "text": b.row_label(rb)})
    return out


def compare(sheets_a, sheets_b, renames=None):
    """Every change from workbook A to workbook B ({name: Sheet} each, as read_workbook gives them).

    Returns {"changes": [...], "counts": {type: n}, "categories": {category: n},
             "renames": {a: b}, "summary": [one line per sheet that changed]}.
    Each change has "type", "category" and "sheet" (its name in B; "sheet_a" when it differs);
    row changes name the rows ("row_a" / "row_b") and cell changes the column too.
    """
    if renames is None:
        renames = sheet_renames(sheets_a, sheets_b)
    as_b = {a: renames.get(a, a) for a in sheets_a}
    changes = []

    for a, b in renames.items():
        changes.append({"type": "sheet_renamed", "category": CONTENT, "sheet": b, "sheet_a": a})
    for a, s in sheets_a.items():
        if as_b[a] not in sheets_b:
            changes.append({"type": "sheet_removed", "category": STRUCTURAL, "sheet": a, "sheet_a": a,
                            "rows": len(s.rows)})
    for b, s in sheets_b.items():
        if b not in sheets_a and b not in renames.values():
            changes.append({"type": "sheet_added", "category": STRUCTURAL, "sheet": b, "rows": len(s.rows),
                            "kind": s.kind})
    both = [a for a in sheets_a if as_b[a] in sheets_b]
    order_b = list(sheets_b)
    places = [order_b.index(as_b[a]) for a in both]
    if places != sorted(places):
        changes.append({"type": "sheet_order", "category": STRUCTURAL, "sheet": "",
                        "order_a": [as_b[a] for a in both], "order_b": [n for n in order_b if n in set(as_b[a] for a in both)]})

    for a in both:
        b = as_b[a]
        for c in _row_changes(sheets_a[a], sheets_b[b], RowMap(sheets_a[a], sheets_b[b])):
            c["sheet"] = b
            if a != b:
                c["sheet_a"] = a
            changes.append(c)

    counts, categories = {}, {}
    for c in changes:
        counts[c["type"]] = counts.get(c["type"], 0) + 1
        categories[c["category"]] = categories.get(c["category"], 0) + 1
    return {"changes": changes, "counts": counts, "categories": categories, "renames": dict(renames),
            "summary": describe(changes)}


def _n(count, one, many=None):
    return f"{count} {one if count == 1 else (many or one + 's')}"


def describe(changes):
    """The change list as the lines a reviewer reads: sheets added / removed / renamed first, then
    one line per sheet whose rows changed."""
    lines, per_sheet, order = [], {}, []
    for c in changes:
        t = c["type"]
        if t == "sheet_renamed":
            lines.append(f"“{c['sheet_a']}” is now called “{c['sheet']}”")
        elif t == "sheet_removed":
            lines.append(f"“{c['sheet']}” was removed from the Excel")
        elif t == "sheet_added":
            lines.append(f"“{c['sheet']}” is a new sheet ({_n(c['rows'], 'row')})")
        elif t == "sheet_order":
            lines.append("The sheets are in a different order")
        else:
            if c["sheet"] not in per_sheet:
                per_sheet[c["sheet"]] = {}
                order.append(c["sheet"])
            key = c.get("what", "") + t
            per_sheet[c["sheet"]][key] = per_sheet[c["sheet"]].get(key, 0) + 1
    words = (("valuecell_changed", "value changed", "values changed"),
             ("textcell_changed", "text changed", "texts changed"),
             ("symbols_changed", "symbol change", "symbol changes"),
             ("row_added", "row added", "rows added"),
             ("row_removed", "row removed", "rows removed"),
             ("row_moved", "row moved", "rows moved"))
    for sheet in order:
        got = per_sheet[sheet]
        parts = [_n(got[k], one, many) for k, one, many in words if got.get(k)]
        lines.append(f"{sheet}: " + ", ".join(parts))
    return lines
