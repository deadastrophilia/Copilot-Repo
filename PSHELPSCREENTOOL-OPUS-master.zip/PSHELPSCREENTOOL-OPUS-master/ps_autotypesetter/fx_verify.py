"""Check the Photoshop-free layer-style preview against real Photoshop.

Previews never need Photoshop (ps_fx_png / ps_fx_canvas.js render every
style). This module is the optional "Verify in Photoshop" path and the
engine of the fidelity harness (tools/fx_fidelity_harness.py):

  * the SAME layer pixels (glyphs rendered once by PIL, or an artist layer's
    raster) go to Photoshop and to ps_fx_png, so the comparison measures the
    effects only — never font rasterisation;
  * Photoshop is reached through photoshop_bridge, so whichever Photoshop
    version is open does the work (COM only reaches the registered one); the
    script opens a temporary PNG, applies the byte-exact effects descriptor,
    saves a PNG and closes only that document.
"""
import base64
import io
import os
import tempfile
import uuid

import numpy as np
from PIL import Image, ImageDraw

from . import fx_descriptor, ps_fx_png

# Sets the active document's Layer Style › Global Light (angle, altitude in degrees): the angle
# "Use Global Light" shadows and bevels take (global_light.py). Never fails the render over it.
GLOBAL_LIGHT_JSX = r"""
function pshGlobalLightAngle() {
    var r = new ActionReference();
    r.putProperty(charIDToTypeID("Prpr"), charIDToTypeID("gblA"));
    r.putEnumerated(charIDToTypeID("Dcmn"), charIDToTypeID("Ordn"), charIDToTypeID("Trgt"));
    return executeActionGet(r).getUnitDoubleValue(charIDToTypeID("gblA"));
}
function pshSetGlobalLight(angle, altitude) {
    // the document's Global Light: "set gblA to a globalLighting object" — the form Photoshop's own
    // Global Light dialog records. The older "to a gblA object" form runs without an error but changes
    // nothing (Photoshop 27: a new document stays at 90, an opened PNG at 30), so it is checked by reading
    // the angle back
    function attempt(cls, angleKey, withAltitude) {
        var desc = new ActionDescriptor();
        var ref = new ActionReference();
        ref.putProperty(charIDToTypeID("Prpr"), charIDToTypeID("gblA"));
        ref.putEnumerated(charIDToTypeID("Dcmn"), charIDToTypeID("Ordn"), charIDToTypeID("Trgt"));
        desc.putReference(charIDToTypeID("null"), ref);
        var light = new ActionDescriptor();
        light.putUnitDouble(angleKey, charIDToTypeID("#Ang"), angle);
        if (withAltitude) light.putUnitDouble(stringIDToTypeID("globalAltitude"), charIDToTypeID("#Ang"), altitude);
        desc.putObject(charIDToTypeID("T   "), cls, light);
        executeAction(charIDToTypeID("setd"), desc, DialogModes.NO);
    }
    if (!isFinite(angle)) return false;
    var tries = [[stringIDToTypeID("globalLighting"), stringIDToTypeID("globalLightingAngle"), true],
                 [stringIDToTypeID("globalLighting"), stringIDToTypeID("globalLightingAngle"), false],
                 [charIDToTypeID("gblA"), charIDToTypeID("gblA"), true],
                 [charIDToTypeID("gblA"), charIDToTypeID("gblA"), false]];
    for (var i = 0; i < tries.length; i++) {
        try {
            attempt(tries[i][0], tries[i][1], tries[i][2] && isFinite(altitude));
            if (Math.abs(pshGlobalLightAngle() - angle) < 0.5) return true;
        } catch (e) { }
    }
    return false;
}
"""

# Applies a descriptor stream (4 hex digits per byte) to the only layer of an
# opened PNG and saves the flattened result as PNG. arguments:
#   [src_png, effects_hex4, out_png, layer_opacity %, fill_opacity %, light angle, light altitude]
#   (the light: "" = Photoshop's own)
_RENDER_JSX = GLOBAL_LIGHT_JSX + r"""
(function (args) {
    var srcPath = args[0], hex = args[1], outPath = args[2];
    var opacity = Number(args[3]), fill = Number(args[4]);
    var lightAngle = args[5] === "" || args[5] == null ? NaN : Number(args[5]);
    var lightAltitude = args[6] === "" || args[6] == null ? NaN : Number(args[6]);
    var prevDialogs = app.displayDialogs;
    var prevUnits = app.preferences.rulerUnits;
    app.displayDialogs = DialogModes.NO;
    app.preferences.rulerUnits = Units.PIXELS;
    var doc = app.open(new File(srcPath));
    try {
        pshSetGlobalLight(lightAngle, lightAltitude);
        var layer = doc.activeLayer;
        if (layer.isBackgroundLayer) layer.isBackgroundLayer = false;
        if (hex) {
            var stream = "";
            for (var i = 0; i < hex.length; i += 4) stream += String.fromCharCode(parseInt(hex.substr(i, 4), 16));
            var effects = new ActionDescriptor();
            effects.fromStream(stream);
            var setDesc = new ActionDescriptor();
            var ref = new ActionReference();
            ref.putProperty(stringIDToTypeID("property"), stringIDToTypeID("layerEffects"));
            ref.putEnumerated(stringIDToTypeID("layer"), stringIDToTypeID("ordinal"), stringIDToTypeID("targetEnum"));
            setDesc.putReference(stringIDToTypeID("null"), ref);
            setDesc.putObject(stringIDToTypeID("to"), stringIDToTypeID("layerEffects"), effects);
            executeAction(stringIDToTypeID("set"), setDesc, DialogModes.NO);
        }
        if (isFinite(opacity)) layer.opacity = opacity;
        if (isFinite(fill)) layer.fillOpacity = fill;
        var opts = new PNGSaveOptions();
        opts.interlaced = false;
        doc.saveAs(new File(outPath), opts, true, Extension.LOWERCASE);
    } finally {
        doc.close(SaveOptions.DONOTSAVECHANGES);
        app.preferences.rulerUnits = prevUnits;
        app.displayDialogs = prevDialogs;
    }
    return "OK";
})(arguments);
"""


class VerifyError(RuntimeError):
    pass


def descriptor_hex4(style_config):
    """Effects descriptor of a style as the capture form (4 hex digits per byte)."""
    if not isinstance(style_config, dict):
        return None
    candidates = []
    block = style_config.get("effects_block")
    if isinstance(block, dict) and block.get("hex"):
        candidates.append(block["hex"])
    if style_config.get("captured_effects_hex"):
        candidates.append(style_config["captured_effects_hex"])
    for raw in candidates:
        data = fx_descriptor.descriptor_bytes(raw)
        if data is not None:
            return "".join("%04x" % b for b in data)
    if style_config.get("stroke_enabled") or style_config.get("shadow_enabled"):
        from .psd_writer import effects as _effects

        payload = _effects.params_payload(style_config)
        if payload:
            return "".join("%04x" % b for b in payload[4:])
    return None


def style_opacities(style_config):
    """(layer opacity %, fill opacity %) a style asks for."""
    params = fx_descriptor.effective_params(style_config) or {}
    try:
        op = float(params.get("opacity", 100))
    except (TypeError, ValueError):
        op = 100.0
    try:
        fill = float(params.get("fill_opacity", 100))
    except (TypeError, ValueError):
        fill = 100.0
    if params.get("is_fill_enabled") is False:
        fill = 0.0
    return op, fill


def verify_light(style_config):
    """The global light a verify render uses: the project's, else the angle the style's "Use Global
    Light" effects were saved at — what the preview engine draws them at (global_light.py)."""
    from . import global_light

    return global_light.current() or global_light.for_document({"layer_style_library": {"style": style_config}})


def photoshop_render(src_img, effects_hex4, opacity=100.0, fill_opacity=100.0, timeout=180, light=None):
    """Render `src_img` (RGBA, already padded) with the descriptor in Photoshop, at `light`
    ({"angle", "altitude"}: the document's Global Light; None = Photoshop's own)."""
    from . import photoshop_bridge

    work = tempfile.mkdtemp(prefix="psh_fxverify_")
    token = uuid.uuid4().hex[:8]
    src_path = os.path.join(work, f"src_{token}.png")
    out_path = os.path.join(work, f"ps_{token}.png")
    src_img.convert("RGBA").save(src_path)
    try:
        result = photoshop_bridge.run_jsx(
            _RENDER_JSX,
            args=[src_path.replace("\\", "/"), effects_hex4 or "", out_path.replace("\\", "/"),
                  str(float(opacity)), str(float(fill_opacity)),
                  "" if not light else str(float(light["angle"])), "" if not light else str(float(light["altitude"]))],
            timeout=timeout,
        )
        if not os.path.isfile(out_path):
            raise VerifyError(f"Photoshop did not write the render ({str(result)[:200]}).")
        with Image.open(out_path) as im:
            img = im.convert("RGBA")
            img.load()
        return img
    finally:
        for path in (src_path, out_path):
            try:
                os.remove(path)
            except OSError:
                pass
        try:
            os.rmdir(work)
        except OSError:
            pass


def pil_render(src_img, style_config):
    """Same padded pixels through ps_fx_png (transparent backdrop, like the PS export)."""
    arr = np.asarray(src_img.convert("RGBA"), dtype=np.float32) / 255.0
    out = ps_fx_png.render_effects(arr, style_config)
    return Image.fromarray(np.clip(np.rint(out * 255.0), 0, 255).astype(np.uint8))


def compare(a, b, background=(128, 128, 128)):
    """Pixel difference of two same-size RGBA renders, composited on `background`.

    Returns (stats, diff_image). stats: mean_abs (0..255, over the pixels
    either render covers), bad_pct (% of those pixels whose worst channel
    differs by more than 32), alpha_mean_abs, covered_px.
    """
    if a.size != b.size:
        b = b.resize(a.size)
    bg = Image.new("RGBA", a.size, tuple(background) + (255,))
    ca = np.asarray(Image.alpha_composite(bg, a.convert("RGBA")).convert("RGB"), dtype=np.float32)
    cb = np.asarray(Image.alpha_composite(bg, b.convert("RGBA")).convert("RGB"), dtype=np.float32)
    aa = np.asarray(a.convert("RGBA"), dtype=np.float32)[..., 3]
    ab = np.asarray(b.convert("RGBA"), dtype=np.float32)[..., 3]
    covered = (aa > 8) | (ab > 8)
    worst = np.abs(ca - cb).max(axis=2)
    n = int(covered.sum())
    if n == 0:
        stats = {"mean_abs": 0.0, "bad_pct": 0.0, "alpha_mean_abs": 0.0, "covered_px": 0}
    else:
        stats = {
            "mean_abs": round(float(np.abs(ca - cb).mean(axis=2)[covered].mean()), 2),
            "bad_pct": round(float((worst[covered] > 32).mean() * 100.0), 2),
            "alpha_mean_abs": round(float(np.abs(aa - ab)[covered].mean()), 2),
            "covered_px": n,
        }
    heat = np.clip(worst * 3.0, 0, 255).astype(np.uint8)
    diff = Image.merge("RGB", (Image.fromarray(heat), Image.fromarray(heat // 3), Image.fromarray(heat // 3)))
    return stats, diff


def text_source(text, font, rgb, pad):
    """Glyph layer image for `text` (fill `rgb`) with `pad` transparent px around the ink."""
    bbox = font.getbbox(text)
    w = int(bbox[2] - bbox[0] + 2 * pad)
    h = int(bbox[3] - bbox[1] + 2 * pad)
    img = Image.new("RGBA", (max(1, w), max(1, h)), tuple(rgb[:3]) + (0,))
    mask = Image.new("L", img.size, 0)
    ImageDraw.Draw(mask).text((pad - bbox[0], pad - bbox[1]), text, font=font, fill=255)
    img.putalpha(mask)
    return img


def verify_layer(src_img, style_config, pad=None):
    """Render one layer image both ways. Returns dict with images + stats.

    Raises VerifyError when the style has no descriptor Photoshop can apply,
    photoshop_bridge.PhotoshopUnavailable when no Photoshop can be reached.
    """
    hex4 = descriptor_hex4(style_config)
    if not hex4:
        raise VerifyError("This style has no Photoshop effects descriptor to verify.")
    N = ps_fx_png.normalize_params(style_config)
    if pad is None:
        pad = ps_fx_png.effect_pad(N) + 4
    src = src_img.convert("RGBA")
    padded = Image.new("RGBA", (src.width + 2 * pad, src.height + 2 * pad), (0, 0, 0, 0))
    padded.paste(src, (pad, pad))
    opacity, fill = style_opacities(style_config)
    ps_img = photoshop_render(padded, hex4, opacity, fill, light=verify_light(style_config))
    tool_img = pil_render(padded, style_config)
    stats, diff = compare(ps_img, tool_img)
    return {"photoshop": ps_img, "tool": tool_img, "diff": diff, "stats": stats, "source": padded}


def verify_text_style(style_config, text="Sample 123", font_name="Arial", size=72, rgb=(255, 255, 255),
                      bold=True):
    """Verify a saved layer style on sample text (the UI's "Verify in Photoshop")."""
    from PIL import ImageFont

    from . import png_builder

    font = png_builder._load_font(ImageFont, font_name, size, bold=bold)
    src = text_source(str(text or "Sample 123"), font, list(rgb), 0)
    return verify_layer(src, style_config)


def png_data_uri(img, background=None):
    if background is not None:
        bg = Image.new("RGBA", img.size, tuple(background) + (255,))
        img = Image.alpha_composite(bg, img.convert("RGBA"))
    buf = io.BytesIO()
    img.save(buf, "PNG")
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode("ascii")
