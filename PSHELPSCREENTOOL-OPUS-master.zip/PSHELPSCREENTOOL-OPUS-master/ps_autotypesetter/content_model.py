"""An AGR's content, independent of any PSD: sheets, rows, cells and the symbols they name.

Both ways of making help screens read the same thing from an AGR: the creator lays
it out, the PSD updater (market_clone today) compares it with another AGR and
edits an existing design. This module is the shared reading; content_diff.py is
the comparison.

  Sheet       one visible sheet: {(row, col): text} as the help screen shows it
              (editors' notes outside the sheet's drawn frame are dropped).
  Index       where a piece of text is in a workbook (cells, whole rows).
  Stream      a sheet's prose as one run of words in row order (an artist splits
              and joins paragraphs, so prose is found as a stretch of words).

Text is compared through norm(): no <ICON> tokens, one space, case folded.
"""
import difflib
import re
from collections import Counter

TOKEN = re.compile(r"<[^<>]*>")
_SPACE = re.compile(r"\s+")


def norm(text):
    """Text as compared: no <ICON> tokens, one space, case folded (the artist's spacing never counts)."""
    t = TOKEN.sub(" ", str(text or "")).replace("\u00a0", " ").replace("\r", " ").replace("\n", " ")
    return _SPACE.sub(" ", t).strip().casefold()


def cell_text(value):
    """A cell as the help screen shows it (png_builder._text; whole numbers without '.0')."""
    if value is None:
        return ""
    if isinstance(value, float) and value.is_integer():
        value = int(value)
    return str(value).replace("\r\n", "\n").replace("\r", "\n").strip()


def lines(text):
    return [ln for ln in str(text or "").replace("\r\n", "\r").replace("\n", "\r").split("\r")]


def word_key(word):
    """A word as compared: case folded, outer punctuation off, 1,250 == 1250."""
    w = word.casefold().strip(".,;:!?()\"'")
    return re.sub(r"(?<=\d),(?=\d{3}\b)", "", w)


# ── symbols ───────────────────────────────────────────────────────────────────
def sym_key(text):
    """A token or layer name as compared: "<PIC4>", "PIC_04 copy 3", "PIC_04.png" -> "pic4"."""
    t = str(text or "").strip().strip("<>")
    t = re.sub(r"\.(png|psb|psd|tif|tiff|jpe?g)$", "", t, flags=re.I)
    t = re.sub(r"(\s+copy(\s*\d+)?)+$", "", t, flags=re.I)
    t = re.sub(r"[^a-z0-9]", "", t.casefold())
    return re.sub(r"(?<![0-9])0+(?=[0-9])", "", t)


_NUMBER_WORDS = {"two": "2", "three": "3", "four": "4", "five": "5", "six": "6", "seven": "7", "eight": "8",
                 "nine": "9", "ten": "10"}


def _name_parts(text):
    """A token or layer name as its parts: "EN_UHDL_ScatGold_Mnr_I_X2_00016" -> scat gold mnr i x2,
    "MINORx2 I" -> minor x2 i ("copy n" endings, file extensions and long numbers left out)."""
    t = re.sub(r"\.(png|psb|psd|tif|tiff|jpe?g)$", "", str(text or "").strip().strip("<>"), flags=re.I)
    t = re.sub(r"(\s+copy(\s*\d+)?)+$", "", t, flags=re.I)
    t = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", t)                  # ScatGold -> Scat Gold
    t = re.sub(r"(?<=[A-Za-z])(?=[xX]\d)", " ", t).lower()       # MINORx2 -> minor x2
    parts = re.findall(r"x\d+|[a-z]+|\d+", t)
    return [p for p in parts if not (p.isdigit() and len(p) >= 3)]


def _abbreviates(short, full):
    """"grd" for "grand", "mjr" for "major": the same first letter, the rest in order."""
    if len(short) < 2 or len(short) >= len(full) or short[0] != full[0]:
        return False
    it = iter(full)
    return all(ch in it for ch in short)


def token_for_name(name, tokens):
    """The token a picture's layer name spells, when one does unambiguously: every part of the token
    is in the name (as it is, or abbreviated — Grd / Grand, Mnr / Minor; Nine / 9), and every telling
    part of the name (a single letter, x2) is in the token. The closest one wins (exact parts over
    abbreviations); a tie names nothing."""
    have = [_NUMBER_WORDS.get(p, p) for p in _name_parts(name)]
    telling = {p for p in have if len(p) == 1 or re.fullmatch(r"x\d+", p)}
    best, tie = (0.0, None), False
    for tok in tokens:
        want = [_NUMBER_WORDS.get(p, p) for p in _name_parts(tok)]
        if not want:
            continue
        score, used = 0.0, set()
        for w in want:
            k = next((i for i, h in enumerate(have) if i not in used and h == w), None)
            if k is None:
                k = next((i for i, h in enumerate(have) if i not in used and (_abbreviates(h, w) or _abbreviates(w, h))), None)
                score -= 0.1
            if k is None:
                break
            used.add(k)
            score += 1.0
        else:
            if any(have[i] in telling for i in range(len(have)) if i not in used):
                continue
            if score > best[0]:
                best, tie = (score, tok), False
            elif score == best[0]:
                tie = True
    return None if tie else best[1]


def tokens_in(text):
    return [m.group()[1:-1] for m in TOKEN.finditer(str(text or ""))]


# ── pages ─────────────────────────────────────────────────────────────────────
def page_kind(name):
    """What a sheet is by its name: "bingo_rules", "game_rules", "paytable" or "page"."""
    low = str(name or "").lower()
    if "bingo" in low:
        return "bingo_rules"
    if "game rules" in low or low in ("rules", "rules of the game", "game rule", "game rules & help", "game_rules"):
        return "game_rules"
    if "paytable" in low or "pay table" in low or "payout" in low:
        return "paytable"
    return "page"


# ── the workbooks ─────────────────────────────────────────────────────────────
class Sheet:
    def __init__(self, name, ws):
        self.name = name
        self.cells = {}                               # (row, col) -> text
        for row in ws.iter_rows():
            for c in row:
                t = cell_text(c.value)
                if t:
                    self.cells[(c.row, c.column)] = t
        self.rows = sorted({r for r, _c in self.cells})

    def row_text(self, r):
        return " ".join(self.cells[k] for k in sorted(k for k in self.cells if k[0] == r))

    def row_cols(self, r):
        return tuple(sorted(c for rr, c in self.cells if rr == r))

    def row_label(self, r, width=60):
        """A row as a report names it: its text, shortened."""
        t = _SPACE.sub(" ", self.row_text(r).replace("\n", " ")).strip()
        return t if len(t) <= width else t[:width - 1].rstrip() + "…"

    @property
    def kind(self):
        return page_kind(self.name)


def read_workbook(path):
    """{sheet name: Sheet} for the visible sheets, in the workbook's order. The parsed workbook is
    shared (workbook_cache: one parse per file version — an AGR with many merged, formatted cells
    takes seconds to parse)."""
    from . import excel_frame, workbook_cache

    with workbook_cache.borrow(path, data_only=True) as wb:
        # editors' notes outside each sheet's drawn frame ("<modified") are not help-screen text
        excel_frame.clear_outside(wb, excel_frame.frames_for(path, wb))
        return {ws.title: Sheet(ws.title, ws) for ws in wb.worksheets if ws.sheet_state == "visible"}


class Index:
    """Where a piece of text is in a workbook: cells and whole rows, by normalized text."""

    def __init__(self, sheets):
        self.sheets = sheets
        self.cell = {}                                # norm -> [(sheet, row, col)]
        self.row = {}                                 # norm -> [(sheet, row)]
        for s in sheets.values():
            for (r, c), t in s.cells.items():
                self.cell.setdefault(norm(t), []).append((s.name, r, c))
            for r in s.rows:
                n = norm(s.row_text(r))
                if n:
                    self.row.setdefault(n, []).append((s.name, r))


# ── prose: the sheet as one stream of words ───────────────────────────────────
# An artist often splits one Excel paragraph over several text layers (around an
# icon) or joins rows into one; so prose is found as a stretch of the sheet's
# words, in row order, wherever it starts and ends.
class Stream:
    def __init__(self, sheet):
        self.words = []                               # (key, word, row)
        for r in sheet.rows:
            for w in TOKEN.sub(" ", sheet.row_text(r)).split():
                self.words.append((word_key(w), w, r))
        self.keys = [w[0] for w in self.words]
        self.first = {}
        for i, k in enumerate(self.keys):
            self.first.setdefault(k, []).append(i)

    def find(self, want):
        """Starts of `want` (word keys) in the stream, exactly."""
        n = len(want)
        return [i for i in self.first.get(want[0], []) if self.keys[i:i + n] == want]

    def near(self, want, at_least=0.85):
        """The stretch most like `want` (the artist reworded a little): (start, end, score) or None."""
        n, best = len(want), None
        starts, seen = [], set()
        for i in sorted({i for k in set(want) for i in self.first.get(k, [])}):
            for start in (max(0, i - n), i):              # each window scored once, in the same order
                if start not in seen:
                    seen.add(start)
                    starts.append(start)
        need = Counter(want)
        sm = difflib.SequenceMatcher(None, autojunk=False)
        sm.set_seq1(want)
        for start in starts:
            window = self.keys[start:start + n + max(2, n // 5)]
            # no more words can match than the two share: a window that can't beat the best is skipped
            have = Counter(window)
            bound = sum(min(c, have[k]) for k, c in need.items()) / n
            if bound < at_least or (best is not None and bound <= best[2]):
                continue
            sm.set_seq2(window)
            blocks = [b for b in sm.get_matching_blocks() if b.size]
            if not blocks:
                continue
            score = sum(b.size for b in blocks) / n
            if score >= at_least and (best is None or score > best[2]):
                best = (start + blocks[0].b, start + blocks[-1].b + blocks[-1].size, score)
        return best
