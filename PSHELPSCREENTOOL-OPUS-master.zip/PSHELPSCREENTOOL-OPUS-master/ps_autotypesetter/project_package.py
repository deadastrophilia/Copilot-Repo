"""Project package system: ``MyGame.project.json`` + ``MyGame_Links/``.

Every saved PSD gets a companion package that makes the whole project
self-contained and restorable:

    MyGame.psd
    MyGame.project.json          # master manifest (project_id, file refs)
    MyGame_Links/
        project/project.json     # project metadata (id, timestamps)
        config/config.json       # full configuration snapshot (source of truth)
        pages/pages.json         # render-all/selected sheets, page overrides, canvas
        typography/typography.json
        styles/styles.json       # heading/body/icon/table styles
        layouts/tables/*.json    # copies of mapped table JSONs
        layouts/paytables/*.json # copy of the paytable template JSON
        layouts/paylines/paylines.json   # reserved (no payline engine yet)
        renderer/renderer.json   # renderer-level settings view
        assets/assets.json       # asset references (icons, background, mappings)
        history/history.json     # save/load history ring
        source/baseline.xlsx     # private copy of the Excel the PSD was built from
        source/manifest.json     # baseline file hash + per-sheet content hashes

The ``source/`` pair is the Perforce-aware baseline: it survives the source
Excel being overwritten in place by the next revision, so "Update PSD" can
always diff the current workbook against the exact workbook the PSD was built
from — no Old Excel required from the user. The baseline is only advanced
(atomically) after a successful PSD save.

The manifest is the master pointer; ``config/config.json`` is the single
source of truth for settings (other files are extracted views). The paytable
and table JSONs are copied into ``layouts/`` so the package is fully portable
and PNGs can be exported from it without the PSD or Photoshop.
"""

import copy
import datetime
import hashlib
import json
import os
import re
import shutil
import uuid

MANIFEST_SUFFIX = ".project.json"
LINKS_SUFFIX = "_Links"
SCHEMA_VERSION = 1
HISTORY_LIMIT = 50

_CONFIG_FILENAME = "config.json"
SOURCE_SUBDIR = "source"
BASELINE_FILENAME = "baseline.xlsx"
BASELINE_MANIFEST_FILENAME = "manifest.json"
BASELINE_SCHEMA_VERSION = 1


def manifest_path_for_psd(psd_path):
    if not psd_path:
        return None
    base, _ = os.path.splitext(str(psd_path))
    return base + MANIFEST_SUFFIX


def links_dir_for_psd(psd_path):
    if not psd_path:
        return None
    base, _ = os.path.splitext(str(psd_path))
    return base + LINKS_SUFFIX


# ---------------------------------------------------------------------------
# Excel baseline (Game_Links/source/baseline.xlsx + source/manifest.json)
# ---------------------------------------------------------------------------

def baseline_path_for_psd(psd_path):
    links = links_dir_for_psd(psd_path)
    if not links:
        return None
    return os.path.join(links, SOURCE_SUBDIR, BASELINE_FILENAME)


def baseline_manifest_path_for_psd(psd_path):
    links = links_dir_for_psd(psd_path)
    if not links:
        return None
    return os.path.join(links, SOURCE_SUBDIR, BASELINE_MANIFEST_FILENAME)


def file_sha256(path):
    """SHA-256 of a file's bytes, streamed in chunks (never fully loaded)."""
    h = hashlib.sha256()
    try:
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(1 << 20), b""):
                h.update(chunk)
    except Exception:
        return ""
    return h.hexdigest()


def _sheet_hashes(excel_path, max_col_limit):
    from .project_manifest import workbook_hashes

    try:
        return workbook_hashes(excel_path, int(max_col_limit or 12))
    except Exception as exc:
        print(f"[HASH] Could not hash workbook sheets: {exc}")
        return {}


def _baseline_payload(excel_path, max_col_limit, version_number, now=None):
    now = now or datetime.datetime.now().isoformat(timespec="seconds")
    sheets = _sheet_hashes(excel_path, max_col_limit)
    pages = []
    for order, (sheet_name, content_hash) in enumerate(sorted(sheets.items()), start=1):
        pages.append({
            "page_id": sheet_name,
            "sheet_name": sheet_name,
            "order": order,
            "content_hash": content_hash,
        })
    return {
        "schema_version": BASELINE_SCHEMA_VERSION,
        "created_at": now,
        "updated_at": now,
        "version_number": int(version_number),
        "source": {
            "original_path": os.path.abspath(excel_path),
            "filename": os.path.basename(excel_path),
            "file_hash": file_sha256(excel_path),
            "created_at": now,
        },
        "pages": pages,
    }


def load_baseline_info(psd_path):
    """Inspect the saved Excel baseline of a PSD. Never raises.

    Returns {"exists": bool, "baseline": str?, "manifest": str?,
             "data": dict|None, "version_number": int,
             "original_path": str?, "file_hash": str?}.
    """
    if not psd_path:
        return {"exists": False}
    baseline = baseline_path_for_psd(psd_path)
    manifest_path = baseline_manifest_path_for_psd(psd_path)
    if not baseline or not os.path.isfile(baseline):
        # no _Links folder: the PSD carries its own Excel snapshot (psd_memory)
        if psd_path and os.path.isfile(psd_path):
            try:
                from . import psd_memory

                info = psd_memory.baseline_info(psd_path)
                if info.get("exists"):
                    return info
            except Exception:
                pass
        return {"exists": False, "baseline": baseline, "manifest": manifest_path}
    data, _err = _load_json(manifest_path)
    source = (data or {}).get("source") or {}
    return {
        "exists": True,
        "baseline": os.path.abspath(baseline),
        "manifest": os.path.abspath(manifest_path) if manifest_path else None,
        "data": data,
        "version_number": int((data or {}).get("version_number") or 1),
        "original_path": source.get("original_path") or "",
        "file_hash": source.get("file_hash") or file_sha256(baseline),
    }


def commit_baseline(psd_path, excel_path, max_col_limit=12, force=False):
    """Save (or advance) the private Excel baseline beside a PSD.

    ``Game_Links/source/baseline.xlsx`` is a byte copy of the workbook the PSD
    was built from; ``source/manifest.json`` records its file hash, per-sheet
    content hashes and a version number. force=False only creates the baseline
    when none exists yet (first build); force=True advances it — call it ONLY
    after the PSD was saved successfully. The copy is atomic (tmp + replace),
    so a crash never leaves a half-written baseline.

    Returns {"ok": bool, "action": "created"|"advanced"|"skipped"|"error",
             "baseline": str?, "manifest": str?, "version_number": int,
             "file_hash": str?, "error": str?}.
    """
    if not psd_path:
        return {"ok": False, "action": "error", "error": "No PSD path."}
    psd_path = os.path.abspath(str(psd_path))
    excel_path = str(excel_path or "").strip()
    baseline = baseline_path_for_psd(psd_path)
    manifest_path = baseline_manifest_path_for_psd(psd_path)
    if not baseline:
        return {"ok": False, "action": "error", "error": "No baseline path for this PSD."}
    if not excel_path or not os.path.isfile(excel_path):
        return {
            "ok": False, "action": "error", "baseline": baseline,
            "manifest": manifest_path, "error": "Excel to baseline is missing.",
        }

    info = load_baseline_info(psd_path)
    if info.get("exists") and not force:
        return {
            "ok": True, "action": "skipped", "baseline": info.get("baseline"),
            "manifest": info.get("manifest"), "version_number": info.get("version_number") or 1,
            "file_hash": info.get("file_hash") or "",
        }
    if info.get("exists"):
        version = (info.get("version_number") or 1) + 1
    else:
        version = 1

    try:
        os.makedirs(os.path.dirname(baseline), exist_ok=True)
        tmp = baseline + ".tmp"
        shutil.copyfile(excel_path, tmp)
        os.replace(tmp, baseline)
        payload = _baseline_payload(excel_path, max_col_limit, version)
        _write_json(manifest_path, payload)
    except Exception as exc:
        print(f"[BASELINE] Could not save baseline: {exc}")
        return {
            "ok": False, "action": "error", "baseline": baseline,
            "manifest": manifest_path, "error": f"Could not save baseline: {exc}",
        }

    action = "created" if version == 1 else "advanced"
    print(f"[BASELINE] Excel baseline {action} (V{version}) for {os.path.basename(psd_path)}")
    return {
        "ok": True, "action": action, "baseline": os.path.abspath(baseline),
        "manifest": os.path.abspath(manifest_path) if manifest_path else None,
        "version_number": version,
        "file_hash": payload["source"]["file_hash"],
    }


def _safe_slug(name, fallback="project"):
    slug = re.sub(r"[^A-Za-z0-9]+", "_", str(name or "")).strip("_").lower()
    return slug or fallback


def _write_json(path, payload):
    """Atomic-ish JSON write: never leaves a half-written file behind."""
    from .safe_json import write_json

    return write_json(path, payload)


def _load_json(path):
    """Return (data, error). error is a human-readable message or None."""
    if not os.path.isfile(path):
        return None, None
    try:
        with open(path, "r", encoding="utf-8-sig") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return None, f"{os.path.basename(path)} does not contain a JSON object."
        return data, None
    except Exception as exc:
        return None, f"{os.path.basename(path)} is corrupted: {exc}"


def load_package_manifest(path):
    """Read a master manifest; returns dict or None (never raises)."""
    data, _err = _load_json(path)
    return data


def _rel(path, base_dir):
    """Relative path (posix separators) from base_dir to path."""
    try:
        return os.path.relpath(os.path.abspath(path), os.path.abspath(base_dir)).replace("\\", "/")
    except Exception:
        return os.path.basename(path)


def _file_ref(path, base_dir):
    if not path:
        return None
    path = str(path).strip()
    if not path:
        return None
    return {
        "absolute": os.path.abspath(path),
        "relative": _rel(path, base_dir),
        "exists": os.path.isfile(path),
    }


def _pick(cfg, keys):
    out = {}
    for k in keys:
        if k in cfg:
            out[k] = copy.deepcopy(cfg[k])
    return out


def _resolve_project_id(config, psd_path, manifest_path):
    """Stable project id: reuse the existing manifest's id; on rename scan
    sibling ``*.project.json`` manifests whose PSD is gone; else derive one."""
    if manifest_path and os.path.isfile(manifest_path):
        existing = load_package_manifest(manifest_path)
        pid = (existing or {}).get("project_id") or ""
        if pid:
            return pid, existing

    psd_name = os.path.basename(str(psd_path or ""))
    folder = os.path.dirname(os.path.abspath(str(psd_path or "")))
    candidates = []
    try:
        for fn in sorted(os.listdir(folder)):
            if not fn.lower().endswith(MANIFEST_SUFFIX):
                continue
            sibling = os.path.join(folder, fn)
            if sibling == manifest_path:
                continue
            other = load_package_manifest(sibling)
            if not other:
                continue
            old_psd = ((other.get("files") or {}).get("psd") or {}).get("absolute") or ""
            if not old_psd or os.path.basename(old_psd) == psd_name:
                continue
            if os.path.isfile(old_psd):
                continue
            candidates.append((sibling, other))
    except Exception:
        candidates = []

    if len(candidates) == 1:
        pid = (candidates[0][1]).get("project_id") or ""
        if pid:
            return pid, candidates[0][1]
    return None, None


def _copy_into_links(src_path, links_subdir, psd_dir, dest_name=None):
    """Copy a JSON file into the links tree; returns the destination path
    (or None when the source is missing/not a file)."""
    if not src_path or not os.path.isfile(src_path):
        return None
    dest_dir = os.path.join(psd_dir, links_subdir)
    name = dest_name or os.path.basename(src_path)
    dest = os.path.join(dest_dir, name)
    if os.path.abspath(src_path) == os.path.abspath(dest):
        return dest
    try:
        os.makedirs(dest_dir, exist_ok=True)
        shutil.copyfile(src_path, dest)
        return dest
    except Exception:
        return None


def _snapshot_config(config, psd_dir, links_rel):
    """Deep copy of the config with template/table JSONs re-pointed at the
    copies inside the links tree (self-contained package)."""
    cfg = copy.deepcopy(config or {})

    ds = cfg.get("dynamic_settings")
    if isinstance(ds, dict):
        tpl = str(ds.get("template_json") or "").strip()
        copied = _copy_into_links(tpl, os.path.join(links_rel, "layouts", "paytables"), psd_dir)
        if copied:
            ds["template_json"] = copied

    ts = cfg.get("table_style")
    if isinstance(ts, dict):
        paths = [p.strip() for p in str(ts.get("mapped_table_jsons") or "").splitlines() if p.strip()]
        new_paths = []
        for p in paths:
            copied = _copy_into_links(p, os.path.join(links_rel, "layouts", "tables"), psd_dir)
            new_paths.append(copied or p)
        ts["mapped_table_jsons"] = "\n".join(new_paths)
        overrides = ts.get("json_sheet_overrides")
        if isinstance(overrides, dict):
            remapped = {}
            for p, v in overrides.items():
                dest = None
                if os.path.isfile(p):
                    dest = _copy_into_links(p, os.path.join(links_rel, "layouts", "tables"), psd_dir)
                remapped[dest or p] = v
            ts["json_sheet_overrides"] = remapped

    return cfg


def write_project_package(config, psd_path):
    """Write/refresh the project package beside a PSD. Never raises.

    Returns {"ok": bool, "manifest": path, "error": str?}.
    """
    if not psd_path:
        return {"ok": False, "manifest": None, "error": "No PSD path."}
    config = config or {}
    psd_path = os.path.abspath(str(psd_path))
    psd_dir = os.path.dirname(psd_path)
    stem = os.path.splitext(os.path.basename(psd_path))[0]
    manifest_path = manifest_path_for_psd(psd_path)
    links_dir = links_dir_for_psd(psd_path)
    links_rel = os.path.basename(links_dir)

    try:
        project_id, old_manifest = _resolve_project_id(config, psd_path, manifest_path)
        if not project_id:
            project_id = f"{_safe_slug(stem)}_" + uuid.uuid4().hex[:6]

        # ---- rename handling: reuse a sibling package's links folder -----
        if old_manifest:
            old_links = ((old_manifest.get("files") or {}).get("links_folder") or {}).get("absolute") or ""
            old_name = (old_manifest.get("project_name") or "") + LINKS_SUFFIX
            if old_links and os.path.isdir(old_links) and os.path.abspath(old_links) != os.path.abspath(links_dir):
                if not os.path.isdir(links_dir):
                    try:
                        os.rename(old_links, links_dir)
                    except Exception:
                        pass

        os.makedirs(links_dir, exist_ok=True)

        now = datetime.datetime.now().isoformat(timespec="seconds")

        # ---- metadata (preserve created_at across refreshes) -------------
        meta_path = os.path.join(links_dir, "project", "project.json")
        meta_data, meta_err = _load_json(meta_path)
        meta = dict(meta_data or {})
        created_at = meta.get("created_at") or now
        meta.update({
            "schema_version": SCHEMA_VERSION,
            "project_id": project_id,
            "project_name": stem,
            "created_at": created_at,
            "updated_at": now,
            "psd_file": psd_path,
        })

        # ---- config snapshot (single source of truth) --------------------
        snapshot = _snapshot_config(config, psd_dir, links_rel)
        psd_in_snapshot = str((snapshot.get("prev_psd_path") or "")).strip()
        if not psd_in_snapshot or not os.path.isfile(psd_in_snapshot):
            snapshot["prev_psd_path"] = psd_path
        _write_json(os.path.join(links_dir, "config", _CONFIG_FILENAME), snapshot)

        # ---- extracted views (subsets of the config snapshot) ------------
        _write_json(os.path.join(links_dir, "project", "project.json"), meta)
        _write_json(os.path.join(links_dir, "pages", "pages.json"), {
            "render_all_pages": snapshot.get("render_all_pages"),
            "selected_sheets": snapshot.get("selected_sheets") or [],
            "page_overrides": snapshot.get("page_overrides") or None,
            "canvas": _pick(snapshot, ["c_width", "c_height", "c_resolution", "canvas_preset"]),
        })
        _write_json(os.path.join(links_dir, "typography", "typography.json"), {
            **_pick(snapshot, [
                "h_font", "h_font_style", "h_size", "h_icon_h", "h_rgb", "h_bold",
                "b_font", "b_font_style", "b_size", "b_icon_h", "b_rgb",
                "line_spacing", "para_spacing", "gap_px", "heading_icon_gap",
                "heading_icon_gap_left", "heading_icon_gap_right",
                "heading_top_margin", "heading_to_body_gap", "bottom_margin",
                "continued_gap",
            ]),
            "dynamic_paytable": _pick((snapshot.get("dynamic_settings") or {}), [
                "heading_uppercase_enabled", "heading_game_name_text",
                "heading_keep_one_line", "heading_one_line_margin",
                "subheading_font_request", "subheading_size", "subheading_rgb",
                "paytable_notes_alignment",
            ]) or None,
        })
        _write_json(os.path.join(links_dir, "styles", "styles.json"), {
            **_pick(snapshot, ["heading_style", "body_style", "icon_style", "table_style"]),
            "style_assignments": ((snapshot.get("dynamic_settings") or {}).get("style_assignments") or None),
            "layer_style_library": ((snapshot.get("dynamic_settings") or {}).get("layer_style_library") or None),
        })
        _write_json(os.path.join(links_dir, "renderer", "renderer.json"), {
            **_pick(snapshot, [
                "build_output", "png_suffix", "margin_x", "max_col_limit",
                "alignment_settings", "keyword_colors", "bg_mode", "bg_color",
                "bg_source", "inner_canvas_width", "performance_mode",
                "body_icons_use_original_size", "icon_simple_mode", "alignment",
            ]),
            "game_rules": {"render_game_rules": snapshot.get("render_game_rules"),
                           "render_bingo_rules": snapshot.get("render_bingo_rules")},
        })
        _write_json(os.path.join(links_dir, "assets", "assets.json"), {
            "icon_folder": _file_ref(snapshot.get("icon_folder"), psd_dir),
            "background": _file_ref(snapshot.get("bg_path"), psd_dir),
            **_pick(snapshot, ["icon_mappings", "icon_size_overrides", "icon_y_offset",
                               "icon_gap_left", "icon_gap_right"]),
        })
        _write_json(os.path.join(links_dir, "layouts", "paylines", "paylines.json"), {
            "paylines": [],
            "note": "Reserved for payline configuration; the current engine has no payline feature.",
        })

        # ---- history -----------------------------------------------------
        history_path = os.path.join(links_dir, "history", "history.json")
        hist_data, _ = _load_json(history_path)
        history = list((hist_data or {}).get("history") or [])
        history.insert(0, {
            "saved_at": now,
            "psd": os.path.basename(psd_path),
            "excel": os.path.basename(str(config.get("excel_path") or "")),
            "project_id": project_id,
        })
        _write_json(history_path, {"history": history[:HISTORY_LIMIT]})

        # ---- master manifest ---------------------------------------------
        excel_path = str(config.get("excel_path") or "").strip()
        manifest = {
            "schema_version": SCHEMA_VERSION,
            "project_id": project_id,
            "project_name": stem,
            "updated_at": now,
            "engine": {
                "shared_layout_engine": True,
                "note": "PSD and PNG builds share the same layout engine (_build_kwargs).",
            },
            "files": {
                "psd": _file_ref(psd_path, psd_dir),
                "links_folder": {
                    "absolute": os.path.abspath(links_dir),
                    "relative": links_rel,
                    "exists": os.path.isdir(links_dir),
                },
                "manifest": _file_ref(manifest_path, psd_dir),
                "excel": _file_ref(excel_path, psd_dir) if excel_path else None,
                "icons": _file_ref(config.get("icon_folder"), psd_dir),
                "background": _file_ref(config.get("bg_path"), psd_dir),
                "pshelpscreen": _file_ref(os.path.splitext(psd_path)[0] + ".pshelpscreen.json", psd_dir),
                "baseline": _file_ref(baseline_path_for_psd(psd_path), psd_dir),
                "baseline_manifest": _file_ref(baseline_manifest_path_for_psd(psd_path), psd_dir),
            },
            "configuration": {
                "config": f"{links_rel}/config/{_CONFIG_FILENAME}",
                "project": f"{links_rel}/project/project.json",
                "pages": f"{links_rel}/pages/pages.json",
                "typography": f"{links_rel}/typography/typography.json",
                "styles": f"{links_rel}/styles/styles.json",
                "layouts": {
                    "tables": f"{links_rel}/layouts/tables",
                    "paytables": f"{links_rel}/layouts/paytables",
                    "paylines": f"{links_rel}/layouts/paylines/paylines.json",
                },
                "renderer": f"{links_rel}/renderer/renderer.json",
                "assets": f"{links_rel}/assets/assets.json",
                "history": f"{links_rel}/history/history.json",
                "source": f"{links_rel}/{SOURCE_SUBDIR}",
            },
        }
        _write_json(manifest_path, manifest)
        return {"ok": True, "manifest": manifest_path, "error": None}
    except Exception as exc:
        return {"ok": False, "manifest": None, "error": f"Could not save project package: {exc}"}


def detect_for_psd(psd_path):
    """Cheap detection: does a master manifest exist beside this PSD?"""
    path = manifest_path_for_psd(psd_path)
    if not path or not os.path.isfile(path):
        return None
    return path


def load_project(manifest_path, session_cfg):
    """Restore a project package into a session config.

    Errors (never raised, never overwritten):
      - missing manifest            -> "Project configuration file not found."
      - missing links folder/config -> "Project configuration is incomplete."
      - corrupted JSON              -> message naming the offending file.

    Returns {"ok": True, "config": dict, "project": dict} or
             {"ok": False, "error": str, "code": str}.
    """
    if not manifest_path or not os.path.isfile(manifest_path):
        return {"ok": False, "code": "not_found", "error": "Project configuration file not found."}

    manifest, err = _load_json(manifest_path)
    if manifest is None:
        return {"ok": False, "code": "corrupt", "error": f"Project file is corrupted ({err})."}

    psd_dir = os.path.dirname(os.path.abspath(manifest_path))
    links_dir = ((manifest.get("files") or {}).get("links_folder") or {}).get("absolute") or ""
    if not links_dir or not os.path.isdir(links_dir):
        base, _ = os.path.splitext(manifest_path)
        links_dir = base + LINKS_SUFFIX
        if not links_dir or not os.path.isdir(links_dir):
            return {"ok": False, "code": "incomplete", "error": "Project configuration is incomplete."}

    config_path = os.path.join(links_dir, "config", _CONFIG_FILENAME)
    if not os.path.isfile(config_path):
        return {"ok": False, "code": "incomplete", "error": "Project configuration is incomplete."}
    snapshot, err = _load_json(config_path)
    if snapshot is None:
        return {"ok": False, "code": "corrupt", "error": f"Project configuration file is corrupted ({err})."}

    merged = dict(session_cfg or {})
    merged.update(snapshot)

    # Session-level artifacts stay session-owned.
    merged["recent_projects"] = (session_cfg or {}).get("recent_projects") or []
    merged["ai_suggestions"] = (session_cfg or {}).get("ai_suggestions") or []

    # Resolve PSD from the manifest (absolute first, then relative).
    psd_ref = (manifest.get("files") or {}).get("psd") or {}
    psd_abs = str(psd_ref.get("absolute") or "")
    if not psd_abs or not os.path.isfile(psd_abs):
        rel = str(psd_ref.get("relative") or "")
        if rel:
            psd_abs = os.path.abspath(os.path.join(psd_dir, rel))
    merged["prev_psd_path"] = psd_abs

    # Excel: manifest ref wins when present, else keep the snapshot value.
    excel_ref = (manifest.get("files") or {}).get("excel") or {}
    excel_abs = str(excel_ref.get("absolute") or "")
    if not excel_abs or not os.path.isfile(excel_abs):
        rel = str(excel_ref.get("relative") or "")
        if rel:
            excel_abs = os.path.abspath(os.path.join(psd_dir, rel))
    if excel_abs and os.path.isfile(excel_abs):
        merged["excel_path"] = excel_abs

    # Fallback: if a links copy is missing, fall back to the original JSON.
    ds = merged.get("dynamic_settings")
    if isinstance(ds, dict):
        tpl = str(ds.get("template_json") or "").strip()
        if tpl and not os.path.isfile(tpl):
            original = ((snapshot.get("dynamic_settings") or {}).get("template_json") or "")
            ds["template_json"] = original if original and os.path.isfile(original) else tpl

    return {
        "ok": True,
        "config": merged,
        "manifest": os.path.abspath(manifest_path),
        "project": {
            "project_id": manifest.get("project_id") or "",
            "project_name": manifest.get("project_name") or "",
            "updated_at": manifest.get("updated_at") or "",
            "manifest": os.path.abspath(manifest_path),
            "links": os.path.abspath(links_dir),
            "psd": psd_abs or "",
            "excel": merged.get("excel_path") or "",
            "baseline": load_baseline_info(psd_abs or ""),
        },
    }
