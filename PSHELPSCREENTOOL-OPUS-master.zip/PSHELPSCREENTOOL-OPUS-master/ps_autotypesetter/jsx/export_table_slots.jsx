#target photoshop

// Web Table Mapper slot scanner.
// Inputs (set by the Python prelude):
//   $.global.PSHST_EXPORT_PSD_PATH  - absolute path to the PSD/PSB to scan
//   $.global.PSHST_SLOT_PREFIX      - slot prefix, default "@table"
//   $.global.PSHST_PREVIEW_PATH     - optional PNG path for a flattened preview
// Output: JSON string returned to doJavaScript (no dialogs, no alerts).

(function () {
    function errorResult(message) {
        return "ERROR:" + String(message || "Unknown error");
    }

    try {
        if (!app.documents.length) {
            return errorResult("NO_DOCUMENT: Open the PSD first or make sure Photoshop has a document open.");
        }

        var doc = app.activeDocument;
        var rawPrefix = String($.global.PSHST_SLOT_PREFIX || "@table");
        var previewPath = String($.global.PSHST_PREVIEW_PATH || "");

        function normalizePrefix(prefix) {
            prefix = String(prefix || "@table");
            prefix = prefix.replace(/^\s+|\s+$/g, "");
            if (!prefix) prefix = "@table";
            if (prefix.charAt(0) !== "@") prefix = "@" + prefix;
            if (prefix.length > 1 && prefix.charAt(prefix.length - 1) === ".") {
                prefix = prefix.substring(0, prefix.length - 1);
            }
            return prefix;
        }

        var slotPrefix = normalizePrefix(rawPrefix);
        var matchPrefix = slotPrefix === "@" ? "@" : (slotPrefix + ".");

        function px(v) {
            try { return Number(v.as("px")); }
            catch (e) { return Number(v); }
        }

        function cleanSlotName(name) {
            name = String(name || "");
            if (slotPrefix === "@") {
                return name.replace(/^@/, "");
            }
            if (name.indexOf(matchPrefix) === 0) {
                return name.substring(matchPrefix.length);
            }
            return name;
        }

        function layerMatchesPrefix(layerName) {
            layerName = String(layerName || "");
            if (slotPrefix === "@") {
                return layerName.indexOf("@") === 0;
            }
            return layerName.indexOf(matchPrefix) === 0;
        }

        function escapeJsonString(s) {
            return String(s)
                .replace(/\\/g, "\\\\")
                .replace(/\"/g, "\\\"")
                .replace(/\r/g, "\\r")
                .replace(/\n/g, "\\n")
                .replace(/\t/g, "\\t");
        }

        function jsonStringify(obj, indent) {
            if (indent === undefined) indent = 0;
            var pad = "";
            for (var i = 0; i < indent; i++) pad += " ";
            var nextPad = pad + "  ";

            if (obj === null) return "null";
            if (typeof obj === "string") return "\"" + escapeJsonString(obj) + "\"";
            if (typeof obj === "number" || typeof obj === "boolean") return String(obj);

            if (obj instanceof Array) {
                var arr = [];
                for (var a = 0; a < obj.length; a++) {
                    arr.push(nextPad + jsonStringify(obj[a], indent + 2));
                }
                return "[\n" + arr.join(",\n") + "\n" + pad + "]";
            }

            var parts = [];
            for (var key in obj) {
                if (obj.hasOwnProperty(key)) {
                    parts.push(nextPad + "\"" + escapeJsonString(key) + "\": " + jsonStringify(obj[key], indent + 2));
                }
            }
            return "{\n" + parts.join(",\n") + "\n" + pad + "}";
        }

        function countObjectKeys(obj) {
            var n = 0;
            for (var key in obj) {
                if (obj.hasOwnProperty(key)) n++;
            }
            return n;
        }

        function getLayerBounds(layer) {
            try {
                var b = layer.bounds;
                var left = px(b[0]);
                var top = px(b[1]);
                var right = px(b[2]);
                var bottom = px(b[3]);

                if (isNaN(left) || isNaN(top) || isNaN(right) || isNaN(bottom)) {
                    return null;
                }

                var w = Math.round(right - left);
                var h = Math.round(bottom - top);

                if (w <= 0 || h <= 0) {
                    return null;
                }

                return {
                    "x": Math.round(left),
                    "y": Math.round(top),
                    "w": w,
                    "h": h
                };
            } catch (e) {
                return null;
            }
        }

        function walkLayers(container, found) {
            for (var i = 0; i < container.layers.length; i++) {
                var layer = container.layers[i];
                if (layerMatchesPrefix(layer.name)) {
                    var key = cleanSlotName(layer.name);
                    var bounds = getLayerBounds(layer);
                    if (bounds) {
                        found.push({ "base": key, "box": bounds });
                    }
                }
                if (layer.typename === "LayerSet") {
                    walkLayers(layer, found);
                }
            }
        }

        var templateName = doc.name.replace(/\.[^\.]+$/, "");
        var output = {
            "template_id": templateName,
            "source_psd": doc.name,
            "slot_prefix": slotPrefix,
            "export_kind": slotPrefix === "@table" ? "table" : (slotPrefix === "@slot" ? "slot" : String(slotPrefix).replace(/^@/, "")),
            "scanned_group": "",
            "canvas": {
                "width": Math.round(px(doc.width)),
                "height": Math.round(px(doc.height))
            },
            "slots": {}
        };

        var found = [];
        walkLayers(doc, found);

        var totals = {};
        var used = {};
        for (var f = 0; f < found.length; f++) {
            totals[found[f].base] = (totals[found[f].base] || 0) + 1;
        }

        for (var j = 0; j < found.length; j++) {
            var item = found[j];
            var key = item.base;
            if (totals[item.base] > 1) {
                used[item.base] = (used[item.base] || 0) + 1;
                key = item.base + "." + used[item.base];
            }
            output.slots[key] = item.box;
        }

        if (slotPrefix === "@table") {
            output.table_slots = output.slots;
        }

        var slotCount = countObjectKeys(output.slots);
        if (slotCount === 0) {
            return errorResult("NO_SLOTS: No layers named like '" + matchPrefix + "...' with usable bounds were found.");
        }

        output.preview_saved = false;
        if (previewPath) {
            try {
                var dup = doc.duplicate("preview", true);
                try {
                    dup.flatten();
                } catch (e) {}
                var pngFile = new File(previewPath);
                var pngOptions = new PNGSaveOptions();
                pngOptions.interlaced = false;
                dup.saveAs(pngFile, pngOptions, true, Extension.LOWERCASE);
                dup.close(SaveOptions.DONOTSAVECHANGES);
                output.preview_saved = true;
            } catch (e) {
                try {
                    app.activeDocument.close(SaveOptions.DONOTSAVECHANGES);
                } catch (e2) {}
                output.preview_saved = false;
            }
        }

        return jsonStringify(output, 0);

    } catch (err) {
        return errorResult(err.message + " | line " + err.line);
    }
})();
