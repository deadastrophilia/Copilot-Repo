#target photoshop

(function () {
    try {
        if (!app.documents.length) {
            alert("No PSD is open. Open your PSD template first, then run this script again.");
            return "ERROR:NO_DOCUMENT";
        }

        var doc = app.activeDocument;
        var rawPrefix = String($.global.PSHST_SLOT_PREFIX || "@slot");
        var groupPath = String($.global.PSHST_EXPORT_GROUP_PATH || "");

        function normalizePrefix(prefix) {
            prefix = String(prefix || "@slot");
            prefix = prefix.replace(/^\s+|\s+$/g, "");
            if (!prefix) prefix = "@slot";
            if (prefix.charAt(0) !== "@") prefix = "@" + prefix;
            if (prefix.length > 1 && prefix.charAt(prefix.length - 1) === ".") {
                prefix = prefix.substring(0, prefix.length - 1);
            }
            return prefix;
        }

        var slotPrefix = normalizePrefix(rawPrefix);
        var matchPrefix = slotPrefix === "@" ? "@" : (slotPrefix + ".");

        function px(v) {
            try { return Number(v.as("px")); }
            catch (e) { return Number(v); }
        }

        function cleanSlotName(name) {
            name = String(name || "");
            if (slotPrefix === "@") {
                return name.replace(/^@/, "");
            }
            if (name.indexOf(matchPrefix) === 0) {
                return name.substring(matchPrefix.length);
            }
            return name;
        }

        function layerMatchesPrefix(layerName) {
            layerName = String(layerName || "");
            if (slotPrefix === "@") {
                return layerName.indexOf("@") === 0;
            }
            return layerName.indexOf(matchPrefix) === 0;
        }

        function escapeJsonString(s) {
            return String(s)
                .replace(/\\/g, "\\\\")
                .replace(/\"/g, "\\\"")
                .replace(/\r/g, "\\r")
                .replace(/\n/g, "\\n")
                .replace(/\t/g, "\\t");
        }

        function jsonStringify(obj, indent) {
            if (indent === undefined) indent = 0;
            var pad = "";
            for (var i = 0; i < indent; i++) pad += " ";
            var nextPad = pad + "  ";

            if (obj === null) return "null";
            if (typeof obj === "string") return "\"" + escapeJsonString(obj) + "\"";
            if (typeof obj === "number" || typeof obj === "boolean") return String(obj);

            if (obj instanceof Array) {
                var arr = [];
                for (var a = 0; a < obj.length; a++) {
                    arr.push(nextPad + jsonStringify(obj[a], indent + 2));
                }
                return "[\n" + arr.join(",\n") + "\n" + pad + "]";
            }

            var parts = [];
            for (var key in obj) {
                if (obj.hasOwnProperty(key)) {
                    parts.push(nextPad + "\"" + escapeJsonString(key) + "\": " + jsonStringify(obj[key], indent + 2));
                }
            }
            return "{\n" + parts.join(",\n") + "\n" + pad + "}";
        }

        function countObjectKeys(obj) {
            var n = 0;
            for (var key in obj) {
                if (obj.hasOwnProperty(key)) n++;
            }
            return n;
        }

        function exportKind(prefix) {
            if (prefix === "@table") return "table";
            if (prefix === "@slot") return "slot";
            if (prefix === "@") return "all_at_layers";
            return String(prefix || "@slot").replace(/^@/, "");
        }

        function getLayerBounds(layer) {
            try {
                var b = layer.bounds;
                var left = px(b[0]);
                var top = px(b[1]);
                var right = px(b[2]);
                var bottom = px(b[3]);

                if (isNaN(left) || isNaN(top) || isNaN(right) || isNaN(bottom)) {
                    return null;
                }

                var w = Math.round(right - left);
                var h = Math.round(bottom - top);

                if (w <= 0 || h <= 0) {
                    return null;
                }

                return {
                    "x": Math.round(left),
                    "y": Math.round(top),
                    "w": w,
                    "h": h
                };
            } catch (e) {
                return null;
            }
        }

        function splitGroupPath(path) {
            path = String(path || "");
            if (!path) return [];
            var raw = path.split("/");
            var parts = [];
            for (var i = 0; i < raw.length; i++) {
                var part = String(raw[i] || "").replace(/^\s+|\s+$/g, "");
                if (part) parts.push(part);
            }
            return parts;
        }

        function findGroup(container, parts, index) {
            if (!parts || parts.length === 0 || index >= parts.length) {
                return container;
            }
            try {
                var sets = container.layerSets;
                for (var i = 0; i < sets.length; i++) {
                    var group = sets[i];
                    if (String(group.name || "") === parts[index]) {
                        return findGroup(group, parts, index + 1);
                    }
                }
            } catch (e) {}
            return null;
        }

        function walkLayers(container, found, debugLines) {
            for (var i = 0; i < container.layers.length; i++) {
                var layer = container.layers[i];
                debugLines.push("Found layer/group: " + layer.name + " | type: " + layer.typename);

                if (layerMatchesPrefix(layer.name)) {
                    var key = cleanSlotName(layer.name);
                    var bounds = getLayerBounds(layer);

                    if (bounds) {
                        found.push({
                            "base": key,
                            "box": bounds
                        });
                        debugLines.push("  EXPORTED SLOT: " + key + " => x:" + bounds.x + " y:" + bounds.y + " w:" + bounds.w + " h:" + bounds.h);
                    } else {
                        debugLines.push("  SKIPPED SLOT, no usable bounds: " + layer.name);
                    }
                }

                if (layer.typename === "LayerSet") {
                    walkLayers(layer, found, debugLines);
                }
            }
        }

        var scanRoot = doc;
        if (groupPath) {
            scanRoot = findGroup(doc, splitGroupPath(groupPath), 0);
            if (!scanRoot) {
                alert("Selected group path was not found:\n" + groupPath);
                return "ERROR:GROUP_NOT_FOUND";
            }
        }

        var templateName = doc.name.replace(/\.[^\.]+$/, "");
        var output = {
            "template_id": templateName,
            "source_psd": doc.name,
            "slot_prefix": slotPrefix,
            "export_kind": exportKind(slotPrefix),
            "scanned_group": groupPath,
            "canvas": {
                "width": Math.round(px(doc.width)),
                "height": Math.round(px(doc.height))
            },
            "slots": {}
        };

        var debugLines = [];
        debugLines.push("Active document: " + doc.name);
        debugLines.push("Slot prefix: " + slotPrefix);
        debugLines.push("Match prefix: " + matchPrefix);
        debugLines.push("Scanned group: " + (groupPath || "[full document]"));

        var found = [];
        walkLayers(scanRoot, found, debugLines);

        var totals = {};
        var used = {};
        for (var f = 0; f < found.length; f++) {
            totals[found[f].base] = (totals[found[f].base] || 0) + 1;
        }

        for (var j = 0; j < found.length; j++) {
            var item = found[j];
            var key = item.base;
            if (totals[item.base] > 1) {
                used[item.base] = (used[item.base] || 0) + 1;
                key = item.base + "." + used[item.base];
            }
            output.slots[key] = item.box;
        }

        if (slotPrefix === "@table") {
            output.table_slots = output.slots;
        }

        var slotCount = countObjectKeys(output.slots);
        if (slotCount === 0) {
            var logFile = new File(Folder.desktop + "/template_slot_export_DEBUG_LOG.txt");
            logFile.encoding = "UTF8";
            logFile.open("w");
            logFile.write(debugLines.join("\n"));
            logFile.close();

            alert("No " + matchPrefix + " layers with usable bounds were found.\n\nA debug log was saved on Desktop:\ntemplate_slot_export_DEBUG_LOG.txt\n\nUse examples like @slot.title, @table.cashExpressTrains.bounds, or choose @ to scan all @-prefixed layers.");
            return "ERROR:NO_SLOTS";
        }

        var saveFile = File.saveDialog("Save template JSON", "JSON Files:*.json");
        if (!saveFile) {
            alert("Export cancelled.");
            return "CANCELLED";
        }

        if (String(saveFile.name).toLowerCase().indexOf(".json") === -1) {
            saveFile = new File(saveFile.fsName + ".json");
        }

        saveFile.encoding = "UTF8";
        saveFile.open("w");
        saveFile.write(jsonStringify(output, 0));
        saveFile.close();

        alert("Template JSON exported successfully.\nPrefix: " + slotPrefix + "\nSlots exported: " + slotCount + "\nSaved to:\n" + saveFile.fsName);
        return "SAVED:" + saveFile.fsName;

    } catch (err) {
        alert("Exporter crashed:\n" + err.message + "\nLine: " + err.line);
        return "ERROR:" + err.message;
    }
})();
