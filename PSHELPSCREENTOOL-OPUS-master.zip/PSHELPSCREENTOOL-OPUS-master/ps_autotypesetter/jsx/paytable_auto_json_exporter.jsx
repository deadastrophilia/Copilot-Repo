/*
PsHelpScreenTool - Paytable Auto JSON Exporter
- Finds a group named exactly "paytable" case-insensitively.
- Ignores everything outside that group. It does NOT delete or save the PSD.
- Detects likely title, repeated symbol slots, feature panel slots, and notes.
- Asks the artist where to save the JSON.
*/
(function () {
    // ExtendScript in older Photoshop versions may not provide JSON.
    // Keep a local serializer so JSON export works everywhere.
    function jsonQuote(s) {
        s = String(s == null ? "" : s);
        var out = '"';
        for (var i = 0; i < s.length; i++) {
            var ch = s.charAt(i);
            if (ch === '"') out += '\\"';
            else if (ch === '\\') out += '\\\\';
            else if (ch === '\r') out += '\\r';
            else if (ch === '\n') out += '\\n';
            else if (ch === '\t') out += '\\t';
            else out += ch;
        }
        return out + '"';
    }

    function jsonStringify(value, indent) {
        indent = indent || 0;
        var pad = "";
        for (var p = 0; p < indent; p++) pad += " ";
        var pad2 = pad + "  ";
        if (value === null || value === undefined) return "null";
        var t = typeof value;
        if (t === "string") return jsonQuote(value);
        if (t === "number") return isFinite(value) ? String(value) : "null";
        if (t === "boolean") return value ? "true" : "false";
        if (value instanceof Array) {
            if (!value.length) return "[]";
            var arr = [];
            for (var i = 0; i < value.length; i++) arr.push(pad2 + jsonStringify(value[i], indent + 2));
            return "[\n" + arr.join(",\n") + "\n" + pad + "]";
        }
        if (t === "object") {
            var parts = [];
            for (var k in value) {
                if (value.hasOwnProperty(k)) parts.push(pad2 + jsonQuote(k) + ": " + jsonStringify(value[k], indent + 2));
            }
            if (!parts.length) return "{}";
            return "{\n" + parts.join(",\n") + "\n" + pad + "}";
        }
        return "null";
    }

    function getGlobalString(name, fallback) {
        try {
            if (typeof $.global[name] !== "undefined" && $.global[name] !== null) return String($.global[name]);
        } catch (e) {}
        return fallback || "";
    }

    function trimLower(s) {
        return String(s || "").replace(/^\s+|\s+$/g, "").toLowerCase();
    }

    function px(v) {
        try { return Number(v.as("px")); } catch (e) { return Number(v); }
    }

    function boxOf(layer) {
        try {
            var b = layer.bounds;
            var x1 = px(b[0]), y1 = px(b[1]), x2 = px(b[2]), y2 = px(b[3]);
            var w = x2 - x1, h = y2 - y1;
            if (!isFinite(x1) || !isFinite(y1) || !isFinite(w) || !isFinite(h) || w <= 2 || h <= 2) return null;
            return { x: Math.round(x1), y: Math.round(y1), w: Math.round(w), h: Math.round(h), x2: Math.round(x2), y2: Math.round(y2) };
        } catch (e) {
            return null;
        }
    }

    function layerKind(layer) {
        try {
            if (layer.typename === "LayerSet") return "group";
            if (layer.kind === LayerKind.TEXT) return "text";
        } catch (e) {}
        return "art";
    }

    function layerVisible(layer) {
        try { return !!layer.visible; } catch (e) { return true; }
    }

    function findPaytableGroups(container, out, path) {
        path = path || "";
        try {
            var sets = container.layerSets;
            for (var i = 0; i < sets.length; i++) {
                var g = sets[i];
                var p = path ? (path + "/" + g.name) : g.name;
                if (trimLower(g.name) === "paytable") out.push({ group: g, path: p });
                findPaytableGroups(g, out, p);
            }
        } catch (e) {}
    }

    function addLayerRecord(layer, depth, path, immediate, records) {
        if (!layerVisible(layer)) return;
        var b = boxOf(layer);
        if (!b) return;
        var kind = layerKind(layer);
        records.push({
            name: String(layer.name || ""),
            path: path,
            kind: kind,
            depth: depth,
            immediate: !!immediate,
            x: b.x, y: b.y, w: b.w, h: b.h, x2: b.x2, y2: b.y2,
            area: b.w * b.h
        });
    }

    function walk(container, depth, path, records) {
        try {
            var layers = container.layers;
            for (var i = 0; i < layers.length; i++) {
                var layer = layers[i];
                var childPath = path ? (path + "/" + layer.name) : String(layer.name || "");
                addLayerRecord(layer, depth, childPath, depth === 1, records);
                if (layer.typename === "LayerSet") walk(layer, depth + 1, childPath, records);
            }
        } catch (e) {
            try {
                var sets = container.layerSets;
                for (var s = 0; s < sets.length; s++) {
                    var g = sets[s];
                    var gp = path ? (path + "/" + g.name) : String(g.name || "");
                    addLayerRecord(g, depth, gp, depth === 1, records);
                    walk(g, depth + 1, gp, records);
                }
                var arts = container.artLayers;
                for (var a = 0; a < arts.length; a++) {
                    var ar = arts[a];
                    var ap = path ? (path + "/" + ar.name) : String(ar.name || "");
                    addLayerRecord(ar, depth, ap, depth === 1, records);
                }
            } catch (e2) {}
        }
    }

    function cleanSlot(b) {
        return { x: Math.round(b.x), y: Math.round(b.y), w: Math.round(b.w), h: Math.round(b.h) };
    }

    function overlap(a, b) {
        var x = Math.max(0, Math.min(a.x2, b.x2) - Math.max(a.x, b.x));
        var y = Math.max(0, Math.min(a.y2, b.y2) - Math.max(a.y, b.y));
        return x * y;
    }

    function nearSameSize(a, b) {
        var dw = Math.abs(a.w - b.w) / Math.max(1, Math.max(a.w, b.w));
        var dh = Math.abs(a.h - b.h) / Math.max(1, Math.max(a.h, b.h));
        return dw <= 0.22 && dh <= 0.22;
    }

    function clusterRepeated(cands) {
        var clusters = [];
        for (var i = 0; i < cands.length; i++) {
            var c = cands[i];
            var added = false;
            for (var j = 0; j < clusters.length; j++) {
                var cl = clusters[j];
                if (nearSameSize(c, cl.avg)) {
                    cl.items.push(c);
                    var n = cl.items.length;
                    cl.avg.w = ((cl.avg.w * (n - 1)) + c.w) / n;
                    cl.avg.h = ((cl.avg.h * (n - 1)) + c.h) / n;
                    added = true;
                    break;
                }
            }
            if (!added) clusters.push({ avg: { w: c.w, h: c.h }, items: [c] });
        }
        clusters.sort(function (a, b) {
            var scoreA = a.items.length * 1000000 + (a.avg.w * a.avg.h);
            var scoreB = b.items.length * 1000000 + (b.avg.w * b.avg.h);
            return scoreB - scoreA;
        });
        return clusters;
    }

    function splitPath(p) {
        var out = [];
        var parts = String(p || "").split("/");
        for (var i = 0; i < parts.length; i++) if (parts[i] !== "") out.push(parts[i]);
        return out;
    }

    function findGroupByPath(container, path) {
        var parts = splitPath(path);
        if (!parts.length) return null;
        var current = container;
        for (var i = 0; i < parts.length; i++) {
            var found = null;
            try {
                var sets = current.layerSets;
                for (var s = 0; s < sets.length; s++) {
                    if (String(sets[s].name) === parts[i]) { found = sets[s]; break; }
                }
            } catch (e) {}
            if (!found) return null;
            current = found;
        }
        return current;
    }

    function sortReadingOrder(items) {
        if (!items || !items.length) return [];
        var avgH = 0;
        for (var i = 0; i < items.length; i++) avgH += items[i].h;
        avgH = avgH / items.length;
        var rowTol = Math.max(20, avgH * 0.45);
        var list = items.slice().sort(function (a, b) { return (a.y - b.y) || (a.x - b.x); });
        var rows = [];
        for (var j = 0; j < list.length; j++) {
            var it = list[j];
            var placed = false;
            for (var r = 0; r < rows.length; r++) {
                if (Math.abs(it.y - rows[r].y) <= rowTol) {
                    rows[r].items.push(it);
                    rows[r].y = ((rows[r].y * (rows[r].items.length - 1)) + it.y) / rows[r].items.length;
                    placed = true;
                    break;
                }
            }
            if (!placed) rows.push({ y: it.y, items: [it] });
        }
        rows.sort(function (a, b) { return a.y - b.y; });
        var out = [];
        for (var k = 0; k < rows.length; k++) {
            rows[k].items.sort(function (a, b) { return a.x - b.x; });
            for (var m = 0; m < rows[k].items.length; m++) out.push(rows[k].items[m]);
        }
        return out;
    }



    function containsCI(text, needle) {
        return String(text || "").toLowerCase().indexOf(String(needle || "").toLowerCase()) >= 0;
    }

    function leafArtChildrenUnderPath(records, pathPrefix) {
        var out = [];
        var prefix = String(pathPrefix || "") + "/";
        for (var i = 0; i < records.length; i++) {
            var r = records[i];
            if (r.kind !== "art") continue;
            if (String(r.path || "").indexOf(prefix) !== 0) continue;
            if (r.w < 35 || r.h < 35) continue;
            out.push(r);
        }
        return out;
    }

    function findBestCardBackgroundGroup(records, docArea) {
        var groupCandidates = [];
        for (var i = 0; i < records.length; i++) {
            var r = records[i];
            if (r.kind !== "group") continue;
            var n = String(r.name || "").toLowerCase();
            var p = String(r.path || "").toLowerCase();
            if (!(n.indexOf("background") >= 0 || n.indexOf("card") >= 0 || n.indexOf("box") >= 0 || p.indexOf("table background") >= 0)) continue;
            var kids = leafArtChildrenUnderPath(records, r.path);
            var filtered = [];
            for (var k = 0; k < kids.length; k++) {
                var c = kids[k];
                if (c.area < docArea * 0.002 || c.area > docArea * 0.10) continue;
                // Card/background rectangles are usually larger than the actual symbol art.
                if (c.w < 80 || c.h < 80) continue;
                filtered.push(c);
            }
            if (filtered.length >= 4) {
                groupCandidates.push({ group: r, items: filtered, score: filtered.length * 1000000 + r.area });
            }
        }
        groupCandidates.sort(function(a,b){ return b.score - a.score; });
        return groupCandidates.length ? groupCandidates[0].items : [];
    }

    function numericTextLike(r) {
        var n = String(r.name || "").replace(/\s+/g, " ").replace(/^\s+|\s+$/g, "");
        return /^[0-9,\.\s]+$/.test(n) && /[0-9]/.test(n);
    }

    function textInsideBox(textRecords, box) {
        var out = [];
        for (var i = 0; i < textRecords.length; i++) {
            var t = textRecords[i];
            var ov = overlap(t, box);
            if (ov / Math.max(1, t.area) > 0.60) out.push(t);
        }
        return out;
    }

    function unionBoxes(items) {
        if (!items || !items.length) return null;
        var x1 = items[0].x, y1 = items[0].y, x2 = items[0].x2, y2 = items[0].y2;
        for (var i = 1; i < items.length; i++) {
            var b = items[i];
            x1 = Math.min(x1, b.x); y1 = Math.min(y1, b.y); x2 = Math.max(x2, b.x2); y2 = Math.max(y2, b.y2);
        }
        return { x: x1, y: y1, w: x2 - x1, h: y2 - y1, x2: x2, y2: y2, area: (x2 - x1) * (y2 - y1) };
    }

    function main() {
        var requestedPsdPath = getGlobalString("PSHST_EXPORT_PSD_PATH", "");
        var requestedGroupPath = getGlobalString("PSHST_EXPORT_GROUP_PATH", "");
        if (requestedPsdPath) {
            var psdFile = new File(requestedPsdPath);
            if (!psdFile.exists) {
                alert("PSD file does not exist:\n" + requestedPsdPath);
                return "ERROR:PSD_NOT_FOUND";
            }
            app.open(psdFile);
        }

        if (!app.documents.length) {
            alert("Open a PSD first, then run Paytable JSON Export.");
            return "CANCELLED:NO_DOCUMENT";
        }

        var doc = app.activeDocument;
        if (!requestedPsdPath) {
            var activeName = String(doc.name || "");
            if (!/\.(psd|psb)$/i.test(activeName)) {
                alert("The active Photoshop document does not look like a PSD/PSB:\n" + activeName + "\n\nOpen the PSD/PSB template or use Browse PSD/PSB + Scan Groups. The exporter should not run on PNG/JPG render previews.");
                return "ERROR:ACTIVE_DOCUMENT_NOT_PSD";
            }
        }
        var docW = Math.round(px(doc.width));
        var docH = Math.round(px(doc.height));
        var docArea = docW * docH;

        var root = null;
        var selectedPath = "";
        var matches = [];

        // If UI supplied a selected PSD group/page, use that exact group.
        // Otherwise fall back to the first group named Paytable/paytable/PAYTABLE.
        if (requestedGroupPath) {
            root = findGroupByPath(doc, requestedGroupPath);
            selectedPath = requestedGroupPath;
            if (!root) {
                alert("Selected group was not found in this PSD:\n" + requestedGroupPath + "\n\nScan groups again and choose a valid group. The PSD was not modified.");
                return "ERROR:GROUP_NOT_FOUND";
            }
            matches.push({ group: root, path: selectedPath });
        } else {
            findPaytableGroups(doc, matches, "");
            if (!matches.length) {
                alert("No group named 'paytable' found.\n\nCreate or rename the root paytable group as Paytable/paytable/PAYTABLE, then try again.\nThe PSD was not modified.");
                return "CANCELLED:NO_PAYTABLE_GROUP";
            }
            if (matches.length > 1) {
                var msg = "Multiple groups named Paytable were found.\n\nUsing the first one found:\n" + matches[0].path + "\n\nThe PSD will not be modified.";
                alert(msg);
            }
            root = matches[0].group;
            selectedPath = matches[0].path;
        }

        var records = [];
        walk(root, 1, selectedPath || root.name, records);

        var rootBox = boxOf(root) || { x: 0, y: 0, w: docW, h: docH, x2: docW, y2: docH };

        var slots = {};
        var notes = [];

        // Title: prefer top wide text; fallback to top wide layer.
        var textLayers = [];
        for (var i = 0; i < records.length; i++) {
            var rec = records[i];
            if (rec.kind === "text") textLayers.push(rec);
        }
        textLayers.sort(function (a, b) {
            var awide = a.w / docW, bwide = b.w / docW;
            return (a.y - b.y) || (bwide - awide) || (b.area - a.area);
        });
        var title = null;
        for (var t = 0; t < textLayers.length; t++) {
            if (textLayers[t].y <= rootBox.y + rootBox.h * 0.28 && textLayers[t].w >= docW * 0.18) { title = textLayers[t]; break; }
        }
        if (!title) {
            var topWide = records.slice().sort(function (a, b) { return (a.y - b.y) || (b.w - a.w); });
            for (var tw = 0; tw < topWide.length; tw++) {
                if (topWide[tw].y <= rootBox.y + rootBox.h * 0.25 && topWide[tw].w >= docW * 0.25 && topWide[tw].h <= docH * 0.18) { title = topWide[tw]; break; }
            }
        }
        // If the selected paytable group does not contain the heading, try the whole document top text as a safe fallback.
        if (!title) {
            var docRecords = [];
            walk(doc, 1, "", docRecords);
            var docText = [];
            for (var dt = 0; dt < docRecords.length; dt++) if (docRecords[dt].kind === "text") docText.push(docRecords[dt]);
            docText.sort(function(a,b){ return (a.y - b.y) || (b.w - a.w) || (b.area - a.area); });
            for (var dti = 0; dti < docText.length; dti++) {
                if (docText[dti].y <= docH * 0.20 && docText[dti].w >= docW * 0.20) { title = docText[dti]; break; }
            }
        }
        if (title) slots["title"] = cleanSlot(title);

        // Repeated symbol slots.
        // V40: for existing production PSDs, the useful slot is usually the full card/background box,
        // not the smaller symbol artwork. Prefer repeated card/background layers when present.
        var symbolItems = findBestCardBackgroundGroup(records, docArea);

        if (!symbolItems.length) {
            var candidates = [];
            for (var c = 0; c < records.length; c++) {
                var r = records[c];
                if (r.kind === "text") continue;
                if (r.w < 35 || r.h < 35) continue;
                if (r.area < docArea * 0.001 || r.area > docArea * 0.28) continue;
                if (r.w > docW * 0.86 && r.h > docH * 0.60) continue; // likely whole bg/panel
                if (title && overlap(r, title) / Math.max(1, r.area) > 0.50) continue;
                // Prefer higher-level records so nested decoration layers do not dominate.
                if (r.immediate || r.kind === "group") candidates.push(r);
            }
            if (candidates.length < 2) {
                candidates = [];
                for (var c2 = 0; c2 < records.length; c2++) {
                    var r2 = records[c2];
                    if (r2.kind === "text") continue;
                    if (r2.w < 35 || r2.h < 35) continue;
                    if (r2.area < docArea * 0.001 || r2.area > docArea * 0.22) continue;
                    if (r2.w > docW * 0.86 && r2.h > docH * 0.60) continue;
                    if (title && overlap(r2, title) / Math.max(1, r2.area) > 0.50) continue;
                    candidates.push(r2);
                }
            }

            var clusters = clusterRepeated(candidates);
            for (var cl = 0; cl < clusters.length; cl++) {
                if (clusters[cl].items.length >= 2) { symbolItems = clusters[cl].items; break; }
            }
        }

        symbolItems = sortReadingOrder(symbolItems);
        for (var s = 0; s < symbolItems.length; s++) {
            slots["symbol." + (s + 1)] = cleanSlot(symbolItems[s]);
        }

        // Feature panel/icon/text guesses. Generic names, no WILD hardcoding.
        var used = [];
        if (title) used.push(title);
        for (var us = 0; us < symbolItems.length; us++) used.push(symbolItems[us]);

        function isUsed(r) {
            for (var u = 0; u < used.length; u++) {
                if (r.path === used[u].path) return true;
                if (overlap(r, used[u]) / Math.max(1, Math.min(r.area, used[u].area)) > 0.78) return true;
            }
            return false;
        }

        // Determine main symbol-table bounds; side panel is usually to the right of this.
        var symbolUnion = unionBoxes(symbolItems);
        var sideX = symbolUnion ? (symbolUnion.x2 + 20) : (rootBox.x + rootBox.w * 0.62);

        var rightTexts = [];
        var rightArts = [];
        for (var rn = 0; rn < records.length; rn++) {
            var rr = records[rn];
            if (isUsed(rr)) continue;
            var mostlyRight = (rr.x >= sideX || rr.x2 > rootBox.x + rootBox.w * 0.72 || rr.x > rootBox.x + rootBox.w * 0.55);
            if (!mostlyRight) continue;
            if (rr.kind === "text") rightTexts.push(rr);
            else if (rr.w >= 35 && rr.h >= 35 && rr.area >= docArea * 0.0008 && rr.area <= docArea * 0.08) rightArts.push(rr);
        }

        // Feature title: right-side top text/art with WILD/SCATTER/BONUS-like name, or simply topmost right text.
        rightTexts.sort(function(a,b){ return (a.y-b.y) || (a.x-b.x); });
        var featureTitle = null;
        for (var ft = 0; ft < rightTexts.length; ft++) {
            var nm = String(rightTexts[ft].name || "").toLowerCase();
            if (nm.indexOf("wild") >= 0 || nm.indexOf("scatter") >= 0 || nm.indexOf("bonus") >= 0) { featureTitle = rightTexts[ft]; break; }
        }
        if (!featureTitle && rightTexts.length) featureTitle = rightTexts[0];
        if (featureTitle) {
            slots["feature.title"] = cleanSlot(featureTitle);
            slots["wild.title"] = cleanSlot(featureTitle); // legacy renderer alias
            used.push(featureTitle);
        }

        // Feature icons: keep only the MAIN feature/scatter/wild artwork slots.
        // Small exception icons inside the substitution sentence must not be
        // exported as feature.icon/wild.icon, otherwise the renderer fills them
        // with the same WILD asset. Those exception icons are rendered later from
        // the Excel <icon> tokens inside feature.text.1.
        rightArts.sort(function(a,b){ return (a.y-b.y) || (a.x-b.x) || (b.area-a.area); });
        var usableRightArts = [];
        for (var ra0 = 0; ra0 < rightArts.length; ra0++) {
            var art0 = rightArts[ra0];
            if (isUsed(art0)) continue;
            if (art0.w < 45 || art0.h < 45) continue;
            usableRightArts.push(art0);
        }
        var maxIconArea = 0;
        for (var ma = 0; ma < usableRightArts.length; ma++) maxIconArea = Math.max(maxIconArea, usableRightArts[ma].area);

        var iconIndex = 1;
        var skippedExceptionIcons = [];
        for (var rai = 0; rai < usableRightArts.length && iconIndex <= 4; rai++) {
            var ia = usableRightArts[rai];
            // Keep large/main feature icons only. In real paytables the
            // exception icons are normally much smaller than the main feature
            // symbol. If the design only has small icons, maxIconArea comes from
            // them and they are still kept.
            if (maxIconArea > 0 && ia.area < maxIconArea * 0.45) {
                skippedExceptionIcons.push(ia);
                continue;
            }
            slots["feature.icon." + iconIndex] = cleanSlot(ia);
            slots["wild.icon." + iconIndex] = cleanSlot(ia); // legacy renderer alias for the same MAIN feature icon
            used.push(ia);
            iconIndex++;
        }

        // Remaining right-side text becomes feature text/bottom notes. Avoid
        // numeric payout text inside symbol boxes. Do NOT reject text simply
        // because an icon overlaps it; old PSDs often use one text layer with
        // blank spaces where exception icons sit.
        function isTextUnavailable(tr) {
            if (!tr) return true;
            if (tr.path === (featureTitle ? featureTitle.path : "")) return true;
            if (title && tr.path === title.path) return true;
            for (var su = 0; su < symbolItems.length; su++) {
                if (tr.path === symbolItems[su].path) return true;
            }
            return false;
        }

        function usefulSideText(tr) {
            if (!tr || tr.kind !== "text") return false;
            if (isTextUnavailable(tr)) return false;
            if (numericTextLike(tr)) return false;
            var nm = String(tr.name || "").replace(/^\s+|\s+$/g, "");
            if (!nm || nm === "." || nm === "," || nm === "-") return false;
            if (tr.w < 30 || tr.h < 10 || tr.area < 80) return false;
            if (symbolUnion && tr.x < sideX && overlap(tr, symbolUnion) > 0) return false;
            return (tr.x >= sideX || tr.x2 > rootBox.x + rootBox.w * 0.72 || tr.x > rootBox.x + rootBox.w * 0.55);
        }

        var remainingText = [];
        for (var rt = 0; rt < textLayers.length; rt++) {
            var tr0 = textLayers[rt];
            if (usefulSideText(tr0)) remainingText.push(tr0);
        }
        remainingText.sort(function (a, b) { return (a.y - b.y) || (a.x - b.x); });

        var featureTextIndex = 1;
        var bottomCandidates = [];
        for (var tx = 0; tx < remainingText.length; tx++) {
            var tr = remainingText[tx];
            var lname = String(tr.name || "").toLowerCase();
            var isBottom = (tr.y > rootBox.y + rootBox.h * 0.72) || lname.indexOf("all wins") >= 0 || lname.indexOf("multiplier") >= 0;
            if (isBottom) {
                bottomCandidates.push(tr);
            } else {
                slots["feature.text." + featureTextIndex] = cleanSlot(tr);
                slots["wild.text" + featureTextIndex] = cleanSlot(tr); // legacy renderer alias: wild.text1, wild.text2
                featureTextIndex++;
            }
        }
        if (bottomCandidates.length) {
            var notesBox = unionBoxes(bottomCandidates);
            slots["bottom_notes"] = cleanSlot(notesBox);
        }

        // Keep raw candidates for debugging/artist review, but renderer can ignore this.
        var raw = [];
        var maxRaw = Math.min(records.length, 300);
        for (var rw = 0; rw < maxRaw; rw++) {
            raw.push({
                name: records[rw].name,
                path: records[rw].path,
                kind: records[rw].kind,
                box: cleanSlot(records[rw])
            });
        }

        var templateId = String(doc.name || "Paytable").replace(/\.[^\.]+$/, "");
        var out = {
            template_id: templateId,
            page_type: "paytable",
            source_psd: String(doc.name || ""),
            detected_from_group: selectedPath,
            detection_note: "Auto-detected draft JSON. PSD was not modified. Review slots before production use.",
            canvas: { width: docW, height: docH },
            slots: slots,
            detection_summary: {
                total_layers_scanned_inside_paytable_group: records.length,
                symbol_slots_detected: symbolItems.length,
                card_background_detection: findBestCardBackgroundGroup(records, docArea).length,
                side_exception_icons_skipped: skippedExceptionIcons.length,
                feature_text_slots_detected: featureTextIndex - 1,
                paytable_group_matches_found: matches.length
            },
            raw_candidates: raw
        };

        var defaultName = templateId + "_Paytable_auto.json";
        var saveFile = File.saveDialog("Save detected Paytable JSON as...", "JSON:*.json");
        if (!saveFile) return "CANCELLED:SAVE_DIALOG";
        if (!/\.json$/i.test(saveFile.fsName)) saveFile = new File(saveFile.fsName + ".json");

        saveFile.encoding = "UTF-8";
        if (!saveFile.open("w")) {
            alert("Could not write JSON to:\n" + saveFile.fsName);
            return "ERROR:WRITE_FAILED";
        }
        saveFile.write(jsonStringify(out, 0));
        saveFile.close();

        alert("Paytable JSON exported.\n\nSaved to:\n" + saveFile.fsName + "\n\nDetected symbol slots: " + symbolItems.length + "\nScanned layers inside Paytable group: " + records.length + "\n\nPSD was not modified or saved.");
        return "SAVED:" + saveFile.fsName;
    }

    try {
        return main();
    } catch (err) {
        alert("Paytable JSON export failed:\n" + err);
        return "ERROR:" + err;
    }
})();
