"""canonical_png — PNG renderer adapter for the canonical pipeline.

Renders PageLayout objects to PIL pages REUSING the historical png_builder
drawing primitives (_draw_inline, _draw_background, _load_font, ...). The
layout engine has already computed wrapping, line breaks, box sizes, icon
positions and margins; this adapter never recalculates them — it only draws
exactly what the PageLayout contains.

Because the adapter uses the same drawing functions as the historical
renderer, output is pixel-identical to the legacy path for the same layout
math (proven by tests/test_canonical_parity.py).
"""

from __future__ import annotations

from typing import List, Optional

from .page_layout import Element, PageLayout, RectElement, TextElement


def _png():
    from . import png_builder

    return png_builder


def render_layout_pages(
    page_layouts: List[PageLayout],
    *,
    bg_path: str = "",
    bg_mode: str = "stretch",
    bg_color: str = "#FFFFFF",
    icon_folder: str = "",
    icon_mappings=None,
    icon_size_overrides=None,
    icon_y_offset=0,
    style_errors=None,
    table_drawer=None,
):
    """Render every PageLayout into a PIL RGBA image. Returns the image list
    in the same order as input (one image per page).

    ``style_errors`` (optional list) receives human-readable messages when an
    element's layer style required Photoshop but Photoshop was unavailable or
    the render failed — final-export callers can surface "Photoshop is
    required ..." instead of silently delivering the approximate preview.
    """
    png = _png()
    Image, ImageDraw, ImageFont = png._require_pillow()
    icon_mappings = dict(icon_mappings or {})
    icon_size_overrides = dict(icon_size_overrides or {})

    pages = []
    for layout in page_layouts:
        canvas_w = max(100, int(layout.canvas.get("width") or 1920))
        canvas_h = max(100, int(layout.canvas.get("height") or 1080))
        page = Image.new("RGBA", (canvas_w, canvas_h), (255, 255, 255, 255))
        png._draw_background(page, Image, bg_path, bg_mode, bg_color)
        draw = ImageDraw.Draw(page)
        for element in layout.elements:
            if getattr(element, "type", "") == "table":
                if table_drawer is not None:            # a table: drawn by the build (png_builder._draw_auto_table)
                    table_drawer(page, draw, element)
                continue
            _render_element(
                page, draw, Image, ImageFont, element,
                icon_folder, icon_mappings, icon_size_overrides, icon_y_offset,
                style_errors,
            )
        pages.append(page)
    return pages


def _render_element(
    page,
    draw,
    Image,
    ImageFont,
    element: Element,
    icon_folder: str,
    icon_mappings: dict,
    icon_size_overrides: dict,
    icon_y_offset=0,
    style_errors=None,
):
    png = _png()
    if isinstance(element, TextElement):
        _render_text_element(
            page, draw, Image, ImageFont, element,
            icon_folder, icon_mappings, icon_size_overrides, icon_y_offset,
            style_errors,
        )
    elif isinstance(element, RectElement):
        _render_rect_element(page, draw, element)
    else:
        # Unknown element kinds are skipped (forward compatibility).
        pass


def _render_text_element(
    page,
    draw,
    Image,
    ImageFont,
    element: TextElement,
    icon_folder: str,
    icon_mappings: dict,
    icon_size_overrides: dict,
    icon_y_offset=0,
    style_errors=None,
):
    """Draw the pre-wrapped lines of a TextElement.

    Every line is drawn with png_builder._draw_inline — the exact same
    function the legacy renderer uses for a single line, so text/icon glyph
    placement is identical. `line_spacing` between lines and per-line heights
    come from the layout; nothing is re-measured or re-wrapped.

    Elements whose layer style needs real Photoshop (see
    photoshop_style_assets.element_style_path) are rendered once in an
    isolated temporary Photoshop document and alpha-composited at the exact
    logical box below — the layout math (box, rows, wrapping) is untouched.
    When that fails, the historical PIL drawing path below runs unchanged.
    """
    png = _png()
    if not element.wrapped_lines:
        return
    from . import photoshop_style_assets as psa

    if psa.element_style_path(element) == "photoshop":
        asset_path, asset_meta = psa.render_style_asset(element)
        if asset_path and psa.composite_style_asset(page, asset_path, element, asset_meta):
            if style_errors is not None:
                style_errors.append(
                    "Photoshop rendered layer style for '{0}' ({1}); composited asset '{2}'.".format(
                        element.id or element.style_role or element.text or "element",
                        element.style_role, asset_path,
                    )
                )
            return
        if style_errors is not None:
            style_errors.append(
                "Photoshop is required to render one or more configured layer styles: "
                "element '{0}' ({1}); PIL approximation drawn instead.".format(
                    element.id or element.style_role or element.text or "element",
                    element.style_role,
                )
            )
    font = png._load_font(ImageFont, element.font, element.size, bold=element.bold, italic=element.italic)
    color = tuple(element.color) if len(element.color) >= 3 else (255, 255, 255)
    icon_h = max(1, int(element.icon_height)) if element.icon_height else 0
    line_spacing = max(0, int(element.line_spacing))
    y = element.y
    from .psd_writer import recorder as _rec

    meta = element.meta or {}
    # layer-to-cell link: the PSD's memory records which Excel row each layer shows
    from . import text_styles as _ts

    from . import ps_text as _pst

    psd_page = _rec.page_for(page)
    first_record = len(psd_page.texts) if psd_page is not None else 0
    with _rec.source(kind=meta.get("kind"), row=meta.get("row"), line=meta.get("line"), element=element.id or None),             _ts.row(element.text), _pst.tracking(meta.get("tracking") or 0):   # rules made for just this Excel row apply here
        for index, line in enumerate(element.wrapped_lines):
            line_h = element.line_heights[index] if index < len(element.line_heights) else 0
            png._draw_inline(
                page, draw, Image, line,
                element.x, y, font, color, max(1, int(element.width)),
                icon_folder, icon_mappings, icon_h, icon_size_overrides,
                align=element.align, line_spacing=line_spacing,
                fx_config=element.effects if element.effects else None,
                icon_gap_left=int(element.icon_gap_left),
                icon_gap_right=int(element.icon_gap_right),
                icon_y_offset=icon_y_offset,
                strips=False,
            )
            y += (float(line_h) if line_h else 0.0) + line_spacing
    # a text box (page_boxes): its lines (one element each, laid out like the paragraph's rows) are one
    # paragraph — one text layer in the PSD, in its box. Lines with another layer style (a line made a
    # heading) and words with a style of their own stay their own layers: a text layer has one style.
    if meta.get("kind") == "box" and psd_page is not None and len(psd_page.texts) > first_record:
        import json

        drawn = psd_page.texts[first_record:]
        records = [r for r in drawn if not getattr(r, "word_style", False)]
        del psd_page.texts[first_record:]
        boxes = psd_page.__dict__.setdefault("_box_layers", {})
        for rec in records:
            key = (meta.get("box"), json.dumps(rec.fx_config or {}, sort_keys=True, default=str))
            merged = boxes.get(key)
            if merged is not None and merged in psd_page.texts:
                merged.lines.extend(rec.lines)
                continue
            frame = meta.get("frame") or {}
            rec.box = (float(frame.get("x", element.x)), float(frame.get("w", element.width)))
            boxes[key] = rec
            psd_page.texts.append(rec)
        psd_page.texts.extend(r for r in drawn if getattr(r, "word_style", False))
        for rec in boxes.values():
            rec.name = "Text box " + " ".join(rec.text.split())[:50]


def _render_rect_element(page, draw, element: RectElement):
    """Filled/stroked rectangle — mirrors the historical text-rectangle cell
    drawing (fill opacity via overlay alpha-composite, stroke outline)."""
    from PIL import Image, ImageDraw

    meta = element.meta or {}
    if meta.get("strip"):
        # a line strip (text_styles): rounded, and its own shape layer in the PSD
        from . import text_styles

        rgb = tuple(int(v) for v in element.fill_rgb[:3])
        rule = dict(meta.get("look") or {"radius": meta.get("radius", 6)},   # corners, border, layer style
                    text=meta.get("text") or "strip", color="#%02x%02x%02x" % rgb, opacity=element.fill_opacity)
        text_styles.draw_strip(page, rule, (element.x, element.y, element.width, element.height))
        return
    left, top = float(element.x), float(element.y)
    if element.fill_opacity > 0 and element.width > 0 and element.height > 0:
        overlay = Image.new("RGBA", (max(1, int(element.width)), max(1, int(element.height))), (0, 0, 0, 0))
        overlay_d = ImageDraw.Draw(overlay)
        alpha = int(255 * max(0.0, min(1.0, element.fill_opacity)))
        fill = tuple(int(v) for v in element.fill_rgb[:3])
        overlay_d.rectangle([0, 0, overlay.width - 1, overlay.height - 1], fill=(*fill, alpha))
        try:
            draw.base.alpha_composite(overlay, (int(round(left)), int(round(top))))
        except (AttributeError, TypeError):
            page.paste(overlay, (int(round(left)), int(round(top))), overlay)
    if element.stroke_width > 0 and element.width > 0 and element.height > 0:
        stroke = tuple(int(v) for v in element.stroke_rgb[:3])
        draw.rectangle(
            [left, top, left + float(element.width), top + float(element.height)],
            outline=stroke, width=max(1, int(element.stroke_width)),
        )