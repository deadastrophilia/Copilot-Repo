"""live_layout_adapter — live preview adapter for the canonical pipeline.

The live preview becomes a VIEWER of PageLayout instead of an independent
renderer. This module:

  1. Builds the canonical page layouts for a sheet (the same PageLayouts the
     PNG and Photoshop renderers consume).
  2. Applies user edits (position / scale / rotation / opacity from
     config.dynamic_settings.live_overrides[sheet][element_id]) as a
     TRANSFORM on a copy of the layout.
  3. Serializes the result as the payload the frontend viewer draws — and the
     same transformed PageLayout can be handed to the PNG / Photoshop
     adapters for a real render, so every renderer sees the identical layout.

The frontend never mutates layout math: it only reports edits; the server
re-computes/transforms the PageLayout, keeping the single source of truth.
"""

from __future__ import annotations

import os

from typing import Any, Dict, List, Optional

from .config import canonical_layout_enabled
from .page_layout import PageLayout


def _png():
    from . import png_builder

    return png_builder


def _safe_float(value, fallback: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return float(fallback)


def _safe_int(value, fallback: int = 0) -> int:
    try:
        return int(float(value))
    except Exception:
        return int(fallback)


# ---------------------------------------------------------------------------
# Live-override transforms
# ---------------------------------------------------------------------------


def element_live_overrides(cfg: dict, sheet_name: str, element_id: str) -> dict:
    """Return the stored live-override dict for one element (or {})."""
    dynamic = cfg.get("dynamic_settings") or {}
    sheet_map = dynamic.get("live_overrides") or {}
    return dict(sheet_map.get(str(sheet_name), {}).get(str(element_id)) or {})


def apply_live_overrides(layout: PageLayout, overrides_map: Optional[dict] = None, extra: Optional[dict] = None) -> PageLayout:
    """Return a NEW PageLayout with user edits applied to element geometry.

    Supported override keys (all optional, mirroring the LIVE canvas):
      x / y        absolute position (page px)
      sx / sy      scale factors (multiply width/height)
      rot          rotation in degrees
      opacity      0..1 multiply

    The input layout/overrides are never mutated.
    """
    transformed = PageLayout.from_dict(layout.to_dict())
    for element in transformed.elements:
        ov = dict(extra or {})
        if overrides_map is not None:
            ov.update(dict(overrides_map.get(element.id) or {}))
        if not ov:
            continue
        if "x" in ov:
            element.x = _safe_float(ov.get("x"), element.x)
        if "y" in ov:
            element.y = _safe_float(ov.get("y"), element.y)
        if "sx" in ov:
            try:
                element.width = float(element.width) * float(ov.get("sx"))
            except Exception:
                pass
        if "sy" in ov:
            try:
                element.height = float(element.height) * float(ov.get("sy"))
            except Exception:
                pass
        if "rot" in ov:
            try:
                element.rotation = float(ov.get("rot"))
            except Exception:
                pass
        if "opacity" in ov:
            try:
                element.opacity = max(0.0, min(1.0, float(ov.get("opacity"))))
            except Exception:
                pass
    return transformed


# ---------------------------------------------------------------------------
# High-level payload builder (used by /api/layout/preview and the LIVE UI)
# ---------------------------------------------------------------------------


def build_sheet_layouts_from_cfg(cfg: dict, sheet_name: str, measure_layer=None, font_cache=None):
    """High-level canonical layout build for one sheet from the app config.

    Returns list[PageLayout] or None when the sheet is not canonicalizable
    (feature-gated off, special page kind, tables present, etc.).
    """
    from .layout_engine import build_sheet_layouts

    if not canonical_layout_enabled():
        return None
    excel_path = str(cfg.get("excel_path") or "")
    sheet_name = str(sheet_name or "").strip()
    if not excel_path or not os.path.isfile(excel_path) or not sheet_name:
        return None
    from . import rules_layout

    if rules_layout.rules_kind(sheet_name):
        return None                                      # their own renderer lays them out (rules_layout.py)
    from . import workbook_cache

    # the parsed workbook is shared between previews (one parse per file version): parsing it
    # was ~90% of every preview, edit and page switch
    try:
        with workbook_cache.borrow(excel_path, data_only=False) as wb:
            if sheet_name not in wb.sheetnames:
                # an Excel sheet named with a space at the end ("JACKPOT CARNIVAL BONUS 1 "): the name
                # arrives trimmed — its page fell back to the old layout, which ignored the alignment
                sheet_name = next((n for n in wb.sheetnames if n.strip() == sheet_name), None)
                if sheet_name is None:
                    return None
            ws = wb[sheet_name]
            _ls_raw = cfg.get("line_spacing")
            # The icon-spacing fields live on the top-level config; the build folds
            # them into dynamic_settings (engine_api._merged_dynamic_settings), so
            # the preview must too or it lays icons out with the 15px default.
            _dyn = dict(cfg.get("dynamic_settings") or {})
            if cfg.get("heading_icon_gap") not in (None, ""):
                _dyn.setdefault("heading_icon_gap", cfg.get("heading_icon_gap"))
            for _k in ("heading_icon_gap_left", "heading_icon_gap_right", "icon_gap_left", "icon_gap_right"):
                if cfg.get(_k) not in (None, ""):
                    _dyn[_k] = cfg.get(_k)
            _lg_raw = cfg.get("line_gap")
            # the fonts as the build asks for them: the family WITH its style ("Arial|Black"), or the
            # Canvas lays text out in the plain face and draws it in the (wider) styled one
            from .ui_web.engine_api import _font_request

            return build_sheet_layouts(
                ws,
                sheet_name,
                canvas_w=_safe_int(cfg.get("c_width"), 1920),
                canvas_h=_safe_int(cfg.get("c_height"), 1080),
                margin_x=_safe_int(cfg.get("margin_x"), 100),
                h_font=_font_request(str(cfg.get("h_font") or "Arial"), cfg.get("h_font_style", "regular")) or "Arial",
                h_size=_safe_int(cfg.get("h_size"), 72),
                h_icon_h=_safe_int(cfg.get("h_icon_h"), 48),
                h_rgb=cfg.get("h_rgb"),
                b_font=_font_request(str(cfg.get("b_font") or "Arial"), cfg.get("b_font_style", "regular")) or "Arial",
                b_size=_safe_int(cfg.get("b_size"), 30),
                b_icon_h=_safe_int(cfg.get("b_icon_h"), 24),
                b_rgb=cfg.get("b_rgb"),
                line_spacing=_ls_raw if _ls_raw not in (None, "") else 1.1,
                para_spacing=_safe_int(cfg.get("para_spacing"), 12),
                line_gap=None if _lg_raw in (None, "") else _safe_int(_lg_raw, 0),
                heading_top_margin=_safe_int(cfg.get("heading_top_margin"), 120),
                heading_to_body_gap=_safe_int(cfg.get("heading_to_body_gap"), 40),
                bottom_margin=_safe_int(cfg.get("bottom_margin"), 80),
                max_col_limit=_safe_int(cfg.get("max_col_limit"), 12),
                icon_folder=str(cfg.get("icon_folder") or ""),
                icon_mappings=cfg.get("icon_mappings") or {},
                icon_size_overrides=cfg.get("icon_size_overrides") or {},
                dynamic_settings=_dyn,
                page_overrides=cfg.get("page_overrides") or {},
                alignment_settings=cfg.get("alignment_settings") or {},
                heading_image_folder=str((cfg.get("alignment_settings") or {}).get("heading_image_folder") or ""),
                measure_layer=measure_layer,
                font_cache=font_cache,
                inner_canvas_width=_safe_int(cfg.get("inner_canvas_width"), 0),
                continued_gap=_safe_int(cfg.get("continued_gap"), 15),
                icon_y_offset=_safe_int(cfg.get("icon_y_offset"), 0),
                table_style=cfg.get("table_style") or {},
            )
    except Exception:
        return None


def layout_payload_for_sheet(
    cfg: dict,
    sheet_name: str,
    apply_overrides: bool = True,
    include_images: bool = False,
    register_preview=None,
):
    """Build the canonical layout payload for the live preview.

    Returns a dict:
        {"ok": True, "sheet_name": ..., "mode": "canonical"|"legacy",
         "use_canonical_layout": bool, "layouts": [PageLayout dicts],
         "canvas": {...}, "live_overrides": [...known element ids...]}
    or
        {"ok": False, "error": "..."} when the sheet cannot be canonicalized
        (the live preview then falls back to its current independent render).
    """
    from .layout_engine import make_measure_layer
    from .page_layout import PageLayout

    sheet_name = str(sheet_name or "").strip()
    try:
        measure_layer, font_cache = None, {}
        try:
            measure_layer = make_measure_layer_from_cfg(cfg, make_measure_layer)
        except Exception:
            measure_layer = None
        layouts = build_sheet_layouts_from_cfg(cfg, sheet_name, measure_layer=measure_layer, font_cache=font_cache)
    except Exception as exc:
        return {"ok": False, "error": f"Canonical layout failed: {exc}"}

    if not layouts:
        return {
            "ok": True,
            "sheet_name": sheet_name,
            "mode": "legacy",
            "use_canonical_layout": canonical_layout_enabled(),
            "layouts": [],
        }

    dynamic = cfg.get("dynamic_settings") or {}
    overrides_map = (dynamic.get("live_overrides") or {}).get(sheet_name) or {}

    # a table's picture (as the layout measured it): saved for the canvas to draw (/api/table_preview)
    for layout in layouts:
        for el in layout.elements:
            pic = getattr(el, "image", None)
            if getattr(el, "type", "") != "table" or pic is None or not callable(register_preview):
                continue
            try:
                import tempfile
                import uuid

                work = os.path.join(tempfile.gettempdir(), "psh_table_previews")
                os.makedirs(work, exist_ok=True)
                path = os.path.join(work, f"{uuid.uuid4().hex}.png")
                pic.save(path, "PNG")
                token = register_preview(path) or ""
                el.meta["url"] = f"/api/table_preview/{token}" if token else ""
            except Exception:
                el.meta["url"] = ""

    final_layouts = []
    for index, layout in enumerate(layouts):
        final = apply_live_overrides(layout, overrides_map) if apply_overrides else layout
        final_layouts.append(final.to_dict())
    # a text box with a font of its own: the font file the canvas loads to draw it
    for lay in final_layouts:
        for el in lay.get("elements") or []:
            meta = el.get("meta") or {}
            if meta.get("kind") == "box":
                try:
                    from visualiser.visualiser_data import resolve_font_file

                    meta["font_file"] = resolve_font_file(el.get("font"), bold=bool(el.get("bold")), italic=bool(el.get("italic"))) or ""
                except Exception:
                    meta["font_file"] = ""

    canvas = final_layouts[0].get("canvas") if final_layouts else {}
    return {
        "ok": True,
        "sheet_name": sheet_name,
        "mode": "canonical",
        "use_canonical_layout": canonical_layout_enabled(),
        "layouts": final_layouts,
        "canvas": canvas,
        "live_overrides": sorted(set(overrides_map.keys())),
    }


def make_measure_layer_from_cfg(cfg: dict, make_measure_layer):
    """Best-effort Photoshop MeasureLayer for the current session.

    Only used when a Photoshop document is already open; every failure falls
    back to Pillow measurement inside the layout engine.
    """
    if not cfg.get("psd_path"):
        return None
    try:
        import photoshop.api as ps

        app = ps.Application()
        doc = app.activeDocument
    except Exception:
        return None
    try:
        return make_measure_layer(doc)
    except Exception:
        return None


def layout_editor_payload(cfg: dict, sheet_name: str):
    """Lightweight viewer payload: element inventory + edit targets.

    Keeps the frontend free of layout math: it just paints the elements and
    POSTs edits back; the server re-applies them through PageLayout.
    """
    payload = layout_payload_for_sheet(cfg, sheet_name, apply_overrides=True)
    if not payload.get("ok"):
        return payload
    inventory = []
    for layout_dict in payload.get("layouts") or []:
        for element in layout_dict.get("elements") or []:
            inventory.append(
                {
                    "id": element.get("id"),
                    "type": element.get("type"),
                    "x": element.get("x"),
                    "y": element.get("y"),
                    "width": element.get("width"),
                    "height": element.get("height"),
                    "rotation": element.get("rotation"),
                    "opacity": element.get("opacity"),
                    "style_role": element.get("style_role"),
                }
            )
    payload["elements"] = inventory
    return payload