"""Rows the artist told the tool to treat as a heading or a subheading (right-click a row on a preview).

Stored in the session as ``dynamic_settings.row_roles``::

    {"<sheet>": {"row:12": "heading",       # drawn like the page heading (font, size, colour, style)
                 "row:15": "subheading"}}   # drawn like a subheading (Typography › Subheadings)

A role row stays in the page's flow exactly where the Excel row is — it only changes how its text
looks; "body" (or no entry) is normal text. Every renderer (the builds, the live window, the
canonical layout) asks ``role``, so the preview and the PSD can never disagree.
"""
import re
import threading

_LOCK = threading.Lock()
_ROLES = {}
_SUB = {}
ROLES = ("heading", "subheading")


def set_all(dynamic_settings):
    """Use these roles (and the subheading look) from now on — the server and every build call this."""
    ds = dynamic_settings if isinstance(dynamic_settings, dict) else {}
    clean = {}
    for sheet, items in (ds.get("row_roles") or {}).items() if isinstance(ds.get("row_roles"), dict) else ():
        if isinstance(items, dict):
            # a whole row: heading / subheading; one of its lines ("row:N|text") may also be normal text
            rows = {str(k): str(v) for k, v in items.items() if str(v) in ROLES or ("|" in str(k) and str(v) == "body")}
            if rows:
                clean[str(sheet)] = rows
    with _LOCK:
        _ROLES.clear()
        _ROLES.update(clean)
        _SUB.clear()
        _SUB.update({k: ds.get(k) for k in ("subheading_font_request", "subheading_font", "subheading_font_style",
                                            "subheading_size", "subheading_rgb", "continued_font",
                                            "continued_font_style", "continued_size", "continued_rgb",
                                            "continued_align", "continued_body_gap")})
        try:
            from . import png_builder as png

            _lib, _sas = ds.get("layer_style_library") or {}, ds.get("style_assignments") or {}
            _SUB["fx"] = png._resolve_fx_config(_lib, _sas, "Subheading text")
            _SUB["cont_fx"] = png._resolve_fx_config(_lib, _sas, "Continued text")
        except Exception:
            _SUB["fx"] = _SUB["cont_fx"] = None


def continued_look(heading_font, heading_size, body_rgb):
    """The "(Continued)" line of pages 2+ (Typography › Continued): font, size, bold, italic, rgb, fx.
    Defaults: the heading font, regular, 38 % of the heading size, the paragraph colour, no style."""
    from . import png_builder as png

    from . import fontfaces

    raw = _SUB.get("continued_font_style")
    style = str(raw or "regular").casefold()
    size = png._safe_int(_SUB.get("continued_size"), 0)
    font = str(_SUB.get("continued_font") or heading_font)
    face = fontfaces.is_face_style(raw)                  # a face from the font's own style menu: exactly it
    if face:
        font = fontfaces.request(font.split("|")[0], raw)
    return {
        "font": font,
        "size": size if size > 0 else max(12, int(png._safe_int(heading_size, 48) * 0.38)),
        "bold": "bold" in style and not face, "italic": "italic" in style and not face,
        "rgb": png._rgb(_SUB.get("continued_rgb"), png._rgb(body_rgb, (255, 255, 255))),
        "fx": _SUB.get("cont_fx"),
    }


def continued_align(heading_align):
    """Where the "(Continued)" line sits (Typography › Continued › align): its own, else the heading's."""
    al = str(_SUB.get("continued_align") or "").strip().casefold()
    return al if al in ("left", "center", "right") else heading_align


def continued_body_gap(default):
    """The gap from "(Continued)" down to the text (its guide on the Canvas); None when not set —
    then the page keeps the old spacing (and never starts above the Heading–Body Gap)."""
    from . import png_builder as png

    raw = _SUB.get("continued_body_gap")
    if raw is None or str(raw).strip() == "":
        return None
    return max(0, png._safe_int(raw, default))


# an Excel's own "continued" note: (Cont.), Continued, CONTINUED, (cont'd), - Contd -, ...
_CONT_WORDS = {"cont", "contd", "continue", "continued", "ctd"}
_CONT_WORD = r"(?:cont(?:inued|inue|'d|’d|d)?|ctd)[.…]*"          # "continued.." or "continued…" (one character)
# at the end of a heading only in brackets or after a dash / colon: "FREE SPINS CONTINUE" stays as it is
_CONT_TAIL = re.compile(r"\s*(?:[(\[]\s*" + _CONT_WORD + r"\s*[)\]]|[\-–—:,]\s*" + _CONT_WORD + r")[\s™®©]*$", re.I)
# a bare trailing word ("XYZ CONTINUED", "XYZ Cont.") — only the unmistakable spellings
_CONT_BARE = re.compile(r"\s+(?:continued|cont'd|cont’d|contd|cont\.+)[.…]*[\s™®©]*$", re.I)


def split_heading_continued(text):
    """Remove a trailing "continued" marker from a page heading: "(continued..)", "(Cont.)", "[cont]",
    "- Continued", ": continued", or a bare "CONTINUED". Returns (clean heading, had marker).
    A heading that is only the marker, or has "continued" inside the title, is left alone."""
    raw = str(text or "")
    for rx in (_CONT_TAIL, _CONT_BARE):
        m = rx.search(raw)
        if m and m.start() > 0:
            clean = raw[:m.start()].rstrip(" 	-–—:,")
            if clean.strip() and not is_continued_note(clean):
                return clean, True
    return raw, False


def is_continued_note(text):
    """True for a row that only says the page goes on ("(Cont.)", "CONTINUED", "(cont'd)", ...)."""
    raw = str(text or "").strip()
    return 0 < len(raw) <= 24 and re.sub(r"[^a-z]", "", raw.casefold()) in _CONT_WORDS


def continued_from_excel(heading_text, text_of, heading_row, last_row):
    """The Excel's own "continued" note right after the page heading — a row of its own, or the end of
    the heading ("FEATURES (CONTINUED)"). The tool drops it and draws its own "(Continued)" line
    (Typography › Continued) instead, so every Continued page looks the same.

    ``text_of(row)`` gives a row's text. Returns (heading text without the note, the note's row or
    None, whether the page is a continued one)."""
    heading = str(heading_text or "")
    clean, had = split_heading_continued(heading)
    if had:
        return clean, None, True
    for row in range(int(heading_row or 0) + 1, int(last_row or 0) + 1):
        text = str(text_of(row) or "").strip()
        if text:
            return heading, (row if is_continued_note(text) else None), is_continued_note(text)
    return heading, None, False


def subheading_style():
    """(bold, italic) of a subheading row — Typography › Subheading style; bold until a style is picked."""
    from . import fontfaces

    raw = _SUB.get("subheading_font_style")
    if fontfaces.is_face_style(raw):                     # a face from the font's style menu: named in the font
        return False, False
    style = str(raw or "").casefold()
    if not style:
        return True, False
    return "bold" in style, "italic" in style


def subheading_fx():
    """The subheading layer style (Typography › Subheadings), or None."""
    return _SUB.get("fx")


def key_of(row):
    """The settings key of a row: an Excel row number -> "row:12"; a text box's words are keyed
    "box:<id>" (a box is laid out like one row of the paragraph, so it takes everything a row does)."""
    return row if isinstance(row, str) else f"row:{int(row)}"


def role(sheet, row_idx):
    """'heading', 'subheading' or '' (normal text) for this Excel row (or text box, by its key)."""
    return _ROLES.get(str(sheet), {}).get(key_of(row_idx), "")


def segments(sheet, row_idx, text):
    """[(text, role)] — the row in parts when the artist made one of its drawn lines a heading /
    subheading on its own ("row:12|<that line's text>": just that text, the rest keeps the row's
    role); [(text, role(row))] otherwise. A line whose text the row no longer holds is ignored."""
    from . import page_boxes

    base = role(sheet, row_idx)
    pre = key_of(row_idx) + "|"
    spans = []
    for key, r in (_ROLES.get(str(sheet)) or {}).items():
        if key.startswith(pre):
            sp = page_boxes.find(text, key[len(pre):])
            if sp and not any(a < sp[1] and sp[0] < b for a, b, _r in spans):
                spans.append((sp[0], sp[1], r))
    if not spans:
        return [(text, base)]

    def _kept(part, lead, tail):
        # the row's own text keeps its empty lines (space typed on the Canvas); the one line break
        # between it and a line with a role of its own is not an empty line
        part = part.strip(" \t")
        if lead:
            part = re.sub(r"^\n[ \t]*", "", part, count=1)
        if tail:
            part = re.sub(r"[ \t]*\n$", "", part, count=1)
        return part.strip(" \t")

    out, at = [], 0
    for a, b, r in sorted(spans):
        if text[at:a].strip():
            out.append((_kept(text[at:a], bool(out), True), base))
        out.append((text[a:b].strip(), "" if r == "body" else r))
        at = b
    if text[at:].strip():
        out.append((_kept(text[at:], True, False), base))
    return out


def subheading_look(heading_font, heading_size, heading_rgb, body_icon_h):
    """(font name, size, rgb, icon height) of a subheading row — the build's section-subheading look."""
    from . import png_builder as png

    name = str(_SUB.get("subheading_font_request") or _SUB.get("subheading_font") or heading_font)
    from . import fontfaces

    if fontfaces.is_face_style(_SUB.get("subheading_font_style")):
        name = fontfaces.request(name.split("|")[0], _SUB.get("subheading_font_style"))
    size = max(8, png._safe_int(_SUB.get("subheading_size"), max(8, int(png._safe_int(heading_size, 48) * 0.65))))
    rgb = png._rgb(_SUB.get("subheading_rgb"), png._rgb(heading_rgb, (255, 80, 80)))
    icon_h = max(1, max(png._safe_int(body_icon_h, size), size))
    return str(name), size, rgb, icon_h
