"""Crash-safe JSON files: atomic writes, rotating backups, recovery on load.

A plain ``open(path, "w")`` empties the file first, so a crash, a full disk or
an exception half-way through ``json.dump`` leaves a truncated file behind.
``write_json`` writes a temp file next to the target and swaps it in with
``os.replace`` (atomic on Windows and POSIX), retrying briefly when another
process (antivirus, cloud sync, a second app window) holds the file.

``snapshot`` keeps timestamped copies in a backups folder (throttled, oldest
pruned) and ``read_json_recover`` falls back to ``.bak`` and those copies when
the main file is unreadable, moving the bad file aside instead of losing it.
"""
import glob
import json
import os
import shutil
import threading
import time

_RETRIES = 6


def write_json(path, data, indent=2):
    """Write `data` to `path` atomically; raises on failure (nothing half-written)."""
    path = os.path.abspath(path)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = f"{path}.{os.getpid()}.{threading.get_ident()}.tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=indent)
            f.flush()
            os.fsync(f.fileno())
        for attempt in range(_RETRIES):
            try:
                os.replace(tmp, path)
                return path
            except PermissionError:
                if attempt == _RETRIES - 1:
                    raise
                time.sleep(0.05 * (attempt + 1))
    finally:
        if os.path.exists(tmp):
            try:
                os.remove(tmp)
            except OSError:
                pass
    return path


def read_json(path):
    """Parse `path` (tolerates a UTF-8 BOM); raises when missing or invalid."""
    with open(path, "r", encoding="utf-8-sig") as f:
        return json.load(f)


def _readable(path):
    try:
        read_json(path)
        return True
    except Exception:
        return False


def backup_dir(path):
    stem = os.path.splitext(os.path.basename(path))[0]
    return os.path.join(os.path.dirname(os.path.abspath(path)), "PsHelpScreenTool_Backups", stem)


def list_backups(path):
    """Timestamped copies of `path`, newest first."""
    stem = os.path.splitext(os.path.basename(path))[0]
    return sorted(glob.glob(os.path.join(backup_dir(path), f"{stem}_*.json")), reverse=True)


def snapshot(path, keep=20, min_interval=600):
    """Copy the current (valid) `path` into its backups folder.

    At most one copy per `min_interval` seconds, `keep` newest kept. Returns
    the new copy's path, or "" when nothing was copied.
    """
    if not os.path.isfile(path) or not _readable(path):
        return ""
    existing = list_backups(path)
    if existing and time.time() - os.path.getmtime(existing[0]) < min_interval:
        return ""
    stem = os.path.splitext(os.path.basename(path))[0]
    dest = os.path.join(backup_dir(path), f"{stem}_{time.strftime('%Y%m%d-%H%M%S')}.json")
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    shutil.copy2(path, dest)
    for old in list_backups(path)[keep:]:
        try:
            os.remove(old)
        except OSError:
            pass
    return dest


def keep_previous(path):
    """Copy a valid `path` to `path.bak` (the version before this save)."""
    if os.path.isfile(path) and _readable(path):
        shutil.copy2(path, path + ".bak")


def read_json_recover(path):
    """Load `path`, falling back to `.bak` then the newest valid backup.

    Returns (data, note). data is None when there is nothing to load; note is
    "" for a normal load, otherwise a sentence saying what was recovered. A
    file that exists but cannot be parsed is renamed to `*.corrupt-<time>.json`
    so the next save cannot overwrite the only copy of the user's work.
    """
    if not os.path.isfile(path):
        return None, ""
    try:
        return read_json(path), ""
    except Exception as exc:
        problem = exc
    aside = f"{os.path.splitext(path)[0]}.corrupt-{time.strftime('%Y%m%d-%H%M%S')}.json"
    try:
        os.replace(path, aside)
    except OSError:
        aside = ""
    for candidate in [path + ".bak"] + list_backups(path):
        try:
            data = read_json(candidate)
        except Exception:
            continue
        note = f"{os.path.basename(path)} could not be read ({problem}); restored from {candidate}."
        if aside:
            note += f" The unreadable file was kept as {aside}."
        return data, note
    note = f"{os.path.basename(path)} could not be read ({problem}) and no backup was usable."
    if aside:
        note += f" It was kept as {aside}."
    return None, note
