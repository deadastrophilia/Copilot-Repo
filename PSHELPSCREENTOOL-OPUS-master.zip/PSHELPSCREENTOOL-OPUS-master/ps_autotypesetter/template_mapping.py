"""Artist-facing model for mapping Excel content to exported PSD slots."""

import copy
import json
import os
import re
from collections import OrderedDict

from openpyxl import load_workbook

from .dynamic_pages.paytable.flow_sources import resolve_source_blocks


_TOKEN = re.compile(r"<\s*([^>]+?)\s*>")
_NUMBER = re.compile(r"^[-+]?\d+(?:,\d{3})*(?:\.\d+)?$")


def load_base_template(path):
    path = os.path.abspath(os.path.expanduser(str(path or "")))
    if not os.path.isfile(path):
        raise FileNotFoundError(f"Template JSON not found:\n{path}")
    with open(path, "r", encoding="utf-8") as handle:
        template = json.load(handle)
    canvas = template.get("canvas") or {}
    slots = template.get("slots") or {}
    if not isinstance(slots, dict) or not slots:
        raise ValueError("The selected JSON does not contain exported PSD slots.")
    if not canvas.get("width") or not canvas.get("height"):
        raise ValueError("The selected JSON needs canvas width and height.")
    return template


def workbook_sheet_names(path):
    workbook = load_workbook(path, data_only=False, read_only=False)
    try:
        return list(workbook.sheetnames)
    finally:
        workbook.close()


def _tokens(text):
    return [token.strip() for token in _TOKEN.findall(str(text or ""))]


def _row_kind(values, tokens):
    if tokens and sum(1 for value in values if _NUMBER.fullmatch(value)) >= 2:
        return "payout"
    if tokens:
        return "flow"
    return "text"


def _defined_name_items(workbook, worksheet):
    names = OrderedDict()
    for container in (getattr(worksheet, "defined_names", None), getattr(workbook, "defined_names", None)):
        if container is None:
            continue
        try:
            keys = list(container.keys())
        except Exception:
            keys = []
        for name in keys:
            if str(name).casefold() not in {key.casefold() for key in names}:
                names[str(name)] = None
    return list(names.keys())


def scan_excel_content(path, sheet_name, max_column=15, include_numeric=False):
    """Return artist-readable row blocks and defined-name blocks."""
    workbook = load_workbook(path, data_only=False, read_only=False)
    try:
        if sheet_name not in workbook.sheetnames:
            raise ValueError(f"Excel sheet not found: {sheet_name}")
        worksheet = workbook[sheet_name]
        max_column = max(1, min(int(max_column or worksheet.max_column), worksheet.max_column))
        blocks = []

        for row_number in range(1, worksheet.max_row + 1):
            values = []
            populated = []
            cells = []
            for column_number in range(1, max_column + 1):
                value = worksheet.cell(row=row_number, column=column_number).value
                text = "" if value is None else str(value).strip()
                if not text:
                    continue
                values.append(text)
                populated.append(column_number)
                cell_source = f"{worksheet.cell(row=row_number, column=column_number).column_letter}{row_number}"
                cells.append({
                    "source": cell_source,
                    "label": cell_source,
                    "text": text,
                    "tokens": _tokens(text),
                    "kind": _row_kind([text], _tokens(text)),
                    "row": row_number,
                    "column": column_number,
                })
            if not values:
                continue
            numeric_only = all(_NUMBER.fullmatch(value) for value in values)
            if numeric_only and not include_numeric:
                continue
            start_col = worksheet.cell(row=row_number, column=min(populated)).column_letter
            end_col = worksheet.cell(row=row_number, column=max(populated)).column_letter
            source = f"{start_col}{row_number}:{end_col}{row_number}"
            text = " ".join(values).strip()
            token_values = _tokens(text)
            blocks.append({
                "id": f"row:{row_number}",
                "source": source,
                "label": f"Row {row_number}",
                "text": text,
                "tokens": token_values,
                "cells": cells,
                "kind": _row_kind(values, token_values),
                "row": row_number,
            })

        for name in _defined_name_items(workbook, worksheet):
            name_blocks, warning = resolve_source_blocks(worksheet, name, preserve_rows=True)
            if warning or not name_blocks:
                continue
            text = " | ".join(block["text"] for block in name_blocks)
            token_values = _tokens(text)
            blocks.append({
                "id": f"name:{name}",
                "source": name,
                "label": f"Named: {name}",
                "text": text,
                "tokens": token_values,
                "kind": "flow" if token_values else "text",
                "row": 100000,
            })
        return blocks
    finally:
        workbook.close()


def extract_existing_mappings(template):
    """Flatten mapper-compatible flow regions and token bindings for the UI."""
    mappings = []
    flow_regions = template.get("flow_regions") or {}
    if isinstance(flow_regions, dict):
        region_items = [(region_id, value) for region_id, value in flow_regions.items() if isinstance(value, dict)]
    elif isinstance(flow_regions, list):
        region_items = [(value.get("id", f"region_{index}"), value) for index, value in enumerate(flow_regions, start=1) if isinstance(value, dict)]
    else:
        region_items = []

    for region_id, region in region_items:
        sources = region.get("sources", region.get("source", []))
        if isinstance(sources, str):
            sources = [sources]
        for source in sources if isinstance(sources, (list, tuple)) else []:
            source_ref = source.get("source") if isinstance(source, dict) else source
            padding = region.get("padding", [0, 0, 0, 0])
            if isinstance(padding, (int, float)):
                padding = [int(padding)] * 4
            elif not isinstance(padding, (list, tuple)):
                padding = [0, 0, 0, 0]
            mappings.append({
                "kind": "flow",
                "source": str(source_ref or ""),
                "slot": str(region.get("slot") or region_id),
                "render_mode": str(region.get("render_mode") or "inline_flow"),
                "font_size": int(region.get("font_size", 30)),
                "minimum_font_size": int(region.get("minimum_font_size", region.get("min_font_size", 20))),
                "emergency_minimum_font_size": int(region.get("emergency_minimum_font_size", 6)),
                "icon_height": int(region.get("icon_height", 48)),
                "gap": int(region.get("gap", region.get("block_gap", 18))),
                "minimum_gap": int(region.get("minimum_gap", region.get("min_gap", 8))),
                "padding": list(padding),
                "vertical_align": str(region.get("vertical_align") or "top"),
                **_style_fields_from(region),
            })

    for binding in template.get("token_bindings") or []:
        if not isinstance(binding, dict):
            continue
        mappings.append({
            "kind": "token",
            "source": str(binding.get("source") or ""),
            "slot": str(binding.get("slot") or ""),
            "token_index": int(binding.get("token_index", 0)),
            "token": str(binding.get("token") or ""),
            "max_height": int(binding.get("max_height", 0) or 0),
            **_style_fields_from(binding),
        })
    for override in template.get("inline_icon_overrides") or []:
        if not isinstance(override, dict):
            continue
        mappings.append({
            "kind": "inline_token",
            "source": str(override.get("source") or ""),
            "slot": str(override.get("slot") or ""),
            "token_index": int(override.get("token_index", 0)),
            "token": str(override.get("token") or ""),
            "icon_height": int(override.get("icon_height", 0) or 0),
            **_style_fields_from(override),
        })
    return mappings


def _region_id(slot, index):
    cleaned = re.sub(r"[^A-Za-z0-9_-]+", "_", str(slot or "region")).strip("_")
    return cleaned or f"region_{index}"


def _style_fields_from(mapping):
    fields = {}
    for key in (
            "color",
            "background_color",
            "opacity",
            "fill_enabled",
            "stroke_enabled",
            "stroke_color",
            "stroke_width"):
        if key in mapping:
            fields[key] = mapping.get(key)
    return fields


def validate_mappings(template, mappings):
    slots = {str(name).casefold() for name in (template.get("slots") or {})}
    flow_pairs = {
        (str(mapping.get("source") or "").strip().casefold(), str(mapping.get("slot") or "").strip().casefold())
        for mapping in mappings
        if mapping.get("kind") == "flow"
    }
    warnings = []
    errors = []
    seen_tokens = set()
    primary_slots = {}
    for index, mapping in enumerate(mappings, start=1):
        slot = str(mapping.get("slot") or "").strip()
        source = str(mapping.get("source") or "").strip()
        if not source:
            errors.append(f"Mapping {index} has no Excel source.")
        if slot.casefold() not in slots:
            errors.append(f"Mapping {index} references missing PSD slot: {slot}")
        if mapping.get("kind") == "token" and slot:
            previous = primary_slots.get(slot.casefold())
            if previous is not None:
                errors.append(
                    f"PSD slot {slot} is assigned more than once by mappings "
                    f"{previous} and {index}. Update the existing assignment instead."
                )
            else:
                primary_slots[slot.casefold()] = index
        if mapping.get("kind") in {"token", "inline_token"}:
            signature = (
                str(mapping.get("kind")),
                source.casefold(),
                slot.casefold(),
                int(mapping.get("token_index", 0)),
            )
            if signature in seen_tokens:
                warnings.append(
                    f"Token #{int(mapping.get('token_index', 0)) + 1} from {source} "
                    f"has the same {mapping.get('kind')} assignment more than once."
                )
            seen_tokens.add(signature)
        if mapping.get("kind") == "inline_token" and (source.casefold(), slot.casefold()) not in flow_pairs:
            errors.append(
                f"Inline icon size mapping {index} needs the parent Excel row assigned "
                f"to the same PSD slot ({slot}) as Flow: text + icons."
            )
    if not mappings:
        warnings.append("No Excel-to-PSD mappings have been created.")
    elif not any(mapping.get("kind") == "flow" for mapping in mappings):
        warnings.append(
            "No text assignment exists. This mapping can place dedicated icons, "
            "but it will not place Excel text into PSD slots."
        )
    return errors, warnings


def build_mapped_template(base_template, sheet_name, mappings, icon_mappings=None):
    """Create the production JSON consumed by the dynamic renderer."""
    template = copy.deepcopy(base_template)
    token_bindings = []
    inline_icon_overrides = []
    token_exclusions = {}
    for index, mapping in enumerate(mappings, start=1):
        if mapping.get("kind") != "token":
            continue
        source = str(mapping.get("source") or "").strip()
        token_index = int(mapping.get("token_index", 0))
        token_binding = {
            "id": f"token_binding_{index}",
            "slot": str(mapping.get("slot") or ""),
            "source": source,
            "token_index": token_index,
            "token": str(mapping.get("token") or ""),
            "max_height": int(mapping.get("max_height", 0) or 0),
        }
        token_binding.update(_style_fields_from(mapping))
        token_bindings.append(token_binding)
        token_exclusions.setdefault(source.casefold(), set()).add(token_index)

    for index, mapping in enumerate(mappings, start=1):
        if mapping.get("kind") != "inline_token":
            continue
        override = {
            "id": f"inline_icon_override_{index}",
            "slot": str(mapping.get("slot") or ""),
            "source": str(mapping.get("source") or "").strip(),
            "token_index": int(mapping.get("token_index", 0)),
            "token": str(mapping.get("token") or ""),
            "icon_height": int(mapping.get("icon_height", 0) or 0),
        }
        override.update(_style_fields_from(mapping))
        inline_icon_overrides.append(override)

    grouped = OrderedDict()
    for mapping in mappings:
        if mapping.get("kind") != "flow":
            continue
        slot = str(mapping.get("slot") or "").strip()
        key = slot.casefold()
        if key not in grouped:
            grouped[key] = {
                "slot": slot,
                "render_mode": str(mapping.get("render_mode") or "inline_flow"),
                "font_size": int(mapping.get("font_size", 30)),
                "minimum_font_size": int(mapping.get("minimum_font_size", 20)),
                "emergency_minimum_font_size": int(mapping.get("emergency_minimum_font_size", 6)),
                "icon_height": int(mapping.get("icon_height", 48)),
                "gap": int(mapping.get("gap", 18)),
                "minimum_gap": int(mapping.get("minimum_gap", 8)),
                "padding": list(mapping.get("padding", [0, 0, 0, 0])),
                "vertical_align": str(mapping.get("vertical_align") or "top"),
                "never_overlap": True,
                "sources": [],
            }
            grouped[key].update(_style_fields_from(mapping))
        source = str(mapping.get("source") or "").strip()
        source_spec = {"source": source}
        excluded = sorted(token_exclusions.get(source.casefold(), set()))
        if excluded:
            source_spec["exclude_token_indexes"] = excluded
        grouped[key]["sources"].append(source_spec)

    flow_regions = OrderedDict()
    for index, region in enumerate(grouped.values(), start=1):
        flow_regions[_region_id(region["slot"], index)] = region

    try:
        old_schema_version = int(template.get("schema_version", 0) or 0)
    except Exception:
        old_schema_version = 0
    template["schema_version"] = max(3, old_schema_version)
    template["page_type"] = "paytable"
    template["sheet_match"] = [str(sheet_name)]
    template["flow_regions"] = flow_regions
    template["token_bindings"] = token_bindings
    template["inline_icon_overrides"] = inline_icon_overrides
    if icon_mappings is not None:
        template["icon_mappings"] = {
            str(key): str(value)
            for key, value in dict(icon_mappings or {}).items()
            if str(key).strip() and str(value).strip()
        }
    template["flow_replaces_legacy_text"] = bool(flow_regions)
    template["mapper_meta"] = {
        "generated_by": "PsHelpScreenTool Template Mapper",
        "sheet": str(sheet_name),
        "mapping_count": len(mappings),
        "authoritative": bool(flow_regions),
    }
    return template


def save_mapped_template(base_template, sheet_name, mappings, output_path, icon_mappings=None):
    errors, warnings = validate_mappings(base_template, mappings)
    if errors:
        raise ValueError("\n".join(errors))
    output_path = os.path.abspath(os.path.expanduser(str(output_path)))
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    template = build_mapped_template(base_template, sheet_name, mappings, icon_mappings=icon_mappings)
    with open(output_path, "w", encoding="utf-8") as handle:
        json.dump(template, handle, indent=2, ensure_ascii=True)
        handle.write("\n")
    return output_path, warnings
