"""Project memory stored inside the PSD itself.

Everything the tool needs to pick a PSD up again lives in the PSD's XMP
metadata (custom namespace ``pshelp:``), so a PSD carries its own project —
no ``_Links`` folder or sidecar files required:

  * settings (the session config it was built with),
  * the template / mapped-table JSON files those settings point at,
  * the source Excel: the workbook itself when small (<= EMBED_WORKBOOK_MAX),
    else the cell values; plus per-sheet content hashes,
  * identity: game / market / version,
  * pages: page group -> sheet, part,
  * layers: text layer -> sheet, Excel row, kind / paytable slot.

Verified 2026-10-18: Photoshop 2026 keeps a custom XMP namespace through
open -> artist edit -> save, byte for byte.

Encoding: JSON -> zlib -> base64 in one ``<pshelp:memory>`` element. Reading
only walks the PSD's image-resource section (fast even for huge PSDs).
"""
import base64
import copy
import datetime
import hashlib
import json
import os
import re
import struct
import zlib

NS = "http://pshelpscreentool/ns/1.0/"
SCHEMA = 1
XMP_RESOURCE = 1060
EMBED_WORKBOOK_MAX = 3 * 1024 * 1024          # bigger workbooks are stored as cell values
SESSION_KEYS = ("recent_projects", "ai_suggestions")
CACHE_DIR = os.path.join(os.path.expanduser("~"), "PsHelpScreenTool_Memory")
_MEMORY_RE = re.compile(rb"<pshelp:memory>([^<]*)</pshelp:memory>")


# ── encoding ────────────────────────────────────────────────────────────────
def _pack(obj):
    return base64.b64encode(zlib.compress(json.dumps(obj, separators=(",", ":")).encode("utf-8"), 9)).decode("ascii")


def _unpack(text):
    return json.loads(zlib.decompress(base64.b64decode(text)).decode("utf-8"))


def _file_blob(path):
    with open(path, "rb") as f:
        return base64.b64encode(zlib.compress(f.read(), 9)).decode("ascii")


def _blob_bytes(blob):
    return zlib.decompress(base64.b64decode(blob))


# ── building the memory ─────────────────────────────────────────────────────
def _referenced_files(cfg):
    """JSON files the settings point at (paytable template, mapped tables)."""
    files = []
    ds = cfg.get("dynamic_settings") if isinstance(cfg.get("dynamic_settings"), dict) else {}
    if str(ds.get("template_json") or "").strip():
        files.append(str(ds["template_json"]).strip())
    ts = cfg.get("table_style") if isinstance(cfg.get("table_style"), dict) else {}
    files += [p.strip() for p in str(ts.get("mapped_table_jsons") or "").splitlines() if p.strip()]
    overrides = ts.get("json_sheet_overrides")
    if isinstance(overrides, dict):
        files += [p for p in overrides if isinstance(p, str)]
    seen, out = set(), []
    for p in files:
        key = os.path.normcase(os.path.abspath(p))
        if key not in seen and os.path.isfile(p):
            seen.add(key)
            out.append(p)
    return out


def _excel_values(excel_path, max_col_limit):
    """{sheet: [[cell values...] per row]} — the content, without formatting."""
    from openpyxl import load_workbook

    wb = load_workbook(excel_path, read_only=True, data_only=True)
    try:
        out = {}
        for ws in wb.worksheets:
            rows = []
            for row in ws.iter_rows(max_col=max(1, int(max_col_limit or 12)), values_only=True):
                rows.append([v if isinstance(v, (int, float, bool)) or v is None else str(v) for v in row])
            while rows and not any(v not in (None, "") for v in rows[-1]):
                rows.pop()
            out[ws.title] = rows
        return out
    finally:
        wb.close()


def build(config, pages=None, layers=None, max_col_limit=None):
    """The memory dict for a PSD built from `config`."""
    from . import project_package as pp

    cfg = {k: copy.deepcopy(v) for k, v in (config or {}).items() if k not in SESSION_KEYS}
    limit = int(max_col_limit or cfg.get("max_col_limit") or 12)
    mem = {
        "schema": SCHEMA,
        "tool": "PsHelpScreenTool",
        "saved_at": datetime.datetime.now().isoformat(timespec="seconds"),
        "config": cfg,
        "files": {},
        "pages": pages or [],
        "layers": layers or {},
        "identity": {},
    }
    for path in _referenced_files(cfg):
        try:
            mem["files"][path] = {"name": os.path.basename(path), "data": _file_blob(path)}
        except OSError:
            pass
    excel = str(cfg.get("excel_path") or "")
    if excel and os.path.isfile(excel):
        info = {"path": os.path.abspath(excel), "name": os.path.basename(excel),
                "sha256": pp.file_sha256(excel), "sheets": pp._sheet_hashes(excel, limit),
                "max_col_limit": limit}
        try:
            if os.path.getsize(excel) <= EMBED_WORKBOOK_MAX:
                info["workbook"] = _file_blob(excel)
            else:
                info["values"] = _excel_values(excel, limit)
        except Exception as exc:                       # never fail a build over the snapshot
            info["error"] = str(exc)
        mem["excel"] = info
    if cfg.get("active_game"):
        try:
            from . import games

            game = games.get(cfg["active_game"])
            market = games.find_market(game, cfg.get("active_market")) if game else None
            mem["identity"] = {
                "game_id": cfg["active_game"], "game_name": (game or {}).get("name") or "",
                "game_folder": (game or {}).get("folder") or "",
                "market_id": cfg.get("active_market") or "", "market_name": (market or {}).get("name") or "",
                "version": len((market or {}).get("versions") or []) + 1,
            }
        except Exception:
            pass
    return mem


# ── XMP packet ──────────────────────────────────────────────────────────────
def _description(mem):
    return (f'<rdf:Description rdf:about="" xmlns:pshelp="{NS}">'
            f"<pshelp:schema>{SCHEMA}</pshelp:schema>"
            f"<pshelp:memory>{_pack(mem)}</pshelp:memory>"
            f"</rdf:Description>")


def xmp_packet(mem, existing=b""):
    """XMP bytes carrying `mem`, keeping any other XMP already in the file."""
    desc = _description(mem)
    text = existing.decode("utf-8", "replace") if existing else ""
    if text and "</rdf:RDF>" in text:
        text = re.sub(r'<rdf:Description[^>]*xmlns:pshelp="[^"]*"[^>]*>.*?</rdf:Description>', "", text, flags=re.S)
        text = text.replace("</rdf:RDF>", desc + "</rdf:RDF>", 1)
        return text.encode("utf-8")
    return ('<?xpacket begin="﻿" id="W5M0MpCehiHzreSzNTczkc9d"?>'
            '<x:xmpmeta xmlns:x="adobe:ns:meta/">'
            '<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">'
            f"{desc}</rdf:RDF></x:xmpmeta>"
            '<?xpacket end="w"?>').encode("utf-8")


def attach(psd_record, mem):
    """Put the memory into a psd-tools PSD record (before it is written)."""
    from psd_tools.constants import Resource
    from psd_tools.psd.image_resources import ImageResource

    resources = psd_record.image_resources
    existing = resources[Resource.XMP_METADATA].data if Resource.XMP_METADATA in resources else b""
    resources[Resource.XMP_METADATA] = ImageResource(key=Resource.XMP_METADATA, name="",
                                                     data=xmp_packet(mem, existing))


def write_into_file(psd_path, mem):
    """Replace the memory inside an existing PSD/PSB without touching its layers:
    only the image-resource section is rewritten (the rest is streamed as is)."""
    tmp = psd_path + ".pshelp.tmp"
    with open(psd_path, "rb") as src:
        head = src.read(26)
        if head[:4] != b"8BPS":
            raise ValueError("Not a Photoshop file.")
        cm = src.read(4)
        cm_data = src.read(struct.unpack(">I", cm)[0])
        (ir_len,) = struct.unpack(">I", src.read(4))
        resources = src.read(ir_len)
        # keep every resource except the XMP; remember the old XMP to merge into
        out, pos, existing = bytearray(), 0, b""
        while pos + 12 <= len(resources):
            start = pos
            pos += 4
            (rid,) = struct.unpack(">H", resources[pos:pos + 2]); pos += 2
            nlen = resources[pos]; pos += 1 + nlen + ((nlen + 1) % 2)
            (size,) = struct.unpack(">I", resources[pos:pos + 4]); pos += 4
            data = resources[pos:pos + size]
            pos += size + (size % 2)
            if rid == XMP_RESOURCE:
                existing = data
            else:
                out += resources[start:pos]
        packet = xmp_packet(mem, existing)
        out += b"8BIM" + struct.pack(">H", XMP_RESOURCE) + b"\x00\x00" + struct.pack(">I", len(packet)) + packet
        if len(packet) % 2:
            out += b"\x00"
        with open(tmp, "wb") as dst:
            dst.write(head + cm + cm_data + struct.pack(">I", len(out)) + bytes(out))
            while True:
                chunk = src.read(1 << 20)
                if not chunk:
                    break
                dst.write(chunk)
    os.replace(tmp, psd_path)


# ── reading ─────────────────────────────────────────────────────────────────
def _xmp_bytes(psd_path):
    """XMP resource of a PSD/PSB, reading only the header + image resources."""
    with open(psd_path, "rb") as f:
        head = f.read(26)
        if len(head) < 26 or head[:4] != b"8BPS":
            return b""
        (cm_len,) = struct.unpack(">I", f.read(4))
        f.seek(cm_len, 1)
        (ir_len,) = struct.unpack(">I", f.read(4))
        end = f.tell() + ir_len
        while f.tell() + 12 <= end:
            sig = f.read(4)
            if sig not in (b"8BIM", b"MeSa", b"AgHg", b"PHUT", b"DCSR"):
                return b""
            (rid,) = struct.unpack(">H", f.read(2))
            (nlen,) = struct.unpack(">B", f.read(1))
            f.seek(nlen + ((nlen + 1) % 2), 1)       # pascal name, padded to even
            (size,) = struct.unpack(">I", f.read(4))
            if rid == XMP_RESOURCE:
                return f.read(size)
            f.seek(size + (size % 2), 1)
    return b""


def read(psd_path):
    """The memory stored in a PSD, or None."""
    try:
        m = _MEMORY_RE.search(_xmp_bytes(psd_path))
        return _unpack(m.group(1).decode("ascii")) if m else None
    except Exception:
        return None


def has_project(mem):
    """A memory with the settings a build used — not only a binding (binding.py: a clone of an
    artist's PSD carries which layers show which AGR content, but no project)."""
    return bool(mem) and isinstance(mem.get("config"), dict)


def summary(psd_path):
    """Small description for the UI (no big blobs)."""
    mem = read(psd_path)
    if not has_project(mem):
        return {"ok": False, "has_memory": False, "binding": bool((mem or {}).get("binding"))}
    ex = mem.get("excel") or {}
    return {
        "ok": True, "has_memory": True, "saved_at": mem.get("saved_at") or "",
        "identity": mem.get("identity") or {},
        "excel": {"name": ex.get("name") or "", "path": ex.get("path") or "",
                  "embedded": "workbook" in ex, "values_only": "values" in ex,
                  "sheets": sorted((ex.get("sheets") or {}).keys())},
        "files": [v.get("name") for v in (mem.get("files") or {}).values()],
        "pages": len(mem.get("pages") or []), "layers": len(mem.get("layers") or {}),
    }


# ── restoring ───────────────────────────────────────────────────────────────
def cache_dir_for(psd_path):
    key = hashlib.sha1(os.path.normcase(os.path.abspath(psd_path)).encode("utf-8")).hexdigest()[:12]
    name = re.sub(r"[^A-Za-z0-9_-]+", "_", os.path.splitext(os.path.basename(psd_path))[0])[:40]
    return os.path.join(CACHE_DIR, f"{name}_{key}")


def materialize_excel(psd_path, mem=None):
    """Path of the Excel this PSD was built from, rebuilt from the memory
    (exact workbook when embedded, values-only otherwise). '' when unavailable."""
    mem = mem or read(psd_path)
    ex = (mem or {}).get("excel") or {}
    if not ex:
        return ""
    folder = os.path.join(cache_dir_for(psd_path), "source", str(ex.get("sha256") or "unknown")[:12])
    os.makedirs(folder, exist_ok=True)
    name = ex.get("name") or "source.xlsx"
    if "workbook" in ex:
        target = os.path.join(folder, name)
        if not os.path.isfile(target):
            with open(target + ".tmp", "wb") as f:
                f.write(_blob_bytes(ex["workbook"]))
            os.replace(target + ".tmp", target)
        return target
    if "values" in ex:
        from openpyxl import Workbook

        target = os.path.join(folder, os.path.splitext(name)[0] + " (values).xlsx")
        if not os.path.isfile(target):
            wb = Workbook()
            wb.remove(wb.active)
            for sheet, rows in ex["values"].items():
                ws = wb.create_sheet(sheet[:31])
                for row in rows:
                    ws.append(row)
            wb.save(target)
        return target
    return ""


def restore(psd_path, session_cfg=None):
    """Session config to continue working on this PSD, from its memory alone.

    Template/table JSON files come from the memory (written into a per-PSD
    cache folder) so the project is exactly as it was built. The Excel stays
    the original file when it still exists (it may be a newer revision — the
    memory is then the diff baseline); otherwise the embedded copy is used.
    Returns {"ok", "config", "notes", "identity"} or {"ok": False, "error"}.
    """
    mem = read(psd_path)
    if not has_project(mem):
        return {"ok": False, "error": "This PSD has no saved project (it wasn't made by this tool, "
                                      "or was built before projects were stored inside PSDs)."}
    cfg = copy.deepcopy(mem.get("config") or {})
    notes = []
    folder = os.path.join(cache_dir_for(psd_path), "files")
    remap = {}
    for original, info in (mem.get("files") or {}).items():
        os.makedirs(folder, exist_ok=True)
        target = os.path.join(folder, info.get("name") or os.path.basename(original))
        with open(target, "wb") as f:
            f.write(_blob_bytes(info["data"]))
        remap[original] = target
    ds = cfg.get("dynamic_settings")
    if isinstance(ds, dict) and ds.get("template_json") in remap:
        ds["template_json"] = remap[ds["template_json"]]
    ts = cfg.get("table_style")
    if isinstance(ts, dict):
        if ts.get("mapped_table_jsons"):
            ts["mapped_table_jsons"] = "\n".join(remap.get(p.strip(), p.strip())
                                                 for p in str(ts["mapped_table_jsons"]).splitlines() if p.strip())
        if isinstance(ts.get("json_sheet_overrides"), dict):
            ts["json_sheet_overrides"] = {remap.get(k, k): v for k, v in ts["json_sheet_overrides"].items()}
    excel = str(cfg.get("excel_path") or "")
    if not excel or not os.path.isfile(excel):
        rebuilt = materialize_excel(psd_path, mem)
        if rebuilt:
            cfg["excel_path"] = rebuilt
            notes.append("The original Excel wasn't found; using the copy saved inside the PSD"
                         + (" (cell values only)." if "values" in (mem.get("excel") or {}) else "."))
        else:
            notes.append("The original Excel wasn't found and no copy is saved in the PSD.")
    cfg["prev_psd_path"] = os.path.abspath(psd_path)
    cfg["prev_excel_path"] = ""
    cfg["update_mode"] = False
    for key in SESSION_KEYS:
        cfg[key] = (session_cfg or {}).get(key) or []
    ident = mem.get("identity") or {}
    cfg.pop("active_game", None)
    cfg.pop("active_market", None)
    if ident.get("game_id"):
        try:
            from . import games

            game = games.get(ident["game_id"])
            if game and games.find_market(game, ident.get("market_id")):
                cfg["active_game"] = ident["game_id"]
                cfg["active_market"] = ident["market_id"]
        except Exception:
            pass
    return {"ok": True, "config": cfg, "notes": notes, "identity": ident}


def baseline_info(psd_path):
    """Same shape as project_package.load_baseline_info, from the PSD's memory."""
    mem = read(psd_path)
    ex = (mem or {}).get("excel") or {}
    if not ex:
        return {"exists": False}
    path = materialize_excel(psd_path, mem)
    if not path:
        return {"exists": False}
    pages = [{"page_id": s, "sheet_name": s, "content_hash": h} for s, h in sorted((ex.get("sheets") or {}).items())]
    return {
        "exists": True, "baseline": path, "manifest": None, "embedded": True,
        "data": {"pages": pages, "source": {"original_path": ex.get("path"), "file_hash": ex.get("sha256")}},
        "version_number": int(((mem.get("identity") or {}).get("version")) or 1),
        "original_path": ex.get("path") or "", "file_hash": ex.get("sha256") or "",
    }
