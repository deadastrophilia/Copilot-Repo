import os
import json
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import photoshopapi as psapi
from photoshopapi import enum


# ---------------------------------------------------------------------------
# Font name mapping  (tkinter font name → PostScript name)
# ---------------------------------------------------------------------------
_COMMON_FONT_MAP = {
    "arial": "ArialMT",
    "arial black": "Arial-Black",
    "arial narrow": "ArialNarrow",
    "arial rounded": "ArialRoundedMTBold",
    "arial bold": "Arial-BoldMT",
    "arial italic": "Arial-ItalicMT",
    "arial bold italic": "Arial-BoldItalicMT",
    "times new roman": "TimesNewRomanPSMT",
    "times new roman bold": "TimesNewRomanPS-BoldMT",
    "times new roman italic": "TimesNewRomanPS-ItalicMT",
    "times new roman bold italic": "TimesNewRomanPS-BoldItalicMT",
    "helvetica": "Helvetica",
    "helvetica bold": "Helvetica-Bold",
    "helvetica neue": "HelveticaNeue",
    "helvetica neue bold": "HelveticaNeue-Bold",
    "tahoma": "Tahoma",
    "tahoma bold": "Tahoma-Bold",
    "verdana": "Verdana",
    "verdana bold": "Verdana-Bold",
    "calibri": "Calibri",
    "calibri bold": "Calibri-Bold",
    "calibri italic": "Calibri-Italic",
    "calibri bold italic": "Calibri-BoldItalic",
    "impact": "Impact",
    "courier new": "CourierNewPSMT",
    "courier new bold": "CourierNewPS-BoldMT",
}

# tkinter font name → Pillow/OS font file name
_FONT_FILE_MAP = {
    "arial": "arial.ttf",
    "arial bold": "arialbd.ttf",
    "arial italic": "ariali.ttf",
    "arial bold italic": "arialbi.ttf",
    "arial black": "ariblk.ttf",
    "arial narrow": "arialn.ttf",
    "arialmt": "arial.ttf",
    "arial-boldmt": "arialbd.ttf",
    "arial-italicmt": "ariali.ttf",
    "arial-bolditalicmt": "arialbi.ttf",
    "times new roman": "times.ttf",
    "times new roman bold": "timesbd.ttf",
    "times new roman italic": "timesi.ttf",
    "times new roman bold italic": "timesbi.ttf",
    "timesnewromanpsmt": "times.ttf",
    "timesnewromaps-boldmt": "timesbd.ttf",
    "timesnewromaps-italicmt": "timesi.ttf",
    "timesnewromaps-bolditalicmt": "timesbi.ttf",
    "courier new": "cour.ttf",
    "courier new bold": "courbd.ttf",
    "courier new italic": "couri.ttf",
    "courier new bold italic": "courbi.ttf",
    "couriernewpsmt": "cour.ttf",
    "tahoma": "tahoma.ttf",
    "tahoma bold": "tahomabd.ttf",
    "tahoma-bold": "tahomabd.ttf",
    "verdana": "verdana.ttf",
    "verdana bold": "verdanab.ttf",
    "verdana-bold": "verdanab.ttf",
    "calibri": "calibri.ttf",
    "calibri bold": "calibrib.ttf",
    "calibri italic": "calibrii.ttf",
    "calibri bold italic": "calibriz.ttf",
    "calibri-bold": "calibrib.ttf",
    "calibri-italic": "calibrii.ttf",
    "calibri-bolditalic": "calibriz.ttf",
    "impact": "impact.ttf",
    "segoe ui": "segoeui.ttf",
    "segoe ui bold": "segoeuib.ttf",
    "segoe ui italic": "segoeuii.ttf",
    "segoe ui semibold": "seguisb.ttf",
    "consolas": "consola.ttf",
    "consolas bold": "consolab.ttf",
    "georgia": "georgia.ttf",
    "georgia bold": "georgiab.ttf",
    "comicsansms": "comic.ttf",
    "comicsansms bold": "comicbd.ttf",
    "cambria": "cambria.ttc",
    "cambria bold": "cambriab.ttf",
    "palatino linotype": "pala.ttf",
    "palatino linotype bold": "palab.ttf",
    "garamond": "GARA.TTF",
    "garamond bold": "GARABD.TTF",
    "book antiqua": "BOOKOS.TTF",
    "book antiqua bold": "BOOKOSB.TTF",
    "century gothic": "GOTHIC.TTF",
    "helvetica": "arial.ttf",
    "helvetica-bold": "arialbd.ttf",
    "helvetica neue": "arial.ttf",
    "helvetica neue bold": "arialbd.ttf",
}

_FONT_DIR_CANDIDATES = [
    os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts"),
    os.path.expanduser(r"~\AppData\Local\Microsoft\Windows\Fonts"),
]

_font_path_cache = {}


def _resolve_ttf_path(font_name):
    """Resolve a tkinter-style font name to a .ttf/.ttc path on disk."""
    if not font_name:
        return None
    key = str(font_name).strip().lower()
    if key in _font_path_cache:
        return _font_path_cache[key]
    try:                                                # the installed face the PNG build draws with
        from . import fontfaces

        hit = fontfaces.pick(font_name)
        if hit and not hit[1]:
            _font_path_cache[key] = hit[0]
            return hit[0]
    except Exception:
        pass

    fname = _FONT_FILE_MAP.get(key)
    if not fname:
        base = key.split("|")[0].strip()
        fname = _FONT_FILE_MAP.get(base)

    if fname:
        for d in _FONT_DIR_CANDIDATES:
            candidate = os.path.join(d, fname)
            if os.path.isfile(candidate):
                _font_path_cache[key] = candidate
                return candidate

    for d in _FONT_DIR_CANDIDATES:
        if not os.path.isdir(d):
            continue
        for fn in os.listdir(d):
            if fn.lower().startswith(key.replace(" ", "")):
                candidate = os.path.join(d, fn)
                _font_path_cache[key] = candidate
                return candidate

    _font_path_cache[key] = None
    return None


def _get_pil_font(font_name, font_size):
    """Get a PIL ImageFont for the given tkinter font name and size."""
    ttf = _resolve_ttf_path(font_name)
    if ttf:
        try:
            return ImageFont.truetype(ttf, int(font_size))
        except Exception:
            pass
    return ImageFont.load_default()


def resolve_font_psapi(font_name):
    if not font_name:
        return "ArialMT"
    name = str(font_name).strip()
    if "|" in name:
        try:                                            # "Family|Semibold" / "Arial|bold": that face's PostScript name
            from . import fontfaces

            face = fontfaces.face_of(name)
            if face and face.get("ps"):
                return face["ps"]
        except Exception:
            pass
        name = name.split("|", 1)[0].strip()
    key = name.lower()
    mapped = _COMMON_FONT_MAP.get(key)
    if mapped:
        return mapped
    return name


# ---------------------------------------------------------------------------
# Color conversion
# ---------------------------------------------------------------------------
def rgb_to_psapi_fill(r, g, b, a=1.0):
    """Convert 0-255 RGB values to the AGBR 0.0-1.0 float list PSAPI expects.

    PSAPI uses AGBR channel order: [Alpha, Green, Blue, Red].
    """
    return [a, g / 255.0, b / 255.0, r / 255.0]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _get_layer_pos(layer):
    try:
        p = layer.position
        if p is not None:
            return (float(p[0]), float(p[1]))
    except Exception:
        pass
    return None

def _get_layer_w(layer):
    try:
        w = layer.width
        if w is not None:
            return float(w())
    except Exception:
        pass
    try:
        bw = layer.box_width
        if bw is not None:
            return float(bw())
    except Exception:
        pass
    return None

# ---------------------------------------------------------------------------
# PSAPIDocument  —  wraps the PSAPI LayeredFile and tracks current context
# ---------------------------------------------------------------------------
class PSAPIDocument:
    def __init__(self, width, height, color_mode=enum.ColorMode.rgb):
        self._lf = psapi.LayeredFile_8bit(color_mode, int(width), int(height))
        self._font_cache = {}
        self._icon_pil_cache = {}
        self._all_layers = []  # keep references alive

    @property
    def width(self):
        return int(self._lf.width)

    @property
    def height(self):
        return int(self._lf.height)

    @staticmethod
    def _parent_add_layer(parent, lf, layer):
        if hasattr(parent, "add_layer"):
            try:
                parent.add_layer(lf, layer)
            except TypeError:
                parent.add_layer(layer)
        else:
            lf.add_layer(layer)

    def add_text_layer(self, parent, text, font_name, font_size, color_rgb,
                       x, y, name="Text", line_height=None):
        """Dual-layer text: visible pixel-rendered ImageLayer + hidden editable TextLayer.

        y is a **baseline** coordinate (matching Photoshop / COM convention).
        PSAPI places the text origin at (x, baseline).
        """
        _txt = str(text or "")
        if not _txt.strip():
            return None

        font_ps = resolve_font_psapi(font_name)
        r, g, b = [max(0, min(255, int(v))) for v in (color_rgb or (0, 0, 0))]
        fill = rgb_to_psapi_fill(r, g, b)

        # ── 1. Pixel-rendered ImageLayer (always visible) ───────────────
        try:
            pil_font = _get_pil_font(font_name, font_size)
            bbox = pil_font.getbbox(_txt)
            tw = int(bbox[2] - bbox[0]) + 4
            th = int(bbox[3] - bbox[1]) + 4
            baseline_offset = int(bbox[1] * -1) + 2
            txt_img = Image.new("RGBA", (max(1, tw), max(1, th)), (0, 0, 0, 0))
            txt_draw = ImageDraw.Draw(txt_img)
            txt_draw.text((0, baseline_offset), _txt,
                          fill=(r, g, b, 255), font=pil_font)
            il = psapi.ImageLayer_8bit(
                np.transpose(np.array(txt_img, dtype=np.uint8), (2, 0, 1)),
                str(name),
                width=max(1, tw), height=max(1, th),
            )
            il.position = (float(x), float(y) - font_size)
            il.fill = 1.0
            il.opacity = 1.0
            self._parent_add_layer(parent, self._lf, il)
            self._all_layers.append(il)
        except Exception:
            pass

        # ── 2. Hidden editable TextLayer_8bit (for editability) ─────────
        tl = psapi.TextLayer_8bit(
            layer_name=str(name) + " [Edit]",
            text=_txt,
            font=font_ps,
            font_size=float(font_size),
            fill_color=fill,
            position_x=float(x),
            position_y=float(y),
        )
        tl.fill = 1.0
        tl.opacity = 0.0
        tl.convert_to_point_text()

        tl.set_style_normal_font_size(float(font_size))
        tl.set_style_normal_fill_color(fill)

        tl.add_font(font_ps)
        tl.set_font(font_ps)
        tl.set_style_normal_font_by_name(font_ps)

        if line_height and float(line_height) > 0:
            tl.set_style_normal_leading(float(line_height))

        self._parent_add_layer(parent, self._lf, tl)
        self._all_layers.append(tl)
        return tl

    def add_group(self, parent, name="Group"):
        """Add a group layer."""
        g = psapi.GroupLayer_8bit(layer_name=str(name))
        g.fill = 1.0
        g.opacity = 1.0
        self._parent_add_layer(parent, self._lf, g)
        self._all_layers.append(g)
        return g

    def add_image_layer(self, parent, pil_image, name="Image", x=0, y=0, scale_x=1.0, scale_y=1.0):
        """Add a pixel layer from a PIL Image, preserving RGBA alpha."""
        w, h = pil_image.size
        if pil_image.mode == "RGBA":
            arr = np.array(pil_image, dtype=np.uint8)
            arr = np.transpose(arr, (2, 0, 1))  # (H,W,4) -> (4,H,W)
        else:
            arr = np.array(pil_image.convert("RGB"), dtype=np.uint8)
            arr = np.transpose(arr, (2, 0, 1))  # (H,W,3) -> (3,H,W)

        il = psapi.ImageLayer_8bit(arr, str(name), width=int(w), height=int(h))
        il.position = (float(x), float(y))
        il.fill = 1.0
        il.opacity = 1.0
        if scale_x != 1.0 or scale_y != 1.0:
            il.set_scale(float(scale_x), float(scale_y))

        self._parent_add_layer(parent, self._lf, il)
        self._all_layers.append(il)
        return il

    def add_icon_layer(self, parent, icon_path, name, x, y, target_h, orig_w, orig_h):
        """Load an icon from disk and add it as a pixel layer."""
        pil = Image.open(icon_path).convert("RGBA")
        scale = target_h / max(orig_h, 1)
        new_w = max(1, int(orig_w * scale))
        new_h = max(1, int(target_h))
        pil_resized = pil.resize((new_w, new_h), Image.LANCZOS)
        return self.add_image_layer(parent, pil_resized, name, x=int(x), y=int(y))

    def align_group(self, group, box_left, box_width, alignment="center"):
        children = group.layers if hasattr(group, "layers") else []
        if not children:
            return
        lefts, rights = [], []
        for c in children:
            pos = _get_layer_pos(c)
            if pos is None:
                continue
            cw = _get_layer_w(c)
            if cw is None:
                continue
            lefts.append(pos[0])
            rights.append(pos[0] + cw)
        if not lefts:
            return
        content_min = min(lefts)
        content_max = max(rights)
        content_w = content_max - content_min
        if content_w <= 0:
            return
        if alignment == "left":
            target_x = float(box_left or 0)
        elif alignment == "right":
            target_x = float(box_left or 0) + float(box_width or 0) - content_w
        else:
            target_x = float(box_left or 0) + (float(box_width or 0) - content_w) / 2
        dx = target_x - content_min
        for c in children:
            pos = _get_layer_pos(c)
            if pos is not None:
                c.position = (pos[0] + dx, pos[1])

    def save(self, path):
        path = str(path)
        ext = os.path.splitext(path)[1].lower()
        if ext not in (".psd", ".psb"):
            path = path + ".psd"
        self._lf.write(path)
        return os.path.getsize(path)

    @property
    def doc(self):
        return self._lf

    def add_text_layer_batch(self, parent, specs):
        """Create multiple text layers at once (each spec is a dict)."""
        for spec in specs:
            self.add_text_layer(
                parent,
                spec.get("text", ""),
                spec.get("font", "ArialMT"),
                spec.get("font_size", 24),
                spec.get("color_rgb", (0, 0, 0)),
                spec.get("x", 0),
                spec.get("y", 0),
                spec.get("name", "Text"),
                spec.get("line_height"),
            )

    def add_horizontal_rule(self, parent, left_x, top_y, width_px, height_px,
                            fill_rgb, layer_name="Separator"):
        """Add a solid-colour rectangle as a pixel layer."""
        w = max(1, int(width_px))
        h = max(1, int(height_px))
        r, g, b = [max(0, min(255, int(v))) for v in (fill_rgb or (0, 0, 0))]
        pil = Image.new("RGBA", (w, h), (r, g, b, 255))
        return self.add_image_layer(parent, pil, layer_name, x=left_x, y=top_y)
