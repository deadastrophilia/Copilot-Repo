"""Photoshop-faithful text rasteriser.

Pillow renders TrueType text hinted and with whole-pixel advances, so a line
looked crisper than in Photoshop and its letters sat slightly elsewhere: the
moment an artist edited a text layer, Photoshop re-rendered it softer and
re-spaced. This module draws text the way Photoshop does, measured against
Photoshop 2026's own rendering (Crisp anti-aliasing, white-on-black and
black-on-white oracles, 9 font/size cases):

  * glyphs sit at their exact (unhinted, fractional) advances, kerned like Photoshop's default
    "Metrics" kerning (the font's own pairs, read by HarfBuzz; psd_writer turns Metrics on, so
    an edited layer keeps every letter where it was — and matches the artists' own files);
  * outlines are rasterised unhinted: drawn at 8x and box-averaged down;
  * each line's baseline snaps to the nearest pixel row, halves downward
    (x stays fractional);
  * text colour blends with what is underneath in gamma-1.45 space
    (Photoshop's "Blend Text Colors Using Gamma: 1.45").

Error per ink pixel vs Photoshop went from 86 (Pillow) to 31 (white text)
and 42 -> 37 (black text); measured with the oracle in the 2026-10-18 session.
"""
import math

import numpy as np
from PIL import Image, ImageChops, ImageDraw

SCALE = 8                  # supersampling factor (outline -> coverage)
TEXT_GAMMA = 1.45          # Photoshop default text blending gamma
_EXACT_SIZE = 1000.0

_BIG_FONTS = {}
_EXACT_FONTS = {}
_ADVANCES = {}
_GLYPHS = {}
_GLYPHS_MAX = 6000


def _font_key(font):
    return (str(getattr(font, "path", "")), int(getattr(font, "index", 0) or 0), float(getattr(font, "size", 0)))         + shape_of(font)


# Photoshop's Character panel width / height scale and kerning travel with the font object (shaped()):
# a heading learned from an artist's PSD (a 152 px layer stretched to 207 px, 80 % tall, kerning off)
# measures, wraps, draws and goes into the PSD with them. Tracking widens by the width scale too
# (Photoshop does: tracking 50 at 72 % wide adds 72 % of 50/1000 em).
def shaped(font, hscale=1.0, vscale=1.0, kerning=True):
    """A copy of the Pillow font that draws `hscale` / `vscale` (1.0 = 100 %) and with or without Metrics
    kerning; the font itself when nothing differs."""
    hs, vs, kern_on = float(hscale or 1.0), float(vscale or 1.0), bool(kerning)
    if abs(hs - 1.0) < 1e-6 and abs(vs - 1.0) < 1e-6 and kern_on:
        return font
    try:
        out = font.font_variant()
    except Exception:
        return font
    out.ps_hscale, out.ps_vscale, out.ps_kerning = hs, vs, kern_on
    return out


def shape_of(font):
    """(width scale, height scale, Metrics kerning on) of a font (1.0, 1.0, True unless shaped())."""
    return (float(getattr(font, "ps_hscale", 1.0) or 1.0), float(getattr(font, "ps_vscale", 1.0) or 1.0),
            bool(getattr(font, "ps_kerning", True)))


def _variant(cache, font, size):
    key = _font_key(font) + (size,)
    hit = cache.get(key)
    if hit is None:
        try:
            hit = font.font_variant(size=size)
        except Exception:
            hit = False
        cache[key] = hit
    return hit


def char_advance(font, ch):
    """Exact advance of one character at the font's size (fractional px)."""
    key = _font_key(font) + (ch,)
    hit = _ADVANCES.get(key)
    if hit is None:
        exact = _variant(_EXACT_FONTS, font, _EXACT_SIZE)
        if exact:
            hit = exact.getlength(ch) * float(font.size) / _EXACT_SIZE
        else:
            hit = float(font.getlength(ch))
        hit *= shape_of(font)[0]
        _ADVANCES[key] = hit
    return hit


import contextlib as _contextlib
import contextvars as _contextvars

# Letter spacing of the text being laid out, in Photoshop's tracking unit (1/1000 em): set around
# the heading / body text (Typography), it widens every advance — measuring, wrapping, drawing and
# the PSD (which writes the measured widths back as tracking) all follow.
_TRACKING = _contextvars.ContextVar("ps_text_tracking", default=0.0)


@_contextlib.contextmanager
def tracking(thousandths_em):
    token = _TRACKING.set(float(thousandths_em or 0.0))
    try:
        yield
    finally:
        _TRACKING.reset(token)


def current_tracking():
    return _TRACKING.get()


def tracking_px(font):
    """The extra px after every character for `font` at the current letter spacing."""
    t = _TRACKING.get()
    return float(getattr(font, "size", 0) or 0) * t / 1000.0 * shape_of(font)[0] if t else 0.0


# Photoshop's "Metrics" kerning: the font's own pair adjustments ('kern' table and GPOS), through
# HarfBuzz (uharfbuzz) — the shaper browsers use too, so the Canvas (fontKerning "normal") agrees.
KERNING = True
_HB_FONTS = {}
_KERNS = {}


def _hb_font(font):
    """(hb.Font, units per em) for a Pillow font's file, or None (no file, no uharfbuzz)."""
    key = (str(getattr(font, "path", "") or ""), int(getattr(font, "index", 0) or 0))
    if key not in _HB_FONTS:
        hit = None
        if key[0]:
            try:
                import uharfbuzz as hb

                face = hb.Face(hb.Blob.from_file_path(key[0]), key[1])
                hit = (hb.Font(face), float(face.upem or 1000))
            except Exception:
                hit = None
        _HB_FONTS[key] = hit
    return _HB_FONTS[key]


def kern(font, a, b):
    """Kerning between the characters `a` and `b` at the font's size (fractional px; 0 = none)."""
    if not KERNING or not a or not b or not shape_of(font)[2]:
        return 0.0
    key = _font_key(font) + (a, b)
    hit = _KERNS.get(key)
    if hit is None:
        hit = 0.0
        hbf = _hb_font(font)
        if hbf is not None:
            try:
                import uharfbuzz as hb

                def width(kerned):
                    buf = hb.Buffer()
                    buf.add_str(a + b)
                    buf.guess_segment_properties()
                    hb.shape(hbf[0], buf, {"kern": kerned, "liga": False, "clig": False, "calt": False})
                    return sum(p.x_advance for p in buf.glyph_positions)
                # the pair's whole change: a legacy 'kern' table (Franklin Gothic) is split by HarfBuzz into
                # half on each glyph (the second also offset back), GPOS puts it all on the first
                units = width(True) - width(False)
                hit = units * float(font.size) / hbf[1] * shape_of(font)[0]
            except Exception:
                hit = 0.0
        if len(_KERNS) > 200000:
            _KERNS.clear()
        _KERNS[key] = hit
    return hit


def advance(font, text):
    """Width of `text` as Photoshop lays it out (exact advances + Metrics kerning + letter spacing)."""
    text = str(text or "")
    return (sum(char_advance(font, ch) for ch in text) + sum(kern(font, a, b) for a, b in zip(text, text[1:]))
            + len(text) * tracking_px(font))


def glyph_positions(font, text, x, tracking_px=0.0):
    """[(char, pen_x)] for `text` starting at pen `x` (extra `tracking_px` per char, kerned pairs)."""
    out, pen = [], float(x)
    text = str(text or "")
    for i, ch in enumerate(text):
        out.append((ch, pen))
        pen += char_advance(font, ch) + tracking_px + (kern(font, ch, text[i + 1]) if i + 1 < len(text) else 0.0)
    return out


def snap_baseline(baseline):
    """Pixel row Photoshop draws a baseline on: nearest row, halves going down the
    page (floor(y + 0.5); Python's round() sends halves to even rows, 1px off half
    the time — measured on 57 layers with baselines at .0/.2/.5/.7/.9)."""
    return int(math.floor(float(baseline) + 0.5 + 1e-9))


def _glyph(font, ch):
    """(mask, left, top) of `ch` at SCALE x size, relative to its origin on the baseline."""
    key = _font_key(font) + (ch,)
    hit = _GLYPHS.get(key)
    if hit is None:
        big = _variant(_BIG_FONTS, font, float(font.size) * SCALE)
        if not big:
            return None
        l, t, r, b = big.getbbox(ch, anchor="ls")
        if r <= l or b <= t:
            hit = (None, 0, 0)
        else:
            mask = Image.new("L", (r - l, b - t), 0)
            ImageDraw.Draw(mask).text((-l, -t), ch, font=big, fill=255, anchor="ls")
            hs, vs, _k = shape_of(font)
            if hs != 1.0 or vs != 1.0:
                # Photoshop's width / height scale: the outline stretched about the pen and the baseline
                l2, t2 = l * hs, t * vs
                r2, b2 = r * hs, b * vs
                L, T = math.floor(l2), math.floor(t2)
                w, h = max(1, math.ceil(r2) - L), max(1, math.ceil(b2) - T)
                mask = mask.transform((w, h), Image.AFFINE, (1 / hs, 0, (L - l2) / hs, 0, 1 / vs, (T - t2) / vs),
                                      resample=Image.BILINEAR)
                l, t = L, T
            hit = (mask, l, t)
        if len(_GLYPHS) > _GLYPHS_MAX:
            _GLYPHS.clear()
        _GLYPHS[key] = hit
    return hit


def coverage(runs, pad=0):
    """Coverage mask for text runs [(text, font, pen_x, baseline, tracking_px)].

    Returns (L image, left, top) in page pixels, or None when nothing is inked.
    """
    placed = []
    for text, font, x, baseline, tracking in runs:
        by = snap_baseline(baseline) * SCALE
        for ch, px in glyph_positions(font, text, x, tracking or tracking_px(font)):
            g = _glyph(font, ch)
            if g is None or g[0] is None:
                continue
            mask, l, t = g
            gx = int(round(px * SCALE)) + l
            placed.append((mask, gx, by + t))
    if not placed:
        return None
    x0 = min(gx for _m, gx, _gy in placed)
    y0 = min(gy for _m, _gx, gy in placed)
    x1 = max(gx + m.width for m, gx, _gy in placed)
    y1 = max(gy + m.height for m, _gx, gy in placed)
    # align the big canvas to whole page pixels so reduce() lands on the grid
    left = math.floor(x0 / SCALE) - pad
    top = math.floor(y0 / SCALE) - pad
    right = math.ceil(x1 / SCALE) + pad
    bottom = math.ceil(y1 / SCALE) + pad
    big = Image.new("L", ((right - left) * SCALE, (bottom - top) * SCALE), 0)
    for mask, gx, gy in placed:
        bx, by = gx - left * SCALE, gy - top * SCALE
        box = (bx, by, bx + mask.width, by + mask.height)
        big.paste(ImageChops.lighter(big.crop(box), mask), box)
    return big.reduce(SCALE), left, top


def composite(base, cov, left, top, rgb, opacity=1.0):
    """Blend a coverage mask in `rgb` onto RGBA `base` like Photoshop text.

    Opaque pixels blend in gamma-1.45 space; transparent ones get the colour
    with the coverage as alpha (normal compositing).
    """
    if cov is None:
        return
    bw, bh = base.size
    x0, y0 = max(0, left), max(0, top)
    x1, y1 = min(bw, left + cov.width), min(bh, top + cov.height)
    if x1 <= x0 or y1 <= y0:
        return
    a = np.asarray(cov.crop((x0 - left, y0 - top, x1 - left, y1 - top)), dtype=np.float32) / 255.0
    a *= max(0.0, min(1.0, float(opacity)))
    region = np.asarray(base.crop((x0, y0, x1, y1)).convert("RGBA"), dtype=np.float32) / 255.0
    fg = np.asarray(rgb[:3], dtype=np.float32) / 255.0
    g = TEXT_GAMMA
    rgb_gamma = ((1.0 - a[..., None]) * region[..., :3] ** g + a[..., None] * fg ** g) ** (1.0 / g)
    ba = region[..., 3:4]
    # over transparent/partly transparent pixels: ordinary "over" compositing
    out_a = a[..., None] + ba * (1.0 - a[..., None])
    with np.errstate(invalid="ignore", divide="ignore"):
        rgb_over = np.where(out_a > 0, (fg * a[..., None] + region[..., :3] * ba * (1.0 - a[..., None])) / out_a, 0.0)
    opaque = ba >= 0.999
    out = np.empty_like(region)
    out[..., :3] = np.where(opaque, rgb_gamma, rgb_over)
    out[..., 3:4] = np.where(opaque, 1.0, out_a)
    base.paste(Image.fromarray(np.clip(out * 255.0 + 0.5, 0, 255).astype(np.uint8)), (x0, y0))


def draw(base, text, font, x, baseline, rgb, opacity=1.0, tracking_px=0.0):
    """Draw `text` with its pen at `x` and baseline `baseline` onto RGBA `base`."""
    res = coverage([(text, font, x, baseline, tracking_px)])
    if res is not None:
        composite(base, res[0], res[1], res[2], rgb, opacity)


def baked_alpha(cov, left, top, rgb, backdrop):
    """Alpha for a text layer's preview pixels so that normal compositing over
    `backdrop` (RGB image of what is under the layer) shows the gamma-blended
    result Photoshop draws once it renders the layer itself."""
    a = np.asarray(cov, dtype=np.float32) / 255.0
    bw, bh = backdrop.size
    box = (max(0, left), max(0, top), min(bw, left + cov.width), min(bh, top + cov.height))
    bg = np.zeros(a.shape + (3,), dtype=np.float32)
    if box[2] > box[0] and box[3] > box[1]:
        bg[box[1] - top:box[3] - top, box[0] - left:box[2] - left] = (
            np.asarray(backdrop.crop(box).convert("RGB"), dtype=np.float32) / 255.0)
    fg = np.asarray(rgb[:3], dtype=np.float32) / 255.0
    g = TEXT_GAMMA
    want = ((1.0 - a[..., None]) * bg ** g + a[..., None] * fg ** g) ** (1.0 / g)
    den = fg - bg
    with np.errstate(invalid="ignore", divide="ignore"):
        est = np.where(np.abs(den) > 0.02, (want - bg) / den, a[..., None])
    # luminance-weighted channel average keeps colour accurate on mixed backdrops
    w = np.abs(den) + 1e-6
    alpha = np.clip((est * w).sum(-1) / w.sum(-1), 0.0, 1.0)
    alpha = np.where(a <= 0, 0.0, np.where(a >= 1, 1.0, alpha))
    return Image.fromarray(np.clip(alpha * 255.0 + 0.5, 0, 255).astype(np.uint8))
