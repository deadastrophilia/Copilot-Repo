"""global_light — the project's Photoshop "Global Light" (Layer › Layer Style › Global Light).

A drop shadow, inner shadow or bevel with "Use Global Light" ticked ignores its own angle in Photoshop:
it takes the DOCUMENT's global angle (and the bevel its global altitude). Those live in the PSD's image
resources 1037 / 1049; a PSD without them is read as 30° — every such shadow then falls down-left.

One global light per project: dynamic_settings["fx_global_light"] = {"angle": deg, "altitude": deg},
taken from the PSD the styles came from (read_psd) or from Photoshop's open document ("Copy from
Photoshop"). Both preview engines (ps_fx_png.py, static/ps_fx_canvas.js) draw those effects at it, the
PSD writer stores it in every PSD it builds (resource_blocks), "Verify in Photoshop" sets it.

Not set: each effect keeps the angle saved in its style (what the previews always drew), and built PSDs
get the angle those styles agree on (for_document) — so nothing changes until a light is known.

Like row_roles / page_boxes, the server and every build load it with set_all(dynamic_settings).
"""

from __future__ import annotations

import struct

# effects that follow the global light, and what of it they take
_KINDS = {"drop_shadow": ("angle",), "inner_shadow": ("angle",), "bevel": ("angle", "altitude")}
PSD_DEFAULT = {"angle": 30.0, "altitude": 30.0}          # what Photoshop assumes without the resources
GLOBAL_ANGLE, GLOBAL_ALTITUDE = 1037, 1049

_STATE = {}


def _num(v):
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    return f if f == f else None


def clean(value):
    """{"angle", "altitude"} from a saved value, or None (angle -180..180, altitude 0..90)."""
    if not isinstance(value, dict):
        return None
    a = _num(value.get("angle"))
    if a is None:
        return None
    a = ((a + 180.0) % 360.0) - 180.0
    alt = _num(value.get("altitude"))
    alt = 30.0 if alt is None else max(0.0, min(90.0, alt))
    return {"angle": a, "altitude": alt}


def resolve(dynamic_settings):
    return clean((dynamic_settings or {}).get("fx_global_light") if isinstance(dynamic_settings, dict) else None)


def set_all(dynamic_settings):
    """Use this project's global light from now on (the server and every build call this)."""
    light = resolve(dynamic_settings)
    _STATE.clear()
    if light:
        _STATE.update(light)


def current():
    return dict(_STATE) if _STATE else None


def apply(params, light=None):
    """Captured params with every "Use Global Light" effect at the global light (a copy; params as they
    are when no light is set). Idempotent."""
    light = clean(light) if light is not None else current()
    if not light or not isinstance(params, dict):
        return params
    out = None
    for kind, keys in _KINDS.items():
        eff = params.get(kind)
        items = eff if isinstance(eff, list) else [eff]
        if not any(isinstance(e, dict) and e.get("use_global_light") for e in items):
            continue
        fixed = [dict(e, **{k: light[k] for k in keys}) if isinstance(e, dict) and e.get("use_global_light") else e
                 for e in items]
        out = dict(params) if out is None else out
        out[kind] = fixed if isinstance(eff, list) else fixed[0]
    return params if out is None else out


def style_angles(fx_configs):
    """[(angle, altitude)] of the "Use Global Light" effects in these style configs (what they were saved at)."""
    from . import fx_descriptor

    found = []
    for cfg in fx_configs or []:
        try:
            params = fx_descriptor.effective_params(cfg) if isinstance(cfg, dict) else None
        except Exception:
            params = None
        if not isinstance(params, dict):
            continue
        for kind in _KINDS:
            eff = params.get(kind)
            for e in eff if isinstance(eff, list) else [eff]:
                if isinstance(e, dict) and e.get("use_global_light") and e.get("enabled", True) is not False:
                    a = _num(e.get("angle"))
                    if a is not None:
                        found.append((a, _num(e.get("altitude"))))
    return found


def for_document(dynamic_settings):
    """The global light a PSD built for this project gets: the project's, else the angle its styles'
    "Use Global Light" effects were saved at (the most used one) — what the previews draw — else None
    (no such effects: nothing in the document depends on it)."""
    light = resolve(dynamic_settings)
    if light:
        return light
    lib = (dynamic_settings or {}).get("layer_style_library") if isinstance(dynamic_settings, dict) else None
    found = style_angles(list(lib.values()) if isinstance(lib, dict) else [])
    if not found:
        return None
    counts = {}
    for a, _alt in found:
        counts[a] = counts.get(a, 0) + 1
    angle = max(counts, key=lambda a: (counts[a], -found.index(next(f for f in found if f[0] == a))))
    alts = [alt for a, alt in found if a == angle and alt is not None]
    return clean({"angle": angle, "altitude": alts[0] if alts else 30.0})


# ── the PSD's image resources ────────────────────────────────────────────────
def read_psd(path):
    """{"angle", "altitude"} stored in a PSD / PSB (read from its header only — fast on 500 MB files),
    PSD_DEFAULT when the file has none, None when it can't be read."""
    try:
        with open(str(path), "rb") as fh:
            if fh.read(26)[:4] != b"8BPS":
                return None
            fh.seek(struct.unpack(">I", fh.read(4))[0], 1)          # colour mode data
            data = fh.read(struct.unpack(">I", fh.read(4))[0])
    except (OSError, struct.error, ValueError, TypeError):
        return None
    found, i = {}, 0
    while i + 12 <= len(data) and data[i:i + 4] == b"8BIM":
        rid = struct.unpack(">H", data[i + 4:i + 6])[0]
        n = data[i + 6]
        i += 6 + 1 + n + ((1 + n) % 2)                               # Pascal name, padded to even
        size = struct.unpack(">I", data[i:i + 4])[0]
        i += 4
        if rid in (GLOBAL_ANGLE, GLOBAL_ALTITUDE) and size >= 4:
            found[rid] = struct.unpack(">i", data[i:i + 4])[0]
        i += size + (size % 2)
    if not found:
        return dict(PSD_DEFAULT)
    return clean({"angle": found.get(GLOBAL_ANGLE, PSD_DEFAULT["angle"]),
                  "altitude": found.get(GLOBAL_ALTITUDE, PSD_DEFAULT["altitude"])})


def write_resources(psd, light):
    """Store the light in a psd_tools PSDImage's image resources (1037 / 1049)."""
    light = clean(light)
    if not light:
        return False
    from psd_tools.constants import Resource
    from psd_tools.psd.image_resources import ImageResource

    resources = psd._record.image_resources
    for rid, value in ((Resource.GLOBAL_ANGLE, light["angle"]), (Resource.GLOBAL_ALTITUDE, light["altitude"])):
        resources[rid] = ImageResource(key=rid, name="", data=struct.pack(">i", int(round(value))))
    return True
