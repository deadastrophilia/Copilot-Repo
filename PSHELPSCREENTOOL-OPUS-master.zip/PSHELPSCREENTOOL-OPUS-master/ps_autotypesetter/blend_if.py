"""Photoshop's Blending Options › Blend If (Gray), "Underlying Layer" sliders.

A layer shows only where what lies UNDER it is between the black and white sliders: an artist's heading
with the white slider at 252 vanishes on a white background and shows on a dark one. Each slider can be
split (Alt-drag) into a ramp, so a range is four numbers 0–255: [black low, black high, white low, white
high]; outside it the layer is hidden, on a ramp partly shown (it acts like the layer's opacity, layer
style included).

It travels with the layer style (Photoshop keeps it in the same dialog): style["blend_if"] =
{"under": [b0, b1, w0, w1]}. The build masks what the layer drew (apply), the PSD writer sets the layer's
blending ranges (to_ranges) and the Canvas mirrors mask() in visualiser_live.js (blendIfMix).
"""

import numpy as np

DEFAULT = (0, 0, 255, 255)


def clean(value):
    """[b0, b1, w0, w1] (ints 0–255, ordered) or None when unset / the default (no effect)."""
    if isinstance(value, dict):
        value = value.get("under")
    try:
        vals = [max(0, min(255, int(round(float(v))))) for v in value]
    except (TypeError, ValueError):
        return None
    if len(vals) == 2:                                    # unsplit sliders: [black, white]
        vals = [vals[0], vals[0], vals[1], vals[1]]
    if len(vals) != 4:
        return None
    b0, b1, w0, w1 = vals
    b1, w1 = max(b0, b1), max(w0, w1)
    if w0 < b1:
        w0 = b1
        w1 = max(w0, w1)
    out = [b0, b1, w0, w1]
    return None if tuple(out) == DEFAULT else out


def of(style):
    """The Underlying Layer range of a layer style, or None."""
    return clean(style.get("blend_if")) if isinstance(style, dict) and style.get("blend_if") else None


def without(style):
    """The style without its Blend If (what is drawn before the mask)."""
    if not isinstance(style, dict) or "blend_if" not in style:
        return style
    return {k: v for k, v in style.items() if k != "blend_if"}


def from_ranges(blending_ranges):
    """[b0, b1, w0, w1] from a psd_tools LayerBlendingRanges (its composite gray "underlying" pair), or None.

    Photoshop stores each slider as two bytes (the split halves): 0xFCFC = 252 / 252."""
    try:
        black, white = blending_ranges.composite_ranges[1]
    except Exception:
        return None
    return clean([(int(black) >> 8) & 255, int(black) & 255, (int(white) >> 8) & 255, int(white) & 255])


def to_ranges(blending_ranges, under):
    """Write `under` into a psd_tools LayerBlendingRanges (in place)."""
    b0, b1, w0, w1 = under
    ranges = list(blending_ranges.composite_ranges)
    ranges[1] = ((b0 << 8) | b1, (w0 << 8) | w1)
    blending_ranges.composite_ranges = ranges


def gray(rgb):
    """Photoshop's Blend If gray of RGB values (0–255, float array [..., 3])."""
    return rgb[..., 0] * 0.3 + rgb[..., 1] * 0.59 + rgb[..., 2] * 0.11


def mask(g, under):
    """How much of the layer shows (0–1) over underlying gray `g`."""
    b0, b1, w0, w1 = under
    g = np.asarray(g, np.float32)
    k = np.ones_like(g)
    k = np.where(g < b0, 0.0, k)
    if b1 > b0:
        k = np.where((g >= b0) & (g < b1), (g - b0) / float(b1 - b0), k)
    if w1 > w0:
        k = np.where((g > w0) & (g <= w1), (w1 - g) / float(w1 - w0), k)
    k = np.where(g > w1, 0.0, k)
    return k


def apply(base, before, under, box=None):
    """`base` (RGBA, the layer already drawn onto `before`, a copy of what was under it): keep only as much
    of the layer as Blend If shows. In place; `box` limits the work (default: where they differ)."""
    from PIL import ImageChops

    if box is None:
        # (every channel: an RGBA image's getbbox looks at the alpha alone)
        box = ImageChops.difference(base.convert("RGBA"), before.convert("RGBA")).getbbox(alpha_only=False)
    if not box:
        return
    a = np.asarray(before.crop(box).convert("RGBA"), np.float32)
    b = np.asarray(base.crop(box).convert("RGBA"), np.float32)
    # what is under: the backdrop's colour (a transparent backdrop counts as black, nothing hides there)
    k = mask(gray(a[..., :3] * (a[..., 3:4] / 255.0)), under)[..., None]
    out = a + (b - a) * k
    from PIL import Image

    base.paste(Image.fromarray(np.clip(out + 0.5, 0, 255).astype(np.uint8)), box[:2])
