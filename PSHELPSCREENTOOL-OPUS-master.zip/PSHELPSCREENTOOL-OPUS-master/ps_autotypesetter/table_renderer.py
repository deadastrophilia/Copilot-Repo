﻿import json
import os
import re

import photoshop.api as ps
from .config import TABLE_DEFAULTS
from .icon_mapping import get_icon_size_override, resolve_icon_path
from .table_mapping import (
    _bounds_slot_for_table,
    _slot_name_is_bounds_like,
    direct_range_bounds,
    parse_table_slot_ref,
    remove_token_indexes,
    resolve_table_source_text,
    resolve_table_token,
    source_for_row_offset,
)
from .text_icon_renderer import (
    _icon_dup_group_id,
    _measure_text_cached,
    _place_icon_duplicate_com,
    _render_cell_with_icons,
    _render_text_with_keyword_overlays,
    flush_text_spec_batch,
)
from .layer_styles import apply_heading_layer_style, apply_style_to_group_text_layers
from .photoshop_fonts import resolve_photoshop_font


_FONT_RESOLVE_CACHE = {}


def _table_text_batch_active():
    """Tables create every cell text layer in ONE JSX eval (mega mode).

    Mirrors the engine-wide PSH_MEGA_BATCH switch so table rendering follows
    the same batching policy as body text. Per-text-spec creation goes through
    the JSX template+duplicate path, so a 46-cell table costs one COM round
    trip for its text instead of ~46."""
    return os.environ.get("PSH_MEGA_BATCH", "1") != "0"


def _flush_icon_dup_entries(entries, app, doc):
    """Duplicate + scale + position every table icon occurrence in ONE JSX eval.

    Falls back to the per-icon COM path if the batched eval fails.
    entries: list of dicts with src/src_id/group/group_id/scale_pct/x/y."""
    if not entries:
        return
    payload = [
        {
            "id": int(entry["src_id"]),
            "g": entry["group_id"] if entry.get("group_id") is not None else 0,
            "s": float(entry["scale_pct"]),
            "x": float(entry["x"]),
            "y": float(entry["y"]),
        }
        for entry in entries
    ]
    jsx = r"""
    (function(){
        function __artById(doc, id){
            for (var i = 0; i < doc.layers.length; i++) {
                var L = doc.layers[i];
                if (L.id == id) return L;
                if (L.typename == "LayerSet") {
                    var hit = __artById(L, id);
                    if (hit) return hit;
                }
            }
            return null;
        }
        function __setById(doc, id){
            for (var i = 0; i < doc.layers.length; i++) {
                var L = doc.layers[i];
                if (L.id == id) return L;
                if (L.typename == "LayerSet") {
                    var hit = __setById(L, id);
                    if (hit) return hit;
                }
            }
            return null;
        }
        var __entries = __ICON_ENTRIES__;
        for (var e = 0; e < __entries.length; e++) {
            (function(){
                var ent = __entries[e];
                var src = __artById(doc, ent.id);
                if (src == null) return;
                var d = src.duplicate();
                var tg = (ent.g > 0) ? __setById(doc, ent.g) : null;
                if (tg != null) d.move(tg, ElementPlacement.INSIDE);
                d.visible = true;
                var b = d.bounds;
                var h0 = b[3].value - b[1].value;
                var scl = Math.max(0.1, Math.min(10000.0, (ent.s / h0) * 100.0));
                d.resize(scl, scl, AnchorPosition.TOPLEFT);
                var b2 = d.bounds;
                d.translate(ent.x - b2[0].value, ent.y - b2[1].value);
            })();
        }
    })();
    """.replace("__ICON_ENTRIES__", json.dumps(payload))
    try:
        app.doJavaScript(jsx)
        return
    except Exception as exc:
        print(f"Icon batch flush failed ({len(entries)} icons); falling back to COM: {exc}")
    for entry in entries:
        try:
            _place_icon_duplicate_com(
                entry["src"], entry["group"], entry["scale_pct"], entry["x"], entry["y"]
            )
        except Exception:
            pass


def _excel_column_name(col_idx):
    try:
        col_idx = int(col_idx)
    except Exception:
        return ""
    if col_idx <= 0:
        return ""
    letters = ""
    while col_idx:
        col_idx, remainder = divmod(col_idx - 1, 26)
        letters = chr(65 + remainder) + letters
    return letters


def _cell_coord_keys(cell, row_idx, col_idx):
    keys = []
    coord = str((cell or {}).get("coord") or (cell or {}).get("source") or "").strip().upper()
    if not coord:
        col_name = _excel_column_name(col_idx)
        if col_name:
            coord = f"{col_name}{int(row_idx)}"
    if coord:
        keys.append(coord)
    keys.append(f"{int(row_idx)}:{int(col_idx)}")
    keys.append((int(row_idx), int(col_idx)))
    return keys


def _coerce_rgb_tuple(value):
    if not value:
        return None
    try:
        r, g, b = value
        return (int(r), int(g), int(b))
    except Exception:
        return None


def _bounds_to_floats(bounds):
    try:
        return [float(bounds[i]) for i in range(4)]
    except Exception:
        return None


def _collect_group_bounds(layer_group):
    boxes = []
    try:
        for layer in list(layer_group.artLayers):
            box = _bounds_to_floats(layer.bounds)
            if box and (box[2] - box[0]) > 0 and (box[3] - box[1]) > 0:
                boxes.append(box)
        for child in list(layer_group.layerSets):
            box = _collect_group_bounds(child)
            if box:
                boxes.append(box)
    except Exception:
        pass
    if not boxes:
        return None
    return [
        min(box[0] for box in boxes),
        min(box[1] for box in boxes),
        max(box[2] for box in boxes),
        max(box[3] for box in boxes),
    ]


def _translate_group_items(layer_group, dx, dy=0):
    try:
        for layer in list(layer_group.artLayers):
            try:
                layer.translate(dx, dy)
            except Exception:
                pass
        for child in list(layer_group.layerSets):
            _translate_group_items(child, dx, dy)
    except Exception:
        pass


def _center_group_horizontally(layer_group, canvas_width):
    bounds = _collect_group_bounds(layer_group)
    if not bounds:
        return None
    width = bounds[2] - bounds[0]
    desired_left = (float(canvas_width) - width) / 2.0
    dx = desired_left - bounds[0]
    if abs(dx) > 0.5:
        _translate_group_items(layer_group, dx, 0)
        bounds = _collect_group_bounds(layer_group) or bounds
    return bounds


def _target_table_height(table_style):
    try:
        return max(0.0, float((table_style or {}).get("table_target_height", 0) or 0))
    except Exception:
        return 0.0


def _scale_group_to_target_height(layer_group, target_height):
    target_height = float(target_height or 0)
    if target_height <= 0:
        return None
    bounds = _collect_group_bounds(layer_group)
    if not bounds:
        return None
    current_h = max(1.0, bounds[3] - bounds[1])
    scale_pct = max(1.0, min(10000.0, (target_height / current_h) * 100.0))
    try:
        layer_group.resize(scale_pct, scale_pct)
    except Exception:
        return None
    scaled_bounds = _collect_group_bounds(layer_group) or bounds
    dx = bounds[0] - scaled_bounds[0]
    dy = bounds[1] - scaled_bounds[1]
    if abs(dx) > 0.5 or abs(dy) > 0.5:
        _translate_group_items(layer_group, dx, dy)
        scaled_bounds = _collect_group_bounds(layer_group) or scaled_bounds
    return scaled_bounds


def _normalize_alignment(value, fallback="center"):
    value = str(value or "").strip().lower()
    if value == "justify":
        return "left"
    if value in ("left", "center", "right"):
        return value
    return fallback


def _aligned_cell_x(alignment, cell_left, cell_width, content_width, padding=0):
    alignment = _normalize_alignment(alignment)
    cell_left = float(cell_left)
    cell_width = max(1.0, float(cell_width))
    content_width = float(content_width or 0)
    padding = max(0.0, float(padding or 0))
    if alignment == "left":
        return cell_left + padding
    if alignment == "right":
        return cell_left + cell_width - padding - content_width
    return cell_left + (cell_width - content_width) / 2.0


def _solid_color(rgb_tuple, fallback=None):
    color = ps.SolidColor()
    values = rgb_tuple if rgb_tuple is not None else fallback
    try:
        color.rgb.red, color.rgb.green, color.rgb.blue = [int(v) for v in values]
    except Exception:
        color.rgb.red, color.rgb.green, color.rgb.blue = 255, 255, 255
    return color


def _safe_int(value, fallback=0):
    try:
        return int(float(value))
    except Exception:
        return int(fallback)


def _safe_float(value, fallback=0.0):
    try:
        return float(value)
    except Exception:
        return float(fallback)


def _table_max_width(c_width, table_style):
    margin_x = max(0.0, _safe_float((table_style or {}).get("table_margin_x", 60), 60))
    return max(1.0, float(c_width) - (margin_x * 2.0))


def _auto_cell_padding_x(table_style):
    return max(10, _safe_int((table_style or {}).get("cell_padding_x", 10), 10))


def _measurement_guard_x(font_size, icon_height, table_style):
    explicit = _safe_float((table_style or {}).get("cell_measurement_guard_x", -1), -1)
    if explicit >= 0:
        return max(0.0, explicit)
    # Photoshop's final text/icon placement can be a little wider than the text
    # measuring layer. Keep a small per-side cushion so content does not kiss the
    # stroke or wrap by a single trailing word.
    return max(12.0, min(32.0, float(font_size or 0) * 0.8, float(icon_height or 0) * 0.75))


def _table_left_for_width(c_width, table_width, table_style):
    for key in ("table_x", "table_left"):
        if (table_style or {}).get(key) not in (None, ""):
            left = _safe_float((table_style or {}).get(key), 0)
            return max(0.0, min(float(c_width) - float(table_width), left))
    return max(0.0, (float(c_width) - float(table_width)) / 2.0)


def _manual_table_width(c_width, table_style):
    style = table_style or {}
    max_width = _table_max_width(c_width, style)
    for key in ("table_target_width", "table_width_px", "table_manual_width"):
        value = _safe_float(style.get(key), 0)
        if value > 0:
            return max(1.0, min(max_width, value))
    mode = str(style.get("table_width_mode") or "content").strip().casefold()
    if mode in {"fixed", "percent", "percentage", "full", "stretch"}:
        pct = max(1.0, min(100.0, _safe_float(style.get("table_width_pct", 85), 85)))
        return max(1.0, min(max_width, float(c_width) * pct / 100.0))
    return 0.0


def _content_table_width(c_width, column_count, widest_column_width, table_style, border_extra=0.0):
    column_count = max(1, int(column_count or 1))
    max_width = _table_max_width(c_width, table_style)
    manual_width = _manual_table_width(c_width, table_style)
    if manual_width > 0:
        inner_width = max(1.0, manual_width - float(border_extra or 0))
        column_width = max(1.0, inner_width / float(column_count))
        table_width = (column_width * column_count) + float(border_extra or 0)
    else:
        column_width = max(1.0, float(widest_column_width or 1.0))
        table_width = (column_width * column_count) + float(border_extra or 0)
        if table_width > max_width:
            inner_width = max(1.0, max_width - float(border_extra or 0))
            column_width = max(1.0, inner_width / float(column_count))
            table_width = (column_width * column_count) + float(border_extra or 0)
    table_width = min(max_width, table_width)
    return table_width, column_width


def _scale_col_widths_to_inner_width(col_widths, target_inner_width):
    """Scale existing column widths to a target total while preserving proportions."""
    target_inner_width = max(1.0, float(target_inner_width or 1.0))
    ordered = list(col_widths.keys())
    current_inner_width = sum(max(1.0, float(col_widths.get(col, 1.0))) for col in ordered)
    if current_inner_width <= 0:
        fallback = target_inner_width / float(max(1, len(ordered)))
        return {col: fallback for col in ordered}
    scale = target_inner_width / current_inner_width
    return {col: max(1.0, float(col_widths.get(col, 1.0)) * scale) for col in ordered}


def _resolve_natural_table_widths(c_width, table_style, natural_col_widths, border_extra=0.0):
    """Return per-column widths and table width for auto/simple tables.

    In content mode the table keeps each column's own measured natural width and
    clamps proportionally only when the full table would exceed the safe width.
    Manual width settings still scale the measured widths to the requested total.
    """
    col_widths = {col: max(1.0, float(width or 1.0)) for col, width in (natural_col_widths or {}).items()}
    if not col_widths:
        col_widths = {1: 1.0}
    max_width = _table_max_width(c_width, table_style)
    max_inner_width = max(1.0, max_width - float(border_extra or 0.0))
    manual_width = _manual_table_width(c_width, table_style)
    natural_inner_width = sum(col_widths.values())

    if manual_width > 0:
        target_inner_width = max(1.0, min(max_width, manual_width) - float(border_extra or 0.0))
        col_widths = _scale_col_widths_to_inner_width(col_widths, target_inner_width)
    elif natural_inner_width > max_inner_width:
        col_widths = _scale_col_widths_to_inner_width(col_widths, max_inner_width)

    table_width = min(max_width, sum(col_widths.values()) + float(border_extra or 0.0))
    return table_width, col_widths


def _span_column_indices(cols, start_col, colspan):
    """Resolve a cell's spanned columns using the detected table column order."""
    colspan = max(1, int(colspan or 1))
    try:
        start_index = cols.index(start_col)
        span = cols[start_index:start_index + colspan]
        if span:
            return span
    except ValueError:
        pass
    return [start_col + offset for offset in range(colspan)]


def _resolve_font_for_render(app, requested_font, fallback="ArialMT"):
    requested = str(requested_font or fallback or "").strip()
    if not requested:
        return str(fallback or "ArialMT")
    if app is None:
        return requested
    cache_key = requested.casefold()
    if cache_key in _FONT_RESOLVE_CACHE:
        return _FONT_RESOLVE_CACHE[cache_key]
    try:
        resolved = resolve_photoshop_font(app, requested)
    except Exception:
        resolved = requested
    resolved = str(resolved or requested).strip() or requested
    _FONT_RESOLVE_CACHE[cache_key] = resolved
    return resolved


def _mapping_font_request(mapping):
    for key in ("font_name", "font_postscript", "postscript_name"):
        value = str((mapping or {}).get(key) or "").strip()
        if value:
            return value
    family = str((mapping or {}).get("font_family") or "").strip()
    style = str((mapping or {}).get("font_style") or (mapping or {}).get("font_weight") or "").strip()
    if not family:
        return ""
    if style and style.casefold() != "regular":
        return f"{family} {style}"
    if bool((mapping or {}).get("bold")) and bool((mapping or {}).get("italic")):
        return f"{family} Bold Italic"
    if bool((mapping or {}).get("bold")):
        return f"{family} Bold"
    if bool((mapping or {}).get("italic")):
        return f"{family} Italic"
    return family


def _role_font_name(mapping, role, table_style, base_font_name, app):
    # Mapped @table JSON owns its text settings. The auto-table UI font controls
    # must not override mapper slot fonts.
    requested = _mapping_font_request(mapping)
    if not requested:
        requested = base_font_name
    return _resolve_font_for_render(app, requested, base_font_name or "ArialMT")


def _role_font_size(mapping, role, table_style, base_font_size):
    return max(1, _safe_int((mapping or {}).get("font_size"), base_font_size or 30))


def _role_line_height(mapping, role, table_style):
    for key in ("line_height", "leading"):
        value = _safe_int((mapping or {}).get(key), 0)
        if value > 0:
            return value
    return 0


def _table_font_settings(table_style, base_font_name, base_font_size):
    body_font_name = str(table_style.get("table_body_font_name") or table_style.get("table_font_name") or base_font_name)
    header_font_name = str(table_style.get("table_header_font_name") or table_style.get("table_font_name") or body_font_name)

    try:
        body_override = int(table_style.get("table_body_font_size") or 0)
    except Exception:
        body_override = 0
    try:
        header_override = int(table_style.get("table_header_font_size") or 0)
    except Exception:
        header_override = 0

    initial_body_font = body_override if body_override > 0 else base_font_size - table_style['table_body_font_size_delta']
    initial_header_font = header_override if header_override > 0 else base_font_size - table_style['header_font_size_delta']
    return header_font_name, body_font_name, max(1, int(initial_header_font)), max(1, int(initial_body_font))


def _float_setting(table_style, key, fallback):
    try:
        return float(table_style.get(key, fallback))
    except Exception:
        return float(fallback)


def _height_metrics(table_style, has_header, num_data_rows, header_font_size, body_font_size, icon_height, row_gap):
    border_width = int(table_style.get('border_width', 2))
    row_mult = max(1.0, _float_setting(table_style, "row_height_multiplier", 1.2))
    header_mult = max(1.0, _float_setting(table_style, "header_height_multiplier", 1.2))
    padding_y = max(0, int(table_style.get('cell_padding_y', 18)))
    row_line_height = _safe_float(table_style.get("table_body_line_height"), 0)
    header_line_height = _safe_float(table_style.get("table_header_line_height"), 0)
    row_basis = max(float(body_font_size), float(icon_height), row_line_height)
    header_basis = max(float(header_font_size), header_line_height)
    row_h = max(int(row_basis * row_mult + 0.5), int(row_basis) + (padding_y * 2))
    header_h = max(int(header_basis * header_mult + 0.5), int(header_basis) + (padding_y * 2)) if has_header else 0
    total_row_h = border_width * 2
    if has_header:
        total_row_h += header_h + row_gap
    total_row_h += num_data_rows * row_h
    if num_data_rows > 1:
        total_row_h += (num_data_rows - 1) * row_gap
    return header_h, row_h, total_row_h


def _table_metrics(table_data, c_width, base_font_name, base_font_size, icon_height,
                   table_style=None, measure_layer=None, font_cache=None,
                   icon_size_overrides=None, gap_px=0, icon_folder=None, icon_mappings=None):
    """Compute table size before drawing.

    The build engine uses this to decide whether a table fits in the remaining
    page space. V33 used a fixed 300 px estimate, which allowed large tables to
    start too low and create ugly overflow/overlay artifacts.
    """
    if table_style is None:
        table_style = TABLE_DEFAULTS.copy()
    if font_cache is None:
        font_cache = {}

    num_data_rows = len(table_data['data_rows'])
    has_header = bool(table_data['header_row'])
    cols = [c_idx for _, c_idx in table_data['columns']]
    row_gap = max(0, int(table_style.get('row_gap', 0)))
    border_width = max(0, int(table_style.get('border_width', 2)))
    padding_x = _auto_cell_padding_x(table_style)
    padding_y = max(0, int(table_style.get('cell_padding_y', 5)))
    content_width_mode = _manual_table_width(c_width, table_style) <= 0

    header_font_name, body_font_name, initial_header_font, initial_body_font = _table_font_settings(
        table_style, base_font_name, base_font_size
    )
    min_body_font = 10

    try:
        requested_table_icon_h = int(table_style.get("table_icon_height") or 0)
    except Exception:
        requested_table_icon_h = 0
    body_font_locked = int(table_style.get("table_body_font_size") or 0) > 0
    header_font_locked = int(table_style.get("table_header_font_size") or 0) > 0
    icon_height_locked = requested_table_icon_h > 0

    current_body_font = initial_body_font
    current_header_font = initial_header_font
    initial_table_icon_h = requested_table_icon_h if requested_table_icon_h > 0 else initial_body_font
    table_icon_h = initial_table_icon_h
    border_extra = border_width * (len(cols) + 1)
    max_inner_w = max(1.0, _table_max_width(c_width, table_style) - border_extra)

    def _measure_natural_col_widths():
        widths = {col_idx: max(24.0, float(current_body_font) + (padding_x * 2)) for col_idx in cols}
        if has_header:
            for col_idx, text in table_data['header_row'].items():
                if col_idx in cols:
                    w = _estimate_inline_width(
                        str(text), current_header_font, header_font_name, table_icon_h, gap_px,
                        measure_layer, font_cache, icon_size_overrides=icon_size_overrides,
                        icon_folder=icon_folder, icon_mappings=icon_mappings
                    )
                    guard_x = _measurement_guard_x(current_header_font, table_icon_h, table_style)
                    widths[col_idx] = max(widths.get(col_idx, 24.0), w + padding_x * 2 + guard_x * 2)

        for row_data in table_data['data_rows']:
            for col_idx, text in row_data.items():
                if col_idx in cols:
                    w = _estimate_inline_width(
                        str(text), current_body_font, body_font_name, table_icon_h, gap_px,
                        measure_layer, font_cache, icon_size_overrides=icon_size_overrides,
                        icon_folder=icon_folder, icon_mappings=icon_mappings
                    )
                    guard_x = _measurement_guard_x(current_body_font, table_icon_h, table_style)
                    widths[col_idx] = max(widths.get(col_idx, 24.0), w + padding_x * 2 + guard_x * 2)
        return widths

    while True:
        _premeasure_table_texts(
            ([(str(v), current_header_font, header_font_name) for v in (table_data.get("header_row") or {}).values()] +
             [(str(v), current_body_font, body_font_name) for row_data in (table_data.get("data_rows") or []) for v in row_data.values()]),
            measure_layer, font_cache
        )
        natural_col_widths = _measure_natural_col_widths()
        total_content_w = sum(natural_col_widths.values())
        if content_width_mode or total_content_w <= max_inner_w or current_body_font <= min_body_font:
            break
        if body_font_locked or header_font_locked:
            break

        current_body_font -= 1
        if not header_font_locked:
            delta = initial_header_font - initial_body_font
            current_header_font = current_body_font + delta
        scale_ratio = current_body_font / initial_body_font if initial_body_font else 1
        if not icon_height_locked:
            table_icon_h = max(int(initial_table_icon_h * scale_ratio), 8)

    table_width, col_widths = _resolve_natural_table_widths(
        c_width, table_style, natural_col_widths, border_extra=border_extra
    )
    table_left = _table_left_for_width(c_width, table_width, table_style)

    header_font_size = current_header_font
    table_body_font_size = current_body_font
    header_h, row_h, total_row_h = _height_metrics(
        table_style, has_header, num_data_rows, header_font_size,
        table_body_font_size, table_icon_h, row_gap
    )
    header_line_height = _safe_int(table_style.get("table_header_line_height"), 0)
    body_line_height = _safe_int(table_style.get("table_body_line_height"), 0)
    if has_header:
        for col_idx, text in table_data.get("header_row", {}).items():
            if col_idx not in cols:
                continue
            inner_w = max(1.0, float(col_widths.get(col_idx, 24.0)) - (padding_x * 2))
            header_h = max(
                header_h,
                int(_estimate_wrapped_height(
                    str(text or ""), inner_w, header_font_size, header_font_name,
                    table_icon_h, gap_px, measure_layer, font_cache,
                    line_height=header_line_height, icon_size_overrides=icon_size_overrides,
                    icon_folder=icon_folder, icon_mappings=icon_mappings
                ) + (padding_y * 2) + 0.5)
            )

    for row_data in table_data.get("data_rows", []):
        for col_idx, text in row_data.items():
            if col_idx not in cols:
                continue
            inner_w = max(1.0, float(col_widths.get(col_idx, 24.0)) - (padding_x * 2))
            row_h = max(
                row_h,
                int(_estimate_wrapped_height(
                    str(text or ""), inner_w, table_body_font_size, body_font_name,
                    table_icon_h, gap_px, measure_layer, font_cache,
                    line_height=body_line_height, icon_size_overrides=icon_size_overrides,
                    icon_folder=icon_folder, icon_mappings=icon_mappings
                ) + (padding_y * 2) + 0.5)
            )

    total_row_h = border_width * 2
    if has_header:
        total_row_h += header_h + row_gap
    total_row_h += num_data_rows * row_h
    if num_data_rows > 1:
        total_row_h += (num_data_rows - 1) * row_gap

    try:
        max_table_height = int(table_style.get("max_table_height") or 0)
    except Exception:
        max_table_height = 0
    while _target_table_height(table_style) <= 0 and max_table_height > 0 and total_row_h > max_table_height and current_body_font > min_body_font:
        if body_font_locked or header_font_locked:
            break
        current_body_font -= 1
        if not header_font_locked:
            delta = initial_header_font - initial_body_font
            current_header_font = max(8, current_body_font + delta)
        scale_ratio = current_body_font / initial_body_font if initial_body_font else 1
        if not icon_height_locked:
            table_icon_h = max(int(initial_table_icon_h * scale_ratio), 8)
        header_font_size = current_header_font
        table_body_font_size = current_body_font
        _premeasure_table_texts(
            ([(str(v), header_font_size, header_font_name) for v in (table_data.get("header_row") or {}).values()] +
             [(str(v), table_body_font_size, body_font_name) for row_data in (table_data.get("data_rows") or []) for v in row_data.values()]),
            measure_layer, font_cache
        )
        header_h, row_h, total_row_h = _height_metrics(
            table_style, has_header, num_data_rows, header_font_size,
            table_body_font_size, table_icon_h, row_gap
        )
        header_line_height = _safe_int(table_style.get("table_header_line_height"), 0)
        body_line_height = _safe_int(table_style.get("table_body_line_height"), 0)
        if has_header:
            for col_idx, text in table_data.get("header_row", {}).items():
                if col_idx not in cols:
                    continue
                inner_w = max(1.0, float(col_widths.get(col_idx, 24.0)) - (padding_x * 2))
                header_h = max(
                    header_h,
                    int(_estimate_wrapped_height(
                        str(text or ""), inner_w, header_font_size, header_font_name,
                        table_icon_h, gap_px, measure_layer, font_cache,
                        line_height=header_line_height, icon_size_overrides=icon_size_overrides,
                        icon_folder=icon_folder, icon_mappings=icon_mappings) + (padding_y * 2) + 0.5)
                )
        for row_data in table_data.get("data_rows", []):
            for col_idx, text in row_data.items():
                if col_idx not in cols:
                    continue
                inner_w = max(1.0, float(col_widths.get(col_idx, 24.0)) - (padding_x * 2))
                row_h = max(
                    row_h,
                    int(_estimate_wrapped_height(
                        str(text or ""), inner_w, table_body_font_size, body_font_name,
                        table_icon_h, gap_px, measure_layer, font_cache,
                        line_height=body_line_height, icon_size_overrides=icon_size_overrides,
                        icon_folder=icon_folder, icon_mappings=icon_mappings
                    ) + (padding_y * 2) + 0.5)
                )
        total_row_h = border_width * 2
        if has_header:
            total_row_h += header_h + row_gap
        total_row_h += num_data_rows * row_h
        if num_data_rows > 1:
            total_row_h += (num_data_rows - 1) * row_gap

    return {
        'table_width': table_width,
        'table_left': table_left,
        'num_data_rows': num_data_rows,
        'has_header': has_header,
        'cols': cols,
        'row_gap': row_gap,
        'col_widths': col_widths,
        'header_font_size': header_font_size,
        'table_body_font_size': table_body_font_size,
        'header_font_name': header_font_name,
        'body_font_name': body_font_name,
        'header_h': header_h,
        'row_h': row_h,
        'total_row_h': total_row_h,
        'table_icon_h': table_icon_h,
        'padding_x': padding_x,
        'padding_y': padding_y,
    }


def _has_grid_table(table_data):
    return bool(table_data.get("grid_mode") and table_data.get("grid_cells") and table_data.get("row_indices"))


def _estimate_inline_width(text, font_size, font_name, icon_height, gap_px, measure_layer, font_cache,
                           icon_size_overrides=None, icon_folder=None, icon_mappings=None):
    width = 0.0
    for part in re.split(r"(<[^>]+>)", str(text or "")):
        if not part:
            continue
        if part.startswith("<") and part.endswith(">"):
            resolved_icon_h = _estimated_icon_height(part, icon_height, icon_size_overrides)
            token = part[1:-1].strip(" .;,-!")
            width += _estimated_icon_width(resolved_icon_h, gap_px, token, icon_folder, icon_mappings)
        else:
            width += float(_measure_text_cached(part, font_size, font_name, measure_layer, font_cache))
    return max(width, 1.0)


def _estimated_icon_height(part, icon_height, icon_size_overrides=None):
    token = str(part or "")
    if token.startswith("<") and token.endswith(">"):
        token = token[1:-1].strip(" .;,-!")
    override = get_icon_size_override(token, icon_size_overrides) if token else None
    return max(1.0, float(override or icon_height or 1.0))


_ICON_DIM_CACHE = {}


def _icon_png_dims(icon_name, icon_folder=None, icon_mappings=None):
    """Return (width, height) of an icon PNG via PIL, cached. None when unresolvable."""
    if not icon_name:
        return None
    cache_key = (icon_name, os.path.normcase(os.path.abspath(icon_folder or "")))
    if cache_key in _ICON_DIM_CACHE:
        return _ICON_DIM_CACHE[cache_key]
    dims = None
    try:
        from PIL import Image
        path = resolve_icon_path(icon_name, icon_folder, icon_mappings)
        if path and os.path.exists(path):
            with Image.open(path) as im:
                dims = (float(im.width), float(im.height))
    except Exception:
        dims = None
    _ICON_DIM_CACHE[cache_key] = dims
    return dims


def _estimated_icon_width(icon_height, gap_px, icon_name=None, icon_folder=None, icon_mappings=None):
    # Match the renderer exactly: the render phase (text_icon_renderer._render_cell_with_icons)
    # sizes icons with their REAL PNG aspect ratio, so the estimate must do the same or rows
    # sized for one line can wrap into two in the finished PSD. When the PNG cannot be read
    # (missing icon / no PIL), fall back to a conservative 1.25x so rows never come out short.
    ratio = 1.25
    dims = _icon_png_dims(icon_name, icon_folder, icon_mappings)
    if dims and float(dims[1] or 0) > 0:
        ratio = max(0.05, float(dims[0]) / float(dims[1]))
    return (float(icon_height) * ratio) + (float(gap_px or 0) * 2.0)


def _estimated_line_height(line, font_size, requested_line_height=0):
    max_icon_h = max((float(item.get("icon_h", 0)) for item in line if item.get("type") == "icon"), default=0.0)
    natural = max(float(font_size) + 5.0, max_icon_h + 12.0 if max_icon_h else float(font_size) + 5.0)
    requested = _safe_float(requested_line_height, 0)
    return max(natural, requested) if requested > 0 else natural


def _estimate_wrapped_lines(text, max_width, font_size, font_name, icon_height, gap_px,
                            measure_layer, font_cache, icon_size_overrides=None,
                            icon_folder=None, icon_mappings=None):
    max_width = max(1.0, float(max_width or 1))
    lines = []
    current_line = []
    current_w = 0.0

    text = str(text or "").strip()

    for part in re.split(r"(<[^>]+>)", str(text or "")):
        if not part:
            continue
        if part.startswith("<") and part.endswith(">"):
            resolved_icon_h = _estimated_icon_height(part, icon_height, icon_size_overrides)
            token = part[1:-1].strip(" .;,-!")
            item_w = _estimated_icon_width(resolved_icon_h, gap_px, token, icon_folder, icon_mappings)
            if current_w and current_w + item_w > max_width:
                lines.append(current_line)
                current_line = []
                current_w = 0.0
            current_line.append({"type": "icon", "w": item_w, "icon_h": resolved_icon_h})
            current_w += item_w
            continue

        part_w = float(_measure_text_cached(part, font_size, font_name, measure_layer, font_cache))
        if current_w + part_w <= max_width:
            current_line.append({"type": "text", "w": part_w})
            current_w += part_w
        else:
            for word in re.split(r"( )", part):
                if not word:
                    continue
                word_w = float(_measure_text_cached(word, font_size, font_name, measure_layer, font_cache))
                if current_w and current_w + word_w > max_width:
                    if word == " ":
                        continue
                    lines.append(current_line)
                    current_line = []
                    current_w = 0.0
                current_line.append({"type": "text", "w": word_w})
                current_w += word_w

    if current_line:
        lines.append(current_line)
    if not lines:
        lines = [[{"type": "text", "w": 0.0}]]
    return lines


def _estimate_wrapped_height(text, max_width, font_size, font_name, icon_height, gap_px,
                             measure_layer, font_cache, line_height=0, icon_size_overrides=None,
                             icon_folder=None, icon_mappings=None):
    lines = _estimate_wrapped_lines(
        text, max_width, font_size, font_name, icon_height, gap_px,
        measure_layer, font_cache, icon_size_overrides=icon_size_overrides,
        icon_folder=icon_folder, icon_mappings=icon_mappings
    )
    return sum(_estimated_line_height(line, font_size, line_height) for line in lines)


def _auto_fit_slot_font_size(text, max_width, max_height, font_name, start_font_size,
                             icon_height, gap_px, measure_layer, font_cache,
                             line_height=0, icon_size_overrides=None,
                             icon_folder=None, icon_mappings=None, min_font_size=8):
    """Largest font size (down to min_font_size) whose wrapped content fits the box."""
    max_width = max(1.0, float(max_width or 1))
    max_height = max(1.0, float(max_height or 1))
    candidate = max(1, int(start_font_size or 0))
    while candidate >= min_font_size:
        lines = _estimate_wrapped_lines(
            text, max_width, candidate, font_name, icon_height, gap_px,
            measure_layer, font_cache, icon_size_overrides=icon_size_overrides,
            icon_folder=icon_folder, icon_mappings=icon_mappings,
        )
        fits_width = all(
            sum(float(item.get("w") or 0) for item in line) <= max_width + 0.5
            for line in lines
        )
        total_height = sum(_estimated_line_height(line, candidate, line_height) for line in lines)
        if fits_width and total_height <= max_height + 0.5:
            return candidate
        candidate -= 1
    return max(1, min_font_size)


def _premeasure_table_texts(cell_triples, measure_layer, font_cache):
    """Measure every table cell's parts+words at the CURRENT font sizes in ONE JSX call.

    The metrics passes (natural widths, height estimates, autofit loop) and the
    draw pass all measure the same (text,size,font) keys; pre-filling the shared
    font_cache once turns every later call into a cache hit. Call with the
    current sizes at the top of each autofit iteration — cache dedupes."""
    if measure_layer is None or not cell_triples:
        return
    from ps_autotypesetter.text_icon_renderer import premeasure_texts_batch
    texts, sizes, fonts = [], [], []
    seen = set()
    for text, font_size, font_name in cell_triples:
        text = str(text or "")
        if not text:
            continue
        for part in re.split(r"(<[^>]+>)", text):
            if not part or (part.startswith("<") and part.endswith(">")):
                continue
            for value in [part] + [w for w in re.split(r"( )", part) if w]:
                key = (value, font_size, font_name)
                if key in seen:
                    continue
                seen.add(key)
                texts.append(value)
                sizes.append(font_size)
                fonts.append(font_name)
    if texts:
        premeasure_texts_batch(texts, sizes, fonts, measure_layer, font_cache)


def _grid_table_metrics(table_data, c_width, base_font_name, base_font_size, icon_height,
                        table_style=None, measure_layer=None, font_cache=None,
                        icon_size_overrides=None, gap_px=0, icon_folder=None, icon_mappings=None):
    if table_style is None:
        table_style = TABLE_DEFAULTS.copy()
    if font_cache is None:
        font_cache = {}

    cols = [c_idx for _, c_idx in table_data.get('columns', [])]
    row_indices = list(table_data.get("row_indices") or [])
    row_roles = dict(table_data.get("row_roles") or {})
    grid_cells = list(table_data.get("grid_cells") or [])
    border_width = max(0, int(table_style.get('border_width', 2)))
    stroke_width = max(0, int(table_style.get('stroke_width', border_width)))
    row_gap = max(0, int(table_style.get('row_gap', 0)))
    padding_x = _auto_cell_padding_x(table_style)
    padding_y = max(0, int(table_style.get('cell_padding_y', 5)))
    content_width_mode = _manual_table_width(c_width, table_style) <= 0

    header_font_name, body_font_name, initial_header_font, initial_body_font = _table_font_settings(
        table_style, base_font_name, base_font_size
    )
    requested_table_icon_h = int(table_style.get("table_icon_height") or 0)
    body_font_locked = int(table_style.get("table_body_font_size") or 0) > 0
    header_font_locked = int(table_style.get("table_header_font_size") or 0) > 0
    icon_height_locked = requested_table_icon_h > 0
    min_body_font = 8
    current_body_font = initial_body_font
    current_header_font = initial_header_font
    initial_table_icon_h = requested_table_icon_h if requested_table_icon_h > 0 else initial_body_font
    table_icon_h = initial_table_icon_h
    max_inner_w = _table_max_width(c_width, table_style)

    def _current_cell_triples():
        triples = []
        for cell in grid_cells:
            text = str(cell.get("value") or "")
            if not text:
                continue
            role = cell.get("role") or row_roles.get(cell.get("row"), "body")
            triples.append((text, current_header_font if role == "header" else current_body_font,
                            header_font_name if role == "header" else body_font_name))
        return triples

    def _measure_natural_col_widths():
        widths = {col_idx: max(24.0, float(current_body_font) + (padding_x * 2)) for col_idx in cols}
        for cell in grid_cells:
            text = str(cell.get("value") or "")
            if not text:
                continue
            role = cell.get("role") or row_roles.get(cell.get("row"), "body")
            font_size = current_header_font if role == "header" else current_body_font
            font_name = header_font_name if role == "header" else body_font_name
            est_w = _estimate_inline_width(
                text, font_size, font_name, table_icon_h, gap_px, measure_layer, font_cache,
                icon_size_overrides=icon_size_overrides,
                icon_folder=icon_folder, icon_mappings=icon_mappings
            )
            est_w += (padding_x * 2) + (_measurement_guard_x(font_size, table_icon_h, table_style) * 2)
            span_cols = _span_column_indices(cols, int(cell.get("col")), cell.get("colspan") or 1)
            if not span_cols:
                continue
            current_span_w = sum(widths.get(col_idx, 24.0) for col_idx in span_cols)
            if est_w > current_span_w:
                extra = (est_w - current_span_w) / float(len(span_cols))
                for col_idx in span_cols:
                    widths[col_idx] = widths.get(col_idx, 24.0) + extra
            elif len(span_cols) == 1:
                widths[span_cols[0]] = max(widths.get(span_cols[0], 24.0), est_w)
        return widths

    while True:
        _premeasure_table_texts(_current_cell_triples(), measure_layer, font_cache)
        natural_col_widths = _measure_natural_col_widths()
        total_content_w = sum(natural_col_widths.values())
        if content_width_mode or total_content_w <= max_inner_w or current_body_font <= min_body_font:
            break
        if body_font_locked or header_font_locked:
            break
        current_body_font -= 1
        if not header_font_locked:
            delta = initial_header_font - initial_body_font
            current_header_font = max(8, current_body_font + delta)
        scale_ratio = current_body_font / initial_body_font if initial_body_font else 1
        if not icon_height_locked:
            table_icon_h = max(int(initial_table_icon_h * scale_ratio), 8)

    table_width, col_widths = _resolve_natural_table_widths(
        c_width, table_style, natural_col_widths, border_extra=0.0
    )
    table_left = _table_left_for_width(c_width, table_width, table_style)

    def _span_width(start_col, colspan):
        width = 0.0
        for col_idx in _span_column_indices(cols, start_col, colspan):
            width += col_widths.get(col_idx, 24.0)
        return width

    row_heights = {}
    for row_idx in row_indices:
        role = row_roles.get(row_idx, "body")
        font_size = current_header_font if role == "header" else current_body_font
        row_line_height = _safe_int(
            table_style.get("table_header_line_height" if role == "header" else "table_body_line_height"),
            0,
        )
        mult_key = "header_height_multiplier" if role == "header" else "row_height_multiplier"
        mult = max(1.0, _float_setting(table_style, mult_key, 1.5))
        basis = max(float(font_size), float(table_icon_h if role != "header" else font_size), float(row_line_height or 0))
        row_heights[row_idx] = max(int(basis * mult + 0.5), int(basis) + (padding_y * 2))

    for cell in grid_cells:
        text = str(cell.get("value") or "")
        if not text:
            continue
        row_idx = int(cell.get("row"))
        role = cell.get("role") or row_roles.get(row_idx, "body")
        font_size = current_header_font if role == "header" else current_body_font
        font_name = header_font_name if role == "header" else body_font_name
        line_height = _safe_int(
            table_style.get("table_header_line_height" if role == "header" else "table_body_line_height"),
            0,
        )
        inner_w = _span_width(int(cell.get("col")), max(1, int(cell.get("colspan") or 1))) - (padding_x * 2)
        cell_h = _estimate_wrapped_height(
            text, inner_w, font_size, font_name, table_icon_h, gap_px,
            measure_layer, font_cache, line_height=line_height,
            icon_size_overrides=icon_size_overrides,
            icon_folder=icon_folder, icon_mappings=icon_mappings
        )
        cell_h = max(cell_h + padding_y * 2, table_icon_h + padding_y * 2)
        rowspan = max(1, int(cell.get("rowspan") or 1))
        share_h = cell_h / float(rowspan)
        for offset in range(rowspan):
            covered_row = row_idx + offset
            if covered_row in row_heights:
                row_heights[covered_row] = max(row_heights[covered_row], share_h)

    total_row_h = 0
    for idx, row_idx in enumerate(row_indices):
        total_row_h += int(row_heights.get(row_idx, current_body_font + padding_y * 2))
        if idx < len(row_indices) - 1:
            total_row_h += row_gap

    try:
        max_table_height = int(table_style.get("max_table_height") or 0)
    except Exception:
        max_table_height = 0
    if _target_table_height(table_style) <= 0 and max_table_height > 0 and total_row_h > max_table_height and row_indices:
        fixed_height = row_gap * max(0, len(row_indices) - 1)
        scalable_height = max(1.0, sum(float(row_heights.get(row_idx, 1.0)) for row_idx in row_indices))
        available_scalable = max(1.0, float(max_table_height - fixed_height))
        scale = max(0.35, min(1.0, available_scalable / scalable_height))
        if scale < 1.0:
            if not body_font_locked:
                current_body_font = max(min_body_font, int(current_body_font * scale))
            if not header_font_locked:
                current_header_font = max(8, int(current_header_font * scale))
            if not icon_height_locked:
                table_icon_h = max(8, int(table_icon_h * scale))
            for row_idx in list(row_heights.keys()):
                row_heights[row_idx] = max(current_body_font + padding_y * 2, int(float(row_heights[row_idx]) * scale))
            total_row_h = 0
            for idx, row_idx in enumerate(row_indices):
                total_row_h += int(row_heights.get(row_idx, current_body_font + padding_y * 2))
                if idx < len(row_indices) - 1:
                    total_row_h += row_gap

    return {
        "grid_mode": True,
        "table_width": table_width,
        "table_left": table_left,
        "cols": cols,
        "row_indices": row_indices,
        "row_roles": row_roles,
        "grid_cells": grid_cells,
        "row_gap": row_gap,
        "col_widths": col_widths,
        "row_heights": row_heights,
        "header_font_size": current_header_font,
        "table_body_font_size": current_body_font,
        "header_font_name": header_font_name,
        "body_font_name": body_font_name,
        "total_row_h": total_row_h,
        "table_icon_h": table_icon_h,
        "border_width": border_width,
        "stroke_width": stroke_width,
        "padding_x": padding_x,
        "padding_y": padding_y,
    }


def estimate_table_height(table_data, c_width, base_font_name, base_font_size, icon_height,
                          table_style=None, measure_layer=None, font_cache=None, gap_px=0,
                          icon_folder=None, icon_mappings=None):
    target_height = _target_table_height(table_style)
    if target_height > 0:
        return target_height
    if _has_grid_table(table_data):
        return _grid_table_metrics(
            table_data, c_width, base_font_name, base_font_size, icon_height,
            table_style, measure_layer, font_cache, gap_px=gap_px,
            icon_folder=icon_folder, icon_mappings=icon_mappings
        )['total_row_h']
    return _table_metrics(
        table_data, c_width, base_font_name, base_font_size, icon_height,
        table_style, measure_layer, font_cache, gap_px=gap_px,
        icon_folder=icon_folder, icon_mappings=icon_mappings
    )['total_row_h']


def _safe_layer_name(value):
    return str(value or "Layer").replace('"', "'")


def _coerce_rgb(value, fallback=(255, 255, 255)):
    if isinstance(value, str):
        cleaned = value.strip().lstrip("#")
        if len(cleaned) == 6:
            try:
                return tuple(int(cleaned[index:index + 2], 16) for index in (0, 2, 4))
            except Exception:
                pass
    if isinstance(value, (list, tuple)) and len(value) >= 3:
        try:
            return tuple(max(0, min(255, int(value[index]))) for index in range(3))
        except Exception:
            pass
    return tuple(fallback)


def _solid_color_to_tuple(color, fallback=(255, 255, 255)):
    try:
        rgb = color.rgb
        return int(rgb.red), int(rgb.green), int(rgb.blue)
    except Exception:
        return tuple(fallback)


def _table_component_name(record):
    return str(record.get("table_name") or (record.get("spec") or {}).get("table_name") or "table").strip()


def _slot_belongs_to_component(slot_name, table_name):
    key = str(slot_name or "").casefold()
    table_key = str(table_name or "").casefold()
    if key == table_key or key.startswith(table_key + "."):
        return True
    if parse_table_slot_ref(slot_name):
        return True
    return False


def _component_slot_boxes(slots, table_name):
    all_slots = {str(name): box for name, box in (slots or {}).items()}
    matching = {
        str(name): box for name, box in all_slots.items()
        if _slot_belongs_to_component(name, table_name)
    }
    if not matching:
        return all_slots
    if any(not _slot_name_is_bounds_like(name) for name in matching):
        return matching
    # Single-table artist JSONs often use flat slots like "header1" or
    # "row2" plus an auto-generated "<table>.bounds" slot. Do not let that
    # generated bounds slot hide the artist's actual mapped slots.
    return all_slots


def _box_copy(box):
    return {
        "x": float(box.get("x", 0)),
        "y": float(box.get("y", 0)),
        "w": float(box.get("w", 0)),
        "h": float(box.get("h", 0)),
    }


def _union_boxes(boxes):
    usable = []
    for box in boxes or []:
        try:
            copied = _box_copy(box)
            if copied["w"] > 0 and copied["h"] > 0:
                usable.append(copied)
        except Exception:
            pass
    if not usable:
        return {"x": 0.0, "y": 0.0, "w": 1.0, "h": 1.0}
    left = min(box["x"] for box in usable)
    top = min(box["y"] for box in usable)
    right = max(box["x"] + box["w"] for box in usable)
    bottom = max(box["y"] + box["h"] for box in usable)
    return {"x": left, "y": top, "w": max(1.0, right - left), "h": max(1.0, bottom - top)}


def _repeat_row_count_for_mapping(mapping):
    if not bool(mapping.get("repeat")) and ".rowtemplate." not in str(mapping.get("slot") or "").casefold():
        return 0
    bounds = direct_range_bounds(mapping.get("source"))
    if not bounds:
        return 1
    return max(1, int(bounds[3]) - int(bounds[1]) + 1)


def _expand_repeating_slots_and_mappings(record):
    table_name = _table_component_name(record)
    spec = record.get("spec") or {}
    base_slots = {
        str(name): _box_copy(box)
        for name, box in _component_slot_boxes(record.get("slots") or {}, table_name).items()
    }
    mappings = [dict(mapping) for mapping in (spec.get("mappings") or [])]
    template_slots = {
        name: box
        for name, box in base_slots.items()
        if ".rowtemplate." in name.casefold()
    }
    repeat_count = 0
    repeat_gap = 0
    for mapping in mappings:
        repeat_count = max(repeat_count, _repeat_row_count_for_mapping(mapping))
        try:
            repeat_gap = max(repeat_gap, int(mapping.get("repeat_row_gap", 0) or 0))
        except Exception:
            pass

    expanded_slots = dict(base_slots)
    if template_slots and repeat_count > 0:
        template_union = _union_boxes(template_slots.values())
        row_step = float(spec.get("repeat_row_step") or 0)
        if row_step <= 0:
            row_step = float(template_union["h"]) + float(repeat_gap)
        for row_offset in range(repeat_count):
            for slot_name, box in template_slots.items():
                rendered_name = re.sub(
                    r"\.rowTemplate\.",
                    f".row{row_offset + 1}.",
                    str(slot_name),
                    flags=re.IGNORECASE,
                )
                rendered_box = dict(box)
                rendered_box["y"] = float(box["y"]) + row_step * row_offset
                expanded_slots[rendered_name] = rendered_box

    expanded_mappings = []
    for mapping in mappings:
        slot = str(mapping.get("slot") or "")
        count = _repeat_row_count_for_mapping(mapping)
        if count > 0 and ".rowtemplate." in slot.casefold():
            for row_offset in range(count):
                rendered = dict(mapping)
                rendered["slot"] = re.sub(
                    r"\.rowTemplate\.",
                    f".row{row_offset + 1}.",
                    slot,
                    flags=re.IGNORECASE,
                )
                rendered["source"] = source_for_row_offset(mapping.get("source"), row_offset)
                rendered["repeat_index"] = row_offset + 1
                expanded_mappings.append(rendered)
        else:
            expanded_mappings.append(mapping)

    return expanded_slots, expanded_mappings


def _scale_slots_to_canvas(record, raw_slots, c_width, c_height):
    canvas = record.get("canvas") or {}
    try:
        source_w = max(1.0, float(canvas.get("width") or c_width))
        source_h = max(1.0, float(canvas.get("height") or c_height))
    except Exception:
        source_w, source_h = float(c_width), float(c_height)
    scale = min(float(c_width) / source_w, float(c_height) / source_h)
    offset_x = (float(c_width) - source_w * scale) / 2.0
    offset_y = (float(c_height) - source_h * scale) / 2.0
    scaled = {}
    for name, box in (raw_slots or {}).items():
        copied = _box_copy(box)
        scaled[name] = {
            "x": offset_x + copied["x"] * scale,
            "y": offset_y + copied["y"] * scale,
            "w": copied["w"] * scale,
            "h": copied["h"] * scale,
        }
    return scaled, scale


def _component_bounds(record, slots):
    table_name = _table_component_name(record)
    spec = record.get("spec") or {}
    bounds_slot = str(spec.get("bounds_slot") or f"{table_name}.bounds")
    lower = {str(name).casefold(): name for name in (slots or {})}
    component_slots = _component_slot_boxes(slots, table_name)
    inferred_bounds = _bounds_slot_for_table({"slots": slots, "template_id": table_name, "export_kind": "table"}, table_name)
    for candidate in (bounds_slot, inferred_bounds, f"{table_name}.bounds", f"{table_name}.bound", table_name):
        found = lower.get(str(candidate).casefold())
        if found:
            base = _box_copy(slots[found])
            # Repeating row slots may extend below the artist's static bounds.
            union = _union_boxes([
                box for name, box in component_slots.items()
                if ".rowtemplate." not in str(name).casefold()
            ])
            right = max(base["x"] + base["w"], union["x"] + union["w"])
            bottom = max(base["y"] + base["h"], union["y"] + union["h"])
            base["w"] = max(base["w"], right - base["x"])
            base["h"] = max(base["h"], bottom - base["y"])
            return base
    return _union_boxes([
        box for name, box in component_slots.items()
        if ".rowtemplate." not in str(name).casefold()
    ])


def _truthy_json_flag(value):
    if isinstance(value, bool):
        return value
    return str(value or "").strip().casefold() in {"1", "true", "yes", "on", "enabled"}


def _mapped_table_respect_absolute_x(spec):
    """Return True only when JSON explicitly requests fixed horizontal position.

    Mirrors the PNG builder: mapper JSONs often save absolute_x from the design
    template, which can shift a normal flowing table right/left. Default PSD
    behavior is therefore to center the table on the canvas unless this is
    explicitly enabled.
    """
    spec = spec or {}
    for key in ("png_respect_absolute_x", "respect_absolute_x", "use_absolute_x"):
        if _truthy_json_flag(spec.get(key)):
            return True
    if str(spec.get("position_mode") or "").strip().casefold() in {"absolute", "fixed", "locked"}:
        return True
    return False


def _transform_mapped_table_slots(record, c_width, c_height, start_y, max_y=None):
    raw_slots, expanded_mappings = _expand_repeating_slots_and_mappings(record)
    scaled_slots, canvas_scale = _scale_slots_to_canvas(record, raw_slots, c_width, c_height)
    bounds = _component_bounds(record, scaled_slots)
    spec = record.get("spec") or {}
    warnings = []

    fit_mode = str(spec.get("fit_mode") or "scale").strip().casefold()
    scale_if_needed = bool(spec.get("scale_if_needed", True)) or fit_mode == "scale"
    target_top = float(start_y)
    if fit_mode == "absolute" or str(spec.get("insert_mode") or "").casefold() == "absolute":
        if spec.get("absolute_y") is not None:
            target_top = float(spec.get("absolute_y"))
    available_height = None
    if max_y is not None:
        available_height = max(1.0, float(max_y) - target_top)

    extra_scale = 1.0
    if available_height is not None and bounds["h"] > available_height:
        if scale_if_needed:
            extra_scale = max(0.2, min(1.0, available_height / max(1.0, bounds["h"])))
            warnings.append(
                f"Scaled mapped table {_table_component_name(record)} to {int(extra_scale * 100)}% to keep bottom margin."
            )
        else:
            warnings.append(f"Mapped table {_table_component_name(record)} exceeds safe page height.")

    if extra_scale < 1.0:
        for name, box in list(scaled_slots.items()):
            scaled_slots[name] = {
                "x": bounds["x"] + (box["x"] - bounds["x"]) * extra_scale,
                "y": bounds["y"] + (box["y"] - bounds["y"]) * extra_scale,
                "w": box["w"] * extra_scale,
                "h": box["h"] * extra_scale,
            }
        bounds = _component_bounds(record, scaled_slots)

    dx = 0.0
    if _mapped_table_respect_absolute_x(spec) and spec.get("absolute_x") is not None:
        try:
            dx = float(spec.get("absolute_x")) - bounds["x"]
        except Exception:
            dx = 0.0
    else:
        align = str(
            spec.get("png_horizontal_align")
            or spec.get("horizontal_align")
            or spec.get("table_align")
            or spec.get("alignment")
            or "center"
        ).strip().casefold()
        rendered_w = max(0.0, float(bounds["w"]))
        if align == "left":
            dx = -bounds["x"]
        elif align == "right":
            dx = max(0.0, float(c_width) - rendered_w) - bounds["x"]
        else:
            dx = max(0.0, (float(c_width) - rendered_w) / 2.0) - bounds["x"]
    dy = target_top - bounds["y"]

    transformed = {}
    for name, box in scaled_slots.items():
        transformed[name] = {
            "x": box["x"] + dx,
            "y": box["y"] + dy,
            "w": box["w"],
            "h": box["h"],
        }
    bounds = _component_bounds(record, transformed)
    return transformed, expanded_mappings, bounds, canvas_scale * extra_scale, warnings


def estimate_mapped_table_height(record, c_width, c_height):
    slots, _mappings = _expand_repeating_slots_and_mappings(record)
    scaled, _scale = _scale_slots_to_canvas(record, slots, c_width, c_height)
    bounds = _component_bounds(record, scaled)
    return max(1.0, float(bounds.get("h", 1.0)))


def _inner_box(box, padding):
    padding = list(padding or [0, 0, 0, 0])
    padding = (padding + [0, 0, 0, 0])[:4]
    try:
        top, right, bottom, left = [max(0.0, float(value)) for value in padding]
    except Exception:
        top = right = bottom = left = 0.0
    return {
        "x": float(box["x"]) + left,
        "y": float(box["y"]) + top,
        "w": max(1.0, float(box["w"]) - left - right),
        "h": max(1.0, float(box["h"]) - top - bottom),
    }


def _create_table_json_rect(doc, app, group, box, name, fill_rgb, opacity=100, stroke_rgb=None, stroke_width=0, fill=True):
    if not box:
        return None
    fill_rgb = _coerce_rgb(fill_rgb, (0, 0, 0))
    stroke_rgb = _coerce_rgb(stroke_rgb, (255, 255, 255))
    stroke_width = max(0, int(stroke_width or 0))
    left = float(box["x"])
    top = float(box["y"])
    right = left + float(box["w"])
    bottom = top + float(box["h"])
    stroke_code = ""
    if stroke_width > 0:
        stroke_code = (
            "var strokeColor = new SolidColor();"
            f"strokeColor.rgb.red={int(stroke_rgb[0])};"
            f"strokeColor.rgb.green={int(stroke_rgb[1])};"
            f"strokeColor.rgb.blue={int(stroke_rgb[2])};"
            f"doc.selection.stroke(strokeColor,{stroke_width},StrokeLocation.INSIDE);"
        )
    fill_code = ""
    if fill:
        fill_code = (
            "var fillColor = new SolidColor();"
            f"fillColor.rgb.red = {int(fill_rgb[0])};"
            f"fillColor.rgb.green = {int(fill_rgb[1])};"
            f"fillColor.rgb.blue = {int(fill_rgb[2])};"
            "doc.selection.fill(fillColor);"
        )
    jsx = f"""
    (function() {{
        var doc = app.activeDocument;
        var layer = doc.artLayers.add();
        layer.name = {json.dumps(_safe_layer_name(name))};
        doc.selection.select([[{left},{top}],[{right},{top}],[{right},{bottom}],[{left},{bottom}]]);
        {fill_code}
        {stroke_code}
        doc.selection.deselect();
        layer.opacity = {max(0, min(100, int(opacity or 0)))};
    }})();
    """
    app.doJavaScript(jsx)
    layer = doc.activeLayer
    try:
        layer.move(group, ps.ElementPlacement.PlaceInside)
    except Exception:
        pass
    return layer


def _place_asset_in_box(doc, app, group, path, box, name, max_height=None, max_width=None):
    if not path or not box:
        return None
    safe_path = os.path.abspath(path).replace("\\", "/")
    app.doJavaScript(f"""
    var idPlc = charIDToTypeID("Plc ");
    var desc = new ActionDescriptor();
    desc.putPath(charIDToTypeID("null"), new File({json.dumps(safe_path)}));
    executeAction(idPlc, desc, DialogModes.NO);
    """)
    layer = doc.activeLayer
    layer.name = _safe_layer_name(name)
    bounds = _bounds_to_floats(layer.bounds)
    if not bounds:
        try:
            layer.move(group, ps.ElementPlacement.PlaceInside)
        except Exception:
            pass
        return layer
    width = max(1.0, bounds[2] - bounds[0])
    height = max(1.0, bounds[3] - bounds[1])
    target_w = float(box["w"])
    target_h = float(box["h"])
    if max_width:
        target_w = min(target_w, max(1.0, float(max_width)))
    if max_height:
        target_h = min(target_h, max(1.0, float(max_height)))
    scale_pct = min(target_w / width, target_h / height) * 100.0
    try:
        layer.resize(scale_pct, scale_pct)
        bounds = _bounds_to_floats(layer.bounds) or bounds
    except Exception:
        pass
    new_w = max(1.0, bounds[2] - bounds[0])
    new_h = max(1.0, bounds[3] - bounds[1])
    target_left = float(box["x"]) + (float(box["w"]) - new_w) / 2.0
    target_top = float(box["y"]) + (float(box["h"]) - new_h) / 2.0
    try:
        layer.translate(target_left - bounds[0], target_top - bounds[1])
    except Exception:
        pass
    try:
        layer.move(group, ps.ElementPlacement.PlaceInside)
    except Exception:
        pass
    return layer


def _dedicated_token_exclusions(mappings):
    exclusions = {}
    for mapping in mappings or []:
        if str(mapping.get("kind") or "").casefold() not in {"icon", "dedicated_icon"}:
            continue
        source_key = str(mapping.get("source") or "").strip().casefold()
        if not source_key:
            continue
        try:
            token_index = int(mapping.get("token_index", 0) or 0)
        except Exception:
            token_index = 0
        exclusions.setdefault(source_key, set()).add(token_index)
    return exclusions


def _inline_size_overrides(mappings, source, slot):
    overrides = {}
    source_key = str(source or "").strip().casefold()
    slot_key = str(slot or "").strip().casefold()
    for mapping in mappings or []:
        if str(mapping.get("kind") or "").casefold() != "inline_token":
            continue
        if str(mapping.get("source") or "").strip().casefold() != source_key:
            continue
        if str(mapping.get("slot") or "").strip().casefold() != slot_key:
            continue
        token = str(mapping.get("token") or "").strip()
        if not token:
            continue
        try:
            icon_height = int(mapping.get("icon_height", 0) or 0)
        except Exception:
            icon_height = 0
        if icon_height > 0:
            overrides[token] = icon_height
    return overrides


def _mapped_slot_role(mapping):
    role = str(mapping.get("role") or "").strip().casefold()
    if role:
        return role
    kind = str(mapping.get("kind") or "").casefold()
    slot = str(mapping.get("slot") or "").casefold()
    if "header" in slot or "heading" in slot or kind == "heading":
        return "heading"
    if kind in {"icon", "dedicated_icon"}:
        return "dedicated_icon"
    if kind == "flow":
        return "text_icon"
    if kind == "background":
        return "slot_style"
    return "normal_text"


def _role_layer_prefix(mapping):
    role = _mapped_slot_role(mapping)
    slot = _safe_layer_name(mapping.get("slot") or "slot")
    labels = {
        "heading": "Heading",
        "normal_text": "NormalText",
        "text_icon": "TextIcon",
        "dedicated_icon": "DedicatedIcon",
        "slot_style": "SlotFillStroke",
    }
    return f"{labels.get(role, role or 'Slot')}_{slot}"


def _apply_slot_layer_style(app, doc, groups, prefix, style_config, warnings=None, slot_name=""):
    if not style_config or not groups:
        return
    prefix = str(prefix or "")
    matched = 0
    for group in groups:
        try:
            for layer in group.artLayers:
                name = str(getattr(layer, "name", "") or "")
                if name.startswith(prefix):
                    apply_heading_layer_style(app, doc, layer, style_config)
                    matched += 1
        except Exception:
            continue
    if warnings is not None and not matched:
        warnings.append(
            f"Slot {slot_name}: layer style applied to no layers (prefix {prefix!r})."
        )


def _resolve_slot_style_config(mapping, layer_style_library, warnings=None):
    style_name = str(mapping.get("layer_style") or "").strip()
    if not style_name:
        return None
    library = layer_style_library or {}
    style_config = library.get(style_name)
    if not style_config and warnings is not None:
        warnings.append(f"Slot {mapping.get('slot') or '?'}: unknown layer style {style_name!r} in library.")
    return style_config


def _mapping_has_slot_style(mapping):
    kind = str(mapping.get("kind") or "").casefold()
    if kind == "background":
        return True
    try:
        stroke_width = int(mapping.get("stroke_width", 0) or 0)
    except Exception:
        stroke_width = 0
    has_bg = bool(str(mapping.get("background_color") or "").strip())
    return has_bg or bool(mapping.get("fill_enabled", False)) or bool(mapping.get("stroke_enabled", False)) or stroke_width > 0


def _slot_style_mapping(mapping):
    kind = str(mapping.get("kind") or "").casefold()
    has_bg = bool(str(mapping.get("background_color") or "").strip())
    fill_enabled = has_bg or bool(mapping.get("fill_enabled", kind == "background"))
    stroke_enabled = bool(mapping.get("stroke_enabled", False))
    try:
        stroke_width = int(mapping.get("stroke_width", 0) or 0)
    except Exception:
        stroke_width = 0
    if stroke_width > 0:
        stroke_enabled = True
    try:
        opacity = int(mapping.get("opacity", 100))
    except Exception:
        opacity = 100
    return {
        "fill_enabled": fill_enabled,
        "stroke_enabled": stroke_enabled,
        "background_color": mapping.get("background_color", mapping.get("color", "#000000")),
        "stroke_color": mapping.get("stroke_color", "#FFFFFF"),
        "stroke_width": stroke_width if stroke_enabled else 0,
        "opacity": max(0, min(100, opacity)),
    }


def draw_mapped_table_to_psd(
        doc, app, record, worksheet, icon_folder, start_y, c_width, c_height, max_y,
        base_font_name, base_font_size, base_text_color, icon_height, icon_y_offset, gap_px,
        measure_layer=None, font_cache=None, icon_cache=None, missing_icons_log=None,
        asset_group=None, parent_group=None, icon_mappings=None, keyword_colors=None,
        table_style=None, icon_size_overrides=None, layer_style_library=None):
    if font_cache is None:
        font_cache = {}
    if icon_cache is None:
        icon_cache = {}
    if missing_icons_log is None:
        missing_icons_log = set()
    if table_style is None:
        table_style = TABLE_DEFAULTS.copy()

    transformed_slots, mappings, bounds, render_scale, warnings = _transform_mapped_table_slots(
        record, c_width, c_height, start_y, max_y=max_y
    )
    table_name = _table_component_name(record)
    if parent_group is None:
        table_group = doc.layerSets.add()
    else:
        table_group = parent_group.layerSets.add()
    table_group.name = f"TableJSON_{table_name}"

    background_group = table_group.layerSets.add()
    background_group.name = "Table Slot Backgrounds"
    content_group = table_group.layerSets.add()
    content_group.name = "Table Slot Content"
    icon_group = content_group.layerSets.add()
    icon_group.name = "Dedicated Icons"
    text_group = content_group.layerSets.add()
    text_group.name = "Text and Inline Icons"

    merged_icon_mappings = dict(icon_mappings or {})
    merged_icon_mappings.update(record.get("icon_mappings") or {})
    dedicated_exclusions = _dedicated_token_exclusions(mappings)

    style_by_slot = {}
    for mapping in mappings:
        if _mapping_has_slot_style(mapping):
            style_by_slot[str(mapping.get("slot") or "").casefold()] = mapping

    for mapping in style_by_slot.values():
        slot_name = str(mapping.get("slot") or "")
        box = transformed_slots.get(slot_name)
        if not box:
            warnings.append(f"Missing mapped table slot for style: {slot_name}")
            continue
        style = _slot_style_mapping(mapping)
        if not style["fill_enabled"] and style["stroke_width"] <= 0:
            continue
        _create_table_json_rect(
            doc, app, background_group, box,
            f"{_role_layer_prefix(mapping)}",
            style["background_color"],
            opacity=style["opacity"],
            stroke_rgb=style["stroke_color"],
            stroke_width=style["stroke_width"],
            fill=style["fill_enabled"],
        )

    heading_group = text_group.layerSets.add()
    heading_group.name = "Heading Text"
    normal_text_group = text_group.layerSets.add()
    normal_text_group.name = "Normal Text"
    flow_text_group = text_group.layerSets.add()
    flow_text_group.name = "Text With Inline Icons"

    text_batch = [] if _table_text_batch_active() else None
    icon_dup_batch = [] if _table_text_batch_active() else None
    icon_dup_groups = {} if text_batch is not None else None
    deferred_slot_styles = []

    for mapping in mappings:
        kind = str(mapping.get("kind") or "").casefold()
        slot_name = str(mapping.get("slot") or "")
        box = transformed_slots.get(slot_name)
        if not box:
            warnings.append(f"Missing mapped table slot: {slot_name}")
            continue

        if kind == "background":
            continue

        source = str(mapping.get("source") or "").strip()
        inner = _inner_box(box, mapping.get("padding"))
        role = _mapped_slot_role(mapping)
        font_size = _role_font_size(mapping, role, table_style, base_font_size)
        font_name = _role_font_name(mapping, role, table_style, base_font_name, app)
        line_height = _role_line_height(mapping, role, table_style)
        mapped_icon_height = max(1, int(mapping.get("icon_height") or icon_height or font_size))
        alignment = _normalize_alignment(mapping.get("alignment") or table_style.get("table_alignment") or "center")
        vertical_align = str(mapping.get("vertical_align") or "center").strip().lower()
        text_rgb = _coerce_rgb(mapping.get("color"), _solid_color_to_tuple(base_text_color))
        text_color = _solid_color(text_rgb, (255, 255, 255))

        if kind in {"icon", "dedicated_icon"}:
            token = str(mapping.get("token") or "").strip()
            if not token:
                token = resolve_table_token(worksheet, source, mapping.get("token_index", 0))
            if not token:
                warnings.append(f"No token found for dedicated icon slot {slot_name}.")
                continue
            asset_path = resolve_icon_path(token, icon_folder, merged_icon_mappings)
            if not asset_path or not os.path.exists(asset_path):
                missing_icons_log.add(token)
                warnings.append(f"Missing icon for mapped table token <{token}>.")
                _render_text_with_keyword_overlays(
                    text_group, f"<{token}>", font_size, font_name, text_color,
                    inner["x"], inner["y"] + font_size, measure_layer, font_cache, keyword_colors,
                    f"{_role_layer_prefix(mapping)}_MissingIcon", app=app, line_height=line_height,
                    text_batch=text_batch
                )
                continue
            max_height = int(mapping.get("max_height") or mapped_icon_height or inner["h"])
            _place_asset_in_box(
                doc, app, icon_group, asset_path, inner,
                f"{_role_layer_prefix(mapping)}_{token}", max_height=max_height
            )
            _apply_slot_layer_style(
                app, doc, [icon_group], _role_layer_prefix(mapping),
                _resolve_slot_style_config(mapping, layer_style_library, warnings),
                warnings=warnings, slot_name=slot_name,
            )
            continue

        if kind == "inline_token":
            continue

        text = str(mapping.get("text") or "").strip()
        if not text:
            text = resolve_table_source_text(worksheet, source)
        if not text:
            warnings.append(f"No Excel text resolved for table slot {slot_name} from {source}.")
            continue
        if kind in {"flow", "text"} and not bool(mapping.get("keep_dedicated_tokens", False)):
            text = remove_token_indexes(text, dedicated_exclusions.get(source.casefold(), set()))
        if kind == "text":
            text = re.sub(r"<\s*([^>]+?)\s*>", "", text).strip()
        local_icon_overrides = dict(icon_size_overrides or {})
        local_icon_overrides.update(_inline_size_overrides(mappings, source, slot_name))
        # By default auto-fit the font so wrapped content stays inside the slot box.
        # An explicit font size chosen by the user (font_override) is respected as-is.
        explicit_font_size = bool(mapping.get("font_override"))
        if not explicit_font_size:
            try:
                fitted = _auto_fit_slot_font_size(
                    text, inner["w"], inner["h"], font_name, font_size,
                    mapped_icon_height, gap_px, measure_layer, font_cache,
                    line_height=line_height, icon_size_overrides=local_icon_overrides,
                    icon_folder=icon_folder, icon_mappings=merged_icon_mappings,
                )
                if fitted < font_size:
                    warnings.append(
                        f"Slot {slot_name}: auto-fitted font {font_size} -> {fitted} to fit box."
                    )
                    font_size = fitted
            except Exception:
                pass
        target_text_group = heading_group if role == "heading" else flow_text_group if role == "text_icon" else normal_text_group
        _render_cell_with_icons(
            doc, target_text_group, text, font_size, font_name, text_color,
            mapped_icon_height, inner["x"], inner["y"], inner["w"], inner["h"],
            icon_y_offset, gap_px, icon_folder, icon_cache, missing_icons_log,
            asset_group, app, measure_layer, font_cache, 0, slot_name,
            merged_icon_mappings, keyword_colors, local_icon_overrides, alignment,
            layer_name_prefix=_role_layer_prefix(mapping), line_height=line_height,
            vertical_align=vertical_align, text_batch=text_batch,
            icon_dup_batch=icon_dup_batch, icon_dup_groups=icon_dup_groups
        )
        if text_batch is not None:
            deferred_slot_styles.append((
                mapping, target_text_group, _role_layer_prefix(mapping), slot_name
            ))
            continue
        _apply_slot_layer_style(
            app, doc, [target_text_group], _role_layer_prefix(mapping),
            _resolve_slot_style_config(mapping, layer_style_library, warnings),
            warnings=warnings, slot_name=slot_name,
        )

    if text_batch is not None:
        flush_text_spec_batch(text_batch, app, doc)
        _flush_icon_dup_entries(icon_dup_batch, app, doc)
        for _s_mapping, _s_group, _s_prefix, _s_slot in deferred_slot_styles:
            _apply_slot_layer_style(
                app, doc, [_s_group], _s_prefix,
                _resolve_slot_style_config(_s_mapping, layer_style_library, warnings),
                warnings=warnings, slot_name=_s_slot,
            )

    return float(bounds["y"] + bounds["h"]), table_group, warnings


def _draw_grid_table_to_psd(doc, app, table_data, icon_folder, start_y, c_width, c_height,
                            margin_x, base_font_name, base_font_size, base_text_color,
                            icon_height, icon_y_offset, gap_px, line_spacing,
                            table_style=None, measure_layer=None, font_cache=None, icon_cache=None,
                            missing_icons_log=None, asset_group=None, parent_group=None,
                            icon_mappings=None, keyword_colors=None, icon_size_overrides=None):
    if table_style is None:
        table_style = TABLE_DEFAULTS.copy()
    if font_cache is None:
        font_cache = {}
    if icon_cache is None:
        icon_cache = {}
    if missing_icons_log is None:
        missing_icons_log = set()

    metrics = _grid_table_metrics(
        table_data, c_width, base_font_name, base_font_size, icon_height,
        table_style, measure_layer, font_cache, icon_size_overrides, gap_px=gap_px,
        icon_folder=icon_folder, icon_mappings=icon_mappings
    )
    table_width = metrics["table_width"]
    table_left = metrics["table_left"]
    row_indices = metrics["row_indices"]
    row_roles = metrics["row_roles"]
    cols = metrics["cols"]
    col_widths = metrics["col_widths"]
    row_heights = metrics["row_heights"]
    row_gap = metrics["row_gap"]
    total_row_h = metrics["total_row_h"]
    table_icon_h = metrics["table_icon_h"]
    header_font_size = metrics["header_font_size"]
    table_body_font_size = metrics["table_body_font_size"]
    header_font_name = metrics["header_font_name"]
    body_font_name = metrics["body_font_name"]
    border_width = metrics["border_width"]
    stroke_w = metrics.get("stroke_width", border_width)
    padding_x = metrics["padding_x"]
    padding_y = metrics["padding_y"]

    if parent_group is None:
        table_group = doc.layerSets.add()
    else:
        table_group = parent_group.layerSets.add()
    table_group.name = f"Table_{table_data['start_row']}_{table_data['end_row']}"
    fill_group = table_group.layerSets.add()
    fill_group.name = "Table Fills"
    stroke_group = table_group.layerSets.add()
    stroke_group.name = "Table Strokes"

    table_top = float(start_y)
    table_bottom = table_top + total_row_h

    sr, sg, sb = table_style.get('stroke_rgb', table_style.get('border_rgb', (255, 255, 255)))
    mode_map_jsx = {"fill": 0, "stroke": 1, "both": 2}
    mode_int = mode_map_jsx.get(table_style.get('render_mode', 'both'), 2)
    opacity = int((float(table_style.get('overlay_opacity', 100)) / 100.0) * 100)
    opacity = max(0, min(100, opacity))
    try:
        stroke_opacity = int(float(table_style.get("stroke_opacity", 100)))
    except Exception:
        stroke_opacity = 100
    stroke_opacity = max(0, min(100, stroke_opacity))
    merge_table_layers = bool(table_style.get("merge_table_layers"))

    col_lefts = {}
    current_x = float(table_left)
    for col_idx in cols:
        col_lefts[col_idx] = current_x
        current_x += float(col_widths.get(col_idx, 24.0))

    row_tops = {}
    current_y = table_top
    for idx, row_idx in enumerate(row_indices):
        row_tops[row_idx] = current_y
        current_y += float(row_heights.get(row_idx, table_body_font_size + padding_y * 2))
        if idx < len(row_indices) - 1:
            current_y += row_gap

    def _span_width(start_col, colspan):
        width = 0.0
        for col_idx in _span_column_indices(cols, start_col, colspan):
            width += float(col_widths.get(col_idx, 24.0))
        return width

    def _span_height(start_row, rowspan):
        height = 0.0
        for offset in range(max(1, int(rowspan))):
            row_idx = start_row + offset
            height += float(row_heights.get(row_idx, table_body_font_size + padding_y * 2))
        if rowspan > 1:
            height += row_gap * (rowspan - 1)
        return height

    body_rows = [row_idx for row_idx in row_indices if row_roles.get(row_idx, "body") != "header"]
    body_order = {row_idx: order for order, row_idx in enumerate(body_rows)}
    bg_commands = []
    use_excel_fill_colors = bool(table_data.get("use_excel_fill_colors"))
    use_excel_font_colors = bool(table_data.get("use_excel_font_colors"))

    excel_fill_hex_overrides = table_data.get("excel_fill_hex_overrides") or {}
    excel_font_hex_overrides = table_data.get("excel_font_hex_overrides") or {}

    def _cell_excel_fill(cell, row_idx, col_idx):
        if not use_excel_fill_colors:
            return None
        fill_rgb = cell.get("fill_color") or table_data.get("cell_fill_colors", {}).get((row_idx, col_idx))
        if not fill_rgb:
            for key in _cell_coord_keys(cell, row_idx, col_idx):
                fill_rgb = excel_fill_hex_overrides.get(key)
                if fill_rgb:
                    break
        return _coerce_rgb_tuple(fill_rgb) or (255, 255, 255)

    def _cell_excel_font_color(cell, row_idx, col_idx):
        font_rgb = None
        for key in _cell_coord_keys(cell, row_idx, col_idx):
            font_rgb = excel_font_hex_overrides.get(key)
            if font_rgb:
                break
        if font_rgb:
            return _coerce_rgb_tuple(font_rgb)
        if not use_excel_font_colors:
            return None
        font_rgb = cell.get("color") or table_data.get("cell_colors", {}).get((row_idx, col_idx))
        return _coerce_rgb_tuple(font_rgb) or (0, 0, 0)

    def add_rect_cmd(name, x, y, w, h, fill_rgb, rect_opacity, rect_mode=None):
        try:
            x = float(x); y = float(y); w = float(w); h = float(h)
        except Exception:
            return
        x2 = min(float(c_width), x + w)
        y2 = min(float(c_height), y + h)
        x = max(0.0, x)
        y = max(0.0, y)
        w = x2 - x
        h = y2 - y
        if w <= 0 or h <= 0:
            return
        r, g, b = fill_rgb
        mode = mode_int if rect_mode is None else int(rect_mode)
        bg_commands.append(
            f'_jsx_createRect("{name}", {x}, {y}, {w}, {h}, '
            f'{int(r)}, {int(g)}, {int(b)}, {int(rect_opacity)}, '
            f'{int(sr)}, {int(sg)}, {int(sb)}, {int(stroke_w)}, '
            f'{int(stroke_opacity)}, {int(mode)});'
        )

    for cell in metrics["grid_cells"]:
        row_idx = int(cell.get("row"))
        col_idx = int(cell.get("col"))
        if row_idx not in row_tops or col_idx not in col_lefts:
            continue
        role = cell.get("role") or row_roles.get(row_idx, "body")
        if use_excel_fill_colors:
            fill_rgb = _cell_excel_fill(cell, row_idx, col_idx)
            if fill_rgb:
                if mode_int == 0 or stroke_w <= 0 or stroke_opacity <= 0:
                    rect_mode = 0
                else:
                    rect_mode = 2
                rect_opacity = 100
            elif mode_int in (1, 2) and stroke_w > 0 and stroke_opacity > 0:
                fill_rgb = (0, 0, 0)
                rect_mode = 1
                rect_opacity = 0
            else:
                continue
        elif role == "header":
            fill_rgb = table_style.get('header_bg_rgb', (20, 20, 30))
            rect_opacity = 100
            ov = str((table_style.get("header_render_mode") or "") or "").casefold()
            rect_mode = mode_map_jsx.get(ov, mode_int) if ov else mode_int
        else:
            body_idx = body_order.get(row_idx, 0)
            fill_rgb = table_style.get('row1_bg_rgb', (35, 35, 50)) if body_idx % 2 == 0 else table_style.get('row2_bg_rgb', (28, 28, 42))
            rect_opacity = 100
            role_key = "row1_render_mode" if body_idx % 2 == 0 else "row2_render_mode"
            ov = str((table_style.get(role_key) or "") or "").casefold()
            rect_mode = mode_map_jsx.get(ov, mode_int) if ov else mode_int
        add_rect_cmd(
            f"GridCellBg_{row_idx}_{col_idx}",
            col_lefts[col_idx],
            row_tops[row_idx],
            _span_width(col_idx, int(cell.get("colspan") or 1)),
            _span_height(row_idx, int(cell.get("rowspan") or 1)),
            fill_rgb,
            rect_opacity,
            rect_mode,
        )

    merge_table_layers_js = "true" if merge_table_layers else "false"
    bg_jsx = """
    var mergeTableLayers = __MERGE_TABLE_LAYERS__;
    var mergedFillLayer = null;
    var mergedStrokeLayer = null;
    function _jsx_mergedName(name, suffix) {
        if (name.indexOf("GridCellBg_") === 0) {
            return "GridCellBg_Merged" + suffix;
        }
        return name + "_Merged" + suffix;
    }
    function _jsx_createRect(name, x, y, w, h, fillR, fillG, fillB, fillOpacity, strokeR, strokeG, strokeB, strokeW, strokeOpacity, mode) {
        var doc = app.activeDocument;
        var region = [[x, y], [x+w, y], [x+w, y+h], [x, y+h]];
        if ((mode == 0 || mode == 2) && fillOpacity > 0) {
            var layer = mergedFillLayer;
            if (!mergeTableLayers || layer == null) {
                layer = doc.artLayers.add();
                layer.name = mergeTableLayers ? _jsx_mergedName(name, "_Fill") : name + "_Fill";
                if (mergeTableLayers) mergedFillLayer = layer;
            }
            doc.activeLayer = layer;
            doc.selection.select(region);
            var fillColor = new SolidColor();
            fillColor.rgb.red = fillR; fillColor.rgb.green = fillG; fillColor.rgb.blue = fillB;
            doc.selection.fill(fillColor);
            doc.selection.deselect();
            layer.opacity = fillOpacity;
        }
        if ((mode == 1 || mode == 2) && strokeW > 0 && strokeOpacity > 0) {
            var strokeLayer = mergedStrokeLayer;
            if (!mergeTableLayers || strokeLayer == null) {
                strokeLayer = doc.artLayers.add();
                strokeLayer.name = mergeTableLayers ? _jsx_mergedName(name, "_Stroke") : name + "_Stroke";
                if (mergeTableLayers) mergedStrokeLayer = strokeLayer;
            }
            doc.activeLayer = strokeLayer;
            doc.selection.select(region);
            var strokeColor = new SolidColor();
            strokeColor.rgb.red = strokeR; strokeColor.rgb.green = strokeG; strokeColor.rgb.blue = strokeB;
            doc.selection.stroke(strokeColor, strokeW, StrokeLocation.INSIDE);
            doc.selection.deselect();
            strokeLayer.opacity = strokeOpacity;
        }
        doc.selection.deselect();
    }
    """.replace("__MERGE_TABLE_LAYERS__", merge_table_layers_js) + "\n".join(bg_commands)

    try:
        if bg_commands:
            app.doJavaScript(bg_jsx)
            for suffix, target_group in (("_Fill", fill_group), ("_Stroke", stroke_group)):
                for layer in list(doc.layers):
                    if layer.name.startswith("GridCellBg_") and layer.name.endswith(suffix):
                        try:
                            layer.move(target_group, ps.ElementPlacement.PlaceInside)
                        except Exception:
                            pass
    except Exception as exc:
        print(f"Table grid background warning: {exc}")

    content_group = table_group.layerSets.add()
    content_group.name = "Table Content"
    header_content_group = content_group.layerSets.add()
    header_content_group.name = "Table Header Text"
    body_content_group = content_group.layerSets.add()
    body_content_group.name = "Table Body Text"

    text_batch = [] if _table_text_batch_active() else None
    icon_dup_batch = [] if _table_text_batch_active() else None
    icon_dup_groups = {} if text_batch is not None else None

    header_alignment = _normalize_alignment(table_style.get("table_header_alignment", table_style.get("table_alignment", "center")))
    body_alignment = _normalize_alignment(table_style.get("table_body_alignment", table_style.get("table_alignment", "center")))
    col_letters = {idx: letter for letter, idx in table_data.get("columns", [])}

    for cell in metrics["grid_cells"]:
        text = str(cell.get("value") or "")
        if not text:
            continue
        row_idx = int(cell.get("row"))
        col_idx = int(cell.get("col"))
        if row_idx not in row_tops or col_idx not in col_lefts:
            continue
        role = cell.get("role") or row_roles.get(row_idx, "body")
        is_header = role == "header"
        target_group = header_content_group if is_header else body_content_group
        font_size = header_font_size if is_header else table_body_font_size
        font_name = header_font_name if is_header else body_font_name
        alignment = header_alignment if is_header else body_alignment
        line_height = _safe_int(table_style.get("table_header_line_height" if is_header else "table_body_line_height"), 0)
        cell_rgb = cell.get("color") or table_data.get("cell_colors", {}).get((row_idx, col_idx))
        explicit_font_rgb = _cell_excel_font_color(cell, row_idx, col_idx)
        if explicit_font_rgb:
            text_color = _solid_color(explicit_font_rgb, (255, 255, 255))
        elif is_header and cell_rgb:
            text_color = _solid_color(cell_rgb, (255, 255, 255))
        elif is_header:
            text_color = _solid_color(table_style.get('header_text_rgb'), (255, 255, 255))
        elif table_style.get('table_body_text_rgb'):
            text_color = _solid_color(table_style.get('table_body_text_rgb'), (255, 255, 255))
        elif cell_rgb:
            text_color = _solid_color(cell_rgb, (255, 255, 255))
        else:
            text_color = base_text_color

        cell_left = col_lefts[col_idx] + padding_x
        cell_top = row_tops[row_idx]
        cell_width = max(1.0, _span_width(col_idx, int(cell.get("colspan") or 1)) - (padding_x * 2))
        cell_height = max(1.0, _span_height(row_idx, int(cell.get("rowspan") or 1)))
        _render_cell_with_icons(
            doc, target_group, text, font_size, font_name, text_color, table_icon_h,
            cell_left, cell_top, cell_width, cell_height, icon_y_offset, gap_px,
            icon_folder, icon_cache, missing_icons_log, asset_group, app, measure_layer, font_cache,
            row_idx - 1, col_letters.get(col_idx, str(col_idx)),
            icon_mappings, keyword_colors, icon_size_overrides, alignment,
            line_height=line_height, text_batch=text_batch,
            icon_dup_batch=icon_dup_batch, icon_dup_groups=icon_dup_groups
        )

    if text_batch is not None:
        flush_text_spec_batch(text_batch, app, doc)
    _flush_icon_dup_entries(icon_dup_batch, app, doc)

    apply_style_to_group_text_layers(app, doc, header_content_group, table_style.get("table_header_style"))
    apply_style_to_group_text_layers(app, doc, body_content_group, table_style.get("table_body_style"))
    scaled_bounds = _scale_group_to_target_height(table_group, _target_table_height(table_style))
    if scaled_bounds:
        table_bottom = scaled_bounds[3]
    return table_bottom, table_group


def draw_table_to_psd(doc, app, table_data, icon_folder, start_y, c_width, c_height,
                      margin_x, base_font_name, base_font_size, base_text_color,
                      icon_height, icon_y_offset, gap_px, line_spacing,
                      table_style=None, measure_layer=None, font_cache=None, icon_cache=None,
                      missing_icons_log=None, asset_group=None, parent_group=None,
                      icon_mappings=None, keyword_colors=None, icon_size_overrides=None):
    if _has_grid_table(table_data):
        return _draw_grid_table_to_psd(
            doc, app, table_data, icon_folder, start_y, c_width, c_height,
            margin_x, base_font_name, base_font_size, base_text_color,
            icon_height, icon_y_offset, gap_px, line_spacing,
            table_style, measure_layer, font_cache, icon_cache,
            missing_icons_log, asset_group, parent_group,
            icon_mappings, keyword_colors, icon_size_overrides
        )

    if table_style is None:
        table_style = TABLE_DEFAULTS.copy()
    if font_cache is None:
        font_cache = {}
    if icon_cache is None:
        icon_cache = {}
    if missing_icons_log is None:
        missing_icons_log = set()

    metrics = _table_metrics(
        table_data, c_width, base_font_name, base_font_size, icon_height,
        table_style, measure_layer, font_cache, icon_size_overrides, gap_px=gap_px,
        icon_folder=icon_folder, icon_mappings=icon_mappings
    )
    table_width = metrics['table_width']
    table_left = metrics['table_left']
    num_data_rows = metrics['num_data_rows']
    has_header = metrics['has_header']
    cols = metrics['cols']
    row_gap = metrics['row_gap']
    col_widths = metrics['col_widths']
    header_font_size = metrics['header_font_size']
    table_body_font_size = metrics['table_body_font_size']
    header_h = metrics['header_h']
    row_h = metrics['row_h']
    total_row_h = metrics['total_row_h']
    table_icon_h = metrics['table_icon_h']
    header_font_name = metrics['header_font_name']
    body_font_name = metrics['body_font_name']
    padding_x = metrics.get('padding_x', _auto_cell_padding_x(table_style))

    if parent_group is None:
        table_group = doc.layerSets.add()
    else:
        table_group = parent_group.layerSets.add()
    table_group.name = f"Table_{table_data['start_row']}_{table_data['end_row']}"
    fill_group = table_group.layerSets.add()
    fill_group.name = "Table Fills"
    stroke_group = table_group.layerSets.add()
    stroke_group.name = "Table Strokes"

    table_top = start_y
    table_bottom = table_top + total_row_h

    sr, sg, sb = table_style.get('stroke_rgb', (255, 255, 255))
    stroke_w = table_style.get('stroke_width', 2)
    mode_map_jsx = {"fill": 0, "stroke": 1, "both": 2}
    mode_int = mode_map_jsx.get(table_style.get('render_mode', 'both'), 2)
    try:
        stroke_opacity = int(float(table_style.get("stroke_opacity", 100)))
    except Exception:
        stroke_opacity = 100
    stroke_opacity = max(0, min(100, stroke_opacity))
    merge_table_layers = bool(table_style.get("merge_table_layers"))

    bg_commands = []

    def add_rect_cmd(name, x, y, w, h, fill_rgb, opacity, rect_mode=None):
        # Photoshop selection rectangles can behave badly when coordinates fall
        # outside the canvas. Clamp visible backgrounds to the canvas; text can
        # still exist outside if the table itself is taller than a page.
        try:
            x = float(x); y = float(y); w = float(w); h = float(h)
        except Exception:
            return
        x2 = min(float(c_width), x + w)
        y2 = min(float(c_height), y + h)
        x = max(0.0, x)
        y = max(0.0, y)
        w = x2 - x
        h = y2 - y
        if w <= 0 or h <= 0:
            return
        r, g, b = fill_rgb
        final_mode = mode_int if rect_mode is None else int(rect_mode)
        bg_commands.append(
            f'_jsx_createRect("{name}", {x}, {y}, {w}, {h}, '
            f'{int(r)}, {int(g)}, {int(b)}, {int(opacity)}, '
            f'{int(sr)}, {int(sg)}, {int(sb)}, {int(stroke_w)}, '
            f'{int(stroke_opacity)}, {int(final_mode)});'
        )

    overlay_opacity_pct = int((table_style['overlay_opacity'] / 100) * 100)
    add_rect_cmd("TableOverlay", table_left, table_top, table_width, total_row_h,
                 table_style['header_bg_rgb'], overlay_opacity_pct)

    current_y_js = table_top + table_style['border_width']
    if has_header:
        h_x = table_left + table_style['border_width']
        h_w = table_width - table_style['border_width'] * 2
        header_ov = str((table_style.get("header_render_mode") or "") or "").casefold()
        header_mode = mode_map_jsx.get(header_ov, mode_int) if header_ov else mode_int
        add_rect_cmd("HeaderBg", h_x, current_y_js, h_w, header_h,
                     table_style['header_bg_rgb'], 100, rect_mode=header_mode)
        current_y_js += header_h + row_gap

    for row_idx in range(num_data_rows):
        is_even = (row_idx % 2 == 0)
        rbg = table_style['row1_bg_rgb'] if is_even else table_style['row2_bg_rgb']
        role_key = "row1_render_mode" if is_even else "row2_render_mode"
        ov = str((table_style.get(role_key) or "") or "").casefold()
        row_mode = mode_map_jsx.get(ov, mode_int) if ov else mode_int
        rx = table_left + table_style['border_width']
        rw = table_width - table_style['border_width'] * 2
        add_rect_cmd(f"RowBg_{row_idx+1}", rx, current_y_js, rw, row_h, rbg, 100, rect_mode=row_mode)
        current_y_js += row_h
        if row_idx < num_data_rows - 1:
            current_y_js += row_gap

    merge_table_layers_js = "true" if merge_table_layers else "false"
    bg_jsx = """
    var mergeTableLayers = __MERGE_TABLE_LAYERS__;
    var mergedFillLayer = null;
    var mergedStrokeLayer = null;
    function _jsx_mergedName(name, suffix) {
        if (name.indexOf("TableOverlay") === 0 || name.indexOf("HeaderBg") === 0 || name.indexOf("RowBg_") === 0) {
            return "TableAuto_Merged" + suffix;
        }
        return name + "_Merged" + suffix;
    }
    function _jsx_createRect(name, x, y, w, h, fillR, fillG, fillB, fillOpacity, strokeR, strokeG, strokeB, strokeW, strokeOpacity, mode) {
        var doc = app.activeDocument;
        var region = [[x, y], [x+w, y], [x+w, y+h], [x, y+h]];
        if ((mode == 0 || mode == 2) && fillOpacity > 0) {
            var layer = mergedFillLayer;
            if (!mergeTableLayers || layer == null) {
                layer = doc.artLayers.add();
                layer.name = mergeTableLayers ? _jsx_mergedName(name, "_Fill") : name + "_Fill";
                if (mergeTableLayers) mergedFillLayer = layer;
            }
            doc.activeLayer = layer;
            doc.selection.select(region);
            var fillColor = new SolidColor();
            fillColor.rgb.red = fillR; fillColor.rgb.green = fillG; fillColor.rgb.blue = fillB;
            doc.selection.fill(fillColor);
            doc.selection.deselect();
            layer.opacity = fillOpacity;
        }
        if ((mode == 1 || mode == 2) && strokeW > 0 && strokeOpacity > 0) {
            var strokeLayer = mergedStrokeLayer;
            if (!mergeTableLayers || strokeLayer == null) {
                strokeLayer = doc.artLayers.add();
                strokeLayer.name = mergeTableLayers ? _jsx_mergedName(name, "_Stroke") : name + "_Stroke";
                if (mergeTableLayers) mergedStrokeLayer = strokeLayer;
            }
            doc.activeLayer = strokeLayer;
            doc.selection.select(region);
            var strokeColor = new SolidColor();
            strokeColor.rgb.red = strokeR; strokeColor.rgb.green = strokeG; strokeColor.rgb.blue = strokeB;
            doc.selection.stroke(strokeColor, strokeW, StrokeLocation.INSIDE);
            doc.selection.deselect();
            strokeLayer.opacity = strokeOpacity;
        }
        doc.selection.deselect();
    }
    """.replace("__MERGE_TABLE_LAYERS__", merge_table_layers_js) + "\n".join(bg_commands)

    try:
        if bg_commands:
            app.doJavaScript(bg_jsx)
            for suffix, target_group in (("_Fill", fill_group), ("_Stroke", stroke_group)):
                for layer in list(doc.layers):
                    if layer.name.startswith(("TableOverlay", "HeaderBg", "RowBg_", "TableAuto_Merged")) and layer.name.endswith(suffix):
                        try:
                            layer.move(target_group, ps.ElementPlacement.PlaceInside)
                        except Exception:
                            pass
    except Exception as e:
        print(f"Table background warning: {e}")

    # Create content after backgrounds so Photoshop keeps table text/icons above
    # opaque row fills. Creating it first can bury the data behind the rectangles.
    content_group = table_group.layerSets.add()
    content_group.name = "Table Content"
    header_content_group = content_group.layerSets.add()
    header_content_group.name = "Table Header Text"
    body_content_group = content_group.layerSets.add()
    body_content_group.name = "Table Body Text"

    text_batch = [] if _table_text_batch_active() else None
    icon_dup_batch = [] if _table_text_batch_active() else None
    icon_dup_groups = {} if text_batch is not None else None

    # Header text
    current_y = table_top + table_style['border_width']
    header_alignment = _normalize_alignment(table_style.get("table_header_alignment", table_style.get("table_alignment", "center")))
    body_alignment = _normalize_alignment(table_style.get("table_body_alignment", table_style.get("table_alignment", "center")))
    if has_header:
        current_x = table_left + table_style['border_width']
        header_line_height = _safe_int(table_style.get("table_header_line_height"), 0)
        for col_letter, col_idx in table_data['columns']:
            col_w = col_widths.get(col_idx, 100)
            text = str(table_data['header_row'].get(col_idx, '') or '')
            if not text:
                current_x += col_w + table_style['border_width']
                continue

            hc = ps.SolidColor()
            cell_rgb = table_data.get('cell_colors', {}).get((table_data['header_row_idx'], col_idx), None)
            if cell_rgb:
                hc.rgb.red, hc.rgb.green, hc.rgb.blue = cell_rgb
            else:
                hc.rgb.red, hc.rgb.green, hc.rgb.blue = table_style['header_text_rgb']

            cell_left = current_x + padding_x
            cell_width = max(1.0, col_w - padding_x * 2)
            _render_cell_with_icons(
                doc, header_content_group, text, header_font_size, header_font_name, hc,
                table_icon_h, cell_left, current_y, cell_width, header_h, icon_y_offset,
                gap_px, icon_folder, icon_cache, missing_icons_log, asset_group,
                app, measure_layer, font_cache, 0, col_letter, icon_mappings,
                keyword_colors, icon_size_overrides, header_alignment,
                layer_name_prefix=f"Header_{col_letter}", line_height=header_line_height,
                text_batch=text_batch, icon_dup_batch=icon_dup_batch, icon_dup_groups=icon_dup_groups
            )
            current_x += col_w + table_style['border_width']
        current_y += header_h + row_gap

    # Data rows
    body_line_height = _safe_int(table_style.get("table_body_line_height"), 0)
    for row_idx, row_data in enumerate(table_data['data_rows']):
        current_x = table_left + table_style['border_width']
        excel_row = table_data['excel_row_map'][row_idx]
        for col_idx_pos, (col_letter, col_idx) in enumerate(table_data['columns']):
            col_w = col_widths.get(col_idx, 100)
            text = str(row_data.get(col_idx, '') or '')
            if not text:
                current_x += col_w + table_style['border_width']
                continue

            cell_rgb = table_data.get('cell_colors', {}).get((excel_row, col_idx), None)
            cell_color = _solid_color(table_style.get('table_body_text_rgb'), None) if table_style.get('table_body_text_rgb') else base_text_color
            if cell_rgb and not table_style.get('table_body_text_rgb'):
                cell_color = ps.SolidColor()
                cell_color.rgb.red, cell_color.rgb.green, cell_color.rgb.blue = cell_rgb

            cell_left = current_x + padding_x
            cell_width = max(1.0, col_w - padding_x * 2)
            _render_cell_with_icons(
                doc, body_content_group, text, table_body_font_size,
                body_font_name, cell_color, table_icon_h,
                cell_left, current_y, cell_width, row_h, icon_y_offset,
                gap_px, icon_folder, icon_cache, missing_icons_log,
                asset_group, app, measure_layer, font_cache, row_idx, col_letter,
                icon_mappings, keyword_colors, icon_size_overrides, body_alignment,
                layer_name_prefix=f"R{row_idx+1}_{col_letter}", line_height=body_line_height,
                text_batch=text_batch, icon_dup_batch=icon_dup_batch, icon_dup_groups=icon_dup_groups
            )
            current_x += col_w + table_style['border_width']
        current_y += row_h
        if row_idx < num_data_rows - 1:
            current_y += row_gap

    if text_batch is not None:
        flush_text_spec_batch(text_batch, app, doc)
    _flush_icon_dup_entries(icon_dup_batch, app, doc)

    apply_style_to_group_text_layers(app, doc, header_content_group, table_style.get("table_header_style"))
    apply_style_to_group_text_layers(app, doc, body_content_group, table_style.get("table_body_style"))
    _center_group_horizontally(content_group, c_width)
    scaled_bounds = _scale_group_to_target_height(table_group, _target_table_height(table_style))
    if scaled_bounds:
        table_bottom = scaled_bounds[3]
    return table_bottom, table_group
