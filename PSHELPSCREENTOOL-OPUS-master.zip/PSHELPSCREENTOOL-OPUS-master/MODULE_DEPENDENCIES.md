# Module Dependencies

This document details the dependency relationships and import hierarchy across `PsHelpScreenTool_v46_20_GAME_RULES_RENDERER`.

---

## High-Level Dependency Graph

```
[Entry Points: main.py, web_launcher.py]
       |
       v
[UI & Web Server Layer]
  - ps_autotypesetter.ui_web.server
  - ps_autotypesetter.ui_web.engine_api
  - ps_autotypesetter.ui_web.jobs
  - ps_autotypesetter.ui
       |
       +---------------------------------------+
       |                                       |
       v                                       v
[Orchestration Engine Layer]             [PNG Rendering Layer]
  - ps_autotypesetter.build_engine         - ps_autotypesetter.png_builder
       |                                       |
       +-------------------+-------------------+
                           |
                           v
              [Rendering Component Layer]
                - ps_autotypesetter.text_icon_renderer
                - ps_autotypesetter.table_renderer
                - ps_autotypesetter.table_detector
                - ps_autotypesetter.table_mapping
                - ps_autotypesetter.dynamic_pages.router
                - ps_autotypesetter.dynamic_pages.paytable.renderer
                - ps_autotypesetter.layer_styles
                - ps_autotypesetter.background
                           |
                           v
              [Core Utilities & Data Layer]
                - ps_autotypesetter.excel_utils
                - ps_autotypesetter.photoshop_fonts
                - ps_autotypesetter.photoshop_utils
                - ps_autotypesetter.keyword_manager
                - ps_autotypesetter.icon_mapping
                - ps_autotypesetter.project_manifest
                - ps_autotypesetter.diff_engine
                - ps_autotypesetter.config
```

---

## Detailed Module Breakdown

### 1. Web UI Subsystem (`ps_autotypesetter/ui_web/`)
- **`server.py`**: Imports `engine_api.py`, `jobs.py`, `ps_actions.py`, `icon_scan.py`. Provides REST API endpoints for the SPA frontend.
- **`engine_api.py`**: Imports `ps_autotypesetter.build_engine`, `ps_autotypesetter.png_builder`, `ps_autotypesetter.session_manager`, `ps_autotypesetter.config`. Converts web config dicts into kwargs for `build_engine` / `png_builder`.
- **`jobs.py`**: Imports `engine_api.py`. Runs build operations in background threads and collects event logs.
- **`window.py` / `desktop.py`**: Imports `server.py`. Manages PyWebView desktop window lifecycle.

### 2. Core Build Engines
- **`build_engine.py`**:
  - Imports: `config`, `excel_utils`, `photoshop_utils`, `photoshop_fonts`, `table_detector`, `table_mapping`, `table_renderer`, `text_icon_renderer`, `background`, `build_profiler`, `diff_engine`, `layer_styles`, `dynamic_pages`, `icon_mapping`, `project_manifest`.
  - Roles: Primary orchestrator for Photoshop PSD generation, incremental page comparison, and layer group structure.
- **`png_builder.py`**:
  - Imports: `config`, `excel_utils`, `table_detector`, `table_mapping`, `table_renderer`, `icon_mapping`, `keyword_manager`, `dynamic_pages`.
  - Roles: Standalone PIL/Pillow-based rendering engine producing PNG exports without Photoshop.

### 3. Rendering Modules
- **`text_icon_renderer.py`**: Batch text specification collector and JSX generator (`flush_text_spec_batch`), direct COM fallback, inline keyword coloring.
- **`table_renderer.py`**: Cell grid drawer, borders, background fills, and cell text typesetter.
- **`table_detector.py`**: Heuristic auto-detection of table bounds from Excel openpyxl worksheet objects.
- **`dynamic_pages/router.py`**: Dispatches sheet rendering to dynamic templates or paytable renderers (`dynamic_pages/paytable/renderer.py`).

### 4. Shared Utilities
- **`excel_utils.py`**: Color conversions (ARGB to RGB hex/tuple), cell coordinate helpers.
- **`photoshop_fonts.py`**: Map font display names to PostScript font names.
- **`project_manifest.py`**: Generates and parses `.pshelpscreen.json` sidecar manifests for incremental build change detection.
- **`diff_engine.py`**: Workbook-to-workbook diffing to identify changed Excel sheets.
