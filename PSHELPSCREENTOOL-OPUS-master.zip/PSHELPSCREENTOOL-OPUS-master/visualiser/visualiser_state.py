"""Visualiser state model: settings <-> guide/geometry mapping (pure logic).

Only REAL settings keys that the normal-page renderer actually consumes are
exposed — a guide or control must change exactly what the output changes.
"""

# Draggable canvas guides. `key` is the config key the guide edits,
# `edge` describes how the page-space line maps to that key's value:
#   top / left        -> value == line position (px)
#   gap               -> value == line_y - heading_bottom
#   bottom / right    -> value == canvas_edge - line position
# The left/right edges edit the sym-metric inner-canvas WIDTH and move
# together around the canvas centre (symmetric margins).
GUIDE_DEFS = (
    {
        "id": "header_top",
        "label": "Header Top Margin",
        "key": "heading_top_margin",
        "orientation": "h",
        "edge": "top",
        "min": 0,
        "max": 800,
    },
    {
        "id": "heading_gap",
        "label": "Heading–Body Gap",
        "key": "heading_to_body_gap",
        "orientation": "h",
        "edge": "gap",
        "min": 0,
        "max": 400,
    },
    {
        "id": "body_bottom",
        "label": "Bottom Margin",
        "key": "bottom_margin",
        "orientation": "h",
        "edge": "bottom",
        "min": 0,
        "max": 1000,
    },
    {
        "id": "safe_left",
        "label": "Inner Canvas Width",
        "key": "inner_canvas_width",
        "orientation": "v",
        "edge": "left",
        "min": 100,
        "max": 5000,
    },
    {
        "id": "safe_right",
        "label": "Inner Canvas Width",
        "key": "inner_canvas_width",
        "orientation": "v",
        "edge": "right",
        "min": 100,
        "max": 5000,
    },
)

# Layer-style roles the normal renderer resolves per role name.
STYLE_ROLES = {
    "heading": "Heading text",
    "body": "Body text",
}


def get_path(config, parts):
    """Read a nested config value by a list of key parts."""
    value = config
    for part in parts:
        if not isinstance(value, dict):
            return None
        value = value.get(part)
    return value


def set_path(config, parts, value):
    """Write a nested config value through a list of key parts (creates dicts)."""
    node = config
    for part in parts[:-1]:
        nxt = node.get(part)
        if not isinstance(nxt, dict):
            nxt = {}
            node[part] = nxt
        node = nxt
    node[parts[-1]] = value


def style_target(config, role):
    """Resolve the LIVE style object for a role.

    Returns (path_parts, assigned_name). When the user has assigned a saved
    library style to the role we edit that library entry; otherwise the legacy
    top-level heading_style / body_style dicts are used. Mirrors
    engine_api._build_kwargs resolution order.
    """
    dynamic = config.get("dynamic_settings") or {}
    library = dynamic.get("layer_style_library") or {}
    assignments = dynamic.get("style_assignments") or {}
    role_name = STYLE_ROLES.get(role, role)
    name = str(assignments.get(role_name) or "").strip()
    if name and name in library:
        return ["dynamic_settings", "layer_style_library", name], name
    return [("heading_style" if role == "heading" else "body_style")], None