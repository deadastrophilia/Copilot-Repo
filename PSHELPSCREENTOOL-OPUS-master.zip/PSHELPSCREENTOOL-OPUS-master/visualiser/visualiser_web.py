"""Visualiser HTTP surface.

Registered from server.create_app() via register_visualiser(...). The addon
only READS the config (via get_config) for its own endpoints and lets the
frontend write settings through the EXISTING /api/config endpoint — the core
settings system stays untouched.
"""

import hashlib
import json as _json
import os
import tempfile
import uuid

from flask import jsonify, request, send_file

from ps_autotypesetter.memo import Memo

from . import visualiser_renderer
from .visualiser_controls import controls_payload
from .visualiser_data import collect_editor_data, _font_dir_lookup
from .visualiser_guides import compute_guides

_ROLE_TITLES = {"heading": "Heading text", "body": "Body text"}

_PREVIEW_CACHE = {}
_PREVIEW_CACHE_MAX = 64          # every page of a large game doc (rail thumbnails)
_EDITOR_CACHE = {}
_EDITOR_CACHE_MAX = 16
_VERIFY_CACHE = {}
_VERIFY_CACHE_MAX = 8



def _sheet_arg(data):
    """The sheet name as the workbook has it — Excel allows a trailing space ("BONUS 1 "), and a
    trimmed name is a sheet that doesn't exist; only an empty / blank name means "the first one"."""
    raw = str((data or {}).get("sheet_name") or "")
    return raw if raw.strip() else ""

def _preview_key(cfg, sheet_name):
    h = hashlib.sha256()
    h.update(_json.dumps(cfg, sort_keys=True, default=str, ensure_ascii=False).encode("utf-8", "replace"))
    excel = str(cfg.get("excel_path") or "")
    try:
        h.update(str(os.path.getmtime(excel)).encode("utf-8", "replace"))
    except Exception:
        pass
    h.update(("|" + sheet_name).encode("utf-8", "replace"))
    return h.hexdigest()


def _editor_key(cfg, sheet_name):
    """Editor data depends mostly on CONTENT inputs, not settings — but the
    payload also resolves FONT FILES from h_font/b_font/style (and per-sheet
    page overrides), so those keys must invalidate the cache: otherwise the
    LIVE/typography canvas keeps drawing with the previously selected font."""
    h = hashlib.sha256()
    h.update(("ed|" + sheet_name).encode("utf-8", "replace"))
    excel = str(cfg.get("excel_path") or "")
    try:
        h.update(str(os.path.getmtime(excel)).encode("utf-8", "replace"))
    except Exception:
        pass
    for key in ("icon_folder", "bg_path", "enable_tables", "max_col_limit", "dynamic_settings",
                "h_font", "b_font", "h_font_style", "b_font_style", "page_overrides", "table_style",
                "icon_mappings", "icon_size_overrides"):
        try:
            h.update((key + "=" + _json.dumps(cfg.get(key), sort_keys=True, default=str, ensure_ascii=False)).encode("utf-8", "replace"))
        except Exception:
            h.update(key.encode("utf-8", "replace"))
    return h.hexdigest()


def _normal_sheets(cfg):
    from openpyxl import load_workbook

    from ps_autotypesetter import png_builder

    excel_path = str(cfg.get("excel_path") or "")
    if not excel_path or not os.path.isfile(excel_path):
        return [], "", {}, {}
    from ps_autotypesetter import workbook_cache

    _wb_loan = workbook_cache.borrow(excel_path)
    try:
        wb = _wb_loan.__enter__()
    except Exception as exc:
        return [], f"Cannot open workbook: {exc}", {}, {}
    sheets = []
    sheet_tables = {}
    sheet_windows = {}
    try:
        max_col = int(cfg.get("max_col_limit", 12))
        table_style = cfg.get("table_style") or {}
        for name in png_builder.visible_sheet_names(wb):
            if png_builder._normalized_sheet_kind(name) == "" and visualiser_renderer._is_normal_sheet(cfg, name):
                sheets.append(name)
                try:
                    sheet_tables[name] = bool(png_builder._prepare_tables(wb[name], table_style, max_col, name))
                except Exception:
                    sheet_tables[name] = False
                try:
                    min_r, max_r, min_c, max_c = png_builder._render_window_for_sheet(
                        cfg.get("dynamic_settings") or {}, name, max_col, wb[name],
                    )
                    sheet_windows[name] = {
                        "min_row": int(min_r), "max_row": int(max_r),
                        "min_col": int(min_c), "max_col": int(max_c),
                    }
                except Exception:
                    pass
    finally:
        _wb_loan.__exit__(None, None, None)
    return sheets, "", sheet_tables, sheet_windows


def _studio_sheets(cfg, normal):
    """({sheet: "paytable" | "game_rules" | "bingo_rules"}, every visible page in workbook order)
    — the pages built by their own studios, which the Visualiser shows as the build draws them."""
    from ps_autotypesetter import png_builder, workbook_cache
    from ps_autotypesetter.ui_web import engine_api

    excel_path = str(cfg.get("excel_path") or "")
    if not excel_path or not os.path.isfile(excel_path):
        return {}, list(normal)
    studio, order = {}, []
    try:
        with workbook_cache.borrow(excel_path) as wb:
            for ws in wb.worksheets:
                name = ws.title
                if getattr(ws, "sheet_state", "visible") != "visible":
                    continue
                if name in normal:
                    order.append(name)
                    continue
                kind = png_builder._normalized_sheet_kind(name) or (
                    "paytable" if engine_api._sheet_type(name) == "paytable" else "")
                if kind:
                    studio[name] = kind
                    order.append(name)
    except Exception:
        return {}, list(normal)
    return studio, order


def _payline_sheets(cfg, sheets):
    """Sheets that build as Paylines / Win Lines pages (a "Line | Reel1 | …"
    table): the live canvas shows the server-rendered pages for these."""
    excel_path = str(cfg.get("excel_path") or "")
    if not sheets or not excel_path or not os.path.isfile(excel_path):
        return []
    from ps_autotypesetter import workbook_cache
    from ps_autotypesetter.dynamic_pages import paylines

    try:
        with workbook_cache.borrow(excel_path) as wb:
            return [n for n in sheets if n in wb.sheetnames and paylines.is_payline_page(wb[n])]
    except Exception:
        return []


def _sheets_key(cfg):
    """The sheet list depends only on the settings and the Excel file's version."""
    from ps_autotypesetter.memo import file_stamp

    return hashlib.sha1(_json.dumps([cfg, file_stamp(cfg.get("excel_path"))],
                                    sort_keys=True, default=str).encode("utf-8")).hexdigest()


_SHEETS_MEMO = Memo(size=4)


def register_visualiser(app, get_config=None, set_config=None, register_preview=None):
    """Attach the Visualiser addon endpoints to the Flask app.

    All helpers are optional; preview renders need get_config + register_preview.
    """

    @app.route("/api/visualiser/sheets", methods=["POST"])
    def visualiser_sheets():
        cfg = dict(get_config() if callable(get_config) else {})
        return jsonify(_SHEETS_MEMO.get(_sheets_key(cfg), lambda: _sheets_payload(cfg)))

    def _sheets_payload(cfg):
        sheets, error, sheet_tables, sheet_windows = _normal_sheets(cfg)
        studio, all_sheets = _studio_sheets(cfg, sheets)
        return {
            "ok": True,
            "sheets": sheets,
            # every page of the help screen, in workbook order: the Visualiser shows the
            # Paytable / Game Rules / Bingo Rules pages too (as built; edited in their studios)
            "all_sheets": all_sheets,
            "studio_sheets": studio,
            "sheet_tables": sheet_tables,
            "render_windows": sheet_windows,
            "payline_sheets": _payline_sheets(cfg, sheets),
            "excel_ok": not error,
            "excel_error": error,
            "canvas_width": int(cfg.get("c_width", 1920)),
            "canvas_height": int(cfg.get("c_height", 1080)),
            "controls": controls_payload(cfg),
            "role_titles": _ROLE_TITLES,
        }

    @app.route("/api/visualiser/preview", methods=["POST"])
    def visualiser_preview():
        cfg = dict(get_config() if callable(get_config) else {})
        data = request.get_json(force=True, silent=True) or {}
        sheet_name = _sheet_arg(data)
        force = bool(data.get("force"))
        if not sheet_name:
            sheets, _error, _sheet_tables, _sheet_windows = _normal_sheets(cfg)
            sheet_name = sheets[0] if sheets else ""
        if not sheet_name:
            return jsonify({"ok": False, "error": "No sheet available. Configure the Excel workbook in the Project view first."}), 400

        key = _preview_key(cfg, sheet_name)
        cached = _PREVIEW_CACHE.get(key)
        if cached and not force and cached.get("png_path") and os.path.isfile(cached["png_path"]):
            return jsonify({
                "ok": True,
                "cached": True,
                "preview_token": cached["token"],
                "sheet_name": sheet_name,
                "pages": cached["pages"],
                "canvas_width": int(cached["geometry"]["canvas_w"]),
                "canvas_height": int(cached["geometry"]["canvas_h"]),
                "geometry": cached["geometry"],
                "guides": cached["guides"],
            })

        try:
            result = visualiser_renderer.render_normal_page(cfg, sheet_name)
        except ValueError as exc:
            return jsonify({"ok": False, "error": str(exc)}), 400
        except Exception as exc:  # addon must never break the UI
            return jsonify({"ok": False, "error": f"Visualiser render failed: {exc}"}), 500
        token = register_preview(result["png_path"]) if callable(register_preview) else ""
        if not token:
            return jsonify({"ok": False, "error": "Preview service unavailable."}), 500
        geometry = result["geometry"]
        guides = compute_guides(geometry)
        _PREVIEW_CACHE[key] = {
            "token": token,
            "png_path": result["png_path"],
            "pages": result["pages"],
            "geometry": geometry,
            "guides": guides,
        }
        if len(_PREVIEW_CACHE) > _PREVIEW_CACHE_MAX:
            for cache_key in list(_PREVIEW_CACHE)[: len(_PREVIEW_CACHE) - _PREVIEW_CACHE_MAX]:
                _PREVIEW_CACHE.pop(cache_key, None)
        return jsonify({
            "ok": True,
            "cached": False,
            "preview_token": token,
            "sheet_name": sheet_name,
            "pages": result["pages"],
            "canvas_width": int(geometry["canvas_w"]),
            "canvas_height": int(geometry["canvas_h"]),
            "geometry": geometry,
            "guides": guides,
        })

    # ------------------------------------------------------------ LIVE renderer

    @app.route("/api/visualiser/editor-data", methods=["POST"])
    def visualiser_editor_data():
        """Sheet content + fonts + icons + styles for the 60 FPS LIVE canvas.

        Cache key excludes settings (live edits never invalidate content);
        pass force=1 to rebuild strips / content.
        """
        cfg = dict(get_config() if callable(get_config) else {})
        data = request.get_json(force=True, silent=True) or {}
        sheet_name = _sheet_arg(data)
        force = bool(data.get("force"))
        if not sheet_name:
            sheets, _error, _sheet_tables, _sheet_windows = _normal_sheets(cfg)
            sheet_name = sheets[0] if sheets else ""
        if not sheet_name:
            return jsonify({"ok": False, "error": "No sheet available. Configure the Excel workbook in the Project view first."}), 400

        key = _editor_key(cfg, sheet_name)
        cached = _EDITOR_CACHE.get(key)
        if cached and not force:
            return jsonify({"ok": True, "cached": True, "data": cached})

        try:
            payload = collect_editor_data(cfg, sheet_name, register_preview=register_preview)
        except ValueError as exc:
            return jsonify({"ok": False, "error": str(exc)}), 400
        except Exception as exc:  # addon must never break the UI
            return jsonify({"ok": False, "error": f"LIVE renderer data failed: {exc}"}), 500
        _EDITOR_CACHE[key] = payload
        if len(_EDITOR_CACHE) > _EDITOR_CACHE_MAX:
            for cache_key in list(_EDITOR_CACHE)[: len(_EDITOR_CACHE) - _EDITOR_CACHE_MAX]:
                _EDITOR_CACHE.pop(cache_key, None)
        return jsonify({"ok": True, "cached": False, "data": payload})

    @app.route("/api/font_file")
    def visualiser_font_file():
        """Serve a font file (basename) to the browser for FontFace loading."""
        name = str(request.args.get("file") or "").strip()
        path = _font_dir_lookup(name) if name else ""
        if not path:
            return jsonify({"ok": False, "error": "Font not found."}), 404
        mime = "font/ttf" if path.lower().endswith(".ttf") else "font/otf" if path.lower().endswith(".otf") else "application/octet-stream"
        return send_file(path, mimetype=mime)

    @app.route("/api/visualiser/verify", methods=["POST"])
    def visualiser_verify():
        """Pixel-diff the client LIVE render against the authoritative PIL PNG.

        Body: {sheet_name, png_b64}. Returns match %, mean abs diff and a diff
        image token so drift is visible on the canvas.
        """
        import base64
        import io

        from PIL import Image as _PILImage

        cfg = dict(get_config() if callable(get_config) else {})
        data = request.get_json(force=True, silent=True) or {}
        sheet_name = _sheet_arg(data)
        png_b64 = str(data.get("png_b64") or "")
        if not sheet_name or not png_b64:
            return jsonify({"ok": False, "error": "sheet_name and png_b64 are required."}), 400

        cache_key = _preview_key(cfg, sheet_name) + "|v"
        cached = _VERIFY_CACHE.get(cache_key)
        if cached and os.path.isfile(cached.get("real_png", "")):
            real = cached
        else:
            try:
                result = visualiser_renderer.render_normal_page(cfg, sheet_name)
            except ValueError as exc:
                return jsonify({"ok": False, "error": str(exc)}), 400
            except Exception as exc:
                return jsonify({"ok": False, "error": f"Verify render failed: {exc}"}), 500
            real = {"real_png": result["png_path"], "real_token": ""}
            _VERIFY_CACHE[cache_key] = real
            if len(_VERIFY_CACHE) > _VERIFY_CACHE_MAX:
                for k in list(_VERIFY_CACHE)[: len(_VERIFY_CACHE) - _VERIFY_CACHE_MAX]:
                    _VERIFY_CACHE.pop(k, None)

        try:
            client_raw = base64.b64decode(png_b64)
            client_img = _PILImage.open(io.BytesIO(client_raw)).convert("RGB")
            real_img = _PILImage.open(real["real_png"]).convert("RGB")
        except Exception as exc:
            return jsonify({"ok": False, "error": f"Cannot decode images: {exc}"}), 400

        if client_img.size != real_img.size:
            client_img = client_img.resize(real_img.size)

        c = client_img.split()
        r = real_img.split()
        diff = _PILImage.new("RGB", real_img.size, (0, 0, 0))
        dd = diff.load()
        cl = [c[0].load(), c[1].load(), c[2].load()]
        rl = [r[0].load(), r[1].load(), r[2].load()]
        w, h = real_img.size
        total = max(1, w * h)
        sum_diff = 0
        matched = 0
        for y in range(h):
            for x in range(w):
                d0 = abs(cl[0][x, y] - rl[0][x, y])
                d1 = abs(cl[1][x, y] - rl[1][x, y])
                d2 = abs(cl[2][x, y] - rl[2][x, y])
                worst = max(d0, d1, d2)
                sum_diff += worst
                if worst < 24:
                    matched += 1
                amp = min(255, worst * 8)
                dd[x, y] = (amp, amp if worst >= 24 else 0, 0 if worst >= 24 else amp)
        match_pct = round(100.0 * matched / total, 2)
        mean_diff = round(sum_diff / float(total), 3)

        diff_path = ""
        diff_token = ""
        real_token = ""
        try:
            work = os.path.join(tempfile.gettempdir(), "psh_visualiser", uuid.uuid4().hex)
            os.makedirs(work, exist_ok=True)
            diff_path = os.path.join(work, "diff.png")
            diff.save(diff_path, "PNG")
            diff_token = register_preview(diff_path) if callable(register_preview) else ""
            real_token = register_preview(real["real_png"]) if callable(register_preview) else ""
        except Exception:
            pass

        return jsonify({
            "ok": True,
            "match_pct": match_pct,
            "mean_diff": mean_diff,
            "diff_token": diff_token,
            "real_token": real_token,
            "canvas_width": real_img.size[0],
            "canvas_height": real_img.size[1],
        })