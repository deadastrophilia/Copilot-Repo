"""Visualiser addon — a visual layout editor for NORMAL pages.

This addon is completely separate from the rendering pipeline. It:
  * never modifies renderer / exporter / parser / preview code,
  * never touches Photoshop documents,
  * only edits the current settings via the existing settings system.

It reuses the existing pure-PIL PNG page renderer for the live preview, so the
canvas is true WYSIWYG: the same code path that produces the real output.
"""

from .visualiser_web import register_visualiser  # noqa: F401

__all__ = ["register_visualiser"]