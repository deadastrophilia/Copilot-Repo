"""Visualiser right-panel control schema (JSON-serializable).

Every `key` is a REAL settings key consumed by the normal-page renderer, so a
control edit and a canvas guide drag change exactly what the output changes.
Two item kinds exist:
  * plain items: {key, label, type, ...} bound to a direct config key;
  * style items: {role, title, fields:[{field, label, type, ...}]} bound to
    the live layer-style object of a role (resolved by visualiser_state).
"""

STYLE_FIELDS = [
    {"field": "stroke_enabled", "label": "Stroke", "type": "toggle"},
    {"field": "stroke_rgb", "label": "Stroke Color", "type": "color", "tuple": True},
    {"field": "stroke_size", "label": "Stroke Size", "type": "slider", "min": 1, "max": 30, "step": 1, "unit": "px"},
    {"field": "stroke_opacity", "label": "Stroke Opacity", "type": "slider", "min": 0, "max": 100, "step": 1, "unit": "%"},
    {"field": "shadow_enabled", "label": "Drop Shadow", "type": "toggle"},
    {"field": "shadow_rgb", "label": "Shadow Color", "type": "color", "tuple": True},
    {"field": "shadow_opacity", "label": "Shadow Opacity", "type": "slider", "min": 0, "max": 100, "step": 1, "unit": "%"},
    {"field": "shadow_distance", "label": "Shadow Distance", "type": "slider", "min": 0, "max": 80, "step": 1, "unit": "px"},
    {"field": "shadow_size", "label": "Shadow Blur", "type": "slider", "min": 0, "max": 80, "step": 1, "unit": "px"},
]

FONT_STYLE_OPTIONS = ["regular", "bold", "italic", "bold italic"]

CONTROL_SECTIONS = [
    {
        "id": "typography_heading",
        "title": "Heading Typography",
        "items": [
            {"key": "h_font", "label": "Font", "type": "font"},
            {"key": "h_font_style", "label": "Style", "type": "select", "options": FONT_STYLE_OPTIONS},
            {"key": "h_size", "label": "Size", "type": "slider", "min": 8, "max": 200, "step": 1, "unit": "px"},
            {"key": "h_rgb", "label": "Color", "type": "color"},
            {"key": "h_bold", "label": "Bold", "type": "toggle"},
        ],
    },
    {
        "id": "typography_body",
        "title": "Body Typography",
        "items": [
            {"key": "b_font", "label": "Font", "type": "font"},
            {"key": "b_font_style", "label": "Style", "type": "select", "options": FONT_STYLE_OPTIONS},
            {"key": "b_size", "label": "Size", "type": "slider", "min": 8, "max": 120, "step": 1, "unit": "px"},
            {"key": "b_rgb", "label": "Color", "type": "color"},
        ],
    },
    {
        "id": "spacing",
        "title": "Spacing & Margins",
        "items": [
            {"key": "line_spacing", "label": "Line Spacing", "type": "slider", "min": 0, "max": 40, "step": 1, "unit": "px"},
            {"key": "para_spacing", "label": "Paragraph Spacing", "type": "slider", "min": 0, "max": 120, "step": 1, "unit": "px"},
            {"key": "heading_top_margin", "label": "Header Top Margin", "type": "slider", "min": 0, "max": 800, "step": 1, "unit": "px"},
            {"key": "heading_to_body_gap", "label": "Heading–Body Gap", "type": "slider", "min": 0, "max": 400, "step": 1, "unit": "px"},
            {"key": "bottom_margin", "label": "Bottom Margin", "type": "slider", "min": 0, "max": 1000, "step": 1, "unit": "px"},
            {"key": "margin_x", "label": "Left/Right Margin", "type": "slider", "min": 0, "max": 960, "step": 1, "unit": "px"},
            {"key": "inner_canvas_width", "label": "Inner Canvas Width", "type": "slider", "min": 100, "max": 5000, "step": 1, "unit": "px", "hint": "0 = auto: capped at the background height minus 10 px each side, centered. Drag the Left/Right guides to adjust."},
            {"key": "continued_gap", "label": "Continued Title Gap", "type": "slider", "min": 0, "max": 120, "step": 1, "unit": "px"},
        ],
    },
    {
        "id": "table_style",
        "title": "Table Style",
        "items": [
            {
                "key": "table_style.header_bg_rgb",
                "label": "Header Background",
                "type": "color",
                "tuple": True,
            },
            {
                "key": "table_style.row1_bg_rgb",
                "label": "Odd Row Background",
                "type": "color",
                "tuple": True,
            },
            {
                "key": "table_style.row2_bg_rgb",
                "label": "Even Row Background",
                "type": "color",
                "tuple": True,
            },
            {
                "key": "table_style.header_text_rgb",
                "label": "Header Text Color",
                "type": "color",
                "tuple": True,
            },
            {
                "key": "table_style.table_body_text_rgb",
                "label": "Body Text Color",
                "type": "color",
                "tuple": True,
            },
            {
                "key": "table_style.stroke_rgb",
                "label": "Grid Line Color",
                "type": "color",
                "tuple": True,
            },
            {
                "key": "table_style.render_mode",
                "label": "Render Mode",
                "type": "select",
                "options": ["both", "fill", "stroke", "none"],
                "hint": "Both = fills + grid lines; text is always drawn.",
            },
            {
                "key": "table_style.stroke_width",
                "label": "Grid Line Width",
                "type": "slider",
                "min": 0,
                "max": 10,
                "step": 1,
                "unit": "px",
            },
            {
                "key": "table_style.cell_padding_x",
                "label": "Cell Padding X",
                "type": "slider",
                "min": 0,
                "max": 60,
                "step": 1,
                "unit": "px",
            },
            {
                "key": "table_style.cell_padding_y",
                "label": "Cell Padding Y",
                "type": "slider",
                "min": 0,
                "max": 40,
                "step": 1,
                "unit": "px",
            },
            {
                "key": "table_style.table_header_font_size",
                "label": "Header Font Size",
                "type": "slider",
                "min": 8,
                "max": 120,
                "step": 1,
                "unit": "px",
                "hint": "0 = auto from body font.",
            },
            {
                "key": "table_style.table_body_font_size",
                "label": "Body Font Size",
                "type": "slider",
                "min": 8,
                "max": 120,
                "step": 1,
                "unit": "px",
                "hint": "0 = auto from body text size.",
            },
            {
                "key": "table_style.table_icon_height",
                "label": "Icon Height",
                "type": "slider",
                "min": 0,
                "max": 120,
                "step": 1,
                "unit": "px",
                "hint": "0 = auto to match body font.",
            },
            {
                "key": "table_style.row_gap",
                "label": "Row Gap",
                "type": "slider",
                "min": 0,
                "max": 40,
                "step": 1,
                "unit": "px",
            },
            {
                "key": "table_style.table_alignment",
                "label": "Table Alignment",
                "type": "select",
                "options": ["center", "left", "right"],
            },
            {
                "key": "table_style.table_header_alignment",
                "label": "Header Text Alignment",
                "type": "select",
                "options": ["center", "left", "right"],
            },
            {
                "key": "table_style.table_body_alignment",
                "label": "Body Text Alignment",
                "type": "select",
                "options": ["center", "left", "right"],
            },
        ],
    },
    {
        "id": "icons",
        "title": "Icons",
        "items": [
            {"key": "h_icon_h", "label": "Heading Icon Height", "type": "slider", "min": 8, "max": 200, "step": 1, "unit": "px"},
            {"key": "b_icon_h", "label": "Body Icon Height", "type": "slider", "min": 8, "max": 120, "step": 1, "unit": "px"},
            {"key": "heading_icon_gap", "label": "Heading Icon Gap", "type": "slider", "min": 0, "max": 80, "step": 1, "unit": "px"},
            {"key": "icon_gap_left", "label": "Icon Left Offset", "type": "slider", "min": 0, "max": 80, "step": 1, "unit": "px"},
            {"key": "icon_gap_right", "label": "Icon Right Offset", "type": "slider", "min": 0, "max": 80, "step": 1, "unit": "px"},
            {"key": "icon_y_offset", "label": "Icon Vertical Offset", "type": "slider", "min": -40, "max": 40, "step": 1, "unit": "px"},
        ],
    },
    {
        "id": "safe_area",
        "title": "Safe Area",
        "items": [
            {
                "key": "__safe_area_info__",
                "label": "Safe Area",
                "type": "info",
                "text": "The dashed box on the canvas is the inner content area — capped at the "
                "background height minus 10 px margins and centered (symmetric). Drag its Left / Right "
                "edges to adjust the inner canvas width, and drag the Header Top / Heading–Body Gap / "
                "Bottom lines directly on the page. The body text re-wraps live. Portrait canvases keep "
                "the classic left/right margin behaviour.",
            },
        ],
    },
    {
        "id": "layer_styles",
        "title": "Layer Styles",
        "styles": [
            {"role": "heading", "title": "Heading Style", "fields": STYLE_FIELDS},
            {"role": "body", "title": "Body Style", "fields": STYLE_FIELDS},
        ],
    },
]


def controls_payload(config):
    """Build the JSON payload the frontend renders the panel from."""
    from .visualiser_state import style_target

    sections = []
    for section in CONTROL_SECTIONS:
        if "styles" in section:
            styles = []
            for entry in section["styles"]:
                path, name = style_target(config, entry["role"])
                styles.append({
                    "role": entry["role"],
                    "title": entry["title"],
                    "path": path,
                    "name": name,
                    "fields": entry["fields"],
                })
            sections.append({"id": section["id"], "title": section["title"], "styles": styles})
        else:
            sections.append({"id": section["id"], "title": section["title"], "items": section["items"]})
    return sections