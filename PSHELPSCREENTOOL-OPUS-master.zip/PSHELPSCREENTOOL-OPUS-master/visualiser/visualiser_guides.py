"""Visualiser guides: page-space guide lines computed from geometry.

Geometry comes from the same layout math the PNG renderer uses, so a guide
always sits exactly on the rendered output (safe area = the renderer's
safe_width/safe_bottom, heading block = the measured heading height).
"""

from .visualiser_state import GUIDE_DEFS


def compute_guides(geometry):
    """Return guide line definitions in page coordinates (px).

    Each entry: {id, label, key, orientation, edge, min, max,
                 x0, y0, x1, y1, value} where value is the current setting
    value the line represents.
    """
    cw = int(geometry.get("canvas_w", 0))
    ch = int(geometry.get("canvas_h", 0))
    heading_top = int(geometry.get("heading_top", 0))
    heading_bottom = int(geometry.get("heading_bottom", 0))
    body_top = int(geometry.get("body_top", 0))
    body_bottom = int(geometry.get("body_bottom", 0))
    safe_left = int(geometry.get("safe_left", 0))
    safe_right = int(geometry.get("safe_right", 0))

    lines = []
    for guide in GUIDE_DEFS:
        edge = guide["edge"]
        if edge == "top":
            y = heading_top
            x0, y0, x1, y1 = 0, y, cw, y
            value = heading_top
        elif edge == "gap":
            y = body_top
            x0, y0, x1, y1 = 0, y, cw, y
            value = max(0, body_top - heading_bottom)
        elif edge == "bottom":
            y = body_bottom
            x0, y0, x1, y1 = 0, y, cw, y
            value = max(0, ch - body_bottom)
        elif edge == "left":
            x = safe_left
            x0, y0, x1, y1 = x, 0, x, ch
            value = max(0, cw - 2 * x)  # symmetric inner-canvas width
        else:  # right
            x = safe_right
            x0, y0, x1, y1 = x, 0, x, ch
            value = max(0, 2 * x - cw)  # symmetric inner-canvas width
        lines.append(dict(guide) | {
            "x0": x0, "y0": y0, "x1": x1, "y1": y1, "value": value,
        })
    return lines


def value_from_drag(geometry, guide, px_position):
    """Convert a dragged line position (page px) into a new setting value."""
    edge = guide["edge"]
    if edge == "top":
        return int(px_position)
    if edge == "gap":
        return int(max(0, px_position - int(geometry.get("heading_bottom", 0))))
    if edge == "bottom":
        return int(max(0, int(geometry.get("canvas_h", 0)) - px_position))
    if edge == "left":
        return int(max(0, int(geometry.get("canvas_w", 0)) - 2 * px_position))
    if edge == "right":
        return int(max(0, 2 * px_position - int(geometry.get("canvas_w", 0))))
    return int(px_position)


def clamp_value(guide, value):
    """Clamp a guide value to the guide's min/max bounds."""
    lo = int(guide.get("min", 0))
    hi = int(guide.get("max", 10**9))
    return max(lo, min(hi, int(value)))