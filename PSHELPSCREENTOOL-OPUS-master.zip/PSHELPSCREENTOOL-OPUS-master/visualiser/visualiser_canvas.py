"""Visualiser canvas math: zoom / fit / pan (pure functions).

The frontend mirrors these trivial formulas; this module documents the
contract and lets tests pin the behavior (e.g. fit-to-window for 1080p,
1440p and 4K canvases).
"""

MIN_SCALE = 0.05
MAX_SCALE = 8.0


def fit_scale(viewport_w, viewport_h, page_w, page_h, padding=24):
    """Scale that fits a page inside a viewport (no upscaling cap)."""
    if viewport_w <= 0 or viewport_h <= 0 or page_w <= 0 or page_h <= 0:
        return 1.0
    return max(
        MIN_SCALE,
        min((viewport_w - 2 * padding) / page_w, (viewport_h - 2 * padding) / page_h),
    )


def center_offset(viewport_w, viewport_h, page_w, page_h, scale):
    """Offset that centers a scaled page inside a viewport."""
    return (
        max(0.0, (viewport_w - page_w * scale) / 2.0),
        max(0.0, (viewport_h - page_h * scale) / 2.0),
    )


def zoom_scale(scale, factor):
    """Apply a zoom factor, clamped to the allowed scale range."""
    return max(MIN_SCALE, min(MAX_SCALE, scale * factor))


def keep_point_fixed(scale_before, scale_after, tx, ty, cursor_x, cursor_y):
    """Adjust pan so the page point under the cursor stays under the cursor."""
    if scale_before <= 0:
        return tx, ty
    ratio = scale_after / scale_before
    return cursor_x - (cursor_x - tx) * ratio, cursor_y - (cursor_y - ty) * ratio