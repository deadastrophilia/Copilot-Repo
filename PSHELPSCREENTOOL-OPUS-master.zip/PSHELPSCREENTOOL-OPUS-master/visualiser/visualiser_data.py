"""Visualiser LIVE renderer: editor-data extraction (pure server side).

Mirrors build_pngs_only (png_builder) for NORMAL pages so the browser can
reproduce the page layout locally at 60 FPS:

    content (heading + body rows + read-only tables)
    + fonts (resolved file basenames for FontFace)
    + icons (token -> asset name + /api/icon_file URL)
    + styles (layer fx configs, colors, sizes)
    + geometry (safe box, heading block) + settings snapshot

The extractor ONLY READS; it never renders pages. Table strips are rendered
to temp PNGs (registered through register_preview) so the live canvas can
blit pixel-exact read-only tables at flow positions.
"""

import math
import os
import tempfile
import uuid

from ps_autotypesetter import png_builder, row_roles
from ps_autotypesetter.ui_web import engine_api

_FONT_DIRS = [
    os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts"),
    r"C:\Windows\Fonts",
    os.path.join(os.environ.get("LOCALAPPDATA", ""), "Microsoft", "Windows", "Fonts"),
    os.path.join(os.getcwd(), "fonts"),
    os.path.join(os.getcwd(), "Fonts"),
    "/usr/share/fonts",
    "/usr/local/share/fonts",
]

_FALLBACK_FONTS = ["arial.ttf", "Arial.ttf", "DejaVuSans.ttf"]


def resolve_font_file(font_name, bold=False, italic=False):
    """Resolve a font request to a FILE BASENAME that /api/font_file can serve.

    Mirrors png_builder._load_font candidate order (direct names first, then
    compact folder scan, then _best_font_path, then fallbacks).
    """
    try:                                               # the installed face the build draws with (same index)
        from ps_autotypesetter import fontfaces

        hit = fontfaces.pick(font_name, bold, italic)
        if hit:
            return fontfaces.file_key(hit[0])
    except Exception:
        pass
    try:
        base_clean, compact, direct, style_flags = png_builder._font_candidates(font_name, bold, italic)
    except Exception:
        base_clean, compact, direct, style_flags = str(font_name or ""), "", [], {}
    for folder in _FONT_DIRS:
        for filename in direct:
            path = os.path.join(folder, filename)
            if os.path.isfile(path):
                return filename
        try:
            if compact:
                for filename in os.listdir(folder):
                    stem = os.path.splitext(filename)[0]
                    if compact in _compact(stem):
                        if os.path.isfile(os.path.join(folder, filename)):
                            return filename
        except Exception:
            pass
    try:
        path = png_builder._best_font_path(base_clean, compact, style_flags)
        if path and os.path.isfile(path):
            return os.path.basename(path)
    except Exception:
        pass
    for fallback in _FALLBACK_FONTS:
        for folder in _FONT_DIRS:
            if os.path.isfile(os.path.join(folder, fallback)):
                return fallback
    return "arial.ttf"


def _compact(value):
    return "".join(ch for ch in str(value or "").casefold() if ch.isalnum())


def _font_dir_lookup(filename):
    """Absolute path for a font basename across the known font dirs."""
    filename = os.path.basename(str(filename or ""))
    if not filename:
        return ""
    for folder in _FONT_DIRS:
        path = os.path.join(folder, filename)
        if os.path.isfile(path):
            return path
    for folder in _FONT_DIRS:
        try:
            for entry in os.listdir(folder):
                if entry.casefold() == filename.casefold():
                    path = os.path.join(folder, entry)
                    if os.path.isfile(path):
                        return path
        except Exception:
            pass
    try:                                               # a face in another fonts folder (Adobe's, sub-folders)
        from ps_autotypesetter import fontfaces

        return fontfaces.path_by_basename(filename) or ""
    except Exception:
        return ""


def _icon_url(folder, name):
    from urllib.parse import quote
    return f"/api/icon_file?folder={quote(str(folder or ''))}&name={quote(str(name or ''))}"


def collect_editor_data(cfg, sheet_name, register_preview=None):
    """Extract everything the LIVE canvas needs to lay out a normal page.

    Returns a JSON-serializable dict (see module docstring). Raises ValueError
    with a user-facing message for invalid input (mirrors the preview route).
    """
    from visualiser.visualiser_renderer import _is_normal_sheet, _heading_geometry

    if not sheet_name:
        raise ValueError("No sheet selected.")
    excel_path = str(cfg.get("excel_path") or "")
    if not excel_path or not os.path.isfile(excel_path):
        raise ValueError("Excel workbook not set. Configure it in the Project view first.")
    # a Game / Bingo Rules sheet: this gives the canvas its settings, icons and fonts; its layout comes from
    # its own renderer (ps_autotypesetter.rules_layout, through /api/layout/preview)
    if engine_api._sheet_type(sheet_name) == "paytable":
        raise ValueError(f"'{sheet_name}' is a Paytable sheet — paytable support is not part of the LIVE renderer yet.")
    if not png_builder._normalized_sheet_kind(sheet_name) and not _is_normal_sheet(cfg, sheet_name):
        raise ValueError(f"'{sheet_name}' uses a custom JSON layout — the LIVE renderer does not support custom layouts yet.")

    kw = engine_api._build_kwargs(cfg)
    canvas_w = int(kw["c_width"])
    canvas_h = int(kw["c_height"])
    margin_x = max(0, png_builder._safe_int(kw["margin_x"], 100))
    inner_canvas_width = max(0, png_builder._safe_int(kw.get("inner_canvas_width", 0), 0))
    bottom_margin = max(0, png_builder._safe_int(kw["bottom_margin"], 80))
    heading_top_margin = max(0, png_builder._safe_int(kw["heading_top_margin"], 150))
    safe_left, safe_width = png_builder._inner_safe_box(canvas_w, canvas_h, margin_x, inner_canvas_width)
    safe_bottom = max(heading_top_margin + 100, canvas_h - bottom_margin)

    dynamic = dict(kw.get("dynamic_settings") or {})
    table_style = dict(png_builder.TABLE_DEFAULTS, **(kw.get("table_style") or {}))
    icon_folder = str(kw.get("icon_folder") or "")
    icon_mappings = dict(kw.get("icon_mappings") or {})
    icon_size_overrides = dict(kw.get("icon_size_overrides") or {})
    page_max_col = int(kw.get("max_col_limit", 12))

    ov = png_builder._png_page_style_override(sheet_name, kw.get("page_overrides"))
    pg_h_font = str(ov.get("h_font") or kw["h_font"])
    pg_b_font = str(ov.get("b_font") or kw["b_font"])
    pg_h_rgb = ov.get("h_rgb") or kw["h_rgb"]
    pg_b_rgb = ov.get("b_rgb") or kw["b_rgb"]
    pg_h_size = kw["h_size"]
    pg_b_size = kw["b_size"]
    if ov.get("h_size") is not None:
        try:
            pg_h_size = max(8, int(float(ov.get("h_size") or kw["h_size"])))
        except Exception:
            pass
    if ov.get("b_size") is not None:
        try:
            pg_b_size = max(8, int(float(ov.get("b_size") or kw["b_size"])))
        except Exception:
            pass

    library = dynamic.get("layer_style_library") or {}
    assignments = dynamic.get("style_assignments") or {}
    heading_fx = png_builder._resolve_fx_config(library, assignments, "Heading text")
    body_fx = png_builder._resolve_fx_config(library, assignments, "Body text")

    from ps_autotypesetter import workbook_cache

    wb = None
    _wb_loan = workbook_cache.borrow(excel_path)       # shared parse with the page render
    try:
        wb = _wb_loan.__enter__()
        ws = wb[sheet_name]

        render_window = png_builder._render_window_for_sheet(
            kw.get("dynamic_settings") or {}, sheet_name, page_max_col, ws,
        )
        page_min_row, page_max_row, page_min_col, page_max_col = render_window

        tables = []
        try:
            # min_col_limit must be an int: None crashes table_detector
            # (and silently drops every table from the LIVE payload).
            tables = png_builder._prepare_tables(ws, table_style, page_max_col, sheet_name, min_col_limit=page_min_col) if kw.get("enable_tables", True) else []
        except Exception:
            tables = []

        # Mapped JSON tables assigned to this sheet (mirror build_pngs_only).
        mapped_for_sheet = []
        try:
            mapped_for_sheet = [
                r for r in png_builder.load_mapped_table_templates(
                    table_style.get("mapped_table_jsons", ""),
                    sheet_overrides=table_style.get("json_sheet_overrides") or {},
                )
                if not r.get("error") and png_builder.template_matches_sheet(r, sheet_name)
            ]
        except Exception:
            mapped_for_sheet = []

        # Drop auto-detected tables that a mapped JSON table already covers so
        # the page does not render the same rows twice (mirrors build_pngs_only).
        if mapped_for_sheet and tables:
            mapped_row_ranges = []
            for record in mapped_for_sheet:
                try:
                    rr = png_builder.source_row_range_for_template(record)
                except Exception:
                    rr = None
                if rr:
                    mapped_row_ranges.append((int(rr[0]), int(rr[1])))
            if mapped_row_ranges:
                tables = [
                    t for t in tables
                    if not any(
                        not (int(t.get("end_row", 0)) < m_start or int(t.get("start_row", 0)) > m_end)
                        for m_start, m_end in mapped_row_ranges
                    )
                ]

        skip_ranges = []
        for table in tables:
            skip_ranges.append((int(table.get("start_row", 0)), int(table.get("end_row", 0))))

        if page_min_col > 1 or page_min_row > 1 or page_max_row < (ws.max_row or 1):
            tables = [
                t for t in tables
                if int(t.get("start_row", 0)) <= page_max_row and int(t.get("end_row", 0)) >= page_min_row
            ]
            skip_ranges = [
                (int(t.get("start_row", 0)), int(t.get("end_row", 0))) for t in tables
            ]

        # Rows consumed by mapped JSON tables are table content too: they must
        # not render again as body text, and the heading scan must skip them.
        for record in mapped_for_sheet:
            try:
                consumed = png_builder.mapped_record_consumed_rows(record)
            except Exception:
                consumed = set()
            if consumed:
                skip_ranges.append((int(min(consumed)), int(max(consumed))))
            else:
                try:
                    rr = png_builder.source_row_range_for_template(record)
                except Exception:
                    rr = None
                if rr:
                    skip_ranges.append((int(rr[0]), int(rr[1])))

        heading_row, heading_text = png_builder._find_heading_row(ws, page_max_col, skip_ranges, min_row=page_min_row, max_row=page_max_row)
        heading_text = heading_text or sheet_name
        # the Excel's own "(Cont.)" / "CONTINUED" note after the heading: the tool's "(Continued)" instead
        heading_text, cont_row, cont_first = row_roles.continued_from_excel(
            heading_text, lambda r: png_builder._row_page_text(ws, r, page_max_col, page_min_col), heading_row, page_max_row)

        current_heading_size = (
            pg_h_size if ov.get("h_size") is not None
            else png_builder._png_heading_size_for_sheet(sheet_name, dynamic, pg_h_size)
        )
        heading_icon_h = max(1, png_builder._safe_int(current_heading_size, png_builder._safe_int(kw["h_icon_h"], 48)))
        body_icon_h = max(1, png_builder._safe_int(kw["b_icon_h"], 28))

        body_rows = []
        table_starts = {int(t.get("start_row", 0)) for t in tables}
        for row_idx in range(page_min_row, page_max_row + 1):
            if row_idx in (heading_row, cont_row) or row_idx in table_starts:
                continue
            if any(lo <= row_idx <= hi for lo, hi in skip_ranges):
                continue
            row_text = png_builder._row_page_text(ws, row_idx, page_max_col, page_min_col)
            if not row_text:
                continue
            body_rows.append({"row": row_idx, "text": row_text,
                              "role": row_roles.role(sheet_name, row_idx)})   # a heading / subheading row (row_roles)

        heading_tokens = sorted({t for t in png_builder.TOKEN_RE.findall(heading_text) if t})
        body_tokens = sorted({
            t
            for entry in body_rows
            for t in png_builder.TOKEN_RE.findall(entry["text"])
            if t
        })

        icons = {}
        for token in sorted(set(heading_tokens) | set(body_tokens)):
            try:
                path = png_builder.resolve_icon_path(token, icon_folder, icon_mappings)
            except Exception:
                path = None
            if not path or not os.path.isfile(path):
                icons[token] = {"file": "", "url": ""}
                continue
            icons[token] = {
                "file": os.path.basename(path),
                "url": _icon_url(os.path.dirname(path), os.path.basename(path)),
            }

        h_style = str(cfg.get("h_font_style") or "regular").casefold()
        b_style = str(cfg.get("b_font_style") or "regular").casefold()
        heading_font_file = resolve_font_file(pg_h_font, bold=True, italic="italic" in h_style)
        body_font_file = resolve_font_file(pg_b_font, bold="bold" in b_style, italic="italic" in b_style)
        # the "(Continued)" line of pages 2+: exactly png_builder's (heading font, regular, 38 %), so
        # a Continued page's body starts at the same y in the live window and the build
        cont = row_roles.continued_look(pg_h_font, current_heading_size, pg_b_rgb)   # Typography › Continued
        cont_size = cont["size"]
        continued_font_file = resolve_font_file(cont["font"], bold=cont["bold"], italic=cont["italic"])
        # rows the artist made subheadings: the build's subheading look (font, size, colour, style)
        sub_name, sub_size, sub_rgb, sub_icon_h = row_roles.subheading_look(pg_h_font, current_heading_size, pg_h_rgb, body_icon_h)
        sub_bold, sub_italic = row_roles.subheading_style()
        subheading_font_file = resolve_font_file(sub_name, bold=sub_bold, italic=sub_italic)
        # heading / subheading rows: wrapped and measured with the build's own code, so the rows and
        # tables after them land exactly where png_builder puts them (the browser measures a
        # display font a few px differently)
        if any(r.get("role") for r in body_rows):
            from ps_autotypesetter import ps_text as _pst

            _I, _D, _F = png_builder._require_pillow()
            _probe = _I.new("RGBA", (8, 8))
            _pd = _D.Draw(_probe)
            _sint = png_builder._safe_int
            _hg = (max(0, _sint(dynamic.get("heading_icon_gap_left", dynamic.get("heading_icon_gap", 15)), 15)),
                   max(0, _sint(dynamic.get("heading_icon_gap_right", dynamic.get("heading_icon_gap", 15)), 15)))
            _bg = (max(0, _sint(dynamic.get("icon_gap_left", 15), 15)), max(0, _sint(dynamic.get("icon_gap_right", 15), 15)))
            _yo = int(kw.get("icon_y_offset") or 0)
            for r in body_rows:
                if r.get("role") == "heading":
                    font = png_builder._load_font(_F, pg_h_font, current_heading_size, bold=True)
                    ih, gaps = max(1, _sint(kw.get("h_icon_h"), _sint(current_heading_size, 48))), _hg
                    trk = png_builder._tracking_setting(dynamic, "heading_tracking")
                elif r.get("role") == "subheading":
                    font = png_builder._load_font(_F, sub_name, sub_size, bold=sub_bold, italic=sub_italic)
                    ih, gaps, trk = sub_icon_h, _bg, png_builder._tracking_setting(dynamic, "body_tracking")
                else:
                    continue
                with _pst.tracking(trk):
                    lines = png_builder._wrap_inline(_pd, _I, r["text"], font, safe_width, icon_folder, icon_mappings,
                                                     ih, icon_size_overrides, gaps[0], gaps[1])
                    r["lines"] = [[ln] + list(png_builder._line_ink_extents(
                        _pd, _I, ln, font, icon_folder, icon_mappings, ih, icon_size_overrides, gaps[0], gaps[1], _yo))
                        for ln in lines if str(ln or "").strip()]
        try:
            _Image, _ImageDraw, _ImageFont = png_builder._require_pillow()
            _probe = _Image.new("RGBA", (8, 8))
            _cfont = png_builder._load_font(_ImageFont, cont["font"], cont_size, bold=cont["bold"], italic=cont["italic"])
            continued_h = float(png_builder._measure_inline(_ImageDraw.Draw(_probe), _Image, "(Continued)", _cfont,
                                                            icon_folder, icon_mappings, 1)[1])
        except Exception:
            continued_h = None

        geometry = _heading_geometry(kw, sheet_name, ws, canvas_w, canvas_h)

        strip_tokens = []
        table_blocks = []
        for table in tables:
            start_row = int(table.get("start_row", 0))
            end_row = int(table.get("end_row", 0))
            height = 0
            token = ""
            geo = {}
            try:
                Image, ImageDraw, ImageFont = png_builder._require_pillow()
                strip = Image.new("RGBA", (canvas_w, canvas_h), (0, 0, 0, 0))
                sdraw = ImageDraw.Draw(strip)
                # the room a page really has below its heading (the build squeezes a table into it),
                # with the game's layer styles at hand (a table's own text style looks them up)
                from ps_autotypesetter import text_styles as _ts

                # a big table starts a Continued page: heading, "(Continued)" (heading font @ 38%), gaps —
                # the same start as the live layout's newPage()
                # (png_builder.table_room — the build sizes tables with the same rule); a table split
                # across pages keeps its size and is cut by rows instead
                split_on = png_builder._table_split_on(table_style, table)
                room = None if split_on else png_builder.table_room(
                    safe_bottom, float((geometry or {}).get("heading_bottom") or 0), kw.get("heading_to_body_gap"),
                    kw.get("continued_gap"), pg_h_size)
                if split_on:
                    strip = Image.new("RGBA", (canvas_w, max(canvas_h, 4000)), (0, 0, 0, 0))
                    sdraw = ImageDraw.Draw(strip)
                with _ts.active(dynamic.get("text_style_rules") or [], sheet_name, library):
                    height = png_builder._draw_auto_table(
                        strip, sdraw, Image, ImageFont, ws, table, safe_left, 0, safe_width,
                        table_style, icon_folder, icon_mappings, icon_size_overrides,
                        available_height=room, geo=geo,
                    )
                if height and height > 0:
                    crop = strip.crop((safe_left, 0, safe_left + safe_width, min(int(height) + 2, strip.height)))
                    work = os.path.join(tempfile.gettempdir(), "psh_visualiser", uuid.uuid4().hex)
                    os.makedirs(work, exist_ok=True)
                    strip_path = os.path.join(work, f"{uuid.uuid4().hex}.png")
                    crop.save(strip_path, "PNG")
                    if callable(register_preview):
                        token = register_preview(strip_path) or ""
            except Exception:
                height = 0
                token = ""
            table_blocks.append({
                "row_start": start_row,
                "row_end": end_row,
                "height": int(height) if height else 0,
                "token": token,
                "url": f"/api/table_preview/{token}" if token else "",
                "design_key": table.get("design_key") or "",      # click it on the canvas: its own design
                "design": table.get("design") or "current",
                "splits": png_builder._table_splits(table_style, table),   # where the artist cut it (body rows)
                "part_pages": png_builder._table_part_pages(table_style, table),   # parts sent to the page before / after
                "after": max(0, png_builder._safe_int((table_style or {}).get("after_table_margin"), 30)),
                # where its columns and rows are (strip px; x from the strip's left = safe_left)
                "geo": png_builder.table_geo_from(geo, safe_left) if geo else None,
                "texts": sorted({png_builder._text(c.get("value")) for c in png_builder._table_grid_values(table)
                                 if png_builder._text(c.get("value"))})[:80],
            })
            if token:
                strip_tokens.append(token)

        # Mapped JSON tables render as read-only strips too, placed at their
        # source start row so the LIVE canvas lays them out in flow order.
        for record in mapped_for_sheet:
            rr = None
            try:
                rr = png_builder.source_row_range_for_template(record)
            except Exception:
                rr = None
            start_row = int(rr[0]) if rr else int(page_min_row)
            end_row = int(rr[1]) if rr else start_row
            height = 0
            token = ""
            try:
                Image, ImageDraw, ImageFont = png_builder._require_pillow()
                strip = Image.new("RGBA", (canvas_w, canvas_h), (0, 0, 0, 0))
                sdraw = ImageDraw.Draw(strip)
                height = png_builder._draw_mapped_table(
                    strip, sdraw, Image, ImageFont, ws, record, safe_left, 0, safe_width,
                    icon_folder, icon_mappings, icon_size_overrides, {},
                    available_height=max(40, safe_bottom - 0), safe_bottom=safe_bottom,
                )
                if height and height > 0:
                    crop = strip.crop((safe_left, 0, safe_left + safe_width, min(int(height) + 2, canvas_h)))
                    work = os.path.join(tempfile.gettempdir(), "psh_visualiser", uuid.uuid4().hex)
                    os.makedirs(work, exist_ok=True)
                    strip_path = os.path.join(work, f"{uuid.uuid4().hex}.png")
                    crop.save(strip_path, "PNG")
                    if callable(register_preview):
                        token = register_preview(strip_path) or ""
            except Exception:
                height = 0
                token = ""
            table_blocks.append({
                "row_start": start_row,
                "row_end": end_row,
                "height": int(height) if height else 0,
                "token": token,
                "url": f"/api/table_preview/{token}" if token else "",
                "mapped": True,
            })
            if token:
                strip_tokens.append(token)

        table_blocks.sort(key=lambda b: int(b.get("row_start", 0)))
    finally:
        _wb_loan.__exit__(None, None, None)

    bg_path = str(kw.get("bg_path") or "")
    bg_image_url = ""
    if bg_path and os.path.isfile(bg_path):
        bg_image_url = _icon_url(os.path.dirname(bg_path), os.path.basename(bg_path))

    settings = {
        "h_size": int(pg_h_size),
        "h_font": pg_h_font,
        "h_font_style": h_style,
        "h_rgb": list(png_builder._rgb(pg_h_rgb, (255, 80, 80))),
        "h_icon_h": heading_icon_h,
        "b_size": int(pg_b_size),
        "b_font": pg_b_font,
        "b_font_style": b_style,
        "b_rgb": list(png_builder._rgb(pg_b_rgb, (255, 255, 255))),
        "b_icon_h": body_icon_h,
        "margin_x": int(margin_x),
        "inner_canvas_width": int(inner_canvas_width),
        "line_spacing": max(0, png_builder._safe_int(kw["line_spacing"], 4)),
        "line_spacing_raw": float(kw.get("line_spacing") if kw.get("line_spacing") not in (None, "") else 1.1),
        "body_line_spacing": png_builder._effective_row_gap(
            kw.get("line_gap") if kw.get("line_gap") not in (None, "") else None),
        "heading_line_spacing": png_builder._row_gap_px(max(8, int(pg_h_size)),
                                                        float(kw.get("line_spacing") if kw.get("line_spacing") not in (None, "") else 1.1)),
        "para_spacing": max(0, png_builder._safe_int(kw["para_spacing"], 12)),
        "heading_top_margin": heading_top_margin,
        "heading_to_body_gap": max(0, png_builder._safe_int(kw["heading_to_body_gap"], 40)),
        "bottom_margin": bottom_margin,
        "continued_gap": max(0, png_builder._safe_int(kw["continued_gap"], 15)),
        "icon_y_offset": int(kw.get("icon_y_offset") or 0),
        "icon_size_overrides": dict(icon_size_overrides),
        "icon_mappings": dict(icon_mappings),
        "bg_color": str(kw.get("bg_color") or "#FFFFFF"),
        "bg_source": str(cfg.get("bg_source") or "image"),
        "bg_mode": str(kw.get("bg_mode") or "cover"),
        "bg_image_url": bg_image_url,
        "enable_tables": bool(kw.get("enable_tables", True)),
    }

    auto_border = png_builder.detect_master_border(ws) if wb is not None else None
    master_border = None
    if auto_border:
        master_border = {
            "min_row": int(auto_border["min_row"]),
            "max_row": int(auto_border["max_row"]),
            "min_col": int(auto_border["min_col"]),
            "max_col": int(auto_border["max_col"]),
        }

    return {
        "sheet_name": sheet_name,
        "canvas_w": canvas_w,
        "canvas_h": canvas_h,
        "render_window": {
            "min_row": int(page_min_row),
            "max_row": int(page_max_row),
            "min_col": int(page_min_col),
            "max_col": int(page_max_col),
        },
        "master_border": master_border,
        "geometry": geometry,
        "safe": {
            "left": safe_left,
            "width": safe_width,
            "bottom": safe_bottom,
            "right": safe_left + safe_width,
        },
        "heading": {
            "text": heading_text,
            "row": int(heading_row),
            "continued": bool(cont_first),          # page 1 has the "(Continued)" line too
            "font": pg_h_font,
            "font_file": heading_font_file,
            "size": int(current_heading_size),
            "rgb": list(png_builder._rgb(pg_h_rgb, (255, 80, 80))),
            "icon_h": heading_icon_h,
            "fx": heading_fx,
        },
        "body": {
            "font": pg_b_font,
            "font_file": body_font_file,
            "size": int(pg_b_size),
            "rgb": list(png_builder._rgb(pg_b_rgb, (255, 255, 255))),
            "icon_h": body_icon_h,
            "fx": body_fx,
        },
        "rows": body_rows,
        "icons": icons,
        "tables": table_blocks,
        "fonts": {
            "heading": heading_font_file,
            "body": body_font_file,
            "continued": continued_font_file,
            "subheading": subheading_font_file,
        },
        "subheading": {"size": sub_size, "rgb": list(sub_rgb), "icon_h": sub_icon_h, "fx": row_roles.subheading_fx()},
        "continued": {"size": cont_size, "h": continued_h, "rgb": list(cont["rgb"]), "fx": cont["fx"],
                      # Typography › Continued: its own alignment and gap down to the text (None = not set)
                      "align": row_roles.continued_align(png_builder._text_alignment(kw.get("alignment_settings"), sheet_name, "heading")),
                      "body_gap": row_roles.continued_body_gap(20)},
        "settings": settings,
        "section_mode": False,
    }
