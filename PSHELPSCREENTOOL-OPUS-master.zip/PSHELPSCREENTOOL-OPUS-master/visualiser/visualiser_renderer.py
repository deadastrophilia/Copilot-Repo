"""Visualiser preview renderer.

The preview page is produced by the REAL pure-PIL PNG page renderer
(png_builder.build_pngs_only) so the canvas is exact WYSIWYG. Geometry is then
derived from the SAME public helpers the renderer uses (page style overrides,
heading size, heading block height, safe width/bottom), so the overlay guides
sit exactly on the rendered output.
"""

import os
import tempfile
import uuid

from openpyxl import load_workbook

from ps_autotypesetter import png_builder
from ps_autotypesetter.ui_web import engine_api


def _is_normal_sheet(cfg, sheet_name):
    """Normal pages only: not game/bingo rules, not paytable-style sheets and
    no active JSON layout."""
    if png_builder._normalized_sheet_kind(sheet_name) != "":
        return False
    if engine_api._sheet_type(sheet_name) == "paytable":
        return False
    dynamic = cfg.get("dynamic_settings") or {}
    if not dynamic.get("enabled"):
        return True
    path = (dynamic.get("template_json_map") or {}).get(sheet_name)
    if not path and str(sheet_name).lower() == str(dynamic.get("sheet_name") or "").lower():
        path = dynamic.get("template_json") or ""
    return not (bool(path) and os.path.isfile(path))


def _heading_geometry(kw, sheet_name, ws, canvas_w, canvas_h):
    """Mirror the renderer's normal-page heading layout numbers exactly.

    Returns a dict with the margin / heading / body lines in page px.
    All numbers come from the same helper functions build_pngs_only uses.
    """
    margin_x = int(float(kw["margin_x"]))
    heading_top = max(0, png_builder._safe_int(kw["heading_top_margin"], 120))
    safe_left, safe_width = png_builder._inner_safe_box(
        canvas_w, canvas_h, margin_x, png_builder._safe_int(kw.get("inner_canvas_width", 0), 0),
    )
    safe_right = safe_left + safe_width

    ov = png_builder._png_page_style_override(sheet_name, kw.get("page_overrides"))
    pg_h_font = str(ov.get("h_font") or kw["h_font"])
    pg_h_rgb = ov.get("h_rgb") or kw["h_rgb"]
    pg_h_size = kw["h_size"]
    if ov.get("h_size") is not None:
        try:
            pg_h_size = max(8, int(float(ov.get("h_size") or kw["h_size"])))
        except Exception:
            pass
    dynamic = kw.get("dynamic_settings") or {}
    current_sheet_heading_size = (
        pg_h_size
        if ov.get("h_size") is not None
        else png_builder._png_heading_size_for_sheet(sheet_name, dynamic, pg_h_size)
    )

    page_max_col = int(kw.get("max_col_limit", 12))
    _heading_row, heading_text = png_builder._find_heading_row(ws, page_max_col, [])
    heading_text = heading_text or sheet_name

    Image, ImageDraw, ImageFont = png_builder._require_pillow()
    heading_font = png_builder._load_font(ImageFont, pg_h_font, current_sheet_heading_size, bold=True)
    heading_color = png_builder._rgb(pg_h_rgb, (255, 80, 80))
    heading_icon_h = max(1, png_builder._safe_int(current_sheet_heading_size, png_builder._safe_int(kw["h_icon_h"], 48)))
    line_spacing = max(0, png_builder._safe_int(kw["line_spacing"], 4))

    alignment = kw.get("alignment_settings") or {}
    heading_img_path = png_builder._resolve_heading_image_path(
        sheet_name, alignment.get("heading_image_folder") or "", alignment_settings=alignment,
    )
    heading_height = 0
    if heading_img_path:
        heading_height = int(alignment.get("heading_image_height") or 0)
        if heading_height <= 0:
            try:
                heading_image = Image.open(heading_img_path).convert("RGBA")
                heading_height = int(heading_image.height)
            except Exception:
                heading_height = int(current_sheet_heading_size * 1.4)
    else:
        scratch = Image.new("RGBA", (max(1, safe_width), max(1, safe_width)), (255, 255, 255, 255))
        scratch_draw = ImageDraw.Draw(scratch)
        try:
            _mw, mh = png_builder._draw_inline(
                scratch, scratch_draw, Image, heading_text, margin_x, 0,
                heading_font, heading_color, safe_width,
                kw["icon_folder"], kw.get("icon_mappings") or {}, heading_icon_h,
                kw.get("icon_size_overrides") or {},
                align="center", line_spacing=line_spacing,
            )
            heading_height = int(mh)
        except Exception:
            heading_height = int(current_sheet_heading_size * 1.4)
        if heading_height < 1:
            heading_height = int(current_sheet_heading_size * 1.4)

    body_top = heading_top + heading_height + max(0, png_builder._safe_int(kw["heading_to_body_gap"], 40))
    body_bottom = max(heading_top + 100, canvas_h - max(0, png_builder._safe_int(kw["bottom_margin"], 80)))

    return {
        "canvas_w": canvas_w,
        "canvas_h": canvas_h,
        "margin_x": margin_x,
        "inner_canvas_width": safe_width,
        "heading_top": heading_top,
        "heading_bottom": heading_top + heading_height,
        "heading_height": heading_height,
        "body_top": body_top,
        "body_bottom": body_bottom,
        "safe_left": safe_left,
        "safe_right": safe_right,
        "heading_text": heading_text,
    }


def render_normal_page(cfg, sheet_name, out_dir=None):
    """Render page 1 of a normal sheet with the real PNG renderer.

    Returns {"png_path", "pages", "geometry"} or raises ValueError with a
    user-facing message for invalid input.
    """
    if not sheet_name:
        raise ValueError("No sheet selected.")
    excel_path = str(cfg.get("excel_path") or "")
    if not excel_path or not os.path.isfile(excel_path):
        raise ValueError("Excel workbook not set. Configure it in the Project view first.")
    if png_builder._normalized_sheet_kind(sheet_name) != "":
        raise ValueError(f"'{sheet_name}' is a Game/Bingo Rules sheet — the Visualiser is for normal pages only.")
    if engine_api._sheet_type(sheet_name) == "paytable":
        raise ValueError(f"'{sheet_name}' is a Paytable sheet — paytable support is not part of the Visualiser yet.")
    if not _is_normal_sheet(cfg, sheet_name):
        raise ValueError(f"'{sheet_name}' uses a custom JSON layout — the Visualiser does not support custom layouts yet.")

    kw = engine_api._build_kwargs(cfg)
    canvas_w = int(kw["c_width"])
    canvas_h = int(kw["c_height"])

    work = out_dir or os.path.join(tempfile.gettempdir(), "psh_visualiser", uuid.uuid4().hex)
    os.makedirs(work, exist_ok=True)
    # output_dir / selected_sheets / show_completion_dialogs already come from
    # _build_kwargs — override them in place, then add the PNG-only extras.
    kw["output_dir"] = work
    kw["selected_sheets"] = [sheet_name]
    kw["show_completion_dialogs"] = False
    kw["png_suffix"] = None
    try:
        build_dir = png_builder.build_pngs_only(
            **kw,
            output_format="png",
            progress_callback=None,
            png_compress_level=1,       # preview only: encode speed over file size
        )
    except Exception as exc:
        raise ValueError(f"Preview render failed: {exc}") from exc

    png_path = ""
    safe_name = png_builder._file_safe(sheet_name)
    if build_dir and os.path.isdir(build_dir):
        entries = sorted(os.listdir(build_dir))
        preferred = f"{safe_name}.png"
        if preferred in entries:
            png_path = os.path.join(build_dir, preferred)
        else:
            pngs = [e for e in entries if e.lower().endswith(".png")]
            if pngs:
                png_path = os.path.join(build_dir, pngs[0])
    if not png_path or not os.path.isfile(png_path):
        raise ValueError("Renderer produced no page image.")

    from ps_autotypesetter import workbook_cache

    with workbook_cache.borrow(excel_path) as wb:      # the copy the render just parsed
        geometry = _heading_geometry(kw, sheet_name, wb[sheet_name], canvas_w, canvas_h)

    pages = 1
    try:
        pages = len([e for e in os.listdir(build_dir) if e.lower().endswith(".png")])
    except Exception:
        pass

    return {"png_path": png_path, "pages": pages, "geometry": geometry}