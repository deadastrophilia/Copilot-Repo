# V28: Stable normal renderer + isolated dynamic-page addon

This build starts from the last modular version whose normal text/icon/table pages worked correctly.

## Critical routing rule

The dynamic renderer runs only when the Excel tab name exactly matches the value in:

`Dynamic Pages > Exact Excel tab name`

Default: `Paytable`

Matching is case-insensitive, but it is not a contains/search rule:

- `Paytable` -> dynamic renderer
- `PAYTABLE` -> dynamic renderer
- `Game Paytable` -> normal renderer
- `Rules` -> normal renderer
- every other tab -> original normal text/icon/table renderer

No Excel markers are required and Excel is never modified.

## Template workflow

The JSON stores positions. The red slot PSD is a design/export guide and is not placed into the output.

1. Create rectangle layers in Photoshop named `@slot.<name>`.
2. Run `export_template_slots_v28.jsx`.
3. Select the generated JSON in the Dynamic Pages tab.
4. Select the folder containing symbol PNGs as the normal Icons Folder.

Duplicate slot names are supported. Two layers named `@slot.wild.icon` export as:

- `wild.icon.1`
- `wild.icon.2`

The same configured wild PNG is placed in every matching wild icon slot.

## Current Paytable slots

- `title`
- `symbol.1` through `symbol.5` or `pic1` through `pic5`
- `ace`, `king`, `queen`, `jack`, `ten`
- `wild.title`
- `wild.icon.1`, `wild.icon.2`
- `wild.text1`
- `wild.text2`
- `bottom_notes`

Whole-card slots are split internally into symbol and payout regions. Future templates can add more low-symbol slots such as `nine`, `eight`, or sequential names such as `lower.6`.

## UI control behavior

Normal Heading, Body, Tables, and Layout settings continue to control normal pages only.

The Dynamic Pages tab controls:

- count text size/color
- payout value text size/color
- fallback symbol text size/color
- upper/lower card background colors and opacity
- card stroke
- wild title size/color
- wild panel text size/color
- bottom notes size/color
- wild symbol filename

Dynamic text sizes are used directly at the selected output resolution. They are not silently scaled twice.

## Included test data

The `examples` folder contains:

- `paytable.xlsx`
- corrected `Paytable.json`
- `Paytable_slots.psd` (slot guide only)
- sample symbol assets

The sample asset set does not include `QUEEN.png` or `red_scat.png`; the renderer falls back to editable text for a missing card symbol and visible placeholder text for a missing inline icon.

## Dynamic Excel text flow

Paytable payout cards keep their existing behavior. Text placement can opt into
measured Excel flow regions without changing old templates.

### Direct range layer names

Name a Photoshop slot rectangle with either form before exporting JSON:

- `@slot.FLOW|B5:O6` renders text and `<icon>` tokens from that range.
- `@slot.TEXT|B8:O8` renders the range as literal text.

Every non-empty Excel row becomes an ordered block. The renderer measures all
blocks in Photoshop, wraps them, reduces the configured gap first, then reduces
font size down to the allowed minimum. A region that still cannot fit is skipped
and reported instead of overlapping another region.

### Excel named ranges

For production templates, use an Excel defined name instead of a fixed address:

- Excel name: `PT_RULES_TOP` -> `Paytable!$B$5:$O$6`
- Photoshop layer: `@slot.FLOW|PT_RULES_TOP`

Defined names continue pointing at the intended content when rows are inserted
or moved in Excel.

### One region with multiple sources

Use a top-level `flow_regions` object when several ranges must share one larger
vertical container:

```json
{
  "flow_regions": {
    "rules_panel": {
      "slot": "text",
      "sources": [
        "PT_WILD_DETAILS",
        "PT_CHARACTER_RULE",
        "PT_GENERAL_RULES"
      ],
      "render_mode": "inline_flow",
      "font_size": 30,
      "minimum_font_size": 20,
      "icon_height": 48,
      "gap": 18,
      "minimum_gap": 8,
      "padding": [12, 16, 12, 16],
      "vertical_align": "top",
      "never_overlap": true
    }
  }
}
```

`padding` uses `[top, right, bottom, left]`. Set
`replace_legacy_text` to `true` only when the new region intentionally replaces
old `wild.text*`, `feature.text*`, or `bottom_notes` rendering.

## Visual Template Mapper

Artists do not need to edit `flow_regions` by hand.

1. Create any layout in Photoshop.
2. Add visible placeholder rectangles named `@slot.region.1`,
   `@slot.icon.1`, `@slot.icon.2`, and so on.
3. Export the base slot JSON with the Custom Layout JSON Exporter.
4. Open `Export JSON > Open Visual Template Mapper`.
5. Load the Excel workbook and exported slot JSON.
6. Select an Excel row or expand it to select an individual `<token>`.
7. Click a PSD region in the scaled preview and press Assign.
8. Save the mapped JSON with the exact Excel tab name.

Supported mapping modes:

- Flow: wraps text and resolves remaining `<token>` values as inline icons.
- Text only: renders literal text without converting tokens into icons.
- Dedicated icon: routes one selected token into its own artist-sized PSD slot.

When dedicated token assignments and a Flow assignment use the same Excel
source, those dedicated tokens are automatically removed from the remaining
sentence. This allows large feature icons and smaller inline exception icons to
come from one arbitrary Excel sentence. Assignment order controls the vertical
order when several Excel sources share one PSD region.

The mapper keeps existing payout-card behavior. The placeholder PSD supplies
geometry and sizing; it is still a guide and is not inserted as static artwork.
