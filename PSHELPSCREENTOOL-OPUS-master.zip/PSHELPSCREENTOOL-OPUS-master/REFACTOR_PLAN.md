# Refactor Plan

This document outlines a phased, risk-mitigated refactoring strategy for `PsHelpScreenTool_v46_20_GAME_RULES_RENDERER`.

---

## Core Constraints & Guarantees
1. **Backward Compatibility**: All existing JSON presets (e.g., `nigga.json`), session schemas (`PsHelpScreenTool_Web_Session.json`), and manifest specifications (`.pshelpscreen.json`) must remain 100% compatible.
2. **PNG Engine Parity**: Standalone PNG rendering (`png_builder.py`) must maintain absolute visual and functional parity with the Photoshop PSD builder (`build_engine.py`).
3. **Zero Code Modifications in Documentation Phase**: This plan defines architectural stages prior to execution.

---

## Phased Execution Roadmap

```
+-----------------------------------------------------------------+
| Stage 1: Modularization & Clean Separation of Concerns          |
| - Extract monolithic build_engine.py logic into modular passes   |
+-----------------------------------------------------------------+
                                 |
                                 v
+-----------------------------------------------------------------+
| Stage 2: Unified Typography & Style Pipeline                    |
| - Consolidate font/size/style resolution across PSD & PNG       |
+-----------------------------------------------------------------+
                                 |
                                 v
+-----------------------------------------------------------------+
| Stage 3: Robust Incremental Build & Style Fingerprinting        |
| - Integrate Style Signature into manifest change detection      |
+-----------------------------------------------------------------+
                                 |
                                 v
+-----------------------------------------------------------------+
| Stage 4: Comprehensive Test Suite & Regression Verification      |
| - Expand automated unit, integration, and visual smoke tests    |
+-----------------------------------------------------------------+
```

---

## Stage Details

### Stage 1: Modularization & Clean Separation of Concerns
- **Target File**: `ps_autotypesetter/build_engine.py` (5,400+ lines).
- **Goal**: Decompose monolithic `execute_build` function into dedicated pass handlers:
  1. `SheetPreparationPass`: Excel reading, column window calculation, alignment & metric overrides.
  2. `TableProcessingPass`: Table detection, style mapping, and table rendering dispatch.
  3. `TextAndIconTypesettingPass`: Collecting heading/body specs and batch flushing via `text_icon_renderer.py`.
  4. `PageOutputPass`: Document saving, sidecar manifest writing, and cleanup.
- **Risk Mitigation**: Extract helper functions incrementally without changing call signatures or global side-effects.

### Stage 2: Unified Typography & Style Pipeline
- **Target Files**: `build_engine.py`, `png_builder.py`, `text_icon_renderer.py`.
- **Goal**:
  - Guarantee identical font sizing (points vs. pixels at given DPI/PPI resolution) across both PSD and PNG rendering paths.
  - Centralize PostScript font name resolution (`photoshop_fonts.py`) and keyword color mapping (`keyword_manager.py`).
- **Backward Compatibility**: Ensure JSON style templates continue reading standard font name strings without schema changes.

### Stage 3: Robust Incremental Build & Style Fingerprinting
- **Target Files**: `project_manifest.py`, `build_engine.py`.
- **Goal**:
  - Persist `style_signature` (hash of typography, colors, margins, spacing, background settings) inside `.pshelpscreen.json` manifests.
  - In incremental builds, if `style_signature` changes, automatically trigger full sheet rebuilds to guarantee UI style updates immediately update the rendered PSD/PNGs.
- **Backward Compatibility**: Gracefully fallback when reading legacy `.pshelpscreen.json` manifests lacking the `style_signature` field.

### Stage 4: Comprehensive Test Suite & Regression Verification
- **Target Files**: `tests/` directory.
- **Goal**:
  - Add unit tests for `_build_style_signature` change detection.
  - Add end-to-end regression tests verifying that config updates (heading size, body text size, font choices) propagate cleanly through `engine_api.py` -> `build_engine.py` / `png_builder.py`.
  - Validate 100% pass rate across existing pytest suite (`pytest tests/`).
