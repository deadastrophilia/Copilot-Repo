# PsHelpScreenTool

Run:

```bash
python main.py
```

## Latest fixes in this build

- `(Continued)` placement now uses real rendered heading bounds instead of baseline math.
- Added **Layout & Build > Text/Table Gap After Heading**. Default: `40px`.
- Continued label gap still has its own control. Default: `15px`.
- Heading drop shadow now has a **Blend Mode** dropdown.
- Heading fonts are resolved from Windows family names to Photoshop PostScript font names.
- Heading styles support copied Photoshop layer style, stroke, and drop shadow.

## V31: PSD output folder and Icon Mapping

- **Files & Canvas → PSD Save Folder** controls the directory used for the generated PSD.
  Leave it blank to save beside the selected Excel workbook.
- **Icon Mapping** scans unique `<icon_name>` pointers from all Excel sheets.
  Select a pointer and either choose an asset from the Icons Folder dropdown or
  browse an arbitrary PNG/JPG/JPEG/PSD file.
- **Clear Override** removes only the mapping; the original `<icon_name>` lookup
  from the Icons Folder is used again.
- Mappings apply to normal pages, table cells, paytable symbol cards, WILD assets,
  and inline paytable icons. They are stored in sessions and full presets.
