"""
Build the standalone PsHelpScreenTool Web UI EXE (native pywebview window).

Usage:
    python build_exe_web.py

Produces: dist\\PsHelpScreenTool\\PsHelpScreenTool.exe  (onedir)
Requirements:
    pip install pyinstaller flask pywebview
"""
import os
import subprocess
import sys

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
SPEC_FILE = os.path.join(PROJECT_ROOT, "PsHelpScreenTool.spec")


def build():
    cmd = [
        sys.executable, "-m", "PyInstaller",
        "--noconfirm",
        "--clean",
        SPEC_FILE,
    ]
    print("Running PyInstaller with the web UI spec:")
    print("  " + " ".join(cmd))
    print()
    sys.stdout.flush()

    result = subprocess.run(cmd, cwd=PROJECT_ROOT)
    if result.returncode == 0:
        # the card templates saved in this copy of the tool travel with the EXE (it reads them next to itself)
        import shutil

        src = os.path.join(PROJECT_ROOT, "CardTemplates")
        dst = os.path.join(PROJECT_ROOT, "dist", "PsHelpScreenTool", "CardTemplates")
        if os.path.isdir(src):
            shutil.copytree(src, dst, dirs_exist_ok=True)
        print()
        print("Success! Web UI executable created at:")
        print(f"  {os.path.join(PROJECT_ROOT, 'dist', 'PsHelpScreenTool', 'PsHelpScreenTool.exe')}")
        print("  (zip the dist/PsHelpScreenTool folder to distribute)")
        print()
        print("Notes:")
        print("  - The EXE opens the native app window (pywebview) with the Flask server inside.")
        print("  - User presets are saved next to the EXE in a 'presets' folder.")
        print("  - Logs print to the console window (useful for debugging on other machines).")
    else:
        print(f"Build failed with exit code {result.returncode}")
        sys.exit(result.returncode)


if __name__ == "__main__":
    build()
