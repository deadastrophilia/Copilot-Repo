# Changelog

Consolidated from 49 per-version release-note files on 2026-08-22.

## V47_HEADLESS_PSD_WRITER

V47 - Headless PSD writer (no Photoshop needed to build)

Scope:
- Replace the Photoshop COM build with a headless writer: PSDs are built in seconds and Photoshop is never touched.
- Paytables: auto layout by default, every slot an editable named layer, cards grouped.

Changes:
- New `ps_autotypesetter/psd_writer/`: records the PNG builder's layout and writes it with PhotoshopAPI + psd-tools: editable text layers (keyword colour runs, icon gaps), icon layers, one graphics layer per page, background; preview pixels so text shows on open; captured and simple (stroke/shadow) layer styles become real Photoshop effects.
- `run_build` uses the new writer; the COM engine only runs with `legacy_photoshop_engine: true`. The old partial `build_engine_psapi` branch is no longer used.
- Paytable sheets without a template get the "auto" layout + automapping for the build; the mapped JSON is saved under `<output>/mapped_paytables/` for the Paytable Mapper / slot editor. Opt out with `paytable_default_auto: false`.
- Mapped paytables: each slot is its own layer named after the slot (fills/strokes as their own layers), symbol cards grouped (`pic1` = symbol + counts + pays).
- Keyword colours are now applied to body text in the PNG output too (they were ignored).
- PNG builder caches text measurement and icon loading per build (a 28-sheet build went from 24s to ~9s).
- Safety: an in-place update request writes `<name>_rebuilt.psd` instead of overwriting the old PSD until page splicing is available.
- Fix: a plain Build no longer inherits `update_mode` from an earlier "Update PSD" run (an unchanged Excel used to hit "nothing to update" and write no PSD while the UI said "Build finished"). A skipped update now reports "already up to date".
- Photoshop features that act on the open document (style capture, slot/template export from the active PSD, status dot) now work with whichever Photoshop version is open (`ps_autotypesetter/photoshop_bridge.py`: COM when the registered version is running, otherwise the script is opened with the running Photoshop's own executable). Building PSDs never needs Photoshop.
- Fix: paytable pay/value slots follow their symbol to its rows in the CURRENT sheet (mappings made against another workbook read rows one off and dropped the first pay line). Cells an artist picks by hand are saved as `source_pinned` and kept.

Verification:
- pytest: 394 passed (13 new in tests/test_psd_writer.py).
- 9-page demo workbook: 2.9s (COM engine: 237s+ then crashed); BZZF 28 sheets / 52 pages: 9.7s.
- Opened in Photoshop 2026 with no refresh: every page shows its text; edit drift median 6px, max 10px.

## V46_36_TABLE_JSON_MULTI_AND_FLAT_SLOT_PREVIEW

V46.36 - Table JSON Multi-Template + Flat Slot Preview

Scope:
- Improve auto table wrapping before it falls back to multi-line rows.
- Allow multiple mapped table JSON files to be active for one build.
- Fix table mapper preview/list for flat exported @table JSONs with slot names like row42/header1.

Changes:
- Auto/simple table metrics now expand to the safe max table width in content-width mode when a cell would otherwise wrap and unused horizontal room exists.
- Manual table target width is still respected; auto widening only applies when target width is 0/content mode.
- Table tab Browse now accepts multiple @table JSON files and stores them as semicolon-separated paths; Build already loads that list.
- Saving a mapped table JSON appends it to the active table JSON list instead of replacing the full list.
- Opening the mapper with multiple selected JSONs opens the first selected file while leaving all selected files active for Build.
- Flat table JSON exports now resolve to one template using template_id/source name and expose all slots in the mapper.
- Mapped table rendering now also accepts flat slot names instead of requiring every slot to start with a table prefix.

Verification:
- tests/smoke_test_auto_tables.py passed.
- tests/smoke_test_table_mapping.py passed.
- tests/smoke_test_template_mapper.py passed.
- tests/smoke_test_dynamic.py passed.
- Photoshop stub import passed.
- bigbuck-page-3table.json now resolves as template bigbuck-page-3table with 44 slots.

---

## V46_35_AUTO_TABLE_CONTENT_ROW_HEIGHT

V46.35 - Auto Table Content-Based Row Height

Scope:
- Fix auto/simple tables where mixed text + icons could overflow outside the row.
- Keep mapped @table JSON rendering isolated from this auto-table behavior.

Changes:
- Auto table row-height measurement now uses the same wrapped text/icon line model as the renderer.
- Rows expand from the tallest content in that row, including multi-line wrapped text and inline symbols.
- Icon rows now include vertical safety space, so an 80 px symbol produces at least symbol height plus top/bottom padding.
- Legacy/simple auto table metrics also measure wrapped content instead of relying only on a fixed row-height guess.
- Auto table draw metrics now receive icon size overrides, so measured row height matches rendered symbol height more closely.

Verification:
- tests/smoke_test_auto_tables.py now covers a narrow row with long text plus an inline icon and asserts the row expands.
- tests/smoke_test_auto_tables.py passed.
- tests/smoke_test_table_mapping.py passed.
- tests/smoke_test_template_mapper.py passed.
- tests/smoke_test_dynamic.py passed.
- Photoshop stub import passed.

---

## V46_34_MAPPED_TABLE_ISOLATION_AND_HEADER_DETECTOR_FIX

V46.34 - Mapped Table Isolation + Auto Header Detection

Scope:
- Keep mapped @table JSON styling isolated from auto-table UI controls.
- Improve auto/simple table header detection for compact two-column tables.

Changes:
- Mapped table slot text no longer uses Table tab header/body font size overrides.
- Mapped table slot text no longer uses Table tab header/body line-height overrides.
- Mapped table slot text no longer uses Table tab header/body layer style assignments.
- Mapped table slot fonts now come from the mapped JSON first, then the normal build body font only as a fallback.
- Auto table detection now pulls in a short column-label row immediately above a bordered body band.
  - This prevents rows like "Boardwalk / 1500" from becoming the header when the real header is "PROPERTIES / PRIZE (credits)".
- Auto table detection now excludes bordered intro/narrative rows such as "table below" or "per the table below" from the table grid.
  - This keeps lines like "CASH ON REEL ... credit prizes are per ... table below" in normal body flow instead of styling them as table headers.

Verification:
- tests/smoke_test_auto_tables.py covers mapped JSON font isolation and the compact Properties/Prize header case.
- tests/smoke_test_auto_tables.py passed.
- tests/smoke_test_table_mapping.py passed.
- tests/smoke_test_template_mapper.py passed.
- tests/smoke_test_dynamic.py passed.
- Diffrent Tables.xlsm CASH ON REELS SYMBOLS now detects only rows 14-16 as the table; row 13 remains normal text.

---

## V46_33_TABLE_BODY_FONT_AND_CONTENT_WIDTH

V46.33 - Table Body Font + Content-Based Auto Width

Scope:
- Auto/simple Excel table rendering.
- Mapped @table JSON text rendering font fallback/override support.

Changes:
- Auto tables now default to content-based width instead of stretching to the full safe page width.
- Column width is based on the widest measured cell content plus 10px left and 10px right padding.
- All columns use the same calculated width for a clean uniform table.
- Calculated table width is clamped to the existing safe page margins when content is too wide.
- Added Table Target Width in the Tables UI tab.
  - 0 = content-based width.
  - Positive value = force the auto table group to that width, clamped to safe margins.
- Auto table header and body cells now use separate header/body font names and sizes through the same cell renderer path.
- Plain body text, inline-icon text, and header text now share the same alignment, wrapping, and optional line-height behavior.
- Mapped table JSON preserves and respects row font metadata such as font_name, font_family, font_style, bold, italic, and line_height.
- Mapped table row fonts use JSON values by default, but non-empty UI table header/body font overrides take priority.

Verification:
- py_compile passed for config.py, table_mapping.py, text_icon_renderer.py, table_renderer.py, ui.py, smoke_test_auto_tables.py, and smoke_test_table_mapping.py.
- tests/smoke_test_auto_tables.py passed.
- tests/smoke_test_table_mapping.py passed.
- tests/smoke_test_template_mapper.py passed.
- tests/smoke_test_dynamic.py passed.
- Photoshop API stub import check passed.

---

## V46_32_AUTO_TABLE_STROKE_TARGET_HEIGHT

V46.32 - Auto Table Stroke Layering + Target Height

Scope:
- Auto/simple Excel table renderer only.
- Mapped @table JSON rendering keeps using its mapper-defined slot styles and layout.

Changes:
- Auto table fills and strokes are now created as separate Photoshop layer groups.
- Strokes are moved into a dedicated "Table Strokes" group above "Table Fills" so colored backgrounds do not cover borders.
- Added Table Target Height in the Tables UI tab.
  - 0 keeps the existing automatic table size.
  - A positive value scales the whole rendered auto-table group proportionally to that height.
- Auto table height estimation respects Table Target Height so following body text placement uses the scaled height.
- Auto table body text now prioritizes the Table tab Body Text Color when set, instead of Excel cell text color overriding it.
- Auto table Row 1 Fill and Row 2 Fill now render at full fill opacity when Cell Style includes fill.
  - Overlay Opacity remains for the overall table overlay/background layer.
- Existing header/body font controls remain the source for auto-table text when "Inherit body font for table text" is off.

Verification:
- py_compile passed for config.py, table_renderer.py, ui.py, and smoke_test_auto_tables.py.
- tests/smoke_test_auto_tables.py passed.
- tests/smoke_test_table_mapping.py passed.
- tests/smoke_test_template_mapper.py passed.
- tests/smoke_test_dynamic.py passed.
- Photoshop API stub import check passed.

---

## V46_31_AUTO_TABLE_GRID_RENDERING_POLISH

V46.31 - Auto Table Grid Rendering Polish

- Kept mapped @table JSON rendering untouched.
- Improved automatic table row classification so simple two-row tables render as header + body instead of header + header.
- Kept title + column-header layouts dynamic when a merged title row is followed by a real column-header row.
- Auto grid tables now draw fill and stroke as separate Photoshop layers, so fill opacity 0 no longer hides the stroke.
- Auto grid tables no longer insert hidden border-width gaps between cells when row gap is 0.
- Default auto-table cell padding is now 5px top and bottom, so a 50px icon produces a 60px row by default.
- New sessions default simple table cell style to Fill + Stroke.
- Added smoke coverage for auto table detection, row roles, zero row gap, and default row height.

---

## V46_30_WORKING_QWEN_TABLE_FILES_IMPORT

V46.30 - Working QWEN Table Files Import

- Replaced the current table build/rendering files with the working QWEN versions provided by the user:
  - ps_autotypesetter/build_engine.py
  - ps_autotypesetter/config.py
  - ps_autotypesetter/table_mapping.py
  - ps_autotypesetter/table_renderer.py
- Restored the working mapped-table row reservation behavior so mapped JSON source rows are skipped by normal body rendering.
- Restored fuzzy sheet matching and overlap-based matching between detected Excel tables and mapped table JSON.
- Updated the table mapping smoke test to match the working overlap behavior.

---

## V46_29_TABLE_JSON_PRIORITY_FIX

V46.29 - Table JSON Priority Fix

- Mapped @table JSON now wins over the automatic table renderer when its mapped source range starts on the detected Excel table row.
- Mapped @table JSON also wins when its source range begins before the detected table and covers the detected table start row.
- The build flow now indexes mapped table JSON by both configured trigger row and source-range start row, so a mapped table can render even if Excel table detection calculates a slightly different range.
- Normal automatic table rendering remains active for detected tables that do not match a mapped @table JSON record on the same sheet.
- Added smoke coverage for non-identical detected table ranges so JSON layout routing does not fall back to the generic renderer.

---

## V46_28_TABLE_MAPPER_COMPONENT_RANGE_FIX

V46.28 Table Mapper Component Range Fix

- Fixed a mapper bug where selecting an Excel cell for a slot could overwrite the table component source range.
- The mapper now keeps two separate values:
  - Component source range: the whole table/range that controls placement, trigger row, and row skipping.
  - Slot Excel source: the individual cell/range/token assigned to one JSON slot.
- Renamed the top range field to "Component source range" for clarity.
- Custom JSON tables can now keep using precise per-slot sources like D8, H8, or J8 without losing the full table range such as D8:L22.
- This keeps mapped JSON tables rendering from their JSON layout while normal detected Excel tables still use the old auto table renderer when no mapped JSON is meant for them.

---

## V46_27_TABLE_MAPPER_BULK_EDIT_AND_AUTO_TABLE_COEXISTENCE

V46.27 Table Mapper Bulk Edit and Auto Table Coexistence

- Added multi-select support for @table slots in the mapper.
- Added a slot list beside the canvas so users can select many JSON slots for bulk editing.
- Added a Role dropdown: Auto, Heading, Normal text, Text + inline icons, Dedicated icon, and Slot style.
- Added Apply to Slots for bulk updates across selected slots: role, font size, icon size, text color, alignment, padding, fill, opacity, stroke color, and stroke width.
- Existing Excel source mappings are preserved during bulk style/role updates.
- Ctrl-click on the slot preview toggles slots for bulk editing.
- Mapped table JSON now only matches sheets explicitly saved in the mapper, preventing accidental use on unrelated tabs.
- Old auto table rendering remains the default for normal Excel tables; mapped JSON replaces it only when the configured table/range clearly matches or a <table:name> marker is used.
- Mapped table source rows are skipped only after that mapped table is actually rendered, so stale or unused mapped JSON cannot suppress normal auto-table rows.

---

## V46_26_TABLE_SLOT_STYLE_SYNC_AND_RENDER_ROLES

V46.26 Table Slot Style Sync and Render Roles

- Table mapper fill/stroke controls can now be saved on any slot mapping, not only separate background mappings.
- Selecting a JSON slot now selects the matching mapping row and highlights its Excel source cells/tokens.
- Selecting an existing mapping now restores its background color, opacity, stroke color, stroke width, fill toggle, and stroke toggle instead of resetting them.
- Mapped table rendering draws slot fill/stroke rectangles from the JSON slot bounds before text/icons are rendered.
- Existing background-only mappings still work for fill-only, stroke-only, or fill-plus-stroke table boxes.
- Rendered table content is grouped by role: Heading Text, Normal Text, Text With Inline Icons, and Dedicated Icons.
- Rendered layer names include role prefixes such as Heading, NormalText, TextIcon, DedicatedIcon, and SlotFillStroke.

---

## V46_25_TABLE_MAPPER_CELL_SOURCES_AND_STROKE

V46.25 Table Mapper Cell Sources and Slot Stroke

- Fixed Table JSON Mapper source selection so a row can be expanded into exact Excel cells.
- Cash Express headers like D8, H8, and J8 can now be mapped to separate JSON slots instead of assigning the whole D8:J8 row.
- Multi-select in the Excel source tree combines selected cells/ranges into one mapping when one slot should receive multiple pieces of data.
- Mapping source strings now support multiple ranges separated by semicolons, for example D8; H8; J8.
- Background/box mappings now support fill only, stroke only, or fill plus stroke per JSON slot.
- Slot styling uses the exported JSON slot bounds for fill/stroke size and placement.
- Added smoke coverage for merged Excel headers and saved stroke metadata.

---

## V46_24_DYNAMIC_TABLE_JSON_MAPPER

V46.24 Dynamic Table JSON Mapper

- Added a Tables-tab Table JSON Mapper for @table exports.
- Mapper can load Excel plus artist @table JSON, preview slots, map Excel rows/ranges/tokens, preflight issues, and save mapped table JSON.
- Mapped table JSON now keeps slots for compatibility and adds export_kind=table plus table_slots.
- Added table_templates metadata for placement, margins, fit behavior, sheet/range source, marker insertion, absolute placement, and alternate-template naming.
- Added mapped table renderer support for text, flow text with inline icons, dedicated icon slots, repeated rowTemplate slots, and slot background colors.
- Build flow now renders mapped table components before the auto-table fallback and can insert them after an Excel row or at <table:templateName> markers.
- Auto-table fallback cleanup: explicit table font/icon sizes are preserved during fitting, row gap can stay 0 px, and 0 opacity is respected.
- Updated @table exporter metadata in the Photoshop JSX exporters.
- Added Layer Naming Guide notes for fixed table layers, repeating row table layers, export, and mapper workflow.
- Added tests/smoke_test_table_mapping.py to protect the mapper JSON contract and placement helpers.

---

## V46_23_UNIVERSAL_JSON_EXPORT_PREFIX

V46.23 Universal JSON Export Prefix

- Added an Export JSON UI field: "Export layers starting with".
- Default remains @slot, so existing paytable/custom layout exports stay compatible.
- @table can now export artist-made table component placeholders such as:
  @table.cashExpressTrains.bounds
  @table.cashExpressTrains.row1.trainIcon
- @ can scan all visible @-prefixed placeholder layers.
- Exported JSON now includes slot_prefix and scanned_group metadata.
- Selected-group export now scans only the chosen group/path instead of the whole document.
- Updated the standalone export_template_slots_v28.jsx to prompt for the prefix when run manually in Photoshop.

---

## V46_22_TABLE_DETECTOR_FIX

V46.22 Table Detector Fix

- Fixed table detection so page frames and large merged text rows are not rendered as tables.
- Tables are now detected from dense bordered row bands, then trimmed to the real content grid.
- Preserves support for legacy two-column tables and newer multi-column tables with merged headers.
- Validated on CE_Legend_Buffalo_GameRules_NYL.xlsm:
  - CASH ON REELS SYMBOLS: detects only rows 13-16 / cols 3-12.
  - CASH EXPRESS LEGEND SYMBOLS: detects only rows 8-22 / cols 4-12.
  - HOLD & SPIN: detects the two inner table blocks.
  - GAME RULES: no longer detects the full page as a table.

---

## V46_20_XLSM_SUPPORT

V46.20 - XLSM picker support

- Current Excel and Previous Excel Browse dialogs now show .xlsm files.
- Visual Template Mapper Excel Browse dialog now shows .xlsm files.
- Existing openpyxl workbook reading logic was left unchanged; it already supports .xlsm for reading.
- Compile check passed for ui.py and template_mapper_ui.py.

---

## V46_19_ALIGNMENT_MARGINS

V46.19 - Alignment margins and Game Rules placement controls

- Added Heading left margin and Body left margin controls in Page Alignment.
- Added per-Excel-tab overrides for Heading/Body left margins.
- Left-aligned headings and continued headings now align inside the configured margin box instead of the canvas edge.
- Left-aligned body text now wraps inside the configured margin box.
- Added Game Rules separator placement controls: left, center, right, plus placement margin.
- Added malfunction/legal paragraph L/R margin independent of the upper Game Rules body margin.
- Kept existing centered layouts unchanged by default.
- Compile check passed for build_engine.py and ui.py.

---

## V46_18_ALIGNMENT_LAYER_STYLES

﻿V46.18 - Page Alignment Overrides + Layer Style JSON

- Added global alignment defaults for heading, body, table, bottom/legal, and paytable notes.
- Added per-Excel-tab page alignment overrides and persisted them in the PSD settings JSON.
- Wired alignment through normal pages, continued pages, tables, Game Rules text, and paytable notes.
- Added Layer Styles UI for selected-layer capture, copied-style capture, sidecar JSON, global style preset folder, assignment, rename, duplicate, and delete.
- Added PSD sidecar style JSON saving/loading as <PSD_NAME>.pshelpscreen_styles.json.
- Added style assignments for heading text, body text, table header/body, paytable payout count/value, Game Rules text, malfunction/legal text, and body icons.
- Kept heading layer styles text-only; heading icons are no longer styled by body/icon overrides.
- Preserved existing renderer, update, re-render, Excel parsing, custom layout, and JSON export behavior.

---

## V46_17_GAME_RULES_DYNAMIC_SENTENCE_SPLIT

V46.17 - Game Rules Dynamic Sentence Split

- Fixed Game Rules cells that contain normal copy plus <dynamic...> placeholders.
- Normal text before and after the dynamic token now still renders.
- The sentence containing the dynamic placeholder is isolated onto its own PSD line.
- The dynamic token is replaced with a small reserved blank area instead of importing huge Excel spacing.
- No renderer behavior outside the Game Rules dynamic-placeholder parsing was changed.

---

## V46_16_GAME_RULES_DYNAMIC_LINE

PsHelpScreenTool V46.16

Game Rules dynamic placeholders
- A cell containing <dynamic...> now becomes one structural blank line.
- Other text in that same Excel cell is intentionally discarded.
- Normal paragraph gaps are not added around the reserved dynamic line.
- Dynamic lines remain isolated from the Excel rows above and below.
- The former dynamic-spaces control is now a dynamic blank-line height control.
- A value of 0 uses one automatic Game Rules text line.

Scope
- Game Rules parsing, layout measurement, rendering, and its existing UI settings only.

---

## V46_15_GAME_RULES_SEPARATOR_AND_XTRAA_REELS

PsHelpScreenTool V46.15

Game Rules only:
- Fixed the malfunction separator by converting the configured RGB tuple into a Photoshop SolidColor before filling the rule layer.
- Added Render Game Rules with XTRAA REELS icons toggle.
- Added XTRAA REELS image asset Browse and Remove controls.
- Added per-icon width, outer canvas margin, text clearance, and vertical offset controls.
- Places the same supplied asset on the left and right in a dedicated Game Rules group.
- Restricts Game Rules text width using outer margin + icon width + text clearance on each side.
- Centers side icons beside the upper rules text and clamps them inside the safe vertical area.
- Missing side-icon assets are reported as render warnings.
- All XTRAA REELS settings persist in sessions, presets, and PSD-adjacent project JSON.

No normal-page, table, paytable, mapper, or other rendering branches were changed.

Verification:
- Python compile check passed for UI and build engine.
- Existing mapper and dynamic smoke tests remain part of deployment verification.

---

## V46_14_MAPPER_SELECTION_AND_SPECIAL_TITLES

PsHelpScreenTool V46.14

- Replaced implicit assignment-tree selection with an explicit active mapping index.
- Selected assignment rows are painted sunflower yellow with black text.
- Clicking the active assignment again deselects it.
- Update, Remove, Up, and Down now read the same explicit active assignment.
- Existing mapping font size is loaded into the Fixed font field and Update writes that exact value.
- Added optional @slot.wildTitle and @slot.scatterTitle rendering.
- Wild and Scatter title text can be edited independently in Paytable / Custom Layouts.
- Special titles use the main heading font, color, and heading layer style FX.
- Special-title settings persist in sessions, presets, and PSD-adjacent project JSON.

Verification:
- Python compile check passed for UI, mapper, and paytable renderer.
- Existing mapper and dynamic smoke tests remain part of deployment verification.

---

## V46_13_FIXED_SLOT_FLOW_AND_RESPONSIVE_MAPPER

PsHelpScreenTool V46.13

- Mapped paytable font size is now exact and authoritative.
- Removed all automatic minimum/emergency font reduction from mapped regions.
- Text and icon content wraps against the assigned JSON slot width with an inner safety gutter.
- Over-wide icons are constrained to the slot width while preserving aspect ratio.
- Vertical overflow is clipped at complete line boundaries and reported instead of rendering outside the slot.
- Mapper now labels the font field as Fixed font and no longer exposes misleading minimum/emergency controls.
- New mapper assignments save the same fixed font value in legacy minimum fields for compatibility.
- Preflight and Save Mapped JSON actions are now in a sticky footer that remains visible.
- Mapper source controls use a compact responsive row layout.
- Mapper window size adapts to the available screen and its three panes can shrink further.

Verification:
- Python compile check passed.
- Fixed-slot clipping unit check passed.
- Existing mapper and dynamic smoke tests remain part of deployment verification.

---

## V46_12_MAPPER_STYLES_AND_TEXT_BG

PsHelpScreenTool V46.12

- JSON Mapper assignment rows now use explicit yellow selection with black text and support click-again deselection.
- JSON Mapper blocks duplicate primary slot assignments and keeps Update tied to the visibly selected assignment.
- Added per-token mapper icon asset overrides, including browse, dropdown, clear, and JSON persistence.
- Icon lookup now tolerates spaces, underscores, hyphens, and compact file names.
- Added reusable named Photoshop layer styles for Heading and Body Text.
- Added exact capture of copied Photoshop FX so stroke, shadow, bevel, glow, and other effects persist in sessions and PSD-adjacent JSON.
- Body text and body icons now render into separate groups, preventing body text FX from leaking onto icons.
- Added optional saved layer style application for icons; disabled by default.
- Added @slot.textBG paytable background color and opacity controls.
- Added session and project-settings persistence for all new controls.

Verification:
- Python compile check for all modified modules.
- Template mapper smoke test covers duplicate slots, inline sizes, icon overrides, and spaced icon filenames.

---

## V46_11_MAPPER_SAFETY_AND_ICON_EDITOR

PsHelpScreenTool V46.11 - Mapper Safety and Row Icon Editor

- Added a row-level icon-size editor showing every <token> in the selected Excel sentence.
- Apply Size updates the exact source/slot/token occurrence instead of creating duplicates.
- Clear Size restores the row's default inline icon height.
- Manual Excel selection now clears the previous assignment edit target.
- Clicking the selected assignment a second time deselects it.
- Update requires an explicitly selected assignment and reports which assignment was updated.
- Duplicate primary PSD-slot assignments are rejected in the mapper and JSON preflight.
- Duplicate inline-size entries for the same source/slot/token are rejected.
- Changed the Open JSON Mapper action to the existing red button color family.
- Yellow selected rows and list options now use black text for readable contrast.
- Existing rendering, routing, update, re-render, tables, and payout cards remain unchanged.

---

## V46_10_PAYTABLE_INLINE_ICON_AND_JSON_LIBRARY

PsHelpScreenTool V46.10 - Paytable Inline Icon Sizes and JSON Library

- Added per-occurrence inline icon height mappings for Excel <tokens>.
- The same icon asset can now render at different heights in different Paytable sentences.
- Select an extracted token in JSON Mapper, choose Inline icon size, enter its height, and assign it to the same slot as its parent flow row.
- Kept Dedicated icon mode for tokens that belong in standalone PSD slots.
- Added a searchable saved-game JSON dropdown and Save Current As action.
- The Paytable panel's active JSON is now the mapper's source of truth.
- The active Paytable JSON now wins over stale per-page overrides during Build.
- Moved Routing & JSON controls inside the Paytable tab.
- Renamed Wild panel text size to Side-panel text size and use it as the mapper's initial text size.
- Changed Open JSON Mapper to a magenta-red action button.
- Existing normal pages, tables, payout cards, update, and re-render behavior remain unchanged.

---

## V46_9_PAYTABLE_JSON_MAPPER

PsHelpScreenTool V46.9 - Paytable JSON Mapper Integration

- Moved the Excel-to-JSON slot mapper into Paytable / Custom Layouts > Paytable.
- The mapper opens with the current Excel workbook and active Paytable JSON.
- Saving a mapping now updates the exact Excel-tab JSON override used by Build.
- Mapped templates are authoritative for their mapped side-panel content, avoiding duplicate legacy icons.
- Added an emergency text-fit pass so mapped text is not silently omitted at the preferred minimum size.
- Added a preflight warning when a mapping contains icons but no text assignments.
- Fixed clicking PSD slot labels in the mapper preview.
- Existing normal pages, tables, payout-card rendering, update, and re-render paths are unchanged.

---

## V46_8_VISUAL_TEMPLATE_MAPPER

V46.8 - Visual Template Mapper

- Added an artist-facing Excel-to-PSD Template Mapper under Export JSON.
- Loads any Excel workbook, sheet, and exported custom-layout slot JSON.
- Displays Excel text rows and expandable token occurrences.
- Displays a responsive scaled canvas of every exported PSD placeholder.
- Supports click-to-select PSD slots and ordered assignments.
- Supports Flow, Text Only, and Dedicated Icon mapping modes.
- Generates flow_regions and token_bindings without manual JSON editing.
- Automatically removes dedicated tokens from the remaining flow sentence.
- Dedicated icon dimensions come from the artist's Photoshop placeholder slot.
- Supports font size, minimum font size, inline icon height, gaps, padding, and
  vertical alignment per mapped region.
- Added mapping preflight, existing-mapping reload, reordering, and generated
  JSON auto-routing back into the Dynamic Pages controls.
- Added renderer support for generic dedicated token slots.
- Existing payout cards and legacy custom-layout JSON remain compatible.

---

## V46_7_DYNAMIC_TEXT_FLOW

V46.7 - Dynamic Paytable Text Flow

- Added direct Excel range slots: FLOW|B5:O6 and TEXT|B8:O8.
- Added workbook and worksheet named-range sources for resilient templates.
- Added JSON flow_regions with ordered multi-source vertical stacking.
- Reused the existing token-aware Photoshop inline renderer.
- Added measured wrapping, gap reduction, minimum font-size fitting, padding,
  and top/center/bottom vertical alignment.
- Added never-overlap protection. Unfittable regions are reported and skipped.
- Added flow warnings to render_report.txt through the existing report collector.
- Preserved all existing payout-card and legacy side-panel behavior by default.
- Added smoke coverage for direct ranges, named ranges, and legacy templates.

---

## V46_6_PRODUCTION_FEATURES

V46.6 Production Features
=========================

Added
-----
- Render Report panel.
  - Build, Update, Re-render, and Batch Export now create a report object in the UI.
  - Reports include rendered pages, skipped pages, updated pages, removed pages, selected pages, missing icons, warnings, errors, render time, notes, and output PSD path.
  - Reports can be viewed in the UI and saved as render_report.txt next to the output PSD when possible.

- Missing Icon Manager panel.
  - Scans Excel <tokens> using the existing icon scanning logic.
  - Shows found/missing status, resolved asset, mapping mode, and custom size.
  - Reuses the same icon mapping/custom size dictionaries as the existing Icons & Mapping tab.
  - Includes browse/clear mapping, apply/clear size, and lightweight preview when Tk can load the image.

- Presets panel.
  - Save, load, delete, and duplicate full style/settings presets as JSON.
  - Presets store fonts, sizes, colors, margins, line heights, icon mappings/sizes, table/paytable/Game Rules settings, keyword colors, canvas settings, and production settings.

- Preview panel.
  - Lightweight Excel tab preview with token summary.
  - Excel Diff Preview for old vs new workbook before Update PSD.
  - Optional confirmation prompt before destructive update.

- Backup & Safety panel.
  - Optional PSD file backup before destructive Update/Re-render.
  - Optional preference to use copy mode for re-rendered page groups.
  - Auto Text Fit preflight controls and report logging without rewriting the existing renderer.

- Batch Export panel.
  - Exports all or selected top-level PSD page groups as PNG/JPG through Photoshop Save for Web.
  - Supports output folder, JPG quality, and transparent PNG option.

- Layer Naming Guide panel.
  - Documents normal page group structure and common paytable/custom-layout slot names.

Changed
-------
- Create Help Screen PSD now opens directly to Files & Canvas instead of the Dashboard.
- Dashboard scroll bar removed; major tool pages retain scrollable content areas for smaller windows.
- Added optional report_collector parameter to execute_build; existing callers remain compatible.

Notes
-----
- Rendering, Excel parsing, table detection, paytable rendering, Game Rules rendering, update/re-render behavior, font resolving, session handling, and JSON export logic were kept intact.
- Auto Text Fit is currently a production preflight/report setting. It logs intent and warnings while preserving the existing renderer overflow behavior.

---

## V46_5

PsHelpScreenTool V46.5

Game Rules visual centering update:
- Text-only Game Rules lines now also render into their own line group.
- Every Game Rules line is centered using actual Photoshop layer/group bounds after rendering.
- This should fix remaining off-center text caused by font side bearings/glyph bounds.

---

## V46_4

PsHelpScreenTool V46.4

Updated Game Rules centering logic:
- Text-only rendered lines stay individually centered as standalone lines.
- Lines containing icons render inside their own line group, and that whole line group is centered after render.
- This avoids paragraph-group centering drift that made some lines look slightly off-center.

Existing fixes retained:
- Re-render reuses already-open PSD instead of opening duplicates.

---

## V46_3

PsHelpScreenTool V46.3

Fixed:
- Re-render now reuses the already-open PSD/PSB in Photoshop when the matching document is open.
- Re-render only opens the target PSD if it is not already open.
- Game Rules upper text is rendered as centered paragraph groups with consistent text width.
- Game Rules malfunction/legal paragraph is centered as its own group.

---

## V46_2

PsHelpScreenTool V46.2

Base: V46.1 safe addons merge.

Fixed/changed:
- Page Selection list is taller and sticks to the top/fills the tab instead of sitting low in the panel.
- Re-render tab is now independent from Page Selection.
- Re-render tab has its own Excel tab list, Refresh Pages, Select All, and Clear buttons.
- Re-render uses the current/last generated PSD automatically after Build/Update.
- Removed broken Re-render Browse/Use Last PSD button workflow.
- Build button is bigger and centered.
- Game Rules malfunction/legal section now renders as one paragraph-style wrapped block instead of separate row blocks.
- Added Malfunction paragraph line height control.
- Game Rules separator width/stroke controls remain defaulted to 1000px / 2px.
- Build/Update now stores the saved PSD path as the re-render target.

---

## V46_1_SAFE_ADDONS

PsHelpScreenTool V46.1 Safe Addons Merge

Base used:
- User-provided PsHelpScreenTool_v43_existing_psd_update_manifest.zip
- Existing features were preserved; changes were added on top of this codebase only.

Added/changed:
- Game Rules now blanks only <dynamic...> placeholders. Normal <symbol> tokens remain and render as icons.
- Added Game Rules controls for separator width, separator stroke/height, bottom paragraph left/right margin, icon-safe line height, and dynamic placeholder spaces.
- Game Rules separator default changed to 1000px width and 2px height.
- Game Rules bottom/legal text uses paragraph width with center alignment and custom margins.
- Added per-token custom icon size in Icons & Mapping tab. Blank size uses the default heading/body/table icon size.
- Added dedicated Page Selection tab.
- Added Re-render tab with replace mode and copy mode.
- Re-render uses the selected Excel tabs only and saves into the chosen PSD.
- Build button kept centered and larger in Create mode.

Notes:
- This build does not intentionally remove existing Codex features from the uploaded base.
- Re-render copy mode keeps old groups and creates timestamped copy groups.

---

## V43

PsHelpScreenTool V43 - Existing PSD Update / Manifest Build

Added:
- Update existing PSD mode using an optional Existing PSD field.
- Sidecar manifest (.pshelpscreen.json) saved next to the PSD after each build.
- Manifest-based changed-sheet detection when Previous Excel is not provided.
- Existing PSD is updated in place: only changed/removed sheet groups are rebuilt/deleted.
- UI wording updated to clarify build vs update workflow.

Behavior:
- If Existing PSD is blank -> normal new PSD build.
- If Existing PSD is selected -> tool opens that PSD, compares current Excel against manifest or Previous Excel, removes only changed sheet groups, rebuilds only changed sheets, and leaves other groups untouched.
- Multi-page groups that start with "<Tab Name> (Page X)" are also replaced together.

---

## V42

PsHelpScreenTool V42
===================

Paytable parser/render refinements based on Monopoly paytable test:

- Title parser no longer joins far-right Excel notes into the paytable heading.
- Paytable intro/side text now ignores far-right production/meta notes such as NOTE <BO> and brand agreement comments.
- Lower symbols are classified by label (A/K/Q/J/10 etc.) even when Excel writes them as <A>, <K>, <Q>, <J>.
- Feature panel is now generic rather than strictly WILD-only. It can resolve main feature tokens such as WILD, WILD2x, Scatter, Bonus, etc. from Excel/icon folder/icon mapper.
- Multiple main feature icon slots can receive different assets from Excel tokens instead of repeating the same WILD asset.
- Feature text slots fill sequentially from parsed feature lines; bottom notes render with inline icons instead of plain text only.
- Paytable title is kept as one text layer and auto-shrunk to fit the JSON title slot.

No intentional changes to the normal page renderer, table renderer, session manager, or Custom Layout PSD group scanner.

---

## V41_1

PsHelpScreenTool V41.1
- Custom Layouts PSD group scanner now accepts only Photoshop documents (.psd/.psb).
- Removed the "All files" picker option that allowed accidentally selecting PNG/JPG assets.
- Group scanning now requires an explicit PSD/PSB path so it does not accidentally scan the active PNG/JPG preview in Photoshop.
- Active-PSD export now warns if the active document is not a PSD/PSB.
- No normal renderer, paytable renderer, icon mapping, or table logic changed.

---

## V41

PsHelpScreenTool V41 - Paytable Detector Text/Icon Accuracy

- Improved Paytable JSON detector for existing PSD groups.
- Main feature/WILD/SCATTER icon slots now keep only the large feature-symbol artwork.
- Smaller exception icons in the side text are no longer exported as wild/feature icon slots.
- This prevents purple/red/green exception icons from being replaced by the WILD asset during render.
- Right-side text detection now ignores tiny punctuation-only text layers and correctly keeps useful text slots such as substitution text and reels text.
- Bottom note text is grouped into bottom_notes more safely.
- Paytable renderer now filters older JSON files too: if feature.icon slots include small exception icons, only the main/largest feature icons are filled with the WILD/SCATTER asset.
- Added paytable text-width measurement cache to reduce repeated Photoshop create/delete measuring cycles.
- Normal renderer, table renderer, and strict dynamic sheet routing were not intentionally changed.

---

## V40

PsHelpScreenTool V40
- Improved Paytable JSON auto detector for existing/premade PSDs.
- Prefers full repeated card/background boxes instead of small symbol artwork bounds.
- Exports continuous symbol.1..symbol.N slots so variable paytables can be filled dynamically.
- Renderer now maps lower paytable cards to symbol.(top_count + index) if explicit lower slots are absent.
- Added generic feature.* slot aliases and legacy wild.* aliases for side panels.
- Detector now attempts a safe document-level fallback title when the selected paytable group does not contain a title layer.
- PSD is still never modified or auto-saved by the JSON exporter.

---

## V38

V38 - Custom Layout Paytable JSON Exporter

Added a new Custom Layouts tab with a button:
- Export Paytable JSON from Active PSD

Exporter behavior:
- Requires the PSD to be open in Photoshop.
- Finds a root group named paytable / Paytable / PAYTABLE case-insensitively.
- Ignores all other groups and layers outside that paytable group.
- Does not delete, modify, save, or auto-save the PSD.
- Asks the artist where to save the generated JSON.
- Exports generic draft slots: title, symbol.1, symbol.2, feature.icon.1, feature.text.1, bottom_notes.
- Includes raw_candidates in JSON for debugging and future detection refinement.

Normal rendering, paytable rendering, icon mapping, keyword coloring, and session logic were not intentionally changed.

---

## V36

PsHelpScreenTool V36 - Character-range keyword coloring

Changes:
- Replaced V35 run-based keyword coloring with Photoshop character-range styling.
- Keyword coloring now keeps each text chunk as one Photoshop text layer.
- Fixes decorative heading overlap caused by splitting words into separate layers.
- Removes duplicate overlay keyword layers, reducing layer count and avoiding thick/bold-looking colored text.
- Keyword colors continue to apply to body, heading, table header/body cells, and text chunks around inline icons.
- If Photoshop rejects Action Manager range styling on a specific text layer, the script keeps the normal base-color layer instead of creating overlapping fallback layers.
- Renamed Body tab to Body Text and Icon Mapping tab to Icons & Mapping.
- Updated app window title to PsHelpScreenTool V36.

Notes:
- Text with inline icons still has to split only around icons; each text chunk uses character-range keyword coloring internally.
- Normal renderer, paytable routing, session restore, icon mapping, and output folder behavior were not intentionally changed.

---

## V35

PsHelpScreenTool V35

- Replaced duplicate keyword overlay text with sequential colored text runs.
  This removes the full base-color duplicate layer that made keyword text look
  thicker/heavier.
- Keyword rendering still works in normal text, headings, and table cells via the
  same shared function.
- Paytable exception icons now keep a controlled gap before punctuation, so icons
  do not touch commas/full stops.
- Merged Heading Styles into the Heading tab as a Heading Layer Style / FX group.
- Updated window title to PsHelpScreenTool V35 and widened the UI.
- Preserved session restore and existing build/dynamic routing behavior.

---

## V34_1

PsHelpScreenTool V34.1

- Restored/migrated session remembering after the app rename.
- Loads old PS_AutoTypesetter_Session.json automatically if the new PsHelpScreenTool_Session.json does not exist.
- Saves the current UI session on Generate and also when the window is closed.
- Writes both the new and legacy session filename for backwards compatibility.

---

## V33

V33 - Normal Flow, Bottom Margin, Keywords, Mapping Status, UI Cleanup

Changes:
1. Table/text flow now paginates body text after a table line-by-line.
   - If text after a table fits above the bottom safe margin, it stays on the table page.
   - If it exceeds the remaining area, only the overflow continues on the next page.
2. Added Layout > Bottom Safe Margin.
   - Default 50 px.
   - Normal text/table flow will not intentionally render inside this bottom area.
3. Fixed Keywords panel rendering for normal heading/body text.
   - Keyword colors now override the body/heading color on matched text runs.
   - Matching is case-insensitive and supports longer phrases first.
4. Icon Mapping tab now shows asset availability.
   - Found / Missing status is shown for each Excel pointer.
   - Overrides show when missing and whether fallback/default was found.
5. UI cleanup.
   - Window is wider and resizable.
   - Title updated to V33.

Not changed:
- Exact Paytable routing remains untouched.
- Paytable custom renderer remains isolated.
- Normal page hierarchy from V32 remains intact.

---

## V32

V32 - Table hierarchy/order fix

Fixed normal table-page rendering order.

Previous behavior:
- Text before table rendered first.
- Text after table also rendered before the table.
- Tables were rendered at the end of the sheet/page.

New behavior:
- Rows are processed in Excel order.
- When the renderer reaches a detected table's start row, it renders that table immediately.
- Rows inside the table are skipped after table rendering.
- Text after the table renders after the table.

Example:
Some Text
[Table]
Some Text 2

Now renders as:
Some Text
[Table]
Some Text 2

Dynamic Paytable routing and icon mapping were not changed in this update.

---

## V31

V31 - Inline spacing, PSD output folder, and Icon Mapping

1. Fixed doubled spacing around paytable inline icons.
   - Excel whitespace adjacent to <icon> pointers no longer stacks with the UI icon gap.
   - Punctuation such as commas and periods attaches directly to the preceding icon.
   - Words such as "and" receive exactly one semantic gap.

2. Added Files & Canvas -> PSD Save Folder.
   - Generated PSD is saved in the selected folder.
   - Leaving it blank preserves the old behavior and saves beside the Excel file.
   - The selected folder is saved in sessions and presets.

3. Added Icon Mapping tab.
   - Scans every unique <icon_name> in every Excel sheet.
   - Duplicate pointers are shown once, case-insensitively.
   - Map a selected pointer from an Icons Folder dropdown or browse any image/PSD file.
   - Clear Override restores the original token-name lookup from Icons Folder.
   - Mappings are saved in sessions and full presets.
   - Overrides work in normal text/icon pages, tables, paytable cards, WILD assets,
     and paytable inline exception icons.

4. Normal renderer routing and exact Paytable sheet routing are unchanged.

---

## V30

V30 - Paytable inline text and WILD asset-token fix

Changes:
- Paytable mixed text now splits only at <symbol> pointers.
- Text between pointers stays in combined Photoshop text layers, preserving normal spaces.
- Commas, conjunctions (such as "and"), and final punctuation remain intact.
- Long text runs wrap by words only when the JSON slot is too narrow.
- Adjacent text chunks are merged before rendering, preventing one-layer-per-word spacing loss.
- The WILD artwork key is read from the Excel reels sentence, e.g. <Wild>.
- Asset lookup tries the Excel token case-insensitively, then the optional UI override and legacy aliases.
- When no WILD asset exists, each WILD slot renders the original pointer text, e.g. <Wild>.
- Exact Paytable sheet routing and all normal-page rendering remain unchanged.

Validation:
- Parser detected PIC1-PIC5 and ACE/KING/QUEEN/JACK/10.
- Parser retained the complete substitution sentence.
- Parser extracted wild_token = Wild.
- All Python files passed compileall.

---

## V29

V29 - Paytable punctuation and icon-size controls

Changes:
- Renamed the Dynamic Pages UI tab to Paytable.
- Added separate final-pixel icon height controls for:
  * top-row symbols
  * lower-row symbols
  * repeated WILD symbols
  * inline exception icons
  * inline icon gap
- The paytable substitution sentence now preserves all punctuation and prose around inline icons.
  Example preserved output:
  substitutes for all Niggas except <purple_Niggat>, <red_Niggat> and <green_Niggat>.
- red_Niggat asset lookup now also falls back to gold_scat.png.
- Symbol image placement respects the new Paytable icon height settings and remains centered in each JSON slot.
- Exact sheet-name routing remains unchanged. Normal pages continue through the original renderer.

Validation performed:
- Parsed paytable.xlsx: PIC1-PIC5 and ACE/KING/QUEEN/JACK/10 detected.
- Verified comma, "and", and final period remain in the substitution sentence.
- Verified exact routing: configured "Sheet 2" matches only "Sheet 2" case-insensitively.
- Compiled all 24 Python files successfully.

Photoshop rendering was not executable in this container, so visual spacing should be tested in Photoshop.

---
