"""PsHelpScreenTool — entry point.

Launches the new Web UI (native pywebview window with the Flask server inside).
Use:  python main.py
Legacy Tkinter UI:  python main.py --legacy-ui
"""

import sys


def main():
    if "--legacy-ui" in sys.argv:
        from ps_autotypesetter.ui import launch_ui

        launch_ui()
        return
    from ps_autotypesetter.ui_web.window import launch_desktop

    launch_desktop()


if __name__ == "__main__":
    main()
