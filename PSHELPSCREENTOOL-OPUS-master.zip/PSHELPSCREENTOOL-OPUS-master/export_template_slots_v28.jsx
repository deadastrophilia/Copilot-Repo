#target photoshop

(function () {
    if (!app.documents.length) {
        alert("Open a PSD slot template first.");
        return;
    }

    var doc = app.activeDocument;
    var rawPrefix = prompt("Export layers starting with:", "@slot");
    if (rawPrefix === null) return;

    function normalizePrefix(prefix) {
        prefix = String(prefix || "@slot").replace(/^\s+|\s+$/g, "");
        if (!prefix) prefix = "@slot";
        if (prefix.charAt(0) !== "@") prefix = "@" + prefix;
        if (prefix.length > 1 && prefix.charAt(prefix.length - 1) === ".") {
            prefix = prefix.substring(0, prefix.length - 1);
        }
        return prefix;
    }

    var slotPrefix = normalizePrefix(rawPrefix);
    var matchPrefix = slotPrefix === "@" ? "@" : (slotPrefix + ".");
    var found = [];

    function px(value) {
        return Number(value.as("px"));
    }

    function matchesPrefix(name) {
        name = String(name || "");
        if (slotPrefix === "@") return name.indexOf("@") === 0;
        return name.indexOf(matchPrefix) === 0;
    }

    function cleanSlotName(name) {
        name = String(name || "");
        if (slotPrefix === "@") return name.replace(/^@/, "");
        if (name.indexOf(matchPrefix) === 0) return name.substring(matchPrefix.length);
        return name;
    }

    function exportKind(prefix) {
        if (prefix === "@table") return "table";
        if (prefix === "@slot") return "slot";
        if (prefix === "@") return "all_at_layers";
        return String(prefix || "@slot").replace(/^@/, "");
    }

    function walk(container) {
        for (var i = 0; i < container.layers.length; i++) {
            var layer = container.layers[i];
            if (matchesPrefix(layer.name)) {
                try {
                    var b = layer.bounds;
                    found.push({
                        base: cleanSlotName(layer.name),
                        box: {
                            x: Math.round(px(b[0])),
                            y: Math.round(px(b[1])),
                            w: Math.round(px(b[2]) - px(b[0])),
                            h: Math.round(px(b[3]) - px(b[1]))
                        }
                    });
                } catch (e) {}
            }
            if (layer.typename === "LayerSet") {
                walk(layer);
            }
        }
    }

    walk(doc);
    if (!found.length) {
        alert("No layers beginning with " + matchPrefix + " were found.");
        return;
    }

    var totals = {};
    var used = {};
    for (var i = 0; i < found.length; i++) {
        totals[found[i].base] = (totals[found[i].base] || 0) + 1;
    }

    var slots = {};
    for (var j = 0; j < found.length; j++) {
        var item = found[j];
        var key = item.base;
        if (totals[item.base] > 1) {
            used[item.base] = (used[item.base] || 0) + 1;
            key = item.base + "." + used[item.base];
        }
        slots[key] = item.box;
    }

    var result = {
        template_id: doc.name.replace(/\.[^.]+$/, ""),
        source_psd: doc.name,
        slot_prefix: slotPrefix,
        export_kind: exportKind(slotPrefix),
        canvas: {
            width: Math.round(px(doc.width)),
            height: Math.round(px(doc.height))
        },
        slots: slots
    };
    if (slotPrefix === "@table") {
        result.table_slots = slots;
    }

    var saveFile = File.saveDialog("Save dynamic template JSON", "*.json");
    if (!saveFile) return;
    saveFile.encoding = "UTF8";
    saveFile.open("w");
    saveFile.write(JSON.stringify(result, null, 2));
    saveFile.close();
    alert("Exported " + found.length + " slots using prefix " + slotPrefix + ". Duplicate names were numbered instead of overwritten.");
})();
