"""Proof: replicate an artist's paytable PSD with data from a (new) Excel.

usage: python replicate.py <artist.psd> <group> <excel> <sheet> <symbols_dir> <out.psd> [plan.json]

learn():      read the artist's page group (psd-tools, no Photoshop), identify
              each symbol image against the sheet's symbols, attach every
              number column to its symbol, match rules text to Excel cells.
              Everything not linked to Excel is DESIGN and is never touched.
regenerate(): keep the artist's file (only bg + this page), edit each DATA
              text layer in place — same font, runs, effects, position — with
              the current Excel values, and redraw its preview pixels.
"""
import copy, difflib, json, logging, os, re, struct, sys, time

import numpy as np
from openpyxl import load_workbook
from PIL import Image, ImageDraw, ImageFont
from psd_tools import PSDImage
from psd_tools.api import layers as ptl
from psd_tools.constants import Compression, Tag
from psd_tools.psd.engine_data import Integer, List, String

REPO = r"E:\Work\ClaudeCode\PsHelpScreenTool_ClaudeCodeLatest"
sys.path.insert(0, REPO)
from ps_autotypesetter.icon_mapping import resolve_icon_path            # noqa: E402
from ps_autotypesetter.psd_writer.fontnames import postscript_name      # noqa: E402
from ps_autotypesetter.ui_web import engine_api                          # noqa: E402

logging.disable(logging.WARNING)
NUM_RE = re.compile(r"^[\d.,]+$")


# ── helpers ─────────────────────────────────────────────────────────────────
def lines_of(text):
    return [t.strip() for t in str(text).replace("\r", "\n").split("\n") if t.strip()]


def strip_tokens(text):
    return re.sub(r"\s+", " ", re.sub(r"<[^<>]+>", "", str(text or ""))).strip()


def sheet_text(ws, refs):
    out = []
    for ref in refs.split(","):
        v = ws[ref.strip()].value
        if v not in (None, ""):
            out.append(str(v).strip())
    return out


def thumb(img, size=48):
    img = img.convert("RGBA")
    bb = img.getbbox()
    if bb:
        img = img.crop(bb)
    canvas = Image.new("RGB", img.size, (0, 0, 0))
    canvas.paste(img, mask=img.split()[3])
    return np.asarray(canvas.resize((size, size), Image.LANCZOS), dtype=np.float32) / 255.0


def all_type_layers(group):
    return [l for l in group.descendants() if l.kind == "type" and l.visible and l.text.strip()]


# ── learn ───────────────────────────────────────────────────────────────────
def learn(psd, group_name, ws, symbols_dir):
    group = next(l for l in psd if l.name == group_name)
    blocks = engine_api.automap_paytable_slots_ws(ws, {"slots": {}, "slot_prefix": "@slot"})["blocks"]

    # 1. symbol images -> which sheet symbol (visual match against the sheet's own symbol art)
    candidates = {}
    for b in blocks:
        path = resolve_icon_path(b["token"], symbols_dir, {})
        if path:
            candidates[b["key"]] = thumb(Image.open(path))
    images = [l for l in group.descendants()
              if l.kind in ("pixel", "smartobject") and l.visible and l.width * l.height > 80 * 80]
    scores = []
    for layer in images:
        t = thumb(layer.topil())
        for key, c in candidates.items():
            scores.append((float(np.mean((t - c) ** 2)), id(layer), key, layer))
    scores.sort(key=lambda s: s[0])
    symbol_of, used = {}, set()
    for err, lid, key, layer in scores:            # greedy one-to-one assignment, best first
        if lid in symbol_of or key in used or err > 0.04:
            continue
        symbol_of[lid] = (key, layer, err)
        used.add(key)
    symbols = list(symbol_of.values())

    # 2. data layers
    data, design = [], []
    for layer in all_type_layers(group):
        txt = lines_of(layer.text)
        if txt and all(NUM_RE.match(t) for t in txt):
            # number column: belongs to the nearest identified symbol above it
            cx, top = (layer.left + layer.right) / 2, layer.top
            best = None
            for key, sl, _ in symbols:
                if sl.bottom <= top + 5 and sl.left - 80 <= cx <= sl.right + 80:
                    d = (top - sl.bottom) + abs(cx - (sl.left + sl.right) / 2) * 0.5
                    if best is None or d < best[0]:
                        best = (d, key)
            if best is None:
                design.append((layer.name, "number column with no symbol above"))
                continue
            block = next(b for b in blocks if b["key"] == best[1])
            pays, values = sheet_text(ws, block["pay_ref"]), sheet_text(ws, block["value_ref"])
            # counts vs values: content first, then left=counts / right=values
            if txt == pays and txt != values:
                role = "pay"
            elif txt == values and txt != pays:
                role = "value"
            else:
                sib = [l for l in all_type_layers(group) if l is not layer and abs(l.top - layer.top) < 15
                       and all(NUM_RE.match(t) for t in lines_of(l.text)) and abs(l.left - layer.left) < 120]
                role = "pay" if all(layer.left < s.left for s in sib) else "value"
            data.append(dict(layer_id=layer.layer_id, name=layer.name, role=role, symbol=best[1],
                             source=block["pay_ref" if role == "pay" else "value_ref"], artist_text=txt))
            continue
        # prose: fuzzy match against the sheet's text cells
        artist = strip_tokens(" ".join(txt))
        best = (0.0, None)
        for row in ws.iter_rows():
            for c in row:
                if isinstance(c.value, str) and len(c.value) > 8:
                    r = difflib.SequenceMatcher(None, strip_tokens(c.value).casefold(), artist.casefold()).ratio()
                    if r > best[0]:
                        best = (r, c.coordinate)
        if best[0] >= 0.6:
            data.append(dict(layer_id=layer.layer_id, name=layer.name, role="text", source=best[1],
                             artist_text=txt, match=round(best[0], 2)))
        else:
            design.append((layer.name, "no Excel match: kept as design"))
    return dict(group=group_name,
                symbols=[dict(layer=sl.name, bbox=list(sl.bbox), symbol=k, error=round(e, 4)) for k, sl, e in symbols],
                data=data, design=[dict(layer=n, why=w) for n, w in design])


# ── regenerate ──────────────────────────────────────────────────────────────
_FONT_FILES = None


def font_file(ps_name):
    global _FONT_FILES
    if _FONT_FILES is None:
        _FONT_FILES = {}
        root = r"C:\Windows\Fonts"
        for f in os.listdir(root):
            if f.lower().endswith((".ttf", ".otf", ".ttc")):
                for idx in range(4 if f.lower().endswith(".ttc") else 1):
                    n = postscript_name(os.path.join(root, f), idx)
                    if n:
                        _FONT_FILES.setdefault(n, (os.path.join(root, f), idx))
    return _FONT_FILES.get(ps_name)


def style_of(layer):
    eng = layer.engine_dict
    fonts = layer.resource_dict["FontSet"]
    sd = eng["StyleRun"]["RunArray"][0]["StyleSheet"]["StyleSheetData"]
    xx, xy, yx, yy, tx, ty = [float(v) for v in layer.transform]
    size = float(sd.get("FontSize", 12)) * yy
    auto = bool(sd.get("AutoLeading", True))
    leading = (float(sd["Leading"]) * yy) if (not auto and "Leading" in sd) else size * 1.2
    col = sd.get("FillColor", {}).get("Values")
    rgb = tuple(int(round(float(v) * 255)) for v in col[1:4]) if col else (0, 0, 0)
    just = int(eng["ParagraphRun"]["RunArray"][0]["ParagraphSheet"]["Properties"].get("Justification", 0))
    return dict(font=str(fonts[int(sd.get("Font", 0))]["Name"]).strip("'"), size=size, leading=leading,
                rgb=rgb, just=just, anchor=(tx, ty), sx=xx / yy if yy else 1.0)


def render(text_lines, st):
    """RGBA of the lines drawn at the layer's anchor (first baseline at anchor y)."""
    entry = font_file(st["font"])
    font = ImageFont.truetype(entry[0], max(1, int(round(st["size"]))), index=entry[1]) if entry \
        else ImageFont.truetype("arial.ttf", max(1, int(round(st["size"]))))
    block_w = max([font.getlength(t) for t in text_lines] + [1])
    w = int(block_w) + 40
    h = int(st["leading"] * len(text_lines) + st["size"]) + 40
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    asc = font.getmetrics()[0]
    for i, t in enumerate(text_lines):
        lw = font.getlength(t)
        # Photoshop justification codes: 0 left, 1 right, 2 centre
        x = 20 + {0: 0.0, 1: block_w - lw, 2: (block_w - lw) / 2.0}.get(st["just"], 0.0)
        d.text((x, 20 + asc + i * st["leading"]), t, font=font, fill=st["rgb"] + (255,), anchor="ls")
    bb = img.getbbox()
    return img.crop(bb) if bb else None


def edit_text_layer(layer, new_text):
    """Replace a type layer's characters, keeping its style sheet and effects."""
    tool = layer._record.tagged_blocks.get_data(Tag.TYPE_TOOL_OBJECT_SETTING)
    eng = tool.text_data[b"EngineData"].value["EngineDict"]
    old = str(eng["Editor"]["Text"].value)
    tail = old[len(old.rstrip("\r")):] or "\r"            # artist's trailing returns
    new = new_text.replace("\n", "\r").rstrip("\r") + tail
    eng["Editor"]["Text"] = String(new)
    sr = eng["StyleRun"]
    sr["RunArray"] = List([sr["RunArray"][0]])            # one style for the whole block
    sr["RunLengthArray"] = List([Integer(len(new))])
    pr = eng["ParagraphRun"]
    paras = [len(p) + 1 for p in new.split("\r")[:-1]]   # every paragraph ends with \r
    old_runs = list(pr["RunArray"])
    pr["RunArray"] = List([copy.deepcopy(old_runs[min(i, len(old_runs) - 1)]) for i in range(len(paras))])
    pr["RunLengthArray"] = List([Integer(n) for n in paras])
    tool.text_data[b"Txt "].value = new[:-1] + "\x00"
    layer.name = " ".join(lines_of(new))[:60] or layer.name


def regenerate(psd, plan, ws, out_path):
    group = next(l for l in psd if l.name == plan["group"])
    # psd-tools' layer-section rebuild (_update_record) produces a file Photoshop
    # refuses for complex artist PSDs, so nothing is deleted or re-built: other
    # pages are only hidden, edited layers are patched in place.
    for top in list(psd):
        top.visible = top.name in ("bg", plan["group"])
    by_id = {l.layer_id: l for l in group.descendants()}
    changes = []
    for item in plan["data"]:
        layer = by_id.get(item["layer_id"])
        if layer is None:
            continue
        if item["role"] in ("pay", "value"):
            new_lines = sheet_text(ws, item["source"])
        else:
            cell = str(ws[item["source"]].value or "")
            same = difflib.SequenceMatcher(None, strip_tokens(cell).casefold(),
                                           strip_tokens(" ".join(item["artist_text"])).casefold()).ratio() >= 0.97
            if same:  # only the artist's spacing/line breaks differ
                continue
            if re.search(r"\S\s*<[^<>]+>\s*\S", cell):
                changes.append((item["name"], "NEEDS ARTIST: text with inline icons changed", cell))
                continue
            new_lines = [strip_tokens(cell)]
        if new_lines == item["artist_text"]:
            continue
        st = style_of(layer)
        old_box = (layer.left, layer.top, layer.right)
        edit_text_layer(layer, "\r".join(new_lines))
        new_img = render(new_lines, st)
        # place against the artist's own pixel bounds (same anchor edge, same top)
        if st["just"] == 1:
            left = old_box[2] - new_img.width
        elif st["just"] == 2:
            left = (old_box[0] + old_box[2]) / 2.0 - new_img.width / 2.0
        else:
            left = old_box[0]
        top = old_box[1]
        rec, chans = ptl.PixelLayer._build_layer_record_and_channels(
            new_img, layer.name, int(round(left)), int(round(top)), Compression.RLE, version=psd._record.header.version)
        r = layer._record
        r.top, r.left, r.bottom, r.right = rec.top, rec.left, rec.bottom, rec.right
        # Same channel ids in the same order, so the record and its data stay paired.
        old_ids = [c.id for c in r.channel_info]
        new_by_id = {c.id: (c, d) for c, d in zip(rec.channel_info, chans)}
        infos, datas = [], []
        for cid, (old_info, old_data) in zip(old_ids, zip(r.channel_info, layer._channels)):
            if cid in new_by_id:
                infos.append(new_by_id[cid][0]); datas.append(new_by_id[cid][1])
            else:  # e.g. a user mask: keep as is
                infos.append(old_info); datas.append(old_data)
        r.channel_info = infos
        layer._channels._items[:] = datas  # mutate the list object the file section already holds
        changes.append((item["name"], " / ".join(item["artist_text"]), " / ".join(new_lines)))
    # Photoshop CC also keeps every text layer's engine data in a document-level
    # 'Txt2' block and prefers it over the layer's own copy, so per-layer edits
    # would be ignored. Without it Photoshop reads each layer's own (edited) data
    # and writes a fresh Txt2 on its next save.
    if any(c[1] != "NEEDS ARTIST: text with inline icons changed" for c in changes):
        doc_blocks = psd._record.layer_and_mask_information.tagged_blocks
        if doc_blocks is not None and Tag.TEXT_ENGINE_DATA in doc_blocks:
            del doc_blocks[Tag.TEXT_ENGINE_DATA]
    with open(out_path, "wb") as f:
        psd._record.write(f)
    return changes


if __name__ == "__main__":
    artist, group_name, excel, sheet, symbols_dir, out = sys.argv[1:7]
    t0 = time.perf_counter()
    psd = PSDImage.open(artist)
    ws = load_workbook(excel, data_only=True)[sheet]
    t1 = time.perf_counter()
    plan = learn(psd, group_name, ws, symbols_dir)
    t2 = time.perf_counter()
    json.dump(plan, open(out.replace(".psd", "_plan.json"), "w"), indent=1)
    changes = regenerate(psd, plan, ws, out)
    t3 = time.perf_counter()
    print(f"open={t1 - t0:.2f}s learn={t2 - t1:.2f}s regenerate+save={t3 - t2:.2f}s total={t3 - t0:.2f}s")
    print("symbols:", [(s["symbol"], s["error"]) for s in plan["symbols"]])
    print("data layers:", len(plan["data"]), " design text layers kept:", [d["layer"][:30] for d in plan["design"]])
    for c in changes:
        print("  CHANGED", c)
