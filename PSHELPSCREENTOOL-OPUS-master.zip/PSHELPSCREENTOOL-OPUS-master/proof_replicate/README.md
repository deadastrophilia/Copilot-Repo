# Replicate an artist's paytable with data from Excel — proof (2026-10-17)

`replicate.py` learns the paytable design from `PSDRef/BZZF_blastBlueHelps.psd` and regenerates it from `BZZF_modified.xlsx` (8 payouts + one rules sentence changed).

    python replicate.py ../PSDRef/BZZF_blastBlueHelps.psd paytable BZZF_modified.xlsx Paytable ../symbols out.psd

- `replica.psd`: the artist's file with only the data layers edited in place (other pages hidden).
- `replica_plan.json`: what was learned (symbol identification, which layer reads which Excel cells).
- `side_by_side.png` / `cards_zoom.png`: artist vs replica, both exported from Photoshop 2023 as opened.
