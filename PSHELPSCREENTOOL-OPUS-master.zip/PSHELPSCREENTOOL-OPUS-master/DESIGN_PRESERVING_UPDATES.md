# Design-preserving updates: architecture assessment

Status: proposal for discussion (2026-10-23). No source files were changed for this document.

The guiding rule, from the brief:

> The AGR decides the content. For new documents, the design settings decide the layout. For an artist's PSD, the PSD itself stays the authoritative design.

---

## Phase 1: how the tool works today (checked in the source)

### Entry points and UI
- `web_launcher.py` starts the Flask app in `ui_web/server.py`. Artists use this web UI.
  - The old Tk UI (`ui.py`) still exists but is legacy.
- `ui_web/engine_api.py` is the layer between the UI and the engines. `run_build()` picks the engine.

### Building a PSD (the creator, Workflow B)
| Engine | Where | Needs Photoshop | Status |
|---|---|---|---|
| Headless writer (default) | `psd_writer/build.py`: `png_builder` lays out every page while a `LayerRecorder` notes each layer, then `psd_writer/document.py` writes a layered PSD with psd-tools records | No | Main path |
| Legacy Photoshop engine | `build_engine.execute_build`, through COM | Yes | Opt-in (`legacy_photoshop_engine`) |
| PSAPI writer | `build_engine_psapi.py` | No | Spike only |

- The layout knowledge is in these modules:
  - `png_builder`, `text_icon_renderer`, `layout_engine`, `page_layout`;
  - `dynamic_pages/paytable/*` for cards and paytables;
  - `table_renderer` / `table_mapping` for tables;
  - `dynamic_pages/paylines.py`;
  - the Game Rules logic inside `png_builder`.
- Layer styles become real PSD effects (`layer_styles`, `fx_descriptor`).
- Shapes are live vector shapes (`psd_writer/shapes.py`).

### Photoshop integration
- `photoshop_bridge.run_jsx()` runs ExtendScript in **whichever Photoshop is running, any version**.
  - It uses COM when the running copy is the registered one; otherwise it opens a wrapper `.jsx` with that Photoshop's own executable.
  - Users today:
    - `photoshop_finish` (re-applies text so Photoshop writes Txt2, which removes the warning triangles);
    - `layer_styles` / `fx_verify`;
    - `photoshop_heading_renderer`;
    - `custom_layout_exporter`;
    - parts of `ui_web/ps_actions.py` (capture a style, list groups, export a paytable template from the open PSD).
- Building never requires Photoshop; only interactive features do.
- No UXP panel exists. Everything is ExtendScript plus Action Manager.

### Metadata that already exists
| What | Where | Content |
|---|---|---|
| Game → Market → Version | `games.py`, `pshelp_game.json` per game (kept on this PC beside the registry, not in the depot) | Shared game style, each market's Excel and settings, versions (Excel sha256, PSD path, baseline) |
| Excel baselines | `project_package.py` | Copy of the Excel each version was built from, plus hashes, so "Update" diffs without asking for the old Excel |
| PSD memory | `psd_memory.py`, XMP namespace `pshelp:` inside the PSD | Settings, templates, the Excel (or its values), identity, **page group → sheet/part** and **text layer → sheet/row/kind/slot**. Photoshop 2026 keeps it through open, edit and save (checked 2026-10-18). |
| Legacy sidecar | `project_manifest.py` (`.pshelpscreen.json`) | Sheet hashes for the COM engine |
| Clone links | game JSON `clone_links`, keyed by PSD file name | Page ↔ sheet choices and symbol names for artist PSDs |

### Updating today
- **A tool-made PSD:** "Update Changed Pages" diffs against the baseline. If nothing changed, it skips the build.
  - The headless writer then rebuilds the whole document into a **separate** `_rebuilt` file; the code says it waits "until page splicing … is available".
  - The COM engine re-renders the changed sheets' page groups inside the opened PSD.
  - **In both cases an artist's manual edits on a changed page are lost.**
- **An artist PSD:** `market_clone.py` (about 2,800 lines) plus `artist_design/psd_pages.py`.
  - It matches page groups to sheets and names symbols from the PSD's own evidence.
  - It diffs text word by word and edits text records in place, keeping Txt2.
  - It removes symbols and closes the gap; adds rows; makes Continued pages; copies pages for new sheets; moves removed sheets' pages into "[Deleted From Excel]"; adds colour labels.
  - It shows an approval screen with crops and editing, and stores links per game.
  - It writes the file in Python.

### Limits found while checking (they shape the recommendation)
1. **Python can't measure text the way Photoshop does.** The tool's preview wrap and line height are approximations. That is why rows added to a single text layer can run off the canvas: we can't know exactly where Photoshop will break lines.
2. **Writing an artist PSD in Python means rewriting the whole file** (500–600 MB for the big ones). Some of these outputs are rejected by Photoshop with "not compatible"; the cause is not found yet.
3. **The Python writer can't do everything:**
   - smart-object contents are never re-rendered;
   - text edits leave Photoshop to redo the layout on open (Txt2 view entries are dropped);
   - layers hidden by the tool were shown again by Photoshop in one case, cause unknown.
4. **`psd_memory` links layers by layer name.** Artists rename and duplicate layers, so a name is not a stable key. Layer IDs (`lyid`) are.
5. **`market_clone.py` mixes four jobs** in one module: understanding (matching), deciding (diff), applying (record surgery) and review. Applying is the fragile part. Understanding and deciding are the valuable parts.

---

## Phase 2: the recommended architecture

### The idea in one line
**Both workflows end in a "managed PSD": the PSD plus a binding that says which layers carry which AGR content.** Updates are always the same three steps: work out what changed in the AGR, turn it into a list of small edits on bound layers, and apply them. The design is never rebuilt.

- **Workflow B (the creator):** the binding is written at build time, so the tool knows every layer it made. `psd_memory` already does most of this; it needs layer IDs instead of names.
- **Workflow A (an artist PSD):** the binding comes from *discovery plus one confirmation*. The matching built for Clone a Market already does this.
- After that, **one updater serves both**. A tool-made PSD that an artist later edited by hand updates exactly like an artist PSD, so manual edits survive.

```mermaid
flowchart LR
  subgraph Content
    AGR1[AGR old / market A] --> CM1[Content model]
    AGR2[AGR new / market B] --> CM2[Content model]
    CM1 & CM2 --> DIFF[Change detection<br/>content / structural / design]
  end
  subgraph Design
    PSD[(Managed PSD)] --> BIND[Binding<br/>content id → layer id + rules]
    PROFILE[(Game design profile<br/>pages, symbols, conventions)] --> BIND
  end
  DIFF --> PLAN[Change plan<br/>small ops on bound layers]
  BIND --> PLAN
  PLAN --> REVIEW[Review screen<br/>report, crops, approve, edit]
  REVIEW --> APPLY{Apply}
  APPLY -->|Photoshop open| PS[Photoshop executor<br/>JSX + Action Manager]
  APPLY -->|fallback| PY[Python record executor<br/>today's writer]
  PS & PY --> OUT[(New PSD file<br/>original untouched)]
  OUT --> CHECK[Validation<br/>untouched pages identical, overflow, binding]
  CHECK --> BIND
  NEW[New game: Excel + symbols + background + settings] --> CREATOR[Creator<br/>existing build engine] --> PSD
```

### Responsibilities, and where they live
| Responsibility | Shared? | Today | Proposal |
|---|---|---|---|
| 1. AGR parser | Shared | `excel_frame`, `excel_utils`, `read_workbook` in market_clone, plus each engine's own readers | Keep the readers. Add one `content_model.read(agr)` that returns pages → blocks → rows → cells/tokens with stable IDs |
| 2. Content model | Shared | Implicit (raw cells) | New, small: `Page(id, sheet, kind)`, `Row(id, cells, tokens)`, `Block(kind: prose / list / table / paytable / paylines)` |
| 3. Change detection | Shared | `diff_engine` (cells only); market_clone `RowMap`, `word_diff`, `sheet_likeness`, `sheet_renames` | Move market_clone's matching into `content_diff`. It outputs typed changes with a category (content / structural / design) |
| 4. Design adapter (binding) | Workflow-specific source, shared format | Clone links; `psd_memory` layers | `binding.py`: one format; filled by discovery (A) or by the recorder (B) |
| 5. Manifest / profile store | Shared | `games.py`, `psd_memory`, `clone_links` | Extend these (no new database): design profile in the game, binding in the PSD's XMP plus a copy in the game |
| 6. Layout engine | B builds pages; A only extends them | `png_builder` and others | Unchanged for B. For A, a small "extend" layout: rows under a template row, content region bottom, Continued pages |
| 7. Photoshop document adapter | A (and edited B) | Python record surgery | **New Photoshop executor** (JSX interpreter for a JSON change plan). Python executor kept as fallback |
| 8. Symbol resolver | Shared | `icon_mapping`, `symbol_tokens`, market_clone `Symbols` | One per-game symbol registry: logical symbol → per-market token and file, plus the PSD picture signature |
| 9. Validation and reporting | Shared | `untouched_check`, clone report, preflight | One change report (the brief's example list) plus post-apply checks |
| 10. Project / version management | Shared | `games.py` versions, baselines | Add the design identity and the PSD lineage (what each PSD was derived from) |

### Stable identifiers (Q2, Q7)
Matching text alone is not safe, as the brief says. Identity has two halves.

**Content IDs (AGR side)** are logical, not literal:
- **Page ID:** an ID from the design profile (for example `paytable-1`, `features`, `game-rules`, `bingo-rules`). Each market's sheet is linked to it once, with the sheet-likeness and rename detection that already exist.
- **Row ID:**
  - Paytable and table rows are keyed by their **symbol token or key column** (`pic4`, `5 OF A KIND`).
  - Prose rows are keyed by **order plus a text anchor**. A diff aligns old and new rows, so a reworded paragraph is still "row 3". The current `RowMap` pairing is this.
- **Cell / token IDs:** row ID + column, or row ID + token index.

**Layer IDs (PSD side):** the Photoshop **layer ID** (`lyid`). It survives saves and renames, and psd-tools and Photoshop's Action Manager read the same number. *(To confirm in the spike; the copied pages written with new `lyid`s opened fine in Photoshop.)* Each bound layer also keeps a **fingerprint**: group path, kind, text hash, bounds. If a layer was deleted, or reused for something else, the tool notices and asks instead of writing into the wrong layer.

### What the binding holds (Q12)
```jsonc
// per PSD (in XMP and mirrored in the game file)
{
  "design_id": "spookylink@c2-v3",            // which design this PSD is (game-specific)
  "agr": {"market": "C2", "version": 3, "sha256": "…"},
  "pages": [{
     "page_id": "paytable-1", "group": 1234,   // group layer ID
     "region": {"top": 180, "bottom": 1010},   // content area (learned, user can drag)
     "heading": 1240, "continued_label": 1302, // layers reused for Continued pages
     "row_template": 1251, "split": "rows"     // rows | paragraphs | never
  }],
  "elements": [
     {"id": "paytable-1/pic4/pay5", "layer": 1261, "kind": "text",   "owner": "data",  "fp": "…"},
     {"id": "paytable-1/pic4",      "layer": 1258, "kind": "symbol", "owner": "data",  "fp": "…"},
     {"layer": 1201, "owner": "static"}         // artwork: never touched
  ],
  "created": [1302, 1310],                     // layers/pages the tool made (for idempotency)
  "history": [{"at": "…", "from_agr": "…", "ops": 14, "out": "…psd"}]
}
```
- **Ownership:** each layer is one of:
  - `data`: content can change; style kept;
  - `static`: never touched;
  - `locked`: content can change but nothing moves.

  Anything not bound is `static` by default. That is the rule that protects artwork.

**Where metadata lives (trade-off and recommendation):**
| Place | Pro | Con |
|---|---|---|
| Inside the PSD (XMP) | Travels with the file; Photoshop keeps it (verified) | Hidden; some tools may strip XMP; read-only in practice for artists |
| Sidecar file | Visible | Gets lost or out of sync when files are copied in the depot |
| Game store (`pshelp_game.json`) | Central, keeps history, shared across markets | Lives on one PC today, not in the depot |

**Recommendation: a combination.** The **binding** goes into the PSD's XMP, with a mirror in the game store, so a copied PSD still updates. The **design profile** (page IDs, symbol registry, conventions) goes in the game store, because it is shared by all markets. The game store should get an export / import (or depot location) so a second artist's PC can use it.

---

## Phase 3: mapping approaches compared (A–F)

| Approach | Reliability | Artist effort | Maintenance | Verdict |
|---|---|---|---|---|
| A. Explicit layer tagging (naming rules) | High, if followed | High; past PSDs never followed any rule | Low | **Not required.** Allowed as an override ("a layer named `#pay pic4 5`") |
| B. Visual mapping (click a layer in Photoshop, pick the AGR field) | High | Medium, only for what discovery misses | Low | **Yes, for the leftovers.** The bridge can read the active layer of the open document |
| C. Automated discovery (names, text, structure, picture evidence) | Medium; good for text and paytables, weak for tables and look-alikes | None | Medium | **Yes, as the first pass.** Already built: page votes, row pairing, symbol evidence |
| D. Hybrid (C, then confirm the ambiguous parts) | High | Low, once per game | Medium | **Recommended.** This is the current links review, widened to every element |
| E. Design manifest (stored mapping) | — | — | — | **Yes.** It is where D's result is stored (binding plus profile) |
| F. Photoshop-side integration | Reading and editing text, layers and smart objects through Action Manager is reliable; the DOM is slower | None | Medium | **Yes, as the executor** (see below), not for discovery: Python reads the PSD in 0.2–1.5 s |

### Photoshop-side options for applying edits (Q13)
| Option | Install | Versions | Notes |
|---|---|---|---|
| **ExtendScript + Action Manager via `photoshop_bridge`** | Nothing | Any version the artists have (already works) | Legacy but still shipped. It waits if a modal dialog is open, so the tool must detect that and say so. |
| UXP panel + batchPlay | Panel install (CCX / UXP Developer Tool) | Photoshop 2021+ only | Modern, can show the change list inside Photoshop. Install friction for non-technical artists. |
| Python record surgery (today) | Nothing | Doesn't need Photoshop | No exact text measurement; rewrites the whole file; the "not compatible" problem |

**Recommendation:** add a **Photoshop executor** that runs through the existing bridge. Python sends one JSON change plan; a JSX interpreter applies it to the document. Keep the plan format engine-neutral, so a UXP panel can later run the same plan without changes. Keep the Python executor as the fallback when Photoshop is closed, and for Workflow B.

What the Photoshop executor gains:
- **Exact text bounds after each edit.** Overflow, wrapping and Continued-page splits use Photoshop's own measurement, so the "text runs off the canvas" problem goes away at the source.
- **Photoshop writes the file itself:** no Txt2 rebuilding, no warning triangles, no "not compatible", and smart-object contents can be replaced natively.
- **The document can already be open:** no reading of a 500 MB file by Python at all.

What it costs, and must be verified before relying on it:
- **Setting `textItem.contents` puts the first character's style on the whole layer.** Text with several styles (bold value, coloured word) must be set with an Action Manager `textKey` that carries the style ranges. This is doable, and the Python side already carries style runs for Txt2, but it is the first thing the spike must prove.
- **Speed:** each Action Manager call takes milliseconds, but opening and saving a 500 MB PSD in Photoshop can take tens of seconds. When the file is already open there is no open step. **Measure this on Spooky (563 MB) before promising "under 20 s".**
- **Photoshop must be running and free of dialogs.** The tool must report a busy Photoshop plainly instead of waiting.

---

## Answers to the brief's questions

1. **Most reliable way to update an artist PSD without recreating it:** treat it as a managed PSD. Bind the layers once; turn AGR changes into small edits on bound layers; let Photoshop apply them to a copy; check that untouched pages are byte-identical. Never re-lay out what exists.
2. **Associating content with an unnamed PSD:** automated discovery (text votes per page, row pairing, symbol evidence from rows, cards and links, smart-object file names), then a one-time confirmation of what is ambiguous, then stored layer-ID bindings with fingerprints. Text is evidence, never the key.
3. **Automatic vs one-time mapping:**
   - Usually automatic: text layers whose content matches the AGR; paytable values; symbols in text rows and on cards; page ↔ sheet links when the text votes clearly.
   - One-time mapping:
     - look-alike symbols with no evidence;
     - pages matched only by name;
     - table cells drawn as separate layers with no matching text;
     - the content region of each page (learned, but the artist confirms);
     - the Continued label when the PSD has none.
4. **Preserving icons, formatting, effects, smart objects, masks and artwork:**
   - Only bound `data` layers are edited, and only their content: style runs are re-applied, effects, masks and smart objects are untouched.
   - Things move only by translation.
   - Unbound means static.
   - A validation pass compares every untouched group's record, pixels and text with the original; `untouched_check` already does this.
5. **Added or removed pages and lines:**
   - A sheet added → a copy of the most alike page (same page kind) is filled in. The copy uses the artist's own layers, and the page is marked new (yellow).
   - A sheet removed → its page moves to the hidden "[Deleted From Excel]" group. It is never deleted.
   - A row added → a copy of the row-template layer (plus its symbols) goes under the previous row, and lower content moves down.
   - A row removed → its layers are hidden and the content below closes up. Only layers the binding owns are affected.
6. **Continued pages following the design:** the binding stores each page's region, heading, Continued label and split rule. Overflow moves whole rows (or, in Photoshop, the paragraphs past the break) onto a copy of the page, built from the heading, the label and the moved rows. Never a whole-page copy with everything duplicated. Tables made of merged shapes, and pages marked `split: never`, are **flagged for the artist** instead of guessed.
7. **Reusing a mapping across markets:** the binding points at *logical* content IDs, and each market's AGR is linked to those IDs. For C2 → NYL, the tool diffs AGR(C2) against AGR(NYL), and the same binding turns that diff into edits. Mapping happens once per **design**, not once per market. The NYL output gets its own binding (copied pages get new layer IDs, which are recorded), so NYL v2 later updates from NYL's own history.
8. **Detecting market differences:** these are found by the AGR-to-AGR diff, plus binding gaps (content with no layer) and orphans (bound layers whose content is gone):
   - sheets added, removed or renamed;
   - rows added, removed or reordered;
   - cells changed;
   - symbol tokens added or removed;
   - payline tables changed.

   Each change gets a category; design changes are reported, never applied.
9. **New games without a PSD:** the existing creator (Excel + symbols + tokens + background + settings → PSD) stays exactly as it is. Nothing here depends on an artist PSD.
10. **Tool-made PSDs keeping their settings and mappings:** they already store settings, Excel and page/layer links in XMP (`psd_memory`). Change: key layers by layer ID and fingerprint instead of name, and record per-page region and template rows from the layout the creator just computed. These are exact, so no discovery is needed.
11. **Updating a tool-made PSD that an artist edited by hand:**
    - Stop rebuilding. Use the same updater as for artist PSDs.
    - The fingerprint shows which layers the artist changed. Their content is still updated, but their style and position are kept and nothing is re-laid out.
    - New rows and pages can use the creator's own settings, because the profile has them.
12. **Where metadata lives:** binding in XMP plus a mirror in the game store; the design profile and symbol registry in the game store. See the table above.
13. **Photoshop interface limits:**
    - ExtendScript is legacy, single-threaded and blocked by dialogs. The DOM is slow per layer, so Action Manager should be used.
    - Setting text through the DOM loses style runs.
    - UXP needs installing and Photoshop 2021+.
    - Python/psd-tools can't measure text exactly or render smart objects, and must rewrite the whole file.
14. **Missing, damaged, incompatible or changed PSDs:**
    - Every bound layer is validated before planning.
    - A missing or changed layer becomes a "needs review" item, never a silent guess.
    - A missing PSD → the user picks it again; the game store keeps its last binding.
    - A file psd-tools can't read → the Photoshop executor can still open it.
    - Photoshop's "not compatible" on our own output is a bug to diagnose (Spooky "(3).psd").
15. **Validation, protection and recovery:**
    - The original is never written. The executor opens the PSD and saves a new file (versioned name beside it). On any error it closes without saving.
    - Afterwards, the checks run:
      - untouched pages are identical;
      - every planned op was applied;
      - no new overflow;
      - the binding is still valid.
    - **Idempotency:** ops are keyed by content ID, and created layers are recorded. Running the same AGR twice gives an empty plan, so no duplicate pages, layers or symbols.
16. **Smallest useful proof:** see Phase 4.

---

## Phase 4: the MVP

**Goal:** one real artist PSD, updated from a changed AGR **by Photoshop**, with the design provably untouched.

- **Pilot data.** Recommendation: the NYL Blue Prosperity PSD with its NYL/HHR AGRs; it is already set up and its links are reviewed. Spooky follows as the large-file and Continued-page test.
- **The modified AGR, made from NYL v1:**
  - 3 text changes;
  - one paytable value change;
  - one symbol removed from a rule line;
  - one added rule paragraph that forces a Continued page;
  - one new sheet.

**Steps:**
1. **Binding.** Run the existing discovery on the PSD and show the existing links review. Save the result as a binding keyed by layer ID (in XMP and the game file).
2. **Change plan.** Diff the AGRs. Produce a JSON op list and a readable report ("3 text changes, 1 value, 1 symbol removed, 1 row added → 1 Continued page, 1 new page").
3. **Photoshop executor.** A JSX interpreter for these ops:
   - `set_text` with style ranges;
   - `hide`, `translate`;
   - `duplicate_layer`, `duplicate_group`, `move_into`;
   - `set_label`;
   - `bounds` (to measure).

   It runs on the open document (or opens the PSD), measures text after each edit, splits onto a Continued page using real bounds, and saves as a new file.
4. **Review.** Use the existing approval screen with crops, before the run.
5. **Verification:**
   - every page the plan doesn't touch is byte-identical in records and pixels (`untouched_check`);
   - every changed layer keeps font, size, colour, effects and position, except the planned moves;
   - no layer extends past the region;
   - running it again gives zero ops;
   - the original file's hash is unchanged.
6. **Timing.** Record open, apply and save times on NYL and on Spooky (563 MB).

**Success:** the artist opens the output and sees no triangles, nothing moved that shouldn't, the Continued page fits, and the report matches what changed.

---

## Phase 5: implementation plan (small, testable)

| # | Phase | Modules | Acceptance |
|---|---|---|---|
| 0 | **Spike: Photoshop text edit keeping style ranges, and timings** | new `psd_apply/photoshop.jsx` (small) | A multi-style text layer changed via Action Manager keeps every run; open/apply/save time measured on a 500 MB PSD |
| 1 | **Content model + diff out of market_clone** | new `content_model.py`, `content_diff.py`; market_clone calls them | Existing clone tests pass unchanged; the diff report lists typed, categorised changes |
| 2 | **Binding format + store** | new `binding.py`; `psd_memory` (layer-ID keys, binding section); `games.py` (design profile) | Discovery result round-trips through XMP and the game file; validation flags a renamed or deleted layer |
| 3 | **Change plan as ops** | market_clone `apply` split into "decide" (ops) and "do" (executor) | The Python executor runs the ops and gives today's output byte-for-byte (regression proof) |
| 4 | **Photoshop executor** | new `psd_apply/` (JSX interpreter + Python driver over `photoshop_bridge`) | MVP verification in Phase 4 passes on NYL; busy Photoshop is reported, not waited on |
| 5 | **Continued pages and paragraph split with real measurement** | executor + page rules in the binding | Spooky case: no text past the region; each Continued page has the heading and label only |
| 6 | **Tool-made PSDs use the same updater** | `psd_writer/build.py` writes the binding; Update flow routes to the updater | Hand-edited tool PSD: the edited layer keeps its style and position after an AGR update; no rebuild |
| 7 | **UI: one project screen** | `market_clone.js` → "Update a PSD" (new AGR version or new market); dashboard shows "design mapped / reusable" | An artist runs it with no technical words on screen |
| Later | Tables (merged shapes) row growth; UXP panel; symbol registry UI; game store export/import | — | — |

**Do not change:** the creator's build path (`psd_writer`, `png_builder`, paytable, Game Rules, tables, text/icon renderers). Phase 6 only adds a binding next to what it already writes.

**Main risks:**
1. Style ranges on text edits in Photoshop: Phase 0 decides this.
2. Open and save time of huge PSDs.
3. Artists using very different Photoshop versions.
4. Table pages built from shapes: flagged until a later phase.
5. The "not compatible" bug in the Python writer; it matters less once Photoshop saves the files.

---

## Phase 0 results (2026-10-23, Photoshop 2026 / 27.7)

The spike scripts and reports are in `E:\Work\ClaudeCode\Phase0Spike\scripts`; the output PSDs are beside them. The artist originals were only read; size and mtime were checked unchanged after every run.

**Timings** (open, then the edits, then save as a new file, then close):
| PSD | Size | Photoshop start | Open | Edits | Save | Whole run |
|---|---|---|---|---|---|---|
| NYL Blue Prosperity | 2.0 GB | 6 s (was closed) | 11–13 s | 0.5–0.8 s (3 edits + measuring) | 5–8 s | 18–24 s |
| Spooky Link | 563 MB | — (already running) | 10–14 s | 0.4–0.9 s (2–4 edits) | 5 s | 17–21 s |

- Opening the file dominates. Edits cost about 0.1–0.25 s each, plus about 0.3 s for each full-height measurement.
- If the artist already has the PSD open, the open step disappears; the script finds the open document.

**Text edits through Action Manager keep the design:**
- Every style run was carried, on all test layers:
  - the paytable column with gold counts and white separators;
  - the heading with a smaller ™, on a scaled and slightly rotated layer;
  - a 28-run rule paragraph with icon gaps;
  - a 7-run paragraph mixing Myriad 30 and Arial 35.
- Changing a layer by its layer ID works; selecting it first isn't needed, so no groups open.
- Re-applying a layer unchanged (control) moved nothing.
- No warning triangles (`textWarningLevel` 0).
- Every layer not edited was identical in what was compared: name, kind, bounds, visibility, effects, opacity, text, style runs and transform. That was 415 of 418 layers in NYL, and 659–660 of 662 in Spooky.

**Confirmed problems, each with a fix:**
1. **Setting text the plain DOM way (`textItem.contents`) loses the style runs:** 3 runs became 1, and the small ™ size was gone. The executor must use Action Manager only. In the one run where this test was done on a copy of the heading, the original heading also came out hidden. Without that test, nothing changed visibility.
2. **Photoshop's "Use Smart Quotes" preference** (on by default) turns every ' in an edited layer into ’, not only the ones in the edit. Fix, checked: switch it off for the run and put it back afterwards.
3. **A font that isn't installed:** re-setting text replaces it with Myriad Pro (Spooky heading, Khepri). Fix, checked: before editing, every run's font is checked with `app.fonts`; the layer is skipped and reported ("font not installed: KhepriRegular").
4. **Paragraph text past its box is clipped,** so the layer's bounds stop at the box and overflow can't be seen there. Fix, checked: stretch the box for a moment, read the ink bounds of all the text, then put the box back exactly as it was. Measured: 1,376 against a box of 818, so it overflows; the paragraph that fits reads as fitting. It takes about 0.3 s.
5. **Photoshop renames auto-named text layers to follow their new text.** Harmless, because the binding keys on layer ID; but layer names must never be used as keys.

**Result:** the Photoshop route is viable and is the recommended main route for artist PSDs. Its cost is about 10–14 s to open a big PSD that isn't already open, plus about 5 s to save.

## Phase 1 status (2026-10-23)

- **`content_model.py`:** reads an AGR with no PSD involved:
  - `Sheet`, `read_workbook` (with the Excel frame filter), `Index`, `Stream`;
  - `norm`, `cell_text`, `sym_key`, `tokens_in`;
  - `page_kind`, which `engine_api._sheet_type` now uses.
- **`content_diff.py`:** compares two AGRs:
  - `RowMap`, `WordMap`, `sheet_likeness`, `sheet_renames`, moved unchanged (checked line for line);
  - new `compare(sheets_a, sheets_b)`, which returns typed changes, each with a category:

    | Type | Category |
    |---|---|
    | `cell_changed` (`what`: value / text) | content |
    | `symbols_changed` (added / removed tokens) | content |
    | `sheet_renamed` | content |
    | `row_added`, `row_removed`, `row_moved` | structural |
    | `sheet_added`, `sheet_removed`, `sheet_order` | structural |

    It also returns counts and one summary line per sheet.
  - Takes about 0.2 s on the Blue Prosperity AGRs.
  - NYL → HHR finds:
    - the 5 paytable values;
    - the purple scatter removed (a symbol change only, not a text change);
    - 2 new sheets, 1 removed sheet.
- **`market_clone`** imports these instead of having its own copies; every old name still works.
  - `check()` and the clone report carry `content_changes`.
  - The clone dialog shows "What the new Excel changes" on the links review and on the approval screen.
- **Tests:**
  - `tests/test_content_diff.py`: 9 new tests;
  - all 24 clone tests pass unchanged.

## Phase 2 status (2026-10-23)

- **`binding.py` holds the binding format.** It has:
  - pages (group layer ID → sheet);
  - text elements (layer ID → content refs: cells, rows, words or paragraphs);
  - symbol elements (layer ID → token);
  - owner per element: `data` or `review`, and everything unbound is static;
  - a fingerprint per layer: kind, text hash, box, parent group, name.
  - **API:** `make` (from a clone plan; side "a" points into the PSD's own AGR, side "b" into the new AGR), `validate`, `summary`, `save` / `load` / `find`, `embed` / `read_embedded`.
- **Where bindings are stored:**
  - **On this PC:** one JSON file per PSD in `bindings/<game>/` beside the games registry, keyed by file name.
  - **Inside the PSD:** a PSD the tool writes carries its binding in its own XMP memory.
  - **The artist's original:** never written.
  - `psd_memory.has_project()` tells a memory holding only a binding from a real project.
- **Clone integration:**
  - each clone keeps two bindings: the artist PSD's own (AGR A) and the new PSD's (AGR B);
  - `check()` reports whether the PSD is already mapped and whether that still fits the file;
  - a layer whose new text wasn't applied (a page the artist kept, a change left to the artist) is marked `review` on the new side.
- **Layer IDs:**
  - Files written by PhotoshopAPI had no layer IDs (all -1). That was the cause of the earlier "layer ids can repeat".
  - `psd_pages.ensure_layer_ids()` now gives them in creator builds (finalize) and in clone outputs.
  - The creator's memory now records each text layer's `id` and each page's `group_id`; PhotoshopAPI layer names end in NUL, which is stripped when matching.
  - For a file still without IDs, the binding falls back to the layer's place.
  - The untouched-pages check ignores an ID added to a layer that had none.
- **On the real BZZF PSD:**
  - 29 pages, 244 bound text layers, 192 symbol layers, 7 to review, 62 kept as design;
  - both bindings validate with no issues (0.3 s / 1.1 s);
  - the embedded copy equals the stored one.
- **Tests:** `tests/test_binding.py`, 6 tests: round trip; renamed / moved / re-texted / deleted layers; a kept page goes to `review`; the store; creator layer IDs.
  - A test fixture now keeps the games / links / bindings store in a temporary folder for every test.

## Phase 3 status (2026-10-24)

- **`psd_apply/`** holds the op vocabulary. Ops are JSON-ready dicts; layers are named by layer ID, with the place as a fallback.

  | Op | What it does |
  |---|---|
  | `set_text` | change a text layer's text |
  | `remove_symbols` | hide removed symbols and close the row up |
  | `add_row` | add a copy of the template row with the new text, after a given row |
  | `continue_if_over` | move the rows past the page's limit onto a Continued page |
  | `edit_text` | put in the artist's wording from the preview |
  | `label` | colour a page group in the Layers panel |

  - Ops that depend on measuring (where a copied row lands, whether a page overflows) leave the measuring to the executor, as the Photoshop executor will need.
  - `psd_apply/records.py` is the **record executor**: today's record surgery, moved behind the ops.
- **`market_clone` now decides and writes ops in three stages:**
  1. `text_ops`;
  2. `row_ops`, planned on the edited text as before;
  3. preview edits and labels.

  `apply()`, `place_new_rows()`, `apply_edits()` and `color_pages()` keep their names and hand their ops to the executor. Every op of a run is kept in `the_plan["_ops"]`.
- **A known bug fixed:** a Continued page found its page by index, which would shift if two pages overflowed in one run; it now uses the group's layer ID.
- **Proof:** HEAD's `market_clone` and the new one cloned the same inputs with the binding timestamp frozen. The output PSDs are byte-identical and the reports match:
  - the tool-made stand-in with an added row and a preview edit;
  - BZZF text and value changes;
  - BZZF new / removed / renamed sheets with one page kept;
  - BZZF six added rows overflowing onto a Continued page.

  A copied smart object always gets a fresh random instance ID (as when Photoshop duplicates), so that ID was fixed to the same sequence for both runs. Without that, the two cases that copy smart objects differ only there, and HEAD run twice differs the same way.
- **Tests:** `tests/test_psd_apply.py`.

## Phase 4 status (2026-10-24)

- **`psd_apply/photoshop.py` is the Photoshop executor.** It is one ExtendScript / Action Manager interpreter run through `photoshop_bridge`, so nothing needs installing and any Photoshop version works.
  - **Opening and saving:** Photoshop opens the artist's PSD, or uses it if it's already open; in that case the document is put back to its earlier history state afterwards. It makes the changes and saves a copy to the new path. The original is never written.
  - **Each run:** smart quotes and dialogs are switched off, and put back at the end.
  - **Ops it makes:**
    - **`copy_page`:** Photoshop's duplicate, placed like the record copy and hidden or shown like its page. The plan's IDs for copied layers are translated to Photoshop's own.
    - **`delete_pages`:** the pages go into a hidden, red "[Deleted From Excel]" group. Photoshop won't move a group straight into a group, so each goes above the holder's top layer, using a stand-in layer while the holder is empty.
    - **`set_text`:** one op per layer, carrying its final text and, for every character, the original character whose style it takes (the same map the record engine uses). Before changing the text it checks the text is what the plan expects and the fonts are installed. Box text is measured in full, so overflow is reported exactly.
    - **`remove_symbols`** and **`label`**.
  - **Not made in Photoshop yet:** `add_row` and `continue_if_over`. Those rows are reported for the artist to add.
- **`clone(engine="photoshop")`** plans in memory as before, then has Photoshop make the PSD. The record engine makes it instead, with the reason in `engine_note`, when:
  - the file has no layer IDs (Photoshop would number its layers differently);
  - Photoshop doesn't answer within 20 s ("close any dialog in it"), or it isn't installed;
  - the run is a test.

  Untouched pages are compared layer by layer (`untouched_layers`), since a file Photoshop saved is never byte-identical. The new PSD's binding follows Photoshop's IDs, with fingerprints re-read from the saved file (`binding.follow`); embedding it in that file's XMP is still to do.
- **Dialog:** the "Let Photoshop finish" checkbox is now "Make the new PSD in Photoshop (exact text layout)". The result says it was made in Photoshop and how long it took, or why it wasn't.
- **NYL Blue Prosperity, NYL → HHR** (2 GB PSD, Photoshop 2026). Both engines were run on the same plan and compared:
  - Photoshop made 34 changes:
    - two new pages, hidden like their originals;
    - "Game Rules denom 5&6" moved into the hidden red group;
    - 14 text layers;
    - the purple scatter hidden;
    - 16 labels.
  - All 14 edited text layers have the same text and the same font, size and colour per character as the record engine's result.
  - 7 untouched pages are identical layer by layer, page labels match, and the new binding validates against Photoshop's file.
  - **Timings:** Photoshop open 9 s, changes 8.6 s, save 5 s (24 s in Photoshop); 44 s for the whole clone. The record engine took 24 s on this file.
  - Left for the artist: 4 added rows and their Continued page (Phase 5). 9 look-alike pay cards stay "can't tell which" until their symbols are named (that's the matching, not the engine).

## Decisions needed from you
1. **Photoshop applies the edits** (the tool plans, Photoshop executes on the open or opened PSD). OK as the main route for artist PSDs?
2. **Pilot:** NYL Blue Prosperity first, then Spooky?
3. **Where game files live:** keep them on each PC (today) or move the game store to a shared or depot folder, so a mapping done once is available to every artist?
