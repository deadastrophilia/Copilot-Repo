# Editable-PSD round trip: design and feasibility report

Date: 2026-10-26.

**Sources:**
- A read-only audit of the repository.
- A proof of concept (PoC) run on real artist PSDs.

**How claims are marked:**
- **VERIFIED**: tested this time.
- **(memory)**: taken from earlier project notes and not re-run.
- **UNVERIFIED**: not tested.

Photoshop was not opened in these tests, so no result here proves that Photoshop accepts an output file. That check is milestone M0 in section 8.

---

## 1. Current-state audit

The repository already contains most of the pieces. The gap is how they are wired together, not missing technology.

| Area | Module(s) | State |
|---|---|---|
| Excel → content | `excel_utils`, `excel_frame`, `content_model` (pages, rows, tokens), `content_diff` (typed changes, renames), `workbook_cache` | Mature |
| Page routing / layout | `dynamic_pages/router.py`, `page_layout`, `page_boxes`, `layout_engine` | Mature |
| PSD generation (headless) | `psd_writer/build.py`, `png_builder.py`, `psd_writer/document.py`, `recorder.py`, `finalize.py`, `txt2.py`, `shapes.py`, `effects.py` | Mature. Native text, live shapes and native effects. |
| Tables | `table_renderer.py`, `table_designs.py`, `table_studio.js` | Mature |
| Paytable | `dynamic_pages/paytable/*`, `paytable_box.py`, `ps_actions.py`, `paytable_canvas.js` / `paytable_live.js` | Mature |
| Game Rules / Bingo | `png_builder` (Game Rules), `game_rules_studio.js`, `bingo_rules_studio.js` | Mature |
| UI / canvas | `ui_web/server.py`, `engine_api.py`, `typo-preview.js`, `visualiser_live.js` | Mature |
| Layer-style engine (no Photoshop) | `fx_descriptor.py` (decodes lfx2), `ps_fx_png.py` and `ps_fx_canvas.js` (same results in Python and JS), `artist_design/fx_preview.py` | Works. All 9 effect types decode. |
| Reading artist PSDs | `artist_design/psd_reader.py` (lazy open, fast EngineData), `psd_render.py` (per-page composite, patched stroke and gradient) | Works |
| **In-place update of artist PSDs** | `psd_apply/splice.py` (`remember`, `mark`, `mark_document`, `write`), `market_clone.py` (plan, apply, save), `psd_apply/records.py` | **Works. VERIFIED in this PoC (section 3).** |
| Layer identity | `binding.py` (layer ID + fingerprint), `psd_memory.py` (XMP `pshelp:`, keyed by layer **name**), `psd_pages.ensure_layer_ids` | Split: two systems; the XMP one is name-keyed |
| Optional Photoshop | `psd_apply/photoshop.py`, `photoshop_bridge.py` (JSX, any running version) | Opt-in only. Not core. |

**Gaps against the goal:**
1. **The biggest gap.** A PSD the tool made, then edited by an artist, is updated by `run_build(update_mode)`, which rebuilds the whole file (`*_rebuilt.psd`). That loses the artist's edits. The in-place updater (`market_clone` + `splice`) only runs on the clone and artist-PSD route.
2. Identity is split. `psd_memory` (XMP) links layers by name, while `binding` uses layer IDs (lyid) and fingerprints.
3. After an update, the canvas preview shows the stale embedded composite until the next Photoshop save.
4. Updates that change structure (new or removed table rows, a paytable switching layout, new pages) are only partly supported on artist PSDs. `add_row` and `continue_if_over` are partial.
5. No automated "does Photoshop open it" gate.
6. `requirements.txt` is a full environment freeze, and its Pillow version doesn't match `pyproject`.

## 2. What is achievable without Photoshop COM

| Need | Without Photoshop? | Notes |
|---|---|---|
| Read every layer, text, effect, mask, smart object, blend mode, PSB | **Yes, VERIFIED** | psd-tools 1.18 on 4 real files, up to 1487 layers, 436 MB and PSB. |
| Change one text layer's content and keep its style, position, effects and everything else | **Yes, VERIFIED** | Splice writer: all other records, channels, effect bytes, masks, smart objects and the composite are copied byte for byte. |
| A valid editable PSD that Photoshop accepts | **Very likely; must be gated** | (memory) Splice output opened in Photoshop on 3 games. Not re-checked here. |
| Text pixels exactly as Photoshop draws them right after an update | **No** | Only Photoshop's text engine lays text out exactly. We write our own close render; Photoshop re-lays out the edited layer on open, which can show the "needs a layout change" warning. |
| The merged composite after an update | **Approximate** | The saved composite goes stale. Re-render it ourselves (FX engine plus per-layer pixels), and mark that preview as ours, not Photoshop's. |
| Re-render smart-object contents, adjustment layers or exotic blend modes exactly | **Not reliably** | Keep these untouched. Show the saved composite for those regions. |
| See unsaved changes still open in Photoshop | **No** | Only the saved file can be read. |

## 3. Library capability matrix (PoC, 2026-10-26)

**Test files:**
- Headers PSD: 0.9 MB, 11 headings, each with all 9 effect types.
- Buffalo_Help: 182 MB, 300 layers, 61 smart objects.
- Hunt Help.psb: 378 MB, a PSB.
- Midnight Helpscreen: 436 MB, 1487 layers, 83 pixel masks, 192 vector masks, 84 clipped layers, 641 smart objects, 9 adjustment layers, 13 blend modes.

**Key:** V = verified, F = failed, U = unverified.

| Feature | psd-tools read | psd-tools save (unchanged) | **Our splice writer** (text edited) | ag-psd 33 read | ag-psd write |
|---|---|---|---|---|---|
| Layer tree / groups / order / IDs | V | V (md5-identical) | V | V | V (counts) |
| Text and EngineData (runs, font, size, colour) | V | n/a | **V** (runs kept, Txt2 synced) | V | text V; Photoshop must re-lay it out |
| Effects (all 9 types) | V | V | **V (bytes identical, including on the edited layer)** | V | **F** (descriptors rewritten, defaults added) |
| Gradient stops | V | V | V | V | rewritten |
| Pixel / vector masks | V | V | V | U | U |
| Clipping | V | V | V | U | U |
| Adjustment / fill layers | V | V | V (raw copy) | U | U |
| Smart objects | V | V | V (raw copy) | V | V (count only) |
| Blend modes | V | V | V | U | U |
| Visibility / opacity / position | V | V | V | U | U |
| Embedded composite | V (0.02–0.16 s) | V | V (copied, so stale) | V | U |
| Re-rendered composite | **F** (needs scipy; limited effects) | | | | |
| Unchanged round trip | V | **V md5** | V | V | **F** (−90 KB on 0.9 MB, −0.7 MB on 182 MB) |
| PSB | V | V | V | U | U |

**Verdict:**
- **Read:** psd-tools.
- **Write:** our splice writer.
- **ag-psd:** must not write artist files, because it rewrites effect descriptors and loses data even when nothing changed. It is acceptable only as a fast read-only parser in the browser, and that isn't needed now.
- **Rust:** cargo is not installed. No library investigated offers safe round-trip writing. Only consider a narrow Rust parser if benchmark M7 shows parsing is the bottleneck.

## 4. Recommended architecture

```
              ┌────────────── Excel (read-only) ──────────────┐
              │ content_model + content_diff  →  typed changes │
              └───────────────────────┬────────────────────────┘
 PSD on disk ──► Importer ──► PsdState ──► Binder ──► Reconciler ──► Patch plan ──► Splice writer ──► PSD
   (watcher)    (psd_reader)  (index,     (lyid +     (ownership      (ops)          (psd_apply)       │
                              composite)  fingerprint)  rules)                                         │
                       │                                                                               │
                       └──► Canvas: saved composite + per-layer overlays + our FX for edited layers ◄──┘
```

**1. Importer** (extends `artist_design/psd_reader` and `psd_render`). It produces `PsdState`:
- the document size and colour mode;
- a layer index: lyid, path, kind, box, visibility, opacity, blend, clipping, mask flags, text (string, runs, font, size), and a hash of the raw effects bytes;
- the embedded composite;
- a file fingerprint: size, mtime, and a hash of the header plus the layer-section length.

**2. Binder** (merge `binding.py` and `psd_memory.py` into one source of truth):
- **Primary key:** the layer ID (lyid), which Photoshop keeps across rename, reorder and save. Duplicating a layer gives the copy a new ID.
- **Secondary:** a fingerprint (text hash, kind, group path, bounds) to re-find a layer after copy-paste between documents, or in a PSD that has no IDs.
- **Bindings live in two places:** the PSD's XMP (`pshelp:` resource, which survives Photoshop saves (memory)), keyed by lyid; and a sidecar `bindings/<game>/<psd>.json` as a backup.
- **Artist PSDs with no tool metadata:** run the existing matching (`market_clone` plans and `content_diff` against the Excel text: exact match, fuzzy match, token maps). The user confirms the low-confidence matches, then the bindings are written.

**3. Reconciler** (new, small). It turns typed Excel changes plus `PsdState` plus bindings into a patch plan, using the ownership rules in section 5.

**4. Splice writer** (existing `psd_apply`). Only patched records and the Txt2 block are serialized; everything else is copied raw. Never use psd-tools `_update_record()` on artist files (memory).

**5. Canvas** (hybrid):
- The base layer is the saved composite: exactly what Photoshop drew last.
- Overlays: per-layer boxes for selecting, moving and identifying.
- For layers we changed, our own render (`ps_text` + FX engine) is drawn over the composite, with that area cut out of the base.
- Unsupported regions (smart objects, adjustments) always come from the composite, and are labelled "preview from last Photoshop save".

**6. File watcher:**
- Poll the fingerprint every 1–2 s, or use OS change notifications.
- A save is complete only once size and mtime have held steady for 2 polls and the file opens without a sharing violation. Photoshop writes to a temp file and renames, so also watch for renames.
- On a change: re-import in the background, then diff the new `PsdState` against the old one per layer ID.
- If the user has unsaved edits in the tool, show a conflict prompt: "the PSD changed in Photoshop: keep mine / take Photoshop's / merge non-overlapping".
- Never read from Photoshop's memory.

## 5. Ownership model and data schema

| Property | Owner | When Excel changes |
|---|---|---|
| Text characters, symbol tokens, table cell values, paytable numbers, row count | **Excel** | Updated |
| Run styles for the new text (font, size, colour, tracking) | **Artist** (taken from the existing runs) | Kept; mapped onto the new text |
| Layer effects, blend, opacity, visibility, mask, clipping | **Artist** | Never touched |
| Position and box | **Artist** once moved; otherwise **Generator** | Kept; overflow is reported |
| Layer order, new decorative layers | **Artist** | Never touched |
| Group or page structure (new page, new table row) | **Generator** | Needs a decision when the artist has edited that group |
| Smart-object contents, adjustment settings | Out of scope for writing | Copied raw |

A property counts as artist-owned once its value differs from what the tool last wrote. The tool's last-written values are stored per layer ID in the binding record, as `last_written`.

```json
{
  "psd_fingerprint": {"size": 191234567, "mtime": 1793000000, "head_hash": "ab12…"},
  "layers": {
    "lyid:4211": {
      "element": "page:GAME_RULES/heading",
      "kind": "heading",
      "excel": {"sheet": "GAME RULES", "cell": "B2", "value_hash": "9f…"},
      "fingerprint": {"text_hash": "c3…", "path": "GAME RULES/Heading", "bounds": [120, 80, 900, 160]},
      "last_written": {"text": "GAME RULES", "bounds": [120, 80, 900, 160], "fx_hash": "e0…", "font": "Kugile", "size": 80},
      "overrides": ["bounds", "fx"],
      "native": {"fx_hash": "7d…", "kept_raw": true}
    }
  },
  "deleted_by_artist": ["page:GAME_RULES/footer"],
  "artist_layers": ["lyid:5120"]
}
```

## 6. Round-trip algorithm

```
import(psd):
  state = Importer.read(psd)                          # lazy index plus the composite
  binds = Binder.load(psd) or Binder.match(state, excel, ask_user_for_low_confidence)
  for each binding b:
      L = state.by_id.get(b.lyid) or state.find(b.fingerprint)   # survives renames
      if L is None:                    b.status = "deleted_by_artist"
      elif L.kind != b.kind:           b.status = "kind_changed"     # needs a user decision
      else:                            b.overrides = diff(L, b.last_written)
  for each layer L in state with no binding:   mark it as artist-made (never touched)
  canvas.show(state.composite, overlays(binds))

update(excel_changes):
  if Importer.fingerprint(psd) != state.fingerprint: re-import, then reconcile again   # changed outside the tool
  plan = []
  for each change c in content_diff(old_excel, new_excel):
      b = binds.for_element(c.element)
      if b is None or b.status == "deleted_by_artist": report(c, "skipped: layer removed by artist"); continue
      if b.status == "kind_changed":                   ask(c); continue
      if c.type == "text":   plan.add(SetText(b.lyid, c.new, keep_runs=True))
      if c.type == "symbol": plan.add(SetSymbols(b.lyid, c.tokens))           # existing ops
      if c.type in ("row_added", "row_removed", "layout_changed"):
            if group_untouched(b.group): plan.add(RegenerateGroup(b.group))   # swap in a newly generated group
            else:                        ask(c)                               # artist edited that group
      if c.type == "page_added":   plan.add(AppendPage(c.page))               # new group from the generator
      if c.type == "page_removed": ask(c)                                     # never delete artist work silently
  for each duplicate binding (one lyid matched twice): keep the original lyid; the copy is artist-made
  check every planned op: does the new text fit its box? Report overflow; never move artist-placed layers silently.
  apply(plan) on the in-memory records → splice.write(out_tmp) → verify(out_tmp) → atomic rename
  verify: re-open; same layer count and IDs; raw effects hashes equal except where planned; the planned text present
  binds.last_written ← new values; write XMP and sidecar
```

## 7. Native writing strategy

| Option | Speed | Effects kept | Text editable | Corruption risk | Verdict |
|---|---|---|---|---|---|
| Patch / splice existing records (**ours**) | 0.03–1.1 s write (V) | 100% byte-identical (V) | Yes (Txt2 synced) | Low (one record rewritten) | **Use this** |
| Rebuild the PSD from parsed layers | slow | loses unknown blocks | yes | high | No |
| ag-psd write | fast | **F**: descriptors rewritten | yes | medium to high | No |
| Hybrid: splice plus newly generated groups (new pages, rows) | fast | yes | yes | low | **Use for structural changes** |
| Photoshop UXP / JSX (optional) | 10–45 s (memory) | yes | exact layout | low | Optional "finish in Photoshop" for exact pixels |

**When we can read an effect but not write it:** never re-serialize it. Effects stay raw bytes, because we only ever replace text, pixels and Txt2 entries. If a requested edit would need to change an effect (for example the user restyles a heading in the tool), write the full descriptor only for effect types covered by `effects.py` templates. Anything else is refused with a "change this in Photoshop" message.

## 8. Performance (measured, 2026-10-26)

| File | Open | Build index | One text edit | Write |
|---|---|---|---|---|
| 0.9 MB | 0.12 s | 0.11 s | 0.69 s | 0.03 s |
| 182 MB | 1.34 s | 1.73 s | 0.78 s | 0.42 s |
| 378 MB PSB | 3.5 s | 3.37 s | 0.65 s | 0.65 s |
| 436 MB, 1487 layers | 31.2 s | 37.3 s (a second full parse) | 0.61 s | 1.07 s |

**Bottleneck:** opening very large files and building the index; the index step parses the whole file a second time.

**Optimizations, in order:**
1. Build the splice index during the same parse as the open (removes the second parse).
2. Cache `PsdState` on disk, keyed by the file fingerprint, so a reopen with no changes takes about 0 s.
3. Use the lazy layer index (`open_lazy`) for the UI and parse channels only for layers being edited.
4. Re-import in the background when the file watcher fires.
5. Keep preview rendering separate from PSD writing.
6. Consider Rust only if, after steps 1–2, parsing still exceeds about 5 s on the 436 MB file.

**Targets:**
- Reopening an unchanged file: under 1 s on any size.
- Updating one heading: under 2 s for files up to 400 MB.
- Full re-import of the 436 MB file: under 15 s.

**Benchmark:** `tools/bench_roundtrip.py` (to be written) runs over the 4 files above and logs open, index, edit and write timings to `bench.json`, with 3 runs each, reporting the median.

## 9. Roadmap: small, testable milestones, highest risk first

| # | Milestone | Proves |
|---|---|---|
| M0 | **Photoshop acceptance gate:** run the PoC outputs (all 4 files, styled heading edited) through Photoshop by hand: opens, layer editable, effects intact, warning shown or not. | The core assumption |
| M1 | One identity store: binding by layer ID in XMP plus a sidecar; migrate `psd_memory` name links into it. | Survives renames, duplicates and deletes |
| M2 | Route **tool-made PSDs** through `market_clone` + `splice` in update mode instead of `_rebuilt` (feature flag). | Closes gap 1 |
| M3 | Reconciler with ownership rules: text, symbols, report-only for everything else. | Artist edits survive |
| M4 | Canvas: saved composite plus overlays plus our render for edited layers; a "from last Photoshop save" badge. | Accurate preview |
| M5 | File watcher plus conflict prompt. | External saves |
| M6 | Structural changes: table rows, paytable layout and new pages via regenerated groups spliced in; ask when the artist edited the group. | Hard cases |
| M7 | Performance: single-parse index, `PsdState` cache, benchmark script. | Speed targets |

## 10. Proof of concept (already run) and what remains

Done (VERIFIED): `poc.py` opens each file, edits one heading's text through the splice writer, writes, reopens, and compares every layer's name, ID, kind, box, effects hash, masks and channel data. Only the edited layer and the Txt2 block changed.

Files: `C:\Users\gsdah\AppData\Local\Temp\claude\E--Work-ClaudeCode-PsHelpScreenTool-ClaudeCodeLatest\e2db71af-a6c3-43e7-a8e4-cc7198ba51f0\scratchpad\poc.py`. The outputs are in the `out_*` folders next to it, about 1.9 GB; delete them when done.

**M0 results so far (checked by the user in Photoshop, 2026-10-26):**

- `out_small\spliced.psd` (headings file; edited layer "BINGO RULES", id 692, hidden in the file):
  - Opens with no warning.
  - The new text is there and the layer is still editable.
  - The effects are kept and the font stays MyriadPro-Bold.
  - **Issue:** until Photoshop re-lays out the text, it shows our preview pixels. Those were drawn in a thin fallback font because Myriad Pro lives in Adobe's font folder, which Python doesn't search. Clicking into the text fixes it.
  - **Chosen fix:** flag edited text layers so Photoshop shows "Some text layers might need to be updated…" on open; one click on **Update** redraws them with Photoshop's exact layout. Seen working on a file written by ag-psd. Users won't install fonts, so this is preferred over finding fonts on disk.
- `ag_big.psd` (ag-psd output): opens with that update prompt and shows the new text. Its effect descriptors are still rewritten (section 3), so ag-psd is still rejected as a writer.
- `out_mid\spliced.psd` (Midnight; edited layer "GAME RULES copy", id 16745, in group MR_BIG › Game Rules - 2, both hidden): same result as the headings file. It opens, the new text is there, the layer is editable and its styles are kept. The font only looks right once you click into the text.

**M0 verdict:** the splice writer is accepted by Photoshop on a small file and on the 436 MB file. The only defect is the stale text preview until Photoshop redraws it, and the redraw prompt fixes that.

**Remaining (M0, needs Photoshop):** open `out_small\spliced.psd` (the styled headings) and `out_mid\spliced.psd` in Photoshop, then check:
- the heading is still an editable text layer;
- its gradient, stroke, bevel and shadows are unchanged;
- whether a "layout change" warning appears;
- no "not compatible" error.

Then save in Photoshop, reopen it in the tool, and diff again.

## 11. Implementation plan (files)

| File | Change | Tests |
|---|---|---|
| `ps_autotypesetter/psd_roundtrip/state.py` (new) | `PsdState` importer: index, composite, fingerprint, cache | parse 4 reference files; fingerprint stable across an unchanged save |
| `ps_autotypesetter/binding.py` | becomes the single identity store (lyid + fingerprint, `last_written`, overrides, XMP + sidecar) | rename, duplicate, delete, kind-change cases |
| `ps_autotypesetter/psd_memory.py` | name links migrated to binding; remains the config / Excel snapshot | migration test |
| `ps_autotypesetter/psd_roundtrip/reconcile.py` (new) | ownership rules → patch plan (reuses `content_diff`, `psd_apply` ops) | the section-6 cases, as table-driven tests |
| `ps_autotypesetter/psd_apply/splice.py` | build the index from the first parse; write to a temp file, verify, then rename atomically | byte-identical copy test on 4 files |
| `ps_autotypesetter/ui_web/engine_api.py` (`run_build` update mode) | flag `update_in_place`: call the reconciler + splice instead of `_rebuilt` | integration: generate, edit the fx bytes, change the Excel, update; the fx bytes stay |
| `ps_autotypesetter/ui_web/server.py` + `static/typo-preview.js` | file-watch endpoint, conflict prompt, composite-backed canvas with overlays | API tests; manual UI check |
| `tools/bench_roundtrip.py` (new) | benchmark | n/a |

**Don't do:** a rewrite of `png_builder`, the table or paytable renderers, a Photoshop clone, ag-psd writing, or COM in the core path.
