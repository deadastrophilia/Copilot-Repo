# Next work: smooth Canvas editing (Option A, 2 weeks)

Context file for the next session. Read this first; it says what to build, where the code is,
what was measured, the rules of this project and the traps already found.

Big picture and the longer plan: `docs/SYSTEM_DESIGN_60FPS_ONE_RENDERER.txt`.
Decision (user, 2026-10-28): **Option A** — make the current web Canvas feel smooth in about
2 weeks. No Qt / desktop rewrite now; re-decide after this work and the "prep" steps.

---

## 1. Goal and what "done" means

The user's complaint: "the tool is wonky, not as smooth as Photoshop; drag changes appear only
when I let go of the handle".

Done when, on the 2160 x 3840 test pages (BBB, BBB(2), Paytable, GAME RULES, Bingo Rules):

1. **Every drag shows the real result while dragging**, not an outline:
   - moves that do not change text wrapping (top margin, gaps, a row / card / box / text box
     being moved) move the drawn page content every frame;
   - drags that change wrapping (side margins / inner width, paragraph frame width, letter
     spacing, line height, card width) show the re-laid-out page while dragging, at least
     5-10 times a second, always the latest value.
2. **Frames during a pure move cost ≤ 16 ms** (measure, see section 6).
3. **No wait after release for our own edit**: what was shown at release stays on screen; the
   save goes to the server in the background; the server result replaces it quietly only if it
   differs.
4. **No flash, no zoom jump, no lost popups** (already fixed — must stay fixed, see section 7).
5. Paytable, Game Rules and Bingo Rules behave exactly as before (must-not-break).

Week 1 = items 1 and 3. Week 2 = item 2 (per-element bitmap cache + one overlay canvas) and
polish.

---

## 2. Project rules (must follow)

- **Test only on the isolated server**: launch config `web-isolated` (port 8764,
  `tools/run_isolated_server.py`). It copies the user's session to
  `%TEMP%\psh_isolated_session.json` with `active_game` removed. **Never** set `active_game`
  in a test (it writes the user's real game file). Never edit the user's real config
  (`~/PsHelpScreenTool_Web_Session.json`) — read-only is fine.
  Restarting the isolated server re-copies the user's session (fresh test data).
  Python changes need a server restart; JS / CSS changes need a page reload.
- **Script cache stamps are manual**: every changed `static/*.js` or `styles.css` needs its
  `?v=` bumped in `static/index.html` (e.g. `?v=20261029a`), or the browser keeps old code.
- **Commits**: only the files you changed. Leave out `requirements.txt` and
  `.claude/launch.json` (both carry unrelated local changes). Another session may edit
  `index.html` at the same time — stage only your own stamp lines if so (build the staged
  version with `git show HEAD:<file>` + your sed, `git hash-object -w`, `git update-index
  --cacheinfo`). End commit messages with
  `Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>`.
- **Subagents**: hand searches and routine work to Sonnet / Haiku; Opus only for hard parts.
- **Must not break**: Paytable (cards, rows, free cards, SCATTER / WILD, gap handle, row
  lock), Game Rules and Bingo Rules (separator, XTRAA icons, guides, per-row align).
- Write user-facing text plainly (the user is a game artist, not a programmer).
- Update memory (`memory/` folder of this project) when something non-obvious is learned.

---

## 3. How an edit flows today (the pipeline to change)

### Normal pages (Canvas route `#/typography`)

```
drag handle / guide  ──(mousemove: only the guide line or frame outline moves)──►
mouseup ──► App.set(key, value) + App.pushConfig()            app.js:555 / :581 (debounced save)
        ──► V.refreshPreview (debounced 120 ms)               typo-preview.js:1478
        ──► refreshPreview(): await App.configSettled()        typo-preview.js:1420
        ──► AppLive.renderInto(canvas, sheet)                  visualiser_live.js:4123
              ├─ POST /api/visualiser/editor-data   (settings, rows, icons, bg)
              ├─ fetchCanonicalData(): POST /api/layout/preview   visualiser_live.js:1048
              │     → server builds the canonical PageLayout for the whole sheet
              ├─ ensureFonts / preloadIcons / preloadBg
              ├─ buildPages() → buildPagesCanonical()           visualiser_live.js:559
              └─ redrawInto(canvas) → draw()                    visualiser_live.js:4187 / :2376
        ──► layout() + redrawCanvas() + guides re-made          typo-preview.js:158 / :82
```

**Key fact**: normal pages are drawn from the SERVER's canonical layout
(`L.state.canon`, `canonActive`). The browser's own layout code in `buildPages()` (after the
canonical branch) is only a fallback — it is NOT a trustworthy live layout engine any more.

Typing already has a live path: `AppLive.draftText(canvas, sheet, edits)`
(visualiser_live.js:4092) posts `/api/layout/preview` with `text_edits_draft` and redraws with
the answer, one request at a time (seq number), never saved until the editor closes. **The
same pattern is the model for live drags that change wrapping** (section 5, W1-3).

Server route: `ps_autotypesetter/ui_web/server.py:1997` `layout_preview()`:
`_load_live_settings(cfg)`, then `live_layout_adapter.layout_payload_for_sheet(dict(cfg), ...)`
inside `text_edits.draft(...)`. A `settings_draft` (unsaved settings merged into that
`dict(cfg)`) can be added there the same way.

### Paytable pages (`paytable_canvas.js`)

- `edit(fn)` (line 56) clones the template, applies `fn`, saves `dynamic_settings.paytable_card_template`,
  `redrawSoon()` (line 161) → server renders a PNG preview → `draw()`.
- Live during drags already exists for some: `liveSet(xf)` / `liveEnd()` (lines 133 / 138) with
  `boxXf()` (152) move the drawn items of a box every frame; used by `startFrameEdit` (1016),
  `overlayDrag` (1509), `gapLive` (1543). Text inside does not reflow until the PNG comes back.
- Overlays: `paintFrames()` (213) rebuilds `.ptc-frames` HTML.

### Game / Bingo Rules (`rules_canvas.js`, `ps_autotypesetter/rules_layout.py`)

- Edited like normal pages since 8a93d60 (canonical layout from the rules renderers' report).
- `rules_canvas.js` is an overlay: separator, XTRAA icons, guides — `dragGuide` (127),
  `dragHandle` (189). **Trap**: `RulesCanvas.redraw` must only repaint frames; re-rendering
  there causes an endless loop of cancelled renders (use the internal `redrawSoon`).

---

## 4. Measured (2026-10-28, isolated app, 2160 x 3840 page, sheet BBB(2))

| Step | Time |
|---|---|
| Save a setting (`App.flushConfig`) | ~155 ms |
| `POST /api/visualiser/editor-data` (27 KB) | 55-313 ms |
| `POST /api/layout/preview` canonical (88 KB, 3 pages) | 91-355 ms (BBB: 150-454 ms) |
| `AppLive.renderInto` total (one edit) | ~420 ms |

Budget for a smooth frame: 16 ms. One edit today = 25-50 frames. For live re-layout while
dragging, the server layout call must get faster — profile it with `PSH_TIMING=1`
(launch config `web-isolated-timing`, port 8766; see memory `startup-performance`), cache the
workbook / content per sheet, lay out only the page being dragged on.

---

## 5. The plan

### Week 1 — live drags, no wait after release

**W1-1. One frame loop.** A small shared helper (e.g. in `typo-preview.js`, exported on
`AppTypoVis`) that coalesces pointer moves to one update per animation frame, with pointer
capture. **Trap**: `requestAnimationFrame` does not run while the app pane is in the
background (found this session) — fall back to `setTimeout(16)` when `document.hidden`, or
the update never happens.

**W1-2. Pure moves draw the real content live.** For drags that only shift things (Header Top
Margin, Heading–Body Gap, Heading–Continued Gap, Continued–Body Gap, Bottom Margin, a heading
row's gap above / below, a text box move, paytable row / card / box moves):
- shift the affected drawn elements of `AppLive.state.elements` by the drag delta (a draw
  transform — no layout), redraw once per frame;
- the elements below a moved gap move with it; the guide line moves with them;
- on release: save once (`App.set` + `pushConfig`), **keep what is on screen**, and let the
  next server layout replace it silently (no blank, no jump).
Drag code to change (all only move a line / outline today):
- guides: `dragGuideStart / dragGuideMove / dragGuideEnd` — typo-preview.js:1379 / 1386 / 1408,
  `posForValue` 1370, `computeTypoGuides` 68, `continuedGuides` 52
- heading row gaps: `rowGapGuides` — typo-preview.js:565
- frames and handles: `dragHandle` 480, `resizeHandles` 497, `paragraphHandles` 535,
  `spacingHandles` 935 (line height / letter spacing — these reflow, see W1-3)
- text boxes: their move / resize in typo-preview.js (search `boxFrame`, `updateBox`)
- rules: `dragGuide` / `dragHandle` in rules_canvas.js
- tables: drags in `table_studio.js` (check each)

**W1-3. Drags that change wrapping show a live layout.** Side margins / Inner Canvas Width,
paragraph frame left / right, letter spacing, line height, card width:
- add `settings_draft` to `/api/layout/preview` (server.py:1997): a dict of setting paths →
  values merged into the `dict(cfg)` copy for this call only (never saved), like
  `text_edits_draft`;
- in the browser: a `draftSettings(canvas, sheet, draft)` next to `draftText`
  (visualiser_live.js:4092) — one request in flight, latest value wins, redraw with the
  answer; drawn content between answers can be scaled / shifted as a hint;
- on release: save once, keep the last drawn layout.
- speed the server call (section 4) so this reaches 5-10 updates a second on 4K pages.

**W1-4. No refetch of our own edit.** After a drag / field change the browser already shows
the result: skip `editor-data` + full `renderInto` when the server's layout equals what is
drawn; when it differs, swap it in without a blank frame (pictures are kept by url since
ee2c5ca). Keep `App.configSettled()` ordering so a later edit never sees older settings
(server `_settings_restore` already guards background builds).

**W1-5. Paytable.** Rows / cards / boxes already move live (`liveSet`); add the same "keep
what is on screen until the new PNG arrives" rule; consider a draft render for card width /
numbers changes (server `render` with an unsaved template — `edit()` currently saves first).

### Week 2 — frames under 16 ms

**W2-1. Per-element bitmap cache.** In `visualiser_live.js` `draw()` (2376) and
`wrapElement` (2006): render each element (heading, line, icon, table, rect) once into an
`OffscreenCanvas` keyed by (element id + its style + text + size); a frame only `drawImage`s
the cached bitmaps with their offsets. Layer-style text (fx sprites, `ps_fx_canvas.js`) is the
expensive part. Invalidate an element only when its own data changes.

**W2-2. One overlay canvas.** Guides, labels, selection frames and handles drawn on one canvas
above the page, in the same frame — instead of rebuilding HTML (`renderGuides` typo-preview.js:1159,
`paintFrames` in paytable_canvas.js:213 and rules_canvas.js:51). Hit-testing for handles
stays in JS (simple rectangles). Ctrl+H (450a397) must hide this layer too.

**W2-3. Measure and guard.** A dev-only FPS / frame-time readout (toggle with a key or a
setting); a scripted drag test that reports the slowest frame.

---

## 6. How to test (what worked this session)

- Drive the app in the built-in browser tab of the `web-isolated` server. Set a viewport like
  1700 x 1000 for coordinates; screen coordinates can be off while the viewport is emulated —
  dispatching synthetic `mousedown` / `mousemove` / `mouseup` / `click` / `wheel` events from
  `javascript_tool` on the real elements is reliable.
- **rAF does not fire when the pane is hidden**: use `setInterval` for probes.
- Pixel probe used to prove the white flash (adapt for frame timing):
  ```js
  const c = document.getElementById('typoVisCanvas'), ctx = c.getContext('2d');
  const px = () => { const d = ctx.getImageData(c.width*0.5|0, c.height*0.25|0, 1, 1).data; return d[0]+','+d[1]+','+d[2]; };
  const seen = []; const t = setInterval(() => seen.push(px()), 8);
  /* do the edit */ setTimeout(() => clearInterval(t), 5000);
  ```
- Useful globals: `AppTypoVis.state` (scale, tx, ty, page, sheet, geometry, guides, userView,
  clean), `AppTypoVis.refreshPreview(true)`, `AppTypoVis.showPage(n)`,
  `AppLive.state` (pages, elements, canon, data, icons, images), `AppLive.renderInto`,
  `PaytableCanvas.state`, `App.get / App.set / App.pushConfig / App.flushConfig`,
  sheet select `#typoVisSheet` (set `.value` + dispatch `change`).
- Dismiss the "Some symbols are missing" dialog: click the button whose text is "Not now".
- Python tests: `python -m pytest -q tests/...` (92 test files; card templates, text styles,
  rules layout, page boxes are the relevant ones).

---

## 7. Already fixed this session — keep them fixed

| Commit | What |
|---|---|
| 24a4295 | Paytable: row edits reach every card of the row (`editSets` / `rowSets`); unlocked row ignores old `lock_size` (`card_templates._lock_box`); numbers ◧⬓◨ on the bars over rows / free cards |
| ed13e61 | Paytable gap handle live and never swaps pays / values; ↺ Reset paytable |
| 4459b09 | Unlocked row drops its old box on first edit (`edit()`) |
| 8a93d60, 234ff77 | Game / Bingo Rules edited like normal pages (other session); Bingo rows pickable, align shown, smoother typing |
| 5264f1f | Guides reach the whole canvas (no 1080p caps) |
| 199f429 | Paragraph size: all its text that size; All pages / This page / Pick pages (`page_overrides[sheet].b_size`, rule `size_off`) |
| dc03bb5 | Zoom / pan kept through edits (`V.state.userView`; only Fit or a new canvas size re-fits) |
| ee2c5ca | No white flash: background / table pictures / icons kept by url across redraws |
| 1da08d0 | Popups never close on an outside click; every dialog / panel has a ✕ (app.js MutationObserver helper `.dlg-x`) |
| 450a397 | Ctrl+H / 👁 Preview hides all overlays (`.typo-clean` on `#typoVisHost`) |

Traps learned:
- `requestAnimationFrame` stalls in a background pane (bit the ✕ helper and the probes).
- A MutationObserver on the whole document runs on every DOM change — keep its callback cheap.
- `paytable_canvas.js` `edit(fn)` works on a clone and saves the whole template.
- Rules: `RulesCanvas.redraw` = repaint frames only.
- A running app overwrites the session JSON (memory `session-repair`).
- `rowParts(t, i)` creates `bands[i].parts` from the drawn geometry if missing.

---

## 8. After Option A

Re-decide (with the user) between staying web and moving to Qt + Skia, using the prep steps in
`docs/SYSTEM_DESIGN_60FPS_ONE_RENDERER.txt` (settings resolver, PageLayout for every page type,
Skia as the PNG painter / CanvasKit in the browser). Those are worth doing either way.
