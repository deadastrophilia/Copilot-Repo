"""
Build a standalone .exe for PsHelpScreenTool using PyInstaller.

Usage:
    python build_exe.py

Requirements:
    pip install pyinstaller
"""
import os
import sys
import subprocess

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
ENTRY_POINT = os.path.join(PROJECT_ROOT, "main.py")
OUTPUT_NAME = "PsHelpScreenTool"
ICON_PATH = ""  # Optional: set to a .ico file path if you have one

DATA_FILES = [
    ("ps_autotypesetter/presets/*.json", "ps_autotypesetter/presets"),
    ("ps_autotypesetter/style_presets/*.json", "ps_autotypesetter/style_presets"),
    ("ps_autotypesetter/dynamic_pages/templates/*.json", "ps_autotypesetter/dynamic_pages/templates"),
    ("ps_autotypesetter/dynamic_pages/paytable/card_templates/*.json", "ps_autotypesetter/dynamic_pages/paytable/card_templates"),
    ("ps_autotypesetter/psd_writer/fx_template.bin", "ps_autotypesetter/psd_writer"),
    ("ps_autotypesetter/psd_writer/fx_glow_template.bin", "ps_autotypesetter/psd_writer"),
    ("ps_autotypesetter/psd_writer/txt2_template.bin", "ps_autotypesetter/psd_writer"),
    ("ps_autotypesetter/psd_writer/shape_template.bin", "ps_autotypesetter/psd_writer"),
    ("ps_autotypesetter/loading.gif", "ps_autotypesetter"),
]

HIDDEN_IMPORTS = [
    "photoshop.api",
    "openpyxl",
    "openpyxl.cell._writer",
    "openpyxl.styles",
    "openpyxl.utils",
    "PIL",
    "PIL.Image",
    "PIL.ImageFont",
    "winreg",
    "tkinter",
    "tkinter.filedialog",
    "tkinter.messagebox",
    "tkinter.simpledialog",
    "tkinter.ttk",
]

EXCLUDES = [
    "matplotlib",
    "numpy",
    "scipy",
    "pandas",
    "PyQt5",
    "PySide2",
    "PySide6",
    "notebook",
    "jupyter",
]


def build():
    cmd = [
        sys.executable, "-m", "PyInstaller",
        "--noconfirm",
        "--clean",
        "--name", OUTPUT_NAME,
        "--onedir",
        "--console",
    ]

    if ICON_PATH:
        cmd.extend(["--icon", ICON_PATH])

    for src, dst in DATA_FILES:
        cmd.extend(["--add-data", f"{src}{os.pathsep}{dst}"])

    for mod in HIDDEN_IMPORTS:
        cmd.extend(["--hidden-import", mod])

    for mod in EXCLUDES:
        cmd.extend(["--exclude-module", mod])

    cmd.append(ENTRY_POINT)

    print("Running PyInstaller with:")
    print("  " + " ".join(cmd))
    print()
    sys.stdout.flush()

    result = subprocess.run(cmd, cwd=PROJECT_ROOT)
    if result.returncode == 0:
        print()
        print(f"Success! Executable and support files created at:")
        print(f"  {os.path.join(PROJECT_ROOT, 'dist', OUTPUT_NAME)}")
        print(f"  (zip that folder to distribute)")
    else:
        print(f"Build failed with exit code {result.returncode}")
        sys.exit(result.returncode)


if __name__ == "__main__":
    build()
