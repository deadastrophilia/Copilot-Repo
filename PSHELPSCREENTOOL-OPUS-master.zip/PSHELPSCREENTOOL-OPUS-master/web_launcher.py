"""Entry point for the packaged Web UI EXE — opens the native app window."""

import sys


def main():
    from ps_autotypesetter.ui_web.window import launch_desktop

    launch_desktop()


if __name__ == "__main__":
    main()
