"""Photoshop text layer vs the tool, for one layer style (ps_autotypesetter/fx_text_roundtrip.py).

    python tools/ps_text_roundtrip.py                       # the session's heading style, font and size
    python tools/ps_text_roundtrip.py --style "Help heading" --font "Arial|Black" --size 120 --text "FEATURES"
    python tools/ps_text_roundtrip.py --session C:/path/session.json --out C:/temp/rt

Prints, per row (plain glyphs, the whole style, each effect alone): mean |dRGB| over the ink,
% of ink pixels off by more than 32, and how much heavier (+) / lighter (-) the tool's ink is.
The renders (<name>.png = Photoshop, <name>.tool.png = the tool) and report.json are in the out folder.
Needs a running Photoshop; it only opens temporary documents and closes them unsaved.
"""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--session", default=os.path.expanduser("~/PsHelpScreenTool_Web_Session.json"))
    ap.add_argument("--style", help="library style name (default: the heading's)")
    ap.add_argument("--font", help='font request, e.g. "Arial|Black" (default: the heading font)')
    ap.add_argument("--size", type=int, help="px (default: the heading size)")
    ap.add_argument("--text", default="GAME RULES")
    ap.add_argument("--color", help="#RRGGBB (default: the heading colour)")
    ap.add_argument("--out")
    ap.add_argument("--no-per-effect", action="store_true")
    ap.add_argument("--kerning", default="metrics", choices=["metrics", "optical", "none"],
                    help="Photoshop's kerning for the test layer (artists' files: usually metrics)")
    a = ap.parse_args()

    from ps_autotypesetter import fx_text_roundtrip, global_light
    from ps_autotypesetter.ui_web import engine_api

    with open(a.session, encoding="utf-8") as fh:
        cfg = json.load(fh)                                   # read only
    ds = cfg.get("dynamic_settings") or {}
    lib = ds.get("layer_style_library") or {}
    name = a.style or (ds.get("style_assignments") or {}).get("Heading text")
    if name not in lib:
        sys.exit(f"No layer style {name!r} in the library ({', '.join(lib) or 'empty'}).")
    font = a.font or engine_api._font_request(cfg.get("h_font") or "Arial", cfg.get("h_font_style") or "")
    size = a.size or int(float(cfg.get("h_size") or 72))
    color = a.color or str(cfg.get("h_rgb") or "#FFFFFF")
    res = fx_text_roundtrip.run(lib[name], font, size, a.text, color, light=global_light.resolve(ds),
                                out_dir=a.out, per_effect=not a.no_per_effect,
                                kerning=a.kerning)
    print(f"style {name!r} - font {font} -> Photoshop {res['font']} - {size}px - light {res['light']}")
    print(f"Photoshop said: {res['photoshop'][:160]}")
    print(f"{'':<18}{'mean dRGB':>10}{'off >32':>9}{'ink d':>9}")
    for row, st in res["rows"].items():
        print(f"{row:<18}{st['mean']:>10.2f}{st['bad_pct']:>8.1f}%{st['ink_diff_pct']:>+8.1f}%")
    print(f"renders: {res['dir']}")


if __name__ == "__main__":
    main()
