"""Fidelity harness: Photoshop vs the Photoshop-free layer-style engine.

Renders a set of reference layer styles twice — in whichever Photoshop is
open (through photoshop_bridge, any version) and through ps_fx_png — on the
SAME layer pixels, and reports the per-style pixel difference:

    python tools/fx_fidelity_harness.py [--out DIR] [--only NAME ...] [--pil-only]

Reference styles:
  * bzzf_title / bzzf_wild — the BZZF paytable title layers from
    PSDRef/BZZF_blastBlueHelps.psd with their own raster and full effects
    (5 drop shadows, gradient overlay, 5 strokes, chisel bevel);
  * one style per effect (shadow, glow, satin, overlays, strokes, every bevel
    style/technique) and a gold combo (gradient overlay + strokes + bevel),
    all derived from the BZZF descriptor so Photoshop gets every key it
    expects, applied to "Style Ag" glyphs rendered once by PIL.

Writes DIR/<style>.png (Photoshop | tool | difference, on grey) and
DIR/report.json. Opening/closing only its own temporary documents, it never
touches the artist's open files. Exit code 0 even when styles differ: the
numbers are the result.

Columns: mean = mean absolute RGB difference over covered pixels (0..255),
bad% = covered pixels whose worst channel is off by more than 32.
"""
import argparse
import copy
import io
import json
import os
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

BZZF_PSD = os.path.join(ROOT, "PSDRef", "BZZF_blastBlueHelps.psd")


# --------------------------------------------------------------------------
# descriptor editing (psd-tools objects keep every key Photoshop wrote)
# --------------------------------------------------------------------------


def _is_list(value):
    from psd_tools.psd.descriptor import List

    return isinstance(value, (List, list))


def _items(value):
    if _is_list(value):
        return list(value)
    if isinstance(value, list):
        return value
    return [value]


def _set(desc, key, value):
    from psd_tools.psd.descriptor import Bool

    k = key.encode("latin-1") if isinstance(key, str) else key
    cur = desc.get(k) if hasattr(desc, "get") else None
    if isinstance(value, bool):
        desc[k] = Bool(value)
    elif isinstance(value, tuple) and len(value) == 3:
        for ck, cv in zip((b"Rd  ", b"Grn ", b"Bl  "), value):
            desc[k][ck].value = float(cv)
    elif isinstance(value, bytes):
        cur.enum = value
    elif cur is not None and hasattr(cur, "value"):
        cur.value = type(cur.value)(value) if not isinstance(cur.value, bool) else value
    else:
        desc[k] = value


def _disable_all(desc):
    from ps_autotypesetter.fx_descriptor import _EFFECT_KEYS
    from psd_tools.psd.descriptor import Bool

    for key in list(desc.keys()):
        if key.decode("latin-1") in _EFFECT_KEYS:
            for item in _items(desc[key]):
                item[b"enab"] = Bool(False)


def _effect(desc, key, index=0):
    """The effect descriptor to edit; multi lists are trimmed to that one entry."""
    value = desc[key.encode("latin-1")]
    if _is_list(value):
        keep = value[index]
        while len(value):
            value.pop()
        value.append(keep)
        return keep
    return value


def _edit(desc, key, fields, index=0):
    eff = _effect(desc, key, index)
    _set(eff, "enab", True)
    _set(eff, "present", True)
    if b"uglg" in eff:
        _set(eff, "uglg", False)
    for name, value in fields.items():
        _set(eff, name, value)
    return eff


def _hex4(desc):
    buf = io.BytesIO()
    desc.write(buf)
    return "".join("%04x" % b for b in buf.getvalue())


def _bzzf_layers():
    from psd_tools import PSDImage
    from psd_tools.constants import Tag
    from psd_tools.psd.descriptor import DescriptorBlock

    psd = PSDImage.open(BZZF_PSD)
    out = {}
    for name, match in (("bzzf_title", "BAO ZHU ZHAO FU BLAST"), ("bzzf_wild", "WILD")):
        layer = next(l for l in psd.descendants() if match in l.name and (match != "WILD" or l.name.strip() == "WILD"))
        buf = io.BytesIO()
        layer.tagged_blocks[Tag.OBJECT_BASED_EFFECTS_LAYER_INFO_V0].data.write(buf)
        payload = buf.getvalue()
        out[name] = {
            "layer": layer,
            "image": layer.topil().convert("RGBA"),
            "desc": DescriptorBlock.read(io.BytesIO(payload[4:])),
            "opacity": layer.opacity / 255.0 * 100.0,
            "fill": float(getattr(layer, "fill_opacity", 255)) / 255.0 * 100.0,
        }
    return out


# --------------------------------------------------------------------------
# reference styles
# --------------------------------------------------------------------------


def _synthetic_specs(gold, red_yellow):
    """name -> list of (effect key, fields, index)."""
    shadow = {"Md  ": b"Mltp", "Clr ": (0, 0, 0), "Opct": 75.0, "lagl": 120.0, "Dstn": 8.0, "blur": 12.0, "Ckmt": 0.0}
    bevel = {"bvlT": b"SfBL", "bvlS": b"InrB", "bvlD": b"In  ", "blur": 6.0, "srgR": 100.0, "lagl": 120.0,
             "Lald": 30.0, "Sftn": 0.0, "hglO": 75.0, "sdwO": 75.0}
    return {
        "drop_shadow": [("dropShadowMulti", shadow, 4)],
        "drop_shadow_spread": [("dropShadowMulti", dict(shadow, Ckmt=50.0, blur=10.0, Dstn=6.0), 4)],
        "outer_glow": [("OrGl", {"Opct": 80.0, "blur": 16.0, "Ckmt": 10.0, "Clr ": (255, 220, 0), "Md  ": b"Scrn"}, 0)],
        "inner_shadow": [("innerShadowMulti", dict(shadow, blur=8.0, Dstn=5.0), 0)],
        "inner_glow": [("IrGl", {"blur": 10.0, "Ckmt": 0.0, "Clr ": (255, 255, 180), "Opct": 90.0, "Md  ": b"Scrn"}, 0)],
        "satin": [("ChFX", {}, 0)],
        "color_overlay": [("solidFillMulti", {"Clr ": (230, 60, 40), "Opct": 100.0, "Md  ": b"Nrml"}, 0)],
        "gradient_overlay": [("GrFl", {"Grad": gold, "Angl": 90.0, "Type": b"Lnr "}, 0)],
        "gradient_overlay_radial": [("GrFl", {"Grad": red_yellow, "Angl": 0.0, "Type": b"Rdl "}, 0)],
        "stroke_outside": [("frameFXMulti", {"Styl": b"OutF", "Sz  ": 4.0, "Clr ": (255, 255, 255)}, 0)],
        "stroke_inside": [("frameFXMulti", {"Styl": b"InsF", "Sz  ": 4.0, "Clr ": (255, 255, 255)}, 0)],
        "stroke_center": [("frameFXMulti", {"Styl": b"CtrF", "Sz  ": 4.0, "Clr ": (255, 255, 255)}, 0)],
        "stroke_gradient": [("frameFXMulti", {"Sz  ": 5.0}, 2)],
        "bevel_inner_smooth": [("ebbl", bevel, 0)],
        "bevel_inner_chisel": [("ebbl", dict(bevel, bvlT=b"PrBL"), 0)],
        "bevel_outer_smooth": [("ebbl", dict(bevel, bvlS=b"OtrB"), 0)],
        "bevel_emboss": [("ebbl", dict(bevel, bvlS=b"Embs"), 0)],
        "bevel_pillow": [("ebbl", dict(bevel, bvlS=b"PlEb"), 0)],
        "combo_gold": [
            ("GrFl", {"Grad": gold, "Angl": 90.0, "Type": b"Lnr "}, 0),
            ("frameFXMulti", {"Styl": b"OutF", "Sz  ": 4.0}, 2),
            ("ebbl", dict(bevel, bvlT=b"PrBL", blur=4.0, srgR=126.0), 0),
        ],
    }


def build_cases(text="Style Ag", font_size=110, fill=(70, 140, 230)):
    """[(name, source RGBA image, style config)] for every reference style."""
    from PIL import ImageFont

    from ps_autotypesetter import fx_verify, png_builder

    layers = _bzzf_layers()
    cases = []
    for name, info in layers.items():
        hex4 = _hex4(info["desc"])
        cases.append((name, info["image"], {
            "captured_effects_hex": hex4,
            "captured_params": {"opacity": info["opacity"], "fill_opacity": info["fill"]},
        }))
    base = layers["bzzf_wild"]["desc"]
    strokes = _items(base[b"frameFXMulti"])
    gold = copy.deepcopy(strokes[2][b"Grad"])
    red_yellow = copy.deepcopy(strokes[1][b"Grad"])
    font = png_builder._load_font(ImageFont, "Arial", font_size, bold=True)
    glyphs = fx_verify.text_source(text, font, list(fill), 0)
    for name, edits in _synthetic_specs(gold, red_yellow).items():
        desc = copy.deepcopy(base)
        _disable_all(desc)
        for key, fields, index in edits:
            _edit(desc, key, fields, index)
        cases.append((name, glyphs, {"captured_effects_hex": _hex4(desc)}))
    return cases


# --------------------------------------------------------------------------
# run
# --------------------------------------------------------------------------


def _triptych(ps_img, tool_img, diff):
    from PIL import Image, ImageDraw

    bg = (128, 128, 128, 255)
    w, h = ps_img.size
    sheet = Image.new("RGBA", (w * 3 + 40, h + 24), (40, 40, 40, 255))
    for i, (label, img) in enumerate((("Photoshop", ps_img), ("tool (no Photoshop)", tool_img), ("difference x3", None))):
        x = i * (w + 20)
        if img is not None:
            tile = Image.new("RGBA", (w, h), bg)
            tile.alpha_composite(img.convert("RGBA"))
        else:
            tile = diff.convert("RGBA")
        sheet.paste(tile, (x, 24))
        ImageDraw.Draw(sheet).text((x + 4, 4), label, fill=(230, 230, 230, 255))
    return sheet


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--out", default=os.path.join(ROOT, "build", "fx_fidelity"))
    ap.add_argument("--only", nargs="*", help="style names to run (default: all)")
    ap.add_argument("--pil-only", action="store_true", help="render the tool side only (no Photoshop)")
    ap.add_argument("--cached", action="store_true",
                    help="compare against the Photoshop renders a previous run saved in --out (no Photoshop)")
    args = ap.parse_args(argv)

    from PIL import Image

    from ps_autotypesetter import fx_verify, photoshop_bridge, ps_fx_png

    os.makedirs(args.out, exist_ok=True)
    cases = build_cases()
    if args.only:
        cases = [c for c in cases if c[0] in set(args.only)]
    if not (args.pil_only or args.cached):
        info = photoshop_bridge.describe()
        print(f"Photoshop route: {info['route']}  running: {info['running'] or '-'}")
        try:
            print("Photoshop version:", photoshop_bridge.run_jsx("app.version", timeout=600))
        except Exception as exc:
            print(f"Photoshop is not reachable: {exc}")
            return 2
    report = []
    print(f"{'style':<26}{'mean':>8}{'bad%':>8}{'alpha':>8}{'px':>9}{'ps s':>7}{'tool s':>8}")
    for name, src, style in cases:
        N = ps_fx_png.normalize_params(style)
        pad = ps_fx_png.effect_pad(N) + 4
        padded = Image.new("RGBA", (src.width + 2 * pad, src.height + 2 * pad), (0, 0, 0, 0))
        padded.paste(src, (pad, pad))
        t0 = time.time()
        tool = fx_verify.pil_render(padded, style)
        t_tool = time.time() - t0
        row = {"style": name, "size": list(padded.size), "tool_seconds": round(t_tool, 3)}
        if args.pil_only:
            tool.save(os.path.join(args.out, f"{name}.tool.png"))
            print(f"{name:<26}{'-':>8}{'-':>8}{'-':>8}{'-':>9}{'-':>7}{t_tool:>8.2f}")
            report.append(row)
            continue
        ps_path = os.path.join(args.out, f"{name}.photoshop.png")
        try:
            t0 = time.time()
            if args.cached:
                with Image.open(ps_path) as im:
                    ps_img = im.convert("RGBA")
            else:
                op, fill = fx_verify.style_opacities(style)
                ps_img = fx_verify.photoshop_render(padded, fx_verify.descriptor_hex4(style), op, fill, timeout=600,
                                                     light=fx_verify.verify_light(style))
                ps_img.save(ps_path)
            t_ps = time.time() - t0
        except Exception as exc:
            print(f"{name:<26} Photoshop render failed: {exc}")
            row["error"] = str(exc)
            report.append(row)
            continue
        stats, diff = fx_verify.compare(ps_img, tool)
        row.update(stats)
        row["photoshop_seconds"] = round(t_ps, 2)
        _triptych(ps_img, tool, diff).save(os.path.join(args.out, f"{name}.png"))
        print(f"{name:<26}{stats['mean_abs']:>8.2f}{stats['bad_pct']:>8.2f}{stats['alpha_mean_abs']:>8.2f}"
              f"{stats['covered_px']:>9}{t_ps:>7.1f}{t_tool:>8.2f}")
        report.append(row)
    with open(os.path.join(args.out, "report.json"), "w", encoding="utf-8") as fh:
        json.dump(report, fh, indent=2)
    print(f"\nWrote {len(report)} results to {args.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
