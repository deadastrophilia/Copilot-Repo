"""Run the web app on a copy of the user's session, for testing without touching their work.

The copy has no active game / market: with one, every settings change is also written into that
game's file in the user's games folder (games.sync_from_session) — a test would change their real
game. Usage: python tools/run_isolated_server.py [port] [--timing]
"""
import json
import os
import shutil
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def main():
    port = int(next((a for a in sys.argv[1:] if a.isdigit()), "8764"))
    if "--timing" in sys.argv:
        os.environ["PSH_TIMING"] = "1"
    # its own copy per port: two test servers running at once never share (and overwrite) one session
    name = "psh_isolated_session.json" if port == 8764 else f"psh_isolated_session_{port}.json"
    session = os.path.join(tempfile.gettempdir(), name)
    src = os.path.expanduser("~/PsHelpScreenTool_Web_Session.json")
    if os.path.isfile(src):
        shutil.copyfile(src, session)
    try:
        with open(session, encoding="utf-8") as fh:
            cfg = json.load(fh)
        cfg.pop("active_game", None)
        cfg.pop("active_market", None)
        with open(session, "w", encoding="utf-8") as fh:
            json.dump(cfg, fh)
    except (OSError, ValueError):
        pass
    from ps_autotypesetter.ui_web.server import create_app

    create_app(session_file=session).run(host="127.0.0.1", port=port, debug=False, use_reloader=False, threaded=True)


if __name__ == "__main__":
    main()
