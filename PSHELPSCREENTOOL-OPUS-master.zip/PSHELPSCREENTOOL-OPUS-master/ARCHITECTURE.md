# Architecture Overview

PsHelpScreenTool_v46_20_GAME_RULES_RENDERER is an enterprise-grade automated layout, typesetting, and rendering tool designed for casino game production (Game Rules, Paytables, Denom Pages, etc.). It automates Adobe Photoshop (via COM/Photoshop API) and provides standalone PNG rendering capabilities, driven by Excel spreadsheets and JSON-configured visual templates/presets.

---

## High-Level System Architecture

```
                                  +-----------------------+
                                  |     Excel Workbooks   |
                                  +-----------+-----------+
                                              |
                                              v
+------------------+          +-------------------------------+          +---------------------------+
| Web UI (SPA)     | <------> | Flask Server (ui_web/server.py)| <------> | Engine API (ui_web/api.py)|
| (HTML/JS/CSS)    |          +-------------------------------+          +-----------+---------------+
+------------------+                                                                 |
                                                                                     v
+------------------+          +-------------------------------+          +---------------------------+
| Legacy Tkinter   | -------> | Build Engines                 | <------> | Photoshop COM / Photoshop |
| UI (ui.py)       |          | (build_engine.py, png_builder)|          | API (comtypes / win32com) |
+------------------+          +-------------------------------+          +---------------------------+
                                              |
                                              v
                              +-------------------------------+
                              | Dynamic Pages & Paytables     |
                              | (dynamic_pages/router.py, etc.)|
                              +-------------------------------+
```

---

## Key Subsystems & Layers

### 1. Presentation & UI Layer
- **Web UI (`ps_autotypesetter/ui_web/`)**: Modern Flask-based backend (`server.py`), asynchronous job manager (`jobs.py`), engine bridge (`engine_api.py`), native desktop launcher using PyWebView (`window.py`, `desktop.py`), and a rich single-page application frontend (`static/index.html`, `static/app.js`).
- **Legacy UI (`ps_autotypesetter/ui.py`)**: Tkinter-based desktop interface for classic workflows and template/table mapping editors (`template_mapper_ui.py`, `table_mapper_ui.py`).

### 2. Core Orchestration & Build Engines
- **Build Engine (`ps_autotypesetter/build_engine.py`)**: Primary orchestrator for Photoshop PSD generation, parsing Excel sheets, mapping headings, body texts, and tables, managing layer groups, and applying project manifests (`project_manifest.py`).
- **PNG Builder (`ps_autotypesetter/png_builder.py`)**: Standalone rendering engine producing high-fidelity PNG proofs and exports without requiring Photoshop.
- **Text & Icon Renderer (`ps_autotypesetter/text_icon_renderer.py`)**: Advanced batch text-layer creation supporting high-speed JSX execution with direct COM fallback, inline keyword colorization, and icon token expansion.
- **Table Renderer & Detector (`ps_autotypesetter/table_renderer.py`, `table_detector.py`, `table_mapping.py`)**: Automatic table grid detection, cell styling, and structured table layout positioning.

### 3. Dynamic Pages & Paytable Subsystem (`ps_autotypesetter/dynamic_pages/`)
- **Router (`router.py`)**: Dispatches sheet rendering strategies based on page types (Game Rules, Paytables, Denom pages).
- **Paytable Subsystem (`paytable/`)**: Specialized parsers (`parser.py`), flow sources (`flow_sources.py`), and renderers (`renderer.py`) for complex multi-column paytable structures.

### 4. Utilities & Infrastructure
- **Render Backends (`render_backend.py`, `com_render_backend.py`, `psapi_backend.py`)**: Abstraction layer for Photoshop integration.
- **Project & Session Management (`project_settings.py`, `session_manager.py`, `project_manifest.py`)**: Handles user session persistence, JSON presets, and render diff manifests (`.pshelpscreen.json`).
- **Font & Style Handling (`photoshop_fonts.py`, `layer_styles.py`, `keyword_manager.py`, `background.py`)**: Font family-to-PostScript name resolution, layer styling, and background placement/fitting.
