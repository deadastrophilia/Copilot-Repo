"""Live Photoshop shapes (psd_writer/shapes.py): rounded rectangles stay editable vectors."""
import logging

import pytest
from psd_tools import PSDImage
from psd_tools.api.layers import PixelLayer

from ps_autotypesetter.psd_writer import shapes

SPECS = {
    "pill": ({"left": 200, "top": 60, "width": 800, "height": 92, "radius": "pill", "fill": "#400000",
              "stroke": {"enabled": True, "width": 8, "color": "#FFD21F", "align": "inside"}}, 46.0, 6),
    "card": ({"left": 120, "top": 240, "width": 420, "height": 260, "radius": 20, "fill": "#3A0000",
              "stroke": {"enabled": True, "width": 4, "color": "#E8A317", "align": "center"}}, 20.0, 8),
    "box": ({"left": 660, "top": 240, "width": 420, "height": 260, "radius": 0, "fill": "#1E5AA8"}, 0.0, 4),
}


def test_outline_knots():
    for spec, _radius, knots in SPECS.values():
        assert len(shapes.outline(spec)) == knots
    assert shapes.radii_of({"width": 100, "height": 40, "radius": 90}) == (20, 20, 20, 20)    # clamped
    assert shapes.radii_of({"width": 100, "height": 40, "radii": (0, 5, 10, 25)}) == (0, 5, 10, 20)


@pytest.fixture(scope="module")
def written(tmp_path_factory):
    logging.disable(logging.WARNING)
    path = tmp_path_factory.mktemp("shapes") / "live.psd"
    psd = PSDImage.new("RGBA", (1200, 700), color=(18, 22, 40, 255))
    for name, (spec, _r, _k) in SPECS.items():
        img, left, top = shapes.render(spec)
        layer = PixelLayer.frompil(img, psd, name, top, left)
        shapes.make_live(layer._record, spec, 1200, 700)
        psd.append(layer)
    psd.save(path)
    yield PSDImage.open(path)
    logging.disable(logging.NOTSET)


@pytest.mark.parametrize("name", list(SPECS))
def test_reads_back_as_live_rounded_rectangle(written, name):
    spec, radius, knots = SPECS[name]
    layer = next(l for l in written if l.name == name)
    assert layer.kind == "shape"
    origin = layer.origination[0]
    assert type(origin).__name__ == "RoundedRectangle"
    assert origin.bbox == (spec["left"], spec["top"], spec["left"] + spec["width"], spec["top"] + spec["height"])
    assert all(abs(v - radius) < 1e-6 for k, v in origin.radii.items() if k != b"unitValueQuadVersion")
    assert len(layer.vector_mask.paths[0]) == knots
    assert bool(layer.stroke and layer.stroke.enabled) == bool((spec.get("stroke") or {}).get("enabled"))


def test_preview_pixels_have_transparent_corners(written):
    pill = next(l for l in written if l.name == "pill").topil()
    assert pill.getpixel((1, 1))[3] == 0 and pill.getpixel((400, 46))[3] == 255
