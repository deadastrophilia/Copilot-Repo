"""Paylines / Win Lines pages as canonical PageLayouts for the Canvas (paylines_layout.py): every page of
the sheet (built or not), the lines as the build's own picture (grids, cells, badges, numbers), the
heading as the page heading's text; the renderer's report places the Canvas's handles.

Pages are rendered in memory (no output folder is touched)."""

import os

from openpyxl import Workbook
from PIL import Image, ImageChops

from ps_autotypesetter import paylines_layout, png_builder
from ps_autotypesetter.dynamic_pages import paylines as pl
from ps_autotypesetter.ui_web.server import create_app

PATTERNS = [[1, 1, 1, 1, 1], [0, 0, 0, 0, 0], [2, 2, 2, 2, 2], [0, 1, 2, 1, 0], [2, 1, 0, 1, 2], [0, 0, 1, 2, 2]]
W, H = 1920, 1080


def _sheet(patterns=PATTERNS, denoms=(("1,2", 6), ("5,10", 3))):
    wb = Workbook()
    ws = wb.active
    ws.title = "Pay Lines"
    for c, h in enumerate(["Line", "Reel1", "Reel2", "Reel3", "Reel4", "Reel5"], start=2):
        ws.cell(2, c, h)
    for i, pat in enumerate(patterns, start=1):
        ws.cell(2 + i, 2, i)
        for c, v in enumerate(pat, start=3):
            ws.cell(2 + i, c, v)
    ws.cell(3, 10, "Denom")
    ws.cell(4, 10, "Paylines")
    for k, (label, count) in enumerate(denoms):
        ws.cell(3, 11 + k, label)
        ws.cell(4, 11 + k, count)
    return ws


def _render(ws, ds, meta=None, every=False, counts=None):
    Image_, ImageDraw, ImageFont = png_builder._require_pillow()
    return png_builder._render_paylines_png_pages(
        Image_, ImageDraw, ImageFont, ws, ws.title, "", "color", "#102040", W, H, "Arial", 60, 48, "#FFFFFF",
        100, 60, 4, "", {}, {}, ds, {}, counts=counts, meta=meta, every=every)


def _payload(ws, ds=None):
    """The Canvas payload, and the files its pictures were written to (url token -> path)."""
    files = {}

    def register(path):
        files[str(len(files))] = path
        return str(len(files) - 1)

    p = paylines_layout.layout_payload(lambda meta: _render(ws, ds or {}, meta, every=True), ws.title, W, H, 100, 60,
                                       register_preview=register)
    return p, files


def _picture(p, files, i):
    el = next(e for e in p["layouts"][i]["elements"] if e["type"] == "image")
    return el, Image.open(files[el["meta"]["url"].rsplit("/", 1)[1]]).convert("RGBA")


def test_every_page_comes_back_built_or_not():
    ds = {"paylines": {"pages_off": ["Pay Lines|3"]}}
    p, _files = _payload(_sheet(), ds)
    assert p["ok"] and p["mode"] == "canonical"
    rep = p["paylines"]
    assert [(q["name"], q["count"], q["on"]) for q in rep["pages"]] == [("Pay Lines 6L", 6, True), ("Pay Lines 3L", 3, False)]
    assert len(p["layouts"]) == 2
    assert [lay["source"]["on"] for lay in p["layouts"]] == [True, False]
    assert rep["lines_total"] == 6 and rep["reels"] == 5 and rep["rows"] == 3 and not rep["error"]
    # the build still leaves the switched-off page out
    assert [n for n, _p in _render(_sheet(), ds)[0]] == ["Pay Lines 6L"]


def test_picture_on_the_background_is_the_build_page():
    """The background + the page's picture is the build's page, pixel for pixel, everywhere but the
    heading (the Canvas's text): grids, lit cells, badges and their numbers all come from the renderer."""
    built = dict(_render(_sheet(), {}, counts=[6, 3])[0])
    p, files = _payload(_sheet())
    for i, name in enumerate(["Pay Lines 6L", "Pay Lines 3L"]):
        el, pic = _picture(p, files, i)
        head = next(e for e in p["layouts"][i]["elements"] if e["type"] == "text")
        page = Image.new("RGBA", (W, H), (255, 255, 255, 255))
        png_builder._draw_background(page, Image, "", "color", "#102040")
        page.alpha_composite(pic, (int(el["x"]), int(el["y"])))
        diff = ImageChops.difference(page.convert("RGB"), built[name].convert("RGB"))
        box = diff.getbbox()
        assert box is not None and box[1] >= head["y"] - 2 and box[3] <= head["y"] + head["height"] + 2   # the heading only
        below = int(head["y"] + head["height"] + 2)
        assert diff.crop((0, below, W, H)).getbbox() is None
        assert el["y"] >= below                                                       # the lines: all in the picture


def test_the_heading_is_text_where_the_build_draws_it_and_not_in_the_picture():
    p, files = _payload(_sheet())
    head = next(e for e in p["layouts"][0]["elements"] if e["type"] == "text")
    assert head["meta"]["kind"] == "heading" and head["wrapped_lines"] == ["WIN LINES"]
    assert head["x"] == 100 and head["y"] == 60 and head["width"] == W - 200
    # the picture holds the lines only: nothing drawn where the heading is
    el, pic = _picture(p, files, 0)
    assert el["y"] > head["y"] + head["height"] - 1 or pic.crop((0, 0, pic.width, max(1, int(head["y"] + head["height"] - el["y"])))).getbbox() is None


def test_report_places_every_line_like_the_layout():
    ds = {"paylines": {"columns": 4}}
    p, _files = _payload(_sheet(), ds)
    cfg = pl.settings_for(ds, W)
    page = p["paylines"]["pages"][0]
    pos, _warn = pl.layout(6, cfg, W, H)
    gw, gh = pl.grid_size(cfg, 5, 3)
    assert [ln["n"] for ln in page["lines"]] == [1, 2, 3, 4, 5, 6]
    assert [tuple(ln["grid"]) for ln in page["lines"]] == [(x, y, gw, gh) for x, y in pos]
    assert page["lines"][0]["badge"] == [pos[0][0] + cfg["badge_dx"], pos[0][1] + cfg["badge_dy"], cfg["badge_w"], cfg["badge_h"]]
    assert tuple(page["block"]) == pl.block_box(6, cfg, W, H)
    assert (page["cols"], page["nrows"], page["grid_w"], page["grid_h"]) == (4, 2, gw, gh)


def test_canvas_edits_are_what_the_build_draws():
    """Settings the Canvas saves (dynamic_settings.paylines) move the lines in the payload and the build alike."""
    moved = {"paylines": {"offset_x": 40, "top": 500, "pitch_x": 200, "badge_font_size": 30}}
    p, _files = _payload(_sheet(), moved)
    meta = {}
    _render(_sheet(), moved, meta)
    assert [ln["grid"] for ln in p["paylines"]["pages"][0]["lines"]] == [ln["grid"] for ln in meta["pages"][0]["lines"]]
    assert p["paylines"]["pages"][0]["lines"][0]["grid"][1] == 500


def test_bad_data_is_a_page_that_says_so():
    ws = _sheet()
    ws.cell(4, 4, 7)                                # a row index out of range
    p, _files = _payload(ws)
    assert p["ok"] and len(p["layouts"]) == 1 and p["layouts"][0]["elements"] == []
    assert p["paylines"]["error"] and p["paylines"]["pages"] == []


def test_a_sink_block_marked_draw_is_recorded_and_drawn():
    """png_builder.line_sink(skip_text) skips text, except inside _sink_ctx(draw=True) (the payline numbers)."""
    Image_, ImageDraw, ImageFont = png_builder._require_pillow()
    font = png_builder._load_font(ImageFont, "Arial", 40, bold=True)
    pages = []
    for ctx in ({}, {"draw": True}):
        page = Image.new("RGBA", (200, 80), (0, 0, 0, 0))
        with png_builder.line_sink(skip_text=True) as rec, png_builder._sink_ctx(kind="number", **ctx):
            png_builder._draw_inline(page, ImageDraw.Draw(page), Image_, "42", 0, 10, font, (255, 255, 255), 200, "", {}, 40,
                                     None, align="center", font_request="Arial", font_size=40, bold=True)
        assert len(rec["lines"]) == 1 and rec["lines"][0]["text"] == "42"
        pages.append(page)
    assert pages[0].getbbox() is None and pages[1].getbbox() is not None


def test_layout_preview_route_serves_payline_sheets(tmp_path):
    ws = _sheet()
    path = os.path.join(str(tmp_path), "lines.xlsx")
    ws.parent.save(path)
    client = create_app(session_file=os.path.join(str(tmp_path), "session.json")).test_client()
    client.post("/api/config", json={"excel_path": path, "c_width": W, "c_height": H, "icon_folder": "",
                                     "dynamic_settings": {"paylines": {"columns": 3}}})
    d = client.post("/api/layout/preview", json={"sheet_name": "Pay Lines"}).get_json()
    assert d["ok"] and d["mode"] == "canonical" and d["sheet_name"] == "Pay Lines"
    assert [q["count"] for q in d["paylines"]["pages"]] == [6, 3] and len(d["layouts"]) == 2
    assert d["paylines"]["pages"][0]["cols"] == 3 and d["paylines"]["settings"]["columns"] == 3
    pic = next(e for e in d["layouts"][0]["elements"] if e["type"] == "image")
    assert client.get(pic["meta"]["url"]).status_code == 200
    # a drag in progress (settings_draft) lays the lines out with its values, never saving them
    d2 = client.post("/api/layout/preview", json={"sheet_name": "Pay Lines",
                                                  "settings_draft": {"dynamic_settings.paylines": {"columns": 2}}}).get_json()
    assert d2["paylines"]["pages"][0]["cols"] == 2
    assert client.get("/api/config").get_json()["config"]["dynamic_settings"]["paylines"] == {"columns": 3}
