"""symbol_align: a PSD's pictures named by lining its text up with the AGR (the user's MO' FEATURES method)."""

from types import SimpleNamespace

from ps_autotypesetter import symbol_align as sa

LINE = "<Mummy> or <Special Mummy> with one or more <Pink Gem> awards Mo' Boosts feature."


def _layer(kind, name, left, top, right, bottom, text="", parent=None):
    return SimpleNamespace(kind=kind, name=name, left=left, top=top, right=right, bottom=bottom, text=text,
                           visible=True, parent=parent, engine_dict={})


def _root(layers):
    root = SimpleNamespace(visible=False, parent=None)          # a hidden page: still read
    for l in layers:
        l.parent = root
    root.descendants = lambda: list(layers)
    return root


def _sheet(*cells):
    return SimpleNamespace(cells={(i + 1, 1): c for i, c in enumerate(cells)})


def _is_pic(l):
    return l.kind == "smartobject"


def _name(layers, sheet_cells):
    root = _root(layers)
    votes, _ev = sa.name_pictures([("page", root)], {"S": _sheet(*sheet_cells)}, _is_pic, lambda l: l.name)
    return {k: v[0] for k, v in sa.decide(votes).items()}


def test_separate_layers_in_a_row():
    """[mummy] or [special] with one or more [gem] awards …: each picture where the AGR has its symbol."""
    layers = [_layer("smartobject", "mummy", 100, 100, 150, 150), _layer("type", "t1", 155, 110, 190, 140, "or"),
              _layer("smartobject", "special", 195, 100, 245, 150),
              _layer("type", "t2", 250, 110, 420, 140, "with one or more"),
              _layer("smartobject", "gem", 425, 100, 475, 150),
              _layer("type", "t3", 480, 110, 800, 140, "awards Mo' Boosts feature.")]
    got = _name(layers, [LINE, "One or more <Pink Gem> in a spin without <Mummy> or <Special Mummy> may award the Mo' Boosts feature."])
    assert got == {"mummy": "Mummy", "special": "Special Mummy", "gem": "Pink Gem"}


def test_one_text_layer_with_icon_gaps_and_a_wrapping_box():
    """One text layer with room left for the icons; the pictures over it fill the gaps in reading order —
    also when the box wraps by itself (its lines aren't the text's lines)."""
    text = "          or          with one or more          awards Mo' Boosts feature."
    layers = [_layer("type", "t", 100, 100, 600, 200, text),
              _layer("smartobject", "gem", 120, 150, 170, 200),          # second visual line
              _layer("smartobject", "mummy", 100, 100, 150, 150),
              _layer("smartobject", "special", 200, 100, 250, 150)]
    assert _name(layers, [LINE]) == {"mummy": "Mummy", "special": "Special Mummy", "gem": "Pink Gem"}


def test_little_words_and_numbers_are_no_cue():
    """"[pic], [pic] and [pic]" or "[pic] 5 400" match anywhere in a list of symbols / pay table: they name
    nothing; a hidden layer on a page names nothing either."""
    layers = [_layer("smartobject", "a", 100, 100, 150, 150), _layer("type", "t", 155, 110, 200, 140, "and"),
              _layer("smartobject", "b", 205, 100, 255, 150), _layer("type", "n", 260, 110, 300, 140, "5 400")]
    assert _name(layers, ["<X> and <Y> 5 400", "<Y> and <X> 5 400"]) == {}
    hidden = _layer("smartobject", "mummy", 100, 100, 150, 150)
    hidden.visible = False
    layers = [hidden, _layer("type", "t1", 155, 110, 190, 140, "or"), _layer("smartobject", "special", 195, 100, 245, 150),
              _layer("type", "t2", 250, 110, 800, 140, "with one or more awards")]
    assert "mummy" not in _name(layers, ["<Mummy> or <Special Mummy> with one or more awards"])


def test_votes_decide_and_ties_are_not_guessed():
    from collections import Counter

    got = sa.decide({"p1": Counter({"Mummy": 8, "Red Gem": 1}), "p2": Counter({"A": 2, "B": 2})})
    assert got["p1"][0] == "Mummy" and got["p1"][1] == "text_majority"
    assert got["p2"][0] is None and got["p2"][1] == "conflict"
