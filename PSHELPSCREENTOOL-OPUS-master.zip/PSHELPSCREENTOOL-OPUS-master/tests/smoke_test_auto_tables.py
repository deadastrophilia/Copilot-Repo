import os
import sys
import types

from openpyxl import Workbook
from openpyxl.styles import Border, PatternFill, Side


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from ps_autotypesetter.config import TABLE_DEFAULTS
from ps_autotypesetter.table_detector import detect_tables_in_sheet, manual_tables_from_ranges


photoshop_pkg = types.ModuleType("photoshop")
photoshop_api = types.ModuleType("photoshop.api")
photoshop_api.Justification = types.SimpleNamespace(Center=2, Left=1, Right=3)
photoshop_api.ElementPlacement = types.SimpleNamespace(PlaceInside=1)
photoshop_api.LayerKind = types.SimpleNamespace(TextLayer=2)
photoshop_api.SolidColor = type(
    "SolidColor",
    (),
    {"__init__": lambda self: setattr(self, "rgb", types.SimpleNamespace(red=0, green=0, blue=0))},
)
photoshop_pkg.api = photoshop_api
sys.modules["photoshop"] = photoshop_pkg
sys.modules["photoshop.api"] = photoshop_api

from ps_autotypesetter.table_renderer import (
    _component_bounds,
    _component_slot_boxes,
    _estimate_wrapped_lines,
    _grid_table_metrics,
    _role_font_name,
    _role_font_size,
    _role_line_height,
    estimate_table_height,
)


class _TextItem:
    def __init__(self):
        self.size = 30
        self.font = "Arial"
        self.contents = ""


class _MeasureLayer:
    def __init__(self):
        self.textItem = _TextItem()

    @property
    def bounds(self):
        text = str(self.textItem.contents or "")
        width = max(0.0, len(text) * float(self.textItem.size) * 0.5)
        return [0.0, 0.0, width, float(self.textItem.size)]


def _bordered(cell):
    side = Side(style="thin", color="FFFFFF")
    cell.border = Border(left=side, right=side, top=side, bottom=side)


workbook = Workbook()
worksheet = workbook.active
worksheet.title = "Auto Tables"

for column, value in enumerate(["100 credit bet", "225 credit bet", "350 credit bet"], start=2):
    cell = worksheet.cell(row=2, column=column, value=value)
    _bordered(cell)
for column, value in enumerate(["50 or more", "100 or more", "150 or more"], start=2):
    cell = worksheet.cell(row=3, column=column, value=value)
    _bordered(cell)

worksheet.merge_cells("B6:G6")
worksheet["B6"] = "Cash prizes are per table below"
for column in range(2, 8):
    _bordered(worksheet.cell(row=6, column=column))
for start_col, value in ((2, "100 credit bet"), (4, "225 credit bet"), (6, "350 credit bet")):
    worksheet.merge_cells(start_row=7, start_column=start_col, end_row=7, end_column=start_col + 1)
    worksheet.cell(row=7, column=start_col, value=value)
    for column in range(start_col, start_col + 2):
        _bordered(worksheet.cell(row=7, column=column))
for row_idx, values in ((8, ["Reels 1 and 5", "Reels 2, 3 and 4"] * 3), (9, ["50 or more", "50 or more"] * 3)):
    for column, value in enumerate(values, start=2):
        cell = worksheet.cell(row=row_idx, column=column, value=value)
        _bordered(cell)

# Big Board Bucks style: a short two-column label row sits just above the
# bordered body band. The detector must pull it in as the header instead of
# treating the first body row as the header.
worksheet["B12"] = "PROPERTIES"
worksheet["C12"] = "PRIZE (credits)"
for row_idx, values in (
    (13, ["Boardwalk", "1500"]),
    (14, ["Park Place", "1000"]),
    (15, ["Pennsylvania Avenue", "600"]),
):
    for column, value in enumerate(values, start=2):
        cell = worksheet.cell(row=row_idx, column=column, value=value)
        _bordered(cell)
worksheet["B13"].fill = PatternFill(fill_type="solid", fgColor="FF0000")

tables = detect_tables_in_sheet(worksheet, 12)
assert len(tables) == 3, tables

two_row = tables[0]
assert two_row["header_row_indices"] == [2]
assert two_row["row_roles"][2] == "header"
assert two_row["row_roles"][3] == "body"
assert len(two_row["data_rows"]) == 1

title_table = tables[1]
assert title_table["start_row"] == 7
assert title_table["header_row_indices"] == [7]
assert title_table["row_roles"][7] == "header"
assert title_table["row_roles"][8] == "body"
assert title_table["row_roles"][9] == "body"

properties_table = tables[2]
assert properties_table["header_row_indices"] == [12]
assert properties_table["row_roles"][12] == "header"
assert properties_table["row_roles"][13] == "body"
assert properties_table["header_row"] == {2: "PROPERTIES", 3: "PRIZE (credits)"}
assert properties_table["data_rows"][0] == {2: "Boardwalk", 3: "1500"}
assert properties_table["cell_fill_colors"][(13, 2)] == (255, 0, 0)

side_by_side_workbook = Workbook()
side_by_side_sheet = side_by_side_workbook.active
side_by_side_sheet.title = "Side by Side"
for row_idx, values in (
    (9, ["UTILITIES", "PRIZE"]),
    (10, ["Water Works", "4 x Total Bet"]),
    (11, ["Electric Company", "4 x Total Bet"]),
):
    for column, value in enumerate(values, start=5):
        cell = side_by_side_sheet.cell(row=row_idx, column=column, value=value)
        _bordered(cell)
for row_idx, values in (
    (9, ["RAILROADS", "PRIZE"]),
    (10, ["B. & O. Railroad", "1 x Total Bet"]),
    (11, ["Short Line", "1 x Total Bet"]),
    (12, ["Reading Railroad", "1 x Total Bet"]),
    (13, ["Pennsylvania Railroad", "1 x Total Bet"]),
):
    for column, value in enumerate(values, start=8):
        cell = side_by_side_sheet.cell(row=row_idx, column=column, value=value)
        _bordered(cell)
side_by_side_tables = detect_tables_in_sheet(side_by_side_sheet, 12)
assert len(side_by_side_tables) == 2, side_by_side_tables
assert [table["start_row"] for table in side_by_side_tables] == [9, 9]
assert [(table["min_col"], table["max_col"]) for table in side_by_side_tables] == [(5, 6), (8, 9)]
right_only_tables = detect_tables_in_sheet(side_by_side_sheet, 12, min_col_limit=8)
assert len(right_only_tables) == 1, right_only_tables
assert (right_only_tables[0]["min_col"], right_only_tables[0]["max_col"]) == (8, 9)

manual_tables = manual_tables_from_ranges(worksheet, ["B12:C15"], 12)
assert len(manual_tables) == 1
manual_properties_table = manual_tables[0]
assert manual_properties_table["manual_table"] is True
assert manual_properties_table["manual_range"] == "B12:C15"
assert manual_properties_table["start_row"] == 12
assert manual_properties_table["end_row"] == 15
assert manual_properties_table["min_col"] == 2
assert manual_properties_table["max_col"] == 3
assert manual_properties_table["header_row_indices"] == [12]
assert manual_properties_table["row_roles"][12] == "header"
assert manual_properties_table["row_roles"][15] == "body"
assert manual_properties_table["header_row"] == {2: "PROPERTIES", 3: "PRIZE (credits)"}

style = TABLE_DEFAULTS.copy()
style.update({
    "table_width_pct": 60,
    "table_body_font_size": 30,
    "table_header_font_size": 30,
    "table_header_font_name": "HeaderFontPS",
    "table_body_font_name": "BodyFontPS",
    "table_icon_height": 50,
    "cell_padding_y": 5,
    "row_gap": 0,
    "row_height_multiplier": 1.2,
})
metrics = _grid_table_metrics(two_row, 1000, "Arial", 30, 50, style, _MeasureLayer(), {})
assert metrics["row_gap"] == 0
assert metrics["row_heights"][3] == 60, metrics["row_heights"]
assert metrics["header_font_name"] == "HeaderFontPS"
assert metrics["body_font_name"] == "BodyFontPS"
assert metrics["table_width"] < 850, metrics["table_width"]
assert len(set(round(width, 3) for width in metrics["col_widths"].values())) == 1

uneven_table = {
    "grid_mode": True,
    "columns": [("A", 1), ("B", 2), ("C", 3)],
    "row_indices": [1, 2],
    "row_roles": {1: "header", 2: "body"},
    "grid_cells": [
        {"row": 1, "col": 1, "rowspan": 1, "colspan": 1, "value": "Name", "role": "header"},
        {"row": 1, "col": 2, "rowspan": 1, "colspan": 1, "value": "Award", "role": "header"},
        {"row": 1, "col": 3, "rowspan": 1, "colspan": 1, "value": "Qty", "role": "header"},
        {"row": 2, "col": 1, "rowspan": 1, "colspan": 1, "value": "Ultra", "role": "body"},
        {
            "row": 2,
            "col": 2,
            "rowspan": 1,
            "colspan": 1,
            "value": "2 or more <COIN> , Grand, Major, Minor, Mini, Double Up, Extra Spins",
            "role": "body",
        },
        {"row": 2, "col": 3, "rowspan": 1, "colspan": 1, "value": "3", "role": "body"},
    ],
}
uneven_style = dict(style)
uneven_style["table_body_font_size"] = 20
uneven_style["table_header_font_size"] = 20
uneven_style["table_icon_height"] = 30
uneven_metrics = _grid_table_metrics(uneven_table, 2200, "Arial", 20, 30, uneven_style, _MeasureLayer(), {})
assert uneven_metrics["col_widths"][2] > uneven_metrics["col_widths"][1], uneven_metrics["col_widths"]
assert uneven_metrics["col_widths"][2] > uneven_metrics["col_widths"][3], uneven_metrics["col_widths"]
inner_col_2 = uneven_metrics["col_widths"][2] - (uneven_style["cell_padding_x"] * 2)
body_lines = _estimate_wrapped_lines(
    uneven_table["grid_cells"][4]["value"],
    inner_col_2,
    uneven_metrics["table_body_font_size"],
    uneven_metrics["body_font_name"],
    uneven_metrics["table_icon_h"],
    0,
    _MeasureLayer(),
    {},
)
assert len(body_lines) == 1, body_lines
assert uneven_metrics["row_heights"][2] >= uneven_metrics["table_icon_h"] + 10, uneven_metrics["row_heights"]

gap_padding_style = dict(uneven_style)
gap_padding_style["cell_padding_x"] = 0
gap_padding_metrics = _grid_table_metrics(
    uneven_table, 2200, "Arial", 20, 30, gap_padding_style, _MeasureLayer(), {}, gap_px=12
)
assert gap_padding_metrics["padding_x"] == 10, gap_padding_metrics["padding_x"]
assert gap_padding_metrics["col_widths"][2] > uneven_metrics["col_widths"][2], (
    gap_padding_metrics["col_widths"],
    uneven_metrics["col_widths"],
)
gap_inner_col_2 = gap_padding_metrics["col_widths"][2] - (gap_padding_metrics["padding_x"] * 2)
gap_body_lines = _estimate_wrapped_lines(
    uneven_table["grid_cells"][4]["value"],
    gap_inner_col_2,
    gap_padding_metrics["table_body_font_size"],
    gap_padding_metrics["body_font_name"],
    gap_padding_metrics["table_icon_h"],
    12,
    _MeasureLayer(),
    {},
)
assert len(gap_body_lines) == 1, gap_body_lines

clamped_metrics = _grid_table_metrics(uneven_table, 500, "Arial", 20, 30, uneven_style, _MeasureLayer(), {})
assert clamped_metrics["table_width"] <= 500 - (uneven_style["table_margin_x"] * 2) + 0.1
assert clamped_metrics["col_widths"][2] > clamped_metrics["col_widths"][1], clamped_metrics["col_widths"]

wrapped_table = {
    "grid_mode": True,
    "columns": [("A", 1), ("B", 2)],
    "row_indices": [1, 2],
    "row_roles": {1: "header", 2: "body"},
    "grid_cells": [
        {"row": 1, "col": 1, "rowspan": 1, "colspan": 1, "value": "BONUS BOOST FEATURE TRIGGER", "role": "header"},
        {"row": 1, "col": 2, "rowspan": 1, "colspan": 1, "value": "WHEEL PRIZES", "role": "header"},
        {"row": 2, "col": 1, "rowspan": 1, "colspan": 1, "value": "Ultra Spins", "role": "body"},
        {
            "row": 2,
            "col": 2,
            "rowspan": 1,
            "colspan": 1,
            "value": "2 or more <COIN> , Grand, Major, Minor, Mini, Double Up, Extra Spins or Double Up Extra Spins",
            "role": "body",
        },
    ],
}
wrapped_style = dict(style)
wrapped_style["table_target_width"] = 320
wrapped_style["table_icon_height"] = 50
wrapped_metrics = _grid_table_metrics(wrapped_table, 1000, "Arial", 30, 50, wrapped_style, _MeasureLayer(), {})
assert wrapped_metrics["row_heights"][2] > wrapped_metrics["table_icon_h"] + (wrapped_style["cell_padding_y"] * 2)
assert wrapped_metrics["row_heights"][2] > wrapped_metrics["row_heights"][1]
manual_width_style = dict(style)
manual_width_style["table_target_width"] = 300
manual_metrics = _grid_table_metrics(two_row, 1000, "Arial", 30, 50, manual_width_style, _MeasureLayer(), {})
assert round(manual_metrics["table_width"]) == 300, manual_metrics["table_width"]
assert all(round(width) == 100 for width in manual_metrics["col_widths"].values()), manual_metrics["col_widths"]
target_style = dict(style)
target_style["table_target_height"] = 100
assert estimate_table_height(two_row, 1000, "Arial", 30, 50, target_style, _MeasureLayer(), {}) == 100
mapped_style = dict(style)
mapped_style["table_body_font_name"] = "AutoTableBodyFont"
mapped_style["table_body_font_size"] = 80
mapped_style["table_body_line_height"] = 90
json_mapping = {"font_name": "JsonMappedBodyFont", "font_size": 15, "line_height": 18}
assert _role_font_name(json_mapping, "normal_text", mapped_style, "BaseFont", None) == "JsonMappedBodyFont"
assert _role_font_size(json_mapping, "normal_text", mapped_style, 30) == 15
assert _role_line_height(json_mapping, "normal_text", mapped_style) == 18

legacy_bounds = _component_bounds(
    {
        "table_name": "bigbuck-page-3table",
        "spec": {"bounds_slot": "bigbuck-page-3table"},
    },
    {
        "bigbuck.bound": {"x": 688, "y": 253, "w": 544, "h": 770},
        "row42": {"x": 688, "y": 988, "w": 299, "h": 35},
        "row41": {"x": 987, "y": 988, "w": 245, "h": 35},
    },
)
assert legacy_bounds["x"] == 688
assert legacy_bounds["y"] == 253
assert legacy_bounds["w"] == 544
assert legacy_bounds["h"] >= 770

flat_artist_slots = _component_slot_boxes(
    {
        "bigbuck-page-3table.bounds": {"x": 688, "y": 253, "w": 544, "h": 770},
        "header1": {"x": 688, "y": 253, "w": 299, "h": 35},
        "row42": {"x": 688, "y": 988, "w": 299, "h": 35},
    },
    "bigbuck-page-3table",
)
assert {"bigbuck-page-3table.bounds", "header1", "row42"}.issubset(flat_artist_slots)

prefixed_component_slots = _component_slot_boxes(
    {
        "tableA.bounds": {"x": 0, "y": 0, "w": 100, "h": 100},
        "tableA.header": {"x": 0, "y": 0, "w": 100, "h": 20},
        "tableB.header": {"x": 0, "y": 120, "w": 100, "h": 20},
    },
    "tableA",
)
assert set(prefixed_component_slots) == {"tableA.bounds", "tableA.header"}

print("Auto table smoke test passed.")
