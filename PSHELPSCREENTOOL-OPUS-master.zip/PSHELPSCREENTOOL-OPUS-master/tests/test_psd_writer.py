"""Headless PSD writer: png_builder layout recorded into an editable PSD."""

import logging
import os

import pytest
from openpyxl import Workbook
from PIL import Image, ImageDraw, ImageFont

pytest.importorskip("photoshopapi")
psd_tools = pytest.importorskip("psd_tools")

from ps_autotypesetter import png_builder
from ps_autotypesetter.psd_writer import build as psd_build
from ps_autotypesetter.psd_writer import document, fontnames, recorder
from ps_autotypesetter.ui_web import engine_api

logging.getLogger("psd_tools").setLevel(logging.ERROR)


def _workbook(path, sheets):
    wb = Workbook()
    wb.remove(wb.active)
    for name, rows in sheets.items():
        ws = wb.create_sheet(name)
        for row in rows:
            ws.append(row)
    wb.save(path)
    return path


@pytest.fixture
def icon_folder(tmp_path):
    folder = tmp_path / "icons"
    folder.mkdir()
    Image.new("RGBA", (40, 40), (255, 200, 0, 255)).save(folder / "gold_scat.png")
    return str(folder)


def _build(tmp_path, excel, icon_folder="", **overrides):
    cfg = {"excel_path": excel, "icon_folder": icon_folder, "bg_path": "", "bg_source": "color",
           "bg_color": "#102040", "output_dir": str(tmp_path / "out"), "output_name": "Out",
           "render_all_pages": True, "c_width": 1280, "c_height": 720}
    cfg.update(overrides)
    base = engine_api._build_kwargs(cfg)
    notes = []
    path = psd_build.build_psd(**base, output_format="PSD",
                               progress_callback=lambda d: notes.append(d.get("message", "")))
    return path, notes


def _text_layers(psd):
    return [l for l in psd.descendants() if l.kind == "type"]


def test_normal_page_becomes_editable_layers(tmp_path, icon_folder):
    excel = _workbook(str(tmp_path / "rules.xlsx"), {
        "Game Rules": [["GAME RULES"], [""], ["All wins on played lines only, except <gold_scat>."],
                       ["Malfunction voids all pays and plays."]],
    })
    path, notes = _build(tmp_path, excel, icon_folder)
    assert path and os.path.isfile(path) and path.endswith("Out.psd")

    psd = psd_tools.PSDImage.open(path)
    assert psd.size == (1280, 720)
    groups = [l for l in psd if l.is_group()]
    assert [g.name.rstrip("\x00") for g in groups] == ["Game Rules"]

    texts = _text_layers(psd)
    joined = " | ".join(t.name.rstrip("\x00") for t in texts)
    assert "GAME RULES" in joined
    assert "Malfunction voids all pays and plays." in joined
    # every text layer carries preview pixels, so Photoshop shows it on open
    for t in texts:
        assert t.has_pixels() and t.width > 10 and t.height > 5, t.name

    icons = [l for l in groups[0] if l.kind == "pixel" and l.name.rstrip("\x00") == "gold_scat"]
    assert len(icons) == 1 and icons[0].height == 28  # scaled to the body icon height
    # the icon sits inside the text line's vertical band
    line = next(t for t in texts if "except" in t.name)
    assert line.top - 20 <= icons[0].top <= line.bottom
    assert any(l.name.rstrip("\x00") == "Background" for l in psd)
    assert any("editable text layer" in n for n in notes)


def test_long_sheet_continues_on_more_page_groups(tmp_path):
    rows = [["RULES"]] + [[f"Rule number {i} explains one more detail of the game."] for i in range(60)]
    excel = _workbook(str(tmp_path / "long.xlsx"), {"Long": rows})
    path, _ = _build(tmp_path, excel)
    psd = psd_tools.PSDImage.open(path)
    # psd-tools lists bottom-to-top; page 1 sits on top of the layer stack
    groups = list(reversed([l for l in psd if l.is_group()]))
    names = [g.name.rstrip("\x00") for g in groups]
    assert names[:3] == ["Long", "Long (Continued 1)", "Long (Continued 2)"]
    # only the first page group is visible when the file opens
    assert groups[0].visible and not any(g.visible for g in groups[1:])


def test_update_in_place_never_overwrites_old_psd(tmp_path):
    old = tmp_path / "Game.psd"
    old.write_bytes(b"artist edits")
    path, redirected = psd_build._save_path(str(tmp_path / "x.xlsx"), "", "", "PSD", True, str(old))
    assert redirected and path == str(tmp_path / "Game_rebuilt.psd")
    path, redirected = psd_build._save_path(str(tmp_path / "x.xlsx"), str(tmp_path / "o"), "Typed", "PSD", True, str(old))
    assert not redirected and path.endswith(os.path.join("o", "Typed.psd"))


def test_icon_gap_is_filled_with_tracked_nbsp():
    font = ImageFont.truetype("arial.ttf", 30)
    rec = recorder.TextRecord(font, (255, 255, 255), "center")
    line = recorder.TextLine(100.0)
    line.runs = [recorder.TextRun("Prizes on", (255, 255, 255), 50, font.getlength("Prizes on")),
                 recorder.TextRun(" win.", (255, 255, 255), 250, font.getlength(" win."))]
    rec.lines = [line]
    rec.box = (0.0, 600.0)
    text, spans, starts = document.text_spans(rec)
    assert text.startswith("Prizes on" + document.NBSP)
    # Photoshop's width of the gap (exact advances + tracking) equals the PNG gap
    gaps = [s for s in spans if text[s[0]] == document.NBSP]
    nbsp_w = document._exact_length(font, document.NBSP)
    width = sum(g[1] * (nbsp_w + g[3] * 30 / 1000.0) for g in gaps)
    assert abs(width - (250 - 50 - font.getlength("Prizes on"))) < 0.1


def test_effects_payload_accepts_both_capture_shapes():
    body = "0000001000000001000000000000" + "6e756c6c" + "00000002" + "00" * 40
    assert document._effects_payload({"captured_effects_hex": body})[:8] == bytes.fromhex("0000000000000010")
    assert document._effects_payload({"captured_effects_hex": "00000000" + body})[:8] == bytes.fromhex("0000000000000010")
    # an empty capture (no effects on the source layer) carries nothing
    assert document._effects_payload({"captured_effects_hex": "000000000000001000000000000000010000"}) is None
    assert document._effects_payload({}) is None


def test_postscript_names_from_font_files():
    assert fontnames.postscript_name_for_font(ImageFont.truetype("arial.ttf", 20)) == "ArialMT"
    assert fontnames.postscript_name_for_font(ImageFont.truetype("arialbd.ttf", 20)) == "Arial-BoldMT"


def test_keyword_colors_draw_on_one_baseline():
    font = ImageFont.truetype("arial.ttf", 40)
    plain = Image.new("RGBA", (700, 80), (0, 0, 0, 255))
    colored = plain.copy()
    text = "Win FREE GAMES now"
    for img, kw in ((plain, None), (colored, {"FREE GAMES": [255, 0, 0]})):
        png_builder._draw_inline(img, ImageDraw.Draw(img), Image, text, 0, 10, font, (255, 255, 255),
                                 700, "", {}, 30, keyword_colors=kw)
    red = [p for p in colored.getdata() if p[0] > 200 and p[1] < 60]
    assert red, "keyword drawn in its colour"
    # same glyph coverage either way: colours change, positions don't
    to_mask = lambda im: [1 if max(p[:3]) > 60 else 0 for p in im.getdata()]
    assert to_mask(plain) == to_mask(colored)


def test_no_recorder_means_png_untouched(tmp_path):
    """Without an active recorder the PNG path paints text as before."""
    assert recorder.active_recorder() is None
    img = Image.new("RGBA", (400, 80), (0, 0, 0, 255))
    png_builder._draw_inline(img, ImageDraw.Draw(img), Image, "Hello", 0, 10,
                             ImageFont.truetype("arial.ttf", 30), (255, 255, 255), 400, "", {}, 24)
    assert img.getbbox() and any(p[0] > 200 for p in img.getdata())


# ── phase 2: paytables, buffers, styles ─────────────────────────────────────
EXAMPLES = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "examples")


def _paytable_cfg(tmp_path, **extra):
    cfg = {"excel_path": os.path.join(EXAMPLES, "paytable.xlsx"),
           "icon_folder": os.path.join(EXAMPLES, "paytable_assets"), "bg_path": "", "bg_source": "color",
           "bg_color": "#101830", "output_dir": str(tmp_path), "output_name": "PT", "render_all_pages": True,
           "dynamic_settings": {}, "safe_backup": False}
    cfg.update(extra)
    return cfg


def test_paytable_without_template_gets_auto_layout_as_editable_cards(tmp_path):
    notes = []
    out = engine_api.run_build(_paytable_cfg(tmp_path), "psd",
                               progress_callback=lambda d: notes.append(d.get("message") or ""))
    assert any(n.startswith("[PAYTABLE]") and "auto layout created" in n for n in notes)
    assert os.path.isfile(os.path.join(tmp_path, "mapped_paytables", "Paytable_auto_mapped.json"))

    psd = psd_tools.PSDImage.open(out["psd_path"])
    page = [g for g in psd if g.is_group()][-1]
    cards = {g.name.rstrip("\x00"): g for g in page if g.is_group()}
    assert {"pic1", "ace"} <= set(cards), sorted(cards)
    card = {l.name.rstrip("\x00"): l for l in cards["pic1"]}
    assert card["pic1 symbol"].kind == "pixel"
    assert card["pic1.pay"].kind == "type" and card["pic1.value"].kind == "type"
    assert card["pic1.value"].has_pixels()


def test_existing_or_disabled_paytable_template_is_left_alone(tmp_path):
    saved = tmp_path / "mine.json"
    saved.write_text("{}")
    cfg = _paytable_cfg(tmp_path, dynamic_settings={"template_json_map": {"Paytable": str(saved)}})
    assert engine_api._with_auto_paytables(cfg) is cfg
    cfg = _paytable_cfg(tmp_path, paytable_default_auto=False)
    assert engine_api._with_auto_paytables(cfg) is cfg


def test_buffer_records_land_on_page_shifted():
    rec = recorder.LayerRecorder()
    page_img, buf = Image.new("RGBA", (200, 200)), Image.new("RGBA", (50, 50))
    font = ImageFont.truetype("arial.ttf", 20)
    with rec.recording():
        rec.register_page(page_img, None)
        rec.register_buffer(buf, page_img, 30, 40)
        png_builder._draw_inline(buf, ImageDraw.Draw(buf), Image, "Hi", 0, 0, font, (255, 255, 255),
                                 50, "", {}, 16, align="left")
    page = rec.page_for(page_img)
    assert len(page.texts) == 1 and not buf.getbbox()  # recorded, not painted
    run = page.texts[0].lines[0].runs[0]
    assert 29 <= run.x <= 32 and page.texts[0].lines[0].baseline > 40


def test_captured_style_hex_with_four_digits_per_byte():
    stream = bytes.fromhex("00000010" + "00000001" + "0000" + "00000000" + "6e756c6c" + "00000001") + b"\x01" * 40
    utf16_hex = "".join(f"{b:04x}" for b in stream)
    payload = document._effects_payload({"captured_effects_hex": utf16_hex})
    assert payload == b"\x00\x00\x00\x00" + stream


def test_parameter_style_becomes_photoshop_effects():
    import io
    from psd_tools.psd.descriptor import DescriptorBlock
    from ps_autotypesetter.psd_writer import effects
    assert effects.params_payload({"stroke_enabled": False, "shadow_enabled": False}) is None
    payload = effects.params_payload({"stroke_enabled": True, "stroke_rgb": [10, 20, 30], "stroke_size": 5,
                                      "shadow_enabled": True, "shadow_distance": 9})
    desc = DescriptorBlock.read(io.BytesIO(payload[4:]))
    assert bool(desc[b"FrFX"][b"enab"]) and desc[b"FrFX"][b"Sz  "].value == 5
    assert desc[b"FrFX"][b"Clr "][b"Grn "].value == 20
    assert bool(desc[b"DrSh"][b"enab"]) and desc[b"DrSh"][b"Dstn"].value == 9


def test_pay_value_slots_follow_their_symbol_in_the_current_sheet():
    """A mapping made against a workbook whose paytable started one row lower
    must still read every pay line from THIS workbook (Excel is the truth),
    while an artist's own pick (source_pinned) is kept."""
    from openpyxl import load_workbook
    from ps_autotypesetter.ui_web import ps_actions

    ws = load_workbook(os.path.join(EXAMPLES, "paytable.xlsx"), data_only=True)["Paytable"]
    template = {"slots": {"pic1": {"x": 0, "y": 0, "w": 100, "h": 100},
                          "pic1.pay": {"x": 0, "y": 100, "w": 50, "h": 100},
                          "pic1.value": {"x": 50, "y": 100, "w": 50, "h": 100}},
                "slot_prefix": "@slot", "mappings": {}}
    live = engine_api.automap_paytable_slots_ws(ws, template)
    fresh = {m["slot"]: m for m in live["mappings"] if m.get("role") in ("pay", "value")}
    assert "pic1.pay" in fresh, fresh

    def shifted(source):  # same cells, one row lower = the stale mapping
        import re
        return ",".join(re.sub(r"\d+", lambda d: str(int(d.group()) + 1), ref) for ref in source.split(","))

    mapped = {
        "pic1.pay": {"mode": "excel", "role": "pay", "symbol": "pic1", "source": shifted(fresh["pic1.pay"]["source"])},
        "pic1.value": {"mode": "excel", "role": "value", "symbol": "pic1", "source": "Z99", "source_pinned": True},
    }
    ps_actions._sanitize_preview_mappings(mapped, ws, template)
    assert mapped["pic1.pay"]["source"] == fresh["pic1.pay"]["source"]
    assert ps_actions._mapping_preview_text(mapped["pic1.pay"], ws) == fresh["pic1.pay"]["text"]
    assert mapped["pic1.value"]["source"] == "Z99"  # the artist's pin wins


def test_text_layer_matches_png_width_and_lists_fonts_truthfully():
    """Photoshop re-lays a layer out on edit: Metrics kerning (as ps_text kerns), tracking that makes its
    fractional widths equal Pillow's, and no FontSet entry with the wrong font type."""
    font = png_builder._load_font(ImageFont, "Arial", 30)
    rec = recorder.TextRecord(font, (255, 255, 255), "center")
    line = recorder.TextLine(100.0)
    text = "All wins pay left to right on adjacent reels"
    line.runs.append(recorder.TextRun(text, (255, 255, 255), 50.0, font.getlength(text)))
    rec.lines.append(line)
    rec.box = (0.0, 1000.0)
    _text, spans, _starts = document.text_spans(rec)
    exact = document._exact_length(font, text)
    tracking = spans[0][3]
    assert abs(exact + tracking / 1000.0 * 30 * len(text) - font.getlength(text)) < 0.03 * len(text)
    layer = document.text_layer(rec, "t")
    assert layer.style_run_auto_kerning(0) is True
    ps = fontnames.postscript_name_for_font(font)
    names = [layer.font_postscript_name(i) for i in range(layer.font_count)]
    assert names.count(ps) == 1


def test_multiline_text_has_one_paragraph_run_per_line():
    """Photoshop's own text update merges lines sharing one paragraph run."""
    font = png_builder._load_font(ImageFont, "Arial", 30)
    rec = recorder.TextRecord(font, (255, 255, 255), "center")
    rec.box = (0.0, 400.0)
    for i, t in enumerate(["150", "50", "10", "5"]):
        line = recorder.TextLine(100.0 + i * 36)
        line.runs.append(recorder.TextRun(t, (255, 255, 255), 180, font.getlength(t)))
        rec.lines.append(line)
    layer = document.text_layer(rec, "pays")
    assert layer.paragraph_run_count == 4
    assert list(layer.paragraph_run_lengths()) == [4, 3, 3, 2]


def test_fix_text_layers_script_is_written_beside_the_psd(tmp_path):
    from ps_autotypesetter.psd_writer import photoshop_finish

    psd = tmp_path / "Game – Paytable.psd"
    psd.write_bytes(b"8BPS")
    js = photoshop_finish.write_fix_script(str(psd))
    assert js == str(tmp_path / "Game – Paytable - Fix text layers.jsx")
    body = open(js, encoding="utf-8-sig").read()
    assert "#target photoshop" in body and "__pshAdoptText(doc)" in body
    assert r'"Game \u2013 Paytable.psd"' in body         # the PSD it opens when none is open (ASCII-escaped)
    assert "__NAME__" not in body and "__PATH__" not in body
    photoshop_finish.remove_fix_script(str(psd))
    assert not os.path.exists(js)


def test_build_writes_photoshop_text_block_and_numbers_layers(tmp_path):
    """Without Photoshop's document text block (Txt2) every text layer opens as legacy
    text (warning triangle, update prompt). The writer generates it; each layer's
    TextIndex must point at its own entry."""
    from ps_autotypesetter.psd_writer import txt2

    excel = _workbook(str(tmp_path / "w.xlsx"), {"Rules": [["Game Rules"], ["All wins pay left to right."],
                                                             ["Malfunction voids all pays."]]})
    path, _notes = _build(tmp_path, excel)
    assert txt2.has_block(path)
    psd = psd_tools.PSDImage.open(path)
    indexes, texts = [], []
    for layer in _text_layers(psd):
        block = [b for k, b in layer._record.tagged_blocks.items() if str(k).endswith("TYPE_TOOL_OBJECT_SETTING")][0]
        indexes.append(block.data.text_data[b"TextIndex"].value)
        texts.append(str(block.data.text_data[b"Txt "].value).rstrip("\x00"))
    assert indexes == list(range(len(indexes)))
    raw = open(path, "rb").read()
    start = raw.find(b"8BIMTxt2")
    length = int.from_bytes(raw[start + 8:start + 12], "big")
    assert length % 2 == 0
    stories = txt2.parse(raw[start + 12:start + 12 + length])[1][1]
    assert [s[0][0].rstrip("\r") for s in stories] == texts        # entry i is layer i's text
    assert all(2 not in s[1] for s in stories)                     # Photoshop lays glyphs out itself


def test_txt2_class_tag_leads_its_dictionary():
    """Photoshop crashes reading a dictionary whose /99 class tag is not first."""
    from ps_autotypesetter.psd_writer import txt2

    out = txt2.dump({1: {0: {0: 1}, 99: txt2.Name("SimplePaint")}})
    assert out.index(b"/99 /SimplePaint") < out.index(b"/0 << /0 1 >>")
    assert txt2.parse(out) == {1: {99: "SimplePaint", 0: {0: 1}}}
