"""Selected text styled from the top bar: one exact occurrence ("nth"), stacked rules, letter
spacing and a strip behind the words — in text_styles, the PNG build and the PSD record."""
from PIL import Image, ImageDraw, ImageFont

from ps_autotypesetter import png_builder as pb
from ps_autotypesetter import text_styles as ts
from ps_autotypesetter.psd_writer import recorder

ROW = ("<RICH> with one or more <BAG> awards Extra Spins feature. <RICH> with one or more <GREEN> "
       "awards Extra Properties feature. <RICH> with one or more <RED> awards Extra Houses feature. One or more")


def _rule(row, phrase, after, **style):
    """The rule the top bar saves for `phrase` selected right after `after` in `row`."""
    start = row.index(after + phrase) + len(after)
    text, nth = ts.nth_of(row, start, start + len(phrase))
    return dict({"kind": "word", "scope": "row", "sheet": "S", "row_text": row, "text": text, "nth": nth,
                 "whole_word": False}, **style)


def _styled(rules, row, piece):
    with ts.active(rules, "S"), ts.row(row):
        return [(seg, st) for seg, st in ts.word_runs(piece) if st]


def test_only_the_selected_occurrence_is_styled():
    rule = _rule(ROW, "feature.", "Houses ", color="#ff0000")
    assert rule["nth"] == 2
    assert _styled([rule], ROW, " awards Extra Spins feature. ") == []
    assert [s for s, _ in _styled([rule], ROW, " awards Extra Houses feature. One or more")] == ["feature."]


def test_wrapping_never_moves_the_style():
    rule = _rule(ROW, "feature.", "Houses ", color="#ff0000")
    assert [s for s, _ in _styled([rule], ROW, "feature. One or more")] == ["feature."]   # a line starting with it
    assert _styled([rule], ROW, "awards Extra Houses") == []
    # a justified line drawn word by word: the word knows which line it is in
    line = " awards Extra Houses feature. One or more"
    with ts.active([rule], "S"), ts.row(ROW), ts.within(line, line.index("feature.")):
        assert ts.word_runs("feature.")[0][1] is not None


def test_the_same_words_between_icons_style_only_the_selected_copy():
    """" with one or more " sits between icons three times in this row: selecting the 2nd "one"
    must style that one only — through the piece's own place in the row, not the first match."""
    second = ROW.index("<RICH> with one", ROW.index("<RICH> with one") + 1)
    rule = _rule(ROW[:second + 20], "one", ROW[second - 10:second] + "<RICH> with ", color="#ffdd00")
    rule["row_text"] = ROW
    assert rule["nth"] == 1
    styled = []
    with ts.active([rule], "S"), ts.row(ROW):
        for kind, value in pb._split_inline(ROW):            # the pieces as png_builder cuts them
            runs = [s for s, st in ts.word_runs(value) if st] if kind == "text" else []
            if runs:
                styled.append((value.src_off, runs))
    assert styled == [(second + len("<RICH> "), ["one"])]    # the 2nd copy only


def test_the_row_bar_styles_every_piece_of_its_row():
    """The Row bar saves one exact rule spanning the whole row: every piece between icons gets it."""
    rule = {"kind": "word", "scope": "row", "sheet": "S", "row_text": ROW, "text": ROW, "nth": 0, "color": "#7fffd4"}
    with ts.active([rule], "S"), ts.row(ROW):
        pieces = [v for k, v in pb._split_inline(ROW) if k == "text"]
        assert pieces and all(all(st for s, st in ts.word_runs(v) if s.strip()) for v in pieces)
    with ts.active([rule], "S"), ts.row(ROW.replace("Houses", "Hotels")):   # another row: untouched
        assert all(st is None for v in pieces for _s, st in ts.word_runs(v))


def test_a_line_strip_runs_on_behind_its_icons(tmp_path):
    """A strip behind a whole line (Row bar, This line): no gap where an icon sits between its words."""
    Image.new("RGBA", (40, 40), (0, 0, 0, 0)).save(tmp_path / "RICH.png")     # a see-through icon
    text = "awards Extra <RICH> in a spin without"
    rule = {"kind": "word", "scope": "row", "sheet": "S", "row_text": text, "text": text, "nth": 0,
            "bg": "#0000ff", "bg_opacity": 1}
    img = Image.new("RGBA", (1000, 100), (0, 0, 0, 255))
    font = pb._load_font(ImageFont, "Arial", 40)
    with ts.active([rule], "S"), ts.row(text):
        pb._draw_inline(img, ImageDraw.Draw(img), Image, text, 10, 20, font, (255, 255, 255, 255), 980,
                        str(tmp_path), {}, 40, align="left")
    font_w = pb._advance(font, "awards Extra")
    mid_x = int(10 + font_w + 20)                                            # the middle of the icon
    column = [img.getpixel((mid_x, y))[:3] for y in range(img.height)]
    assert (0, 0, 255) in column


def test_a_line_that_lost_its_origin_is_found_by_its_icons():
    rule = dict(_rule(ROW, "or more <GREEN> awards", "with one "), color="#ff0000")
    line = ROW[ROW.index("feature. <RICH> with one or more <GREEN>"):][:70]   # plain str: no origin
    piece = pb._split_inline(line)[2][1]                       # " with one or more " of THIS line
    assert str(piece).strip() == "with one or more"
    with ts.active([dict(rule, text="one", nth=1)], "S"), ts.row(ROW):
        assert [s for s, st in ts.word_runs(piece) if st] == ["one"]
    with ts.active([dict(rule, text="one", nth=0)], "S"), ts.row(ROW):
        assert [s for s, st in ts.word_runs(piece) if st] == []


def test_a_selection_across_words_styles_the_spaces_between():
    rule = _rule(ROW, "Extra Houses feature.", "awards ", size=150)
    assert [s for s, _ in _styled([rule], ROW, " awards Extra Houses feature. One")] == ["Extra Houses feature."]


def test_overlapping_selections_add_up_later_last():
    big = _rule(ROW, "Extra Houses feature.", "awards ", size=150)
    red = _rule(ROW, "feature.", "Houses ", color="#ff0000")
    runs = _styled([big, red, {"kind": "word", "text": "One", "bold": True}], ROW, " awards Extra Houses feature. One")
    looks = {seg: (st["size"], st["rgb"], st["bold"]) for seg, st in runs}
    assert looks == {"Extra Houses ": (150.0, None, False), "feature.": (150.0, (255, 0, 0), False), "One": (None, None, True)}


def test_text_changed_in_excel_the_occurrence_is_gone_not_moved():
    rule = _rule(ROW, "feature.", "Houses ", color="#ff0000")
    shorter = ROW.split(" <RICH> with one or more <RED>")[0]                # the 3rd feature. was deleted
    rule["row_text"] = shorter
    assert _styled([rule], shorter, shorter) == []


def test_plain_word_rules_are_unchanged():
    rules = [{"kind": "word", "text": "Extra", "color": "#00ff00"}]
    with ts.active(rules, "S"), ts.row(ROW):
        assert [s for s, st in ts.word_runs(ROW) if st] == ["Extra", "Extra", "Extra"]


def _draw(rules, text, record=False):
    img = Image.new("RGBA", (1000, 100), (0, 0, 0, 255))
    font = pb._load_font(ImageFont, "Arial", 40)
    rec = recorder.LayerRecorder() if record else None
    if rec:
        rec.register_page(img, None)
    ctx = rec.recording() if rec else _null()
    with ctx, ts.active(rules, "S"), ts.row(text):
        pb._draw_inline(img, ImageDraw.Draw(img), Image, text, 10, 20, font, (255, 255, 255, 255), 980, "", {}, 40, align="left")
    return img, (rec.page_for(img) if rec else None)


class _null:
    def __enter__(self):
        return None

    def __exit__(self, *a):
        return False


def _ink_right(img):
    return img.convert("L").point(lambda v: 255 if v > 200 else 0).getbbox()[2]


def test_letter_spacing_of_a_selection_widens_just_it():
    text = "Win FREE spins now and FREE games"
    plain, _ = _draw([], text)
    rule = _rule(text, "FREE", "Win ", tracking=400)
    wide, _ = _draw([rule], text)
    assert _ink_right(wide) - _ink_right(plain) > 30                 # 4 letters x 0.4 em x 40px = 64px further
    font = pb._load_font(ImageFont, "Arial", 40)
    with ts.active([rule], "S"), ts.row(text):
        assert abs(pb._styled_width(None, text, font) - pb._advance(font, text) - 4 * 16) < 1.5


def test_canvas_run_boxes_measure_a_repeated_word_with_its_own_style():
    """The live canvas places runs where the server measured them: the 3rd "feature." (a word that is
    in the row three times) must be measured with its own size and spacing, not as a plain copy."""
    text = "awards Extra Spins feature. awards Extra Houses feature. One or more"
    rule = _rule(text, "feature.", "Houses ", tracking=300, size=130)
    font = pb._load_font(ImageFont, "Arial", 40)
    img = Image.new("RGBA", (10, 10))
    with ts.active([rule], "S"), ts.row(text):
        _w, _h, runs = pb._measure_inline_boxes(ImageDraw.Draw(img), Image, text, font, "", {}, 40)
    styled = [r for r in runs if r.get("style")]
    assert [r["text"] for r in styled] == ["feature."]
    big = pb._styled_font(font, {"size": 130.0})
    from ps_autotypesetter import ps_text

    with ps_text.tracking(300):
        assert abs(styled[0]["w"] - pb._advance(big, "feature.")) < 0.5
    following = runs[runs.index(styled[0]) + 1]
    assert abs(following["x"] - (styled[0]["x"] + styled[0]["w"])) < 0.01   # "One or more" starts after it


def test_a_strip_is_painted_behind_the_selection_only():
    text = "Win FREE spins now and FREE games"
    rule = _rule(text, "FREE", "Win ", bg="#0000ff", bg_opacity=1)
    img, _ = _draw([rule], text)
    blue = [(x, y) for y in range(img.height) for x in range(img.width) if img.getpixel((x, y))[:3] == (0, 0, 255)]
    assert blue, "no strip painted"
    xs = [x for x, _ in blue]
    plain_w = pb._advance(pb._load_font(ImageFont, "Arial", 40), "Win ")
    assert min(xs) < 10 + plain_w and max(xs) < 10 + plain_w + 140   # behind the first FREE, not the second


def test_psd_gets_the_strip_as_a_shape_and_the_spacing_as_tracking():
    text = "Win FREE spins now"
    rule = _rule(text, "FREE", "Win ", tracking=300, bg="#00ff00")
    _img, page = _draw([rule], text, record=True)
    assert any("FREE" in getattr(s, "name", "") for s in page.shapes)
    runs = [r for t in page.texts for ln in t.lines for r in ln.runs]
    free = next(r for r in runs if r.text == "FREE")
    font = pb._load_font(ImageFont, "Arial", 40)
    assert free.advance > pb._advance(font, "FREE") + 40               # measured with its own spacing
    # the PSD text layer: "FREE" gets Photoshop tracking 300, the rest of the line none
    from ps_autotypesetter.psd_writer import document

    text, spans, _starts = document.text_spans(page.texts[0])
    at = text.index("FREE")
    free_spans = [s for s in spans if s[0] < at + 4 and s[0] + s[1] > at]
    other = [s for s in spans if s[0] + s[1] <= at or s[0] >= at + 4]
    assert free_spans and all(abs(s[3] - 300) <= 1 for s in free_spans)
    assert other and all(abs(s[3]) <= 1 for s in other)
