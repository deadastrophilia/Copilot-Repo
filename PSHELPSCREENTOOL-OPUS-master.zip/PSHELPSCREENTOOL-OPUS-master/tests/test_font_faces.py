"""The page font loader picks the face a font name asks for, not the first file of the family."""
from ps_autotypesetter import png_builder as pb

POPPINS = ["Poppins-Bold.ttf", "Poppins-Medium.ttf", "Poppins-Regular.ttf", "Poppins-SemiBold.ttf", "Poppins-Italic.ttf"]


def _pick(name, bold=False, italic=False):
    _base, _compact, _direct, flags = pb._font_candidates(name, bold, italic)
    return sorted(POPPINS, key=lambda f: pb._face_mismatch(f, flags, name))[0]


def test_plain_family_name_is_the_regular_face():
    assert _pick("Poppins") == "Poppins-Regular.ttf"          # Bold sorts first; it used to win
    assert _pick("Poppins Regular") == "Poppins-Regular.ttf"


def test_named_and_flagged_weights():
    assert _pick("Poppins Bold") == "Poppins-Bold.ttf"
    assert _pick("Poppins", bold=True) == "Poppins-Bold.ttf"
    assert _pick("Poppins SemiBold") == "Poppins-SemiBold.ttf"
    assert _pick("Poppins Medium") == "Poppins-Medium.ttf"
    assert _pick("Poppins Italic") == "Poppins-Italic.ttf"
