"""Table designs (table_designs.py): a look per table, Excel's own colours, coloured rules."""
import os

import pytest
from openpyxl import Workbook, load_workbook
from openpyxl.formatting.rule import CellIsRule
from openpyxl.styles import PatternFill

from ps_autotypesetter import png_builder as pb
from ps_autotypesetter import table_designs as td


def test_a_tables_own_design_wins_over_the_default_and_unknown_ones_fall_back():
    ts = {"default_design": "gold", "designs": {"Rules|a | b": "excel", "Rules|c": "nope"}}
    assert td.design_for(ts, "Rules|a | b") == "excel"
    assert td.design_for(ts, "Rules|c") == "gold"                      # unknown design: the default
    assert td.design_for({}, "x") == "current"                          # nothing chosen: the Tables settings


def test_a_design_sets_colours_only_never_sizes():
    merged = td.apply({"table_body_font_size": 30, "header_bg_rgb": "#000000"}, "midnight")
    assert merged["header_bg_rgb"] == "#22305A" and merged["table_body_font_size"] == 30
    assert all(k in td.DESIGN_KEYS for d in td.BUILTINS.values() for k in d["style"])


def test_saving_the_current_colours_as_a_design():
    ts = {"header_bg_rgb": "#112233", "stroke_width": 2, "table_body_font_size": 28,
          "custom_designs": {"my_x": {"name": "X", "style": {"header_bg_rgb": "#ABCDEF"}}}}
    assert td.style_from_settings(ts) == {"header_bg_rgb": "#112233", "stroke_width": 2}
    assert td.apply(ts, "my_x")["header_bg_rgb"] == "#ABCDEF"


def test_conditional_formatting_colours_are_read():
    wb = Workbook()
    ws = wb.active
    ws["A1"], ws["A2"] = " ", ""
    ws.conditional_formatting.add("A1:A2", CellIsRule(operator="equal", formula=['" "'],
                                                      fill=PatternFill(bgColor="FFFFC7CE")))
    assert td.conditional_fill(ws, ws["A1"]) == (255, 199, 206)
    assert td.conditional_fill(ws, ws["A2"]) is None


def test_like_excel_paints_unfilled_cells_white_and_keeps_excel_fills():
    wb = Workbook()
    ws = wb.active
    ws.title = "Rules"
    ws["B2"], ws["C2"] = "Train", "Prize"
    ws["B3"], ws["C3"] = "Red", "10"
    ws["C3"].fill = PatternFill("solid", fgColor="FFFFFF00")
    table = {"start_row": 2, "end_row": 3, "min_col": 2, "max_col": 3, "header_row_idx": 2}
    ts = {"designs": {td.table_key("Rules", "Train | Prize"): "excel"}}
    assert pb._table_header_text(ws, table) == "Train | Prize"
    key = td.table_key("Rules", pb._table_header_text(ws, table))
    table.update(design_key=key, design=td.design_for(ts, key), use_excel_fill_colors=True, excel_blank_white=True)
    assert pb._cell_fill_for_table(ws, table, 3, 3, "body", ts) == (255, 255, 0)
    assert pb._cell_fill_for_table(ws, table, 3, 2, "body", ts) == (255, 255, 255)


def test_thunder_empires_coloured_win_line_cells():
    path = os.path.join(os.path.dirname(__file__), "..", "ExcelFileForReference", "ThunderEmpire_MongolianEmpress_AGR_HHRE.xlsx")
    if not os.path.isfile(path):
        pytest.skip("reference AGR not here")
    ws = load_workbook(path)["WIN LINES 4 (5 lines)"]
    assert td.conditional_fill(ws, ws["D7"]) == (255, 199, 206)          # the " " cells Excel paints
    assert td.conditional_fill(ws, ws["D6"]) is None
