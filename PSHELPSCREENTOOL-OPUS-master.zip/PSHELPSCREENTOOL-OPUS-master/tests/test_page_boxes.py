"""Canvas boxes (page_boxes.py): the paragraph's own box, gaps around rows made headings, and text
split off into boxes of its own — laid out by layout_engine (the preview and the text-page builds)."""
import pytest
from openpyxl import Workbook
from openpyxl.styles import Font

from ps_autotypesetter import page_boxes, row_roles
from ps_autotypesetter.layout_engine import build_normal_page_layouts


@pytest.fixture(autouse=True)
def _clean():
    page_boxes.set_all({})
    row_roles.set_all({})
    yield
    page_boxes.set_all({})
    row_roles.set_all({})


def _sheet(rows=None):
    wb = Workbook()
    ws = wb.active
    ws.title = "P"
    ws.cell(row=1, column=1, value="GAME RULES").font = Font(bold=True)
    for text in rows or ["First row of the rules", "Second row says more", "Third row ends it"]:
        ws.append([text])
    return ws


def _layouts(ws):
    return build_normal_page_layouts(
        ws, "P", canvas_w=1920, canvas_h=1080, margin_x=100,
        h_font="Arial", h_size=72, h_icon_h=48, h_rgb=(255, 80, 80),
        b_font="Arial", b_size=30, b_icon_h=24, b_rgb=(255, 255, 255),
        line_spacing=4, para_spacing=12, continued_gap=15, line_gap=30,
        heading_top_margin=120, heading_to_body_gap=40, bottom_margin=80,
        page_max_row=ws.max_row, page_max_col=12)


def _rows(layout):
    return {e.meta["row"]: e for e in layout.elements if e.meta.get("kind") == "body"}


def test_paragraph_box_moves_the_body_not_the_heading():
    ws = _sheet()
    plain = _layouts(ws)[0]
    page_boxes.set_all({"body_boxes": {"P": {"left": 400, "right": 1000, "top": 500}}})
    boxed = _layouts(ws)[0]
    head0, head1 = plain.elements[0], boxed.elements[0]
    assert (head1.x, head1.width) == (head0.x, head0.width)
    first = _rows(boxed)[2]
    assert (first.x, first.width) == (400, 600)
    assert first.meta["ink_top"] == pytest.approx(500, abs=1)
    assert boxed.safe_area["body"]["left"] == 400


def test_paragraph_bottom_sends_text_to_a_continued_page():
    ws = _sheet([f"Rule number {i} of a long page of rules" for i in range(8)])
    assert len(_layouts(ws)) == 1
    page_boxes.set_all({"body_boxes": {"P": {"bottom": 450}}})
    pages = _layouts(ws)
    assert len(pages) > 1
    assert all(e.y + e.height <= 460 for e in pages[0].elements if e.meta.get("kind") == "body")


def test_a_row_made_a_heading_gets_the_page_headings_gaps():
    ws = _sheet()
    plain = _rows(_layouts(ws)[0])
    row_roles.set_all({"row_roles": {"P": {"row:3": "heading"}}})
    rows = _rows(_layouts(ws)[0])
    head = rows[3]
    assert head.meta["gaps"] == {"above": 40, "below": 40, "default": 40}
    # 40 px from the row above's ink to its ink, and 40 px below it
    assert head.meta["ink_top"] - rows[2].meta["ink_bottom"] == pytest.approx(40, abs=1)
    assert rows[4].meta["ink_top"] - head.meta["ink_bottom"] == pytest.approx(40, abs=1)
    assert rows[2].y == plain[2].y                                      # rows above it don't move

    page_boxes.set_all({"row_gaps": {"P": {"row:3": {"above": 10, "below": 90}}}})
    rows = _rows(_layouts(ws)[0])
    assert rows[3].meta["ink_top"] - rows[2].meta["ink_bottom"] == pytest.approx(10, abs=1)
    assert rows[4].meta["ink_top"] - rows[3].meta["ink_bottom"] == pytest.approx(90, abs=1)


def test_split_words_leave_their_row_for_a_box():
    ws = _sheet()
    page_boxes.set_all({"text_boxes": {"P": [{"id": "b1", "parts": [{"row": 3, "text": "says more"}],
                                                "page": 0, "x": 1300, "y": 700, "w": 400, "h": 80,
                                                "size": 44, "rgb": "#FFD000", "bold": True}]}})
    page = _layouts(ws)[0]
    assert _rows(page)[3].text == "Second row"
    assert _rows(page)[3].meta["boxed"] is True
    box = next(e for e in page.elements if e.meta.get("kind") == "box")
    assert (box.x, box.width) == (1300, 400) and box.meta["ink_top"] == pytest.approx(700, abs=1)   # its text starts at the box's top
    assert box.meta["frame"]["x"] == 1300 and box.meta["frame"]["y"] == 700
    assert box.wrapped_lines == ["says more"]
    assert (box.size, box.bold, tuple(box.color)) == (44, True, (255, 208, 0))


def test_a_box_whose_words_are_gone_gives_them_back():
    ws = _sheet()
    page_boxes.set_all({"text_boxes": {"P": [{"id": "b1", "parts": [{"row": 3, "text": "words not there"}],
                                                "page": 0, "x": 100, "y": 700, "w": 400}]}})
    page = _layouts(ws)[0]
    assert not [e for e in page.elements if e.meta.get("kind") == "box"]
    assert _rows(page)[3].text == "Second row says more"
    assert page.source["missing_boxes"] == ["b1"]


def test_box_words_match_through_icon_size_tags_and_line_breaks():
    assert page_boxes.find("one or more <WILD~140> awards", "more <WILD> awards") == (7, 29)
    assert page_boxes.find("one or\nmore", "or more") == (4, 11)
    assert page_boxes.take_out("a b c d", [(2, 5)]) == "a d"


def test_the_psd_build_has_the_box_as_one_text_layer_where_the_canvas_put_it(tmp_path):
    from psd_tools import PSDImage

    from ps_autotypesetter.psd_writer import build as psd_build
    from ps_autotypesetter.ui_web import engine_api

    wb = Workbook()
    ws = wb.active
    ws.title = "Rules"
    ws.cell(row=1, column=1, value="GAME RULES").font = Font(bold=True)
    ws.append(["All wins pay left to right on adjacent reels starting from the leftmost reel"])
    ws.append(["Malfunction voids all pays and plays"])
    excel = str(tmp_path / "Game.xlsx")
    wb.save(excel)
    ds = {"text_boxes": {"Rules": [{"id": "b1", "parts": [{"row": 2, "text": "starting from the leftmost reel"}],
                                    "page": 0, "x": 200, "y": 520, "w": 700, "h": 60}]},
          "body_boxes": {"Rules": {"left": 300, "right": 1000}},
          "row_roles": {"Rules": {"row:3": "heading"}}}
    cfg = {"excel_path": excel, "icon_folder": "", "bg_path": "", "bg_source": "color", "bg_color": "#102040",
           "output_dir": str(tmp_path / "out"), "output_name": "Game", "render_all_pages": True,
           "c_width": 1280, "c_height": 720, "dynamic_settings": ds}
    psd = psd_build.build_psd(**engine_api._build_kwargs(cfg), output_format="PSD")
    texts = [l for l in PSDImage.open(psd).descendants() if l.kind == "type"]
    box = [l for l in texts if l.name.startswith("Text box")]
    assert len(box) == 1 and "starting from the leftmost reel" in " ".join(box[0].text.split())
    assert abs(box[0].top - 520) < 30 and box[0].left >= 200
    row = next(l for l in texts if l.text.strip().startswith("All wins pay"))
    assert "leftmost" not in row.text                                  # the words left their row
    assert row.left >= 300 - 2 and row.right <= 1000 + 2              # inside the paragraph's box


def test_a_box_and_the_row_its_words_left_are_edited_like_any_text():
    from ps_autotypesetter import text_edits

    ws = _sheet()
    page_boxes.set_all({"text_boxes": {"P": [{"id": "b1", "parts": [{"row": 3, "text": "says more"}],
                                                "page": 0, "x": 1300, "y": 700, "w": 400}]}})
    text_edits.set_all({"P": {"box:b1": {"from": "says more", "to": "says\nmuch more"},
                              "row:3": {"from": "Second row", "to": "The second row"}}})
    try:
        page = _layouts(ws)[0]
        box = [e for e in page.elements if e.meta.get("kind") == "box"]
        assert [e.wrapped_lines[0] for e in box] == ["says", "much more"] and box[0].text == "says\nmuch more"
        assert _rows(page)[3].text == "The second row"
        # the Excel changes the box's words: the box goes, its row gets them back (its edit no longer applies)
        ws.cell(row=3, column=1, value="Second row says less")
        page = _layouts(ws)[0]
        assert not [e for e in page.elements if e.meta.get("kind") == "box"]
        assert _rows(page)[3].text == "Second row says less"
    finally:
        text_edits.set_all({})


def test_one_drawn_line_made_a_heading_leaves_the_rest_of_its_row():
    ws = _sheet(["Intro words of a row", "Prizes displayed are : 5 or more Credits", "Last row"])
    row_roles.set_all({"row_roles": {"P": {"row:3|5 or more Credits": "heading"}}})
    lines = [e for e in _layouts(ws)[0].elements if e.meta.get("kind") == "body" and e.meta["row"] == 3]
    assert [(e.wrapped_lines[0], e.meta["role"]) for e in lines] == [("Prizes displayed are :", ""), ("5 or more Credits", "heading")]
    assert all(e.text == "Prizes displayed are : 5 or more Credits" for e in lines)      # still one row to edit
    assert lines[1].meta["gaps"]["above"] == 40                                          # a heading's gaps
    # the whole row a heading, one of its lines normal text again
    row_roles.set_all({"row_roles": {"P": {"row:3": "heading", "row:3|5 or more Credits": "body"}}})
    lines = [e for e in _layouts(ws)[0].elements if e.meta.get("kind") == "body" and e.meta["row"] == 3]
    assert [e.meta["role"] for e in lines] == ["heading", ""]


def test_rows_starting_with_the_same_words_share_a_style():
    from ps_autotypesetter import text_styles as ts

    rule = {"kind": "word", "scope": "starts", "starts": "Prizes displayed during Bought games", "text": "x",
            "whole_row": True, "color": "#ff0000"}
    num = {"kind": "word", "scope": "starts", "starts": "5 or more Credits, Mini,", "text": "y", "whole_row": True, "bold": True}
    with ts.active([rule, num], "P"):
        def look(row):
            with ts.row(row):
                return [(t, (s or {}).get("rgb"), (s or {}).get("bold")) for t, s in ts.word_runs(row) if t.strip()]
        assert look("Prizes displayed during Bought games and Bonus Boost features are :") == [
            ("Prizes displayed during Bought games and Bonus Boost features are :", (255, 0, 0), False)]
        assert look("Prizes displayed during Free games") == [("Prizes displayed during Free games", None, None)]  # 4 of 5
        assert look("25 or more Credits, Mini, Minor or Major")[0][2] is True               # a number for any number
        assert look("25 or less Credits, Mini, Minor or Major")[0][2] is None


@pytest.mark.parametrize("in_box", [False, True])
def test_a_selected_words_layer_style_reaches_the_psd(tmp_path, in_box):
    """The Canvas draws a selection's own layer style; the PSD gives those words a text layer with it
    (a Photoshop text layer has one layer style), in place, the paragraph keeping their room — in a
    text box too (its lines are one layer, those words stay apart)."""
    from psd_tools import PSDImage

    from ps_autotypesetter.psd_writer import build as psd_build
    from ps_autotypesetter.psd_writer import effects
    from ps_autotypesetter.ui_web import engine_api

    wb = Workbook()
    ws = wb.active
    ws.title = "Rules"
    ws.cell(row=1, column=1, value="GAME RULES").font = Font(bold=True)
    row = "at the start of each spin as shown on the screen."
    ws.append([row])
    excel = str(tmp_path / "Game.xlsx")
    wb.save(excel)
    hex4 = "".join("%04x" % b for b in effects.params_payload({"stroke_enabled": True, "stroke_size": 4})[4:])
    ds = {"layer_style_library": {"Outline": {"captured_effects_hex": hex4}},
          "text_style_rules": [{"kind": "word", "scope": "row", "sheet": "Rules", "row_text": row,
                                "text": "screen.", "nth": 0, "whole_word": False, "fx": "Outline"}]}
    if in_box:
        ds["text_boxes"] = {"Rules": [{"id": "b1", "parts": [{"row": 2, "text": row}], "page": 0,
                                       "x": 100, "y": 400, "w": 500, "h": 100}]}
    cfg = {"excel_path": excel, "icon_folder": "", "bg_path": "", "bg_source": "color", "bg_color": "#102040",
           "output_dir": str(tmp_path / "out"), "output_name": "Game", "render_all_pages": True,
           "c_width": 1280, "c_height": 720, "dynamic_settings": ds}
    psd = psd_build.build_psd(**engine_api._build_kwargs(cfg), output_format="PSD")
    texts = {l.text.strip(): l for l in PSDImage.open(psd).descendants() if l.kind == "type"}
    fx = lambda layer: any("OBJECT_BASED_EFFECTS" in str(k) for k in layer.tagged_blocks.keys())  # noqa: E731
    word = texts["screen."]
    assert fx(word)                                                                # its layer style
    rest = next(l for t, l in texts.items() if t.startswith("at the start"))
    assert "screen" not in rest.text and not fx(rest)
    assert rest.left <= word.left and rest.top - 12 <= word.top <= rest.bottom    # where the paragraph left its room


def test_line_height_for_a_row_or_just_some_of_its_lines():
    long = "A very long rule that wraps over several lines of the page because it keeps on going and going " * 3
    ws = _sheet(["First row", long, "Last row"])
    body = lambda: [e for e in _layouts(ws)[0].elements if e.meta.get("kind") == "body"]  # noqa: E731
    plain = body()
    row3 = [e for e in plain if e.meta["row"] == 3]
    assert len(row3) >= 3 and all(e.meta["line_height"] == 30 for e in row3[1:])
    gap = lambda ls, i: ls[i].meta["ink_top"] - ls[i - 1].meta["ink_bottom"]  # noqa: E731
    # only its 2nd drawn line: 80 px above it, the others as they were
    page_boxes.set_all({"row_gaps": {"P": {"row:3": {"lines": {"2": 80}}}}})
    ls = [e for e in body() if e.meta["row"] == 3]
    assert gap(ls, 1) == pytest.approx(80, abs=1) and gap(ls, 2) == pytest.approx(30, abs=1)
    assert ls[1].meta["line_height_set"] and not ls[2].meta["line_height_set"]
    # the whole row: every line of it, and the gap above its first line
    page_boxes.set_all({"row_gaps": {"P": {"row:3": {"line": 50}}}})
    all_ = body()
    ls = [e for e in all_ if e.meta["row"] == 3]
    assert all(gap(ls, i) == pytest.approx(50, abs=1) for i in range(1, len(ls)))
    first2 = [e for e in all_ if e.meta["row"] == 2][-1]
    assert ls[0].meta["ink_top"] - first2.meta["ink_bottom"] == pytest.approx(50, abs=1)


def test_a_text_box_has_a_line_height_of_its_own():
    ws = _sheet()
    conf = {"id": "b1", "parts": [{"row": 3, "text": "says more"}], "page": 0, "x": 100, "y": 700, "w": 60}
    gap = lambda ls: ls[1].meta["ink_top"] - ls[0].meta["ink_bottom"]  # noqa: E731
    lines = lambda: [e for e in _layouts(ws)[0].elements if e.meta.get("kind") == "box"]  # noqa: E731
    page_boxes.set_all({"text_boxes": {"P": [conf]}})
    plain = lines()
    assert len(plain) > 1                                                # narrow: a line per word
    assert gap(plain) == pytest.approx(30, abs=1) and not plain[0].meta["line_height_box_set"]
    page_boxes.set_all({"text_boxes": {"P": [dict(conf, line=72)]}})
    tall = lines()
    assert gap(tall) == pytest.approx(72, abs=1) and tall[0].meta["line_height_box_set"]
    assert tall[0].meta["frame"]["h"] - plain[0].meta["frame"]["h"] == pytest.approx(42 * (len(plain) - 1), abs=2)


def test_a_text_box_takes_everything_a_paragraph_row_does():
    """A box is laid out like a row of the paragraph (its key "box:<id>"): a line of it made a heading,
    the line height of one of its lines, justify — the same settings, the same code."""
    ws = _sheet(["First row", "Second row says more and more words to wrap", "Third row"])
    box = {"id": "b1", "parts": [{"row": 3, "text": "says more and more words to wrap"}], "page": 0, "x": 100, "y": 600, "w": 300}
    page_boxes.set_all({"text_boxes": {"P": [box]}})
    lines = lambda: [e for e in _layouts(ws)[0].elements if e.meta.get("kind") == "box"]  # noqa: E731
    plain = lines()
    assert len(plain) >= 2 and all(e.meta["key"] == "box:b1" and e.meta["role"] == "" for e in plain)
    # a line of the box made a heading: the heading's look, the rest stays the box's
    row_roles.set_all({"row_roles": {"P": {"box:b1|says more": "heading"}}})
    made = lines()
    assert made[0].meta["role"] == "heading" and made[0].size == 72 and made[0].bold
    assert made[-1].meta["role"] == "" and made[-1].size == 30                     # the box's own text after it
    # the whole box a subheading
    row_roles.set_all({"row_roles": {"P": {"box:b1": "subheading"}}})
    assert {e.meta["role"] for e in lines()} == {"subheading"}
    row_roles.set_all({})
    # the line height of its 2nd line only
    page_boxes.set_all({"text_boxes": {"P": [box]}, "row_gaps": {"P": {"box:b1": {"lines": {"2": 90}}}}})
    ls = lines()
    assert ls[1].meta["ink_top"] - ls[0].meta["ink_bottom"] == pytest.approx(90, abs=1) and ls[1].meta["line_height_set"]


def test_a_build_gives_the_live_settings_back():
    """A page-picture build loads its own (maybe older) row roles / boxes / text edits into the shared
    settings; build_pngs_only takes a snapshot first and puts it back after, so the Canvas never lays
    out with a background build's settings."""
    import inspect

    from ps_autotypesetter import png_builder, text_edits

    live = {"row_roles": {"P": {"row:3": "heading"}}, "row_gaps": {"P": {"row:2": {"line": 50}}}}
    row_roles.set_all(live)
    page_boxes.set_all(live)
    text_edits.set_all({"P": {"row:2": {"from": "a", "to": "b"}}})
    try:
        snap = png_builder._settings_snapshot()
        old = {"row_roles": {"P": {"row:2": "heading", "row:2|Some": "body"}}, "row_gaps": {}}
        row_roles.set_all(old)                              # what the build loads
        page_boxes.set_all(old)
        text_edits.set_all({})
        png_builder._settings_restore(snap)
        assert row_roles.role("P", 3) == "heading" and row_roles.role("P", 2) == ""
        assert page_boxes.line_gap("P", 2, 1) == (None, 50.0)
        assert text_edits._EDITS["P"]["row:2"]["to"] == "b"
        src = inspect.getsource(png_builder.build_pngs_only)
        assert "_settings_snapshot()" in src and "_settings_restore(_live_settings, _build_settings)" in src
    finally:
        text_edits.set_all({})


def test_a_deleted_heading_is_not_drawn_and_the_text_moves_up():
    ws = _sheet()
    plain = _layouts(ws)[0]
    page_boxes.set_all({"hidden_parts": {"P": ["heading"]}})
    gone = _layouts(ws)[0]
    assert any(e.meta.get("kind") == "heading" for e in plain.elements)
    assert not any(e.meta.get("kind") == "heading" for e in gone.elements)
    assert _rows(gone)[2].meta["ink_top"] == pytest.approx(120, abs=1)          # where the heading was
    assert _rows(gone)[2].meta["ink_top"] < _rows(plain)[2].meta["ink_top"]
    page_boxes.set_all({})                                                        # brought back
    assert any(e.meta.get("kind") == "heading" for e in _layouts(ws)[0].elements)


def test_a_deleted_continued_line_leaves_the_continued_pages():
    ws = _sheet([f"Rule number {i} of a long page of rules" for i in range(8)])
    page_boxes.set_all({"body_boxes": {"P": {"bottom": 450}}})
    pages = _layouts(ws)
    assert any(e.meta.get("kind") == "continued" for e in pages[1].elements)
    page_boxes.set_all({"body_boxes": {"P": {"bottom": 450}}, "hidden_parts": {"P": ["continued"]}})
    pages = _layouts(ws)
    assert not any(e.meta.get("kind") == "continued" for p in pages for e in p.elements)
    assert any(e.meta.get("kind") == "heading" for e in pages[1].elements)


def test_continued_pages_have_margins_of_their_own():
    ws = _sheet([f"Rule number {i} of a long page of rules" for i in range(8)])
    page_boxes.set_all({"body_boxes": {"P": {"bottom": 450, "cont": {"left": 500, "right": 1100, "top": 600}}}})
    pages = _layouts(ws)
    first, later = _rows(pages[0]), [e for e in pages[1].elements if e.meta.get("kind") == "body"]
    assert all(e.x != 500 for e in first.values())                  # page 1 keeps its own margins
    assert later and all((e.x, e.width) == (500, 600) for e in later)
    assert min(e.meta["ink_top"] for e in later) == pytest.approx(600, abs=1)


def test_a_row_can_be_sent_to_the_next_page_and_back():
    ws = _sheet()
    assert len(_layouts(ws)) == 1
    page_boxes.set_all({"page_breaks": {"P": ["row:3"]}})
    pages = _layouts(ws)
    assert len(pages) == 2
    assert 3 in _rows(pages[1]) and 2 in _rows(pages[0])
    assert any(e.meta.get("kind") == "continued" for e in pages[1].elements)
    page_boxes.set_all({})
    assert len(_layouts(ws)) == 1


def test_the_heading_can_go_from_the_continued_pages_only():
    ws = _sheet([f"Rule number {i} of a long page of rules" for i in range(8)])
    heads = lambda pages: [any(e.meta.get("kind") == "heading" for e in p.elements) for p in pages]
    page_boxes.set_all({"body_boxes": {"P": {"bottom": 450}}, "hidden_parts": {"P": ["heading_cont"]}})
    pages = _layouts(ws)
    assert heads(pages)[0] and not any(heads(pages)[1:])
    page_boxes.set_all({"body_boxes": {"P": {"bottom": 450}}, "hidden_parts": {"P": ["heading_main"]}})
    pages = _layouts(ws)
    assert not heads(pages)[0] and all(heads(pages)[1:])


def test_a_heading_plate_fits_the_heading_and_a_page_can_have_its_own():
    ws = _sheet()
    plate = lambda: [e for e in _layouts(ws)[0].elements if e.meta.get("plate") == "heading"]
    assert not plate()
    page_boxes.set_all({"heading_plate": {"on": True, "color": "#112233", "pad_x": 30, "pad_y": 10}})
    p, = plate()
    head = next(e for e in _layouts(ws)[0].elements if e.meta.get("kind") == "heading")
    assert p.width == pytest.approx(max(head.line_widths) + 60, abs=1)          # fit to the text, not the page
    assert p.width < 1700
    els = _layouts(ws)[0].elements
    assert els.index(next(e for e in els if e.meta.get("plate"))) < els.index(next(e for e in els if e.meta.get("kind") == "heading"))
    page_boxes.set_all({"heading_plate": {"on": True}, "heading_plates": {"P": {"on": False}}})
    assert not plate()                                                           # this page: no plate


def test_a_heading_too_long_for_the_page_shrinks_to_one_line_on_its_own():
    def heading(ws):
        return next(e for e in _layouts(ws)[0].elements if e.meta.get("kind") == "heading")

    short = heading(_sheet())
    assert short.size == 72 and len(short.wrapped_lines) == 1
    ws = _sheet()
    ws.cell(row=1, column=1, value="A VERY LONG PAGE HEADING THAT NEVER FITS ON ONE LINE AT THIS SIZE")
    long_h = heading(ws)
    assert len(long_h.wrapped_lines) == 1 and long_h.size < 72
    assert heading(_sheet()).size == 72                  # the other pages' headings keep their size
