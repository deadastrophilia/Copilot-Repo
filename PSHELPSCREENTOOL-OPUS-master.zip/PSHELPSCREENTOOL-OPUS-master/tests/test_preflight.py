"""Preflight validation — structured, side-effect-free pre-build checks.

``engine_api.preflight`` assembles the facts the scanners already compute into
a single ``{ok, blocking, warnings}`` report so artists see problems BEFORE a
build runs, with actionable ``fix`` text, instead of alien mid-build popups.

Every item is ``{code, message, fix}``. ``ok`` is True only when nothing is
blocking; warnings never block. Sheet presence is validated by NAME only —
row/column dimensions are unreliable under openpyxl read_only, so a real sheet
is never wrongly flagged empty.
"""

import copy
import os

import pytest

from ps_autotypesetter.ui_web import engine_api

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXAMPLE_XLSX = os.path.join(REPO_ROOT, "examples", "paytable.xlsx")

pytestmark = pytest.mark.skipif(
    not os.path.isfile(EXAMPLE_XLSX),
    reason="examples/paytable.xlsx fixture is required",
)


def _codes(items):
    return [i["code"] for i in items]


def _valid_cfg(**over):
    cfg = {"excel_path": EXAMPLE_XLSX, "c_width": 1920, "c_height": 1080}
    cfg.update(over)
    return cfg


def test_preflight_empty_config_blocks():
    """No workbook and no canvas -> two blocking items; not ok."""
    pf = engine_api.preflight({})

    assert pf["ok"] is False
    assert "excel_missing" in _codes(pf["blocking"])
    assert "canvas_invalid" in _codes(pf["blocking"])


def test_preflight_missing_excel_file():
    pf = engine_api.preflight({"excel_path": "X:/does/not/exist.xlsx", "c_width": 1920, "c_height": 1080})

    assert pf["ok"] is False
    assert _codes(pf["blocking"]) == ["excel_not_found"]


def test_preflight_unreadable_excel(tmp_path):
    """A file with an .xlsx name but junk content is a blocking, readable error."""
    bad = tmp_path / "bad.xlsx"
    bad.write_text("this is not a real workbook")
    pf = engine_api.preflight({"excel_path": str(bad), "c_width": 1920, "c_height": 1080})

    assert pf["ok"] is False
    assert "excel_unreadable" in _codes(pf["blocking"])


def test_preflight_bad_canvas():
    pf = engine_api.preflight(_valid_cfg(c_width=0, c_height=0))

    assert pf["ok"] is False
    assert "canvas_invalid" in _codes(pf["blocking"])


def test_preflight_selected_sheet_missing():
    pf = engine_api.preflight(_valid_cfg(selected_sheets=["NoSuchSheet"]))

    assert pf["ok"] is False
    assert "sheet_missing" in _codes(pf["blocking"])


def test_preflight_valid_sheet_not_flagged():
    """A real, conventionally-named sheet is never flagged as missing/empty."""
    pf = engine_api.preflight(_valid_cfg(selected_sheets=["Paytable"]))

    assert pf["ok"] is True
    assert "sheet_missing" not in _codes(pf["blocking"])
    assert "no_sheets" not in _codes(pf["blocking"])


def test_preflight_happy_path_warns_but_does_not_block():
    """Valid workbook + canvas, but no icon folder / output dir -> ok with warnings."""
    pf = engine_api.preflight(_valid_cfg())

    assert pf["ok"] is True
    assert pf["blocking"] == []
    assert "icon_folder_missing" in _codes(pf["warnings"])
    assert "output_dir_missing" in _codes(pf["warnings"])


def test_preflight_unresolved_icons_warn(tmp_path):
    """An icon folder that lacks the workbook's tokens warns (does not block)."""
    icons = tmp_path / "icons"
    icons.mkdir()
    pf = engine_api.preflight(_valid_cfg(icon_folder=str(icons)))

    assert pf["ok"] is True
    assert "icons_unresolved" in _codes(pf["warnings"])
    assert "icon_folder_missing" not in _codes(pf["warnings"])


def test_preflight_items_have_code_message_fix():
    pf = engine_api.preflight({})
    for item in pf["blocking"] + pf["warnings"]:
        assert set(item.keys()) == {"code", "message", "fix"}
        assert item["message"]  # never empty


def test_preflight_is_side_effect_free(tmp_path):
    """preflight only reads — it never mutates cfg nor writes files."""
    cfg = _valid_cfg(output_dir=str(tmp_path))
    snapshot = copy.deepcopy(cfg)

    engine_api.preflight(cfg)

    assert cfg == snapshot  # cfg untouched
    assert list(tmp_path.iterdir()) == []  # nothing written
