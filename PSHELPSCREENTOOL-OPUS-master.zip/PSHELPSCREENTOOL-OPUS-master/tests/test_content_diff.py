"""content_model / content_diff: an AGR read without a PSD, and what changed between two AGRs."""
from openpyxl import Workbook

from ps_autotypesetter import content_diff as cd
from ps_autotypesetter import content_model as cm
from ps_autotypesetter import market_clone as mc


def sheets(**tabs):
    """{name: Sheet} from {name: [[cells of row 1], [cells of row 2], ...]} (column A first)."""
    out = {}
    for name, rows in tabs.items():
        wb = Workbook()
        ws = wb.active
        for r, row in enumerate(rows, start=1):
            for c, value in enumerate(row, start=1):
                if value is not None:
                    ws.cell(r, c, value)
        out[name.replace("_", " ")] = cm.Sheet(name.replace("_", " "), ws)
    return out


PAYTABLE = [["PAYTABLE"], ["<pic1>", 5, 500], [None, 4, 100], ["<pic2>", 5, 250], [None, 4, 50]]
RULES = [["GAME RULES"], ["All wins pay left to right."], ["Malfunction voids all pays and plays."]]


def types(result):
    return [(c["type"], c.get("sheet")) for c in result["changes"]]


def test_the_same_workbook_has_no_changes():
    a = sheets(PAYTABLE=PAYTABLE, GAME_RULES=RULES)
    r = cd.compare(a, sheets(PAYTABLE=PAYTABLE, GAME_RULES=RULES))
    assert r["changes"] == [] and r["summary"] == [] and r["counts"] == {}


def test_a_pay_value_is_a_content_change_of_that_cell():
    b_rows = [row[:] for row in PAYTABLE]
    b_rows[3][2] = 300
    r = cd.compare(sheets(PAYTABLE=PAYTABLE), sheets(PAYTABLE=b_rows))
    (c,) = r["changes"]
    assert (c["type"], c["category"], c["what"]) == ("cell_changed", cd.CONTENT, "value")
    assert (c["row_a"], c["row_b"], c["col"], c["old"], c["new"]) == (4, 4, 3, "250", "300")
    assert r["summary"] == ["PAYTABLE: 1 value changed"]


def test_a_row_added_in_the_middle_does_not_change_the_rows_under_it():
    b_rows = RULES[:2] + [["Wins on different paylines are added."]] + RULES[2:]
    r = cd.compare(sheets(GAME_RULES=RULES), sheets(GAME_RULES=b_rows))
    (c,) = r["changes"]
    assert (c["type"], c["category"], c["row_b"]) == ("row_added", cd.STRUCTURAL, 3)
    assert c["text"] == "Wins on different paylines are added."


def test_a_removed_and_a_moved_row():
    a_rows = RULES + [["Highest win only per line."], ["Odds are fixed."]]
    b_rows = [RULES[0], ["Odds are fixed."], RULES[1], ["Highest win only per line."]]
    r = cd.compare(sheets(GAME_RULES=a_rows), sheets(GAME_RULES=b_rows))
    got = sorted(c["type"] for c in r["changes"])
    assert got == ["row_moved", "row_removed"]
    removed = next(c for c in r["changes"] if c["type"] == "row_removed")
    assert removed["text"] == "Malfunction voids all pays and plays."


def test_a_symbol_removed_with_its_comma_is_a_symbol_change_only():
    a = sheets(SCATTER=[["SCATTERED <purple_scat>, <blue_scat>, <red_scat> pay anywhere."]])
    b = sheets(SCATTER=[["SCATTERED <blue_scat>, <red_scat> pay anywhere."]])
    (c,) = cd.compare(a, b)["changes"]
    assert (c["type"], c["removed"], c["added"]) == ("symbols_changed", ["purple_scat"], [])


def test_a_capital_letter_is_a_text_change():
    a = sheets(GAME_RULES=[["Free games are played at the triggering bet."]])
    b = sheets(GAME_RULES=[["Free Games are played at the triggering bet."]])
    (c,) = cd.compare(a, b)["changes"]
    assert (c["type"], c["what"]) == ("cell_changed", "text")


def test_sheets_added_removed_renamed_and_reordered():
    a = sheets(PAYTABLE=PAYTABLE, GAME_RULES=RULES, JACKPOTS=[["JACKPOTS"], ["Grand is 1000 x bet."]],
               FEATURES=[["FREE GAMES"], ["3 scatters award 8 free games."], ["Free games can be retriggered."]])
    b = sheets(GAME_RULES=RULES, PAYTABLE=PAYTABLE, BINGO_RULES=[["BINGO RULES"], ["Bingo pattern pays."]],
               FREE_GAMES=[["FREE GAMES"], ["3 scatters award 8 free games."], ["Free games can be retriggered."]])
    r = cd.compare(a, b)
    assert r["renames"] == {"FEATURES": "FREE GAMES"}
    got = types(r)
    assert ("sheet_renamed", "FREE GAMES") in got
    assert ("sheet_removed", "JACKPOTS") in got
    assert ("sheet_added", "BINGO RULES") in got
    assert ("sheet_order", "") in got
    added = next(c for c in r["changes"] if c["type"] == "sheet_added")
    assert (added["kind"], added["category"]) == ("bingo_rules", cd.STRUCTURAL)
    assert "“JACKPOTS” was removed from the Excel" in r["summary"]
    assert "“FEATURES” is now called “FREE GAMES”" in r["summary"]


def test_market_clone_keeps_the_names_it_always_had():
    assert mc.RowMap is cd.RowMap and mc.sheet_renames is cd.sheet_renames
    assert mc.read_workbook is cm.read_workbook and mc.norm is cm.norm and mc.sym_key is cm.sym_key
    assert mc.norm("Pays <pic1>  LEFT\rto right") == "pays left to right"


def test_page_kind_is_the_engine_sheet_type():
    from ps_autotypesetter.ui_web import engine_api

    for name in ("PAYTABLE", "Pay Table 2", "GAME RULES (denom 5&6)", "Rules", "Bingo Rules", "JACKPOTS", "Payouts"):
        assert engine_api._sheet_type(name) == cm.page_kind(name)
    assert [cm.page_kind(n) for n in ("PAYTABLE-My", "Game Rules", "BINGO", "Features")] == [
        "paytable", "game_rules", "bingo_rules", "page"]
