"""Paytable layout learned from an artist PSD (ps_autotypesetter/artist_design)."""

import os

import pytest
from openpyxl import load_workbook
from PIL import Image

from ps_autotypesetter.artist_design import fit_cards, fx_preview
from ps_autotypesetter.artist_design.learn_paytable import _line_end_words
from ps_autotypesetter.ui_web import engine_api, ps_actions

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXAMPLES = os.path.join(ROOT, "examples")
BZZF_PSD = os.path.join(ROOT, "PSDRef", "BZZF_blastBlueHelps.psd")
BZZF_XLSX = os.path.join(ROOT, "proof_replicate", "BZZF_modified.xlsx")
SYMBOLS = os.path.join(ROOT, "symbols")


def _sheet():
    return load_workbook(os.path.join(EXAMPLES, "paytable.xlsx"), data_only=True)["Paytable"]


def _box(x, y, w, h):
    return {"x": x, "y": y, "w": w, "h": h}


def _artist_template(cards):
    """A learned-style template with one card (symbol, pay, value, card art) per symbol."""
    slots, mappings, meta_cards = {}, {}, []
    for i, sym in enumerate(cards):
        x = 100 + i * 260
        names = [sym, f"{sym}.pay", f"{sym}.value", f"decor.{i + 1}"]
        slots[f"decor.{i + 1}"] = _box(x - 10, 240, 250, 460)
        slots[sym] = _box(x, 250, 200, 180)
        slots[f"{sym}.pay"] = _box(x, 450, 80, 200)
        slots[f"{sym}.value"] = _box(x + 90, 450, 100, 200)
        mappings[f"decor.{i + 1}"] = {"slot": f"decor.{i + 1}", "mode": "icon", "token": f"<decor_{i + 1}>",
                                      "fit": "exact", "symbol": sym, "layer_opacity": 0.6}
        mappings[sym] = {"slot": sym, "mode": "icon", "token": f"<{sym}>"}
        mappings[f"{sym}.pay"] = {"slot": f"{sym}.pay", "mode": "excel", "role": "pay", "symbol": sym,
                                  "source": "A1", "font_size": 40}
        mappings[f"{sym}.value"] = {"slot": f"{sym}.value", "mode": "excel", "role": "value", "symbol": sym,
                                    "source": "A1", "font_size": 40}
        meta_cards.append({"symbol": sym, "slots": names, "box": _box(x - 10, 240, 250, 460)})
    return {"canvas": {"width": 1920, "height": 1080}, "slot_prefix": "@slot", "slots": slots,
            "mappings": mappings, "icon_mappings": {},
            "mapper_meta": {"generated_by": "artist_design", "artist_design": {
                "cards": meta_cards, "pitch": {"x": 260, "y": 480}, "content_bottom": 1000, "title_art": []}}}


# ── line breaks ────────────────────────────────────────────────────────────
def test_artist_line_breaks_are_learned_and_reapplied_to_excel_text():
    words = _line_end_words("substitutes for all \rsymbols except     \r\r ,  ")
    assert words == ["all", "except"]
    text = fit_cards.break_after_words(
        "substitutes for all symbols except <purple_scat>, <red_scat> and <green_scat>.", words)
    assert text == "substitutes for all\nsymbols except\n<purple_scat>, <red_scat> and <green_scat>."
    # words the Excel text no longer has are skipped, the rest still break
    assert fit_cards.break_after_words("pays on all lines", ["except", "all"]) == "pays on all\nlines"


# ── card fitting ───────────────────────────────────────────────────────────
def test_cards_for_missing_symbols_are_dropped_and_extra_symbols_cloned():
    ws = _sheet()                                     # 10 symbols: pic1..pic5, ace..ten
    notes = []
    out = fit_cards.prepare(_artist_template(["pic1", "pic2", "ghost"]), ws, notes)
    syms = {c["symbol"] for c in out["mapper_meta"]["artist_design"]["cards"]}
    assert "ghost" not in syms and "ghost" not in out["slots"] and "decor.3" not in out["slots"]
    blocks = engine_api.automap_paytable_slots_ws(ws, {"slots": {}, "slot_prefix": "@slot"})["blocks"]
    assert syms == {b["key"] for b in blocks}
    # a clone carries the card art and reads ITS symbol's rows
    ace_pay = out["mappings"]["ace.pay"]
    assert ace_pay["source"] == next(b["pay_ref"] for b in blocks if b["key"] == "ace")
    assert any(m.get("symbol") == "ace" and m.get("fit") == "exact" for m in out["mappings"].values())
    assert any("ghost" in n for n in notes) and any("cloning" in n for n in notes)
    # every card stays inside the artist's content area
    bottom = max(c["box"]["y"] + c["box"]["h"] for c in out["mapper_meta"]["artist_design"]["cards"])
    assert bottom <= 1000 + 1


def test_prepare_scales_learned_sizes_to_the_output_canvas():
    t = _artist_template(["pic1"])
    t["canvas"] = {"width": 3840, "height": 2160}
    out = fit_cards.prepare(t, None, target=(1920, 1080))
    assert out["mappings"]["pic1.pay"]["font_size"] == 20


# ── learned design art survives the legacy clean-ups ───────────────────────
def test_learned_design_art_is_kept_by_sanitize_and_dead_card_filter():
    ws = _sheet()
    t = _artist_template(["pic1"])
    t["slots"]["decor.9"] = _box(100, 20, 1700, 80)          # title art: no card, unknown token
    t["mappings"]["decor.9"] = {"slot": "decor.9", "mode": "icon", "token": "<decor_9>", "fit": "exact"}
    mapped = ps_actions._mapping_dict(t["mappings"])
    ps_actions._sanitize_preview_mappings(mapped, ws, t)
    assert "decor.9" in mapped
    live = engine_api._paytable_live_slot_data(ws, t)
    assert not engine_api.paytable_slot_is_dead("decor.9", mapped["decor.9"], live)


def test_exact_fit_art_is_drawn_with_the_artist_layer_opacity(tmp_path):
    art = tmp_path / "decor_1.png"
    Image.new("RGBA", (20, 10), (200, 0, 0, 255)).save(art)
    overlay = Image.new("RGBA", (100, 100), (0, 0, 0, 0))
    spec = {"slot": "decor.1", "mode": "icon", "token": "<decor_1>", "fit": "exact", "layer_opacity": 0.5}
    assert ps_actions._draw_mapped_slot_icon(overlay, spec, None, "", {"<decor_1>": str(art)}, 10, 10, 40, 20, 1.0)
    r, g, b, a = overlay.getpixel((20, 20))
    assert r == 200 and 120 <= a <= 135
    assert overlay.getpixel((5, 5))[3] == 0


def test_learned_template_survives_the_mappers_resave(tmp_path):
    """The mapper re-saves with generated_by=web_paytable_mapper, sorted slot keys and
    no template-level icon_mappings: the design must still render the same."""
    art = tmp_path / "decor_1.png"
    Image.new("RGBA", (8, 8), (10, 20, 30, 255)).save(art)
    t = _artist_template(["pic1"])
    t["mappings"]["decor.1"]["asset_path"] = str(art)
    t["mapper_meta"]["generated_by"] = "web_paytable_mapper"
    t["slots"] = dict(sorted(t["slots"].items()))              # what Flask's jsonify does
    t.pop("icon_mappings")
    assert fit_cards.is_artist_template(t)
    out = fit_cards.prepare(t, None)
    assert next(iter(out["slots"])) == "decor.1"                # art is drawn first again
    info = ps_actions._mapping_preview_icon(out["mappings"]["decor.1"], None, "", {})
    assert info and info["path"] == str(art)


# ── effects preview ────────────────────────────────────────────────────────
class _Fx:
    def __init__(self, kind, **kw):
        self.__class__ = type(kind, (_Fx,), {})
        self.enabled = True
        self.opacity = 100.0
        for k, v in kw.items():
            setattr(self, k, v)


class _Layer:
    def __init__(self, effects, image):
        self.effects = effects
        self._image = image

    def topil(self):
        return self._image


def test_fx_preview_draws_stroke_and_overlay_around_the_glyphs():
    glyph = Image.new("RGBA", (40, 20), (0, 0, 0, 0))
    glyph.paste((0, 255, 0, 255), (10, 5, 30, 15))
    layer = _Layer([
        _Fx("Stroke", size=3.0, position=b"OutF", color={b"Rd  ": 255.0, b"Grn ": 255.0, b"Bl  ": 0.0},
            fill_type=b"SClr"),
        _Fx("ColorOverlay", color={b"Rd  ": 255.0, b"Grn ": 0.0, b"Bl  ": 0.0}),
    ], glyph)
    img, pad = fx_preview.render(layer)
    assert pad >= 3 and img.size == (40 + 2 * pad, 20 + 2 * pad)
    assert img.getpixel((pad + 20, pad + 10))[:3] == (255, 0, 0)          # overlay replaces the green
    assert img.getpixel((pad + 8, pad + 10))[:3] == (255, 255, 0)          # outside stroke
    assert img.getpixel((0, 0))[3] == 0


def test_fx_preview_ignores_layers_without_drawable_effects():
    layer = _Layer([_Fx("BevelEmboss", size=4.0)], Image.new("RGBA", (4, 4), (255, 255, 255, 255)))
    assert fx_preview.render(layer) == (None, 0)


# ── end to end on the BZZF artist file (local only) ────────────────────────
@pytest.mark.skipif(not (os.path.isfile(BZZF_PSD) and os.path.isfile(BZZF_XLSX) and os.path.isdir(SYMBOLS)),
                    reason="BZZF artist PSD / workbook / symbols not available")
def test_learn_bzzf_paytable(tmp_path):
    from ps_autotypesetter.artist_design import psd_reader
    from ps_autotypesetter.artist_design.learn_paytable import learn_paytable

    ws = load_workbook(BZZF_XLSX, data_only=True)["Paytable"]
    res = learn_paytable(psd_reader.open_psd(BZZF_PSD), "paytable", ws, SYMBOLS, str(tmp_path / "assets"))
    t, report = res["template"], res["report"]
    meta = t["mapper_meta"]["artist_design"]
    assert len(meta["cards"]) == 10 and meta["title_art"]
    assert {c["symbol"] for c in meta["cards"]} >= {"pic1", "ace", "ten"}
    assert t["mappings"]["pic1.value"]["source"].startswith("H13")
    # decor first, so art never covers symbols or numbers
    names = list(t["slots"])
    assert names.index("decor.1") < names.index("pic1")
    # card art keeps the artist's transparency; squeezed title text is art with effects + preview
    assert t["mappings"]["decor.1"]["layer_opacity"] < 1.0
    title = t["mappings"][meta["title_art"][0]]
    assert title["effects_block"]["hex"] and os.path.isfile(title["preview_image"])
    assert not report.get("warnings") or all("symbol" not in w.casefold() for w in report["warnings"])
