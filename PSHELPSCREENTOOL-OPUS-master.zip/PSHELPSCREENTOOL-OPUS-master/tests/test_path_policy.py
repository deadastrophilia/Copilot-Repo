import os

import pytest

from ps_autotypesetter.ui_web import path_policy


@pytest.fixture()
def policy(tmp_path):
    workspace = tmp_path / "workspace"
    user = tmp_path / "user"
    workspace.mkdir()
    user.mkdir()
    path_policy.reset_for_tests(workspace=str(workspace))
    yield user
    path_policy.reset_for_tests(workspace=str(workspace))


def test_granted_file_is_allowed(policy):
    target = policy / "icons" / "wild.png"
    target.parent.mkdir()
    target.write_bytes(b"png")
    assert not path_policy.is_allowed(str(target))
    path_policy.grant(str(target))
    assert path_policy.is_allowed(str(target))
    assert path_policy.is_allowed(str(target.parent))
    sibling = target.parent / "elsewhere.png"
    sibling.write_bytes(b"x")
    assert path_policy.is_allowed(str(sibling))
    outside = policy / "outside.png"
    outside.write_bytes(b"x")
    assert not path_policy.is_allowed(str(outside))
    stranger = policy.parent / "stranger.png"
    stranger.write_bytes(b"x")
    assert not path_policy.is_allowed(str(stranger))


def test_ungranted_drive_path_rejected(policy):
    assert not path_policy.is_allowed(str(policy.parent / "nope" / "file.png"))
    assert not path_policy.is_allowed("")
    assert not path_policy.is_allowed(None)


def test_missing_output_dir_still_grantable(policy):
    pending = policy / "out" / "not_created_yet"
    path_policy.grant_tree(str(pending))
    assert not pending.exists()
    assert path_policy.is_allowed(str(pending))


def test_grant_walks_up_to_nearest_existing(policy):
    deep = policy / "a" / "b" / "c" / "d" / "picked.xlsx"
    path_policy.grant(str(deep))
    assert path_policy.is_allowed(str(deep))
    assert path_policy.is_allowed(str(policy / "a"))


def test_config_seeding_grants_known_keys_and_nested_paths(policy):
    excel = policy / "books" / "game.xlsx"
    excel.parent.mkdir(parents=True)
    excel.write_bytes(b"x")
    cfg = {
        "excel_path": str(excel),
        "output_dir": str(policy / "future_out"),
        "dynamic_settings": {"template_json_map": {"Rules": str(excel)}},
    }
    path_policy.grant_config_paths(cfg)
    assert path_policy.is_allowed(str(excel))
    assert path_policy.is_allowed(str(excel.parent))
    assert not (policy / "future_out").exists()


def _client():
    from ps_autotypesetter.ui_web.server import create_app

    return create_app().test_client()


def test_image_size_endpoint_blocks_foreign_path(policy):
    client = _client()
    resp = client.get("/api/image_size", query_string={"path": "Q:\\evil\\x.png"})
    assert resp.status_code == 403
    body = resp.get_json()
    assert body["ok"] is False


def test_icons_endpoint_blocks_foreign_folder(policy):
    client = _client()
    resp = client.get("/api/icons", query_string={"folder": "Q:\\evil"})
    assert resp.status_code == 403
