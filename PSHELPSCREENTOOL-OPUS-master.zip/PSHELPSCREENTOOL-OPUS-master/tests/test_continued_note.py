"""An Excel's own "continued" note after the heading ((Cont.), CONTINUED, (cont'd), ...) is not drawn:
the page gets the tool's "(Continued)" line instead, so every Continued page looks the same."""
import pytest
from openpyxl import Workbook
from openpyxl.styles import Font

from ps_autotypesetter import page_boxes, row_roles
from ps_autotypesetter.layout_engine import build_normal_page_layouts


@pytest.fixture(autouse=True)
def _clean():
    page_boxes.set_all({})
    row_roles.set_all({})
    yield
    page_boxes.set_all({})
    row_roles.set_all({})


@pytest.mark.parametrize("text", ["(Cont.)", "Continued", "CONTINUED", "(cont)", "(CONTINUED)", "(cont'd)",
                                  "- Contd -", "[Continued]", " continued... "])
def test_notes_that_say_the_page_goes_on(text):
    assert row_roles.is_continued_note(text)


@pytest.mark.parametrize("text", ["", "Contents", "Continue to spin until no wins", "WILD", "Bonus continues",
                                  "The feature is continued on the next spin"])
def test_other_text_is_not_a_note(text):
    assert not row_roles.is_continued_note(text)


def test_a_note_row_right_after_the_heading():
    rows = {1: "FEATURES", 2: "", 3: "(CONTINUED)", 4: "Text"}
    assert row_roles.continued_from_excel("FEATURES", rows.get, 1, 4) == ("FEATURES", 3, True)


def test_a_note_further_down_is_text():
    rows = {1: "FEATURES", 2: "Text", 3: "(CONTINUED)"}
    assert row_roles.continued_from_excel("FEATURES", rows.get, 1, 3) == ("FEATURES", None, False)


@pytest.mark.parametrize("heading", ["FEATURES (CONTINUED)", "FEATURES (Cont.)", "FEATURES - continued", "FEATURES: Cont'd"])
def test_a_note_at_the_end_of_the_heading(heading):
    assert row_roles.continued_from_excel(heading, {}.get, 1, 1) == ("FEATURES", None, True)


def test_a_heading_that_ends_in_a_word_like_it_stays():
    assert row_roles.continued_from_excel("FREE SPINS CONTINUE", {}.get, 1, 1) == ("FREE SPINS CONTINUE", None, False)


def _layouts(note):
    wb = Workbook()
    ws = wb.active
    ws.title = "P"
    ws.cell(row=1, column=1, value="BIG FEATURES").font = Font(bold=True)
    if note:
        ws.cell(row=2, column=1, value=note)
    ws.cell(row=3, column=1, value="The feature text")
    return build_normal_page_layouts(
        ws, "P", canvas_w=1920, canvas_h=1080, margin_x=100,
        h_font="Arial", h_size=72, h_icon_h=48, h_rgb=(255, 80, 80),
        b_font="Arial", b_size=30, b_icon_h=24, b_rgb=(255, 255, 255),
        line_spacing=4, para_spacing=12, continued_gap=15, line_gap=30,
        heading_top_margin=120, heading_to_body_gap=40, bottom_margin=80,
        page_max_row=ws.max_row, page_max_col=12)


def test_the_page_gets_the_tools_continued_line_not_the_excels():
    page = _layouts("(CONTINUED)")[0]
    kinds = [(e.meta.get("kind"), e.text) for e in page.elements]
    assert ("continued", "(Continued)") in kinds
    body = [e for e in page.elements if e.meta.get("kind") == "body"]
    assert [e.meta.get("row") for e in body] == [3]                       # the note row is not drawn
    cont = next(e for e in page.elements if e.meta.get("kind") == "continued")
    assert body[0].y >= cont.y + cont.height                             # the text starts under it


def test_a_page_without_a_note_has_no_continued_line():
    page = _layouts(None)[0]
    assert not [e for e in page.elements if e.meta.get("kind") == "continued"]


def test_a_continued_page_keeps_the_heading_body_gap():
    wb = Workbook()
    ws = wb.active
    ws.title = "P"
    ws.cell(row=1, column=1, value="BIG FEATURES").font = Font(bold=True)
    for r in range(2, 40):
        ws.cell(row=r, column=1, value=f"Line of text number {r}")

    def pages(gap):
        return build_normal_page_layouts(
            ws, "P", canvas_w=1920, canvas_h=1080, margin_x=100,
            h_font="Arial", h_size=72, h_icon_h=48, h_rgb=(255, 80, 80),
            b_font="Arial", b_size=30, b_icon_h=24, b_rgb=(255, 255, 255),
            line_spacing=4, para_spacing=12, continued_gap=15, line_gap=30,
            heading_top_margin=120, heading_to_body_gap=gap, bottom_margin=80,
            page_max_row=ws.max_row, page_max_col=12)

    def first_text(page):
        return min(e.meta["ink_top"] for e in page.elements if e.meta.get("kind") == "body")   # where its letters start

    small, big = pages(40), pages(300)
    heading = next(e for e in big[1].elements if e.meta.get("kind") == "heading")
    assert first_text(big[1]) >= heading.y + heading.height + 300 - 1       # as far down as the gap says
    assert first_text(small[1]) < first_text(big[1])                       # a small gap: under "(Continued)" as before


def _long_sheet():
    wb = Workbook()
    ws = wb.active
    ws.title = "P"
    ws.cell(row=1, column=1, value="BIG FEATURES").font = Font(bold=True)
    for r in range(2, 40):
        ws.cell(row=r, column=1, value=f"Line of text number {r}")
    return build_normal_page_layouts(
        ws, "P", canvas_w=1920, canvas_h=1080, margin_x=100,
        h_font="Arial", h_size=72, h_icon_h=48, h_rgb=(255, 80, 80),
        b_font="Arial", b_size=30, b_icon_h=24, b_rgb=(255, 255, 255),
        line_spacing=4, para_spacing=12, continued_gap=15, line_gap=30,
        heading_top_margin=120, heading_to_body_gap=40, bottom_margin=80,
        page_max_row=ws.max_row, page_max_col=12,
        alignment_settings={"global": {"body": "center", "heading": "center"}})


def test_continued_has_its_own_alignment_and_gap():
    row_roles.set_all({"continued_align": "left", "continued_body_gap": 200})
    page = _long_sheet()[1]
    cont = next(e for e in page.elements if e.meta.get("kind") == "continued")
    assert cont.align == "left"
    body = [e for e in page.elements if e.meta.get("kind") == "body"]
    assert {e.align for e in body} == {"center"}                          # the paragraph keeps its own
    assert min(e.meta["ink_top"] for e in body) == pytest.approx(cont.y + cont.height + 200, abs=1)


def test_continued_follows_the_heading_until_set():
    page = _long_sheet()[1]
    cont = next(e for e in page.elements if e.meta.get("kind") == "continued")
    assert cont.align == "center"


@pytest.mark.parametrize("heading, clean", [
    ("JACKPOT CARNIVAL\u2122 FEATURE (continued..)", "JACKPOT CARNIVAL\u2122 FEATURE"),
    ("XYZ (Continued)", "XYZ"), ("XYZ (Cont.)", "XYZ"), ("XYZ (cont)", "XYZ"), ("XYZ [cont]", "XYZ"),
    ("XYZ - Continued", "XYZ"), ("XYZ \u2013 continued", "XYZ"), ("XYZ: continued...", "XYZ"),
    ("XYZ CONTINUED", "XYZ"), ("XYZ Continued\u2122", "XYZ"), ("XYZ\u2122 (Cont.)  ", "XYZ\u2122")])
def test_split_heading_continued_strips_the_marker(heading, clean):
    assert row_roles.split_heading_continued(heading) == (clean, True)


@pytest.mark.parametrize("heading", ["CONTINUED FREE GAMES", "CONTINUED", "(Continued)", "FREE SPINS CONTINUE",
                                     "The Continued Story", "WILD", ""])
def test_split_heading_continued_leaves_other_headings(heading):
    assert row_roles.split_heading_continued(heading) == (heading, False)


def test_a_marker_inside_the_heading_gives_the_continued_line():
    wb = Workbook()
    ws = wb.active
    ws.title = "P"
    ws.cell(row=1, column=1, value="JACKPOT CARNIVAL FEATURE (continued..)").font = Font(bold=True)
    ws.cell(row=2, column=1, value="The feature text")
    page = build_normal_page_layouts(
        ws, "P", canvas_w=1920, canvas_h=1080, margin_x=100,
        h_font="Arial", h_size=72, h_icon_h=48, h_rgb=(255, 80, 80),
        b_font="Arial", b_size=30, b_icon_h=24, b_rgb=(255, 255, 255),
        line_spacing=4, para_spacing=12, continued_gap=15, line_gap=30,
        heading_top_margin=120, heading_to_body_gap=40, bottom_margin=80,
        page_max_row=ws.max_row, page_max_col=12)[0]
    heading = next(e for e in page.elements if e.meta.get("kind") == "heading")
    assert heading.text == "JACKPOT CARNIVAL FEATURE"
    assert ("continued", "(Continued)") in [(e.meta.get("kind"), e.text) for e in page.elements]



@pytest.mark.parametrize("heading, clean", [
    ("JACKPOT CARNIVAL™ FEATURE (continued…)", "JACKPOT CARNIVAL™ FEATURE"),
    ("HAMMER FEATURE (continued…)", "HAMMER FEATURE"),
    ("FREE GAMES CONTINUED…", "FREE GAMES"),
])
def test_an_ellipsis_character_after_continued(heading, clean):
    from ps_autotypesetter import row_roles as rr
    assert rr.split_heading_continued(heading) == (clean, True)
