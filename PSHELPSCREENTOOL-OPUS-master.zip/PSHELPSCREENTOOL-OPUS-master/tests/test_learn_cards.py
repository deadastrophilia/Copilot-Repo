"""An artist's paytable page (PSD) read as an editable card design (artist_design/learn_cards.py).
Runs on the artist PSDs of the 6-game test set where they are on this machine."""
import os

import pytest

from ps_autotypesetter.artist_design import learn_cards, psd_reader
from ps_autotypesetter.dynamic_pages.paytable import card_templates as ct

D = r"E:\Work\ClaudeCode\DataForHelpScreenTool"
PSDS = {"jcj": D + r"\JuCaiJin-4tHelp\Working\Help.psd", "spooky": D + r"\Spooky\Spooky_Link HelpPSD.psd",
        "neptune": D + r"\Hunt-Nept\Working\Help.psb", "kismet": D + r"\kismatkat\HHR_10169025\Help\Working\HelpScreens_KismetKat.psd"}


def _learn(key, out_width=1920):
    path = PSDS[key]
    if not os.path.isfile(path):
        pytest.skip("artist PSD not on this machine")
    psd = psd_reader.open_psd(path)
    pages = learn_cards.paytable_groups(psd)
    assert pages
    return learn_cards.learn(psd, pages[0]["path"], ct.get_template("classic_cards"), out_width)


def _part(t, role, band=0):
    return next(p for p in t["bands"][band]["parts"] if p["role"] == role)


def test_live_shape_cards_their_look_and_numbers():
    t, rep = _learn("jcj")
    assert rep["cards"] == 11 and rep["rows"] == [5, 6] and rep["from_shapes"]
    look = t["styles"]["card"]
    assert look["fill"] == "#720000" and look["fill_opacity"] == 80 and look["radius"] > 0
    assert look["stroke"]["enabled"] and look["stroke"]["align"] == "center"
    c, p = _part(t, "counts"), _part(t, "pays")
    assert c["font"] == "Arial-Black" and c["color"] == "#ffffff" and p["color"] == "#ffb900"
    assert c["x"] + c["w"] <= p["x"]                              # the counts never run into the pays
    assert _part(t, "symbol")["x"] < 0.1                         # the symbol at the card's left
    assert [b["per_row"] for b in t["bands"]] == [5, 6] and t["name"].startswith("From the artist")


def test_symbol_on_top_and_right_aligned_pays():
    t, rep = _learn("spooky")
    assert rep["rows"] == [5, 5]
    sym, pays = _part(t, "symbol"), _part(t, "pays")
    assert sym["y"] < 0.2 and sym["h"] < 0.5                    # the picture at the top, the numbers below
    assert pays["align"] == "right" and _part(t, "counts")["color"] == "#feea01"


def test_a_hidden_page_inside_another_group_and_a_layer_effect_stroke():
    t, rep = _learn("neptune")
    assert t["styles"]["card"]["fill"] == "#3049b1" and t["styles"]["card"]["fill_opacity"] == 75
    t2, _ = _learn("kismet")
    look = t2["styles"]["card"]
    assert not look["fill_enabled"] and look["stroke"]["enabled"] and look["stroke"]["color"] == "#fff600"


def test_text_sizes_follow_the_projects_canvas():
    small, _ = _learn("jcj", 1920)
    big, _ = _learn("jcj", 3840)
    assert _part(big, "pays")["font_size"] == pytest.approx(2 * _part(small, "pays")["font_size"], rel=0.02)


def test_the_learned_design_lays_out_with_an_excel():
    from ps_autotypesetter.ui_web import engine_api

    excel = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "ExcelFileForReference", "paytable.xlsx")
    if not os.path.isfile(excel):
        pytest.skip("reference Excel not here")
    t, _ = _learn("spooky")
    res, _ = engine_api.auto_map_page(dict(engine_api.DEFAULT_CONFIG, excel_path=excel), "Paytable", "", {"card_template": t, "dry_run": True})
    assert res["ok"] and any(k.endswith(".card") for k in res["_template"]["slots"])
