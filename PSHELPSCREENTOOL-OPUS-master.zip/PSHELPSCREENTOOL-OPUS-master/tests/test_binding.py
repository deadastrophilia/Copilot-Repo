"""binding.py: which layers show which AGR content — made by a clone, kept, carried, checked."""
import os

import pytest
from openpyxl import Workbook

from ps_autotypesetter import binding, psd_memory
from ps_autotypesetter import market_clone as mc


def _book(path, rows):
    wb = Workbook()
    ws = wb.active
    ws.title = "Features"
    for row in rows:
        ws.append(row)
    wb.save(path)
    return str(path)


NYL = [["FREE SPINS"], ["Three scatters award 10 free spins."], ["Wins are multiplied by the bet multiplier."]]
HHR = [["FREE SPINS"], ["Four scatters award 12 free spins."], ["Wins are multiplied by the bet multiplier."]]


@pytest.fixture
def cloned(tmp_path):
    """A PSD made by the tool's writer (stand-in for an artist's) cloned to another market's Excel."""
    pytest.importorskip("photoshopapi")
    from ps_autotypesetter.psd_writer import build as psd_build
    from ps_autotypesetter.ui_web import engine_api

    excel_a = _book(tmp_path / "Game NYL.xlsx", NYL)
    cfg = {"excel_path": excel_a, "icon_folder": "", "bg_path": "", "bg_source": "color", "bg_color": "#102040",
           "output_dir": str(tmp_path / "out"), "output_name": "Game NYL", "render_all_pages": True,
           "c_width": 1280, "c_height": 720}
    src = psd_build.build_psd(**engine_api._build_kwargs(cfg), output_format="PSD")
    excel_b = _book(tmp_path / "Game HHR.xlsx", HHR)
    out = str(tmp_path / "Game HHR.psd")
    report = mc.clone(src, excel_a, excel_b, out, pictures=False, game_id="game1")
    return src, out, report


def _text_elements(b):
    return [e for e in b["elements"] if e["kind"] == "text" and e["owner"] == "data"]


def test_a_clone_keeps_both_bindings_and_the_new_psd_carries_its_own(cloned):
    src, out, report = cloned
    assert report["bindings"]["source"]["texts"] >= 2 and report["bindings"]["new"]["texts"] >= 2
    a, b = binding.load(src, "game1"), binding.load(out, "game1")
    assert a and b and binding.load(src) is None                     # kept with its game only
    assert a["agr"]["name"] == "Game NYL.xlsx" and b["agr"]["name"] == "Game HHR.xlsx"
    assert binding.read_embedded(out)["elements"] == b["elements"]     # inside the new PSD too
    assert binding.find(out) is not None                             # found without the game
    # what each layer shows, in each market's AGR (the stand-in has no layer IDs, the new PSD does)
    assert {e["content"]["sheet"] for e in _text_elements(a)} == {"Features"}
    assert {e["content"]["sheet"] for e in _text_elements(b)} == {"Features"}
    assert len({e["layer"] for e in b["elements"]}) == len(b["elements"])   # every layer its own ID
    # both fit their files exactly as they are
    for bd, path in ((a, src), (b, out)):
        v = binding.validate(bd, path)
        assert v["ok"] and v["problems"] == [], v["problems"]


def test_the_new_psd_memory_is_a_binding_not_a_project(cloned, tmp_path):
    _src, out, _report = cloned
    mem = psd_memory.read(out)
    assert mem.get("binding")
    # the stand-in was made by the tool, so its project came along (as the artist's file would keep its
    # XMP); a PSD carrying a binding only is not a project
    only = {"schema": psd_memory.SCHEMA, "binding": mem["binding"]}
    assert not psd_memory.has_project(only) and psd_memory.has_project(mem) == bool(mem.get("config"))


def test_validate_tells_a_changed_layer_from_a_gone_one(cloned):
    from ps_autotypesetter.artist_design import psd_reader

    _src, out, _report = cloned
    b = binding.load(out, "game1")
    psd = psd_reader.open_lazy(out)
    layers = {l.layer_id: l for l in psd.descendants()}
    texts = [layers[e["layer"]] for e in _text_elements(b)]
    renamed, moved, retyped = texts[0], texts[1], texts[-1]
    renamed.name = "my own name"
    moved._record.top += 10
    moved._record.bottom += 10
    mc.edit_text_layer(retyped, "Something the artist typed.")
    v = binding.validate(b, psd)
    issues = {(p["layer"], p["issue"]) for p in v["problems"]}
    assert (renamed.layer_id, "renamed") in issues and (moved.layer_id, "moved") in issues
    assert (retyped.layer_id, "text_changed") in issues
    assert v["ok"]                                                   # all of these can still be updated
    # a layer deleted from the file: its content can't be updated any more
    gone = texts[0]
    gone.parent.remove(gone)
    v = binding.validate(b, psd)
    assert not v["ok"] and {"layer": gone.layer_id, "issue": "missing"}.items() <= next(
        p for p in v["problems"] if p["layer"] == gone.layer_id).items()


def test_a_page_the_artist_kept_does_not_claim_the_new_agr(cloned):
    """On the written side a layer still showing the old text (page kept, change left to the artist)
    waits for a look; on the artist's side it is bound."""
    from ps_autotypesetter.artist_design import psd_reader

    _src, out, _report = cloned
    psd = psd_reader.open_lazy(out)
    layer = next(l for l in psd.descendants() if l.kind == "type")
    content = {"kind": "cells", "a": {"sheet": "Features", "cells": [[2, 1]]}, "b": {"sheet": "Features", "cells": [[2, 1]]}}
    plan = {"items": [{"layer_id": layer.layer_id, "status": "kept", "content": content, "source": "Features!A2"}]}
    side_a, side_b = binding.make(psd, plan, out, side="a"), binding.make(psd, plan, out, side="b")
    assert side_a["elements"][0]["owner"] == "data" and side_b["elements"][0]["owner"] == "review"
    assert side_a["elements"][0]["content"] == {"kind": "cells", "sheet": "Features", "cells": [[2, 1]]}


def test_bindings_are_kept_per_game_by_file_name(tmp_path):
    b = {"schema": binding.SCHEMA, "pages": [], "elements": [], "static": 3}
    path = binding.save(b, r"C:\art\Game NYL.psd", "game1")
    assert os.path.isfile(path) and binding.load(r"D:\copy\game nyl.psd", "game1")["static"] == 3
    assert binding.load(r"C:\art\Game NYL.psd", "game2") is None
    assert binding.load(r"C:\art\Game HHR.psd", "game1") is None


def test_tool_made_psds_remember_their_layers_by_id(tmp_path):
    pytest.importorskip("photoshopapi")
    from psd_tools import PSDImage

    from ps_autotypesetter.psd_writer import build as psd_build
    from ps_autotypesetter.ui_web import engine_api

    excel = _book(tmp_path / "Game NYL.xlsx", NYL)
    cfg = {"excel_path": excel, "icon_folder": "", "bg_path": "", "bg_source": "color", "bg_color": "#102040",
           "output_dir": str(tmp_path / "out"), "output_name": "Game NYL", "render_all_pages": True,
           "c_width": 1280, "c_height": 720}
    psd_path = psd_build.build_psd(**engine_api._build_kwargs(cfg), output_format="PSD", project_config=cfg)
    mem = psd_memory.read(psd_path)
    ids = {l.name.rstrip("\x00"): l.layer_id for l in PSDImage.open(psd_path).descendants()}
    assert len(set(ids.values())) == len(ids) and min(ids.values()) > 0
    assert mem["layers"] and all(src.get("id") == ids[name] for name, src in mem["layers"].items())
    assert all(page.get("group_id") == ids[page["group"]] for page in mem["pages"])
