"""Paytable card symbols: hand-picked overrides, live re-bind, and cards defined by what you see."""

import os

from openpyxl import load_workbook

from ps_autotypesetter.ui_web import engine_api, ps_actions

EXAMPLES = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "examples")


def _sheet():
    # pic1..pic5 + ace, king, queen, jack, ten
    return load_workbook(os.path.join(EXAMPLES, "paytable.xlsx"), data_only=True)["Paytable"]


def _box(x, y, w=200, h=200):
    return {"x": x, "y": y, "w": w, "h": h}


def _template(swap45=False):
    slots = {}
    for i in range(1, 6):
        x = 100 + (i - 1) * 260
        slots[f"pic{i}"] = _box(x, 100)
        slots[f"pic{i}.pay"] = _box(x, 320, 90, 150)
        slots[f"pic{i}.value"] = _box(x + 100, 320, 90, 150)
    if swap45:   # the artist's symbol boxes for pic4/pic5 were dragged into each other's column
        slots["pic4"], slots["pic5"] = slots["pic5"], slots["pic4"]
    return {"canvas": {"width": 1920, "height": 1080}, "slot_prefix": "@slot", "slots": slots, "mappings": {}}


def test_hand_picked_symbol_is_never_dropped():
    ws, t = _sheet(), _template()
    live = engine_api._paytable_live_slot_data(ws, t)
    typed = {"mode": "icon", "token": "<Purple Bag>"}
    assert engine_api.paytable_slot_is_dead("pic3", typed, live)          # unknown to the sheet: hidden
    assert not engine_api.paytable_slot_is_dead("pic3", dict(typed, symbol_pinned=True), live)
    assert not engine_api.paytable_slot_is_dead("pic3", {"mode": "icon", "asset_path": "x.png"}, live)


def test_card_shows_the_symbol_whose_pays_are_under_it():
    ws, t = _sheet(), _template(swap45=True)
    assert ps_actions._card_under(t, "pic4") == "pic5"
    assert ps_actions._card_under(t, "pic1") == "pic1"
    mapped = {"pic4": {"mode": "icon", "token": "<pic4>"}, "pic5": {"mode": "icon", "token": "<pic5>"},
              "pic1": {"mode": "icon", "token": "<pic1>"}}
    ps_actions._sanitize_preview_mappings(mapped, ws, t)
    assert mapped["pic4"]["token"] == "<pic5>" and mapped["pic5"]["token"] == "<pic4>"
    assert mapped["pic1"]["token"] == "<pic1>"


def test_pinned_symbol_is_not_rebound():
    ws, t = _sheet(), _template(swap45=True)
    mapped = {"pic4": {"mode": "icon", "token": "<pic4>", "symbol_pinned": True},
              "pic5": {"mode": "icon", "token": "<pic5>", "asset_path": "C:/x/train.png"}}
    ps_actions._sanitize_preview_mappings(mapped, ws, t)
    assert mapped["pic4"]["token"] == "<pic4>" and mapped["pic5"]["token"] == "<pic5>"


def test_stale_symbol_follows_the_sheet(tmp_path):
    from openpyxl import Workbook

    src = _sheet()
    wb = Workbook()
    ws = wb.active
    ws.title = "Paytable"
    for row in src.iter_rows():
        for c in row:
            if c.value is not None:
                ws[c.coordinate] = c.value
    ws["D27"] = "<SPACESHIP>"           # the 4th card's symbol is no longer <pic4>
    path = tmp_path / "pt.xlsx"
    wb.save(path)
    ws = load_workbook(path, data_only=True)["Paytable"]
    mapped = {"pic4": {"mode": "icon", "token": "<pic4>"}}
    ps_actions._sanitize_preview_mappings(mapped, ws, _template())
    assert mapped["pic4"]["token"] == "<spaceship>"


def test_symbol_picks_belong_to_their_workbook():
    mapped = {"pic4": {"mode": "icon", "token": "<pic4>", "asset_path": "C:/a/train.png",
                       "symbol_pinned": True, "pinned_excel": "Chickens.xlsx"},
              "pic5": {"mode": "icon", "token": "<pic5>", "asset_path": "C:/a/old.png", "symbol_pinned": True}}
    assert engine_api.drop_foreign_symbol_picks({k: dict(v) for k, v in mapped.items()}, r"D:\games\chickens.XLSX") == 1
    other = {k: dict(v) for k, v in mapped.items()}
    assert engine_api.drop_foreign_symbol_picks(other, r"D:\games\BZZF.xlsx") == 2
    assert "asset_path" not in other["pic4"] and not other["pic4"].get("symbol_pinned")
    # a pick saved before workbooks were recorded can't be placed: ignored, the card auto-maps
    assert "asset_path" not in other["pic5"]


def test_everywhere_relinks_swap_with_the_workbook():
    cfg = {"excel_path": r"D:\g\BZZF.xlsx",
           "icon_mappings": {"<spaceship>": "C:/a/train.png", "<wild>": "C:/a/w.png"},
           "icon_mappings_by_excel": {"chickens.xlsx": {"<spaceship>": "C:/a/train.png"},
                                      "bzzf.xlsx": {"<ingot>": "C:/a/ingot.png"}}}
    engine_api.swap_scoped_icon_mappings(cfg, r"D:\g\Chickens.xlsx")
    assert cfg["icon_mappings"] == {"<wild>": "C:/a/w.png", "<ingot>": "C:/a/ingot.png"}


def test_game_name_heading_prefers_image_then_typed_name(tmp_path):
    from PIL import Image

    from ps_autotypesetter.png_builder import game_name_heading

    folder = tmp_path / "icons"
    folder.mkdir()
    assert game_name_heading("<GAME NAME>\u2122 PAYTABLE", {"heading_game_name_text": "Crazy Chickens"}, str(folder), {}) \
        == "Crazy Chickens\u2122 PAYTABLE"
    assert game_name_heading("<Game_Name> rules", {}, str(folder), {}) == "<Game_Name> rules"
    Image.new("RGBA", (10, 4)).save(folder / "GAME NAME.png")
    assert game_name_heading("<GAME NAME> PAYTABLE", {"heading_game_name_text": "Crazy"}, str(folder), {}) \
        == "<GAME NAME> PAYTABLE"                              # the image wins, drawn inline like an icon


def test_pays_beside_the_symbol_are_still_its_own():
    """Pays laid out to the RIGHT of each symbol: the next band's pays further
    below must not steal the top cards' symbols."""
    slots = {}
    for i, n in enumerate(["pic1", "pic2", "pic3", "pic4", "pic5"]):
        x = 100 + i * 360
        slots[n] = _box(x, 100, 150, 150)
        slots[f"{n}.pay"] = _box(x + 160, 110, 80, 130)
        slots[f"{n}.value"] = _box(x + 250, 110, 80, 130)
    for i, n in enumerate(["ace", "king", "queen", "jack", "ten"]):
        x = 100 + i * 360
        slots[n] = _box(x, 400, 150, 150)
        slots[f"{n}.pay"] = _box(x, 560, 70, 120)
        slots[f"{n}.value"] = _box(x + 80, 560, 70, 120)
    t = {"canvas": {"width": 1920, "height": 1080}, "slots": slots, "mappings": {}}
    for n in ("pic1", "pic3"):
        assert ps_actions._card_under(t, n) == n
    mapped = {"pic1": {"mode": "icon", "token": "<pic1>"}}
    ps_actions._sanitize_preview_mappings(mapped, _sheet(), t)
    assert mapped["pic1"]["token"] == "<pic1>"


def test_hand_picked_cells_belong_to_their_workbook():
    mapped = {"text": {"mode": "excel", "source": "B8,K11", "source_pinned": True},
              "pic1.pay": {"mode": "excel", "role": "pay", "source": "F1", "source_pinned": True,
                           "pinned_excel": "chickens.xlsx"}}
    engine_api.drop_foreign_symbol_picks(mapped, r"D:\g\BZZF.xlsx")
    assert not mapped["text"].get("source_pinned") and not mapped["pic1.pay"].get("source_pinned")
    # unpinned, the rules catch-all follows THIS sheet again
    mapped = {"text": {"mode": "excel", "source": "B8,K11"}}
    t = _template()
    t["slots"]["text"] = _box(1500, 100, 300, 400)
    ps_actions._sanitize_preview_mappings(mapped, _sheet(), t)
    assert mapped["text"]["source"] != "B8,K11"
