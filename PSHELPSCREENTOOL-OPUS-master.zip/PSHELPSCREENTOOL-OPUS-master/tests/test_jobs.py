"""Tests for the web UI JobManager: immediate cancel via cancel_event,
cancelled-vs-done status, and output folder collection."""

import os
import time

import pytest

from ps_autotypesetter.ui_web import engine_api, jobs


@pytest.fixture
def manager():
    return jobs.JobManager()


def _wait_finished(job_id, manager, timeout=10.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        job = manager.get(job_id)
        if job and job["status"] not in ("running",):
            return job
        time.sleep(0.05)
    raise AssertionError("job did not finish in time")


def _patch(monkeypatch):
    from ps_autotypesetter.ui_web import ps_actions

    monkeypatch.setattr(ps_actions, "ensure_com_initialized", lambda: None)


def test_cancel_stops_build_immediately(monkeypatch, manager, tmp_path):
    _patch(monkeypatch)
    started = {"flag": False}

    def fake_run_build(config, mode, progress_callback=None, cancel_event=None):
        started["flag"] = True
        timeout = time.time() + 10
        while not cancel_event.is_set() and time.time() < timeout:
            time.sleep(0.02)
        if not cancel_event.is_set():
            raise RuntimeError("cancel_event was never set")
        return {"png_dir": str(tmp_path)}

    monkeypatch.setattr(engine_api, "run_build", fake_run_build)
    job_id = manager.start({"excel_path": "x.xlsx"}, "png")
    assert manager.cancel(job_id) is True
    job = _wait_finished(job_id, manager)
    assert job["status"] == "cancelled"
    deadline = time.time() + 10
    while time.time() < deadline:
        job = manager.get(job_id)
        if any("Build cancelled by user." in line for line in job.get("log", [])):
            break
        time.sleep(0.02)
    assert any("Build cancelled by user." in line for line in job["log"])
    assert started["flag"] is True


def test_normal_completion_is_done_with_output_folders(monkeypatch, manager, tmp_path):
    _patch(monkeypatch)
    png_dir = tmp_path / "out_png"
    png_dir.mkdir()

    def fake_run_build(config, mode, progress_callback=None, cancel_event=None):
        if progress_callback:
            progress_callback({"event": "build_done"})
        return {"png_dir": str(png_dir)}

    monkeypatch.setattr(engine_api, "run_build", fake_run_build)
    job_id = manager.start({"excel_path": "x.xlsx"}, "png")
    job = _wait_finished(job_id, manager)
    assert job["status"] == "done"
    assert job["progress"] == 100
    assert job["output_folders"] == [str(png_dir)]


def test_output_folders_exclude_missing_and_dedupe():
    manager = jobs.JobManager()
    result = {
        "psd_path": r"C:/work/out/project.psd",
        "png_dir": r"C:/work/out/pngs",
    }
    # both paths fake-non-existent -> empty list (no exceptions)
    assert manager._output_folders(result) == []
    result = {"png_dir": str(os.path.dirname(os.path.abspath(__file__)))}
    folders = manager._output_folders(result)
    assert folders == [os.path.dirname(os.path.abspath(__file__))]


def test_cancel_unknown_job_returns_false(manager):
    assert manager.cancel("does-not-exist") is False


def test_job_has_output_folders_key(monkeypatch, manager, tmp_path):
    _patch(monkeypatch)

    def fake_run_build(config, mode, progress_callback=None, cancel_event=None):
        return {}

    monkeypatch.setattr(engine_api, "run_build", fake_run_build)
    job_id = manager.start({"excel_path": "x.xlsx"}, "png")
    job = _wait_finished(job_id, manager)
    assert job["status"] == "done"
    assert job["output_folders"] == []