"""Count-aware paytable auto-layout generator.

``paytable_layouts.generate_paytable_slots`` turns a symbol count (top band +
lower band) into a mapped-paytable ``slots`` dict: each symbol is an icon on
the left with its pay and value columns beside it (``picN`` / ``picN.pay`` /
``picN.value``), numbered continuously across both bands, plus a full-width
title band and a catch-all ``text`` rules band beneath it.
``engine_api.paytable_sheet_structure`` detects those counts from a real sheet
by reusing the automapper's own block detection.
"""

import pytest

from ps_autotypesetter.ui_web import paytable_layouts


def _slots(top, lower=0, **kw):
    return paytable_layouts.generate_paytable_slots(top, lower, **kw)


def test_generate_two_bands_numbers_continuously():
    slots = _slots(3, 2)
    # top band pic1..pic3, lower band pic4..pic5, each with pay/value columns.
    for n in range(1, 6):
        assert f"@slot.pic{n}" in slots
        assert f"@slot.pic{n}.pay" in slots
        assert f"@slot.pic{n}.value" in slots
    assert "@slot.pic6" not in slots
    # title + catch-all text band are always present.
    assert "@slot.title" in slots
    assert "@slot.text" in slots


def test_generate_real_names_override_positional_picN():
    # Real ordered symbol keys name each cell for its symbol (top row first),
    # instead of a continuous pic1..pic10 that the live render filter would
    # treat as stray top-row cards and drop.
    slots = paytable_layouts.generate_paytable_slots(
        0, 0, top_names=["pic1", "pic2", "pic3"], lower_names=["ace", "king", "queen"])
    for nm in ("pic1", "pic2", "pic3", "ace", "king", "queen"):
        assert f"@slot.{nm}" in slots
        assert f"@slot.{nm}.pay" in slots
        assert f"@slot.{nm}.value" in slots
    assert "@slot.pic4" not in slots  # lower band uses real names, not pic4..
    # icon-left / columns-right holds for the real-named lower band too.
    assert slots["@slot.ace"]["x"] < slots["@slot.ace.pay"]["x"] < slots["@slot.ace.value"]["x"]
    assert slots["@slot.pic1"]["y"] != slots["@slot.ace"]["y"]  # two distinct bands


def test_generate_wild_name_uses_wild_slot_keys():
    # a cell literally named "wild" emits the wild/wildpay/wildvalue keys the
    # automapper special-cases (not wild.pay / wild.value).
    slots = paytable_layouts.generate_paytable_slots(0, 0, top_names=["pic1", "wild"])
    assert {"@slot.wild", "@slot.wildpay", "@slot.wildvalue"} <= set(slots)
    assert "@slot.wild.pay" not in slots


def test_generate_icon_left_columns_right():
    slots = _slots(3, 0)
    for n in range(1, 4):
        icon = slots[f"@slot.pic{n}"]
        pay = slots[f"@slot.pic{n}.pay"]
        value = slots[f"@slot.pic{n}.value"]
        # icon on the left, then the pay column, then the value column.
        assert icon["x"] < pay["x"] < value["x"]
        assert icon["y"] == pay["y"] == value["y"]
        assert pay["w"] > 0 and value["w"] > 0


def test_generate_text_band_between_title_and_grid():
    slots = _slots(5, 5)
    title = slots["@slot.title"]
    text = slots["@slot.text"]
    top_icon = slots["@slot.pic1"]
    # title above the rules text, rules text above the first symbol band.
    assert title["y"] + title["h"] <= text["y"]
    assert text["y"] + text["h"] <= top_icon["y"]
    # the rules band is full width (matches the title band).
    assert text["x"] == title["x"]
    assert text["w"] == title["w"]


def test_generate_single_band_when_no_lower():
    slots = _slots(4, 0)
    assert "@slot.pic4" in slots
    assert "@slot.pic5" not in slots
    ys = {slots[f"@slot.pic{n}"]["y"] for n in range(1, 5)}
    assert len(ys) == 1  # one band -> a single row


def test_generate_wild_cluster_appended_to_top_band():
    slots = _slots(3, 0, has_wild=True)
    assert {"@slot.wild", "@slot.wildpay", "@slot.wildvalue"} <= set(slots)
    # wild sits in the top band, to the right of the last symbol.
    assert slots["@slot.wild"]["x"] > slots["@slot.pic3"]["x"]
    assert slots["@slot.wild"]["y"] == slots["@slot.pic1"]["y"]


def test_generate_never_empty():
    slots = _slots(0, 0)
    assert any(k.startswith("@slot.pic") for k in slots)


def test_generate_no_overlap_within_band():
    slots = _slots(5, 0)
    for i in range(1, 5):
        prev = slots[f"@slot.pic{i}.value"]
        nxt = slots[f"@slot.pic{i + 1}"]
        assert prev["x"] + prev["w"] <= nxt["x"]


def test_generate_layout_wraps_slots_with_meta():
    tpl = paytable_layouts.generate_paytable_layout(2, 1, has_wild=False)
    assert tpl["canvas"] == {"width": 1920, "height": 1080}
    assert tpl["slot_prefix"] == "@slot"
    assert tpl["mapper_meta"]["auto_generated"] is True
    assert tpl["mapper_meta"]["top_count"] == 2
    assert tpl["mapper_meta"]["lower_count"] == 1
    assert tpl["slots"]


def test_auto_is_default_layout():
    layouts = paytable_layouts.list_paytable_layouts()
    default = next((l for l in layouts if l.get("default")), None)
    assert default is not None
    assert default["name"] == "auto"
    # simple is still selectable, just no longer the default.
    assert any(l["name"] == "simple" for l in layouts)


def test_get_auto_layout_resolves_to_template():
    tpl = paytable_layouts.get_paytable_layout("auto")
    assert isinstance(tpl, dict)
    assert tpl["slots"]
    assert tpl["mapper_meta"]["auto_generated"] is True


def test_sheet_structure_detects_counts(tmp_path):
    openpyxl = pytest.importorskip("openpyxl")
    from ps_autotypesetter.ui_web import engine_api

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Paytable"
    # anchor in col A, pay in col B, value in col C; two picN + two royals.
    rows = [("<PIC1>", 5, 100), ("<PIC2>", 4, 50), ("<ACE>", 3, 25), ("<KING>", 2, 10)]
    for i, (name, pay, val) in enumerate(rows):
        r = 2 + i
        ws.cell(row=r, column=1, value=name)
        ws.cell(row=r, column=2, value=pay)
        ws.cell(row=r, column=3, value=val)
    path = tmp_path / "pt.xlsx"
    wb.save(str(path))

    st = engine_api.paytable_sheet_structure(str(path), "Paytable")
    assert st["total"] == 4
    assert st["top"] + st["lower"] == 4
    assert st["top"] == 2  # two picN-named anchors -> top band of 2
    assert st["has_wild"] is False
    # ordered anchor keys (top row first, then lower) drive real-name layout.
    assert st["block_keys"] == ["pic1", "pic2", "ace", "king"]


def test_sheet_structure_missing_file_is_all_zero():
    from ps_autotypesetter.ui_web import engine_api

    st = engine_api.paytable_sheet_structure("X:/does/not/exist.xlsx", "Paytable")
    assert st == {"top": 0, "lower": 0, "total": 0, "has_wild": False,
                  "has_scatter": False, "max_pay_rows": 0, "symbols": [],
                  "block_keys": []}


# --- placement: pay/value vertical alignment vs the symbol ------------------
# The generator stamps a `vertical_align` hint on the pay/value slot boxes so
# the automapper (which otherwise defaults pay/value to "top") renders them
# CENTERED beside the icon (right/left) and TOP-aligned below it. This is the
# hint `engine_api._slot_valign` reads.

def _pay_value_valigns(slots):
    return {v.get("vertical_align")
            for k, v in slots.items()
            if k.endswith(".pay") or k.endswith(".value")
            or k in ("@slot.wildpay", "@slot.wildvalue")}


def test_placement_right_centers_pay_value():
    slots = _slots(3, 0)  # right is the default
    assert _pay_value_valigns(slots) == {"center"}
    # geometry unchanged: icon left, pay then value to its right.
    for n in range(1, 4):
        icon, pay, value = slots[f"@slot.pic{n}"], slots[f"@slot.pic{n}.pay"], slots[f"@slot.pic{n}.value"]
        assert icon["x"] < pay["x"] < value["x"]
        assert icon["y"] == pay["y"] == value["y"]


def test_placement_left_centers_and_icon_on_right():
    slots = _slots(3, 0, placement="left")
    assert _pay_value_valigns(slots) == {"center"}
    for n in range(1, 4):
        icon, pay, value = slots[f"@slot.pic{n}"], slots[f"@slot.pic{n}.pay"], slots[f"@slot.pic{n}.value"]
        # pay then value on the LEFT, icon on the RIGHT of both.
        assert pay["x"] < value["x"] < icon["x"]
        assert icon["y"] == pay["y"] == value["y"]


def test_placement_below_top_aligns_and_stacks():
    slots = _slots(3, 0, placement="below")
    assert _pay_value_valigns(slots) == {"top"}
    for n in range(1, 4):
        icon, pay, value = slots[f"@slot.pic{n}"], slots[f"@slot.pic{n}.pay"], slots[f"@slot.pic{n}.value"]
        # icon on top (full cell width), pay + value side-by-side beneath it.
        assert icon["y"] < pay["y"]
        assert pay["y"] == value["y"]
        assert pay["x"] < value["x"]
        assert icon["w"] > pay["w"] and icon["w"] > value["w"]


def test_placement_below_wild_cluster_top_aligned():
    slots = _slots(2, 0, has_wild=True, placement="below")
    assert slots["@slot.wildpay"]["vertical_align"] == "top"
    assert slots["@slot.wildvalue"]["vertical_align"] == "top"


# --- explicit rows x cols grid (row-major, auto-fit) ------------------------

def _icon_nums(slots):
    import re
    rx = re.compile(r"^@slot\.pic(\d+)$")
    return sorted(int(m.group(1)) for m in (rx.match(k) for k in slots) if m)


def test_grid_rows_cols_row_major():
    names = [f"pic{i}" for i in range(1, 7)]
    slots = paytable_layouts.generate_paytable_slots(6, 0, top_names=names, rows=2, cols=3)
    assert _icon_nums(slots) == [1, 2, 3, 4, 5, 6]
    # exactly two rows (two distinct y bands), three symbols each.
    ys = sorted({slots[f"@slot.{nm}"]["y"] for nm in names})
    assert len(ys) == 2
    top_y, bot_y = ys
    # row-major: first three names on the top row, next three below.
    assert all(slots[f"@slot.{nm}"]["y"] == top_y for nm in names[:3])
    assert all(slots[f"@slot.{nm}"]["y"] == bot_y for nm in names[3:])
    # columns increase left-to-right within a row.
    xs = [slots[f"@slot.{nm}"]["x"] for nm in names[:3]]
    assert xs == sorted(xs) and len(set(xs)) == 3


def test_grid_autofit_grows_rows_never_drops():
    # a 2x4 grid holds 8, but 10 symbols must all be placed (rows grow to 3).
    names = [f"pic{i}" for i in range(1, 11)]
    slots = paytable_layouts.generate_paytable_slots(10, 0, top_names=names, rows=2, cols=4)
    assert _icon_nums(slots) == list(range(1, 11))
    assert len({slots[f"@slot.{nm}"]["y"] for nm in names}) == 3  # grew to 3 rows


def test_grid_single_dim_derives_other():
    names = [f"pic{i}" for i in range(1, 7)]
    # cols only -> rows derived (6 / 2 = 3 rows).
    slots = paytable_layouts.generate_paytable_slots(6, 0, top_names=names, cols=2)
    assert _icon_nums(slots) == [1, 2, 3, 4, 5, 6]
    assert len({slots[f"@slot.{nm}"]["y"] for nm in names}) == 3


def test_grid_combines_both_bands():
    # top + lower symbols flatten into one ordered grid list.
    slots = paytable_layouts.generate_paytable_slots(
        0, 0, top_names=["pic1", "pic2"], lower_names=["ace", "king"], rows=2, cols=2)
    for nm in ("pic1", "pic2", "ace", "king"):
        assert f"@slot.{nm}" in slots


def test_layout_meta_records_placement_grid():
    tpl = paytable_layouts.generate_paytable_layout(5, 5, placement="below", rows=3, cols=4)
    meta = tpl["mapper_meta"]
    assert meta["placement"] == "below"
    assert meta["rows"] == 3
    assert meta["cols"] == 4
    # auto (no rows/cols) records None for the grid dims.
    auto = paytable_layouts.generate_paytable_layout(5, 5)
    assert auto["mapper_meta"]["placement"] == "right"
    assert auto["mapper_meta"]["rows"] is None
    assert auto["mapper_meta"]["cols"] is None
