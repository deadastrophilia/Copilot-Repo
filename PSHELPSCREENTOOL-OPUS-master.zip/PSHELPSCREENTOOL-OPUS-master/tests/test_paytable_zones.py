"""Zone layouts on paytable pages: rows like [SCATTER box | rules text | WILD box], each item shown by
its rule (auto: only when the Excel has it), a hidden item's room going to the others."""
import copy
import os

import pytest

from ps_autotypesetter.dynamic_pages.paytable import card_templates as ct
from ps_autotypesetter.ui_web import engine_api

REF = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "ExcelFileForReference")
THUNDER = os.path.join(REF, "ThunderEmpire_MongolianEmpress_AGR_HHRE.xlsx")
NINE = os.path.join(REF, "AGR 9 Pages.xlsx")
ROW = [{"id": "top", "pos": "top", "h": 300, "items": [
    {"kind": "scatter", "w": 1}, {"kind": "text", "id": "notes", "w": 2}, {"kind": "wild", "w": 1, "title": "SUBSTITUTES"}]}]
# the same row with its WILD shown always: these sheets' WILD has no pays of its own (only the rules name it), so
# "auto" leaves it out — "always" is the artist asking for the box anyway
ROW_WILD = copy.deepcopy(ROW)
ROW_WILD[0]["items"][2]["show"] = "always"


def _layout(excel, sheet, zones=ROW, **changes):
    if not os.path.isfile(excel):
        pytest.skip("reference Excel not here")
    t = copy.deepcopy(ct.get_template("classic_cards"))
    t["zones"] = copy.deepcopy(zones)
    t.update(changes)
    cfg = dict(engine_api.DEFAULT_CONFIG, excel_path=excel)
    res, _ = engine_api.auto_map_page(cfg, sheet, "", {"card_template": t, "dry_run": True})
    assert res["ok"], res.get("error")
    return res["_template"]["mapper_meta"], {m["slot"]: m for m in res["_mappings"]}


def test_zone_lays_out_scatter_rules_wild_side_by_side_above_the_cards():
    meta, maps = _layout(THUNDER, "Paytable-100-50-25lines", ROW_WILD)
    b = meta["blocks"]
    assert b["scatter"][2] <= b["text:notes"][0] and b["text:notes"][2] <= b["wild"][0]      # in the zone's order
    assert b["text:notes"][2] - b["text:notes"][0] > 1.8 * (b["wild"][2] - b["wild"][0])    # w 2 : 1
    assert b["cards"][1] >= b["zone:top"][3]                                                  # the cards below the row
    assert maps["@slot.wildbox.tab"]["text"] == "SUBSTITUTES"                                 # the zone's own title


def test_auto_hides_what_the_excel_has_not_and_the_others_take_its_room():
    meta, _ = _layout(NINE, "Paytable")                # no SCATTER, a WILD only named in the rules (no pays)
    b = meta["blocks"]
    assert "scatter" not in b and "wild" not in b             # a box only for a real card of the AGR
    assert abs(b["text:notes"][0] - b["zone:top"][0]) < 1     # the rules text starts where the SCATTER would be
    assert abs(b["text:notes"][2] - b["zone:top"][2]) < 1     # …and takes the WILD's room too
    items = {i["key"]: i for i in meta["zones"][0]["items"]}
    assert items["scatter"]["visible"] is False and items["scatter"]["has"] is False
    assert items["wild"]["visible"] is False and items["wild"]["has"] is False


def test_never_and_always():
    zones = copy.deepcopy(ROW)
    zones[0]["items"][2]["show"] = "never"
    zones[0]["items"][0]["show"] = "always"
    meta, _ = _layout(NINE, "Paytable", zones)
    assert "wild" not in meta["blocks"] and "scatter" in meta["blocks"]


def test_a_row_with_nothing_to_show_takes_no_room():
    zones = [{"id": "bottom", "pos": "bottom", "h": 260, "items": [{"kind": "scatter"}]}]
    meta, _ = _layout(NINE, "Paytable", zones)
    assert "zone:bottom" not in meta["blocks"] and meta["zones"][0]["rect"] is None


def test_wild_reel_rule_is_the_wild_boxs_caption_not_rules_text():
    meta, maps = _layout(THUNDER, "Paytable-100-50-25lines", ROW_WILD)
    assert "reels 2, 3, 4 and 5" in maps["@slot.wildbox.label"]["text"]
    assert "appear on reels" not in meta["text_info"]["full"]
    assert "substitute for all symbols" in maps["@slot.wildbox.text"]["text"]


def test_bottom_rows_stack_up_from_the_bottom_margin():
    zones = [{"id": "boxes", "pos": "bottom", "h": 220, "items": [{"kind": "wild"}, {"kind": "scatter"}]}]
    meta, _ = _layout(THUNDER, "Paytable-100-50-25lines", zones)
    b = meta["blocks"]
    bottom = 1080 - float(ct.get_template("classic_cards")["page"].get("bottom", 30))
    assert b["zone:boxes"][3] == pytest.approx(bottom, abs=1) and b["cards"][3] <= b["zone:boxes"][1]


def test_a_boxs_own_words_typed_over_and_styled():
    import hashlib
    h = hashlib.sha1("pay any".encode("utf-8")).hexdigest()[:12]
    meta, maps = _layout(THUNDER, "Paytable-100-50-25lines", text_overrides={h: "Pays anywhere."},
                         features={"enabled": True, "scatter_parts": None})
    assert maps["@slot.scatbox.label"]["text"] == "Pays anywhere."
    assert meta["box_texts"]["@slot.scatbox.label"] == {"hash": h, "original": "pay any"}
