"""Unit tests for page_layout.py — the PageLayout model + serializer."""

import json

import pytest

from ps_autotypesetter.page_layout import (
    Element,
    PageLayout,
    PageLayoutError,
    RectElement,
    TextElement,
    element_from_dict,
    layouts_from_json,
    layouts_to_json,
)


def test_text_element_roundtrip():
    element = TextElement(
        element_id="body_3",
        x=320.0,
        y=180.0,
        width=3200.0,
        height=140.0,
        text="GAME RULES",
        font="Arial Bold",
        size=72.0,
        bold=True,
        color=[255, 255, 255],
        align="center",
        line_spacing=4.0,
        wrapped_lines=["GAME RULES"],
        line_heights=[86.0],
        effects={"stroke_enabled": True, "stroke_size": 3},
        style_role="Heading",
    )
    restored = element_from_dict(element.to_dict())
    assert isinstance(restored, TextElement)
    assert restored.id == element.id
    assert restored.type == "text"
    assert restored.x == element.x
    assert restored.y == element.y
    assert restored.width == element.width
    assert restored.height == element.height
    assert restored.font == element.font
    assert restored.size == element.size
    assert restored.bold is True
    assert restored.color == [255, 255, 255]
    assert restored.wrapped_lines == ["GAME RULES"]
    assert restored.line_heights == [86.0]
    assert restored.effects == element.effects


def test_rect_element_roundtrip():
    rect = RectElement(
        element_id="bg_1",
        x=100.0,
        y=200.0,
        width=500.0,
        height=300.0,
        fill_rgb=(20, 20, 30),
        fill_opacity=0.7,
        stroke_rgb=(255, 255, 255),
        stroke_width=2.0,
    )
    restored = element_from_dict(rect.to_dict())
    assert isinstance(restored, RectElement)
    assert restored.type == "rect"
    assert restored.fill_rgb == [20, 20, 30]
    assert restored.fill_opacity == pytest.approx(0.7)
    assert restored.stroke_width == 2.0


def test_unknown_element_type_falls_back_to_base():
    element = element_from_dict({"id": "x", "type": "unknown", "x": 5})
    assert isinstance(element, Element)
    assert element.type == "element"
    assert element.x == 5.0


def test_page_layout_roundtrip_json():
    layout = PageLayout(
        source={"excel_path": "c:/work/example.xlsx", "sheet_name": "PAGE1", "page_index": 0, "layout_mode": "normal"},
        canvas={"width": 1920, "height": 1080},
        safe_area={"left": 100, "top": 120, "width": 1720, "height": 880, "bottom": 1000},
        margins={"margin_x": 100, "heading_top_margin": 120},
    )
    layout.add(TextElement(element_id="heading_1", x=100, y=120, width=1720, height=90, text="PAGE1", font="Arial", size=72, wrapped_lines=["PAGE1"], line_heights=[90]))
    layout.add(TextElement(element_id="body_1", x=100, y=300, width=1720, height=40, text="hello world", font="Arial", size=30, wrapped_lines=["hello world"], line_heights=[40]))

    raw = layout.to_json()
    data = json.loads(raw)
    assert data["version"] == 1
    assert len(data["elements"]) == 2

    restored = PageLayout.from_dict(data)
    assert restored.source["sheet_name"] == "PAGE1"
    assert restored.canvas["width"] == 1920
    assert restored.elements[0].id == "heading_1"
    assert restored.find("body_1") is not None
    assert restored.find("missing") is None


def test_layouts_json_list_roundtrip():
    layouts = [
        PageLayout(source={"sheet_name": "A", "page_index": 0}),
        PageLayout(source={"sheet_name": "A", "page_index": 1}),
    ]
    restored = layouts_from_json(layouts_to_json(layouts))
    assert len(restored) == 2
    assert restored[1].source["page_index"] == 1


def test_save_load_file(tmp_path):
    layout = PageLayout(source={"sheet_name": "X"})
    layout.add(TextElement(element_id="e1", x=1, y=2, width=3, height=4))
    path = tmp_path / "layout.json"
    layout.save(str(path))
    loaded = PageLayout.load(str(path))
    assert loaded.find("e1") is not None
    assert loaded.source["sheet_name"] == "X"


def test_invalid_data_raises():
    with pytest.raises(PageLayoutError):
        PageLayout.from_dict("nope")


def test_color_normalization():
    element = TextElement(color="#FF8000")
    assert element.color == [255, 128, 0]
    element2 = TextElement(color=(1, 2, 3))
    assert element2.color == [1, 2, 3]
    element3 = TextElement(color=None)
    assert element3.color == [255, 255, 255]
