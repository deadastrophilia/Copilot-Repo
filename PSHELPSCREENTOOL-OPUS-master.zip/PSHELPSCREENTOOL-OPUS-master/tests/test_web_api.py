"""Smoke tests for the PsHelpScreenTool Web UI API (Flask test client)."""

import json
import os
import shutil
import tempfile

import pytest
from openpyxl import Workbook

from ps_autotypesetter.ui_web.server import create_app
from ps_autotypesetter.ui_web.ps_actions import is_photoshop_running


@pytest.fixture(scope="module")
def client(tmp_path_factory):
    session = os.path.join(str(tmp_path_factory.mktemp("session")), "session.json")
    app = create_app(session_file=session)
    return app.test_client()


@pytest.fixture(scope="module")
def excel_file(tmp_path_factory):
    folder = tmp_path_factory.mktemp("web")
    wb = Workbook()
    ws = wb.active
    ws.title = "Game Rules"
    ws.append(["GAME RULES", "", "", ""])
    ws.append(["1. Place your bet and press Spin.", "", "", ""])
    ws2 = wb.create_sheet("Paytable")
    ws2.append(["SYMBOL", "x2", "x3", "x5"])
    ws2.append(["Wild", "2", "5", "50"])
    ws3 = wb.create_sheet("Help Page")
    ws3.append(["HELP", "", "", ""])
    ws3.append(["Wild symbols substitute. Press <wild> to activate.", "", "", ""])
    path = os.path.join(str(folder), "sample.xlsx")
    wb.save(path)

    icon_dir = os.path.join(str(folder), "icons")
    os.makedirs(icon_dir, exist_ok=True)
    with open(os.path.join(icon_dir, "wild.png"), "wb") as f:
        f.write(b"\x89PNG\r\n\x1a\n" + b"\x00" * 64)
    return {"excel": path, "icons": icon_dir}


def test_index_served(client):
    res = client.get("/")
    assert res.status_code == 200
    assert b"PsHelpScreenTool" in res.data


def test_static_assets(client):
    assert client.get("/static/styles.css").status_code == 200
    assert client.get("/static/app.js").status_code == 200


def test_bootstrap(client):
    res = client.get("/api/bootstrap")
    assert res.status_code == 200
    data = res.get_json()
    assert data["app_title"] == "PsHelpScreenTool"
    assert isinstance(data["config"], dict)
    assert data["config"]["c_width"] == 1920
    assert len(data["canvas_presets"]) >= 4


def test_config_post_get(client):
    res = client.post("/api/config", json={"h_size": 77, "excel_path": "Z:\\mock.xlsx"})
    assert res.status_code == 200
    cfg = res.get_json()["config"]
    assert cfg["h_size"] == 77

    res = client.get("/api/config")
    assert res.get_json()["config"]["h_size"] == 77
    client.post("/api/config", json={"h_size": 60, "excel_path": ""})


def test_scan_excel(client, excel_file):
    res = client.post("/api/scan", json={"excel_path": excel_file["excel"], "icon_folder": excel_file["icons"]})
    assert res.status_code == 200
    data = res.get_json()
    excel = data["excel"]
    assert excel["ok"] is True
    names = [s["name"] for s in excel["sheets"]]
    assert "Game Rules" in names
    assert "Paytable" in names
    assert any(s["type"] == "game_rules" for s in excel["sheets"])
    assert any(s["type"] == "paytable" for s in excel["sheets"])
    assert any(s["type"] == "page" for s in excel["sheets"])

    icons = data["icons"]
    assert icons["ok"] is True
    assert icons["icon_count"] == 1
    assert "wild" in icons["tokens"]

    assert isinstance(data["suggestions"], list)
    assert len(data["suggestions"]) >= 3


def test_scan_missing_file(client):
    res = client.post("/api/scan", json={"excel_path": "Z:\\nope.xlsx"})
    assert res.status_code == 200
    assert res.get_json()["excel"]["ok"] is False


def test_presets_roundtrip(client):
    res = client.post("/api/presets/My Style", json={"config": {"h_size": 99, "b_size": 22}})
    assert res.status_code == 200
    res = client.get("/api/presets")
    assert "My Style" in res.get_json()["presets"]
    res = client.get("/api/presets/My Style")
    assert res.get_json()["preset"]["h_size"] == 99
    client.delete("/api/presets/My Style")
    res = client.get("/api/presets")
    assert "My Style" not in res.get_json()["presets"]


def test_ai_commands(client):
    client.post("/api/config", json={"h_size": 60, "c_width": 1920, "c_height": 1080})

    res = client.post("/api/ai", json={"command": "Make all headings larger"})
    data = res.get_json()
    assert data["ok"] is True
    assert data["config"]["h_size"] == 70

    res = client.post("/api/ai", json={"command": "Reduce body text by 10%"})
    data = res.get_json()
    assert data["config"]["b_size"] == pytest.approx(27, abs=1)

    res = client.post("/api/ai", json={"command": "Create a 4K version"})
    data = res.get_json()
    assert data["config"]["c_width"] == 3840
    assert data["config"]["c_height"] == 2160

    res = client.post("/api/ai", json={"command": "Center all icons"})
    assert res.get_json()["config"]["alignment"] == "center"

    res = client.post("/api/ai", json={"command": "blah blah gibberish"})
    assert res.get_json()["ok"] is True
    assert "I can help with" in res.get_json()["message"]


def test_build_requires_excel(client):
    client.post("/api/config", json={"excel_path": "", "output_dir": ""})
    res = client.post("/api/build", json={"mode": "png"})
    assert res.status_code == 400

    res = client.post("/api/build", json={"mode": "nonsense"})
    assert res.status_code == 400


def test_job_unknown(client):
    res = client.get("/api/jobs/nope123")
    assert res.status_code == 404


def test_ps_status_endpoint(client):
    res = client.get("/api/ps/status")
    assert res.status_code == 200
    data = res.get_json()
    assert "available" in data


def test_templates_endpoint(client):
    res = client.get("/api/templates")
    assert res.status_code == 200
    data = res.get_json()
    assert "templates" in data
    assert isinstance(data["templates"], list)


def test_mappings_roundtrip(client):
    res = client.get("/api/mappings")
    assert res.status_code == 200
    data = res.get_json()
    assert "mappings" in data and "size_overrides" in data and "tokens" in data

    res = client.post("/api/mappings", json={
        "icon_mappings": {"WILD": "wild.png"},
        "icon_size_overrides": {"WILD": 64},
    })
    assert res.status_code == 200
    res = client.get("/api/mappings")
    data = res.get_json()
    assert data["mappings"].get("WILD") == "wild.png"
    assert data["size_overrides"].get("WILD") == 64
    client.post("/api/mappings", json={"icon_mappings": {}, "icon_size_overrides": {}})


def test_capture_style_offline(client):
    from ps_autotypesetter.ui_web import ps_actions

    if ps_actions.is_photoshop_running():
        import pytest

        pytest.skip("Photoshop is running — capture-style succeeds.")
    res = client.post("/api/ps/capture-style", json={"mode": "selected", "target": "heading"})
    assert res.status_code == 200
    data = res.get_json()
    assert data["ok"] is False
    assert data["error"]


def test_ps_groups_offline(client):
    res = client.get("/api/ps/groups?psd_path=Z%3A%5Cnone.psd")
    assert res.status_code == 200
    assert res.get_json()["groups"] == []


def test_export_paytable_offline(client):
    from ps_autotypesetter.ui_web import ps_actions

    if ps_actions._photoshop_available():
        pytest.skip("photoshop.api is installed — export success depends on live Photoshop state")
    res = client.post("/api/export/paytable-json", json={"mode": "active"})
    assert res.status_code == 200
    data = res.get_json()
    assert data["ok"] is False


def test_export_batch_validation(client):
    client.post("/api/config", json={"prev_psd_path": "", "output_dir": ""})
    res = client.post("/api/export/batch", json={"psd_path": "", "output_folder": ""})
    assert res.status_code == 400
    assert "PSD path" in res.get_json()["error"]


def test_export_backup_validation(client):
    res = client.post("/api/export/backup", json={"psd_path": ""})
    assert res.status_code == 400

    res = client.post("/api/export/backup", json={"psd_path": "Z:\\does_not_exist.psd"})
    assert res.status_code == 200
    data = res.get_json()
    assert data["ok"] is False
    assert data["error"]


def _table_template():
    return {
        "name": "payoutTable",
        "canvas": {"width": 1920, "height": 1080},
        "slots": {
            "B2": {"x": 10, "y": 10, "w": 200, "h": 60},
            "C2": {"x": 210, "y": 10, "w": 200, "h": 60},
            "D2": {"x": 410, "y": 10, "w": 200, "h": 60},
        },
    }


def _paytable_template():
    return {
        "name": "payoutTable",
        "canvas": {"width": 1920, "height": 1080},
        "slots": {
            "ten.pay": {"x": 10, "y": 10, "w": 200, "h": 60},
            "ten.value": {"x": 210, "y": 10, "w": 200, "h": 60},
            "BottomCardsBG.1": {"x": 410, "y": 10, "w": 400, "h": 60},
            "wild.title": {"x": 10, "y": 80, "w": 400, "h": 40},
        },
    }


def test_paytable_mapper_global_styles_roundtrip(client):
    styles = {"pay": {"font_size": 44, "stroke_color": "#FF0000"}, "topbg": {"background_color": "#8774d2"}}
    res = client.post("/api/paytable_mapper/global_styles", json={"styles": styles})
    assert res.status_code == 200
    assert res.get_json()["ok"] is True

    cfg = client.get("/api/config").get_json()["config"]
    assert cfg["paytable_global_styles"] == styles

    res = client.post("/api/paytable_mapper/global_styles", json={"clear": True})
    assert res.get_json()["ok"] is True
    cfg = client.get("/api/config").get_json()["config"]
    assert cfg["paytable_global_styles"] == {}


def test_paytable_mapper_save_load_returns_path(client):
    template = _paytable_template()
    mappings = {
        "ten.pay": {"slot": "ten.pay", "mode": "text", "source": "B2", "color": "#FFFFFF"},
        "wild.title": {"slot": "wild.title", "mode": "text", "source": ""},
        "BottomCardsBG.1": {"slot": "BottomCardsBG.1", "mode": "text", "source": "", "background_color": "#8774d2", "fill_enabled": True},
    }
    payload = {
        "template_id": "payoutTable",
        "template": template,
        "mappings": list(mappings.values()),
        "slot_prefix": "@slot",
    }
    res = client.post("/api/paytable_mapper/save", json=payload)
    saved = res.get_json()
    assert saved["ok"] is True, saved
    assert saved["path"].endswith("payoutTable_mapped.json")

    res = client.post("/api/paytable_mapper/load", json={"path": saved["path"]})
    assert res.status_code == 200
    loaded = res.get_json()
    assert loaded["ok"] is True
    assert loaded["path"] == saved["path"]
    assert isinstance(loaded["global_styles"], dict)
    assert "BottomCardsBG.1" in loaded["mappings"]
    assert loaded["mappings"]["BottomCardsBG.1"]["background_color"] == "#8774d2"


def test_table_mapper_automap(client, excel_file):
    res = client.post(
        "/api/table_mapper/automap",
        json={"template": _table_template(), "excel_path": excel_file["excel"], "sheet_name": "Paytable"},
    )
    assert res.status_code == 200
    data = res.get_json()
    assert data["ok"] is True
    assert data["count"] == 3
    kinds = {m["slot"]: m["kind"] for m in data["mappings"]}
    assert kinds["B2"] == "flow"
    assert kinds["C2"] == "flow"


def test_table_mapper_source_range(client):
    mappings = [
        {"slot": "B4", "source": "B2"},
        {"slot": "C4", "source": "D2:F2"},
        {"slot": "B5", "source": "B3:D3"},
    ]
    res = client.post("/api/table_mapper/source_range", json={"mappings": mappings})
    assert res.status_code == 200
    assert res.get_json()["range"].startswith("B2:")


def test_table_mapper_save_load_roundtrip(client, excel_file):
    template = _table_template()
    mappings = [
        {"slot": "B2", "source": "B2", "kind": "flow", "role": "Symbol"},
        {"slot": "C2", "source": "D2:F2", "kind": "flow", "role": "Payout"},
    ]
    payload = {
        "table_name": "payoutTable",
        "excel_path": excel_file["excel"],
        "sheet_name": "Paytable",
        "source_range": "B2:F2",
        "template": template,
        "mappings": mappings,
        "insert_after_row": 4,
    }
    res = client.post("/api/table_mapper/save", json=payload)
    saved = res.get_json()
    assert saved["ok"] is True, saved
    assert saved["path"].endswith("payoutTable_mapped.json")

    cfg = client.get("/api/config").get_json()["config"]
    mapped = cfg["table_style"]["mapped_table_jsons"]
    assert saved["path"] in mapped
    overrides = cfg["table_style"]["json_sheet_overrides"]
    assert saved["path"] in overrides
    assert "Paytable" in overrides[saved["path"]]

    res = client.post("/api/table_template/load", json={"path": saved["path"]})
    assert res.status_code == 200
    loaded = res.get_json()
    assert loaded["ok"] is True
    assert loaded["table_name"] == "payoutTable"
    assert loaded["source_range"] == "B2:F2"
    assert loaded["preview_token"]

    res = client.get(f"/api/table_preview/{loaded['preview_token']}")
    assert res.status_code == 200
    assert res.mimetype == "image/png"


def test_table_template_load_missing(client):
    res = client.post("/api/table_template/load", json={"path": "Z:\\no_such_mapping.json"})
    assert res.status_code == 400


def test_paytable_automap_anchor_blocks(client, tmp_path_factory):
    """Pay/value slots are filled from symbol anchor blocks: anchor cell
    (<PIC1>, PIC2, ACE — with or without <>) -> first numeric column right is
    pay, second is value; block top/bottom is the numeric run nearest the
    anchor row. Supports shifted columns and varying row counts."""
    from ps_autotypesetter.table_mapping import resolve_paytable_source_text

    folder = tmp_path_factory.mktemp("pt_automap")
    wb = Workbook()
    ws = wb.active
    ws.title = "Paytable"

    ws["A2"] = "<PIC1>"  # pay F2:F5, value H2:H5, anchor centered, junk col G
    for col, values in ((6, [5, 4, 3, 2]), (8, [150, 50, 10, 5])):
        for i, v in enumerate(values):
            ws.cell(row=2 + i, column=col, value=v)
    for i in range(4):
        ws.cell(row=2 + i, column=7, value="x")

    ws["A7"] = "PIC2"  # plain label, shifted pay/value columns G/I, 3 rows
    for col, values in ((7, [5, 4, 3]), (9, [100, 30, 5])):
        for i, v in enumerate(values):
            ws.cell(row=7 + i, column=col, value=v)

    ws["A11"] = "ACE"  # anchor below the block top (rows 10-12)
    for col, values in ((6, [5, 4, 3]), (8, [50, 10, 5])):
        for i, v in enumerate(values):
            ws.cell(row=10 + i, column=col, value=v)

    ws["A15"] = "<WILD>"  # wildpay/wildvalue anchors
    for col, values in ((6, [100, 50]), (8, [1000, 250])):
        for i, v in enumerate(values):
            ws.cell(row=15 + i, column=col, value=v)

    ws["A19"] = 10  # "ten" written as a bare NUMBER (the reported bug)
    for col, values in ((6, [5, 4, 3, 2]), (8, [150, 50, 25, 10])):
        for i, v in enumerate(values):
            ws.cell(row=19 + i, column=col, value=v)

    ws["A24"] = "Ten"  # mixed-case word label must resolve "ten" too
    for col, values in ((6, [5, 4, 3]), (8, [100, 40, 20])):
        for i, v in enumerate(values):
            ws.cell(row=24 + i, column=col, value=v)

    ws["A28"] = "tEn"
    for col, values in ((6, [5, 4]), (8, [60, 30])):
        for i, v in enumerate(values):
            ws.cell(row=28 + i, column=col, value=v)

    path = os.path.join(str(folder), "pt.xlsx")
    wb.save(path)

    slots = {}
    for sym in ("pic1", "pic2", "pic3", "ace", "ten"):
        slots[sym + ".pay"] = {}
        slots[sym + ".value"] = {}
    slots["wildpay"] = {}
    slots["wildvalue"] = {}
    for sym in ("pic1", "pic2", "ace"):
        slots[sym] = {}

    res = client.post(
        "/api/paytable_mapper/automap",
        json={"template": {"slots": slots}, "excel_path": path, "sheet_name": "Paytable"},
    )
    assert res.status_code == 200
    data = res.get_json()
    assert data["ok"] is True
    sources = {m["slot"]: m.get("source", "") for m in data["mappings"]}
    by_slot = {m["slot"]: m for m in data["mappings"]}

    # Symbol slots must never be treated as phantom cell refs: "pic1" with an
    # anchor cell "<PIC1>" in the sheet maps to the name icon, not cell "PIC1".
    assert by_slot["pic1"]["mode"] == "icon"
    assert by_slot["pic1"]["token"] == "<pic1>"
    assert not by_slot["pic1"].get("source")
    assert by_slot["pic2"]["mode"] == "icon" and by_slot["pic2"]["token"] == "<pic2>"
    assert by_slot["ace"]["mode"] == "icon" and by_slot["ace"]["token"] == "<ace>"

    # Pay/value slots: vertical top align + literal resolved text
    assert by_slot["pic1.pay"]["vertical_align"] == "top"
    assert by_slot["pic1.pay"]["text"] == "5\n4\n3\n2"
    assert by_slot["pic1.value"]["vertical_align"] == "top"
    assert by_slot["pic1.value"]["text"] == "150\n50\n10\n5"
    assert by_slot["ace.pay"]["text"] == "5\n4\n3"
    assert by_slot["wildpay"]["vertical_align"] == "top"
    assert by_slot["wildpay"]["text"] == "100\n50"
    assert by_slot["wildvalue"]["text"] == "1000\n250"
    assert data["sheet_dims"] == {"rows": 29, "cols": 9}

    from openpyxl import load_workbook

    wb2 = load_workbook(path, data_only=True, read_only=True)
    ws2 = wb2["Paytable"]

    def resolved(slot):
        return resolve_paytable_source_text(ws2, sources[slot])

    assert resolved("pic1.pay") == "5\n4\n3\n2"
    assert resolved("pic1.value") == "150\n50\n10\n5"
    assert resolved("pic2.pay") == "5\n4\n3"
    assert resolved("pic2.value") == "100\n30\n5"
    assert resolved("ace.pay") == "5\n4\n3"
    assert resolved("ace.value") == "50\n10\n5"
    wb2.close()

    unmapped = sorted(data["unmapped"])
    assert "pic3.pay" in unmapped and "pic3.value" in unmapped

    # The "ten" card: whatever way Excel spells it (bare number 10, "Ten",
    # "tEn"), the ten.pay / ten.value slots must pick up its pay/value cells.
    assert "ten.pay" not in unmapped and "ten.value" not in unmapped
    assert by_slot["ten.pay"]["text"] == "5\n4\n3\n2"
    assert by_slot["ten.value"]["text"] == "150\n50\n25\n10"


def test_paytable_templates_roundtrip(client, tmp_path_factory, monkeypatch):
    """PaytableTemplates: list, save, import JSON from PC, active-PSD guard."""
    import ps_autotypesetter.ui_web.paytable_templates as pt_mod

    folder = tmp_path_factory.mktemp("paytable_templates")
    monkeypatch.setattr(pt_mod, "templates_dir", lambda: str(folder))

    doc = {
        "template_id": "MyDesign",
        "canvas": {"width": 1920, "height": 1080},
        "slots": {"@slot.title": {"x": 60, "y": 40, "w": 1800, "h": 80}},
    }

    res = client.post("/api/paytable_templates/save", json={"name": "MyDesign", "template": doc})
    assert res.status_code == 200
    assert res.get_json()["ok"] is True

    res = client.get("/api/paytable_templates")
    assert res.status_code == 200
    names = [t["name"] for t in res.get_json()["templates"]]
    assert names == ["MyDesign"]
    assert res.get_json()["templates"][0]["slot_count"] == 1

    json_file = os.path.join(str(folder), "imported_design.json")
    with open(json_file, "w", encoding="utf-8") as f:
        json.dump({"template_id": "Imported", "canvas": {"width": 3840, "height": 2160},
                   "slots": {"a": {"x": 0, "y": 0, "w": 10, "h": 10}}}, f)
    res = client.post("/api/paytable_templates/import", json={"path": json_file})
    assert res.status_code == 200
    data = res.get_json()
    assert data["ok"] is True and data["name"] == "Imported" and data["slots"] == 1
    assert os.path.basename(data["path"]) == "Imported.json"

    bad = os.path.join(str(folder), "bad.txt")
    with open(bad, "w", encoding="utf-8") as f:
        f.write("nope")
    res = client.post("/api/paytable_templates/import", json={"path": bad})
    assert res.status_code == 400

    res = client.post("/api/paytable_templates/import", json={"path": os.path.join(str(folder), "missing.psd")})
    assert res.status_code == 400

    res = client.post("/api/paytable_templates/import_active", json={})
    # Photoshop may be running with a document that has @slot.* layers on this
    # dev machine, in which case the import succeeds (200). Only assert a clean
    # 400 guard when Photoshop is NOT running.
    if not is_photoshop_running():
        assert res.status_code == 400


# ---------------------------------------------------------------- project discovery

@pytest.fixture(scope="module")
def game_folder(tmp_path_factory):
    """A Perforce-style game folder: Excel + Symbols/ + background + output + PSD."""
    folder = tmp_path_factory.mktemp("game")
    wb = Workbook()
    ws = wb.active
    ws.title = "Paytable"
    ws.append(["SYMBOL", "x2"])
    ws.append(["Wild", "5"])
    wb.save(os.path.join(str(folder), "GameRules.xlsx"))
    symbols = os.path.join(str(folder), "Symbols")
    os.makedirs(symbols)
    with open(os.path.join(symbols, "a.png"), "wb") as f:
        f.write(b"\x89PNG\r\n\x1a\n" + b"\x00" * 32)
    with open(os.path.join(str(folder), "background.png"), "wb") as f:
        f.write(b"\x89PNG\r\n\x1a\n" + b"\x00" * 32)
    os.makedirs(os.path.join(str(folder), "output"))
    with open(os.path.join(str(folder), "Paytable.psd"), "w", encoding="utf-8") as f:
        f.write("8BPS")
    return str(folder)


def test_update_diff_preview(client, excel_file, tmp_path):
    """Update PSD flow: the diff preview reports changed/added/removed pages
    between the Old Excel (diff source) and the New Excel."""
    folder = str(tmp_path / "update")
    os.makedirs(folder)
    old_path = os.path.join(folder, "old.xlsx")
    wb = Workbook()
    ws = wb.active
    ws.title = "Game Rules"
    ws.append(["GAME RULES", "", "", ""])
    ws.append(["1. Original line.", "", "", ""])
    ws2 = wb.create_sheet("Paytable")
    ws2.append(["SYMBOL", "x2", "x3", "x5"])
    ws2.append(["Wild", "2", "5", "50"])
    wb.save(old_path)

    # New Excel: same sheets, one edited cell + one new sheet.
    new_path = os.path.join(folder, "new.xlsx")
    wb = Workbook()
    ws = wb.active
    ws.title = "Game Rules"
    ws.append(["GAME RULES", "", "", ""])
    ws.append(["1. Changed line.", "", "", ""])
    ws2 = wb.create_sheet("Paytable")
    ws2.append(["SYMBOL", "x2", "x3", "x5"])
    ws2.append(["Wild", "2", "5", "50"])
    ws3 = wb.create_sheet("New Page")
    ws3.append(["NEW", "", "", ""])
    wb.save(new_path)

    res = client.post("/api/update/preview", json={
        "prev_excel_path": old_path,
        "excel_path": new_path,
        "max_col_limit": 12,
    })
    assert res.status_code == 200
    data = res.get_json()
    assert data["ok"] is True
    diff = data["diff"]
    assert diff["changed"] == ["Game Rules"]
    assert diff["added"] == ["New Page"]
    assert diff["removed"] == []
    assert "Paytable" in diff["unchanged"]

    # Missing inputs never raise — empty diff.
    res = client.post("/api/update/preview", json={"prev_excel_path": "Z:\\nope.xlsx", "excel_path": new_path})
    assert res.status_code == 200
    assert res.get_json()["ok"] is True


def test_run_build_save_modes_plumbing(client):
    """update_save_mode decides overwrite_existing; regular builds keep the
    user's toggle. Exercise through the engine API without starting a build."""
    from ps_autotypesetter.ui_web import engine_api

    base = {"excel_path": "", "icon_folder": "", "bg_path": "", "prev_excel_path": "",
            "prev_psd_path": "C:\\old.psd", "output_name": "", "output_dir": "",
            "max_col_limit": 12, "update_mode": True}
    kw = engine_api._build_kwargs(base)

    # new_copy must not overwrite the old PSD
    cfg = dict(base, update_save_mode="new_copy")
    if cfg["update_mode"]:
        kw["overwrite_existing"] = (cfg.get("update_save_mode") or "overwrite") == "overwrite"
    assert kw["overwrite_existing"] is False

    # overwrite mode writes in place
    cfg = dict(base, update_save_mode="overwrite")
    if cfg["update_mode"]:
        kw["overwrite_existing"] = (cfg.get("update_save_mode") or "overwrite") == "overwrite"
    assert kw["overwrite_existing"] is True

    # regular build (no update_mode) keeps its own toggle
    cfg = dict(base, update_mode=False, update_save_mode="new_copy", overwrite_existing=True)
    kw["overwrite_existing"] = bool(cfg.get("overwrite_existing"))
    assert kw["overwrite_existing"] is True


def _write_workbook(path, sheets_lines):
    wb = Workbook()
    wb.remove(wb.active)
    for name, rows in sheets_lines.items():
        ws = wb.create_sheet(name)
        for row in rows:
            ws.append(row)
    wb.save(path)
    return path


def test_project_package_baseline_lifecycle(tmp_path):
    """Baseline: created on first build, skipped on re-build, advanced only
    via force (successful update), untouched by errors."""
    from ps_autotypesetter import project_package as pp

    psd = str(tmp_path / "MyGame.psd")
    v1 = _write_workbook(str(tmp_path / "v1.xlsx"), {
        "Game Rules": [["GAME RULES", "", "", ""], ["1. Spin.", "", "", ""]],
        "Paytable": [["SYMBOL", "x2"], ["Wild", "2"]],
    })

    res = pp.commit_baseline(psd, v1, 12)
    assert res["ok"] and res["action"] == "created" and res["version_number"] == 1
    baseline = res["baseline"]
    assert os.path.isfile(baseline)
    assert baseline == pp.baseline_path_for_psd(psd)
    assert os.path.isfile(pp.baseline_manifest_path_for_psd(psd))

    info = pp.load_baseline_info(psd)
    assert info["exists"] and info["version_number"] == 1
    assert info["file_hash"] == pp.file_sha256(baseline)
    assert info["original_path"] == os.path.abspath(v1)
    assert len(info["data"]["pages"]) == 2

    # a regular (non-update) re-build must not advance the baseline
    res = pp.commit_baseline(psd, v1, 12)
    assert res["action"] == "skipped" and res["version_number"] == 1

    # advance only after a successful update
    v2 = _write_workbook(str(tmp_path / "v2.xlsx"), {
        "Game Rules": [["GAME RULES", "", "", ""], ["1. Changed line.", "", "", ""]],
        "Paytable": [["SYMBOL", "x2"], ["Wild", "5"]],
    })
    res = pp.commit_baseline(psd, v2, 12, force=True)
    assert res["action"] == "advanced" and res["version_number"] == 2
    assert pp.file_sha256(baseline) == pp.file_sha256(v2)
    assert pp.load_baseline_info(psd)["version_number"] == 2

    # a failed save must never touch the baseline
    before = pp.file_sha256(baseline)
    res = pp.commit_baseline(psd, str(tmp_path / "nope.xlsx"), 12, force=True)
    assert res["action"] == "error"
    assert pp.file_sha256(baseline) == before
    assert pp.load_baseline_info(psd)["version_number"] == 2


def test_update_preview_resolves_baseline(client, tmp_path_factory):
    """Old Excel is optional: the saved baseline is the diff source; identical
    files short-circuit with no_changes; an explicit Old Excel still wins."""
    from ps_autotypesetter import project_package as pp

    folder = tmp_path_factory.mktemp("blprev")
    psd = str(folder / "Game.psd")
    v1 = _write_workbook(str(folder / "v1.xlsx"), {
        "Game Rules": [["GAME RULES", "", "", ""], ["1. Spin.", "", "", ""]],
        "Paytable": [["SYMBOL", "x2"], ["Wild", "2"]],
    })
    v2 = _write_workbook(str(folder / "v2.xlsx"), {
        "Game Rules": [["GAME RULES", "", "", ""], ["1. Changed.", "", "", ""]],
        "Paytable": [["SYMBOL", "x2"], ["Wild", "2"]],
    })
    pp.commit_baseline(psd, v1, 12)

    res = client.post("/api/update/preview", json={
        "prev_psd_path": psd, "excel_path": v2, "max_col_limit": 12,
    })
    assert res.status_code == 200
    data = res.get_json()
    assert data["ok"] is True
    assert data["baseline_used"] is True
    assert data["baseline"]["exists"] is True
    assert data["baseline"]["version_number"] == 1
    assert os.path.isfile(data["prev_excel_path"])
    assert data["prev_excel_path"].replace("\\", "/").endswith("source/baseline.xlsx")
    assert data["diff"]["changed"] == ["Game Rules"]
    assert "Paytable" in data["diff"]["unchanged"]

    # byte-identical workbook -> fast path, no sheet hashing at all
    res = client.post("/api/update/preview", json={
        "prev_psd_path": psd, "excel_path": v1, "max_col_limit": 12,
    })
    data = res.get_json()
    assert data["no_changes"] is True
    assert data["diff"]["changed"] == [] and data["diff"]["details"] == []

    # an explicit Old Excel overrides the baseline
    other = _write_workbook(str(folder / "other.xlsx"), {"Other": [["X", ""]]})
    res = client.post("/api/update/preview", json={
        "prev_psd_path": psd, "prev_excel_path": other,
        "excel_path": v2, "max_col_limit": 12,
    })
    data = res.get_json()
    assert data["baseline_used"] is False
    assert data["prev_excel_path"].replace("\\", "/").endswith("other.xlsx")


def test_detect_package_reports_baseline(client, tmp_path_factory):
    """detect returns the package dict (fixes the manifest-string bug) and the
    baseline state."""
    from ps_autotypesetter import project_package as pp

    folder = tmp_path_factory.mktemp("detectbl")
    psd = str(folder / "MyGame.psd")
    excel = _write_workbook(str(folder / "src.xlsx"), {"Game Rules": [["GAME RULES", "", "", ""]]})
    pkg = pp.write_project_package({"excel_path": excel, "prev_psd_path": psd}, psd)
    assert pkg["ok"]
    pp.commit_baseline(psd, excel, 12)

    res = client.post("/api/project/detect", json={"psd": psd})
    assert res.status_code == 200
    data = res.get_json()
    assert data["ok"] is True and data["exists"] is True
    assert (data["package"] or {})["files"]["excel"]["absolute"] == os.path.abspath(excel)
    assert data["baseline"]["exists"] is True
    assert data["baseline"]["version_number"] == 1

    # a PSD without a baseline reports exists False (legacy recovery path)
    bare_psd = str(folder / "Bare.psd")
    res = client.post("/api/project/detect", json={"psd": bare_psd})
    data = res.get_json()
    assert data["ok"] is True and data["exists"] is False
    assert data["baseline"]["exists"] is False


def test_run_build_baseline_lifecycle(client, tmp_path_factory, monkeypatch):
    """run_build creates the baseline on first PSD save, advances it after a
    successful update, preserves it on failure, and skips the whole Photoshop
    round-trip when the current Excel is byte-identical to the baseline."""
    from ps_autotypesetter import build_engine
    from ps_autotypesetter import project_package as pp
    from ps_autotypesetter.ui_web import engine_api, ps_actions

    folder = tmp_path_factory.mktemp("rbbaseline")
    psd = str(folder / "Game.psd")
    excel = _write_workbook(str(folder / "src.xlsx"), {
        "Game Rules": [["GAME RULES", "", "", ""], ["1. Spin.", "", "", ""]],
    })

    calls = {"n": 0, "fail": False}

    def fake_execute_build(**kwargs):
        calls["n"] += 1
        return None if calls["fail"] else psd

    from ps_autotypesetter.psd_writer import build as psd_build

    monkeypatch.setattr(build_engine, "execute_build", fake_execute_build)
    monkeypatch.setattr(psd_build, "build_psd", fake_execute_build)
    monkeypatch.setattr(ps_actions, "ensure_com_initialized", lambda: None)

    base = {"excel_path": excel, "icon_folder": "", "bg_path": "", "prev_psd_path": psd,
            "prev_excel_path": "", "update_mode": True, "update_save_mode": "overwrite",
            "max_col_limit": 12, "output_name": "", "output_dir": "", "safe_backup": False,
            "write_links_folder": True}   # the optional _Links baseline (PSDs also carry their own)

    # first update: no baseline yet -> created V1
    out = engine_api.run_build(dict(base), "psd")
    assert out.get("psd_path") == os.path.abspath(psd)
    assert calls["n"] == 1
    info = pp.load_baseline_info(psd)
    assert info["exists"] and info["version_number"] == 1

    # changed workbook + successful save -> baseline advances to V2
    excel_v2 = _write_workbook(str(folder / "src2.xlsx"), {
        "Game Rules": [["GAME RULES", "", "", ""], ["1. New spin.", "", "", ""]],
    })
    base["excel_path"] = excel_v2
    out = engine_api.run_build(dict(base), "psd")
    assert out.get("psd_path") == os.path.abspath(psd)
    info = pp.load_baseline_info(psd)
    assert info["version_number"] == 2
    assert info["file_hash"] == pp.file_sha256(excel_v2)

    # failed save -> baseline stays V2
    excel_v3 = _write_workbook(str(folder / "src3.xlsx"), {
        "Game Rules": [["GAME RULES", "", "", ""], ["1. Broken.", "", "", ""]],
    })
    base["excel_path"] = excel_v3
    calls["fail"] = True
    out = engine_api.run_build(dict(base), "psd")
    assert not out.get("psd_path")
    info = pp.load_baseline_info(psd)
    assert info["version_number"] == 2
    assert info["file_hash"] == pp.file_sha256(excel_v2)
    calls["fail"] = False

    # byte-identical workbook -> fast path: engine never called
    shutil.copyfile(info["baseline"], excel_v3)
    base["excel_path"] = excel_v3
    before = calls["n"]
    out = engine_api.run_build(dict(base), "psd")
    assert calls["n"] == before
    assert not out.get("psd_path")
    assert out.get("skipped") == "unchanged"  # the UI says "already up to date", not "built"
    info = pp.load_baseline_info(psd)
    assert info["version_number"] == 2


def test_project_discover_ok(client, game_folder):
    res = client.post("/api/project/discover", json={"folder": game_folder})
    assert res.status_code == 200
    data = res.get_json()
    assert data["ok"] is True
    assert data["found"]["folder"] is True
    assert data["found"]["excel"] is True
    assert data["found"]["icons"] is True
    assert data["found"]["background"] is True
    assert data["found"]["output"] is True
    assert data["missing"] == []
    assert data["excel_path"].replace("\\", "/").endswith("GameRules.xlsx")
    assert data["icon_folder"].replace("\\", "/").endswith("Symbols")
    assert data["output_will_be_created"] is False
    assert len(data["psd_files"]) == 1
    assert data["psd_files"][0].replace("\\", "/").endswith("Paytable.psd")
    assert data["name"] == os.path.basename(game_folder)


def test_project_discover_partial(tmp_path, client):
    empty = str(tmp_path / "emptygame")
    os.makedirs(empty)
    res = client.post("/api/project/discover", json={"folder": empty})
    assert res.status_code == 200
    data = res.get_json()
    assert data["ok"] is True
    assert data["excel_path"] is None
    assert data["found"]["excel"] is False
    assert set(data["missing"]) == {"excel", "icons", "background"}


def test_project_discover_bad_folder(client):
    res = client.post("/api/project/discover", json={"folder": "Z:\\definitely\\not\\here"})
    assert res.status_code == 200
    data = res.get_json()
    assert data["ok"] is False
    assert "error" in data


def test_project_discover_excel_candidates(client, tmp_path):
    folder = str(tmp_path / "multi")
    os.makedirs(folder)
    for name in ("GameRules.xlsx", "Paytable.xlsx"):
        wb = Workbook()
        wb.active.title = "S"
        wb.active.append(["x"])
        wb.save(os.path.join(folder, name))
    res = client.post("/api/project/discover", json={"folder": folder})
    data = res.get_json()
    assert data["ok"] is True
    assert data["excel_count"] == 2
    assert len(data["excel_candidates"]) == 2
    assert data["excel_path"].split(os.sep)[-1] == "GameRules.xlsx"


def test_project_open_recents(client):
    res = client.post("/api/project/open", json={"folder": "Z:\\games\\BuffaloGold", "name": "Buffalo Gold"})
    assert res.status_code == 200
    cfg = res.get_json()["config"]
    assert cfg["recent_projects"][0] == {
        "folder": "Z:\\games\\BuffaloGold",
        "name": "Buffalo Gold",
        "opened_at": cfg["recent_projects"][0]["opened_at"],
    }

    res = client.post("/api/project/open", json={"folder": "Z:\\games\\Lucky7"})
    cfg = res.get_json()["config"]
    assert cfg["recent_projects"][0]["folder"] == "Z:\\games\\Lucky7"
    # re-opening the same folder moves it to the top without duplicating
    res = client.post("/api/project/open", json={"folder": "Z:\\games\\BuffaloGold"})
    cfg = res.get_json()["config"]
    folders = [e["folder"] for e in cfg["recent_projects"]]
    assert folders == ["Z:\\games\\BuffaloGold", "Z:\\games\\Lucky7"]

    res = client.get("/api/bootstrap")
    assert isinstance(res.get_json()["config"]["recent_projects"], list)


def test_page_preview_thumbnail(client, excel_file):
    """Project Pages card thumbnails: renders the real PNG pipeline for one
    sheet into a throwaway temp dir and serves it via the preview token."""
    client.post("/api/config", json={
        "excel_path": excel_file["excel"],
        "icon_folder": excel_file["icons"],
        "bg_source": "color",
        "bg_color": "#000000",
        "output_dir": "",
    })
    res = client.post("/api/page_preview", json={"sheet_name": "Game Rules"})
    assert res.status_code == 200
    data = res.get_json()
    assert data["ok"] is True
    assert data["preview_token"]
    assert data["sheet_name"] == "Game Rules"
    assert data["pages"] >= 1

    img = client.get(f"/api/table_preview/{data['preview_token']}")
    assert img.status_code == 200
    assert img.data[:8] == b"\x89PNG\r\n\x1a\n"

    # unknown sheet name -> renderer error path
    res = client.post("/api/page_preview", json={"sheet_name": "No Such Sheet"})
    assert res.status_code == 200
    assert res.get_json()["ok"] is False

    # missing workbook -> guarded 400
    client.post("/api/config", json={"excel_path": ""})
    res = client.post("/api/page_preview", json={"sheet_name": "Game Rules"})
    assert res.status_code == 400
    assert res.get_json()["ok"] is False
    client.post("/api/config", json={"excel_path": excel_file["excel"]})


def test_pages_preview_batch(client, excel_file):
    """Project Pages grid: one round trip returns a {sheet: token} map with a
    valid PNG per sheet; unknown sheets land in the errors map."""
    client.post("/api/config", json={
        "excel_path": excel_file["excel"],
        "icon_folder": excel_file["icons"],
        "bg_source": "color",
        "bg_color": "#000000",
        "output_dir": "",
    })
    res = client.post("/api/pages_preview", json={
        "sheets": ["Game Rules", "Paytable", "Help Page", "No Such Sheet"],
    })
    assert res.status_code == 200
    data = res.get_json()
    assert data["ok"] is True
    assert data["total"] == 4
    assert set(data["thumbs"].keys()) == {"Game Rules", "Paytable", "Help Page"}
    assert "No Such Sheet" in data["errors"]
    for token in data["thumbs"].values():
        img = client.get(f"/api/table_preview/{token}")
        assert img.status_code == 200
        assert img.data[:8] == b"\x89PNG\r\n\x1a\n"
    # second call is served from the disk cache (same tokens, no re-render)
    res2 = client.post("/api/pages_preview", json={"sheets": ["Game Rules"]})
    assert res2.status_code == 200
    assert res2.get_json()["thumbs"].get("Game Rules") == data["thumbs"]["Game Rules"]
    # no workbook -> guarded 400
    client.post("/api/config", json={"excel_path": ""})
    assert client.post("/api/pages_preview", json={"sheets": ["Game Rules"]}).status_code == 400
    client.post("/api/config", json={"excel_path": excel_file["excel"]})


def test_pages_thumb_direct(client, excel_file):
    """Project Pages grid tiles load PNGs straight from the disk-cached
    thumbnail URL — no token registry, no client-side orchestration."""
    client.post("/api/config", json={
        "excel_path": excel_file["excel"],
        "icon_folder": excel_file["icons"],
        "bg_source": "color",
        "bg_color": "#000000",
        "output_dir": "",
    })
    img = client.get("/api/pages_thumb/Game%20Rules")
    assert img.status_code == 200
    assert img.data[:8] == b"\x89PNG\r\n\x1a\n"
    # second hit is served from the disk cache
    img2 = client.get("/api/pages_thumb/Game%20Rules")
    assert img2.status_code == 200
    assert img2.data == img.data
    # unknown sheet -> 404 with error json
    res = client.get("/api/pages_thumb/No%20Such%20Sheet")
    assert res.status_code == 404
    assert res.get_json()["ok"] is False
    # no workbook -> guarded 400
    client.post("/api/config", json={"excel_path": ""})
    assert client.get("/api/pages_thumb/Game%20Rules").status_code == 400
    client.post("/api/config", json={"excel_path": excel_file["excel"]})


def test_layer_style_swatch_draws_the_style(tmp_path):
    import io
    import json as _json

    from PIL import Image

    session = tmp_path / "s.json"
    style = {"stroke_enabled": True, "stroke_rgb": "#FF0000", "stroke_size": 6, "stroke_opacity": 100}
    session.write_text(_json.dumps({"dynamic_settings": {"layer_style_library": {"Red edge": style}}}), encoding="utf-8")
    c = create_app(session_file=str(session)).test_client()
    styled = Image.open(io.BytesIO(c.get("/api/layer-styles/swatch?name=Red%20edge").data)).convert("RGBA")
    plain = Image.open(io.BytesIO(c.get("/api/layer-styles/swatch?name=nothing").data)).convert("RGBA")
    reds = lambda im: sum(1 for r, g, b, a in im.getdata() if a > 128 and r > 180 and g < 80 and b < 80)
    assert styled.size == plain.size
    assert reds(styled) > 200 and reds(plain) == 0          # the stroke is drawn; no style = plain white text
