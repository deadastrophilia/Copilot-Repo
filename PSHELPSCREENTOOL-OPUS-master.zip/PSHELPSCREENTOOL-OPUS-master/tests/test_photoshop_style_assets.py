"""Tests for the Photoshop-assisted layer-style rendering hybrid system
(photoshop_style_assets + its canonical_png integration)."""

import json
import os
import tempfile

import pytest

from ps_autotypesetter import photoshop_style_assets as psa
from ps_autotypesetter.config import (
    photoshop_style_assets_enabled,
    set_photoshop_style_assets_enabled,
)
from ps_autotypesetter.page_layout import TextElement


@pytest.fixture(autouse=True)
def _reset_flag_and_cache(tmp_path):
    from ps_autotypesetter import photoshop_heading_renderer as phr

    set_photoshop_style_assets_enabled(None)
    psa._PS_PROBE = psa._PS_PROBE_UNSET
    phr._PS_PROBE = None
    original_cache = psa._CACHE_DIR
    psa._CACHE_DIR = str(tmp_path / "style_cache")
    os.makedirs(psa._CACHE_DIR, exist_ok=True)
    yield
    set_photoshop_style_assets_enabled(None)
    psa._PS_PROBE = psa._PS_PROBE_UNSET
    phr._PS_PROBE = None
    psa._CACHE_DIR = original_cache


def _element(**overrides):
    values = dict(
        element_id="el1", x=120.0, y=90.0, width=1680.0, height=66.0,
        text="Styled line", font="Arial", size=52.0, bold=True, italic=False,
        color=[255, 255, 255], align="center", line_height=66.0,
        line_spacing=8.0, wrapped_lines=["Styled line"], line_heights=[66.0],
        line_widths=[660.0], effects=None,
    )
    values.update(overrides)
    return TextElement(**values)


# ---------------------------------------------------------------------------
# Simple vs complex style split
# ---------------------------------------------------------------------------


def test_is_complex_style_false_for_empty_and_legacy_styles():
    assert psa.is_complex_style(None) is False
    assert psa.is_complex_style({}) is False
    legacy = {
        "stroke_enabled": True, "stroke_size": 3,
        "shadow_enabled": True, "shadow_distance": 4,
    }
    assert psa.is_complex_style(legacy) is False


def test_is_complex_style_true_for_captured_and_pasted():
    assert psa.is_complex_style({"captured_effects_hex": "0f0f0f0f"}) is True
    assert psa.is_complex_style({"paste_copied_style": True}) is True


def test_is_complex_style_by_effect_type():
    single = {
        "captured_params": {
            "drop_shadow": {"enabled": True},
        },
    }
    assert psa.is_complex_style(single) is False
    for key in ("inner_glow", "color_overlay", "gradient_overlay",
                "bevel", "satin", "pattern_overlay"):
        assert psa.is_complex_style({"captured_params": {key: {"enabled": True}}}) is True, key
    combined_simple = {
        "captured_params": {
            "drop_shadow": {"enabled": True},
            "outer_glow": {"enabled": True},
            "stroke": {"enabled": True},
        },
    }
    assert psa.is_complex_style(combined_simple) is True


def test_is_complex_style_unknown_effect_key_is_complex():
    assert psa.is_complex_style({"captured_params": {"userDefinedFX": {"ok": 1}}}) is True


# ---------------------------------------------------------------------------
# Cache key determinism + invalidation semantics
# ---------------------------------------------------------------------------


def test_asset_cache_key_deterministic():
    a = _element()
    b = _element()
    assert psa.asset_cache_key(a) == psa.asset_cache_key(b)
    assert len(psa.asset_cache_key(a)) == 64


def test_asset_cache_key_sensitive_to_render_props():
    base = psa.asset_cache_key(_element())
    mutators = [
        {"wrapped_lines": ["Changed line"]},
        {"font": "Times New Roman"},
        {"size": 40.0},
        {"bold": False},
        {"italic": True},
        {"color": [10, 20, 30]},
        {"align": "left"},
        {"width": 1600.0},
        {"line_heights": [70.0]},
        {"line_spacing": 14.0},
        {"effects": {"stroke_enabled": True, "stroke_size": 5}},
    ]
    for change in mutators:
        assert psa.asset_cache_key(_element(**change)) != base, change


def test_asset_cache_key_ignores_unrelated_meta():
    a = psa.asset_cache_key(_element(meta={"source_page": 7}))
    b = psa.asset_cache_key(_element(meta={"source_page": 8}))
    assert a == b


# ---------------------------------------------------------------------------
# Element routing
# ---------------------------------------------------------------------------


def test_style_path_off_flag_and_env():
    # Photoshop rendering is opt-in: the Photoshop-free engine is the default.
    assert photoshop_style_assets_enabled() is False
    assert psa.element_style_path(_element(effects={"captured_effects_hex": "00"})) == "pil"
    set_photoshop_style_assets_enabled(False)
    assert psa.element_style_path(_element(effects={"captured_effects_hex": "00"})) == "pil"
    set_photoshop_style_assets_enabled(True)
    assert psa.element_style_path(_element(effects={"captured_effects_hex": "00"})) == "photoshop"


def test_style_path_simple_vs_complex():
    set_photoshop_style_assets_enabled(True)
    assert psa.element_style_path(_element(effects=None)) == "pil"
    assert psa.element_style_path(_element(effects={"stroke_enabled": True})) == "pil"
    assert psa.element_style_path(_element(effects={"captured_effects_hex": "00"})) == "photoshop"
    assert psa.element_style_path(_element()) == "pil"


def test_style_path_icon_lines_stay_on_pil():
    el = _element(effects={"captured_effects_hex": "00"},
                  wrapped_lines=["Line with <icon> token"])
    assert psa.element_style_path(el) == "pil"


# ---------------------------------------------------------------------------
# Compositing math
# ---------------------------------------------------------------------------


def test_composite_places_ink_at_text_origin(tmp_path):
    from PIL import Image

    asset = Image.new("RGBA", (20, 20), (0, 0, 0, 0))
    for y in range(3, 13):
        for x in range(5, 15):
            asset.putpixel((x, y), (255, 0, 0, 255))
    asset_path = str(tmp_path / "asset.png")
    asset.save(asset_path)
    meta = {"ink_bounds": [5, 3, 15, 13],
            "render_size": [20, 20],
            "offset": [5, 3],
            "logical_size": [1680, 66],
            "resolved_font": "ArialMT"}

    page = Image.new("RGBA", (500, 300), (255, 255, 255, 255))
    assert psa.composite_style_asset(page, asset_path, _element(), meta) is True
    el = _element()
    pad = max(40, int(el.size) * 2)
    box_width = max(el.width, 1680)
    max_lw = max(el.line_widths)
    text_origin_x = el.x + max(0, (box_width - max_lw) / 2.0)
    doc_text_origin_x = pad + max(0.0, (box_width - max_lw) / 2.0)
    ax = int(round(text_origin_x - doc_text_origin_x))
    ay = int(round(el.y - meta["ink_bounds"][1]))
    assert page.getpixel((ax + meta["ink_bounds"][0], ay + meta["ink_bounds"][1])) == (255, 0, 0, 255)
    assert page.getpixel((ax + meta["ink_bounds"][0] - 1, ay + meta["ink_bounds"][1] - 1)) == (255, 255, 255, 255)
    assert psa.composite_style_asset(page, asset_path + ".missing", _element(), meta) is False


# ---------------------------------------------------------------------------
# Validation page — Photoshop missing (exact fallback proving nothing breaks)
# ---------------------------------------------------------------------------


def test_validation_page_without_photoshop(tmp_path, monkeypatch):
    set_photoshop_style_assets_enabled(True)
    monkeypatch.setattr(psa, "photoshop_available", lambda: False)
    out = str(tmp_path / "validation.png")
    errors = []
    result = psa.render_validation_page(out, style_errors=errors)
    assert os.path.isfile(out)
    assert os.path.getsize(out) > 0
    paths = {item["id"]: item["path"] for item in result["elements"]}
    assert paths["validate_1"] == "pil"
    assert paths["validate_2"] == "pil"
    assert paths["validate_3"] == "pil"
    assert paths["validate_4"] == "pil"
    assert paths["validate_5"] == "pil"
    assert paths["validate_6"] == "photoshop"
    assert paths["validate_7"] == "photoshop"
    assert paths["validate_8"] == "photoshop"
    assert paths["validate_9"] == "photoshop"
    messages = " ".join(errors)
    assert "Photoshop is required" in messages
    assert "validate_6" in messages and "validate_9" in messages
    assert "validate_2" not in messages
    from PIL import Image

    img = Image.open(out)
    assert img.size == (1920, 80 + 9 * 96)


# ---------------------------------------------------------------------------
# Validation page — Photoshop mocked (PS assets composited end-to-end)
# ---------------------------------------------------------------------------


def test_validation_page_with_mocked_photoshop(tmp_path, monkeypatch):
    set_photoshop_style_assets_enabled(True)
    monkeypatch.setattr(psa, "photoshop_available", lambda: True)

    asset = None
    from PIL import Image

    asset = Image.new("RGBA", (24, 24), (0, 0, 0, 0))
    for y in range(6, 20):
        for x in range(4, 22):
            asset.putpixel((x, y), (0, 200, 255, 255))
    asset_path = str(tmp_path / "mock_asset.png")
    asset.save(asset_path)
    meta = {"ink_bounds": [4, 6, 22, 20], "render_size": [24, 24],
            "offset": [4, 6], "logical_size": [1680, 66],
            "resolved_font": "ArialMT"}

    def fake_render(element):
        return asset_path, dict(meta)

    monkeypatch.setattr(psa, "render_style_asset", fake_render)
    out = str(tmp_path / "validation_ps.png")
    errors = []
    result = psa.render_validation_page(out, style_errors=errors)
    assert os.path.isfile(out)
    rendered = [m for m in errors if m.startswith("Photoshop rendered")]
    assert len(rendered) == 4
    assert "Photoshop is required" not in " ".join(errors)
    from PIL import Image

    img = Image.open(out).convert("RGBA")
    cyan = (0, 200, 255, 255)
    import numpy as np
    arr = np.array(img)
    has_cyan = np.any(
        (arr[:, :, 0] == cyan[0]) & (arr[:, :, 1] == cyan[1]) &
        (arr[:, :, 2] == cyan[2]) & (arr[:, :, 3] == cyan[3])
    )
    assert has_cyan, "Mock PS assets should be composited into the validation page"
    assert result["elements"][7]["path"] == "photoshop"


# ---------------------------------------------------------------------------
# Canonical integration: cache assets reused; unrelated style untouched
# ---------------------------------------------------------------------------

CACHE_DIR = None


def test_cached_asset_usable_without_photoshop(tmp_path, monkeypatch):
    """A previously rendered asset serves elements even when PS is offline —
    final exports do not silently degrade once the artist rendered once."""
    set_photoshop_style_assets_enabled(True)
    monkeypatch.setattr(psa, "photoshop_available", lambda: True)

    el = _element(effects={"captured_effects_hex": "00"})
    from PIL import Image

    key = psa.asset_cache_key(el)
    cache_dir = psa.style_cache_dir()
    asset_path = os.path.join(cache_dir, key + ".png")
    meta_path = os.path.join(cache_dir, key + ".json")
    img = Image.new("RGBA", (10, 10), (0, 0, 0, 0))
    img.save(asset_path)
    with open(meta_path, "w", encoding="utf-8") as fh:
        json.dump({"ink_bounds": [1, 1, 8, 8], "render_size": [10, 10],
                   "offset": [1, 1], "logical_size": [10, 10],
                   "resolved_font": "ArialMT"}, fh)
    try:
        monkeypatch.setattr(psa, "photoshop_available", lambda: False)
        found, meta = psa.render_style_asset(_element(effects={"captured_effects_hex": "00"}))
        assert found == asset_path
        assert meta["offset"] == [1, 1]
    finally:
        for p in (asset_path, meta_path):
            try:
                os.remove(p)
            except OSError:
                pass