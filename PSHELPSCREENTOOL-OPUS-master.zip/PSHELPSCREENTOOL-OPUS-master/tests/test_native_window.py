"""Tests for the native window bridge (pywebview dialogs)."""

from webview.util import parse_file_type

from ps_autotypesetter.ui_web.window import (
    NativeApi,
    _ALL_TYPES,
    _EXCEL_TYPES,
    _IMAGE_TYPES,
    _JSON_TYPES,
)


class MockWindow:
    def __init__(self):
        self.calls = []

    def create_file_dialog(self, *args, **kwargs):
        self.calls.append((args, kwargs))
        return ("C:\\work\\sample.xlsx",)


class MockWindowSave:
    def __init__(self):
        self.calls = []

    def create_file_dialog(self, *args, **kwargs):
        self.calls.append((args, kwargs))
        return "C:\\work\\mapped_tables\\payoutTable_mapped.json"


class MockWindowCancel:
    def create_file_dialog(self, *args, **kwargs):
        return None


class MockWindowFail:
    def create_file_dialog(self, *args, **kwargs):
        raise RuntimeError("dialog failed")


def test_file_type_filters_are_valid():
    for f in (*_EXCEL_TYPES, *_IMAGE_TYPES, *_ALL_TYPES):
        desc, ext = parse_file_type(f)
        assert desc and ext.startswith("*.")


def test_browse_file_excel():
    w = MockWindow()
    api = NativeApi(w)
    path = api.browse_file("excel")
    assert path == "C:\\work\\sample.xlsx"
    args, kwargs = w.calls[0]
    assert kwargs["file_types"] == _EXCEL_TYPES
    assert kwargs["allow_multiple"] is False


def test_browse_file_image():
    w = MockWindow()
    api = NativeApi(w)
    assert api.browse_file("image") == "C:\\work\\sample.xlsx"
    assert w.calls[0][1]["file_types"] == _IMAGE_TYPES


def test_browse_file_all():
    w = MockWindow()
    api = NativeApi(w)
    assert api.browse_file("other") == "C:\\work\\sample.xlsx"
    assert w.calls[0][1]["file_types"] == _ALL_TYPES


def test_browse_folder():
    w = MockWindow()
    api = NativeApi(w)
    assert api.browse_folder() == "C:\\work\\sample.xlsx"
    assert w.calls[0][0][0] is not None  # a dialog type constant was passed


def test_browse_cancel_returns_empty():
    api = NativeApi(MockWindowCancel())
    assert api.browse_file("excel") == ""
    assert api.browse_folder() == ""


def test_browse_failure_returns_empty():
    api = NativeApi(MockWindowFail())
    assert api.browse_file("excel") == ""
    assert api.browse_folder() == ""


def test_save_file_returns_path():
    w = MockWindowSave()
    api = NativeApi(w)
    path = api.save_file("Save mapped table JSON", "payoutTable_mapped.json")
    assert path == "C:\\work\\mapped_tables\\payoutTable_mapped.json"
    args, kwargs = w.calls[0]
    assert kwargs["file_types"] == _JSON_TYPES
    assert kwargs["save_filename"] == "payoutTable_mapped.json"


def test_save_file_default_name():
    w = MockWindowSave()
    api = NativeApi(w)
    assert api.save_file("Save", "") == "C:\\work\\mapped_tables\\payoutTable_mapped.json"
    assert w.calls[0][1]["save_filename"] == "file.json"


def test_save_file_cancel_returns_empty():
    api = NativeApi(MockWindowCancel())
    assert api.save_file("Save") == ""


def test_save_file_failure_returns_empty():
    api = NativeApi(MockWindowFail())
    assert api.save_file("Save") == ""
