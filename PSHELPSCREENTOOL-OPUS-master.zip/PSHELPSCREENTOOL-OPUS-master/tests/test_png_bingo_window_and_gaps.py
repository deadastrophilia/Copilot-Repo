"""PNG Bingo Rules renderer must honor the master-border window like PSD
(stray cells past the window's columns are never rendered), and the icon
spacing sliders must reach the renderers through the merged dynamic
settings in both the live preview and the final build."""

from openpyxl import Workbook
from openpyxl.styles import Font

from ps_autotypesetter import png_builder
from ps_autotypesetter.ui_web import engine_api


def _ink_count(img):
    gray = img.convert("L")
    w, h = gray.size
    px = gray.load()
    return sum(1 for y in range(h) for x in range(w) if px[x, y] < 250)


def _render_bingo(page_max_col):
    wb = Workbook()
    ws = wb.active
    ws.title = "BINGO RULES"
    ws.cell(row=2, column=1, value="BINGO RULES").font = Font(bold=True)
    ws.cell(row=4, column=1, value="All wins pay left to right on adjacent reels.").font = Font(bold=False)
    ws.cell(row=6, column=1, value="Valid coin sizes are displayed in the table.").font = Font(bold=False)
    ws.cell(row=20, column=13, value="<UPDATE> unreleased marketing marker outside the border")
    Image, ImageDraw, ImageFont = png_builder._require_pillow()
    pages = png_builder._render_bingo_rules_png_pages(
        Image, ImageDraw, ImageFont, ws, "BINGO RULES",
        bg_path="", bg_mode="stretch", bg_color="#FFFFFF",
        canvas_w=1920, canvas_h=1080,
        h_font="Arial", h_size=72, h_icon_h=48, h_rgb="#FF5050",
        b_font="Arial", b_size=30, b_icon_h=24, b_rgb="#101010",
        margin_x=100, heading_top_margin=120, heading_to_body_gap=40, bottom_margin=80,
        line_spacing=4, para_spacing=12,
        icon_folder="", icon_mappings={}, icon_size_overrides={},
        dynamic_settings={}, alignment_settings={},
        page_max_col=page_max_col, page_min_col=1,
    )
    return pages[0], ws


def test_bingo_renderer_skips_columns_outside_window():
    windowed, _ = _render_bingo(page_max_col=12)  # stray sits in column 13
    full, _ = _render_bingo(page_max_col=100)
    assert _ink_count(windowed) < _ink_count(full)


def test_bingo_window_respects_min_col():
    cleaned, _ = _render_bingo(page_max_col=12)
    assert _ink_count(cleaned) > 0  # body rows inside the window still render


def test_merged_dynamic_settings_folds_icon_gap_sliders():
    merged = engine_api._merged_dynamic_settings({
        "heading_icon_gap_left": 90,
        "heading_icon_gap_right": 80,
        "icon_gap_left": 70,
        "icon_gap_right": 60,
    })
    assert merged["heading_icon_gap_left"] == 90
    assert merged["heading_icon_gap_right"] == 80
    assert merged["icon_gap_left"] == 70
    assert merged["icon_gap_right"] == 60


def test_merged_dynamic_settings_keeps_explicit_dynamic_values_when_unset():
    merged = engine_api._merged_dynamic_settings({
        "dynamic_settings": {"icon_gap_left": 55, "icon_gap_right": 44},
    })
    assert merged["icon_gap_left"] == 55
    assert merged["icon_gap_right"] == 44
    assert "heading_icon_gap_left" not in merged


def test_build_kwargs_carries_gaps_to_dynamic_settings():
    kw = engine_api._build_kwargs({
        "excel_path": "x.xlsx",
        "icon_folder": "",
        "bg_path": "",
        "output_dir": "out",
        "heading_icon_gap_left": 120,
        "icon_gap_left": 60,
    })
    ds = kw["dynamic_settings"]
    assert ds["heading_icon_gap_left"] == 120
    assert ds["icon_gap_left"] == 60