"""New-game discovery: flexible folder names, Excel fallback, symbols, settings modes."""
import os

import pytest
from openpyxl import Workbook
from PIL import Image

from ps_autotypesetter import games
from ps_autotypesetter.ui_web import engine_api


def _excel(path, sheets=("Paytable", "Game Rules")):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    wb = Workbook()
    wb.active.title = sheets[0]
    for s in sheets[1:]:
        wb.create_sheet(s)
    wb.save(path)
    return str(path)


@pytest.fixture(autouse=True)
def _registry(tmp_path, monkeypatch):
    monkeypatch.setattr(games, "REGISTRY_FILE", str(tmp_path / "registry.json"))


def test_docs_folder_names_and_market_prefixes(tmp_path):
    game = tmp_path / "Game B"
    _excel(game / "Help Documentation" / "NYL - New York" / "B_NYL.xlsx")
    _excel(game / "Help Documentation" / "HHR_2024" / "B_HHR.xlsx")
    (game / "Production" / "Video").mkdir(parents=True)
    found = games.discover(str(game))
    assert found["layout"] == "depot"
    assert [m["name"] for m in found["markets"]] == ["NYL", "HHR"]
    assert found["markets"][0]["excel_path"].endswith("B_NYL.xlsx")
    assert found["markets"][0]["working"].endswith(os.path.join("Video", "NYL", "Help Screen", "Working"))


def test_excel_moved_out_of_its_market_folder_is_still_found(tmp_path):
    game = tmp_path / "Game C"
    _excel(game / "Game Docs" / "NYL" / "C_AGR_NYL.xlsx")
    (game / "Game Docs" / "ATLS").mkdir(parents=True)                       # market folder now empty
    _excel(game / "Game Docs" / "Archive" / "C_AGR_ATLS.xlsx")              # moved elsewhere in the docs
    _excel(game / "Art" / "misc" / "C_AGR_HHR.xlsx")                        # moved outside the docs
    found = games.discover(str(game))
    markets = {m["name"]: m for m in found["markets"]}
    assert set(markets) == {"NYL", "ATLS", "HHR"}
    assert markets["ATLS"]["excel_path"].endswith("C_AGR_ATLS.xlsx") and markets["ATLS"]["outside_market_folder"]
    assert markets["HHR"]["excel_path"].endswith("C_AGR_HHR.xlsx")
    assert not markets["NYL"]["outside_market_folder"]


def test_unrelated_excels_rank_low_and_choices_are_offered(tmp_path):
    game = tmp_path / "Game D"
    _excel(game / "Game Docs" / "NYL" / "D_HelpScreen_NYL.xlsx")
    _excel(game / "Game Docs" / "NYL" / "D_Rules_NYL_v2.xlsx")
    _excel(game / "Game Docs" / "NYL" / "D_math_budget_NYL.xlsx", sheets=("Sheet1",))
    _excel(game / "Game Docs" / "Notes.xlsx", sheets=("Sheet1",))
    found = games.discover(str(game))
    nyl = found["markets"][0]
    assert "math" not in os.path.basename(nyl["excel_path"]).lower()
    assert not any("math_budget" in c for c in nyl["excel_candidates"])   # clearly not a help-screen workbook
    assert nyl["ambiguous"] and len(nyl["excel_candidates"]) == 2         # two plausible: the user picks


def test_symbols_folder_found_or_left_empty_never_inherited(tmp_path):
    game = tmp_path / "Game E"
    _excel(game / "Game Docs" / "NYL" / "E_NYL.xlsx")
    found = games.discover(str(game))
    assert found["icon_folder"] == ""
    g = games.create(str(game), base_config={"icon_folder": r"C:\Old Game\symbols", "bg_path": r"C:\Old Game\bg.png", "b_size": 31})
    assert "icon_folder" not in g["style"] and "bg_path" not in g["style"]   # nothing from the old game
    sym = game / "Game Docs" / "Art" / "Symbols"
    sym.mkdir(parents=True)
    for i in range(4):
        Image.new("RGBA", (10, 10)).save(sym / f"s{i}.png")
    assert games.discover(str(game))["icon_folder"] == str(sym)


def test_settings_current_keeps_formatting_drops_paths(tmp_path):
    game = tmp_path / "Game F"
    _excel(game / "Game Docs" / "NYL" / "F_NYL.xlsx")
    base = {
        "h_font": "Impact", "h_size": 64, "b_size": 29,
        "icon_folder": r"E:\Games\Old\icons", "bg_path": r"E:\Games\Old\bg.png",
        "icon_mappings": {"wild": "wild_old.png"},
        "dynamic_settings": {"template_json": r"E:\Games\Old\pt.json", "layer_style_library": {"Gold": {"fx": 1}},
                             "text_style_rules": [{"kind": "word", "text": "Extra"}]},
        "table_style": {"mapped_table_jsons": "E:\\Games\\Old\\t1.json\nE:\\Games\\Old\\t2.json", "row_gap": 9},
        "alignment_settings": {"heading_image_folder": r"E:\Games\Old\Heading", "global": {"body": "left"}},
    }
    g = games.create(str(game), base_config=base, settings_mode="current")
    st = g["style"]
    assert (st["h_font"], st["h_size"], st["b_size"]) == ("Impact", 64, 29)
    assert st["dynamic_settings"]["layer_style_library"] == {"Gold": {"fx": 1}}
    assert st["table_style"]["row_gap"] == 9 and "mapped_table_jsons" not in st["table_style"]
    assert st["alignment_settings"]["global"] == {"body": "left"}
    assert "heading_image_folder" not in st["alignment_settings"]
    for gone in ("icon_folder", "bg_path", "icon_mappings"):
        assert gone not in st
    assert "template_json" not in st["dynamic_settings"] and "text_style_rules" not in st["dynamic_settings"]
    assert "icon_folder" in g["not_copied"] and "dynamic_settings.template_json" in g["not_copied"]


def test_settings_new_uses_defaults(tmp_path):
    game = tmp_path / "Game G"
    _excel(game / "Game Docs" / "NYL" / "G_NYL.xlsx")
    g = games.create(str(game), base_config={"h_font": "Impact", "h_size": 99},
                     settings_mode="new", defaults=engine_api.DEFAULT_CONFIG)
    assert g["style"]["h_font"] == engine_api.DEFAULT_CONFIG["h_font"]
    assert g["style"]["h_size"] == engine_api.DEFAULT_CONFIG["h_size"]
