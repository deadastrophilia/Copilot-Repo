"""Project memory stored inside the PSD (psd_memory.py)."""
import json
import os

import pytest
from openpyxl import Workbook, load_workbook

pytest.importorskip("photoshopapi")
psd_tools = pytest.importorskip("psd_tools")

from ps_autotypesetter import project_package, psd_memory
from ps_autotypesetter.ui_web import engine_api


@pytest.fixture(autouse=True)
def _cache(tmp_path, monkeypatch):
    monkeypatch.setattr(psd_memory, "CACHE_DIR", str(tmp_path / "memcache"))


def _workbook(path):
    wb = Workbook()
    ws = wb.active
    ws.title = "Rules"
    ws.append(["Game Rules"])
    ws.append(["All wins pay left to right."])
    ws.append(["Malfunction voids all pays."])
    wb.save(path)
    return str(path)


def _build(tmp_path, **extra):
    excel = _workbook(tmp_path / "LD_NYL.xlsx")
    template = tmp_path / "paytable_template.json"
    template.write_text(json.dumps({"slots": {"title": {"x": 1}}}), encoding="utf-8")
    cfg = dict(engine_api.DEFAULT_CONFIG)
    cfg.update({"excel_path": excel, "icon_folder": "", "bg_path": "", "bg_source": "color",
                "bg_color": "#102040", "output_dir": str(tmp_path / "out"), "output_name": "LD NYL",
                "render_all_pages": True, "c_width": 1280, "c_height": 720, "b_size": 33,
                "dynamic_settings": {"template_json": str(template)}})
    cfg.update(extra)
    out = engine_api.run_build(cfg, "psd")
    return out["psd_path"], cfg, excel, str(template)


def test_build_stores_the_project_inside_the_psd(tmp_path):
    psd, cfg, excel, template = _build(tmp_path)
    mem = psd_memory.read(psd)
    assert mem and mem["schema"] == psd_memory.SCHEMA
    assert mem["config"]["b_size"] == 33
    assert mem["excel"]["name"] == "LD_NYL.xlsx" and "workbook" in mem["excel"]
    assert set(mem["excel"]["sheets"]) == {"Rules"}
    assert os.path.basename(template) in [f["name"] for f in mem["files"].values()]
    assert mem["pages"] and mem["pages"][0]["sheet"] == "Rules"
    assert any(v.get("sheet") == "Rules" for v in mem["layers"].values())
    # _Links is opt-in now
    assert not os.path.isdir(project_package.links_dir_for_psd(psd))
    assert not os.path.isfile(project_package.manifest_path_for_psd(psd))


def test_restore_from_the_psd_alone(tmp_path):
    psd, cfg, excel, template = _build(tmp_path)
    os.remove(excel)                                   # the PSD is all we have left
    os.remove(template)
    res = psd_memory.restore(psd, {"recent_projects": [{"folder": "x"}]})
    assert res["ok"]
    out = res["config"]
    assert out["b_size"] == 33 and out["prev_psd_path"] == os.path.abspath(psd)
    assert os.path.isfile(out["excel_path"])           # rebuilt from the copy inside the PSD
    assert load_workbook(out["excel_path"])["Rules"]["A2"].value == "All wins pay left to right."
    restored_tpl = out["dynamic_settings"]["template_json"]
    assert os.path.isfile(restored_tpl) and json.load(open(restored_tpl))["slots"]["title"]["x"] == 1
    assert out["recent_projects"] == [{"folder": "x"}]
    assert res["notes"]                                # tells the user the copy was used


def test_baseline_comes_from_the_psd_without_links(tmp_path):
    psd, cfg, excel, _tpl = _build(tmp_path)
    info = project_package.load_baseline_info(psd)
    assert info["exists"] and info.get("embedded")
    assert info["file_hash"] == project_package.file_sha256(excel)
    assert load_workbook(info["baseline"])["Rules"]["A3"].value == "Malfunction voids all pays."


def test_rewrite_memory_keeps_layers_and_other_xmp(tmp_path):
    psd, cfg, excel, _tpl = _build(tmp_path)
    before = [l.name for l in psd_tools.PSDImage.open(psd).descendants()]
    mem = psd_memory.read(psd)
    mem["config"]["b_size"] = 55
    psd_memory.write_into_file(psd, mem)
    assert psd_memory.read(psd)["config"]["b_size"] == 55
    after = psd_tools.PSDImage.open(psd)
    assert [l.name for l in after.descendants()] == before
    # another app's XMP survives our rewrite
    from psd_tools.constants import Resource

    raw = after._record.image_resources[Resource.XMP_METADATA].data
    assert b"pshelp:memory" in raw


def test_large_workbook_stores_cell_values(tmp_path, monkeypatch):
    monkeypatch.setattr(psd_memory, "EMBED_WORKBOOK_MAX", 10)
    psd, cfg, excel, _tpl = _build(tmp_path)
    mem = psd_memory.read(psd)
    assert "workbook" not in mem["excel"] and mem["excel"]["values"]["Rules"][1][0] == "All wins pay left to right."
    rebuilt = psd_memory.materialize_excel(psd, mem)
    assert load_workbook(rebuilt)["Rules"]["A1"].value == "Game Rules"


def test_not_a_tool_psd(tmp_path):
    img = psd_tools.PSDImage.new("RGB", (8, 8))
    path = tmp_path / "other.psd"
    img.save(str(path))
    assert psd_memory.read(str(path)) is None
    assert not psd_memory.restore(str(path))["ok"]
