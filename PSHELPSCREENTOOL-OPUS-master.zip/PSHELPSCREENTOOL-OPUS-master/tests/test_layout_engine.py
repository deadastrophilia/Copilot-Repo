"""Unit tests for layout_engine.py — canonical layout computation.

Verifies:
  * the feature flag (USE_CANONICAL_LAYOUT / env override),
  * measurement adapter wrap parity with the historical PNG wrap math,
  * normal-page layout structure (heading, body, pagination, Continued),
  * PhotoshopMeasureAdapter fallback behaviour without Photoshop,
  * gate behaviour: unsupported features return None.
"""

import os

import pytest

from ps_autotypesetter import config
from ps_autotypesetter.layout_engine import (
    PhotoshopMeasureAdapter,
    PillowMeasureAdapter,
    build_normal_page_layouts,
    build_sheet_layouts,
    make_measure_layer,
)

pytestmark = pytest.mark.skipif(
    not config.canonical_layout_enabled() and os.environ.get("PSH_USE_CANONICAL_LAYOUT") == "0",
    reason="Canonical layout disabled via env",
)


# ---------------------------------------------------------------------------
# Feature flag
# ---------------------------------------------------------------------------


def test_flag_default_true():
    assert config.USE_CANONICAL_LAYOUT is True


def test_flag_env_override(monkeypatch):
    monkeypatch.setenv("PSH_USE_CANONICAL_LAYOUT", "0")
    assert config.canonical_layout_enabled() is False
    monkeypatch.setenv("PSH_USE_CANONICAL_LAYOUT", "1")
    assert config.canonical_layout_enabled() is True
    monkeypatch.setenv("PSH_USE_CANONICAL_LAYOUT", "false")
    assert config.canonical_layout_enabled() is False
    monkeypatch.delenv("PSH_USE_CANONICAL_LAYOUT")
    assert config.canonical_layout_enabled() is True


# ---------------------------------------------------------------------------
# Wrap parity: the engine must produce the SAME lines as png_builder
# ---------------------------------------------------------------------------


def _pillow_adapter():
    from PIL import Image, ImageDraw

    probe = Image.new("RGBA", (1920, 1080), (0, 0, 0, 0))
    return PillowMeasureAdapter(probe, ImageDraw.Draw(probe))


def test_wrap_matches_historical_wrap():
    from PIL import Image as PILImage

    from ps_autotypesetter import png_builder

    adapter = _pillow_adapter()
    Image, ImageDraw, ImageFont = png_builder._require_pillow()
    font = png_builder._load_font(ImageFont, "Arial", 30)
    draw = ImageDraw.Draw(Image.new("RGBA", (400, 100), (0, 0, 0, 0)))
    sample = "The quick brown fox jumps over the lazy dog and keeps running through the forest without stopping"
    max_w = 700
    historical = png_builder._wrap_inline(
        draw, Image, sample, font, max_w,
        "", {}, 24, None, 15, 15,
    )
    mine = adapter.wrap(sample, font, 30, "Arial", max_w, 24, 15, 15)
    assert mine == historical
    assert all(str(line).strip() for line in mine)


def test_wrap_with_newlines_matches():
    from ps_autotypesetter import png_builder

    adapter = _pillow_adapter()
    Image, ImageDraw, ImageFont = png_builder._require_pillow()
    font = png_builder._load_font(ImageFont, "Arial", 30)
    draw = ImageDraw.Draw(Image.new("RGBA", (400, 100), (0, 0, 0, 0)))
    sample = "first paragraph text.\nsecond paragraph text."
    historical = png_builder._wrap_inline(draw, Image, sample, font, 700, "", {}, 24, None, 15, 15)
    mine = adapter.wrap(sample, font, 30, "Arial", 700, 24, 15, 15)
    assert mine == historical


# ---------------------------------------------------------------------------
# Normal page layout structure
# ---------------------------------------------------------------------------


def _workbook(heading_bold=True):
    from openpyxl import Workbook
    from openpyxl.styles import Font

    wb = Workbook()
    ws = wb.active
    ws.title = "PAGE1"
    cell = ws.cell(row=1, column=1, value="GAME RULES")
    if heading_bold:
        cell.font = Font(bold=True)
    ws.append(["Line of body text number one"])
    ws.append(["More example body text for the page"])
    ws.append(["Final line"])
    return wb


def _layout_for(wb, **overrides):
    ws = wb["PAGE1"]
    params = dict(
        canvas_w=1920, canvas_h=1080, margin_x=100,
        h_font="Arial", h_size=72, h_icon_h=48, h_rgb=(255, 80, 80),
        b_font="Arial", b_size=30, b_icon_h=24, b_rgb=(255, 255, 255),
        line_spacing=4, para_spacing=12, continued_gap=15,
        heading_top_margin=120, heading_to_body_gap=40, bottom_margin=80,
        page_max_row=ws.max_row or 1, page_max_col=12,
    )
    params.update(overrides)
    return build_normal_page_layouts(ws, "PAGE1", **params)


def test_builds_heading_then_body():
    from ps_autotypesetter import png_builder

    wb = _workbook()
    layouts = _layout_for(wb)
    assert layouts is not None
    assert len(layouts) == 1
    page = layouts[0]
    assert page.source["sheet_name"] == "PAGE1"
    assert page.canvas["width"] == 1920
    assert page.safe_area["left"] == png_builder._inner_safe_box(1920, 1080, 100, 0)[0]
    kinds = [element.meta.get("kind") for element in page.elements]
    assert kinds[0] == "heading"
    assert all(kind == "body" for kind in kinds[1:])
    heading = page.elements[0]
    assert heading.y == 120
    assert heading.font == "Arial"
    assert heading.size == 72
    assert heading.bold is True
    assert heading.wrapped_lines == ["GAME RULES"]


def test_pagination_and_continued_label():
    wb = _workbook()
    ws = wb["PAGE1"]
    for index in range(30):
        ws.append([f"Very long wrapping body line number {index + 1} that keeps going to force multiple pages"])
    layouts = _layout_for(wb)
    assert layouts is not None
    assert len(layouts) >= 2
    second_page_meta = [element.meta.get("kind") for element in layouts[1].elements]
    assert second_page_meta[0] == "heading"
    assert second_page_meta[1] == "continued"
    continued = layouts[1].elements[1]
    assert continued.text == "(Continued)"
    assert any(element.meta.get("kind") == "body" for element in layouts[1].elements)


def test_every_element_has_final_geometry():
    wb = _workbook()
    layouts = _layout_for(wb)
    for layout in layouts:
        for element in layout.elements:
            assert element.x >= 0 and element.y >= 0
            assert element.width > 0 or element.type == "rect"
            assert len(element.wrapped_lines) >= 1
            assert len(element.line_heights) == len(element.wrapped_lines)


def test_heading_image_folder_returns_none(tmp_path):
    wb = _workbook()
    image_folder = tmp_path / "heading_images"
    image_folder.mkdir()
    # historical helper only returns a path for files named like the sheet
    from PIL import Image

    Image.new("RGB", (64, 32), (255, 0, 0)).save(str(image_folder / "PAGE1.png"))
    layouts = _layout_for(wb, heading_image_folder=str(image_folder))
    assert layouts is None


def test_heading_row_skipped():
    wb = _workbook()
    ws = wb["PAGE1"]
    row_texts = [element.text for element in _layout_for(wb)[0].elements]
    assert "GAME RULES" in row_texts  # heading element
    body_texts = []
    for element in _layout_for(wb)[0].elements:
        if element.meta.get("kind") == "body":
            body_texts.extend(element.wrapped_lines)
    assert "GAME RULES" not in body_texts


# ---------------------------------------------------------------------------
# Titles/roles carried in the layout
# ---------------------------------------------------------------------------


def test_styles_roles_centered():
    wb = _workbook()
    page = _layout_for(wb)[0]
    heading = page.elements[0]
    assert heading.style_role == "Heading"
    assert heading.align == "center"
    body = [element for element in page.elements if element.meta.get("kind") == "body"][0]
    assert body.style_role == "Body"
    assert body.align == "center"


# ---------------------------------------------------------------------------
# PhotoshopMeasureAdapter fallback (no Photoshop on CI)
# ---------------------------------------------------------------------------


def test_photoshop_measure_adapter_falls_back():
    from PIL import Image, ImageDraw

    from ps_autotypesetter import png_builder

    ImageFont = png_builder._require_pillow()[2]
    probe = Image.new("RGBA", (1000, 500), (0, 0, 0, 0))
    draw = ImageDraw.Draw(probe)
    adapter = PhotoshopMeasureAdapter(
        measure_layer=None, image=probe, draw=draw,
        icon_folder="", icon_mappings={},
    )
    font = png_builder._load_font(ImageFont, "Arial", 30)
    w, h = adapter.measure("hello", font, 30, "Arial", 24, 0, 0)
    assert w > 0
    assert h > 0


def test_make_measure_layer_without_photoshop():
    assert make_measure_layer(None) is None


def test_build_sheet_layouts_flag_off(monkeypatch):
    monkeypatch.setenv("PSH_USE_CANONICAL_LAYOUT", "0")
    wb = _workbook()
    assert build_sheet_layouts(wb["PAGE1"], "PAGE1", **{}) is None