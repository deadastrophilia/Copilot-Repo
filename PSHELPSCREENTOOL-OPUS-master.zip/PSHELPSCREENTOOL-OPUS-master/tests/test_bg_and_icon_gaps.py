"""Background fill modes and icon spacing in the shared layout engine."""

from PIL import Image

from ps_autotypesetter import png_builder


def test_cover_fills_the_canvas_without_stretching(tmp_path):
    # tall 1000x1800 art on a 1920x1080 canvas: no stretch, no empty bars
    art = Image.new("RGBA", (1000, 1800), (0, 0, 255, 255))
    art.paste((255, 0, 0, 255), (0, 0, 1000, 900))           # top half red, bottom half blue
    p = tmp_path / "bg.png"
    art.save(p)
    canvas = Image.new("RGBA", (1920, 1080), (0, 0, 0, 0))
    png_builder._paint_background(canvas, Image, str(p), "cover")
    assert canvas.getpixel((5, 540))[3] == 255 and canvas.getpixel((1914, 540))[3] == 255   # edges filled
    top, bottom = canvas.getpixel((960, 520))[:3], canvas.getpixel((960, 560))[:3]
    assert top[0] > 240 and top[2] < 15 and bottom[2] > 240 and bottom[0] < 15   # proportions kept, centred


def test_layout_engine_uses_the_icon_spacing_settings():
    from openpyxl import Workbook

    from ps_autotypesetter.layout_engine import build_normal_page_layouts

    wb = Workbook()
    ws = wb.active
    ws["A1"] = "HEADING"
    ws["A3"] = "Some body text here"

    def gaps(g):
        pages = build_normal_page_layouts(
            ws, "S", canvas_w=1920, canvas_h=1080, margin_x=80, h_font="arial.ttf", h_size=60, h_icon_h=60,
            h_rgb=(255, 255, 255), b_font="arial.ttf", b_size=30, b_icon_h=40, b_rgb=(255, 255, 255),
            line_spacing=4, para_spacing=10, continued_gap=15, heading_top_margin=100, heading_to_body_gap=30,
            bottom_margin=60, icon_gap_left=g, icon_gap_right=g + 1, heading_icon_gap_left=g, heading_icon_gap_right=g)
        assert pages
        return {(e.icon_gap_left, e.icon_gap_right) for e in pages[0].elements if e.type == "text"}

    assert gaps(0) == {(0.0, 0.0), (0.0, 1.0)} or (0.0, 1.0) in gaps(0)
    assert (40.0, 41.0) in gaps(40)


def test_live_layout_uses_top_level_icon_gaps(tmp_path, monkeypatch):
    """The Typography icon-gap fields are top-level config; the live preview layout
    must use them like the build does (engine_api._merged_dynamic_settings)."""
    from openpyxl import Workbook

    from ps_autotypesetter import layout_engine, live_layout_adapter

    xl = tmp_path / "g.xlsx"
    wb = Workbook()
    wb.active.title = "Rules"
    wb.active["A1"] = "Rules"
    wb.save(xl)
    seen = {}
    monkeypatch.setattr(live_layout_adapter, "canonical_layout_enabled", lambda: True)
    monkeypatch.setattr(layout_engine, "build_sheet_layouts",
                        lambda ws, name, **kw: seen.update(kw["dynamic_settings"]) or [])
    live_layout_adapter.build_sheet_layouts_from_cfg(
        {"excel_path": str(xl), "icon_gap_left": 40, "icon_gap_right": 7,
         "heading_icon_gap_left": 50, "dynamic_settings": {"icon_gap_left": 15}}, "Rules")
    assert (seen["icon_gap_left"], seen["icon_gap_right"], seen["heading_icon_gap_left"]) == (40, 7, 50)
