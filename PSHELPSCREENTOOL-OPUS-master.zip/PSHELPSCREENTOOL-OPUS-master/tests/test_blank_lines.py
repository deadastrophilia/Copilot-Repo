"""Empty lines typed on the Canvas (Enter pressed twice, like in Notepad) are space on the page: a blank
line of the text's height, before the next line or after a row's last one; the editor's caret sits on it."""
import pytest
from openpyxl import Workbook
from openpyxl.styles import Font

from ps_autotypesetter import page_boxes, row_roles, text_edits
from ps_autotypesetter.layout_engine import build_normal_page_layouts


@pytest.fixture(autouse=True)
def _clean():
    page_boxes.set_all({})
    row_roles.set_all({})
    text_edits.set_all({})
    yield
    page_boxes.set_all({})
    row_roles.set_all({})
    text_edits.set_all({})


def _rows(edits=None):
    wb = Workbook()
    ws = wb.active
    ws.title = "P"
    ws.cell(row=1, column=1, value="FEATURES").font = Font(bold=True)
    ws.cell(row=2, column=1, value="First row")
    ws.cell(row=3, column=1, value="Second row")
    text_edits.set_all({"P": edits or {}})
    page = build_normal_page_layouts(
        ws, "P", canvas_w=1920, canvas_h=1080, margin_x=100,
        h_font="Arial", h_size=72, h_icon_h=48, h_rgb=(255, 80, 80),
        b_font="Arial", b_size=30, b_icon_h=24, b_rgb=(255, 255, 255),
        line_spacing=4, para_spacing=12, continued_gap=15, line_gap=30,
        heading_top_margin=120, heading_to_body_gap=40, bottom_margin=80,
        page_max_row=ws.max_row, page_max_col=12)[0]
    return {e.meta.get("row"): e for e in page.elements if e.meta.get("kind") == "body"}


def test_an_empty_line_after_a_row_pushes_the_next_row_down():
    plain = _rows()
    spaced = _rows({"row:2": {"from": "First row", "to": "First row\n"}})
    step = spaced[3].y - plain[3].y
    assert step > 20                                               # one blank line (its height + the row gap)
    assert spaced[2].meta["blank_below"][0]["top"] > spaced[2].meta["ink_bottom"]
    two = _rows({"row:2": {"from": "First row", "to": "First row\n\n"}})
    assert two[3].y - plain[3].y == pytest.approx(2 * step)


def test_an_empty_line_before_a_row_is_on_that_row():
    plain = _rows()
    spaced = _rows({"row:3": {"from": "Second row", "to": "\nSecond row"}})
    assert spaced[3].y > plain[3].y
    assert len(spaced[3].meta["blank_above"]) == 1


def test_an_empty_line_inside_a_row():
    rows = _rows({"row:2": {"from": "First row", "to": "First\n\nrow"}})
    assert rows[2].meta["line"] == 2 and len(rows[2].meta["blank_above"]) == 1   # "row", under the empty line
    plain = _rows({"row:2": {"from": "First row", "to": "First\nrow"}})
    assert rows[3].y > plain[3].y


def test_a_line_with_a_role_of_its_own_keeps_the_empty_lines_around_it():
    row_roles.set_all({"row_roles": {"S": {"row:1|Big": "heading"}}})
    assert row_roles.segments("S", 1, "Intro\n\nBig\n\nText after\n") == [
        ("Intro\n", ""), ("Big", "heading"), ("\nText after\n", "")]
    assert row_roles.segments("S", 1, "Intro\nBig\nText") == [("Intro", ""), ("Big", "heading"), ("Text", "")]
