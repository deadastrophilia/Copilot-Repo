"""Auto-map text routing: ALL remaining plain text always lands on the
literal ``text`` slot (@slot.text / text) no matter what; every other
text-ish slot (text.1, notes, label, description, ...) is left unmapped so
the user can still map duplicate data onto it manually."""

import os

from openpyxl import Workbook, load_workbook

from ps_autotypesetter.ui_web import engine_api


def _workbook_with_text(tmp_path):
    wb = Workbook()
    ws = wb.active
    ws.title = "Paytable"
    for label in ("<PIC1>", "<PIC2>", "<PIC3>", "ACE", "KING"):
        row = len([c for c in ws.iter_rows() if c[0].value is not None]) + 2
        ws.cell(row=row, column=1, value=label)
        for i, v in enumerate((5, 4, 3, 2)):
            ws.cell(row=row + 1 + i, column=6, value=v)
        for i, v in enumerate((150, 50, 10, 5)):
            ws.cell(row=row + 1 + i, column=8, value=v)
    ws.cell(row=2, column=2, value="All wins begin with leftmost reel and")
    ws.cell(row=3, column=2, value="pay left to right on adjacent reels")
    ws.cell(row=4, column=2, value="Poker symbols pay any position")
    path = os.path.join(str(tmp_path), "text.xlsx")
    wb.save(path)
    return path


def _template(slots):
    return {"canvas": {"width": 1920, "height": 1080}, "slots": slots,
            "mappings": {}, "mapper_meta": {"generated_by": "web_paytable_mapper",
                                            "sheet_name": "Paytable"}}


def _box(x=0, y=0):
    return {"x": x, "y": y, "w": 100, "h": 50}


def _slot_mapping(result, slot):
    for m in result["mappings"]:
        if m.get("slot") == slot:
            return m
    return None


def test_automap_sends_all_text_to_literal_text_slot(tmp_path):
    """@slot.text owns the WHOLE text pool; @slot.text.1 / @slot.notes stay
    unmapped (manual-only), regardless of their order in the template."""
    slots = {
        "title": _box(),
        "@slot.text.1": _box(0, 60),
        "@slot.text": _box(0, 120),
        "@slot.notes": _box(0, 180),
        "@slot.label": _box(0, 240),
        "pic1": _box(0, 300),
        "ace": _box(0, 360),
    }
    path = _workbook_with_text(tmp_path)
    wb = load_workbook(path, data_only=True, read_only=True)
    try:
        ws = wb["Paytable"]
        result = engine_api.automap_paytable_slots_ws(ws, _template(slots))
        text = _slot_mapping(result, "@slot.text")
        assert text and text["mode"] == "excel"
        joined = text["text"]
        # B2 is reserved as the page's title cell; the rest of the pool
        # (B3, B4) must land entirely on @slot.text
        for phrase in ("pay left to right on adjacent reels",
                       "Poker symbols pay any position"):
            assert phrase in joined
        assert "All wins begin with leftmost reel and" not in joined
        assert _slot_mapping(result, "@slot.text.1") is None
        assert _slot_mapping(result, "@slot.notes") is None
        assert _slot_mapping(result, "@slot.label") is None
        assert "@slot.text.1" in result["unmapped"]
        assert "@slot.notes" in result["unmapped"]
        assert "@slot.label" in result["unmapped"]
    finally:
        if wb is not None:
            wb.close()


def test_automap_text_slot_first_even_if_iterated_last(tmp_path):
    """The bare ``text`` slot beats ``text.1`` even when it appears AFTER
    ``text.1`` in the template's slot order."""
    slots = {
        "title": _box(),
        "@slot.text.1": _box(0, 60),
        "text": _box(0, 120),
        "pic1": _box(0, 300),
    }
    path = _workbook_with_text(tmp_path)
    wb = None
    try:
        wb = load_workbook(path, data_only=True, read_only=True)
        ws = wb["Paytable"]
        result = engine_api.automap_paytable_slots_ws(ws, _template(slots))
        mapped = _slot_mapping(result, "text")
        assert mapped and "pay left to right on adjacent reels" in mapped["text"]
        assert mapped and "Poker symbols pay any position" in mapped["text"]
        assert _slot_mapping(result, "@slot.text.1") is None
        assert "@slot.text.1" in result["unmapped"]
    finally:
        if wb is not None:
            wb.close()


def test_automap_fallback_when_no_literal_text_slot(tmp_path):
    """Only when the template has NO literal ``text`` slot does the first
    text-ish slot fall back to the whole pool (text is never dropped)."""
    slots = {
        "title": _box(),
        "@slot.notes": _box(0, 60),
        "@slot.label": _box(0, 120),
        "pic1": _box(0, 300),
    }
    path = _workbook_with_text(tmp_path)
    wb = None
    try:
        wb = load_workbook(path, data_only=True, read_only=True)
        ws = wb["Paytable"]
        result = engine_api.automap_paytable_slots_ws(ws, _template(slots))
        notes = _slot_mapping(result, "@slot.notes")
        assert notes and "pay left to right on adjacent reels" in notes["text"]
        assert notes and "Poker symbols pay any position" in notes["text"]
        assert _slot_mapping(result, "@slot.label") is None
        assert "@slot.label" in result["unmapped"]
    finally:
        if wb is not None:
            wb.close()