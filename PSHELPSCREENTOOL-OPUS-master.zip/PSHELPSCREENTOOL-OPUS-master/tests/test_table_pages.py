"""Pages with tables go through the layout engine (layout_engine places them between the rows of text):
they get the paragraph's box, its alignment and every row feature, like any text page."""
import pytest
from openpyxl import Workbook
from openpyxl.styles import Font

from ps_autotypesetter import page_boxes, png_builder as pb, row_roles, table_designs as td
from ps_autotypesetter.layout_engine import build_normal_page_layouts


@pytest.fixture(autouse=True)
def _clean():
    page_boxes.set_all({})
    row_roles.set_all({})
    yield
    page_boxes.set_all({})
    row_roles.set_all({})


def _sheet():
    """Row 1 heading, row 2 text, rows 4-7 a table (cols B-C), row 9 text."""
    wb = Workbook()
    ws = wb.active
    ws.title = "P"
    ws.cell(row=1, column=1, value="GAME RULES").font = Font(bold=True)
    ws.cell(row=2, column=1, value="Text above the table")
    rows = (("Symbol", "Pays"), ("Wild", "500"), ("Cherry", "20"), ("Bell", "10"))
    for r, row in enumerate(rows, start=4):
        for c, v in enumerate(row, start=2):
            ws.cell(r, c, v)
    ws.cell(row=9, column=1, value="Text under the table")
    cells = [{"row": r, "col": c, "value": v, "role": "header" if r == 4 else "body", "rowspan": 1, "colspan": 1}
             for r, row in enumerate(rows, start=4) for c, v in enumerate(row, start=2)]
    table = {"start_row": 4, "end_row": 7, "min_col": 2, "max_col": 3, "grid_cells": cells,
             "design_key": td.table_key("P", "Symbol | Pays"), "design": "current"}
    return ws, table


def _layouts(ws, table, align="center", ts=None, overrides=None):
    return build_normal_page_layouts(
        ws, "P", canvas_w=1920, canvas_h=1080, margin_x=100,
        h_font="Arial", h_size=72, h_icon_h=48, h_rgb=(255, 80, 80),
        b_font="Arial", b_size=30, b_icon_h=24, b_rgb=(255, 255, 255),
        line_spacing=4, para_spacing=12, continued_gap=15, line_gap=30,
        heading_top_margin=120, heading_to_body_gap=40, bottom_margin=80,
        page_max_row=ws.max_row, page_max_col=12,
        alignment_settings={"global": {"body": align}},
        tables=[table], table_style=dict(pb.TABLE_DEFAULTS, **(ts or {})), table_overrides=overrides)


def _table_box(el):
    g = el.meta["geo"]
    left = el.x + g["x"]
    return left, left + sum(g["cols"])


def test_a_table_sits_between_its_rows_of_text():
    ws, table = _sheet()
    page = _layouts(ws, table)[0]
    kinds = [(e.meta.get("kind"), e.meta.get("row")) for e in page.elements if e.meta.get("kind") in ("body", "table")]
    assert kinds == [("body", 2), ("table", None), ("body", 9)]       # in the page's flow
    tbl = next(e for e in page.elements if e.meta.get("kind") == "table")
    above = next(e for e in page.elements if e.meta.get("row") == 2)
    under = next(e for e in page.elements if e.meta.get("row") == 9)
    assert above.meta["ink_bottom"] < tbl.y < tbl.y + tbl.height < under.meta["ink_top"]
    assert tbl.meta["jsid"] == "table.4" and tbl.image is not None and tbl.meta["geo"]["cols"]
    # the table's own rows are not text
    assert not any(e.meta.get("row") in (4, 5, 6, 7) for e in page.elements if e.meta.get("kind") == "body")


def test_tables_follow_the_paragraphs_alignment_and_box():
    ws, table = _sheet()
    body = lambda lay: lay.safe_area["body"]  # noqa: E731
    for align in ("left", "right", "center"):
        page = _layouts(ws, table, align)[0]
        tbl = next(e for e in page.elements if e.meta.get("kind") == "table")
        left, right = _table_box(tbl)
        b = body(page)
        if align == "left":
            assert left == pytest.approx(b["left"], abs=2)
        elif align == "right":
            assert right == pytest.approx(b["left"] + b["width"], abs=2)
        else:
            assert (left + right) / 2 == pytest.approx(b["left"] + b["width"] / 2, abs=2)
    page_boxes.set_all({"body_boxes": {"P": {"left": 600, "right": 1400}}})
    tbl = next(e for e in _layouts(ws, table, "left")[0].elements if e.meta.get("kind") == "table")
    assert _table_box(tbl)[0] == pytest.approx(600, abs=2)            # inside the paragraph's own box


def test_cut_parts_go_side_by_side_aligned_and_a_moved_table_keeps_its_move():
    ws, table = _sheet()
    cut = {"split_tables": {table["design_key"]: [2]}}                 # body rows 0-1 | 2
    page = _layouts(ws, table, "right", ts=cut)[0]
    parts = [e for e in page.elements if e.meta.get("kind") == "table"]
    assert [p.meta["jsid"] for p in parts] == ["table.4", "table.4.1"]
    assert parts[0].y == parts[1].y and _table_box(parts[1])[0] > _table_box(parts[0])[1]   # side by side
    b = page.safe_area["body"]
    assert _table_box(parts[1])[1] == pytest.approx(b["left"] + b["width"], abs=2)        # at the right
    assert parts[1].meta["geo"]["rowMap"] == [0, 3]                                       # header + its row
    moved = _layouts(ws, table, overrides={"table.4": {"x": 25, "y": -10}})[0]
    tbl = next(e for e in moved.elements if e.meta.get("kind") == "table")
    assert (tbl.meta["dx"], tbl.meta["dy"]) == (25.0, -10.0)


def test_the_build_draws_the_layouts_tables():
    from PIL import Image

    from ps_autotypesetter.canonical_png import render_layout_pages

    ws, table = _sheet()
    lays = _layouts(ws, table)
    seen = []
    pages = render_layout_pages(lays, bg_color="#000000", table_drawer=lambda page, draw, el: seen.append(el.meta["jsid"]))
    assert seen == ["table.4"] and isinstance(pages[0], Image.Image)
