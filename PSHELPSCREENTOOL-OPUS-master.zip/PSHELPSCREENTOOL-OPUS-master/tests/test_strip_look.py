"""Strip looks (text_styles.strip_look): corners, a border and a layer style on every kind of strip —
a row's strip rule, a selection's strip (bg_ keys) — drawn as live Photoshop rounded rectangles."""
from openpyxl import Workbook
from openpyxl.styles import Font

from ps_autotypesetter import text_styles as ts
from ps_autotypesetter.psd_writer import shapes


def test_look_reads_corners_border_and_style_with_or_without_the_bg_prefix():
    rule = {"radius": 8, "radii": [0, 12, 0, 12], "border": {"width": 3, "color": "#ffcc00", "align": "outside"},
            "fx": "Glow", "_fx": {"x": 1}}
    look = ts.strip_look(rule)
    assert look["radius"] == 8 and look["radii"] == [0, 12, 0, 12]
    assert look["border"] == {"width": 3, "color": "#ffcc00", "opacity": 100, "align": "outside"}
    assert look["fx"] == "Glow" and look["_fx"] == {"x": 1}
    assert ts.strip_look({"border": {"width": 0}}) == {"radius": 6}                # no width: no border
    word = {"bg": "#112233", "bg_radius": 2, "bg_border": {"width": 1, "align": "nope"}, "bg_fx": "Glow", "_bg_fx": {"y": 2}}
    bg = ts.bg_of(word)
    assert bg["radius"] == 2 and bg["border"]["align"] == "inside" and bg["_fx"] == {"y": 2}
    assert ts.bg_of({"bg": "#112233"})["radius"] == 4                               # a word strip's own default


def test_each_corner_its_own_radius_in_the_pixels():
    img, _l, _t = shapes.render({"left": 0, "top": 0, "width": 200, "height": 100, "radii": [0, 40, 0, 40],
                                 "fill": "#ff0000"})
    assert img.getpixel((1, 1))[3] == 255 and img.getpixel((198, 1))[3] == 0      # square top-left, round top-right
    assert img.getpixel((198, 98))[3] == 255 and img.getpixel((1, 98))[3] == 0     # square bottom-right, round bottom-left


def test_strips_reach_the_psd_as_live_shapes_with_border_corners_and_style(tmp_path):
    from psd_tools import PSDImage

    from ps_autotypesetter.psd_writer import build as psd_build
    from ps_autotypesetter.psd_writer import effects
    from ps_autotypesetter.ui_web import engine_api

    wb = Workbook()
    ws = wb.active
    ws.title = "Rules"
    ws.cell(row=1, column=1, value="GAME RULES").font = Font(bold=True)
    ws.append(["Note: all wins pay left to right"])
    ws.append(["Malfunction voids all pays and plays"])
    excel = str(tmp_path / "Game.xlsx")
    wb.save(excel)
    hex4 = "".join("%04x" % b for b in effects.params_payload({"stroke_enabled": True, "stroke_size": 4})[4:])
    ds = {"layer_style_library": {"Outline": {"captured_effects_hex": hex4}},
          "text_style_rules": [
              {"kind": "strip", "text": "Note:", "match": "starts", "color": "#1e3a8a", "opacity": 0.5,
               "radii": [0, 20, 0, 20], "border": {"width": 3, "color": "#ffcc00"}, "fx": "Outline"},
              {"kind": "word", "text": "Malfunction", "bg": "#880000", "bg_border": {"width": 2, "color": "#ffffff"}},
              {"kind": "word", "text": "wins", "bg": "#00aa00"}]}
    cfg = {"excel_path": excel, "icon_folder": "", "bg_path": "", "bg_source": "color", "bg_color": "#102040",
           "output_dir": str(tmp_path / "out"), "output_name": "Game", "render_all_pages": True,
           "c_width": 1280, "c_height": 720, "dynamic_settings": ds}
    psd = psd_build.build_psd(**engine_api._build_kwargs(cfg), output_format="PSD")
    layers = [l for l in PSDImage.open(psd).descendants()]           # bottom of the stack first
    name = lambda l: l.name.rstrip("\x00")  # noqa: E731
    order = [name(l) for l in layers]
    at = lambda end: next(i for i, n in enumerate(order) if n.startswith("strip") and n.endswith(end))  # noqa: E731
    strips = {name(l): l for l in layers if name(l).startswith("strip") and not name(l).endswith(" wins")}
    assert len(strips) == 2 and all(l.kind == "shape" for l in strips.values())
    assert any(n.endswith("Note: all wins pay left to right") for n in strips)       # named after its text
    # a word's strip inside a row with a strip of its own: above it in Photoshop, as on the canvas
    assert at(" wins") > at("Note: all wins pay left to right")
    assert all(l.stroke and l.stroke.enabled for l in strips.values())
    row = next(l for l in strips.values() if any("OBJECT_BASED_EFFECTS" in str(k) for k in l.tagged_blocks.keys()))
    radii = {k: v for k, v in row.origination[0].radii.items() if k != b"unitValueQuadVersion"}
    assert sorted(set(round(float(v)) for v in radii.values())) == [0, 20]       # two square, two round corners
