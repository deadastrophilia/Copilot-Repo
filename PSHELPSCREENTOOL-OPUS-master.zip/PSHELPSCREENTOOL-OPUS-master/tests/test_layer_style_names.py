"""Renaming / deleting a layer style (layer_style_names.py, /api/layer-styles/rename|delete)."""
import pytest

from ps_autotypesetter import layer_style_names as names


def _cfg():
    return {
        "h_size": 120,
        "dynamic_settings": {
            "layer_style_library": {"A gold": {"fx_base_size": 120}, "Glow": {}, "Z last": {}},
            "style_assignments": {"Heading text": "Glow", "Body text": "A gold"},
            "text_style_rules": [{"words": "WILD", "fx": "Glow"}, {"words": "x", "fx": "A gold"}],
            "table_style": {"table_layouts": {"t1": {"lines_fx": "Glow", "cells": {"0,0": {"fx": "Glow"}}}}},
            "text_boxes": {"Rules": [{"id": "b1", "style": "Glow"}]},
            "bevel_like": {"style": "Glow", "fx": "Other"},          # "style" outside text boxes is not a name
        },
        "paytable_maps": {"slot.a": {"text_fx": "Glow", "shape": {"fx": "Glow"}}},
    }


def test_rename_moves_every_reference_and_keeps_the_order():
    cfg = _cfg()
    out, n = names.rename(cfg, "Glow", "Neon glow")
    ds = out["dynamic_settings"]
    assert list(ds["layer_style_library"]) == ["A gold", "Neon glow", "Z last"]
    assert ds["style_assignments"] == {"Heading text": "Neon glow", "Body text": "A gold"}
    assert ds["text_style_rules"][0]["fx"] == "Neon glow" and ds["text_style_rules"][1]["fx"] == "A gold"
    lay = ds["table_style"]["table_layouts"]["t1"]
    assert lay["lines_fx"] == "Neon glow" and lay["cells"]["0,0"]["fx"] == "Neon glow"
    assert ds["text_boxes"]["Rules"][0]["style"] == "Neon glow"
    assert ds["bevel_like"] == {"style": "Glow", "fx": "Other"}
    assert out["paytable_maps"]["slot.a"] == {"text_fx": "Neon glow", "shape": {"fx": "Neon glow"}}
    assert n == 7
    assert cfg["dynamic_settings"]["style_assignments"]["Heading text"] == "Glow"      # the copy only


@pytest.mark.parametrize("old,new,msg", [("Glow", "", "name"), ("Nope", "X", "no layer style"),
                                         ("Glow", "A gold", "already exists")])
def test_rename_refuses(old, new, msg):
    with pytest.raises(ValueError, match=msg):
        names.rename(_cfg(), old, new)


def test_rename_and_delete_routes(tmp_path):
    from ps_autotypesetter.ui_web.server import create_app

    c = create_app(session_file=str(tmp_path / "session.json")).test_client()
    cfg = c.get("/api/config").get_json()
    cfg = cfg.get("config", cfg)
    cfg["dynamic_settings"] = dict(cfg.get("dynamic_settings") or {}, **_cfg()["dynamic_settings"])
    cfg.pop("active_game", None)
    c.post("/api/config", json=cfg)
    d = c.post("/api/layer-styles/rename", json={"name": "Glow", "new_name": "Neon"}).get_json()
    assert d["ok"] and d["config"]["dynamic_settings"]["style_assignments"]["Heading text"] == "Neon"
    assert not c.post("/api/layer-styles/rename", json={"name": "Neon", "new_name": "A gold"}).get_json()["ok"]
    d = c.post("/api/layer-styles/delete", json={"name": "Neon"}).get_json()
    ds = d["config"]["dynamic_settings"]
    assert "Neon" not in ds["layer_style_library"] and "Heading text" not in ds["style_assignments"]
