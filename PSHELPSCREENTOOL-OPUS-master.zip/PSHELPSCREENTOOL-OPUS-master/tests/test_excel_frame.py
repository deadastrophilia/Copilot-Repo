"""Only the AGR text inside a sheet's drawn frame reaches the tool."""

import os

from openpyxl import Workbook
from openpyxl.styles import Border, Side

import ps_autotypesetter  # noqa: F401  (installs the filtered loader)
from openpyxl import load_workbook


def _framed(path, frame=True):
    wb = Workbook()
    ws = wb.active
    ws.title = "Feature"
    thin = Side(style="thin")
    if frame:                                    # a box B2:H20, like the game docs draw
        for c in range(2, 9):
            ws.cell(2, c).border = Border(top=thin, left=thin if c == 2 else None, right=thin if c == 8 else None)
            ws.cell(20, c).border = Border(bottom=thin, left=thin if c == 2 else None, right=thin if c == 8 else None)
        for r in range(3, 20):
            ws.cell(r, 2).border = Border(left=thin)
            ws.cell(r, 8).border = Border(right=thin)
    ws["C3"] = "FEATURE TITLE"
    ws["C5"] = "Three scatters award free games."
    ws["J5"] = "< modified 7/2/25"                  # an editor's note beside the box
    ws["J21"] = "< removed 7/2/25"
    ws["J8"] = "Denom"                              # tool data beside the box: kept
    ws["K8"] = "1,2"
    ws["J9"] = "Paylines"
    ws["K9"] = 50
    wb.save(path)


def _texts(ws):
    return {c.coordinate: c.value for row in ws.iter_rows() for c in row if c.value not in (None, "")}


def test_notes_outside_the_frame_are_dropped(tmp_path):
    path = os.path.join(str(tmp_path), "agr.xlsx")
    _framed(path)
    for read_only in (False, True):
        t = _texts(load_workbook(path, data_only=True, read_only=read_only)["Feature"])
        assert t["C3"] == "FEATURE TITLE" and t["C5"].startswith("Three scatters")
        assert "J5" not in t and "J21" not in t, read_only               # the notes are gone
        assert t["J8"] == "Denom" and t["K9"] == 50, read_only            # the Denom / Paylines table stays


def test_a_one_column_frame_counts_when_the_column_is_wide(tmp_path):
    # the page box is a single very wide column B (ThunderEmpire "GRAND JACKPOT LINK")
    path = os.path.join(str(tmp_path), "narrow.xlsx")
    wb = Workbook()
    ws = wb.active
    ws.title = "Jackpot"
    thin = Side(style="thin")
    ws.column_dimensions["B"].width = 150
    ws["B2"].border = Border(top=thin, left=thin, right=thin)
    for r in range(3, 13):
        ws.cell(r, 2).border = Border(left=thin, right=thin)
    ws["B13"].border = Border(bottom=thin, left=thin, right=thin)
    ws["B3"] = "LINKED PROGRESSIVE GRAND JACKPOT"
    ws["B6"] = "<GRAND JACKPOT> is awarded when 15 <COR> are collected."
    ws["C9"] = "<removed"
    ws["C11"] = "<removed"
    wb.save(path)
    t = _texts(load_workbook(path, data_only=True)["Jackpot"])
    assert t["B3"].startswith("LINKED") and t["B6"].startswith("<GRAND")
    assert "C9" not in t and "C11" not in t


def test_a_few_narrow_bordered_cells_are_not_a_frame(tmp_path):
    path = os.path.join(str(tmp_path), "cells.xlsx")
    wb = Workbook()
    ws = wb.active
    thin = Side(style="thin")
    ws["B2"].border = Border(top=thin, left=thin, right=thin)       # a small boxed table cell
    for r in range(3, 8):
        ws.cell(r, 2).border = Border(left=thin, right=thin)
    ws["B3"] = "5"
    ws["E5"] = "Real text beside it"
    wb.save(path)
    t = _texts(load_workbook(path, data_only=True)[ws.title])
    assert t["E5"] == "Real text beside it"


def test_a_sheet_without_a_frame_is_untouched(tmp_path):
    path = os.path.join(str(tmp_path), "plain.xlsx")
    _framed(path, frame=False)
    t = _texts(load_workbook(path, data_only=True)["Feature"])
    assert t["J5"] == "< modified 7/2/25" and t["C5"].startswith("Three")
