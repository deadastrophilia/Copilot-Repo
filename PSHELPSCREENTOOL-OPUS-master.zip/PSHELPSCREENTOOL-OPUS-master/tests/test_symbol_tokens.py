import os

from PIL import Image

from ps_autotypesetter import symbol_tokens as st


def _png(folder, name):
    Image.new("RGBA", (4, 4), (255, 0, 0, 255)).save(os.path.join(folder, name))


def _cfg(tmp_path, monkeypatch, tokens, files, mappings=None):
    folder = tmp_path / "Symbols"
    folder.mkdir()
    for f in files:
        _png(str(folder), f)
    monkeypatch.setattr(st, "scan_excel_icon_tokens", lambda path: list(tokens))
    excel = tmp_path / "game.xlsx"
    excel.write_bytes(b"x")
    return {"excel_path": str(excel), "icon_folder": str(folder), "icon_mappings": mappings or {}}


def test_placeholders_are_not_symbols():
    assert st.is_symbol_token("WILD")
    assert not st.is_symbol_token("GAME NAME")
    assert not st.is_symbol_token("dynamic Text")


def test_state_name_mapping_and_suggestion(tmp_path, monkeypatch):
    cfg = _cfg(tmp_path, monkeypatch, ["WILD", "PIC1", "SCAT", "GAME NAME"],
               ["WILD.png", "Layer 720.png", "SCAT_symbol.png"], {"PIC1": "Layer 720.png"})
    s = st.state(cfg)
    rows = {r["token"]: (r["file"], r["via"]) for r in s["tokens"]}
    assert rows == {"WILD": ("WILD.png", "name"), "PIC1": ("Layer 720.png", "mapping"),
                    "SCAT": ("SCAT_symbol.png", "suggested")}
    assert s["unmapped"] == ["SCAT"]                # suggested isn't saved yet
    assert s["unused_files"] == []


def test_check_states(tmp_path, monkeypatch):
    cfg = _cfg(tmp_path, monkeypatch, ["WILD", "PIC1"], ["WILD.png"])
    assert st.check(dict(cfg, icon_folder="")) ["state"] == "no_folder"
    assert st.check(dict(cfg, icon_folder=str(tmp_path / "missing")))["state"] == "no_folder"
    empty = tmp_path / "Empty"
    empty.mkdir()
    assert st.check(dict(cfg, icon_folder=str(empty)))["state"] == "empty_folder"
    c = st.check(cfg)
    assert c["state"] == "unmapped" and c["unresolved"] == ["PIC1"]
    cfg = st.apply(cfg, {"PIC1": "WILD.png"})        # one picture for two symbols
    assert st.check(cfg)["state"] == "ok"


def test_apply_replaces_and_tracks_new_tokens(tmp_path, monkeypatch):
    cfg = _cfg(tmp_path, monkeypatch, ["WILD", "PIC1"], ["a.png", "b.png"], {"wild": "a.png", "OTHER": "b.png"})
    cfg = st.apply(cfg, {"WILD": "b.png", "PIC1": ""}, tokens=["WILD", "PIC1"])
    assert cfg["icon_mappings"] == {"OTHER": "b.png", "WILD": "b.png"}
    assert st.state(cfg)["new_tokens"] == []
    monkeypatch.setattr(st, "scan_excel_icon_tokens", lambda path: ["WILD", "PIC1", "PIC9"])
    assert st.state(cfg)["new_tokens"] == ["PIC9"]   # Excel changed; old links kept
    assert cfg["icon_mappings"]["WILD"] == "b.png"


def test_preflight_honours_saved_links(tmp_path, monkeypatch):
    """Linked symbols and text placeholders must not be reported as missing before a build."""
    from ps_autotypesetter.ui_web import engine_api

    cfg = _cfg(tmp_path, monkeypatch, ["GAME NAME", "PIC1", "WILD", "dynamic Text"],
               ["Layer 720.png", "SYM_WW.png"], {"PIC1": "Layer 720.png", "WILD": "SYM_WW.png"})
    cfg = dict(engine_api.DEFAULT_CONFIG, **cfg)
    codes = lambda pf: [w.get("code") for w in pf.get("warnings", []) + pf.get("blocking", [])]
    assert "icons_unresolved" not in codes(engine_api.preflight(cfg))
    cfg["icon_mappings"] = {"WILD": "SYM_WW.png"}
    pf = engine_api.preflight(cfg)
    msg = [w["message"] for w in pf["warnings"] if w.get("code") == "icons_unresolved"]
    assert msg and "PIC1" in msg[0] and "GAME NAME" not in msg[0]


def test_psd_layer_names_suggest_the_excels_tokens():
    from ps_autotypesetter.ui_web import symbol_scan as ss

    toks = ["A", "K", "10", "gold_scat", "PIC1", "WILD", "dynamic Text", "green_scatno_firecracker"]
    got = ss.suggest_names(["ace symbol #2", "king symbol", "ten symbol", "gold_scat #144", "pic1 symbol",
                            "WILD symbol", "text icon #14", "green_scat_no_firecracker #3", "Line 5 badge #3"], toks)
    assert got == {"ace symbol #2": "A", "king symbol": "K", "ten symbol": "10", "gold_scat #144": "gold_scat",
                   "pic1 symbol": "PIC1", "WILD symbol": "WILD", "green_scat_no_firecracker #3": "green_scatno_firecracker"}


def test_symbol_names_with_spaces_are_checked_placeholders_are_not():
    from ps_autotypesetter import symbol_tokens as st

    for t in ("Red Bag", "Feature MrMonopoly", "In Jail/Just Visiting", "+1 Spin Gold Bag", "WILD", "WILD2x"):
        assert st.is_symbol_token(t), t
    for t in ("GAME NAME", "dynamic text", "DYNAMIC SY", "# Lines", "Game Name"):
        assert not st.is_symbol_token(t), t


def test_provide_symbols_copies_only_the_missing_ones(tmp_path):
    import json

    from openpyxl import Workbook
    from PIL import Image

    from ps_autotypesetter.ui_web.server import create_app

    xl = tmp_path / "agr.xlsx"
    wb = Workbook()
    wb.active["B5"] = "<WILD> substitutes for all symbols except <Red Bag> and <Gold Bag>."
    wb.save(str(xl))
    syms, given = tmp_path / "Symbols", tmp_path / "artist"
    syms.mkdir(); given.mkdir()
    Image.new("RGBA", (4, 4)).save(str(syms / "WILD.png"))
    for n in ("Red Bag.png", "other.png"):
        Image.new("RGBA", (4, 4)).save(str(given / n))
    session = tmp_path / "session.json"
    client = create_app(session_file=str(session)).test_client()
    client.post("/api/config", json={"excel_path": str(xl), "icon_folder": str(syms)})
    r = client.post("/api/symbols/provide", json={"folder": str(given)}).get_json()
    assert [f["token"] for f in r["found"]] == ["Red Bag"] and r["missing"] == ["Gold Bag"]
    assert (syms / "Red Bag.png").exists() and not (syms / "other.png").exists()   # only what was missing
    json.dumps(r)
