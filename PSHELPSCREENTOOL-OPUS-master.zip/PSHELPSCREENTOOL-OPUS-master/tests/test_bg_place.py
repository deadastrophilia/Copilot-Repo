"""Background placement: one rule (bg_place) for the PNG / PSD build, thumbnails and the Canvas."""
from PIL import Image

from ps_autotypesetter import bg_place, png_builder


def test_spec_from_settings():
    assert bg_place.spec({}) == "cover"
    assert bg_place.spec({"bg_source": "color"}) == "color"
    assert bg_place.spec({"bg_mode": "fit_width", "bg_anchor": "bottom"}) == "fit_width:bottom"
    assert bg_place.spec({"bg_mode": "place", "bg_rect": [0, 1200, 2160, 2640]}) == "place:0,1200,2160,2640"
    assert bg_place.spec({"bg_mode": "place", "bg_rect": None}) == "cover"     # no rectangle: fills
    assert bg_place.spec({"bg_mode": "fill"}) == "cover"


def test_dest_rectangles():
    assert bg_place.dest("fit_width:bottom", 200, 400, 100, 50) == (0.0, 300.0, 200.0, 100.0)
    assert bg_place.dest("fit_width:top", 200, 400, 100, 50)[1] == 0.0
    assert bg_place.dest("place:10,20,30,40", 200, 400, 100, 50) == (10.0, 20.0, 30.0, 40.0)
    x, y, w, h = bg_place.dest("cover", 200, 400, 100, 100)
    assert (w, h) == (400.0, 400.0) and x == -100.0


def test_png_places_the_picture_and_fills_the_rest(tmp_path):
    pic = tmp_path / "bg.png"
    Image.new("RGBA", (100, 50), (255, 0, 0, 255)).save(pic)
    page = Image.new("RGBA", (200, 400), (0, 0, 0, 0))
    png_builder._paint_background(page, Image, str(pic), "fit_width:bottom", "#0000FF")
    assert page.getpixel((100, 10))[:3] == (0, 0, 255)            # above the picture: the colour
    assert page.getpixel((100, 350))[:3] == (255, 0, 0)           # the picture at the bottom
    page = Image.new("RGBA", (200, 400), (0, 0, 0, 0))
    png_builder._paint_background(page, Image, str(pic), "place:20,30,40,20", "#000000")
    assert page.getpixel((25, 35))[:3] == (255, 0, 0) and page.getpixel((10, 10))[:3] == (0, 0, 0)
