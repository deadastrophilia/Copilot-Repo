"""Text never runs past its paragraph box (like Photoshop's): the Canvas lays text out in the same
styled face the build draws ("Arial|Black", not plain Arial), and a word wider than the box breaks
between letters instead of sticking out."""

import os

import pytest
from openpyxl import Workbook
from PIL import Image, ImageDraw, ImageFont

from ps_autotypesetter import png_builder
from ps_autotypesetter.ui_web import engine_api
from ps_autotypesetter.ui_web.server import create_app

LONG = ("If only SYMBOL UPGRADES FEATURE and STICKY WILDS FEATURE are triggered in the same spin, "
        "the STICKY WILDS SYMBOL UPGRADES SUPER FEATURE is awarded.")


def _black_available():
    f = png_builder._load_font(ImageFont, "Arial|Black", 40)
    return "ariblk" in str(getattr(f, "path", "")).lower()


def _wrap(text, width, font="Arial|Black", size=42):
    f = png_builder._load_font(ImageFont, font, size)
    d = ImageDraw.Draw(Image.new("RGBA", (4, 4)))
    lines = png_builder._wrap_inline(d, Image, text, f, width, "", {}, 30, {}, 0, 0)
    return lines, [png_builder._measure_inline(d, Image, ln, f, "", {}, 30, {}, 0, 0)[0] for ln in lines]


def test_a_word_wider_than_the_box_breaks_between_letters():
    lines, widths = _wrap("short " + "X" * 60 + " end", 600)
    assert max(widths) <= 600 and len(lines) >= 3
    assert "".join(lines).replace(" ", "") == ("short" + "X" * 60 + "end")      # nothing lost
    assert lines[0] == "short"                                                    # the word starts its own line
    lines, widths = _wrap("W" * 50, 300)
    assert max(widths) <= 300 and "".join(lines) == "W" * 50


def test_words_that_fit_wrap_as_before_and_tokens_are_never_cut():
    assert _wrap("a b c", 600)[0] == ["a b c"]
    lines, _w = _wrap(LONG, 1500)
    assert all(" " not in ln[:1] for ln in lines) and " ".join(lines) == LONG     # whole words only
    assert _wrap("<SOME_VERY_LONG_TOKEN_NAME_HERE> ok", 100)[0][0] == "<SOME_VERY_LONG_TOKEN_NAME_HERE>"


@pytest.mark.skipif(not _black_available(), reason="Arial Black not installed")
def test_canvas_layout_uses_the_styled_face_the_build_draws(tmp_path):
    wb = Workbook()
    ws = wb.active
    ws.title = "Features"
    ws["B2"] = "FEATURES"
    for r in range(4, 10):
        ws.cell(r, 2, LONG)
    path = os.path.join(str(tmp_path), "f.xlsx")
    wb.save(path)
    client = create_app(session_file=os.path.join(str(tmp_path), "session.json")).test_client()
    client.post("/api/config", json={"excel_path": path, "c_width": 3840, "c_height": 2160, "margin_x": 241,
                                     "b_font": "Arial", "b_font_style": "Black", "b_size": 42, "icon_folder": ""})
    d = client.post("/api/layout/preview", json={"sheet_name": "Features"}).get_json()
    assert d["ok"] and d["mode"] == "canonical"
    body = [e for e in d["layouts"][0]["elements"] if e["type"] == "text" and e["meta"].get("kind") != "heading"]
    assert body and {e["font"] for e in body} == {engine_api._font_request("Arial", "Black")}
    face = png_builder._load_font(ImageFont, "Arial|Black", 42)
    for e in body:
        for text, w in zip(e["wrapped_lines"], e["line_widths"]):
            assert w <= e["width"]
            assert face.getlength(text) <= e["width"] + 1        # measured in the face it is drawn in
    # plain Arial would have fitted the long sentence on fewer lines: the Black face wraps more
    assert sum(len(e["wrapped_lines"]) for e in body) > 6
