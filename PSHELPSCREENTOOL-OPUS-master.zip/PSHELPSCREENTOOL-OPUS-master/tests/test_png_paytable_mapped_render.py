"""PNG builder renders web-Paytable-Mapper authored JSONs through their own
per-slot ``mappings`` -- the same clean content the Paytable Mapper studio
preview shows with annotations off -- instead of the PSD-parser guess path."""

import json
import os

from PIL import Image, ImageDraw, ImageFont

from ps_autotypesetter import png_builder

BG = (18, 22, 30)


def _mapper_template():
    return {
        "canvas": {"width": 1920, "height": 1080},
        "slots": {
            "title": {"x": 0, "y": 0, "w": 1920, "h": 100},
            "wild.title": {"x": 0, "y": 120, "w": 1920, "h": 80},
            "pic1": {"x": 100, "y": 300, "w": 220, "h": 220},
            "pic1.pay": {"x": 100, "y": 540, "w": 220, "h": 120},
            "pic1.value": {"x": 340, "y": 540, "w": 220, "h": 120},
            "notes": {"x": 100, "y": 900, "w": 1720, "h": 120},
            "unmapped.box": {"x": 1400, "y": 700, "w": 200, "h": 200},
        },
        "mappings": {
            "title": {"mode": "literal", "text": "PAYTABLE", "color": "#FFFFFF"},
            "wild.title": {"mode": "literal", "text": "WILD", "color": "#FFCD32"},
            "pic1": {"mode": "icon", "token": "<PIC1>", "icon_height": 180},
            "pic1.pay": {"mode": "text", "text": "5\n4\n3\n2", "font_size": 34,
                         "color": "#FFFFFF", "alignment": "center",
                         "vertical_align": "center", "padding": [0, 0, 0, 0]},
            "pic1.value": {"mode": "excel", "source": "H3", "text": "150\n50\n10\n5",
                           "font_size": 34, "color": "#FFD700",
                           "alignment": "left", "vertical_align": "top",
                           "padding": [6, 6, 6, 6]},
            "notes": {"mode": "text", "text": "PAY TABLE NOTES", "font_size": 26,
                      "color": "#FFFFFF", "background_color": "#222233",
                      "opacity": 100, "fill_enabled": True,
                      "stroke_color": "#887755", "stroke_width": 3,
                      "stroke_enabled": True, "vertical_align": "center"},
        },
        "mapper_meta": {"generated_by": "web_paytable_mapper", "sheet_name": "Paytable"},
    }


def _render(template, settings=None, icon_folder="", icon_mappings=None, canvas=(640, 360)):
    page = Image.new("RGBA", canvas, BG + (255,))
    draw = ImageDraw.Draw(page)
    png_builder._render_mapped_paytable_png(
        page, draw, Image, ImageFont, template, None, "Paytable",
        settings or {}, icon_folder, icon_mappings or {}, {},
        png_builder.scale_template_slots(template, canvas[0], canvas[1])[0],
        4, {},
    )
    return page


def _non_bg_pixels(page, xr, yr):
    px = page.load()
    return sum(1 for x in xr for y in yr if px[x, y][:3] != BG)


def test_mapper_design_detection():
    from ps_autotypesetter.dynamic_pages.router import _is_mapper_design

    assert _is_mapper_design(_mapper_template())
    legacy = dict(_mapper_template())
    legacy["mappings"] = {}
    legacy["mapper_meta"] = {}
    legacy["table_templates"] = {}
    assert not _is_mapper_design(legacy)


def test_mapped_fill_and_stroke_render():
    """640x360 canvas scales the 1920x1080 design 1:3 -> notes slot at
    (33, 300, 573, 40). Fill composites onto the canvas (opaque enough),
    stroke draws on the border, outside stays the canvas background.
    Near the left edge there is no text, so the strip is pure fill."""
    page = _render(_mapper_template())
    px = page.load()
    # rows 306-325 are pure fill (stroke borders are rows 300-302 / 337-339)
    fill_strip = [px[x, y][0] for x in range(40, 65, 5) for y in range(306, 326, 5)]
    assert all(25 <= r <= 90 for r in fill_strip)  # #222233 fill over dark bg
    assert px[33, 300][:3] == (136, 119, 85)   # stroke border 0x887755
    assert px[33, 339][:3] == (136, 119, 85)
    assert px[20, 310][:3] == BG               # outside the slot untouched
    assert _non_bg_pixels(page, range(60, 600, 25), range(305, 335, 8)) > 20  # text present


def test_unmapped_slot_stays_invisible_without_annotations():
    """unmapped.box scales to (466, 233, 66, 66): nothing drawn --
    no blueprint outline, no slot label, no default fill."""
    page = _render(_mapper_template())
    px = page.load()
    assert all(px[x, y][:3] == BG and px[x, y][3] == 255
               for x in range(472, 530, 8) for y in range(240, 292, 8))


def test_mapped_text_slots_render():
    page = _render(_mapper_template())
    # pic1.pay text (white, centered) and pic1.value text (left/top, gold)
    assert _non_bg_pixels(page, range(40, 200, 12), range(190, 214, 6)) > 0
    assert _non_bg_pixels(page, range(120, 250, 12), range(190, 214, 6)) > 0


def test_title_and_wild_title_render():
    page = _render(_mapper_template())
    # title slot (0,0,640,33) and wild.title (0,40,640,26) show text
    assert _non_bg_pixels(page, range(300, 600, 30), range(8, 26, 5)) > 0
    assert _non_bg_pixels(page, range(300, 600, 30), range(46, 62, 5)) > 0


def test_flow_through_dynamic_json_interception(tmp_path):
    """End-to-end: the paytable JSON interception routes a web-mapper design
    to the mapped renderer (notes fill + stroke prove it) instead of the PSD
    parser path."""
    from openpyxl import Workbook

    wb = Workbook()
    ws = wb.active
    ws.title = "Paytable"
    path = os.path.join(str(tmp_path), "design.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(_mapper_template(), f)
    page = Image.new("RGBA", (640, 360), BG + (255,))
    draw = ImageDraw.Draw(page)
    png_builder._render_dynamic_json_page_png(
        page, draw, Image, ImageFont, ws, "Paytable", path,
        {"enabled": True, "template_json": path, "sheet_name": "Paytable"},
        "", {}, {}, 640, 360,
        "arialbd.ttf", 90, (255, 80, 80), "arial.ttf", 30, (255, 255, 255),
        0, 4, {},
    )
    px = page.load()
    fill_strip = [px[x, y][0] for x in range(40, 65, 5) for y in range(306, 326, 5)]
    assert all(25 <= r <= 90 for r in fill_strip)
    assert px[33, 300][:3] == (136, 119, 85)
    assert px[20, 310][:3] == BG