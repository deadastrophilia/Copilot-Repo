"""Fast symbol scan of an artist PSD (symbol_scan.py)."""
import os

import pytest
from PIL import Image, ImageDraw

psd_tools = pytest.importorskip("psd_tools")
from psd_tools import PSDImage
from psd_tools.api.layers import PixelLayer

from ps_autotypesetter.ui_web import symbol_scan


def _gem(colour, size):
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.ellipse((2, 2, size - 3, size - 3), fill=colour)
    d.rectangle((size // 3, size // 3, size // 2, size // 2), fill=(255, 255, 255, 255))
    return img


def _place(img, canvas, x, y):
    full = Image.new("RGBA", canvas, (0, 0, 0, 0))
    full.paste(img, (x, y))
    return full


@pytest.fixture
def psd_file(tmp_path, monkeypatch):
    monkeypatch.setattr(symbol_scan, "_CACHE", {})
    canvas = (800, 600)
    psd = PSDImage.new("RGBA", canvas)
    bg = Image.new("RGBA", canvas, (20, 40, 90, 255))
    ImageDraw.Draw(bg).ellipse((100, 100, 700, 500), fill=(60, 90, 160, 255))
    psd.append(PixelLayer.frompil(bg, psd, name="bg"))
    page1 = psd.create_group(name="Paytable")
    page1.append(PixelLayer.frompil(_place(_gem((200, 40, 200, 255), 120), canvas, 50, 50), psd, name="purple big"))
    page1.append(PixelLayer.frompil(_place(_gem((220, 30, 30, 255), 120), canvas, 300, 50), psd, name="Layer 12"))
    page2 = psd.create_group(name="Rules")
    page2.append(PixelLayer.frompil(_place(_gem((200, 40, 200, 255), 60), canvas, 40, 300), psd, name="Layer 99 copy 3"))
    page2.append(PixelLayer.frompil(_place(_gem((200, 40, 200, 255), 60), canvas, 400, 300), psd, name="Layer 99 copy 4"))
    block = Image.new("RGBA", (90, 90), (0, 0, 0, 255))
    page2.append(PixelLayer.frompil(_place(block, canvas, 600, 300), psd, name="clip base"))
    page2.visible = False                                 # pages after the first are hidden in real PSDs
    path = tmp_path / "ref.psd"
    psd.save(str(path))
    return str(path)


def test_scan_finds_each_symbol_once_including_hidden_pages(psd_file):
    res = symbol_scan.scan(psd_file)
    syms = res["symbols"]
    assert len(syms) == 2                                 # purple (3 copies, 2 sizes) + red
    purple = [s for s in syms if s["count"] == 3][0]
    assert purple["name"] == "purple big"                 # descriptive name wins over "Layer 99 copy 3"
    assert (purple["w"], purple["h"]) == (116, 116)       # biggest copy (painted size) kept for export
    assert set(purple["pages"]) == {"Paytable", "Rules"}
    assert len(purple["sizes"]) == 2
    red = [s for s in syms if s["count"] == 1][0]
    assert red["name"] == "Layer 12"                      # same shape, other colour -> separate symbol
    assert [b["name"] for b in res["backgrounds"]] == ["bg"]
    assert any(o["name"] == "clip base" for o in res["others"])   # flat block is not a symbol
    pub = symbol_scan.public(res)
    assert "_images" not in pub and all("_sig" not in s for s in pub["symbols"])


def test_thumbnails_are_real_pictures(psd_file):
    res = symbol_scan.scan(psd_file)
    import io

    for s in res["symbols"]:
        img = Image.open(io.BytesIO(symbol_scan.thumbnail(psd_file, s["key"])))
        assert img.getbbox() is not None


def test_export_saves_symbols_and_background(psd_file, tmp_path):
    res = symbol_scan.scan(psd_file)
    items = [{"key": s["key"], "name": "wild" if s["count"] == 3 else "scatter"} for s in res["symbols"]]
    items.append({"key": res["backgrounds"][0]["key"], "name": "bg"})
    out = symbol_scan.export(psd_file, items, str(tmp_path / "Working" / "Symbols"), str(tmp_path / "Working" / "BG"))
    names = sorted(f["name"] for f in out["files"] if f["kind"] == "symbol")
    assert names == ["scatter.png", "wild.png"]
    wild = Image.open(tmp_path / "Working" / "Symbols" / "wild.png")
    assert wild.size == (116, 116) and wild.mode == "RGBA"   # painted size in the PSD
    assert os.path.isfile(tmp_path / "Working" / "BG" / "bg.png")


def test_suggest_names_matches_excel_tokens():
    got = symbol_scan.suggest_names(["WILD symbol", "Layer 12", "scatter_purple"], ["wild", "purple_scat", "ace"])
    assert got == {"WILD symbol": "wild"}


def test_existing_symbols_are_never_overwritten_silently(psd_file, tmp_path):
    res = symbol_scan.scan(psd_file)
    sym = tmp_path / "Working" / "Symbols"
    sym.mkdir(parents=True)
    Image.new("RGBA", (5, 5), (1, 2, 3, 255)).save(sym / "wild.png")      # the artist's own file
    items = [{"key": res["symbols"][0]["key"], "name": "wild"}]
    assert symbol_scan.conflicts(items, str(sym)) == [str(sym / "wild.png")]
    out = symbol_scan.export(psd_file, items, str(sym))                    # default: keep both
    assert out["files"][0]["name"] == "wild_2.png"
    assert Image.open(sym / "wild.png").size == (5, 5)                    # untouched
    symbol_scan.export(psd_file, items, str(sym), on_conflict="replace")
    assert Image.open(sym / "wild.png").size != (5, 5)


def test_export_route_asks_before_overwriting(psd_file, tmp_path):
    from ps_autotypesetter.ui_web import path_policy
    from ps_autotypesetter.ui_web.server import create_app

    app = create_app(session_file=str(tmp_path / "session.json"))
    client = app.test_client()
    path_policy.grant(psd_file)
    sym = tmp_path / "Working" / "Symbols"
    sym.mkdir(parents=True)
    Image.new("RGBA", (5, 5)).save(sym / "wild.png")
    key = symbol_scan.scan(psd_file)["symbols"][0]["key"]
    body = {"psd_path": psd_file, "items": [{"key": key, "name": "wild"}], "symbols_dir": str(sym), "bg_dir": str(tmp_path / "BG")}
    r = client.post("/api/symbols/export_picked", json=body)
    assert r.status_code == 409 and r.get_json()["needs_choice"]
    assert Image.open(sym / "wild.png").size == (5, 5)
    r = client.post("/api/symbols/export_picked", json=dict(body, on_conflict="keep_both"))
    assert r.status_code == 200 and r.get_json()["files"][0]["name"] == "wild_2.png"
