"""Clone a market: the artist's PSD for market A, with market B's Excel data in its text layers."""
import json
import logging
import os

import pytest
from openpyxl import Workbook, load_workbook

from ps_autotypesetter import market_clone as mc

logging.getLogger("psd_tools").setLevel(logging.ERROR)
REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


# ── the text rules ────────────────────────────────────────────────────────────
def test_word_diff_keeps_the_artists_line_breaks_and_spacing():
    artist = "Three scatters award\r10 free spins.  "
    new, why = mc.word_diff(artist, "Three scatters award 10 free spins.", "Four scatters award 12 free spins.")
    assert why is None and new == "Four scatters award\r12 free spins.  "


def test_word_diff_leaves_icon_lines_to_the_artist():
    artist = "Collect          to win the bonus"             # spaces where the artist placed an icon layer
    a, b = "Collect <COIN> to win the bonus", "Collect <COIN> to win the grand bonus"
    new, why = mc.word_diff(artist, a, b)
    assert new is None and "icon" in why
    same_length, why = mc.word_diff(artist, a, "Collect <COIN> to win the bonuz")
    assert same_length == "Collect          to win the bonuz" and why is None


def test_values_keep_the_artists_number_format_and_line_spacing():
    assert mc.lines_replaced("1,250\r500\r\r", ["2500", "750"]) == "2,500\r750\r\r"
    assert mc.lines_replaced("150\r50", ["1", "2", "3"]) is None       # no longer line up


def test_rows_added_in_the_new_market_do_not_shift_the_rest(tmp_path):
    a = _book(tmp_path / "a.xlsx", {"S": [["Title"], ["First rule."], ["Second rule."]]})
    b = _book(tmp_path / "b.xlsx", {"S": [["Title"], ["A brand new rule."], ["First rule."], ["Second rule changed."]]})
    sa, sb = mc.read_workbook(a)["S"], mc.read_workbook(b)["S"]
    rm = mc.RowMap(sa, sb)
    assert rm.map[2] == 3 and rm.map[3] == 4 and rm.new_rows == [2]


def _book(path, sheets):
    wb = Workbook()
    wb.remove(wb.active)
    for name, rows in sheets.items():
        ws = wb.create_sheet(name)
        for row in rows:
            ws.append(row)
    wb.save(path)
    return str(path)


# ── a whole PSD (made by the tool's writer, as a stand-in for the artist's) ──
@pytest.fixture
def market_a(tmp_path):
    pytest.importorskip("photoshopapi")
    pytest.importorskip("psd_tools")
    from ps_autotypesetter.psd_writer import build as psd_build
    from ps_autotypesetter.ui_web import engine_api

    excel = _book(tmp_path / "Game NYL.xlsx", {"Features": [
        ["FREE SPINS"],
        ["Three scatters award 10 free spins."],
        ["Wins are multiplied by the bet multiplier."],
    ]})
    cfg = {"excel_path": excel, "icon_folder": "", "bg_path": "", "bg_source": "color", "bg_color": "#102040",
           "output_dir": str(tmp_path / "out"), "output_name": "Game NYL", "render_all_pages": True,
           "c_width": 1280, "c_height": 720}
    psd = psd_build.build_psd(**engine_api._build_kwargs(cfg), output_format="PSD")
    return psd, excel


def test_clone_writes_market_b_into_the_same_design(tmp_path, market_a):
    from psd_tools import PSDImage

    psd, excel_a = market_a
    excel_b = _book(tmp_path / "Game HHR.xlsx", {"Features": [
        ["FREE SPINS"],
        ["Bonus spins can be bought."],                  # a row the NYL PSD never had
        ["Four scatters award 12 free spins."],
        ["Wins are multiplied by the bet multiplier."],
    ]})
    out = str(tmp_path / "Game HHR.psd")
    report = mc.clone(psd, excel_a, excel_b, out)
    assert report["edited"] >= 1 and os.path.isfile(out)
    before, after = PSDImage.open(psd), PSDImage.open(out)
    texts = " ".join(l.text for l in after.descendants() if l.kind == "type" and l.visible)
    norm = " ".join(texts.split())
    assert "Four scatters award 12 free spins." in norm and "Three scatters" not in norm
    assert "FREE SPINS" in norm and "bet multiplier" in norm                              # the rest as it was
    # the row market B added: placed as a copy of the row most like it (one layer more, nothing else)
    assert "Bonus spins can be bought." in norm and report["new_rows"] == []
    assert sum(1 for _ in after.descendants()) == sum(1 for _ in before.descendants()) + 1
    saved = json.load(open(report["report_path"], encoding="utf-8"))
    assert saved["counts"].get("change", 0) >= 1


def test_review_pictures_show_each_change_before_and_after(tmp_path, market_a):
    from PIL import Image, ImageChops

    psd, excel_a = market_a
    excel_b = _book(tmp_path / "Game HHR.xlsx", {"Features": [
        ["FREE SPINS"], ["Four scatters award 12 free spins."], ["Wins are multiplied by the bet multiplier."]]})
    report = mc.clone(psd, excel_a, excel_b, str(tmp_path / "Game HHR.psd"))
    pages = report["pages"]
    assert len(pages) == 1 and pages[0]["changed"] == 1 and pages[0]["kind"] == "page"
    crop = pages[0]["crops"][0]                                # just the changed area, before and after
    assert os.path.dirname(crop["after"]).endswith(" - review") and "Four" in crop["new"]
    before, after = Image.open(crop["before"]), Image.open(crop["after"])
    assert before.size == after.size and before.width < 1280
    assert ImageChops.difference(before.convert("L"), after.convert("L")).getbbox()


def test_identical_markets_change_nothing(tmp_path, market_a):
    psd, excel_a = market_a
    report = mc.clone(psd, excel_a, excel_a, str(tmp_path / "copy.psd"))
    assert report["edited"] == 0 and not report["layers"] and report["pages"] == []


# ── the real artist PSD (when the reference files are on this machine) ─────────
ARTIST = os.path.join(REPO, "PSDRef", "BZZF_blastBlueHelps.psd")
NYL = os.path.join(REPO, "PSDRef", "BZZF_Blast_AGR_NYL.xlsx")
CHANGED = os.path.join(REPO, "proof_replicate", "BZZF_modified.xlsx")


@pytest.mark.skipif(not all(map(os.path.isfile, (ARTIST, NYL, CHANGED))), reason="reference PSD not here")
def test_artist_psd_payouts_and_rules_follow_the_new_excel(tmp_path):
    from psd_tools import PSDImage

    report = mc.clone(ARTIST, NYL, CHANGED, str(tmp_path / "BZZF HHR.psd"), icon_folder=os.path.join(REPO, "symbols"),
                      pictures=False)
    changed = [l for l in report["layers"] if l["status"] == "change"]
    assert len(changed) == 8 and report["edited"] == 8
    assert not [l for l in report["layers"] if l["status"] == "ambiguous"]
    # look-alike pay columns told apart by the symbol on their card (as the symbol-matching proof found)
    by_card = {l["source"] for l in changed}
    assert {"Paytable!H34-H36", "Paytable!H42-H44", "Paytable!H50-H52", "Paytable!H22-H24"} <= by_card
    out = PSDImage.open(str(tmp_path / "BZZF HHR.psd"))
    texts = [l.text for l in out.descendants() if l.kind == "type"]
    assert any("2, 3 and 4 only" in t for t in texts)


@pytest.mark.skipif(not all(map(os.path.isfile, (ARTIST, NYL, CHANGED))), reason="reference PSD not here")
def test_unnamed_card_pictures_are_left_and_asked_for_then_linked(tmp_path):
    # this PSD's card pictures are plain "Layer 882"s: nothing names them, so the cards that look
    # alike are left as they are and their pictures are listed for the artist to name once
    report = mc.check(ARTIST, NYL, CHANGED)
    ambiguous = [l for l in report["layers"] if l["status"] == "ambiguous"]
    assert ambiguous and all("Symbols" in l["why"] for l in ambiguous)
    asked = [s for s in report["symbols"] if s["needed"]]
    assert asked and all(s["card"] for s in asked)
    # what the symbol folder used to work out, given as the artist's links instead: the same result
    with_folder = mc.check(ARTIST, NYL, CHANGED, icon_folder=os.path.join(REPO, "symbols"))
    links = {"symbols": {s["sig"]: s["token"] for s in with_folder["symbols"] if s["card"] and s["token"]}}
    linked = mc.clone(ARTIST, NYL, CHANGED, str(tmp_path / "BZZF HHR.psd"), pictures=False, links=links)
    assert linked["edited"] == 8 and not [l for l in linked["layers"] if l["status"] == "ambiguous"]


@pytest.mark.skipif(not all(map(os.path.isfile, (ARTIST, NYL, CHANGED))), reason="reference PSD not here")
def test_a_page_linked_to_no_sheet_is_left_alone():
    first = mc.check(ARTIST, NYL, CHANGED)
    pay = next(p for p in first["page_links"] if p["sheet"] == "Paytable")
    again = mc.check(ARTIST, NYL, CHANGED, links={"chosen": {pay["key"]: ""}})   # the artist chose it
    assert not [l for l in again["layers"] if l["page_key"] == pay["page_key"]]
    assert next(p for p in again["page_links"] if p["key"] == pay["key"])["how"] == "link"


# ── rows, symbols and text, without a PSD ─────────────────────────────────────
def test_rows_whose_every_value_changed_still_pair_up(tmp_path):
    a = _book(tmp_path / "a.xlsx", {"P": [[None, 5, 150], ["<PIC1>", 4, 50], [None, 3, 10]]})
    b = _book(tmp_path / "b.xlsx", {"P": [[None, 69, 69], ["<PIC1>", 4, 50], [None, 69, 69]]})
    rm = mc.RowMap(mc.read_workbook(a)["P"], mc.read_workbook(b)["P"])
    assert rm.map == {1: 1, 2: 2, 3: 3} and rm.new_rows == []


def test_symbol_names_compare_however_they_are_spelled():
    assert mc.sym_key("<PIC4>") == mc.sym_key("PIC_04 copy 3") == mc.sym_key("PIC_04.png") == "pic4"
    assert mc.sym_key("Purple Firework L copy.psb") == "purplefireworkl"


def test_removed_words_take_their_space_and_removed_sentences_their_line():
    new, _ = mc.word_diff("one unfilled position is randomly selected.",
                          "one unfilled position is randomly selected.", "one unfilled position is selected.")
    assert new == "one unfilled position is selected."
    artist = "Malfunction voids all pays.\rThis is a lottery game.\rPlayer is responsible."
    new, _ = mc.word_diff(artist, "Malfunction voids all pays. This is a lottery game. Player is responsible.",
                          "Malfunction voids all pays. Player is responsible.")
    assert new == "Malfunction voids all pays.\rPlayer is responsible."


def test_punctuation_moves_with_the_words_around_it():
    new, _ = mc.word_diff("divided into 4 zones randomly, purple and red.",
                          "divided into 4 zones randomly, purple and red.", "divided into 4 zones, purple and red.")
    assert new == "divided into 4 zones, purple and red."


def test_cells_with_icons_keep_their_gaps_never_a_token():
    artist = "a chance that random credits are added to any 1 or more           .\rAdded to           : 0.5 x"
    a = ["a chance that random credits are added to any 1 or more <gold_scat>.", "Added to <gold_scat> : 0.5 x"]
    b = ["a chance that credits are added to any 1 or more <gold_scat>.", "Added to <gold_scat> : 0.5 x"]
    new, why = mc.lines_diffed(artist, a, b)
    assert why is None and "<" not in new
    assert new == "a chance that credits are added to any 1 or more           .\rAdded to           : 0.5 x"


class _Layer:
    """Just enough of a psd-tools layer for the row logic."""

    def __init__(self, kind, name, box, text=None):
        self.kind, self.name, self.text, self.visible = kind, name, text, True
        self.left, self.top, self.right, self.bottom = box
        self.layer_id = id(self)

    width = property(lambda s: s.right - s.left)
    height = property(lambda s: s.bottom - s.top)


class _Doc(list):
    size = (730, 400)

    def descendants(self):
        return iter(self)


def test_a_symbol_removed_from_a_heading_is_hidden_and_the_row_closes_up(tmp_path):
    row = [_Layer("type", "SCATTERED", (100, 100, 400, 150), "SCATTERED"),
           _Layer("pixel", "purple", (420, 95, 470, 155)), _Layer("type", ",", (480, 130, 490, 150), ","),
           _Layer("pixel", "blue", (500, 95, 550, 155)), _Layer("type", ",", (560, 130, 570, 150), ","),
           _Layer("pixel", "red", (580, 95, 630, 155))]
    doc = _Doc(row)
    a = _book(tmp_path / "a.xlsx", {"S": [["SCATTERED <purple_scat>, <blue_scat>, <red_scat>"]]})
    b = _book(tmp_path / "b.xlsx", {"S": [["SCATTERED <blue_scat>, <red_scat>"]]})
    sa, sb = mc.read_workbook(a), mc.read_workbook(b)
    symbols = mc.Symbols(doc, sa)
    symbols.learn_rows(doc, sa["S"].cells)
    assert [symbols.token(p) for p in row if p.kind == "pixel"] == ["purple_scat", "blue_scat", "red_scat"]
    place = symbols.place
    the_plan = {"page_sheet": {"0": "S"}, "_roots": {"0": doc}, "_symbols": symbols, "_size": doc.size,
                "items": [{"page": "p", "page_key": "0", "place": place[id(l)], "old": l.text, "status": "design"}
                          for l in row if l.kind == "type"]}
    edits = mc.icon_edits(the_plan, sa, sb, {"S": mc.RowMap(sa["S"], sb["S"])})
    assert len(edits) == 1 and edits[0]["status"] == "change"
    assert sorted(edits[0]["hide"]) == sorted([place[id(row[1])], place[id(row[2])]])   # the symbol and its comma
    moves = dict((p, dx) for p, dx in edits[0]["move"])
    # 90 px went (from SCATTERED's end to the comma's end); the centred row moves back by half
    assert moves[place[id(row[0])]] == 45 and moves[place[id(row[3])]] == -45 and moves[place[id(row[5])]] == -45


def test_an_added_symbol_is_left_to_the_artist(tmp_path):
    row = [_Layer("type", "SCATTERED", (100, 100, 400, 150), "SCATTERED"), _Layer("pixel", "blue", (420, 95, 470, 155))]
    doc = _Doc(row)
    a = _book(tmp_path / "a.xlsx", {"S": [["SCATTERED <blue_scat>"]]})
    b = _book(tmp_path / "b.xlsx", {"S": [["SCATTERED <purple_scat> <blue_scat>"]]})
    sa, sb = mc.read_workbook(a), mc.read_workbook(b)
    symbols = mc.Symbols(doc, sa)
    the_plan = {"page_sheet": {"0": "S"}, "_roots": {"0": doc}, "_symbols": symbols, "_size": doc.size, "items": []}
    edits = mc.icon_edits(the_plan, sa, sb, {"S": mc.RowMap(sa["S"], sb["S"])})
    assert [e["status"] for e in edits] == ["artist"] and not edits[0]["hide"]


@pytest.mark.skipif(not all(map(os.path.isfile, (ARTIST, NYL, CHANGED))), reason="reference PSD not here")
def test_photoshops_text_block_follows_the_edited_layers_and_keeps_the_rest(tmp_path):
    import io

    from psd_tools.constants import Tag

    from ps_autotypesetter.artist_design import psd_reader

    out = str(tmp_path / "BZZF HHR.psd")
    report = mc.clone(ARTIST, NYL, CHANGED, out, icon_folder=os.path.join(REPO, "symbols"), pictures=False,
                      photoshop_redraw=False)                    # the block kept in step (no update prompt)
    assert report["text_engine"] == "updated"
    src, dst = psd_reader.open_lazy(ARTIST), psd_reader.open_lazy(out)
    block = lambda p: p._record.layer_and_mask_information.tagged_blocks.get_data(Tag.TEXT_ENGINE_DATA)["1"]["1"]
    so, do = block(src), block(dst)

    def raw(o):
        b = io.BytesIO()
        o.write(b)
        return b.getvalue()

    edited = 0
    for a, b in zip(src.descendants(), dst.descendants()):
        if a.kind != "type":
            continue
        i = int(b._record.tagged_blocks.get_data(Tag.TYPE_TOOL_OBJECT_SETTING).text_data[b"TextIndex"])
        text = mc._editor_text(b)
        if a.text != b.text:                          # edited: the document copy says the same, runs add up
            edited += 1
            m = do[i]["0"]
            assert str(m["0"].value) == text and "2" not in do[i]["1"]
            assert sum(int(r["1"]) for r in m["5"]["0"]) == len(text) == sum(int(r["1"]) for r in m["6"]["0"])
        else:                                         # untouched: byte for byte as Photoshop wrote it
            assert raw(so[i]) == raw(do[i])
    assert edited == 8


def test_links_are_saved_with_the_game_and_shared_by_its_psds(tmp_path, monkeypatch):
    from ps_autotypesetter import games

    monkeypatch.setattr(games, "REGISTRY_FILE", str(tmp_path / "Games.json"))
    mc.save_links(r"C:\x\Game NYL.psd", {"pages": {"3|scatters": "SCATTERED"}, "symbols": {"so:PIC_04.png": "PIC4", "px:12": "ACE"}})
    same = mc.load_links(r"D:\elsewhere\game nyl.psd")
    assert same["pages"] == {"3|scatters": "SCATTERED"} and same["symbols"]["px:12"] == "ACE" and same["saved"]
    other = mc.load_links(r"C:\x\Game HHR.psd")                  # another market's PSD of the game
    assert other["symbols"] == {"so:PIC_04.png": "PIC4"} and other["pages"] == {} and not other["saved"]


# ── pages: a new sheet copies its closest page group; a removed sheet's group is labelled ──
@pytest.mark.skipif(not os.path.isfile(ARTIST), reason="reference PSD not here")
def test_a_page_group_is_copied_inside_the_artists_psd(tmp_path):
    import collections

    from psd_tools.constants import SheetColorType, Tag

    from ps_autotypesetter.artist_design import psd_pages, psd_reader

    psd = psd_reader.open_lazy(ARTIST)
    tops = list(psd)
    page = next(t for t in tops if t.is_group() and any(l.kind == "type" for l in t.descendants()))
    gone = next(t for t in tops if t.is_group() and t is not page)
    before = len(psd._record.layer_and_mask_information.layer_info.layer_records)
    first, last = psd_pages.duplicate_group(psd, page, name="NEW PAGE - NEW from Excel")
    psd_pages.mark_group(psd, gone, name="DELETED FROM EXCEL - " + gone.name)
    out = str(tmp_path / "pages.psd")
    with open(out, "wb") as f:
        psd._record.write(f)

    again = psd_reader.open_lazy(out)
    names = [t.name for t in again]
    i = names.index("NEW PAGE - NEW from Excel")
    assert names[i - 1] == page.name                   # right above the page it copies
    copy_, orig = list(again)[i], list(again)[i - 1]
    assert [l.name for l in copy_.descendants()] == [l.name for l in orig.descendants()]
    assert [str(l.text) for l in copy_.descendants() if l.kind == "type"] == \
           [str(l.text) for l in orig.descendants() if l.kind == "type"]
    li = again._record.layer_and_mask_information.layer_info
    added = last - first + 1
    assert len(li.layer_records) == before + added
    assert len(again._record.image_resources.get(1026).data) == before + added
    ids = collections.Counter(r.tagged_blocks.get_data(Tag.LAYER_ID) for r in li.layer_records)
    assert max(ids.values()) == 1                     # every layer its own id
    texts = [int(r.tagged_blocks.get_data(Tag.TYPE_TOOL_OBJECT_SETTING).text_data[b"TextIndex"])
             for r in li.layer_records if r.tagged_blocks.get_data(Tag.TYPE_TOOL_OBJECT_SETTING) is not None]
    assert len(set(texts)) == len(texts)              # every text layer its own document text entry
    marked = next(t for t in again if t.name.startswith("DELETED FROM EXCEL"))
    assert marked._record.tagged_blocks.get_data(Tag.SHEET_COLOR_SETTING) == SheetColorType.RED


@pytest.mark.skipif(not all(map(os.path.isfile, (ARTIST, NYL, CHANGED))), reason="reference PSD not here")
def test_new_removed_and_renamed_sheets_preview_then_write_only_what_was_approved(tmp_path):
    from psd_tools.constants import SheetColorType, Tag

    from ps_autotypesetter.artist_design import psd_reader

    wb = load_workbook(CHANGED)
    twin = wb.copy_worksheet(wb["Wheel(denom5&6)"])           # a new denom: like 5&6, one value different
    twin.title = "Wheel(denom7&8)"
    for row in twin.iter_rows():
        for c in row:
            if isinstance(c.value, str) and "Wheel" in c.value:
                c.value = c.value.replace("Wheel", "Big Wheel", 1)
                break
    wb.move_sheet(twin, offset=wb.index(wb["Wheel(denom5&6)"]) + 1 - wb.index(twin))
    del wb["Jackpots"]                                          # a sheet the new AGR dropped
    wb["DoubleUp_feature"].title = "Double Up Feature"          # only renamed: the same page
    excel_b = str(tmp_path / "v2.xlsx")
    wb.save(excel_b)

    seen = mc.check(ARTIST, NYL, excel_b)
    pc = seen["page_changes"]
    assert [n["sheet"] for n in pc["new"]] == ["Wheel(denom7&8)"] and pc["new"][0]["sibling"] == "Wheel(denom5&6)"
    assert [g["sheet"] for g in pc["removed"]] == ["Jackpots"]
    assert pc["renamed"] == [{"from": "DoubleUp_feature", "to": "Double Up Feature"}]

    shown = mc.preview(ARTIST, NYL, excel_b, str(tmp_path / "preview"), icon_folder=os.path.join(REPO, "symbols"))
    kinds = {p["id"]: p["kind"] for p in shown["pages"]}
    assert kinds["new:Wheel(denom7&8)"] == "new" and kinds["removed:Jackpots"] == "removed"
    jobs = shown.pop("_crop_jobs")
    assert jobs == [] or all(os.path.isfile(j[0]) for j in jobs)        # drawn (preview draws them by default)
    assert all(c["before"] and os.path.isfile(c["before"]) for p in shown["pages"] for c in p["crops"])
    assert not os.path.exists(str(tmp_path / "v2.psd"))         # a preview writes no PSD
    changed = [p["id"] for p in shown["pages"] if p["kind"] == "page"]
    kept = changed[0]

    out = str(tmp_path / "v2.psd")
    report = mc.clone(ARTIST, NYL, excel_b, out, icon_folder=os.path.join(REPO, "symbols"), pictures=False, reject=[kept])
    assert report["untouched"]["differ"] == [] and report["untouched"]["pages"] > 0
    assert report["counts"].get("kept", 0) >= 1
    psd = psd_reader.open_lazy(out)
    names = [t.name for t in psd]
    new = names.index("Wheel(denom7&8)" + mc.NEW_TAG)
    assert names[new - 1].startswith("Wheel Blast denom 5 6")      # in AGR order: right after 5&6's page
    copy_texts = " ".join(str(l.text) for l in list(psd)[new].descendants() if l.kind == "type")
    assert "Big Wheel" in " ".join(copy_texts.split())       # filled from the new sheet
    # the dropped sheet's page: inside the hidden, red "[Deleted From Excel]" group, hidden and red too
    gone = next(t for t in psd if t.name == mc.GONE_GROUP)
    assert not gone.visible and gone._record.tagged_blocks.get_data(Tag.SHEET_COLOR_SETTING) == SheetColorType.RED
    inside = list(gone)
    assert inside and all(not g.visible for g in inside)
    assert all(g._record.tagged_blocks.get_data(Tag.SHEET_COLOR_SETTING) == SheetColorType.RED for g in inside)
    # the Layers panel tells what happened: new yellow, changed orange, unchanged green
    color = lambda t: t._record.tagged_blocks.get_data(Tag.SHEET_COLOR_SETTING)
    assert color(list(psd)[new]) == SheetColorType.YELLOW
    assert report["colors"]["green"] >= 1          # (the one changed page was kept as it was: green too)
    kept_page = next(t for t in psd if mc.page_id(t) == kept)
    assert color(kept_page) == SheetColorType.GREEN
    # the page the artist kept: as in the artist's file
    src_page = next(t for t in psd_reader.open_lazy(ARTIST) if mc.page_id(t) == kept)
    out_page = next(t for t in psd if mc.page_id(t) == kept)
    assert [str(l.text) for l in src_page.descendants() if l.kind == "type"] == \
           [str(l.text) for l in out_page.descendants() if l.kind == "type"]


@pytest.mark.skipif(not all(map(os.path.isfile, (ARTIST, NYL, CHANGED))), reason="reference PSD not here")
def test_rows_added_to_a_sheet_are_placed_and_overflow_onto_a_continued_page(tmp_path):
    from ps_autotypesetter.artist_design import psd_reader

    wb = load_workbook(CHANGED)
    ws = wb["Scattered_Symbols(denom1&2)"]
    last = max(r for r in range(1, ws.max_row + 1) if str(ws.cell(r, 2).value or "").strip())
    for k in range(6):                                   # six more rows like its last one, inside the sheet's box
        ws.cell(last + 1 + k, 2).value = ws.cell(last, 2).value
    excel_b = str(tmp_path / "rows.xlsx")
    wb.save(excel_b)

    out = str(tmp_path / "rows.psd")
    report = mc.clone(ARTIST, NYL, excel_b, out, icon_folder=os.path.join(REPO, "symbols"), pictures=False)
    added = [r for r in report["rows_added"] if r.get("row")]
    assert len(added) == 6 and all(r["status"] == "change" for r in added)
    assert not [r for r in report["new_rows"] if r["sheet"] == "Scattered_Symbols(denom1&2)"]
    assert report["untouched"]["differ"] == []
    names = [t.name for t in psd_reader.open_lazy(out)]
    assert any(n.startswith("Scattered_Symbols(denom1&2) (Continued)") for n in names)


def test_an_edit_made_in_the_preview_is_what_the_psd_gets(tmp_path, market_a):
    from psd_tools import PSDImage

    psd, excel_a = market_a
    excel_b = _book(tmp_path / "Game HHR.xlsx", {"Features": [
        ["FREE SPINS"], ["Four scatters award 12 free spins."], ["Wins are multiplied by the bet multiplier."]]})
    shown = mc.preview(psd, excel_a, excel_b, str(tmp_path / "preview"), draw=False)
    crop = shown["pages"][0]["crops"][0]
    assert crop["key"] and "Four scatters" in crop["text"]
    edited = "Four scatters award\r12 FREE spins."
    path, _box = mc.edit_crop(shown["_psd"], crop["key"], edited, crop["box"], str(tmp_path / "edits"))
    assert os.path.isfile(path)                                 # drawn again at once

    out = str(tmp_path / "Game HHR.psd")
    report = mc.clone(psd, excel_a, excel_b, out, pictures=False, edits={crop["key"]: edited})
    assert report["edits_applied"] == 1 and report["edits_lost"] == []
    texts = [str(l.text) for l in PSDImage.open(out).descendants() if l.kind == "type"]
    assert any(t.startswith("Four scatters award\r12 FREE spins.") for t in texts)


@pytest.mark.skipif(not all(map(os.path.isfile, (ARTIST, NYL, CHANGED))), reason="reference PSD not here")
def test_only_links_the_artist_chose_bind_what_the_dialog_showed_is_found_again():
    first = mc.check(ARTIST, NYL, CHANGED)
    pay = next(p for p in first["page_links"] if p["sheet"] == "Paytable")
    # a link the dialog only showed (saved with the others) never outranks what the Excel says now
    shown = mc.check(ARTIST, NYL, CHANGED, links={"pages": {pay["key"]: "Jackpots"}})
    assert next(p for p in shown["page_links"] if p["key"] == pay["key"])["sheet"] == "Paytable"
    # what the artist picked binds
    picked = mc.check(ARTIST, NYL, CHANGED, links={"chosen": {pay["key"]: "Jackpots"}})
    got = next(p for p in picked["page_links"] if p["key"] == pay["key"])
    assert got["sheet"] == "Jackpots" and got["chosen"]


def test_words_the_artist_already_typed_are_not_added_again():
    # JuCaiJin: the artist's PSD already had the new wording; the old Excel didn't
    head = "STICKY WILDS SYMBOL UPGRADES SUPER FEATURE continued"
    new, why = mc.word_diff(head, "STICKY WILDS SYMBOL UPGRADES FEATURE continued", head)
    assert (new, why) == (head, None)
    line = "One of the Minor Bonus letters and one of the Mini Bonus letter prizes may become multipliers"
    new, why = mc.word_diff(line, "One of Minor Bonus letter and one of Mini Bonus letter prizes may become multipliers",
                            line)
    assert new == line and "the the" not in new
    # only part of it typed already: the rest still changes, nothing doubles
    new, _ = mc.word_diff("Award 10 free spins now", "Award 10 spins", "Award 12 free spins")
    assert new == "Award 12 free spins now"


def test_pictures_are_named_from_abbreviated_layer_names():
    # JuCaiJin: the artist's layer names spell the tokens their own way
    from ps_autotypesetter.content_model import token_for_name

    toks = ["D", "G", "J", "JACK", "Grand_A", "Major_A", "Minor_I", "MINORx2 I", "Mini_I", "MINx2 I", "MINIx2 I",
            "9", "10", "BLUE TURTLE", "LANTERN"]
    assert token_for_name("EN_UHDL_ScatGold_Grd_A_00016", toks) == "Grand_A"
    assert token_for_name("EN_UHDL_ScatGold_Mjr_A_00016", toks) == "Major_A"
    assert token_for_name("EN_UHDL_ScatGold_Mnr_I_00016", toks) == "Minor_I"
    assert token_for_name("EN_UHDL_ScatGold_Mnr_I_X2_00016", toks) == "MINORx2 I"     # x2 must be in the token
    assert token_for_name("EN_UHDL_ScatGold_Mini_I_X2_00016", toks) == "MINIx2 I"     # exact parts beat MINx2
    assert token_for_name("EN_UHDL_ScatGold_Mjr_J_00016", toks) == "J"
    assert token_for_name("Jack", toks) == "JACK" and token_for_name("Nine", toks) == "9"
    assert token_for_name("BLUE TURTLE copy 2", toks) == "BLUE TURTLE"
    assert token_for_name("EN_UHDL_ScatGold_Blank_00016", toks) is None and token_for_name("Layer 1", toks) is None


def test_a_symbol_the_new_excel_adds_is_never_dropped():
    gap = mc._gap_of(12)
    assert gap == " " + " " * 10 + " "          # no-break inside: a wrapping line never splits it
    item = {"old": "JU CAI JIN GUI FEATURES are available during bought games only.", "_gap": gap}
    src = {"kind": "cell", "refs": [("Feature Trigger", 5, 2)]}
    mc._decide(item, src, ["JU CAI JIN GUI FEATURES are available during bought games only."],
               ["MY EDITED TEXT <LANTERN> ."])
    assert item["status"] == "change" and item["new"] == "MY EDITED TEXT" + gap + "."
    assert item["added_symbols"] == ["LANTERN"] and "<LANTERN>" in item["why"]
    assert item["gap_spans"] == [(14, 26)]
    # only the symbol added, the words the same: still noticed (text is compared without tokens)
    item = {"old": "Collect the coins.", "_gap": gap}
    mc._decide(item, src, ["Collect the coins."], ["Collect the <GOLD COIN> coins."])
    assert item["status"] == "change" and item["added_symbols"] == ["GOLD COIN"]
    # several lines (a row the artist broke, a column of cells): the gap goes where the symbol is,
    # the artist's line breaks kept; a symbol at a line's end needs no space after it
    item = {"old": "Line one\rLine two", "_gap": gap}
    mc._decide(item, {"kind": "row", "refs": [("S", 3)]}, ["Line one Line two"], ["Line one <X> Line two"])
    assert item["status"] == "change" and item["new"] == "Line one" + gap.rstrip(" ") + "\rLine two"
    item = {"old": "First row.\r\rSecond row.", "_gap": gap}
    mc._decide(item, {"kind": "cells", "refs": [("S", 3, 2), ("S", 5, 2)]}, ["First row.", "Second row."],
               ["First row.<X>", "Second <Y> row."])
    assert item["new"] == "First row." + gap.rstrip(" ") + "\r\rSecond" + gap + "row."
    assert item["added_symbols"] == ["X", "Y"] and len(item["gap_spans"]) == 2
    assert all(set(item["new"][a:b]) <= {" ", " "} for a, b in item["gap_spans"])
    # a symbol the old Excel had too isn't added again
    item = {"old": "Win" + gap + "coins.", "_gap": gap}
    mc._decide(item, src, ["Win <C> coins."], ["Win <C> coins <C>."])
    assert item["added_symbols"] == ["C"] and item["new"].count(gap.strip(" ")) == 2
    # wording the artist changed their own way: theirs, with the reason
    item = {"old": "Line one\rLine two", "_gap": gap}
    mc._decide(item, {"kind": "row", "refs": [("S", 3)]}, ["Other words here"], ["Other <X> words here"])
    assert item["status"] == "artist" and "<X>" in item["why"]


JCJ = r"E:\Work\ClaudeCode\DataForHelpScreenTool\JuCaiJin-4tHelp"
JCJ_FILES = (JCJ + r"\Working\Help.psd", JCJ + r"\HelpDocs\JCJG_Ingot_Art_GameRules_ATLS.xlsx",
             JCJ + r"\HelpDocs\HHR_10170428\JCJG_Art_GameRules_HHR-updated.xlsx")


JCJ_HHR = JCJ + r"\HelpDocs\HHR_10170428\JCJG_Art_GameRules_HHR.xlsx"


@pytest.mark.skipif(not all(map(os.path.isfile, JCJ_FILES + (JCJ_HHR,))), reason="JuCaiJin test files not here")
def test_icons_already_in_a_line_stay_in_their_gaps_when_a_symbol_is_added_to_it():
    # the updated AGR adds a lion mid-line ("appear the STICKY <LION_NEW> WILDS FEATURE"): the coin and
    # turtle on that line used to move by a shift worked out before the lion's gap was widened —
    # ending ~45 px off their gaps, over the text. All icons are now set from the final text.
    psd_path, _a, excel_b = JCJ_FILES
    links = {"symbols": {"so:Pic3.png": "LANTERN", "so:Pic1_New_frame.png": "LION_NEW"}}
    psd, plan = mc.prepare(psd_path, JCJ_HHR, excel_b, links=links)
    before = {l.name: l.bbox for l in next(p for p in psd if p.name.startswith("4_Feature Trigger")).descendants()}
    mc.apply(psd, plan)
    psd = mc.place_new_rows(psd, plan)
    psd = mc.place_symbols(psd, plan)
    page = next(p for p in psd if p.name.startswith("4_Feature Trigger"))
    pics = [l for l in page.descendants() if not l.is_group() and l.visible and l.kind in ("smartobject", "pixel")
            and l.height < 300]
    for t in (l for l in page.descendants() if l.kind == "type" and l.visible):
        text = str(t.text)
        spots, lines = mc._laid_out(t, text)
        for _n, a, b in mc._gaps(text.rstrip("\r")):
            x, y = mc._gap_spots(spots, lines, text, a, b)
            sitting = [p for p in pics if p.left < x < p.right and p.top < y < p.bottom]
            assert len(sitting) == 1, (t.name, text[max(0, a - 20):a])
            assert abs((sitting[0].left + sitting[0].right) / 2 - x) < 12      # centred in its gap
    # lines that didn't change keep their icons exactly where the artist put them
    assert before["GreenCoin"] == next(l for l in pics if l.name == "GreenCoin").bbox
    assert before["RED TURTLE"] == next(l for l in pics if l.name == "RED TURTLE").bbox


@pytest.mark.skipif(not all(map(os.path.isfile, JCJ_FILES + (JCJ_HHR,))), reason="JuCaiJin test files not here")
def test_an_added_symbol_keeps_one_size_and_its_lines_are_spaced_out_to_fit_it(tmp_path):
    # page 7's lanterns went into tightly set lines: they were shrunk to fit (each a different size)
    # and still covered the lines above and below. Now each is the page's icon size and the lines
    # it sits between are spaced out (their characters' leading), in the layer and in Photoshop's copy
    from psd_tools.constants import Tag

    psd_path, _a, excel_b = JCJ_FILES
    links = {"symbols": {"so:Pic3.png": "LANTERN", "so:Pic1_New_frame.png": "LION_NEW"}}
    psd, plan = mc.prepare(psd_path, JCJ_HHR, excel_b, links=links)
    plan["photoshop_redraw"] = False                  # Photoshop's copy kept, to check it below
    mc.apply(psd, plan)
    psd = mc.place_new_rows(psd, plan)
    psd = mc.place_symbols(psd, plan)
    page = next(p for p in psd if p.name.startswith("7_Feature Upgrade cont"))
    lanterns = [l for l in page.descendants() if l.name.startswith("Pic3") and l.visible]
    assert len(lanterns) == 4
    assert max(l.height for l in lanterns) - min(l.height for l in lanterns) <= 2      # one size
    texts = [l for l in page.descendants() if l.kind == "type" and l.visible]
    for pic in lanterns:
        cy = (pic.top + pic.bottom) / 2
        # on its own line — the lanterns of the lower blocks were placed before the blocks above them had
        # grown and rose further above their lines block by block
        on = [ln for t in texts if t.left < (pic.left + pic.right) / 2 < t.right + pic.width
              for ln in mc._laid_out(t, str(t.text))[1] if ln[2] and abs(ln[0] + ln[1] / 2 - cy) < ln[1] * 0.6]
        assert on, pic.bbox
        for t in texts:
            spots, lines = mc._laid_out(t, str(t.text))
            for top, size, n in lines:
                if n and not top <= cy <= top + size:                 # every other line of text: clear of it
                    assert pic.bottom <= top + 2 or pic.top >= top + 0.72 * size - 2 \
                        or pic.right < t.left or pic.left > t.right, (t.name, top)
    blk = psd._record.layer_and_mask_information.tagged_blocks.get_data(Tag.TEXT_ENGINE_DATA)
    spaced = 0
    for t in texts:
        sr = t.engine_dict["StyleRun"]
        lengths = [int(n) for n in sr["RunLengthArray"]]
        leads = [round(float(r["StyleSheet"]["StyleSheetData"].get("Leading", 0)), 2) for r in sr["RunArray"]]
        obj = blk["1"]["1"][int(t._record.tagged_blocks.get_data(Tag.TYPE_TOOL_OBJECT_SETTING).text_data[b"TextIndex"])]
        styles = list(obj["0"]["6"]["0"])
        assert [int(e["1"]) for e in styles] == lengths                 # Photoshop's copy in step
        if len(set(leads)) > 1:                                         # spaced out: both copies alike
            spaced += 1
            assert [round(float(e["0"]["0"]["6"]["5"]), 2) for e in styles] == leads
    assert spaced >= 3                                # the three paragraphs with a lantern in them
    # the working area: as far as the artist's content goes on any page (not the canvas, not the frame)
    left, top, right, bottom = plan["work_area"]
    assert 0 < left < right < psd.size[0] and 0 < top < bottom < psd.size[1]
    page6 = next(i for i in plan["items"] if i.get("source") == "Feature Upgrade!B17-B23")
    assert "below the area the artist keeps content in" in page6["why"]     # it now runs onto the frame
    out = tmp_path / "spaced.psd"
    mc.save(psd, str(out))
    from psd_tools import PSDImage

    assert PSDImage.open(str(out)).size == psd.size  # the file opens again


@pytest.mark.skipif(not all(map(os.path.isfile, JCJ_FILES + (JCJ_HHR,))), reason="JuCaiJin test files not here")
def test_a_symbol_taken_out_from_between_two_words_leaves_a_space_between_them(tmp_path):
    # "is shown as <OVERLAYx1> and": its picture hidden and the gap closed up read "is shown asand"
    wb = load_workbook(JCJ_HHR, data_only=True)
    ws = wb["Sticky Wilds Feature"]
    cell = next(c for row in ws.iter_rows() for c in row if isinstance(c.value, str) and "<OVERLAYx1> and" in c.value)
    cell.value = cell.value.replace(" <OVERLAYx1>", "", 1)
    excel_b = str(tmp_path / "b.xlsx")
    wb.save(excel_b)
    psd, plan = mc.prepare(JCJ_FILES[0], JCJ_HHR, excel_b)
    item = next(i for i in plan["items"] if i.get("why") == "symbol removed" and "Sticky Wilds" in i.get("source", ""))
    assert "shown as and" in " ".join(item["new"].split()) and "asand" not in item["new"]


DATA = r"E:\Work\ClaudeCode\DataForHelpScreenTool"
BUFFALO = (DATA + r"\Jactpot-carn-help\Working\Buffalo_Help.psd",
           DATA + r"\Jactpot-carn-help\JackpotCarnivalBuffalo_GameRules_NYL.xlsm")
SPOOKY_PSD = DATA + r"\Spooky\Spooky_Link HelpPSD.psd"


@pytest.mark.skipif(not all(map(os.path.isfile, BUFFALO)), reason="Buffalo test files not here")
def test_a_removed_sheet_marks_only_pages_clearly_its_own():
    # three Buffalo pages were tied to MYSTERY FEATURE by a couple of shared sentences ("Bet multiplier
    # is the same as…"); with the sheet gone they were all moved into [Deleted From Excel]
    from ps_autotypesetter.artist_design import psd_reader

    psd = psd_reader.open_lazy(BUFFALO[0])
    a = mc.read_workbook(BUFFALO[1])
    b = {k: v for k, v in a.items() if k != "MYSTERY FEATURE"}
    pages = mc.plan_pages(psd, mc.plan(psd, a, b), a, b, {})
    assert not [e for e in pages["removed"] if e["status"] == "mark"]
    check = next(e for e in pages["removed"] if e["status"] == "check")
    assert check["sheet"] == "MYSTERY FEATURE" and "delete them by hand" in check["why"]


@pytest.mark.skipif(not os.path.isfile(SPOOKY_PSD), reason="Spooky PSD not here")
def test_text_is_laid_out_as_photoshop_drew_the_artists_lines():
    # Spooky's letter-spaced Arial: laid out from its tracking alone, every line came out 4% narrower
    # than Photoshop's (icons over the words once redrawn) and a wrapped paragraph a line short
    from ps_autotypesetter.artist_design import psd_reader

    psd = psd_reader.open_lazy(SPOOKY_PSD)
    page = next(t for t in psd if t.name.strip().startswith("Cash Collect feature Cont_Page01"))
    t = next(l for l in page.descendants() if l.kind == "type" and len(str(l.text)) > 80)
    text = str(t.text)
    spots, lines = mc._laid_out(t, text)
    ours = [(min(spots[i][0] for i in spots if spots[i][2] == n and text[i] not in " \u00a0"),
             max(spots[i][0] + spots[i][1] for i in spots if spots[i][2] == n and text[i] not in " \u00a0"))
            for n, ln in enumerate(lines) if ln[2]]
    for (a, b), (c, d) in zip(ours, mc._ink_lines(t)):
        assert abs(a - c) < 6 and abs(b - d) < 6
    spins = next(x for x in psd if x.name.strip().startswith("MO' SPINS FEATURE_Page05"))
    para = next(l for l in spins.descendants() if l.kind == "type" and len(str(l.text)) > 80)
    _spots, lines = mc._laid_out(para, str(para.text))
    assert len([x for x in lines if x[2]]) == len(mc._ink_lines(para))      # wrapped where Photoshop did


SPOOKY_AGR = DATA + r"\Spooky\SpookyLink_MoMummy_AGR_NYL.xlsm"


@pytest.mark.skipif(not all(map(os.path.isfile, (SPOOKY_PSD, SPOOKY_AGR))), reason="Spooky files not here")
def test_icons_follow_their_words_when_a_removed_symbol_rewraps_the_paragraph(tmp_path):
    # Mo' Spins: a symbol taken out of a wrapped paragraph made it wrap differently ("awarded." came
    # back up a line); the icons after it were only shifted sideways and ended up over the words
    wb = load_workbook(SPOOKY_AGR, data_only=True, keep_vba=True)
    ws = wb["Mo'Spins"]
    cell = next(c for row in ws.iter_rows() for c in row
                if isinstance(c.value, str) and "<Feature Mummy 3x3>" in c.value and "Once 4" in c.value)
    cell.value = " ".join(cell.value.replace("<Feature Mummy 3x3>", " ", 1).split())
    excel_b = str(tmp_path / "b.xlsm")
    wb.save(excel_b)
    psd, plan = mc.prepare(SPOOKY_PSD, SPOOKY_AGR, excel_b)
    edit = next(e for e in plan["icon_edits"] if e.get("status") == "change" and "Mo'Spins" in e.get("source", ""))
    assert edit["hide"] and any(len(m) > 2 and m[2] < 0 for m in edit["move"])      # icons below moved up a line
    item = next(i for i in plan["items"] if i.get("why") == "symbol removed" and "Mo'Spins" in i.get("source", ""))
    mc.apply(psd, plan)
    layer = next(l for l in psd.descendants() if l.layer_id == item["layer_id"])
    text = str(layer.text)
    spots, lines = mc._laid_out(layer, text)
    pics = [l for l in psd.descendants() if l.visible and not l.is_group() and l.kind in ("smartobject", "pixel")
            and layer.left - 20 < (l.left + l.right) / 2 < layer.right + 20 and layer.top - 60 < (l.top + l.bottom) / 2 < layer.bottom + 60]
    for _n, a, b in mc._gaps(text.rstrip("\r")):
        x, y = mc._gap_spots(spots, lines, text, a, b)
        assert any(p.left < x < p.right and p.top < y < p.bottom for p in pics), text[max(0, a - 20):a]


HUNT = (DATA + r"\Hunt-Nept\Working\Help.psb", DATA + r"\Hunt-Nept\HFNG_Baron_Rules.xlsx")
MIDNIGHT_PSD = DATA + r"\MidnightExp-Help\Working\Helpscreen.psd"


@pytest.mark.skipif(not all(map(os.path.isfile, HUNT + (MIDNIGHT_PSD, JCJ_FILES[0]))), reason="test PSDs not here")
def test_pages_inside_a_group_of_pages_are_pages():
    # Hunt keeps every page in "Group 1", Midnight Express one group per game (K2: its Paytable, Game
    # Rules, Train Prizes…): each such group was taken for one page, so most edits never landed
    from ps_autotypesetter.artist_design import psd_reader, psd_render

    hunt = psd_reader.open_lazy(HUNT[0])
    names = [t.name for t in psd_render.page_tops(hunt)]
    assert "Group 1" not in names and {"BingoRules", "Game_Rules", "Page1.png", "Page2.png"} <= set(names)
    midnight = psd_reader.open_lazy(MIDNIGHT_PSD)
    tops = psd_render.page_tops(midnight)
    k2 = [t for t in tops if psd_render.holder_of(midnight, t) is not None and psd_render.holder_of(midnight, t).name == "K2"]
    assert {"Paytable", "Game Rules $1", "TRAIN PRIZES 1c 2c"} <= {t.name for t in k2}
    assert not any(t.name in ("K2-BG", "SYMBOLS", "K2 LOGO") for t in k2)       # the game's shared look
    jcj = psd_reader.open_lazy(JCJ_FILES[0])
    assert [t.name for t in psd_render.page_tops(jcj)] == [t.name for t in jcj]  # pages already top-level
    # a removed sheet marks its own page inside the group, not the whole group
    a = mc.read_workbook(HUNT[1])
    b = {k: v for k, v in a.items() if k != "Bingo Rules"}
    pages = mc.plan_pages(hunt, mc.plan(hunt, a, b), a, b, {})
    marked = [p for e in pages["removed"] if e["status"] == "mark" for p in e["pages"]]
    assert marked == ["BingoRules"]
    # a page drawn on its own: over its group's backdrop
    page = next(t for t in k2 if t.name == "Paytable")
    img = psd_render.render_page(midnight, page, (0, 0, 400, 300))
    assert img.getbbox() is not None


def test_a_pages_continued_page_is_found_by_its_name():
    assert mc._page_base("6_Feature Upgrade") == mc._page_base("7_Feature Upgrade cont") == "feature upgrade"
    assert mc._page_base("23_Sticky Jackpot Feature con 1-10") == "sticky jackpot feature 1-10"
    assert mc._page_base("Bonus (Continued)") == mc._page_base("Bonus Continued") == mc._page_base("Bonus") == "bonus"


@pytest.mark.skipif(not all(map(os.path.isfile, JCJ_FILES + (JCJ_HHR,))), reason="JuCaiJin test files not here")
def test_what_runs_past_the_working_area_flows_onto_the_continued_page(tmp_path):
    # the lanterns' spaced-out lines pushed page 6 past the bottom of the area the artist keeps content
    # in: its last section goes onto the artist's own continued page (7), at the top of its content;
    # page 7 then runs over in turn and, having no continued page of its own, gets a new one
    from ps_autotypesetter.artist_design import psd_reader

    psd_path, _a, excel_b = JCJ_FILES
    src = psd_reader.open_lazy(psd_path)
    names = [t.name for t in src]
    assert mc.continued_page(src, names.index("6_Feature Upgrade")) == names.index("7_Feature Upgrade cont")
    assert mc.continued_page(src, names.index("7_Feature Upgrade cont")) is None
    links = {"symbols": {"so:Pic3.png": "LANTERN", "so:Pic1_New_frame.png": "LION_NEW"}}
    psd, plan = mc.prepare(psd_path, JCJ_HHR, excel_b, links=links)
    mc.apply(psd, plan)
    psd = mc.place_new_rows(psd, plan)
    psd = mc.place_symbols(psd, plan)
    psd = mc.reflow_pages(psd, plan)
    bottom = plan["work_area"][3]
    pages = {mc._clean_name(t.name): t for t in psd}
    for name in ("6_Feature Upgrade", "7_Feature Upgrade cont"):
        assert max(l.bottom for l in mc._page_content(pages[name], psd.size[1])) <= bottom + 4, name
    new = next(n for n in pages if n.startswith("7_Feature Upgrade cont 2"))
    assert mc._page_content(pages[new], psd.size[1])
    moved = next(i for i in plan["items"] if i.get("source") == "Feature Upgrade!B17-B23")
    assert moved["page"] == "7_Feature Upgrade cont" and "moved onto" in moved["why"]
    assert "move what doesn't fit" not in moved["why"]
    # the section sits at the top of page 7's content, under its heading, page 7's own content under it
    p7 = mc._row_bands(mc._page_content(pages["7_Feature Upgrade cont"], psd.size[1]))
    assert any("SYMBOL UPGRADES FEATURE" == str(l.text).strip() for l in p7[1]["layers"] if l.kind == "type")
    out = tmp_path / "flowed.psd"
    mc.save(psd, str(out))
    assert len(list(psd_reader.open_lazy(str(out)))) == len(list(psd))


@pytest.mark.skipif(not all(map(os.path.isfile, JCJ_FILES)), reason="JuCaiJin test files not here")
def test_text_is_laid_out_with_the_layers_horizontal_scale():
    # JuCaiJin's text is set at 80% width: laid out unscaled, every redrawn line ran 25% wider than
    # Photoshop's (past the frame) and added symbols were placed against the wrong lines
    from ps_autotypesetter.artist_design import psd_reader

    psd = psd_reader.open_lazy(JCJ_FILES[0])
    page = next(p for p in psd if p.name.startswith("6_Feature Upgrade"))
    t = next(l for l in page.descendants() if l.kind == "type" and str(l.text).startswith("During any spin"))
    assert mc._scales(t) == (0.8, 0.95)
    spots, lines = mc._laid_out(t, str(t.text))
    assert len(lines) == 4                            # wrapped in its box as Photoshop wraps it
    left, right = min(s[0] for s in spots.values()), max(s[0] + s[1] for s in spots.values())
    assert abs(left - t.left) < 15 and abs(right - t.right) < 30


@pytest.mark.skipif(not all(map(os.path.isfile, JCJ_FILES)), reason="JuCaiJin test files not here")
def test_a_symbol_the_new_excel_adds_gets_its_picture_sized_like_the_pages_icons():
    psd_path, excel_a, excel_b = JCJ_FILES
    # the paytable's lantern picture is named <LANTERN> in the clone dialog (the artist's link)
    psd, plan = mc.prepare(psd_path, excel_a, excel_b, links={"symbols": {"so:Pic3.png": "LANTERN"}})
    page = next(p for p in psd if p.name.startswith("4_Feature Trigger"))
    ratio, _offset = mc.page_icons(page)                # the coins: about 3.3 x the line's font size
    assert 2.5 < ratio < 4.0
    mc.apply(psd, plan)
    psd = mc.place_new_rows(psd, plan)
    psd = mc.place_symbols(psd, plan)
    page = next(p for p in psd if p.name.startswith("4_Feature Trigger"))
    text = next(l for l in page.descendants() if l.kind == "type" and "MY EDITED TEXT" in l.text)
    lanterns = [l for l in page.descendants() if l.name.startswith("Pic3")]
    assert all(l.visible for l in lanterns)
    pic = next(l for l in lanterns if l.top < (text.top + text.bottom) / 2 < l.bottom)   # on the line
    assert text.left < (pic.left + pic.right) / 2 < text.right                 # in the line, in its gap
    assert 100 < pic.height < 160                                             # like the coins (108-138)
    item = next(i for i in plan["items"] if "MY EDITED TEXT" in (i.get("new") or ""))
    assert "picture was put in the gap" in item["why"]
    # the new Excel also ends three of the paragraphs below with a lantern: one picture after each
    para = next(i for i in plan["items"] if i.get("source") == "Feature Trigger!B10-B16")
    assert para["added_symbols"].count("LANTERN") == 3 and "pictures were put in the gaps" in para["why"]
    assert len(lanterns) == 4


def test_edited_text_asks_photoshop_to_update_it_on_open(tmp_path):
    # the preview pixels of changed text are only ours (the artist's font may not be where Python looks):
    # without the document text block Photoshop asks "Some text layers might need to be updated…"
    from psd_tools.constants import Tag

    from ps_autotypesetter.artist_design import psd_reader

    if not os.path.isfile(ARTIST):
        pytest.skip("artist PSD not here")
    out = str(tmp_path / "redraw.psd")
    report = mc.clone(ARTIST, NYL, CHANGED, out, icon_folder=os.path.join(REPO, "symbols"), pictures=False)
    assert report["text_engine"] == "redraw"
    dst = psd_reader.open_lazy(out)
    assert dst._record.layer_and_mask_information.tagged_blocks.get_data(Tag.TEXT_ENGINE_DATA) is None
    assert any(l.kind == "type" for l in dst.descendants())        # every text layer still there, with its own text
