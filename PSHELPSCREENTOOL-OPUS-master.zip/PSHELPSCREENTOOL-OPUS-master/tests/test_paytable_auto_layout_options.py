"""Auto-layout placement options: the pay/value centering fix, end to end.

The layout generator stamps a ``vertical_align`` hint on each pay/value slot
box (``center`` when they sit beside the icon, ``top`` when below it); the
automapper's :func:`engine_api._slot_valign` reads that hint back into every
pay/value mapping spec, so the renderer centers or top-aligns them without any
render-core change. These tests cover the hint helper in isolation, the
placement-driven template the generator produces, and the generate -> auto-map
flow that ``auto_map_page`` runs internally (exercised here without the config
persistence so the suite stays hermetic).
"""

import os

import pytest

from ps_autotypesetter.ui_web import engine_api

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXAMPLE_XLSX = os.path.join(REPO_ROOT, "examples", "paytable.xlsx")

requires_example = pytest.mark.skipif(
    not os.path.isfile(EXAMPLE_XLSX),
    reason="examples/paytable.xlsx fixture is required",
)


# --- _slot_valign: the hint reader -----------------------------------------

def test_slot_valign_honors_hint():
    assert engine_api._slot_valign({"vertical_align": "center"}) == "center"
    assert engine_api._slot_valign({"vertical_align": "bottom"}) == "bottom"


def test_slot_valign_normalizes_hint():
    # trimmed + case-folded so "  Center " and "CENTER" are the same hint.
    assert engine_api._slot_valign({"vertical_align": "  Center "}) == "center"
    assert engine_api._slot_valign({"vertical_align": "TOP"}) == "top"


def test_slot_valign_falls_back_to_default():
    # plain {x,y,w,h} boxes (hand-authored templates) keep the default.
    assert engine_api._slot_valign({"x": 0, "y": 0, "w": 10, "h": 10}) == "top"
    assert engine_api._slot_valign({"vertical_align": ""}) == "top"  # blank ignored
    assert engine_api._slot_valign(None) == "top"
    assert engine_api._slot_valign({}, default="bottom") == "bottom"


# --- _auto_paytable_template: placement -> stamped hint --------------------

def _pay_value_valigns(template):
    slots = template["slots"]
    return {v.get("vertical_align")
            for k, v in slots.items()
            if k.endswith(".pay") or k.endswith(".value")
            or k in ("@slot.wildpay", "@slot.wildvalue")}


@requires_example
def test_auto_template_right_centers():
    tpl = engine_api._auto_paytable_template(EXAMPLE_XLSX, "Paytable", {"placement": "right"})
    assert _pay_value_valigns(tpl) == {"center"}
    assert tpl["mapper_meta"]["placement"] == "right"


@requires_example
def test_auto_template_below_top_aligns():
    tpl = engine_api._auto_paytable_template(EXAMPLE_XLSX, "Paytable", {"placement": "below"})
    assert _pay_value_valigns(tpl) == {"top"}
    assert tpl["mapper_meta"]["placement"] == "below"


@requires_example
def test_auto_template_left_centers():
    tpl = engine_api._auto_paytable_template(EXAMPLE_XLSX, "Paytable", {"placement": "left"})
    assert _pay_value_valigns(tpl) == {"center"}


@requires_example
def test_auto_template_default_and_garbage_placement_center():
    # no options -> right (center); an unknown placement is sanitized to right.
    assert _pay_value_valigns(engine_api._auto_paytable_template(EXAMPLE_XLSX, "Paytable")) == {"center"}
    bad = engine_api._auto_paytable_template(EXAMPLE_XLSX, "Paytable", {"placement": "sideways"})
    assert _pay_value_valigns(bad) == {"center"}
    assert bad["mapper_meta"]["placement"] == "right"


@requires_example
def test_auto_template_grid_options_recorded_and_fit():
    tpl = engine_api._auto_paytable_template(
        EXAMPLE_XLSX, "Paytable", {"placement": "right", "rows": 3, "cols": 4})
    meta = tpl["mapper_meta"]
    assert meta["rows"] == 3 and meta["cols"] == 4
    # the example sheet's 10 symbols all keep an icon slot (grid never drops one).
    icons = [k for k in tpl["slots"]
             if k.startswith("@slot.") and "." not in k[len("@slot."):]
             and k not in ("@slot.title", "@slot.text")]
    assert len(icons) == 10


# --- generate -> auto-map: the mapping specs carry the hint ----------------
# This is exactly what auto_map_page does between generation and save; asserting
# it here (without the save) keeps the coverage hermetic.

def _pay_value_mapping_valigns(template):
    automap = engine_api.automap_paytable_slots(template, EXAMPLE_XLSX, "Paytable")
    return {m.get("vertical_align")
            for m in automap["mappings"]
            if m.get("role") in ("pay", "value")}


@requires_example
def test_mapping_right_places_centered_pay_value():
    tpl = engine_api._auto_paytable_template(EXAMPLE_XLSX, "Paytable", {"placement": "right"})
    valigns = _pay_value_mapping_valigns(tpl)
    assert valigns == {"center"}


@requires_example
def test_mapping_below_places_top_aligned_pay_value():
    tpl = engine_api._auto_paytable_template(EXAMPLE_XLSX, "Paytable", {"placement": "below"})
    valigns = _pay_value_mapping_valigns(tpl)
    assert valigns == {"top"}


@requires_example
def test_mapping_hand_authored_box_stays_top():
    # a plain {x,y,w,h} slot (no hint) must still map pay/value top-aligned.
    template = {
        "canvas": {"width": 1920, "height": 1080},
        "slot_prefix": "@slot",
        "slots": {
            "@slot.pic1": {"x": 100, "y": 100, "w": 120, "h": 120},
            "@slot.pic1.pay": {"x": 240, "y": 100, "w": 120, "h": 60},
            "@slot.pic1.value": {"x": 240, "y": 160, "w": 120, "h": 60},
        },
    }
    automap = engine_api.automap_paytable_slots(template, EXAMPLE_XLSX, "Paytable")
    pv = [m for m in automap["mappings"] if m.get("role") in ("pay", "value")]
    assert pv, "expected pic1 pay/value to map"
    assert all(m["vertical_align"] == "top" for m in pv)
