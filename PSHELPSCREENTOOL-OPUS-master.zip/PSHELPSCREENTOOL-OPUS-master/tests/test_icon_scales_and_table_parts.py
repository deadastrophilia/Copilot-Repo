"""Icons sized in Assets & Icons (icon_scales) and cut-table parts sharing a page (png_builder)."""
from PIL import Image

from ps_autotypesetter import icon_scales, png_builder, text_edits
from ps_autotypesetter.icon_mapping import normalize_token, resolve_icon_path


def test_apply_tags_one_copy_and_whole_sheet():
    icon_scales.set_all({"Page": {"WILD": 140, "WILD@row:3#1": 80, "BO": 100}})
    try:
        assert icon_scales.apply("Page", "row:3", "a <WILD> b <WILD> c <Wild> <BO>") == \
            "a <WILD~140> b <WILD~80> c <Wild~140> <BO>"
        assert icon_scales.apply("Other", "row:3", "<WILD>") == "<WILD>"
        assert icon_scales.split("WILD~140") == ("WILD", 1.4)
        assert icon_scales.split("WILD") == ("WILD", 1.0)
        assert icon_scales.compact("Wild 2x~50") == "WILD2X"
    finally:
        icon_scales.set_all({})


def test_project_size_reaches_every_sheet_and_the_closest_size_wins():
    icon_scales.set_all({"*": {"WILD": 120, "BONUS": 90}, "Page": {"WILD": 140, "BONUS@row:3#0": 60}})
    try:
        assert icon_scales.apply("Other", "row:3", "<WILD> <BONUS>") == "<WILD~120> <BONUS~90>"      # the project's
        assert icon_scales.apply("Page", "row:3", "<WILD> <BONUS> <BONUS>") == \
            "<WILD~140> <BONUS~60> <BONUS~90>"                                                    # sheet, one icon, project
    finally:
        icon_scales.set_all({})


def test_tagged_token_finds_its_picture_and_is_scaled(tmp_path):
    Image.new("RGBA", (40, 20), (255, 0, 0, 255)).save(tmp_path / "WILD.png")
    assert normalize_token("<WILD~140>") == normalize_token("WILD")
    assert resolve_icon_path("WILD~140", str(tmp_path), {}) == resolve_icon_path("WILD", str(tmp_path), {})
    plain, _ = png_builder._load_icon_uncached(Image, "WILD", str(tmp_path), {}, 50)
    big, _ = png_builder._load_icon_uncached(Image, "WILD~140", str(tmp_path), {}, 50)
    assert plain.size == (100, 50)
    assert big.size == (140, 70)


def test_text_edit_ignores_size_tags():
    text_edits.set_all({"P": {"row:3": {"from": "x <WILD~140> y", "to": "x <WILD~140>\ny"}}})
    try:
        assert text_edits.apply("P", "row:3", "x <WILD> y") == "x <WILD>\ny"
    finally:
        text_edits.set_all({})


def test_cut_parts_side_by_side_when_they_fit_else_stacked():
    spots, h = png_builder._table_part_block([300, 200], 400, 100, 1000, 30)
    total = 2 * 400 + png_builder.TABLE_PART_SIDE_GAP
    start = (1000 - total) / 2
    assert spots == [(round(start - 100), 0), (round(start + 400 + png_builder.TABLE_PART_SIDE_GAP - 100), 0)]
    assert h == 300
    spots, h = png_builder._table_part_block([300, 200], 600, 100, 1000, 30)
    assert spots == [(0, 0), (0, 330)]
    assert h == 530


def test_part_pages_read_from_table_style():
    ts = {"split_pages": {"k": {"1": 1, "0": -1, "2": 0, "x": 1}}}
    assert png_builder._table_part_pages(ts, {"design_key": "k"}) == {1: 1, 0: -1}
    assert png_builder._table_part_pages({}, {"design_key": "k"}) == {}


def test_strip_can_be_thinner_than_the_text_down_to_zero():
    from ps_autotypesetter import text_styles

    assert text_styles.strip_geometry({"pad_y": -10}, 0, 100, 500, 40)[1:] == (110.0, 548.0, 20.0)
    assert text_styles.strip_geometry({"pad_y": -30}, 0, 100, 500, 40)[3] == 0.0


def test_strip_still_matches_a_row_whose_icon_was_sized():
    from ps_autotypesetter import text_styles

    sized, plain = "with one or more <Green Bag~158> awards", "with one or more <Green Bag> awards"
    assert text_styles._row_key(sized) == text_styles._row_key(plain)


def test_row_roles_and_continued_look():
    from ps_autotypesetter import row_roles

    row_roles.set_all({"row_roles": {"P": {"row:4": "subheading", "row:5": "heading", "row:6": "bogus"}},
                       "subheading_size": 36, "continued_size": 26, "continued_font_style": "bold",
                       "continued_rgb": "#FFD23A"})
    try:
        assert (row_roles.role("P", 4), row_roles.role("P", 5), row_roles.role("P", 6)) == ("subheading", "heading", "")
        name, size, rgb, icon_h = row_roles.subheading_look("Arial", 50, "#FF0000", 100)
        assert (name, size, icon_h) == ("Arial", 36, 100)
        look = row_roles.continued_look("Arial", 50, (255, 255, 255))
        assert (look["size"], look["bold"], tuple(look["rgb"])) == (26, True, (255, 210, 58))
        row_roles.set_all({})
        assert row_roles.continued_look("Arial", 50, (1, 2, 3))["size"] == 19
    finally:
        row_roles.set_all({})


def test_heading_icons_and_body_icons_are_sized_apart():
    from ps_autotypesetter import icon_scales

    icon_scales.set_all({"P": {"WILD": 140, "H:COIN": 60}, "*": {"H:WILD": 80, "COIN": 120}})
    try:
        body, head = "a <WILD> b <COIN>", "<WILD> TITLE <COIN>"
        assert icon_scales.apply("P", "row:5", body) == "a <WILD~140> b <COIN~120>"
        assert icon_scales.apply("P", "row:1", head, role="heading") == "<WILD~80> TITLE <COIN~60>"
        icon_scales.set_all({"P": {"WILD": 140, "WILD@row:1#0": 70}})      # one heading icon sized before "H:" keys
        assert icon_scales.apply("P", "row:1", head, role="heading") == "<WILD~70> TITLE <COIN>"
    finally:
        icon_scales.set_all({})
