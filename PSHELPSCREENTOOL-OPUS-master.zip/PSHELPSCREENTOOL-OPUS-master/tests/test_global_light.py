"""The project's Global Light (global_light.py): "Use Global Light" shadows / bevels are drawn at the
document's angle by both preview engines, built PSDs carry it (resources 1037 / 1049), imports read it."""

import json
import os
import shutil
import struct
import subprocess

import numpy as np
import pytest
from openpyxl import Workbook

from ps_autotypesetter import fx_verify, global_light, ps_fx_png

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
JS_ENGINE = os.path.join(ROOT, "ps_autotypesetter", "ui_web", "static", "ps_fx_canvas.js")

PARAMS = {
    "drop_shadow": [{"enabled": True, "angle": 90, "use_global_light": True, "distance": 8, "size": 3},
                    {"enabled": True, "angle": 45, "use_global_light": False, "distance": 4, "size": 2}],
    "inner_shadow": {"enabled": True, "angle": 90, "use_global_light": True, "distance": 3, "size": 2},
    "bevel": {"enabled": True, "angle": 90, "altitude": 40, "use_global_light": True, "size": 4},
    "stroke": {"enabled": True, "size": 2},
}


@pytest.fixture(autouse=True)
def _no_light():
    global_light.set_all({})
    yield
    global_light.set_all({})


def test_apply_moves_only_global_light_effects_and_is_idempotent():
    out = global_light.apply(PARAMS, {"angle": 30, "altitude": 20})
    assert [e["angle"] for e in out["drop_shadow"]] == [30, 45]          # the own-angle shadow keeps 45
    assert out["inner_shadow"]["angle"] == 30
    assert (out["bevel"]["angle"], out["bevel"]["altitude"]) == (30, 20)
    assert out["stroke"] is PARAMS["stroke"]
    assert PARAMS["drop_shadow"][0]["angle"] == 90                         # a copy: the style is untouched
    assert global_light.apply(out, {"angle": 30, "altitude": 20}) == out


def test_no_light_leaves_every_preview_as_it_was():
    assert global_light.apply(PARAMS) is PARAMS
    assert ps_fx_png.normalize_params(PARAMS) == ps_fx_png.normalize_params(json.loads(json.dumps(PARAMS)))
    global_light.set_all({"fx_global_light": {"angle": 120}})
    lit = ps_fx_png.normalize_params(PARAMS)
    assert [s["angle"] for s in lit["drop_shadows"]] == [120, 45] and lit["bevels"][0]["altitude"] == 30


def test_the_light_turns_the_drawn_shadow():
    content = np.zeros((60, 60, 4), np.float32)
    content[20:40, 20:40] = (1, 1, 1, 1)
    style = {"drop_shadow": {"enabled": True, "color": [255, 0, 0], "angle": 90, "use_global_light": True,
                             "distance": 10, "size": 0, "opacity": 100}}

    def shadow_x():
        out = ps_fx_png.render_effects(content, style)
        red = (out[..., 0] > 0.5) & (out[..., 1] < 0.2) & (out[..., 3] > 0.5)
        return np.nonzero(red)[1].mean()

    straight_down = shadow_x()
    global_light.set_all({"fx_global_light": {"angle": 0}})               # light from the right: shadow to the left
    assert shadow_x() < straight_down - 5


def test_clean_and_for_document():
    assert global_light.clean({"angle": 450}) == {"angle": 90.0, "altitude": 30.0}
    assert global_light.clean({"angle": ""}) is None and global_light.clean(None) is None
    assert global_light.for_document({"fx_global_light": {"angle": 96, "altitude": 26}}) == {"angle": 96.0, "altitude": 26.0}
    lib = {"a": {"captured_params": {"drop_shadow": {"enabled": True, "angle": 90, "use_global_light": True}}},
           "b": {"captured_params": {"drop_shadow": {"enabled": True, "angle": 90, "use_global_light": True}}},
           "c": {"captured_params": {"drop_shadow": {"enabled": True, "angle": 30, "use_global_light": True}}},
           "d": {"captured_params": {"drop_shadow": {"enabled": True, "angle": 10}}}}
    assert global_light.for_document({"layer_style_library": lib})["angle"] == 90
    assert global_light.for_document({"layer_style_library": {"d": lib["d"]}}) is None


def _psd_header(resources):
    body = b""
    for rid, value in resources.items():
        body += b"8BIM" + struct.pack(">H", rid) + b"\x00\x00" + struct.pack(">I", 4) + struct.pack(">i", value)
    return b"8BPS" + b"\x00" * 22 + struct.pack(">I", 0) + struct.pack(">I", len(body)) + body + b"\x00" * 16


def test_read_psd_from_the_header(tmp_path):
    p = tmp_path / "a.psd"
    p.write_bytes(_psd_header({1037: 96, 1049: 26}))
    assert global_light.read_psd(str(p)) == {"angle": 96.0, "altitude": 26.0}
    p.write_bytes(_psd_header({}))
    assert global_light.read_psd(str(p)) == global_light.PSD_DEFAULT                # what Photoshop assumes
    p.write_bytes(b"not a psd")
    assert global_light.read_psd(str(p)) is None


def test_verify_sets_the_documents_light():
    assert "pshSetGlobalLight(lightAngle, lightAltitude)" in fx_verify._RENDER_JSX
    assert 'charIDToTypeID("gblA")' in fx_verify.GLOBAL_LIGHT_JSX and "globalAltitude" in fx_verify.GLOBAL_LIGHT_JSX
    style = {"captured_params": {"drop_shadow": {"enabled": True, "angle": 90, "use_global_light": True}}}
    assert fx_verify.verify_light(style)["angle"] == 90
    global_light.set_all({"fx_global_light": {"angle": 30}})
    assert fx_verify.verify_light(style)["angle"] == 30


def test_reference_psd_import_brings_the_light(tmp_path):
    from ps_autotypesetter import psd_style_import

    out = psd_style_import.apply({}, [{"key": "ds.fx_global_light", "value": [96, 26], "apply": True}])
    assert out["dynamic_settings"]["fx_global_light"] == {"angle": 96.0, "altitude": 26.0}
    assert "fx_global_light" not in psd_style_import.apply({}, [{"key": "ds.fx_global_light", "value": ["x"], "apply": True}]).get("dynamic_settings", {})


def test_built_psd_carries_the_light(tmp_path):
    pytest.importorskip("photoshopapi")
    from ps_autotypesetter.psd_writer import build as psd_build
    from ps_autotypesetter.ui_web import engine_api

    wb = Workbook()
    wb.active.title = "Features"
    wb.active.append(["FEATURES"])
    wb.active.append(["A plain line of text."])
    excel = str(tmp_path / "a.xlsx")
    wb.save(excel)
    cfg = {"excel_path": excel, "icon_folder": "", "bg_path": "", "bg_source": "color", "bg_color": "#102040",
           "output_dir": str(tmp_path / "out"), "output_name": "Out", "render_all_pages": True,
           "c_width": 640, "c_height": 360, "dynamic_settings": {"fx_global_light": {"angle": 96, "altitude": 26}}}
    path = psd_build.build_psd(**engine_api._build_kwargs(cfg), output_format="PSD")
    assert path and global_light.read_psd(path) == {"angle": 96.0, "altitude": 26.0}


@pytest.mark.skipif(shutil.which("node") is None, reason="node not installed")
def test_js_engine_draws_the_same_light(tmp_path):
    content = np.zeros((48, 48, 4), np.float32)
    content[14:34, 14:34] = (0.9, 0.8, 0.2, 1)
    content.tofile(tmp_path / "content.f32")
    light = {"angle": 20, "altitude": 50}
    (tmp_path / "case.json").write_text(json.dumps({"w": 48, "h": 48, "params": PARAMS, "light": light}))
    script = tmp_path / "run.js"
    script.write_text(
        "const fs=require('fs');const PsFx=require(" + json.dumps(JS_ENGINE) + ");"
        "const d=" + json.dumps(str(tmp_path)) + ";const c=JSON.parse(fs.readFileSync(d+'/case.json'));"
        "const b=fs.readFileSync(d+'/content.f32');const content=new Float32Array(b.buffer,b.byteOffset,b.length/4);"
        "PsFx.setGlobalLight(c.light);const o=PsFx.renderEffects(content,c.w,c.h,c.params,null,null);"
        "fs.writeFileSync(d+'/js.f32',Buffer.from(o.buffer));"
        "fs.writeFileSync(d+'/n.json',JSON.stringify(PsFx.normalize(c.params).drop_shadows.map(s=>s.angle)));"
    )
    subprocess.run(["node", str(script)], check=True, capture_output=True, timeout=60)
    global_light.set_all({"fx_global_light": light})
    py = ps_fx_png.render_effects(content, PARAMS)
    js = np.fromfile(tmp_path / "js.f32", dtype=np.float32).reshape(py.shape)
    assert float(np.abs(js - py).max()) < 1e-3
    assert json.loads((tmp_path / "n.json").read_text()) == [20, 45]


def test_photoshops_light_is_read_with_the_altitude_from_the_saved_file(tmp_path, monkeypatch):
    # Photoshop 27 reports the document's angle (gblA) but not its altitude: that comes from the file
    from ps_autotypesetter import photoshop_bridge
    from ps_autotypesetter.ui_web import ps_actions

    p = tmp_path / "Help.psd"
    p.write_bytes(_psd_header({1037: 96, 1049: 26}))
    monkeypatch.setattr(photoshop_bridge, "run_jsx", lambda jsx, *a, **k: f"96,,{p}")
    assert ps_actions.document_global_light() == {"angle": 96.0, "altitude": 26.0}
    monkeypatch.setattr(photoshop_bridge, "run_jsx", lambda jsx, *a, **k: "120,,")        # an unsaved document
    assert ps_actions.document_global_light() == {"angle": 120.0, "altitude": 30.0}
    monkeypatch.setattr(photoshop_bridge, "run_jsx", lambda jsx, *a, **k: "")              # no document
    assert ps_actions.document_global_light() is None


def test_every_copied_style_brings_its_documents_light(tmp_path, monkeypatch):
    # the angle is never typed in: each copy from Photoshop takes the document's Global Light (a project that
    # already had one gets the new one, and the reply says it changed)
    from ps_autotypesetter.ui_web import ps_actions
    from ps_autotypesetter.ui_web.server import create_app

    client = create_app(session_file=str(tmp_path / "session.json")).test_client()
    lights = iter([{"angle": 96.0, "altitude": 30.0}, {"angle": 96.0, "altitude": 30.0}, {"angle": 65.0, "altitude": 30.0}])
    monkeypatch.setattr(ps_actions, "capture_style", lambda mode: {"ok": True, "style": {"captured_params": {}},
                                                                   "global_light": next(lights)})
    first = client.post("/api/ps/capture-style", json={"name": "A"}).get_json()
    assert first["config"]["dynamic_settings"]["fx_global_light"] == {"angle": 96.0, "altitude": 30.0}
    assert first["light_changed"]["to"]["angle"] == 96.0
    same = client.post("/api/ps/capture-style", json={"name": "B"}).get_json()
    assert "light_changed" not in same                                                    # nothing new to say
    other = client.post("/api/ps/capture-style", json={"name": "C"}).get_json()
    assert other["config"]["dynamic_settings"]["fx_global_light"]["angle"] == 65.0
    assert other["light_changed"]["from"]["angle"] == 96.0
