"""Start-up speed: shared answers (Memo), the cached sheet list, stale-while-redrawn thumbnails."""
import threading
import time

from openpyxl import Workbook

from ps_autotypesetter.memo import Memo, file_stamp
from ps_autotypesetter.ui_web import page_thumbs


def test_memo_computes_once_for_callers_arriving_together():
    memo, calls = Memo(), []

    def slow():
        calls.append(1)
        time.sleep(0.2)
        return {"v": [1]}

    out = []
    threads = [threading.Thread(target=lambda: out.append(memo.get("k", slow))) for _ in range(5)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    assert len(calls) == 1 and out == [{"v": [1]}] * 5
    out[0]["v"].append(2)                                  # callers get copies
    assert memo.get("k", slow) == {"v": [1]}


def test_memo_failure_is_not_remembered():
    memo = Memo()

    def boom():
        raise ValueError("no")

    try:
        memo.get("k", boom)
    except ValueError:
        pass
    assert memo.get("k", lambda: 7) == 7


def test_file_stamp_changes_when_the_file_is_saved(tmp_path):
    f = tmp_path / "a.xlsx"
    f.write_bytes(b"1")
    one = file_stamp(f)
    f.write_bytes(b"22")
    assert file_stamp(f) != one and file_stamp(tmp_path / "missing") is None


def _excel(tmp_path):
    wb = Workbook()
    ws = wb.active
    ws.title = "Features"
    ws.append(["FREE SPINS"])
    ws.append(["Three scatters award 10 free spins."])
    path = str(tmp_path / "game.xlsx")
    wb.save(path)
    return path


def test_sheet_list_is_computed_once_per_settings(tmp_path, monkeypatch):
    from visualiser import visualiser_web
    from ps_autotypesetter.ui_web.server import create_app

    excel = _excel(tmp_path)
    visualiser_web._SHEETS_MEMO.clear()
    calls = []
    real = visualiser_web._normal_sheets
    monkeypatch.setattr(visualiser_web, "_normal_sheets", lambda cfg: calls.append(1) or real(cfg))
    client = create_app(session_file=str(tmp_path / "s.json")).test_client()
    client.post("/api/config", json={"excel_path": excel})
    first = client.post("/api/visualiser/sheets", json={}).get_json()
    client.post("/api/visualiser/sheets", json={})
    assert len(calls) == 1 and first["sheets"] == ["Features"]
    client.post("/api/config", json={"c_width": 1000})   # a setting changed: worked out again
    client.post("/api/visualiser/sheets", json={})
    assert len(calls) == 2


def test_sheet_list_without_excel_says_so(tmp_path):
    from visualiser import visualiser_web
    from ps_autotypesetter.ui_web.server import create_app

    visualiser_web._SHEETS_MEMO.clear()
    client = create_app(session_file=str(tmp_path / "s.json")).test_client()
    client.post("/api/config", json={"excel_path": ""})
    data = client.post("/api/visualiser/sheets", json={}).get_json()
    assert data["ok"] and data["sheets"] == []


def test_old_thumbnail_is_served_while_the_new_one_is_drawn(tmp_path, monkeypatch):
    monkeypatch.setattr(page_thumbs, "THUMB_ROOT", str(tmp_path / "thumbs"))
    excel = _excel(tmp_path)
    drawn, gate = [], threading.Event()

    def fake_render(excel_path, sheet_name, cfg, out_path):
        if drawn:
            gate.wait(5)                                   # the redraw takes a while
        drawn.append(cfg.get("b_size"))
        import os
        from PIL import Image

        os.makedirs(os.path.dirname(out_path), exist_ok=True)
        Image.new("RGB", (4, 4)).save(out_path)
        page_thumbs._save_page_count(out_path, 1)
        return {"ok": True, "pages": 1}

    monkeypatch.setattr(page_thumbs, "_render_full_preview", fake_render)
    first = page_thumbs.preview_or_stale(excel, "Features", {"b_size": 30})
    assert first["ok"] and not first["stale"]              # never drawn: waited for it
    t = time.perf_counter()
    second = page_thumbs.preview_or_stale(excel, "Features", {"b_size": 40})
    assert time.perf_counter() - t < 0.5                   # did not wait for the redraw
    assert second["stale"] and second["path"] == first["path"]
    assert not page_thumbs.is_fresh(excel, "Features", {"b_size": 40})
    gate.set()
    for _ in range(50):
        if page_thumbs.is_fresh(excel, "Features", {"b_size": 40}):
            break
        time.sleep(0.05)
    assert page_thumbs.is_fresh(excel, "Features", {"b_size": 40}) and drawn == [30, 40]
    third = page_thumbs.preview_or_stale(excel, "Features", {"b_size": 40})
    assert not third["stale"] and third["path"] != first["path"]


def test_pages_fresh_route(tmp_path, monkeypatch):
    from ps_autotypesetter.ui_web.server import create_app

    monkeypatch.setattr(page_thumbs, "THUMB_ROOT", str(tmp_path / "thumbs"))
    excel = _excel(tmp_path)
    client = create_app(session_file=str(tmp_path / "s.json")).test_client()
    client.post("/api/config", json={"excel_path": excel})
    data = client.post("/api/pages_fresh", json={"sheets": ["Features"]}).get_json()
    assert data == {"ok": True, "fresh": {"Features": False}}
