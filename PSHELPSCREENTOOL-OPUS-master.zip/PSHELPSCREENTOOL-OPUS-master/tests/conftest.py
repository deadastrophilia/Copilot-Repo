import pytest
from openpyxl import Workbook


@pytest.fixture(autouse=True)
def _private_paytable_library(tmp_path_factory, monkeypatch):
    """Tests never write into the real PaytableTemplates folder (the user's library)."""
    from ps_autotypesetter.ui_web import paytable_templates

    folder = tmp_path_factory.mktemp("PaytableTemplates")
    monkeypatch.setattr(paytable_templates, "templates_dir", lambda: str(folder))
    from ps_autotypesetter.dynamic_pages.paytable import card_templates

    cards = tmp_path_factory.mktemp("CardTemplates")
    monkeypatch.setattr(card_templates, "user_dir", lambda: str(cards))


@pytest.fixture(autouse=True)
def _private_session_file(tmp_path_factory):
    """create_app() without a session_file must not read or write the user's real session."""
    from ps_autotypesetter.ui_web import engine_api

    old = engine_api._SESSION_FILE
    engine_api.set_session_file(str(tmp_path_factory.mktemp("session") / "session.json"))
    yield
    engine_api.set_session_file(old)


@pytest.fixture(autouse=True)
def _private_games_registry(tmp_path_factory, monkeypatch):
    """Games, clone links and bindings written by tests land in a scratch store, never the user's."""
    from ps_autotypesetter import games

    monkeypatch.setattr(games, "REGISTRY_FILE", str(tmp_path_factory.mktemp("games") / "Games.json"))


@pytest.fixture(autouse=True)
def _private_thumbnails(tmp_path_factory, monkeypatch):
    """Page previews drawn by tests never land in the user's thumbnail cache (or its latest.json)."""
    from ps_autotypesetter.ui_web import page_thumbs

    monkeypatch.setattr(page_thumbs, "THUMB_ROOT", str(tmp_path_factory.mktemp("thumbs")))


@pytest.fixture
def empty_workbook():
    wb = Workbook()
    wb.remove(wb.active)
    return wb


@pytest.fixture
def single_sheet_wb():
    wb = Workbook()
    ws = wb.active
    ws.title = "Sheet1"
    ws.append(["A", "B", "C"])
    ws.append(["1", "2", "3"])
    return wb


@pytest.fixture
def two_sheet_wb():
    wb = Workbook()
    ws1 = wb.active
    ws1.title = "GameRules"
    ws1.append(["Header", "Value"])
    ws1.append(["Rule 1", "Description 1"])
    ws2 = wb.create_sheet("Paytable")
    ws2.append(["Symbol", "Payout"])
    return wb
