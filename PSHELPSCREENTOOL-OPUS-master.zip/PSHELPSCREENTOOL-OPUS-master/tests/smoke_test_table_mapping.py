import json
import os
import sys
import tempfile

from openpyxl import Workbook, load_workbook


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from ps_autotypesetter.table_mapping import (
    _bounds_slot_for_table,
    _ensure_synthetic_bounds_slot,
    build_mapped_table_template,
    extract_existing_table_mappings,
    load_mapped_table_templates,
    load_table_template,
    normalize_range,
    remove_token_indexes,
    resolve_table_source_text,
    resolve_table_token,
    save_mapped_table_template,
    scan_table_excel_content,
    source_for_row_offset,
    source_row_range_for_template,
    slots_for_table_template,
    strip_table_markers,
    table_template_for_excel_table,
    table_template_names,
    table_templates_for_marker,
    template_matches_sheet,
    trigger_row_for_template,
    validate_table_mappings,
)


with tempfile.TemporaryDirectory() as folder:
    excel_path = os.path.join(folder, "cash_express.xlsx")
    json_path = os.path.join(folder, "cashExpressJsonTable.json")
    output_path = os.path.join(folder, "cashExpressJsonTable_mapped.json")

    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = "CASH EXPRESS LEGEND SYMBOLS"
    worksheet["B2"] = "Cash Express Trains"
    worksheet["B4"] = "<TRAIN> Cash Express"
    worksheet["C4"] = "Collect 3 cash values"
    worksheet["D4"] = "$10"
    worksheet["B5"] = "<TRAIN> Major Express"
    worksheet["C5"] = "Collect 4 cash values"
    worksheet["D5"] = "$20"
    worksheet["B6"] = "<TRAIN> Mega Express"
    worksheet["C6"] = "Collect 5 cash values"
    worksheet["D6"] = "$30"
    worksheet.merge_cells("D8:G8")
    worksheet.merge_cells("H8:I8")
    worksheet.merge_cells("J8:L8")
    worksheet["D8"] = "CASH EXPRESS TRAINS"
    worksheet["H8"] = "Number of Carriages"
    worksheet["J8"] = "Possible Prizes"
    worksheet["B12"] = "Use <table:cashExpressTrains> for the legend table."
    worksheet["B14"] = "Outside page copy with <HOTEL> and <HOUSE> tokens."
    workbook.save(excel_path)

    base_template = {
        "template_id": "cash_express_table",
        "slot_prefix": "@table",
        "canvas": {"width": 1920, "height": 1080},
        "slots": {
            "cashExpressTrains.bounds": {"x": 220, "y": 260, "w": 1480, "h": 460},
            "cashExpressTrains.header.title": {"x": 260, "y": 285, "w": 1400, "h": 70},
            "cashExpressTrains.rowTemplate.trainIcon": {"x": 260, "y": 380, "w": 120, "h": 90},
            "cashExpressTrains.rowTemplate.carriageText": {"x": 410, "y": 380, "w": 760, "h": 90},
            "cashExpressTrains.rowTemplate.prizeText": {"x": 1190, "y": 380, "w": 320, "h": 90},
            "cashExpressTrains.rowTemplate.rowBox": {"x": 245, "y": 370, "w": 1290, "h": 110},
        },
    }
    with open(json_path, "w", encoding="utf-8") as handle:
        json.dump(base_template, handle)

    template = load_table_template(json_path)
    assert template["export_kind"] == "table"
    assert template["table_slots"] == template["slots"]
    assert table_template_names(template) == ["cashExpressTrains"]

    flat_template = {
        "template_id": "bigbuck-page-3table",
        "slot_prefix": "@table",
        "export_kind": "table",
        "canvas": {"width": 1920, "height": 1080},
        "slots": {
            "header1": {"x": 688, "y": 253, "w": 299, "h": 35},
            "header2": {"x": 987, "y": 253, "w": 245, "h": 35},
            "row42": {"x": 688, "y": 988, "w": 299, "h": 35},
        },
    }
    assert table_template_names(flat_template) == ["bigbuck-page-3table"]
    assert set(slots_for_table_template(flat_template, "bigbuck-page-3table")) == {"header1", "header2", "row42"}
    generated_bound = _ensure_synthetic_bounds_slot(flat_template, "bigbuck-page-3table")
    assert generated_bound == "bigbuck-page-3table.bounds"
    assert flat_template["slots"][generated_bound] == {"x": 688, "y": 253, "w": 544, "h": 770}
    assert {"header1", "header2", "row42"}.issubset(
        set(slots_for_table_template(flat_template, "bigbuck-page-3table"))
    )

    bigbuck_bounds_template = {
        "template_id": "bigbuck-page-3table",
        "slot_prefix": "@table",
        "export_kind": "table",
        "canvas": {"width": 1920, "height": 1080},
        "slots": {
            "bigbuck.bound": {"x": 688, "y": 253, "w": 544, "h": 770},
            "row42": {"x": 688, "y": 988, "w": 299, "h": 35},
            "row41": {"x": 987, "y": 988, "w": 245, "h": 35},
        },
    }
    assert table_template_names(bigbuck_bounds_template) == ["bigbuck-page-3table"]
    assert _bounds_slot_for_table(bigbuck_bounds_template, "bigbuck-page-3table") == "bigbuck.bound"
    bigbuck_mapped = build_mapped_table_template(
        bigbuck_bounds_template,
        "Big Board Bucks Features",
        "bigbuck-page-3table",
        "B10:C33",
        [{"kind": "text", "source": "B10", "slot": "row42"}],
    )
    assert bigbuck_mapped["table_templates"]["bigbuck-page-3table"]["bounds_slot"] == "bigbuck.bound"

    loose_template = {
        "template_id": "loose_table_slots",
        "slot_prefix": "@",
        "export_kind": "all_at_layers",
        "canvas": {"width": 1920, "height": 1080},
        "slots": {
            "table.header.one": {"x": 10, "y": 10, "w": 100, "h": 30},
            "slot.anything": {"x": 10, "y": 50, "w": 100, "h": 30},
            "etc.custom.name": {"x": 10, "y": 90, "w": 100, "h": 30},
        },
    }
    assert table_template_names(loose_template) == ["loose_table_slots"]
    assert set(slots_for_table_template(loose_template, "loose_table_slots")) == set(loose_template["slots"])

    grouped_all_at_template = {
        "template_id": "mixed_export",
        "slot_prefix": "@",
        "export_kind": "all_at_layers",
        "canvas": {"width": 1920, "height": 1080},
        "slots": {
            "table.cashExpressTrains.bounds": {"x": 0, "y": 0, "w": 100, "h": 100},
            "table.cashExpressTrains.header": {"x": 0, "y": 0, "w": 100, "h": 20},
            "slot.other": {"x": 0, "y": 120, "w": 100, "h": 20},
        },
    }
    assert table_template_names(grouped_all_at_template) == ["table.cashExpressTrains"]
    assert set(slots_for_table_template(grouped_all_at_template, "table.cashExpressTrains")) == {
        "table.cashExpressTrains.bounds",
        "table.cashExpressTrains.header",
    }

    blocks = scan_table_excel_content(excel_path, "CASH EXPRESS LEGEND SYMBOLS", max_column=12)
    row_four = next(block for block in blocks if block["kind"] != "table_range" and block["row"] == 4)
    assert row_four["source"] == "B4:D4"
    assert row_four["tokens"] == ["TRAIN"]
    row_eight = next(block for block in blocks if block["kind"] != "table_range" and block["row"] == 8)
    assert row_eight["source"] == "D8:J8"
    assert [cell["source"] for cell in row_eight["cells"]] == ["D8", "H8", "J8"]
    assert row_eight["cells"][0]["merged_source"] == "D8:G8"

    loaded_workbook = load_workbook(excel_path, data_only=False)
    try:
        sheet = loaded_workbook["CASH EXPRESS LEGEND SYMBOLS"]
        assert "Cash Express Collect 3 cash values $10" in resolve_table_source_text(sheet, "B4:D4")
        assert resolve_table_token(sheet, "B4:D6", 0) == "TRAIN"
        assert remove_token_indexes("<TRAIN> Cash Express", [0]) == "Cash Express"
        assert resolve_table_source_text(sheet, "D8") == "CASH EXPRESS TRAINS"
        assert resolve_table_source_text(sheet, "H8") == "Number of Carriages"
        assert resolve_table_source_text(sheet, "J8") == "Possible Prizes"
        assert resolve_table_source_text(sheet, "D8; H8; J8").splitlines() == [
            "CASH EXPRESS TRAINS",
            "Number of Carriages",
            "Possible Prizes",
        ]
        assert normalize_range("D8; H8:I8; J8") == "D8; H8:I8; J8"
    finally:
        loaded_workbook.close()

    mappings = [
        {
            "kind": "text",
            "source": "B2:D2",
            "slot": "cashExpressTrains.header.title",
            "role": "heading",
            "font_size": 34,
            "color": [255, 238, 120],
            "alignment": "center",
            "background_color": "#07162b",
            "fill_enabled": True,
            "stroke_enabled": True,
            "stroke_color": "#ffffff",
            "stroke_width": 2,
        },
        {
            "kind": "dedicated_icon",
            "source": "B4:D6",
            "slot": "cashExpressTrains.rowTemplate.trainIcon",
            "token_index": 0,
            "icon_height": 76,
            "repeat": True,
        },
        {
            "kind": "flow",
            "source": "B4:D6",
            "slot": "cashExpressTrains.rowTemplate.carriageText",
            "font_size": 28,
            "font_family": "Body Fancy",
            "font_style": "Italic",
            "line_height": 42,
            "icon_height": 34,
            "repeat": True,
        },
        {
            "kind": "text",
            "source": "D4:D6",
            "slot": "cashExpressTrains.rowTemplate.prizeText",
            "font_size": 30,
            "color": "#ffffff",
            "alignment": "right",
            "repeat": True,
        },
        {
            "kind": "background",
            "slot": "cashExpressTrains.rowTemplate.rowBox",
            "background_color": "#14293f",
            "opacity": 0,
            "fill_enabled": True,
            "stroke_enabled": True,
            "stroke_color": "#f6c343",
            "stroke_width": 3,
            "repeat": True,
        },
    ]

    errors, warnings = validate_table_mappings(
        template,
        "cashExpressTrains",
        mappings,
        excel_path=excel_path,
        sheet_name="CASH EXPRESS LEGEND SYMBOLS",
    )
    assert not errors, errors
    assert any("Missing dedicated icon assets" in warning for warning in warnings)
    assert not any("Unmapped Excel rows" in warning for warning in warnings), warnings
    assert not any("HOTEL" in warning or "HOUSE" in warning for warning in warnings), warnings

    mapped = build_mapped_table_template(
        template,
        "CASH EXPRESS LEGEND SYMBOLS",
        "cashExpressTrains",
        "B4:D6",
        mappings,
        insert_mode="after_row",
        insert_after_row=3,
        margin_before=18,
        margin_after=24,
        fit_mode="scale",
    )
    assert mapped["export_kind"] == "table"
    assert mapped["table_slots"] == mapped["slots"]
    assert mapped["table_templates"]["cashExpressTrains"]["mappings"][0]["role"] == "heading"
    assert mapped["table_templates"]["cashExpressTrains"]["mappings"][0]["fill_enabled"] is True
    assert mapped["table_templates"]["cashExpressTrains"]["mappings"][0]["stroke_width"] == 2
    assert mapped["table_templates"]["cashExpressTrains"]["mappings"][1]["repeat"] is True
    assert mapped["table_templates"]["cashExpressTrains"]["mappings"][2]["font_family"] == "Body Fancy"
    assert mapped["table_templates"]["cashExpressTrains"]["mappings"][2]["font_style"] == "Italic"
    assert mapped["table_templates"]["cashExpressTrains"]["mappings"][2]["line_height"] == 42
    assert mapped["table_templates"]["cashExpressTrains"]["mappings"][4]["stroke_width"] == 3
    assert mapped["table_templates"]["cashExpressTrains"]["mappings"][4]["stroke_enabled"] is True

    saved_path, _save_warnings = save_mapped_table_template(
        template,
        "CASH EXPRESS LEGEND SYMBOLS",
        "cashExpressTrains",
        "B4:D6",
        mappings,
        output_path,
        insert_mode="after_row",
        insert_after_row=3,
        margin_before=18,
        margin_after=24,
        fit_mode="scale",
    )
    assert saved_path == output_path

    records = load_mapped_table_templates(output_path)
    assert len(records) == 1
    record = records[0]
    assert template_matches_sheet(record, "CASH EXPRESS LEGEND SYMBOLS") is True
    assert template_matches_sheet(record, "CASH EXPRESS") is False
    assert template_matches_sheet(record, "OTHER SHEET") is False
    blank_sheet_record = dict(record)
    blank_sheet_record["spec"] = dict(record["spec"])
    blank_sheet_record["spec"]["source_sheet"] = ""
    assert template_matches_sheet(blank_sheet_record, "CASH EXPRESS LEGEND SYMBOLS") is False
    assert trigger_row_for_template(record) == 4
    assert source_row_range_for_template(record) == (4, 6)
    assert source_for_row_offset("B4:D6", 1) == "B5:D5"
    assert table_template_for_excel_table(records, "CASH EXPRESS LEGEND SYMBOLS", {"start_row": 4, "end_row": 6}) == record
    trigger_cell_record = dict(record)
    trigger_cell_record["spec"] = dict(record["spec"])
    trigger_cell_record["spec"]["source_range"] = "D9"
    trigger_cell_record["spec"]["mappings"] = [
        mapping for mapping in record["spec"]["mappings"]
        if mapping.get("source") != "B2:D2"
    ]
    assert source_row_range_for_template(trigger_cell_record) == (4, 6)
    assert table_template_for_excel_table(
        [trigger_cell_record], "CASH EXPRESS LEGEND SYMBOLS", {"start_row": 4, "end_row": 6}
    ) == trigger_cell_record
    short_source_record = dict(record)
    short_source_record["spec"] = dict(record["spec"])
    short_source_record["spec"]["insert_mode"] = "range_start"
    short_source_record["spec"]["source_range"] = "B4:D4"
    assert table_template_for_excel_table(
        [short_source_record], "CASH EXPRESS LEGEND SYMBOLS", {"start_row": 4, "end_row": 6}
    ) == short_source_record
    wider_source_record = dict(record)
    wider_source_record["spec"] = dict(record["spec"])
    wider_source_record["spec"]["insert_mode"] = "range_start"
    wider_source_record["spec"]["source_range"] = "B3:D8"
    assert table_template_for_excel_table(
        [wider_source_record], "CASH EXPRESS LEGEND SYMBOLS", {"start_row": 4, "end_row": 6}
    ) == wider_source_record
    loose_record = dict(record)
    loose_record["spec"] = dict(record["spec"])
    loose_record["spec"]["insert_mode"] = "range_start"
    loose_record["spec"]["source_range"] = "B5:D8"
    assert table_template_for_excel_table(
        [loose_record], "CASH EXPRESS LEGEND SYMBOLS", {"start_row": 4, "end_row": 6}
    ) == loose_record
    assert table_templates_for_marker(records, "CASH EXPRESS LEGEND SYMBOLS", "Intro <table:cashExpressTrains>") == [record]
    assert strip_table_markers("Intro <table:cashExpressTrains> outro") == "Intro  outro"

    existing_mappings, spec = extract_existing_table_mappings(load_table_template(output_path), "cashExpressTrains")
    assert len(existing_mappings) == len(mappings)
    assert spec["source_range"] == "B4:D6"

print("Table JSON mapper smoke test passed.")
