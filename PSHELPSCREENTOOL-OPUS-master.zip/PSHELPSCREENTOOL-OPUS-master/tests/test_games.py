"""Game -> Market -> Version library (games.py)."""
import os

import pytest
from openpyxl import Workbook
from PIL import Image

from ps_autotypesetter import games, project_package
from ps_autotypesetter.ui_web import engine_api


@pytest.fixture
def game_folder(tmp_path, monkeypatch):
    monkeypatch.setattr(games, "REGISTRY_FILE", str(tmp_path / "registry.json"))
    folder = tmp_path / "Lucky Dragon"
    (folder / "icons").mkdir(parents=True)
    (folder / "Heading").mkdir()
    for name in ("LD_Rules_NYL.xlsx", "LD_Rules_PA.xlsx"):
        wb = Workbook()
        wb.active.title = "Rules"
        wb.active["A1"] = "Game Rules"
        wb.active["A2"] = f"Market {name}"
        wb.save(folder / name)
    for i in range(3):
        Image.new("RGBA", (20, 20), (255, 0, 0, 255)).save(folder / "icons" / f"sym{i}.png")
    Image.new("RGB", (64, 36), (0, 0, 80)).save(folder / "bg.jpg")
    return folder


def test_market_names_keep_the_part_that_differs():
    assert games.market_names(["x/BZZF_Blast_AGR_NYL.xlsx", "x/BZZF_Blast_AGR_PA.xlsx"]) == ["NYL", "PA"]
    assert games.market_names(["x/BaoZhao.xlsx"]) == ["BaoZhao"]


def test_create_finds_markets_and_assets(game_folder):
    game = games.create(str(game_folder), base_config={"b_size": 33, "excel_path": "old.xlsx"})
    assert [m["name"] for m in game["markets"]] == ["NYL", "PA"]
    assert game["style"]["icon_folder"].endswith("icons")
    assert game["style"]["bg_path"].endswith("bg.jpg")
    assert game["style"]["alignment_settings"]["heading_image_folder"].endswith("Heading")
    assert game["style"]["b_size"] == 33 and "excel_path" not in game["style"]
    assert not os.path.isfile(game_folder / games.GAME_FILE)   # nothing written into the game folder
    assert os.path.isfile(game["_file"]) and os.path.dirname(game["_file"]) == games._store_dir()
    assert [g["name"] for g in games.list_games()] == ["Lucky Dragon"]
    # re-adding the same folder re-opens it instead of making a second game
    assert games.create(str(game_folder))["id"] == game["id"]


def test_style_is_shared_and_market_fields_stay_per_market(game_folder):
    game = games.create(str(game_folder), base_config={"b_size": 30})
    nyl, pa = game["markets"]
    cfg = games.open_market(game, nyl["id"], {}, defaults=engine_api.DEFAULT_CONFIG)
    assert cfg["excel_path"].endswith("LD_Rules_NYL.xlsx") and cfg["active_market"] == nyl["id"]
    cfg["b_size"] = 41                                     # a look change …
    cfg["page_overrides"] = {"Rules": {"x": 1}}            # … and a market tweak
    cfg["dynamic_settings"] = {"live_overrides": {"Rules": {"a": 1}}, "card_style": "round"}
    games.sync_from_session(cfg)
    other = games.open_market(games.get(game["id"]), pa["id"], {}, defaults=engine_api.DEFAULT_CONFIG)
    assert other["b_size"] == 41                           # shared by every market
    assert other["excel_path"].endswith("LD_Rules_PA.xlsx")
    assert not other.get("page_overrides")                 # NYL's tweak stays in NYL
    assert "live_overrides" not in (other["dynamic_settings"] or {})
    assert other["dynamic_settings"]["card_style"] == "round"
    back = games.open_market(games.get(game["id"]), nyl["id"], {}, defaults=engine_api.DEFAULT_CONFIG)
    assert back["page_overrides"] == {"Rules": {"x": 1}}
    assert back["dynamic_settings"]["live_overrides"] == {"Rules": {"a": 1}}


def test_versions_states_and_changed_pages(game_folder, tmp_path):
    game = games.create(str(game_folder))
    nyl = game["markets"][0]
    assert games.market_status(nyl)["state"] == "never_built"
    cfg = games.open_market(game, nyl["id"], {}, defaults=engine_api.DEFAULT_CONFIG)
    assert cfg["output_name"].endswith(" v1") and cfg["overwrite_existing"] is False
    psd = tmp_path / "out" / "Lucky Dragon NYL v1.psd"
    psd.parent.mkdir()
    psd.write_bytes(b"8BPS")
    project_package.commit_baseline(str(psd), nyl["excel_path"], 12, force=True)
    entry = games.record_version(cfg, str(psd))
    assert entry["n"] == 1 and cfg["output_name"].endswith(" v2")
    market = games.find_market(games.get(game["id"]), nyl["id"])
    assert games.market_status(market)["state"] == "up_to_date"
    from openpyxl import load_workbook
    wb = load_workbook(nyl["excel_path"])
    wb["Rules"]["A2"] = "Revised text"
    wb.create_sheet("Paytable")["A1"] = "pays"
    wb.save(nyl["excel_path"])
    assert games.market_status(market)["state"] == "changed"
    ch = games.changed_pages(market)
    assert ch["known"] and ch["changed"] == ["Rules"] and ch["added"] == ["Paytable"]


def test_unregister_keeps_files(game_folder):
    game = games.create(str(game_folder))
    games.unregister(game["id"])
    assert games.list_games() == []
    assert os.path.isfile(game["_file"])                  # forgetting a game deletes nothing


def test_native_browse_returns_full_windows_path(monkeypatch):
    """Browser version: the server opens the real dialog (a browser only gives names)."""
    import tkinter.filedialog as fd

    from ps_autotypesetter.ui_web import native_dialogs

    monkeypatch.setattr(fd, "askdirectory", lambda **kw: "E:/Games/Lucky Dragon")
    monkeypatch.setattr(fd, "askopenfilename", lambda **kw: "E:/Games/Lucky Dragon/LD_NYL.xlsx")
    assert native_dialogs.pick("dir") == r"E:\Games\Lucky Dragon"
    assert native_dialogs.pick("excel") == r"E:\Games\Lucky Dragon\LD_NYL.xlsx"



@pytest.fixture
def depot(tmp_path, monkeypatch):
    """<Game>/Game Docs/<Market>/<excel>  +  <Game>/Production/Video/<Market>/Help Screen/{Working,Static}."""
    monkeypatch.setattr(games, "REGISTRY_FILE", str(tmp_path / "registry.json"))
    game = tmp_path / "Game A"
    for market in ("NYL", "HHR", "ATLS", "C2"):
        (game / "Game Docs" / market).mkdir(parents=True)
        wb = Workbook()
        wb.active.title = "Rules"
        wb.active["A1"] = f"Rules {market}"
        wb.save(game / "Game Docs" / market / f"GameA_AGR_{market}.xlsx")
        (game / "Production" / "Video" / market / "Edits").mkdir(parents=True)
    # NYL already has its help-screen folders (different spelling)
    (game / "Production" / "Video" / "NYL" / "HelpScreen" / "working").mkdir(parents=True)
    (game / "Production" / "Video" / "NYL" / "HelpScreen" / "statics").mkdir(parents=True)
    (game / "Other Stuff").mkdir()
    return game


def test_depot_layout_markets_and_help_screen_folders(depot):
    found = games.discover(str(depot))
    assert found["layout"] == "depot"
    markets = {m["name"]: m for m in found["markets"]}
    assert sorted(markets) == ["ATLS", "C2", "HHR", "NYL"]
    assert markets["HHR"]["excel_path"].endswith("GameA_AGR_HHR.xlsx")
    nyl = markets["NYL"]
    assert nyl["help_exists"] and nyl["working"].endswith(os.path.join("HelpScreen", "working"))
    assert nyl["static"].lower().endswith("statics")
    hhr = markets["HHR"]
    assert not hhr["help_exists"]
    assert hhr["working"].endswith(os.path.join("Production", "Video", "HHR", "Help Screen", "Working"))
    assert hhr["static"].endswith(os.path.join("Help Screen", "Static"))
    assert not os.path.exists(hhr["working"])          # discovering writes nothing


def test_depot_market_builds_into_working_and_static(depot):
    game = games.create(str(depot))
    assert game["naming"] == "fixed"
    hhr = [m for m in game["markets"] if m["name"] == "HHR"][0]
    cfg = games.open_market(game, hhr["id"], {}, defaults=engine_api.DEFAULT_CONFIG)
    assert cfg["output_dir"].endswith(os.path.join("HHR", "Help Screen", "Working"))
    assert cfg["png_output_dir"].endswith(os.path.join("HHR", "Help Screen", "Static"))
    assert cfg["output_name"] == "Game A HHR"            # fixed name, no vN
    made = games.ensure_output_folders(cfg)
    assert os.path.isdir(cfg["output_dir"]) and os.path.isdir(cfg["png_output_dir"]) and len(made) == 2


def test_fixed_name_never_overwrites_an_edited_or_readonly_psd(depot):
    import stat

    game = games.create(str(depot))
    nyl = [m for m in game["markets"] if m["name"] == "NYL"][0]
    cfg = games.open_market(game, nyl["id"], {}, defaults=engine_api.DEFAULT_CONFIG)
    target = os.path.join(cfg["output_dir"], cfg["output_name"] + ".psd")
    with open(target, "wb") as f:
        f.write(b"8BPS ours")
    games.record_version(cfg, target)
    assert games.protect_artist_psd(dict(cfg)) == ""     # untouched since our build: overwrite is fine
    with open(target, "ab") as f:
        f.write(b" + artist edit")
    c2 = dict(cfg)
    note = games.protect_artist_psd(c2)
    assert note and c2["output_name"] == "Game A NYL_rebuilt"
    os.chmod(target, stat.S_IREAD)
    try:
        c3 = dict(cfg)
        assert "read-only" in games.protect_artist_psd(c3)
    finally:
        os.chmod(target, stat.S_IWRITE | stat.S_IREAD)


# ── a game's workspace takes only its own Excel ───────────────────────────────
def _agr(path, tokens, sheets=("Paytable", "Game Rules")):
    wb = Workbook()
    wb.active.title = sheets[0]
    for s in sheets[1:]:
        wb.create_sheet(s)
    ws = wb[sheets[-1]]
    for i, t in enumerate(tokens, start=1):
        ws.cell(i, 1, f"<{t}> substitutes for <WILD> and <A>")
    wb.save(path)
    return str(path)


DRAGON = ["RED DRAGON", "GOLD COIN", "LANTERN", "FIRECRACKER", "JADE"]
CHICKEN = ["BLURPLE EGG", "BLASTER", "ROCKET", "CHICKEN", "UFO"]


@pytest.fixture
def two_games(tmp_path, monkeypatch):
    monkeypatch.setattr(games, "REGISTRY_FILE", str(tmp_path / "registry.json"))
    made = {}
    for name, toks, sheets in (("Lucky Dragon", DRAGON, ("Paytable", "Dragon Feature", "Game Rules")),
                               ("Crazy Chickens", CHICKEN, ("Paytable", "Instant Win", "Game Rules"))):
        folder = tmp_path / name
        folder.mkdir()
        _agr(folder / f"{name.replace(' ', '')}_AGR_NYL.xlsx", toks, sheets)
        made[name] = games.create(str(folder))
    return made, tmp_path


def test_the_same_games_revision_belongs_another_games_excel_does_not(two_games):
    made, tmp = two_games
    dragon = made["Lucky Dragon"]
    rev = _agr(tmp / "rev2.xlsx", DRAGON[:4] + ["NEW SYMBOL"], ("Paytable", "Dragon Feature", "Game Rules"))
    assert games.check_excel(dragon, rev)["same"]
    other = _agr(tmp / "unnamed.xlsx", CHICKEN, ("Paytable", "Instant Win", "Game Rules"))
    r = games.check_excel(dragon, other)
    assert not r["same"] and r["game"] == "Lucky Dragon"
    assert [o["name"] for o in r["other"]] == ["Crazy Chickens"]       # offered as the game to switch to
    assert not games.belongs(dragon, other)


def test_accepting_an_excel_remembers_it_for_the_game(two_games):
    made, tmp = two_games
    dragon = made["Lucky Dragon"]
    odd = _agr(tmp / "odd.xlsx", ["TOTALLY", "DIFFERENT", "SYMBOLS"], ("Sheet A",))
    assert not games.check_excel(dragon, odd)["same"]
    games.accept_excel(dragon, odd)
    assert games.check_excel(games.get(dragon["id"]), odd)["same"]


def test_the_build_check_blocks_another_games_excel(two_games):
    made, tmp = two_games
    other = _agr(tmp / "unnamed.xlsx", CHICKEN, ("Paytable", "Instant Win", "Game Rules"))
    report = engine_api.preflight({"excel_path": other, "active_game": made["Lucky Dragon"]["id"], "c_width": 1920, "c_height": 1080})
    assert any(b["code"] == "excel_other_game" for b in report["blocking"])
    own = made["Lucky Dragon"]["markets"][0]["excel_path"]
    report = engine_api.preflight({"excel_path": own, "active_game": made["Lucky Dragon"]["id"], "c_width": 1920, "c_height": 1080})
    assert not any(b["code"] == "excel_other_game" for b in report["blocking"])


def test_the_game_card_picture_is_its_paytable_page(tmp_path, monkeypatch):
    from ps_autotypesetter.ui_web.server import create_app

    session = tmp_path / "session.json"
    session.write_text("{}", encoding="utf-8")
    client = create_app(session_file=str(session)).test_client()      # games list beside the session
    folder = tmp_path / "Lucky Dragon"
    folder.mkdir()
    _agr(folder / "LuckyDragon_AGR_NYL.xlsx", DRAGON, ("Game Rules", "Paytable"))
    game = games.create(str(folder))
    seen = {}
    real = __import__("ps_autotypesetter.ui_web.page_thumbs", fromlist=["x"]).render_sheet_preview

    def spy(excel, sheet, cfg):
        seen["sheet"], seen["game"] = sheet, cfg.get("active_game")
        return real(excel, sheet, cfg)

    monkeypatch.setattr("ps_autotypesetter.ui_web.page_thumbs.render_sheet_preview", spy)
    r = client.get(f"/api/games/{game['id']}/thumb")
    assert r.status_code == 200 and r.mimetype == "image/png"
    assert seen == {"sheet": "Paytable", "game": None}                # the paytable, never as the open game
    again = client.get(f"/api/games/{game['id']}/thumb")
    assert again.status_code == 200 and "sheet" in seen               # kept: served from the saved picture


def _built_psd(folder, excel, name="Lucky Dragon NYL v3.psd"):
    """A tool-made PSD stand-in and its memory: the Excel snapshot as it was built from."""
    psd = folder / "out" / name
    psd.parent.mkdir(exist_ok=True)
    psd.write_bytes(b"8BPS")
    return str(psd), {"excel": {"path": str(excel), "sha256": project_package.file_sha256(str(excel))},
                      "identity": {}}


def test_open_a_psd_puts_an_unlisted_psd_in_recent_games(game_folder):
    excel = game_folder / "LD_Rules_NYL.xlsx"
    psd, mem = _built_psd(game_folder, excel)
    cfg = {"excel_path": str(excel)}
    note = games.adopt_psd(cfg, psd, mem)
    assert note.startswith("Added to Recent games")
    game = games.get(cfg["active_game"])
    market = games.find_market(game, cfg["active_market"])
    assert market["excel_path"] == str(excel) and market["settings"]["output_name"] == "Lucky Dragon NYL"
    assert games.market_status(market)["state"] == "up_to_date"
    assert games.adopt_psd(dict(cfg), psd, mem) == ""          # opened again: listed once
    assert len(games.find_market(games.get(game["id"]), market["id"])["versions"]) == 1

    from openpyxl import load_workbook                        # the Excel moves on: Update PSD shows
    wb = load_workbook(str(excel))
    wb["Rules"]["A2"] = "Revised text"
    wb.save(str(excel))
    assert games.market_status(games.find_market(games.get(game["id"]), market["id"]))["state"] == "changed"


def test_open_a_psd_of_a_listed_market_adds_a_version_to_it(game_folder):
    game = games.create(str(game_folder))
    nyl = game["markets"][0]
    psd, mem = _built_psd(game_folder, nyl["excel_path"])
    mem["identity"] = {"game_id": game["id"], "market_id": nyl["id"]}
    cfg = {}
    games.adopt_psd(cfg, psd, mem)
    after = games.get(game["id"])
    assert (cfg["active_game"], cfg["active_market"]) == (game["id"], nyl["id"])
    assert len(after["markets"]) == len(game["markets"])
    assert [v["psd_path"] for v in games.find_market(after, nyl["id"])["versions"]] == [os.path.abspath(psd)]
