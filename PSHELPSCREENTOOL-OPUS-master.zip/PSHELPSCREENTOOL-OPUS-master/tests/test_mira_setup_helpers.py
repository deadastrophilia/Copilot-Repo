"""MIRA AI-setup helpers: model picker, availability shape, status endpoints."""

import os
from unittest import mock

import pytest

from ps_autotypesetter import ai_assist
from ps_autotypesetter.ui_web.server import create_app


@pytest.fixture(scope="module")
def client(tmp_path_factory):
    session = os.path.join(str(tmp_path_factory.mktemp("session")), "session.json")
    app = create_app(session_file=session)
    return app.test_client()


def test_pick_model_prefers_configured_model():
    with mock.patch.object(ai_assist, "_installed_models", return_value=["qwen2.5:7b", "llama3.2"]):
        assert ai_assist._pick_model() == ai_assist.MODEL


def test_pick_model_falls_back_to_any_installed():
    with mock.patch.object(ai_assist, "_installed_models", return_value=["llama3.2"]):
        assert ai_assist._pick_model() == "llama3.2"


def test_pick_model_returns_configured_when_none_installed():
    with mock.patch.object(ai_assist, "_installed_models", return_value=[]):
        assert ai_assist._pick_model() == ai_assist.MODEL


def test_model_hint_mentions_pull_and_button():
    hint = ai_assist._mira_model_hint("qwen2.5:7b")
    assert "ollama pull qwen2.5:7b" in hint
    assert "Download AI model" in hint


def test_installed_models_empty_without_client():
    with mock.patch.object(ai_assist, "requests", None):
        assert ai_assist._installed_models(force=True) == []


class _BoomClient:
    def get(self, *args, **kwargs):
        raise OSError("connection refused")


def test_mira_available_offline_shape():
    with mock.patch.object(ai_assist, "requests", _BoomClient()):
        d = ai_assist.mira_available()
        assert d["ok"] is False
        assert d["ollama"] is False
        assert d["can_setup"] is True


class _NoModelClient:
    class _Resp:
        ok = True
        status_code = 200

        def json(self):
            return {"models": []}

    def get(self, *args, **kwargs):
        return self._Resp()


def test_mira_available_no_models_reports_model_missing():
    with mock.patch.object(ai_assist, "requests", _NoModelClient()):
        d = ai_assist.mira_available()
        assert d["ok"] is False
        assert d["ollama"] is True
        assert d["model_missing"] is True
        assert d["can_setup"] is True


def test_setup_status_idle_and_start(client):
    """GET reports idle; POST kicks off a worker thread without errors."""
    res = client.get("/api/mira/setup")
    assert res.status_code == 200
    assert res.get_json()["state"] == "idle"
    res = client.post("/api/mira/setup", json={})
    assert res.status_code == 200
    assert res.get_json()["ok"] is True
    res = client.get("/api/mira/setup")
    assert res.get_json()["state"] in ("queued", "running")


def test_find_ollama_exe_never_raises():
    exe = ai_assist.find_ollama_exe()
    assert exe is None or os.path.isfile(exe)


def test_setup_pipeline_rejects_failed_pull(tmp_path):
    """_pull_model gives a human-readable error when /api/pull fails."""
    class _FailResp:
        ok = False
        status_code = 500

        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

    class _FailPull:
        def post(self, *args, **kwargs):
            return _FailResp()

    with mock.patch.object(ai_assist, "requests", _FailPull()):
        with pytest.raises(RuntimeError, match="HTTP 500"):
            ai_assist._pull_model("qwen2.5:7b")