"""The paragraph's alignment: Photoshop's four Justify modes, and alignment / margins page by page.

Justify used to have one mode (Photoshop's "Justify last left"): on a page of one-line rows every line is
a paragraph's last, so it looked left aligned. Last line centred / right and Justify all are here too, and
the Canvas sets the alignment and the margins for all pages, this page or picked pages."""

import os

import numpy as np
import pytest
from openpyxl import Workbook
from PIL import Image

from ps_autotypesetter import png_builder

_LONG = ("Whenever three or more scatter symbols appear anywhere on the reels the free games feature is "
         "triggered and the player is awarded ten free games with all wins multiplied by two during the feature.")


def _workbook(path, sheets=("Features",)):
    wb = Workbook()
    wb.remove(wb.active)
    for name in sheets:
        ws = wb.create_sheet(name)
        for row in (["FEATURES"], [""], [_LONG]):
            ws.append(row)
    wb.save(path)
    return path


def _lines(tmp_path, alignment, ds=None, sheets=("Features",)):
    """Per sheet: [(left, right)] of each body line's ink, top to bottom."""
    path = _workbook(str(tmp_path / "j.xlsx"), sheets)
    out = png_builder.build_pngs_only(
        excel_path=path, icon_folder="", bg_path="", c_width=1280, c_height=720, max_col_limit=12,
        h_font="Arial", h_size=60, h_icon_h=48, h_rgb="#FFFFFF", b_font="Arial", b_size=30, b_icon_h=24,
        b_rgb="#FFFFFF", margin_x=100, line_spacing=4, para_spacing=12, gap_px=12, icon_y_offset=0,
        bg_mode="color", bg_color="#000000", heading_top_margin=60, continued_gap=15, heading_to_body_gap=40,
        bottom_margin=80, inner_canvas_width=0, page_min_row=1, page_max_row=100, page_min_col=1,
        page_max_col=12, page_overrides={}, dynamic_settings=dict(ds or {}), alignment_settings=alignment,
        output_dir=str(tmp_path / "out"), output_name=None)
    got = {}
    for name in sorted(n for n in os.listdir(out) if n.lower().endswith(".png")):
        a = np.asarray(Image.open(os.path.join(out, name)).convert("L"))
        ys = np.nonzero((a > 100).any(1))[0]
        groups = np.split(ys, np.nonzero(np.diff(ys) > 3)[0] + 1)[1:]          # the heading first
        got[name] = [tuple(np.nonzero((a[g[0]:g[-1] + 1] > 100).any(0))[0][[0, -1]].tolist()) for g in groups]
    return list(got.values())


def test_justify_line_align():
    j = png_builder.justify_line_align
    assert [j("justify", i, 3) for i in range(3)] == ["justify_all", "justify_all", "left"]
    assert j("justify_center", 2, 3) == "center" and j("justify_right", 0, 1) == "right"
    assert j("justify_all", 0, 1) == "justify_all" and j("center", 0, 3) == "center"


@pytest.mark.parametrize("mode, last", [("justify", "left"), ("justify_center", "center"),
                                        ("justify_right", "right"), ("justify_all", "full")])
def test_justify_modes_place_the_last_line(tmp_path, mode, last):
    lines = _lines(tmp_path, {"global": {"heading": "center", "body": mode}})[0]
    assert len(lines) >= 3
    left, right = min(l for l, _r in lines), max(r for _l, r in lines)
    for l, r in lines[:-1]:                                    # stretched to the box
        assert l <= left + 2 and r >= right - 3
    l, r = lines[-1]
    if last == "left":
        assert l <= left + 2 and r < right - 20
    elif last == "right":
        assert r >= right - 3 and l > left + 20
    elif last == "center":
        assert abs((l + r) / 2 - (left + right) / 2) <= 3 and l > left + 20
    else:
        assert l <= left + 2 and r >= right - 3


def test_alignment_and_margins_page_by_page(tmp_path):
    al = {"global": {"heading": "center", "body": "left"},
          "overrides": {"Two": {"use_global": False, "body": "right"}}}
    one, two = _lines(tmp_path, al, {"body_boxes": {"Two": {"left": 300, "right": 900}}}, sheets=("One", "Two"))
    assert min(l for l, _r in one) < 300                        # the project margins, left aligned
    assert max(r for _l, r in one) > 950
    assert all(r <= 902 for _l, r in two) and min(l for l, _r in two) >= 300
    assert len({r for _l, r in two}) <= 2                       # right aligned: one right edge
    assert png_builder._text_alignment(al, "two", "body") == "right"
    assert png_builder._text_alignment(al, "Two", "heading") == "center"
    assert png_builder._text_alignment({"global": {"heading": "justify_center"}}, "x", "heading") == "center"


def test_justify_button_treats_the_paragraph_box_as_one_paragraph(tmp_path):
    """The Canvas's Justify (justify_center): every line in the box stretched — one-line rows too — and
    only the box's very last line centred (the user's choice, 2026-10-29)."""
    wb = Workbook()
    ws = wb.active
    ws.title = "Symbols"
    for row in (["SYMBOLS"], [""], ["All wins begin with the leftmost reel."], ["Wild substitutes for all symbols."],
                ["Scatter pays in any position on the reels."], ["Malfunction voids all."]):
        ws.append(row)
    path = str(tmp_path / "s.xlsx")
    wb.save(path)
    out = png_builder.build_pngs_only(
        excel_path=path, icon_folder="", bg_path="", c_width=1280, c_height=720, max_col_limit=12,
        h_font="Arial", h_size=60, h_icon_h=48, h_rgb="#FFFFFF", b_font="Arial", b_size=30, b_icon_h=24,
        b_rgb="#FFFFFF", margin_x=100, line_spacing=4, para_spacing=12, gap_px=12, icon_y_offset=0,
        bg_mode="color", bg_color="#000000", heading_top_margin=60, continued_gap=15, heading_to_body_gap=40,
        bottom_margin=80, inner_canvas_width=0, page_min_row=1, page_max_row=100, page_min_col=1,
        page_max_col=12, page_overrides={}, dynamic_settings={},
        alignment_settings={"global": {"heading": "center", "body": "justify_center"}},
        output_dir=str(tmp_path / "out"), output_name=None)
    name = sorted(n for n in os.listdir(out) if n.lower().endswith(".png"))[0]
    a = np.asarray(Image.open(os.path.join(out, name)).convert("L"))
    ys = np.nonzero((a > 100).any(1))[0]
    groups = np.split(ys, np.nonzero(np.diff(ys) > 3)[0] + 1)[1:]
    lines = [tuple(np.nonzero((a[g[0]:g[-1] + 1] > 100).any(0))[0][[0, -1]].tolist()) for g in groups]
    left, right = min(l for l, _r in lines), max(r for _l, r in lines)
    for l, r in lines[:-1]:
        assert l <= left + 2 and r >= right - 3, lines
    l, r = lines[-1]
    assert l > left + 50 and abs((l + r) / 2 - (left + right) / 2) <= 3, lines
