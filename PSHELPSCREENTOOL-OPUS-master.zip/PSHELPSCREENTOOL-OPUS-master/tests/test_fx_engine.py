"""Photoshop-free layer-style engine: descriptor decoding (fx_descriptor), every
effect of ps_fx_png, the JS twin's parity, and the optional Photoshop verify
plumbing (fx_verify) — all without Photoshop."""

import io
import json
import os
import shutil
import subprocess

import numpy as np
import pytest
from PIL import Image, ImageFont

from ps_autotypesetter import fx_descriptor, fx_verify, ps_fx_png

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BZZF_PSD = os.path.join(ROOT, "PSDRef", "BZZF_blastBlueHelps.psd")
JS_ENGINE = os.path.join(ROOT, "ps_autotypesetter", "ui_web", "static", "ps_fx_canvas.js")
needs_bzzf = pytest.mark.skipif(not os.path.isfile(BZZF_PSD), reason="BZZF artist PSD not available")


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------


def _square(size=100, box=(30, 30, 70, 70), rgb=(0.2, 0.4, 0.9)):
    """Opaque coloured square layer on a transparent padded canvas (float RGBA)."""
    arr = np.zeros((size, size, 4), dtype=np.float32)
    x0, y0, x1, y1 = box
    arr[y0:y1, x0:x1, :3] = rgb
    arr[y0:y1, x0:x1, 3] = 1.0
    return arr


def _render(params, content=None, backdrop=None):
    return ps_fx_png.render_effects(_square() if content is None else content, params, backdrop)


def _lum(px):
    return float(px[0] + px[1] + px[2])


def _template_hex4(fx):
    """A real Photoshop effects descriptor (fx_template.bin edited by psd_writer)."""
    from ps_autotypesetter.psd_writer import effects

    payload = effects.params_payload(fx)
    return "".join("%04x" % b for b in payload[4:])


@pytest.fixture(scope="module")
def bzzf_wild(request):
    """(WILD layer raster, style) from the local BZZF PSD.

    psd-tools needs about a minute to parse that 86 MB file, so the extracted
    layer is remembered in pytest's local cache (.pytest_cache, gitignored),
    keyed by the file's size and mtime.
    """
    import base64

    st = os.stat(BZZF_PSD)
    key = f"fx_engine/bzzf_wild/{st.st_size}-{int(st.st_mtime)}"
    cache = getattr(request.config, "cache", None)
    hit = cache.get(key, None) if cache is not None else None
    if hit:
        img = Image.open(io.BytesIO(base64.b64decode(hit["png"]))).convert("RGBA")
        return img, {"effects_block": {"key": "lmfx", "hex": hit["hex"]}}
    from psd_tools import PSDImage
    from psd_tools.constants import Tag

    psd = PSDImage.open(BZZF_PSD)
    layer = next(l for l in psd.descendants() if l.name.strip() == "WILD")
    buf = io.BytesIO()
    layer.tagged_blocks[Tag.OBJECT_BASED_EFFECTS_LAYER_INFO_V0].data.write(buf)
    img = layer.topil().convert("RGBA")
    if cache is not None:
        png = io.BytesIO()
        img.save(png, "PNG")
        cache.set(key, {"hex": buf.getvalue().hex(), "png": base64.b64encode(png.getvalue()).decode("ascii")})
    return img, {"effects_block": {"key": "lmfx", "hex": buf.getvalue().hex()}}


# --------------------------------------------------------------------------
# descriptor decoding
# --------------------------------------------------------------------------


def test_decode_template_descriptor_roundtrip():
    hex4 = _template_hex4({
        "stroke_enabled": True, "stroke_rgb": [10, 20, 30], "stroke_size": 6, "stroke_opacity": 80,
        "shadow_enabled": True, "shadow_rgb": [200, 0, 0], "shadow_opacity": 55,
        "shadow_angle": 45, "shadow_distance": 7, "shadow_size": 9,
    })
    params = fx_descriptor.decode_effects_hex(hex4)
    assert params["source"] == "descriptor"
    st, ds = params["stroke"], params["drop_shadow"]
    assert st["color"] == [10, 20, 30] and st["size"] == 6 and st["opacity"] == 80
    assert ds["color"] == [200, 0, 0] and ds["angle"] == 45 and ds["distance"] == 7 and ds["size"] == 9
    assert ds["opacity"] == 55


def test_decode_accepts_all_hex_forms_and_rejects_garbage():
    hex4 = _template_hex4({"stroke_enabled": True, "stroke_size": 3})
    data = bytes(int(hex4[i:i + 4], 16) for i in range(0, len(hex4), 4))
    a = fx_descriptor.decode_effects_hex(hex4)                       # capture JSX form
    b = fx_descriptor.decode_effects_hex(data.hex())                 # plain byte hex
    c = fx_descriptor.decode_effects_hex((b"\x00\x00\x00\x00" + data).hex())   # lfx2 payload
    assert a == b == c and a["stroke"]["size"] == 3
    assert fx_descriptor.decode_effects_hex("") is None
    assert fx_descriptor.decode_effects_hex("0000") is None
    assert fx_descriptor.decode_effects_hex("deadbeef" * 8) is None


def test_disabled_effects_are_dropped():
    params = fx_descriptor.decode_effects_hex(_template_hex4({"stroke_enabled": True}))
    assert "stroke" in params and "drop_shadow" not in params


def test_effective_params_prefers_descriptor_and_keeps_opacity():
    hex4 = _template_hex4({"stroke_enabled": True, "stroke_size": 5})
    cfg = {"captured_effects_hex": hex4,
           "captured_params": {"opacity": 60, "fill_opacity": 0, "stroke": {"enabled": True, "size": 1}}}
    params = fx_descriptor.effective_params(cfg)
    assert params["stroke"]["size"] == 5
    assert params["opacity"] == 60 and params["fill_opacity"] == 0
    # no descriptor: the readable params are used as they are
    assert fx_descriptor.effective_params({"captured_params": {"stroke": {"size": 2}}}) == {"stroke": {"size": 2}}
    assert fx_descriptor.effective_params({"stroke_enabled": True}) is None


def test_enrich_style_keeps_bytes_and_adds_readable_params():
    hex4 = _template_hex4({"shadow_enabled": True})
    cfg = {"captured_effects_hex": hex4, "captured_params": {"opacity": 100}}
    out = fx_descriptor.enrich_style(cfg)
    assert out is not cfg and out["captured_effects_hex"] == hex4
    assert out["captured_params"]["drop_shadow"]["enabled"] is True
    assert cfg["captured_params"] == {"opacity": 100}        # the saved style is not mutated
    plain = {"stroke_enabled": True}
    assert fx_descriptor.enrich_style(plain) is plain


@needs_bzzf
def test_decode_bzzf_multi_effects(bzzf_wild):
    _, style = bzzf_wild
    p = fx_descriptor.effective_params(style)
    assert isinstance(p["drop_shadow"], list) and len(p["drop_shadow"]) == 5
    assert [s["color"] for s in p["drop_shadow"][:3]] == [[255, 246, 0], [252, 202, 0], [202, 0, 0]]
    assert p["drop_shadow"][4]["spread"] == 71 and p["drop_shadow"][4]["size"] == 27
    assert isinstance(p["stroke"], list) and len(p["stroke"]) == 4        # the disabled 5th is dropped
    assert p["stroke"][0]["position"] == "inside" and p["stroke"][0]["fill_type"] == "color"
    assert [s["size"] for s in p["stroke"]] == [3, 1, 4, 2]
    gold = p["stroke"][2]["gradient"]
    assert p["stroke"][2]["fill_type"] == "gradient" and len(gold["colors"]) == 10 and gold["angle"] == 90
    go = p["gradient_overlay"]
    assert go["colors"][0][0] == [236, 0, 0] and go["angle"] == -90
    bv = p["bevel"]
    assert (bv["style"], bv["technique"], bv["size"], bv["depth"]) == ("inner", "chisel_hard", 4, 126)
    assert (bv["angle"], bv["altitude"], bv["highlight_blend"], bv["shadow_blend"]) == (98, 32, "screen", "multiply")
    assert "inner_glow" not in p and "satin" not in p                   # present but disabled


# --------------------------------------------------------------------------
# normalization
# --------------------------------------------------------------------------


def test_normalize_lists_singles_and_legacy():
    N = ps_fx_png.normalize_params({
        "stroke": [{"enabled": True, "size": 2}, {"enabled": False}, {"enabled": True, "size": 5}],
        "drop_shadow": {"enabled": True, "blend": "multiply"},
    })
    assert [s["size"] for s in N["strokes"]] == [2, 5]
    assert N["stroke"]["size"] == 2 and N["drop_shadows"][0]["blend"] == "multiply"
    legacy = ps_fx_png.normalize_params({"stroke_enabled": True, "stroke_size": 4, "shadow_enabled": False})
    assert legacy["has_fx"] and legacy["strokes"][0]["size"] == 4 and not legacy["drop_shadows"]
    assert not ps_fx_png.normalize_params({})["has_fx"]
    assert not ps_fx_png.normalize_params(None)["has_fx"]


def test_normalize_reads_descriptor_from_full_config():
    hex4 = _template_hex4({"stroke_enabled": True, "stroke_size": 7})
    N = ps_fx_png.normalize_params({"captured_effects_hex": hex4})
    assert N["has_fx"] and N["strokes"][0]["size"] == 7


def test_blend_names():
    assert ps_fx_png._blend_code("Soft Light") == "soft-light"
    assert ps_fx_png._blend_code("MLTP") == "multiply"
    assert ps_fx_png._blend_code("linear dodge") == "linear-dodge"
    assert ps_fx_png._blend_code("lighter") == "linear-dodge"
    assert ps_fx_png._blend_code(None) == "normal"


# --------------------------------------------------------------------------
# primitives
# --------------------------------------------------------------------------


def test_distance_field_is_exact_euclidean():
    seed = np.zeros((21, 21), dtype=bool)
    seed[10, 10] = True
    d = ps_fx_png._edt(seed, 12)
    assert d[10, 10] == 0
    assert abs(d[10, 15] - 5) < 1e-5 and abs(d[13, 14] - 5) < 1e-5
    assert abs(d[0, 0] - min(13, np.hypot(10, 10))) < 1e-5     # capped at R + 1


def test_blur_preserves_mass_and_spreads():
    a = np.zeros((41, 41), dtype=np.float32)
    a[20, 20] = 1.0
    b = ps_fx_png.blur(a, 3.0)
    assert abs(float(b.sum()) - 1.0) < 1e-4
    assert b[20, 20] < 0.1 and b[20, 23] > 0


def test_shape_grow_and_shrink():
    shape = ps_fx_png._Shape(_square()[..., 3], 8)
    grown = shape.grow(4)
    assert grown[50, 27] == 1.0 and grown[50, 24] == 0.0      # 4 px outside the left edge
    shrunk = shape.shrink(4)
    assert shrunk[50, 35] == 1.0 and shrunk[50, 32] == 0.0


# --------------------------------------------------------------------------
# every effect
# --------------------------------------------------------------------------


def test_drop_shadow_offset_follows_photoshop_angle():
    out = _render({"drop_shadow": {"enabled": True, "color": [0, 0, 0], "opacity": 100,
                                   "angle": 120, "distance": 8, "size": 0, "blend": "normal"}})
    # light from the upper left (120 deg) -> shadow lower right
    # square 30..69 shifted by (+4, +7): (x=72, y=75) is shadow only, the upper left is clear
    assert out[75, 72, 3] > 0.99 and out[26, 26, 3] == 0
    assert out[50, 50, 2] > 0.85                                  # the fill stays on top


def test_drop_shadow_spread_and_blur():
    hard = _render({"drop_shadow": {"enabled": True, "distance": 0, "size": 10, "spread": 100, "opacity": 100}})
    soft = _render({"drop_shadow": {"enabled": True, "distance": 0, "size": 10, "spread": 0, "opacity": 100}})
    assert hard[50, 25, 3] > 0.99                                  # solid 10 px ring
    assert 0.05 < soft[50, 25, 3] < 0.8                            # blurred falloff


def test_multiple_shadows_paint_top_most_last():
    out = _render({"drop_shadow": [
        {"enabled": True, "color": [255, 0, 0], "opacity": 100, "distance": 0, "size": 4, "spread": 100},
        {"enabled": True, "color": [0, 255, 0], "opacity": 100, "distance": 0, "size": 8, "spread": 100},
    ]})
    assert out[50, 27, 0] > 0.99 and out[50, 27, 1] < 0.01        # red (index 0) on top near the edge
    assert out[50, 23, 1] > 0.99                                    # green ring beyond it


def test_outer_glow_surrounds_shape():
    out = _render({"outer_glow": {"enabled": True, "color": [255, 255, 0], "opacity": 100, "size": 10,
                                  "spread": 50, "blend": "normal"}})
    assert out[50, 27, 3] > 0.9 and out[50, 27, 0] > 0.99
    assert out[50, 5, 3] == 0


def test_inner_shadow_lands_on_the_lit_side_inner_edge():
    out = _render({"inner_shadow": {"enabled": True, "color": [0, 0, 0], "opacity": 100, "angle": 120,
                                    "distance": 5, "size": 4, "blend": "normal"}})
    assert _lum(out[33, 33]) < _lum(out[66, 66]) - 0.3
    assert out[20, 20, 3] == 0                                      # nothing outside the shape


def test_inner_glow_edge_and_center():
    edge = _render({"inner_glow": {"enabled": True, "color": [255, 255, 255], "opacity": 100, "size": 8,
                                   "blend": "normal", "range": 100}})
    center = _render({"inner_glow": {"enabled": True, "color": [255, 255, 255], "opacity": 100, "size": 8,
                                     "blend": "normal", "source": "center", "range": 100}})
    assert _lum(edge[50, 31]) > _lum(edge[50, 50]) + 0.5
    assert _lum(center[50, 50]) > _lum(center[50, 31]) + 0.5
    assert edge[50, 20, 3] == 0


def test_strokes_outside_inside_center():
    def st(pos):
        return _render({"stroke": {"enabled": True, "color": [255, 0, 0], "size": 4, "position": pos,
                                   "opacity": 100, "blend": "normal"}})
    out, ins, cen = st("outside"), st("inside"), st("center")
    assert out[50, 27, 0] > 0.99 and out[50, 32, 0] < 0.3          # ring outside, fill inside
    assert ins[50, 32, 0] > 0.99 and ins[50, 27, 3] == 0           # ring inside only
    assert cen[50, 29, 0] > 0.99 and cen[50, 31, 0] > 0.99 and cen[50, 26, 3] == 0


def test_gradient_stroke_follows_gradient():
    out = _render({"stroke": {"enabled": True, "size": 6, "position": "outside", "opacity": 100,
                              "fill_type": "gradient",
                              "gradient": {"colors": [[[255, 0, 0], 0], [[0, 0, 255], 100]], "angle": 90}}})
    assert out[72, 50, 0] > out[72, 50, 2]                          # bottom: first stop (red)
    assert out[27, 50, 2] > out[27, 50, 0]                          # top: last stop (blue)


def test_gradient_overlay_angle_reverse_and_midpoint():
    g = {"enabled": True, "opacity": 100, "angle": 90, "colors": [[[0, 0, 0], 0], [[255, 255, 255], 100]]}
    out = _render({"gradient_overlay": g})
    assert _lum(out[31, 50]) > 2.5 and _lum(out[68, 50]) < 0.5      # black bottom -> white top
    rev = _render({"gradient_overlay": dict(g, reverse=True)})
    assert _lum(rev[31, 50]) < 0.5
    mid = _render({"gradient_overlay": dict(g, colors=[[[0, 0, 0], 0], [[255, 255, 255], 100, 20]])})
    assert _lum(mid[50, 50]) > _lum(out[50, 50]) + 0.3              # midpoint pulled toward black stop


def test_gradient_types_and_transparency():
    stops = [[[255, 0, 0], 0], [[0, 0, 255], 100]]
    radial = _render({"gradient_overlay": {"enabled": True, "type": "radial", "colors": stops}})
    assert radial[50, 50, 0] > 0.95 and radial[31, 31, 2] > radial[31, 31, 0] - 0.2
    for gtype in ("angle", "reflected", "diamond"):
        out = _render({"gradient_overlay": {"enabled": True, "type": gtype, "colors": stops}})
        assert out[50, 50, 3] > 0.99
    faded = _render({"gradient_overlay": {"enabled": True, "angle": 0, "colors": stops,
                                          "transparency": [[100, 0], [0, 100]]}})
    assert faded[50, 32, 0] > 0.9                                    # opaque red at the left
    assert abs(faded[50, 68, 2] - 0.9) < 0.1                         # right: the fill shows through


def test_color_overlay_and_blend_mode():
    out = _render({"color_overlay": {"enabled": True, "color": [255, 0, 0], "opacity": 100, "blend": "normal"}})
    assert out[50, 50, 0] > 0.99 and out[50, 50, 2] < 0.01 and out[20, 20, 3] == 0
    mul = _render({"color_overlay": {"enabled": True, "color": [255, 128, 0], "opacity": 100, "blend": "multiply"}})
    assert abs(mul[50, 50, 1] - 0.4 * 128 / 255) < 0.02 and mul[50, 50, 2] < 0.01


def test_satin_changes_only_the_interior():
    plain = _render({"stroke": {"enabled": True, "size": 0.01, "opacity": 0}})
    out = _render({"satin": {"enabled": True, "color": [0, 0, 0], "opacity": 100, "angle": 45,
                             "distance": 10, "size": 6, "blend": "multiply"}})
    assert np.abs(out[30:70, 30:70, :3] - plain[30:70, 30:70, :3]).max() > 0.1
    assert out[20, 20, 3] == 0 and out[80, 80, 3] == 0


@pytest.mark.parametrize("technique", ["smooth", "chisel_hard", "chisel_soft"])
def test_inner_bevel_lights_the_lit_edge(technique):
    out = _render({"bevel": {"enabled": True, "style": "inner", "technique": technique, "size": 6,
                             "depth": 100, "angle": 135, "altitude": 30, "highlight_opacity": 100,
                             "shadow_opacity": 100}})
    base = _square()[50, 50]
    assert _lum(out[32, 50]) > _lum(base) + 0.2                     # top edge faces the light
    assert _lum(out[67, 50]) < _lum(base) - 0.2                     # bottom edge in shadow
    assert out[20, 20, 3] == 0
    if technique == "chisel_hard":
        assert np.allclose(out[50, 50, :3], base[:3], atol=0.01)     # flat top untouched


def test_bevel_direction_down_inverts():
    up = _render({"bevel": {"enabled": True, "style": "inner", "technique": "chisel_hard", "size": 6, "angle": 90}})
    down = _render({"bevel": {"enabled": True, "style": "inner", "technique": "chisel_hard", "size": 6,
                              "angle": 90, "direction": "down"}})
    assert _lum(up[32, 50]) > _lum(down[32, 50]) + 0.2


@pytest.mark.parametrize("style", ["outer", "emboss", "pillow"])
def test_outer_bevel_styles_reach_outside(style):
    out = _render({"bevel": {"enabled": True, "style": style, "technique": "smooth", "size": 8,
                             "angle": 90, "shadow_opacity": 100, "highlight_opacity": 100}})
    assert out[50, 27, 3] > 0.05                                     # lighting outside the shape
    assert ps_fx_png.effect_pad(ps_fx_png.normalize_params({"bevel": {"enabled": True, "style": style,
                                                                      "size": 8}})) >= 10


def test_fill_opacity_zero_keeps_effects_and_knocks_out_shadow():
    out = _render({"fill_opacity": 0,
                   "stroke": {"enabled": True, "color": [255, 0, 0], "size": 3, "opacity": 100},
                   "drop_shadow": {"enabled": True, "distance": 0, "size": 0, "spread": 100, "opacity": 100}})
    assert out[50, 50, 3] == 0                                       # fill hidden, shadow knocked out
    assert out[50, 28, 0] > 0.99


def test_multiply_shadow_blends_with_the_backdrop():
    back = np.zeros((100, 100, 4), dtype=np.float32)
    back[..., :3] = (1.0, 1.0, 0.0)
    back[..., 3] = 1.0
    out = _render({"drop_shadow": {"enabled": True, "color": [128, 128, 128], "opacity": 100, "distance": 0,
                                   "size": 4, "spread": 100, "blend": "multiply"}}, backdrop=back)
    ring = out[50, 29]
    assert abs(ring[0] - 128 / 255) < 0.02 and ring[2] < 0.01         # yellow * grey, not grey


def test_render_text_with_descriptor_style():
    from ps_autotypesetter import png_builder

    font = png_builder._load_font(ImageFont, "Arial", 40, bold=True)
    page = Image.new("RGBA", (300, 100), (255, 255, 255, 255))
    style = {"captured_effects_hex": _template_hex4({"stroke_enabled": True, "stroke_rgb": [255, 0, 0],
                                                     "stroke_size": 4})}
    assert ps_fx_png.render_captured_params_text(page, 20, 20, "Hi", font, (0, 0, 255), style)
    arr = np.asarray(page)
    red = (arr[..., 0] > 200) & (arr[..., 1] < 60) & (arr[..., 2] < 60)
    blue = (arr[..., 2] > 200) & (arr[..., 0] < 60)
    assert red.sum() > 50 and blue.sum() > 50
    assert not ps_fx_png.render_captured_params_text(page, 0, 0, "Hi", font, (0, 0, 0), {})


def test_render_layer_image_pads_for_effects():
    img = Image.new("RGBA", (20, 20), (0, 255, 0, 255))
    out, pad = ps_fx_png.render_layer_image(img, {"stroke": {"enabled": True, "size": 5}})
    assert pad >= 5 and out.size == (20 + 2 * pad, 20 + 2 * pad)
    assert ps_fx_png.render_layer_image(img, {}) == (None, 0)


@needs_bzzf
def test_bzzf_wild_style_renders_all_layers(bzzf_wild):
    img, style = bzzf_wild
    out, pad = ps_fx_png.render_layer_image(img, style)
    arr = np.asarray(out)
    assert arr[..., 3].max() == 255
    # the 15 px red shadow ring and the gold gradient stroke both show up
    assert ((arr[..., 0] > 180) & (arr[..., 1] < 40) & (arr[..., 3] > 200)).sum() > 200
    assert ((arr[..., 0] > 200) & (arr[..., 1] > 150) & (arr[..., 2] < 120)).sum() > 100


# --------------------------------------------------------------------------
# JS twin parity (static/ps_fx_canvas.js), when Node is available
# --------------------------------------------------------------------------


@pytest.mark.skipif(shutil.which("node") is None, reason="node not installed")
def test_js_engine_matches_python(tmp_path):
    cases = [
        {"drop_shadow": [{"enabled": True, "distance": 4, "size": 6, "spread": 20, "angle": 120},
                         {"enabled": True, "color": [255, 0, 0], "size": 3, "spread": 100}],
         "outer_glow": {"enabled": True, "size": 8, "spread": 10, "blend": "screen"},
         "stroke": [{"enabled": True, "size": 2, "position": "inside", "color": [0, 80, 0]},
                    {"enabled": True, "size": 4, "fill_type": "gradient",
                     "gradient": {"colors": [[[255, 0, 0], 0], [[0, 0, 255], 100, 30]], "angle": 30}}],
         "gradient_overlay": {"enabled": True, "type": "reflected", "angle": 60, "scale": 80,
                              "colors": [[[255, 255, 0], 0], [[255, 0, 255], 100]],
                              "transparency": [[100, 0], [40, 100]]},
         "bevel": {"enabled": True, "style": "inner", "technique": "chisel_hard", "size": 5, "angle": 98,
                   "altitude": 32, "depth": 126}},
        {"inner_glow": {"enabled": True, "size": 7, "spread": 20, "blend": "screen", "color": [255, 255, 0]},
         "inner_shadow": {"enabled": True, "distance": 4, "size": 5, "blend": "multiply"},
         "satin": {"enabled": True, "distance": 8, "size": 5, "angle": 45, "contour": [[0, 0], [128, 255], [255, 0]]},
         "color_overlay": {"enabled": True, "color": [40, 160, 255], "opacity": 50, "blend": "overlay"},
         "bevel": {"enabled": True, "style": "emboss", "technique": "smooth", "size": 6, "soften": 2,
                   "direction": "down"},
         "fill_opacity": 40},
    ]
    content = _square(64, (16, 20, 48, 44))
    content[28:36, 26:38, 3] = 0.0                                  # a hole: inner edges too
    content[20, 16:48, 3] = 0.5                                     # antialiased edge
    back = np.zeros_like(content)
    back[32:, :, :3] = (0.1, 0.3, 0.6)
    back[32:, :, 3] = 1.0
    content.tofile(tmp_path / "content.f32")
    back.tofile(tmp_path / "back.f32")
    (tmp_path / "cases.json").write_text(json.dumps({"w": 64, "h": 64, "params": cases}))
    script = tmp_path / "run.js"
    script.write_text(
        "const fs=require('fs');const PsFx=require(" + json.dumps(JS_ENGINE) + ");"
        "const d=" + json.dumps(str(tmp_path)) + ";const c=JSON.parse(fs.readFileSync(d+'/cases.json'));"
        "const rd=(f)=>{const b=fs.readFileSync(f);return new Float32Array(b.buffer,b.byteOffset,b.length/4);};"
        "const content=rd(d+'/content.f32'),back=rd(d+'/back.f32');"
        "c.params.forEach((p,i)=>{const o=PsFx.renderEffects(content,c.w,c.h,p,back,null);"
        "fs.writeFileSync(d+'/js_'+i+'.f32',Buffer.from(o.buffer));});"
    )
    subprocess.run(["node", str(script)], check=True, capture_output=True, timeout=60)
    for i, params in enumerate(cases):
        py = ps_fx_png.render_effects(content, params, back)
        js = np.fromfile(tmp_path / f"js_{i}.f32", dtype=np.float32).reshape(py.shape)
        assert float(np.abs(js - py).max()) < 1e-3, f"case {i} drifted between ps_fx_png and ps_fx_canvas.js"


def test_live_canvas_loads_the_js_engine():
    html = open(os.path.join(ROOT, "ps_autotypesetter", "ui_web", "static", "index.html"), encoding="utf-8").read()
    assert html.index("/static/ps_fx_canvas.js") < html.index("/static/visualiser_live.js")
    live = open(os.path.join(ROOT, "ps_autotypesetter", "ui_web", "static", "visualiser_live.js"), encoding="utf-8").read()
    assert "PsFx.renderImageData" in live


# --------------------------------------------------------------------------
# optional Photoshop verify plumbing (Photoshop mocked)
# --------------------------------------------------------------------------


def test_descriptor_hex4_for_every_style_kind():
    hex4 = _template_hex4({"stroke_enabled": True})
    assert fx_verify.descriptor_hex4({"captured_effects_hex": hex4}) == hex4
    flat = fx_verify.descriptor_hex4({"stroke_enabled": True, "stroke_size": 3})
    assert flat and fx_descriptor.decode_effects_hex(flat)["stroke"]["size"] == 3
    assert fx_verify.descriptor_hex4({"captured_params": {"stroke": {"enabled": True}}}) is None


def test_compare_identical_and_different():
    a = Image.new("RGBA", (10, 10), (255, 0, 0, 255))
    stats, diff = fx_verify.compare(a, a.copy())
    assert stats["mean_abs"] == 0 and stats["bad_pct"] == 0 and diff.size == (10, 10)
    stats, _ = fx_verify.compare(a, Image.new("RGBA", (10, 10), (0, 0, 255, 255)))
    assert stats["bad_pct"] == 100


def test_verify_layer_uses_the_same_pixels(monkeypatch):
    seen = {}
    style = {"captured_effects_hex": _template_hex4({"stroke_enabled": True, "stroke_size": 4}),
             "captured_params": {"fill_opacity": 50}}

    def fake_ps(src, hex4, opacity, fill, timeout=180, light=None):
        seen["size"], seen["hex"], seen["fill"], seen["light"] = src.size, hex4, fill, light
        return fx_verify.pil_render(src, style)

    monkeypatch.setattr(fx_verify, "photoshop_render", fake_ps)
    res = fx_verify.verify_layer(Image.new("RGBA", (30, 20), (0, 0, 255, 255)), style)
    assert res["stats"]["mean_abs"] == 0 and seen["size"] == res["tool"].size and seen["fill"] == 50
    with pytest.raises(fx_verify.VerifyError):
        fx_verify.verify_layer(Image.new("RGBA", (4, 4)), {"captured_params": {}})


def test_verify_endpoint(tmp_path, monkeypatch):
    from ps_autotypesetter.ui_web.server import create_app

    client = create_app(session_file=str(tmp_path / "session.json")).test_client()
    hex4 = _template_hex4({"stroke_enabled": True})
    res = client.post("/api/config", json={"dynamic_settings": {
        "layer_style_library": {"Gold": {"captured_effects_hex": hex4}},
        "style_assignments": {"Heading text": "Gold"}}})
    assert res.status_code == 200

    def fake_verify(style, **kw):
        img = Image.new("RGBA", (8, 8), (255, 0, 0, 255))
        return {"photoshop": img, "tool": img, "diff": img.convert("RGB"),
                "stats": {"mean_abs": 0.0, "bad_pct": 0.0, "alpha_mean_abs": 0.0, "covered_px": 64}}

    monkeypatch.setattr(fx_verify, "verify_text_style", fake_verify)
    data = client.post("/api/style-assets/verify", json={"role": "Heading text"}).get_json()
    assert data["ok"] and data["name"] == "Gold" and data["tool_png"].startswith("data:image/png;base64,")
    missing = client.post("/api/style-assets/verify", json={"name": "Nope"})
    assert missing.status_code == 400


def test_previews_do_not_use_photoshop_by_default(monkeypatch):
    from ps_autotypesetter import photoshop_style_assets as psa
    from ps_autotypesetter.config import set_photoshop_style_assets_enabled

    set_photoshop_style_assets_enabled(None)
    monkeypatch.delenv("PSH_USE_PHOTOSHOT_STYLE_ASSETS", raising=False)
    monkeypatch.setattr(psa, "photoshop_available", lambda: pytest.fail("previews must not probe Photoshop"))
    assert psa.photoshop_style_assets_enabled() is False
    out = str(Image and os.path.join(os.environ.get("TEMP", "."), "_fx_validation_test.png"))
    try:
        errors = []
        result = psa.render_validation_page(out, style_errors=errors)
        assert all(item["path"] == "pil" for item in result["elements"])
        assert not errors
    finally:
        if os.path.isfile(out):
            os.remove(out)


@needs_bzzf
def test_scale_effects_is_not_applied_to_effect_sizes():
    # a 300 dpi artist PSD stores "Scale Effects" 416.67 % (300 / 72) on every layer; Photoshop still draws
    # its 5 px stroke at 5 px (the composite it saves, and Photoshop 27.7 itself) — the tool once
    # multiplied, making strokes, shadows and glows 4x too big on the Canvas and in the PNG
    import sys

    sys.path.insert(0, os.path.join(ROOT, "tools"))
    import fx_fidelity_harness as H

    desc = H._bzzf_layers()["bzzf_wild"]["desc"]
    base = fx_descriptor.params_from_descriptor(fx_descriptor.read_descriptor(fx_descriptor.descriptor_bytes(H._hex4(desc))))
    desc[b"Scl "].value = 416.6666
    scaled = fx_descriptor.params_from_descriptor(fx_descriptor.read_descriptor(fx_descriptor.descriptor_bytes(H._hex4(desc))))
    assert json.dumps(scaled, sort_keys=True) == json.dumps(base, sort_keys=True)
