"""A paytable blueprint PSD (named shapes, no text) read as an editable card template: rows where the
artist drew them, the numbers where "pays and values" is, a SCATTER box only on sheets with a scatter."""
import os

import pytest

from ps_autotypesetter.artist_design import blueprint
from ps_autotypesetter.ui_web import engine_api

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PSD = r"E:\Work\ClaudeCode\DataForHelpScreenTool\Paytabke Template\Paytable-BPs.psd"
REF = os.path.join(ROOT, "ExcelFileForReference")


@pytest.fixture(scope="module")
def bp():
    if not os.path.isfile(PSD):
        pytest.skip("blueprint PSD not here")
    from psd_tools import PSDImage

    psd = PSDImage.open(PSD)
    assert blueprint.is_blueprint(psd)
    return blueprint.read_blueprint(psd, "Paytable BPs")


def _slots(t, excel, sheet):
    path = os.path.join(REF, excel)
    if not os.path.isfile(path):
        pytest.skip("reference Excel not here")
    res, _ = engine_api.auto_map_page(dict(engine_api.DEFAULT_CONFIG, excel_path=path), sheet, "", {"card_template": t, "dry_run": True})
    assert res["ok"], res.get("error")
    return res["_template"]["slots"]


def test_the_blueprint_is_read_as_rows_boxes_and_texts(bp):
    t, rep = bp
    assert rep["rows"] == [5, 6] and rep["boxes"] == ["scatter"] and rep["texts"] == 2
    assert t["page"]["title"]["plate"] is False                      # the heading is the other pages' heading
    hi, lo = t["bands"][0], t["bands"][1]
    assert (hi["per_row"], lo["per_row"]) == (5, 2)
    assert hi["pos"][1] < lo["pos"][1] and lo["lock_size"]
    nums = {p["role"]: p for p in hi["parts"]}
    assert nums["symbol"]["x"] + nums["symbol"]["w"] <= nums["counts"]["x"] <= nums["pays"]["x"]   # numbers on the right
    sec = t["scatter_section"]                                               # the SCATTER: a card of its own, in no row
    assert sec["enabled"] and sec["rect"][1] > sec["area"][1] and not t["features"]["enabled"]
    assert "grow_into" not in t["page"]["texts"][0] and t["page"]["texts"][1]["grow_into"] == ["scatter"]


def test_no_scatter_no_card_and_the_rules_take_its_place(bp):
    t, _ = bp
    s = _slots(t, "C2_Monopoly_AGR.xlsm", "Paytable")
    assert not any("scat" in k for k in s)
    box = t["scatter_section"]["area"]
    r = s["@slot.rules.t1"]
    assert r["x"] <= box[0] + 1 and r["w"] > box[2]


def test_a_scatter_is_its_own_card_where_drawn_and_fewer_cards_centre_in_their_row(bp):
    t, _ = bp
    s = _slots(t, "ThunderEmpire_MongolianEmpress_AGR_HHRE.xlsx", "Paytable-5lines")
    assert "@slot.scatbox" not in s and not any(k.startswith("@slot.scat.") and k.endswith(".card") for k in s)
    f, rect = s["@slot.scatsec"], t["scatter_section"]["rect"]
    assert (f["x"], f["y"], f["w"]) == pytest.approx(tuple(rect[:3]), abs=1)            # the frame where it was drawn
    assert s["@slot.scatsec.title"]["y"] < f["y"]                                     # its heading above it
    sym, num = s["@slot.scat"], s["@slot.scat.value"]
    assert sym["x"] < num["x"] and f["x"] <= sym["x"] and num["x"] + num["w"] <= f["x"] + f["w"]
    assert s["@slot.rules.t1"]["x"] == pytest.approx(t["page"]["texts"][1]["rect"][0], abs=1)   # stays where drawn
    top = sorted(v["x"] for k, v in s.items() if k.startswith("@slot.pic") and k.endswith(".card"))
    row = t["bands"][0]
    assert len(top) == 4 and top[0] > row["pos"][0] + 50                                     # 4 of 5: centred


def test_numbers_below_the_symbol_when_the_pays_box_is_a_strip():
    parts = {p["role"]: p for p in blueprint.card_parts({"x": 0.0, "y": 0.6, "w": 1.0, "h": 0.4})}
    assert parts["symbol"]["y"] + parts["symbol"]["h"] <= parts["counts"]["y"] + 0.01


def test_scatter_heading_and_caption_a_column_beside_the_symbol():
    from ps_autotypesetter.dynamic_pages.paytable import card_templates as ct
    cells = [("C64", "Scatter"), ("D66", "<SCAT>"), ("E66", "5"), ("C70", "pays in any position.")]
    assert ct._symbol_texts(cells, "scat", ["buffalo"]) == (("C64", "Scatter"), ("C70", "pays in any position."))


def test_the_rules_are_shared_over_the_text_boxes_in_reading_order(bp):
    t, _ = bp
    path = os.path.join(REF, "C2_Monopoly_AGR.xlsm")
    if not os.path.isfile(path):
        pytest.skip("reference Excel not here")
    res, _ = engine_api.auto_map_page(dict(engine_api.DEFAULT_CONFIG, excel_path=path), "Paytable", "", {"card_template": t, "dry_run": True})
    m = {x["slot"]: x for x in res["_mappings"]}
    top, side = m["@slot.text"].get("text") or "", m["@slot.rules.t1"].get("text") or ""
    assert top and side and top not in side and side not in top




def test_two_scatters_share_the_scatter_card_and_ten_is_never_a_scatter(bp):
    t, _ = bp
    s = _slots(t, "CE_Legend_Buffalo_GameRules_NYL.xlsm", "PAYTABLE")
    f = s["@slot.scatsec"]
    for k in ("@slot.buffalobgscatter", "@slot.buffalofgscatter"):
        assert f["x"] <= s[k]["x"] and s[k]["x"] + s[k]["w"] <= f["x"] + f["w"]
    assert "@slot.scatsec" not in _slots(t, "C2_Monopoly_AGR.xlsm", "Paytable")        # its <10> is the grid's TEN


def test_a_blueprint_gives_places_only_never_its_shapes_looks(bp):
    t, _ = bp
    assert t["styles"]["card"] == blueprint.LOOKS["card"] and t["styles"]["scatter_frame"] == blueprint.LOOKS["scatter"]
    assert all("bg" not in x for x in t["page"]["texts"])                      # no black panels behind the text
    assert t["page"]["title"]["plate"] is False                                  # the heading: the pages' own, no box
