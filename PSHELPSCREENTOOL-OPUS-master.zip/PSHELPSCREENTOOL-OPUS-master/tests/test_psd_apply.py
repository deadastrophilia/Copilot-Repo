"""psd_apply: the clone's changes as ops, carried out by the record executor."""
import json
import os

import pytest
from openpyxl import Workbook

from ps_autotypesetter import market_clone as mc
from ps_autotypesetter.psd_apply import OPS, Layers
from ps_autotypesetter.psd_apply.records import RecordExecutor


def _book(path, rows):
    wb = Workbook()
    wb.active.title = "Features"
    for row in rows:
        wb.active.append(row)
    wb.save(path)
    return str(path)


@pytest.fixture
def tool_psd(tmp_path):
    pytest.importorskip("photoshopapi")
    from ps_autotypesetter.psd_writer import build as psd_build
    from ps_autotypesetter.ui_web import engine_api

    a = _book(tmp_path / "Game NYL.xlsx", [["FREE SPINS"], ["Three scatters award 10 free spins."],
                                           ["Wins are multiplied by the bet multiplier."]])
    b = _book(tmp_path / "Game HHR.xlsx", [["FREE SPINS"], ["Bonus spins can be bought."],
                                           ["Four scatters award 12 free spins."],
                                           ["Wins are multiplied by the bet multiplier."]])
    cfg = {"excel_path": a, "icon_folder": "", "bg_path": "", "bg_source": "color", "bg_color": "#102040",
           "output_dir": str(tmp_path / "out"), "output_name": "Game NYL", "render_all_pages": True,
           "c_width": 1280, "c_height": 720}
    return psd_build.build_psd(**engine_api._build_kwargs(cfg), output_format="PSD"), a, b


def test_the_clone_writes_its_changes_down_as_ops(tool_psd, tmp_path):
    src, a, b = tool_psd
    shown = mc.preview(src, a, b, str(tmp_path / "preview"), draw=False)
    ops = shown["_plan"]["_ops"]
    kinds = [op["op"] for op in ops]
    assert set(kinds) <= set(OPS)
    assert "set_text" in kinds and "add_row" in kinds and kinds[-1] == "continue_if_over"
    json.dumps(ops)                                     # ready to hand to another engine (Photoshop)
    text = next(op for op in ops if op["op"] == "set_text")
    assert text["old"].startswith("Three scatters") and text["text"].startswith("Four scatters")
    row = next(op for op in ops if op["op"] == "add_row")
    assert row["text"] == "Bonus spins can be bought." and "layer" in row["template"]
    # every layer an op names is a layer of the PSD it was planned on (IDs given in memory)
    psd = shown["_psd"]
    ids = {l.layer_id for l in psd.descendants()}
    assert text["layer"] in ids and row["template"]["layer"] in ids and row["page"] in ids


class _L:
    def __init__(self, lid, name):
        self.layer_id, self.name = lid, name


class _Psd:
    def __init__(self, layers):
        self.layers = layers

    def descendants(self):
        return iter(self.layers)

    def __iter__(self):
        return iter(self.layers)


def test_a_layer_is_found_by_id_or_by_place_when_ids_repeat():
    unique = Layers(_Psd([_L(7, "a"), _L(9, "b")]))
    assert unique.get({"layer": 9, "place": 0}).name == "b"            # the ID wins over a stale place
    repeated = Layers(_Psd([_L(-1, "a"), _L(-1, "b"), _L(4, "c")]))
    assert repeated.get({"layer": -1, "place": 1}).name == "b"
    assert repeated.get({"layer": -1, "place": 2}) is None             # that place holds another layer
    assert repeated.get({"layer": 5, "place": 0}) is None


def test_a_layer_changed_since_the_plan_is_left_to_the_artist(tool_psd):
    from ps_autotypesetter.artist_design import psd_reader

    src, _a, _b = tool_psd
    psd = psd_reader.open_lazy(src)
    layers = list(psd.descendants())
    n, layer = next((n, l) for n, l in enumerate(layers) if l.kind == "type")
    plan = {"items": [{"old": "not what it says", "new": "x", "status": "change"}]}
    op = {"op": "set_text", "layer": layer.layer_id, "place": n, "old": "not what it says", "text": "x",
          "ref": ["items", 0]}
    assert RecordExecutor(psd, plan).apply_text_ops([op]) == 0
    assert plan["items"][0]["status"] == "artist" and plan["text_engine"] in ("none", "untouched")
    assert os.path.isfile(src)


# ── the Photoshop executor's Python side (Photoshop itself is never driven by tests) ──
def _expand(runs, n):
    out = [None] * n
    for a, b, first, step in runs:
        for k in range(a, b):
            out[k] = first + (k - a) * step
    return out


@pytest.mark.parametrize("old,new", [
    ("Three scatters award 10 free spins.", "Four scatters award 12 free spins."),
    ("5\r4\r3\r2", "5\r4\r3"),
    ("BONUS BOOSTTM FEATURES", "BONUS BOOSTTM EXTRAS"),
    ("abc", "xabcy"),
])
def test_photoshop_gets_the_style_every_character_takes(old, new):
    from ps_autotypesetter.psd_apply import photoshop as ps

    want = mc._carry(old, new, list(range(len(old))))
    assert _expand(ps._carry_runs(old, new), len(new)) == want


def test_photoshop_is_given_one_text_op_per_layer_and_no_rows():
    from ps_autotypesetter.psd_apply import photoshop as ps

    class Layer:
        def __init__(self, lid, text):
            self.layer_id, self.text = lid, text

    class Psd:
        def descendants(self):
            return iter([Layer(5, "Four scatters award 12 free spins!"), Layer(6, "unchanged")])

    plan = {"items": [{"layer_id": 5, "old": "Three scatters award 10 free spins.", "status": "change"}],
            "rows_added": [{"row": 4}], "_source_ids": {1, 5, 6},
            "_ops": [{"op": "copy_page", "group": 1, "above": None, "name": "x", "color": "green", "pairs": [[1, 50]]},
                     {"op": "set_text", "layer": 5, "old": "Three scatters award 10 free spins.", "text": "Four…",
                      "ref": ["items", 0]},
                     {"op": "edit_text", "layer": 5, "key": "k", "text": "Four scatters award 12 free spins!"},
                     {"op": "add_row", "ref": ["rows_added", 0]},
                     {"op": "continue_if_over", "page": 1, "page_key": 1, "sheet": "S", "limit": 900},
                     {"op": "label", "group": 50, "color": "yellow"},
                     {"op": "label", "group": 777, "color": "green"}]}
    ops, skipped = ps.payload(Psd(), plan)
    assert [op["op"] for op in ops] == ["copy_page", "set_text", "label"]
    text = ops[1]
    assert text["text"] == "Four scatters award 12 free spins!" and text["old"].startswith("Three")   # the final text
    assert [op["op"] for op in skipped] == ["add_row", "continue_if_over", "label"]   # 777: a page made in memory only
    ps.merge(plan, ops, skipped, {"results": [{"ok": True}, {"ok": False, "why": "font not installed on this PC: X"},
                                              {"ok": True}]})
    assert plan["items"][0]["status"] == "artist" and "font not installed" in plan["items"][0]["why"]
    assert plan["rows_added"][0]["status"] == "artist"


def test_a_photoshop_that_does_not_answer_is_reported_not_waited_for(monkeypatch):
    import time

    from ps_autotypesetter import photoshop_bridge
    from ps_autotypesetter.psd_apply import photoshop as ps

    monkeypatch.setenv("PSH_TEST_PHOTOSHOP", "1")
    monkeypatch.setattr(photoshop_bridge, "running_photoshops", lambda: [(1, "Photoshop.exe")])
    monkeypatch.setattr(photoshop_bridge, "run_jsx", lambda *a, **k: time.sleep(5))
    t = time.perf_counter()
    with pytest.raises(ps.PhotoshopBusy):
        ps.ready(timeout=0.5)
    assert time.perf_counter() - t < 3


def test_a_clone_asked_for_photoshop_says_why_the_tool_made_it(tool_psd, tmp_path):
    src, a, b = tool_psd
    report = mc.clone(src, a, b, str(tmp_path / "out.psd"), pictures=False, engine="photoshop")
    assert report["engine"] == "records" and "Photoshop" in report["engine_note"]
    assert os.path.isfile(str(tmp_path / "out.psd"))
