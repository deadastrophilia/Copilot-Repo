"""Tests for auto-extending card slots when a sheet has more cards than the
template's paytable slots (e.g. 12 symbols on a 10-slot template)."""

from ps_autotypesetter.dynamic_pages.paytable.auto_extend import auto_extend_card_slots


def _renderer_aliases(card, index, card_type, top_count=0):
    key = card.get("slot_key") or str(card.get("label") or "").casefold()
    global_index = int(index) if card_type == "top" else int(top_count) + int(index)
    aliases = {
        str(key).casefold(),
        f"pic{global_index}".casefold(),
        f"symbol.{global_index}".casefold(),
        f"symbol{global_index}".casefold(),
        f"{card_type}.{index}".casefold(),
    }
    if card_type != "top":
        aliases.update({f"low.{index}", f"lower.{index}", f"bottom.{index}"})
    return aliases


def _make_slots():
    slots = {}
    for n in range(1, 11):  # 10-slot template: top pic1..5, lower pic6..10
        slots[f"pic{n}"] = {"x": 0, "y": (n - 1) * 120, "w": 400, "h": 100}
        slots[f"pic{n}.pay"] = {"x": 0, "y": (n - 1) * 120 + 60, "w": 200, "h": 40}
        slots[f"pic{n}.value"] = {"x": 200, "y": (n - 1) * 120 + 60, "w": 200, "h": 40}
    return slots


def _cards(count, start_label="sym"):
    return [{"label": f"{start_label}{i}", "slot_key": "", "payouts": []} for i in range(1, count + 1)]


def test_fewer_cards_adds_nothing():
    slots = _make_slots()
    page_data = {"top_cards": _cards(4), "lower_cards": _cards(5)}
    original_keys = set(slots)
    added = auto_extend_card_slots(slots, page_data, lambda s, c, i, tc: _find(s, c, i, "lower"), _renderer_aliases, card_type="lower")
    assert added == 0
    assert set(slots) == original_keys


def _find(slots, card, index, card_type, top_count=0):
    candidates = _renderer_aliases(card, index, card_type, top_count)
    for alias in candidates:
        if alias in {str(k).casefold() for k in slots}:
            return slots[alias]
    return None


def test_extra_lower_cards_clone_last_matched_row():
    slots = _make_slots()
    page_data = {"top_cards": _cards(5), "lower_cards": _cards(7)}
    added = auto_extend_card_slots(
        slots, page_data,
        lambda s, c, i, tc: _find(s, c, i, "lower", tc),
        _renderer_aliases, card_type="lower", top_count=5,
    )
    # 2 extra cards x (1 base + 2 sub-slots) x 7 aliases each
    assert added == 2 * 3 * len(_renderer_aliases(_cards(1)[0], 6, "lower", 5))
    # New rows continue the template's own pitch below the last matched row
    # (pic10 bottom = 10*120 = 1200, pitch from pic9 -> pic10 = 120).
    box11 = slots["pic11"]
    assert box11["y"] == 10 * 120
    assert slots["pic11.pay"]["y"] == 10 * 120 + 60
    box12 = slots["pic12"]
    assert box12["y"] == 11 * 120
    # Generic continuous aliases are registered too, matching the finders
    assert slots["symbol.11"]["y"] == 10 * 120
    assert slots["symbol.12"]["y"] == 11 * 120
    # Real template slots are never overwritten by clones
    assert slots["pic6"]["y"] == 5 * 120


def test_gap_setting_shifts_rows():
    slots = _make_slots()
    page_data = {"top_cards": [], "lower_cards": _cards(6)}
    auto_extend_card_slots(
        slots, page_data,
        lambda s, c, i, tc: _find(s, c, i, "lower", tc),
        _renderer_aliases, card_type="lower", settings={"extra_card_gap_v": 30},
        top_count=5,
    )
    # Explicit gap overrides the template's own row pitch (120): 1080 + 100 + 30
    assert slots["pic11"]["y"] == 9 * 120 + 100 + 30


def test_canvas_overflow_stops_cloning():
    slots = _make_slots()
    page_data = {"top_cards": [], "lower_cards": _cards(9)}
    added = auto_extend_card_slots(
        slots, page_data,
        lambda s, c, i, tc: _find(s, c, i, "lower", tc),
        _renderer_aliases, card_type="lower", canvas_height=10 * 120 + 110,
        top_count=5,
    )
    # Anchored on pic10 (y=1080, h=100). pic11 at 1180 fits under 1310 but
    # pic12 at 1280 + 100 = 1380 would overflow -> exactly one extra row.
    assert added == 1 * 3 * len(_renderer_aliases(_cards(1)[0], 6, "lower"))