"""A mapped icon token whose name has a space is never broken across two lines."""
import re

from ps_autotypesetter import png_builder as png


def _words(text, mapped):
    return png._keep_tokens(re.split(r"(\s+)", text), lambda t: t in mapped)


def test_a_mapped_token_with_a_space_is_one_word():
    words = _words("If all 4 are active, <Feature Gem> or <Coin> may appear.", {"Feature Gem", "Coin"})
    assert "<Feature Gem>" in words
    assert "".join(words) == "If all 4 are active, <Feature Gem> or <Coin> may appear."


def test_tokens_written_against_text_stay_whole():
    words = _words("x <Feature Gem>or<Double Feature Coin> y", {"Feature Gem", "Double Feature Coin"})
    assert "<Feature Gem>or<Double Feature Coin>" in words


def test_a_token_that_is_not_mapped_breaks_like_text():
    words = _words("a <Double Blue Gem> b", set())
    assert "<Double" in words and "Gem>" in words


def test_one_copy_of_a_symbol_in_a_paytable_text_has_its_own_size():
    from ps_autotypesetter.ui_web import ps_actions

    scales = {"MUMMY": "40px", "MUMMY#1": "90px"}
    assert ps_actions.icon_height_for(scales, "<Mummy>", 30, 0) == 40
    assert ps_actions.icon_height_for(scales, "<Mummy>", 30, 1) == 90
    assert ps_actions.icon_height_for(scales, "<Mummy>", 30) == 40
