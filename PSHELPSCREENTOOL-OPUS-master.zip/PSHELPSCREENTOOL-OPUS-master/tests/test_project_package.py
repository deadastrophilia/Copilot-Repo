"""Tests for the project package system (MyGame.project.json + MyGame_Links/)."""

import json
import os

import pytest

from ps_autotypesetter import project_package as pp


@pytest.fixture
def game_folder(tmp_path):
    folder = tmp_path / "Game"
    folder.mkdir()
    (folder / "mapped_paytables").mkdir()
    (folder / "mapped_tables").mkdir()
    (folder / "Game.xlsx").write_text("x", encoding="utf-8")
    (folder / "mapped_paytables" / "MyGame_mapped.json").write_text(
        json.dumps({"template_id": "MyGame", "canvas": {"width": 1920, "height": 1080}, "slots": {"@slot.a": {"x": 1}}}),
        encoding="utf-8",
    )
    (folder / "mapped_tables" / "t1_mapped.json").write_text(
        json.dumps({"table_templates": {"t1": {"source_sheets": ["Paytable"]}}}),
        encoding="utf-8",
    )
    return folder


def _touch(path):
    path.write_text("fake psd", encoding="utf-8")
    return str(path)


def _cfg(folder):
    return {
        "excel_path": str(folder / "Game.xlsx"),
        "output_dir": str(folder),
        "c_width": 1920,
        "c_height": 1080,
        "dynamic_settings": {"template_json": str(folder / "mapped_paytables" / "MyGame_mapped.json")},
        "table_style": {"mapped_table_jsons": str(folder / "mapped_tables" / "t1_mapped.json")},
    }


def _load_json(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def test_package_structure(game_folder):
    psd = _touch(game_folder / "MyGame.psd")
    cfg = _cfg(game_folder)
    result = pp.write_project_package(cfg, psd)
    assert result["ok"] is True, result.get("error")

    expected = {
        "MyGame.project.json",
        "MyGame_Links/project/project.json",
        "MyGame_Links/config/config.json",
        "MyGame_Links/pages/pages.json",
        "MyGame_Links/typography/typography.json",
        "MyGame_Links/styles/styles.json",
        "MyGame_Links/layouts/tables/t1_mapped.json",
        "MyGame_Links/layouts/paytables/MyGame_mapped.json",
        "MyGame_Links/layouts/paylines/paylines.json",
        "MyGame_Links/renderer/renderer.json",
        "MyGame_Links/assets/assets.json",
        "MyGame_Links/history/history.json",
    }
    found = set()
    for root, _dirs, files in os.walk(game_folder):
        for fn in files:
            found.add(os.path.relpath(os.path.join(root, fn), game_folder).replace(os.sep, "/"))
    for item in expected:
        assert item in found, f"missing package file: {item}"


def test_manifest_schema(game_folder):
    psd = _touch(game_folder / "MyGame.psd")
    pp.write_project_package(_cfg(game_folder), psd)
    m = _load_json(game_folder / "MyGame.project.json")
    assert m["schema_version"] == pp.SCHEMA_VERSION
    assert m["project_name"] == "MyGame"
    assert m["project_id"]
    assert m["files"]["psd"]["absolute"] == str(psd)
    assert m["files"]["psd"]["relative"] == "MyGame.psd"
    assert m["files"]["links_folder"]["relative"] == "MyGame_Links"
    assert m["configuration"]["config"].endswith("config/config.json")


def test_snapshot_repoints_template_to_links(game_folder):
    psd = _touch(game_folder / "MyGame.psd")
    pp.write_project_package(_cfg(game_folder), psd)
    snapshot = _load_json(game_folder / "MyGame_Links" / "config" / "config.json")
    tpl = snapshot["dynamic_settings"]["template_json"]
    assert "MyGame_Links" in tpl
    assert os.path.isfile(tpl)
    tables = snapshot["table_style"]["mapped_table_jsons"]
    assert "MyGame_Links" in tables
    assert os.path.isfile(tables.strip().splitlines()[0])


def test_project_id_stable_through_refresh(game_folder):
    psd = _touch(game_folder / "MyGame.psd")
    pp.write_project_package(_cfg(game_folder), psd)
    first = _load_json(game_folder / "MyGame.project.json")["project_id"]
    pp.write_project_package(_cfg(game_folder), psd)
    second = _load_json(game_folder / "MyGame.project.json")["project_id"]
    assert first == second


def test_project_id_stable_after_rename(game_folder):
    psd_a = _touch(game_folder / "A.psd")
    pp.write_project_package(_cfg(game_folder), psd_a)
    id_a = _load_json(game_folder / "A.project.json")["project_id"]
    os.remove(psd_a)

    psd_b = _touch(game_folder / "B.psd")
    pp.write_project_package(_cfg(game_folder), psd_b)
    id_b = _load_json(game_folder / "B.project.json")["project_id"]
    assert id_a == id_b
    assert (game_folder / "B_Links").is_dir()
    assert not (game_folder / "A_Links").exists()


def test_load_restores_config_and_links(game_folder):
    psd = _touch(game_folder / "MyGame.psd")
    pp.write_project_package(_cfg(game_folder), psd)
    session = {"recent_projects": [{"folder": "x"}], "prev_psd_path": ""}
    result = pp.load_project(str(game_folder / "MyGame.project.json"), session)
    assert result["ok"] is True
    cfg = result["config"]
    assert cfg["excel_path"] == str(game_folder / "Game.xlsx")
    assert cfg["prev_psd_path"] == str(psd)
    assert "MyGame_Links" in cfg["dynamic_settings"]["template_json"]
    assert cfg["recent_projects"] == session["recent_projects"]
    project = result["project"]
    assert project["project_id"]
    assert project["project_name"] == "MyGame"


def test_load_missing_manifest_error(game_folder):
    result = pp.load_project(str(game_folder / "Nope.project.json"), {})
    assert result["ok"] is False
    assert result["error"] == "Project configuration file not found."


def test_load_incomplete_error(game_folder):
    manifest = game_folder / "OnlyManifest.project.json"
    manifest.write_text(json.dumps({"schema_version": 1, "files": {}}), encoding="utf-8")
    result = pp.load_project(str(manifest), {})
    assert result["ok"] is False
    assert result["error"] == "Project configuration is incomplete."


def test_load_corrupt_manifest_not_overwritten(game_folder):
    manifest = game_folder / "Bad.project.json"
    manifest.write_text("{not json", encoding="utf-8")
    result = pp.load_project(str(manifest), {})
    assert result["ok"] is False
    assert "corrupted" in result["error"]
    assert manifest.read_text(encoding="utf-8") == "{not json"


def test_load_corrupt_links_config(game_folder):
    psd = _touch(game_folder / "MyGame.psd")
    pp.write_project_package(_cfg(game_folder), psd)
    cfg_path = game_folder / "MyGame_Links" / "config" / "config.json"
    cfg_path.write_text("{broken", encoding="utf-8")
    result = pp.load_project(str(game_folder / "MyGame.project.json"), {})
    assert result["ok"] is False
    assert "corrupted" in result["error"]
    assert cfg_path.read_text(encoding="utf-8") == "{broken"


def test_detect_for_psd(game_folder):
    assert pp.detect_for_psd(str(game_folder / "None.psd")) is None
    psd = _touch(game_folder / "MyGame.psd")
    pp.write_project_package(_cfg(game_folder), psd)
    path = pp.detect_for_psd(str(psd))
    assert path and os.path.isfile(path)


def test_manifest_paths_naming():
    assert pp.manifest_path_for_psd("C:/x/A.psd") == "C:/x/A.project.json"
    assert pp.links_dir_for_psd("C:/x/A.psd") == "C:/x/A_Links"
    assert pp.manifest_path_for_psd("") is None


# ---------------------------------------------------------------------------
# API level (Flask test client)
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def client(tmp_path_factory):
    from ps_autotypesetter.ui_web.server import create_app

    session = os.path.join(str(tmp_path_factory.mktemp("session")), "session.json")
    app = create_app(session_file=session)
    return app.test_client()


def test_api_detect_no_manifest(client):
    res = client.post("/api/project/detect", json={"psd": "C:/no/such/MyGame.psd"})
    data = res.get_json()
    assert data["ok"] is True
    assert data["exists"] is False


def test_api_detect_requires_psd(client):
    res = client.post("/api/project/detect", json={})
    assert res.status_code == 400


def test_api_project_load_missing_manifest(client):
    res = client.post("/api/project/load", json={"path": "C:/no/such/MyGame.project.json"})
    assert res.status_code == 400
    assert res.get_json()["error"] == "Project configuration file not found."


def test_api_project_detect_load_save_roundtrip(client, game_folder):
    psd = _touch(game_folder / "Test.psd")
    pp.write_project_package(_cfg(game_folder), psd)

    det = client.post("/api/project/detect", json={"psd": psd}).get_json()
    assert det["exists"] is True
    assert det["project_name"] == "Test"

    with open(game_folder / "Test.project.json", encoding="utf-8") as f:
        id_before = json.load(f)["project_id"]

    loaded = client.post("/api/project/load", json={"path": str(game_folder / "Test.project.json")}).get_json()
    assert loaded["ok"] is True
    assert loaded["project"]["project_name"] == "Test"
    assert loaded["project"]["project_id"] == id_before
    assert loaded["config"]["prev_psd_path"] == str(psd)
    assert "Test_Links" in loaded["config"]["dynamic_settings"]["template_json"]

    saved = client.post("/api/project/save", json={"psd": psd}).get_json()
    assert saved["ok"] is True
    with open(game_folder / "Test.project.json", encoding="utf-8") as f:
        assert json.load(f)["project_id"] == id_before


def test_api_project_save_missing_psd(client):
    res = client.post("/api/project/save", json={})
    assert res.status_code == 400


def test_api_project_load_corrupt(client, game_folder):
    manifest = game_folder / "Bad.project.json"
    manifest.write_text("{nope", encoding="utf-8")
    res = client.post("/api/project/load", json={"path": str(manifest)})
    assert res.status_code == 400
    assert "corrupted" in res.get_json()["error"]
    assert manifest.read_text(encoding="utf-8") == "{nope"