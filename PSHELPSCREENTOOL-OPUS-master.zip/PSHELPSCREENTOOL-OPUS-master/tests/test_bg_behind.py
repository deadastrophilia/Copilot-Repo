"""What the background picture leaves uncovered is transparent, unless "Colour behind" is on."""
from PIL import Image

from ps_autotypesetter import bg_place
from ps_autotypesetter import png_builder as png


def test_behind_is_transparent_unless_switched_on():
    assert bg_place.behind({"bg_color": "#FFFFFF"}) == ""
    assert bg_place.behind({"bg_color": "#112233", "bg_behind_fill": True}) == "#112233"
    assert bg_place.behind({"bg_source": "color", "bg_color": "#445566"}) == "#445566"


def _page(tmp_path, mode, behind):
    pic = tmp_path / "bg.png"
    Image.new("RGBA", (50, 20), (200, 0, 0, 255)).save(pic)
    page = Image.new("RGBA", (100, 100), (255, 255, 255, 255))      # a build page starts white
    png._paint_background(page, Image, str(pic), mode, behind)
    return page


def test_around_a_fit_picture_is_transparent(tmp_path):
    page = _page(tmp_path, "fit_width:top", "")
    assert page.getpixel((50, 99))[3] == 0
    assert page.getpixel((50, 10)) == (200, 0, 0, 255)


def test_around_a_picture_in_the_colour_behind(tmp_path):
    page = _page(tmp_path, "center", "#000000")
    assert page.getpixel((2, 2)) == (0, 0, 0, 255)
    assert page.getpixel((50, 50)) == (200, 0, 0, 255)
