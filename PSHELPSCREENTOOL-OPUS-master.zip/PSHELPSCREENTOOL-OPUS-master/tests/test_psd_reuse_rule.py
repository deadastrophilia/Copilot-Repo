"""PSD doc-acquisition rule: the COM engine must only reuse/open the previous
PSD when the user-given output name matches the PSD file name. If the names
differ — or some unrelated file is open in Photoshop — the build must create
a SEPARATE new document instead of writing into whatever PSD is open."""

import ps_autotypesetter.build_engine as be


def test_reuse_when_names_match_plain():
    assert be._psd_reuse_previous("MyGame", r"D:\out\MyGame.psd") is True


def test_reuse_when_names_match_case_and_ext_insensitive():
    assert be._psd_reuse_previous("MYGAME.psd", r"D:\out\mygame.psb") is True


def test_no_reuse_when_typed_name_differs():
    assert be._psd_reuse_previous("BrandNew", r"D:\out\OldName.psd") is False
    assert be._psd_reuse_previous("OldName", r"D:\out\BrandNew.psd") is False


def test_no_reuse_when_previous_missing():
    assert be._psd_reuse_previous("Any", "") is False
    assert be._psd_reuse_previous("Any", None) is False


def test_legacy_update_without_typed_name_still_reuses():
    assert be._psd_reuse_previous("", r"D:\out\OldName.psd") is True
    assert be._psd_reuse_previous(None, r"D:\out\OldName.psd") is True


def test_full_prev_path_with_extension_handled():
    assert be._psd_reuse_previous("Keep", r"D:\deep\folder\Keep.PSD") is True
    assert be._psd_reuse_previous("Keep.psb", r"D:\deep\folder\Keep.PSD") is True
    assert be._psd_reuse_previous("Other", r"D:\deep\folder\Keep.PSD") is False