"""XTRAA REELS side-icon auto-detection + mapped-template root copies."""

import json
import os
import tempfile

import pytest

from ps_autotypesetter.ui_web import engine_api


def _touch(path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb"):
        pass
    return path


def test_xtra_explicit_path_wins():
    from ps_autotypesetter.build_engine import _resolve_xtra_reels_asset

    with tempfile.TemporaryDirectory() as tmp:
        explicit = _touch(os.path.join(tmp, "my_icon.png"))
        _touch(os.path.join(tmp, "XTRAA.PNG"))
        assert _resolve_xtra_reels_asset(explicit, [tmp]) == os.path.abspath(explicit)


def test_xtra_auto_detect_any_case_and_longest_pattern():
    from ps_autotypesetter.build_engine import _resolve_xtra_reels_asset

    with tempfile.TemporaryDirectory() as tmp:
        _touch(os.path.join(tmp, "XTRAA.PNG"))
        assert os.path.basename(_resolve_xtra_reels_asset("", [tmp])) == "XTRAA.PNG"
        _touch(os.path.join(tmp, "xtrareels.png"))
        assert os.path.basename(_resolve_xtra_reels_asset("", [tmp])) == "xtrareels.png"


def test_xtra_detects_one_level_deep_and_ignores_deeper():
    from ps_autotypesetter.build_engine import _resolve_xtra_reels_asset

    with tempfile.TemporaryDirectory() as tmp:
        sub = os.path.join(tmp, "icons")
        _touch(os.path.join(sub, "xtraareel.jpg"))
        deep = os.path.join(sub, "deep")
        _touch(os.path.join(deep, "xtrareels.png"))
        # Depth 1 is scanned; deeper folders are intentionally not searched.
        assert os.path.basename(_resolve_xtra_reels_asset("", [tmp])) == "xtraareel.jpg"
        assert _resolve_xtra_reels_asset("", [tempfile.mkdtemp()]) == ""


def test_xtra_missing_explicit_path_falls_back_to_auto():
    from ps_autotypesetter.build_engine import _resolve_xtra_reels_asset

    with tempfile.TemporaryDirectory() as tmp:
        _touch(os.path.join(tmp, "xtrareel.png"))
        resolved = _resolve_xtra_reels_asset(os.path.join(tmp, "gone.png"), [tmp])
        assert os.path.basename(resolved) == "xtrareel.png"


def test_save_mapping_writes_root_copy_even_for_library_templates(tmp_path, monkeypatch):
    from ps_autotypesetter.ui_web import paytable_templates

    lib_dir = paytable_templates.templates_dir()
    out_dir = tmp_path / "Output"
    out_dir.mkdir()
    template = {
        "template_id": "RootCopyZZ",
        "canvas": {"width": 1920, "height": 1080},
        "slots": {"@slot.text": {"x": 1, "y": 1, "w": 100, "h": 30}},
    }
    payload = {
        "template": template,
        "mappings": [{"slot": "@slot.text", "source": "B5", "mode": "excel"}],
        "template_dir": True,
    }
    try:
        result, _cfg = engine_api.save_paytable_mapping({"output_dir": str(out_dir)}, payload)
        assert result["ok"] is True
        root_copy = os.path.join(out_dir, "RootCopyZZ_mapped.json")
        assert result["root_path"] == os.path.abspath(root_copy)
        assert os.path.isfile(root_copy)
        with open(root_copy, encoding="utf-8") as handle:
            doc = json.load(handle)
        assert doc["mappings"]["@slot.text"]["source"] == "B5"
        library_files = [f for f in os.listdir(lib_dir) if f.startswith("RootCopyZZ")]
        assert library_files == ["RootCopyZZ.json"]
    finally:
        for f in os.listdir(lib_dir):
            if f.startswith("RootCopyZZ"):
                os.remove(os.path.join(lib_dir, f))


def test_import_mirrors_new_template_to_project_root(tmp_path):
    from ps_autotypesetter.ui_web import paytable_templates
    from ps_autotypesetter.ui_web.server import create_app

    lib_dir = paytable_templates.templates_dir()
    out_dir = tmp_path / "Out"
    out_dir.mkdir()
    session = tmp_path / "session.json"
    template_path = tmp_path / "ImportedZZ.json"
    with open(template_path, "w", encoding="utf-8") as handle:
        json.dump(
            {
                "template_id": "ImportedZZ",
                "canvas": {"width": 1920, "height": 1080},
                "slots": {"@slot.text": {"x": 1, "y": 1, "w": 100, "h": 30}},
            },
            handle,
        )
    app = create_app(session_file=str(session))
    client = app.test_client()
    try:
        cfg_res = client.post("/api/config", json={"output_dir": str(out_dir)})
        assert cfg_res.get_json()["ok"] is True
        resp = client.post("/api/paytable_templates/import", json={"path": str(template_path)})
        data = resp.get_json()
        assert data["ok"] is True
        expected = os.path.abspath(os.path.join(out_dir, "ImportedZZ.json"))
        assert data["root_path"] == expected
        assert os.path.isfile(expected)
        with open(expected, encoding="utf-8") as handle:
            doc = json.load(handle)
        assert doc["template_id"] == "ImportedZZ"
    finally:
        for f in os.listdir(lib_dir):
            if f.startswith("ImportedZZ"):
                os.remove(os.path.join(lib_dir, f))


def test_save_mapping_root_copy_skipped_when_output_dir_is_the_library(tmp_path, monkeypatch):
    from ps_autotypesetter.ui_web import paytable_templates

    lib_dir = paytable_templates.templates_dir()
    template = {
        "template_id": "RootSkipZZ",
        "canvas": {"width": 1920, "height": 1080},
        "slots": {"@slot.text": {"x": 1, "y": 1, "w": 100, "h": 30}},
    }
    payload = {
        "template": template,
        "mappings": [{"slot": "@slot.text", "source": "B5", "mode": "excel"}],
        "template_dir": True,
    }
    try:
        result, _cfg = engine_api.save_paytable_mapping({"output_dir": lib_dir}, payload)
        assert result["ok"] is True
        assert result["root_path"] == ""
        library_files = sorted(f for f in os.listdir(lib_dir) if f.startswith("RootSkipZZ"))
        assert library_files == ["RootSkipZZ.json"]
    finally:
        for f in os.listdir(lib_dir):
            if f.startswith("RootSkipZZ"):
                os.remove(os.path.join(lib_dir, f))