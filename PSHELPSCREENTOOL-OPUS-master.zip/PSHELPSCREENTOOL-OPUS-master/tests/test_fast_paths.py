"""The fast paths give exactly what the slow ones gave: the splice writer, the engine-data writer and
copy, and the fuzzy word search."""
import difflib
import io

import pytest
from openpyxl import Workbook

from ps_autotypesetter import content_model as cm
from ps_autotypesetter import market_clone as mc


def _book(path, rows):
    wb = Workbook()
    wb.active.title = "Features"
    for row in rows:
        wb.active.append(row)
    wb.save(path)
    return str(path)


@pytest.fixture
def tool_psd(tmp_path):
    pytest.importorskip("photoshopapi")
    from ps_autotypesetter.psd_writer import build as psd_build
    from ps_autotypesetter.ui_web import engine_api

    a = _book(tmp_path / "A.xlsx", [["FREE SPINS"], ["Three scatters award 10 free spins."],
                                    ["Wins are multiplied by the bet multiplier."]])
    b = _book(tmp_path / "B.xlsx", [["FREE SPINS"], ["Bonus spins can be bought."], ["Four scatters award 12 free spins."],
                                    ["Wins are multiplied by the bet multiplier."]])
    cfg = {"excel_path": a, "icon_folder": "", "bg_path": "", "bg_source": "color", "bg_color": "#102040",
           "output_dir": str(tmp_path / "out"), "output_name": "A", "render_all_pages": True,
           "c_width": 1280, "c_height": 720}
    return psd_build.build_psd(**engine_api._build_kwargs(cfg), output_format="PSD"), a, b


def _raw(el, **kw):
    out = io.BytesIO()
    el.write(out, **kw)
    return out.getvalue()


def test_the_splice_writer_writes_what_psd_tools_would(tool_psd, tmp_path):
    from ps_autotypesetter.artist_design import psd_reader
    from ps_autotypesetter.psd_apply import splice

    src, a, b = tool_psd
    psd, plan = mc.prepare(src, a, b)
    mc.apply(psd, plan)
    psd = mc.place_new_rows(psd, plan)
    mc.color_pages(psd, plan)
    assert splice.known(psd)
    full = str(tmp_path / "full.psd")
    with open(full, "wb") as f:
        psd._record.write(f)
    stats = mc.save(psd, str(tmp_path / "splice.psd"))
    assert stats and stats["raw"] > 0 and stats["written"] > 0       # some layers copied, the edited ones written
    A, B = psd_reader.open_lazy(full)._record, psd_reader.open_lazy(str(tmp_path / "splice.psd"))._record
    la, lb = A.layer_and_mask_information.layer_info, B.layer_and_mask_information.layer_info
    v = A.header.version
    # a layer's text data copied raw keeps its writer's own spacing (PhotoshopAPI's here), where the full
    # write re-formats what was read: compared as content, both parsed
    from psd_tools.constants import Tag

    for rec in list(la.layer_records) + list(lb.layer_records):
        tool = rec.tagged_blocks.get_data(Tag.TYPE_TOOL_OBJECT_SETTING)
        if tool is not None:
            getattr(tool.text_data[b"EngineData"].value, "parsed", None)
    assert la.layer_count == lb.layer_count
    assert [_raw(r, encoding="macroman", version=v) for r in la.layer_records] == \
           [_raw(r, encoding="macroman", version=v) for r in lb.layer_records]
    assert [[(c.compression, c.data) for c in ch] for ch in la.channel_image_data] == \
           [[(c.compression, c.data) for c in ch] for ch in lb.channel_image_data]
    assert _raw(A.layer_and_mask_information.tagged_blocks, version=v, padding=4) == \
           _raw(B.layer_and_mask_information.tagged_blocks, version=v, padding=4)
    assert A.image_data.data == B.image_data.data


def test_an_unmarked_change_is_still_written(tool_psd, tmp_path):
    """A record changed in a way the fingerprint sees (a layer hidden) is written, not copied."""
    from ps_autotypesetter.artist_design import psd_reader
    from ps_autotypesetter.psd_apply import splice

    src, _a, _b = tool_psd
    psd = psd_reader.open_lazy(src)
    assert splice.remember(psd, src)
    layer = next(l for l in psd.descendants() if l.kind == "type")
    layer.visible = False
    stats = splice.write(psd, str(tmp_path / "hidden.psd"))
    assert stats["written"] == 1
    again = psd_reader.open_lazy(str(tmp_path / "hidden.psd"))
    assert not next(l for l in again.descendants() if l.layer_id == layer.layer_id).visible


def test_engine_data_is_written_and_copied_as_psd_tools_does(tool_psd):
    from psd_tools.constants import Tag

    from ps_autotypesetter.artist_design import psd_reader

    src, _a, _b = tool_psd
    psd = psd_reader.open_lazy(src)
    for layer in psd.descendants():
        if layer.kind != "type":
            continue
        ed = layer._record.tagged_blocks.get_data(Tag.TYPE_TOOL_OBJECT_SETTING).text_data[b"EngineData"].value
        parsed = ed.parsed
        assert psd_reader.engine_bytes(parsed) == _raw(parsed)
        assert _raw(psd_reader.engine_copy(parsed)) == _raw(parsed)
    txt2 = psd._record.layer_and_mask_information.tagged_blocks.get_data(Tag.TEXT_ENGINE_DATA)
    if txt2 is not None:
        assert psd_reader.engine_bytes(txt2.parsed) == _raw(txt2.parsed)


def _old_near(st, want, at_least=0.85):
    n, best = len(want), None
    for i in sorted({i for k in set(want) for i in st.first.get(k, [])}):
        for start in (max(0, i - n), i):
            window = st.keys[start:start + n + max(2, n // 5)]
            sm = difflib.SequenceMatcher(None, want, window, autojunk=False)
            blocks = [b for b in sm.get_matching_blocks() if b.size]
            if not blocks:
                continue
            score = sum(b.size for b in blocks) / n
            if score >= at_least and (best is None or score > best[2]):
                best = (start + blocks[0].b, start + blocks[-1].b + blocks[-1].size, score)
    return best


def test_the_word_search_finds_what_it_always_found():
    wb = Workbook()
    ws = wb.active
    rows = ["Three scatters award 10 free spins during the base game.",
            "Free spins are played at the bet of the triggering game.",
            "Wins during free spins are multiplied by the bet multiplier.",
            "Three scatters award 10 free spins during the bonus game.",
            "All wins pay left to right on adjacent reels only."]
    for r in rows:
        ws.append([r])
    st = cm.Stream(cm.Sheet("S", ws))
    for text in rows + ["Three scatters award 12 free spins during the base game",
                        "Free spins are played at the bet of the game that triggered them",
                        "Wins during free spins are multiplied", "nothing like any row here at all"]:
        want = [cm.word_key(w) for w in text.split()]
        for floor in (0.85, 0.6):
            assert st.near(want, floor) == _old_near(st, want, floor)
