"""What the Canvas shows is what the PSD gets (the user's standing rule, 2026-10-30): the paytable's
texts are laid out once (ps_actions.slot_text_layout) for the preview, the build and the Canvas, and a
card look's layer style (glow, shadow, bevel, gradient…) is written into the PSD's layer style."""
import io

from psd_tools.psd.descriptor import DescriptorBlock

from ps_autotypesetter import fx_descriptor as fd
from ps_autotypesetter.psd_writer import effects
from ps_autotypesetter.ui_web import ps_actions as pa

TITLE = "Fo MO MO MO MO MO MUMMY PAYTABLE"


def test_the_title_keeps_to_one_line_from_its_own_size():
    # the design's own title size (page.title → title_own) is the start; too wide, it gets smaller
    m = pa.title_mapping({"slot": "@slot.title", "title_own": {"font_size": 207}}, {"title_size": 60})
    assert m["font_size"] == 207 and m["bold"] is True and m["alignment"] == "center"
    lay = pa.slot_text_layout("@slot.title", m, TITLE, 0, 0, 2700, 260)
    assert len(lay["lines"]) == 1 and lay["fh"] < 207


def test_the_canvas_gets_the_builds_own_lines_and_sizes():
    m = {"mode": "text", "font_size": 30, "fit_box": True, "shrink_to_fit": True, "alignment": "center",
         "vertical_align": "top", "inline_icons": True}
    text = "All wins begin with the leftmost reel and pay left to right on adjacent reels, except feature prizes. " * 3
    lay = pa.slot_text_layout("@slot.text", m, text, 100, 200, 900, 300)
    out = pa.layout_for_canvas(lay, 200)
    assert out["size"] == lay["font"].size and len(out["lines"]) == len(lay["lines"]) > 1
    assert [" ".join(w["t"] for w in ln) for ln in out["lines"]] == [" ".join(i["val"] for i in ln) for ln in lay["lines"]]
    assert out["lh"] == [round(float(v), 2) for v in lay["line_heights"]] and len(out["base"]) == len(out["lines"])
    assert out["top"] == round(lay["ty"] - 200, 2)


def test_the_build_lays_its_texts_out_with_the_shared_layout(monkeypatch):
    from PIL import Image, ImageDraw, ImageFont

    from ps_autotypesetter import png_builder

    calls = []
    real = pa.slot_text_layout
    monkeypatch.setattr(pa, "slot_text_layout", lambda *a, **k: calls.append(a[0]) or real(*a, **k))
    base = Image.new("RGBA", (1920, 1080))
    template = {"canvas": {"width": 1920, "height": 1080}, "slots": {"@slot.text": {"x": 100, "y": 700, "w": 1600, "h": 200}},
                "mappings": {"@slot.text": {"slot": "@slot.text", "mode": "text", "text": "Rules text here", "font_size": 30}}}
    png_builder._render_mapped_paytable_png_ws(base, ImageDraw.Draw(base), Image, ImageFont, template, None, "Paytable",
                                               {}, "", {}, {}, template["slots"], 2, {})
    assert "@slot.text" in calls


def _written(cp):
    desc = DescriptorBlock.read(io.BytesIO(effects.params_payload({"captured_params": cp})[4:]))
    return fd.params_from_descriptor(fd.plain(desc))


def test_a_card_looks_effects_are_the_psds_layer_style():
    cp = {"drop_shadow": {"color": "#000000", "opacity": 65, "distance": 6, "size": 12, "angle": 120},
          "outer_glow": {"color": "#61FF19", "opacity": 50, "size": 15, "blend": "screen"},
          "inner_glow": {"color": "#FFD36B", "opacity": 55, "size": 10, "source": "center"},
          "inner_shadow": {"color": "#000000", "opacity": 70, "distance": 5, "size": 14, "angle": 120},
          "bevel": {"style": "inner", "technique": "smooth", "depth": 120, "size": 4, "angle": 120, "altitude": 30,
                    "highlight_color": "#FFF4C2", "highlight_opacity": 70, "shadow_color": "#5A3A00", "shadow_opacity": 70},
          "gradient_overlay": {"colors": [["#FFF3C4", 0], ["#C9963A", 100]], "angle": 90, "opacity": 100, "type": "linear"}}
    back = _written(cp)
    assert back["outer_glow"]["enabled"] and back["outer_glow"]["color"] == [97, 255, 25] and back["outer_glow"]["size"] == 15
    assert back["drop_shadow"]["enabled"] and back["drop_shadow"]["distance"] == 6 and back["drop_shadow"]["opacity"] == 65
    assert back["inner_glow"]["enabled"] and back["inner_glow"]["source"] == "center"
    assert back["inner_shadow"]["enabled"] and back["inner_shadow"]["size"] == 14
    assert back["bevel"]["enabled"] and back["bevel"]["depth"] == 120 and back["bevel"]["highlight_color"] == [255, 244, 194]
    g = back["gradient_overlay"]
    assert g["enabled"] and [c[0] for c in g["colors"]] == [[255, 243, 196], [201, 150, 58]]
    # an effect switched off is not written; no effect at all: no layer style
    assert not _written({"outer_glow": {"color": "#FF0000", "enabled": False}, "drop_shadow": {"color": "#000"}}).get("outer_glow", {}).get("enabled")
    assert effects.params_payload({"captured_params": {}}) is None


def test_gradients_blend_straight_in_the_psd_as_on_the_canvas():
    # Photoshop's default Smoothness 100 % eases a gradient's colours (more contrast than the Canvas / PNG,
    # which blend in a straight line): the PSD's gradients are written at 0 %
    from psd_tools.constants import Tag

    from ps_autotypesetter.psd_writer import shapes

    vscg = next(b for b in shapes.blocks(dict(left=0, top=0, width=200, height=100, fill="#1B2050", fill_to="#0E1022"), 1920, 1080)
                if b.key == Tag.VECTOR_STROKE_CONTENT_DATA).data
    assert vscg[b"Grad"][b"Intr"].value == 0
    back = _written({"gradient_overlay": {"colors": [["#FFF3C4", 0], ["#C9963A", 100]], "angle": 90}})
    assert back["gradient_overlay"]["smoothness"] == 0


def test_a_plate_sized_by_hand_is_any_size_around_its_text():
    from ps_autotypesetter import text_styles

    # a text page's heading plate: its own margin on each side of the heading's text, any size
    rule = {"full_width": False, "pads": [10, -5, 300, 40]}
    assert text_styles.strip_geometry(rule, 100, 50, 800, 60, 300, 500) == (290.0, 55.0, 510.0, 95.0)
    # narrower and shorter than the text too (it never vanishes)
    assert text_styles.strip_geometry(dict(rule, pads=[-150, -40, -150, -40]), 100, 50, 800, 60, 300, 500)[2:] == (1.0, 1.0)
    # the paytable title: the same around its laid-out text, for the preview, the build and the Canvas
    m = pa.title_mapping({"slot": "@slot.title", "title_own": {"font_size": 120}}, {})
    lay = pa.slot_text_layout("@slot.title", m, "PAYTABLE", 0, 0, 2000, 200)
    tx, ty, tw, th = pa.text_rect(lay)
    assert pa.plate_rect({"pads": [20, 10, 600, 0]}, 0, 0, 2000, 200, lay) == (tx - 20, ty - 10, tw + 620, th + 10)
    assert pa.plate_rect({"fit": 40}, 0, 0, 2000, 200, lay)[2] == tw + 80


def test_the_title_plate_drag_is_kept_as_margins_around_the_text():
    from ps_autotypesetter.dynamic_pages.paytable import card_templates as ct

    t = ct.get_template("fomo_mummy")
    t["page"]["title"].update(plate=True, fit=True, plate_pads=[30, 5, 30, 5])
    _doc, maps = ct.compile_template(t, {"top": 2, "lower": 2, "block_keys": ["pic1", "pic2", "ace", "king"]}, None,
                                     {"canvas": (3840, 2160)})
    shape = maps["@slot.title"]["shape"]
    assert shape["pads"] == [60, 10, 60, 10] and "fit" not in shape          # canvas px (design px × 2)


def test_a_strip_or_plate_takes_a_card_look_into_the_psd(monkeypatch):
    # a card look pasted on a heading plate / row strip: its gradient, corner shapes and own layer style
    # reach the shape the build draws (the PSD's vector shape + layer style), as on the Canvas
    from ps_autotypesetter import paytable_box, text_styles

    rule = {"color": "#102040", "opacity": 0.9, "radius": 14, "corner": "cut", "fill_to": "#000000",
            "gradient_dir": "horizontal", "gradient_amount": 50,
            "fx": {"captured_params": {"outer_glow": {"color": "#3D7BFF", "size": 20, "opacity": 80}}}}
    look = text_styles.strip_look(rule)
    assert look["corner"] == "cut" and look["fill_to"] == "#081020" and look["gradient_dir"] == "horizontal"
    assert look["fx"] == "inline" and look["_fx"]["captured_params"]["outer_glow"]["size"] == 20
    # read again from the look (the canonical layout's rect → canonical_png → draw_strip)
    again = text_styles.strip_look(dict(look, color="#102040"))
    assert again["fill_to"] == "#081020" and again["_fx"] == rule["fx"]
    seen = {}
    monkeypatch.setattr(paytable_box, "draw", lambda base, m, *a, **k: seen.update(m["shape"]) or True)
    text_styles.draw_strip(None, rule, (10, 10, 400, 80))
    assert seen["corner"] == "cut" and seen["fill_to"] == "#081020" and seen["gradient_dir"] == "horizontal"
    assert seen["fx"]["captured_params"]["outer_glow"]["color"] == "#3D7BFF"
