"""Parity tests: canonical layout PNG output must match historical output.

For a fully supported sheet (plain heading + centered body rows, no tables,
no heading images), the canonical pipeline must produce byte-identical images
to the historical png_builder path. Each test runs BOTH pipelines on the same
workbook and compares every output PNG byte-for-byte.
"""

import os

import pytest
from openpyxl import Workbook
from openpyxl.styles import Font

from ps_autotypesetter import layout_engine, png_builder

pytestmark = pytest.mark.skipif(
    not layout_engine.canonical_layout_enabled(),
    reason="Canonical layout disabled",
)


def _make_workbook(path):
    wb = Workbook()
    ws = wb.active
    ws.title = "PAGE1"
    cell = ws.cell(row=1, column=1, value="GAME RULES")
    cell.font = Font(bold=True)
    ws.append(["Simple body line one"])
    ws.append(["Body line two continues here"])
    ws.append(["Last body line"])
    wb.save(path)


def _build(path, use_canonical, **overrides):
    params = dict(
        excel_path=path, icon_folder="", bg_path="",
        c_width=1920, c_height=1080, max_col_limit=12,
        h_font="Arial", h_size=72, h_icon_h=48, h_rgb="#FF5050",
        b_font="Arial", b_size=30, b_icon_h=24, b_rgb="#FFFFFF",
        margin_x=100, line_spacing=4, para_spacing=12,
        gap_px=12, icon_y_offset=0,
        bg_mode="stretch", bg_color="#FFFFFF",
        heading_top_margin=120, continued_gap=15, heading_to_body_gap=40,
        bottom_margin=80, inner_canvas_width=0,
        page_min_row=1, page_max_row=100,
        page_min_col=1, page_max_col=12,
        page_overrides={}, dynamic_settings={},
        use_canonical_layout=use_canonical,
        output_dir=None, output_name=None,
    )
    params.update(overrides)
    target_dir = png_builder.build_pngs_only(**params)
    return target_dir


def _pngs(target_dir):
    names = sorted(n for n in os.listdir(target_dir) if n.lower().endswith(".png"))
    assert names, f"no PNG output produced in {target_dir}"
    return [open(os.path.join(target_dir, n), "rb").read() for n in names]


def _assert_parity(tmp_path, use_canonical_path=True, **kwargs):
    legacy_path = tmp_path / "legacy.xlsx"
    canonical_path = tmp_path / "canonical.xlsx"
    _make_workbook(str(legacy_path))
    _make_workbook(str(canonical_path))
    kwargs = dict(kwargs)
    # output_dir isolation
    legacy_dir = _build(str(legacy_path), False, output_dir=str(tmp_path / "out_legacy"), **kwargs)
    canonical_dir = _build(str(canonical_path), True, output_dir=str(tmp_path / "out_canonical"), **kwargs)
    assert _pngs(legacy_dir) == _pngs(canonical_dir)


def test_parity_single_page(tmp_path):
    _assert_parity(tmp_path)


def test_parity_across_multiple_fonts(tmp_path):
    for font_name, h_size, b_size in [("Arial", 72, 30), ("Times New Roman", 44, 22)]:
        _assert_parity(tmp_path, h_font=font_name, h_size=h_size, b_font=font_name, b_size=b_size)


def test_parity_with_margins_and_gaps(tmp_path):
    _assert_parity(
        tmp_path,
        margin_x=180, heading_top_margin=200, heading_to_body_gap=60, bottom_margin=120,
    )


def test_parity_with_line_spacing_and_para_spacing(tmp_path):
    _assert_parity(tmp_path, line_spacing=10, para_spacing=30)


def test_parity_with_multiplier_line_spacing(tmp_path):
    """The web UI Line spacing (0.5-3 multiplier) must resolve identically in
    the legacy and canonical pipelines (font * (multiplier - 1) row gap)."""
    _assert_parity(tmp_path, line_spacing=1.1, b_size=30)
    _assert_parity(tmp_path, line_spacing=2.0, b_size=30)


def test_parity_with_explicit_row_gap(tmp_path):
    """The UI 'Row spacing' (line_gap px) drives PSD-style content-based row
    gaps in BOTH pipelines -- legacy PNG and canonical output must be
    byte-identical for the same px gap (paragraph gap replaced by it)."""
    _assert_parity(tmp_path, dynamic_settings={"line_gap": 30})
    _assert_parity(tmp_path, dynamic_settings={"line_gap": 0})


def test_parity_with_multiplier_and_heading_wrap(tmp_path):
    """A two-line heading exercises the heading row-gap math (derived from the heading font size) in
    both pipelines. Its lines are the cell's own: a heading too long for the page no longer wraps —
    it shrinks to stay on one line (layout_engine)."""
    legacy_path = tmp_path / "legacy_wrap.xlsx"
    canonical_path = tmp_path / "canonical_wrap.xlsx"
    for path in (legacy_path, canonical_path):
        wb = Workbook()
        ws = wb.active
        ws.title = "PAGE1"
        ws.cell(row=1, column=1, value="GAME RULES HEADING\nON TWO LINES OF ITS OWN").font = Font(bold=True)
        for index in range(3):
            ws.append([f"Body line number {index + 1} for the wrapped heading test"])
        wb.save(str(path))
    legacy_dir = _build(str(legacy_path), False, output_dir=str(tmp_path / "out_legacy_wrap"), line_spacing=1.1, b_size=30, margin_x=100)
    canonical_dir = _build(str(canonical_path), True, output_dir=str(tmp_path / "out_canonical_wrap"), line_spacing=1.1, b_size=30, margin_x=100)
    assert _pngs(legacy_dir) == _pngs(canonical_dir)


def test_parity_multi_page(tmp_path):
    legacy_path = tmp_path / "legacy.xlsx"
    canonical_path = tmp_path / "canonical.xlsx"
    for path in (legacy_path, canonical_path):
        wb = Workbook()
        ws = wb.active
        ws.title = "PAGE1"
        ws.cell(row=1, column=1, value="GAME RULES").font = Font(bold=True)
        for index in range(40):
            ws.append([f"Multi page body line number {index + 1} continues with more text"])
        wb.save(str(path))
    legacy_dir = _build(str(legacy_path), False, output_dir=str(tmp_path / "out_legacy"))
    canonical_dir = _build(str(canonical_path), True, output_dir=str(tmp_path / "out_canonical"))
    assert _pngs(legacy_dir) == _pngs(canonical_dir)


def test_parity_feature_flag_off_uses_legacy(tmp_path):
    """With the flag forced off, output must still be produced (legacy path)."""
    import io

    path = tmp_path / "flag_off.xlsx"
    _make_workbook(str(path))
    target_dir = _build(str(path), None, use_canonical_layout=False, output_dir=str(tmp_path / "out_flag_off"))
    assert _pngs(target_dir)
    assert len(_pngs(target_dir)) >= 1


# ---------------------------------------------------------------------------
# Live-canvas geometry: the payload must carry PIL-computed per-line widths
# and run boxes the browser can draw verbatim (no re-measurement), matching
# the exact positions png_builder._draw_inline composites.
# ---------------------------------------------------------------------------


def _make_icon_folder(tmp_path):
    from PIL import Image, ImageDraw

    icon_dir = tmp_path / "icons"
    icon_dir.mkdir(exist_ok=True)
    img = Image.new("RGBA", (40, 50), (0, 0, 0, 0))
    ImageDraw.Draw(img).rectangle([0, 0, 39, 49], fill=(255, 0, 0, 255))
    img.save(icon_dir / "ACE.png")
    return str(icon_dir)


def _simple_workbook_with_icon(path):
    wb = Workbook()
    ws = wb.active
    ws.title = "PAGE1"
    ws.cell(row=1, column=1, value="GAME RULES").font = Font(bold=True)
    ws.append(["Prefix <ACE> suffix"])
    wb.save(path)


def test_payload_carries_line_widths_and_runs(tmp_path):
    """The canonical payload must serialize per-line PIL widths + run boxes
    (the live canvas draws these instead of re-measuring in the browser)."""
    from ps_autotypesetter import live_layout_adapter

    icon_dir = _make_icon_folder(tmp_path)
    path = tmp_path / "t.xlsx"
    _simple_workbook_with_icon(str(path))

    cfg = {
        "excel_path": str(path), "line_spacing": 1.1, "line_gap": "", "c_width": 1920, "c_height": 1080,
        "margin_x": 100, "h_font": "Arial", "h_size": 72, "h_icon_h": 48, "h_rgb": "#FF5050",
        "b_font": "Arial", "b_size": 30, "b_icon_h": 24, "b_rgb": "#FFFFFF",
        "para_spacing": 12, "heading_top_margin": 120, "heading_to_body_gap": 40,
        "bottom_margin": 80, "max_col_limit": 12, "icon_folder": icon_dir, "icon_mappings": {},
        "icon_size_overrides": {}, "dynamic_settings": {}, "page_overrides": {},
        "alignment_settings": {}, "heading_image_folder": "", "inner_canvas_width": 0,
        "continued_gap": 15, "icon_y_offset": 3,
    }
    payload = live_layout_adapter.layout_payload_for_sheet(cfg, "PAGE1", apply_overrides=True)
    assert payload.get("mode") == "canonical"
    elements = {e["id"]: e for e in payload["layouts"][0]["elements"]}
    body = elements["body_2_1"]
    assert len(body["line_widths"]) == 1
    assert body["line_widths"][0] > 0
    runs = body["line_runs"][0]
    assert any(r["kind"] == "icon" and r["token"] == "ACE" for r in runs)
    icon = next(r for r in runs if r["kind"] == "icon")
    # icon scaled to b_icon_h 24 (40x50 keeps aspect) with the 15px gaps
    assert icon["w"] == 19 and icon["h"] == 24
    from ps_autotypesetter import ps_text

    prefix = ps_text.advance(png_builder._load_font(__import__("PIL.ImageFont").ImageFont, "Arial", 30), "Prefix")
    assert icon["x"] == pytest.approx(prefix + 15, abs=0.01)  # "Prefix" (Photoshop width) + left gap


def test_runs_match_draw_inline_composite(tmp_path):
    """The server run box must land on the exact pixels _draw_inline places
    the icon on (x + run.x, y + round(run.y)) — the same walk _draw_inline
    uses, so the canvas and the PNG agree to the pixel."""
    from ps_autotypesetter import layout_engine, png_builder

    icon_dir = _make_icon_folder(tmp_path)
    path = tmp_path / "t.xlsx"
    _simple_workbook_with_icon(str(path))

    wb = __import__("openpyxl").load_workbook(str(path))
    ws = wb["PAGE1"]
    layouts = layout_engine.build_sheet_layouts(
        ws, "PAGE1", canvas_w=1920, canvas_h=1080, margin_x=100,
        h_font="Arial", h_size=72, h_icon_h=48, h_rgb="#FF5050",
        b_font="Arial", b_size=30, b_icon_h=24, b_rgb="#FFFFFF",
        line_spacing=1.1, para_spacing=12, line_gap=None,
        heading_top_margin=120, heading_to_body_gap=40, bottom_margin=80,
        max_col_limit=12, icon_folder=icon_dir, icon_mappings={},
        icon_size_overrides={}, dynamic_settings={}, page_overrides={},
        alignment_settings={}, heading_image_folder="", inner_canvas_width=0,
        continued_gap=15, icon_y_offset=3,
    )
    wb.close()
    assert layouts is not None
    body = next(e for e in layouts[0].elements if e.id == "body_2_1")
    icon = next(r for r in body.line_runs[0] if r["kind"] == "icon")

    Image, ImageDraw, ImageFont = png_builder._require_pillow()
    probe = Image.new("RGBA", (1920, 1080), (0, 0, 0, 0))
    draw = ImageDraw.Draw(probe)
    font = png_builder._load_font(ImageFont, "Arial", 30)
    png_builder._draw_inline(
        probe, draw, Image, body.text, body.x, body.y, font, (255, 255, 255),
        int(body.width), icon_dir, {}, int(body.icon_height), {}, "center",
        int(body.line_spacing), None, int(body.icon_gap_left), int(body.icon_gap_right), 3,
    )
    line_x = body.x + max(0, (body.width - body.line_widths[0]) / 2.0)
    icon_abs_x = int(round(line_x + icon["x"]))
    icon_abs_y = int(round(body.y + icon["y"]))
    px = probe.load()
    assert px[icon_abs_x + 1, icon_abs_y + 1][0] > 200 and px[icon_abs_x + 1, icon_abs_y + 1][3] > 200
    assert px[icon_abs_x - 1, icon_abs_y - 1][3] == 0  # outside the icon: transparent


def test_pillow_adapter_resolves_icons(tmp_path):
    """Regression: PillowMeasureAdapter must measure icon tokens using the
    PIL module (Image.open is a module function — a probe instance or
    Image.Image class silently dropped every icon from measurement)."""
    from ps_autotypesetter import layout_engine

    icon_dir = _make_icon_folder(tmp_path)
    path = tmp_path / "t.xlsx"
    _simple_workbook_with_icon(str(path))

    wb = __import__("openpyxl").load_workbook(str(path))
    ws = wb["PAGE1"]
    Image, ImageDraw, ImageFont = layout_engine._require_pillow()
    probe = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    adapter = layout_engine.PillowMeasureAdapter(
        probe, ImageDraw.Draw(probe), icon_folder=icon_dir,
        icon_mappings={}, icon_size_overrides={},
    )
    font = png_builder._load_font(ImageFont, "Arial", 30)
    w, _h = adapter.measure("Prefix <ACE> suffix", font, 30, "Arial", 24, 15, 15)
    wb.close()
    # icon-aware: "Prefix" + gap(15) + icon(19) + gap(15) + "suffix", at Photoshop's exact widths
    from ps_autotypesetter import ps_text

    expected = ps_text.advance(font, "Prefix") + 15 + 19 + 15 + ps_text.advance(font, "suffix")
    assert w == pytest.approx(expected, abs=0.01)


def test_canonical_layout_resolves_layer_style_fx(tmp_path):
    """Layer styles assigned to 'Heading text' / 'Body text' must propagate
    into the canonical elements' `effects` — the live Typography/Assets
    canvas draws FX from those effects (`raw.effects` → `e.fx`)."""
    from ps_autotypesetter import layout_engine

    path = tmp_path / "t.xlsx"
    _make_workbook(str(path))
    library = {
        "GoldGlow": {
            "stroke_enabled": True, "stroke_size": 4, "stroke_rgb": (0, 0, 0),
            "shadow_enabled": True, "shadow_distance": 6, "shadow_size": 2,
        },
        "ShadowWhite": {
            "shadow_enabled": True, "shadow_distance": 3, "shadow_size": 1,
        },
    }
    assignments = {
        "Heading text": "GoldGlow",
        "Body text": "ShadowWhite",
    }

    wb = __import__("openpyxl").load_workbook(str(path))
    ws = wb["PAGE1"]
    layouts = layout_engine.build_sheet_layouts(
        ws, "PAGE1", canvas_w=1920, canvas_h=1080, margin_x=100,
        h_font="Arial", h_size=72, h_icon_h=48, h_rgb="#FF5050",
        b_font="Arial", b_size=30, b_icon_h=24, b_rgb="#FFFFFF",
        line_spacing=1.1, para_spacing=12, line_gap=None,
        heading_top_margin=120, heading_to_body_gap=40, bottom_margin=80,
        max_col_limit=12, icon_folder="", icon_mappings={},
        icon_size_overrides={}, page_overrides={},
        alignment_settings={}, heading_image_folder="",
        inner_canvas_width=0, continued_gap=15, icon_y_offset=0,
        dynamic_settings={"layer_style_library": library, "style_assignments": assignments},
    )
    wb.close()
    assert layouts is not None
    heading = next(e for e in layouts[0].elements if e.id.startswith("heading_page"))
    assert heading.effects == library["GoldGlow"]
    body = next(e for e in layouts[0].elements if e.id.startswith("body_"))
    assert body.effects == library["ShadowWhite"]


def test_canonical_layout_empty_without_styles(tmp_path):
    """Without assignments the canonical effects stay empty (no crash)."""
    from ps_autotypesetter import layout_engine

    path = tmp_path / "t.xlsx"
    _make_workbook(str(path))
    wb = __import__("openpyxl").load_workbook(str(path))
    ws = wb["PAGE1"]
    layouts = layout_engine.build_sheet_layouts(
        ws, "PAGE1", canvas_w=1920, canvas_h=1080, margin_x=100,
        h_font="Arial", h_size=72, h_icon_h=48, h_rgb="#FF5050",
        b_font="Arial", b_size=30, b_icon_h=24, b_rgb="#FFFFFF",
        line_spacing=1.1, para_spacing=12, line_gap=None,
        heading_top_margin=120, heading_to_body_gap=40, bottom_margin=80,
        max_col_limit=12, dynamic_settings={}, page_overrides={},
        alignment_settings={},
    )
    wb.close()
    assert layouts is not None
    heading = next(e for e in layouts[0].elements if e.id.startswith("heading_page"))
    assert heading.effects == {}