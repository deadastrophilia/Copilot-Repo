"""A background on part of the page (a PSD's "place" rectangle, fit, fit-width): the paytable starts inside it.

Buffalo_Help: a 2160 x 3840 page with its background at 27, 2355 (2106 x 1286). An old 1920 x 1080 design
was centred on the page, so its cards sat above the background; now its frame is centred in the
background, and the auto-placed content stays inside it."""

import json
import os

from ps_autotypesetter import bg_place
from ps_autotypesetter.dynamic_pages.paytable import card_templates as ct

PAGE = (2160.0, 3840.0)
BG = (27.0, 2355.0, 2106.0, 1286.0)


def test_area_of_the_background():
    assert bg_place.area({"c_width": 2160, "c_height": 3840, "bg_mode": "place", "bg_rect": list(BG)}) == BG
    assert bg_place.area({"bg_mode": "cover", "bg_path": "x.png"}) is None
    assert bg_place.area({"bg_source": "color"}) is None
    # a rectangle reaching past the page: only its part on the page
    got = bg_place.area({"c_width": 1000, "c_height": 1000, "bg_mode": "place", "bg_rect": [-50, 600, 2000, 800]})
    assert got == (0.0, 600.0, 1000.0, 400.0)


def test_old_frame_centres_in_the_background():
    area = ct.bg_area(PAGE, BG)
    dx, dy = ct.frame_shift(PAGE, area)
    assert area[1] <= dy and dy + ct.CANVAS[1] <= area[3] + 1
    assert ct.frame_shift(PAGE) == (0.0, 1166.0)                 # no area: centred on the page, as before
    moved = ct.to_page_frame({"page": {"top": 30, "bottom": 30, "left": 60, "right": 60}, "bands": [{"pos": [100, 300]}]},
                             PAGE, area)
    W, H = ct.design_frame(PAGE)
    assert moved["bands"][0]["pos"] == [100 + dx, 300 + dy]
    assert moved["page"]["top"] == 30 + dy and moved["page"]["bottom"] == 30 + (H - ct.CANVAS[1] - dy)


def test_compiled_paytable_stays_in_the_background():
    with open(os.path.join(ct._builtin_dir(), "classic_cards.json"), encoding="utf-8") as fh:
        tpl = json.load(fh)
    structure = {"top": 5, "block_keys": ["pic1", "pic2", "pic3", "pic4", "pic5", "ace", "king", "queen", "jack", "ten"]}
    ctx = {"canvas": PAGE, "heading_top": 2419.0, "heading_size": 78.0, "bg_area": BG}
    compiled, _maps = ct.compile_template(tpl, structure, None, ctx)
    x0, y0, x1, y1 = ct.bg_area(PAGE, BG)
    for name, box in compiled["slots"].items():
        assert y0 - 1 <= box["y"] and box["y"] + box["h"] <= y1 + 1, (name, box)
        assert x0 - 1 <= box["x"] and box["x"] + box["w"] <= x1 + 1, (name, box)
