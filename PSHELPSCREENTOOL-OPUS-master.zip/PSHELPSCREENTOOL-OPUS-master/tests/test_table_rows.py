"""Table rows on the Canvas: a sentence above a table stays text (table_detector), a row as normal text /
a row or column as header or normal (table_rows.py via png_builder._prepare_tables), Border Outside."""
import contextlib
import io

from openpyxl import Workbook
from openpyxl.styles import Border, Side
from PIL import Image, ImageDraw, ImageFont

from ps_autotypesetter import png_builder as pb
from ps_autotypesetter import table_rows as tr
from ps_autotypesetter.table_detector import detect_tables_in_sheet

THIN = Side(style="thin", color="000000")
BOX = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
ROWS = [("Jackpot/Bonus", "Letter Prizes"), ("Grand Jackpot", "G, R, A, N and D"), ("Major Jackpot", "M, A, J, O and R"),
        ("Minor Bonus", "M, I, N, O and R"), ("Mini Bonus", "M, I and N")]


def _sheet(sentence="Possible letter prizes are shown below."):
    """The JuCaiJin "Jackpot Feature" shape: a bordered, merged sentence row right on top of the table."""
    wb = Workbook()
    ws = wb.active
    ws.title = "Jackpot"
    ws.cell(2, 2, "JACKPOT FEATURE")
    ws.merge_cells("B2:H2")
    ws.cell(4, 2, sentence)
    ws.merge_cells("B4:H4")
    for c in range(2, 9):
        ws.cell(4, c).border = BOX
    for i, (a, b) in enumerate(ROWS):
        r = 5 + i
        ws.cell(r, 2, a)
        ws.cell(r, 5, b)
        ws.merge_cells(start_row=r, start_column=2, end_row=r, end_column=4)
        ws.merge_cells(start_row=r, start_column=5, end_row=r, end_column=8)
        for c in range(2, 9):
            ws.cell(r, c).border = BOX
    return ws


def _quiet(fn, *a, **k):
    with contextlib.redirect_stdout(io.StringIO()):
        return fn(*a, **k)


def test_a_sentence_on_top_of_a_table_stays_text_and_the_real_header_is_the_header():
    (t,) = _quiet(detect_tables_in_sheet, _sheet())
    assert t["start_row"] == 5 and t["header_row_indices"] == [5]


def test_a_short_title_on_top_of_a_table_is_still_its_title_row():
    (t,) = _quiet(detect_tables_in_sheet, _sheet("LETTER PRIZES"))
    assert t["start_row"] == 4 and t["header_row_indices"][0] == 4


def _tables(ws, spec=None):
    probe = _quiet(pb._prepare_tables, ws, {}, 12, ws.title)
    key = probe[0]["design_key"]
    ts = {"table_rows": {key: spec}} if spec else {}
    return key, _quiet(pb._prepare_tables, ws, ts, 12, ws.title)


def _roles(t):
    return {(c["row"], c["col"]): c["role"] for c in t["grid_cells"]}


def test_the_top_row_as_normal_text_leaves_the_table_and_the_next_row_is_the_header():
    key, (t,) = _tables(_sheet(), {"text": [0]})
    assert t["design_key"] == key                       # still the same table (its settings stay)
    assert (t["start_row"], t["end_row"]) == (6, 9) and t["head_rows"] == [6]
    assert _roles(t)[(6, 2)] == "header" and _roles(t)[(7, 2)] == "body"
    assert t["text_rows"] == [{"row": 5, "off": 0, "text": "Jackpot/Bonus Letter Prizes"}]


def test_a_middle_row_as_normal_text_splits_the_table_where_it_was():
    key, (top, low) = _tables(_sheet(), {"text": [2]})
    assert (top["start_row"], top["end_row"]) == (5, 6) and top["head_rows"] == [5]
    assert (low["start_row"], low["end_row"]) == (8, 9) and low["head_rows"] == []
    assert low["design_key"] == key + "#1" and low["rows_key"] == key and low["rows_start"] == 5
    assert top["design"] == low["design"]


def test_back_in_the_table_is_the_table_as_detected():
    _key, before = _tables(_sheet())
    _key, after = _tables(_sheet(), {"text": []})
    assert [(t["start_row"], t["end_row"], _roles(t)) for t in before] == [(t["start_row"], t["end_row"], _roles(t)) for t in after]


def test_rows_and_columns_set_as_header_or_normal():
    _key, (t,) = _tables(_sheet(), {"rows": {"0": "body", "3": "header"}, "cols": {"0": "header"}})
    r = _roles(t)
    assert r[(5, 5)] == "body"                          # the auto header row set Normal
    assert r[(8, 5)] == "header"                        # a body row set Header
    assert r[(6, 2)] == "header" and r[(7, 5)] == "body"   # the first column set Header
    assert t["head_rows"] == []                         # no header rows on top: nothing repeats on ✂ parts


def test_a_header_column_never_makes_its_rows_header_rows():
    ws = _sheet()
    _key, (t,) = _tables(ws, {"cols": {"0": "header"}})
    img = Image.new("RGBA", (1600, 1000))
    geo = {}
    pb._draw_auto_table(img, ImageDraw.Draw(img), Image, ImageFont, ws, t, 100, 0, 1400, {}, "", {}, {},
                        available_height=950, geo=geo)
    assert geo["header_rows"] == 1 and geo["row_offs"] == [0, 1, 2, 3, 4]


def test_a_merge_running_into_a_text_row_ends_above_it():
    table = {"start_row": 1, "end_row": 3, "min_col": 1, "max_col": 2, "design_key": "S|a", "header_row_indices": [1],
             "grid_cells": [{"row": 1, "col": 1, "value": "a", "rowspan": 1, "colspan": 2, "role": "header"},
                            {"row": 2, "col": 1, "value": "b", "rowspan": 2, "colspan": 1, "role": "body"},
                            {"row": 2, "col": 2, "value": "c", "rowspan": 1, "colspan": 1, "role": "body"},
                            {"row": 3, "col": 2, "value": "d", "rowspan": 1, "colspan": 1, "role": "body"}]}
    (t,) = tr.apply(table, {"text": [2]})
    assert [c for c in t["grid_cells"] if c["value"] == "b"][0]["rowspan"] == 1
    assert t["end_row"] == 2


def test_a_lower_piece_takes_its_tables_look_but_not_its_boxes():
    lays = {"S|a": {"outer": {"color": "#FF0000", "width": 3}, "cells": {"0,0": {"fill": "#00FF00"}},
                    "boxes": {"row:2": {"fill": "#0000FF"}, "col:1": {"bold": True}}}}
    lay = tr.piece_layout(lays, "S|a#1")
    assert lay["outer"]["color"] == "#FF0000" and "cells" not in lay and lay["boxes"] == {"col:1": {"bold": True}}
    assert tr.piece_layout(lays, "S|a") is lays["S|a"]
    lays["S|a#1"] = {"outer": {"width": 8}, "lines": "none"}       # set on the piece itself: on top of its table's look
    lay = tr.piece_layout(lays, "S|a#1")
    assert lay["outer"] == {"color": "#FF0000", "width": 8} and lay["lines"] == "none"


def _outer_img(ws, t, row_slice=None):
    ts = {"table_layouts": {t["design_key"]: {"outer": {"color": "#FF00FF", "width": 6}}}}
    img = Image.new("RGBA", (1600, 1000), (60, 60, 60, 255))
    geo = {}
    h = pb._draw_auto_table(img, ImageDraw.Draw(img), Image, ImageFont, ws, t, 100, 0, 1400, ts, "", {}, {},
                            available_height=950, geo=geo, row_slice=row_slice)
    return img, geo, h


def test_border_outside_is_the_tables_outside_edge_only():
    ws = _sheet()
    _key, (t,) = _tables(ws)
    img, geo, h = _outer_img(ws, t)
    x0, w = int(geo["x"]), int(sum(geo["cols"]))
    mag = (255, 0, 255)
    assert img.getpixel((x0 + 2, h // 2))[:3] == mag and img.getpixel((x0 + w - 3, h // 2))[:3] == mag
    assert img.getpixel((x0 + w // 2, 2))[:3] == mag and img.getpixel((x0 + w // 2, h - 3))[:3] == mag
    inner_line = int(geo["rows"][0])                   # the line between the header and the first row
    assert img.getpixel((x0 + w // 2, inner_line))[:3] != mag
    # a ✂ part has it round its own edge too
    img2, _g, h2 = _outer_img(ws, t, row_slice=(2, 4))
    assert img2.getpixel((x0 + w // 2, h2 - 3))[:3] == mag


def test_a_cut_part_of_a_table_with_a_header_column_repeats_only_the_header_row():
    ws = _sheet()
    _key, (t,) = _tables(ws, {"cols": {"0": "header"}})
    img = Image.new("RGBA", (1600, 1000))
    geo = {}
    pb._draw_auto_table(img, ImageDraw.Draw(img), Image, ImageFont, ws, t, 100, 0, 1400, {}, "", {}, {},
                        available_height=950, geo=geo, row_slice=(2, 4))
    assert len(geo["rows"]) == 3 and geo["header_rows"] == 1      # the header row + body rows 2..3
