"""The paytable reader (an AGR paytable sheet → one list per symbol) and the pay check (the page against
the Excel)."""
import os

import pytest
from openpyxl import Workbook

from ps_autotypesetter.dynamic_pages.paytable import pay_reader as pr

REF = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "ExcelFileForReference")


def _sheet(blocks, name_col="D", count_col="F", pay_col="H", start=13, gap=1):
    """blocks: [(label, [(count, pay), …])] written the AGR way: the label on the block's 2nd row."""
    wb = Workbook()
    ws = wb.active
    ws.title = "Paytable"
    ws["B3"] = "<GAME NAME> PAYTABLE"
    ws["B5"] = "<WILDX> substitutes for all symbols except <SCAT>."
    r = start
    for label, pays in blocks:
        for i, (cnt, pay) in enumerate(pays):
            ws[f"{count_col}{r + i}"] = cnt
            ws[f"{pay_col}{r + i}"] = pay
        if label is not None:
            ws[f"{name_col}{r + min(1, len(pays) - 1)}"] = label
        r += len(pays) + gap
    return ws


def _by(res):
    return {s["symbol"]: s for s in res["symbols"]}


def test_vertical_blocks_tokens_and_plain_names():
    ws = _sheet([("<PIC1>", [(5, 150), (4, 50), (3, 10), (2, 5)]), ("ACE", [(5, 50), (4, 10), (3, 5)]),
                 ("10", [(5, 50), (4, 10), (3, 5)])])
    res = pr.read_sheet(ws)
    s = _by(res)
    assert list(s) == ["PIC1", "ACE", "10"]
    assert [(p["count"], p["pay"]) for p in s["PIC1"]["pays"]] == [(5, 150), (4, 50), (3, 10), (2, 5)]
    assert s["PIC1"]["pays"][0]["pay_cell"] == "H13" and s["PIC1"]["cell"] == "D14"
    assert not res["problems"]


def test_a_ten_typed_as_a_number_is_still_a_symbol():
    ws = _sheet([("<PIC1>", [(5, 100), (4, 20), (3, 5)]), (10, [(5, 50), (4, 10), (3, 5)])])
    assert list(_by(pr.read_sheet(ws))) == ["PIC1", "10"]


def test_shifted_columns_and_a_grouped_symbol():
    ws = _sheet([("<PIC1>", [(5, 100), (4, 25), (3, 10)]), ("<A> / <K>", [(5, 30), (4, 15), (3, 5)])],
                name_col="E", count_col="G", pay_col="I")
    s = _by(pr.read_sheet(ws))
    assert s["A / K"]["group"] == ["A", "K"]
    assert [p["pay"] for p in s["A / K"]["pays"]] == [30, 15, 5]


def test_scatters_side_by_side_under_a_heading():
    ws = _sheet([("<PIC1>", [(5, 100), (4, 25), (3, 10)])])
    ws["C63"] = "Scatter"
    for i, (c, p) in enumerate([(5, 1500), (4, 750), (3, 200)]):
        ws[f"F{65 + i}"], ws[f"H{65 + i}"] = c, p
        ws[f"L{65 + i}"], ws[f"N{65 + i}"] = c, p
    ws["D66"], ws["J66"] = "<BG SCATTER>", "<FG SCATTER>"
    ws["C69"] = "pays in any position."
    s = _by(pr.read_sheet(ws))
    assert s["BG SCATTER"]["role"] == s["FG SCATTER"]["role"] == "scatter"
    assert s["FG SCATTER"]["pays"][0]["pay_cell"] == "N65"
    assert s["PIC1"]["role"] == ""


def test_what_doesnt_add_up_is_flagged():
    ws = _sheet([("<PIC1>", [(5, 100), (4, "lots"), (3, 10)]), (None, [(5, 9), (4, 8), (3, 7)]),
                 ("<PIC1>", [(3, 1), (4, 2), (5, 3)])])
    res = pr.read_sheet(ws)
    texts = " | ".join(p["text"] for p in res["problems"])
    assert "not a number" in texts                       # a pay that isn't one
    assert "no symbol next to them" in texts             # pays nobody names
    assert "listed twice" in texts                       # the same symbol twice
    assert "counts don't go down" in texts


def test_editor_notes_and_prose_are_not_symbols():
    ws = _sheet([("<PIC1>", [(5, 100), (4, 25), (3, 10)])])
    ws["P3"] = "Game Name with BRAND per agreement"
    ws["P5"] = "NOTE <BO> Symbol = <DYNAMIC SY>"
    res = pr.read_sheet(ws)
    assert list(_by(res)) == ["PIC1"]
    assert any("substitutes" in n["text"] for n in res["notes"])


def _page(res, drop=(), change=None):
    """A page like the auto layout makes it: per symbol a .pay slot (its counts) and a .value slot (its pays)."""
    maps, texts = {}, {}
    for s in res["symbols"]:
        if s["symbol"] in drop:
            continue
        key = "@slot." + s["symbol"].lower()
        maps[key + ".pay"] = {"source": ",".join(p["count_cell"] for p in s["pays"])}
        maps[key + ".value"] = {"source": ",".join(p["pay_cell"] for p in s["pays"])}
        texts[key + ".pay"] = "\n".join(str(p["count"]) for p in s["pays"])
        texts[key + ".value"] = "\n".join(str(p["pay"]) for p in s["pays"])
        if change and s["symbol"] in change:
            texts[key + ".value"] = change[s["symbol"]]
    return maps, texts


def test_the_pay_check_passes_a_page_that_shows_every_pay():
    res = pr.read_sheet(_sheet([("<PIC1>", [(5, 150), (4, 50), (3, 10)]), ("ACE", [(5, 50), (4, 10), (3, 5)])]))
    maps, texts = _page(res)
    out = pr.check_pays(res, maps, texts)
    assert out["ok"] and out["checked"] == 2 and not out["problems"]


def test_the_pay_check_finds_a_missing_symbol_a_wrong_number_and_a_hidden_box():
    res = pr.read_sheet(_sheet([("<PIC1>", [(5, 150), (4, 50), (3, 10)]), ("ACE", [(5, 50), (4, 10), (3, 5)]),
                                ("KING", [(5, 40), (4, 10), (3, 5)])]))
    maps, texts = _page(res, drop=("KING",), change={"ACE": "50\n100\n5"})
    out = pr.check_pays(res, maps, texts, hidden=["@slot.pic1.value"])
    texts = " | ".join(p["text"] for p in out["problems"])
    assert not out["ok"]
    assert "KING: its pays (40, 10, 5) are not on the page" in texts
    assert "ACE: the page shows 50, 100, 5 — the Excel says 50, 10, 5" in texts
    assert "<PIC1>: its pays don't fit" in texts
    assert [p["level"] for p in out["problems"] if "don't fit" in p["text"]] == ["warn"]


def test_cell_ranges_in_a_slot_source():
    assert pr._cells_of("F13:F15, Paytable!$H$5") == {"F13", "F14", "F15", "H5"}


REFERENCE = [("CE_Legend_Buffalo_GameRules_NYL.xlsm", "PAYTABLE", 13, "BUFFALO FG SCATTER", [1500, 750, 200]),
             ("CrazyChickens_InSpace_AGR_C2.xlsx", "Paytable", 10, "NINE", [20, 10, 5]),
             ("ThunderEmpire_MongolianEmpress_AGR_HHRE.xlsx", "Paytable-5lines", 10, "SCAT", [100, 10, 2]),
             ("paytable.xlsx", "Paytable", 10, "10", [50, 10, 5]),
             ("C2_Monopoly_AGR.xlsm", "Paytable(BaseBet50_25)", 9, "J", [50, 15, 5])]


@pytest.mark.parametrize("name,sheet,n,symbol,pays", REFERENCE)
def test_the_reference_agrs(name, sheet, n, symbol, pays):
    path = os.path.join(REF, name)
    if not os.path.isfile(path):
        pytest.skip("reference Excel not here")
    res = pr.read_workbook(path, sheet)[0]
    s = _by(res)
    assert len(s) == n
    assert [p["pay"] for p in s[symbol]["pays"]] == pays
    assert not [p for p in res["problems"] if p["level"] == "error"]


# ---- tiers, shared cards, suggested layouts ----
def test_tiers_card_ranks_low_specials_apart_excel_order_kept():
    ws = _sheet([("<PIC1>", [(5, 500), (4, 100), (3, 20)]), ("<COUGAR>", [(5, 250), (4, 80), (3, 10)]),
                 ("ACE", [(5, 100), (4, 20), (3, 5)]), ("<K>", [(5, 100), (4, 20), (3, 5)])])
    ws["C40"] = "Scatter"
    for i, (c, p) in enumerate([(5, 100), (4, 10), (3, 2)]):
        ws[f"F{42 + i}"], ws[f"H{42 + i}"] = c, p
    ws["D43"] = "<SCAT>"
    t = pr.tiers(pr.read_sheet(ws))
    assert t == {"pic1": "premium", "cougar": "premium", "a": "low", "k": "low", "scat": "special"}


def test_tiers_without_card_ranks_split_at_the_biggest_drop():
    ws = _sheet([("<P1>", [(5, 1000)]), ("<P2>", [(5, 800)]), ("<P3>", [(5, 750)]), ("<L1>", [(5, 100)]), ("<L2>", [(5, 80)])])
    t = pr.tiers(pr.read_sheet(ws))
    assert [t[k] for k in ("p1", "p2", "p3", "l1", "l2")] == ["premium"] * 3 + ["low"] * 2


def test_same_pays_runs_next_to_each_other():
    ws = _sheet([("ACE", [(5, 50), (4, 10)]), ("KING", [(5, 50), (4, 10)]), ("QUEEN", [(5, 40), (4, 10)]),
                 ("JACK", [(5, 40), (4, 10)]), ("10", [(5, 50), (4, 10)])])
    assert pr.same_pays(pr.read_sheet(ws)) == [["a", "k"], ["q", "j"]]
    assert pr.key_of("<ACE>") == pr.key_of("A") == "a" and pr.key_of("TEN") == "10"


def test_the_pay_check_accepts_a_shared_card():
    res = pr.read_sheet(_sheet([("ACE", [(5, 50), (4, 10), (3, 5)]), ("KING", [(5, 50), (4, 10), (3, 5)])]))
    maps, texts = _page(res, drop=("KING",))
    maps["@slot.ace"] = {"mode": "icon"}
    maps["@slot.king"] = {"mode": "icon"}                 # KING's picture on ACE's card
    assert pr.check_pays(res, maps, texts)["ok"]
    del maps["@slot.king"]                               # …but without its picture it is missing
    assert not pr.check_pays(res, maps, texts)["ok"]


def test_suggestions_put_the_own_design_first_then_the_best_scored():
    from ps_autotypesetter.dynamic_pages.paytable import suggest as sg

    res = pr.read_sheet(_sheet([("<PIC1>", [(5, 500)]), ("<PIC2>", [(5, 300)]), ("ACE", [(5, 50)]), ("KING", [(5, 50)]),
                                ("QUEEN", [(5, 40)])]))
    base = {"kind": "card_template", "bands": [{"name": "high", "per_row": 5}, {"name": "low", "per_row": 5}], "card": {}}
    seen = []

    def lay_out(t):
        seen.append(t)
        shrink = 1.0 if t.get("tiers") == "auto" and t["bands"][1]["per_row"] >= 2 else 0.7
        return {"ok": True, "overflow": [], "_template": {"mapper_meta": {"fit": shrink, "band_geo": {
            "high": {"size": [250, 180], "fit": shrink}, "low": {"size": [200, 150], "fit": shrink}}}}}

    out = sg.suggest(base, res, lay_out, own=True)
    assert out[0]["own"] and out[0]["label"] == "Your design as it is"
    assert len(out) == 3 and all(c["template"]["tiers"] == "auto" for c in out[1:])
    assert out[1]["score"] >= out[2]["score"] or out[2]["template"]["card"]["group_same_pays"] != out[1]["template"]["card"]["group_same_pays"]
    assert base.get("tiers") is None                     # the design itself is untouched
