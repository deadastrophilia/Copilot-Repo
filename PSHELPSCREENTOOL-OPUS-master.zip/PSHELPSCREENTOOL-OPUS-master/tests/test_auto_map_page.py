"""Zero-map convention path (the artist happy-path).

``engine_api.auto_map_page`` chains the existing convention engine end to end
with no manual mapping: resolve a bundled paytable layout -> auto-map every
``@slot.*`` against a conventionally-named sheet -> save the mapped JSON and
register it as the global ``dynamic_settings.template_json`` so the dynamic
router renders it on the next build.

These tests exercise the real chain against the committed example workbook.
``save_paytable_mapping`` mirrors the design into the tool's PaytableTemplates
library and copies it to the project root; the ``redirect_library`` fixture
points that library at a tmp dir so the suite never writes into the repo.
"""

import os

import pytest

from ps_autotypesetter.ui_web import engine_api, paytable_templates

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXAMPLE_XLSX = os.path.join(REPO_ROOT, "examples", "paytable.xlsx")

pytestmark = pytest.mark.skipif(
    not os.path.isfile(EXAMPLE_XLSX),
    reason="examples/paytable.xlsx fixture is required",
)


@pytest.fixture
def redirect_library(tmp_path, monkeypatch):
    """Keep the PaytableTemplates library mirror inside tmp so tests are hermetic."""
    lib = tmp_path / "PaytableTemplates"
    lib.mkdir()
    monkeypatch.setattr(paytable_templates, "templates_dir", lambda: str(lib))
    return lib


@pytest.fixture
def base_cfg(tmp_path):
    return {
        "excel_path": EXAMPLE_XLSX,
        "output_dir": str(tmp_path),
        "c_width": 1920,
        "c_height": 1080,
    }


def test_auto_map_page_auto_layout_fits_sheet(base_cfg, redirect_library):
    """Empty layout name -> the AUTO layout, generated to fit the sheet.

    The example workbook has 10 symbols (pic1..pic5 premium on top + ace/king/
    queen/jack/ten royals below). The generator names each cell for its real
    detected symbol -- top band pic1..pic5, lower band ace..ten -- each with its
    own icon + dotted pay/value columns, plus a full-width title and a catch-all
    text band. Naming the lower band for real symbols (not a continuous
    pic6..pic10) is what keeps the live-sheet render filter from dropping it.
    Every symbol keeps its pay and value grouped with it, the rules text
    collects into the `text` slot, and only the title is left unmapped (the
    renderer draws the page heading itself)."""
    result, _ = engine_api.auto_map_page(base_cfg, "Paytable", "")

    assert result["ok"] is True
    assert result["error"] == ""
    assert result["layout"] == "auto"  # empty layout_name -> generated default
    assert result["sheet_name"] == "Paytable"
    assert result["mapped"] == 31
    assert result["unmapped"] == ["@slot.title"]
    assert result["warnings"] and "1 slot" in result["warnings"][0]

    slots = result["_template"]["slots"]
    # top band = real premium names, lower band = real royal names (NOT pic6..).
    assert {"@slot.pic1", "@slot.pic1.pay", "@slot.pic1.value",
            "@slot.ten", "@slot.ten.pay", "@slot.ten.value",
            "@slot.title", "@slot.text"} <= set(slots)
    assert "@slot.pic6" not in slots  # no continuous numbering leaked
    # icon on the left, pay column then value column to its right (both bands).
    assert slots["@slot.pic1"]["x"] < slots["@slot.pic1.pay"]["x"] < slots["@slot.pic1.value"]["x"]
    assert slots["@slot.ten"]["x"] < slots["@slot.ten.pay"]["x"] < slots["@slot.ten.value"]["x"]

    by_slot = {m["slot"]: m for m in result["_mappings"]}
    # pic1 (top) keeps its own pay/value columns grouped with it.
    assert by_slot["@slot.pic1.pay"]["role"] == "pay"
    assert by_slot["@slot.pic1.pay"]["symbol"] == "pic1"
    assert by_slot["@slot.pic1.value"]["role"] == "value"
    # ten (lower band) is filled by its real name and grouped the same way.
    assert by_slot["@slot.ten.pay"]["role"] == "pay"
    assert by_slot["@slot.ten.pay"]["symbol"] == "ten"
    assert by_slot["@slot.ten.value"]["role"] == "value"
    # the descriptive rules text collects into the catch-all `text` slot.
    assert by_slot["@slot.text"]["mode"] == "excel"
    assert by_slot["@slot.text"]["text"].strip()


def test_auto_map_page_auto_centers_pay_value(base_cfg, redirect_library):
    """The default auto path centers each symbol's pay/value beside its icon.

    The generator places pay/value to the right of the icon in the icon's full
    band box; without the centering hint the automapper would top-align them
    (numbers riding above a centered icon). The generated slots carry a
    `vertical_align="center"` hint that `_slot_valign` reads, so pay/value render
    vertically centered on their box. Counts are unchanged by the hint."""
    result, _ = engine_api.auto_map_page(base_cfg, "Paytable", "")

    slots = result["_template"]["slots"]
    # both bands: pay/value boxes carry the center hint (icon has no hint).
    for key in ("@slot.pic1.pay", "@slot.pic1.value", "@slot.ten.pay", "@slot.ten.value"):
        assert slots[key].get("vertical_align") == "center"
    assert "vertical_align" not in slots["@slot.pic1"]  # icon box untouched
    # the hint does not disturb the map: counts match the fits-sheet baseline.
    assert result["mapped"] == 31
    assert result["unmapped"] == ["@slot.title"]


def test_auto_map_page_explicit_layout_is_not_regenerated(base_cfg, redirect_library):
    """An explicit named layout keeps its fixed slots (only "auto" regenerates)."""
    result, _ = engine_api.auto_map_page(base_cfg, "Paytable", "simple")

    assert result["ok"] is True
    assert result["layout"] == "simple"
    # SimplePaytable's fixed template maps 33 slots / leaves 4 empty.
    assert result["mapped"] == 33
    assert result["unmapped"] == ["title", "wild.title", "text.2", "text.3"]


def test_auto_map_page_registers_template_json(base_cfg, redirect_library):
    """The saved mapped JSON is registered as the global template_json and exists."""
    result, new_cfg = engine_api.auto_map_page(base_cfg, "Paytable", "")

    tj = new_cfg.get("dynamic_settings", {}).get("template_json")
    assert tj
    assert os.path.isfile(tj)
    assert result["path"] == tj
    # auto_map_page must not mutate the caller's cfg in place.
    assert "dynamic_settings" not in base_cfg


def test_auto_map_page_hands_off_template_and_mappings(base_cfg, redirect_library):
    """Private hand-off keys let the /api/auto_page route mint a preview token."""
    result, _ = engine_api.auto_map_page(base_cfg, "Paytable", "")

    assert isinstance(result["_template"], dict)
    assert result["_template"].get("slots")
    assert isinstance(result["_mappings"], list)
    assert len(result["_mappings"]) >= 1
    assert all(isinstance(m, dict) and m.get("slot") for m in result["_mappings"])


def test_auto_map_page_unknown_layout_falls_back_to_default(base_cfg, redirect_library):
    """An unknown layout name gracefully falls back to the bundled default."""
    result, _ = engine_api.auto_map_page(base_cfg, "Paytable", "no-such-layout-xyz")

    assert result["ok"] is True
    assert result["layout"] == "simple"
    assert result["mapped"] == 33


def test_auto_map_page_missing_excel(tmp_path, redirect_library):
    """No workbook -> a blocking, actionable error and the cfg is returned unchanged."""
    cfg = {"excel_path": "", "output_dir": str(tmp_path), "c_width": 1920, "c_height": 1080}
    result, new_cfg = engine_api.auto_map_page(cfg, "Paytable", "")

    assert result["ok"] is False
    assert "Excel" in result["error"]
    assert new_cfg is cfg  # unchanged on failure


def test_auto_map_page_no_sheet(base_cfg, redirect_library):
    """No sheet selected -> a blocking error, no JSON written."""
    result, new_cfg = engine_api.auto_map_page(base_cfg, "", "")

    assert result["ok"] is False
    assert "sheet" in result["error"].lower()
    assert new_cfg.get("dynamic_settings", {}).get("template_json") in (None, "")
