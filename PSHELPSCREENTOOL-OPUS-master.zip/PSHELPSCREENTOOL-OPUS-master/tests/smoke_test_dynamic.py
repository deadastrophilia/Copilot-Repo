import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from openpyxl import Workbook, load_workbook
from openpyxl.workbook.defined_name import DefinedName
from ps_autotypesetter.dynamic_pages.paytable.parser import parse_paytable_sheet
from ps_autotypesetter.dynamic_pages.paytable.flow_sources import (
    extract_flow_regions,
    resolve_source_blocks,
    template_flow_specs,
)
from ps_autotypesetter.dynamic_pages.router import should_handle_sheet
from ps_autotypesetter.dynamic_pages.template_loader import load_template_json, scale_template_slots

excel = os.path.join(ROOT, "examples", "paytable.xlsx")
template_path = os.path.join(ROOT, "examples", "Paytable.json")
worksheet = load_workbook(excel, data_only=False)["Paytable"]
data = parse_paytable_sheet(worksheet)

assert data["parser_summary"]["top_cards"] == 5, data["parser_summary"]
assert data["parser_summary"]["lower_cards"] == 5, data["parser_summary"]
assert data["parser_summary"]["all_cards"] == [
    "PIC1", "PIC2", "PIC3", "PIC4", "PIC5",
    "ACE", "KING", "QUEEN", "JACK", "10",
]
assert [(p["count"], p["value"]) for p in data["top_cards"][1]["payouts"]] == [
    ("5", "100"), ("4", "30"), ("3", "5")
]
assert data["flow_regions"] == []

flow_book = Workbook()
flow_sheet = flow_book.active
flow_sheet.title = "Paytable"
flow_sheet["B5"] = "First line with <Wild>"
flow_sheet["B6"] = "Second line"
flow_book.defined_names.add(DefinedName("PT_RULES_TOP", attr_text="'Paytable'!$B$5:$B$6"))

direct_blocks, direct_warning = resolve_source_blocks(flow_sheet, "B5:O6")
assert not direct_warning
assert [block["text"] for block in direct_blocks] == ["First line with <Wild>", "Second line"]

named_blocks, named_warning = resolve_source_blocks(flow_sheet, "PT_RULES_TOP")
assert not named_warning
assert [block["text"] for block in named_blocks] == ["First line with <Wild>", "Second line"]

flow_template = {
    "slots": {
        "FLOW|B5:O6": {"x": 100, "y": 100, "w": 600, "h": 200},
        "named_rules": {"x": 100, "y": 320, "w": 600, "h": 200},
    },
    "flow_regions": {
        "named_rules": {
            "source": "PT_RULES_TOP",
            "render_mode": "inline_flow",
            "gap": 12,
        }
    },
}
specs = template_flow_specs(flow_template)
assert [spec["slot"] for spec in specs] == ["named_rules", "FLOW|B5:O6"]
flow_regions, flow_warnings = extract_flow_regions(flow_sheet, flow_template)
assert not flow_warnings, flow_warnings
assert len(flow_regions) == 2
assert all(len(region["blocks"]) == 2 for region in flow_regions)

settings = {"enabled": True, "sheet_name": "Paytable"}
assert should_handle_sheet("Paytable", settings)
assert should_handle_sheet("PAYTABLE", settings)
assert not should_handle_sheet("Game Paytable", settings)
assert not should_handle_sheet("Rules", settings)

template = load_template_json(template_path)
slots, scale, _, _ = scale_template_slots(template, 1920, 1080)
assert round(scale, 4) == 0.5
assert "wild.icon.1" in slots and "wild.icon.2" in slots
assert round(slots["symbol.1"]["x"], 1) == 157.5

print("Dynamic addon smoke test passed.")
print(data["parser_summary"])
