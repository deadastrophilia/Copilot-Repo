"""Paylines / Win Lines pages (dynamic_pages/paylines.py)."""
import os

import pytest
from openpyxl import Workbook
from PIL import Image, ImageDraw, ImageFont

from ps_autotypesetter import png_builder
from ps_autotypesetter.dynamic_pages import paylines as pl

REF_XLSX = os.path.join(os.path.dirname(__file__), "..", "PSDRef", "BZZF_Blast_AGR_NYL.xlsx")
PATTERNS = [[1, 1, 1, 1, 1], [0, 0, 0, 0, 0], [2, 2, 2, 2, 2], [0, 1, 2, 1, 0], [2, 1, 0, 1, 2], [0, 0, 1, 2, 2]]


def _sheet(patterns=PATTERNS, denoms=(("1,2", 6), ("5,10", 3), ("$1, $2", 1)), title="Pay Lines", nbsp=True):
    wb = Workbook()
    ws = wb.active
    ws.title = title
    for c, h in enumerate(["Line", "Reel1", "Reel2", "Reel3", "Reel4", "Reel5"], start=2):
        ws.cell(2, c, h)
    for i, pat in enumerate(patterns, start=1):
        ws.cell(2 + i, 2, i)
        for c, v in enumerate(pat, start=3):
            ws.cell(2 + i, c, ("\xa0\xa0" + str(v)) if (nbsp and c > 3) else v)   # the real workbook stores " 1"
    if denoms:
        ws.cell(3, 10, "Denom")
        ws.cell(4, 10, "Paylines")
        for k, (label, count) in enumerate(denoms):
            ws.cell(3, 11 + k, label)
            ws.cell(4, 11 + k, count)
    return ws


def test_parse_lines_and_denominations():
    d = pl.parse(_sheet())
    assert d["errors"] == [] and d["reels"] == 5
    assert d["lines"][5] == [2, 1, 0, 1, 2]
    assert pl.variants(d) == [("1,2", 6), ("5,10", 3), ("$1, $2", 1)]


def test_column_layout_denominations_and_shared_counts():
    ws = _sheet(denoms=None)
    ws["J10"], ws["K10"] = "Denom", "Paylines"
    for r, (label, count) in enumerate([("1", 6), ("2", 6), ("5", 2)], start=11):
        ws.cell(r, 10, label)
        ws.cell(r, 11, count)
    assert pl.variants(pl.parse(ws)) == [("1, 2", 6), ("5", 2)]


def test_no_denominations_means_one_page_with_a_note():
    d = pl.parse(_sheet(denoms=None))
    assert pl.variants(d) == [("", 6)] and d["warnings"]


@pytest.mark.parametrize("mutate, expected", [
    (lambda ws: ws.cell(4, 4, 3), "is not a row index 0–2"),
    (lambda ws: setattr(ws.cell(5, 6), "value", None), "missing value"),
    (lambda ws: ws.cell(6, 2, 2), "appears twice"),
    (lambda ws: ws.cell(4, 11, 40), "needs 40 lines but the table has 6"),
    (lambda ws: ws.cell(3, 2, "one"), "not a whole number"),
])
def test_bad_data_is_reported_not_drawn(mutate, expected):
    ws = _sheet()
    mutate(ws)
    d = pl.parse(ws)
    assert any(expected in e for e in d["errors"]), d["errors"]
    with pytest.raises(pl.PaylineError):
        pl.render_pages(ws, {}, 2210, 1341, lambda name, count: (None, None, 0))


def test_missing_line_numbers_are_errors():
    ws = _sheet()
    ws.cell(5, 2, 9)                       # 1, 2, 9, 4 … — line 3 is gone
    assert any("missing: 3" in e for e in pl.parse(ws)["errors"])


def test_sheet_detection():
    assert pl.is_payline_sheet("Pay Lines") and pl.is_payline_sheet("Paylines") and pl.is_payline_sheet("Win Lines")
    assert pl.is_payline_sheet("Min Lines") and not pl.is_payline_sheet("Paytable")
    assert pl.is_payline_page(_sheet()) and not pl.is_payline_page(Workbook().active)


def test_layout_adapts_to_count():
    cfg = pl.settings_for({})
    p50, w50 = pl.layout(50, cfg, 2210, 1341)
    p25, _ = pl.layout(25, cfg, 2210, 1341)
    p5, _ = pl.layout(5, cfg, 2210, 1341)
    assert w50 is None and p50[0] == (176, 334) and p50[10][1] - p50[0][1] == cfg["pitch_y"]
    assert p25[0] == (176, 448) and p25[20][0] == p25[0][0]          # short last row stays left
    assert p5[0] == (646, 448)                                         # one row: centred (as the reference)
    _pos, warn = pl.layout(50, dict(cfg, columns=3), 2210, 1341)
    assert warn and "don't fit" in warn


def _render(ws, settings=None):
    def draw_page(name, count):
        page = Image.new("RGBA", (2210, 1341), (0, 0, 40, 255))
        png_builder._draw_background(page, Image, "", "color", "#000028")
        return page, ImageDraw.Draw(page), 200
    return pl.render_pages(ws, settings or {}, 2210, 1341, draw_page)


def _cell_rgb(page, cfg, origin, reel, row):
    g, o = cfg["cell_gap"], cfg["outline"]
    x = origin[0] + o + g + reel * (cfg["cell_w"] + g) + cfg["cell_w"] // 2
    y = origin[1] + o + g + row * (cfg["cell_h"] + g) + cfg["cell_h"] // 2
    return page.getpixel((x, y))[:3]


def test_rendered_cells_follow_the_excel():
    ws = _sheet()
    pages, _w = _render(ws)
    assert [n for n, _p in pages] == ["Pay Lines 6L", "Pay Lines 3L", "Pay Lines 1L"]
    cfg = pl.settings_for({})
    page = pages[0][1]
    pos, _ = pl.layout(6, cfg, 2210, 1341)
    for n, pat in enumerate(PATTERNS, start=1):
        for reel in range(1, 5):                   # reel 1's top cell can sit under the badge
            for row in range(3):
                rgb = _cell_rgb(page, cfg, pos[n - 1], reel, row)
                want = pl.line_rgb(n, cfg) if pat[reel] == row else (255, 255, 255)
                assert rgb == want, (n, reel, row, rgb)


def test_settings_change_the_drawing():
    pages, _ = _render(_sheet(), {"paylines": {"highlight_mode": "fixed", "highlight_rgb": "#FF0000", "cell_rgb": "#000000"}})
    cfg = pl.settings_for({"paylines": {}})
    pos, _ = pl.layout(6, cfg, 2210, 1341)
    assert _cell_rgb(pages[0][1], cfg, pos[0], 2, 1) == (255, 0, 0)
    assert _cell_rgb(pages[0][1], cfg, pos[0], 2, 0) == (0, 0, 0)


def test_psd_layers_are_grouped_per_line():
    from ps_autotypesetter.psd_writer import recorder

    rec = recorder.LayerRecorder()
    with rec.recording():
        pages, _ = _render(_sheet(patterns=PATTERNS[:2], denoms=None))
    page = rec.page_for(pages[0][1])
    shapes = [(s.name, s.group) for s in page.shapes]
    assert shapes[:3] == [("Line 1 badge", "Line 1"), ("Line 1 cells", "Line 1"), ("Line 1 grid", "Line 1")]
    texts = [(t.name, t.group, t.text) for t in page.texts]
    assert ("Line 2 number", "Line 2", "2") in texts


def test_preflight_blocks_bad_payline_data(tmp_path):
    from ps_autotypesetter.ui_web import engine_api

    ws = _sheet()
    ws.cell(4, 4, 7)
    path = tmp_path / "bad.xlsx"
    ws.parent.save(path)
    pf = engine_api.preflight(dict(engine_api.DEFAULT_CONFIG, excel_path=str(path)))
    assert any(b.get("code") == "paylines_data" and "D4" in b["message"] for b in pf["blocking"])


@pytest.mark.skipif(not os.path.isfile(REF_XLSX), reason="reference workbook not available")
def test_reference_workbook():
    from openpyxl import load_workbook

    ws = load_workbook(REF_XLSX, data_only=True)["Pay Lines"]
    d = pl.parse(ws)
    assert d["errors"] == [] and len(d["lines"]) == 50
    assert pl.variants(d) == [("1,2", 50), ("5,10", 25), ("$1, $2", 5)]
    assert d["lines"][1] == [1, 1, 1, 1, 1] and d["lines"][5] == [2, 1, 0, 1, 2]
    pages, warnings = _render(ws)
    assert [n for n, _p in pages] == ["Pay Lines 50L", "Pay Lines 25L", "Pay Lines 5L"] and not warnings


def test_users_pick_which_pages_are_built():
    ws = _sheet()
    pages, warnings = _render(ws, {"paylines": {"pages_off": [3]}})
    assert [n for n, _p in pages] == ["Pay Lines 6L", "Pay Lines 1L"] and not warnings
    pages, warnings = _render(ws, {"paylines": {"pages_off": [6, 3, 1]}})
    assert pages == [] and any("switched off" in w for w in warnings)
    listed = pl.page_list(pl.parse(ws), pl.settings_for({"paylines": {"pages_off": ["3"]}}))
    assert [(p["count"], p["on"]) for p in listed] == [(6, True), (3, False), (1, True)]


def test_preview_can_render_a_page_that_is_switched_off():
    pages, _w = pl.render_pages(_sheet(), {"paylines": {"pages_off": [3]}}, 2210, 1341,
                                lambda name, count: _render_page(), counts=[3])
    assert [n for n, _p in pages] == ["Pay Lines 3L"]


def _render_page():
    page = Image.new("RGBA", (2210, 1341), (0, 0, 40, 255))
    png_builder._draw_background(page, Image, "", "color", "#000028")
    return page, ImageDraw.Draw(page), 200


def test_block_box_wraps_grids_and_badges():
    cfg = pl.settings_for({})
    pos, _ = pl.layout(5, cfg, 2210, 1341)
    gw, gh = pl.grid_size(cfg, 5, 3)
    box = pl.block_box(5, cfg, 2210, 1341)
    assert box[0] == pos[0][0] and box[1] == pos[0][1] + cfg["badge_dy"]
    assert box[2] == pos[-1][0] + gw and box[3] == pos[-1][1] + gh


# ── other ways AGRs draw their lines ─────────────────────────────────────────
from openpyxl.styles import Border, PatternFill, Side

_THIN = Side(style="thin")
_BOX = Border(left=_THIN, right=_THIN, top=_THIN, bottom=_THIN)
REF_DIR = os.path.join(os.path.dirname(__file__), "..", "ExcelFileForReference")


def _grid_sheet(patterns=PATTERNS, mark="X", first=1, title="Paylines", per_row=3):
    """Numbered 5x3 grids, the line's cells marked: "X", " " (Excel colours it) or "fill"."""
    wb = Workbook()
    ws = wb.active
    ws.title = title
    for i, pat in enumerate(patterns):
        top, left = 3 + (i // per_row) * 5, 2 + (i % per_row) * 7
        ws.cell(top, left, first + i)
        for reel, row in enumerate(pat):
            for r in range(3):
                cell = ws.cell(top + 1 + r, left + reel)
                cell.border = _BOX
                hit = r == row
                if mark == "X":
                    cell.value = "X" if hit else None
                elif mark == "space":
                    cell.value = " " if hit else ""
                elif hit:
                    cell.fill = PatternFill("solid", fgColor="FFE91E63")
    return ws


@pytest.mark.parametrize("mark", ["X", "space", "fill"])
def test_line_grids_are_read(mark):
    ws = _grid_sheet(mark=mark)
    assert pl.is_payline_page(ws)
    d = pl.parse(ws)
    assert d["form"] == "grid" and not d["errors"]
    assert (d["reels"], d["rows"]) == (5, 3)
    assert [d["lines"][n] for n in sorted(d["lines"])] == PATTERNS


def test_a_grid_with_two_marks_in_a_reel_is_an_error_naming_the_cells():
    ws = _grid_sheet()
    ws.cell(4, 2, "X")                                   # line 1, reel 1: top AND middle
    errs = pl.parse(ws)["errors"]
    assert any("line 1, reel 1" in e and "B4:B6" in e for e in errs)


def test_a_sheet_carrying_on_from_another_shows_its_own_line_numbers():
    d = pl.parse(_grid_sheet(first=51, title="WIN LINES 2"))
    assert not d["errors"] and sorted(d["lines"]) == list(range(51, 57))
    page = pl.page_list(d, pl.settings_for({}))[0]
    assert (page["first"], page["last"], page["count"]) == (51, 56, 6)
    assert pl.line_numbers(d, page["count"]) == list(range(51, 57))


def test_payline_counts_written_as_ranges_and_rows_counted_from_one():
    ws = _sheet(patterns=[[p + 1 for p in pat] for pat in PATTERNS], denoms=(("1,2", "1-6"), ("5", "1-3")), nbsp=False)
    d = pl.parse(ws)
    assert not d["errors"]
    assert d["lines"][4] == [0, 1, 2, 1, 0]                # 1 top … 3 bottom, read as 0…2
    assert pl.variants(d) == [("1,2", 6), ("5", 3)]


def test_a_page_switched_off_in_one_sheet_stays_on_in_another():
    a, b = pl.parse(_grid_sheet(title="WIN LINES 1")), pl.parse(_grid_sheet(title="WIN LINES 2"))
    cfg = pl.settings_for({"paylines": {"pages_off": ["WIN LINES 1|6"]}})
    assert [p["on"] for p in pl.page_list(a, cfg)] == [False]
    assert [p["on"] for p in pl.page_list(b, cfg)] == [True]
    legacy = pl.settings_for({"paylines": {"pages_off": [6]}})        # older saves: that count everywhere
    assert [p["on"] for p in pl.page_list(b, legacy)] == [False]


@pytest.mark.parametrize("name, sheet, lines", [
    ("C2_Monopoly_AGR.xlsm", "Line Patterns", 50),
    ("CrazyChickens_InSpace_AGR_C2.xlsx", "Paylines", 50),
    ("ThunderEmpire_MongolianEmpress_AGR_HHRE.xlsx", "WIN LINES 2 (50&100lines)", 50),
])
@pytest.mark.parametrize("read_only", [False, True])
def test_reference_agrs(name, sheet, lines, read_only):
    path = os.path.join(REF_DIR, name)
    if not os.path.isfile(path):
        pytest.skip("reference AGR not here")
    from openpyxl import load_workbook

    wb = load_workbook(path, data_only=True, read_only=read_only)
    assert pl.is_payline_page(wb[sheet])
    d = pl.parse(wb[sheet])
    assert not d["errors"] and len(d["lines"]) == lines
    assert all(len(p) == 5 and all(0 <= v < 3 for v in p) for p in d["lines"].values())
