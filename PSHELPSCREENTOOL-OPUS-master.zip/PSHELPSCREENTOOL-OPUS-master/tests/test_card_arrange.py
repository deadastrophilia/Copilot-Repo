"""The artist's own arrangement of paytable cards (dragged / right-clicked on the Canvas): card order,
a card moved to the other row, symbols sharing a card only when they pay the same."""
import copy
import os

import pytest

from ps_autotypesetter.dynamic_pages.paytable import card_templates as ct
from ps_autotypesetter.ui_web import engine_api

REF = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "ExcelFileForReference", "paytable.xlsx")
pytestmark = pytest.mark.skipif(not os.path.isfile(REF), reason="reference Excel not here")


def _rows(**changes):
    t = copy.deepcopy(ct.get_template("classic_cards"))
    for k, v in changes.items():
        if k == "card":
            t["card"].update(v)
        else:
            t[k] = v
    cfg = dict(engine_api.DEFAULT_CONFIG, excel_path=REF)
    res, _ = engine_api.auto_map_page(cfg, "Paytable", "", {"card_template": t, "dry_run": True})
    assert res["ok"]
    slots = res["_template"]["slots"]
    cards = sorted(((b["y"], b["x"], k[len("@slot."):-len(".card")]) for k, b in slots.items() if k.endswith(".card")))
    lines, out = [], []
    for y, x, name in cards:
        if not lines or abs(y - lines[-1]) > 5:
            lines.append(y)
            out.append([])
        out[-1].append(name)
    icons = {k[len("@slot."):] for k in slots if k.count(".") == 1}
    return out, icons


def test_as_designed():
    rows, _ = _rows()
    assert rows[0][:2] == ["pic1", "pic2"] and "ace" in rows[-1] + rows[-2]


def test_card_order_and_a_card_moved_to_the_other_row():
    rows, _ = _rows(card_order=["pic2", "pic1", "pic3", "pic4", "pic5"], row_of={"ace": "high"})
    top = [n for r in rows for n in r if n.startswith("pic") or n == "ace"]
    assert top[:2] == ["pic2", "pic1"]
    flat = [n for r in rows for n in r]
    assert flat.index("ace") < flat.index("king")      # ace now ends the top row, before the low row


def test_symbols_that_pay_the_same_share_a_card_others_never():
    rows, icons = _rows(card={"shared": [["ace", "king"], ["queen", "pic1"]]})
    flat = [n for r in rows for n in r]
    assert "king" not in flat and "ace" in flat         # ACE and KING pay the same: one card…
    assert {"ace", "king"} <= icons                     # …with both pictures on it
    assert "queen" in flat and "pic1" in flat           # QUEEN and PIC1 don't: never shared


def test_unshared_wins_over_automatic_sharing():
    rows, _ = _rows(card={"group_same_pays": "low", "unshared": ["ace", "king"]})
    flat = [n for r in rows for n in r]
    assert "ace" in flat and "king" in flat


# ---- the rules text, dividers, a card's own size (compiled without a sheet) ----
_STRUCT = {"top": 5, "lower": 5, "block_keys": ["pic1", "pic2", "pic3", "pic4", "pic5", "ace", "king", "queen", "jack", "ten"]}


def _doc(mutate, ctx=None):
    t = copy.deepcopy(ct.get_template("classic_cards"))
    mutate(t)
    doc, maps = ct.compile_template(t, _STRUCT, None, dict({"canvas": (1920, 1080), "body_size": 44}, **(ctx or {})))
    return doc, maps


def test_a_rules_box_with_no_place_takes_the_biggest_free_space_at_the_paragraph_size():
    doc, maps = _doc(lambda t: t["page"].update(texts=[{"id": "notes"}]))
    b, cards = doc["mapper_meta"]["blocks"]["text:notes"], doc["mapper_meta"]["blocks"]["cards"]
    assert b[3] - b[1] > 150                                        # bigger than the old 150 px strip
    assert b[3] <= cards[1] or b[1] >= cards[3] or b[0] >= cards[2] or b[2] <= cards[0]   # never on the cards
    assert maps["@slot.text"]["font_size"] == 44                    # the other pages' paragraph size


def test_a_rules_box_placed_by_hand_stays_unless_asked():
    doc, _ = _doc(lambda t: t["page"].update(texts=[{"id": "notes", "rect": [100, 900, 600, 120]}]))
    assert [round(v) for v in doc["mapper_meta"]["blocks"]["text:notes"]] == [100, 900, 700, 1020]
    doc, _ = _doc(lambda t: t["page"].update(texts=[{"id": "notes", "rect": [100, 900, 600, 120], "fill_space": True}]))
    assert doc["mapper_meta"]["blocks"]["text:notes"][1] != 900


def test_dividers_between_the_symbol_the_counts_and_the_pays():
    def on(t):
        t["card"]["dividers"] = {"enabled": True, "color": "#ffd200", "width": 3}
        t["card_overrides"] = {"pic2": {"dividers": {"numbers": False}}}
    doc, maps = _doc(on)
    s = doc["slots"]
    assert s["@slot.pic1.div1"]["h"] > s["@slot.pic1.div1"]["w"] == 3     # upright: symbol | counts
    assert "@slot.pic1.div2" in s and "@slot.pic2.div2" not in s          # one card without its second line
    assert maps["@slot.pic1.div1"]["shape"]["fill"] == "#ffd200"


def test_one_card_bigger_than_the_others_in_its_row():
    doc, _ = _doc(lambda t: t.update(card_overrides={"pic1": {"size": 130}}))
    s = doc["slots"]
    assert s["@slot.pic1.card"]["w"] > s["@slot.pic2.card"]["w"] * 1.2
    assert s["@slot.pic1.card"]["x"] + s["@slot.pic1.card"]["w"] < s["@slot.pic2.card"]["x"]   # no overlap


def test_a_row_moved_by_hand_starts_where_it_was_dropped():
    def m(t):
        t["bands"][1].update(pos=[400, 620], card_w=200, card_h=120)
    doc, _ = _doc(m)
    low = doc["mapper_meta"]["blocks"]["low"]
    assert round(low[0]) == 400 and round(low[1]) == 620                # not re-centred in a page-wide box
