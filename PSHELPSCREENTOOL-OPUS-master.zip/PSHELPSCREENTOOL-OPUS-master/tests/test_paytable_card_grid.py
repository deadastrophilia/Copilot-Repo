"""Excel-driven paytable card grid: <ace> split + re-laid bands on fixed templates."""

import os

from openpyxl import Workbook, load_workbook

from ps_autotypesetter.dynamic_pages.paytable import card_grid
from ps_autotypesetter.ui_web import engine_api


def _sheet(tmp_path, anchors):
    wb = Workbook()
    ws = wb.active
    ws.title = "Paytable"
    row = 2
    for label in anchors:
        ws.cell(row=row, column=1, value=label)
        for i, (p, v) in enumerate(((5, 100), (4, 25), (3, 5))):
            ws.cell(row=row + 1 + i, column=6, value=p)
            ws.cell(row=row + 1 + i, column=8, value=v)
        row += 6
    path = os.path.join(str(tmp_path), "pt.xlsx")
    wb.save(path)
    return load_workbook(path, data_only=True)["Paytable"]


def _five_five(prefix=""):
    slots, mappings = {}, {}
    for band, names, y in (("Top", ["pic1", "pic2", "pic3", "pic4", "pic5"], 100),
                           ("Bottom", ["ace", "king", "queen", "jack", "ten"], 600)):
        for i, n in enumerate(names, start=1):
            x = 100 + (i - 1) * 300
            slots[f"{prefix}{band}CardsBG.{i}"] = {"x": x, "y": y, "w": 280, "h": 450}
            slots[f"{prefix}{n}"] = {"x": x + 40, "y": y + 10, "w": 200, "h": 200}
            slots[f"{prefix}{n}.pay"] = {"x": x + 10, "y": y + 230, "w": 120, "h": 200}
            slots[f"{prefix}{n}.value"] = {"x": x + 150, "y": y + 230, "w": 120, "h": 200}
            mappings[f"{prefix}{n}"] = {"mode": "icon", "token": f"<{n}>"}
            mappings[f"{prefix}{n}.pay"] = {"mode": "excel", "role": "pay", "font_size": 40, "color": "#ffdd00"}
            mappings[f"{prefix}{n}.value"] = {"mode": "excel", "role": "value", "font_size": 40}
            mappings[f"{prefix}{band}CardsBG.{i}"] = {"mode": "text", "background_color": "#101030"}
    slots[f"{prefix}title"] = {"x": 100, "y": 10, "w": 1500, "h": 80}
    return {"canvas": {"width": 1920, "height": 1200}, "slots": slots, "mappings": mappings,
            "mapper_meta": {"generated_by": "web_paytable_mapper"}}


FOUR_SIX = ["<PIC1>", "<PIC2>", "<PIC3>", "<SPACESHIP>", "Ace", "KING", "QUEEN", "JACK", "TEN", "NINE"]


def test_bottom_band_starts_at_ace(tmp_path):
    ws = _sheet(tmp_path, FOUR_SIX)
    counts = engine_api.automap_paytable_slots_ws(ws, _five_five())["card_counts"]
    assert counts == {"top": 4, "lower": 6}


def test_template_bands_from_card_backgrounds():
    bands = card_grid.template_bands(_five_five())
    assert [len(r) for r in bands["top"]] == [5] and [len(r) for r in bands["bottom"]] == [5]
    assert bands["top"][0][0]["members"]["bg"] == "TopCardsBG.1"


def test_four_six_sheet_on_five_five_template(tmp_path):
    ws = _sheet(tmp_path, FOUR_SIX)
    notes = []
    out = card_grid.adapt(_five_five(), ws, notes)
    s, m = out["slots"], out["mappings"]
    # one card per Excel card, named by its symbol, reading its own rows
    for key in ("pic1", "pic2", "pic3", "spaceship", "ace", "king", "queen", "jack", "ten", "nine"):
        assert key in s and f"{key}.pay" in s and f"{key}.value" in s
    assert "pic4" not in s and "pic5" not in s
    assert m["spaceship"]["token"] == "<spaceship>"
    assert m["nine.pay"]["role"] == "pay" and m["nine.pay"]["source"].startswith("F")
    assert m["spaceship.value"]["source"].startswith("H")
    assert sum(1 for n in s if n.startswith("TopCardsBG.")) == 4
    assert sum(1 for n in s if n.startswith("BottomCardsBG.")) == 6
    # 4 top cards keep the design's size and sit centred in the top area
    assert s["pic1"]["w"] == 200
    xs = [s[k]["x"] for k in ("pic1", "pic2", "pic3", "spaceship")]
    left_margin = xs[0] - 40 - 100
    right_margin = (100 + 5 * 300 - 20) - (xs[-1] - 40 + 280)
    assert abs(left_margin - right_margin) < 1
    # 6 bottom cards are shrunk to fit the bottom area, fonts too
    assert s["nine"]["x"] + s["nine"]["w"] <= 100 + 5 * 300 - 20 + 1
    assert m["ace.pay"]["font_size"] < 40
    # backgrounds are drawn first (under symbols and pays)
    assert next(iter(s)).startswith(("TopCardsBG", "BottomCardsBG"))
    assert "title" in s and any("Excel has 4" in n for n in notes)


def test_matching_sheet_leaves_the_design_untouched(tmp_path):
    ws = _sheet(tmp_path, ["<PIC1>", "<PIC2>", "<PIC3>", "<PIC4>", "<PIC5>", "ACE", "KING", "QUEEN", "JACK", "TEN"])
    t = _five_five()
    out = card_grid.adapt(t, ws)
    assert out["slots"] == t["slots"]


def test_hand_picked_symbol_survives_regrid(tmp_path):
    ws = _sheet(tmp_path, FOUR_SIX)
    t = _five_five(prefix="@slot.")
    t["mappings"]["@slot.pic4"].update(asset_path="C:/art/train.png", symbol_pinned=True, symbol="spaceship")
    out = card_grid.adapt(t, ws)
    assert out["mappings"]["@slot.spaceship"]["asset_path"] == "C:/art/train.png"
    assert "@slot.nine" in out["slots"]


def test_band_box_scales_and_moves_the_cards(tmp_path):
    ws = _sheet(tmp_path, FOUR_SIX)
    t = _five_five()
    info = {}
    base = card_grid.adapt(t, ws, info=info)
    assert info["top"]["managed"] and len(info["top"]["cards"]) == 4
    assert set(info["top"]["hidden"]) >= {"pic5", "pic5.pay", "TopCardsBG.5"}
    # double the top band box: the four cards grow with it
    box = info["top"]["box"]
    t["mapper_meta"]["card_grid"] = {"bands": {"top": {"box": {"x": box[0], "y": box[1] + 50,
                                                              "w": box[2] * 2, "h": box[3] * 2}}}}
    info2 = {}
    big = card_grid.adapt(t, ws, info=info2)
    assert info2["top"]["scale"] > 1.5
    assert big["slots"]["pic1"]["w"] > base["slots"]["pic1"]["w"] * 1.5
    assert big["mappings"]["pic1.pay"]["font_size"] > 40


def test_band_box_on_matching_band_takes_over(tmp_path):
    ws = _sheet(tmp_path, ["<PIC1>", "<PIC2>", "<PIC3>", "<PIC4>", "<PIC5>", "ACE", "KING", "QUEEN", "JACK", "TEN"])
    t = _five_five()
    t["mapper_meta"]["card_grid"] = {"bands": {"bottom": {"box": {"x": 100, "y": 700, "w": 1480, "h": 450}}}}
    info = {}
    out = card_grid.adapt(t, ws, info=info)
    assert not info["top"]["managed"] and info["bottom"]["managed"]
    assert out["slots"]["ace"]["y"] >= 700


def test_symbol_picked_on_a_generated_card_is_kept(tmp_path):
    ws = _sheet(tmp_path, FOUR_SIX)
    t = _five_five()
    t["mappings"]["nine"] = {"mode": "icon", "token": "<nine>", "asset_path": "C:/art/nine.png",
                             "symbol_pinned": True, "icon_height": 12}
    out = card_grid.adapt(t, ws)
    assert out["mappings"]["nine"]["asset_path"] == "C:/art/nine.png"
    assert out["mappings"]["nine"].get("icon_height") != 12      # sizes follow the band, not the stale pick


def test_layout_puts_pays_right_and_keeps_each_card_together(tmp_path):
    ws = _sheet(tmp_path, FOUR_SIX)
    t = _five_five()
    t["mapper_meta"]["card_grid"] = {"bands": {"top": {"layout": {"pays": "right", "gap": 10, "gutter": 30}}}}
    info = {}
    out = card_grid.adapt(t, ws, info=info)
    s = out["slots"]
    for key in ("pic1", "spaceship"):
        sym, pay, val, = s[key], s[key + ".pay"], s[key + ".value"]
        assert pay["x"] > sym["x"] + sym["w"]                # pays to the right of ITS symbol (gap scales with the band)
        assert val["x"] >= pay["x"] + pay["w"]               # values right after its pays
    assert s["pic2"]["x"] > s["pic1.value"]["x"] + s["pic1.value"]["w"]   # next card starts after card 1
    assert info["top"]["proto"]["pay"] == "pic1.pay" and "pay" in info["top"]["cards"][0]["parts"]


def test_layout_cards_per_row(tmp_path):
    ws = _sheet(tmp_path, FOUR_SIX)
    t = _five_five()
    t["mapper_meta"]["card_grid"] = {"bands": {"bottom": {"layout": {"cols": 3}}}}
    out = card_grid.adapt(t, ws)
    ys = sorted({round(out["slots"][k]["y"]) for k in ("ace", "king", "queen", "jack", "ten", "nine")})
    assert len(ys) == 2                                      # 6 cards, 3 per row -> 2 rows


def test_one_card_can_have_its_own_look(tmp_path):
    ws = _sheet(tmp_path, FOUR_SIX)
    t = _five_five()
    t["mappings"]["pic3.pay@card"] = {"slot": "pic3.pay@card", "color": "#00ff66",
                                      "source": "Z1", "role": "value"}     # data fields are not overridable
    t["mappings"]["pic1.pay@card"] = {"slot": "pic1.pay@card", "color": "#112233"}   # card 1 = the prototype
    out = card_grid.adapt(t, ws)
    m = out["mappings"]
    assert m["pic3.pay"]["color"] == "#00ff66" and m["pic2.pay"]["color"] == "#ffdd00"
    assert m["pic3.pay"]["role"] == "pay" and m["pic3.pay"]["source"].startswith("F")
    assert m["pic1.pay"]["color"] == "#112233" and m["spaceship.pay"]["color"] == "#ffdd00"


def test_sheet_coverage_flags_cells_not_on_the_page(tmp_path):
    from ps_autotypesetter.ui_web import engine_api as e

    ws = _sheet(tmp_path, FOUR_SIX)
    ws["B60"] = "A rule nobody placed on the page."
    t = _five_five()
    cov = e.paytable_sheet_coverage(t, None, ws, "pt.xlsx")
    unused = {u["ref"] for u in cov["unused"]}
    assert "B60" in unused
    used = {c["ref"] for row in cov["rows"] for c in row["cells"] if c["used"]}
    assert {"A2", "F3", "H3"} <= used          # spaceship? no: first card anchor + its pay/value cells
