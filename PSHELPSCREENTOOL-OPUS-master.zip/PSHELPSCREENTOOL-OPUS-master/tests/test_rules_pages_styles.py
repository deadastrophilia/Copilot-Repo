"""Game Rules / Bingo Rules page styling keys: legal colour, paragraph strips, own font / size / colour,
per-row Bingo looks, and the reports the studio reads (blocks, bg, cells[].size / rgb).

Pages are rendered in memory (no output folder is touched)."""

import os

import pytest
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font

from ps_autotypesetter import png_builder

REF = r"E:\Work\ClaudeCode\DataForHelpScreenTool\Jactpot-carn-help\JackpotCarnivalBuffalo_GameRules_NYL.xlsm"


def _common(ws, name, ds, report, **kw):
    Image, ImageDraw, ImageFont = png_builder._require_pillow()
    args = (Image, ImageDraw, ImageFont, ws, name, "", "stretch", "#FFFFFF", 1920, 1080,
            "Arial", 72, 48, "#FF5050", "Arial", 30, 24, "#101010", 100, 120, 40, 80, 4, 12,
            "", {}, {}, ds, {})
    fn = png_builder._render_bingo_rules_png_pages if name.startswith("BINGO") else png_builder._render_game_rules_png_pages
    return fn(*args, report=report, **kw)


@pytest.fixture(scope="module")
def rules_ws():
    if not os.path.isfile(REF):
        pytest.skip("reference workbook not available")
    wb = load_workbook(REF, read_only=False)
    name = next(n for n in wb.sheetnames if png_builder._normalized_sheet_kind(n) == "game_rules")
    return wb[name], name


def _gr(rules_ws, ds):
    ws, name = rules_ws
    rep = {}
    page = _common(ws, name, ds, rep)[0]
    return page, rep


def _legal_pixels(page, rep):
    x0, y0, x1, y1 = [int(v) for v in rep["blocks"]["legal"]]
    return page.convert("RGB").crop((x0, y0, x1, y1))


def test_game_rules_blocks_reported(rules_ws):
    _page, rep = _gr(rules_ws, {})
    assert rep["blocks"]["rules"] and len(rep["blocks"]["rules"]) == 4
    assert rep["bg"] == {"rules": None, "legal": None}
    parts = {ln["part"] for ln in rep["lines"]}
    assert "rules" in parts


def test_legal_colour_key(rules_ws):
    page0, rep0 = _gr(rules_ws, {})
    if not rep0["blocks"]["legal"]:
        pytest.skip("sheet has no legal text")
    page1, rep1 = _gr(rules_ws, {"game_rules_bottom_rgb": "#00FF00"})
    assert rep0["blocks"]["legal"] == rep1["blocks"]["legal"]
    assert _legal_pixels(page0, rep0).tobytes() != _legal_pixels(page1, rep1).tobytes()
    greens = [p for p in _legal_pixels(page1, rep1).getdata() if p[1] > 200 and p[0] < 60 and p[2] < 60]
    assert greens
    # the rules paragraph stays as it was
    assert rep0["blocks"]["rules"] == rep1["blocks"]["rules"]


def test_strip_behind_rules_paragraph(rules_ws):
    page0, rep0 = _gr(rules_ws, {})
    strip = {"on": True, "fill": "#0000FF", "fill_opacity": 100, "radius": 0, "pad": 20}
    page1, rep1 = _gr(rules_ws, {"game_rules_rules_bg": strip})
    r = rep1["bg"]["rules"]
    assert r and rep1["blocks"]["rules"] == rep0["blocks"]["rules"]
    x0, y0, x1, y1 = rep1["blocks"]["rules"]
    assert r[0] == pytest.approx(x0 - 20, abs=0.2) and r[1] == pytest.approx(y0 - 20, abs=0.2)
    assert r[2] == pytest.approx(x1 - x0 + 40, abs=0.2)
    # a pixel inside the strip but outside the text is now blue
    px = page1.convert("RGB").getpixel((int(r[0]) + 4, int(r[1]) + 4))
    assert px == (0, 0, 255)
    assert page0.convert("RGB").getpixel((int(r[0]) + 4, int(r[1]) + 4)) != (0, 0, 255)
    # off: nothing drawn
    _p, rep2 = _gr(rules_ws, {"game_rules_rules_bg": dict(strip, on=False)})
    assert rep2["bg"]["rules"] is None


def test_legal_strip_reported(rules_ws):
    _p, rep0 = _gr(rules_ws, {})
    if not rep0["blocks"]["legal"]:
        pytest.skip("sheet has no legal text")
    _p, rep = _gr(rules_ws, {"game_rules_legal_bg": {"on": True, "fill": "#222222"}})
    assert rep["bg"]["legal"] and rep["bg"]["rules"] is None


def test_game_rules_own_body_size_and_colour(rules_ws):
    _p, rep0 = _gr(rules_ws, {})
    page1, rep1 = _gr(rules_ws, {"game_rules_body_size": 20, "game_rules_body_rgb": "#FF00FF"})
    assert rep1["sizes"]["body_set"] == 20 and rep0["sizes"]["body_set"] != 20
    assert rep1["sizes"]["legal_set"] == rep0["sizes"]["legal_set"]   # the legal text is untouched
    x0, y0, x1, y1 = [int(v) for v in rep1["blocks"]["rules"]]
    assert any(p[0] > 200 and p[1] < 60 and p[2] > 200 for p in page1.convert("RGB").crop((x0, y0, x1, y1)).getdata())


def _bingo_ws(rows=4, text="Bingo cards win on any complete line."):
    wb = Workbook()
    ws = wb.active
    ws.title = "BINGO RULES"
    ws.cell(row=2, column=2, value="BINGO RULES").font = Font(bold=True)
    for i in range(rows):
        ws.cell(row=4 + i, column=2, value=f"{text} {i}")
    return ws


def _bingo(ds, ws=None):
    rep = {}
    pages = _common(ws or _bingo_ws(), "BINGO RULES", ds, rep)
    return pages, rep


def test_bingo_per_row_size_and_rgb():
    _p, base = _bingo({})
    cell = base["cells"][1]["cell"]
    _p, rep = _bingo({"bingo_rules_line_styles": {cell: {"size": 60, "rgb": "#00FF00"}}})
    by = {c["cell"]: c for c in rep["cells"]}
    b0 = {c["cell"]: c for c in base["cells"]}
    assert by[cell]["size"] == 60 and by[cell]["rgb"] == "#00FF00"
    assert by[cell]["rect"][3] > b0[cell]["rect"][3]
    other = next(c for c in by if c != cell)
    assert by[other]["size"] == base["sizes"]["body"] and by[other]["rect"][3] == b0[other]["rect"][3]


def test_bingo_font_and_rgb_keys():
    pages0, _ = _bingo({})
    pages1, rep = _bingo({"bingo_rules_rgb": "#00FF00", "bingo_rules_font": "Times New Roman"})
    assert all(c["rgb"] == "#00FF00" for c in rep["cells"])
    assert pages0[0].tobytes() != pages1[0].tobytes()


def test_bingo_always_one_page():
    ws = _bingo_ws(rows=60, text="A long bingo rule sentence that keeps going and going across the page.")
    pages, rep = _bingo({}, ws)
    assert len(pages) == 1
    assert rep["sizes"]["body"] < rep["sizes"]["body_set"]       # it shrank to fit
    pages, _ = _bingo({"bingo_rules_line_styles": {"B4": {"size": 90}}}, ws)
    assert len(pages) == 1


def test_a_build_never_puts_back_settings_older_than_an_edit_saved_while_it_ran():
    from ps_autotypesetter import text_edits as te
    te.set_all({"S": {"B1": {"from": "a", "to": "old"}}})
    live = png_builder._settings_snapshot()
    te.set_all({"S": {"B1": {"from": "a", "to": "build"}}})          # the build's own copy
    built = png_builder._settings_snapshot()
    te.set_all({"S": {"B1": {"from": "a", "to": "new edit"}}})       # saved on the server meanwhile
    png_builder._settings_restore(live, built)
    assert te.apply("S", "B1", "a") == "new edit"
    te.set_all({"S": {"B1": {"from": "a", "to": "build"}}})
    png_builder._settings_restore(live, built)                         # untouched: the server's own comes back
    assert te.apply("S", "B1", "a") == "old"
    te.set_all({})


def test_game_rules_line_breaks_and_empty_lines_typed_in_a_cell_are_kept():
    assert png_builder._game_rules_pieces("One. Two.") == ["One. Two."]                       # as before
    assert png_builder._game_rules_pieces("One.\n\nTwo.\n") == ["One.", png_builder._GR_BLANK, "Two."]


def _icon_dir(tmp_path):
    from PIL import Image

    d = tmp_path / "icons"
    d.mkdir()
    Image.new("RGBA", (40, 40), (255, 0, 0, 255)).save(d / "WILD.png")
    return str(d)


def _bingo_with(ds, ws, icon_folder=""):
    Image, ImageDraw, ImageFont = png_builder._require_pillow()
    rep = {}
    args = (Image, ImageDraw, ImageFont, ws, "BINGO RULES", "", "stretch", "#FFFFFF", 1920, 1080,
            "Arial", 72, 48, "#FF5050", "Arial", 30, 24, "#101010", 100, 120, 40, 80, 4, 12,
            icon_folder, {}, {}, ds, {})
    pages = png_builder._render_bingo_rules_png_pages(*args, report=rep)
    return pages, rep


def test_bingo_icon_scales_size_the_icon_and_report_stays_plain(tmp_path):
    from ps_autotypesetter import icon_scales

    ws = _bingo_ws(rows=1, text="Win with <WILD> now")
    folder = _icon_dir(tmp_path)
    try:
        icon_scales.set_all({})
        _p, base = _bingo_with({}, ws, folder)
        icon_scales.set_all({"BINGO RULES": {"WILD": 300}})
        _p, big = _bingo_with({}, ws, folder)
    finally:
        icon_scales.set_all({})
    assert big["cells"][0]["rect"][3] > base["cells"][0]["rect"][3]
    assert big["cells"][0]["rect"][2] > base["cells"][0]["rect"][2]
    assert "~" not in big["cells"][0]["text"] and "<WILD>" in big["cells"][0]["text"]


def test_game_rules_icon_scales_plain_report_text(rules_ws):
    from ps_autotypesetter import icon_scales

    try:
        icon_scales.set_all({"*": {"WILD": 200}})
        _page, rep = _gr(rules_ws, {})
    finally:
        icon_scales.set_all({})
    assert all("~" not in ln["text"] for ln in rep["lines"])
    assert all("~" not in t for t in rep["cells"].values())


def test_bingo_tracking_widens_a_line():
    _p, base = _bingo({})
    _p, wide = _bingo({"bingo_rules_tracking": 200})
    assert wide["cells"][0]["rect"][2] > base["cells"][0]["rect"][2]


def test_game_rules_tracking_widens_lines(rules_ws):
    _p, base = _gr(rules_ws, {})
    _p, wide = _gr(rules_ws, {"game_rules_tracking": 150, "game_rules_legal_tracking": 150})
    w0 = max(ln["rect"][2] for ln in base["lines"] if ln["part"] == "rules")
    w1 = max(ln["rect"][2] for ln in wide["lines"] if ln["part"] == "rules")
    assert w1 > w0


def test_game_rules_row_gap_wins_and_is_reported(rules_ws):
    _p, a = _gr(rules_ws, {"game_rules_row_gap": 10, "game_rules_legal_row_gap": 3})
    _p, b = _gr(rules_ws, {"game_rules_row_gap": 40, "game_rules_legal_row_gap": 3})
    assert a["fit"] == b["fit"] == 1.0 or a["sizes"]["row_gap"] != b["sizes"]["row_gap"]
    ra = [ln["rect"][1] for ln in a["lines"] if ln["part"] == "rules"]
    rb = [ln["rect"][1] for ln in b["lines"] if ln["part"] == "rules"]
    assert rb[1] - rb[0] > ra[1] - ra[0]
    assert a["sizes"]["legal_row_gap"] <= 3


def test_bingo_row_gap_moves_second_wrapped_line():
    ws = _bingo_ws(rows=1, text="Bingo cards win on any complete line " * 12)
    _p, a = _bingo({"bingo_rules_row_gap": 2}, ws)
    _p, b = _bingo({"bingo_rules_row_gap": 30}, ws)
    assert a["sizes"]["row_gap"] == 2 and b["sizes"]["row_gap"] == 30
    assert b["cells"][0]["rect"][3] > a["cells"][0]["rect"][3]


def test_bingo_clean_spaces_collapses_runs():
    ws = _bingo_ws(rows=1, text="Win   with\t\t two  spaces")
    _p, keep = _bingo({}, ws)
    _p, clean = _bingo({"bingo_rules_clean_spaces": True}, ws)
    assert "  " not in clean["cells"][0]["text"]
    assert "Win with two spaces" in clean["cells"][0]["text"]
    assert clean["cells"][0]["rect"][2] <= keep["cells"][0]["rect"][2]
