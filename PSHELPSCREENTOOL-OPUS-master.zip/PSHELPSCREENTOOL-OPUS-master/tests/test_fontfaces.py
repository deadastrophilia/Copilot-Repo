"""Font faces like Photoshop's menus: family + style from the font files, one pick for the build and the Canvas."""
import os

import pytest

from ps_autotypesetter import fontfaces, png_builder
from ps_autotypesetter.ui_web import engine_api

ARIAL = fontfaces.families().get("Arial")
pytestmark = pytest.mark.skipif(not ARIAL or "Bold" not in ARIAL, reason="needs Arial Regular + Bold installed")


def _file(req, bold=False, italic=False):
    hit = fontfaces.pick(req, bold, italic)
    return os.path.basename(hit[0]).lower() if hit else None


def test_family_lists_its_own_styles():
    assert ARIAL[0] == "Regular" and "Bold Italic" in ARIAL


def test_older_requests_keep_their_meaning():
    assert _file("Arial") == _file("ArialMT") == "arial.ttf"
    assert _file("Arial", bold=True) == _file("ArialMT", bold=True) == _file("Arial|bold") == _file("Arial Bold") == "arialbd.ttf"
    assert _file("Arial|bold|italic") == "arialbi.ttf"


def test_a_face_picked_from_the_menu_wins_over_the_heading_bold():
    assert _file("Arial|Regular", bold=True) == "arial.ttf"           # the heading asked Regular: Regular
    assert _file("Arial|Bold Italic") == "arialbi.ttf"


def test_postscript_name_of_a_bold_face_is_that_face():
    assert _file("Arial-BoldMT") == "arialbd.ttf"
    assert fontfaces.face_of("Arial-BoldMT")["style"] == "Bold"


def test_font_request_keeps_legacy_and_names_a_picked_face():
    assert engine_api._font_request("Arial", "regular") == "Arial"
    assert engine_api._font_request("Arial", "bold") == "Arial|bold"
    assert engine_api._font_request("Arial", "Bold") == "Arial|Bold"
    assert fontfaces.is_face_style("Semibold") and not fontfaces.is_face_style("bold italic")


def test_build_draws_with_the_picked_file():
    from PIL import ImageFont

    png_builder._FONT_CACHE.clear()
    f = png_builder._load_font(ImageFont, "Arial|Regular", 40, bold=True)
    assert os.path.basename(f.path).lower() == "arial.ttf"
    from visualiser import visualiser_data

    assert visualiser_data.resolve_font_file("Arial|Regular", bold=True).lower() == "arial.ttf"
    assert visualiser_data.resolve_font_file("Arial", bold=True).lower() == "arialbd.ttf"


def test_unknown_font_is_none():
    assert fontfaces.pick("No Such Font 123") is None


@pytest.fixture
def photoshop_fonts(tmp_path, monkeypatch):
    """A Photoshop install whose own font (a copy of Arial Bold) sits hidden as "typesupport/.f/.19",
    listed in Photoshop's font cache like the real "AdobeDefault_Fonts.lst"."""
    import shutil

    hidden = tmp_path / "Photoshop" / "Required" / "typesupport" / ".f"
    hidden.mkdir(parents=True)
    shutil.copyfile(fontfaces.pick("Arial", bold=True)[0], hidden / ".19")
    cache = tmp_path / "Roaming" / "Adobe" / "Adobe Photoshop 2099" / "CT Font Cache"
    cache.mkdir(parents=True)
    (cache / "AdobeDefault_Fonts.lst").write_text(
        "%BeginFont\nHandler:DirectoryHandler\nFontName:Arial-BoldMT\nOutlineFileName:"
        + str(hidden).replace("\\", "\\\\") + "\\.19\n%EndFont\n", encoding="latin-1")
    monkeypatch.setenv("APPDATA", str(tmp_path / "Roaming"))
    monkeypatch.setattr(fontfaces, "_INDEX", None)
    yield str(hidden / ".19")
    fontfaces._INDEX = None


def test_photoshops_own_fonts_are_found(photoshop_fonts, monkeypatch):
    # Windows has no such font: the face comes from Photoshop's hidden file, and the Canvas fetches it
    # by a name of its own (every Photoshop version numbers its files ".19", ".22" ...)
    monkeypatch.setattr(fontfaces, "_files", lambda: [])
    hit = fontfaces.pick("Arial-BoldMT")
    assert hit and os.path.normcase(hit[0]) == os.path.normcase(photoshop_fonts)
    assert "Bold" in fontfaces.families()["Arial"]
    key = fontfaces.file_key(hit[0])
    assert key.startswith("adobe-") and key.endswith(".otf")
    assert os.path.normcase(fontfaces.path_by_basename(key)) == os.path.normcase(photoshop_fonts)
    assert fontfaces.path_by_basename(".19") is None


def test_windows_fonts_win_over_photoshops_copy(photoshop_fonts):
    assert _file("Arial", bold=True) == "arialbd.ttf"                   # the installed one, as before
    assert fontfaces.file_key(fontfaces.pick("Arial", bold=True)[0]) == "arialbd.ttf"
