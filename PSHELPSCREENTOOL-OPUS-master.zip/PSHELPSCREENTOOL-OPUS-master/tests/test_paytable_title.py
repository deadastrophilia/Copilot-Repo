"""Regression tests for the mapped-paytable title slot + text justification."""

import pytest


def _import_renderer():
    renderer = pytest.importorskip(
        "ps_autotypesetter.dynamic_pages.paytable.renderer",
        reason="renderer requires photoshop.api",
    )
    return renderer


def _import_ps_actions():
    return pytest.importorskip("ps_autotypesetter.ui_web.ps_actions")


@pytest.mark.parametrize(
    "name,expected",
    [
        ("title", True),
        ("Title", True),
        ("title ", True),
        ("@slot.title", True),
        ("@slot.Title", True),
        ("@table.title", True),
        ("@slot. title", True),
        ("wild.title", False),
        ("@slot.wild.title", False),
        ("paytable", False),
        ("title.background", False),
        ("@slot.titlecard", False),
    ],
)
def test_slot_is_title(name, expected):
    renderer = _import_renderer()
    assert renderer._slot_is_title(name) is expected


def test_preview_slot_is_title():
    actions = _import_ps_actions()
    assert actions._preview_slot_is_title("@slot.title") is True
    assert actions._preview_slot_is_title("title") is True
    assert actions._preview_slot_is_title("wild.title") is False
    assert actions._preview_slot_is_title("paytable") is False


@pytest.mark.parametrize(
    "name,expected",
    [
        ("wild.title", True),
        ("@slot.wild.title", True),
        ("@slot.wild.text", True),
        ("@slot.wild.text ", True),
        ("feature.title", True),
        ("special.title", True),
        ("wild.1", False),
        ("wild.2", False),
        ("wildpay", False),
        ("title", False),
        ("ten.pay", False),
    ],
)
def test_slot_is_wild_title(name, expected):
    renderer = _import_renderer()
    assert renderer._slot_is_wild_title(name) is expected


def test_preview_slot_is_wild_title():
    actions = _import_ps_actions()
    assert actions._preview_slot_is_wild_title("@slot.wild.title") is True
    assert actions._preview_slot_is_wild_title("wild.text") is True
    assert actions._preview_slot_is_wild_title("wild.1") is False
    assert actions._preview_slot_is_wild_title("title") is False


@pytest.mark.parametrize(
    "value,expected",
    [
        ("B3", True),
        ("AB123", True),
        ("a1", True),
        ("My Game", False),
        ("WILD", False),
        ("B3,B5", False),
        ("", False),
        ("5\n4\n3\n2", False),
    ],
)
def test_cell_like_source(value, expected):
    renderer = _import_renderer()
    assert renderer._cell_like_source(value) is expected
    actions = _import_ps_actions()
    assert actions._cell_like_source(value) is expected


def test_justification_for():
    renderer = _import_renderer()
    ps = pytest.importorskip("photoshop.api", reason="photoshop.api required")
    assert renderer._justification_for("left") == ps.Justification.Left
    assert renderer._justification_for("right") == ps.Justification.Right
    assert renderer._justification_for("center") == ps.Justification.Center
    assert renderer._justification_for("") == ps.Justification.Center
    assert renderer._justification_for(None) == ps.Justification.Center


def test_coerce_rgb_none_fallback_safe():
    """Regression: an unmapped @slot.title renders with an empty spec, so
    ``_coerce_rgb(None, None)`` must return None instead of crashing on
    ``tuple(None)`` — that crash killed the whole PSD build the moment the
    auto-rendered heading ran."""
    renderer = _import_renderer()
    assert renderer._coerce_rgb(None, None) is None
    assert renderer._coerce_rgb("", None) is None
    assert renderer._coerce_rgb("#FFCD32", None) == (255, 205, 50)
    assert renderer._coerce_rgb((1, 2, 3), None) == (1, 2, 3)
    assert renderer._coerce_rgb(None, (1, 2, 3)) == (1, 2, 3)
    assert renderer._coerce_rgb("junk", (9, 9, 9)) == (9, 9, 9)
