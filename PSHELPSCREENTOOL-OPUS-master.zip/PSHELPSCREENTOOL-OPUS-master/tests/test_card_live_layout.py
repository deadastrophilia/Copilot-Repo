"""The card studio's live view: /api/card_templates/layout returns a draw list fast, without
rendering a PNG or writing the card layout file."""

import os

from openpyxl import Workbook

from ps_autotypesetter.dynamic_pages.paytable import card_templates as ct
from ps_autotypesetter.ui_web.server import create_app


def _workbook(path):
    wb = Workbook()
    ws = wb.active
    ws.title = "Paytable"
    ws["B2"] = "BASE GAMES PAYTABLE"
    ws["H4"] = "All wins begin with leftmost reel."
    ws["H5"] = "<WILD> substitutes for all symbols."
    row = 11
    for sym in ("<PIC1>", "<PIC2>", "<ACE>", "<KING>"):
        for i, (cnt, pay) in enumerate(((5, 100), (4, 20), (3, 5))):
            ws.cell(row + i, 6, cnt)
            ws.cell(row + i, 8, pay)
        ws.cell(row + 1, 4, sym)
        row += 4
    wb.save(path)


def test_layout_is_a_draw_list_and_writes_nothing(tmp_path, monkeypatch):
    monkeypatch.setenv("USERPROFILE", str(tmp_path))          # ~ -> tmp: no card layout file may appear
    monkeypatch.setenv("HOME", str(tmp_path))
    xl = os.path.join(str(tmp_path), "agr.xlsx")
    _workbook(xl)
    client = create_app(session_file=os.path.join(str(tmp_path), "session.json")).test_client()
    client.post("/api/config", json={"excel_path": xl, "c_width": 1920, "c_height": 1080, "icon_folder": ""})
    r = client.post("/api/card_templates/layout", json={"template": ct.get_template("classic_cards"), "sheet_name": "Paytable"})
    d = r.get_json()
    assert r.status_code == 200 and d["ok"]
    by_slot = {it["slot"]: it for it in d["items"]}
    assert by_slot["@slot.pic1.card"]["shape"]["fill"]                       # card backgrounds
    assert by_slot["@slot.pic1.value"]["text"].split("\n") == ["100", "20", "5"]   # numbers resolved from Excel
    assert by_slot["@slot.pic1"]["text"] == "<PIC1>"                          # no icon folder: the token shows
    assert d["canvas_px"] == {"width": 1920.0, "height": 1080.0}
    assert "card:pic1" in d["blocks"] and d["band_geo"]
    assert not os.path.exists(os.path.join(str(tmp_path), "PsHelpScreenTool_CardLayouts"))
