from PIL import Image

from ps_autotypesetter import text_styles as ts


WORD = {"kind": "word", "text": "Extra", "color": "#FF3030", "bold": True}
STRIP = {"kind": "strip", "text": "Note:", "match": "starts", "color": "#1E3A8A", "text_color": "#FFFFFF"}


def test_word_runs_split_on_rule_words():
    with ts.active([WORD]):
        runs = ts.word_runs("Win Extra spins, extra fun")
    styled = [seg for seg, st in runs if st]
    assert styled == ["Extra", "extra"]
    assert "".join(seg for seg, _ in runs) == "Win Extra spins, extra fun"


def test_whole_word_only_and_longer_rule_wins():
    rules = [WORD, {"kind": "word", "text": "Extra Spins", "color": "#00FF00"}]
    with ts.active(rules):
        assert all(st is None for _, st in ts.word_runs("Extravaganza"))
        runs = ts.word_runs("Get Extra Spins now")
    assert [(seg, st["rgb"]) for seg, st in runs if st] == [("Extra Spins", (0, 255, 0))]


def test_page_scope_only_on_its_sheet():
    rule = dict(WORD, scope="page", sheet="Rules")
    with ts.active([rule], "Paytable"):
        assert not ts.has_word_rules()
    with ts.active([rule], "rules"):
        assert ts.has_word_rules()


def test_a_size_is_not_used_on_pages_given_one_paragraph_size():
    rule = dict(WORD, size=60, size_off=["BBB"])
    with ts.active([rule], "Wheel"):
        assert [st["size"] for _, st in ts.word_runs("Extra") if st] == [60]
    with ts.active([rule], "bbb"):
        st = [st for _, st in ts.word_runs("Extra") if st][0]
        assert st["size"] is None and st["rgb"] == (255, 48, 48)      # its colour stays, only the size goes


def test_no_rules_means_plain_text():
    assert ts.word_runs("Extra") == [("Extra", None)]
    assert ts.strip_for("Note: x") is None


def test_strip_matching_modes():
    with ts.active([STRIP, {"kind": "strip", "text": "Bonus round", "match": "exact"}]):
        assert ts.strip_for("note:  pays left to right")["text"] == "Note:"
        assert ts.strip_for("A Note: inside") is None
        assert ts.strip_for("Bonus round")["match"] == "exact"
        assert ts.strip_for("Bonus round starts") is None


def test_strip_geometry_and_draw_clips_to_page():
    left, top, w, h = ts.strip_geometry({"pad_x": 10, "pad_y": 4}, 100, 50, 200, 30)
    assert (left, top, w, h) == (90, 46, 220, 38)
    page = Image.new("RGBA", (100, 40), (0, 0, 0, 0))
    ts.draw_strip(page, {"color": "#FF0000", "opacity": 1, "radius": 0}, (-20, 10, 200, 10))
    assert page.getpixel((50, 15)) == (255, 0, 0, 255)
    assert page.getpixel((50, 5))[3] == 0


def test_layout_inserts_strip_rect_under_row():
    from openpyxl import Workbook

    from ps_autotypesetter import layout_engine

    wb = Workbook()
    ws = wb.active
    ws.title = "Rules"
    ws["A1"] = "Game Rules"
    ws["A2"] = "All wins pay left to right."
    ws["A3"] = "Note: malfunction voids all pays."
    layouts = layout_engine.build_sheet_layouts(
        ws, "Rules", dynamic_settings={"text_style_rules": [STRIP]})
    els = [e for lay in layouts or [] for e in lay.elements]
    strips = [e for e in els if (getattr(e, "meta", {}) or {}).get("strip")]
    assert len(strips) == 1
    note = [e for e in els if "Note:" in str(getattr(e, "text", ""))]
    assert note and list(note[0].color)[:3] == [255, 255, 255]
    assert els.index(strips[0]) < els.index(note[0])          # strip drawn under the text


def test_strip_width_percent_stays_centred_and_height_from_pad_y():
    left, top, w, h = ts.strip_geometry({"pad_x": 0, "pad_y": 20, "width_pct": 50}, 100, 50, 400, 30)
    assert (left, w) == (200, 200)
    assert (top, h) == (30, 70)
    # fit text ignores the width slider and hugs the words
    left, _t, w, _h = ts.strip_geometry({"pad_x": 10, "full_width": False, "width_pct": 50}, 100, 50, 400, 30, 250, 300)
    assert (left, w) == (240, 70)
