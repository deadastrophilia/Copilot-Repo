from unittest.mock import MagicMock
from ps_autotypesetter.excel_utils import _openpyxl_color_to_rgb, get_excel_color, get_excel_fill_color


class MockColor:
    def __init__(self, color_type="rgb", rgb=None, index=None):
        self.type = color_type
        self.rgb = rgb
        self.index = index


class TestOpenpyxlColorToRgb:
    def test_none_color(self):
        assert _openpyxl_color_to_rgb(None) is None

    def test_rgb_color_8char(self):
        color = MockColor(rgb="00FF0000")
        assert _openpyxl_color_to_rgb(color) == (255, 0, 0)

    def test_rgb_color_6char(self):
        color = MockColor(rgb="00FF00")
        assert _openpyxl_color_to_rgb(color) == (0, 255, 0)

    def test_indexed_color(self):
        color = MockColor(color_type="indexed", index=0)
        result = _openpyxl_color_to_rgb(color)
        assert result is not None
        assert len(result) == 3


class TestGetExcelColor:
    def test_no_font(self):
        cell = MagicMock(font=None)
        assert get_excel_color(cell) is None

    def test_no_font_color(self):
        cell = MagicMock()
        cell.font.color = None
        assert get_excel_color(cell) is None

    def test_with_color(self):
        cell = MagicMock()
        cell.font.color = MockColor(rgb="FF0000FF")
        assert get_excel_color(cell) == (0, 0, 255)


class TestGetExcelFillColor:
    def test_no_fill(self):
        cell = MagicMock(fill=None)
        assert get_excel_fill_color(cell) is None

    def test_no_pattern(self):
        cell = MagicMock()
        cell.fill.patternType = "none"
        assert get_excel_fill_color(cell) is None

    def test_with_fill(self):
        cell = MagicMock()
        cell.fill.patternType = "solid"
        cell.fill.fgColor = MockColor(rgb="00FF0000")
        assert get_excel_fill_color(cell) == (255, 0, 0)
