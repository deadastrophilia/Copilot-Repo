"""Word styles: a picked word's own size and layer style (text_styles + png_builder)."""
from PIL import Image, ImageDraw, ImageFont

from ps_autotypesetter import png_builder as pb
from ps_autotypesetter import text_styles

LIB = {"Red edge": {"stroke_enabled": True, "stroke_rgb": "#FF0000", "stroke_size": 4, "stroke_opacity": 100}}


def _render(rules, text="Win FREE spins now"):
    img = Image.new("RGBA", (900, 120), (0, 0, 0, 255))
    font = pb._load_font(ImageFont, "Arial", 40)
    with text_styles.active(rules, "Rules", LIB):
        pb._draw_inline(img, ImageDraw.Draw(img), Image, text, 10, 20, font, (255, 255, 255, 255), 880,
                        "", {}, 40, align="left")
    return img


def _red(img):
    return sum(1 for r, g, b, a in img.getdata() if r > 180 and g < 80 and b < 80)


def _ink_right(img):
    return img.convert("L").point(lambda v: 255 if v > 40 else 0).getbbox()[2]


def test_a_word_gets_its_own_layer_style():
    plain = _render([])
    styled = _render([{"kind": "word", "text": "FREE", "fx": "Red edge"}])
    assert _red(plain) == 0 and _red(styled) > 150                      # only the picked word has the red edge


def test_a_word_gets_its_own_size_and_the_line_makes_room():
    plain = _render([])
    big = _render([{"kind": "word", "text": "FREE", "size": 160}])
    assert _ink_right(big) > _ink_right(plain) + 20                     # the bigger word pushes the rest along


def test_style_of_reports_size_and_layer_style():
    rule = text_styles.normalize_rules([{"kind": "word", "text": "x", "size": 120, "fx": "Red edge"}], LIB)[0]
    st = text_styles.style_of(rule)
    assert st["size"] == 120 and st["fx"] == "Red edge" and st["fx_config"]
    assert text_styles.style_of({"text": "x", "size": 100})["size"] is None    # 100 % = the line's size


def test_heading_and_body_alignment_come_from_typography():
    al = {"global": {"heading": "left", "body": "justify"}}
    assert pb._text_alignment(al, "Rules", "heading") == "left"
    assert pb._text_alignment(al, "Rules", "body") == "justify"
    own = dict(al, overrides={"Rules": {"use_global": False, "body": "right"}})
    assert pb._text_alignment(own, "Rules", "body") == "right"            # a page's own alignment wins
    assert pb._text_alignment({}, "Rules", "body") == "center"


def test_a_justified_line_reaches_both_edges():
    img = Image.new("RGBA", (1200, 100), (0, 0, 0, 255))
    font = pb._load_font(ImageFont, "Arial", 30)
    pb._draw_inline(img, ImageDraw.Draw(img), Image, "One or more in a spin without", 10, 10, font,
                    (255, 255, 255, 255), 1000, "", {}, 30, align="justify_all")
    box = img.convert("L").point(lambda v: 255 if v > 40 else 0).getbbox()
    assert box[0] < 20 and box[2] > 990


def test_live_layout_lines_follow_the_alignment():
    from ps_autotypesetter import page_layout

    el = page_layout.TextElement(text="x", align="justify_all")
    assert el.align == "justify_all"


def test_a_style_for_just_this_text_changes_only_its_own_row():
    rule = {"kind": "word", "text": "Extra", "scope": "row", "sheet": "Rules", "bold": True,
            "row_text": "Win  Extra spins here"}
    with text_styles.active([rule], "Rules"):
        with text_styles.row("Win Extra spins here"):
            assert any(st for _seg, st in text_styles.word_runs("Win Extra spins here"))
        with text_styles.row("Another Extra line"):
            assert not any(st for _seg, st in text_styles.word_runs("Another Extra line"))
    with text_styles.active([rule], "Other sheet"), text_styles.row("Win Extra spins here"):
        assert not any(st for _seg, st in text_styles.word_runs("Win Extra spins here"))
