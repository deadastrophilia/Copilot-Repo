"""Use Settings From a Given PSD (psd_style_import.py)."""
import hashlib
import os

import pytest

from ps_autotypesetter import games, psd_style_import as imp
from ps_autotypesetter.ui_web import engine_api

from .test_games import game_folder  # noqa: F401  (fixture)

REF = os.path.join(os.path.dirname(__file__), "..", "PSDRef", "BZZF_blastBlueHelps.psd")


def _layer(text, font, size, name="", color="#ffffff", lines=1, fx=None):
    return {"name": name, "text": text, "font": font, "size": size, "leading": size * 1.2, "color": color,
            "alignment": "center", "lines": lines, "chars": len(text.replace(" ", "")), "bbox": (100, 0, 1820, 50),
            "bold": "Bold" in font or "Black" in font, "numbers": imp._is_numberish(text), "effects": fx, "visible": True}


def test_roles_by_size_amount_and_weight():
    body = "Wins pay left to right on adjacent reels starting from the leftmost reel. " * 2
    fx = {"effects_block": {"key": "lfx2", "hex": "00"}, "captured_params": {"fill_opacity": 100}}
    layers = [_layer(body, "ArialMT", 36, lines=3) for _ in range(5)]
    layers += [_layer("FREE GAMES", "Arial-Black", 120, name="title", color="#00ff00", fx=fx) for _ in range(4)]
    layers += [_layer("How to play", "Arial-BoldMT", 60, name="sub") for _ in range(3)]
    layers += [_layer("25-1250 Credits", "Arial-BoldMT", 36) for _ in range(20)]   # payouts: not a role
    roles = imp.classify(layers)
    assert (roles["body"]["font"], roles["body"]["size"], roles["body"]["confidence"]) == ("ArialMT", 36, "high")
    assert (roles["heading"]["font"], roles["heading"]["color"]) == ("Arial-Black", "#00ff00")
    assert roles["heading"]["layer_style"] == fx
    assert (roles["subheading"]["font"], roles["subheading"]["size"]) == ("Arial-BoldMT", 60)


def test_apply_takes_formatting_only():
    fields = [{"key": "h_font", "value": "Arial-Black"}, {"key": "h_size", "value": "120"},
              {"key": "b_rgb", "value": "#fafcfa", "apply": False},
              {"key": "ds.subheading_rgb", "value": "#000000"},
              {"key": "icon_folder", "value": "E:/Old Game/Symbols"},          # never a path
              {"key": "excel_path", "value": "E:/Old Game/old.xlsx"}]
    styles = {"Heading text": {"name": "Ref heading", "style": {"effects_block": {"key": "lfx2", "hex": "00"}}},
              "Body text": {"name": "Ref body", "style": {"x": 1}, "apply": False}}
    out = imp.apply({"b_rgb": "#FFFFFF"}, fields, styles)
    assert out["h_font"] == "Arial-Black" and out["h_size"] == 120 and out["b_rgb"] == "#FFFFFF"
    assert "icon_folder" not in out and "excel_path" not in out
    ds = out["dynamic_settings"]
    assert ds["subheading_rgb"] == [0, 0, 0]
    assert ds["style_assignments"] == {"Heading text": "Ref heading"}
    assert list(ds["layer_style_library"]) == ["Ref heading"]


def test_create_game_with_psd_settings(game_folder):  # noqa: F811
    old = {"icon_folder": "E:/Old/Symbols", "icon_mappings": {"WILD": "w.png"}, "h_font": "OldFont"}
    game = games.create(str(game_folder), base_config=old, settings_mode="psd", defaults=engine_api.DEFAULT_CONFIG,
                        psd_settings={"source": "E:/Ref/Help.psd", "fields": [{"key": "h_font", "value": "Arial-Black"}]})
    st = game["style"]
    assert st["h_font"] == "Arial-Black"
    assert st["b_size"] == engine_api.DEFAULT_CONFIG["b_size"]       # untouched values: defaults, not the old game
    assert not st.get("icon_mappings")
    assert st["icon_folder"].endswith("icons")                        # this game's own folder
    assert game["settings_source"] == "Help.psd"


@pytest.mark.skipif(not os.path.isfile(REF), reason="reference PSD not available")
def test_real_psd_is_read_and_left_untouched():
    before = hashlib.sha1(open(REF, "rb").read()).hexdigest()
    r = imp.analyse(REF)
    assert r["ok"] and r["roles"]["body"]["font"] == "ArialMT" and r["roles"]["heading"]["font"] == "Arial-Black"
    assert "Heading text" in r["styles"]
    assert hashlib.sha1(open(REF, "rb").read()).hexdigest() == before
