"""A heading learned from an artist's PSD: width / height scale, tracking, kerning and Blend If.

TEST.psd (GameRules LayerStyle): the artist's heading is a 152 px layer stretched with Free Transform to
207 px (Photoshop shows "207 px"), 80 % tall, tracking 50 — and Blend If hides it over white. Plain 207 px
text looked bigger and differently shaped, and stayed on a white background."""

import os

import numpy as np
import psd_tools
import pytest
from openpyxl import Workbook
from PIL import Image, ImageDraw, ImageFont

from ps_autotypesetter import blend_if, png_builder, ps_text, psd_style_import
from ps_autotypesetter.psd_writer import document, recorder, txt2


def _font(size=100):
    return png_builder._load_font(ImageFont, "Arial", size, bold=True)


def test_shaped_font_measures_like_photoshop():
    plain = _font()
    narrow = ps_text.shaped(plain, hscale=0.7, vscale=0.8, kerning=False)
    assert ps_text.shaped(plain) is plain and ps_text.shape_of(plain) == (1.0, 1.0, True)
    assert ps_text.shape_of(narrow) == (0.7, 0.8, False)
    unkerned = sum(ps_text.char_advance(plain, c) for c in "AVATAR")
    assert ps_text.advance(plain, "AVATAR") < unkerned - 5          # Metrics kerning tightens AV / VA / TA
    assert ps_text.advance(narrow, "AVATAR") == pytest.approx(unkerned * 0.7, abs=0.01)
    # tracking widens with the width scale (Photoshop: tracking 50 at 72 % adds 72 % of 50/1000 em)
    with ps_text.tracking(50):
        assert ps_text.tracking_px(narrow) == pytest.approx(100 * 50 / 1000 * 0.7)
    # the ink: 70 % as wide, 80 % as tall, on the same baseline
    def ink(font):
        img = Image.new("RGBA", (900, 300), (0, 0, 0, 0))
        ps_text.draw(img, "HELLO", font, 20, 200, (255, 255, 255))
        return np.asarray(img)[..., 3].astype(float)
    a, b = ink(plain), ink(narrow)
    ya, xa = np.nonzero(a > 128)
    yb, xb = np.nonzero(b > 128)
    assert (xb.max() - xb.min()) == pytest.approx((xa.max() - xa.min()) * 0.7, abs=3)
    assert (yb.max() - yb.min()) == pytest.approx((ya.max() - ya.min()) * 0.8, abs=2)
    assert yb.max() == pytest.approx(ya.max(), abs=1)


def test_heading_shape_setting():
    assert png_builder.heading_shape({}) == {"hscale": 1.0, "vscale": 1.0, "kerning": True}
    got = png_builder.heading_shape({"dynamic_settings": {"heading_hscale": 72.12, "heading_vscale": "80",
                                                          "heading_kerning": "none"}})
    assert got == {"hscale": pytest.approx(0.7212), "vscale": 0.8, "kerning": False}


def test_blend_if_ranges_and_mask():
    class R:
        composite_ranges = [(0, 65535), (0, 64764)]            # TEST.psd: underlying white at 252 / 252
    assert blend_if.from_ranges(R) == [0, 0, 252, 252]
    blend_if.to_ranges(R, [10, 20, 200, 240])
    assert blend_if.from_ranges(R) == [10, 20, 200, 240]
    assert blend_if.clean([0, 255]) is None and blend_if.clean({"under": [0, 0, 252, 252]}) == [0, 0, 252, 252]
    k = blend_if.mask(np.array([0, 15, 100, 220, 252, 253, 255]), [10, 20, 200, 240])
    assert list(np.round(k, 2)) == [0, 0.5, 1, 0.5, 0, 0, 0]
    # the layer drawn over white is taken back out; over black it stays
    for bg, kept in (((255, 255, 255, 255), False), ((0, 0, 0, 255), True)):
        base = Image.new("RGBA", (20, 20), bg)
        before = base.copy()
        base.paste((200, 0, 0, 255), (5, 5, 15, 15))
        blend_if.apply(base, before, [0, 0, 252, 252])
        assert (base.getpixel((10, 10)) == (200, 0, 0, 255)) is kept


def _layer(**sd):
    from types import SimpleNamespace

    data = {"HorizontalScale": 1.0, "VerticalScale": 0.8, "Tracking": 50, "AutoKerning": True}
    data.update(sd)
    run = {"StyleSheet": {"StyleSheetData": data}}
    ranges = SimpleNamespace(composite_ranges=[(0, 65535), (0, 64764)])
    return SimpleNamespace(engine_dict={"StyleRun": {"RunArray": [run], "RunLengthArray": [11]}},
                           text="game rules\r", transform=(0.98281, 0.0, 0.0, 1.36280, 647.3, 247.7),
                           _record=SimpleNamespace(blending_ranges=ranges))


def test_mimic_reads_the_artists_character_panel():
    sh = psd_style_import._shape(_layer())
    assert sh == {"hscale": pytest.approx(72.12, abs=0.01), "vscale": 80.0, "tracking": 50, "kerning": "metrics",
                  "blend_if": [0, 0, 252, 252]}
    assert psd_style_import._shape(_layer(AutoKerning=False))["kerning"] == "none"


def test_mimic_applies_the_ticked_heading_fields():
    style = {"dynamic_settings": {"layer_style_library": {"Old": {"stroke_size": 2}},
                                  "style_assignments": {"Heading text": "Old"}}}
    fields = [{"key": "ds.heading_hscale", "value": "72.12"}, {"key": "ds.heading_vscale", "value": 80},
              {"key": "ds.heading_tracking", "value": 50}, {"key": "ds.heading_kerning", "value": "none"},
              {"key": "ds.heading_blend_if", "value": "0, 0, 252, 252"}]
    out = psd_style_import.apply(style, fields)["dynamic_settings"]
    assert (out["heading_hscale"], out["heading_vscale"], out["heading_tracking"], out["heading_kerning"]) == \
        (72.12, 80, 50, "none")
    assert out["layer_style_library"]["Old"] == {"stroke_size": 2, "blend_if": {"under": [0, 0, 252, 252]}}
    # unticked: the style keeps its own Blend If; a default range removes it
    fields[-1]["apply"] = False
    assert "blend_if" in psd_style_import.apply({"dynamic_settings": out}, fields)["dynamic_settings"][
        "layer_style_library"]["Old"]
    fields[-1].update(apply=True, value=[0, 0, 255, 255])
    assert "blend_if" not in psd_style_import.apply({"dynamic_settings": out}, fields)["dynamic_settings"][
        "layer_style_library"]["Old"]


def test_psd_text_keeps_scale_kerning_and_tracking():
    font = ps_text.shaped(_font(60), hscale=0.72, vscale=0.8, kerning=False)
    rec = recorder.TextRecord(font, (255, 255, 255), "center")
    line = recorder.TextLine(100.0)
    with ps_text.tracking(50):
        adv = ps_text.advance(font, "GAME RULES")
    line.runs.append(recorder.TextRun("GAME RULES", (255, 255, 255), 50.0, adv))
    rec.lines.append(line)
    rec.box = (0.0, 1000.0)
    _t, spans, _s = document.text_spans(rec)
    assert abs(spans[0][3] - 50) <= 1                       # the layer's tracking is the artist's 50
    layer = document.text_layer(rec, "t")
    assert layer.style_run_auto_kerning(0) is False
    assert layer.style_run_horizontal_scale(0) == pytest.approx(0.72)
    assert layer.style_run_vertical_scale(0) == pytest.approx(0.8)
    run = document.text_model(rec)["runs"][0]
    assert (run["hscale"], run["vscale"], run["kerning"]) == (pytest.approx(0.72), pytest.approx(0.8), False)


def _workbook(path):
    wb = Workbook()
    ws = wb.active
    ws.title = "Game Rules"
    for row in (["GAME RULES"], [""], ["All wins on played lines only."]):
        ws.append(row)
    wb.save(path)
    return path


_STYLE = {"captured_params": {"stroke": {"enabled": True, "size": 3, "color": [200, 40, 0]}},
          "blend_if": {"under": [0, 0, 252, 252]}}


def _settings(**extra):
    ds = {"heading_hscale": 72, "heading_vscale": 80, "heading_tracking": 50, "heading_kerning": "metrics",
          "layer_style_library": {"H": dict(_STYLE)}, "style_assignments": {"Heading text": "H"}}
    ds.update(extra)
    return ds


def _png(tmp_path, bg, ds):
    path = _workbook(str(tmp_path / f"r{bg[1:]}.xlsx"))
    out = png_builder.build_pngs_only(
        excel_path=path, icon_folder="", bg_path="", c_width=1280, c_height=720, max_col_limit=12,
        h_font="Arial", h_size=120, h_icon_h=48, h_rgb="#FFFFFF", b_font="Arial", b_size=30, b_icon_h=24,
        b_rgb="#808080", margin_x=100, line_spacing=4, para_spacing=12, gap_px=12, icon_y_offset=0,
        bg_mode="color", bg_color=bg, heading_top_margin=60, continued_gap=15, heading_to_body_gap=40,
        bottom_margin=80, inner_canvas_width=0, page_min_row=1, page_max_row=100, page_min_col=1,
        page_max_col=12, page_overrides={}, dynamic_settings=ds, output_dir=str(tmp_path / f"o{bg[1:]}"),
        output_name=None)
    name = sorted(n for n in os.listdir(out) if n.lower().endswith(".png"))[0]
    return np.asarray(Image.open(os.path.join(out, name)).convert("RGB")).astype(int)


def test_build_draws_the_learned_heading(tmp_path):
    dark = _png(tmp_path, "#000000", _settings())
    head = (np.abs(dark[:210] - 0).sum(-1) > 60)          # the heading (the body line starts lower)
    ys, xs = np.nonzero(head)
    plain = _png(tmp_path, "#000001", _settings(heading_hscale=100, heading_vscale=100, heading_tracking=0))
    ys2, xs2 = np.nonzero(np.abs(plain[:210] - [0, 0, 1]).sum(-1) > 60)
    # narrower (72 % + tracking) and shorter (80 %) than the plain heading
    assert (xs.max() - xs.min()) < (xs2.max() - xs2.min()) * 0.9
    assert (ys.max() - ys.min()) == pytest.approx((ys2.max() - ys2.min()) * 0.8, abs=3)
    # Blend If: over white the heading (style included) is gone; the body text still draws
    white = _png(tmp_path, "#FFFFFF", _settings())
    assert (np.abs(white[:210] - 255).sum(-1) > 30).sum() == 0
    assert (np.abs(white[210:] - 255).sum(-1) > 30).sum() > 50


def test_built_psd_heading_layer_keeps_the_look(tmp_path):
    from ps_autotypesetter.psd_writer import build as psd_build
    from ps_autotypesetter.ui_web import engine_api

    cfg = {"excel_path": _workbook(str(tmp_path / "rules.xlsx")), "icon_folder": "", "bg_path": "",
           "bg_source": "color", "bg_color": "#102040", "output_dir": str(tmp_path / "out"), "output_name": "Out",
           "render_all_pages": True, "c_width": 1280, "c_height": 720, "h_size": 120,
           "dynamic_settings": _settings()}
    path = psd_build.build_psd(**engine_api._build_kwargs(cfg), output_format="PSD", progress_callback=lambda d: None)
    psd = psd_tools.PSDImage.open(path)
    head = next(l for l in psd.descendants() if l.kind == "type" and "GAME RULES" in l.name)
    body = next(l for l in psd.descendants() if l.kind == "type" and "wins" in l.name)
    assert blend_if.from_ranges(head._record.blending_ranges) == [0, 0, 252, 252]
    assert blend_if.from_ranges(body._record.blending_ranges) is None
    # the document text block (Txt2, what Photoshop reads): style sheet 6 / 7 = width / height scale, 8 tracking
    raw = open(path, "rb").read()
    start = raw.find(b"8BIMTxt2")
    stories = txt2.parse(raw[start + 12:start + 12 + int.from_bytes(raw[start + 8:start + 12], "big")])[1][1]
    sheets = {s[0][0].strip(): [r[0][0][6] for r in s[0][6][0]] for s in stories}
    head_runs = sheets["GAME RULES"]
    assert all(r[6] == pytest.approx(0.72) and r[7] == pytest.approx(0.8) and r[11] == 1 for r in head_runs)
    assert any(abs(r[8] - 50) <= 1 for r in head_runs), [r[8] for r in head_runs]
    assert all(r.get(6, 1.0) == 1.0 and r.get(7, 1.0) == 1.0 for r in sheets["All wins on played lines only."])


def test_legacy_kern_table_pairs_count_whole():
    """Franklin Gothic keeps its pairs in a legacy 'kern' table: HarfBuzz puts half on each glyph. Photoshop
    (and Chrome) kern "ATATATAT" at 207 px 54 px tighter; only half of that was counted."""
    font = png_builder._load_font(ImageFont, "FranklinGothic-Heavy", 207, bold=True)
    if "franklin" not in str(getattr(font, "path", "")).lower():
        pytest.skip("Franklin Gothic Heavy not installed")
    plain = sum(ps_text.char_advance(font, c) for c in "ATATATAT")
    assert plain - ps_text.advance(font, "ATATATAT") == pytest.approx(54, abs=1)


def test_tracked_lines_align_like_photoshop():
    """Photoshop centres a tracked line one tracking step right of plain centring, right-aligns it two
    (measured: "H", "HB", "GAME RULES" at tracking 50–200); left-aligned lines start at the box."""
    font = _font(120)

    def ink_left(align, trk):
        img = Image.new("RGBA", (1200, 300), (0, 0, 0, 0))
        with ps_text.tracking(trk):
            w = ps_text.advance(font, "HB")
            png_builder._draw_inline(img, ImageDraw.Draw(img), Image, "HB", 100, 50, font, (255, 255, 255), 1000,
                                     "", {}, 40, align=align, line_spacing=0)
        plain = {"left": 100, "center": 100 + (1000 - w) / 2, "right": 1100 - w}[align]
        return np.nonzero((np.asarray(img)[..., 3] > 128).any(0))[0].min() - plain

    for align, steps in (("left", 0), ("center", 1), ("right", 2)):
        assert ink_left(align, 100) - ink_left(align, 0) == pytest.approx(steps * 12, abs=1.5), align
