"""PNG/PSD row-gap parity: png_builder._row_gap_px must be a faithful twin of
build_engine._line_gap_margin_px, and the PNG game-rules renderer must honor
the same priorities (UI Row spacing > configured line height > multiplier/px
Line spacing)."""

from ps_autotypesetter.build_engine import _line_gap_margin_px
from ps_autotypesetter.png_builder import _row_gap_px


def test_row_gap_matches_psd_math():
    for font_size, line_spacing, step in [
        (20, 1.1, None),
        (30, 2.0, None),
        (20, 25, None),
        (20, 19, None),
        (30, 0, None),
        (20, 1.1, 30),
        (44, 1.1, 0),
        (30, 3, None),
        (30, 3.1, None),
    ]:
        assert _row_gap_px(font_size, line_spacing, line_step_override=step) == _line_gap_margin_px(
            font_size, line_spacing, step
        ), (font_size, line_spacing, step)


def test_row_gap_multiplier_semantics():
    assert _row_gap_px(30, 1.1) == 3
    assert _row_gap_px(30, 2.0) == 30
    assert _row_gap_px(30, 1.0) == 0
    assert _row_gap_px(30, 0.9) == 0


def test_row_gap_px_values_used_directly():
    assert _row_gap_px(30, 19) == 19
    assert _row_gap_px(30, 4) == 4
    assert _row_gap_px(30, 0) == 0


def test_row_gap_line_height_override_wins_over_multiplier():
    assert _row_gap_px(30, 1.1, line_step_override=40) == 40


def test_row_gap_explicit_line_gap_wins_over_everything():
    assert _row_gap_px(30, 1.1, line_step_override=40, line_gap=12) == 12
    assert _row_gap_px(30, 1.1, line_gap=0) == 0
    assert _row_gap_px(30, 19, line_gap=7) == 7


def test_draw_inline_applies_icon_y_offset(tmp_path):
    """The FINAL PNG renderer must shift inline icons by icon_y_offset exactly
    like the PSD engine (build_engine target_y = center - h/2 + offset) and the
    LIVE canvas, so the three renderers keep icon placement identical."""
    from PIL import Image, ImageDraw, ImageFont

    from ps_autotypesetter import png_builder

    icon = Image.new("RGBA", (24, 24), (0, 0, 0, 0))
    ImageDraw.Draw(icon).ellipse((2, 2, 22, 22), fill=(255, 0, 0, 255))
    icon_dir = tmp_path / "icons"
    icon_dir.mkdir()
    icon_path = icon_dir / "gem.png"
    icon.save(str(icon_path))

    tops = []
    for offset in (0, 30):
        base = Image.new("RGBA", (400, 240), (255, 255, 255, 255))
        draw = ImageDraw.Draw(base)
        font = png_builder._load_font(ImageFont, "Arial", 30)
        png_builder._draw_inline(
            base, draw, Image, "Hello <gem> world", 10, 40, font, (0, 0, 0), 380,
            str(icon_dir), {}, 24, align="center", icon_y_offset=offset,
        )
        px = base.load()
        red_tops = [y for y in range(240) for x in range(400) if px[x, y][:3] == (255, 0, 0)]
        assert red_tops, "icon not drawn"
        tops.append(min(red_tops))
    assert tops[1] - tops[0] == 30


def _engine_rows(ws, sheet_name, icon_dir, line_spacing, line_gap):
    from openpyxl import load_workbook

    from ps_autotypesetter import layout_engine

    layouts = layout_engine.build_sheet_layouts(
        ws, sheet_name, canvas_w=1920, canvas_h=1080, margin_x=100,
        h_font="Arial", h_size=72, h_icon_h=48, h_rgb="#FF5050",
        b_font="Arial", b_size=30, b_icon_h=24, b_rgb="#FFFFFF",
        line_spacing=line_spacing, para_spacing=12, line_gap=line_gap,
        heading_top_margin=120, heading_to_body_gap=40, bottom_margin=80,
        max_col_limit=12, icon_folder=icon_dir, icon_mappings={},
        icon_size_overrides={}, dynamic_settings={}, page_overrides={},
        alignment_settings={}, heading_image_folder="", inner_canvas_width=0,
        continued_gap=15, icon_y_offset=0,
    )
    return sorted(
        (e for e in layouts[0].elements if e.id.startswith("body_")),
        key=lambda e: e.y,
    )


def test_px_gap_mode_advances_from_ink_bottom(tmp_path):
    """PSD-style Row spacing (line_gap px): rows advance from the REAL ink
    bottom (glyph ink / icon boxes) + the px gap, so the VISUAL gap between
    consecutive rows equals the Row Gap field exactly (next_row_top =
    prev_ink_bottom + gap - ink_top). The font box (ascent+descent) is taller
    than the ink, so box-based stacking would render gaps larger than the
    configured value."""
    from openpyxl import Workbook
    from openpyxl.styles import Font

    from ps_autotypesetter import layout_engine, png_builder

    icon_dir = tmp_path / "icons"
    icon_dir.mkdir()
    img = __import__("PIL.Image", fromlist=["Image"]).new("RGBA", (40, 50), (0, 0, 0, 0))
    __import__("PIL.ImageDraw", fromlist=["ImageDraw"]).Draw(img).rectangle([0, 0, 39, 49], fill=(255, 0, 0, 255))
    img.save(icon_dir / "ACE.png")

    path = tmp_path / "t.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "PAGE1"
    ws.cell(row=1, column=1, value="GAME RULES").font = Font(bold=True)
    ws.append(["Row one <ACE>"])
    ws.append(["Row two <ACE>"])
    wb.save(str(path))
    wb.close()

    wb = __import__("openpyxl").load_workbook(str(path))
    ws = wb["PAGE1"]

    Image = __import__("PIL.Image", fromlist=["Image"])
    ImageDraw = __import__("PIL.ImageDraw", fromlist=["ImageDraw"])
    ImageFont = __import__("PIL.ImageFont", fromlist=["ImageFont"])
    font = png_builder._load_font(ImageFont, "Arial", 30)
    probe = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    probe_draw = ImageDraw.Draw(probe)
    it1, ib1 = png_builder._line_ink_extents(probe_draw, probe, "Row one <ACE>", font, str(icon_dir), {}, 24, {}, 15, 15, 0)
    it2, ib2 = png_builder._line_ink_extents(probe_draw, probe, "Row two <ACE>", font, str(icon_dir), {}, 24, {}, 15, 15, 0)
    assert ib1 - it1 < png_builder._glyph_box_h_px(font), "ink must be shorter than the font box, or the exactness claim is moot"

    expected_30 = ib1 + 30 - it2  # next_row_top = prev_ink_bottom + gap - ink_top
    rows = _engine_rows(ws, "PAGE1", str(icon_dir), 1.1, 30)
    assert len(rows) == 2
    step = rows[1].y - rows[0].y
    assert step == expected_30, f"px row gap: step {step} != ink-based {expected_30}"
    assert rows[1].meta.get("line") == 1  # per-line elements, never re-stacked

    rows = _engine_rows(ws, "PAGE1", str(icon_dir), 30, None)
    assert rows[1].y - rows[0].y == expected_30, "px Line spacing must use the same ink-based gap"

    rows = _engine_rows(ws, "PAGE1", str(icon_dir), 1.1, None)
    assert rows[1].y - rows[0].y == expected_30, "empty Row spacing defaults to the 30px ink-based gap (Line spacing no longer participates)"
    rows = _engine_rows(ws, "PAGE1", str(icon_dir), 1.1, 0)
    assert rows[1].y - rows[0].y == ib1 - it2, "line_gap 0 = rows touch their own ink extents"
    wb.close()
    assert layout_engine is not None


def _band_gaps(img_path, threshold=250):
    from PIL import Image

    img = Image.open(img_path).convert("L")
    w, h = img.size
    px = img.load()
    bands = []
    in_band = False
    for y in range(h):
        dark = any(px[x, y] < threshold for x in range(w))
        if dark and not in_band:
            bands.append([y, y])
            in_band = True
        elif dark:
            bands[-1][1] = y
        else:
            in_band = False
    return [bands[i + 1][0] - bands[i][1] - 1 for i in range(len(bands) - 1)], bands


def test_canonical_png_keeps_exact_row_gap(tmp_path, monkeypatch):
    """The canonical PNG branch must receive the UI Row spacing value.

    (Regression: png_builder dropped line_gap on the canonical layout call, so
    canonical PNG pages rendered the 30px default no matter what Row spacing
    said. The canonical PNG must render EXACTLY the same constant ink gap as
    the game-rules PNG.)"""
    import ps_autotypesetter.layout_engine as layout_engine_mod
    from ps_autotypesetter import png_builder

    called_with = {}

    real = layout_engine_mod.build_normal_page_layouts

    def spy(*args, **kwargs):
        called_with.update(kwargs)
        return real(*args, **kwargs)

    monkeypatch.setattr(layout_engine_mod, "build_normal_page_layouts", spy)

    path = tmp_path / "canonical.xlsx"

    from openpyxl import Workbook
    from openpyxl.styles import Font

    wb = Workbook()
    ws = wb.active
    ws.title = "PAGE1"
    ws.cell(row=1, column=1, value="GAME RULES").font = Font(bold=True)
    for i in range(3):
        ws.append([
            f"Canonical paragraph {i + 1}: spin wins with a wild multiplier and bonus free games awarded on "
            f"every winning combination. It always wraps onto several rendered rows so the row spacing becomes measurable."
        ])
    wb.save(str(path))
    wb.close()

    import os

    out = tmp_path / "out"
    out.mkdir()
    png_builder.build_pngs_only(
        excel_path=str(path), icon_folder="", bg_path="", bg_color="#FFFFFF",
        c_width=1920, c_height=1080, max_col_limit=12,
        h_font="Arial", h_size=72, h_icon_h=48, h_rgb="#FF5050",
        b_font="Arial", b_size=30, b_icon_h=24, b_rgb="#101010",
        margin_x=100, line_spacing=1.1, para_spacing=12,
        gap_px=20, icon_y_offset=0, enable_tables=False,
        dynamic_settings={"line_gap": 70}, alignment_settings={},
        heading_top_margin=120, heading_to_body_gap=40, bottom_margin=80,
        icon_mappings={}, icon_size_overrides={}, output_dir=str(out),
        output_name="canonical", selected_sheets=["PAGE1"],
        use_canonical_layout=True,
    )
    assert called_with.get("line_gap") == 70, f"canonical branch must receive line_gap, got {called_with.get('line_gap')!r}"

    import glob

    pngs = glob.glob(os.path.join(str(out), "canonical_PNGs", "*.png"))
    assert pngs, f"no canonical PNG produced: {os.listdir(str(out))}"
    gaps, bands = _band_gaps(pngs[0])
    body_gaps = gaps[1:]
    assert len(body_gaps) >= 3, f"expected wrapped rows, got bands {bands}"
    for g in body_gaps:
        assert g in (69, 70, 71), f"canonical PNG wrapped gap {g} != 70 (gaps {gaps})"


def test_psd_row_gap_measures_union_box_to_union_box():
    """PSD 'Row spacing' contract: the gap is the distance between consecutive
    rows' FULL content bounds — the union of the tallest icon and the text ink,
    whatever is higher and whatever is lower — exactly like the PNG renderer.

    With 44px icons over 14px text and Row Gap 90 the measured union-to-union
    gap must be 90. A text-box-only step would read 90 - 15 = 75 (icon counted
    on one side only) or 60 (ignored on both), so this pins the union bounds
    on BOTH the previous row's bottom and the next row's top."""
    from ps_autotypesetter.build_engine import _pil_ink_extents, _row_gap_step_px

    F, ICON, GAP = 14, 44, 90

    def ink(text):
        it, ib, asc = _pil_ink_extents(F, "Arial", text)
        return it, ib, asc

    def union_bottom(it, ib, asc, icon_h):
        bot = ib
        if icon_h:
            bot = max(bot, asc - F * 0.35 + icon_h / 2.0)
        return bot

    def union_top(it, ib, asc, icon_h):
        top = it
        if icon_h:
            top = min(top, asc - F * 0.35 - icon_h / 2.0)
        return top

    it1, ib1, asc1 = ink("Row one")
    it2, ib2, asc2 = ink("Row two")
    step = _row_gap_step_px(F, "Arial", "Row one", ICON, GAP, next_text="Row two", next_icon_h=ICON)
    # baselines: text top = baseline - ascent; ink offsets are from text top.
    # Absolute union gap(row1->row2) = (b1 - asc2 + ut2) - (b0 - asc1 + ub1)
    union_gap = step + (union_top(it2, ib2, asc2, ICON) - asc2) - (union_bottom(it1, ib1, asc1, ICON) - asc1)
    assert abs(union_gap - GAP) <= 1.0, f"union->union gap {union_gap} != {GAP}: icons must be part of the row bound on BOTH sides"

    # The OLD bug: a step computed from the TEXT boxes only (icons ignored on
    # both sides) makes the visible union gap smaller than configured (~75
    # instead of 90 here): the icons eat into the gap. This must never return.
    step_t = _row_gap_step_px(F, "Arial", "Row one", 0, GAP, next_text="Row two", next_icon_h=0)
    t_gap = step_t + (union_top(it2, ib2, asc2, ICON) - asc2) - (union_bottom(it1, ib1, asc1, ICON) - asc1)
    assert t_gap < GAP - 5, f"a text-box-only step would render union gap {t_gap} instead of {GAP}; icons must count on both sides"

    # Icon taller than text in a common size: gap stays exact.
    step2 = _row_gap_step_px(24, "Arial", "Row a", 60, 70, next_text="Row b", next_icon_h=60)
    ita, iba, asca = _pil_ink_extents(24, "Arial", "Row a")
    itb, ibb, ascb = _pil_ink_extents(24, "Arial", "Row b")
    g2 = step2 + (union_top(itb, ibb, ascb, 60) - ascb) - (union_bottom(ita, iba, asca, 60) - asca)
    assert abs(g2 - 70) <= 1.0, f"24px/60px-icon union gap {g2} != 70"

    # Text-only rows: the text ink is the bound; the gap must stay exact.
    ita3, iba3, asca3 = _pil_ink_extents(14, "Arial", "Row a")
    itb3, ibb3, ascb3 = _pil_ink_extents(14, "Arial", "Row b")
    step3 = _row_gap_step_px(14, "Arial", "Row a", 0, 90, next_text="Row b", next_icon_h=0)
    g3 = step3 + (itb3 - ascb3) - (iba3 - asca3)
    assert abs(g3 - 90) <= 1.0, f"text-only union gap {g3} != 90"

