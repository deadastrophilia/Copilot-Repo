"""Photoshop-faithful text rasteriser (measured against Photoshop 2026)."""
import numpy as np
import pytest
from PIL import Image, ImageFont

from ps_autotypesetter import png_builder, ps_text


@pytest.fixture
def arial():
    return png_builder._load_font(ImageFont, "Arial", 30)


def test_baseline_snaps_like_photoshop():
    # nearest row, halves going DOWN the page (Python's round() sends halves to even)
    assert [ps_text.snap_baseline(v) for v in (436.5, 437.5, 10.2, 10.7, 99.49)] == [437, 438, 10, 11, 99]


def test_advance_is_exact_and_kerned_like_photoshop_metrics(arial):
    exact = arial.font_variant(size=1000)
    plain = (exact.getlength("A") + exact.getlength("V")) * 30 / 1000
    k = ps_text.kern(arial, "A", "V")
    assert k == pytest.approx(-152 / 2048 * 30, abs=0.05)                   # Arial's own AV pair
    assert ps_text.advance(arial, "AV") == pytest.approx(plain + k, abs=1e-6)
    assert ps_text.kern(arial, "a", "b") == 0.0
    ps_text.KERNING = False
    try:
        assert ps_text.advance(arial, "AV") == pytest.approx(plain, abs=1e-6)
    finally:
        ps_text.KERNING = True
    assert ps_text.advance(arial, "Wave") != arial.getlength("Wave")          # Pillow rounds per glyph
    pos = ps_text.glyph_positions(arial, "ab", 10.25, tracking_px=1.0)
    assert pos[1][1] == pytest.approx(10.25 + ps_text.char_advance(arial, "a") + 1.0)
    pos = ps_text.glyph_positions(arial, "AV", 0.0)
    assert pos[1][1] == pytest.approx(ps_text.char_advance(arial, "A") + k)


def test_coverage_lands_on_snapped_baseline_and_fractional_x(arial):
    cov, left, top = ps_text.coverage([("H", arial, 100.25, 200.5, 0.0)])
    ink = np.asarray(cov) > 128
    rows = np.where(ink.any(1))[0]
    assert top + rows.max() == 200                        # H sits on row 201 - 1 (baseline 201)
    a, _, _ = ps_text.coverage([("H", arial, 100.25, 200.5, 0.0)])
    b, bl, _ = ps_text.coverage([("H", arial, 100.75, 200.5, 0.0)])
    assert np.asarray(a).tobytes() != np.asarray(b).tobytes() or bl != left   # sub-pixel x is honoured


def test_gamma_blend_matches_photoshop_direction(arial):
    white = Image.new("RGBA", (200, 60), (255, 255, 255, 255))
    black = Image.new("RGBA", (200, 60), (0, 0, 0, 255))
    ps_text.draw(white, "Hi", arial, 10, 40, (0, 0, 0))
    ps_text.draw(black, "Hi", arial, 10, 40, (255, 255, 255))
    # gamma 1.45: a 50% edge is lighter than 50% grey on white, brighter on black
    w = np.asarray(white.convert("L"), float)
    k = np.asarray(black.convert("L"), float)
    edge_w = w[(w > 20) & (w < 235)].mean()
    edge_k = k[(k > 20) & (k < 235)].mean()
    assert edge_w > 128 and edge_k > 128


def test_text_layer_tracking_is_zero_with_exact_layout(arial):
    from ps_autotypesetter.psd_writer import document, recorder

    rec = recorder.TextRecord(arial, (255, 255, 255), "center")
    line = recorder.TextLine(100.0)
    line.runs.append(recorder.TextRun("Wave AVATAR", (255, 255, 255), 40.0, ps_text.advance(arial, "Wave AVATAR")))
    rec.lines.append(line)
    rec.box = (0.0, 800.0)
    _text, spans, _ = document.text_spans(rec)
    assert all(s[3] == 0 for s in spans)        # typed text in Photoshop gets normal spacing
