"""Mapped-paytable live-sheet filter: templates saved for 10 cards must render
only the cards the CURRENT worksheet contains (9 cards -> 9 slots, no 10th
icon/pay/value and no extra card-BG fill)."""

import os
import tempfile

import pytest
from openpyxl import Workbook

from ps_autotypesetter.ui_web import engine_api
from ps_autotypesetter.ui_web.engine_api import (
    filter_paytable_mappings_to_sheet,
    paytable_slot_is_dead,
)


def _build_sheet(anchors, rows=6, start_row=2):
    """Workbook with one anchor per card block (label in A-col, pay/value in
    F/G cols below the anchor row). ``anchors``: list of label strings."""
    wb = Workbook()
    ws = wb.active
    ws.title = "Paytable"
    row = start_row
    for label in anchors:
        ws.cell(row=row, column=1, value=label)
        for i, v in enumerate((5, 4, 3, 2)):
            ws.cell(row=row + 1 + i, column=6, value=v)
        for i, v in enumerate((150, 50, 10, 5)):
            ws.cell(row=row + 1 + i, column=8, value=v)
        row += rows
    wb.save
    return ws, wb


@pytest.fixture
def nine_card_workbook(tmp_path):
    wb = Workbook()
    ws = wb.active
    ws.title = "Paytable"
    anchors = ["<PIC1>", "<PIC2>", "<PIC3>", "<PIC4>", "<PIC5>",
               "ACE", "KING", "QUEEN", "JACK"]
    row = 2
    for label in anchors:
        ws.cell(row=row, column=1, value=label)
        for i, v in enumerate((5, 4, 3, 2)):
            ws.cell(row=row + 1 + i, column=6, value=v)
        for i, v in enumerate((150, 50, 10, 5)):
            ws.cell(row=row + 1 + i, column=8, value=v)
        row += 7
    path = os.path.join(str(tmp_path), "nine.xlsx")
    wb.save(path)
    return path


TEN_CARD_SLOTS = {
    "title": {"x": 0, "y": 0, "w": 100, "h": 50},
    "TopCardsBG.1": {"x": 0, "y": 60, "w": 100, "h": 50},
    "TopCardsBG.2": {"x": 110, "y": 60, "w": 100, "h": 50},
    "TopCardsBG.3": {"x": 220, "y": 60, "w": 100, "h": 50},
    "TopCardsBG.4": {"x": 330, "y": 60, "w": 100, "h": 50},
    "TopCardsBG.5": {"x": 440, "y": 60, "w": 100, "h": 50},
    "BottomCardsBG.1": {"x": 0, "y": 120, "w": 100, "h": 50},
    "BottomCardsBG.2": {"x": 110, "y": 120, "w": 100, "h": 50},
    "BottomCardsBG.3": {"x": 220, "y": 120, "w": 100, "h": 50},
    "BottomCardsBG.4": {"x": 330, "y": 120, "w": 100, "h": 50},
    "BottomCardsBG.5": {"x": 440, "y": 120, "w": 100, "h": 50},
    "wild.title": {"x": 0, "y": 180, "w": 100, "h": 50},
}
for _sym in ("pic1", "pic2", "pic3", "pic4", "pic5", "ace", "king", "queen", "jack", "ten"):
    TEN_CARD_SLOTS[_sym] = {"x": 0, "y": 230, "w": 100, "h": 50}
    TEN_CARD_SLOTS[_sym + ".pay"] = {"x": 0, "y": 280, "w": 100, "h": 50}
    TEN_CARD_SLOTS[_sym + ".value"] = {"x": 0, "y": 330, "w": 100, "h": 50}


def _ten_card_template():
    template = dict(TEN_CARD_SLOTS)
    return {
        "canvas": {"width": 1920, "height": 1080},
        "slots": template,
        "mappings": {},
        "mapper_meta": {"generated_by": "web_paytable_mapper", "sheet_name": "Paytable"},
    }


def _with_row_counts(template, top=0, bottom=0):
    """Template copy carrying user-chosen row capacities."""
    t = dict(template)
    t["mapper_meta"] = {"generated_by": "web_paytable_mapper",
                        "sheet_name": "Paytable",
                        "row_counts": {"top": top, "bottom": bottom}}
    return t


def _icon_spec(slot):
    return {"mode": "icon", "token": f"<{slot.split('.')[0]}>", "icon_height": 120}


def _pay_spec(slot, symbol):
    return {"mode": "excel", "source": "F2", "role": "pay", "symbol": symbol,
            "font_size": 30, "color": "#FFFFFF", "text": "5\n4\n3\n2"}


def _bg_spec():
    return {"mode": "excel", "source": "", "fill_enabled": True,
            "fill_color": "#112233", "opacity": 100, "color": "#FFFFFF"}


def _all_mappings():
    mappings = {}
    for sym in ("pic1", "pic2", "pic3", "pic4", "pic5", "ace", "king", "queen", "jack", "ten"):
        mappings[sym] = _icon_spec(sym)
        mappings[sym + ".pay"] = _pay_spec(sym + ".pay", sym)
        mappings[sym + ".value"] = _pay_spec(sym + ".value", sym)
    for i in range(1, 6):
        mappings[f"TopCardsBG.{i}"] = dict(_bg_spec(), slot=f"TopCardsBG.{i}")
        mappings[f"BottomCardsBG.{i}"] = dict(_bg_spec(), slot=f"BottomCardsBG.{i}")
    mappings["title"] = {"mode": "literal", "text": "PAYTABLE", "color": "#FFFFFF"}
    mappings["wild.title"] = {"mode": "literal", "text": "WILD", "color": "#FFCD32"}
    return mappings


@pytest.fixture
def randomname_workbook(tmp_path):
    """10-card sheet whose 4th top card is named <SPACESHIP> instead of
    <PIC4> — the card must auto-layout into the pic4 slot BY POSITION."""
    wb = Workbook()
    ws = wb.active
    ws.title = "Paytable"
    anchors = ["<PIC1>", "<PIC2>", "<PIC3>", "<SPACESHIP>", "ACE",
               "KING", "QUEEN", "JACK", "TEN", "NINE"]
    row = 2
    for label in anchors:
        ws.cell(row=row, column=1, value=label)
        for i, v in enumerate((5, 4, 3, 2)):
            ws.cell(row=row + 1 + i, column=6, value=v)
        for i, v in enumerate((150, 50, 10, 5)):
            ws.cell(row=row + 1 + i, column=8, value=v)
        row += 7
    path = os.path.join(str(tmp_path), "randomname.xlsx")
    wb.save(path)
    return path


def _slot_mapping(result, slot):
    for m in result["mappings"]:
        if m.get("slot") == slot:
            return m
    return None


def test_blocks_ordered_and_positional_pic_fallback(randomname_workbook):
    wb, ws = _load_ws(randomname_workbook)
    try:
        result = engine_api.automap_paytable_slots_ws(ws, _ten_card_template())
        blocks = result["blocks"]
        assert len(blocks) == 10
        assert [b["key"] for b in blocks] == [
            "pic1", "pic2", "pic3", "spaceship", "ace",
            "king", "queen", "jack", "ten", "nine",
        ]
        assert blocks[3]["token"] == "<spaceship>"
        assert blocks[3]["pay_ref"].startswith("F")
        assert blocks[3]["value_ref"].startswith("H")
        # the bottom band starts at the first <ace>: pic1..pic3 + <spaceship> on top
        assert result["card_counts"] == {"top": 4, "lower": 6}
        # pic4 (no <PIC4> anchor) falls back to the 4th block by position
        pic4 = _slot_mapping(result, "pic4")
        assert pic4 and pic4["mode"] == "icon"
        assert pic4["token"] == "<spaceship>"
        assert pic4["symbol"] == "spaceship"
        pic4_pay = _slot_mapping(result, "pic4.pay")
        assert pic4_pay and pic4_pay["symbol"] == "spaceship"
        assert pic4_pay["text"] == "5\n4\n3\n2"
        pic4_value = _slot_mapping(result, "pic4.value")
        assert pic4_value and pic4_value["symbol"] == "spaceship"
        assert pic4_value["text"] == "150\n50\n10\n5"
        # pic5's position lands on ACE, which the "ace" slot already claims
        # by name — it must NOT get the block; it stays a generic <pic5>
        # icon (which the live-sheet filter drops, since no pic5 anchor
        # exists), and its pay/value data slots stay unmapped
        assert _slot_mapping(result, "pic5")["token"] == "<pic5>"
        assert "pic5.pay" in result["unmapped"]
        assert "pic5.value" in result["unmapped"]
        # name-matched cards keep their own tokens
        assert _slot_mapping(result, "pic1")["token"] == "<pic1>"
        assert _slot_mapping(result, "ace")["token"] == "<ace>"
        assert _slot_mapping(result, "ten")["token"] == "<ten>"
    finally:
        wb.close()


def test_randomname_filter_keeps_positional_slot(randomname_workbook):
    wb, ws = _load_ws(randomname_workbook)
    try:
        template = _ten_card_template()
        mappings = _all_mappings()
        # simulate a saved session: pic4 was auto-mapped to the SPACESHIP block
        mappings["pic4"] = {"mode": "icon", "source": "", "slot": "pic4",
                            "token": "<spaceship>", "symbol": "spaceship",
                            "icon_height": 120, "color": "#FFFFFF",
                            "alignment": "center", "vertical_align": "center",
                            "padding": [0, 0, 0, 0]}
        mappings["pic4.pay"] = {"mode": "excel", "source": "F20", "role": "pay",
                                "symbol": "spaceship", "font_size": 30,
                                "color": "#FFFFFF", "text": "5\n4\n3\n2"}
        mappings["pic4.value"] = {"mode": "excel", "source": "H20", "role": "value",
                                  "symbol": "spaceship", "font_size": 30,
                                  "color": "#FFFFFF", "text": "150\n50\n10\n5"}
        dropped = filter_paytable_mappings_to_sheet(mappings, ws, template)
        # pic5 icon + pay + value and TopCardsBG.5: the top band holds 4 cards (ACE starts the bottom)
        assert dropped == 4
        assert mappings["pic4"]["token"] == "<spaceship>"
        assert mappings["pic4.pay"]["symbol"] == "spaceship"
        assert mappings["pic4.value"]["symbol"] == "spaceship"
        for key in ("pic5", "pic5.pay", "pic5.value"):
            assert key not in mappings
        for sym in ("pic1", "pic2", "pic3", "ace", "king", "queen", "jack", "ten"):
            assert sym in mappings
        assert "BottomCardsBG.5" in mappings  # lower row has 6 cards (template only has 5 boxes)
        assert "TopCardsBG.5" not in mappings
        assert "title" in mappings and "wild.title" in mappings
    finally:
        wb.close()


def _load_ws(path):
    from openpyxl import load_workbook

    wb = load_workbook(path, data_only=True, read_only=True)
    return wb, wb["Paytable"]


def test_sheet_card_counts_nine_cards(nine_card_workbook):
    wb, ws = _load_ws(nine_card_workbook)
    try:
        result = engine_api.automap_paytable_slots_ws(ws, _ten_card_template())
        counts = result["card_counts"]
        assert counts == {"top": 5, "lower": 4}
        symbols = set(result["symbols"])
        assert "pic1" in symbols and "jack" in symbols and "ten" not in symbols
    finally:
        wb.close()


def test_filter_drops_absent_10th_card(nine_card_workbook):
    wb, ws = _load_ws(nine_card_workbook)
    try:
        template = _ten_card_template()
        mappings = _all_mappings()
        dropped = filter_paytable_mappings_to_sheet(mappings, ws, template)
        assert dropped == 4  # ten icon + ten.pay + ten.value + BottomCardsBG.5
        # The 10th card (ten) is fully gone
        assert "ten" not in mappings and "ten.pay" not in mappings and "ten.value" not in mappings
        # All 9 real cards stay
        for sym in ("pic1", "pic2", "pic3", "pic4", "pic5", "ace", "king", "queen", "jack"):
            assert sym in mappings and sym + ".pay" in mappings and sym + ".value" in mappings
        # Card-BG fills capped to the sheet's blocks: bottom row has 4 cards
        assert "BottomCardsBG.5" not in mappings
        for i in range(1, 5):
            assert f"BottomCardsBG.{i}" in mappings
        assert "TopCardsBG.5" in mappings
        # Legend slots never dropped
        assert "title" in mappings and "wild.title" in mappings
    finally:
        wb.close()


def test_filter_keeps_all_for_full_sheet(tmp_path):
    wb = Workbook()
    ws = wb.active
    ws.title = "Paytable"
    anchors = ["<PIC1>", "<PIC2>", "<PIC3>", "<PIC4>", "<PIC5>",
               "ACE", "KING", "QUEEN", "JACK", "TEN"]
    row = 2
    for label in anchors:
        ws.cell(row=row, column=1, value=label)
        for i, v in enumerate((5, 4, 3, 2)):
            ws.cell(row=row + 1 + i, column=6, value=v)
        for i, v in enumerate((150, 50, 10, 5)):
            ws.cell(row=row + 1 + i, column=8, value=v)
        row += 7
    try:
        template = _ten_card_template()
        mappings = _all_mappings()
        dropped = filter_paytable_mappings_to_sheet(mappings, ws, template)
        assert dropped == 0
        assert "ten" in mappings and "BottomCardsBG.5" in mappings
    finally:
        wb.close()


def test_slot_is_dead_direct():
    live = ({"pic1", "ace", "ten"}, 5, 4, 9)
    assert not paytable_slot_is_dead("ace", _icon_spec("ace"), live)
    assert not paytable_slot_is_dead("ace.pay", _pay_spec("ace.pay", "ace"), live)
    assert paytable_slot_is_dead("queen", _icon_spec("queen"), live)
    assert paytable_slot_is_dead("BottomCardsBG.5", None, live)
    assert not paytable_slot_is_dead("BottomCardsBG.4", None, live)
    assert not paytable_slot_is_dead("title", None, live)
    assert not paytable_slot_is_dead("wild.title", None, live)
    # unmapped slots cannot be judged without a spec (the renderer hands the
    # name-based icon default, which carries the token)
    assert not paytable_slot_is_dead("jack", None, live)
    assert paytable_slot_is_dead("jack", _icon_spec("jack"), live)
    assert not paytable_slot_is_dead("ace", None, live)


def test_data_slots_with_stray_tokens_never_die():
    """A DATA slot (``mode:"excel"`` etc.) reads cells by ``source``; a stray
    ``token`` leftover from an older auto-map must not make the slot look like
    a missing card and kill its render (regression: `@slot.slot.1` carrying
    ``token:"<1>"`` rendered nothing while the sheet has no ``<1>`` anchor)."""
    live = ({"ace", "jack", "ten"}, 5, 4, 9)
    stray = {"mode": "excel", "source": "B6", "text": "<WILD> This is wild Text",
             "token": "<1>"}
    assert not paytable_slot_is_dead("slot.1", stray, live)
    assert not paytable_slot_is_dead("text", dict(stray, token="<garbage>"), live)
    assert not paytable_slot_is_dead("text.1", dict(stray, token="<1>"), live)
    # data slot WITHOUT any token still follows the same rule
    assert not paytable_slot_is_dead("slot.1", {"mode": "excel", "source": "B6"}, live)
    # card-like data slots stay subject to the sheet when they carry a symbol
    assert paytable_slot_is_dead("queen.pay", _pay_spec("queen.pay", "queen"), live)
    assert not paytable_slot_is_dead("ace.pay", _pay_spec("ace.pay", "ace"), live)
    # explicit automap symbol keeps a data slot tied to its card
    assert paytable_slot_is_dead("slot.1", dict(stray, symbol="queen"), live)
    # icon slots unaffected: a token alone still binds to the card
    assert paytable_slot_is_dead("some", {"mode": "icon", "token": "<some>"}, live)


def test_wild_icons_always_render(nine_card_workbook):
    """WILD icons the JSON explicitly carries (`@slot.wild` / `wild.1` /
    `wild.2` with a `<wild>` token) are universal: they render even when the
    sheet has no bare WILD anchor. Only wild DATA slots (wildpay/wildvalue)
    stay subject to the sheet."""
    live = ({"pic1", "ace", "ten"}, 5, 4, 9)
    assert not paytable_slot_is_dead("wild", _icon_spec("wild"), live)
    assert not paytable_slot_is_dead("wild.1", _icon_spec("wild.1"), live)
    assert not paytable_slot_is_dead("wild.2", _icon_spec("wild.2"), live)
    # unmapped @slot.wild gets the name-based <wild> default -> still kept
    assert not paytable_slot_is_dead("wild", _default_icon_spec("wild"), live)
    assert not paytable_slot_is_dead("wild.1", _default_icon_spec("wild.1"), live)
    # non-wild symbols keep filtering
    assert paytable_slot_is_dead("queen", _icon_spec("queen"), live)


def _default_icon_spec(slot):
    from ps_autotypesetter.dynamic_pages.paytable.renderer import _default_icon_mapping

    return _default_icon_mapping(slot)


def test_wild_icons_survive_sheet_filter(nine_card_workbook):
    wb, ws = _load_ws(nine_card_workbook)
    try:
        template = _ten_card_template()
        mappings = _all_mappings()
        mappings["wild"] = _icon_spec("wild")
        mappings["wild.1"] = _icon_spec("wild.1")
        mappings["wildpay"] = _pay_spec("wildpay", "wild")
        dropped = filter_paytable_mappings_to_sheet(mappings, ws, template)
        assert "wild" in mappings and "wild.1" in mappings
        assert "wildpay" not in mappings  # no wild data row in the sheet
        assert "ten" not in mappings      # ordinary cards still filtered
    finally:
        wb.close()


def test_renderer_mapped_filter_shim(nine_card_workbook):
    from ps_autotypesetter.dynamic_pages.paytable.renderer import _filter_mappings_to_sheet

    wb, ws = _load_ws(nine_card_workbook)
    try:
        template = _ten_card_template()
        mappings = _all_mappings()
        assert _filter_mappings_to_sheet(mappings, ws, template) == 4
        assert "ten" not in mappings
    finally:
        wb.close()


def test_row_counts_override_card_counts(randomname_workbook):
    """User-chosen row capacities (top=4/bottom=6) beat the template's
    card-BG counts: the 5th top slot stops rendering, the bottom absorbs
    the freed card."""
    wb, ws = _load_ws(randomname_workbook)
    try:
        base = _ten_card_template()
        result = engine_api.automap_paytable_slots_ws(ws, _with_row_counts(base, top=4, bottom=6))
        assert result["card_counts"] == {"top": 4, "lower": 6}
        # pic4 still positionally finds <SPACESHIP> (top position 4)
        assert _slot_mapping(result, "pic4")["token"] == "<spaceship>"
        # top position 5 is gone -> pic5 stays a generic icon, data unmapped
        assert _slot_mapping(result, "pic5")["token"] == "<pic5>"
        # top-only override: bottom = the rest
        result2 = engine_api.automap_paytable_slots_ws(ws, _with_row_counts(base, top=4))
        assert result2["card_counts"] == {"top": 4, "lower": 6}
        # bottom-only override: top still comes from the <ace> split
        result3 = engine_api.automap_paytable_slots_ws(ws, _with_row_counts(base, bottom=4))
        assert result3["card_counts"] == {"top": 4, "lower": 4}
        # no overrides: Excel decides — the bottom band starts at <ace> (4/6)
        result4 = engine_api.automap_paytable_slots_ws(ws, base)
        assert result4["card_counts"] == {"top": 4, "lower": 6}
    finally:
        wb.close()


def test_dead_positional_slots_beyond_row_caps():
    blocks = ["pic1", "pic2", "pic3", "spaceship", "ace",
              "king", "queen", "jack", "ten", "nine"]
    # pic5 HAS an anchor in the sheet, yet dies by POSITION (slot 5 > cap 4)
    live_top4 = ({"pic1", "pic3", "spaceship", "pic5", "ace", "ten"}, 4, 6, 10, blocks)
    assert paytable_slot_is_dead("pic5", _icon_spec("pic5"), live_top4)
    assert paytable_slot_is_dead("pic5.pay", _pay_spec("pic5.pay", "pic5"), live_top4)
    assert paytable_slot_is_dead("pic5.value", _pay_spec("pic5.value", "pic5"), live_top4)
    assert not paytable_slot_is_dead("pic3", _icon_spec("pic3"), live_top4)
    assert not paytable_slot_is_dead("TopCardsBG.4", None, live_top4)
    assert paytable_slot_is_dead("TopCardsBG.5", None, live_top4)
    # bottom row capacity 4: ten sits at bottom position 5 -> dead even
    # though a TEN anchor exists in the sheet
    live_bottom4 = ({"pic1", "ace", "ten"}, 5, 4, 9,
                    ["pic1", "pic2", "pic3", "pic4", "pic5",
                     "ace", "king", "queen", "jack", "ten"])
    assert paytable_slot_is_dead("ten", _icon_spec("ten"), live_bottom4)
    assert paytable_slot_is_dead("ten.pay", _pay_spec("ten.pay", "ten"), live_bottom4)
    assert not paytable_slot_is_dead("queen", _icon_spec("queen"), live_bottom4)
    assert paytable_slot_is_dead("BottomCardsBG.5", None, live_bottom4)
    assert not paytable_slot_is_dead("BottomCardsBG.4", None, live_bottom4)
    # wild icons stay universal regardless of row caps
    assert not paytable_slot_is_dead("wild.1", _icon_spec("wild.1"), live_bottom4)


def test_filter_drops_beyond_row_caps(tmp_path):
    wb = Workbook()
    ws = wb.active
    ws.title = "Paytable"
    anchors = ["<PIC1>", "<PIC2>", "<PIC3>", "<PIC4>", "<PIC5>",
               "ACE", "KING", "QUEEN", "JACK", "TEN"]
    row = 2
    for label in anchors:
        ws.cell(row=row, column=1, value=label)
        for i, v in enumerate((5, 4, 3, 2)):
            ws.cell(row=row + 1 + i, column=6, value=v)
        for i, v in enumerate((150, 50, 10, 5)):
            ws.cell(row=row + 1 + i, column=8, value=v)
        row += 7
    try:
        template = _with_row_counts(_ten_card_template(), top=4, bottom=4)
        mappings = _all_mappings()
        dropped = filter_paytable_mappings_to_sheet(mappings, ws, template)
        # top=4: pic5 trio + TopCardsBG.5.
        # bottom=4 (blocks 5..10 rank 1..6): jack (5) + ten (6) trios +
        # BottomCardsBG.5.
        assert dropped == 11
        for key in ("pic5", "pic5.pay", "pic5.value",
                    "jack", "jack.pay", "jack.value",
                    "ten", "ten.pay", "ten.value",
                    "TopCardsBG.5", "BottomCardsBG.5"):
            assert key not in mappings
        for sym in ("pic1", "pic2", "pic3", "ace", "king", "queen"):
            assert sym in mappings and sym + ".pay" in mappings
        assert "TopCardsBG.4" in mappings and "BottomCardsBG.4" in mappings
    finally:
        wb.close()