"""A character the text's font has no glyph for (™ in a display heading font) is drawn in Arial at the
same size — what the browser does on the Canvas — so the PNG and the PSD show it too."""
import glob
import os

import pytest
from PIL import Image, ImageDraw, ImageFont

from ps_autotypesetter import png_builder as pb
from ps_autotypesetter.psd_writer import fontnames


def _font_without_tm():
    paths = glob.glob(os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\Windows\Fonts\*.ttf")) + glob.glob(r"C:\Windows\Fonts\*.ttf")
    for p in paths:
        try:
            f = ImageFont.truetype(p, 60)
        except Exception:
            continue
        if fontnames.has_glyph(f, "A") and not fontnames.has_glyph(f, "™"):
            return f
    pytest.skip("no installed font without a ™ glyph")


def test_arial_has_the_trademark_sign():
    f = pb._fallback_font(ImageFont.load_default()) if False else ImageFont.truetype(r"C:\Windows\Fonts\arial.ttf", 40)
    assert fontnames.has_glyph(f, "™") and fontnames.has_glyph(f, "A")


def test_a_missing_glyph_gets_its_own_arial_run_and_is_drawn():
    f = _font_without_tm()
    runs = pb._style_runs("CARNIVAL™ BONUS", (255, 255, 255), f)
    assert [r[0] for r in runs] == ["CARNIVAL", "™", " BONUS"]
    assert runs[0][2] is f and runs[2][2] is f and os.path.basename(runs[1][2].path).lower() == "arial.ttf"
    assert runs[1][2].size == f.size

    def ink(text):
        base = Image.new("RGBA", (1200, 160), (0, 0, 0, 255))
        pb._draw_inline(base, ImageDraw.Draw(base), Image, text, 0, 20, f, (255, 255, 255), 1200, "", {}, 60, align="left")
        return sum(1 for v in base.convert("L").getdata() if v > 60)
    assert ink("CARNIVAL™") > ink("CARNIVAL") + 200                        # the ™ is drawn, not a blank gap
