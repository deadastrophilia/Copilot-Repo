"""Previews reuse the parsed Excel (workbook_cache) instead of parsing it on every request."""
from openpyxl import Workbook

from ps_autotypesetter import workbook_cache
from ps_autotypesetter.ui_web import page_thumbs


def _excel(tmp_path):
    wb = Workbook()
    ws = wb.active
    ws.title = "Features"
    ws.append(["FREE SPINS"])
    ws.append(["Three scatters award 10 free spins."])
    path = str(tmp_path / "game.xlsx")
    wb.save(path)
    return path


def _count_loads(monkeypatch):
    calls = []
    real = workbook_cache.load_workbook

    def counting(*a, **k):
        calls.append(k.get("read_only", False))
        return real(*a, **k)

    monkeypatch.setattr(workbook_cache, "load_workbook", counting)
    workbook_cache.clear()
    return calls


def test_preview_routes_parse_once_and_return_the_loan(tmp_path, monkeypatch):
    from ps_autotypesetter.ui_web.server import create_app

    excel = _excel(tmp_path)
    calls = _count_loads(monkeypatch)
    client = create_app(session_file=str(tmp_path / "session.json")).test_client()
    client.post("/api/config", json={"excel_path": excel})
    for _ in range(3):
        client.post("/api/paylines/preview", json={})
    assert calls == [False]                                   # one full parse for three previews
    assert all(not e["busy"] for e in workbook_cache._CACHE.values())   # handed back after each request
    workbook_cache.clear()


def test_full_preview_hands_the_workbook_to_the_build(tmp_path, monkeypatch):
    from ps_autotypesetter import png_builder

    excel = _excel(tmp_path)
    calls = _count_loads(monkeypatch)
    seen = {}

    def fake_build(**kw):
        seen["busy"] = [e["busy"] for e in workbook_cache._CACHE.values()]
        with workbook_cache.borrow(excel):                    # what the real build does
            pass
        (tmp_path / "out").mkdir(exist_ok=True)
        from PIL import Image

        Image.new("RGB", (4, 4)).save(kw["output_dir"] + "/Features.png")

    monkeypatch.setattr(png_builder, "build_pngs_only", fake_build)
    out = str(tmp_path / "thumbs" / "full_Features.png")
    res = page_thumbs._render_full_preview(excel, "Features", {"excel_path": excel}, out)
    assert res.get("ok"), res
    assert seen["busy"] == [False]                            # released before the build ran
    assert calls == [False]                                   # so the build reused the same parse
    workbook_cache.clear()
