"""Full previews keep every page of a sheet (its Continued pages too) for the Typography page rail."""
from ps_autotypesetter.ui_web import page_thumbs


def test_continued_pages_come_after_page_one_in_number_order():
    names = ["BBB_Continued_10.png", "BBB.png", "BBB_Continued_2.png", "BBB_Continued_1.png"]
    assert sorted(names, key=page_thumbs._page_order) == \
        ["BBB.png", "BBB_Continued_1.png", "BBB_Continued_2.png", "BBB_Continued_10.png"]


def test_page_files_sit_beside_page_one_and_the_count_is_kept(tmp_path):
    first = str(tmp_path / "full_BBB.png")
    assert page_thumbs.page_path(first, 1) == first
    assert page_thumbs.page_path(first, 3) == str(tmp_path / "full_BBB__p3.png")
    assert page_thumbs.cached_page_count(first) == 1            # made before pages were kept
    page_thumbs._save_page_count(first, 3)
    assert page_thumbs.cached_page_count(first) == 3
