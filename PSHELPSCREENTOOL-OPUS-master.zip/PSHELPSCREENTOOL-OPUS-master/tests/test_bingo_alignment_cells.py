"""Tests for Bingo footer cell alignment (simple Left/Right cell fields)."""

from ps_autotypesetter import build_engine, png_builder


def test_png_defaults_b27_b28_left_h27_h28_right():
    merged = png_builder._bingo_merged_alignments({}, "Bingo Rules")
    assert merged["B27"]["alignment"] == "left"
    assert merged["B28"]["alignment"] == "left"
    assert merged["H27"]["alignment"] == "right"
    assert merged["H28"]["alignment"] == "right"
    assert "B26" not in merged
    assert "A27" not in merged


def test_png_psd_defaults_agree():
    png = png_builder._bingo_merged_alignments({}, "Bingo Rules")
    psd = build_engine._bingo_merged_alignments_psd({}, "Bingo Rules")
    assert psd[(27, 2)]["alignment"] == png["B27"]["alignment"] == "left"
    assert psd[(28, 2)]["alignment"] == png["B28"]["alignment"] == "left"
    assert psd[(27, 8)]["alignment"] == png["H27"]["alignment"] == "right"
    assert psd[(28, 8)]["alignment"] == png["H28"]["alignment"] == "right"


def test_simple_fields_override_defaults():
    ds = {"bingo_rules_left_align_cells": "C5, d6", "bingo_rules_right_align_cells": "G9"}
    merged = png_builder._bingo_merged_alignments(ds, "Bingo Rules")
    assert merged["C5"]["alignment"] == "left"
    assert merged["D6"]["alignment"] == "left"
    assert merged["G9"]["alignment"] == "right"
    assert merged["B27"]["alignment"] == "left"
    assert merged["H28"]["alignment"] == "right"


def test_simple_fields_can_move_default_cells():
    ds = {"bingo_rules_right_align_cells": "B27, B28"}
    merged = png_builder._bingo_merged_alignments(ds, "Bingo Rules")
    assert merged["B27"]["alignment"] == "right"
    assert merged["B28"]["alignment"] == "right"
    merged_psd = build_engine._bingo_merged_alignments_psd(ds, "Bingo Rules")
    assert merged_psd[(27, 2)]["alignment"] == "right"
    assert merged_psd[(28, 2)]["alignment"] == "right"


def test_legacy_overrides_still_win_over_defaults():
    legacy = "Bingo Rules=H27:left:120:120"
    ds = {"bingo_rules_alignment_overrides": legacy}
    merged = png_builder._bingo_merged_alignments(ds, "Bingo Rules")
    assert merged["H27"]["alignment"] == "left"
    assert merged["H27"]["left_margin"] == 120


def test_garbage_input_is_ignored():
    ds = {"bingo_rules_left_align_cells": "notacell, !!", "bingo_rules_right_align_cells": ""}
    merged = png_builder._bingo_merged_alignments(ds, "Bingo Rules")
    assert "notacell" not in merged
    assert merged["H27"]["alignment"] == "right"


def test_ranges_accepted():
    ds = {"bingo_rules_left_align_cells": "B5:C6"}
    merged = png_builder._bingo_merged_alignments(ds, "Bingo Rules")
    assert merged["B5"]["alignment"] == "left"
    assert merged["C6"]["alignment"] == "left"
