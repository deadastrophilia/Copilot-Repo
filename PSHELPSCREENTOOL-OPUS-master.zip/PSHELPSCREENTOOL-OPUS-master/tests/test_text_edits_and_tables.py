"""Artist text edits, letter spacing, hidden sheets and tables split across pages."""
from openpyxl import Workbook

from ps_autotypesetter import png_builder as pb
from ps_autotypesetter import ps_text, text_edits


def test_text_edit_applies_only_while_the_excel_text_is_unchanged():
    text_edits.set_all({"Page": {"row:4": {"from": "Collect  all houses", "to": "Collect all\nhouses"}}})
    try:
        assert text_edits.apply("Page", "row:4", "Collect all houses") == "Collect all\nhouses"   # spaces ignored
        assert text_edits.apply("Page", "row:4", "Collect every house") == "Collect every house"  # Excel changed
        assert text_edits.apply("Other", "row:4", "Collect all houses") == "Collect all houses"
        wb = Workbook()
        ws = wb.active
        ws.title = "Page"
        ws["B4"] = "Collect all houses"
        assert pb._row_page_text(ws, 4, 8) == "Collect all\nhouses"
    finally:
        text_edits.set_all({})


def test_text_typed_in_a_live_editor_is_used_only_inside_its_draft():
    text_edits.set_all({"Page": {"row:4": {"from": "Collect all houses", "to": "Saved text"}}})
    try:
        typed = {"Page": {"row:4": {"from": "Collect all houses", "to": "Typed text"},
                          "row:5": {"from": "Hotels pay more", "to": ""}}}          # row 5 joined away
        with text_edits.draft(typed):
            assert text_edits.apply("Page", "row:4", "Collect all houses") == "Typed text"
            assert text_edits.apply("Page", "row:5", "Hotels pay more") == ""
            assert text_edits.apply("Page", "row:6", "Untouched") == "Untouched"
        assert text_edits.apply("Page", "row:4", "Collect all houses") == "Saved text"   # nothing was saved
        assert text_edits.apply("Page", "row:5", "Hotels pay more") == "Hotels pay more"
    finally:
        text_edits.set_all({})


def test_letter_spacing_widens_every_character():
    _i, _d, ImageFont = pb._require_pillow()
    font = pb._load_font(ImageFont, "Arial", 40)
    plain = ps_text.advance(font, "Bingo")
    with ps_text.tracking(100):                   # 100/1000 em = 4px at 40px
        assert abs(ps_text.advance(font, "Bingo") - (plain + 5 * 4.0)) < 0.01
    assert ps_text.advance(font, "Bingo") == plain


def test_hidden_sheets_are_not_pages():
    wb = Workbook()
    wb.active.title = "Page"
    wb.create_sheet("Notes").sheet_state = "hidden"
    assert pb.visible_sheet_names(wb) == ["Page"]


def test_a_split_table_part_keeps_the_header_and_its_rows():
    Image, ImageDraw, ImageFont = pb._require_pillow()
    wb = Workbook()
    ws = wb.active
    ws.append(["PROPERTIES", "PRIZE"])
    for i in range(10):
        ws.append([f"Street {i}", (i + 1) * 10])
    table = pb.manual_tables_from_ranges(ws, ["A1:B11"], 4)[0] if hasattr(pb, "manual_tables_from_ranges") else None
    if table is None:
        import pytest
        pytest.skip("manual tables not available")
    img = Image.new("RGBA", (1920, 2000))
    full, part = {}, {}
    h_full = pb._draw_auto_table(img, ImageDraw.Draw(img), Image, ImageFont, ws, table, 100, 0, 1720, {}, "", {}, {}, geo=full)
    h_part = pb._draw_auto_table(img, ImageDraw.Draw(img), Image, ImageFont, ws, table, 100, 0, 1720, {}, "", {}, {},
                                 geo=part, row_slice=(4, 7))
    assert full["header_rows"] == 1 and len(full["rows"]) == 11
    assert len(part["rows"]) == 4 and part["header_rows"] == 1               # header + 3 rows
    gap = full["row_gap"]
    assert h_part == full["rows"][0] + sum(full["rows"][5:8]) + 3 * gap      # rows sized as in the whole table
    assert h_part < h_full
