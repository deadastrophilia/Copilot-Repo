"""photoshop_bridge: use whichever Photoshop version is open (no Photoshop needed here)."""

import pytest

from ps_autotypesetter import photoshop_bridge as b

REG = r"F:\Adobe Photoshop 2026\Photoshop.exe"
OLD = r"D:\Adobe Photoshop 2023\Photoshop.exe"


@pytest.mark.parametrize("running, route", [
    ([], "com"),                       # nothing open: COM starts the registered version
    ([(1, REG)], "com"),               # the registered version is open: fast COM path
    ([(1, OLD)], "file"),              # another version open: run the script through ITS exe
])
def test_route_follows_the_open_version(monkeypatch, running, route):
    monkeypatch.setattr(b, "running_photoshops", lambda: running)
    monkeypatch.setattr(b, "registered_photoshop", lambda: REG)
    assert b.describe()["route"] == route


def test_no_photoshop_anywhere(monkeypatch):
    monkeypatch.setattr(b, "running_photoshops", lambda: [])
    monkeypatch.setattr(b, "registered_photoshop", lambda: "")
    with pytest.raises(b.PhotoshopUnavailable):
        b.run_jsx("app.version")


def test_file_route_opens_script_with_the_running_exe(monkeypatch, tmp_path):
    launched = {}
    monkeypatch.setattr(b, "running_photoshops", lambda: [(1, OLD)])
    monkeypatch.setattr(b, "registered_photoshop", lambda: REG)
    monkeypatch.setattr(b.tempfile, "gettempdir", lambda: str(tmp_path))

    def fake_popen(cmd, **kw):  # play Photoshop: write the result file the wrapper asks for
        launched["cmd"] = cmd
        script = open(cmd[1], encoding="utf-8").read()
        assert 'var arguments = ["x"]' in script
        out = cmd[1][:-4] + ".out"
        open(out, "w", encoding="utf-8").write("OK\n24.2.0|x")
    monkeypatch.setattr(b.subprocess, "Popen", fake_popen)
    assert b.run_jsx("app.version + '|' + arguments[0]", args=["x"], timeout=5) == "24.2.0|x"
    assert launched["cmd"][0] == OLD
    assert not list(tmp_path.glob("psh_bridge_*"))  # temp files cleaned up
