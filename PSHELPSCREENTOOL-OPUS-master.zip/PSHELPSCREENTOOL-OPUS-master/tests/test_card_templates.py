"""Card templates (dynamic_pages/paytable/card_templates.py): built-ins, copies, compile, render."""
import copy
import os

import pytest
from openpyxl import Workbook

from ps_autotypesetter.dynamic_pages.paytable import card_templates as ct

# the first designs, retired from the list (old games and these tests still read them) …
BUILTINS = ["classic_cards", "stacked_columns", "compact_grid", "feature_focus", "plain",
            "symbols_on_top", "side_panel", "rules_top_scatter"]
OFFERED = ["fomo_mummy", "floating_showcase", "fruit_columns", "pyramid", "rules_side", "rules_top_kind", "portrait_pillars", "bento_royal_grad", "feature_crown", "floating", "two_column_list", "gold_plates", "jewel_grid"]   # the default first, then the designs


def _sheet():
    wb = Workbook()
    ws = wb.active
    ws.title = "Paytable"
    ws["B2"] = "BASE GAMES PAYTABLE"
    ws["H4"] = "All wins begin with leftmost reel."
    ws["H5"] = "<WILD BASE> substitute for all symbols except <SCAT>."
    row = 11
    for sym in ("<PIC1>", "<PIC2>", "ACE", "KING"):
        for i, (cnt, pay) in enumerate(((5, 100), (4, 20), (3, 5))):
            ws.cell(row + i, 6, cnt)
            ws.cell(row + i, 8, pay)
        ws.cell(row + 1, 4, sym)
        row += 4
    ws.cell(row + 1, 4, "<SCAT>")
    for i, (cnt, pay) in enumerate(((5, 100), (4, 10), (3, 2))):
        ws.cell(row + i, 6, cnt)
        ws.cell(row + i, 8, pay)
    ws.cell(row + 3, 4, "pay any")
    return wb


def test_builtins_are_listed_and_read_only():
    rows = ct.list_templates()
    assert [r["id"] for r in rows if r["builtin"]] == OFFERED
    for tid in BUILTINS + ["blueprint_1"]:
        assert ct.get_template(tid)["builtin"] is True
        with pytest.raises(ValueError):
            ct.delete_user(tid)


def test_save_copy_never_overwrites_a_builtin():
    t = ct.get_template("classic_cards")
    t["styles"]["card"]["radius"] = 30
    with pytest.raises(ValueError):
        ct.save_copy(t, ct.get_template("blueprint_1")["name"])     # a built-in's name
    tid = ct.save_copy(t, "My red cards")
    mine = ct.get_template(tid)
    assert mine["builtin"] is False and mine["styles"]["card"]["radius"] == 30 and mine["based_on"] == "classic_cards"
    assert ct.get_template("classic_cards")["styles"]["card"]["radius"] == 12     # original untouched
    assert tid in [r["id"] for r in ct.list_templates() if not r["builtin"]]
    ct.delete_user(tid)
    assert ct.get_template(tid) is None


def test_compile_builds_cards_features_and_pins(tmp_path):
    wb = _sheet()
    structure = {"top": 2, "lower": 2, "block_keys": ["pic1", "pic2", "ace", "king", "scatter", "scat", "payany"]}
    doc, maps = ct.compile_template(ct.get_template("classic_cards"), structure, wb.active,
                                    {"rules_cells": ["H4", "H5"]})
    slots = doc["slots"]
    assert doc["page_type"] == "paytable" and doc["mapper_meta"]["layout"] == "cards"
    for name in ("pic1", "pic2", "ace", "king"):
        assert {f"@slot.{name}", f"@slot.{name}.pay", f"@slot.{name}.value", f"@slot.{name}.card"} <= set(slots)
        assert maps[f"@slot.{name}.card"]["shape"]["radius"] == 12
    assert "@slot.scat" in slots and "@slot.scatter" not in slots and "@slot.payany" not in slots
    # the WILD is only named in the rules (no pays of its own): no WILD box, its line stays in the rules text
    assert "@slot.wild" not in slots and "@slot.wildbox" not in slots
    assert maps["@slot.scatbox.tab"]["text"] == "SCATTER"
    # the Excel's lines join into one paragraph that wraps to its box (a wider box: fewer lines)
    assert maps["@slot.text"]["text"] == "All wins begin with leftmost reel. <WILD BASE> substitute for all symbols except <SCAT>."
    # cards of a band share a row and never overlap
    a, b = slots["@slot.pic1.card"], slots["@slot.pic2.card"]
    assert a["y"] == b["y"] and a["x"] + a["w"] <= b["x"]
    merged = {m["slot"]: m for m in ct.merge_mappings(
        [{"slot": "@slot.scatbox.tab", "mode": "icon", "token": "<scatbox.tab>"},
         {"slot": "@slot.text", "mode": "excel", "source": "H4,H5"}], maps, "C:/x.xlsx")}
    assert merged["@slot.text"]["mode"] == "text" and merged["@slot.text"]["pinned_excel"] == "C:/x.xlsx"
    assert merged["@slot.scatbox.tab"]["mode"] == "text" and merged["@slot.scatbox.tab"]["source_pinned"]


def test_plain_and_compact_grid_templates():
    structure = {"top": 2, "lower": 2, "block_keys": ["pic1", "pic2", "ace", "king"]}
    doc, maps = ct.compile_template(ct.get_template("plain"), structure, None)
    assert not any(k.endswith(".card") for k in doc["slots"])                  # no boxes at all
    doc, _ = ct.compile_template(ct.get_template("compact_grid"), structure, None)
    y = lambda n: doc["slots"][f"@slot.{n}.card"]["y"]
    assert y("pic1") == y("pic2") and y("ace") == y("king") and y("ace") > y("pic1")   # always two rows, split at ACE


def test_scatter_gets_a_box_and_a_paying_wild_is_a_card_of_its_row():
    # the SCATTER always gets a box of its own; a paying WILD is a card like the others in every design, in
    # its row at its row's size (2026-10-30: "make the wild card same as our normal card … not so wide") —
    # no WILD box, and its rules sentence stays in the rules text
    structure = {"top": 2, "lower": 3, "block_keys": ["pic1", "pic2", "ace", "king", "wild", "scat"]}
    for tid in ("plain", "side_panel", "compact_grid"):
        doc, maps = ct.compile_template(ct.get_template(tid), structure, _sheet().active, {"rules_cells": ["H4", "H5"]})
        slots, meta = doc["slots"], doc["mapper_meta"]
        assert meta["top_count"] == 2, tid
        assert "@slot.scat.card" not in slots and "@slot.scatbox" in slots, tid
        assert {"@slot.scat.pay", "@slot.scat.value", "@slot.wild.pay", "@slot.wild.value"} <= set(slots), tid
        assert "@slot.wildbox" not in slots and "@slot.wildbox.text" not in slots, tid
        assert "@slot.wild" in slots and meta["lower_count"] == 3 and not meta.get("auto_free"), tid
        assert slots["@slot.wild"]["w"] == slots["@slot.ace"]["w"], tid                 # sized like its row's cards
        assert "wild" not in meta["required_boxes"], tid
        assert "substitute" in maps["@slot.text"]["text"], tid                         # the sentence: rules text
    # "Join row": in its row again (card_overrides.wild.in_row)
    t = ct.get_template("plain")
    t["card_overrides"] = {"wild": {"in_row": True}}
    doc, _ = ct.compile_template(t, structure, _sheet().active, {"rules_cells": ["H4", "H5"]})
    assert not doc["mapper_meta"].get("auto_free") and "wild" not in doc["mapper_meta"]["free_cards"]
    assert doc["mapper_meta"]["lower_count"] == 3                          # ace, king, wild
    for tid in ("plain", "side_panel", "compact_grid"):
        doc, maps = ct.compile_template(ct.get_template(tid), structure, _sheet().active, {"rules_cells": ["H4", "H5"]})
        slots = doc["slots"]
        box = slots["@slot.scatbox"]
        for k in ("@slot.ace.card", "@slot.king.card"):
            c = slots.get(k)
            assert not c or c["y"] + c["h"] <= box["y"] or c["y"] >= box["y"] + box["h"] or \
                c["x"] + c["w"] <= box["x"] or c["x"] >= box["x"] + box["w"], (tid, k)
    # a moved box stays where the artist put it
    t = ct.get_template("plain")
    t.setdefault("features", {})["scatter_box"] = {"rect": [100, 120, 400, 180]}
    doc, _ = ct.compile_template(t, structure, None)
    assert doc["slots"]["@slot.scatbox"] == {"x": 100, "y": 120, "w": 400, "h": 180}


def test_a_placed_row_stays_where_it_was_put_even_over_the_rules_panel():
    # the side-panel design placed for 4 royals (A K Q J) meets a sheet with 5 (A K Q J 10)
    t = ct.get_template("side_panel")
    t["page"]["texts"] = [{"id": "notes", "rect": [1398, 164, 448, 785], "locked": True}]   # 🔒: the cards fit beside it
    t["bands"][0].update(card_w=242, card_h=354, pos=[70, 146])
    t["bands"][1].update(card_w=287, card_h=298, pos=[117, 521], gap_x=8)
    structure = {"top": 4, "lower": 5, "block_keys": ["pic1", "pic2", "pic3", "pic4", "ace", "king", "queen", "jack", "ten"]}
    doc, _ = ct.compile_template(t, structure, None, {"canvas": (1920, 1080)})
    s = doc["slots"]
    assert "@slot.ten.card" in s                                                        # free: it may run over the panel
    assert s["@slot.ace.card"]["x"] == 117 and s["@slot.ace.card"]["y"] == 521          # where it was put
    assert s["@slot.pic1.card"]["w"] == 242                                             # the top row untouched
    # a sheet with 4 royals keeps the designed size
    structure = {"top": 4, "lower": 4, "block_keys": ["pic1", "pic2", "pic3", "pic4", "ace", "king", "queen", "jack"]}
    doc, _ = ct.compile_template(t, structure, None, {"canvas": (1920, 1080)})
    assert doc["slots"]["@slot.ace.card"]["w"] == 287


def test_a_text_box_left_empty_on_this_sheet_draws_no_panel():
    # the design split its rules over two boxes for another game; this sheet's text is different,
    # so it all starts in the first box — the second draws no empty panel and blocks nothing
    t = ct.get_template("plain")
    t["styles"]["textbg_a"] = {"fill": "#400000", "opacity": 1.0, "radius": 8}
    t["styles"]["textbg_b"] = {"fill": "#400000", "opacity": 1.0, "radius": 8}
    t["page"]["texts"] = [{"id": "a", "rect": [1400, 160, 440, 600], "bg": {"on": True, "style": "textbg_a"}},
                          {"id": "b", "rect": [220, 840, 950, 120], "bg": {"on": True, "style": "textbg_b"}}]
    t["page"]["text_edits"] = {"0123456789ab": {"a": "Other game's text", "b": "more"}}
    structure = {"top": 2, "lower": 2, "block_keys": ["pic1", "pic2", "ace", "king"]}
    doc, maps = ct.compile_template(t, structure, _sheet().active, {"rules_cells": ["H4", "H5"]})
    assert "@slot.textbg.a" in doc["slots"] and "@slot.textbg.b" not in doc["slots"]
    assert maps["@slot.text"]["text"].startswith("All wins begin")


def test_card_boxes_render_rounded_and_become_live_shapes():
    from PIL import Image

    from ps_autotypesetter import paytable_box
    from ps_autotypesetter.psd_writer import recorder

    m = {"shape": {"radius": 20, "fill": "#3D0000", "stroke": {"enabled": True, "width": 4, "color": "#E8B400"}}}
    img = Image.new("RGBA", (300, 200), (0, 0, 0, 0))
    assert paytable_box.draw(img, m, 50, 50, 200, 100)
    assert img.getpixel((51, 51))[3] == 0                 # rounded corner stays empty
    assert img.getpixel((150, 100))[:3] == (0x3D, 0, 0)   # fill
    rec = recorder.LayerRecorder()
    page = Image.new("RGBA", (300, 200))
    with rec.recording():
        rec.register_page(page, page.copy())
        paytable_box.draw(page, m, 50, 50, 200, 100, label="pic1", group="pic1")
    shape = rec.page_for(page).shapes[0]
    assert shape.vector["radius"] == 20 and shape.name == "pic1 box" and shape.group == "pic1"


REF = os.path.join(os.path.dirname(__file__), "..", "ExcelFileForReference", "ThunderEmpire_MongolianEmpress_AGR_HHRE.xlsx")


@pytest.mark.skipif(not os.path.isfile(REF), reason="reference workbook not available")
def test_mongolian_sheet_compiles_like_the_artist_layout():
    from openpyxl import load_workbook

    from ps_autotypesetter.ui_web import engine_api

    sheet = "Paytable-100-50-25lines"
    st = engine_api.paytable_sheet_structure(REF, sheet)
    doc, maps = ct.compile_template(ct.get_template("classic_cards"), st, load_workbook(REF, data_only=True)[sheet])
    cards = sorted(k[len("@slot."):-len(".card")] for k in doc["slots"] if k.endswith(".card"))
    assert cards == sorted(["pic1", "pic2", "pic3", "pic4", "ace", "king", "queen", "jack", "ten"])
    assert "@slot.wildbox" not in doc["slots"] and "@slot.scatbox" in doc["slots"]   # its <SUNSET> wild has no pays


def _sheet_with_wild():
    """_sheet() plus a WILD with pays of its own: a real WILD card of the AGR."""
    wb = _sheet()
    ws = wb.active
    for i, (cnt, pay) in enumerate(((5, 500), (4, 100), (3, 20))):
        ws.cell(40 + i, 6, cnt)
        ws.cell(40 + i, 8, pay)
    ws.cell(41, 4, "<WILD>")
    return wb


WILD_KEYS = {"top": 3, "lower": 2, "block_keys": ["pic1", "pic2", "wild", "ace", "king", "scatter", "scat", "payany"]}


def test_free_layout_cards_fill_the_space_left():
    structure = {"top": 2, "lower": 2, "block_keys": ["pic1", "pic2", "ace", "king"]}
    t = ct.get_template("classic_cards")
    ctx = {"canvas": (1920, 1080), "heading_top": 150, "heading_size": 60, "rules_cells": []}
    doc, _ = ct.compile_template(t, structure, None, ctx)
    b = doc["mapper_meta"]["blocks"]
    assert b["title"][1] == 150 - 10                     # where every page heading sits (minus the plate padding)
    assert "title" not in [k for k in b if k == "cards"] and b["cards"][1] > b["title"][3]
    # a text box on the left: the cards move right of it, nothing overlaps
    t["page"]["texts"] = [{"id": "notes", "rect": [80, 300, 400, 500], "rest": True, "locked": True}]
    doc, _ = ct.compile_template(t, structure, None, ctx)
    b = doc["mapper_meta"]["blocks"]
    assert b["cards"][0] >= b["text:notes"][2]
    for k in ("pic1", "pic2", "ace", "king"):
        c = doc["slots"][f"@slot.{k}.card"]
        assert c["x"] >= b["text:notes"][2]
    # a design's WILD box: none any more — the WILD is a card of its row
    t["features"]["enabled"] = True
    t["features"]["wild_box"] = {"rect": [1400, 300, 400, 300]}
    doc, _ = ct.compile_template(t, WILD_KEYS, _sheet_with_wild().active, ctx)
    assert "@slot.wildbox" not in doc["slots"] and "@slot.wild.card" in doc["slots"]


def test_strip_tokens_keeps_sentences_whole():
    line = "<WILD BASE> substitute for all symbols except <SCAT>, <COR> and <OVERLAY>."
    assert ct.strip_tokens(line, ["<COR>"]) == "<WILD BASE> substitute for all symbols except <SCAT> and <OVERLAY>."
    assert ct.strip_tokens(line, ["<OVERLAY>"]) == "<WILD BASE> substitute for all symbols except <SCAT> and <COR>."
    assert ct.strip_tokens(line, ["<SCAT>"]) == "<WILD BASE> substitute for all symbols except <COR> and <OVERLAY>."


def test_overflow_is_measured_and_cards_can_grow():
    structure = {"top": 1, "lower": 0, "block_keys": ["pic1"]}
    t = ct.get_template("plain")
    t["bands"][0]["card_w"] = 300                          # a small card
    doc, maps = ct.compile_template(t, structure, None, {"canvas": (1920, 1080)})
    m = [{"slot": "@slot.pic1.value", "text": "\n".join(["1500000", "2500000", "3500000"]), "font_size": 30}]
    over = ct.measure_overflow(doc, m, "ArialMT", 1.0)
    assert over and over[0]["part"] == "pays" and over[0]["ratio"] > 1
    bigger = ct.grown(t, over)
    assert bigger["bands"][0]["card_h"] > t["bands"][0]["card_h"]
    ct.shrink_slots(m, over)
    assert m[0]["shrink_to_fit"] is True


def test_locked_cards_keep_their_place():
    structure = {"top": 2, "lower": 2, "block_keys": ["pic1", "pic2", "ace", "king"]}
    t = ct.get_template("classic_cards")
    t["page"]["texts"] = [{"id": "notes", "rect": [80, 900, 1760, 120], "rest": True}]
    doc, _ = ct.compile_template(t, structure, None, {"canvas": (1920, 1080)})
    area = doc["mapper_meta"]["blocks"]["cards_area"]
    t["page"]["cards_lock"] = [area[0], area[1], area[2] - area[0], area[3] - area[1]]
    before = doc["slots"]["@slot.pic1.card"]
    t["page"]["texts"][0]["rect"] = [80, 400, 600, 300]   # a text box moved right into them
    doc, _ = ct.compile_template(t, structure, None, {"canvas": (1920, 1080)})
    assert doc["slots"]["@slot.pic1.card"] == before


def test_text_edits_follow_the_excel_text():
    wb = _sheet()
    structure = {"top": 2, "lower": 2, "block_keys": ["pic1", "pic2", "ace", "king"]}
    t = ct.get_template("plain")
    t["page"]["texts"] = [{"id": "notes", "rect": [80, 900, 1760, 120]}, {"id": "side", "rect": [1500, 300, 340, 200]}]
    ctx = {"rules_cells": ["H4", "H5"]}
    doc, maps = ct.compile_template(t, structure, wb.active, ctx)
    info = doc["mapper_meta"]["text_info"]
    assert maps["@slot.text"]["text"] == ct.flow_lines(info["full"]) and maps["@slot.rules.side"]["text"] == ""
    # the artist breaks a line and moves a selection into the side box
    edited = "\n".join(["All wins begin", "with leftmost reel."])
    t["page"]["text_edits"] = {info["hash"]: {"notes": edited, "side": "<WILD BASE> substitute"}}
    doc, maps = ct.compile_template(t, structure, wb.active, ctx)
    assert maps["@slot.text"]["text"] == ct.flow_lines(edited)
    assert maps["@slot.rules.side"]["text"] == "<WILD BASE> substitute"
    # another market's Excel says something else: its own text, never edits made for other words
    wb.active["H4"] = "All wins pay left to right."
    doc, maps = ct.compile_template(t, structure, wb.active, ctx)
    assert maps["@slot.text"]["text"].startswith("All wins pay left to right.")
    assert doc["mapper_meta"]["text_info"]["other_edits"] is True



def test_cards_move_as_one_grid_and_stay_on_the_page():
    structure = {"top": 2, "lower": 2, "block_keys": ["pic1", "pic2", "ace", "king"]}
    t = ct.get_template("classic_cards")
    doc, _ = ct.compile_template(t, structure, None, {"canvas": (1920, 1080)})
    s0, b0 = doc["slots"], doc["mapper_meta"]["blocks"]
    t["page"]["cards_offset"] = [40, -25]
    doc, _ = ct.compile_template(t, structure, None, {"canvas": (1920, 1080)})
    s1, b1 = doc["slots"], doc["mapper_meta"]["blocks"]
    for k in ("@slot.pic1.card", "@slot.pic1", "@slot.ace.pay", "@slot.king.value"):
        assert (s1[k]["x"] - s0[k]["x"], s1[k]["y"] - s0[k]["y"]) == (40, -25), k
    assert b1["cards"][0] == b0["cards"][0] + 40 and b1["card:ace"][1] == b0["card:ace"][1] - 25
    t["page"]["cards_offset"] = [5000, 5000]                 # dragged off the page: kept on it
    doc, _ = ct.compile_template(t, structure, None, {"canvas": (1920, 1080)})
    c = doc["mapper_meta"]["blocks"]["cards"]
    assert c[2] <= 1920.5 and c[3] <= 1080.5


def test_symbol_size_per_symbol_and_for_all():
    structure = {"top": 2, "lower": 2, "block_keys": ["pic1", "pic2", "ace", "king"]}
    t = ct.get_template("classic_cards")
    doc, _ = ct.compile_template(t, structure, None, {"canvas": (1920, 1080)})
    base = {k: doc["slots"][f"@slot.{k}"] for k in ("pic1", "pic2", "ace")}
    t["card"]["symbol_size"] = {"*": 50, "pic1": 150}
    doc, _ = ct.compile_template(t, structure, None, {"canvas": (1920, 1080)})
    p1, p2 = doc["slots"]["@slot.pic1"], doc["slots"]["@slot.pic2"]
    assert abs(p1["w"] - base["pic1"]["w"] * 1.5) <= 1 and abs(p2["w"] - base["pic2"]["w"] * 0.5) <= 1
    # grown about its centre, the card itself untouched
    cx = lambda b: b["x"] + b["w"] / 2
    assert abs(cx(p1) - cx(base["pic1"])) <= 1
    assert doc["slots"]["@slot.ace"]["w"] < base["ace"]["w"]


def test_numbers_style_reaches_the_slots():
    structure = {"top": 2, "lower": 2, "block_keys": ["pic1", "pic2", "ace", "king"]}
    t = ct.get_template("classic_cards")
    for p in t["card"]["parts"]:
        if p["role"] in ("counts", "pays"):
            p.update(line_height=44, bold=True, italic=True, font="Arial")
    _doc, maps = ct.compile_template(t, structure, None, {"canvas": (1920, 1080)})
    m = maps["@slot.pic1.value"]
    assert m["line_height"] == 44 and m["bold"] and m["italic"] and m["font_name"] == "Arial"


def test_a_placed_text_box_stays_where_it_is_put_and_moves_nothing():
    structure = {"top": 2, "lower": 2, "block_keys": ["pic1", "pic2", "ace", "king"]}
    t = ct.get_template("classic_cards")
    t["page"]["texts"] = [{"id": "notes", "rect": [80, 900, 1760, 120]}]
    doc, _ = ct.compile_template(t, structure, None, {"canvas": (1920, 1080)})
    cards = doc["mapper_meta"]["blocks"]["cards"]
    t["page"]["cards_offset"] = [0, 900 - cards[1] - 20]          # cards dropped onto the text
    doc, _ = ct.compile_template(t, structure, None, {"canvas": (1920, 1080)})
    b = doc["mapper_meta"]["blocks"]
    assert b["text:notes"][1] == 900                                  # it stays: the cards may overlap it
    moved = dict(t["page"]["texts"][0], rect=[300, 200, 600, 300])     # moved onto the cards: they don't make way
    t["page"]["texts"] = [moved]
    t["page"].pop("cards_offset")
    doc2, _ = ct.compile_template(t, structure, None, {"canvas": (1920, 1080)})
    assert list(doc2["mapper_meta"]["blocks"]["text:notes"][:2]) == [300, 200]
    assert doc2["mapper_meta"]["blocks"]["cards"] == ct.compile_template(
        dict(t, page=dict(t["page"], texts=[dict(moved, rect=[300, 950, 600, 100])])), structure, None, {"canvas": (1920, 1080)})[0]["mapper_meta"]["blocks"]["cards"]


def test_wider_cards_grow_their_box_instead_of_being_capped():
    structure = {"top": 2, "lower": 2, "block_keys": ["pic1", "pic2", "ace", "king"]}
    t = ct.get_template("classic_cards")
    t["page"]["texts"] = [{"id": "notes", "rect": [1500, 300, 400, 300], "locked": True}]   # squeezes the free area
    doc, _ = ct.compile_template(t, structure, None, {"canvas": (1920, 1080)})
    w0 = doc["slots"]["@slot.pic1.card"]["w"]
    # without the text box in the way, a wider card keeps its width: the cards' box grows
    t["page"]["texts"] = [{"id": "notes", "rect": [60, 940, 1800, 100]}]
    doc, _ = ct.compile_template(t, structure, None, {"canvas": (1920, 1080)})
    area0 = doc["mapper_meta"]["blocks"]["cards_area"]
    for b in t["bands"]:
        b["card_w"] = w0 + 100
    t["page"]["texts"] = [{"id": "notes", "rect": [1500, 300, 400, 300], "locked": True}]
    area0 = ct.compile_template(t, structure, None, {"canvas": (1920, 1080)})[0]["mapper_meta"]["blocks"]["cards_area"]
    t["page"]["texts"] = [{"id": "notes", "rect": [60, 940, 1800, 100]}]
    doc, _ = ct.compile_template(t, structure, None, {"canvas": (1920, 1080)})
    assert doc["slots"]["@slot.pic1.card"]["w"] == w0 + 100                    # not capped by the old box
    area1 = doc["mapper_meta"]["blocks"]["cards_area"]
    assert area1[2] - area1[0] > area0[2] - area0[0]
    assert area1[0] >= 0 and area1[2] <= 1920
    # a text box that can't step aside: the wider cards stop before it, never under it
    t["page"]["texts"] = [{"id": "notes", "rect": [1500, 300, 400, 300], "locked": True}]
    for b in t["bands"]:
        b["card_w"] = w0 + 100
    doc, _ = ct.compile_template(t, structure, None, {"canvas": (1920, 1080)})
    for k, s in doc["slots"].items():
        if k.endswith(".card"):
            assert s["x"] + s["w"] <= 1500 or s["y"] + s["h"] <= 300 or s["y"] >= 600, k


def test_top_and_bottom_cards_have_their_own_parts():
    structure = {"top": 2, "lower": 2, "block_keys": ["pic1", "pic2", "ace", "king"]}
    t = ct.get_template("classic_cards")
    doc, _ = ct.compile_template(t, structure, None, {"canvas": (1920, 1080)})
    low0 = doc["slots"]["@slot.ace"]
    parts = [dict(p) for p in t["card"]["parts"]]
    for p in parts:
        if p["role"] == "symbol":
            p["x"] += 0.1
    t["bands"][0]["parts"] = parts                       # only the top cards' symbol moves
    doc, _ = ct.compile_template(t, structure, None, {"canvas": (1920, 1080)})
    assert doc["slots"]["@slot.ace"] == low0
    geo = doc["mapper_meta"]["band_geo"]
    assert set(geo) == {"high", "low"} and geo["high"]["parts"][0]["role"] == "symbol"


def test_card_keeps_its_size_whatever_is_inside():
    parts = [{"role": "symbol", "x": 0.0, "y": 0.0, "w": 2.0, "h": 2.0}]       # 200x200 in a 100x100 card
    out, w, h = ct.fit_card(parts, 100.0, 100.0)
    assert (w, h) == (100.0, 100.0) and out[0]["w"] == 2.0                    # it reaches past the edge
    parts = [{"role": "symbol", "x": -0.5, "y": 0.2, "w": 0.5, "h": 0.5}]     # dragged off the left edge
    out, w, h = ct.fit_card(parts, 100.0, 100.0)
    assert (w, h) == (100.0, 100.0) and out[0]["x"] == -0.5


def test_locked_box_never_grows_content_scales_inside():
    structure = {"top": 2, "lower": 2, "block_keys": ["pic1", "pic2", "ace", "king"]}
    t = ct.get_template("classic_cards")
    doc, _ = ct.compile_template(t, structure, None, {"canvas": (1920, 1080)})
    a = doc["mapper_meta"]["blocks"]["cards_area"]
    a = (a[0], a[1], a[0] + (a[2] - a[0]) / 2, a[1] + (a[3] - a[1]) / 2)   # a small locked box
    t["page"]["cards_lock"] = [a[0], a[1], a[2] - a[0], a[3] - a[1]]
    parts = [dict(p) for p in t["card"]["parts"]]
    for p in parts:
        if p["role"] == "symbol":
            p["w"], p["h"] = p["w"] * 3, p["h"] * 3                  # a much bigger symbol
    t["bands"][0]["parts"] = parts
    doc, _ = ct.compile_template(t, structure, None, {"canvas": (1920, 1080)})
    b = doc["mapper_meta"]["blocks"]
    assert [round(v) for v in b["cards_area"]] == [round(v) for v in a]
    c = b["cards"]
    assert c[0] >= a[0] - 0.5 and c[1] >= a[1] - 0.5 and c[2] <= a[2] + 0.5 and c[3] <= a[3] + 0.5
    t["page"].pop("cards_lock")                                       # unlocked: the box grows instead
    doc, _ = ct.compile_template(t, structure, None, {"canvas": (1920, 1080)})
    a2 = doc["mapper_meta"]["blocks"]["cards_area"]
    assert (a2[3] - a2[1]) > (a[3] - a[1]) or (a2[2] - a2[0]) > (a[2] - a[0])


def test_unlocked_box_stays_where_it_was_locked_and_grows_from_there():
    structure = {"top": 2, "lower": 2, "block_keys": ["pic1", "pic2", "ace", "king"]}
    t = ct.get_template("classic_cards")
    for b in t["bands"]:
        b["card_w"], b["card_h"] = 300, 140
    t["page"]["cards_at"] = [400, 300]
    doc, _ = ct.compile_template(t, structure, None, {"canvas": (1920, 1080)})
    c = doc["mapper_meta"]["blocks"]["cards"]
    assert abs(c[0] - 400) < 1 and abs(c[1] - 300) < 1
    for b in t["bands"]:
        b["card_w"] = 400                                  # bigger cards: same corner, wider box
    doc, _ = ct.compile_template(t, structure, None, {"canvas": (1920, 1080)})
    c2 = doc["mapper_meta"]["blocks"]["cards"]
    assert abs(c2[0] - 400) < 1 and c2[2] - c2[0] > c[2] - c[0]


def test_one_card_edited_alone_leaves_the_others():
    structure = {"top": 2, "lower": 2, "block_keys": ["pic1", "pic2", "ace", "king"]}
    t = ct.get_template("classic_cards")
    doc, _ = ct.compile_template(t, structure, None, {"canvas": (1920, 1080)})
    before = {k: dict(v) for k, v in doc["slots"].items()}
    parts = [dict(p) for p in t["card"]["parts"]]
    for p in parts:
        if p["role"] == "symbol":
            p["w"], p["h"] = p["w"] * 1.5, p["h"] * 1.5
    t["card_overrides"] = {"pic1": {"parts": parts}}
    doc, _ = ct.compile_template(t, structure, None, {"canvas": (1920, 1080)})
    assert doc["slots"]["@slot.pic1"]["w"] > before["@slot.pic1"]["w"]
    for k in ("@slot.pic2", "@slot.ace", "@slot.pic1.card", "@slot.pic2.card"):
        assert doc["slots"][k] == before[k], k                     # nothing else moves or resizes
    assert "pic1" in doc["mapper_meta"]["card_geo"]


def test_text_boxes_keep_their_icon_tokens_for_the_renderer():
    from ps_autotypesetter.ui_web import ps_actions as pa

    wb = _sheet()
    wb.active["H4"] = "<WILD> appears on reels 2,3,4 and 5 only."
    structure = {"top": 2, "lower": 2, "block_keys": ["pic1", "pic2", "ace", "king"]}
    t = ct.get_template("plain")
    _doc, maps = ct.compile_template(t, structure, wb.active, {"rules_cells": ["H4"]})
    m = maps["@slot.text"]
    assert m.get("inline_icons") is True
    assert pa._mapping_preview_text(m, None).startswith("<WILD> appears")       # drawn as an icon, not dropped
    assert "<" not in pa._mapping_preview_text({"mode": "text", "text": "<WILD> x"}, None)   # plain text slots unchanged


def test_text_box_can_leave_chosen_icons_out():
    wb = _sheet()
    wb.active["H4"] = "<WILD> substitutes for all symbols except <purple_scat>, <red_scat> and <green_scat>."
    structure = {"top": 2, "lower": 2, "block_keys": ["pic1", "pic2", "ace", "king"]}
    t = ct.get_template("plain")
    t["page"]["texts"] = [{"id": "notes", "rect": [80, 900, 1760, 120], "hide_icons": ["<red_scat>"]}]
    doc, maps = ct.compile_template(t, structure, wb.active, {"rules_cells": ["H4"]})
    assert maps["@slot.text"]["text"] == "<WILD> substitutes for all symbols except <purple_scat> and <green_scat>."
    meta = doc["mapper_meta"]["texts"][0]
    assert "<red_scat>" in meta["tokens"] and meta["hidden"] == ["<red_scat>"]
    assert "<red_scat>" in meta["text"]                                  # the editor keeps the full text


def test_an_icon_with_no_picture_shows_its_token():
    from PIL import ImageFont
    from ps_autotypesetter.ui_web import ps_actions as pa

    font = ImageFont.load_default()
    lines = pa._wrap_preview_inline("<NO_SUCH_ICON> appears", font, 800, 30, "", {})
    words = [it.get("val") for ln in lines for it in ln]
    assert "<NO_SUCH_ICON>" in words


BUFFALO = os.path.join(os.path.dirname(__file__), "..", "ExcelFileForReference", "CE_Legend_Buffalo_GameRules_NYL.xlsm")


def test_scatter_section_is_read_from_the_sheet():
    import pytest
    if not os.path.isfile(BUFFALO):
        pytest.skip("reference workbook not present")
    from openpyxl import load_workbook

    from ps_autotypesetter.ui_web import engine_api

    st = engine_api.paytable_sheet_structure(BUFFALO, "PAYTABLE")
    ws = load_workbook(BUFFALO, data_only=True)["PAYTABLE"]
    sec = ct.find_pay_section(ws, ct._clean_keys(st["block_keys"])[0])
    assert [c["token"] for c in sec["cards"]] == ["<BUFFALO BG SCATTER>", "<BUFFALO FG SCATTER>"]
    assert sec["cards"][1]["counts"] == "L65,L66,L67" and sec["cards"][1]["pays"] == "N65,N66,N67"
    assert sec["title"][1] == "Scatter" and sec["caption"][1] == "pays in any position."
    assert sec["notes"] == ["C71", "C72"]
    rules = ["B5", "B7", "B9", "B11", "C69", "C71", "C72"]
    doc, maps = ct.compile_template(ct.get_template("rules_top_scatter"), st, ws, {"rules_cells": rules})
    cards = [k[len("card:"):] for k in doc["mapper_meta"]["blocks"] if k.startswith("card:")]
    assert len(cards) == 11 and "scatter" not in cards                     # 5 top + 6 bottom, no fake card
    assert maps["@slot.buffalofgscatter"]["token"] == "<BUFFALO FG SCATTER>"
    assert maps["@slot.buffalofgscatter.value"]["source"] == "N65,N66,N67"
    texts = {t["id"]: t["text"] for t in doc["mapper_meta"]["texts"]}
    assert texts["scatnotes"].startswith("<BUFFALO BG SCATTER> appears") and "pays in any" not in texts["notes"]
    assert "@slot.wild" not in doc["slots"]                                 # this design keeps the wild in the text
    doc, maps = ct.compile_template(ct.get_template("side_panel"), st, ws, {"rules_cells": rules})
    assert "@slot.wild" not in doc["slots"]                                 # <SUNSET> is only named, it has no pays


def test_the_scatter_section_moves_where_it_was_dragged():
    if not os.path.isfile(BUFFALO):
        pytest.skip("reference workbook not present")
    from openpyxl import load_workbook

    from ps_autotypesetter.ui_web import engine_api

    st = engine_api.paytable_sheet_structure(BUFFALO, "PAYTABLE")
    ws = load_workbook(BUFFALO, data_only=True)["PAYTABLE"]
    t = ct.get_template("rules_top_scatter")
    doc, _ = ct.compile_template(t, st, ws, {"rules_cells": []})
    before = doc["slots"]["@slot.scatsec"]
    t.setdefault("features", {})["scatter_box"] = {"rect": [1200, 300, 500, 200]}   # what the studio saves on a drag
    doc, _ = ct.compile_template(t, st, ws, {"rules_cells": []})
    after = doc["slots"]["@slot.scatsec"]
    assert after["x"] == 1200 and after["y"] != before["y"] and after["w"] == 500     # where and as big as dragged
    sec = doc["mapper_meta"]["blocks"]["scatter"]
    assert abs(sec[1] - (300 - float(t["features"].get("tab_h", 56) if (t["features"].get("tab") or {}).get("enabled", True) else 0) / 2)) < 1


@pytest.mark.skipif(not os.path.isfile(REF), reason="reference workbook not available")
def test_the_scatter_box_shows_the_agr_heading_and_caption():
    # ThunderEmpire: "Scatter" above <SCAT>, the pays beside it, "pay any" under it
    from openpyxl import load_workbook

    from ps_autotypesetter.ui_web import engine_api

    sheet = "Paytable-5lines"
    st = engine_api.paytable_sheet_structure(REF, sheet)
    ws = load_workbook(REF, data_only=True)[sheet]
    head, cap = ct._symbol_texts(ct._cells(ws), "scat", ct._clean_keys(st["block_keys"])[0])
    assert head == ("D51", "Scatter") and cap == ("D55", "pay any")
    # a design without a tab: the heading is a part of the box; with a tab, the tab says it
    doc, maps = ct.compile_template(ct.get_template("side_panel"), st, ws, {"rules_cells": ["D51", "D55", "B57"]})
    meta = doc["mapper_meta"]
    assert maps["@slot.scatbox.title"]["text"] == "Scatter" and maps["@slot.scatbox.label"]["text"] == "pay any"
    assert meta["auto_boxes"] == ["scatter"] and meta["required_boxes"] == ["scatter"]
    assert {"title", "label", "symbol", "counts", "pays"} <= set(meta["feature_parts"]["scatter"])
    rules = " ".join(t["text"] for t in meta["texts"])
    assert "pay any" not in rules and "Scatter" not in rules                   # not repeated in the rules text
    box = doc["slots"]["@slot.scatbox"]
    for k in ("@slot.scatbox.title", "@slot.scatbox.label", "@slot.scat"):
        s = doc["slots"][k]
        assert box["x"] <= s["x"] and s["x"] + s["w"] <= box["x"] + box["w"] + 1, k
    # styled like any text: the design's part keeps its look
    t = ct.get_template("side_panel")
    t["features"]["scatter_parts"] = dict(meta["feature_parts"]["scatter"],
                                         title=dict(meta["feature_parts"]["scatter"]["title"], color="#00FF00", bold=True))
    _doc, maps = ct.compile_template(t, st, ws, {"rules_cells": []})
    assert maps["@slot.scatbox.title"]["color"] == "#00FF00" and maps["@slot.scatbox.title"]["bold"] is True
    doc, maps = ct.compile_template(ct.get_template("classic_cards"), st, ws, {"rules_cells": []})
    assert maps["@slot.scatbox.tab"]["text"] == "Scatter" and "@slot.scatbox.title" not in doc["slots"]


def test_icon_sizes_in_text_page_wide_and_per_box():
    from ps_autotypesetter.ui_web import ps_actions as pa

    t = {"text_icon_scale": {"WILD": 150, "*": 120}}
    sc = ct.icon_scales(t, {"icon_scale": {"<WILD>": 200}})
    assert pa.icon_scale_for(sc, "<WILD>") == 2.0                           # this box's own size wins
    assert pa.icon_scale_for(ct.icon_scales(t), "<Wild>") == 1.5           # page-wide, any case
    assert pa.icon_scale_for(ct.icon_scales(t), "<purple_scat>") == 1.2    # "*": every other icon


def test_card_symbols_are_pinned_to_their_card():
    structure = {"top": 2, "lower": 2, "block_keys": ["pic1", "pic2", "ace", "king"]}
    _doc, maps = ct.compile_template(ct.get_template("classic_cards"), structure, None, {"canvas": (1920, 1080)})
    assert maps["@slot.pic2"]["symbol_pinned"] is True       # a big symbol never borrows the next card's symbol


def test_top_and_bottom_rows_are_separate_boxes():
    structure = {"top": 2, "lower": 6, "block_keys": ["pic1", "pic2", "ace", "king", "queen", "jack", "ten", "nine"]}
    t = ct.get_template("classic_cards")
    for b in t["bands"]:
        b["per_row"] = 8
    doc, _ = ct.compile_template(t, structure, None, {"canvas": (1920, 1080)})
    geo = doc["mapper_meta"]["band_geo"]
    assert geo["high"]["fit"] >= geo["low"]["fit"]               # a long bottom row never shrinks the top row
    top0 = doc["slots"]["@slot.pic1.card"]
    # the bottom row moved on its own: the top row stays exactly where it was
    t["bands"][1]["pos"] = [300, 700]
    doc, _ = ct.compile_template(t, structure, None, {"canvas": (1920, 1080)})
    b = doc["mapper_meta"]["blocks"]
    assert doc["slots"]["@slot.pic1.card"] == top0
    assert abs(b["low"][1] - 700) < 1
    # locked: the row keeps its size, its cards scale to fit inside
    t["bands"][1]["lock_size"] = [600, 150]
    doc, _ = ct.compile_template(t, structure, None, {"canvas": (1920, 1080)})
    low = doc["mapper_meta"]["blocks"]["low"]
    assert low[2] - low[0] <= 601 and low[3] - low[1] <= 151
    assert doc["slots"]["@slot.pic1.card"] == top0


def test_bottom_row_starts_at_ace():
    structure = {"top": 4, "lower": 3, "block_keys": ["pic1", "pic2", "pic3", "ace", "king", "queen", "jack"]}
    doc, _ = ct.compile_template(ct.get_template("classic_cards"), structure, None, {"canvas": (1920, 1080)})
    assert doc["mapper_meta"]["top_count"] == 3 and doc["mapper_meta"]["lower_count"] == 4


def test_numbers_are_never_cut_and_shrink_with_their_row():
    from PIL import ImageFont

    from ps_autotypesetter.ui_web import ps_actions as pa

    font = ImageFont.load_default()
    lines = pa._wrap_preview_inline("1500", font, 4, 30, "", {})              # a box far too narrow
    assert [it["val"] for ln in lines for it in ln] == ["1500"]               # printed in full, never "…"
    out, w, _h = ct.fit_card([{"role": "pays", "x": 0.6, "y": 0.1, "w": 0.05, "h": 0.8, "font_size": 30}],
                             200.0, 150.0, 3, pay_digits=4)
    assert out[0]["w"] * w >= 4 * 30 * 0.62                                   # wide enough for 4 digits
    assert ct._fitted({"font_size": 30, "line_height": 40}, 0.5) == {"font_size": 15.0, "line_height": 20.0}
    assert ct._fitted({"font_size": 30}, 1.0) == {"font_size": 30}


def test_single_letter_royals_make_one_card_each(tmp_path):
    from openpyxl import Workbook

    from ps_autotypesetter.ui_web import engine_api

    wb = Workbook()
    ws = wb.active
    ws.title = "Paytable"
    row = 11
    for sym in ("<PIC1>", "<PIC2>", "<A>", "<K>", "<Q>", "<10>"):
        for i, (cnt, pay) in enumerate(((5, 100), (4, 20), (3, 5))):
            ws.cell(row + i, 6, cnt)
            ws.cell(row + i, 8, pay)
        ws.cell(row + 1, 4, sym)
        row += 4
    path = os.path.join(str(tmp_path), "royals.xlsx")
    wb.save(path)
    keys = engine_api.paytable_sheet_structure(path, "Paytable")["block_keys"]
    assert len(keys) == 6 and keys.count("a") + keys.count("ace") == 1      # <A> is one card, not A and ACE
    doc, maps = ct.compile_template(ct.get_template("classic_cards"), engine_api.paytable_sheet_structure(path, "Paytable"),
                                    None, {"canvas": (1920, 1080)})
    assert maps["@slot.a"]["icon_aliases"] == ["ACE"]                          # cards find ACE.png for <A>
    assert maps["@slot.pic1"]["icon_aliases"] == []


def test_card_symbols_find_either_royal_spelling_but_text_does_not(tmp_path):
    from ps_autotypesetter.ui_web import ps_actions as pa

    folder = str(tmp_path)
    open(os.path.join(folder, "ACE.png"), "wb").close()
    from PIL import Image
    Image.new("RGBA", (4, 4)).save(os.path.join(folder, "ACE.png"))
    assert pa._mapping_preview_icon({"token": "<A>", "icon_aliases": ["ACE"]}, None, folder, {})["path"].endswith("ACE.png")
    assert pa._mapping_preview_icon({"token": "<A>"}, None, folder, {}) is None   # text icons keep exact names


def test_text_boxes_shrink_to_stay_in_their_box():
    structure = {"top": 2, "lower": 2, "block_keys": ["pic1", "pic2", "ace", "king"]}
    _doc, maps = ct.compile_template(ct.get_template("classic_cards"), structure, None, {"canvas": (1920, 1080)})
    assert maps["@slot.text"]["shrink_to_fit"] is True


def test_text_box_background_panel_or_strip():
    structure = {"top": 2, "lower": 2, "block_keys": ["pic1", "pic2", "ace", "king"]}
    t = ct.get_template("classic_cards")
    t["styles"]["textbg_notes"] = {"radius": 18, "fill_enabled": True, "fill": "#102040", "fill_opacity": 70,
                                   "stroke": {"enabled": True, "width": 3, "color": "#FFD23A", "align": "inside"}, "fx": ""}
    t["page"]["texts"] = [{"id": "notes", "rect": [200, 880, 1500, 150], "bg": {"on": True, "style": "textbg_notes", "pad": 10}}]
    doc, maps = ct.compile_template(t, structure, None, {"canvas": (1920, 1080)})
    assert doc["slots"]["@slot.textbg.notes"] == {"x": 190, "y": 870, "w": 1520, "h": 170}
    order = list(doc["slots"])
    assert order.index("@slot.textbg.notes") < order.index("@slot.text")         # drawn behind the text
    assert maps["@slot.textbg.notes"]["shape"]["stroke"]["enabled"] is True
    t["page"]["texts"][0]["bg"]["mode"] = "strip"
    doc, _ = ct.compile_template(t, structure, None, {"canvas": (1920, 1080)})
    s = doc["slots"]["@slot.textbg.notes"]
    assert s["x"] == 0 and s["w"] == 1920                                       # across the page
    t["page"]["texts"][0]["bg"]["on"] = False
    doc, _ = ct.compile_template(t, structure, None, {"canvas": (1920, 1080)})
    assert "@slot.textbg.notes" not in doc["slots"]


def test_text_box_font_bold_italic_and_layer_style_reach_the_renderer():
    structure = {"top": 2, "lower": 2, "block_keys": ["pic1", "pic2", "ace", "king"]}
    t = ct.get_template("classic_cards")
    t["page"]["texts"] = [{"id": "notes", "rect": [200, 880, 1500, 150], "font": "Impact", "bold": True,
                           "italic": True, "fx": "Heading style"}]
    _doc, maps = ct.compile_template(t, structure, None, {"canvas": (1920, 1080)})
    m = maps["@slot.text"]
    assert (m["font_name"], m["bold"], m["italic"], m["text_fx"]) == ("Impact", True, True, "Heading style")


def test_styled_text_is_drawn_a_run_at_a_time():
    from PIL import Image, ImageDraw, ImageFont

    from ps_autotypesetter.ui_web import ps_actions as pa
    from ps_autotypesetter import png_builder as pb

    calls = []
    real = pb._draw_text_visual
    pb._draw_text_visual = lambda *a, **k: calls.append(a[3])
    try:
        img = Image.new("RGBA", (400, 60))
        font = ImageFont.load_default()
        items = [{"type": "text", "val": w, "w": pb._advance(font, w)} for w in ("All", "wins", "begin")]
        pa._draw_preview_inline_line(ImageDraw.Draw(img), img, items, 0, 0, 400, (255, 255, 255), font, 30, 20,
                                     fx_config={"stroke_enabled": True})
    finally:
        pb._draw_text_visual = real
    assert calls == ["All wins begin"]                     # one run: no word's stroke covers the last one


def test_blank_lines_typed_in_a_text_box_are_kept():
    from PIL import ImageFont

    from ps_autotypesetter.ui_web import ps_actions as pa

    font = ImageFont.load_default()
    words = lambda lines: [[it["val"] for it in ln] for ln in lines]
    assert words(pa._wrap_preview_inline("One\n\nTwo", font, 800, 30, "", {}, keep_blank=True)) == [["One"], [], ["Two"]]
    assert words(pa._wrap_preview_inline("One\n\n\nTwo", font, 800, 30, "", {}, keep_blank=True)) == [["One"], [], [], ["Two"]]
    assert words(pa._wrap_preview_inline("One\nTwo", font, 800, 30, "", {}, keep_blank=True)) == [["One"], ["Two"]]
    assert words(pa._wrap_preview_inline("One\n\nTwo", font, 800, 30, "", {})) == [["One"], ["Two"]]   # pay ranges: unchanged


def test_inline_icons_report_where_they_landed():
    from PIL import Image, ImageDraw, ImageFont

    from ps_autotypesetter.ui_web import ps_actions as pa

    img = Image.new("RGBA", (400, 60))
    font = ImageFont.load_default()
    icon = Image.new("RGBA", (40, 20), (255, 0, 0, 255))
    items = [{"type": "text", "val": "Hi", "w": 20}, {"type": "icon", "val": "WILD", "w": 40, "img": icon, "h": 20}]
    out = []
    pa._draw_preview_inline_line(ImageDraw.Draw(img), img, items, 0, 10, 400, (255, 255, 255), font, 40, 20,
                                 align="left", icons_out=out)
    sp = max(1.0, __import__("ps_autotypesetter.png_builder", fromlist=["_advance"])._advance(font, " "))
    assert out == [{"tok": "WILD", "rect": [int(20 + sp), 20, int(20 + sp) + 40, 40]}]


def test_the_paytable_title_can_have_its_own_look():
    structure = {"top": 2, "lower": 2, "block_keys": ["pic1", "pic2", "ace", "king"]}
    plain_doc, plain_maps = ct.compile_template(ct.get_template("classic_cards"), structure, None)
    assert "title_own" not in plain_maps["@slot.title"]                     # the page heading's look by default
    t = ct.get_template("classic_cards")
    t.setdefault("page", {}).setdefault("title", {}).update(font="Impact", font_size=140, color="#ff0000", bold=False)
    doc, maps = ct.compile_template(t, structure, None)
    assert maps["@slot.title"]["title_own"] == {"font": "Impact", "font_size": 140, "color": "#ff0000", "bold": False}
    assert doc["slots"]["@slot.title"]["h"] > plain_doc["slots"]["@slot.title"]["h"]   # room for the bigger title


def test_the_paytable_title_moves_and_keeps_its_own_gap_to_the_cards():
    structure = {"top": 2, "lower": 2, "block_keys": ["pic1", "pic2", "ace", "king"]}
    base, _ = ct.compile_template(ct.get_template("classic_cards"), structure, None)
    t = ct.get_template("classic_cards")
    t.setdefault("page", {}).setdefault("title", {}).update(dx=40, dy=25, gap=100)
    moved, _ = ct.compile_template(t, structure, None)
    a, b = base["slots"]["@slot.title"], moved["slots"]["@slot.title"]
    assert (round(b["x"] - a["x"]), round(b["y"] - a["y"])) == (40, 25)
    card = lambda d: min(s["y"] for k, s in d["slots"].items() if k.endswith(".card"))
    assert card(moved) - (b["y"] + b["h"]) == pytest.approx(100, abs=1)


def test_the_fomo_mummy_design_is_the_default_a_paytable_starts_from():
    rows = ct.list_templates()
    assert rows[0]["id"] == "fomo_mummy" and rows[0]["default"] and rows[0]["builtin"]
    assert sum(1 for r in rows if r["default"]) == 1
    t = ct.get_template("fomo_mummy")
    assert t and t["kind"] == "card_template" and t["name"] == "FoMo Mummy Paytable"


def test_locking_one_row_never_moves_the_other():
    wb = _sheet()
    structure = {"top": 2, "lower": 2, "block_keys": ["pic1", "pic2", "ace", "king", "scatter", "scat", "payany"]}
    base = ct.get_template("classic_cards")

    def blocks(t):
        doc, _m = ct.compile_template(t, structure, wb.active, {"rules_cells": ["H4", "H5"]})
        return doc["mapper_meta"]["blocks"]

    b0 = blocks(base)
    for i, key in enumerate(("high", "low")):
        t = copy.deepcopy(base)
        r = b0[key]
        t["bands"][i].update(pos=[r[0], r[1]], lock_size=[r[2] - r[0], r[3] - r[1]], locked=True)
        b1 = blocks(t)
        for k in ("high", "low"):
            assert [round(v) for v in b1[k]] == [round(v) for v in b0[k]], (key, k)


def test_the_scatter_joins_a_row_as_a_card_and_goes_back_to_its_box():
    wb = _sheet()
    structure = {"top": 2, "lower": 2, "block_keys": ["pic1", "pic2", "ace", "king", "scatter", "scat", "payany"]}
    base = ct.get_template("classic_cards")
    doc, _m = ct.compile_template(base, structure, wb.active, {"rules_cells": ["H4", "H5"]})
    assert "scatter" in doc["mapper_meta"]["blocks"] and "card:scat" not in doc["mapper_meta"]["blocks"]
    t = copy.deepcopy(base)
    t["card_overrides"] = {"scat": {"in_row": "low"}}
    doc, maps = ct.compile_template(t, structure, wb.active, {"rules_cells": ["H4", "H5"]})
    bl = doc["mapper_meta"]["blocks"]
    assert "card:scat" in bl and "scatter" not in bl
    assert bl["card:scat"][1] >= bl["low"][1] - 1                     # in the bottom row
    assert doc["mapper_meta"]["joined"] == {"scat": "low"}


def test_a_caption_on_every_card_one_card_or_hidden_on_one():
    wb = _sheet()
    structure = {"top": 2, "lower": 2, "block_keys": ["pic1", "pic2", "ace", "king", "scatter", "scat", "payany"]}

    def caps(t):
        doc, maps = ct.compile_template(t, structure, wb.active, {"rules_cells": ["H4", "H5"]})
        return {s.split(".")[1]: maps[s]["text"] for s in doc["slots"] if s.endswith(".kind")}

    base = ct.get_template("classic_cards")
    assert caps(base) == {}
    t = copy.deepcopy(base)
    t.setdefault("card", {})["kind_caption"] = {"enabled": True, "on": "all", "text": "OF A KIND"}
    assert set(caps(t)) == {"pic1", "pic2", "ace", "king"}
    t["card_overrides"] = {"ace": {"caption": {"enabled": False}}, "king": {"caption": {"text": "PAYS ANY"}}}
    got = caps(t)
    assert "ace" not in got and got["king"] == "PAYS ANY" and got["pic1"] == "OF A KIND"
    one = copy.deepcopy(base)
    one["card_overrides"] = {"pic2": {"caption": {"enabled": True, "text": "MEGA"}}}
    assert caps(one) == {"pic2": "MEGA"}


def test_fruit_columns_dock_the_rows_and_put_wild_in_the_middle_only_when_the_sheet_has_it():
    # When the AGR actually has a WILD card ("wild" in block_keys) and SCATTER card ("scat"), both dock in the middle
    structure = {"top": 2, "lower": 3, "block_keys": ["pic1", "pic2", "ace", "king", "wild", "scatter", "scat", "payany"]}
    t = ct.get_template("fruit_columns")
    doc, _m = ct.compile_template(t, WILD_KEYS, _sheet_with_wild().active, {"rules_cells": ["H4", "H5"]})
    bl = doc["mapper_meta"]["blocks"]
    hi, lo = bl["high"], bl["low"]
    assert hi[2] < lo[0]                                      # a column on the left, one on the right
    assert "wild" not in bl and "card:wild" in bl              # the WILD: a card of its column, no box
    assert "scatter" in bl and hi[2] <= bl["scatter"][0] and bl["scatter"][2] <= lo[0]   # the SCATTER between them
    # A sheet that only mentions <WILD> in prose rules (H5) with NO wild/scatter cards in block_keys:
    # neither WILD nor SCATTER box is rendered, and the columns take the full page width
    doc2, _m2 = ct.compile_template(t, {"top": 2, "lower": 2, "block_keys": ["pic1", "pic2", "ace", "king"]}, _sheet().active, {"rules_cells": ["H4", "H5"]})
    bl2 = doc2["mapper_meta"]["blocks"]
    assert "wild" not in bl2 and "scatter" not in bl2
    assert "@slot.wildbox" not in doc2["slots"] and "@slot.wild" not in doc2["slots"]
    assert (bl2["high"][2] - bl2["high"][0]) > (hi[2] - hi[0]) + 50


def test_active_templates_never_render_wild_from_prose_and_have_high_card_area():
    # Even when the worksheet prose mentions <WILD BASE> and <SCAT> in H5, if the sheet has no wild/scat card block,
    # active templates must NEVER render a wild/scatter box or card, and cards must cover substantial area.
    wb = Workbook()
    ws = wb.active
    ws.title = "Paytable"
    ws["B2"] = "BASE GAMES PAYTABLE"
    ws["H4"] = "All wins begin with leftmost reel."
    ws["H5"] = "<WILD BASE> substitutes for all symbols except <SCAT>."
    ws["H6"] = "<WILD BASE> appears on reels 2, 3 and 4 only."
    row = 11
    for sym in ("<PIC1>", "<PIC2>", "<PIC3>", "<PIC4>", "<PIC5>", "ACE", "KING", "QUEEN", "JACK", "10"):
        for i, (cnt, pay) in enumerate(((5, 100), (4, 20), (3, 5))):
            ws.cell(row + i, 6, cnt)
            ws.cell(row + i, 8, pay)
        ws.cell(row + 1, 4, sym)
        row += 4
    st = {"top": 5, "lower": 5, "block_keys": ["pic1", "pic2", "pic3", "pic4", "pic5", "ace", "king", "queen", "jack", "ten"]}
    for tid in OFFERED:
        t = ct.get_template(tid)
        doc, maps = ct.compile_template(t, st, ws, {"canvas": (1920, 1080), "rules_cells": ["H4", "H5", "H6"]})
        slots = doc["slots"]
        assert "@slot.wildbox" not in slots and "@slot.wild" not in slots, tid
        assert "@slot.scatbox" not in slots and "@slot.scat" not in slots and "@slot.scatsec" not in slots, tid
        if tid != "fomo_mummy":
            blocks = doc["mapper_meta"]["blocks"]
            card_rects = [v for k, v in blocks.items() if k.startswith("card:")]
            area_pct = sum((c[2] - c[0]) * (c[3] - c[1]) for c in card_rects) / (1920.0 * 1080.0) * 100.0
            assert area_pct >= 32.0, f"{tid} card area too small: {area_pct:.1f}%"


def test_card_corners_round_cut_notch_step_draw_and_become_vector_paths():
    from ps_autotypesetter.psd_writer import shapes

    base = dict(left=10, top=10, width=200, height=120, fill="#0A1AFF", fill_opacity=100,
                stroke={"enabled": True, "width": 4, "color": "#FFC23A", "align": "inside"})
    assert len(shapes.blocks(dict(base, radius=20), 400, 300)) == 5          # all round: a live rounded rectangle
    for kind in ("cut", "notch", "step"):
        spec = dict(base, radius=24, corner=kind)
        img, left, top = shapes.render(spec)
        assert img.getpixel((img.width // 2, img.height // 2))[3] == 255       # filled inside
        assert img.getpixel((2, 2))[3] == 0                                   # the corner is cut away
        assert len(shapes.blocks(spec, 400, 300)) == 3                        # a vector path of its own
    leaf = dict(base, radii=[0, 40, 0, 40])
    img, _l, _t = shapes.render(leaf)
    assert img.getpixel((1, 1))[3] == 255 and img.getpixel((img.width - 2, 1))[3] == 0


def test_auto_size_text_fills_its_box_and_an_own_size_is_kept():
    structure = {"top": 2, "lower": 2, "block_keys": ["pic1", "pic2", "ace", "king"]}
    t = copy.deepcopy(ct.get_template("classic_cards"))
    t["page"]["texts"] = [{"id": "notes", "rect": [80, 700, 1700, 200]}]
    _doc, maps = ct.compile_template(t, structure, _sheet().active, {"rules_cells": ["H4", "H5"]})
    assert maps["@slot.text"].get("fit_box") and maps["@slot.text"].get("shrink_to_fit")    # Auto size: fills its box
    t["page"]["texts"][0].update(size_mode="own", font_size=30, font_size_set=True)
    _doc, maps = ct.compile_template(t, structure, _sheet().active, {"rules_cells": ["H4", "H5"]})
    assert not maps["@slot.text"].get("fit_box") and maps["@slot.text"]["font_size"] == 30  # its own size: kept


def test_gradient_fills_render_in_shapes_and_paytable_box():
    from PIL import Image
    from ps_autotypesetter import paytable_box as pb

    shape = {
        "radius": 16,
        "fill": "#FF0000",
        "fill_to": "#0000FF",
        "gradient_dir": "vertical",
        "fill_opacity": 100,
        "stroke": {"enabled": True, "width": 4, "color": "#FFD23A", "align": "inside"},
    }
    img = Image.new("RGBA", (240, 160), (0, 0, 0, 0))
    assert pb.draw(img, {"shape": shape}, 20, 20, 200, 120)
    top_px = img.getpixel((120, 35))
    bot_px = img.getpixel((120, 125))
    # Top of vertical gradient is predominantly red; bottom is predominantly blue
    assert top_px[0] > 180 and top_px[2] < 80
    assert bot_px[2] > 180 and bot_px[0] < 80


def test_auto_palette_extracts_harmonious_colors_from_image(tmp_path):
    from PIL import Image

    img_path = os.path.join(str(tmp_path), "bg.png")
    im = Image.new("RGB", (64, 64), (20, 40, 90))
    for x in range(20, 44):
        for y in range(20, 44):
            im.putpixel((x, y), (255, 190, 30))
    im.save(img_path)
    pal = ct.extract_auto_palette(img_path)
    for k in ("fill", "fill_to", "stroke", "glow", "text_accent", "low_fill", "low_stroke", "plate_fill"):
        assert isinstance(pal.get(k), str) and pal[k].startswith("#") and len(pal[k]) == 7


def test_bento_span_promotion_fills_every_row_to_full_width():
    st = {"top": 5, "lower": 5, "block_keys": ["pic1", "pic2", "pic3", "pic4", "pic5", "ace", "king", "queen", "jack", "ten"]}
    t = ct.get_template("bento_royal_grad")
    doc, _ = ct.compile_template(t, st, None, {"canvas": (1920, 1080)})
    s = doc["slots"]
    # High band has 5 cards with per_row=3 and bento=True -> Row 1 has 2 wide hero cards (pic1, pic2), Row 2 has 3 cards (pic3..pic5)
    assert s["@slot.pic1.card"]["y"] == s["@slot.pic2.card"]["y"]
    assert s["@slot.pic3.card"]["y"] == s["@slot.pic4.card"]["y"] == s["@slot.pic5.card"]["y"]
    assert s["@slot.pic1.card"]["w"] > s["@slot.pic3.card"]["w"] * 1.35
    # Both rows span the exact same total width (zero orphan gap)
    r1_span = (s["@slot.pic2.card"]["x"] + s["@slot.pic2.card"]["w"]) - s["@slot.pic1.card"]["x"]
    r2_span = (s["@slot.pic5.card"]["x"] + s["@slot.pic5.card"]["w"]) - s["@slot.pic3.card"]["x"]
    assert r1_span == pytest.approx(r2_span, abs=2)


def test_aspect_ratio_aware_parts_switch_wide_vs_tall():
    base_parts = [
        {"role": "symbol", "x": 0.04, "y": 0.06, "w": 0.46, "h": 0.88},
        {"role": "counts", "x": 0.52, "y": 0.08, "w": 0.14, "h": 0.84, "font_size": 34, "color": "#FFD23A"},
        {"role": "pays", "x": 0.68, "y": 0.08, "w": 0.28, "h": 0.84, "font_size": 34, "color": "#FFFFFF"},
    ]
    wide = {p["role"]: p for p in ct.adapt_aspect_parts(base_parts, 1.8)}
    assert wide["symbol"]["w"] >= 0.8 and wide["symbol"]["y"] + wide["symbol"]["h"] <= wide["counts"]["y"]
    tall = {p["role"]: p for p in ct.adapt_aspect_parts(base_parts, 0.9)}
    assert tall["symbol"]["x"] + tall["symbol"]["w"] <= tall["counts"]["x"]


def test_jackpot_tier_bar_renders_only_when_sheet_defines_jackpots():
    wb = Workbook()
    ws = wb.active
    ws.title = "Paytable"
    ws["B2"] = "BASE GAMES PAYTABLE"
    ws["B4"] = "GRAND"
    ws["C4"] = 5000
    ws["D4"] = "MAJOR"
    ws["E4"] = 1000
    ws["F4"] = "MINOR"
    ws["G4"] = 250
    ws["H4"] = "MINI"
    ws["I4"] = 50
    tiers = ct.find_jackpot_tiers(ws)
    assert [t["tier"] for t in tiers] == ["grand", "major", "minor", "mini"]
    st = {"top": 3, "lower": 3, "block_keys": ["pic1", "pic2", "pic3", "ace", "king", "queen"]}
    doc, maps = ct.compile_template(ct.get_template("bento_royal_grad"), st, ws, {"canvas": (1920, 1080)})
    assert "@slot.jackpot.grand.card" in doc["slots"] and maps["@slot.jackpot.grand.value"]["text"] == "5000"
    # Without jackpot rows, no jackpot slots are created
    wb2 = Workbook()
    doc2, _ = ct.compile_template(ct.get_template("bento_royal_grad"), st, wb2.active, {"canvas": (1920, 1080)})
    assert not any("jackpot" in k for k in doc2["slots"])


def test_multi_page_paytable_splitting_when_crowded():
    st = {"top": 6, "lower": 6, "block_keys": ["pic1", "pic2", "pic3", "pic4", "pic5", "pic6", "ace", "king", "queen", "jack", "ten", "nine"]}
    pages = ct.split_paytable_pages(ct.get_template("bento_royal_grad"), st, None, {"canvas": (1920, 1080)})
    assert len(pages) == 2
    p1_slots, p2_slots = pages[0]["template"]["slots"], pages[1]["template"]["slots"]
    assert "@slot.pic1.card" in p1_slots and "@slot.ace.card" not in p1_slots
    assert "@slot.ace.card" in p2_slots and "@slot.pic1.card" not in p2_slots


def test_suggest_archetypes_scores_distinct_templates():
    from ps_autotypesetter.dynamic_pages.paytable import pay_reader as pr, suggest as sg

    wb = _sheet()
    read = pr.read_sheet(wb.active)
    def lay_out(t):
        st = {"top": 2, "lower": 2, "block_keys": ["pic1", "pic2", "ace", "king"]}
        doc, maps = ct.compile_template(t, st, wb.active, {"canvas": (1920, 1080)})
        return {"ok": True, "overflow": [], "_template": doc, "_mappings": list(maps.values())}
    archs = sg.suggest_archetypes(read, lay_out, limit=5)
    assert len(archs) == 5 and all(a["score"] > 0.5 for a in archs)
    assert len({a["id"] for a in archs}) == 5


def test_gradient_card_is_a_photoshop_gradient_fill_in_the_psd():
    # Photoshop redraws a shape layer from its fill content: a gradient card keeps its gradient there (GdFl),
    # a flat one stays a solid colour, and "none" switches a kept second colour off
    from psd_tools.constants import Tag
    from ps_autotypesetter import paytable_box as pb
    from ps_autotypesetter.psd_writer import shapes

    base = dict(left=10, top=20, width=400, height=200, radius=16, fill="#FF0000")
    for direction, kind, angle in (("vertical", b"Lnr ", -90.0), ("horizontal", b"Lnr ", 0.0), ("radial", b"Rdl ", 90.0)):
        vscg = next(b for b in shapes.blocks(dict(base, fill_to="#0000FF", gradient_dir=direction), 1920, 1080)
                    if b.key == Tag.VECTOR_STROKE_CONTENT_DATA).data
        assert vscg.key == b"GdFl" and vscg[b"Type"].enum == kind and vscg[b"Angl"].value == angle
        assert len(vscg[b"Grad"][b"Clrs"]) == 2
    flat = next(b for b in shapes.blocks(base, 1920, 1080) if b.key == Tag.VECTOR_STROKE_CONTENT_DATA).data
    assert flat.key == b"SoCo"
    assert "fill_to" not in pb.spec_for({"fill": "#FF0000", "fill_to": "#0000FF", "gradient_dir": "none"}, 0, 0, 100, 50)
    assert "fill_to" not in ct.shape_of({"fill": "#FF0000", "fill_to": "#0000FF", "gradient_dir": "none"})


def test_rules_text_lines_join_and_wrap_to_the_box_unless_line_breaks_are_kept():
    structure = {"top": 2, "lower": 2, "block_keys": ["pic1", "pic2", "ace", "king"]}
    t = copy.deepcopy(ct.get_template("classic_cards"))
    t["page"]["texts"] = [{"id": "notes", "rect": [80, 700, 1700, 200]}]
    _doc, maps = ct.compile_template(t, structure, _sheet().active, {"rules_cells": ["H4", "H5"]})
    assert "\n" not in maps["@slot.text"]["text"]                               # one paragraph: it wraps to the box
    t["page"]["texts"][0]["keep_breaks"] = True
    _doc, maps = ct.compile_template(t, structure, _sheet().active, {"rules_cells": ["H4", "H5"]})
    assert maps["@slot.text"]["text"].count("\n") == 1                          # each Excel line on its own line
    assert ct.flow_lines("a\nb\n\nc\nd") == "a b\n\nc d"                         # a blank line: a new paragraph


def test_a_text_box_placed_by_hand_is_drawn_over_the_cards():
    structure = {"top": 2, "lower": 2, "block_keys": ["pic1", "pic2", "ace", "king"]}
    t = copy.deepcopy(ct.get_template("classic_cards"))
    t["page"]["texts"] = [{"id": "notes", "rect": [80, 300, 1700, 400]}]
    doc, _maps = ct.compile_template(t, structure, _sheet().active, {"rules_cells": ["H4", "H5"]})
    assert list(doc["slots"])[-1] == "@slot.text"                               # last: over what it is stretched on


def test_gradient_strength_mixes_the_second_colour_toward_the_fill():
    full = ct.shape_of({"fill": "#000000", "fill_to": "#FFFFFF"})
    half = ct.shape_of({"fill": "#000000", "fill_to": "#FFFFFF", "gradient_amount": 50})
    flat = ct.shape_of({"fill": "#000000", "fill_to": "#FFFFFF", "gradient_amount": 0})
    assert full["fill_to"] == "#FFFFFF" and half["fill_to"] == "#808080" and flat["fill_to"] == "#000000"
