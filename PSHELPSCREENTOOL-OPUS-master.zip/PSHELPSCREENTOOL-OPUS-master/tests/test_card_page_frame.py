"""The paytable design frame takes the page's shape (card_templates.design_frame), and a design made on the
old centred 1920 x 1080 frame is moved once onto it so it stays where it was on the page (to_page_frame)."""
import pytest

from ps_autotypesetter.dynamic_pages.paytable import card_templates as ct
from ps_autotypesetter.dynamic_pages.template_loader import scale_template_slots

PORTRAIT = (2160, 3840)
STRUCT = {"top": 4, "lower": 4, "block_keys": ["pic1", "pic2", "pic3", "pic4", "ace", "king", "queen", "jack"]}


def _placed():
    t = ct.get_template("side_panel")
    t["page"]["texts"] = [{"id": "notes", "rect": [1398, 164, 448, 785], "locked": True}]
    t["bands"][0].update(card_w=242, card_h=354, pos=[70, 146])
    t["bands"][1].update(card_w=287, card_h=298, pos=[117, 521], gap_x=8)
    t.setdefault("features", {})["wild_box"] = {"rect": [100, 900, 300, 120]}
    t["card_overrides"] = {"jack": {"free": [1500, 960, 200, 100]}}
    t.pop("frame", None)
    return t


@pytest.mark.parametrize("canvas,frame", [((1920, 1080), (1920, 1080)), ((3840, 2160), (1920, 1080)),
                                          (PORTRAIT, (1920, 3412)), ((3840, 1080), (3840, 1080))])
def test_the_frame_is_the_page_shape_at_the_old_scale(canvas, frame):
    assert ct.design_frame(canvas) == frame
    W, H = ct.design_frame(canvas)
    # one design px is the same canvas px as on the old 1920 x 1080 frame
    assert min(canvas[0] / W, canvas[1] / H) == pytest.approx(min(canvas[0] / 1920, canvas[1] / 1080))


def test_an_old_design_moves_once_and_only_its_page_positions():
    t = _placed()
    m = ct.to_page_frame(t, PORTRAIT)
    dy = (3412 - 1080) / 2
    assert m["frame"] == "page" and "frame" not in t                     # a copy; the original untouched
    assert m["bands"][1]["pos"] == [117, 521 + dy]
    assert m["page"]["texts"][0]["rect"] == [1398, 164 + dy, 448, 785]
    assert m["features"]["wild_box"]["rect"] == [100, 900 + dy, 300, 120]
    assert m["card_overrides"]["jack"]["free"] == [1500, 960 + dy, 200, 100]
    assert m["page"]["top"] == t["page"].get("top", 30) + dy and m["page"]["bottom"] == t["page"].get("bottom", 30) + dy
    assert m["bands"][1]["card_w"] == 287                                 # sizes and card parts stay
    assert m["card"] == t["card"] and m["styles"] == t["styles"]
    assert ct.to_page_frame(m, PORTRAIT) is m                             # idempotent
    # 16:9: nothing moves, the design is just marked
    w = ct.to_page_frame(t, (3840, 2160))
    assert w["frame"] == "page" and w["bands"][1]["pos"] == [117, 521] and w["page"]["texts"] == t["page"]["texts"]


def _canvas_px(doc, canvas, slot):
    slots, _sc, _ox, _oy = scale_template_slots(doc, *canvas)
    return slots[slot]


def test_an_old_portrait_design_stays_where_it_was_on_the_page():
    t = _placed()
    doc169, _ = ct.compile_template(t, STRUCT, None, {"canvas": (1920, 1080)})
    doc, _ = ct.compile_template(t, STRUCT, None, {"canvas": PORTRAIT})
    assert doc["canvas"] == {"width": 1920, "height": 3412}
    sc = 2160 / 1920
    old_oy = (3840 - 1080 * sc) / 2                                       # the old frame, centred in the page
    for slot in ("@slot.ace.card", "@slot.pic1.card", "@slot.jack.card", "@slot.text"):
        if slot not in doc169["slots"]:
            continue
        old = doc169["slots"][slot]
        new = _canvas_px(doc, PORTRAIT, slot)
        assert new["x"] == pytest.approx(old["x"] * sc, abs=0.5), slot
        assert new["y"] == pytest.approx(old_oy + old["y"] * sc, abs=0.5), slot
        assert new["w"] == pytest.approx(old["w"] * sc, abs=0.5), slot


def test_on_a_portrait_page_rows_and_the_area_reach_the_page_bottom():
    t = ct.to_page_frame(_placed(), PORTRAIT)
    t["bands"][1]["pos"] = [117, 3000]                                    # far below the old 1080 band
    t["page"]["bottom"] = 20
    doc, _ = ct.compile_template(t, STRUCT, None, {"canvas": PORTRAIT})
    assert doc["slots"]["@slot.ace.card"]["y"] == 3000                    # not clamped to the old frame
    assert doc["mapper_meta"]["blocks"]["page"][3] == pytest.approx(3412 - 20)
    canvas_y = _canvas_px(doc, PORTRAIT, "@slot.ace.card")["y"]
    sc = 2160 / 1920
    assert canvas_y == pytest.approx((3840 - 3412 * sc) / 2 + 3000 * sc, abs=0.01)   # the page's sub-px rest, centred


def test_a_169_game_compiles_exactly_as_before():
    t = _placed()
    a, _ = ct.compile_template(t, STRUCT, None, {"canvas": (3840, 2160)})
    b, _ = ct.compile_template(dict(t, frame="page"), STRUCT, None, {"canvas": (3840, 2160)})
    assert a["canvas"] == {"width": 1920, "height": 1080}
    assert a["slots"] == b["slots"]


def test_a_row_the_old_frame_held_in_stays_there_once_saved():
    # dropped below the old 1080 frame: the old frame kept it on the page — the move keeps it there
    t = _placed()
    t["bands"][0]["pos"] = [70, 1294]
    old169, _ = ct.compile_template(t, STRUCT, None, {"canvas": (1920, 1080)})
    doc, _ = ct.compile_template(t, STRUCT, None, {"canvas": PORTRAIT})
    assert doc["mapper_meta"]["band_at"]["high"][1] < 1166 + 1080
    saved = ct.settle_frame(ct.to_page_frame(t, PORTRAIT), doc)
    assert saved["frame"] == "page" and saved["bands"][0]["pos"] == doc["mapper_meta"]["band_at"]["high"]
    again, _ = ct.compile_template(saved, STRUCT, None, {"canvas": PORTRAIT})
    assert "band_at" not in again["mapper_meta"]
    sc, old_oy = 2160 / 1920, (3840 - 1080 * 2160 / 1920) / 2
    for d in (doc, again):
        new = _canvas_px(d, PORTRAIT, "@slot.pic1.card")
        assert new["y"] == pytest.approx(old_oy + old169["slots"]["@slot.pic1.card"]["y"] * sc, abs=0.5)


@pytest.mark.parametrize("tid", ["classic_cards", "stacked_columns", "compact_grid", "feature_focus", "plain",
                                 "symbols_on_top", "side_panel", "rules_top_scatter"])
def test_builtin_designs_land_the_same_before_and_after_the_move_is_saved(tid):
    t = ct.get_template(tid)
    ctx = {"canvas": PORTRAIT, "heading_top": 150, "heading_size": 60}
    a, _ = ct.compile_template(t, STRUCT, None, ctx)                     # moved on the fly
    saved = ct.settle_frame(ct.to_page_frame(t, PORTRAIT), a)
    b, _ = ct.compile_template(saved, STRUCT, None, ctx)                 # saved on the page frame
    assert a["canvas"] == b["canvas"] == {"width": 1920, "height": 3412}
    assert set(a["slots"]) == set(b["slots"])
    for k, s in a["slots"].items():
        for q in "xywh":
            assert b["slots"][k][q] == pytest.approx(s[q], abs=0.6), (k, q)


def _numbers(c_x, p_x):
    return [{"role": "symbol", "x": 0.05, "y": 0.1, "w": 0.35, "h": 0.8},
            {"role": "counts", "x": c_x, "y": -0.2, "w": 0.12, "h": 1.4, "align": "right", "font_size": 40},
            {"role": "pays", "x": p_x, "y": -0.2, "w": 0.21, "h": 1.4, "align": "left", "font_size": 40}]


def test_crossed_counts_and_pays_go_back_in_order():
    # the gap handle had pushed the pays box left of where the counts end: "1005", pays before counts
    t = _placed()
    t["bands"][1]["parts"] = _numbers(0.631, 0.556)
    t["card_overrides"] = {"ace": {"parts": _numbers(0.631, 0.556)}}
    fixed = ct.numbers_in_order(t)
    for ps in (fixed["bands"][1]["parts"], fixed["card_overrides"]["ace"]["parts"]):
        c, p = ps[1], ps[2]
        assert c["x"] + c["w"] < p["x"]                                   # counts end before the pays start
        assert p["x"] - (c["x"] + c["w"]) == pytest.approx(ct.NUMBERS_GAP)
        assert (c["x"] + c["w"] + p["x"]) / 2 == pytest.approx((0.631 + 0.12 + 0.556) / 2)   # where they met
    assert t["bands"][1]["parts"][2]["x"] == 0.556                       # the saved design untouched
    assert ct.numbers_in_order(fixed) is fixed                           # in order: nothing to do
    doc, _ = ct.compile_template(t, STRUCT, None, {"canvas": (1920, 1080)})
    s = doc["slots"]
    assert s["@slot.ace.pay"]["x"] + s["@slot.ace.pay"]["w"] < s["@slot.ace.value"]["x"]   # counts (.pay) left of pays


def test_numbers_set_apart_on_purpose_stay_as_they_are():
    t = _placed()
    t["bands"][1]["parts"] = _numbers(0.42, 0.6)
    assert ct.numbers_in_order(t) is t
    below = _numbers(0.42, 0.3)
    below[2]["y"] = 1.3                                                   # pays under the counts: not side by side
    t["bands"][1]["parts"] = below
    assert ct.numbers_in_order(t) is t
