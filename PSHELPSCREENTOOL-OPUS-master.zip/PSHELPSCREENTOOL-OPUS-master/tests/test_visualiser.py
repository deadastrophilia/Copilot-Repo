"""Visualiser addon tests: pure logic + Flask endpoint smoke tests."""

import os
import sys
import tempfile

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from openpyxl import Workbook

from visualiser import visualiser_canvas, visualiser_controls, visualiser_guides
from visualiser import visualiser_renderer
from visualiser.visualiser_state import get_path, set_path, style_target


def _make_workbook(path):
    wb = Workbook()
    ws = wb.active
    ws.title = "Paylines"
    ws.cell(row=1, column=1, value="Paylines")
    for row in range(2, 12):
        ws.cell(row=row, column=1, value=f"Line {row - 1}: five of a kind pays 500x")
        ws.cell(row=row, column=2, value=f"<gem> {row - 1}")
    wb.save(path)
    return path


def _base_config(excel_path):
    return {
        "excel_path": excel_path,
        "icon_folder": "",
        "bg_path": "",
        "bg_source": "color",
        "bg_mode": "color",
        "bg_color": "#101418",
        "c_width": 1920,
        "c_height": 1080,
        "render_all_pages": True,
        "h_font": "ArialMT",
        "h_size": 60,
        "h_rgb": "#FFFFFF",
        "b_font": "ArialMT",
        "b_size": 30,
        "b_rgb": "#FFFFFF",
        "margin_x": 80,
        "heading_top_margin": 150,
        "heading_to_body_gap": 40,
        "bottom_margin": 50,
        "line_spacing": 1.1,
        "para_spacing": 14,
        "alignment_settings": None,
        "dynamic_settings": None,
        "page_overrides": None,
    }


@pytest.fixture()
def excel_path():
    path = os.path.join(tempfile.gettempdir(), f"vis_test_{os.getpid()}.xlsx")
    _make_workbook(path)
    yield path
    try:
        os.remove(path)
    except OSError:
        pass


# ------------------------------ pure logic ------------------------------


def test_fit_scale_1080p():
    s = visualiser_canvas.fit_scale(1280, 720, 1920, 1080, padding=24)
    assert 0.5 < s < 0.7  # letterboxed full HD in a 720p viewport
    s4k = visualiser_canvas.fit_scale(1600, 900, 3840, 2160, padding=24)
    assert s4k < s  # 4K fits smaller than 1080p


def test_zoom_clamp_and_point_fixed():
    assert visualiser_canvas.zoom_scale(1.0, 10.0) <= visualiser_canvas.MAX_SCALE
    tx, ty = visualiser_canvas.keep_point_fixed(1.0, 2.0, 10, 20, 100, 200)
    assert (tx, ty) == (100 - (100 - 10) * 2, 200 - (200 - 20) * 2)


def test_guides_compute_and_drag():
    geometry = {
        "canvas_w": 1920, "canvas_h": 1080,
        "heading_top": 150, "heading_bottom": 150 + 80,
        "body_top": 150 + 80 + 40, "body_bottom": 1080 - 50,
        "safe_left": 80, "safe_right": 1920 - 80,
    }
    guides = visualiser_guides.compute_guides(geometry)
    by_id = {g["id"]: g for g in guides}
    assert by_id["header_top"]["value"] == 150
    # left/right guides edit the symmetric inner-canvas WIDTH
    assert by_id["safe_left"]["value"] == 1760
    assert by_id["safe_right"]["value"] == 1760
    assert by_id["safe_left"]["key"] == "inner_canvas_width"
    assert by_id["safe_right"]["key"] == "inner_canvas_width"
    assert by_id["heading_gap"]["value"] == 40
    assert by_id["body_bottom"]["value"] == 50

    gap = by_id["heading_gap"]
    # gap line at y=270 (body_top); heading_bottom=230 -> current value 40
    assert visualiser_guides.value_from_drag(geometry, gap, 270) == 40
    assert visualiser_guides.value_from_drag(geometry, gap, 330) == 100
    bottom = by_id["body_bottom"]
    assert visualiser_guides.value_from_drag(geometry, bottom, 1080 - 120) == 120
    left = by_id["safe_left"]
    right = by_id["safe_right"]
    assert visualiser_guides.value_from_drag(geometry, left, 80) == 1760
    assert visualiser_guides.value_from_drag(geometry, right, 1920 - 80) == 1760
    assert visualiser_guides.value_from_drag(geometry, left, 200) == 1520
    assert visualiser_guides.value_from_drag(geometry, right, 1720) == 1520
    assert visualiser_guides.clamp_value(gap, -50) == 0
    assert visualiser_guides.clamp_value(gap, 5000) == 400


def test_inner_safe_box_auto_and_override():
    from ps_autotypesetter import png_builder

    # 4K landscape: auto inner canvas = bg height - 20 px (10 px each side)
    left, width = png_builder._inner_safe_box(3840, 2160, 80, 0)
    assert (left, width) == (850, 2140)
    # explicit override wins over auto
    left2, width2 = png_builder._inner_safe_box(3840, 2160, 80, 2500)
    assert (left2, width2) == (670, 2500)
    # margins already narrower than the cap keep the classic box
    left3, width3 = png_builder._inner_safe_box(3840, 2160, 1400, 0)
    assert (left3, width3) == (1400, 1040)
    # portrait keeps margin_x semantics
    left4, width4 = png_builder._inner_safe_box(2160, 3840, 100, 0)
    assert (left4, width4) == (100, 1960)


def test_style_target_resolution():
    cfg = {"dynamic_settings": None}
    path, name = style_target(cfg, "heading")
    assert path == ["heading_style"] and name is None
    cfg = {
        "dynamic_settings": {
            "layer_style_library": {"Gold": {"stroke_enabled": True}},
            "style_assignments": {"Heading text": "Gold"},
        }
    }
    path, name = style_target(cfg, "heading")
    assert path == ["dynamic_settings", "layer_style_library", "Gold"] and name == "Gold"
    assert get_path(cfg, path + ["stroke_enabled"]) is True
    set_path(cfg, path + ["stroke_enabled"], False)
    assert get_path(cfg, path + ["stroke_enabled"]) is False


def test_controls_payload_shapes():
    cfg = {"dynamic_settings": None, "heading_style": None, "body_style": None}
    sections = visualiser_controls.controls_payload(cfg)
    by_id = {s["id"]: s for s in sections}
    assert any(i["key"] == "margin_x" for i in by_id["spacing"]["items"])
    styles = by_id["layer_styles"]["styles"]
    assert {s["role"] for s in styles} == {"heading", "body"}
    assert styles[0]["path"] == ["heading_style"]
    keys = {f["field"] for f in styles[0]["fields"]}
    assert {"stroke_enabled", "shadow_size", "stroke_rgb"} <= keys

    table = by_id["table_style"]["items"]
    table_keys = {i["key"] for i in table}
    assert "table_style.header_bg_rgb" in table_keys
    assert "table_style.render_mode" in table_keys
    assert "table_style.table_body_font_size" in table_keys


# ------------------------------ endpoint smoke ------------------------------


def _pillow_fonts_ok():
    try:
        from ps_autotypesetter import png_builder

        Image, _ImageDraw, ImageFont = png_builder._require_pillow()
        png_builder._load_font(ImageFont, "ArialMT", 30)
        return True
    except Exception:
        return False


@pytest.fixture()
def client(excel_path):
    from ps_autotypesetter.ui_web.server import create_app

    session = os.path.join(tempfile.gettempdir(), f"vis_session_{os.getpid()}.json")
    app = create_app(session_file=session)
    app.config["TESTING"] = True
    with app.test_client() as c:
        c.post("/api/config", json=_base_config(excel_path))
        yield c
    try:
        os.remove(session)
    except OSError:
        pass


def test_sheets_endpoint(client):
    resp = client.post("/api/visualiser/sheets", json={})
    data = resp.get_json()
    assert data["ok"] is True
    assert "Paylines" in data["sheets"]
    assert data["canvas_width"] == 1920
    assert any(s["id"] == "layer_styles" for s in data["controls"])


@pytest.mark.skipif(not _pillow_fonts_ok(), reason="No usable PIL font on this machine")
def test_preview_endpoint_renders(client):
    resp = client.post("/api/visualiser/preview", json={"sheet_name": "Paylines"})
    data = resp.get_json()
    assert resp.status_code == 200, data
    assert data["ok"] is True, data
    assert data["preview_token"]
    assert data["geometry"]["canvas_w"] == 1920
    assert data["guides"]
    # the preview token must serve a real PNG
    img = client.get(f"/api/table_preview/{data['preview_token']}")
    assert img.status_code == 200
    assert img.mimetype == "image/png"


def test_preview_rejects_paytable_sheet(excel_path):
    from ps_autotypesetter.ui_web.server import create_app

    wb = Workbook()
    ws = wb.active
    ws.title = "Paytable Main"
    wb.save(excel_path)
    try:
        session = os.path.join(tempfile.gettempdir(), f"vis_session2_{os.getpid()}.json")
        app = create_app(session_file=session)
        app.config["TESTING"] = True
        with app.test_client() as c:
            c.post("/api/config", json=_base_config(excel_path))
            resp = c.post("/api/visualiser/preview", json={"sheet_name": "Paytable Main"})
            data = resp.get_json()
            # a "Paytable …" sheet is NOT a normal page -> rejected, not rendered
            assert data["ok"] is False
            assert "paytable" in (data.get("error") or "").lower()
    finally:
        try:
            os.remove(excel_path)
        except OSError:
            pass


# ------------------------------ LIVE renderer ------------------------------


def test_editor_data_endpoint(client):
    resp = client.post("/api/visualiser/editor-data", json={"sheet_name": "Paylines"})
    data = resp.get_json()
    assert resp.status_code == 200, data
    assert data["ok"] is True, data
    d = data["data"]
    assert d["sheet_name"] == "Paylines"
    assert d["heading"]["text"] == "Paylines"
    # this fixture's aligned 2-column content IS auto-detected as a table by
    # the real renderer — the LIVE extractor must mirror that exactly
    assert len(d["tables"]) >= 1
    assert d["tables"][0]["height"] > 0
    assert d["tables"][0]["token"]
    assert d["safe"]["left"] >= 0 and d["safe"]["width"] > 0
    assert d["safe"]["bottom"] > d["safe"]["left"]
    assert d["fonts"]["body"]
    assert d["heading"]["font_file"]
    assert d["settings"]["h_size"] == 60
    assert d["settings"]["b_size"] == 30
    assert d["settings"]["heading_to_body_gap"] == 40
    assert d["canvas_w"] == 1920 and d["canvas_h"] == 1080


def test_editor_data_row_gaps_match_png_renderer(client):
    """The LIVE canvas row gaps must equal the FINAL PNG renderer's PSD
    row-gap math. Row Gap ('line_gap') is the SINGLE body row-gap source
    (empty -> the 30px default); headings keep the multiplier rule."""
    from ps_autotypesetter import png_builder

    resp = client.post("/api/visualiser/editor-data", json={"sheet_name": "Paylines"})
    data = resp.get_json()
    assert resp.status_code == 200, data
    s = data["data"]["settings"]
    assert s["line_spacing_raw"] == pytest.approx(1.1)
    assert s["body_line_spacing"] == 30  # empty Row Gap -> the 30px default
    assert s["heading_line_spacing"] == png_builder._row_gap_px(60, 1.1)
    assert png_builder._effective_row_gap(None) == 30
    assert png_builder._effective_row_gap("") == 30
    assert png_builder._effective_row_gap(12) == 12
    assert png_builder._effective_row_gap(0) == 0


def _make_text_workbook(path):
    """Single-column content: no auto-table detection, pure heading+body flow."""
    wb = Workbook()
    ws = wb.active
    ws.title = "Paylines"
    ws.cell(row=1, column=1, value="Paylines")
    for row in range(2, 12):
        ws.cell(row=row, column=1, value=f"Line {row - 1}: five of a kind pays 500x with the golden gem <gem>")
    wb.save(path)


@pytest.fixture()
def text_excel_path(tmp_path):
    path = os.path.join(tmp_path, "text_sheet.xlsx")
    _make_text_workbook(path)
    return path


def _config_with(excel_path):
    cfg = _base_config(excel_path)
    cfg["icon_folder"] = ""
    return cfg


def test_editor_data_text_rows(text_excel_path):
    from ps_autotypesetter.ui_web.server import create_app

    session = os.path.join(tempfile.gettempdir(), f"vis_session3_{os.getpid()}.json")
    app = create_app(session_file=session)
    app.config["TESTING"] = True
    try:
        with app.test_client() as c:
            c.post("/api/config", json=_config_with(text_excel_path))
            resp = c.post("/api/visualiser/editor-data", json={"sheet_name": "Paylines"})
            data = resp.get_json()
            assert data["ok"] is True, data
            d = data["data"]
            assert d["heading"]["text"] == "Paylines"
            assert len(d["rows"]) == 10
            assert d["tables"] == []
            assert "<gem>" in d["rows"][0]["text"]
            assert d["icons"]["gem"]["url"] == ""  # no icon folder -> placeholder
            assert all(r["row"] != d["heading"]["row"] for r in d["rows"])
    finally:
        try:
            os.remove(session)
        except OSError:
            pass


def test_editor_data_heading_row_skipped(client):
    resp = client.post("/api/visualiser/editor-data", json={"sheet_name": "Paylines"})
    d = resp.get_json()["data"]
    assert all(r["row"] != d["heading"]["row"] for r in d["rows"])


def test_editor_data_cache_and_force(client):
    r1 = client.post("/api/visualiser/editor-data", json={"sheet_name": "Paylines"}).get_json()
    assert r1["cached"] is False
    r2 = client.post("/api/visualiser/editor-data", json={"sheet_name": "Paylines"}).get_json()
    assert r2["cached"] is True
    r3 = client.post("/api/visualiser/editor-data", json={"sheet_name": "Paylines", "force": True}).get_json()
    assert r3["cached"] is False


def test_font_file_endpoint(client):
    resp = client.get("/api/font_file?file=arial.ttf")
    assert resp.status_code == 200
    assert resp.data[:4] == b"\x00\x01\x00\x00" or len(resp.data) > 1000
    missing = client.get("/api/font_file?file=does_not_exist_xyz.ttf")
    assert missing.status_code == 404


@pytest.mark.skipif(not _pillow_fonts_ok(), reason="No usable PIL font on this machine")
def test_verify_endpoint_identity_match(client):
    import base64

    preview = client.post("/api/visualiser/preview", json={"sheet_name": "Paylines"}).get_json()
    assert preview["ok"] is True
    img = client.get(f"/api/table_preview/{preview['preview_token']}")
    b64 = base64.b64encode(img.data).decode("ascii")
    resp = client.post("/api/visualiser/verify", json={"sheet_name": "Paylines", "png_b64": b64})
    data = resp.get_json()
    assert resp.status_code == 200, data
    assert data["ok"] is True, data
    assert data["match_pct"] > 99.0
    assert data["mean_diff"] < 1.0
    assert data["diff_token"]
    diff = client.get(f"/api/table_preview/{data['diff_token']}")
    assert diff.status_code == 200 and diff.mimetype == "image/png"


@pytest.mark.skipif(not _pillow_fonts_ok(), reason="No usable PIL font on this machine")
def test_verify_endpoint_blank_differs(client):
    import base64
    import io

    from PIL import Image as PILImage

    buf = io.BytesIO()
    PILImage.new("RGB", (1920, 1080), (255, 255, 255)).save(buf, "PNG")
    b64 = base64.b64encode(buf.getvalue()).decode("ascii")
    resp = client.post("/api/visualiser/verify", json={"sheet_name": "Paylines", "png_b64": b64})
    data = resp.get_json()
    assert data["ok"] is True, data
    assert data["match_pct"] < 99.0

def test_sheets_endpoint_lists_every_page_with_the_studio_ones_marked(tmp_path):
    from openpyxl import Workbook

    from ps_autotypesetter.ui_web.server import create_app

    wb = Workbook()
    wb.active.title = "Paytable"
    for name in ("Features", "Game Rules", "Bingo Rules"):
        wb.create_sheet(name)["A1"] = name + " text"
    wb["Paytable"]["A1"] = "PAYTABLE"
    path = tmp_path / "agr.xlsx"
    wb.save(path)
    session = tmp_path / "s.json"
    session.write_text("{}", encoding="utf-8")
    c = create_app(session_file=str(session)).test_client()
    c.post("/api/config", json={"excel_path": str(path)})
    data = c.post("/api/visualiser/sheets", json={}).get_json()
    assert data["all_sheets"] == ["Paytable", "Features", "Game Rules", "Bingo Rules"]
    assert data["studio_sheets"] == {"Paytable": "paytable", "Game Rules": "game_rules", "Bingo Rules": "bingo_rules"}
    assert "Paytable" not in data["sheets"]            # Typography's preview keeps to the normal pages
