from openpyxl import Workbook
from ps_autotypesetter.diff_engine import compare_workbooks


def _make_wb(sheet_data):
    """Create a workbook from a dict of {sheet_name: [[row_values]]}."""
    wb = Workbook()
    first = True
    for name, rows in sheet_data.items():
        if first:
            ws = wb.active
            ws.title = name
            first = False
        else:
            ws = wb.create_sheet(name)
        for row in rows:
            ws.append(row)
    return wb


class TestCompareWorkbooks:
    def test_no_changes(self, single_sheet_wb):
        wb2 = _make_wb({"Sheet1": [["A", "B", "C"], ["1", "2", "3"]]})
        assert compare_workbooks(single_sheet_wb, wb2, 3) == {}

    def test_tab_added(self, single_sheet_wb):
        wb2 = _make_wb({"Sheet1": [["A", "B", "C"], ["1", "2", "3"]], "NewTab": [["X"]]})
        result = compare_workbooks(single_sheet_wb, wb2, 3)
        assert result.get("NewTab") == ["Tab added"]

    def test_tab_removed(self, single_sheet_wb):
        wb2 = _make_wb({})
        result = compare_workbooks(single_sheet_wb, wb2, 3)
        assert result.get("Sheet1") == ["Tab removed"]

    def test_row_count_changed(self, single_sheet_wb):
        wb2 = _make_wb({"Sheet1": [["A", "B", "C"]]})
        result = compare_workbooks(single_sheet_wb, wb2, 3)
        assert any("Row count changed" in msg for msg in result.get("Sheet1", []))

    def test_cell_value_changed(self, single_sheet_wb):
        wb2 = _make_wb({"Sheet1": [["A", "X", "C"], ["1", "2", "3"]]})
        result = compare_workbooks(single_sheet_wb, wb2, 3)
        assert any("Col2" in msg for msg in result.get("Sheet1", []))
