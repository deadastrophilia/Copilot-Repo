"""Card variants on paytable pages: a tile behind each symbol, "of a kind" on a shared card, a card's
own look, a third tier (a middle row) and a panel behind all the cards."""
import copy
import os

import pytest

from ps_autotypesetter.dynamic_pages.paytable import card_templates as ct
from ps_autotypesetter.ui_web import engine_api

REF = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "ExcelFileForReference", "C2_Monopoly_AGR.xlsm")
_STRUCT = {"top": 5, "lower": 5, "block_keys": ["pic1", "pic2", "pic3", "pic4", "pic5", "ace", "king", "queen", "jack", "ten"]}


def _doc(mutate):
    t = copy.deepcopy(ct.get_template("classic_cards"))
    mutate(t)
    return ct.compile_template(t, _STRUCT, None, {"canvas": (1920, 1080), "body_size": 44})


def _excel(mutate):
    if not os.path.isfile(REF):
        pytest.skip("reference Excel not here")
    t = copy.deepcopy(ct.get_template("classic_cards"))
    mutate(t)
    cfg = dict(engine_api.DEFAULT_CONFIG, excel_path=REF)
    res, _ = engine_api.auto_map_page(cfg, "Paytable", "", {"card_template": t, "dry_run": True})
    assert res["ok"], res.get("error")
    return res["_template"], {m["slot"]: m for m in res["_mappings"]}


def test_a_tile_sits_under_each_symbol_of_its_row_and_the_symbol_inside_it():
    doc, maps = _doc(lambda t: t["bands"][0].update(tile={"enabled": True, "pad": 0.1}))
    s, keys = doc["slots"], list(doc["slots"])
    tile, sym = s["@slot.pic1.tile"], s["@slot.pic1"]
    assert keys.index("@slot.pic1.tile") < keys.index("@slot.pic1")                 # drawn first
    assert tile["x"] <= sym["x"] and sym["x"] + sym["w"] <= tile["x"] + tile["w"]    # the symbol inside
    assert sym["w"] < tile["w"]
    assert "@slot.ace.tile" not in s                                                 # only the high row
    assert maps["@slot.pic1.tile"]["shape"]["stroke"]["enabled"]


def test_a_card_with_its_own_look():
    def m(t):
        t["styles"]["mine"] = {"fill_enabled": True, "fill": "#123456", "radius": 4}
        t["card_overrides"] = {"pic2": {"style": "mine"}}
    _doc_, maps = _doc(m)
    assert maps["@slot.pic2.card"]["shape"]["fill"].lower() == "#123456"
    assert maps["@slot.pic1.card"]["shape"]["fill"].lower() != "#123456"


def test_a_third_tier_between_the_rows():
    doc, _ = _doc(lambda t: t["bands"].append(dict(copy.deepcopy(t["bands"][0]), name="mid")) or t["bands"][0].update(count=2))
    b = doc["mapper_meta"]["blocks"]
    assert b["high"][3] <= b["mid"][1] and b["mid"][3] <= b["low"][1]
    inside = lambda row: sorted(k[5:] for k, r in b.items() if k.startswith("card:") and b[row][1] <= (r[1] + r[3]) / 2 <= b[row][3])  # noqa: E731
    assert inside("high") == ["pic1", "pic2"] and inside("mid") == ["pic3", "pic4", "pic5"]


def test_a_card_moved_to_the_middle_row_by_hand():
    def m(t):
        t["bands"].append(dict(copy.deepcopy(t["bands"][0]), name="mid"))
        t["bands"][0]["count"] = 3
        t["row_of"] = {"a": "mid", "pic3": "high"}                  # this sheet's ACE is "a"
    doc, _ = _excel(m)
    b = doc["mapper_meta"]["blocks"]
    mid_of = lambda k: b["mid"][1] <= (b[k][1] + b[k][3]) / 2 <= b["mid"][3]  # noqa: E731
    assert mid_of("card:a")
    assert not mid_of("card:pic3") and b["card:pic3"][3] <= b["mid"][1]


def test_of_a_kind_on_a_shared_card_only():
    def m(t):
        t["card"]["group_same_pays"] = "low"
        t["card"]["kind_caption"] = {"enabled": True, "text": "ANY OF A KIND"}
    doc, maps = _excel(m)
    kinds = [k for k in maps if k.endswith(".kind")]
    assert kinds and all(maps[k]["text"] == "ANY OF A KIND" for k in kinds)
    name = kinds[0].split(".")[1]
    s = doc["slots"]
    cap, card = s[kinds[0]], s[f"@slot.{name}.card"]
    assert cap["h"] < card["h"] / 3 and cap["y"] > card["y"] + card["h"] / 2           # a strip at the bottom
    syms = [s[f"@slot.{k}"] for k in ("a", "k", "q", "j") if f"@slot.{k}" in s
            and card["x"] <= s[f"@slot.{k}"]["x"] < card["x"] + card["w"] and card["y"] <= s[f"@slot.{k}"]["y"] < card["y"] + card["h"]]
    assert len(syms) >= 2 and all(v["y"] + v["h"] <= cap["y"] + 1 for v in syms)     # the symbols stay above it


def test_a_panel_behind_all_the_cards():
    doc, maps = _doc(lambda t: t["page"].update(cards_panel={"enabled": True, "pad": 20}))
    assert next(iter(doc["slots"])) == "@slot.cardspanel"                            # drawn under everything
    p, c = doc["mapper_meta"]["blocks"]["cardspanel"], doc["mapper_meta"]["blocks"]["cards"]
    assert p[0] <= c[0] - 19 and p[3] >= c[3] + 19
    assert maps["@slot.cardspanel"]["shape"]


def test_mid_split_at_the_biggest_drop_else_half():
    assert ct.mid_split(["a", "b", "c", "d"], None) == 2
    assert ct.mid_split(["a"], None) == 1


# ---- a card broken out of its row, divider lines of their own, a layer style on fill / stroke only ----
def test_a_card_broken_out_of_its_row_sits_where_put_and_its_row_closes_up():
    doc, maps = _doc(lambda t: t.update(card_overrides={"pic2": {"free": [1500, 800, 300, 200]}}))
    s, meta = doc["slots"], doc["mapper_meta"]
    assert (s["@slot.pic2.card"]["x"], s["@slot.pic2.card"]["y"], s["@slot.pic2.card"]["w"]) == (1500, 800, 300)
    assert meta["free_cards"] == {"pic2": "high"}
    hi = meta["blocks"]["high"]
    assert hi[2] < 1500 or hi[3] < 800                                    # the row's box doesn't stretch to it
    base, bmaps = _doc(lambda t: None)                                   # its content scales with it
    k = 300 / base["slots"]["@slot.pic2.card"]["w"]
    assert maps["@slot.pic2.pay"]["font_size"] == pytest.approx(bmaps["@slot.pic2.pay"]["font_size"] * k, rel=0.15)


def test_a_divider_line_of_its_own_length_and_place():
    def m(t):
        t["card"]["dividers"] = {"enabled": True, "width": 4, "lines": {"div1": {"len": 0.5, "off": 0.1}}}
    doc, _ = _doc(m)
    base, _ = _doc(lambda t: t["card"].update(dividers={"enabled": True, "width": 4}))
    a, b, card = doc["slots"]["@slot.pic1.div1"], base["slots"]["@slot.pic1.div1"], doc["slots"]["@slot.pic1.card"]
    if a["h"] > a["w"]:                                                    # upright
        assert a["h"] == pytest.approx(card["h"] * 0.5, abs=2) and a["x"] > b["x"]
    else:
        assert a["w"] == pytest.approx(card["w"] * 0.5, abs=2) and a["y"] > b["y"]


def test_a_layer_style_on_the_stroke_only_is_its_own_layer():
    def m(t):
        st = t["bands"][0].get("style") or "card"
        t["styles"][st] = {"fill_enabled": True, "fill": "#222222", "radius": 8, "fx": "Glow", "fx_on": "stroke",
                           "stroke": {"enabled": True, "width": 3, "color": "#ffffff"}}
    doc, maps = _doc(m)
    keys = list(doc["slots"])
    assert keys.index("@slot.pic1.card.stroke") == keys.index("@slot.pic1.card") + 1
    assert maps["@slot.pic1.card"]["shape"]["fx"] == "" and not maps["@slot.pic1.card"]["shape"]["stroke"]
    assert maps["@slot.pic1.card.stroke"]["shape"]["fx"] == "Glow" and maps["@slot.pic1.card.stroke"]["shape"]["fill"] is None


# ---- symbol sizes in px (as drawn, canvas px): card symbols and the symbols inside text ----
def test_a_card_symbol_sized_in_px_is_that_tall():
    doc, maps = _doc(lambda t: t["card"].update(symbol_px={"pic1": 90, "*": 50}))
    assert maps["@slot.pic1"]["icon_height"] == pytest.approx(90, abs=1)       # canvas px (the test canvas is 1920 wide: scale 1)
    assert maps["@slot.pic2"]["icon_height"] == pytest.approx(50, abs=1)       # every other symbol


def test_text_symbol_heights_in_px_win_over_percent():
    from ps_autotypesetter.ui_web import ps_actions as pa
    t = {"text_icon_scale": {"WILD": 200}, "text_icon_px": {"SCAT": 33}}
    scales = ct.icon_scales(t, {"icon_px": {"WILD": 21}})
    assert pa.icon_height_for(scales, "<WILD>", 40) == 21                     # this box's px over the page-wide %
    assert pa.icon_height_for(scales, "<SCAT>", 40) == 33                     # every paytable text's px
    assert pa.icon_height_for(ct.icon_scales(t, None), "<WILD>", 40) == 80    # an older % still works


def test_a_locked_row_never_moves_when_the_scatter_card_moves():
    path = r"E:\Work\ClaudeCode\DataForHelpScreenTool\Jactpot-carn-help\JackpotCarnivalBuffalo_GameRules_NYL.xlsm"
    if not os.path.isfile(path):
        pytest.skip("Jackpot Carnival Excel not here")
    t = copy.deepcopy(ct.get_template("classic_cards"))
    t["scatter_section"] = {"enabled": True, "rect": [1300, 600, 400, 300]}
    t["bands"][1].update(pos=[70, 560], lock_size=[1150, 330])
    t["bands"][1].pop("card_w", None)

    def low(rect):
        t2 = copy.deepcopy(t)
        t2["scatter_section"]["rect"] = rect
        res, _ = engine_api.auto_map_page(dict(engine_api.DEFAULT_CONFIG, excel_path=path), "PAYTABLE", "", {"card_template": t2, "dry_run": True})
        s = res["_template"]["slots"]
        return [tuple(round(s[k][a]) for a in "xywh") for k in ("@slot.ace.card", "@slot.nine.card")]
    assert low([1300, 600, 400, 300]) == low([900, 600, 400, 300]) == low([500, 300, 400, 300])


def test_an_unlocked_row_keeps_its_box_and_its_box_grows_with_bigger_cards():
    t = copy.deepcopy(ct.get_template("classic_cards"))
    t["bands"][1].update(pos=[70, 600], lock_size=[900, 200], card_w=200, card_h=120, locked=False)
    doc, _ = _doc(lambda x: x.update(bands=t["bands"]))
    a = doc["slots"]["@slot.ace.card"]
    assert (a["x"], a["y"]) == (70, 600) or a["y"] >= 600                     # where it was, not reflowed
    t["bands"][1]["card_w"] = 400                                            # edited bigger after unlocking
    doc2, _ = _doc(lambda x: x.update(bands=t["bands"]))
    assert doc2["slots"]["@slot.ace.card"]["w"] > a["w"] * 1.5               # it grows (a locked box would shrink it)
    t["bands"][1]["locked"] = True
    doc3, _ = _doc(lambda x: x.update(bands=t["bands"]))
    assert doc3["slots"]["@slot.ace.card"]["w"] < doc2["slots"]["@slot.ace.card"]["w"]


def test_an_unlocked_row_is_its_cards_an_old_box_never_holds_it_back():
    # unlocked with the box it had when locked still saved: smaller cards stay smaller, where they were put
    t = copy.deepcopy(ct.get_template("classic_cards"))
    t["bands"][1].update(pos=[300, 600], lock_size=[1400, 400], card_w=150, card_h=100, locked=False)
    doc, _ = _doc(lambda x: x.update(bands=t["bands"]))
    t["bands"][1].pop("lock_size")
    ref, _ = _doc(lambda x: x.update(bands=t["bands"]))
    keys = [k for k in ref["slots"] if k.endswith(".card")]
    assert keys and all({a: round(doc["slots"][k][a]) for a in "xywh"} == {a: round(ref["slots"][k][a]) for a in "xywh"} for k in keys)
    assert round(doc["slots"]["@slot.ace.card"]["x"]) == 300                  # it starts where it was dropped


def test_the_scatter_card_keeps_the_size_it_was_dragged_to():
    path = r"E:\Work\ClaudeCode\DataForHelpScreenTool\Jactpot-carn-help\JackpotCarnivalBuffalo_GameRules_NYL.xlsm"
    if not os.path.isfile(path):
        pytest.skip("Jackpot Carnival Excel not here")
    t = copy.deepcopy(ct.get_template("classic_cards"))
    t["features"]["tab"] = {"enabled": False}
    t["scatter_section"] = {"enabled": True, "title_h": 50}
    t["features"]["scatter_box"] = {"rect": [1200, 500, 520, 400]}          # its left edge dragged out
    res, _ = engine_api.auto_map_page(dict(engine_api.DEFAULT_CONFIG, excel_path=path), "PAYTABLE", "", {"card_template": t, "dry_run": True})
    f = res["_template"]["slots"]["@slot.scatsec"]
    assert (f["x"], f["w"]) == (1200, 520) and f["y"] == 500 + 50 + 4 and f["h"] == 400 - 50 - 4


def test_a_frame_with_only_a_stroke_draws_its_stroke_in_the_build():
    from PIL import Image
    from ps_autotypesetter import paytable_box as pb
    shape = {"radius": 20, "fill": None, "fill_opacity": 0, "fx": "",
             "stroke": {"enabled": True, "width": 4, "color": "#FFC23A", "align": "inside"}}
    assert pb.spec_for(shape, 0, 0, 100, 60)["fill_opacity"] == 100.0           # Fill 0 would hide the border
    base = Image.new("RGBA", (300, 200), (0, 0, 0, 255))
    pb.draw(base, {"shape": shape}, 20, 20, 200, 120)
    assert base.getpixel((120, 21))[:3] == pytest.approx((255, 194, 58), abs=4)     # the gold border
    assert base.getpixel((120, 80))[:3] == (0, 0, 0)                               # nothing inside
