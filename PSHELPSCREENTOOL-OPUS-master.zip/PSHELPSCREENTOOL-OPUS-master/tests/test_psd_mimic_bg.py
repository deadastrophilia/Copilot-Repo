"""Mimic a PSD design: the background layer (named BG / Background), where it sits, margins, and restyle()."""
import os

from PIL import Image

from ps_autotypesetter import games, psd_style_import


class _Layer:
    def __init__(self, name, bbox, kind="pixel", visible=True, group=False):
        self.name, self.bbox, self.kind, self._v, self._g = name, bbox, kind, visible, group

    def is_visible(self):
        return self._v

    def is_group(self):
        return self._g

    def composite(self):
        l, t, r, b = self.bbox
        return Image.new("RGBA", (r - l, b - t), (200, 10, 10, 255))


class _Psd:
    width, height = 2160, 3840

    def __init__(self, layers):
        self._layers = layers

    def descendants(self):
        return iter(self._layers)


def test_visible_bg_layer_wins_over_a_hidden_full_background():
    psd = _Psd([_Layer("Background", (0, 0, 2160, 3840), visible=False), _Layer("JC_Scaled", (0, 0, 2160, 3840), "smartobject"),
                _Layer("BG", (27, 2355, 2133, 3641))])
    layer, rect = psd_style_import.bg_layer(psd)
    assert layer.name == "BG" and rect == (27, 2355, 2106, 1286)


def test_no_named_layer_falls_back_to_the_biggest_picture():
    psd = _Psd([_Layer("Art", (0, 0, 2160, 3840), "smartobject"), _Layer("small", (0, 0, 100, 100))])
    assert psd_style_import.bg_layer(psd)[0].name == "Art"


def test_apply_takes_placement_and_margins_only_when_ticked():
    fields = [{"key": "bg_mode", "value": "place", "apply": True}, {"key": "bg_rect", "value": [27, 2355, 2106, 1286], "apply": True},
              {"key": "heading_top_margin", "value": 2419, "apply": True}, {"key": "bottom_margin", "value": 540, "apply": False},
              {"key": "h_font_style", "value": "Bold", "apply": True}, {"key": "bg_path", "value": "C:/evil.png", "apply": True}]
    out = psd_style_import.apply({"bottom_margin": 30}, fields)
    assert out["bg_mode"] == "place" and out["bg_rect"] == [27, 2355, 2106, 1286]
    assert out["heading_top_margin"] == 2419 and out["bottom_margin"] == 30 and out["h_font_style"] == "Bold"
    assert "bg_path" not in out                                         # never a path from the fields


def test_restyle_saves_the_game_and_its_background(tmp_path, monkeypatch):
    folder = tmp_path / "Game"
    folder.mkdir()
    psd = tmp_path / "Ref.psd"
    psd.write_bytes(b"8BPS")
    monkeypatch.setattr(psd_style_import, "export_bg",
                        lambda src, out: (Image.new("RGBA", (10, 10)).save(out) or out, [0, 0, 10, 10]))
    game = {"id": "g1", "name": "G", "folder": str(folder), "style": {"h_size": 60, "b_size": 30},
            "markets": [], "_file": str(tmp_path / "g1.json")}
    ps = {"source": str(psd), "fields": [{"key": "h_size", "value": 90, "apply": True}, {"key": "b_size", "value": 10, "apply": False},
                                         {"key": "bg_from_psd", "value": True, "apply": True}], "styles": {}}
    out = games.restyle(game, ps)
    assert out["style"]["h_size"] == 90 and out["style"]["b_size"] == 30
    assert out["style"]["bg_path"] == os.path.join(str(folder), "Ref_BG.png") and os.path.isfile(out["style"]["bg_path"])
    assert os.path.isfile(tmp_path / "g1.json")
