"""Photoshop text layer vs the tool (fx_text_roundtrip.py), and the blend-mode decoding it uncovered.

The real round trip needs Photoshop: set PSH_PHOTOSHOP_TESTS=1 to run it (it opens temporary documents
only and closes them unsaved)."""

import os

import numpy as np
import pytest
from PIL import Image

from ps_autotypesetter import fx_descriptor, fx_text_roundtrip as rt, fx_verify, ps_fx_png


@pytest.mark.parametrize("stored, blend", [("overlay", "overlay"), ("multiply", "multiply"), ("screen", "screen"),
                                           ("softLight", "soft light"), ("colorDodge", "color dodge"),
                                           ("linearDodge", "linear dodge"), ("Ovrl", "overlay"), ("normal", "normal")])
def test_descriptor_blend_modes_are_kept(stored, blend):
    """Photoshop stores long stringIDs ("overlay") in layerEffects; they used to fall back to Normal."""
    p = fx_descriptor.params_from_descriptor({"IrGl": {"enab": True, "Md  ": {"$enum": stored}}})
    assert p["inner_glow"]["blend"] == blend


def test_an_overlay_inner_glow_no_longer_whitens_the_text():
    """The FoMoMummy heading: a white Overlay inner glow over a yellow gradient keeps the yellow."""
    content = np.zeros((40, 40, 4), np.float32)
    content[8:32, 8:32] = (1, 1, 1, 1)
    style = {"gradient_overlay": {"enabled": True, "colors": [[[255, 242, 0], 0], [[255, 242, 0], 100]]},
             "inner_glow": {"enabled": True, "color": [255, 255, 255], "opacity": 91, "size": 2, "spread": 100,
                            "source": "center", "blend": fx_descriptor._BLEND_NAMES["overlay"]}}
    out = ps_fx_png.render_effects(content, style)
    assert out[20, 20, 2] < 0.2                     # still yellow (blue stays low); Normal made it ~0.9


def test_kinds_and_subsets():
    params = {"opacity": 100, "stroke": {"enabled": True}, "inner_glow": {"enabled": False},
              "drop_shadow": [{"enabled": False}, {"enabled": True}]}
    assert rt.kinds_in(params) == ["drop_shadow", "stroke"]
    sub = rt.subset_style({"fx_base_size": 207, "effects_block": {"hex": "00"}}, params, "stroke")
    assert sub["captured_params"] == {"opacity": 100, "stroke": {"enabled": True}, "source": "descriptor"}
    assert "effects_block" not in sub and sub["fx_base_size"] == 207


def test_compare_counts_heavier_ink():
    a = Image.new("RGBA", (20, 20), (0, 0, 0, 0))
    a.paste((255, 255, 255, 255), (5, 5, 15, 15))
    b = Image.new("RGBA", (20, 20), (0, 0, 0, 0))
    b.paste((255, 255, 255, 255), (5, 5, 16, 15))
    assert rt.compare(a, a)["mean"] == 0
    st = rt.compare(a, b)
    assert st["ink_diff_pct"] == 10.0 and st["bad_pct"] > 0


def test_run_lines_the_renders_up(monkeypatch, tmp_path):
    """Without Photoshop: its renders replaced by the tool's own, moved — the run lines them up and finds no difference."""
    style = {"captured_params": {"stroke": {"enabled": True, "size": 3, "color": [200, 40, 0]}}}

    def fake_ps(work, font_ps, size, text, rgb_hex, hex4, light, canvas, origin, kinds, kerning="metrics"):
        files = {}
        for name, st in [("plain", None), ("all", style)] + [(k, rt.subset_style(style, style["captured_params"], k)) for k in kinds]:
            img = rt.shift(rt.tool_text("Arial", size, text, (255, 255, 255), st, canvas, (origin[0], origin[1] - size)), 3, 2)
            files[name] = os.path.join(work, name + ".png")
            img.save(files[name])
        return files, "fake"

    monkeypatch.setattr(rt, "photoshop_text", fake_ps)
    monkeypatch.setattr(fx_verify, "descriptor_hex4", lambda s: "0001")
    res = rt.run(style, "Arial", 60, "AB", out_dir=str(tmp_path))
    assert res["offset"] == (3, 2)
    assert all(row["mean"] < 0.01 for row in res["rows"].values()), res["rows"]
    assert set(res["rows"]) == {"plain", "all", "stroke"}


@pytest.mark.skipif(os.environ.get("PSH_PHOTOSHOP_TESTS") != "1", reason="needs Photoshop (PSH_PHOTOSHOP_TESTS=1)")
def test_photoshop_text_layer_matches_the_build(tmp_path):
    """A real Photoshop type layer with a gradient, strokes, shadows and an Overlay inner glow vs the build."""
    import json

    cfg = json.load(open(os.path.expanduser("~/PsHelpScreenTool_Web_Session.json"), encoding="utf-8"))
    ds = cfg.get("dynamic_settings") or {}
    name = (ds.get("style_assignments") or {}).get("Heading text")
    style = (ds.get("layer_style_library") or {}).get(name)
    if not style:
        pytest.skip("no heading style in the session")
    from ps_autotypesetter.ui_web import engine_api

    font = engine_api._font_request(cfg.get("h_font") or "Arial", cfg.get("h_font_style") or "")
    res = rt.run(style, font, int(float(cfg.get("h_size") or 120)), "GAME RULES", out_dir=str(tmp_path))
    assert res["rows"]["plain"]["mean"] < 3 and abs(res["rows"]["plain"]["ink_diff_pct"]) < 1.5
    assert res["rows"]["all"]["mean"] < 6, res["rows"]
