"""Game Rules / Bingo Rules pages as canonical PageLayouts (rules_layout.py): the renderer's own lines,
keyed by Excel cell, drawn by the Canvas like every other page; the decor picture holds no text.

Pages are rendered in memory (no output folder is touched)."""

import os

import pytest
from openpyxl import Workbook, load_workbook

from ps_autotypesetter import png_builder, rules_layout, text_edits

REF = r"E:\Work\ClaudeCode\DataForHelpScreenTool\Jactpot-carn-help\JackpotCarnivalBuffalo_GameRules_NYL.xlsm"


def _render(ws, name, ds, report):
    Image, ImageDraw, ImageFont = png_builder._require_pillow()
    args = (Image, ImageDraw, ImageFont, ws, name, "", "stretch", "#FFFFFF", 1920, 1080,
            "Arial", 72, 48, "#FF5050", "Arial", 30, 24, "#101010", 100, 120, 40, 80, 4, 12,
            "", {}, {}, ds, {})
    fn = png_builder._render_bingo_rules_png_pages if name.startswith("BINGO") else png_builder._render_game_rules_png_pages
    return fn(*args, report=report)


def _payload(ws, name, ds=None):
    kind = "bingo_rules" if name.startswith("BINGO") else "game_rules"
    return rules_layout.layout_payload(lambda rep: (_render(ws, name, ds or {}, rep), name), kind, name)


@pytest.fixture(scope="module")
def rules_ws():
    if not os.path.isfile(REF):
        pytest.skip("reference workbook not available")
    wb = load_workbook(REF, read_only=False)
    name = next(n for n in wb.sheetnames if png_builder._normalized_sheet_kind(n) == "game_rules")
    return wb[name], name


def _bingo_ws():
    wb = Workbook()
    ws = wb.active
    ws.title = "BINGO RULES"
    ws["B2"] = "BINGO RULES"
    ws["B4"] = "Left cell"
    ws["C4"] = "Right cell"
    ws["B6"] = "A long bingo rule that is just a sentence of plain text."
    return ws


def _lines(payload):
    return [e for e in payload["layouts"][0]["elements"] if e["type"] == "text" and e["meta"].get("kind") == "body"]


def test_game_rules_one_page_lines_match_report(rules_ws):
    ws, name = rules_ws
    p = _payload(ws, name)
    assert p["ok"] and p["mode"] == "canonical" and len(p["layouts"]) == 1
    rep = p["rules"]["report"]
    lines = _lines(p)
    # one element per drawn line, in the report's order, at the report's place
    assert [e["wrapped_lines"][0] for e in lines] and len(lines) == len(rep["lines"])
    for e, r in zip(lines, rep["lines"]):
        assert e["meta"]["cell"] == r["cell"] and e["meta"]["key"] == r["cell"]
        assert e["meta"]["part"] == r["part"] and e["meta"]["rules"] == "game_rules"
        assert e["meta"]["row"] == int("".join(c for c in r["cell"] if c.isdigit()))
        # the rect is the line's ink box; the element is its line box (drawn at its y)
        assert e["y"] <= r["rect"][1] + 0.6 and e["y"] + e["height"] >= r["rect"][1] + r["rect"][3] - 0.6
    heading = [e for e in p["layouts"][0]["elements"] if e["meta"].get("kind") == "heading"]
    assert len(heading) == 1 and heading[0]["wrapped_lines"]


def test_game_rules_line_text_is_the_cells_text(rules_ws):
    ws, name = rules_ws
    p = _payload(ws, name)
    norm = lambda s: "".join(str(s).split())
    for e in _lines(p):
        assert norm(e["wrapped_lines"][0].split("~")[0].replace("<", "")) [:3] in norm(e["text"]).replace("<", "")


def test_decor_picture_has_no_text_and_drawn_page_unchanged(rules_ws):
    ws, name = rules_ws
    rep = {}
    with png_builder.line_sink(skip_text=True) as rec:
        decor = _render(ws, name, {}, rep)[0]
    assert rec["lines"]
    # nothing drawn where the text lines are (transparent), the background is not drawn either
    assert decor.getpixel((5, 5))[3] == 0
    for r in rep["lines"][:5]:
        x, y, w, h = [int(v) for v in r["rect"]]
        assert decor.crop((x, y, x + w, y + h)).getextrema()[3][1] == 0
    # outside a sink the page is drawn as always
    page = _render(ws, name, {}, {})[0]
    assert page.getpixel((5, 5))[3] == 255


def test_own_align_and_style_keys(rules_ws):
    ws, name = rules_ws
    p = _payload(ws, name, {"game_rules_body_align": "left", "game_rules_body_font_style": "bold"})
    rules = [e for e in _lines(p) if e["meta"]["part"] == "rules"]
    assert rules and all(e["align"] == "left" for e in rules)
    assert all(e["font"].endswith("Bold") for e in rules)
    legal = [e for e in _lines(p) if e["meta"]["part"] == "legal"]
    assert all(not e["font"].endswith("Bold") for e in legal)


def test_draft_edit_by_cell_relayouts(rules_ws):
    ws, name = rules_ws
    first = _lines(_payload(ws, name))[0]
    cell, text = first["meta"]["cell"], first["text"]
    edit = {name: {cell: {"from": text, "to": "ALPHA\n\nBETA"}}}
    with text_edits.draft(edit):
        lines = [e for e in _lines(_payload(ws, name)) if e["meta"]["cell"] == cell]
    assert [e["wrapped_lines"][0] for e in lines] == ["ALPHA", "BETA"]
    assert lines[1].get("meta", {}).get("blank_above")          # the empty line: a caret place


def test_bingo_cells_grid():
    ws = _bingo_ws()
    p = _payload(ws, "BINGO RULES", {"bingo_rules_right_align_cells": "BINGO RULES=C4"})
    lines = _lines(p)
    cells = {e["meta"]["cell"] for e in lines}
    assert {"B4", "C4", "B6"} <= cells
    assert all(e["meta"]["rules"] == "bingo_rules" and e["meta"]["part"] == "bingo" for e in lines)
    b4 = next(e for e in lines if e["meta"]["cell"] == "B4")
    c4 = next(e for e in lines if e["meta"]["cell"] == "C4")
    assert b4["y"] == pytest.approx(c4["y"], abs=1)


def test_adapter_leaves_rules_sheets_to_their_renderer(tmp_path):
    from ps_autotypesetter import live_layout_adapter

    wb = Workbook()
    wb.active.title = "GAME RULES"
    wb.active["B2"] = "GAME RULES"
    wb.active["B4"] = "Some rule."
    path = tmp_path / "g.xlsx"
    wb.save(path)
    assert live_layout_adapter.build_sheet_layouts_from_cfg({"excel_path": str(path)}, "GAME RULES") is None


def test_fit_cache_gives_the_same_page(rules_ws):
    ws, name = rules_ws
    png_builder._GR_FIT_CACHE.clear()
    cold = {}
    _render(ws, name, {"game_rules_body_size": 90}, cold)
    warm = {}
    _render(ws, name, {"game_rules_body_size": 90}, warm)     # every line's heights from the cache now
    assert png_builder._GR_FIT_CACHE
    assert cold["fit"] == warm["fit"] and cold["lines"] == warm["lines"]
    # a typed line is measured again: the page fits it as a fresh render would
    first = cold["lines"][0]
    edit = {name: {first["cell"]: {"from": cold["cells"][first["cell"]], "to": "A much longer line " * 30}}}
    with text_edits.draft(edit):
        typed = {}
        _render(ws, name, {"game_rules_body_size": 90}, typed)
        png_builder._GR_FIT_CACHE.clear()
        fresh = {}
        _render(ws, name, {"game_rules_body_size": 90}, fresh)
    assert typed["fit"] == fresh["fit"] < cold["fit"] and typed["lines"] == fresh["lines"]


def test_decor_picture_cropped_and_reused(rules_ws, tmp_path):
    ws, name = rules_ws
    tokens = []

    def register(path):
        tokens.append(path)
        return f"t{len(set(tokens))}"

    a = rules_layout.layout_payload(lambda rep: (_render(ws, name, {}, rep), name), "game_rules", name, register_preview=register)
    b = rules_layout.layout_payload(lambda rep: (_render(ws, name, {}, rep), name), "game_rules", name, register_preview=register)
    pa = next(e for e in a["layouts"][0]["elements"] if e["type"] == "image")
    pb = next(e for e in b["layouts"][0]["elements"] if e["type"] == "image")
    assert pa["meta"]["url"] == pb["meta"]["url"] and tokens[0] == tokens[1]      # the same picture: the same file
    assert pa["width"] < 3840 or pa["height"] < 2160 or pa["y"] > 0                  # only where something is drawn
    sep = a["rules"]["report"]["separator"]
    if sep:
        assert pa["y"] <= sep[1] and pa["y"] + pa["height"] >= sep[1] + sep[3]


def test_bingo_without_decor_has_no_picture():
    ws = _bingo_ws()
    p = rules_layout.layout_payload(lambda rep: (_render(ws, "BINGO RULES", {}, rep), "BINGO RULES"), "bingo_rules",
                                    "BINGO RULES", register_preview=lambda path: "t1")
    assert not [e for e in p["layouts"][0]["elements"] if e["type"] == "image"]
