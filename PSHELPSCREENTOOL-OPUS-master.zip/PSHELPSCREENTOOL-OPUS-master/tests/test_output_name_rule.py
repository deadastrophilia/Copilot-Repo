"""Build output-naming rule: a user-typed PSD name (Project → PSD name) must
always be honored — even in update mode with "Overwrite in place" selected,
the build must land with the typed name instead of writing back over the
Old PSD."""

import ps_autotypesetter.build_engine as be
from ps_autotypesetter.psd_writer import build as psd_build
from ps_autotypesetter.ui_web import engine_api


def _run(config):
    """Capture the kwargs run_build hands to whichever PSD engine is active."""
    captured = {}
    orig_com, orig_psd = be.execute_build, psd_build.build_psd
    be.execute_build = lambda **kw: captured.update(kw) or None
    psd_build.build_psd = lambda **kw: captured.update(kw) or None
    try:
        engine_api.run_build(config, "psd")
    finally:
        be.execute_build, psd_build.build_psd = orig_com, orig_psd
    return captured


def test_typed_name_wins_over_update_overwrite():
    captured = _run({
        "excel_path": r"E:\Work\AGR\For Demo\ALL PAGES - New.xlsx",
        "output_name": "MyNigga",
        "output_dir": r"E:\Work\AGR\For Demo\Output",
        "update_mode": True,
        "update_save_mode": "overwrite",
        "prev_psd_path": r"Z:\nope\NOTEXIST.psd",
    })
    assert captured.get("overwrite_existing") is False


def test_empty_name_keeps_update_overwrite():
    captured = _run({
        "excel_path": "x.xlsx",
        "output_name": "",
        "update_mode": True,
        "update_save_mode": "overwrite",
        "prev_psd_path": "old.psd",
    })
    assert captured.get("overwrite_existing") is True


def test_new_copy_never_overwrites():
    captured = _run({
        "excel_path": "x.xlsx",
        "output_name": "Fresh",
        "update_mode": True,
        "update_save_mode": "new_copy",
        "prev_psd_path": "old.psd",
    })
    assert captured.get("overwrite_existing") is False


def test_normal_build_keeps_user_overwrite_toggle():
    captured = _run({
        "excel_path": "x.xlsx",
        "output_name": "N",
        "overwrite_existing": True,
        "prev_psd_path": "old.psd",
    })
    assert captured.get("overwrite_existing") is True