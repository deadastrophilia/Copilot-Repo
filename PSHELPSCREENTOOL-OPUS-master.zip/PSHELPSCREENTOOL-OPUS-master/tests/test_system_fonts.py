"""Font dropdown must list only REAL installed system font families (the
names Photoshop's menus show), read from the font files themselves -- never
registry/PostScript aliases like "Arial MT" that Photoshop cannot apply."""

import os

from ps_autotypesetter.ui_web import paytable_style_common as style
from ps_autotypesetter.ui_web.ps_actions import list_system_fonts


def _win_fonts_dir():
    return os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts")


def test_read_font_meta_arial():
    path = os.path.join(_win_fonts_dir(), "arial.ttf")
    meta = style._read_font_meta(path)
    assert meta and meta[0] == "Arial"
    assert meta[1]  # style present


def test_family_names_from_real_files():
    fonts = style.system_font_list()
    assert isinstance(fonts, list) and len(fonts) >= 40
    assert "Arial" in fonts
    assert "Times New Roman" in fonts
    assert "Segoe UI" in fonts
    # PostScript/registry aliases that Photoshop menus do not show must
    # never appear in the dropdown
    assert "ArialMT" not in fonts
    assert "Arial MT" not in fonts
    assert "TimesNewRomanPSMT" not in fonts


def test_iconish_faces_excluded():
    fonts = style.system_font_list()
    for bad in ("Wingdings", "Webdings", "Symbol", "Segoe MDL2 Assets",
                "Segoe UI Symbol", "Marlett", "Segoe UI Emoji"):
        assert bad not in fonts


def test_list_deduped_and_sorted():
    fonts = list_system_fonts()
    lowered = [f.lower() for f in fonts]
    assert len(lowered) == len(set(lowered))
    assert fonts == sorted(fonts)


def test_ps_font_name_mapping():
    assert style.ps_font_name("Arial") == "ArialMT"
    assert style.ps_font_name("Times New Roman") == "TimesNewRomanPSMT"
    assert style.ps_font_name("Arial Bold") == "ArialMT"
    assert style.ps_font_name("Consolas") == "Consolas"
    assert style.ps_font_name("Courier New") == "CourierNewPSMT"
    # unknown families pass through unchanged (PS live-resolves them)
    assert style.ps_font_name("AMS Anaram2") == "AMS Anaram2"
    assert style.ps_font_name("") == ""


def test_family_names_resolve_to_files():
    from ps_autotypesetter.ui_web.ps_actions import _resolve_font_file

    arial_path = _resolve_font_file("Arial")
    assert arial_path and os.path.basename(arial_path).lower() in (
        "arial.ttf", "arialbd.ttf")
    times_path = _resolve_font_file("Times New Roman")
    assert times_path and os.path.basename(times_path).lower() == "times.ttf"


def test_system_font_candidates_all_parse():
    cands = style._font_file_candidates()
    assert len(cands) >= 40  # a stock Windows install has 100+ font files
    failed = [c for c in cands if style._read_font_meta(c) is None]
    assert not failed, f"unparseable font files: {failed}"