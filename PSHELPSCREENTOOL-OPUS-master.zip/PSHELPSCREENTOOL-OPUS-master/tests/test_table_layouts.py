"""A table's own sizes from the Tables preview handles (png_builder._draw_auto_table + table_layouts)."""
import os

import pytest
from openpyxl import Workbook
from PIL import Image, ImageDraw, ImageFont

from ps_autotypesetter import png_builder as pb
from ps_autotypesetter import table_designs as td


def _table(tmp_path, rows=(("Symbol", "Pays"), ("<WILD> Wild", "500"), ("Cherry", "20"), ("Bell", "10"))):
    wb = Workbook()
    ws = wb.active
    ws.title = "Rules"
    for r, row in enumerate(rows, start=2):
        for c, v in enumerate(row, start=2):
            ws.cell(r, c, v)
    cells = [{"row": r, "col": c, "value": v, "role": "header" if r == 2 else "body", "rowspan": 1, "colspan": 1}
             for r, row in enumerate(rows, start=2) for c, v in enumerate(row, start=2)]
    key = td.table_key("Rules", " | ".join(rows[0]))
    return ws, {"start_row": 2, "end_row": 1 + len(rows), "min_col": 2, "max_col": 3, "grid_cells": cells,
                "design_key": key, "design": "current"}, key


def _draw(ws, table, lay=None, icon_folder=""):
    ts = {"table_layouts": {table["design_key"]: lay}} if lay else {}
    img = Image.new("RGBA", (1600, 1000))
    geo = {}
    h = pb._draw_auto_table(img, ImageDraw.Draw(img), Image, ImageFont, ws, table, 100, 0, 1400, ts,
                            icon_folder, {}, {}, available_height=950, geo=geo)
    return h, geo


def test_corner_handles_scale_the_table_and_everything_in_it(tmp_path):
    ws, t, _k = _table(tmp_path)
    h1, g1 = _draw(ws, t)
    h2, g2 = _draw(ws, t, {"scale": 1.5})
    assert g2["body_size"] == round(g1["body_size"] * 1.5) and g2["header_size"] == round(g1["header_size"] * 1.5)
    assert sum(g2["cols"]) > sum(g1["cols"]) * 1.3 and h2 > h1 * 1.3


def test_side_handles_widen_the_columns_but_never_the_text(tmp_path):
    ws, t, _k = _table(tmp_path)
    _h, g1 = _draw(ws, t)
    _h, g2 = _draw(ws, t, {"width": 900})
    assert sum(g2["cols"]) == pytest.approx(900, abs=2) and g2["body_size"] == g1["body_size"]


def test_a_column_divider_sets_each_columns_share(tmp_path):
    ws, t, _k = _table(tmp_path)
    _h, g = _draw(ws, t, {"width": 800, "cols": [0.75, 0.25]})
    assert g["cols"][0] == pytest.approx(600, abs=2) and g["cols"][1] == pytest.approx(200, abs=2)


def test_row_lines_and_the_bottom_handle_give_rows_room_never_less_than_their_content(tmp_path):
    ws, t, _k = _table(tmp_path)
    h1, g1 = _draw(ws, t)
    _h, g2 = _draw(ws, t, {"row_h": [0, 120]})
    assert g2["rows"][1] == 120 and g2["rows"][0] == g1["rows"][0]
    _h, g3 = _draw(ws, t, {"row_h": [0, 2]})
    assert g3["rows"][1] == g1["rows"][1]                                   # content is never squashed
    h4, _g = _draw(ws, t, {"height": h1 + 200})
    assert h4 == pytest.approx(h1 + 200, abs=len(g1["rows"]))


def test_symbols_in_a_table_get_their_own_size_and_rows_follow(tmp_path):
    folder = tmp_path / "icons"
    folder.mkdir()
    Image.new("RGBA", (64, 64), (255, 0, 0, 255)).save(folder / "WILD.png")
    ws, t, _k = _table(tmp_path)
    _h, g1 = _draw(ws, t, None, str(folder))
    _h, g2 = _draw(ws, t, {"icon_scale": 250}, str(folder))
    assert g2["icon_h"] == round(g1["icon_h"] * 2.5) and g2["rows"][1] > g1["rows"][1]


def test_a_tables_own_text_colour(tmp_path):
    ws, t, _k = _table(tmp_path)
    img = Image.new("RGBA", (1600, 1000))
    ts = {"render_mode": "stroke", "table_layouts": {t["design_key"]: {"body": {"color": "#00FF00"}}}}
    pb._draw_auto_table(img, ImageDraw.Draw(img), Image, ImageFont, ws, t, 100, 0, 1400, ts, "", {}, {}, available_height=950)
    greens = sum(1 for r, g, b, a in img.getdata() if a > 200 and g > 200 and r < 80 and b < 80)
    assert greens > 50


def test_a_merged_header_keeps_its_full_height(tmp_path):
    ws, t, _k = _table(tmp_path)
    for c in t["grid_cells"]:
        if c["role"] == "header":
            c["rowspan"] = 2                                 # merged over an empty Excel row the table skips
        else:
            c["row"] += 1
    _h, g = _draw(ws, t)
    assert g["rows"][0] >= g["header_size"]


def _px(img, x, y):
    return img.getpixel((int(x), int(y)))[:3]


def test_one_box_gets_its_own_fill_border_and_text_and_no_other_box_changes(tmp_path):
    ws, t, key = _table(tmp_path)
    ts = {"render_mode": "fill", "row1_bg_rgb": "#202020", "row2_bg_rgb": "#202020", "header_bg_rgb": "#202020",
          "table_layouts": {key: {"cells": {"2,1": {"fill": "#FF0000", "border": "#00FF00", "border_width": 4,
                                                    "size": 60, "color": "#0000FF"}}}}}
    img = Image.new("RGBA", (1600, 1000))
    geo = {}
    pb._draw_auto_table(img, ImageDraw.Draw(img), Image, ImageFont, ws, t, 100, 0, 1400, ts, "", {}, {},
                        available_height=950, geo=geo)
    x0 = geo["x"]
    ys = [sum(geo["rows"][:i]) for i in range(len(geo["rows"]) + 1)]
    xs = [x0 + sum(geo["cols"][:i]) for i in range(len(geo["cols"]) + 1)]
    inside = (xs[1] + 6, ys[2] + 6)                                    # box row 2, column 1, near its corner
    assert _px(img, *inside) == (255, 0, 0)
    assert _px(img, xs[1] + 1, (ys[2] + ys[3]) / 2) == (0, 255, 0)     # its border
    assert _px(img, xs[0] + 6, ys[2] + 6) == (32, 32, 32)              # the box beside it: untouched
    assert _px(img, xs[1] + 6, ys[3] + 6) == (32, 32, 32)              # the box below it: untouched
    blues = sum(1 for r, g, b, a in img.crop((int(xs[1]), int(ys[2]), int(xs[2]), int(ys[3]))).getdata() if b > 200 and r < 60 and g < 60)
    assert blues > 100                                                 # its own text colour
    _h, plain = _draw(ws, t)
    assert geo["rows"][2] > plain["rows"][2]                           # its bigger text: the row makes room


def test_a_box_border_on_some_sides_only(tmp_path):
    ws, t, key = _table(tmp_path)
    ts = {"render_mode": "fill", "row1_bg_rgb": "#202020", "row2_bg_rgb": "#202020", "header_bg_rgb": "#202020",
          "table_layouts": {key: {"cells": {"2,1": {"border": "#00FF00", "border_width": 4, "border_sides": "b"}}}}}
    img = Image.new("RGBA", (1600, 1000))
    geo = {}
    pb._draw_auto_table(img, ImageDraw.Draw(img), Image, ImageFont, ws, t, 100, 0, 1400, ts, "", {}, {},
                        available_height=950, geo=geo)
    x0 = geo["x"]
    ys = [sum(geo["rows"][:i]) for i in range(len(geo["rows"]) + 1)]
    xs = [x0 + sum(geo["cols"][:i]) for i in range(len(geo["cols"]) + 1)]
    mid_x = (xs[1] + xs[2]) / 2
    assert _px(img, mid_x, ys[3] - 2) == (0, 255, 0)                   # its bottom side
    assert _px(img, mid_x, ys[2] + 1) != (0, 255, 0)                   # not its top
    assert _px(img, xs[1] + 1, (ys[2] + ys[3]) / 2) != (0, 255, 0)     # nor its left
    assert geo["looks"]["2,1"]["border_sides"] == "b"                  # the Cell bar reads it back


def test_a_deleted_box_draws_empty_and_the_others_keep_their_text(tmp_path):
    ws, t, key = _table(tmp_path)
    ts = {"render_mode": "fill", "row1_bg_rgb": "#202020", "row2_bg_rgb": "#202020", "header_bg_rgb": "#202020",
          "table_body_text_rgb": "#FFFFFF"}
    def ink(layouts):
        img = Image.new("RGBA", (1600, 1000))
        geo = {}
        pb._draw_auto_table(img, ImageDraw.Draw(img), Image, ImageFont, ws, t, 100, 0, 1400, dict(ts, table_layouts=layouts),
                            "", {}, {}, available_height=950, geo=geo)
        x0, ys = geo["x"], [sum(geo["rows"][:i]) for i in range(len(geo["rows"]) + 1)]
        xs = [x0 + sum(geo["cols"][:i]) for i in range(len(geo["cols"]) + 1)]
        box = lambda r, c: sum(1 for x in range(int(xs[c]) + 4, int(xs[c + 1]) - 4, 2) for y in range(int(ys[r]) + 4, int(ys[r + 1]) - 4, 2)  # noqa: E731
                               if _px(img, x, y)[0] > 200)
        return box(2, 1), box(2, 0)
    full = ink({})
    cleared = ink({key: {"cells": {"2,1": {"clear": True}}}})
    assert full[0] > 0 and cleared[0] == 0                              # its text gone, the box still drawn
    assert cleared[1] == full[1]                                        # its neighbour untouched


def test_box_positions_are_reported_with_their_spans(tmp_path):
    ws, t, _k = _table(tmp_path)
    t["grid_cells"][0]["colspan"] = 2
    t["grid_cells"] = [c for c in t["grid_cells"] if not (c["row"] == 2 and c["col"] == 3)]
    _h, g = _draw(ws, t)
    assert [0, 0, 1, 2] in g["cells"] and [1, 1, 1, 1] in g["cells"]


# ── Excel's own colours and lines, and a table's own lines on any design ──────────────
def test_theme_colours_with_a_tint_are_read_like_excel_shows_them():
    from openpyxl.styles import PatternFill
    from openpyxl.styles.colors import Color

    from ps_autotypesetter.excel_utils import get_excel_fill_color

    wb = Workbook()
    ws = wb.active
    ws["A1"].fill = PatternFill("solid", fgColor=Color(theme=8, tint=0.3999755859375))   # accent5, lighter 40 %
    ws["A2"].fill = PatternFill("solid", fgColor=Color(theme=1))                          # dk1
    r, g, b = get_excel_fill_color(ws["A1"])
    assert b > r and b > 200 and r > 120                                # a light blue, not white
    assert get_excel_fill_color(ws["A2"]) == (0, 0, 0)


def _lined(tmp_path, lay=None, design="current", border=False):
    from openpyxl.styles import Border, Side

    ws, t, key = _table(tmp_path)
    if border:
        thin = Side(style="thin", color="FF000000")
        for row in ws.iter_rows(min_row=2, max_row=5, min_col=2, max_col=3):
            for c in row:
                c.border = Border(left=thin, right=thin, top=thin, bottom=thin)
    t["design"] = design
    if design == "excel":
        t.update(use_excel_fill_colors=True, use_excel_font_colors=True, excel_blank_white=True)
    ts = {"render_mode": "fill", "header_bg_rgb": "#202020", "row1_bg_rgb": "#202020", "row2_bg_rgb": "#202020"}
    if lay:
        ts["table_layouts"] = {key: lay}
    img = Image.new("RGBA", (1600, 1000), (60, 60, 60, 255))
    geo = {}
    pb._draw_auto_table(img, ImageDraw.Draw(img), Image, ImageFont, ws, t, 100, 0, 1400, ts, "", {}, {},
                        available_height=950, geo=geo)
    return img, geo


def _count(img, rgb, tol=40):
    return sum(1 for p in img.getdata() if all(abs(p[i] - rgb[i]) <= tol for i in range(3)))


def test_like_excel_draws_excels_own_borders(tmp_path):
    with_lines, _g = _lined(tmp_path, design="excel", border=True)
    without, _g = _lined(tmp_path, design="excel", border=False)
    assert _count(with_lines, (0, 0, 0), 30) > _count(without, (0, 0, 0), 30) + 300


def test_every_box_lines_and_a_border_around_the_table_on_any_design(tmp_path):
    img, geo = _lined(tmp_path, {"lines": "all", "line_color": "#00FF00", "line_width": 2,
                                 "outer": {"color": "#FF00FF", "width": 6}}, design="excel")
    assert _count(img, (0, 255, 0), 30) > 300                         # the lines between the boxes
    x0 = int(geo["x"])
    assert img.getpixel((x0 + 2, 40))[:3] == (255, 0, 255)            # the border around the table
    none, _g = _lined(tmp_path, {"lines": "none"}, design="excel", border=True)
    bare, _g = _lined(tmp_path, design="excel", border=False)
    assert abs(_count(none, (0, 0, 0), 30) - _count(bare, (0, 0, 0), 30)) < 50   # Excel's borders off too


def test_a_layer_style_on_the_tables_lines(tmp_path):
    from ps_autotypesetter import text_styles

    lib = {"Glow": {"stroke_enabled": True, "stroke_rgb": "#FF0000", "stroke_size": 3, "stroke_opacity": 100}}
    with text_styles.active([], "Rules", lib):
        img, _g = _lined(tmp_path, {"lines": "all", "line_color": "#FFFFFF", "line_width": 2, "lines_fx": "Glow"})
    assert _count(img, (255, 0, 0), 40) > 300


def test_a_tables_own_colours_over_its_design(tmp_path):
    img, geo = _lined(tmp_path, {"style": {"header_bg_rgb": "#0000FF"}}, design="midnight")
    x0 = int(geo["x"])
    assert img.getpixel((x0 + 8, 6))[:3] == (0, 0, 255)


# ── styles for many boxes at once (Canvas Cell bar): whole table, header, body, a row, a column ──────
def _fills(tmp_path, lay, row_slice=None):
    ws, t, key = _table(tmp_path, rows=(("Symbol", "Pays"), ("A", "1"), ("B", "2"), ("C", "3"), ("D", "4")))
    ts = {"render_mode": "fill", "header_bg_rgb": "#202020", "row1_bg_rgb": "#202020", "row2_bg_rgb": "#202020",
          "table_layouts": {key: lay}}
    img = Image.new("RGBA", (1600, 1000))
    geo = {}
    pb._draw_auto_table(img, ImageDraw.Draw(img), Image, ImageFont, ws, t, 100, 0, 1400, ts, "", {}, {},
                        available_height=950, geo=geo, row_slice=row_slice)
    xs = [geo["x"] + sum(geo["cols"][:i]) for i in range(len(geo["cols"]) + 1)]
    ys = [sum(geo["rows"][:i]) + i * geo.get("row_gap", 0) for i in range(len(geo["rows"]) + 1)]
    return lambda r, c: _px(img, xs[c] + 5, ys[r] + 5)              # the fill near a box's top-left corner


def test_a_row_a_column_the_header_and_the_body_get_a_look_of_their_own(tmp_path):
    box = _fills(tmp_path, {"boxes": {"row:2": {"fill": "#FF0000"}, "col:1": {"fill": "#00FF00"}}})
    assert box(2, 0) == (255, 0, 0)                                    # row 2
    assert box(3, 1) == (0, 255, 0) and box(1, 1) == (0, 255, 0)       # column 1
    assert box(2, 1) == (255, 0, 0)                                    # where they meet: the row wins
    assert box(3, 0) == (32, 32, 32)                                   # the rest: untouched
    box = _fills(tmp_path, {"boxes": {"all": {"fill": "#0000FF"}, "header": {"fill": "#FFFF00"}},
                            "cells": {"3,0": {"fill": "#FF00FF"}}})
    assert box(0, 0) == (255, 255, 0) and box(0, 1) == (255, 255, 0)   # the header over the whole table
    assert box(1, 0) == (0, 0, 255) and box(4, 1) == (0, 0, 255)       # every other box
    assert box(3, 0) == (255, 0, 255)                                  # one box's own: last, over everything
    box = _fills(tmp_path, {"boxes": {"body": {"fill": "#00FFFF"}}})
    assert box(0, 0) == (32, 32, 32) and box(1, 0) == (0, 255, 255)    # body rows only


def test_a_cut_table_part_keeps_each_boxes_own_look(tmp_path):
    """A box styled on a later part of a split table: its key is its row in the WHOLE table."""
    # whole-table rows: 0 header, 1..4 body; the part with body rows 2..3 (whole-table rows 3 and 4)
    box = _fills(tmp_path, {"cells": {"3,0": {"fill": "#FF0000"}}, "boxes": {"row:4": {"fill": "#00FF00"}}}, row_slice=(2, 4))
    assert box(1, 0) == (255, 0, 0)                                    # the part's 1st body row = row 3
    assert box(2, 1) == (0, 255, 0)                                    # its 2nd = row 4
    assert box(0, 0) == (32, 32, 32)                                   # the header: untouched


def test_a_header_merged_over_a_skipped_row_spans_one_drawn_row(tmp_path):
    """A header merged in Excel with the empty row under it (the table skips that row): the box map the
    Canvas picks boxes from says one row, so the row under the header is its own box (Monopoly tables)."""
    ws, t, _k = _table(tmp_path)
    for c in t["grid_cells"]:
        if c["role"] == "header":
            c["rowspan"] = 2                                 # merged over an empty Excel row the table skips
        else:
            c["row"] += 1
    _h, g = _draw(ws, t)
    assert [0, 0, 1, 1] in g["cells"] and [0, 1, 1, 1] in g["cells"]    # header boxes: one drawn row
    assert [1, 0, 1, 1] in g["cells"]                                  # the first body row: its own box


def test_each_boxs_drawn_look_is_reported_for_copying(tmp_path):
    """Copying a box on the Canvas takes its look as drawn — a fill from the preset / Excel, not only
    what was set on the box (Monopoly's property colours come from the Excel)."""
    ws, t, key = _table(tmp_path)
    ts = {"render_mode": "fill", "header_bg_rgb": "#202020", "row1_bg_rgb": "#304050", "row2_bg_rgb": "#304050",
          "table_body_text_rgb": "#ffcc00",
          "table_layouts": {key: {"cells": {"2,1": {"fill": "#FF0000", "bold": True}}}}}
    img = Image.new("RGBA", (1600, 1000))
    geo = {}
    pb._draw_auto_table(img, ImageDraw.Draw(img), Image, ImageFont, ws, t, 100, 0, 1400, ts, "", {}, {},
                        available_height=950, geo=geo)
    looks = geo["looks"]
    assert looks["1,0"]["fill"] == "#304050" and looks["1,0"]["align"]       # a body box: the preset's fill
    assert looks["2,1"]["fill"] == "#ff0000" and looks["2,1"]["bold"] is True  # a box's own setting
    assert looks["0,0"]["fill"] == "#202020"                                 # the header


# ── icon sizes in tables: this box, this table, every table; every icon of a table / of every table ──
def _icon_sizes(tmp_path, ts_extra, lay=None):
    from PIL import Image as _Im
    folder = tmp_path / "icons"
    folder.mkdir(exist_ok=True)
    _Im.new("RGBA", (100, 100), (255, 0, 0, 255)).save(folder / "WILD.png")
    ws, t, key = _table(tmp_path, rows=(("Symbol", "Pays"), ("<WILD> Wild", "500"), ("<WILD> Wild", "20"), ("Bell", "10")))
    ts = dict({"render_mode": "fill", "table_icon_height": 40}, **ts_extra)
    if lay is not None:
        ts["table_layouts"] = {key: lay}
    img = Image.new("RGBA", (1600, 1000))
    geo = {}
    pb._draw_auto_table(img, ImageDraw.Draw(img), Image, ImageFont, ws, t, 100, 0, 1400, ts, str(folder), {}, {},
                        available_height=950, geo=geo)
    return {(i["cell"], i["tok"]): i["rect"][3] for i in geo["icons"]}


def test_table_icons_are_reported_where_they_are_drawn(tmp_path):
    got = _icon_sizes(tmp_path, {})
    assert set(got) == {("1,0", "WILD"), ("2,0", "WILD")} and all(h == 40 for h in got.values())


def test_one_icon_sized_in_its_box_in_its_table_or_in_every_table(tmp_path):
    assert _icon_sizes(tmp_path, {}, {"cells": {"1,0": {"icons": {"WILD": 150}}}}) == {("1,0", "WILD"): 60, ("2,0", "WILD"): 40}
    assert set(_icon_sizes(tmp_path, {}, {"icons": {"WILD": 50}}).values()) == {20}
    assert set(_icon_sizes(tmp_path, {"table_icon_sizes": {"WILD": 200}}).values()) == {80}
    # the closest wins: this box over this table over every table
    got = _icon_sizes(tmp_path, {"table_icon_sizes": {"WILD": 200}}, {"icons": {"WILD": 50}, "cells": {"2,0": {"icons": {"WILD": 100 + 25}}}})
    assert got == {("1,0", "WILD"): 20, ("2,0", "WILD"): 50}


def test_every_icon_of_a_table_and_of_every_table(tmp_path):
    assert set(_icon_sizes(tmp_path, {}, {"icon_scale": 150}).values()) == {60}
    assert set(_icon_sizes(tmp_path, {"table_icon_scale": 50}).values()) == {20}


def test_a_column_whose_boxes_are_all_deleted_takes_no_room(tmp_path):
    ws, t, key = _table(tmp_path)
    def draw(layouts):
        img = Image.new("RGBA", (1600, 1000))
        geo = {}
        pb._draw_auto_table(img, ImageDraw.Draw(img), Image, ImageFont, ws, t, 100, 0, 1400,
                            {"render_mode": "fill", "row1_bg_rgb": "#202020", "table_layouts": layouts}, "", {}, {},
                            available_height=950, geo=geo)
        return geo
    full = draw({})
    gone = draw({key: {"boxes": {"col:1": {"clear": True}}}})
    assert full["cols"][1] > 0 and gone["cols"][1] == 0                  # nothing of it left, not even a sliver
    assert gone["cols"][0] == full["cols"][0]
    one = draw({key: {"cells": {"2,1": {"clear": True}}}})
    assert one["cols"][1] == full["cols"][1]                             # one box gone: its column stays


def _green_run(img, xs, y):
    """How many green pixels across, at row y, between xs[0] and xs[1]."""
    return sum(1 for x in range(int(xs[0]), int(xs[1])) if _px(img, x, y) == (0, 255, 0))


@pytest.mark.parametrize("w", [1, 3, 6])
def test_lines_between_boxes_are_as_wide_as_given_not_doubled(tmp_path, w):
    ws, t, key = _table(tmp_path)
    ts = {"render_mode": "stroke", "stroke_rgb": "#00FF00", "stroke_width": w}
    img = Image.new("RGBA", (1600, 1000))
    geo = {}
    pb._draw_auto_table(img, ImageDraw.Draw(img), Image, ImageFont, ws, t, 100, 0, 1400, ts, "", {}, {},
                        available_height=950, geo=geo)
    x0 = geo["x"]
    xs = [x0 + sum(geo["cols"][:i]) for i in range(len(geo["cols"]) + 1)]
    ys = [sum(geo["rows"][:i]) for i in range(len(geo["rows"]) + 1)]
    mid_y = (ys[1] + ys[2]) / 2
    assert _green_run(img, (xs[1] - 12, xs[1] + 12), mid_y) == w          # between two boxes: once
    assert _green_run(img, (xs[0] - 12, xs[0] + 12), mid_y) == w          # the table's outside edge: the same


def test_a_box_border_lies_over_the_shared_line(tmp_path):
    ws, t, key = _table(tmp_path)
    ts = {"render_mode": "stroke", "stroke_rgb": "#FFFFFF", "stroke_width": 2,
          "table_layouts": {key: {"cells": {"1,0": {"border": "#00FF00", "border_width": 4}}}}}
    img = Image.new("RGBA", (1600, 1000))
    geo = {}
    pb._draw_auto_table(img, ImageDraw.Draw(img), Image, ImageFont, ws, t, 100, 0, 1400, ts, "", {}, {},
                        available_height=950, geo=geo)
    xs = [geo["x"] + sum(geo["cols"][:i]) for i in range(len(geo["cols"]) + 1)]
    ys = [sum(geo["rows"][:i]) for i in range(len(geo["rows"]) + 1)]
    mid_y = (ys[1] + ys[2]) / 2
    run = [x for x in range(int(xs[1]) - 6, int(xs[1]) + 6) if _px(img, x, mid_y) != (0, 0, 0)]
    assert _green_run(img, (xs[1] - 6, xs[1] + 6), mid_y) == 4 and len(run) == 4     # one 4 px line, no white beside it


def test_table_icons_sized_in_px_are_drawn_at_that_height(tmp_path):
    assert _icon_sizes(tmp_path, {}, {"cells": {"1,0": {"icons_px": {"WILD": 63}}}}) == {("1,0", "WILD"): 63, ("2,0", "WILD"): 40}
    assert set(_icon_sizes(tmp_path, {}, {"icons_px": {"WILD": 22}}).values()) == {22}
    assert set(_icon_sizes(tmp_path, {"table_icon_sizes_px": {"WILD": 55}}).values()) == {55}
    assert set(_icon_sizes(tmp_path, {}, {"icon_px": 31}).values()) == {31}
    assert set(_icon_sizes(tmp_path, {"table_icon_px": 47}).values()) == {47}
    # the closest wins: this box (px) over this table over every table
    got = _icon_sizes(tmp_path, {"table_icon_sizes_px": {"WILD": 55}}, {"icons_px": {"WILD": 22}, "cells": {"2,0": {"icons_px": {"WILD": 70}}}})
    assert got == {("1,0", "WILD"): 22, ("2,0", "WILD"): 70}


def test_a_row_is_never_shorter_than_its_sized_icon(tmp_path):
    from PIL import Image as _Im
    folder = tmp_path / "icons"
    folder.mkdir(exist_ok=True)
    _Im.new("RGBA", (100, 100), (255, 0, 0, 255)).save(folder / "WILD.png")
    ws, t, key = _table(tmp_path, rows=(("Symbol", "Pays"), ("<WILD> Wild", "500"), ("Bell", "10")))
    img = Image.new("RGBA", (1600, 1000))
    geo = {}
    pb._draw_auto_table(img, ImageDraw.Draw(img), Image, ImageFont, ws, t, 100, 0, 1400,
                        {"render_mode": "stroke", "table_icon_height": 30, "table_layouts": {key: {"cells": {"1,0": {"icons_px": {"WILD": 120}}}}}},
                        str(folder), {}, {}, available_height=950, geo=geo)
    icon = geo["icons"][0]["rect"]
    assert icon[3] == 120 and geo["rows"][1] >= 120                       # the row holds it: it never overlaps the lines
