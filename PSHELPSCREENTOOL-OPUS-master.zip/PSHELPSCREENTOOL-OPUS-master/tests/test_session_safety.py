"""Session file safety: atomic writes, backups, recovery from a corrupt file."""
import json
import os

import pytest

from ps_autotypesetter import safe_json
from ps_autotypesetter.ui_web import engine_api


@pytest.fixture
def session(tmp_path):
    old = engine_api._SESSION_FILE
    path = str(tmp_path / "session.json")
    engine_api.set_session_file(path)
    yield path
    engine_api.set_session_file(old)


def test_write_json_leaves_no_temp_and_keeps_old_file_on_failure(tmp_path):
    path = str(tmp_path / "a.json")
    safe_json.write_json(path, {"v": 1})
    with pytest.raises(TypeError):
        safe_json.write_json(path, {"v": object()})          # not serialisable
    assert safe_json.read_json(path) == {"v": 1}             # old content intact
    assert os.listdir(tmp_path) == ["a.json"]                # no stray .tmp


def test_save_keeps_previous_and_snapshot(session):
    engine_api._save_config({"excel_path": "one.xlsx"})
    engine_api._save_config({"excel_path": "two.xlsx"})
    assert safe_json.read_json(session)["excel_path"] == "two.xlsx"
    assert safe_json.read_json(session + ".bak")["excel_path"] == "one.xlsx"
    backups = safe_json.list_backups(session)
    assert len(backups) == 1                                 # throttled: one per interval
    assert safe_json.read_json(backups[0])["excel_path"] == "one.xlsx"


def test_unchanged_config_is_not_rewritten(session):
    engine_api._save_config({"a": 1})
    before = os.stat(session).st_mtime_ns
    os.utime(session, ns=(before - 10**9, before - 10**9))
    engine_api._save_config({"a": 1})
    assert os.stat(session).st_mtime_ns == before - 10**9


def test_snapshot_prunes_oldest(tmp_path):
    path = str(tmp_path / "s.json")
    safe_json.write_json(path, {"a": 1})
    folder = safe_json.backup_dir(path)
    os.makedirs(folder)
    for i in range(5):
        with open(os.path.join(folder, f"s_20260101-00000{i}.json"), "w") as f:
            f.write("{}")
        os.utime(os.path.join(folder, f"s_20260101-00000{i}.json"), (0, 0))
    assert safe_json.snapshot(path, keep=3)
    names = [os.path.basename(p) for p in safe_json.list_backups(path)]
    assert len(names) == 3 and "s_20260101-000000.json" not in names


def test_corrupt_session_restores_from_bak_and_keeps_bad_file(session):
    engine_api._save_config({"excel_path": "good.xlsx"})
    engine_api._save_config({"excel_path": "newer.xlsx"})
    with open(session, "w", encoding="utf-8") as f:
        f.write('{"excel_path": "half')                      # truncated write
    cfg = engine_api._load_config()
    assert cfg["excel_path"] == "good.xlsx"
    assert "restored" in engine_api.session_note()
    folder = os.path.dirname(session)
    assert any(".corrupt-" in n for n in os.listdir(folder))
    assert not os.path.exists(session)                       # next save writes a fresh file


def test_corrupt_session_without_backups_falls_back_to_defaults(session):
    with open(session, "w", encoding="utf-8") as f:
        f.write("not json")
    cfg = engine_api._load_config()
    assert cfg == dict(engine_api.DEFAULT_CONFIG)
    assert "no backup" in engine_api.session_note()


def test_missing_session_is_quiet(session):
    engine_api._load_config()
    assert engine_api.session_note() == ""


def test_bootstrap_reports_recovery(tmp_path):
    from ps_autotypesetter.ui_web.server import create_app

    path = tmp_path / "session.json"
    (tmp_path / "session.json.bak").write_text(json.dumps({"excel_path": "x.xlsx"}), encoding="utf-8")
    path.write_text("{broken", encoding="utf-8")
    old = engine_api._SESSION_FILE
    try:
        data = create_app(session_file=str(path)).test_client().get("/api/bootstrap").get_json()
    finally:
        engine_api.set_session_file(old)
    assert data["config"]["excel_path"] == "x.xlsx"
    assert "restored" in data["session_note"]
