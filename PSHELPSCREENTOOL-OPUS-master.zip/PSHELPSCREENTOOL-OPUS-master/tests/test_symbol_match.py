"""Symbols from a PSD + the AGR it was made from (symbol_match.py): naming, matching, the saving rules."""

import os

from PIL import Image

from ps_autotypesetter import games, symbol_match
from ps_autotypesetter.ui_web import symbol_scan


def _pic(colour, size=(40, 40)):
    img = Image.new("RGBA", size, (0, 0, 0, 0))
    for x in range(4, size[0] - 4):
        for y in range(4 + (colour[0] % 7), size[1] - 4):
            img.putpixel((x, y), colour + (255,))
    return img


def _fake_scan(monkeypatch, pictures):
    """pictures: {key: (layer name, image)} as symbol_scan.scan would find them."""
    imgs = {k: img for k, (_n, img) in pictures.items()}
    syms = [{"key": k, "name": n, "w": img.width, "h": img.height, "count": 1, "pages": [], "hidden": False,
             "_sig": symbol_scan._signature(img)} for k, (n, img) in pictures.items()]
    result = {"symbols": syms, "backgrounds": [], "paylines": [], "others": [], "_images": imgs, "_thumbs": {}}
    monkeypatch.setattr(symbol_scan, "scan", lambda path: result)
    return result


def test_noise_tokens_are_not_symbols():
    for t in ('"&$H$49&"', "FEATURE NAME", "SYMBOL", "TRANSLATION OF SYMBOL", "X", "z", "", "=A1"):
        assert not symbol_match.is_symbol_token(t), t
    for t in ("SCAT", "WHITE WW", "A", "10", "COR_BLUE", "OVERLAYx2", "+1 GAME"):
        assert symbol_match.is_symbol_token(t), t


def test_match_prefers_the_agr_evidence_and_matches_this_games_tokens(monkeypatch, tmp_path):
    _fake_scan(monkeypatch, {"s0": ("Layer 1", _pic((200, 30, 30))), "s1": ("WOLF copy", _pic((30, 200, 30))),
                             "s2": ("ace symbol", _pic((30, 30, 200))), "s3": ("Layer 9", _pic((120, 120, 0)))})
    agr = tmp_path / "agr.xlsx"
    agr.write_bytes(b"x")
    # the AGR evidence named s0 SCAT (its pay card) and s1 SCAT too (a row) — the layer name WOLF must not
    # take a picture the evidence gave another symbol
    monkeypatch.setattr(symbol_match, "_named_by_agr",
                        lambda psd, a, pics, ss: ({"s0": {"SCAT": "card"}, "s1": {"BONUS": "row"}, "s3": {"MOON": "row"}}, {}))
    res = symbol_match.match("x.psd", ["SCAT", "BONUS", "WOLF", "A", '"&$H$49&"'], str(agr))
    rows = {r["token"]: r for r in res["rows"]}
    assert '"&$H$49&"' not in rows
    assert rows["SCAT"]["key"] == "s0" and rows["SCAT"]["confidence"] == "high"
    assert rows["BONUS"]["key"] == "s1" and rows["BONUS"]["how"] == "row"
    assert rows["WOLF"]["key"] is None                       # s1 is BONUS's, whatever its layer is called
    assert rows["A"]["key"] == "s2" and rows["A"]["confidence"] == "low"     # "ace symbol" layer
    assert res["not_in_game"] == ["MOON"]
    assert res["unused"] == ["s3"]


def test_royal_names_match_both_ways(monkeypatch, tmp_path):
    _fake_scan(monkeypatch, {"s0": ("Layer 1", _pic((200, 30, 30)))})
    agr = tmp_path / "agr.xlsx"
    agr.write_bytes(b"x")
    monkeypatch.setattr(symbol_match, "_named_by_agr", lambda psd, a, pics, ss: ({"s0": {"ACE": "row"}}, {}))
    rows = {r["token"]: r for r in symbol_match.match("x.psd", ["A"], str(agr))["rows"]}
    assert rows["A"]["key"] == "s0" and rows["A"]["agr_token"] == "ACE"


def test_one_png_per_token_reuse_and_ask(monkeypatch, tmp_path):
    red, blue = _pic((200, 30, 30)), _pic((30, 30, 200))
    _fake_scan(monkeypatch, {"s0": ("overlay", red), "s1": ("blue", blue)})
    folder = str(tmp_path / "Symbols")
    # two tokens, one picture: two files named after the tokens
    res = symbol_match.save("x.psd", [{"token": "OVERLAYx1", "key": "s0"}, {"token": "OVERLAYx2", "key": "s0"}], folder)
    assert sorted(os.listdir(folder)) == ["OVERLAYx1.png", "OVERLAYx2.png"] and res["saved"] == ["OVERLAYx1", "OVERLAYx2"]
    # the same picture again: reused, nothing written, no "_2" copy
    res = symbol_match.save("x.psd", [{"token": "OVERLAYx1", "key": "s0"}], folder)
    assert res["reused"] == ["OVERLAYx1"] and sorted(os.listdir(folder)) == ["OVERLAYx1.png", "OVERLAYx2.png"]
    # a different picture under a taken name: asked first, then replaced or kept
    res = symbol_match.save("x.psd", [{"token": "OVERLAYx1", "key": "s1"}], folder)
    assert [a["token"] for a in res["ask"]] == ["OVERLAYx1"] and not res["saved"]
    res = symbol_match.save("x.psd", [{"token": "OVERLAYx1", "key": "s1"}], folder, {"OVERLAYx1": "keep"})
    assert res["kept"] == ["OVERLAYx1"]
    res = symbol_match.save("x.psd", [{"token": "OVERLAYx1", "key": "s1"}], folder, {"OVERLAYx1": "replace"})
    assert res["saved"] == ["OVERLAYx1"] and sorted(os.listdir(folder)) == ["OVERLAYx1.png", "OVERLAYx2.png"]
    assert symbol_match.file_name("<SCAT/GRAND>") == "SCAT_GRAND.png"


def test_no_video_folder_gives_no_relative_working_folder():
    """A game folder without Production\\Video: "Working" relative to wherever the tool ran (JuCaiJin's
    symbols and PSDs landed in the tool's own folder)."""
    assert games.help_screen_paths("", "HHR") == ("", "", "")


def test_background_names_and_help_groups():
    """BG, Background, Help BG, help_bg, BG.png, "BG copy 21", a background group — and a group named only
    "Help" when it holds no text (a "Help" group with text is the help pages, not their background)."""
    from types import SimpleNamespace

    from ps_autotypesetter.psd_style_import import bg_name_strength

    for n in ("BG", "Help BG", "help_bg", "Background group", "BG.png", "BG copy 21", "Help BG Group", "backgrounds"):
        assert bg_name_strength(n) == 2, n
    assert bg_name_strength("Panel BG") == 1 and bg_name_strength("Symbols") == 0

    def group(*kinds):
        kids = [SimpleNamespace(kind=k) for k in kinds]
        return SimpleNamespace(is_group=lambda: True, descendants=lambda: kids)
    assert bg_name_strength("Help", group("pixel", "smartobject")) == 2
    assert bg_name_strength("Help", group("pixel", "type")) == 0
