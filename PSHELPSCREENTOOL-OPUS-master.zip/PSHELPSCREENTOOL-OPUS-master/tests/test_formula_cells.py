"""Formula cells read as what the sheet shows, never as their formula text (workbook_cache.formula_results).

The page builders open the workbook with data_only=False to read colours / bold / rich text; such a load
gives a formula cell's FORMULA as its value — =IF(Checklist!$B$321="x",Checklist!E321,"") was drawn on a
page whose cell shows nothing."""
from openpyxl import Workbook
from openpyxl.styles import Font

from ps_autotypesetter import workbook_cache


def _book(path):
    wb = Workbook()
    ws = wb.active
    ws.title = "Feature Upgrade"
    ws["B13"] = "If only JACKPOT FEATURE and DOUBLE FEATURE are triggered."
    ws["B13"].font = Font(color="FFFF0000", bold=True)
    ws["B15"] = '=IF(Checklist!$B$321="x",Checklist!E321,"")'       # saved without a result (never calculated)
    ws["B16"] = "SYMBOL UPGRADES FEATURE"
    wb.create_sheet("Checklist")["B321"] = ""
    wb.save(path)


def test_a_formula_cell_never_reads_as_its_formula(tmp_path):
    p = str(tmp_path / "rules.xlsx")
    _book(p)
    for wb in (workbook_cache.load_formatted(p),):
        ws = wb["Feature Upgrade"]
        assert ws["B15"].value is None                                   # no result saved: nothing
        assert ws["B16"].value == "SYMBOL UPGRADES FEATURE"               # plain cells as they are
        assert ws["B13"].font.color.rgb == "FFFF0000" and ws["B13"].font.bold   # the formatting kept
    workbook_cache.clear()
    with workbook_cache.borrow(p) as wb:                                 # the shared copy the builds use
        assert wb["Feature Upgrade"]["B15"].value is None
    with workbook_cache.borrow(p, data_only=True) as wb:
        assert wb["Feature Upgrade"]["B15"].value is None
    workbook_cache.clear()
