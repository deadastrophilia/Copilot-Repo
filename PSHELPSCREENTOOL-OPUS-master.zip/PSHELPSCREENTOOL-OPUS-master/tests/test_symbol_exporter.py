"""Tests for the Export Symbols feature (psd-tools layer list / preview / export)."""

import os

import pytest
from PIL import Image, ImageDraw

from psd_tools import PSDImage
from psd_tools.api.layers import PixelLayer

from ps_autotypesetter.ui_web import symbol_exporter


def _mk(color, box):
    img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    ImageDraw.Draw(img).rectangle(box, fill=color)
    return img


@pytest.fixture(scope="module")
def psd_file(tmp_path_factory):
    path = tmp_path_factory.mktemp("psd") / "icons.psd"
    psd = PSDImage.new("RGBA", (64, 64))
    psd.append(PixelLayer.frompil(_mk((255, 0, 0, 255), (8, 8, 56, 56)), psd, name="Icon_Circle"))
    psd.append(PixelLayer.frompil(_mk((0, 255, 0, 255), (16, 16, 32, 32)), psd, name="Icon_Square"))
    group = psd.create_group(name="Wilds")
    group.append(PixelLayer.frompil(_mk((0, 0, 255, 255), (24, 24, 40, 40)), group, name="Icon_Star"))
    psd.append(PixelLayer.frompil(_mk((255, 255, 0, 255), (4, 4, 12, 12)), psd, name="Icon_Duplicate"))
    psd.append(PixelLayer.frompil(_mk((255, 0, 255, 255), (6, 6, 10, 10)), psd, name="Icon_Duplicate"))
    hidden = PixelLayer.frompil(_mk((255, 255, 255, 255), (2, 2, 6, 6)), psd, name="Icon_Hidden")
    hidden.visible = False
    psd.append(hidden)
    psd.save(str(path))
    return str(path)


@pytest.fixture(scope="module")
def client(psd_file, tmp_path_factory):
    from ps_autotypesetter.ui_web import path_policy
    from ps_autotypesetter.ui_web.server import create_app

    session = os.path.join(str(tmp_path_factory.mktemp("session")), "session.json")
    app = create_app(session_file=session)
    path_policy.grant(psd_file)
    path_policy.grant("C:/tmp")
    return app.test_client()


def _layers_by_name(psd_file):
    data = symbol_exporter.list_psd_layers(psd_file)
    assert data["ok"]
    return {l["name"]: l for l in data["layers"]}


# --------------------------------------------------------------- list


def test_list_layers(psd_file):
    data = symbol_exporter.list_psd_layers(psd_file)
    assert data["ok"]
    assert data["width"] == 64
    assert data["height"] == 64
    names = [l["name"] for l in data["layers"]]
    assert names == [
        "Icon_Circle",
        "Icon_Square",
        "Wilds",
        "Icon_Star",
        "Icon_Duplicate",
        "Icon_Duplicate",
        "Icon_Hidden",
    ]
    by_name = {l["name"]: l for l in data["layers"]}
    assert by_name["Wilds"]["kind"] == "group"
    assert by_name["Icon_Star"]["kind"] == "pixel"
    assert by_name["Icon_Star"]["path"] == "Wilds/Icon_Star"
    assert by_name["Icon_Hidden"]["visible"] is False
    assert by_name["Icon_Circle"]["visible"] is True


# --------------------------------------------------------------- preview


def test_render_layer_image(psd_file):
    img = symbol_exporter.render_layer_image(psd_file, 0, max_size=0)
    assert img.mode == "RGBA"
    assert img.size == (64, 64)
    assert img.getbbox() == (8, 8, 57, 57)
    assert img.getpixel((3, 3))[3] == 0  # outside the icon: transparent


def test_render_layer_preview_downscaled(psd_file):
    img = symbol_exporter.render_layer_image(psd_file, 0, max_size=32)
    assert img.mode == "RGBA"
    assert img.size == (32, 32)


def test_render_unknown_key_raises(psd_file):
    with pytest.raises(ValueError):
        symbol_exporter.render_layer_image(psd_file, 999, 0)


# --------------------------------------------------------------- export


def test_export_selected_layers_trimmed(psd_file, tmp_path):
    out = str(tmp_path / "icons_out")
    result = symbol_exporter.export_selected_layers(psd_file, ["0", "1", "3"], out)
    assert result["skipped"] == []
    names = {f["name"]: f for f in result["files"]}
    assert set(names) == {"Icon_Circle.png", "Icon_Square.png", "Icon_Star.png"}

    circle = Image.open(names["Icon_Circle.png"]["path"]).convert("RGBA")
    assert circle.mode == "RGBA"  # transparent background preserved
    assert circle.size == (49, 49)  # trimmed to the 8..56 red rect (inclusive)
    assert circle.getbbox() == (0, 0, 49, 49)

    square = Image.open(names["Icon_Square.png"]["path"]).convert("RGBA")
    assert square.size == (17, 17)


def test_export_duplicate_names_suffixed(psd_file, tmp_path):
    out = str(tmp_path / "dup_out")
    result = symbol_exporter.export_selected_layers(psd_file, ["4", "5"], out)
    assert result["skipped"] == []
    names = sorted(f["name"] for f in result["files"])
    assert names == ["Icon_Duplicate.png", "Icon_Duplicate_2.png"]


def test_export_skips_hidden_and_unknown(psd_file, tmp_path):
    out = str(tmp_path / "skip_out")
    result = symbol_exporter.export_selected_layers(psd_file, ["6", "999"], out)
    assert result["files"] == []
    assert [s["name"] for s in result["skipped"]] == ["Icon_Hidden", ""]
    assert result["skipped"][0]["reason"] == "Layer is hidden."
    assert result["skipped"][1]["reason"] == "Layer not found."


# --------------------------------------------------------------- endpoints


def test_symbols_list_endpoint(client, psd_file):
    res = client.post("/api/symbols/list", json={"psd_path": psd_file})
    assert res.status_code == 200
    data = res.get_json()
    assert data["ok"]
    assert data["layer_count"] == 7
    assert data["layers"][0]["name"] == "Icon_Circle"


def test_symbols_list_endpoint_missing_file(client):
    res = client.post("/api/symbols/list", json={"psd_path": "Z:/no/such.psd"})
    assert res.status_code == 400
    assert "not found" in res.get_json()["error"]


def test_symbols_preview_endpoint(client, psd_file):
    res = client.get(f"/api/symbols/preview?psd_path={psd_file}&key=0&max=32")
    assert res.status_code == 200
    assert res.mimetype == "image/png"
    assert res.data[:8] == b"\x89PNG\r\n\x1a\n"
    from PIL import Image as PILImage
    import io

    img = PILImage.open(io.BytesIO(res.data))
    assert img.size == (32, 32)


def test_symbols_preview_endpoint_bad_key(client, psd_file):
    res = client.get(f"/api/symbols/preview?psd_path={psd_file}&key=404")
    assert res.status_code == 400


def test_symbols_export_endpoint(client, psd_file, tmp_path):
    out = str(tmp_path / "web_out")
    res = client.post(
        "/api/symbols/export",
        json={"psd_path": psd_file, "keys": ["0", "6"], "output_dir": out},
    )
    assert res.status_code == 200
    data = res.get_json()
    assert data["ok"]
    assert [f["name"] for f in data["files"]] == ["Icon_Circle.png"]
    assert data["skipped"][0]["name"] == "Icon_Hidden"
    assert os.path.isfile(data["files"][0]["path"])


def test_symbols_export_endpoint_validation(client, psd_file):
    res = client.post("/api/symbols/export", json={"psd_path": psd_file, "keys": ["0"]})
    assert res.status_code == 400
    assert "output folder" in res.get_json()["error"]

    res = client.post(
        "/api/symbols/export",
        json={"psd_path": psd_file, "keys": [], "output_dir": "C:/tmp"},
    )
    assert res.status_code == 400
    assert "at least one" in res.get_json()["error"]