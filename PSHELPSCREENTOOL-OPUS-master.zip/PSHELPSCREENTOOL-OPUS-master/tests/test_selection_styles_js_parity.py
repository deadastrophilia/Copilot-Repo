"""The Canvas (visualiser_live.js wordRuns) styles exactly the characters the build (text_styles.word_runs)
does — exact occurrences, stacking, letter spacing, strips. The JS functions are run in node."""
import json
import pathlib
import shutil
import subprocess

import pytest

from ps_autotypesetter import text_styles as ts

JS = pathlib.Path(__file__).resolve().parents[1] / "ps_autotypesetter" / "ui_web" / "static" / "visualiser_live.js"
ROW = ("<RICH> with one or more <BAG> awards Extra Spins feature. <RICH> with one or more <GREEN> "
       "awards Extra Properties feature. <RICH> with one or more <RED> awards Extra Houses feature. One or more")
PIECES = [ROW, " awards Extra Spins feature. ", " awards Extra Houses feature. One or more", "feature. One or more",
          "awards Extra Houses", " with one or more ", "Extra"]


def _rule(phrase, after, **style):
    start = ROW.index(after + phrase) + len(after)
    text, nth = ts.nth_of(ROW, start, start + len(phrase))
    return dict({"kind": "word", "scope": "row", "sheet": "S", "row_text": ROW, "text": text, "nth": nth}, **style)


RULES = [
    _rule("Extra Houses feature.", "awards ", size=150, bg="#112233", bg_opacity=0.5),
    _rule("feature.", "Houses ", color="#ff0000", tracking=200),
    _rule("with one", "Spins feature. <RICH> ", bold=True),
    {"kind": "word", "text": "Extra", "italic": True, "scope": "game"},
    {"kind": "word", "text": "One or more", "color": "#00ff00", "scope": "page", "sheet": "S"},
]


def _look(st):
    """What both sides must agree on for a styled run."""
    if not st:
        return None
    bg = st.get("bg")
    return {"rgb": list(st["rgb"]) if st.get("rgb") else None, "bold": bool(st.get("bold")), "italic": bool(st.get("italic")),
            "size": st.get("size"), "tracking": st.get("tracking"),
            "bg": [list(bg["rgba"]), bg["pad_x"], bg["pad_y"], bg["radius"]] if bg else None}


def _python():
    with ts.active(RULES, "S"), ts.row(ROW):
        return [[[seg, _look(st)] for seg, st in ts.word_runs(p)] for p in PIECES]


def _js(tmp_path):
    src = JS.read_text(encoding="utf-8")
    block = src[src.index("  function rowKeyOf(t) {"):src.index("  function styledSegW(")]
    script = tmp_path / "parity.js"
    script.write_text("""
const L = { state: { wsRow: "", wsRowText: "", data: { sheet_name: "S" } } };
const App = { state: { config: { dynamic_settings: { text_style_rules: %s, layer_style_library: {} } } } };
%s
const look = (st) => st ? { rgb: st.rgb || null, bold: !!st.bold, italic: !!st.italic, size: st.size == null ? null : st.size,
  tracking: st.tracking == null ? null : st.tracking,
  bg: st.bg ? [st.bg.rgba, st.bg.pad_x, st.bg.pad_y, st.bg.radius] : null } : null;
setWsRow(%s);
const out = %s.map((p) => { const r = wordRuns(p); return r ? r.map(([s, st]) => [s, look(st)]) : [[p, null]]; });
process.stdout.write(JSON.stringify(out));
""" % (json.dumps(RULES), block, json.dumps(ROW), json.dumps(PIECES)), encoding="utf-8")
    res = subprocess.run(["node", str(script)], capture_output=True, text=True, timeout=60)
    assert res.returncode == 0, res.stderr
    return json.loads(res.stdout)


@pytest.mark.skipif(shutil.which("node") is None, reason="node not installed")
def test_repeated_words_between_icons_style_the_same_copy(tmp_path):
    """The 2nd "one" of a row where " with one or more " repeats between icons: the Canvas and the
    build style the same piece (each part knows its line and place — splitInline src / o)."""
    from ps_autotypesetter import png_builder as pb

    second = ROW.index("<RICH> with one", ROW.index("<RICH> with one") + 1) + len("<RICH> with ")
    text, nth = ts.nth_of(ROW, second, second + 3)
    rules = [{"kind": "word", "scope": "row", "sheet": "S", "row_text": ROW, "text": text, "nth": nth, "color": "#ffdd00"}]
    parts = [(v, v.src_off) for k, v in pb._split_inline(ROW) if k == "text"]
    with ts.active(rules, "S"), ts.row(ROW):
        py = [[[s, bool(st)] for s, st in ts.word_runs(ts.cut(ROW, o, v))] for v, o in parts]
    src = JS.read_text(encoding="utf-8")
    block = src[src.index("  function rowKeyOf(t) {"):src.index("  function styledSegW(")]
    script = tmp_path / "repeat.js"
    script.write_text("""
const L = { state: { wsRow: "", wsRowText: "", data: { sheet_name: "S" } } };
const App = { state: { config: { dynamic_settings: { text_style_rules: %s, layer_style_library: {} } } } };
%s
setWsRow(%s);
const out = %s.map(([v, o]) => { L.state.wsPart = { v, src: %s, o }; const r = wordRuns(v);
  return r ? r.map(([s, st]) => [s, !!st]) : [[v, false]]; });
process.stdout.write(JSON.stringify(out));
""" % (json.dumps(rules), block, json.dumps(ROW), json.dumps([[str(v), o] for v, o in parts]), json.dumps(ROW)), encoding="utf-8")
    res = subprocess.run(["node", str(script)], capture_output=True, text=True, timeout=60)
    assert res.returncode == 0, res.stderr
    js = json.loads(res.stdout)
    assert js == py
    assert sum(1 for piece in py for _s, on in piece if on) == 1     # exactly one "one"


@pytest.mark.skipif(shutil.which("node") is None, reason="node not installed")
def test_canvas_and_build_style_the_same_characters(tmp_path):
    py, js = _python(), _js(tmp_path)
    norm = lambda runs: json.loads(json.dumps(runs).replace(".0,", ",").replace(".0]", "]").replace(".0}", "}"))
    for piece, a, b in zip(PIECES, py, js):
        assert norm(a) == norm(b), piece
    assert any(look and look["bg"] for piece in py for _seg, look in piece)   # the case is really covered
