"""Gaps beside one icon (icon_scales: dynamic_settings.icon_gaps): this copy, a sheet, the project."""
from PIL import Image, ImageDraw, ImageFont

from ps_autotypesetter import icon_scales
from ps_autotypesetter import png_builder as png


def teardown_function(_f):
    icon_scales.set_all({})


def test_gap_tags_go_to_the_copies_asked_for():
    icon_scales.set_all({}, {"P": {"WILD@row:3#1": [2, 40]}, "*": {"COIN": [0, 0]}})
    out = icon_scales.apply("P", "row:3", "a <WILD> b <WILD> c <Coin>")
    assert out == "a <WILD> b <WILD^2,40> c <Coin^0,0>"
    assert icon_scales.strip("WILD~140^2,40") == "WILD" and icon_scales.split("WILD~140^2,40") == ("WILD", 1.4)
    assert icon_scales.gaps("WILD^2,40", 15, 15) == (2, 40) and icon_scales.gaps("WILD", 15, 15) == (15, 15)


def test_an_icon_with_its_own_gaps_measures_with_them(tmp_path):
    Image.new("RGBA", (40, 40), (255, 0, 0, 255)).save(tmp_path / "WILD.png")
    font = png._load_font(ImageFont, "Arial", 30)
    d = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    plain = png._measure_inline(d, Image, "a <WILD> b", font, str(tmp_path), {}, 40, None, 15, 15)[0]
    own = png._measure_inline(d, Image, "a <WILD^0,60> b", font, str(tmp_path), {}, 40, None, 15, 15)[0]
    assert own - plain == 30                           # 0 + 60 instead of 15 + 15


def test_row_text_matching_ignores_the_gap_tag():
    assert png._untag_text("x <WILD~120^4,4> y <A^1,2> z <B~90>") == "x <WILD> y <A> z <B>"
