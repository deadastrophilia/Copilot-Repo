"""Headless PNG game-rules row-gap checks.

The PNG game-rules renderer must stack rows with the same gap priorities as
the PSD engine: UI 'Row spacing' (line_gap, empty -> the 30px default) >
configured line height > ... The Typography 'Line spacing' multiplier no
longer affects row stacking -- Row Gap is the single source.
"""

from openpyxl import Workbook
from openpyxl.styles import Font

from ps_autotypesetter import png_builder


def _render(dynamic_settings, line_spacing=1.1, canvas_h=2600):
    wb = Workbook()
    ws = wb.active
    ws.title = "GAME RULES"
    ws.cell(row=1, column=1, value="GAME RULES").font = Font(bold=True)
    for index in range(5):
        ws.append([
            f"Rule paragraph number {index + 1}: spin wins with a wild multiplier and bonus free games "
            f"awarded on every winning combination. Each paragraph repeats itself several times so it "
            f"always wraps onto multiple rendered rows and the row-spacing controls become measurable."
        ])
    Image, ImageDraw, ImageFont = png_builder._require_pillow()
    pages = png_builder._render_game_rules_png_pages(
        Image, ImageDraw, ImageFont, ws, "GAME RULES",
        bg_path="", bg_mode="stretch", bg_color="#FFFFFF",
        canvas_w=1920, canvas_h=canvas_h,
        h_font="Arial", h_size=72, h_icon_h=48, h_rgb="#FF5050",
        b_font="Arial", b_size=30, b_icon_h=24, b_rgb="#101010",
        margin_x=100, heading_top_margin=120, heading_to_body_gap=40, bottom_margin=80,
        line_spacing=line_spacing, para_spacing=12,
        icon_folder="", icon_mappings={}, icon_size_overrides={},
        dynamic_settings=dynamic_settings, alignment_settings={},
    )
    return pages


def _content_bottom(images):
    """Last row that contains any non-background pixel."""
    bottom = 0
    for img in images:
        gray = img.convert("L")
        w, h = gray.size
        found = 0
        for y in range(h - 1, -1, -1):
            row = gray.crop((0, y, w, y + 1))
            if row.getextrema()[0] < 250:
                found = y
                break
        bottom = max(bottom, found)
    return bottom


def test_row_gap_defaults_to_30_and_multiplier_ignored():
    base = _content_bottom(_render({}))
    multi = _content_bottom(_render({}, line_spacing=2.0))
    assert base == multi  # Line spacing no longer affects row/paragraph gaps
    tight = _content_bottom(_render({"line_gap": 0}))
    assert base > tight  # the 30px default pushes rows apart
    assert base - tight >= 50  # ~30px per paragraph boundary (fit-shrink dampens the exact sum)


def test_line_gap_zero_makes_rows_touch():
    tight = _content_bottom(_render({"line_gap": 0}))
    tiny = _content_bottom(_render({"line_gap": 0}, line_spacing=2.0))
    assert tight == tiny  # 0 must beat the 2.0 multiplier too


def test_line_gap_override_wins_over_line_height():
    gapped = _content_bottom(_render({"line_gap": 30}))
    base = _content_bottom(_render({}))
    assert gapped == base  # the 30px default IS the Row Gap contract
    taller = _content_bottom(_render({"line_gap": 40}))
    assert taller - base >= 30  # +10px per paragraph boundary over 5 paragraphs
    tall = _content_bottom(_render({"game_rules_line_height": 40}))
    assert tall < base  # a full 40px baseline step leaves only ~4px of row gap
    assert taller - tall >= 20  # the explicit Row Gap beats the line-height step


def test_game_rules_line_height_override_wins_over_multiplier():
    tall = _content_bottom(_render({"game_rules_line_height": 40}))
    base = _content_bottom(_render({}))
    assert tall < base  # a px line-height override is a baseline STEP, not a gap:
    # (_line_step_for_line = max(override, font + 2)) leaves gap = step - box,
    # tighter than the 30px default row gap -- PSD semantics.
    gapped = _content_bottom(_render({"line_gap": 40}))
    assert gapped - tall >= 20


def test_row_gap_px_is_exact_visual_gap():
    """The Row Gap field value must be the EXACT visual gap between the real
    ink of consecutive rows -- the user-visible contract (70px in the field
    means 70px of blank space between rows, top to bottom). Box-based stacking
    rendered gaps larger than the field because the font box (ascent+descent)
    is taller than the actual glyph ink."""
    img = _band_image({"line_gap": 70}, rows=["Row one", "Row two", "Row three"])
    gaps = [_band_gaps(img)[i] for i in range(1, len(_band_gaps(img)))]
    for g in gaps:
        assert g == 70, f"visual gap {g} != Row Gap field 70"


def _band_image(dynamic_settings, rows=None):
    wb = Workbook()
    ws = wb.active
    ws.title = "GAME RULES"
    ws.cell(row=1, column=1, value="GAME RULES").font = Font(bold=True)
    if rows is None:
        rows = []
    for r in rows:
        ws.append([r])
    Image, ImageDraw, ImageFont = png_builder._require_pillow()
    pages = png_builder._render_game_rules_png_pages(
        Image, ImageDraw, ImageFont, ws, "GAME RULES",
        bg_path="", bg_mode="stretch", bg_color="#FFFFFF",
        canvas_w=1920, canvas_h=1400,
        h_font="Arial", h_size=72, h_icon_h=48, h_rgb="#FF5050",
        b_font="Arial", b_size=30, b_icon_h=24, b_rgb="#101010",
        margin_x=100, heading_top_margin=120, heading_to_body_gap=40, bottom_margin=80,
        line_spacing=1.1, para_spacing=12,
        icon_folder="", icon_mappings={}, icon_size_overrides={},
        dynamic_settings=dynamic_settings, alignment_settings={},
    )
    return pages[0].convert("L")


def _band_gaps(img):
    w, h = img.size
    px = img.load()
    bands = []
    in_band = False
    for y in range(h):
        dark = any(px[x, y] < 250 for x in range(w))
        if dark and not in_band:
            bands.append([y, y])
            in_band = True
        elif dark:
            bands[-1][1] = y
        else:
            in_band = False
    return [bands[i + 1][0] - bands[i][1] - 1 for i in range(len(bands) - 1)]


def test_row_gap_exact_across_wrapped_paragraphs():
    """Multi-line paragraphs: EVERY pair of consecutive body rows -- inside a
    paragraph and across paragraph boundaries -- must show the exact Row Gap.
    (Regression: paragraphs were drawn as one _draw_inline call whose internal
    wrapped rows used leading, so only paragraph boundaries hit the field.)"""
    rows = [
        "Rule paragraph one: spin wins with a wild multiplier and bonus free games awarded on every winning combination over and over again until the page fills.",
        "Rule paragraph two: another long paragraph that also wraps onto several rendered rows so its internal row spacing becomes measurable too.",
        "Rule paragraph three: a final long paragraph with enough words to guarantee wrapping onto multiple rows inside the safe area.",
    ]
    img = _band_image({"line_gap": 70}, rows=rows)
    gaps = _band_gaps(img)
    body_gaps = gaps[1:]  # drop heading->first-body boundary (fixed leading gap)
    assert len(body_gaps) >= 3, f"expected several wrapped rows, got bands gaps {gaps}"
    for g in body_gaps:
        assert g in (69, 70, 71), f"wrapped-row visual gap {g} != Row Gap 70 (gaps {gaps})"

    img = _band_image({}, rows=rows)
    body_gaps = _band_gaps(img)[1:]
    for g in body_gaps:
        assert g in (29, 30, 31), f"default wrapped-row gap {g} != 30 (gaps {_band_gaps(img)})"

def _sheet(rules, legal=("Malfunction voids all pays and plays.", "Player is responsible to confirm credits.")):
    wb = Workbook()
    ws = wb.active
    ws.title = "GAME RULES"
    ws["B2"] = "GAME RULES"
    r = 4
    for t in list(rules) + list(legal):
        ws.cell(row=r, column=2, value=t)
        r += 1
    return ws


def _render_ws(ws, ds, canvas_h=1080, icon_folder="", b_size=30, b_icon_h=24):
    Image, ImageDraw, ImageFont = png_builder._require_pillow()
    report = {}
    pages = png_builder._render_game_rules_png_pages(
        Image, ImageDraw, ImageFont, ws, "GAME RULES",
        bg_path="", bg_mode="stretch", bg_color="#FFFFFF", canvas_w=1920, canvas_h=canvas_h,
        h_font="Arial", h_size=60, h_icon_h=48, h_rgb="#FF5050",
        b_font="Arial", b_size=b_size, b_icon_h=b_icon_h, b_rgb="#101010",
        margin_x=100, heading_top_margin=60, heading_to_body_gap=40, bottom_margin=40,
        line_spacing=1.1, para_spacing=12, icon_folder=icon_folder, icon_mappings={}, icon_size_overrides={},
        dynamic_settings=ds, alignment_settings={}, report=report,
    )
    return pages, report


def test_a_long_page_shrinks_text_gaps_and_symbols_together():
    # 30 rules at 60px don't fit one page: everything scales by one factor (not text alone,
    # which left fixed 30px row gaps and full-size symbols and made the text tiny)
    ws = _sheet([f"Rule {i}: wins pay left to right on adjacent reels." for i in range(30)])
    _pages, rep = _render_ws(ws, {}, b_size=60, b_icon_h=60)
    sz = rep["sizes"]
    assert rep["fit"] < 1 and sz["body_set"] == 60
    assert abs(sz["body"] / 60 - rep["fit"]) < 0.03 and abs(sz["icon"] / 60 - rep["fit"]) < 0.03
    assert sz["body"] >= 15                      # the old text-only shrink hit its 10px floor here
    bottom = max(l["rect"][1] + l["rect"][3] for l in rep["lines"])
    assert bottom <= 1080 - 40 + 2               # and it all fits the page


def test_the_report_says_where_each_line_and_the_separator_are():
    ws = _sheet(["All wins pay left to right.", "Highest win only on each line."])
    _pages, rep = _render_ws(ws, {})
    parts = [(l["part"], l["cell"]) for l in rep["lines"]]
    assert parts == [("rules", "B4"), ("rules", "B5"), ("legal", "B6"), ("legal", "B7")]
    sep = rep["separator"]
    rules_bottom = max(l["rect"][1] + l["rect"][3] for l in rep["lines"] if l["part"] == "rules")
    legal_top = min(l["rect"][1] for l in rep["lines"] if l["part"] == "legal")
    assert rules_bottom < sep[1] < legal_top
    assert rep["legal"] == {"manual": False, "off": False, "split": "", "first": "B6"}


def test_the_artist_chooses_where_the_legal_text_starts():
    ws = _sheet(["All wins pay left to right.", "Progressive wins are not multiplied.", "Touch CREDIT to show credits."])
    _p, rep = _render_ws(ws, {"game_rules_legal_split_overrides": "GAME RULES=B5"})
    assert [l["cell"] for l in rep["lines"] if l["part"] == "legal"] == ["B5", "B6", "B7", "B8"]
    # "none": nothing under the separator, even the Malfunction line (and no separator drawn)
    _p, rep = _render_ws(ws, {"game_rules_legal_split_overrides": "GAME RULES=B5\nGAME RULES=none"})
    assert not [l for l in rep["lines"] if l["part"] == "legal"] and rep["separator"] is None


def test_xtraa_reels_show_when_the_page_mentions_them_and_each_side_can_be_ticked(tmp_path):
    from PIL import Image

    Image.new("RGBA", (100, 160), (0, 0, 255, 255)).save(str(tmp_path / "xtraa.png"))
    plain = _sheet(["All wins pay left to right."])
    _p, rep = _render_ws(plain, {}, icon_folder=str(tmp_path))
    x = rep["xtra"]
    assert x["asset"] and not x["mentioned"] and not x["left"] and not x["right"]   # not mentioned: off
    assert x["rects"]["left"] and x["rects"]["right"]                               # its spots are known
    told = _sheet(["XTRAA REELS add extra rows during free games."])
    _p, rep = _render_ws(told, {}, icon_folder=str(tmp_path))
    assert rep["xtra"]["mentioned"] and rep["xtra"]["left"] and rep["xtra"]["right"]
    narrow = rep["guides"]["upper_margin"]
    assert narrow >= 100 + 100 + 50                                                  # text clears the icons
    _p, rep = _render_ws(told, {"game_rules_xtra_reels_right": False, "game_rules_xtra_reels_width": 140},
                         icon_folder=str(tmp_path))
    x = rep["xtra"]
    assert x["left"] and not x["right"] and x["rects"]["left"][2] == x["rects"]["right"][2] == 140
    _p, rep = _render_ws(plain, {"game_rules_xtra_reels_left": True}, icon_folder=str(tmp_path))
    assert rep["xtra"]["left"] and not rep["xtra"]["right"]                          # ticked anyway
    _p, rep = _render_ws(told, {}, icon_folder="")                                    # no icon in the folder
    assert not rep["xtra"]["asset"] and not rep["xtra"]["left"]


def test_the_separator_takes_its_layer_style():
    ws = _sheet(["All wins pay left to right."])
    style = {"stroke": {"enabled": True, "size": 3, "color": "#00FF00", "position": "outside"}}
    plain, rep = _render_ws(ws, {"game_rules_separator_height": 10, "game_rules_separator_rgb": "#FF0000"})
    styled, _r = _render_ws(ws, {"game_rules_separator_height": 10, "game_rules_separator_rgb": "#FF0000",
                                 "game_rules_separator_fx": "Green edge",
                                 "layer_style_library": {"Green edge": style}})
    sx, sy, sw, sh = rep["separator"]
    assert plain[0].getpixel((int(sx + sw / 2), int(sy + sh / 2)))[:3] == (255, 0, 0)
    assert plain[0].tobytes() != styled[0].tobytes()                              # the style changed the line
