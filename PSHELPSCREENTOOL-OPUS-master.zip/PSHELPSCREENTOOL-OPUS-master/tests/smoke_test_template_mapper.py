import json
import os
import sys
import tempfile

from openpyxl import Workbook, load_workbook


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from ps_autotypesetter.dynamic_pages.paytable.parser import parse_paytable_sheet
from ps_autotypesetter.icon_mapping import resolve_icon_path
from ps_autotypesetter.template_mapping import (
    build_mapped_template,
    load_base_template,
    save_mapped_template,
    scan_excel_content,
    validate_mappings,
)


with tempfile.TemporaryDirectory() as folder:
    excel_path = os.path.join(folder, "mapper.xlsx")
    json_path = os.path.join(folder, "base.json")
    output_path = os.path.join(folder, "paytable.json")
    spaced_icon_path = os.path.join(folder, "Red_Bag.png")
    with open(spaced_icon_path, "wb") as handle:
        handle.write(b"test")
    assert resolve_icon_path("Red Bag", folder) == spaced_icon_path

    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = "paytable"
    worksheet["B3"] = "PAYTABLE"
    worksheet["B6"] = "<WILD> and <WILD2x> substitutes for all symbols except <A>, <B>."
    worksheet["B11"] = "<FEATURE> appears during the bonus."
    workbook.save(excel_path)

    base_template = {
        "template_id": "mapper_test",
        "canvas": {"width": 1920, "height": 1080},
        "slots": {
            "icon.1": {"x": 1400, "y": 100, "w": 180, "h": 180},
            "icon.2": {"x": 1600, "y": 100, "w": 180, "h": 180},
            "rules": {"x": 1380, "y": 320, "w": 440, "h": 500},
            "feature_strip": {"x": 200, "y": 900, "w": 1100, "h": 100},
        },
    }
    with open(json_path, "w", encoding="utf-8") as handle:
        json.dump(base_template, handle)

    blocks = scan_excel_content(excel_path, "paytable", max_column=15)
    row_six = next(block for block in blocks if block["row"] == 6)
    assert row_six["source"] == "B6:B6"
    assert row_six["tokens"] == ["WILD", "WILD2x", "A", "B"]

    mappings = [
        {"kind": "token", "source": "B6:B6", "slot": "icon.1", "token_index": 0, "token": "WILD", "max_height": 0},
        {"kind": "token", "source": "B6:B6", "slot": "icon.2", "token_index": 1, "token": "WILD2x", "max_height": 0},
        {"kind": "inline_token", "source": "B6:B6", "slot": "rules", "token_index": 2, "token": "A", "icon_height": 24},
        {"kind": "inline_token", "source": "B6:B6", "slot": "rules", "token_index": 3, "token": "B", "icon_height": 36},
        {
            "kind": "flow", "source": "B6:B6", "slot": "rules", "render_mode": "inline_flow",
            "font_size": 30, "minimum_font_size": 20, "icon_height": 48,
            "gap": 18, "minimum_gap": 8, "padding": [10, 10, 10, 10], "vertical_align": "top",
        },
        {
            "kind": "flow", "source": "B11:B11", "slot": "feature_strip", "render_mode": "inline_flow",
            "font_size": 28, "minimum_font_size": 20, "icon_height": 44,
            "gap": 12, "minimum_gap": 6, "padding": [4, 4, 4, 4], "vertical_align": "center",
        },
    ]

    errors, warnings = validate_mappings(base_template, mappings)
    assert not errors, errors
    icon_mappings = {"Red Bag": spaced_icon_path}
    mapped = build_mapped_template(base_template, "paytable", mappings, icon_mappings=icon_mappings)
    assert mapped["mapper_meta"]["authoritative"] is True
    assert mapped["flow_replaces_legacy_text"] is True
    rules_source = mapped["flow_regions"]["rules"]["sources"][0]
    assert rules_source["exclude_token_indexes"] == [0, 1]
    assert len(mapped["token_bindings"]) == 2
    assert [item["icon_height"] for item in mapped["inline_icon_overrides"]] == [24, 36]
    assert mapped["icon_mappings"] == icon_mappings

    saved_path, save_warnings = save_mapped_template(
        base_template, "paytable", mappings, output_path, icon_mappings=icon_mappings,
    )
    assert saved_path == output_path
    assert not save_warnings
    loaded_template = load_base_template(output_path)
    assert loaded_template["icon_mappings"] == icon_mappings
    rendered_data = parse_paytable_sheet(load_workbook(excel_path, data_only=False)["paytable"], template=loaded_template)
    assert [binding["token"] for binding in rendered_data["token_bindings"]] == ["WILD", "WILD2x"]
    rules_region = next(region for region in rendered_data["flow_regions"] if region["slot"] == "rules")
    assert rules_region["blocks"][0]["text"] == "substitutes for all symbols except <A>, <B>."
    assert rules_region["blocks"][0]["inline_icon_heights"] == {0: 24, 1: 36}

    icon_only_errors, icon_only_warnings = validate_mappings(base_template, mappings[:2])
    assert not icon_only_errors
    assert any("No text assignment exists" in warning for warning in icon_only_warnings)
    orphan_size_errors, _ = validate_mappings(base_template, mappings[:4])
    assert any("needs the parent Excel row assigned" in error for error in orphan_size_errors)
    duplicate_slot_errors, _ = validate_mappings(base_template, mappings + [dict(mappings[4])])
    assert any("assigned more than once" in error for error in duplicate_slot_errors)

print("Template mapper smoke test passed.")
