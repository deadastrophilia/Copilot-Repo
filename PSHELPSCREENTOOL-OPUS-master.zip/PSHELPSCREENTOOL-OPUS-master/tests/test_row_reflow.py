"""Regression tests for measured-bound row layout (inline icons cannot overlap).

Simulates the Photoshop layer model used by the game-rules / body renderers:
every line is one group containing a 'Body Text' group and a 'Body Icons' group.
Each layer exposes `bounds` like a Photoshop layer and supports `translate`.
"""
import pytest

from ps_autotypesetter.build_engine import (
    _collect_group_bounds,
    _line_gap_margin_px,
    _previous_visual_bottom_above,
    _push_block_below_previous,
    _reflow_centered_rows,
    _reflow_rows_by_measured_bounds,
    _translate_group_items,
)


class _MockArtLayer:
    """One Photoshop layer with mutable [left, top, right, bottom] bounds."""

    def __init__(self, bounds):
        self._bounds = [float(v) for v in bounds]

    @property
    def bounds(self):
        return list(self._bounds)

    def translate(self, dx, dy=0):
        self._bounds[0] += dx
        self._bounds[2] += dx
        self._bounds[1] += dy
        self._bounds[3] += dy


class _MockGroup:
    """One Photoshop layer-set (a rendered row or block)."""

    def __init__(self, art_layers=None, sub_groups=None, parent=None):
        self.artLayers = art_layers or []
        self.layerSets = sub_groups or []
        self.parent = parent

    @property
    def bounds(self):
        return _collect_group_bounds(self)

    def translate(self, dx, dy=0):
        _translate_group_items(self, dx, dy)


def _row(text_bounds, icon_bounds=None, parent=None):
    """Build one rendered row: 'Body Text' group plus optional 'Body Icons' group."""
    text = _MockGroup([_MockArtLayer(text_bounds)])
    if icon_bounds is None:
        return _MockGroup([text], parent=parent)
    icons = _MockGroup([_MockArtLayer(icon_bounds)])
    return _MockGroup([text, icons], parent=parent)


def test_text_only_rows_stay_compact():
    """Small text-only rows must not grow: no push happens when rows already clear."""
    rows = [
        _row([0, 100, 500, 110]),
        _row([0, 120, 500, 130]),
        _row([0, 140, 500, 150]),
    ]
    top, bottom = _reflow_rows_by_measured_bounds(rows, 10)
    assert top == 100
    assert bottom == 150
    for row in rows:
        r_top, r_bottom = row.bounds[1], row.bounds[3]
        assert r_bottom - r_top == 10


def test_tall_icon_row_is_pushed_off_previous_line():
    """Row 2's icon extends ABOVE its own text top and into row 1's bottom.

    Text-only advance would leave row 3 at top=215, overlapping the icon's
    bottom=260. The measured reflow must push row 2 down (union top 60 -> 120)
    and row 3 below the icon bottom plus the 10px margin.
    """
    # line 1: text only, bottom=110
    # line 2: text [200..210] but icon [60..260] -> union top=60, bottom=260
    # line 3: text [215..225] (placed as if only text height mattered -> overlap)
    rows = [
        _row([0, 100, 500, 110]),
        _row([0, 200, 500, 210], icon_bounds=[0, 60, 100, 260]),
        _row([0, 215, 500, 225]),
    ]
    gap = 10
    top, bottom = _reflow_rows_by_measured_bounds(rows, gap)
    assert top == 100

    b1 = rows[0].bounds
    b2 = rows[1].bounds
    b3 = rows[2].bounds
    assert b2[1] == 120  # pushed from 60 by delta (110 + 10 - 60)
    assert b2[3] == 320  # 260 + 60
    assert b2[1] >= b1[3] + gap
    assert b3[1] >= b2[3] + gap
    assert b3[1] == 330  # 320 + 10
    assert bottom == 340


def test_row_gap_applied_after_every_row_both_directions():
    """The web-UI Row spacing must be applied after EVERY row's bounding box.

    Previously the reflow only pushed a row DOWN when the estimated position
    collided (top < prev_bottom + gap). A row that was estimated much farther
    down kept its oversize spacing, so the gap only ever showed up on the row
    that happened to overlap. Now each box is snapped to exactly
    `prev_bottom + gap`, both pushing up and pulling down.
    """
    # row 1: bottom at 110. row 2 estimated way too low (only overlaps once).
    rows = [
        _row([0, 100, 500, 110]),
        _row([0, 2000, 500, 2010]),   # huge estimated offset -> must snap up to exact gap
        _row([0, 3000, 500, 3010]),
    ]
    top, bottom = _reflow_rows_by_measured_bounds(rows, 10)
    assert rows[1].bounds[1] == 120  # 110 + 10
    assert rows[1].bounds[3] == 130
    assert rows[2].bounds[1] == 140  # 130 + 10
    assert rows[2].bounds[3] == 150
    assert bottom == 150


def test_zero_margin_means_rows_touch_but_never_overlap():
    """gap=0: consecutive rows may touch exactly, but never overlap."""
    rows = [
        _row([0, 100, 500, 110]),
        _row([0, 200, 500, 210], icon_bounds=[0, 60, 100, 260]),
        _row([0, 215, 500, 225]),
    ]
    top, bottom = _reflow_rows_by_measured_bounds(rows, 0)
    b1, b2, b3 = (r.bounds for r in rows)
    assert b2[1] == 110  # exactly touching previous bottom
    assert b2[3] == 310  # icon union 260 + push 50
    assert b3[1] == 310  # touching icon bottom
    assert top == 100
    assert bottom == 320


def test_centered_row_tuples_unwrapped():
    """_reflow_centered_rows must unwrap (group, align, left, width) tuples."""
    groups = [
        (_row([0, 100, 500, 110]), "center", 0, 500),
        (_row([0, 200, 500, 210], icon_bounds=[0, 60, 100, 260]), "center", 0, 500),
        (_row([0, 215, 500, 225]), "center", 0, 500),
    ]
    bottom = _reflow_centered_rows(groups, margin_px=10)
    assert bottom == 340
    b2, b3 = groups[1][0].bounds, groups[2][0].bounds
    assert b2[1] == 120
    assert b3[1] == 330


def test_line_gap_margin_math():
    """Web multiplier, desktop px and explicit line-step semantics."""
    assert _line_gap_margin_px(20, 1.1) == 2
    assert _line_gap_margin_px(20, 2.0) == 20
    assert _line_gap_margin_px(20, 25) == 25   # desktop px value
    assert _line_gap_margin_px(20, 19) == 19   # preset px value
    assert _line_gap_margin_px(20, 1.1, 30) == 30
    assert _line_gap_margin_px(20, 0) == 0


def test_previous_visual_bottom_above_finds_closest_sibling():
    """The auto-detect fallback must pick the content laid out above the block."""
    parent = _MockGroup([])
    row1 = _row([0, 100, 500, 110], parent=parent)
    row2 = _row([0, 200, 500, 210], icon_bounds=[0, 60, 100, 260], parent=parent)
    row3 = _row([0, 300, 500, 310], parent=parent)
    parent.layerSets = [row1, row2, row3]

    # The block at row3 (span 300-310) has row2 above it (bottom 260) and row1 below that.
    assert _previous_visual_bottom_above(row3, 300, block_bottom=310) == 260.0
    # The block at row2 (span 60-260 after union) has only row1 (bottom 110) above it;
    # row3 would sit below, so it is not considered.
    assert _previous_visual_bottom_above(row2, 60, block_bottom=260) == 110.0
    # The first (topmost) sibling has nothing above it.
    assert _previous_visual_bottom_above(row1, 100, block_bottom=110) is None


def test_push_auto_detects_previous_when_none_passed():
    """With prev_visual_bottom=None the block still clears the sibling above.

    The web body renderer never threads the previous bottom through the
    draw_parsed_block_paged call sites; auto-detection must still fire so a
    paragraph whose first row rises into the previous one is pushed down.
    """
    parent = _MockGroup([])
    prev_block = _row([0, 100, 500, 110], parent=parent)
    block = _row([0, 200, 500, 210], icon_bounds=[0, 60, 100, 260], parent=parent)
    parent.layerSets = [prev_block, block]

    # block's own union bottom is 260; icon top 60 must clear prev bottom
    # 110 + margin 10 -> top 120, then current_y (the next-row baseline = 260)
    # is bumped by the same delta.
    new_current_y = _push_block_below_previous(block, None, 260, margin_px=10)
    assert block.bounds[1] == 120
    assert block.bounds[3] == 320
    assert new_current_y == 320


def test_push_auto_detect_respects_explicit_previous():
    """An explicit prev_visual_bottom overrides auto-detection."""
    parent = _MockGroup([])
    prev_block = _row([0, 100, 500, 110], parent=parent)
    block = _row([0, 200, 500, 210], icon_bounds=[0, 60, 100, 260], parent=parent)
    parent.layerSets = [prev_block, block]

    # Explicit reference of 150 requires top >= 160; icon union top 60 needs
    # delta 100, so the union bottom (260) lands at 360 and current_y jumps 100.
    new_current_y = _push_block_below_previous(block, 150, 520, margin_px=10)
    assert block.bounds[1] == 160
    assert block.bounds[3] == 360
    assert new_current_y == 620