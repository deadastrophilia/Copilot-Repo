"""Layer styles that follow the text size (fx_scale.py + PsFx.scaleFor), Mimic's Global Light,
and the one-script Photoshop capture."""
import io
import json
import os
import shutil
import subprocess

import pytest
from PIL import ImageFont

from ps_autotypesetter import fx_descriptor, fx_scale, global_light, photoshop_bridge, ps_fx_png
from ps_autotypesetter import psd_style_import as imp

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
JS_ENGINE = os.path.join(ROOT, "ps_autotypesetter", "ui_web", "static", "ps_fx_canvas.js")


def _descriptor_hex(use_global_light=False, angle=120.0, distance=8.0, blur=12.0, stroke=4.0, wide=True):
    """A real Photoshop effects descriptor (drop shadow + stroke), as a capture ("00xx") or plain hex."""
    from psd_tools.psd.descriptor import Bool, DescriptorBlock

    with open(os.path.join(ROOT, "ps_autotypesetter", "psd_writer", "fx_template.bin"), "rb") as f:
        desc = DescriptorBlock.read(io.BytesIO(f.read()))
    sh, fr = desc[b"DrSh"], desc[b"FrFX"]
    for d in (sh, fr):
        d[b"enab"], d[b"present"] = Bool(True), Bool(True)
    sh[b"uglg"] = Bool(use_global_light)
    sh[b"lagl"].value, sh[b"Dstn"].value, sh[b"blur"].value = angle, distance, blur
    sh[b"Ckmt"].value = 20.0
    fr[b"Sz  "].value = stroke
    buf = io.BytesIO()
    desc.write(buf)
    data = buf.getvalue()
    return "".join("%04x" % b for b in data) if wide else (b"\x00\x00\x00\x00" + data).hex()


def _lengths(params):
    out = {}
    for kind, keys in fx_scale.LENGTHS.items():
        eff = params.get(kind)
        for i, e in enumerate(eff if isinstance(eff, list) else [eff]):
            if isinstance(e, dict):
                out.update({f"{kind}{i}.{k}": e.get(k) for k in keys})
    return out


# ── modes ────────────────────────────────────────────────────────────────────
def test_styles_without_a_size_stay_exactly_as_they_were():
    legacy = {"captured_effects_hex": _descriptor_hex(), "stroke_enabled": True, "stroke_size": 3}
    for size in (10, 60, 400, None):
        assert fx_scale.scaled(legacy, size) is legacy
    assert fx_scale.mode(legacy) == "original"


def test_the_three_modes():
    st = {"fx_base_size": 100}
    assert fx_scale.mode(st) == "proportional" and fx_scale.factor(st, 50) == 0.5
    assert fx_scale.factor(dict(st, fx_scale_mode="original"), 50) == 1.0
    assert fx_scale.factor(dict(st, fx_scale_mode="custom", fx_scale_pct=150), 50) == 1.5   # whatever the size
    assert fx_scale.factor(dict(st, fx_scale_mode="custom"), 50) == 1.0                    # no % yet
    assert fx_scale.factor(st, None) == 1.0


def test_only_lengths_change_whole_px_half_up():
    params = {"drop_shadow": [{"distance": 5, "size": 3, "spread": 20, "opacity": 75, "angle": 120,
                               "color": [0, 0, 0], "contour": [[0, 0], [255, 255]]}],
              "stroke": {"size": 1, "opacity": 100, "position": "outside"},
              "bevel": {"size": 9, "soften": 2, "depth": 100, "altitude": 30},
              "satin": {"distance": 11, "size": 14, "angle": 19},
              "gradient_overlay": {"scale": 100, "angle": 90}, "opacity": 90}
    out = fx_scale.scale_params(params, 0.5)
    sh = out["drop_shadow"][0]
    assert (sh["distance"], sh["size"]) == (3.0, 2.0)                         # 2.5 -> 3, 1.5 -> 2
    assert (sh["spread"], sh["opacity"], sh["angle"], sh["color"], sh["contour"]) == \
        (20, 75, 120, [0, 0, 0], [[0, 0], [255, 255]])
    assert out["stroke"]["size"] == 1.0                                       # 0.5 never becomes 0
    assert (out["bevel"]["size"], out["bevel"]["soften"], out["bevel"]["depth"]) == (5.0, 1.0, 100)
    assert (out["satin"]["distance"], out["satin"]["size"], out["satin"]["angle"]) == (6.0, 7.0, 19)
    assert out["gradient_overlay"] == params["gradient_overlay"] and out["opacity"] == 90
    assert params["drop_shadow"][0]["distance"] == 5                          # the copy only


def test_every_size_is_worked_out_from_the_copied_values():
    st = fx_scale.remember_size({"captured_effects_hex": _descriptor_hex(blur=7)}, 100)
    once = fx_scale.scaled(st, 133)
    assert fx_scale.scaled(once, 133) is once                                 # never scaled twice
    # 100 -> 133 -> 50 by way of the drawn copy would drift; from the copied values it can't
    direct = _lengths(fx_descriptor.effective_params(fx_scale.scaled(st, 50)))
    assert direct["drop_shadow0.size"] == 4.0 and direct["stroke0.size"] == 2.0


@pytest.mark.parametrize("wide", [True, False])
def test_descriptor_bytes_scale_like_the_params(wide):
    raw = _descriptor_hex(wide=wide)
    st = fx_scale.remember_size({"captured_effects_hex": raw}, 120)
    out = fx_scale.scaled(st, 50)
    h = out["captured_effects_hex"]
    assert len(h) == len(raw) and (h[:2] == "00") == (raw[:2] == "00")      # the same form and length
    want = _lengths(fx_scale.scale_params(fx_descriptor.effective_params(st), 50 / 120))
    assert _lengths(fx_descriptor.effective_params(out)) == want
    assert want["drop_shadow0.distance"] == 3.0 and want["drop_shadow0.size"] == 5.0 and want["stroke0.size"] == 2.0
    # an artist layer's raw block (Mimic) scales the same way
    blk = fx_scale.remember_size({"effects_block": {"key": "lfx2", "hex": _descriptor_hex(wide=False)}}, 120)
    assert _lengths(fx_descriptor.effective_params(fx_scale.scaled(blk, 50))) == want


def test_unscaled_descriptor_is_byte_identical():
    data = fx_descriptor.descriptor_bytes(_descriptor_hex())
    assert fx_scale._scale_stream(data, 1.0) == data


# ── PNG, PSD and Canvas draw the same numbers ────────────────────────────────
def _font(size):
    for name in ("arialbd.ttf", "arial.ttf", "DejaVuSans-Bold.ttf"):
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    pytest.skip("no TrueType font")


def test_psd_layer_gets_the_scaled_descriptor():
    from ps_autotypesetter.psd_writer import document
    from ps_autotypesetter.psd_writer.recorder import TextRecord

    st = fx_scale.remember_size({"captured_effects_hex": _descriptor_hex(stroke=8)}, 120)
    rec = TextRecord(_font(60), (255, 255, 255), "center", st)
    key, payload = document.effects_of(rec.fx_config)
    params = fx_descriptor.decode_effects_hex(payload.hex())
    assert key == b"lfx2" and params["stroke"]["size"] == 4.0
    # the PNG renderer draws the same numbers for the same font
    assert _lengths(ps_fx_png._source_params(fx_scale.scaled(st, _font(60).size))) == _lengths(params)


def test_png_text_effects_follow_the_size():
    from PIL import Image, ImageDraw

    from ps_autotypesetter import png_builder

    st = fx_scale.remember_size({"captured_effects_hex": _descriptor_hex(stroke=10, distance=0, blur=0)}, 40)

    def ink(cfg):
        img = Image.new("RGBA", (400, 160), (0, 0, 0, 0))
        png_builder._draw_text_visual(ImageDraw.Draw(img), 40, 40, "HI", _font(40), (255, 255, 255, 255), 60,
                                      base=img, fx_config=cfg)
        return img.getbbox()

    grown = ink(st)
    fixed = ink(dict(st, fx_scale_mode="original"))
    assert grown == fixed                                     # at its own size: as copied
    st2 = dict(st, fx_base_size=80)                           # copied at 80 px: half the stroke at 40 px
    small = ink(st2)
    assert (small[2] - small[0]) < (fixed[2] - fixed[0])


@pytest.mark.skipif(shutil.which("node") is None, reason="node not installed")
def test_js_scale_matches_python(tmp_path):
    base = {"captured_params": {
        "drop_shadow": [{"distance": 7, "size": 13, "spread": 10, "angle": 90}, {"distance": 0, "size": 1}],
        "outer_glow": {"size": 9, "range": 50}, "inner_glow": {"size": 3}, "inner_shadow": {"distance": 3, "size": 5},
        "stroke": [{"size": 3}, {"size": 6, "opacity": 50}], "bevel": {"size": 9, "soften": 3, "depth": 120},
        "satin": {"distance": 11, "size": 14}, "opacity": 80},
        "stroke_size": 5, "shadow_distance": 4, "shadow_size": 7}
    cases = [(dict(base, fx_base_size=134.15), s) for s in (30, 67.07, 134.15, 200, 401.5)]
    cases += [(dict(base, fx_base_size=60, fx_scale_mode="custom", fx_scale_pct=pct), 10) for pct in (33, 150)]
    cases += [(dict(base, fx_base_size=60, fx_scale_mode="original"), 10), (base, 10)]
    (tmp_path / "cases.json").write_text(json.dumps([[c, s] for c, s in cases]))
    script = tmp_path / "run.js"
    script.write_text(
        "const fs=require('fs');const PsFx=require(" + json.dumps(JS_ENGINE) + ");"
        "const c=JSON.parse(fs.readFileSync(" + json.dumps(str(tmp_path / "cases.json")) + "));"
        "process.stdout.write(JSON.stringify(c.map(([cfg,s])=>PsFx.scaleFor(cfg,s))));")
    js = json.loads(subprocess.run(["node", str(script)], check=True, capture_output=True, timeout=60).stdout)
    for (cfg, size), got in zip(cases, js):
        py = fx_scale.scaled(cfg, size)
        keys = ("captured_params", "stroke_size", "shadow_distance", "shadow_size", "fx_scale_mode")
        assert {k: py.get(k) for k in keys} == {k: got.get(k) for k in keys}, (cfg.get("fx_scale_mode"), size)


# ── Mimic a PSD: the Global Light comes with the style, like a paste ─────────
def test_mimic_style_brings_the_psd_global_light(monkeypatch, tmp_path):
    from ps_autotypesetter.artist_design import psd_reader

    psd = tmp_path / "Help.psd"
    psd.write_bytes(b"8BPS")
    style = {"effects_block": {"key": "lfx2", "hex": _descriptor_hex(use_global_light=True, angle=120, wide=False)},
             "captured_params": {"fill_opacity": 100.0}}
    body = "Wins pay left to right on adjacent reels starting from the leftmost reel. " * 2
    layers = [dict(text=body, font="ArialMT", size=36, leading=43, color="#ffffff", alignment="center", lines=3,
                   chars=120, bbox=(100, 400, 1800, 500), bold=False, numbers=False, effects=None, visible=True,
                   name="")] * 4
    layers += [dict(text="FEATURES", font="Arial-Black", size=120, leading=144, color="#ffcc00", alignment="center",
                    lines=1, chars=8, bbox=(700, 40, 1200, 160), bold=True, numbers=False, effects=style, visible=True,
                    name="title")] * 3
    monkeypatch.setattr(psd_reader, "open_psd", lambda p: type("P", (), {"width": 1920, "height": 1080})())
    monkeypatch.setattr(imp, "read_layers", lambda p: layers)
    monkeypatch.setattr(imp, "bg_layer", lambda p: None)
    monkeypatch.setattr(global_light, "read_psd", lambda p: {"angle": 90.0, "altitude": 30.0})
    res = imp.analyse(str(psd))
    head = res["styles"]["Heading text"]
    assert head["global_light"] == {"angle": 90.0, "altitude": 30.0}
    assert head["style"]["fx_base_size"] == 120 and head["style"]["fx_scale_mode"] == "proportional"

    # only the heading ticked (the Global light field left alone): the PSD's light still comes along
    fields = [dict(f, apply=f["key"].startswith("h_")) for f in res["fields"]]
    ds = imp.apply({}, fields, res["styles"])["dynamic_settings"]
    assert ds["fx_global_light"] == {"angle": 90.0, "altitude": 30.0}
    global_light.set_all(ds)
    try:
        N = ps_fx_png.normalize_params(ds["layer_style_library"][ds["style_assignments"]["Heading text"]])
        assert N["drop_shadows"][0]["angle"] == 90.0          # as Photoshop draws it (the style says 120)
    finally:
        global_light.set_all({})

    # the Global light field ticked (and edited by the artist) wins
    fields = [dict(f, apply=True, value=[45, 30] if f["key"] == "ds.fx_global_light" else f["value"])
              for f in res["fields"]]
    assert imp.apply({}, fields, res["styles"])["dynamic_settings"]["fx_global_light"]["angle"] == 45.0


def test_mimic_style_without_global_light_effects_sets_no_light():
    styles = {"Heading text": {"name": "h", "style": {"captured_params": {}}}}
    assert "fx_global_light" not in imp.apply({}, [], styles)["dynamic_settings"]


# ── copying from Photoshop: one script, its text size and light ──────────────
def test_capture_result_carries_text_size_and_errors():
    from ps_autotypesetter import layer_styles

    got = layer_styles._parse_capture_result(json.dumps({"hex": "0010", "params": {}, "text_px": 134.1538,
                                                         "extra": "-32,,E:/a.psd"}))
    assert got["text_px"] == 134.15 and got["extra"] == "-32,,E:/a.psd"
    with pytest.raises(RuntimeError, match="Open a Photoshop document"):
        layer_styles._capture_result(layer_styles._NO_DOCUMENT, "copied")


def test_capture_is_one_script(monkeypatch):
    from ps_autotypesetter import layer_styles

    calls = []

    def run(jsx, *a, **k):
        calls.append(jsx)
        return json.dumps({"hex": "0010" * 30, "params": {}, "text_px": 80, "extra": "90,30,"})

    monkeypatch.setattr(photoshop_bridge, "run_jsx", run)
    out = layer_styles.capture_copied_layer_style_from_photoshop(extra_js='"x"')
    assert len(calls) == 1 and out["text_px"] == 80 and out["extra"] == "90,30,"
    layer_styles.capture_selected_layer_style_from_photoshop()
    assert len(calls) == 2


def test_bridge_uses_the_running_versions_own_com_id(monkeypatch):
    monkeypatch.setattr(photoshop_bridge, "running_photoshops", lambda: [(1, r"D:\PS 2023\Photoshop.exe")])
    monkeypatch.setattr(photoshop_bridge, "registered_photoshop", lambda: r"F:\PS 2026\Photoshop.exe")
    monkeypatch.setattr(photoshop_bridge, "version_progids",
                        lambda: {photoshop_bridge._norm(r"D:\PS 2023\Photoshop.exe"): "Photoshop.Application.170"})
    info = photoshop_bridge.describe()
    assert (info["route"], info["progid"]) == ("com", "Photoshop.Application.170")
    monkeypatch.setattr(photoshop_bridge, "version_progids", lambda: {})
    assert photoshop_bridge.describe()["route"] == "file"                   # no own id: the script file, as before
