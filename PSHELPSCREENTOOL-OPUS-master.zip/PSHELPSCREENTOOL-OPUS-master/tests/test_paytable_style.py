"""Tests for the shared paytable style logic + preview warning indicators."""

import os
import tempfile

import pytest

from ps_autotypesetter.ui_web import paytable_style_common as style


def test_norm_font():
    assert style.norm_font("ArialMT") == "arial"
    assert style.norm_font("Arial-BoldMT") == "arialbold"
    assert style.norm_font("") == ""
    assert style.norm_font(None) == ""


def test_ps_font_tff_fallback_keys():
    # Every canonical Photoshop PostScript name maps to a TrueType file.
    assert style.PS_FONT_TTF_FALLBACKS["arialmt"] == "arial.ttf"
    assert style.PS_FONT_TTF_FALLBACKS["timesnewromanpsmt"] == "times.ttf"


def test_resolve_font_file():
    if os.name != "nt":
        pytest.skip("Windows font registry only")
    path = style.resolve_font_file("ArialMT")
    assert path and os.path.isfile(path)
    assert style.resolve_font_file("") is None


def test_px_pt_conversion():
    assert style.px_to_pt(30) == 30
    assert style.pt_to_px(72) == 72


def test_default_font_sizes():
    assert style.default_font_size_for("") == 30
    assert style.default_font_size_for("heading") == 72
    assert style.default_font_size_for("WILD") == 72


def test_preview_overflow_reported():
    from ps_autotypesetter.ui_web import ps_actions

    pytest.importorskip("PIL")
    template = {
        "canvas": {"width": 600, "height": 400},
        "slots": {
            "ten.pay": {"x": 10, "y": 10, "w": 120, "h": 40},
            "ten.value": {"x": 140, "y": 10, "w": 120, "h": 40},
        },
    }
    mappings = {
        "ten.pay": {"slot": "ten.pay", "mode": "text", "source": "", "text": "50000.00", "font_size": 200},
        "ten.value": {"slot": "ten.value", "mode": "text", "source": "", "text": "1", "font_size": 30},
    }
    out = os.path.join(str(pytest.importorskip("tempfile").gettempdir()), "pt_overflow_test.png")
    report = {}
    try:
        path = ps_actions.render_table_outline_preview(template, out, settings={}, mappings=mappings, report=report)
        assert path, "preview should render"
    finally:
        if os.path.isfile(out):
            os.remove(out)
    assert "ten.pay" in (report.get("overflow_issues") or []), report
    assert "ten.value" not in (report.get("overflow_issues") or []), report


def test_preview_overflow_absent_when_fit():
    from ps_autotypesetter.ui_web import ps_actions

    pytest.importorskip("PIL")
    template = {
        "canvas": {"width": 600, "height": 400},
        "slots": {"tiny": {"x": 10, "y": 10, "w": 200, "h": 80}},
    }
    mappings = {
        "tiny": {"slot": "tiny", "mode": "text", "source": "", "text": "OK", "font_size": 12},
    }
    out = os.path.join(str(pytest.importorskip("tempfile").gettempdir()), "pt_fit_test.png")
    report = {}
    try:
        path = ps_actions.render_table_outline_preview(template, out, settings={}, mappings=mappings, report=report)
        assert path, "preview should render"
    finally:
        if os.path.isfile(out):
            os.remove(out)
    assert not (report.get("overflow_issues") or []), report


def test_preview_true_size_render():
    from PIL import Image

    from ps_autotypesetter.ui_web import ps_actions

    pytest.importorskip("PIL")
    tmp = tempfile.mkdtemp(prefix="pt_true_")
    template = {
        "canvas": {"width": 1920, "height": 1080},
        "slots": {"demo": {"x": 100, "y": 100, "w": 400, "h": 200}},
    }
    mappings = {
        "demo": {"slot": "demo", "mode": "text", "source": "", "text": "Hi", "font_size": 30},
    }
    out = os.path.join(tmp, "out.png")
    try:
        path = ps_actions.render_table_outline_preview(template, out, settings={}, mappings=mappings)
        assert path and os.path.isfile(path), "preview should render"
        img = Image.open(path).convert("RGB")
        assert img.size == (1920, 1080), f"preview must be true size, got {img.size}"
        border = img.getpixel((101, 150))
        assert abs(border[0] - 96) < 40 and abs(border[1] - 140) < 40 and abs(border[2] - 255) < 40, (
            f"slot border not at true-size coords: {border}"
        )
    finally:
        if os.path.isfile(out):
            os.remove(out)


def test_preview_4k_template_scaled_to_target():
    from PIL import Image

    from ps_autotypesetter.ui_web import ps_actions

    pytest.importorskip("PIL")
    tmp = tempfile.mkdtemp(prefix="pt_4k_")
    template = {
        "canvas": {"width": 3840, "height": 2160},
        "slots": {"demo": {"x": 100, "y": 100, "w": 400, "h": 200}},
    }
    mappings = {
        "demo": {"slot": "demo", "mode": "text", "source": "", "text": "Hi", "font_size": 30},
    }
    out = os.path.join(tmp, "out.png")
    try:
        path = ps_actions.render_table_outline_preview(template, out, settings={}, mappings=mappings)
        assert path and os.path.isfile(path), "preview should render"
        img = Image.open(path).convert("RGB")
        assert img.size == (1920, 1080), f"4K template must render at 1920x1080 target, got {img.size}"
        border = img.getpixel((51, 150))
        assert abs(border[0] - 96) < 40 and abs(border[1] - 140) < 40 and abs(border[2] - 255) < 40, (
            f"slot border not at scaled coords (x=100 -> 50): {border}"
        )
    finally:
        if os.path.isfile(out):
            os.remove(out)


def test_preview_annotations_off_hides_blueprint():
    from PIL import Image

    from ps_autotypesetter.ui_web import ps_actions

    pytest.importorskip("PIL")
    tmp = tempfile.mkdtemp(prefix="pt_clean_")
    template = {
        "canvas": {"width": 3840, "height": 2160},
        "slots": {"demo": {"x": 100, "y": 100, "w": 400, "h": 200}},
    }
    mappings = {
        "demo": {"slot": "demo", "mode": "text", "source": "", "text": "Hi", "font_size": 30},
    }
    out = os.path.join(tmp, "out.png")
    try:
        path = ps_actions.render_table_outline_preview(
            template, out, settings={}, mappings=mappings, annotations=False
        )
        assert path and os.path.isfile(path), "preview should render"
        img = Image.open(path).convert("RGB")
        px = img.getpixel((51, 150))
        assert abs(px[0] - 18) < 10 and abs(px[1] - 22) < 10 and abs(px[2] - 30) < 10, (
            f"blueprint outline must be hidden in clean render: {px}"
        )
    finally:
        if os.path.isfile(out):
            os.remove(out)


def test_automap_paytable_mixed_case_anchors_and_letter_variants():
    """Pay/value slots resolve anchors regardless of case/space ("<PIC1>",
    "<Pic 2>") and through symbol-name variants ("ace" -> "<A>",
    "ten" -> "<10>")."""
    from openpyxl import Workbook

    from ps_autotypesetter.ui_web import engine_api

    pytest.importorskip("openpyxl")
    tmp = tempfile.mkdtemp(prefix="pt_automap_")
    xlsx = os.path.join(tmp, "t.xlsx")
    wb = Workbook()
    ws = wb.active
    ws["D19"] = "<PIC1>"; ws["F18"] = 5;   ws["H18"] = 150
    ws["F19"] = 4;        ws["H19"] = 50
    ws["F20"] = 3;        ws["H20"] = 15
    ws["D23"] = "<Pic 2>"; ws["F22"] = 5;  ws["H22"] = 150
    ws["F23"] = 4;        ws["H23"] = 50
    ws["F24"] = 3;        ws["H24"] = 15
    ws["D39"] = "<A>";    ws["F38"] = 5;   ws["H38"] = 100
    ws["F39"] = 4;        ws["H39"] = 30
    ws["F40"] = 3;        ws["H40"] = 10
    ws["D51"] = "<10>";   ws["F50"] = 5;   ws["H50"] = 100
    ws["F51"] = 4;        ws["H51"] = 30
    ws["F52"] = 3;        ws["H52"] = 10
    wb.save(xlsx)
    try:
        template = {"slots": {
            "@slot.pic1.pay": {}, "@slot.pic1.value": {},
            "@slot.pic2.pay": {}, "@slot.pic2.value": {},
            "@slot.ace.pay": {}, "@slot.ace.value": {},
            "@slot.ten.pay": {}, "@slot.ten.value": {},
        }}
        result = engine_api.automap_paytable_slots(template, xlsx, "Sheet")
        by_slot = {m["slot"]: m for m in result["mappings"]}
        assert by_slot["@slot.pic1.pay"]["source"] == "F18,F19,F20"
        assert by_slot["@slot.pic1.pay"]["text"] == "5\n4\n3"
        assert by_slot["@slot.pic1.value"]["source"] == "H18,H19,H20"
        assert by_slot["@slot.pic1.value"]["text"] == "150\n50\n15"
        assert by_slot["@slot.pic2.pay"]["source"] == "F22,F23,F24"
        assert by_slot["@slot.ace.pay"]["source"] == "F38,F39,F40"
        assert by_slot["@slot.ace.value"]["source"] == "H38,H39,H40"
        assert by_slot["@slot.ten.pay"]["source"] == "F50,F51,F52"
        assert by_slot["@slot.ten.value"]["source"] == "H50,H51,H52"
        assert "@slot.pic1.pay" not in result["unmapped"]
    finally:
        if os.path.isfile(xlsx):
            os.remove(xlsx)


def test_automap_symbol_canon_table_jack_queen():
    """The canonical symbol table resolves "<J>"/"<Q>" anchors to jack/queen
    slots (case/space-insensitive, like A->ace, 10->ten)."""
    from openpyxl import Workbook

    from ps_autotypesetter.ui_web import engine_api

    pytest.importorskip("openpyxl")
    tmp = tempfile.mkdtemp(prefix="pt_canon_")
    xlsx = os.path.join(tmp, "t.xlsx")
    wb = Workbook()
    ws = wb.active
    ws["D19"] = "<J>";  ws["F18"] = 5; ws["H18"] = 100
    ws["F19"] = 4;      ws["H19"] = 30
    ws["F20"] = 3;      ws["H20"] = 10
    ws["D23"] = "Q";    ws["F22"] = 5; ws["H22"] = 100
    ws["F23"] = 4;      ws["H23"] = 30
    ws["F24"] = 3;      ws["H24"] = 10
    wb.save(xlsx)
    try:
        template = {"slots": {
            "jack.pay": {}, "jack.value": {},
            "queen.pay": {}, "queen.value": {},
            "@slot.pic1.pay": {},
        }}
        result = engine_api.automap_paytable_slots(template, xlsx, "Sheet")
        by_slot = {m["slot"]: m for m in result["mappings"]}
        assert by_slot["jack.pay"]["source"] == "F18,F19,F20"
        assert by_slot["jack.value"]["source"] == "H18,H19,H20"
        assert by_slot["queen.pay"]["source"] == "F22,F23,F24"
        assert by_slot["queen.value"]["source"] == "H22,H23,H24"
    finally:
        if os.path.isfile(xlsx):
            os.remove(xlsx)


def test_automap_paytable_text_slots():
    """The ".text" slot collects ALL the remaining plain text of the page
    (every unused text cell, newline-joined, refs comma-joined); other text
    slots take the next single unused cell; title-like slots stay unmapped
    (the renderer fills the page heading into ``.title`` itself); wild/
    feature title slots stay unmapped too (they render "WILD" by default);
    artist notes and symbol/pay cells never leak in."""
    from openpyxl import Workbook

    from ps_autotypesetter.ui_web import engine_api

    pytest.importorskip("openpyxl")
    tmp = tempfile.mkdtemp(prefix="pt_text_")
    xlsx = os.path.join(tmp, "t.xlsx")
    wb = Workbook()
    ws = wb.active
    ws["A1"] = "MY GAME PAYTABLE"; ws["C2"] = "All wins pay left to right"
    ws["D3"] = "Collect 5 of a kind"
    ws["C4"] = "<WILD> substitutes for all symbols except <purple_scat>."
    ws["C5"] = "<WILD>"  # pure-token legend row — never body text
    ws["E5"] = "PAYS"; ws["G5"] = "VALUE"
    ws["D9"] = "<PIC1>"; ws["F8"] = 5; ws["H8"] = 150
    ws["F9"] = 4;        ws["H9"] = 50
    ws["F10"] = 3;       ws["H10"] = 15
    ws["N20"] = "NOTE <BO> brand per agreement"
    wb.save(xlsx)
    try:
        template = {"slots": {
            "@slot.title": {}, "@slot.subtitle": {}, "@slot.text": {}, "@slot.notes": {},
            "@slot.wild.title": {}, "@slot.wild.text": {}, "feature.title": {},
            "@slot.pic1": {}, "@slot.pic1.pay": {}, "@slot.pic1.value": {},
        }}
        result = engine_api.automap_paytable_slots(template, xlsx, "Sheet")
        by_slot = {m["slot"]: m for m in result["mappings"]}
        assert "@slot.title" in result["unmapped"], "title slot never takes a text cell"
        assert "@slot.subtitle" in result["unmapped"]
        assert "@slot.wild.title" in result["unmapped"]
        assert "@slot.wild.text" in result["unmapped"], "wild text stays unmapped"
        assert "feature.title" in result["unmapped"]
        assert by_slot["@slot.text"]["mode"] == "excel"
        assert by_slot["@slot.text"]["source"] == "C2,D3,C4"
        assert by_slot["@slot.text"]["text"] == (
            "All wins pay left to right\nCollect 5 of a kind\n"
            "<WILD> substitutes for all symbols except <purple_scat>."
        )
        assert "@slot.notes" in result["unmapped"], "text consumed every remaining cell"
        assert by_slot["@slot.pic1.pay"]["source"] == "F8,F9,F10"
        assert by_slot["@slot.pic1.value"]["source"] == "H8,H9,H10"
        assert all("NOTE <BO>" not in (m.get("text") or "") for m in result["mappings"])
    finally:
        if os.path.isfile(xlsx):
            os.remove(xlsx)


def test_auto_fill_pay_value_slots():
    """auto_fill_pay_value_slots: mapping only the main symbol (pic2)
    automatically fills its .pay/.value slots from Excel; template slots that
    don't exist and symbols not in the sheet are skipped; already-populated
    mappings are never overridden."""
    from openpyxl import Workbook

    from ps_autotypesetter.ui_web import engine_api

    pytest.importorskip("openpyxl")
    tmp = tempfile.mkdtemp(prefix="pt_autofill_")
    xlsx = os.path.join(tmp, "t.xlsx")
    wb = Workbook()
    ws = wb.active
    ws["D19"] = "<Pic 2>"; ws["F18"] = 9; ws["H18"] = 99
    ws["F19"] = 6;         ws["H19"] = 999
    ws["F20"] = 3;         ws["H20"] = 66
    wb.save(xlsx)
    try:
        template = {"slots": {
            "pic2": {}, "pic2.pay": {}, "pic2.value": {},
            "pic3": {}, "pic3.pay": {}, "pic3.value": {},
            "ace.pay": {},  # slot exists but "ace" is not mapped
        }}
        mappings = {
            "pic2": {"mode": "icon", "token": "<pic2>"},
            "pic3": {"mode": "icon", "token": "<pic3>"},
            "pic2.pay": {"mode": "text", "source": "", "text": ""},  # empty default
            "pic2.value": {"mode": "text", "source": "", "text": "custom"},  # user-set -> keep
        }
        result = engine_api.auto_fill_pay_value_slots(template, mappings, xlsx, "Sheet")
        assert result["ok"] is True
        filled = result["mappings"]
        assert filled["pic2.pay"]["mode"] == "excel"
        assert filled["pic2.pay"]["source"] == "F18,F19,F20"
        assert filled["pic2.pay"]["text"] == "9\n6\n3"
        assert "pic2.value" not in filled, "user-set text must not be overridden"
        assert "pic3.pay" not in filled, "pic3 has no anchor in the sheet"
        assert "pic3.value" not in filled
        assert "ace.pay" not in filled, "unmapped symbol must not be filled"
        assert result["filled"] == 1
        empty = engine_api.auto_fill_pay_value_slots(template, {}, xlsx, "Sheet")
        assert empty == {"ok": True, "mappings": {}, "filled": 0}
    finally:
        if os.path.isfile(xlsx):
            os.remove(xlsx)


def test_preview_uses_document_canvas_size():
    from PIL import Image

    from ps_autotypesetter.ui_web import ps_actions

    pytest.importorskip("PIL")
    tmp = tempfile.mkdtemp(prefix="pt_docsize_")
    template = {
        "canvas": {"width": 3840, "height": 2160},
        "slots": {"demo": {"x": 100, "y": 100, "w": 400, "h": 200}},
    }
    mappings = {
        "demo": {"slot": "demo", "mode": "text", "source": "", "text": "Hi", "font_size": 30},
    }
    out = os.path.join(tmp, "out.png")
    try:
        path = ps_actions.render_table_outline_preview(
            template, out, settings={"canvas_width": 3840, "canvas_height": 2160}, mappings=mappings
        )
        assert path and os.path.isfile(path), "preview should render"
        img = Image.open(path).convert("RGB")
        assert img.size == (3840, 2160), f"preview must match the document size, got {img.size}"
        border = img.getpixel((101, 150))
        assert abs(border[0] - 96) < 40 and abs(border[1] - 140) < 40 and abs(border[2] - 255) < 40, (
            f"slot not drawn unscaled in a 1:1 document: {border}"
        )
    finally:
        if os.path.isfile(out):
            os.remove(out)


def test_preview_uses_bg_image():
    from PIL import Image

    from ps_autotypesetter.ui_web import ps_actions

    pytest.importorskip("PIL")
    tmp = tempfile.mkdtemp(prefix="pt_bg_")
    bg = os.path.join(tmp, "bg.png")
    Image.new("RGB", (600, 400), (200, 30, 30)).save(bg)
    template = {
        "canvas": {"width": 600, "height": 400},
        "slots": {"wild.title": {"x": 20, "y": 20, "w": 200, "h": 60}},
    }
    mappings = {
        "wild.title": {"slot": "wild.title", "mode": "text", "source": "", "text": "WILD", "font_size": 20},
    }
    out = os.path.join(tmp, "out.png")
    try:
        path = ps_actions.render_table_outline_preview(template, out, settings={}, mappings=mappings, bg_path=bg)
        assert path and os.path.isfile(path)
        px = Image.open(path).convert("RGB").getpixel((5, 380))
        assert px[0] > 150 and px[1] < 100, f"background not applied: {px}"
    finally:
        for f in (bg, out):
            if os.path.isfile(f):
                os.remove(f)


def _preview_pixels(template, mappings, icon_folder="", settings=None):
    from PIL import Image

    from ps_autotypesetter.ui_web import ps_actions

    tmp = tempfile.mkdtemp(prefix="pt_opt_")
    out = os.path.join(tmp, "out.png")
    path = ps_actions.render_table_outline_preview(
        template, out, settings=settings or {}, mappings=mappings,
        icon_folder=icon_folder, annotations=False,
    )
    assert path and os.path.isfile(path), "preview should render"
    return Image.open(path).convert("RGB")


def _white_rows(img, x0, x1, y0, y1):
    px = img.load()
    rows = []
    for y in range(y0, y1):
        if any(sum(px[x, y]) > 600 for x in range(x0, x1, 2)):
            rows.append(y)
    return rows


def _red_rows(img, x0, x1, y0, y1):
    px = img.load()
    rows = []
    for y in range(y0, y1):
        if any(px[x, y][0] > 200 and px[x, y][1] < 90 and px[x, y][2] < 90 for x in range(x0, x1, 2)):
            rows.append(y)
    return rows


def test_preview_icons_centered_on_text_line():
    pytest.importorskip("PIL")
    tmp = tempfile.mkdtemp(prefix="pt_icon_")
    icon = os.path.join(tmp, "PIC1.png")
    from PIL import Image as PILImage

    PILImage.new("RGBA", (40, 40), (255, 0, 0, 255)).save(icon)
    template = {
        "canvas": {"width": 400, "height": 200},
        "slots": {"demo": {"x": 50, "y": 50, "w": 300, "h": 100}},
    }
    mappings = {
        "demo": {"slot": "demo", "mode": "excel", "source": "", "text": "<PIC1> HI THERE",
                 "font_size": 24, "icon_height": 48, "color": "#FFFFFF"},
    }
    img = _preview_pixels(template, mappings, icon_folder=tmp, settings={"canvas_width": 400, "canvas_height": 200})
    white = _white_rows(img, 70, 350, 50, 150)
    red = _red_rows(img, 50, 350, 50, 150)
    assert white and red, f"expected text+icon pixels: white={white[:3]} red={red[:3]}"
    text_center = (white[0] + white[-1]) / 2.0
    icon_center = (red[0] + red[-1]) / 2.0
    assert abs(text_center - icon_center) <= 4.0, (
        f"icon not centered on its text line: text_center={text_center} icon_center={icon_center}"
    )


def test_preview_padding_insets_content():
    pytest.importorskip("PIL")
    template = {
        "canvas": {"width": 400, "height": 200},
        "slots": {"demo": {"x": 50, "y": 50, "w": 300, "h": 100}},
    }
    base = {"slot": "demo", "mode": "text", "source": "", "text": "LINE ONE",
            "font_size": 24, "color": "#FFFFFF", "vertical_align": "top"}
    img_none = _preview_pixels(template, {"demo": dict(base)}, settings={"canvas_width": 400, "canvas_height": 200})
    img_pad = _preview_pixels(
        template, {"demo": {**base, "padding": [30, 20, 30, 20]}},
        settings={"canvas_width": 400, "canvas_height": 200},
    )
    rows_none = _white_rows(img_none, 40, 360, 40, 160)
    rows_pad = _white_rows(img_pad, 40, 360, 40, 160)
    assert rows_none and rows_pad
    assert rows_none[0] < 80, f"unpadded top-aligned text should start high, got {rows_none[0]}"
    assert rows_pad[0] - rows_none[0] >= 25, (
        f"padding top 30 must push the text down: none={rows_none[0]} pad={rows_pad[0]}"
    )


def test_preview_line_height_option_works():
    pytest.importorskip("PIL")
    template = {
        "canvas": {"width": 400, "height": 220},
        "slots": {"demo": {"x": 50, "y": 10, "w": 300, "h": 200}},
    }
    base = {"slot": "demo", "mode": "text", "source": "", "text": "FIRST LINE\nSECOND LINE",
            "font_size": 24, "color": "#FFFFFF"}
    img_auto = _preview_pixels(template, {"demo": dict(base)}, settings={"canvas_width": 400, "canvas_height": 220})
    img_wide = _preview_pixels(
        template, {"demo": {**base, "line_height": 90}},
        settings={"canvas_width": 400, "canvas_height": 220},
    )
    span_auto = _white_rows(img_auto, 50, 350, 10, 210)
    span_wide = _white_rows(img_wide, 50, 350, 10, 210)
    assert span_auto and span_wide
    span_auto_h = span_auto[-1] - span_auto[0]
    span_wide_h = span_wide[-1] - span_wide[0]
    assert span_wide_h > span_auto_h + 40, (
        f"line_height must widen the text block: auto={span_auto_h} wide={span_wide_h}"
    )


def test_preview_explicit_font_size_not_shrunk():
    """A pay/value stack mapped at 30px renders at ~30px even inside a short
    box — the auto-fit must never fight an explicit font_size (regression:
    stacks were shrinking all the way to 8px)."""
    pytest.importorskip("PIL")
    template = {
        "canvas": {"width": 600, "height": 400},
        "slots": {"pic1.pay": {"x": 10, "y": 10, "w": 280, "h": 96}},
    }
    mappings = {
        "pic1.pay": {"slot": "pic1.pay", "mode": "excel", "source": "", "text": "5\n4\n3\n2",
                     "font_size": 30, "icon_height": 48, "color": "#FFFFFF"},
    }
    img = _preview_pixels(template, {"pic1.pay": mappings["pic1.pay"]},
                          settings={"canvas_width": 600, "canvas_height": 400})
    rows = _white_rows(img, 0, 300, 0, 250)
    assert rows, "pay stack should draw"
    bands = []
    for y in rows:
        if bands and y - bands[-1][-1] <= 2:
            bands[-1].append(y)
        else:
            bands.append([y])
    assert len(bands) == 4, f"expected 4 pay lines, got {len(bands)} bands"
    heights = [b[-1] - b[0] + 1 for b in bands]
    assert all(18 <= h <= 28 for h in heights), (
        f"30px stack glyphs should be ~21px ink per line, got {heights}"
    )


def test_classic_layout_two_bands():
    """The classic layout is a two-band template: 5 top cards + wild column,
    and a second row of 5 lower cards, each column owning pay/value slots —
    so a 10-card sheet auto-fills pic1..pic10."""
    from ps_autotypesetter.ui_web.paytable_layouts import get_paytable_layout

    template = get_paytable_layout("classic")
    slots = template["slots"]
    for n in range(1, 11):
        assert f"@slot.pic{n}" in slots
        assert f"@slot.pay{n}" in slots
        assert f"@slot.value{n}" in slots
    assert "@slot.wild" in slots
    assert "@slot.title" in slots
    top_cards = [slots["@slot.pic%d" % n] for n in (1, 2, 5)]
    bottom_cards = [slots["@slot.pic%d" % n] for n in (6, 7, 10)]
    assert all(b["y"] > top_cards[0]["y"] + top_cards[0]["h"] for b in bottom_cards)
    assert all(abs(t["y"] - top_cards[0]["y"]) <= 1 for t in top_cards)
    assert all(abs(b["y"] - bottom_cards[0]["y"]) <= 1 for b in bottom_cards)


def _two_band_sheet(path):
    """10-card two-row sheet: <PIC1..5> top, ACE/KING/QUEEN/JACK/TEN below,
    each label owning a 4-cell pay run (col F) and value run (col H),
    with a blank row between blocks so the runs stay bounded."""
    from openpyxl import Workbook

    wb = Workbook()
    ws = wb.active
    labels = ["<PIC1>", "<PIC2>", "<PIC3>", "<PIC4>", "<PIC5>",
              "ACE", "KING", "QUEEN", "JACK", "TEN"]
    row = 14
    for label in labels:
        ws.cell(row=row, column=4, value=label)
        for i, v in enumerate((5, 4, 3, 2)):
            ws.cell(row=row + 1 + i, column=6, value=v)
        for i, v in enumerate((150, 50, 10, 5)):
            ws.cell(row=row + 1 + i, column=8, value=v)
        row += 6
    wb.save(path)


def test_automap_two_band_positional_bottom_row():
    """pic6..pic10 (the classic layout's bottom band) bind positionally to
    the sheet's lower cards (ace..ten) when the sheet has no PIC6 anchors."""
    from ps_autotypesetter.ui_web import engine_api
    from ps_autotypesetter.ui_web.paytable_layouts import get_paytable_layout

    pytest.importorskip("openpyxl")
    tmp = tempfile.mkdtemp(prefix="pt_2band_")
    xlsx = os.path.join(tmp, "t.xlsx")
    _two_band_sheet(xlsx)
    try:
        result = engine_api.automap_paytable_slots(
            get_paytable_layout("classic"), xlsx, "Sheet")
        by_slot = {m["slot"]: m for m in result["mappings"]}
        assert by_slot["@slot.pic1"]["token"] == "<pic1>"
        assert by_slot["@slot.pic6"]["token"] == "<ace>"
        assert by_slot["@slot.pic7"]["token"] == "<king>"
        assert by_slot["@slot.pic8"]["token"] == "<queen>"
        assert by_slot["@slot.pic9"]["token"] == "<jack>"
        assert by_slot["@slot.pic10"]["token"] == "<ten>"
        assert by_slot["@slot.pic6"]["mode"] == "icon"
        assert by_slot["@slot.pay6"]["source"] == "F45,F46,F47,F48"
        assert by_slot["@slot.value6"]["source"] == "H45,H46,H47,H48"
        assert by_slot["@slot.pay10"]["source"] == "F69,F70,F71,F72"
        assert "@slot.pic10" not in result["unmapped"]
        assert result["card_counts"] == {"top": 5, "lower": 5}
    finally:
        if os.path.isfile(xlsx):
            os.remove(xlsx)


def test_automap_two_band_honors_user_row_counts():
    """mapper_meta.row_counts override the top/lower split; the bottom band
    still binds positionally below the top count."""
    from ps_autotypesetter.ui_web import engine_api
    from ps_autotypesetter.ui_web.paytable_layouts import get_paytable_layout

    pytest.importorskip("openpyxl")
    tmp = tempfile.mkdtemp(prefix="pt_2band_rc_")
    xlsx = os.path.join(tmp, "t.xlsx")
    _two_band_sheet(xlsx)
    try:
        template = get_paytable_layout("classic")
        template["mapper_meta"]["row_counts"] = {"top": 4, "bottom": 6}
        result = engine_api.automap_paytable_slots(template, xlsx, "Sheet")
        by_slot = {m["slot"]: m for m in result["mappings"]}
        assert result["card_counts"] == {"top": 4, "lower": 6}
        assert by_slot["@slot.pic6"]["token"] == "<ace>"
        assert by_slot["@slot.pay6"]["source"] == "F45,F46,F47,F48"
    finally:
        if os.path.isfile(xlsx):
            os.remove(xlsx)
