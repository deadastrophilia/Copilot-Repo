"""Layout manifest parity: PNG canonical pipeline vs PSAPI PSD pipeline.

The canonical PNG renderer and the headless PSAPI PSD writer are independent
implementations of the same layout intent. Each side can export a geometry
manifest (every element's text, position, size). These tests assert the
invariants that must hold across BOTH renderers:

  - identical element count / order / text content
  - every body line horizontally centered on the canvas center
  - heading anchored at the configured top margin
  - vertical positions strictly increasing (no overlaps)

Cross-renderer vertical rhythm is intentionally NOT asserted pixel-exact:
the two pipelines use different row-advance math by design; the manifests
(written to disk) exist to make that drift inspectable.
"""

import json
import os

import pytest
from openpyxl import Workbook
from openpyxl.styles import Font

from ps_autotypesetter import layout_engine, png_builder
from ps_autotypesetter.layout_manifest import manifest_from_backend_ops

try:
    import photoshopapi  # noqa: F401

    _HAS_PSAPI = True
except Exception:
    _HAS_PSAPI = False


def _make_workbook(path):
    wb = Workbook()
    ws = wb.active
    ws.title = "PAGE1"
    cell = ws.cell(row=1, column=1, value="GAME RULES")
    cell.font = Font(bold=True)
    ws.append(["Simple body line one"])
    ws.append(["Body line two continues here"])
    ws.append(["Last body line"])
    wb.save(path)


def _build_png(path, output_dir, manifest_dir):
    return png_builder.build_pngs_only(
        excel_path=path, icon_folder="", bg_path="",
        c_width=1920, c_height=1080, max_col_limit=12,
        h_font="Arial", h_size=72, h_icon_h=48, h_rgb="#FF5050",
        b_font="Arial", b_size=30, b_icon_h=24, b_rgb="#FFFFFF",
        margin_x=100, line_spacing=4, para_spacing=12,
        gap_px=12, icon_y_offset=0,
        bg_mode="stretch", bg_color="#FFFFFF",
        heading_top_margin=120, continued_gap=15, heading_to_body_gap=40,
        bottom_margin=80, inner_canvas_width=0,
        page_min_row=1, page_max_row=100,
        page_min_col=1, page_max_col=12,
        page_overrides={},
        dynamic_settings={"line_gap": 30, "layout_manifest_dir": str(manifest_dir)},
        use_canonical_layout=True,
        output_dir=str(output_dir), output_name=None,
    )


def _build_psapi(path, output_dir):
    from ps_autotypesetter.build_engine_psapi import execute_build_psapi
    from ps_autotypesetter.psapi_render_backend import PSAPIRenderBackend

    backend = PSAPIRenderBackend(record_ops=True)
    execute_build_psapi(
        excel_path=str(path), icon_folder="", bg_path="", c_width=1920,
        c_height=1080, max_col_limit=12,
        h_font="Arial", h_size=72, h_icon_h=48, h_rgb=(255, 80, 80),
        b_font="Arial", b_size=30, b_icon_h=24, b_rgb=(255, 255, 255),
        margin_x=100, line_spacing=4, para_spacing=12, gap_px=12,
        icon_y_offset=0, row_spacing=30, bg_mode="stretch", table_style=None,
        enable_tables=True, bg_color="#FFFFFF", prev_excel_path=None,
        prev_psd_path=None, keyword_colors=None, heading_top_margin=120,
        continued_gap=15, heading_to_body_gap=40, heading_style=None,
        dynamic_settings={"line_gap": 30}, output_dir=str(output_dir),
        icon_mappings=None, icon_size_overrides=None, bottom_margin=80,
        output_name="parity.psd", output_format="PSD", overwrite_existing=True,
        selected_sheets=None, preserve_selected_existing=False,
        body_icons_use_original_size=False, report_collector=None,
        body_style=None, icon_style=None, alignment_settings=None,
        progress_callback=None, cancel_event=None, show_completion_dialogs=False,
        performance_mode=False, icon_gap_left=None, icon_gap_right=None,
        heading_icon_gap=None, render_backend=backend,
    )
    return backend


@pytest.mark.skipif(
    not layout_engine.canonical_layout_enabled(),
    reason="Canonical layout disabled",
)
def test_png_manifest_self_parity(tmp_path):
    """Two identical canonical runs must produce byte-identical manifests."""
    manifest_a = tmp_path / "manifest_a"
    manifest_b = tmp_path / "manifest_b"
    for name in ("a", "b"):
        wb_path = tmp_path / f"{name}.xlsx"
        _make_workbook(str(wb_path))
        _build_png(wb_path, tmp_path / f"out_{name}", manifest_name_dir := manifest_a if name == "a" else manifest_b)
    files_a = sorted(os.listdir(manifest_a))
    files_b = sorted(os.listdir(manifest_b))
    assert files_a == files_b and files_a
    for name in files_a:
        data_a = (manifest_a / name).read_bytes()
        data_b = (manifest_b / name).read_bytes()
        assert data_a == data_b, f"manifest drift in {name}"


@pytest.mark.skipif(not _HAS_PSAPI, reason="photoshopapi not available")
@pytest.mark.skipif(
    not layout_engine.canonical_layout_enabled(),
    reason="Canonical layout disabled",
)
def test_manifest_png_vs_psapi(tmp_path):
    """Structural + horizontal parity between PNG and PSAPI renderers."""
    wb_path = tmp_path / "parity.xlsx"
    _make_workbook(str(wb_path))

    png_manifest_dir = tmp_path / "png_manifest"
    _build_png(wb_path, tmp_path / "out_png", png_manifest_dir)
    with open(png_manifest_dir / "PAGE1.layout.json", encoding="utf-8") as f:
        png_m = json.load(f)

    backend = _build_psapi(wb_path, tmp_path / "out_psd")
    psd_m = manifest_from_backend_ops(backend.op_log, 1920, 1080)

    png_pages = png_m["pages"]
    psd_pages = psd_m["pages"]
    assert len(png_pages) == len(psd_pages) == 1
    png_elements = [e for e in png_pages[0]["elements"] if e.get("type") == "text"]
    psd_elements = [e for e in psd_pages[0]["elements"] if e.get("type") == "text"]
    assert len(png_elements) == len(psd_elements) >= 2

    def _norm(value):
        return " ".join(str(value or "").split()).casefold()

    def _center(element):
        width = element.get("width") or 0
        if not width and element.get("line_widths"):
            width = element["line_widths"][0]
        return float(element.get("x") or 0) + float(width or 0) / 2.0

    canvas_center = 1920 / 2
    previous_png_y = previous_psd_y = None
    for index, (pe, se) in enumerate(zip(png_elements, psd_elements)):
        assert pe.get("type") == se.get("type") == "text"
        assert _norm(pe.get("text")) == _norm(se.get("text")), f"text order mismatch at {index}"
        assert abs(_center(pe) - canvas_center) <= 2.0, f"PNG element not centered at {index}"
        assert abs(_center(se) - canvas_center) <= 2.0, f"PSAPI element not centered at {index}"
        if index == 0:
            assert pe.get("y") == 120, "heading top margin mismatch for PNG"
            assert se.get("y") == 120 + 72, "heading baseline mismatch for PSAPI (visual_top + font_size)"
        py_, sy_ = float(pe["y"]), float(se["y"])
        if previous_png_y is not None:
            assert py_ > previous_png_y, "PNG y sequence not strictly increasing"
            assert sy_ > previous_psd_y, "PSAPI y sequence not strictly increasing"
        previous_png_y, previous_psd_y = py_, sy_
